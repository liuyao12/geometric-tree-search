"""Prospective once worker; Source authoring does not execute this file.

One independent declaration is frozen before any search. Five explicitly
scoped control populations and one new obligation-first symbolic producer
share the original whole limits. Baseline controls never seed the new search.
Only a reviewed exact whole plan and a separately consumed grant may run main.
This is neither a GCTS point engine nor a fixed Wang verifier machine.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback


VERSION = 'FPC-H1-obligation-search-worker-v4'
CASE_ID = 'obligation-fpc-h1-hi-point-not-line-0'
EXPERIMENT = 'FPC-H1-obligation-first-feasibility-v1'
MODULE_ROLES = ('checker', 'builders', 'reference', 'baseline_search', 'codec',
                'baseline_bank', 'producer', 'obligation_bank', 'point_adapter', 'point_bank',
                'intro_bank', 'regression_bank')
CONTROL_COUNTS = {'baseline56': 56, 'obligation47': 47, 'point20': 20,
                  'intro_integration1': 1, 'regression2': 2}
PRODUCTION_CONFIGURATION = {
    'schema': 'FPC-H1-obligation-configuration-v1', 'control_only': False,
    'variables': 8, 'term_depth': 2, 'fallback_witness_nodes': 9,
    'obligation_nodes': 512, 'priority_subformula_nodes': 512,
    'intro_depth': 8, 'oldest_period': 4, 'ordering': 'FOCUSED',
}
KERNEL_PINS = {
    'checker': (31557, '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'),
    'builders': (11348, 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'),
    'reference': (24681, 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'),
}
DECLARATIONS_PIN = (8614, 'c6ae5f616b61e85f4b5cbd2b1e7619c047f42d83afd725e277475292cd904b0a')
AUTHORITY_PIN = (7910, '2e7cc31d6e72107d3811cf6a980ec261e0122c8736d4520db9cea119317eb54d')
CAPS = dict(work_seconds=160, positive_seconds=180, custody_seconds=210,
            observer_fallback_seconds=225, memory_bytes=1073741824,
            physical_bytes=134217728, result_bytes=50331648,
            log_bytes=4194304, reserved_outer_bytes=9437184,
            root_callbacks=400000000)


class RootBudget(RuntimeError):
    """Only a genuine whole-worker limit may create this owned condition."""


def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module


def main(plan_path, actual_dir, root_start):
    if not (sys.platform == 'darwin' and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode and os.getpid() == os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start)
            and 0 <= root_start <= time.monotonic()):
        raise ValueError('isolated owned Darwin child and genuine parent start required')
    began = root_start
    directory, plan_path = Path(actual_dir), Path(plan_path)
    plan_pin = raw_pin(plan_path)
    plan_body = plan_path.read_bytes()
    if byte_identity(plan_body) != {k: plan_pin[k] for k in ('bytes', 'sha256')}:
        raise ValueError('stable exact complete plan bytes required')
    plan = json.loads(plan_body)
    del plan_body
    if not (directory.is_absolute() and directory.resolve() == directory
            and not directory.is_symlink() and directory.is_dir()
            and plan['schema'] == 'proof-search-case-once-plan-v1'
            and plan['case_id'] == CASE_ID and plan['stage'] == 'evaluate'
            and plan['experiment'] == EXPERIMENT
            and plan['required_upstream_ids'] == []
            and plan['actual_dir'] == str(directory)
            and Path(plan['worker_path']) == Path(__file__).resolve()):
        raise ValueError('exact new search-feasibility plan and owned directory required')
    if not all(type(plan['limits'].get(k)) is int and plan['limits'][k] == v
               for k, v in CAPS.items()):
        raise ValueError('unchanged original whole ceilings required')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'], CAPS['physical_bytes']))
    consumed = json.loads((directory / 'CONSUMED.json').read_bytes())
    if not (consumed['schema'] == 'proof-search-case-consumed-v1'
            and consumed['plan_sha256'] == plan_pin['sha256']
            and consumed['case_id'] == CASE_ID
            and type(consumed['uses']) is int and consumed['uses'] == 1):
        raise ValueError('fresh exact once consumption required')

    state = dict(stage='PIN_INTAKE', callbacks=0, first_fault=None,
                 stages=[], versions={})
    primary, guards, source_unchanged = None, [], False
    input_freeze = qualification = search_receipt = subject_receipt = reference_receipt = point_receipt = None
    frozen_query = candidate_bytes = None
    scientific = None

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        fault = None
        if state['callbacks'] > CAPS['root_callbacks']:
            fault = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic() - began >= CAPS['work_seconds']:
            fault = RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            fault = RootBudget('strict Python whole high-water ceiling')
        if fault is not None:
            state['first_fault'] = fault
            raise fault

    def stage(name, operation):
        check()
        state['stage'] = name
        item = dict(name=name, began=time.monotonic() - began, status='STARTED')
        state['stages'].append(item)
        answer = operation()
        check()
        item.update(status='COMPLETED', seconds=time.monotonic() - began - item['began'])
        return answer

    def verify_files(cooperative):
        for row in guards:
            if cooperative:
                check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed declared Source/input: ' + row['path'])

    try:
        check()
        if type(plan['files']) is not list or not plan['files']:
            raise ValueError('closed nonempty exact guard list required')
        guards = [pin_fields(row) for row in plan['files']]
        if len({row['path'] for row in guards}) != len(guards):
            raise ValueError('unique guarded raw paths required')
        by_path = {row['path']: row for row in guards}
        if type(plan['module_pins']) is not dict or set(plan['module_pins']) != set(MODULE_ROLES):
            raise ValueError('only twelve exact scientific Source roles permitted')
        module_pins = {role: pin_fields(plan['module_pins'][role]) for role in MODULE_ROLES}
        for role, row in module_pins.items():
            if by_path.get(row['path']) != row:
                raise ValueError('all imported modules must belong to exact guards')
            if role in KERNEL_PINS and (row['bytes'], row['sha256']) != KERNEL_PINS[role]:
                raise ValueError('frozen primitive kernel Source changed')
        for key in ('protocol', 'python', 'declarations', 'target_authority'):
            row = pin_fields(plan[key])
            if by_path.get(row['path']) != row:
                raise ValueError('all plan, input and authority pins must be guarded')
        if (plan['declarations']['bytes'], plan['declarations']['sha256']) != DECLARATIONS_PIN:
            raise ValueError('exact unchanged six independent declarations required')
        if (plan['target_authority']['bytes'], plan['target_authority']['sha256']) != AUTHORITY_PIN:
            raise ValueError('explicit phase-freeze authority successor required')
        if (by_path.get(str(Path(__file__).resolve())) != raw_pin(Path(__file__).resolve())
                or raw_pin(Path(sys.executable).resolve()) != pin_fields(plan['python'])):
            raise ValueError('exact current worker and isolated runtime required')
        populations = plan['control_populations']
        if type(populations) is not dict or set(populations) != set(CONTROL_COUNTS):
            raise ValueError('five separately declared original/additive control populations required')
        scoped_ids = []
        for name, count in CONTROL_COUNTS.items():
            ids = populations[name]['control_ids']
            if not (type(ids) is list and len(ids) == count
                    and all(type(x) is str and x for x in ids)
                    and len(set(ids)) == count):
                raise ValueError('fixed complete unique ordered control population required')
            scoped_ids.extend((name, value) for value in ids)
        if len(set(scoped_ids)) != sum(CONTROL_COUNTS.values()):
            raise ValueError('control identities are (population,id); literal IDs may recur across banks')
        configuration_frozen = serialize(PRODUCTION_CONFIGURATION, CAPS['log_bytes'])
        if serialize(plan['configuration'], CAPS['log_bytes']) != configuration_frozen:
            raise ValueError('exact full production scope/order required; no control-only target shrink')
        verify_files(True)
        modules = {}
        for role in MODULE_ROLES:
            modules[role] = stage('IMPORT ' + role, lambda role=role: load_exact(
                module_pins[role], 'owned_fpc_obligation_worker_' + role + '_v4', check))
            state['versions'][role] = modules[role].VERSION

        def freeze_input():
            check()
            declarations = json.loads(Path(plan['declarations']['path']).read_bytes())
            if declarations['schema'] != 'FPC-H1-six-public-development-target-declarations-v1':
                raise ValueError('exact six-target carrier required')
            if not (type(plan['target_index']) is int and plan['target_index'] == 3
                    and plan['target_id'] == 'HI-point-not-line'):
                raise ValueError('prospectively fixed feasibility manifest slot required')
            spec = declarations['targets'][plan['target_index']]
            if not (spec['id'] == plan['target_id'] and spec['mode'] == 0
                    and spec['hypotheses'] == []):
                raise ValueError('same independent closed theorem target required')
            literal_spec_body = serialize(spec, CAPS['result_bytes'])
            supplied_spec = json.loads(literal_spec_body)
            check()
            encoded = modules['codec'].encode_declared_query(supplied_spec, check=check)
            check()
            if (serialize(spec, CAPS['result_bytes']) != literal_spec_body
                    or serialize(supplied_spec, CAPS['result_bytes']) != literal_spec_body):
                raise ValueError('codec mutated the independent literal declaration')
            spec = json.loads(literal_spec_body)
            if not (type(encoded) is dict and set(encoded) == {'query_bytes', 'receipt'}
                    and type(encoded['query_bytes']) is bytes
                    and type(encoded['receipt']) is dict):
                raise ValueError('complete exact codec output carrier required')
            query_bytes = encoded['query_bytes']
            codec_receipt = encoded['receipt']
            if not (codec_receipt.get('complete') is True
                    and codec_receipt.get('declaration_id') == spec['id']
                    and type(codec_receipt.get('expanded_goal')) is list
                    and codec_receipt.get('query_identity') == byte_identity(query_bytes)):
                raise ValueError('complete declaration/query/expanded-goal codec association required')
            # Parse-only consistency is not proof authority or cross-representation comparison.
            parsed = modules['checker'].decode_query(query_bytes, check=check)
            if not (parsed['version'] == 1 and parsed['claim_mode'] == spec['mode']
                    and parsed['theory_profile'] == spec['profile_id']
                    and parsed['function_arities'] == spec['function_arities']
                    and parsed['predicate_arities'] == spec['predicate_arities']
                    and parsed['Gamma'] == spec['hypotheses']
                    and parsed['finite_axioms'] == [] and parsed['EOF'] == len(query_bytes)):
                raise ValueError('encoded query profile/signature/mode/Gamma/EOF mismatch')
            expected_association = dict(profile_id=spec['profile_id'],
                function_arities=spec['function_arities'], predicate_arities=spec['predicate_arities'],
                mode=spec['mode'], hypotheses=spec['hypotheses'], expanded_goal=parsed['goal'],
                query_identity=byte_identity(query_bytes))
            actual_association = {key: codec_receipt.get(key) for key in expected_association}
            # Canonical JSON comparison preserves bool/int/float distinctions in these JSON trees.
            if serialize(actual_association, CAPS['result_bytes']) != serialize(expected_association, CAPS['result_bytes']):
                raise ValueError('codec receipt does not bind exact parsed goal and independent query fields')
            check()
            query_path = directory / 'target-query.bin'
            write_body(query_path, query_bytes)
            record = dict(schema='FPC-H1-in-job-independent-target-freeze-v1',
                declaration=pin_fields(plan['declarations']), target_index=plan['target_index'],
                literal_declaration=spec, codec_Source=module_pins['codec'],
                codec_receipt=encoded['receipt'], decoded_query=parsed,
                immutable_query=raw_pin(query_path), search_started=False,
                scope='Provisional independent input binding only; no proof or admission')
            write_body(directory / 'target-input-freeze.json', serialize(record, CAPS['result_bytes']))
            check()
            return query_bytes, record

        frozen_query, input_freeze = stage('FREEZE independent target before any search', freeze_input)
        exact_query_identity = byte_identity(frozen_query)
        kernel_modules = {role: modules[role] for role in ('checker', 'builders', 'reference')}
        qualification = {}

        def qualify_population(name, operation, schema, counts):
            result = stage('CONTROLS ' + name, operation)
            check()
            ids = populations[name]['control_ids']
            if not (type(result) is dict and result.get('schema') == schema
                    and result.get('complete') is True
                    and result.get('control_ids') == ids
                    and type(result.get('controls')) is list
                    and all(type(x) is dict for x in result['controls'])
                    and [x.get('id') for x in result['controls']] == ids
                    and all(x.get('passed') is True for x in result['controls'])
                    and type(result.get('counts')) is dict
                    and set(result['counts']) == set(counts)
                    and all(type(result['counts'][key]) is int for key in counts)
                    and result['counts'] == counts):
                raise ValueError('complete ordered whole population required; no prefix or replacement')
            return result

        # Old API/expectations remain attached to their original unchanged baseline.
        # Its synthetic controls are not a qualification of the new producer.
        qualification['baseline56'] = qualify_population('baseline56', lambda:
            modules['baseline_bank'].run_search_controls(search=modules['baseline_search'],
                codec=modules['codec'], modules=kernel_modules, check=check),
            'FPC-H1-independent-search-controls-v1', dict(total=56, passed=56, failed=0))
        qualification['obligation47'] = qualify_population('obligation47', lambda:
            modules['obligation_bank'].run_obligation_controls(modules['producer'],
                modules=kernel_modules, check=check),
            'FPC-H1-independent-obligation-controls-v1', dict(groups=47, passed=47, failed=0))
        qualification['intro_integration1'] = qualify_population('intro_integration1', lambda:
            modules['intro_bank'].run_intro_integration_control(modules['producer'],
                modules=kernel_modules, check=check),
            'FPC-H1-obligation-INTRO-integration-control-v1', dict(groups=1, passed=1, failed=0))
        qualification['regression2'] = qualify_population('regression2', lambda:
            modules['regression_bank'].run_obligation_regression_controls(modules['producer'],
                modules=kernel_modules, check=check),
            'FPC-H1-obligation-two-defect-regressions-v1', dict(groups=2, passed=2, failed=0))
        qualification['point20'] = qualify_population('point20', lambda:
            modules['point_bank'].run_point_row_controls(modules['point_adapter'],
                builders=modules['builders'], check=check),
            'FPC-H1-point-row-independent-controls-v1', dict(groups=20, passed=20, failed=0))
        supplied_configuration = json.loads(configuration_frozen)
        expected_query = dict(exact_query_identity)
        for key in ('version', 'claim_mode', 'function_arities', 'predicate_arities',
                    'theory_profile', 'finite_axioms', 'Gamma', 'goal'):
            check()
            expected_query[key] = input_freeze['decoded_query'][key]
        query_association_frozen = serialize(expected_query, CAPS['result_bytes'])
        del expected_query
        search_receipt = stage('SEARCH obligation producer on same independent query', lambda:
            modules['producer'].search_obligations(frozen_query,
                configuration=supplied_configuration,
                modules={role: modules[role] for role in ('checker', 'builders')}, check=check))
        check()
        for configuration_value in (plan['configuration'], supplied_configuration,
                                    PRODUCTION_CONFIGURATION):
            check()
            if serialize(configuration_value, CAPS['log_bytes']) != configuration_frozen:
                raise ValueError('producer changed supplied, plan or independent production configuration')
        if byte_identity(frozen_query) != exact_query_identity:
            raise ValueError('frozen immutable query changed')
        if not (type(search_receipt) is dict
                and set(search_receipt) == {'status', 'candidate_certificate_bytes', 'receipt'}
                and type(search_receipt['receipt']) is dict
                and search_receipt['receipt'].get('schema') == 'FPC-H1-obligation-search-receipt-v1'
                and search_receipt['receipt'].get('accepted') is False
                and type(search_receipt['receipt'].get('coverage')) is dict
                and search_receipt['receipt']['coverage'].get('restricted') is True
                and search_receipt['receipt']['coverage'].get('exhaustion_claim') is False):
            raise ValueError('exact scoped obligation receipt required; no exhaustion/nonprovability claim')
        if (serialize(search_receipt['receipt'].get('configuration'), CAPS['log_bytes'])
                != configuration_frozen
                or serialize(search_receipt['receipt'].get('query'), CAPS['result_bytes'])
                != query_association_frozen):
            raise ValueError('receipt must bind exact immutable query fields and full production scope')
        status = search_receipt['status']
        if search_receipt['receipt'].get('status') != status:
            raise ValueError('outer and complete receipt status must agree')
        if status == 'CANDIDATE_FOUND':
            candidate_bytes = search_receipt.get('candidate_certificate_bytes')
            if type(candidate_bytes) is not bytes or not candidate_bytes:
                raise ValueError('new complete immutable candidate certificate required')
            write_body(directory / 'candidate-certificate.bin', candidate_bytes)
            subject_receipt = stage('VALIDATE exact candidate with subject', lambda:
                modules['checker'].check_certificate(frozen_query, candidate_bytes, check=check))
            reference_receipt = stage('VALIDATE same bytes with independent reference', lambda:
                modules['reference'].reference_check_certificate(frozen_query, candidate_bytes, check=check))
            if not (type(subject_receipt) is dict
                    and subject_receipt.get('status') == 'VALID_DERIVATION'
                    and all(subject_receipt.get(k) is True for k in
                        ('complete', 'accepted', 'syntax_complete', 'derivation_complete',
                         'no_prefix_authority', 'final_goal_equal'))
                    and subject_receipt['raw_inputs']['query'] == exact_query_identity
                    and subject_receipt['raw_inputs']['certificate'] == byte_identity(candidate_bytes)):
                raise ValueError('produced candidate failed complete subject/integrity gates')
            if not (type(reference_receipt) is dict
                    and reference_receipt.get('schema') == 'FPC-H1-independent-flat-reference-v2'
                    and reference_receipt.get('status') == 'VALID_DERIVATION'
                    and reference_receipt.get('complete_check') is True
                    and reference_receipt.get('final_goal_equal') is True):
                raise ValueError('produced candidate failed independent complete reference gates')
            # The subject receipt holds the paired parse of these exact immutable
            # bytes. Its validity has already been checked independently above.
            point_input_before = serialize(dict(query=subject_receipt['query'],
                certificate=subject_receipt['certificate']), CAPS['result_bytes'])
            point_receipt = stage('ENCODE validated primitive rows as point markings', lambda:
                modules['point_adapter'].check_rows_as_points(subject_receipt['query'],
                    subject_receipt['certificate'], builders=modules['builders'], check=check))
            check()
            if serialize(dict(query=subject_receipt['query'],
                    certificate=subject_receipt['certificate']), CAPS['result_bytes']) != point_input_before:
                raise ValueError('point adapter mutated the paired validated parser records')
            del point_input_before
            if not (type(point_receipt) is dict
                    and point_receipt.get('schema') == 'FPC-H1-point-row-observation-v1'
                    and point_receipt.get('complete') is True
                    and point_receipt.get('point_compatible') is True
                    and point_receipt.get('mismatches') == []
                    and point_receipt.get('proof_admitted') is False
                    and point_receipt.get('search_engine') is False
                    and point_receipt.get('GCTS_conformance') is False
                    and type(point_receipt.get('row_count')) is int
                    and point_receipt['row_count'] == subject_receipt['certificate']['row_count']):
                raise ValueError('complete same-certificate point representation required')
            scientific = dict(status='FOUND_VALID_PENDING_ROOT_WHOLE_ADMISSION',
                query=exact_query_identity, certificate=byte_identity(candidate_bytes),
                same_immutable_inputs_to_both_validators=True,
                point_representation='COMPATIBLE_CANONICAL_ROWS_NOT_GCTS_SEARCH',
                representation_scope='No automatic AST/flat-token/span normalization claimed')
        elif status in ('UNKNOWN_DECLARED_PRODUCER', 'SOURCE_OUTSIDE_DECLARED_SCOPE'):
            if search_receipt.get('candidate_certificate_bytes') is not None:
                raise ValueError('nonfound result cannot carry a candidate certificate')
            scientific = dict(status=status, query=exact_query_identity,
                scope='Scoped producer unknown or exact input-scope refusal; no exhaustion/nonprovability')
        else:
            raise ValueError('undeclared search status or incomplete ordinary return')
        check()
    except BaseException as error:
        if type(error) is RootBudget and state['first_fault'] is None:
            state['first_fault'] = error
        primary = state['first_fault'] if state['first_fault'] is not None else error
    finally:
        try:
            verify_files(primary is None)
            source_unchanged = bool(guards)
        except BaseException as error:
            source_unchanged = False
            if primary is None:
                primary = state['first_fault'] if state['first_fault'] is not None else error

    def receipt():
        # This is a representation change of an exact bytes field, not a decoder.
        # Full output is withheld on any whole-job failure, regardless of stages.
        saved_search = None
        if primary is None and search_receipt is not None:
            saved_search = {key: value for key, value in search_receipt.items()
                            if key != 'candidate_certificate_bytes'}
            saved_search['candidate_certificate_hex'] = candidate_bytes.hex() if candidate_bytes is not None else None
        return dict(schema='proof-search-case-worker-v1', case_id=CASE_ID, stage='evaluate',
            worker_version=VERSION, status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            stages=state['stages'], callbacks=state['callbacks'],
            elapsed_seconds=time.monotonic() - began, source_unchanged=source_unchanged,
            python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            native_peak_bytes=0, native_requests_started=0, native_queries=[],
            native_transport=dict(closed=True, all_reaped=True, native_exit_code=0,
                native_high_water_bytes=0, subprocesses_started=0,
                scope='VACUOUS: no Native imports, oracle or subprocesses'),
            guard_compilations=[], work_snapshots=[], qualification_complete=primary is None,
            qualification_result=qualification if primary is None else None,
            input_freeze=input_freeze if primary is None else None,
            search_result=saved_search, subject_receipt=subject_receipt if primary is None else None,
            reference_receipt=reference_receipt if primary is None else None,
            point_receipt=point_receipt if primary is None else None,
            scientific_result=scientific if primary is None else None,
            independent_external_controls=None,
            error=None if primary is None else dict(type=type(primary).__name__, message=str(primary),
                traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,
            old_qualification_reused=False, component_versions=state['versions'],
            scope='One fresh obligation-first symbolic search; original56 baseline controls, '
                  'additive47 producer, one INTRO integration 20 point and two defect regression controls stay separately scoped. '
                  'Every provisional output is nonadmitted until whole custody/review/Root disposition. '
                  'No GCTS/Graph/RL, fixed verifier machine/palette, truth/consistency, '
                  'full Hilbert geometry, broad completeness or advantage claim')

    try:
        if primary is None:
            check()
        body = serialize(receipt(), CAPS['result_bytes'])
        if primary is None:
            check()
    except BaseException as error:
        if primary is None:
            if type(error) is RootBudget and state['first_fault'] is None:
                state['first_fault'] = error
            primary = state['first_fault'] if state['first_fault'] is not None else error
        body = serialize(receipt(), CAPS['result_bytes'])
    result_path = directory / ('result.json' if primary is None else 'failure.json')
    write_body(result_path, body)
    del body
    result_pin = raw_pin(result_path)
    header = dict(schema='proof-search-case-worker-header-v1', case_id=CASE_ID,
        status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'], seconds=time.monotonic() - began,
        python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0, source_unchanged=source_unchanged,
        native_closed_and_reaped=True, first_Root_fault=state['first_fault'] is not None,
        result=result_pin, native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory / 'worker-header.json', serialize(header, CAPS['log_bytes']))
    print(json.dumps(dict(case_id=CASE_ID, status=header['status'], callbacks=state['callbacks'],
                          seconds=time.monotonic() - began)))
    return 0 if (primary is None and source_unchanged
        and time.monotonic() - began < CAPS['positive_seconds']
        and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < CAPS['memory_bytes']) else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: fpc_h1_obligation_search_worker_v4.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1], sys.argv[2], float(sys.argv[3])))
