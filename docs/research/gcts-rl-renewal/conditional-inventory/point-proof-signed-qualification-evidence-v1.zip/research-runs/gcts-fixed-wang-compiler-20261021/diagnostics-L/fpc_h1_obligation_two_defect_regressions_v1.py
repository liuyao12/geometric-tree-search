"""Two separate synthetic regressions, UNRUN Source; original124 unchanged.

Only a malformed compiler-plan INPUT and a charged diagnostic fault selector.
No old proof state, six-target hint, runtime ordinal sampling or private patch.
"""
import hashlib
import json

VERSION = 'FPC-H1-obligation-two-defect-regressions-v1'
RETURN_SCHEMA = 'FPC-H1-obligation-two-defect-regressions-v1'
POPULATION = 'regression2'
CONTROL_IDS = (
    'refuse-extra-INTRO-reused-owned-context',
    'constructor-StopIteration-first-fault-and-owned-cleanup',
)
EXPECTED_PRODUCER_VERSION = 'FPC-H1-OBLIGATION-PRODUCER-v2'
PRODUCER_SOURCE = {
    'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_obligation_producer_v2.py',
    'bytes': 105517,
    'sha256': 'fa135ec9e84cdb84b0be506d74a1f167e619b7ac82fcb6a1d8b8782c738523d1',
}
# Ordinal is proven against that exact Source, never measured by a trial call.
CONSTRUCTOR_PHASE_ORDINAL = 3
PLAN_QUERY = {
    'profile_id': 0, 'mode': 0, 'function_arities': [0], 'predicate_arities': [1, 1],
    'finite_axioms': [], 'Gamma': [],
    'goal': ['imp', ['pred', 0, [['fun', 0, []]]],
             ['imp', ['pred', 1, [['fun', 0, []]]], ['pred', 1, [['fun', 0, []]]]]],
}
# Literal canonical child-ID input: c,A,B,(B->B),F,(F->F),H1(F,F).
# This is a deliberately MALFORMED qualification plan, not a search input.
MALFORMED_PLAN = {
    'schema': 'FPC-H1-obligation-plan-v1',
    'arena': [
        {'id': 0, 'sort': 'T', 'tag': 'fun', 'symbol': 0, 'children': []},
        {'id': 1, 'sort': 'F', 'tag': 'pred', 'symbol': 0, 'children': [0]},
        {'id': 2, 'sort': 'F', 'tag': 'pred', 'symbol': 1, 'children': [0]},
        {'id': 3, 'sort': 'F', 'tag': 'imp', 'symbol': None, 'children': [2, 2]},
        {'id': 4, 'sort': 'F', 'tag': 'imp', 'symbol': None, 'children': [1, 3]},
        {'id': 5, 'sort': 'F', 'tag': 'imp', 'symbol': None, 'children': [4, 4]},
        {'id': 6, 'sort': 'F', 'tag': 'imp', 'symbol': None, 'children': [4, 5]},
    ],
    'contexts': [
        {'id': 0, 'parent': None, 'opener': None, 'assumption': None},
        {'id': 1, 'parent': 0, 'opener': 2, 'assumption': 1},
        {'id': 2, 'parent': 0, 'opener': 4, 'assumption': 1},
        {'id': 3, 'parent': 1, 'opener': 1, 'assumption': 2},
    ],
    'nodes': [
        {'id': 0, 'context': 3, 'formula': 2, 'operator': 'HYP', 'premises': [], 'payload': {'index': 1}},
        {'id': 1, 'context': 1, 'formula': 3, 'operator': 'INTRO', 'premises': [0], 'payload': {'child_context': 3}},
        {'id': 2, 'context': 0, 'formula': 4, 'operator': 'INTRO', 'premises': [1], 'payload': {'child_context': 1}},
        {'id': 3, 'context': 2, 'formula': 3, 'operator': 'INTRO', 'premises': [0], 'payload': {'child_context': 3}},
        {'id': 4, 'context': 0, 'formula': 4, 'operator': 'INTRO', 'premises': [3], 'payload': {'child_context': 2}},
        {'id': 5, 'context': 0, 'formula': 6, 'operator': 'LOGICAL_AXIOM', 'premises': [],
         'payload': {'tag': 0, 'witness': [{'sort': 'F', 'id': 4}, {'sort': 'F', 'id': 4}]}},
        {'id': 6, 'context': 0, 'formula': 5, 'operator': 'MP', 'premises': [2, 5], 'payload': {}},
        {'id': 7, 'context': 0, 'formula': 4, 'operator': 'MP', 'premises': [4, 6], 'payload': {}},
    ],
    'root': 7,
}
FAULT_QUERY = {
    'profile_id': 0, 'mode': 1, 'function_arities': [0],
    'predicate_arities': [1, 1, 1, 1], 'finite_axioms': [],
    'Gamma': [['pred', 0, [['fun', 0, []]]]],
    'goal': ['pred', 0, [['fun', 0, []]]],
}
FAULT_CONFIGURATION = {
    'schema': 'FPC-H1-obligation-configuration-v1', 'control_only': True,
    'variables': 0, 'term_depth': 0, 'fallback_witness_nodes': 0,
    'obligation_nodes': 5, 'priority_subformula_nodes': 5,
    'intro_depth': 0, 'oldest_period': 4, 'ordering': 'FOCUSED',
}


class RegressionControlFailure(AssertionError):
    pass


class _Call:
    def __init__(self, callback):
        self.callback, self.first = callback, None

    def fault(self):
        if self.first is not None:
            raise self.first

    def __call__(self):
        self.fault()
        try:
            self.callback()
        except BaseException as error:
            self.first = error
            raise


def _need(condition, reason):
    if condition is not True:
        raise RegressionControlFailure(reason)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def _clone(value, check):
    check()
    if type(value) is dict:
        result = {}
        for key, item in value.items():
            check()
            result[key] = _clone(item, check)
        return result
    if type(value) in (list, tuple):
        result = []
        for item in value:
            check()
            result.append(_clone(item, check))
        return result
    return value


def _unsigned(number, check):
    _need(type(number) is int and number >= 0, 'authored fixture integer')
    output = bytearray()
    while True:
        check()
        part = number & 127
        number >>= 7
        output.append(part | (128 if number else 0))
        if not number:
            return bytes(output)


def _tree_bytes(tree, check):
    # Generic positional writer for the literal profile0 control fragments only.
    output, pending = bytearray(), [tree]
    while pending:
        check()
        node = pending.pop()
        tag = node[0]
        if tag == 'imp':
            output.extend(_unsigned(3, check))
            pending.append(node[2])
            pending.append(node[1])
        else:
            _need(tag in ('fun', 'pred'), 'fixture fragment')
            output.extend(_unsigned(1 if tag == 'fun' else 0, check))
            output.extend(_unsigned(node[1], check))
            output.extend(_unsigned(len(node[2]), check))
            for child in reversed(node[2]):
                check()
                pending.append(child)
    return bytes(output)


def _query_bytes(spec, check):
    output = bytearray(b'FPC1')
    for value in (1, spec['mode']):
        check()
        output.extend(_unsigned(value, check))
    for arities in (spec['function_arities'], spec['predicate_arities']):
        check()
        output.extend(_unsigned(len(arities), check))
        for arity in arities:
            check()
            output.extend(_unsigned(arity, check))
    _need(spec['profile_id'] == 0 and spec['finite_axioms'] == [], 'empty profile0 table')
    output.extend(_unsigned(0, check))
    output.extend(_unsigned(0, check))
    output.extend(_unsigned(len(spec['Gamma']), check))
    for formula in spec['Gamma']:
        check()
        output.extend(_tree_bytes(formula, check))
    output.extend(_tree_bytes(spec['goal'], check))
    return bytes(output)


def _identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def _malformed_plan_control(producer, roles, check):
    plan, spec = _clone(MALFORMED_PLAN, check), _clone(PLAN_QUERY, check)
    before = _canonical([plan, spec])
    query = _query_bytes(spec, check)
    caught = None
    try:
        producer.compile_plan(query, plan, modules=roles, check=check)
    except BaseException as error:
        check.fault()
        if type(error) is not producer.ProducerInputError or not producer.is_owned_error(error):
            raise
        caught = error
    _need(caught is not None, 'extra INTRO reuse must owned-refuse, no candidate')
    _need(before == _canonical([plan, spec]), 'malformed plan and spec unchanged')
    check()
    return {'query_input': spec, 'query': _identity(query), 'query_hex': query.hex(),
            'input_plan': plan, 'expected': 'OWNED_ProducerInputError',
            'observed': {'class': type(caught).__name__, 'message': str(caught)},
            'all_eight_nodes_root_reachable': True,
            'isolated_defect': 'node3 does not own child_context3; legitimate opener is node1',
            'candidate_or_proof_admitted': False}


class _ConstructorFault:
    """Read-only public-progress selector, never a semantic search input."""
    def __init__(self, outer, progress):
        self.outer, self.progress = outer, progress
        self.E = StopIteration('intentional constructor generator first fault')
        self.F = RuntimeError('a second producer callback must not run')
        self.total, self.phase_count, self.after_first = 0, 0, 0
        self.fired, self.before_progress = False, None

    def __call__(self):
        if self.fired:
            self.after_first += 1
            raise self.F
        self.outer()
        self.total += 1
        if len(self.progress) != 1 or type(self.progress[0]) is not dict:
            return
        receipt = self.progress[0]
        operations, cursors = receipt.get('operations'), receipt.get('cursors')
        if (type(operations) is dict and operations.get('live_snapshot_complete') is False
                and type(cursors) is dict and bool(cursors)):
            self.phase_count += 1
            if self.phase_count == CONSTRUCTOR_PHASE_ORDINAL:
                _need(receipt.get('status') == 'STARTED' and receipt.get('accepted') is False,
                      'current unaccepted constructor phase')
                _need(cursors.get('catalogs') == {} and receipt.get('obligations') == [],
                      'selected callback precedes catalogs/root creation')
                _need(receipt.get('query', {}).get('Gamma') == FAULT_QUERY['Gamma'] and
                      receipt.get('query', {}).get('goal') == FAULT_QUERY['goal'],
                      'exact source-bearing query phase')
                self.before_progress = _canonical(receipt)
                self.fired = True
                raise self.E


def _constructor_fault_control(producer, roles, check):
    spec = _clone(FAULT_QUERY, check)
    configuration = _clone(FAULT_CONFIGURATION, check)
    before_inputs = _canonical([spec, configuration])
    query = _query_bytes(spec, check)
    progress = []
    probe = _ConstructorFault(check, progress)
    before_args, before_vars = probe.E.args, dict(vars(probe.E))
    escaped = False
    try:
        producer.search_obligations(query, configuration=configuration, modules=roles,
                                    check=probe, progress=progress)
    except BaseException as error:
        check.fault()
        if error is not probe.E:
            raise
        escaped = True
    _need(escaped and probe.fired and probe.phase_count == 3 and probe.after_first == 0,
          'nonvacuous exact first StopIteration, no later callback')
    _need(probe.E.args == before_args and vars(probe.E) == before_vars,
          'first exception args/attributes unchanged')
    _need(len(progress) == 1 and _canonical(progress[0]) == probe.before_progress,
          'owned cleanup must not rewrite saved progress')
    _need(before_inputs == _canonical([spec, configuration]), 'query/config input unchanged')
    check()
    return {'query_input': spec, 'configuration': configuration,
            'query': _identity(query), 'query_hex': query.hex(),
            'expected_producer_Source': _clone(PRODUCER_SOURCE, check),
            'selected_constructor_phase_ordinal': CONSTRUCTOR_PHASE_ORDINAL,
            'phase_callbacks_observed': probe.phase_count, 'total_callbacks_observed': probe.total,
            'callbacks_after_first': probe.after_first, 'same_exception_identity': True,
            'exception_args_attributes_unchanged': True,
            'public_progress_at_fault': json.loads(probe.before_progress),
            'owned_cleanup_observed': False,
            'owned_cleanup_authority': 'INDEPENDENT_SOURCE_REVIEW_AND_WHOLE_CUSTODY_ONLY',
            'cleanup_scope': 'No public iterator-close witness; no private/GC/frame inspection.',
            'traceback_context_compared': False, 'candidate_or_prefix_admitted': False}


def run_obligation_regression_controls(producer, *, modules, check):
    """Two additive groups only; run solely in separately reviewed whole scope."""
    call = _Call(check)
    call()
    _need(type(modules) is dict and set(modules) == {'checker', 'builders', 'reference'},
          'exact shared module carrier')
    _need(getattr(producer, 'VERSION', None) == EXPECTED_PRODUCER_VERSION,
          'this phase association is pinned to exact producer v2')
    roles = {'checker': modules['checker'], 'builders': modules['builders']}
    first = _malformed_plan_control(producer, roles, call)
    second = _constructor_fault_control(producer, roles, call)
    call()
    return {'schema': RETURN_SCHEMA, 'version': VERSION, 'complete': True,
            'population': POPULATION, 'control_ids': list(CONTROL_IDS),
            'controls': [{'id': CONTROL_IDS[0], 'passed': True, 'evidence': first},
                         {'id': CONTROL_IDS[1], 'passed': True, 'evidence': second}],
            'counts': {'groups': 2, 'passed': 2, 'failed': 0},
            'accepted': False, 'proof_admitted': False,
            'scope': 'Two qualification regressions, no six-goal result or observed cleanup proof.',
            'limitations': ['All original124 groups unchanged and separately scoped.',
                'Ordinal3 applies only to the exact pinned Source/query/public phase.',
                'Cleanup is Source/whole-custody evidence, not a direct runtime observation.',
                'No sweep of other callbacks, malformed plans, fairness or completeness.',
                'No fit, proof search success, GCTS/RL or fixed-palette claim.']}
