"""Independent UNRUN obligation-producer qualification Source.

Only literal generic synthetic inputs; no six-goal hints or old accepting state.
This module must only be imported/called inside future exact Root custody.
Fixture assembly is representation-only and occurs inside that future call.
"""
import hashlib
import json

VERSION = "FPC-H1-independent-obligation-controls-v2"
RETURN_SCHEMA = "FPC-H1-independent-obligation-controls-v1"

ORIGINAL_INPUT_DECLARATIONS = {'schema': 'F-L-obligation-first-independent-input-declarations-v1', 'status': 'LITERAL_INPUTS_ONLY_UNRUN_NO_PROOF_OR_CERTIFICATE', 'legend_latex': {'functions': '\\(c=f_0()\\)', 'predicates': '\\(A(c),B(c),C(c),D(c)\\) are unrelated unary predicates, not PA or geometry facts.', 'guard_variables': '\\(v_0,v_1,v_2,v_4\\) are exact literal object IDs.'}, 'query_count': 9, 'query_declarations': [{'id': 'context-Gamma-present', 'group': 'context-Gamma', 'mode': 1, 'finite_axioms': [], 'Gamma': [['pred', 0, [['fun', 0, []]]]], 'goal': ['pred', 0, [['fun', 0, []]]], 'expected_property': 'The explicit hypothesis may license this goal; any accepted export must cite the current query, not a cached derivation from another context.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, {'id': 'context-Gamma-absent', 'group': 'context-Gamma', 'mode': 1, 'finite_axioms': [], 'Gamma': [], 'goal': ['pred', 0, [['fun', 0, []]]], 'expected_property': 'A positive fact or HYP row from the preceding context must not transfer. A context-insensitive solved-obligation cache is unsound here.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, {'id': 'context-theory-present', 'group': 'context-theory', 'mode': 0, 'finite_axioms': [['pred', 1, [['fun', 0, []]]]], 'Gamma': [], 'goal': ['pred', 1, [['fun', 0, []]]], 'expected_property': 'Any finite-table derivation must refer to this current table/profile/signature and exact query.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, {'id': 'context-theory-absent', 'group': 'context-theory', 'mode': 0, 'finite_axioms': [], 'Gamma': [], 'goal': ['pred', 1, [['fun', 0, []]]], 'expected_property': 'A table fact from the preceding theory context must not transfer.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, {'id': 'cycle-without-seed', 'group': 'cycles', 'mode': 0, 'finite_axioms': [['imp', ['pred', 0, [['fun', 0, []]]], ['pred', 1, [['fun', 0, []]]]], ['imp', ['pred', 1, [['fun', 0, []]]], ['pred', 0, [['fun', 0, []]]]]], 'Gamma': [], 'goal': ['pred', 0, [['fun', 0, []]]], 'expected_property': 'A repeated in-progress obligation is a dependency/cycle marker, not a proven fact. Neither implication alone supplies an atomic premise; no positive cyclic certificate or circular refs.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, {'id': 'premise-source-first', 'group': 'premise-order', 'mode': 0, 'finite_axioms': [['pred', 2, [['fun', 0, []]]], ['imp', ['pred', 2, [['fun', 0, []]]], ['pred', 3, [['fun', 0, []]]]]], 'Gamma': [], 'goal': ['pred', 3, [['fun', 0, []]]], 'expected_property': 'Swapping ordinary table order must not lose an available primitive MP opportunity. No certificate/row order is supplied.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, {'id': 'premise-implication-first', 'group': 'premise-order', 'mode': 0, 'finite_axioms': [['imp', ['pred', 2, [['fun', 0, []]]], ['pred', 3, [['fun', 0, []]]]], ['pred', 2, [['fun', 0, []]]]], 'Gamma': [], 'goal': ['pred', 3, [['fun', 0, []]]], 'expected_property': 'Same semantic question as source-first, with implication first. All inferred refs must remain backward after fresh export.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, {'id': 'premise-duplicate-source', 'group': 'premise-order', 'mode': 0, 'finite_axioms': [['pred', 2, [['fun', 0, []]]], ['pred', 2, [['fun', 0, []]]], ['imp', ['pred', 2, [['fun', 0, []]]], ['pred', 3, [['fun', 0, []]]]]], 'Gamma': [], 'goal': ['pred', 3, [['fun', 0, []]]], 'expected_property': 'Duplicate source occurrences retain their table-index origins; they do not silently multiply a shared placement/fact, erase fallback ownership or authorize a stale ref.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, {'id': 'shared-context-diamond', 'group': 'shared-obligations', 'mode': 0, 'finite_axioms': [['pred', 0, [['fun', 0, []]]], ['imp', ['pred', 0, [['fun', 0, []]]], ['pred', 1, [['fun', 0, []]]]], ['imp', ['pred', 0, [['fun', 0, []]]], ['pred', 2, [['fun', 0, []]]]], ['imp', ['pred', 1, [['fun', 0, []]]], ['pred', 3, [['fun', 0, []]]]], ['imp', ['pred', 2, [['fun', 0, []]]], ['pred', 3, [['fun', 0, []]]]]], 'Gamma': [], 'goal': ['pred', 3, [['fun', 0, []]]], 'expected_property': 'If both alternatives open the same premise obligation in this exact context, one semantic obligation may share it with all requester origins retained. The engine may find either primitive proof; no requirement forces both alternatives to be explored after discovery.', 'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}], 'guard_request_count': 6, 'guard_declarations': [{'id': 'UI-capture-binder', 'operation': 'primitive-Q1-free-for', 'formula': ['all', 2, ['pred', 2, [['var', 0], ['var', 2]]]], 'substitution_variable': 0, 'term': ['var', 2], 'signature': {'function_arities': [0], 'predicate_arities': [1, 1, 2]}, 'expected': 'REFUSE_CAPTURE', 'reason_latex': 'Replacing a free \\(v_0\\) by \\(v_2\\) below \\(\\forall v_2\\) would capture it. This is an inference-guard expectation, not a claim that a selected whole goal is unprovable.'}, {'id': 'UI-closed-term-no-capture', 'operation': 'primitive-Q1-free-for', 'formula': ['all', 2, ['pred', 2, [['var', 0], ['var', 2]]]], 'substitution_variable': 0, 'term': ['fun', 0, []], 'signature': {'function_arities': [0], 'predicate_arities': [1, 1, 2]}, 'expected': 'ALLOW_FREE_FOR', 'reason_latex': 'The closed term \\(c\\) has no free variable to capture. This alone licenses neither a discovered fact nor a certificate.'}, {'id': 'UI-shadowed-target-ID', 'operation': 'primitive-substitution-scope', 'formula': ['all', 0, ['pred', 2, [['var', 0], ['var', 2]]]], 'substitution_variable': 0, 'term': ['var', 2], 'signature': {'function_arities': [0], 'predicate_arities': [1, 1, 2]}, 'expected': 'BOUND_TARGET_OCCURRENCES_UNCHANGED', 'reason_latex': 'An occurrence of \\(v_0\\) bound by the displayed \\(\\forall v_0\\) is not a free substitution site. Preserve literal IDs and scope.'}, {'id': 'rigid-binder-not-alpha-match', 'operation': 'rigid-pattern-match', 'pattern': ['all', 0, ['pred', 0, [['var', 0]]]], 'value': ['all', 1, ['pred', 0, [['var', 1]]]], 'expected': 'NOT_AN_EXACT_RIGID_MATCH', 'reason_latex': 'The binder/leaf IDs differ, even though the formulas are alpha-equivalent. No automatic renaming is permitted in exact wire or proof rows.'}, {'id': 'GEN-unused-Gamma-variable', 'operation': 'primitive-GEN-global-Gamma', 'formula': ['pred', 0, [['fun', 0, []]]], 'variable': 4, 'Gamma': [['pred', 0, [['fun', 0, []]]], ['pred', 1, [['var', 4]]]], 'signature': {'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, 'expected': 'REFUSE_GLOBAL_GAMMA', 'reason_latex': '\\(v_4\\) occurs free in an unused hypothesis. Direct GEN of \\(v_4\\) is forbidden even when it is absent from the displayed source formula. Another sound route to the same goal is not ruled out.'}, {'id': 'GEN-full-Gamma-clear', 'operation': 'primitive-GEN-global-Gamma', 'formula': ['pred', 0, [['fun', 0, []]]], 'variable': 4, 'Gamma': [['pred', 0, [['fun', 0, []]]], ['all', 4, ['pred', 1, [['var', 4]]]]], 'signature': {'function_arities': [0], 'predicate_arities': [1, 1, 1, 1]}, 'expected': 'ALLOW_GAMMA_SIDE_CONDITION', 'reason_latex': 'The unused hypothesis binds all displayed \\(v_4\\) occurrences. This clears only the full-Gamma side condition; primitive source/ref/export validation remains required.'}], 'representation': 'Core-tag JSON INPUT trees and declarative guard requests only. No query/certificate bytes, proof row, closure, accepting history, lemma or executable operation is generated here.', 'expected_outcome_scope': 'A future bounded control actual must distinguish observed positive/negative/UNKNOWN statuses. No completion time or practical fit is forecast. The two context-absent/cyclic atomic goals have no fact license from the supplied toy theories; no successful circular/cross-context proof may be accepted.', 'old_fixture_adoption': 'No old137/56 accepting output, proof/certificate/closure/result or mutable state is input. Fresh symbols/queries are declarative qualification fixtures, not the six mathematical search goals.'}

CONTROL_IDS = (
    'search-context-Gamma-present', 'search-context-Gamma-absent',
    'search-context-theory-present', 'search-context-theory-absent',
    'search-cycle-without-seed', 'search-premise-source-first',
    'search-premise-implication-first', 'search-premise-duplicate-source',
    'search-shared-context-diamond',
    'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture',
    'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable',
    'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable',
    'guard-induction-wrong-profile', 'guard-induction-wrong-parameters',
    'guard-induction-parameter-closure',
    'compile-intro-identity', 'compile-intro-root-hypothesis',
    'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions',
    'compile-intro-finite-table', 'compile-intro-logical-axiom',
    'compile-intro-PA-table', 'compile-intro-incidence-table',
    'compile-intro-induction', 'compile-full-FPC-deep-term',
    'compile-full-FPC-large-formula',
    'refuse-MP-premise-order', 'refuse-rigid-binder-HYP',
    'refuse-GEN-unused-root', 'refuse-GEN-unused-local',
    'refuse-context-opener', 'refuse-forward-premise',
    'refuse-duplicate-arena-row',
    'product-diagonal-2x2', 'product-open-WAIT-growth',
    'product-closed-empty-open-other', 'product-zero-arity',
    'fault-search-first-RuntimeError', 'fault-guard-StopIteration',
    'fault-compile-same-public-class', 'fault-retained-owned-through-guard',
    'fault-late-compile-first-before-second', 'fault-dual-validators',
)

A = ['pred', 0, [['fun', 0, []]]]
B = ['pred', 1, [['fun', 0, []]]]
C = ['pred', 2, [['fun', 0, []]]]
D = ['pred', 3, [['fun', 0, []]]]


class ControlFailure(AssertionError):
    """A completed synthetic qualification assertion failed; no proof authority."""


def _need(condition, label):
    if condition is not True:
        raise ControlFailure(label)


def _nat(value):
    return type(value) is int and value >= 0


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def _same(left, right):
    # JSON array/list versus tuple is representation only; bool/numeric differs.
    return _canonical(left) == _canonical(right)


def _clone(value, check):
    """Checked structural copy, not a formula transformer or expected oracle."""
    check()
    if type(value) is dict:
        result = {}
        for key, child in value.items():
            check()
            result[key] = _clone(child, check)
        return result
    if type(value) in (list, tuple):
        result = []
        for child in value:
            check()
            result.append(_clone(child, check))
        return result
    return value


def _identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def _unsigned(number, check):
    _need(_nat(number), 'bank unsigned fixture integer')
    result = bytearray()
    while True:
        check()
        byte = number & 127
        number >>= 7
        result.append(byte | (128 if number else 0))
        if not number:
            return bytes(result)


def _tree_bytes(tree, check):
    """Own direct positional wire writer; never calls a producer/codec/builder."""
    output = bytearray()
    pending = [('tree', tree)]
    tags = {'var': 0, 'fun': 1, 'pred': 0, 'eq': 1,
            'not': 2, 'imp': 3, 'all': 4}
    while pending:
        check()
        kind, value = pending.pop()
        if kind == 'number':
            output.extend(_unsigned(value, check))
            continue
        tag = value[0]
        output.extend(_unsigned(tags[tag], check))
        if tag == 'var':
            output.extend(_unsigned(value[1], check))
        elif tag in ('fun', 'pred'):
            output.extend(_unsigned(value[1], check))
            output.extend(_unsigned(len(value[2]), check))
            for child in reversed(value[2]):
                check()
                pending.append(('tree', child))
        elif tag == 'all':
            output.extend(_unsigned(value[1], check))
            pending.append(('tree', value[2]))
        else:
            for child in reversed(value[1:]):
                check()
                pending.append(('tree', child))
    return bytes(output)


def _query(spec, check):
    # This future-actual writer encodes only authored generic control inputs.
    output = bytearray(b'FPC1')
    output.extend(_unsigned(1, check))
    output.extend(_unsigned(spec['mode'], check))
    for signature in (spec['function_arities'], spec['predicate_arities']):
        check()
        output.extend(_unsigned(len(signature), check))
        for arity in signature:
            check()
            output.extend(_unsigned(arity, check))
    output.extend(_unsigned(spec['profile_id'], check))
    if spec['profile_id'] == 0:
        output.extend(_unsigned(len(spec['finite_axioms']), check))
        for formula in spec['finite_axioms']:
            check()
            output.extend(_tree_bytes(formula, check))
    output.extend(_unsigned(len(spec['Gamma']), check))
    for formula in spec['Gamma']:
        check()
        output.extend(_tree_bytes(formula, check))
    output.extend(_tree_bytes(spec['goal'], check))
    return bytes(output)


def _spec(goal, Gamma=None, table=None, profile=0, functions=None,
          predicates=None, mode=1, *, check):
    return {'mode': mode, 'profile_id': profile,
            'function_arities': _clone([0] if functions is None else functions, check),
            'predicate_arities': _clone([1, 1, 1, 1] if predicates is None else predicates, check),
            'finite_axioms': _clone([] if table is None else table, check),
            'Gamma': _clone([] if Gamma is None else Gamma, check),
            'goal': _clone(goal, check)}


def _configuration(check):
    check()
    return {'schema': 'FPC-H1-obligation-configuration-v1', 'control_only': True,
            'variables': 0, 'term_depth': 0, 'fallback_witness_nodes': 0,
            'obligation_nodes': 5, 'priority_subformula_nodes': 5,
            'intro_depth': 0, 'oldest_period': 4, 'ordering': 'FOCUSED'}


def _dual(modules, query, certificate, check):
    """Whole same-byte validation only; receipts have different representations."""
    _need(type(query) is bytes and type(certificate) is bytes, 'dual bytes')
    subject = modules['checker'].check_certificate(query, certificate, check=check)
    check()
    _need(subject.get('status') == 'VALID_DERIVATION', 'subject valid status')
    for key in ('accepted', 'syntax_complete', 'derivation_complete',
                'final_goal_equal', 'complete'):
        check()
        _need(subject.get(key) is True, 'subject whole gate ' + key)
    reference = modules['reference'].reference_check_certificate(
        query, certificate, check=check)
    check()
    _need(reference.get('status') == 'VALID_DERIVATION' and
          reference.get('complete_check') is True, 'reference complete valid')
    return {'query': _identity(query), 'certificate': _identity(certificate),
            'query_hex': query.hex(), 'certificate_hex': certificate.hex(),
            'subject': subject, 'reference': reference}


def _arena_plan(contexts, nodes, root, check):
    """Syntactic fixture assembler. Formula truth/guards are never inferred here.

    Inputs below are independently authored tree/node declarations. This helper
    only interns literal trees and converts them to the published child-ID ABI.
    It does not call builders or create proof nodes/lemmas from a target.
    """
    arena, index = [], {}

    def intern(tree):
        pending, resolved = [(tree, False)], {}
        while pending:
            check()
            node, done = pending.pop()
            key = _canonical(node)
            if key in index:
                resolved[key] = index[key]
                continue
            tag = node[0]
            if tag == 'var':
                children, symbol, sort = [], node[1], 'T'
            elif tag in ('fun', 'pred'):
                children, symbol = node[2], node[1]
                sort = 'T' if tag == 'fun' else 'F'
            elif tag == 'all':
                children, symbol, sort = [node[2]], node[1], 'F'
            else:
                children, symbol, sort = node[1:], None, 'F'
            if not done and children:
                pending.append((node, True))
                for child in reversed(children):
                    check()
                    pending.append((child, False))
                continue
            child_ids = []
            for child in children:
                check()
                child_ids.append(index[_canonical(child)])
            position = len(arena)
            arena.append({'id': position, 'sort': sort, 'tag': tag,
                          'symbol': symbol, 'children': child_ids})
            index[key] = position
            resolved[key] = position
        return resolved[_canonical(tree)]

    result_contexts = []
    for context in contexts:
        check()
        item = _clone(context, check)
        if item['assumption'] is not None:
            item['assumption'] = intern(item['assumption'])
        result_contexts.append(item)
    result_nodes = []
    for node in nodes:
        check()
        item = _clone(node, check)
        item['formula'] = intern(item['formula'])
        payload = item['payload']
        if item['operator'] == 'LOGICAL_AXIOM':
            atoms = []
            for atom in payload['witness']:
                check()
                if atom['sort'] == 'V':
                    atoms.append(_clone(atom, check))
                else:
                    atoms.append({'sort': atom['sort'], 'id': intern(atom['tree'])})
            payload['witness'] = atoms
        if item['operator'] == 'THEORY_AXIOM' and payload['tag'] == 2:
            payload['formula'] = intern(payload['formula'])
        result_nodes.append(item)
    return {'schema': 'FPC-H1-obligation-plan-v1', 'arena': arena,
            'contexts': result_contexts, 'nodes': result_nodes, 'root': root}


def _node(number, context, formula, operator, premises, payload, check):
    check()
    return {'id': number, 'context': context, 'formula': _clone(formula, check),
            'operator': operator, 'premises': _clone(premises, check),
            'payload': _clone(payload, check)}


def _intro_fixture(assumption, conclusion, leaf_operator, leaf_payload, spec, check):
    contexts = [{'id': 0, 'parent': None, 'opener': None, 'assumption': None},
                {'id': 1, 'parent': 0, 'opener': 1, 'assumption': assumption}]
    nodes = [_node(0, 1, conclusion, leaf_operator, [], leaf_payload, check),
             _node(1, 0, ['imp', assumption, conclusion], 'INTRO', [0],
                   {'child_context': 1}, check)]
    return spec, _arena_plan(contexts, nodes, 1, check)


def _compile_fixtures(check):
    """Hand-authored synthetic plan INPUTS, not discovered proofs or six targets."""
    result = []
    result.append(_intro_fixture(A, A, 'HYP', {'index': 0},
                  _spec(['imp', A, A], check=check), check))
    result.append(_intro_fixture(A, B, 'HYP', {'index': 0},
                  _spec(['imp', A, B], Gamma=[B], check=check), check))
    contexts = [{'id': 0, 'parent': None, 'opener': None, 'assumption': None},
                {'id': 1, 'parent': 0, 'opener': 3, 'assumption': A}]
    nodes = [_node(0, 1, A, 'HYP', [], {'index': 1}, check),
             _node(1, 1, ['imp', A, B], 'HYP', [], {'index': 0}, check),
             _node(2, 1, B, 'MP', [0, 1], {}, check),
             _node(3, 0, ['imp', A, B], 'INTRO', [2], {'child_context': 1}, check)]
    result.append((_spec(['imp', A, B], Gamma=[['imp', A, B]], check=check),
                   _arena_plan(contexts, nodes, 3, check)))
    contexts[1]['opener'] = 2
    nodes = [_node(0, 1, B, 'HYP', [], {'index': 0}, check),
             _node(1, 1, ['all', 4, B], 'GEN', [0], {'variable': 4}, check),
             _node(2, 0, ['imp', A, ['all', 4, B]], 'INTRO', [1],
                   {'child_context': 1}, check)]
    result.append((_spec(['imp', A, ['all', 4, B]], Gamma=[B], check=check),
                   _arena_plan(contexts, nodes, 2, check)))
    contexts = [{'id': 0, 'parent': None, 'opener': None, 'assumption': None},
                {'id': 1, 'parent': 0, 'opener': 2, 'assumption': A},
                {'id': 2, 'parent': 1, 'opener': 1, 'assumption': A}]
    nodes = [_node(0, 2, A, 'HYP', [], {'index': 0}, check),
             _node(1, 1, ['imp', A, A], 'INTRO', [0], {'child_context': 2}, check),
             _node(2, 0, ['imp', A, ['imp', A, A]], 'INTRO', [1],
                   {'child_context': 1}, check)]
    result.append((_spec(['imp', A, ['imp', A, A]], check=check),
                   _arena_plan(contexts, nodes, 2, check)))
    result.append(_intro_fixture(A, B, 'THEORY_AXIOM', {'tag': 0, 'index': 0},
                  _spec(['imp', A, B], table=[B], check=check), check))
    # Literal Q3 instance, independent of any builder return value.
    q3 = ['imp', A, ['all', 4, A]]
    result.append(_intro_fixture(B, q3, 'LOGICAL_AXIOM',
                  {'tag': 5, 'witness': [{'sort': 'F', 'tree': A},
                                        {'sort': 'V', 'value': 4}]},
                  _spec(['imp', B, q3], check=check), check))
    pa0 = ['all', 0, ['not', ['eq', ['fun', 1, [['var', 0]]], ['fun', 0, []]]]]
    eq00 = ['eq', ['fun', 0, []], ['fun', 0, []]]
    result.append(_intro_fixture(eq00, pa0, 'THEORY_AXIOM', {'tag': 1, 'index': 0},
                  _spec(['imp', eq00, pa0], profile=1, functions=[0, 1, 2, 2],
                        predicates=[], check=check), check))
    # HI-TYPE is a literal fixed table formula, not a geometry oracle.
    hi1 = ['all', 0, ['all', 3, ['imp',
        ['pred', 2, [['var', 0], ['var', 3]]],
        ['not', ['imp', ['pred', 0, [['var', 0]]],
                 ['not', ['pred', 1, [['var', 3]]]]]]]]]
    va = ['pred', 0, [['var', 6]]]
    result.append(_intro_fixture(va, hi1, 'THEORY_AXIOM', {'tag': 3, 'index': 1},
                  _spec(['imp', va, hi1], profile=2, functions=[],
                        predicates=[1, 1, 2], check=check), check))
    # Fully written parameter-closed induction schema for body v0=v1.
    induction = ['all', 1, ['imp',
        ['not', ['imp', ['eq', ['fun', 0, []], ['var', 1]],
            ['not', ['all', 0, ['imp', ['eq', ['var', 0], ['var', 1]],
                ['eq', ['fun', 1, [['var', 0]]], ['var', 1]]]]]]],
        ['all', 0, ['eq', ['var', 0], ['var', 1]]]]]
    result.append(_intro_fixture(eq00, induction, 'THEORY_AXIOM',
                  {'tag': 2, 'formula': ['eq', ['var', 0], ['var', 1]],
                   'variable': 0, 'parameters': [1]},
                  _spec(['imp', eq00, induction], profile=1,
                        functions=[0, 1, 2, 2], predicates=[], check=check), check))
    deep = ['pred', 0, [['fun', 1, [['fun', 1, [['fun', 1, [['fun', 0, []]]]]]]]]]
    result.append(_intro_fixture(deep, deep, 'HYP', {'index': 0},
                  _spec(['imp', deep, deep], functions=[0, 1], check=check), check))
    # Literal finite fixture definition executed only in the future actual.
    # 513 unary NOT constructors + P(c):515 nodes; not a discovery catalog entry.
    large = _clone(A, check)
    for unused in range(513):
        check()
        large = ['not', large]
    result.append(_intro_fixture(large, large, 'HYP', {'index': 0},
                  _spec(['imp', large, large], check=check), check))
    return result

def _search_check(producer, modules, declaration, check):
    spec = _clone(declaration, check)
    query = _query(spec, check)
    configuration = _configuration(check)
    before = _canonical([spec, configuration])
    progress = []
    result = producer.search_obligations(query, configuration=configuration,
        modules={'checker': modules['checker'], 'builders': modules['builders']},
        check=check, progress=progress)
    check()
    _need(type(result) is dict and set(result) ==
          {'status', 'candidate_certificate_bytes', 'receipt'}, 'search wrapper')
    receipt = result['receipt']
    _need(len(progress) == 1 and progress[0] is receipt, 'live progress ownership')
    _need(receipt.get('schema') == 'FPC-H1-obligation-search-receipt-v1' and
          receipt.get('accepted') is False and
          receipt.get('candidate_validation') == 'NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED',
          'search has no internal admission')
    _need(receipt.get('status') == result['status'], 'search status association')
    coverage = receipt['coverage']
    _need(coverage.get('restricted') is True and
          coverage.get('exhaustion_claim') is False, 'restricted not exhaustion')
    negative = declaration['id'] in ('context-Gamma-absent',
        'context-theory-absent', 'cycle-without-seed')
    _need(result['status'] == ('UNKNOWN_DECLARED_PRODUCER' if negative else
          'CANDIDATE_FOUND'), 'independent toy source/MP/cycle outcome')
    keys, solved = set(), {}
    for index, obligation in enumerate(receipt['obligations']):
        check()
        _need(obligation['id'] == index and type(obligation['id']) is int,
              'obligation IDs')
        key = (obligation['context_id'], obligation['formula_id'])
        _need(key not in keys, 'one node per exact context/formula')
        keys.add(key)
        if obligation['state'] == 'SOLVED':
            _need(_nat(obligation['solved_serial']), 'grounded solve serial')
            solved[index] = obligation['solved_serial']
    # This checks saved ordered incidences; it does not replay obligation search.
    watcher_keys = set()
    for watcher in receipt['cursors']['watchers']:
        check()
        key = (watcher['premise'], watcher['alternative'], watcher['position'])
        _need(key not in watcher_keys and type(watcher['notified']) is bool,
              'distinct ordered watcher incidence')
        watcher_keys.add(key)
    for alternative in receipt['alternatives']:
        check()
        for position, premise in enumerate(alternative['premise_ids']):
            check()
            _need((premise, alternative['id'], position) in watcher_keys,
                  'saved alternative ordered watcher coverage')
            if alternative['status'] == 'SELECTED':
                _need(premise in solved and alternative['owner'] in solved and
                      solved[premise] < solved[alternative['owner']],
                      'selected dependency is already grounded, never circular')
    _need(before == _canonical([spec, configuration]), 'search input immutability')
    evidence = {'input': spec, 'configuration': configuration, 'receipt': receipt,
                'query': _identity(query)}
    if negative:
        _need(result['candidate_certificate_bytes'] is None,
              'UNKNOWN has no candidate or proof prefix')
    else:
        evidence['dual_validation'] = _dual(modules, query,
            result['candidate_certificate_bytes'], check)
    return evidence


def _guard_cases(check):
    """Original guard trees are copied literally; added contexts are explicit."""
    old = ORIGINAL_INPUT_DECLARATIONS['guard_declarations']
    result = []
    substitutions = [None,
        ['all', 2, ['pred', 2, [['fun', 0, []], ['var', 2]]]],
        ['all', 0, ['pred', 2, [['var', 0], ['var', 2]]]]]
    for position in range(3):
        check()
        item = old[position]
        spec = _spec(A, predicates=item['signature']['predicate_arities'], check=check)
        request = {'kind': 'UI', 'formula': _clone(item['formula'], check),
            'variable': item['substitution_variable'], 'term': _clone(item['term'], check),
            'local_stack': []}
        result.append((spec, request,
            {'permitted': position != 0, 'reason': 'UI_CAPTURE' if position == 0 else 'OK',
             'evidence': {'free_for': position != 0,
                          'substitution_result': substitutions[position]}}))
    for position in (4, 5):
        check()
        item = old[position]
        spec = _spec(item['formula'], Gamma=item['Gamma'], check=check)
        result.append((spec, {'kind': 'GEN', 'variable': 4, 'local_stack': []},
            {'permitted': position == 5,
             'reason': 'OK' if position == 5 else 'GEN_FULL_CONTEXT_FV',
             'evidence': {'hypothesis_FV': [[], []] if position == 5 else [[], [4]],
                          'offending_indices': [] if position == 5 else [1]}}))
    result.append((_spec(A, Gamma=[A], check=check),
        {'kind': 'GEN', 'variable': 4,
         'local_stack': [{'owner': 7, 'formula': ['pred', 1, [['var', 4]]]}]},
        {'permitted': False, 'reason': 'GEN_FULL_CONTEXT_FV',
         'evidence': {'hypothesis_FV': [[], [4]], 'offending_indices': [1]}}))
    body = ['eq', ['var', 0], ['var', 1]]
    for profile, parameters, permitted, reason in (
        (0, [1], False, 'INDUCTION_WRONG_PROFILE'),
        (1, [], False, 'INDUCTION_PARAMETERS'),
        (1, [1], True, 'OK')):
        check()
        spec = _spec(['eq', ['fun', 0, []], ['fun', 0, []]], profile=profile,
                     functions=[0, 1, 2, 2], predicates=[], check=check)
        expected = {'expected_parameters': [1], 'parameter_equal': parameters == [1]}
        if profile == 0:
            expected.update({'capture_free': None, 'generated_formula': None})
        elif permitted:
            expected.update({'capture_free': True, 'generated_formula':
                ['all', 1, ['imp',
                    ['not', ['imp', ['eq', ['fun', 0, []], ['var', 1]],
                        ['not', ['all', 0, ['imp', ['eq', ['var', 0], ['var', 1]],
                            ['eq', ['fun', 1, [['var', 0]]], ['var', 1]]]]]]],
                    ['all', 0, ['eq', ['var', 0], ['var', 1]]]]]})
        result.append((spec, {'kind': 'INDUCTION', 'formula': body, 'variable': 0,
            'parameters': parameters, 'local_stack': []},
            {'permitted': permitted, 'reason': reason, 'evidence': expected}))
    return result


def _guard_check(producer, modules, case, check):
    spec, request, expected = case
    query = _query(spec, check)
    before = _canonical(request)
    result = producer.inspect_guard(query, request,
        modules={'checker': modules['checker'], 'builders': modules['builders']}, check=check)
    check()
    _need(set(result) == {'schema', 'complete', 'kind', 'context', 'permitted',
                         'reason', 'evidence'}, 'guard exact wrapper')
    _need(result['schema'] == 'FPC-H1-obligation-guard-receipt-v1' and
          result['complete'] is True and result['kind'] == request['kind'], 'guard identity')
    _need(type(result['permitted']) is bool and
          result['permitted'] is expected['permitted'] and
          result['reason'] == expected['reason'], 'manual guard expectation')
    context = result['context']
    _need(context['scope'] == 'DECLARED_LOCAL_SCOPE_NOT_AUTHENTICATED_AS_PLAN' and
          context['query_sha256'] == _identity(query)['sha256'] and
          _same(context['root_Gamma'], spec['Gamma']) and
          _same(context['local_stack'], request['local_stack']), 'declared guard scope')
    for key, value in expected['evidence'].items():
        check()
        _need(_same(result['evidence'][key], value), 'literal guard evidence ' + key)
    _need(before == _canonical(request), 'guard input immutability')
    return {'query_input': spec, 'request': request, 'expected': expected,
            'query': _identity(query), 'receipt': result}


def _compile_check(producer, modules, case, position, check):
    spec, plan = case
    query = _query(spec, check)
    before = _canonical(plan)
    result = producer.compile_plan(query, plan,
        modules={'checker': modules['checker'], 'builders': modules['builders']}, check=check)
    check()
    _need(set(result) == {'candidate_certificate_bytes', 'receipt'}, 'compile wrapper')
    receipt = result['receipt']
    _need(receipt.get('schema') == 'FPC-H1-obligation-elaboration-receipt-v1' and
          receipt.get('status') == 'ELABORATED_NOT_VALIDATED' and
          receipt.get('complete') is True and receipt.get('accepted') is False,
          'compiler not validator')
    _need(receipt['input_plan_sha256'] == hashlib.sha256(before.encode()).hexdigest(),
          'canonical authored plan binding')
    rows = receipt['candidate_rows']
    _need(type(rows) is list and len(rows) > 0 and
          _same(rows[-1]['formula'], spec['goal']), 'whole export final exact goal')
    for index, row in enumerate(rows):
        check()
        _need(type(row['index']) is int and row['index'] == index and
              type(row['rule_tag']) is int and 0 <= row['rule_tag'] <= 4,
              'primitive export tags/index')
        for reference in row['references']:
            check()
            _need(_nat(reference) and reference < index, 'export backward references')
    primitive = receipt['primitive_nodes']
    for index, node in enumerate(primitive):
        check()
        _need(type(node['id']) is int and node['id'] == index and
              type(node['rule_tag']) is int and 0 <= node['rule_tag'] <= 4,
              'primitive DAG identity')
        for reference in node['premises']:
            check()
            _need(_nat(reference) and reference < index and
                  primitive[reference]['context'] == node['context'],
                  'primitive dependency context/order')
    for entry in receipt['export_map']:
        check()
        _need(primitive[entry['primitive']]['context'] == 0 and
              rows[entry['row']]['primitive'] == entry['primitive'], 'root-only export map')
    expected_indices = [0, 1, 1, 1, None, 0, 0, 0, 0, 0, 0, 0]
    discharges = receipt['discharges']
    if position == 4:
        pairs = {(row['intro_node'], row['discharged_hypothesis_index']) for row in discharges}
        _need(pairs == {(1, 1), (2, 0)} and len(discharges) == 2,
              'equal assumptions retain occurrence discharge order')
    else:
        _need(len(discharges) == 1 and
              discharges[0]['discharged_hypothesis_index'] == expected_indices[position],
              'exact last local occurrence discharged')
    if position == 3:
        guards = discharges[0]['GEN_guards']
        _need(len(guards) >= 1 and all(g['permitted'] is True for g in guards),
              'GEN discharge full-context checks retained')
    raw = result['candidate_certificate_bytes']
    _need(receipt['certificate'] == _identity(raw), 'compiler byte identity')
    validators = _dual(modules, query, raw, check)
    _need(before == _canonical(plan), 'compiler input immutability')
    return {'query_input': spec, 'input_plan': plan, 'receipt': receipt,
            'dual_validation': validators}


def _refusal_cases(fixtures, check):
    cases = []
    spec, plan = _clone(fixtures[2], check)
    plan['nodes'][2]['premises'] = [1, 0]
    cases.append((spec, plan))
    # Same declaration pair as the rigid-binder input; no alpha conversion.
    old = ORIGINAL_INPUT_DECLARATIONS['guard_declarations'][3]
    spec = _spec(old['value'], Gamma=[old['pattern']], check=check)
    nodes = [_node(0, 0, old['value'], 'HYP', [], {'index': 0}, check)]
    cases.append((spec, _arena_plan(
        [{'id': 0, 'parent': None, 'opener': None, 'assumption': None}], nodes, 0, check)))
    # A valid source B plus an unused free-variable root hypothesis forbids GEN.
    spec = _spec(['all', 4, B], Gamma=[B, ['pred', 0, [['var', 4]]]], check=check)
    nodes = [_node(0, 0, B, 'HYP', [], {'index': 0}, check),
             _node(1, 0, ['all', 4, B], 'GEN', [0], {'variable': 4}, check)]
    cases.append((spec, _arena_plan(
        [{'id': 0, 'parent': None, 'opener': None, 'assumption': None}], nodes, 1, check)))
    local = ['pred', 0, [['var', 4]]]
    spec = _spec(['imp', local, ['all', 4, B]], Gamma=[B], check=check)
    contexts = [{'id': 0, 'parent': None, 'opener': None, 'assumption': None},
                {'id': 1, 'parent': 0, 'opener': 2, 'assumption': local}]
    nodes = [_node(0, 1, B, 'HYP', [], {'index': 0}, check),
             _node(1, 1, ['all', 4, B], 'GEN', [0], {'variable': 4}, check),
             _node(2, 0, spec['goal'], 'INTRO', [1], {'child_context': 1}, check)]
    cases.append((spec, _arena_plan(contexts, nodes, 2, check)))
    spec, plan = _clone(fixtures[0], check)
    plan['contexts'][1]['opener'] = 0
    cases.append((spec, plan))
    spec, plan = _clone(fixtures[2], check)
    plan['nodes'][2]['premises'] = [0, 2]
    cases.append((spec, plan))
    spec, plan = _clone(fixtures[0], check)
    duplicate = _clone(plan['arena'][0], check)
    duplicate['id'] = len(plan['arena'])
    plan['arena'].append(duplicate)
    cases.append((spec, plan))
    return cases


def _owned_refusal(producer, function, check):
    try:
        function(check)
    except BaseException as error:
        # Identity-first: genuine outer faults must never be normalized.
        check.propagate()
        if type(error) is not producer.ProducerInputError or not producer.is_owned_error(error):
            raise
        check()
        return error
    raise ControlFailure('required owned malformed/context/operator refusal')


def _refusal_check(producer, modules, case, check):
    spec, plan = case
    query = _query(spec, check)
    before = _canonical(plan)
    error = _owned_refusal(producer, lambda callback: producer.compile_plan(
        query, plan, modules={'checker': modules['checker'], 'builders': modules['builders']},
        check=callback), check)
    _need(before == _canonical(plan), 'refused plan immutable')
    return {'query_input': spec, 'input_plan': plan, 'query': _identity(query),
            'expected': 'OWNED_ProducerInputError',
            'observed': {'class': type(error).__name__, 'message': str(error)}}

class _Call:
    """The bank also preserves the first genuine outer callback object."""
    def __init__(self, callback):
        self.callback, self.first = callback, None

    def propagate(self):
        if self.first is not None:
            raise self.first

    def __call__(self):
        self.propagate()
        try:
            self.callback()
        except BaseException as error:
            self.first = error
            raise


def _product_call(producer, state, lengths, closed, check):
    before = _canonical([state, lengths, closed])
    result = producer.product_step(state, lengths, closed, check=check)
    check()
    _need(set(result) == {'kind', 'state', 'indices', 'requests'}, 'product wrapper')
    _need(result['kind'] in ('TUPLE', 'WAIT', 'SKIP_OUTSIDE', 'EOF'), 'product kind')
    state_out = result['state']
    _need(set(state_out) == {'arity', 'diagonal', 'positions', 'started', 'finished'},
          'new product-state ABI')
    _need(type(state_out['arity']) is int and state_out['arity'] == len(lengths) and
          _nat(state_out['diagonal']) and type(state_out['started']) is bool and
          type(state_out['finished']) is bool, 'product state types')
    _need(type(state_out['positions']) is list and
          len(state_out['positions']) == len(lengths) and
          all(_nat(x) for x in state_out['positions']) and
          sum(state_out['positions']) == state_out['diagonal'], 'product cursor vector')
    if result['kind'] in ('TUPLE', 'SKIP_OUTSIDE'):
        vector = result['indices']
        _need(type(vector) is list and len(vector) == len(lengths) and
              all(_nat(x) for x in vector), 'emitted/skipped exact vector')
        if result['kind'] == 'TUPLE':
            _need(all(value < lengths[i] for i, value in enumerate(vector)),
                  'only present tuple')
        else:
            _need(any(closed[i] and value >= lengths[i]
                      for i, value in enumerate(vector)), 'known-closed skipped coordinate')
    else:
        _need(result['indices'] is None, 'WAIT/EOF no emitted tuple')
    _need(before == _canonical([state, lengths, closed]), 'product input immutable')
    return result


def _products(producer, check):
    # Independently written finite diagonal set and order, not engine-derived.
    state, records, tuples = {'arity': 2, 'diagonal': 0, 'positions': [0, 0],
                               'started': False, 'finished': False}, [], []
    for unused in range(20):
        check()
        result = _product_call(producer, state, [2, 2], [True, True], check)
        records.append(result)
        state = result['state']
        if result['kind'] == 'TUPLE':
            tuples.append(result['indices'])
        if result['kind'] == 'EOF':
            break
    _need(tuples == [[0, 0], [0, 1], [1, 0], [1, 1]] and
          records[-1]['kind'] == 'EOF', 'complete literal 2x2 diagonal coverage')
    first = {'records': records, 'expected_tuples': [[0, 0], [0, 1], [1, 0], [1, 1]]}
    r0 = _product_call(producer, {'arity': 2, 'diagonal': 0, 'positions': [0, 0],
        'started': False, 'finished': False}, [1, 0], [False, False], check)
    _need(r0['kind'] == 'WAIT' and r0['requests'] == [{'slot': 1, 'index': 0}],
          'missing open catalog entry is WAIT, not EOF')
    r1 = _product_call(producer, r0['state'], [1, 0], [False, False], check)
    _need(r1['kind'] == 'WAIT' and _same(r1['state'], r0['state']), 'WAIT no advance')
    r2 = _product_call(producer, r1['state'], [1, 1], [True, False], check)
    _need(r2['kind'] == 'TUPLE' and r2['indices'] == [0, 0], 'service missing index')
    r3 = _product_call(producer, r2['state'], [1, 1], [True, False], check)
    _need(r3['kind'] == 'WAIT' and r3['requests'] == [{'slot': 1, 'index': 1}],
          'staggered next arrival retains cursor')
    r4 = _product_call(producer, r3['state'], [1, 2], [True, True], check)
    _need(r4['kind'] == 'TUPLE' and r4['indices'] == [0, 1], 'late tuple not lost')
    second = {'records': [r0, r1, r2, r3, r4],
              'scope': 'Staggered growth prefix; full closed coverage separately tested.'}
    empty = _product_call(producer, {'arity': 2, 'diagonal': 0, 'positions': [0, 0],
        'started': False, 'finished': False}, [0, 1], [True, False], check)
    _need(empty['kind'] == 'EOF' and empty['requests'] == [], 'closed empty dimension')
    zero0 = _product_call(producer, {'arity': 0, 'diagonal': 0, 'positions': [],
        'started': False, 'finished': False}, [], [], check)
    _need(zero0['kind'] == 'TUPLE' and zero0['indices'] == [], 'arity0 unit tuple')
    zero1 = _product_call(producer, zero0['state'], [], [], check)
    _need(zero1['kind'] == 'EOF' and zero1['requests'] == [], 'arity0 then EOF')
    return [first, second, {'record': empty}, {'records': [zero0, zero1]}]


class _Probe:
    """Deliberate sentinel only; genuine outer faults bypass expected handling."""
    def __init__(self, outer, sentinel, at=1, second=None):
        self.outer, self.sentinel, self.at = outer, sentinel, at
        self.second, self.calls, self.first = second, 0, None

    def __call__(self):
        if self.first is not None:
            # If a subject incorrectly asks again, expose that extra callback.
            self.calls += 1
            raise self.second if self.second is not None else self.first
        self.outer()
        self.calls += 1
        if self.calls == self.at:
            self.first = self.sentinel
            raise self.sentinel


def _exact_fault(function, probe, sentinel):
    before_args = sentinel.args
    before_vars = dict(vars(sentinel))
    try:
        function(probe)
    except BaseException as error:
        if error is not sentinel:
            raise
    else:
        raise ControlFailure('callback fault was normalized/returned')
    _need(probe.calls == probe.at and probe.first is sentinel,
          'no callback after first fault')
    _need(sentinel.args == before_args and vars(sentinel) == before_vars,
          'retained exception payload not overwritten')
    return {'class': type(sentinel).__name__, 'fault_ordinal': probe.at,
            'callbacks_observed': probe.calls, 'identity_preserved': True,
            'args_and_attributes_unchanged': True,
            'scope': 'Python traceback/context fields are not compared.'}


def _faults(producer, modules, fixtures, refusal_cases, check):
    roles = {'checker': modules['checker'], 'builders': modules['builders']}
    fixture_snapshot = _canonical([fixtures, refusal_cases])
    query = _query(ORIGINAL_INPUT_DECLARATIONS['query_declarations'][0], check)
    config = _configuration(check)
    progress = []
    error = RuntimeError('independent first search callback')
    probe = _Probe(check, error)
    search_evidence = _exact_fault(lambda callback: producer.search_obligations(
        query, configuration=config, modules=roles, check=callback, progress=progress),
        probe, error)
    _need(len(progress) == 1 and type(progress[0]) is dict,
          'search carrier exists before first callback')
    search_evidence['progress'] = _clone(progress, check)
    request = {'kind': 'GEN', 'variable': 4, 'local_stack': []}
    error = StopIteration('independent guard callback')
    probe = _Probe(check, error)
    guard_evidence = _exact_fault(lambda callback: producer.inspect_guard(
        query, request, modules=roles, check=callback), probe, error)
    spec, plan = fixtures[0]
    compiled_query = _query(spec, check)
    error = producer.ProducerInputError('unowned public-class callback')
    probe = _Probe(check, error)
    class_evidence = _exact_fault(lambda callback: producer.compile_plan(
        compiled_query, plan, modules=roles, check=callback), probe, error)
    bad_spec, bad_plan = refusal_cases[4]
    bad_query = _query(bad_spec, check)
    retained = _owned_refusal(producer, lambda callback: producer.compile_plan(
        bad_query, bad_plan, modules=roles, check=callback), check)
    probe = _Probe(check, retained)
    retained_evidence = _exact_fault(lambda callback: producer.inspect_guard(
        query, request, modules=roles, check=callback), probe, retained)
    # A successful baseline measures only a synthetic callback count. It is not
    # reused as a result or proof. This samples one late path, not every cutoff.
    visits = [0]
    def count():
        check()
        visits[0] += 1
    producer.compile_plan(compiled_query, plan, modules=roles, check=count)
    _need(visits[0] >= 2, 'late compiler cutoff must be nonvacuous')
    at = max(2, visits[0] - 1)
    error, second = RuntimeError('independent late E'), ValueError('later F must not run')
    probe = _Probe(check, error, at=at, second=second)
    late_evidence = _exact_fault(lambda callback: producer.compile_plan(
        compiled_query, plan, modules=roles, check=callback), probe, error)
    late_evidence['baseline_callbacks'] = visits[0]
    completed = producer.compile_plan(compiled_query, plan, modules=roles, check=check)
    certificate = completed['candidate_certificate_bytes']
    validation_evidence = []
    for role, name in (('checker', 'check_certificate'),
                       ('reference', 'reference_check_certificate')):
        check()
        error = RuntimeError('independent ' + role + ' first callback')
        probe = _Probe(check, error)
        function = getattr(modules[role], name)
        row = _exact_fault(lambda callback: function(
            compiled_query, certificate, check=callback), probe, error)
        row['role'] = role
        validation_evidence.append(row)
    _need(fixture_snapshot == _canonical([fixtures, refusal_cases]),
          'compiler and retained-fault fixture inputs remain immutable')
    return [search_evidence, guard_evidence, class_evidence, retained_evidence,
            late_evidence, {'validators': validation_evidence,
                'query': _identity(compiled_query), 'certificate': _identity(certificate)}]


def run_obligation_controls(producer, *, modules, check):
    """Run only inside separately reviewed once custody; never self-admit.

    The 47 new groups ADD obligation/compiler coverage. They do not silently
    replace the separately frozen 56 old-forward-engine expectations/IDs.
    """
    call = _Call(check)
    call()
    _need(type(modules) is dict and set(modules) == {'checker', 'builders', 'reference'},
          'bank exact dependency roles')
    results = []
    def save(evidence):
        call()
        number = len(results)
        _need(number < len(CONTROL_IDS), 'bank population overflow')
        results.append({'id': CONTROL_IDS[number], 'passed': True, 'evidence': evidence})
    for declaration in ORIGINAL_INPUT_DECLARATIONS['query_declarations']:
        call()
        save(_search_check(producer, modules, declaration, call))
    for case in _guard_cases(call):
        call()
        save(_guard_check(producer, modules, case, call))
    fixtures = _compile_fixtures(call)
    _need(len(fixtures) == 12, 'complete twelve compiler input cases')
    for position, case in enumerate(fixtures):
        call()
        save(_compile_check(producer, modules, case, position, call))
    refusals = _refusal_cases(fixtures, call)
    _need(len(refusals) == 7, 'complete seven compiler refusals')
    for case in refusals:
        call()
        save(_refusal_check(producer, modules, case, call))
    for evidence in _products(producer, call):
        call()
        save(evidence)
    for evidence in _faults(producer, modules, fixtures, refusals, call):
        call()
        save(evidence)
    _need(len(results) == len(CONTROL_IDS) == 47 and
          [row['id'] for row in results] == list(CONTROL_IDS), 'full fixed bank order')
    call()
    return {'schema': RETURN_SCHEMA, 'version': VERSION, 'complete': True,
            'control_ids': list(CONTROL_IDS), 'controls': results,
            'counts': {'groups': 47, 'passed': 47, 'failed': 0},
            'accepted': False, 'proof_admitted': False,
            'scope': 'Synthetic qualification only; no six-goal proof or search result.',
            'limitations': [
                'No Root execution authority or formal completeness/soundness theorem.',
                '47 groups are additive, not a replacement for old56 expectations.',
                'Sharing is checked on visited saved nodes; early success need not visit both diamond paths.',
                'Cursor products are fully checked only on the literal tiny domains.',
                'Not every event lane/callback/priority service cutoff is exercised.',
                'No elapsed-time, memory-fit, useful proof, GCTS/RL or fixed-palette claim.',
                'Declared guard local stacks are not authenticated plan contexts.',
                'Exception args/attributes checked; traceback/context are not compared.'
            ]}
