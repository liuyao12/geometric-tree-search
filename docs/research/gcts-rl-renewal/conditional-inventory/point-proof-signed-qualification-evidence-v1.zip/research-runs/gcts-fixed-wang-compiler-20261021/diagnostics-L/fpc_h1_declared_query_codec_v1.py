"""Prospective declaration-to-FPC1 codec. Source only; no import/call performed.

This module has no file access, theorem-name dispatch, proof output, checker,
builder, search, or target-declaration imports. All expansion/bytes below are
created only when a future reviewed actual calls the public entry point.
"""

import hashlib
import json

VERSION = "FPC-H1-declared-query-codec-v1"
_ISSUED = object()
_REQUIRED = frozenset(("id", "profile", "profile_id", "function_arities",
    "predicate_arities", "mode", "hypotheses", "goal_latex", "binder_order",
    "goal_tree", "classification"))
_OPTIONAL = frozenset(("binder_kinds",))


class DeclarationFormatError(ValueError):
    """A completed declaration-format refusal; public construction is unowned."""

    def __init__(self, message, *, _issued=None, _call=None):
        super().__init__(message)
        self._issued = _issued
        self._call = _call


def is_owned_error(error):
    """Diagnostic only; never authorizes normalization in another invocation."""
    return (type(error) is DeclarationFormatError
            and error._issued is _ISSUED and error._call is not None)


class _Call:
    def __init__(self, check):
        if not callable(check):
            raise TypeError("check must be callable")
        self.check = check
        self.first_fault = None

    def tick(self):
        if self.first_fault is not None:
            raise self.first_fault
        try:
            self.check()
        except BaseException as error:
            self.first_fault = error
            raise

    def need(self, condition, message):
        if self.first_fault is not None:
            raise self.first_fault
        if not condition:
            raise DeclarationFormatError(message, _issued=_ISSUED, _call=self)


def _natural(value, call, label):
    call.tick()
    call.need(type(value) is int and value >= 0, label + " must be a natural")
    return value


def _snapshot(value, call):
    """Checked explicit-stack copy of plain acyclic JSON, with no size cutoff."""
    root = [None]
    active = set()
    pending = [("visit", value, root, 0)]
    while pending:
        call.tick()
        task = pending.pop()
        if task[0] == "leave":
            active.remove(task[1])
            continue
        _, current, parent, key = task
        if type(current) in (str, int) or current is None:
            parent[key] = current
        elif type(current) is list:
            call.need(id(current) not in active, "cyclic declaration")
            active.add(id(current))
            output = [None] * len(current)
            parent[key] = output
            pending.append(("leave", id(current)))
            for index in range(len(current) - 1, -1, -1):
                call.tick()
                pending.append(("visit", current[index], output, index))
        elif type(current) is dict:
            call.need(id(current) not in active, "cyclic declaration")
            active.add(id(current))
            output = {}
            parent[key] = output
            pending.append(("leave", id(current)))
            keys = list(current)
            for item in reversed(keys):
                call.tick()
                call.need(type(item) is str, "declaration keys must be strings")
                pending.append(("visit", current[item], output, item))
        else:
            call.need(False, "plain JSON strings/naturals/lists/maps/null only")
    return root[0]


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def _expand(tree, functions, predicates, call):
    """Validate types/closure and replace only the two declared abbreviations."""
    root = [None]
    records = []
    binders = []
    pending = [("F", tree, root, 0, (), (), frozenset())]
    while pending:
        call.tick()
        kind, node, parent, slot, source_path, core_path, bound = pending.pop()
        call.need(type(node) is list and node and type(node[0]) is str,
                  "tree node must be a nonempty tagged list")
        tag = node[0]
        record = {"source_path": list(source_path), "core_path": list(core_path),
                  "source_tag": tag, "kind": kind}
        records.append(record)
        if kind == "T":
            if tag == "var":
                call.need(len(node) == 2, "var fields")
                variable = _natural(node[1], call, "variable ID")
                call.need(variable in bound, "theorem goal has a free variable")
                parent[slot] = ["var", variable]
            elif tag == "fun":
                call.need(len(node) == 3 and type(node[2]) is list, "fun fields")
                symbol = _natural(node[1], call, "function ID")
                call.need(symbol < len(functions), "unknown function ID")
                call.need(len(node[2]) == functions[symbol], "function arity")
                args = [None] * len(node[2])
                parent[slot] = ["fun", symbol, args]
                for i in range(len(args) - 1, -1, -1):
                    call.tick()
                    pending.append(("T", node[2][i], args, i,
                        source_path + (2, i), core_path + (2, i), bound))
            else:
                call.need(False, "formula tag in term position")
        elif tag == "pred":
            call.need(len(node) == 3 and type(node[2]) is list, "pred fields")
            symbol = _natural(node[1], call, "predicate ID")
            call.need(symbol < len(predicates), "unknown predicate ID")
            call.need(len(node[2]) == predicates[symbol], "predicate arity")
            args = [None] * len(node[2])
            parent[slot] = ["pred", symbol, args]
            for i in range(len(args) - 1, -1, -1):
                call.tick()
                pending.append(("T", node[2][i], args, i,
                    source_path + (2, i), core_path + (2, i), bound))
        elif tag in ("eq", "imp", "and"):
            call.need(len(node) == 3, tag + " fields")
            if tag == "and":
                inner = ["imp", None, ["not", None]]
                parent[slot] = ["not", inner]
                pending.append(("F", node[2], inner[2], 1,
                    source_path + (2,), core_path + (1, 2, 1), bound))
                pending.append(("F", node[1], inner, 1,
                    source_path + (1,), core_path + (1, 1), bound))
            else:
                output = [tag, None, None]
                parent[slot] = output
                child_kind = "T" if tag == "eq" else "F"
                pending.append((child_kind, node[2], output, 2,
                    source_path + (2,), core_path + (2,), bound))
                pending.append((child_kind, node[1], output, 1,
                    source_path + (1,), core_path + (1,), bound))
        elif tag == "not":
            call.need(len(node) == 2, "not fields")
            output = ["not", None]
            parent[slot] = output
            pending.append(("F", node[1], output, 1,
                source_path + (1,), core_path + (1,), bound))
        elif tag in ("all", "exists"):
            call.need(len(node) == 3, tag + " fields")
            variable = _natural(node[1], call, "binder ID")
            binders.append({"kind": tag, "id": variable,
                            "source_path": list(source_path)})
            new_bound = bound | frozenset((variable,))
            if tag == "exists":
                output = ["not", ["all", variable, ["not", None]]]
                parent[slot] = output
                pending.append(("F", node[2], output[1][2], 1,
                    source_path + (2,), core_path + (1, 2, 1), new_bound))
            else:
                output = ["all", variable, None]
                parent[slot] = output
                pending.append(("F", node[2], output, 2,
                    source_path + (2,), core_path + (2,), new_bound))
        else:
            call.need(False, "unsupported formula tag")
    return root[0], records, binders


def _put_natural(output, value, call):
    while True:
        call.tick()
        digit = value & 127
        value >>= 7
        output.append(digit | (128 if value else 0))
        if not value:
            return


def _encode_goal(goal, output, call):
    spans = {}
    pending = [("node", goal, ())]
    while pending:
        call.tick()
        task = pending.pop()
        if task[0] == "end":
            _, path, start = task
            spans[path] = [start, len(output)]
            continue
        _, node, path = task
        pending.append(("end", path, len(output)))
        tag = node[0]
        if tag == "var":
            _put_natural(output, 0, call)
            _put_natural(output, node[1], call)
        elif tag in ("fun", "pred"):
            _put_natural(output, 1 if tag == "fun" else 0, call)
            _put_natural(output, node[1], call)
            _put_natural(output, len(node[2]), call)
            for i in range(len(node[2]) - 1, -1, -1):
                call.tick()
                pending.append(("node", node[2][i], path + (2, i)))
        elif tag in ("eq", "imp"):
            _put_natural(output, 1 if tag == "eq" else 3, call)
            pending.append(("node", node[2], path + (2,)))
            pending.append(("node", node[1], path + (1,)))
        elif tag == "not":
            _put_natural(output, 2, call)
            pending.append(("node", node[1], path + (1,)))
        else:  # Validated expansion leaves only the ALL constructor here.
            call.need(tag == "all", "internal non-core constructor")
            _put_natural(output, 4, call)
            _put_natural(output, node[1], call)
            pending.append(("node", node[2], path + (2,)))
    return spans


def encode_declared_query(spec, *, check):
    """Return one exact theorem query plus an audit receipt, never a proof."""
    call = _Call(check)
    try:
        call.tick()
        frozen = _snapshot(spec, call)
        call.need(type(frozen) is dict, "declaration must be a map")
        keys = set(frozen)
        call.need(_REQUIRED <= keys and keys <= _REQUIRED | _OPTIONAL,
                  "exact declaration fields")
        for key in ("id", "profile", "goal_latex", "classification"):
            call.tick()
            call.need(type(frozen[key]) is str and bool(frozen[key]), key + " string")
        profile = _natural(frozen["profile_id"], call, "profile ID")
        call.need(profile in (1, 2), "only the two declared fixed profiles")
        expected = (("PA_0S_PLUS_TIMES_V1", [0, 1, 2, 2], []) if profile == 1
                    else ("HILBERT_PLANE_INCIDENCE_MIN_V1", [], [1, 1, 2]))
        call.need(frozen["profile"] == expected[0], "profile name/ID mismatch")
        for key, values in (("function_arities", expected[1]),
                            ("predicate_arities", expected[2])):
            vector = frozen[key]
            call.need(type(vector) is list, key + " vector")
            for value in vector:
                _natural(value, call, "arity")
            call.need(vector == values, "fixed profile signature")
        call.need(type(frozen["mode"]) is int and frozen["mode"] == 0,
                  "theorem mode exactly zero")
        call.need(type(frozen["hypotheses"]) is list and not frozen["hypotheses"],
                  "Gamma must be empty")
        call.need(type(frozen["binder_order"]) is list, "binder_order vector")
        for variable in frozen["binder_order"]:
            _natural(variable, call, "declared binder ID")
        goal, source_map, binders = _expand(frozen["goal_tree"],
            frozen["function_arities"], frozen["predicate_arities"], call)
        call.need([row["id"] for row in binders] == frozen["binder_order"],
                  "exact binder preorder")
        if "binder_kinds" in frozen:
            call.need(type(frozen["binder_kinds"]) is list
                and frozen["binder_kinds"] == [row["kind"] for row in binders],
                "exact binder kinds")
        output = bytearray(b"FPC1")
        _put_natural(output, 1, call)
        _put_natural(output, 0, call)
        for key in ("function_arities", "predicate_arities"):
            vector = frozen[key]
            _put_natural(output, len(vector), call)
            for value in vector:
                _put_natural(output, value, call)
        _put_natural(output, profile, call)
        # Profiles 1 and 2 have NO profile-payload octets, not a zero sentinel.
        _put_natural(output, 0, call)  # Empty Gamma vector.
        goal_start = len(output)
        spans = _encode_goal(goal, output, call)
        for row in source_map:
            call.tick()
            row["query_byte_span"] = list(spans[tuple(row["core_path"])])
        query_bytes = bytes(output)
        canonical = _canonical(frozen)
        call.tick()
        call.need(_canonical(_snapshot(spec, call)) == canonical,
                  "declaration changed during encoding")
        receipt = {"schema": "FPC-H1-declared-query-codec-receipt-v1",
            "complete": True, "version": VERSION,
            "declaration_id": frozen["id"],
            "declaration_canonical_sha256": hashlib.sha256(canonical).hexdigest(),
            "query_identity": {"bytes": len(query_bytes),
                "sha256": hashlib.sha256(query_bytes).hexdigest()},
            "query_version": 1, "mode": 0, "hypotheses": [],
            "profile_id": profile, "profile_payload_octets": 0,
            "function_arities": frozen["function_arities"],
            "predicate_arities": frozen["predicate_arities"],
            "expanded_goal": goal, "goal_byte_span": [goal_start, len(query_bytes)],
            "binders": binders, "source_map": source_map, "EOF": len(query_bytes),
            "scope": "DECLARATION_ENCODING_ONLY_NO_PROOF_OR_SEARCH_AUTHORITY"}
        return {"query_bytes": query_bytes, "receipt": receipt}
    except BaseException:
        if call.first_fault is not None:
            raise call.first_fault
        raise
