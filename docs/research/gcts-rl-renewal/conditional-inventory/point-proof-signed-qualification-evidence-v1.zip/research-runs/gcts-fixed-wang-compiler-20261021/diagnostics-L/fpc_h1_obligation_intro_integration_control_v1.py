"""One independent synthetic DISCOVERY control; UNRUN Source.

No caller plan enters search. This is not a six-target proof/hint or an actual
qualification. All encoding/search/validation happens only in future Root scope.
"""
import hashlib
import json

VERSION = 'FPC-H1-obligation-INTRO-integration-control-v1'
RETURN_SCHEMA = 'FPC-H1-obligation-INTRO-integration-control-v1'
CONTROL_IDS = ('producer-INTRO-local-HYP-dual-export',)
QUERY_INPUT = {
    'profile_id': 0, 'function_arities': [0], 'predicate_arities': [1],
    'mode': 0, 'finite_axioms': [], 'Gamma': [],
    'goal': ['imp', ['pred', 0, [['fun', 0, []]]],
                    ['pred', 0, [['fun', 0, []]]]],
}
CONFIGURATION = {
    'schema': 'FPC-H1-obligation-configuration-v1', 'control_only': True,
    'variables': 0, 'term_depth': 0, 'fallback_witness_nodes': 0,
    'obligation_nodes': 5, 'priority_subformula_nodes': 5,
    'intro_depth': 1, 'oldest_period': 4, 'ordering': 'FOCUSED',
}


class IntegrationControlFailure(AssertionError):
    pass


class _Call:
    def __init__(self, callback):
        self.callback, self.first = callback, None

    def __call__(self):
        if self.first is not None:
            raise self.first
        try:
            self.callback()
        except BaseException as error:
            self.first = error
            raise


def _need(condition, label):
    if condition is not True:
        raise IntegrationControlFailure(label)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def _clone(value, check):
    check()
    if type(value) is dict:
        result = {}
        for key, item in value.items():
            check()
            result[key] = _clone(item, check)
        return result
    if type(value) in (list, tuple):
        result = []
        for item in value:
            check()
            result.append(_clone(item, check))
        return result
    return value


def _unsigned(value, check):
    _need(type(value) is int and value >= 0, 'fixture integer')
    result = bytearray()
    while True:
        check()
        byte = value & 127
        value >>= 7
        result.append(byte | (128 if value else 0))
        if not value:
            return bytes(result)


def _fixture_query(spec, check):
    """Own positional encoder for this literal input, called only in actual."""
    result = bytearray(b'FPC1')
    for value in (1, spec['mode']):
        check()
        result.extend(_unsigned(value, check))
    for arities in (spec['function_arities'], spec['predicate_arities']):
        check()
        result.extend(_unsigned(len(arities), check))
        for arity in arities:
            check()
            result.extend(_unsigned(arity, check))
    result.extend(_unsigned(spec['profile_id'], check))
    # Literal profile0 empty table and empty Gamma, no hidden source facts.
    _need(spec['finite_axioms'] == [] and spec['Gamma'] == [] and
          spec['profile_id'] == 0, 'fixture no source input')
    result.extend(_unsigned(0, check))
    result.extend(_unsigned(0, check))
    stack = [spec['goal']]
    while stack:
        check()
        node = stack.pop()
        tag = node[0]
        if tag == 'imp':
            result.extend(_unsigned(3, check))
            stack.append(node[2])
            stack.append(node[1])
        elif tag == 'pred':
            result.extend(_unsigned(0, check))
            result.extend(_unsigned(node[1], check))
            result.extend(_unsigned(len(node[2]), check))
            for child in reversed(node[2]):
                check()
                stack.append(child)
        elif tag == 'fun':
            result.extend(_unsigned(1, check))
            result.extend(_unsigned(node[1], check))
            result.extend(_unsigned(len(node[2]), check))
            for child in reversed(node[2]):
                check()
                stack.append(child)
        else:
            raise IntegrationControlFailure('unexpected authored fixture tree')
    return bytes(result)


def _identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def run_intro_integration_control(producer, *, modules, check):
    """Exactly one additive group; no plan/hint argument exists on this call."""
    call = _Call(check)
    call()
    _need(type(modules) is dict and set(modules) == {'checker', 'builders', 'reference'},
          'exact external roles')
    spec = _clone(QUERY_INPUT, call)
    configuration = _clone(CONFIGURATION, call)
    before = _canonical([spec, configuration])
    query = _fixture_query(spec, call)
    progress = []
    result = producer.search_obligations(query, configuration=configuration,
        modules={'checker': modules['checker'], 'builders': modules['builders']},
        check=call, progress=progress)
    call()
    _need(type(result) is dict and set(result) ==
          {'status', 'candidate_certificate_bytes', 'receipt'}, 'search wrapper')
    receipt = result['receipt']
    _need(len(progress) == 1 and progress[0] is receipt, 'current live receipt')
    _need(result['status'] == 'CANDIDATE_FOUND' and
          receipt['status'] == 'CANDIDATE_FOUND' and
          receipt['schema'] == 'FPC-H1-obligation-search-receipt-v1' and
          receipt['accepted'] is False and
          receipt['candidate_validation'] == 'NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED',
          'bounded synthetic candidate has no internal admission')
    plan = receipt['selected_plan']
    _need(plan['schema'] == 'FPC-H1-obligation-plan-v1', 'selected primitive/INTRO plan')
    _need(type(plan['root']) is int and plan['root'] == 1 and len(plan['nodes']) == 2,
          'root INTRO and sole reachable HYP node')
    root, child = plan['nodes'][1], plan['nodes'][0]
    _need(type(root['id']) is int and root['id'] == 1 and
          type(root['context']) is int and root['context'] == 0 and
          root['operator'] == 'INTRO' and
          _canonical(root['premises']) == '[0]' and set(root['payload']) == {'child_context'},
          'discovery actually selected INTRO')
    _need(type(root['payload']['child_context']) is int and
          root['payload']['child_context'] == 1 and len(plan['contexts']) == 2,
          'one authenticated child context')
    _need(_canonical(plan['contexts'][0]) == _canonical(
          {'id': 0, 'parent': None, 'opener': None, 'assumption': None}), 'root context')
    local = plan['contexts'][1]
    _need(type(local['id']) is int and local['id'] == 1 and
          type(local['parent']) is int and local['parent'] == 0 and
          type(local['opener']) is int and local['opener'] == 1,
          'opener owns child context')
    _need(type(child['id']) is int and child['id'] == 0 and
          type(child['context']) is int and child['context'] == 1 and
          child['operator'] == 'HYP' and child['premises'] == [] and
          _canonical(child['payload']) == '{"index":0}',
          'current local hypothesis, no supplied Gamma')
    arena = plan['arena']
    atom_id, goal_id = child['formula'], root['formula']
    _need(type(atom_id) is int and type(goal_id) is int and
          type(local['assumption']) is int and
          local['assumption'] == atom_id, 'literal discharged assumption identity')
    atom, goal = arena[atom_id], arena[goal_id]
    _need(goal['sort'] == 'F' and goal['tag'] == 'imp' and goal['symbol'] is None and
          _canonical(goal['children']) == _canonical([atom_id, atom_id]), 'exact implication goal')
    _need(atom['sort'] == 'F' and atom['tag'] == 'pred' and
          type(atom['symbol']) is int and atom['symbol'] == 0 and
          len(atom['children']) == 1, 'exact unary predicate')
    _need(type(atom['children'][0]) is int, 'term child ID')
    constant = arena[atom['children'][0]]
    _need(constant['sort'] == 'T' and constant['tag'] == 'fun' and
          type(constant['symbol']) is int and constant['symbol'] == 0 and
          constant['children'] == [], 'exact nullary term')
    raw = result['candidate_certificate_bytes']
    _need(type(raw) is bytes, 'fresh immutable primitive certificate bytes')
    subject = modules['checker'].check_certificate(query, raw, check=call)
    call()
    _need(subject['status'] == 'VALID_DERIVATION', 'subject complete valid')
    for field in ('accepted', 'syntax_complete', 'derivation_complete',
                  'final_goal_equal', 'complete'):
        call()
        _need(subject[field] is True, 'subject whole gate ' + field)
    _need(_canonical(subject['query']['goal']) == _canonical(spec['goal']) and
          subject['query']['Gamma'] == [] and subject['query']['finite_axioms'] == [] and
          subject['query']['theory_profile'] == 0, 'same literal no-source parsed query')
    reference = modules['reference'].reference_check_certificate(query, raw, check=call)
    call()
    _need(reference['status'] == 'VALID_DERIVATION' and
          reference['complete_check'] is True, 'independent same-byte reference complete')
    _need(before == _canonical([spec, configuration]), 'configuration/input stability')
    evidence = {'query_input': spec, 'configuration': configuration,
        'query': _identity(query), 'query_hex': query.hex(),
        'certificate': _identity(raw), 'certificate_hex': raw.hex(),
        'producer_receipt': receipt, 'subject': subject, 'reference': reference,
        'supplied_plan_to_search': False}
    call()
    return {'schema': RETURN_SCHEMA, 'version': VERSION, 'complete': True,
        'control_ids': list(CONTROL_IDS),
        'controls': [{'id': CONTROL_IDS[0], 'passed': True, 'evidence': evidence}],
        'counts': {'groups': 1, 'passed': 1, 'failed': 0},
        'accepted': False, 'proof_admitted': False,
        'scope': 'One synthetic discovery integration control, not a six-goal result.',
        'limitations': ['No runtime or resource-fit claim before independent whole actual.',
            'Not universal search fairness, completeness or all-context compiler coverage.',
            'Only the exact restricted language makes root INTRO expectation justified.']}
