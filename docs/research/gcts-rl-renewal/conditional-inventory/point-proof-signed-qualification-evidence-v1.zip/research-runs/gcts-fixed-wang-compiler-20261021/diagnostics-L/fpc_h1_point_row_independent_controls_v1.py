"""Unrun independent semantic INPUT projections for the point-row adapter.

These authored tiny rows are qualification fixtures, not discoveries, byte
parser outputs, old accepted certificates, a search prefix, or proof admission.
No scientific role is imported. All calls below are future-actual recipes only.
"""

import copy
import json

VERSION = "FPC-H1-point-row-independent-controls-v1"
CONTROL_IDS = (
    "point-HYP-MP-agreement", "point-wrong-MP-mark-conflict",
    "point-final-goal-boundary-conflict", "point-GEN-agreement",
    "point-GEN-source-mark-conflict", "point-GEN-unused-Gamma-refusal",
    "point-HYP-declared-conclusion-refusal", "point-LOGICAL-declared-conclusion-refusal",
    "point-THEORY-profile-refusal", "point-MP-forward-reference-refusal",
    "point-MP-coincident-port-refusal", "point-repeated-remote-port-agreement",
    "point-long-range-mark-only-agreement", "point-LOGICAL-Q3-agreement",
    "point-THEORY-finite-agreement", "point-first-RuntimeError-identity",
    "point-first-public-refusal-class-identity", "point-first-StopIteration-identity",
    "point-later-first-fault-and-immutability", "point-retained-family-refusal-identity",
)

# Every tree/row below is a new handwritten test INPUT. There are no output
# certificates, serialized bytes, theorem search targets, or generated proofs.
A = ["pred", 0, [["fun", 0, []]]]
B = ["pred", 1, [["fun", 0, []]]]
C = ["pred", 2, [["fun", 0, []]]]
AB = ["imp", ["pred", 0, [["fun", 0, []]]], ["pred", 1, [["fun", 0, []]]]]
ALL3A = ["all", 3, ["pred", 0, [["fun", 0, []]]]]
ALL4A = ["all", 4, ["pred", 0, [["fun", 0, []]]]]
ALL4B = ["all", 4, ["pred", 1, [["fun", 0, []]]]]

FIXTURES = (
    {"id": "point-HYP-MP-agreement", "Gamma": [A, AB], "finite_axioms": [], "goal": B,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": AB, "rule_tag": 0, "subtag": None, "witness": [1]},
         {"index": 2, "formula": B, "rule_tag": 3, "subtag": None, "witness": [0, 1]}],
     "expected": "POINT_COMPATIBLE"},
    {"id": "point-wrong-MP-mark-conflict", "Gamma": [A, AB], "finite_axioms": [], "goal": C,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": AB, "rule_tag": 0, "subtag": None, "witness": [1]},
         {"index": 2, "formula": C, "rule_tag": 3, "subtag": None, "witness": [0, 1]}],
     "expected": "M_VALUE_DISAGREEMENT", "expected_point": [1, 1]},
    {"id": "point-final-goal-boundary-conflict", "Gamma": [A, AB], "finite_axioms": [], "goal": C,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": AB, "rule_tag": 0, "subtag": None, "witness": [1]},
         {"index": 2, "formula": B, "rule_tag": 3, "subtag": None, "witness": [0, 1]}],
     "expected": "M_VALUE_DISAGREEMENT", "expected_point": [2, 1]},
    {"id": "point-GEN-agreement", "Gamma": [A], "finite_axioms": [], "goal": ALL4A,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": ALL4A, "rule_tag": 4, "subtag": None, "witness": [0, 4]}],
     "expected": "POINT_COMPATIBLE"},
    {"id": "point-GEN-source-mark-conflict", "Gamma": [A], "finite_axioms": [], "goal": ALL4B,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": ALL4B, "rule_tag": 4, "subtag": None, "witness": [0, 4]}],
     "expected": "M_VALUE_DISAGREEMENT", "expected_point": [0, 1]},
    {"id": "point-GEN-unused-Gamma-refusal", "Gamma": [A, ["pred", 1, [["var", 4]]]],
     "finite_axioms": [], "goal": ALL4A,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": ALL4A, "rule_tag": 4, "subtag": None, "witness": [0, 4]}],
     "expected": "LOCAL_MEMBERSHIP_REFUSAL"},
    {"id": "point-HYP-declared-conclusion-refusal", "Gamma": [A], "finite_axioms": [], "goal": B,
     "rows": [{"index": 0, "formula": B, "rule_tag": 0, "subtag": None, "witness": [0]}],
     "expected": "LOCAL_MEMBERSHIP_REFUSAL"},
    {"id": "point-LOGICAL-declared-conclusion-refusal", "Gamma": [], "finite_axioms": [], "goal": B,
     "rows": [{"index": 0, "formula": B, "rule_tag": 1, "subtag": 5, "witness": [A, 4]}],
     "expected": "LOCAL_MEMBERSHIP_REFUSAL"},
    {"id": "point-THEORY-profile-refusal", "Gamma": [], "finite_axioms": [B], "goal": B,
     "rows": [{"index": 0, "formula": B, "rule_tag": 2, "subtag": 1, "witness": [0]}],
     "expected": "LOCAL_MEMBERSHIP_REFUSAL"},
    {"id": "point-MP-forward-reference-refusal", "Gamma": [A, AB], "finite_axioms": [], "goal": B,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": AB, "rule_tag": 0, "subtag": None, "witness": [1]},
         {"index": 2, "formula": B, "rule_tag": 3, "subtag": None, "witness": [2, 1]}],
     "expected": "LOCAL_MEMBERSHIP_REFUSAL"},
    {"id": "point-MP-coincident-port-refusal", "Gamma": [A], "finite_axioms": [], "goal": B,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": B, "rule_tag": 3, "subtag": None, "witness": [0, 0]}],
     "expected": "LOCAL_MEMBERSHIP_REFUSAL"},
    {"id": "point-repeated-remote-port-agreement", "Gamma": [A], "finite_axioms": [], "goal": ALL4A,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": ALL3A, "rule_tag": 4, "subtag": None, "witness": [0, 3]},
         {"index": 2, "formula": ALL4A, "rule_tag": 4, "subtag": None, "witness": [0, 4]}],
     "expected": "POINT_COMPATIBLE", "expected_shared_port": [0, 1]},
    {"id": "point-long-range-mark-only-agreement", "Gamma": [A], "finite_axioms": [], "goal": ALL4A,
     "rows": [
         {"index": 0, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 1, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 2, "formula": A, "rule_tag": 0, "subtag": None, "witness": [0]},
         {"index": 3, "formula": ALL4A, "rule_tag": 4, "subtag": None, "witness": [0, 4]}],
     "expected": "POINT_COMPATIBLE", "expected_long_local_port": [-3, 1]},
    {"id": "point-LOGICAL-Q3-agreement", "Gamma": [], "finite_axioms": [],
     "goal": ["imp", A, ALL4A],
     "rows": [{"index": 0, "formula": ["imp", A, ALL4A], "rule_tag": 1, "subtag": 5, "witness": [A, 4]}],
     "expected": "POINT_COMPATIBLE"},
    {"id": "point-THEORY-finite-agreement", "Gamma": [], "finite_axioms": [B], "goal": B,
     "rows": [{"index": 0, "formula": B, "rule_tag": 2, "subtag": 0, "witness": [0]}],
     "expected": "POINT_COMPATIBLE"},
)


class PointControlFailure(AssertionError):
    """A test mismatch, never a resource wrapper or logical proof result."""


class _Call:
    def __init__(self, check):
        if not callable(check):
            raise TypeError("check must be callable")
        self.check = check
        self.fault = None

    def tick(self):
        if self.fault is not None:
            raise self.fault
        try:
            self.check()
        except BaseException as error:
            self.fault = error
            raise

    def need(self, condition, message):
        if self.fault is not None:
            raise self.fault
        if not condition:
            raise PointControlFailure(message)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def _same(a, b):
    return _canonical(a) == _canonical(b)


def _inputs(fixture):
    # Semantic projections only: no forged byte spans, parser status or EOF.
    query = {"version": 1, "claim_mode": 1 if fixture["Gamma"] else 0,
        "theory_profile": 0, "function_arities": [0],
        "predicate_arities": [1, 1, 1], "finite_axioms": fixture["finite_axioms"],
        "Gamma": fixture["Gamma"], "goal": fixture["goal"]}
    certificate = {"row_count": len(fixture["rows"]), "rows": fixture["rows"]}
    return copy.deepcopy(query), copy.deepcopy(certificate)


def _observation(adapter, builders, fixture, call):
    query, certificate = _inputs(fixture)
    before = _canonical([query, certificate])
    counter = [0]
    def callback():
        call.tick()
        counter[0] += 1
    result = adapter.check_rows_as_points(query, certificate, builders=builders, check=callback)
    call.tick()
    call.need(_canonical([query, certificate]) == before, "adapter mutated semantic fixture")
    call.need(type(result) is dict and result.get("schema") == "FPC-H1-point-row-observation-v1"
        and result.get("complete") is True, "point observation complete schema")
    call.need(type(result.get("point_compatible")) is bool and type(result.get("mismatches")) is list, "point observation status")
    call.need(result.get("proof_admitted") is False and result.get("search_engine") is False
        and result.get("GCTS_conformance") is False, "point observation overclaim")
    call.need(type(result.get("row_count")) is int and result["row_count"] == len(certificate["rows"]), "point row count")
    call.need(type(result.get("callbacks")) is int and result["callbacks"] >= 0, "point callback carrier")
    boundary = result["boundary"]
    call.need(_same(boundary["final_goal_port"], [len(certificate["rows"]) - 1, 1])
        and _same(boundary["final_goal_value"], query["goal"])
        and type(boundary["exterior_t"]) is int and boundary["exterior_t"] == 1
        and _same(boundary["exterior_m"], ["OUTSIDE_FORMULA_DOMAIN"]), "point boundary")
    call.need(len(result["tiles"]) == len(certificate["rows"]), "point inventory row identity")
    for row, tile in zip(certificate["rows"], result["tiles"]):
        call.tick()
        call.need(_same(tile["translation"], [row["index"], 0])
            and _same(tile["t"], [[[0, 0], 1]])
            and _same(tile["conclusion"], row["formula"]), "point translation/unit occupancy/declared binding")
    expected = fixture["expected"]
    if expected == "POINT_COMPATIBLE":
        call.need(result["point_compatible"] is True and not result["mismatches"], "valid authored fixture disagrees at points")
        totals = {tuple(point): value for point, value in result["t_totals"]}
        for row in certificate["rows"]:
            call.tick()
            call.need(type(totals.get((row["index"], 0))) is int
                and totals[(row["index"], 0)] == 1, "required point not unit-covered")
        marks = {tuple(point): value for point, value in result["m_values"]}
        call.need(_same(marks[(len(certificate["rows"]) - 1, 1)], query["goal"]), "final goal port")
        if "expected_shared_port" in fixture:
            port = tuple(fixture["expected_shared_port"])
            call.need(_same(marks[port], A), "repeated remote source formula")
            assignments = 0
            for tile in result["tiles"]:
                for local, value in tile["m"]:
                    call.tick()
                    shifted = (local[0] + tile["translation"][0], local[1])
                    if shifted == port:
                        call.need(_same(value, A), "remote assignment inconsistent")
                        assignments += 1
            call.need(assignments == 3, "two remote inputs and one output not retained")
        if "expected_long_local_port" in fixture:
            call.need(any(_same(point, fixture["expected_long_local_port"]) and _same(value, A)
                for point, value in result["tiles"][-1]["m"]), "long-range mark-only contact missing")
    else:
        call.need(expected == "M_VALUE_DISAGREEMENT" and result["point_compatible"] is False,
                  "wrong point instance accepted or wrong refusal path")
        call.need(any(item.get("kind") == "M_VALUE_DISAGREEMENT"
            and _same(item.get("point"), fixture["expected_point"])
            for item in result["mismatches"]), "wrong dependency/goal mismatch not retained")
    return {"query": query, "certificate": certificate, "observation": result,
            "observed_callback_invocations": counter[0],
            "scope": "AUTHORED_SEMANTIC_INPUT_POINT_OBSERVATION_NOT_BYTE_OR_PROOF_ADMISSION"}


def _refusal(adapter, builders, fixture, call):
    query, certificate = _inputs(fixture)
    before = _canonical([query, certificate])
    try:
        adapter.check_rows_as_points(query, certificate, builders=builders, check=call.tick)
    except BaseException as error:
        if call.fault is not None:
            raise call.fault
        if type(error) is not adapter.PointFamilyRefusal:
            raise
        call.need(_canonical([query, certificate]) == before, "refusal mutated fixture")
        return {"query": query, "certificate": certificate,
                "refusal_type": type(error).__name__, "message": str(error),
                "scope": "LOCAL_INVENTORY_MEMBERSHIP_REFUSAL_NO_POINT_OR_PROOF_PREFIX"}
    call.need(False, "invalid family member was not locally refused")


def _fault(adapter, builders, fixture, sentinel, ordinal, call):
    query, certificate = _inputs(fixture)
    before = _canonical([query, certificate])
    seen = [0]
    later = ValueError("must not replace first intentional callback fault")
    def callback():
        call.tick()
        seen[0] += 1
        if seen[0] == ordinal:
            raise sentinel
        if seen[0] > ordinal:
            raise later
    try:
        adapter.check_rows_as_points(query, certificate, builders=builders, check=callback)
    except BaseException as error:
        if call.fault is not None:
            raise call.fault
        if error is not sentinel:
            raise
        call.need(seen[0] == ordinal, "callback called after first fault")
        call.need(_canonical([query, certificate]) == before, "callback fault mutated input")
        return {"identity_preserved": True, "callback_ordinal": ordinal,
                "fault_type": type(sentinel).__name__, "input_unchanged": True,
                "returned_point_or_proof_prefix": False}
    call.need(False, "callback fault normalized or swallowed")


def run_point_row_controls(adapter, *, builders, check):
    """Exactly20 frozen groups; all source recipes remain unrun at authorship."""
    call = _Call(check)
    try:
        call.tick()
        rows = []
        baseline = None
        for i, fixture in enumerate(FIXTURES):
            call.tick()
            call.need(fixture["id"] == CONTROL_IDS[i], "point control order")
            if fixture["expected"] == "LOCAL_MEMBERSHIP_REFUSAL":
                evidence = _refusal(adapter, builders, fixture, call)
            else:
                evidence = _observation(adapter, builders, fixture, call)
            if i == 0:
                baseline = evidence["observed_callback_invocations"]
            rows.append({"id": fixture["id"], "passed": True, "evidence": evidence})
        errors = [RuntimeError("intentional first runtime fault"),
                  adapter.PointFamilyRefusal("intentional foreign public-class fault"),
                  StopIteration("intentional first generator-style fault")]
        for i, error in enumerate(errors):
            call.tick()
            rows.append({"id": CONTROL_IDS[15 + i], "passed": True,
                "evidence": _fault(adapter, builders, FIXTURES[0], error, 1, call)})
        call.need(type(baseline) is int and baseline >= 2, "later fault diagnostic not exercised")
        ordinal = max(2, baseline // 2)
        rows.append({"id": CONTROL_IDS[18], "passed": True,
            "evidence": _fault(adapter, builders, FIXTURES[0],
                RuntimeError("intentional later first fault"), ordinal, call)})
        prior_query, prior_certificate = _inputs(FIXTURES[6])
        retained = None
        try:
            adapter.check_rows_as_points(prior_query, prior_certificate,
                builders=builders, check=call.tick)
        except BaseException as error:
            if call.fault is not None:
                raise call.fault
            if type(error) is not adapter.PointFamilyRefusal:
                raise
            retained = error
        call.need(retained is not None, "genuine prior family refusal missing")
        retained_fields = dict(vars(retained))
        retained_evidence = _fault(adapter, builders, FIXTURES[0], retained, 1, call)
        call.need(vars(retained) == retained_fields, "retained refusal metadata mutated")
        retained_evidence["retained_refusal_metadata_unchanged"] = True
        rows.append({"id": CONTROL_IDS[19], "passed": True, "evidence": retained_evidence})
        call.tick()
        call.need([row["id"] for row in rows] == list(CONTROL_IDS), "point control population incomplete")
        return {"schema": VERSION, "complete": True, "control_ids": list(CONTROL_IDS),
            "controls": rows, "counts": {"groups": 20, "passed": 20, "failed": 0},
            "scope": "STATIC_ADAPTER_QUALIFICATION_FIXTURES_ONLY_NOT_SEARCH_OR_PROOF_ADMISSION",
            "limitations": [
                "Authored semantic input projections confer no byte parser/EOF provenance.",
                "No private kernel injection, arbitrary missing-cell/overlap fixture or exhaustive point verifier is supplied.",
                "Only Q3/finite-table positive members are sampled; no all-eight-schema/PA-induction family coverage is claimed.",
                "No complete candidate graph, generation/dead/forced scheduler, rollback or learned-marking qualification.",
                "No strict finite Wang palette/fixed verifier-machine result or self-admission of these expectations.",
                "No every-callback sweep or resource/fit forecast; original whole caps and external Root/C gates apply."]}
    except BaseException:
        if call.fault is not None:
            raise call.fault
        raise
