"""Independent flat-prefix reference specification for FPC-H1.

UNRUN Source. No B builder/checker imports. All public inputs are immutable bytes.
This is not a Root grant, mathematical soundness certificate or search producer.
"""
VERSION = "FPC-H1-independent-flat-reference-v2"
_ISSUER = object()


class ReferenceRefusal(ValueError):
    """Public construction alone does not make an exception an owned refusal."""


def is_owned_error(error):
    """Diagnostic issuer predicate; never sufficient for catch authority."""
    return type(error) is ReferenceRefusal and getattr(error, "_issuer", None) is _ISSUER


class _Call:
    """Unique public-call ownership and genuine first callback fault latch."""
    def __init__(self, callback):
        self.callback = callback
        self.owner = object()
        self.first_fault = None

    def propagate_fault(self):
        if self.first_fault is not None:
            raise self.first_fault

    def __call__(self):
        self.propagate_fault()
        try:
            self.callback()
        except BaseException as error:
            self.first_fault = error
            raise

    def owns(self, error):
        return (type(error) is ReferenceRefusal and
                getattr(error, "_owner", None) is self.owner and
                getattr(error, "_issuer", None) is _ISSUER)


def _reject(call, status, component, reason, row=None):
    error = ReferenceRefusal(reason)
    error._issuer, error._owner = _ISSUER, call.owner
    error.status, error.component, error.reason, error.row = status, component, reason, row
    raise error


def _require(call, test, status, component, reason, row=None):
    if not test:
        _reject(call, status, component, reason, row)


def _arity(token):
    if token[0] in ("fun", "pred"):
        return token[2]
    return {"var": 0, "eq": 2, "not": 1, "imp": 2, "all": 1}[token[0]]


class _Tree:
    """Immutable prefix tokens, subtree end indices, original byte spans."""
    __slots__ = ("tokens", "ends", "spans", "_check")

    def __init__(self, tokens, spans=None, *, check):
        self._check = check
        self.tokens = tuple(tokens)
        ends = [None] * len(tokens)
        stack = []
        for index, token in enumerate(tokens):
            check()
            if index and not stack:
                raise AssertionError("internal multi-root prefix")
            if stack:
                stack[-1][1] -= 1
            stack.append([index, _arity(token)])
            while stack and stack[-1][1] == 0:
                check()
                start, unused = stack.pop()
                ends[start] = index + 1
        if stack or not tokens:
            raise AssertionError("internal incomplete prefix")
        self.ends = tuple(ends)
        self.spans = tuple(spans) if spans is not None else None


def _op(tag, *children):
    check = children[0]._check
    tokens = [(tag,)]
    for child in children:
        for token in child.tokens:
            check()
            tokens.append(token)
    return _Tree(tokens, check=check)


def _all(variable, body):
    tokens = [("all", variable)]
    for token in body.tokens:
        body._check()
        tokens.append(token)
    return _Tree(tokens, check=body._check)


def _term(variable, check):
    return _Tree([("var", variable)], check=check)


def _function(symbol, arguments, check):
    tokens = [("fun", symbol, len(arguments))]
    for child in arguments:
        for token in child.tokens:
            check()
            tokens.append(token)
    return _Tree(tokens, check=check)


class _Reader:
    def __init__(self, body, component, check):
        _require(check, type(body) is bytes, "MALFORMED_INPUT", component, "immutable bytes required")
        self.body, self.component, self.check, self.pos = body, component, check, 0

    def require(self, test, reason):
        _require(self.check, test, "MALFORMED_INPUT", self.component, reason)

    def take(self, count):
        self.check()
        self.require(type(count) is int and 0 <= count <= len(self.body) - self.pos, "truncated bytes")
        start = self.pos
        self.pos += count
        return self.body[start:self.pos]

    def natural(self):
        value, shift, count = 0, 0, 0
        while True:
            self.check()
            self.require(self.pos < len(self.body), "unterminated natural")
            byte = self.body[self.pos]
            self.pos += 1
            count += 1
            value |= (byte & 127) << shift
            if byte < 128:
                self.require(count == 1 or byte != 0, "overlong natural")
                return value
            shift += 7

    def count(self):
        count = self.natural()
        self.require(count <= len(self.body) - self.pos, "vector count exceeds remaining bytes")
        return count

    def eof(self):
        self.check()
        self.require(self.pos == len(self.body), "trailing bytes")


def _parse_tree(reader, expected, signature):
    """An explicit prefix parse stack, with no recursive AST descent."""
    tokens, spans = [], []
    todo = [(expected, None)]
    functions, predicates = signature
    while todo:
        reader.check()
        kind, marker = todo.pop()
        if kind == "close":
            spans[marker] = (spans[marker][0], reader.pos)
            continue
        start = reader.pos
        tag = reader.natural()
        children = []
        if kind == "term":
            reader.require(tag in (0, 1), "term tag")
            symbol = reader.natural()
            if tag == 0:
                token = ("var", symbol)
            else:
                reader.require(symbol < len(functions), "function index")
                count = reader.count()
                reader.require(count == functions[symbol], "function arity")
                token, children = ("fun", symbol, count), ["term"] * count
        else:
            reader.require(tag in (0, 1, 2, 3, 4), "formula tag")
            if tag == 0:
                symbol = reader.natural()
                reader.require(symbol < len(predicates), "predicate index")
                count = reader.count()
                reader.require(count == predicates[symbol], "predicate arity")
                token, children = ("pred", symbol, count), ["term"] * count
            elif tag == 1:
                token, children = ("eq",), ["term", "term"]
            elif tag == 2:
                token, children = ("not",), ["formula"]
            elif tag == 3:
                token, children = ("imp",), ["formula", "formula"]
            else:
                token, children = ("all", reader.natural()), ["formula"]
        index = len(tokens)
        tokens.append(token)
        spans.append((start, None))
        todo.append(("close", index))
        for child in reversed(children):
            reader.check()
            todo.append((child, None))
    return _Tree(tokens, spans, check=reader.check)


def _binding_scan(tree, check, wanted=None, inserted=None):
    """Flat leaf scan with binder exit events; not B's path-set traversal."""
    active, exits, free = {}, [], set()
    for index, token in enumerate(tree.tokens):
        check()
        while exits and exits[-1][0] <= index:
            check()
            unused, variable = exits.pop()
            active[variable] -= 1
            if not active[variable]:
                del active[variable]
        if token[0] == "all":
            variable = token[1]
            active[variable] = active.get(variable, 0) + 1
            exits.append((tree.ends[index], variable))
        elif token[0] == "var" and token[1] not in active:
            free.add(token[1])
            if wanted is not None and token[1] == wanted:
                for variable in inserted:
                    check()
                    if variable in active:
                        return False
    return free if wanted is None else True


def _free_variables(tree, check):
    return _binding_scan(tree, check)


def _free_for(term, variable, formula, check):
    return _binding_scan(formula, check, variable, _free_variables(term, check))


def _substitute(term, variable, formula, check):
    _require(check, _free_for(term, variable, formula, check), "INVALID_CERTIFICATE", "certificate", "capture")
    output, active, exits = [], {}, []
    for index, token in enumerate(formula.tokens):
        check()
        while exits and exits[-1][0] <= index:
            check()
            unused, bound = exits.pop()
            active[bound] -= 1
            if not active[bound]:
                del active[bound]
        if token[0] == "all":
            active[token[1]] = active.get(token[1], 0) + 1
            exits.append((formula.ends[index], token[1]))
        if token == ("var", variable) and variable not in active:
            # Insert the already parsed term without scanning it again.
            for inserted in term.tokens:
                check()
                output.append(inserted)
        else:
            output.append(token)
    return _Tree(output, check=check)


def _parse_query(body, check):
    r = _Reader(body, "query", check)
    r.require(r.take(4) == b"FPC1", "query magic")
    r.require(r.natural() == 1, "query version")
    mode = r.natural()
    r.require(mode in (0, 1), "claim mode")
    function_values, predicate_values = [], []
    for unused in range(r.count()):
        check()
        function_values.append(r.natural())
    for unused in range(r.count()):
        check()
        predicate_values.append(r.natural())
    functions, predicates = tuple(function_values), tuple(predicate_values)
    profile = r.natural()
    r.require(profile in (0, 1, 2), "profile")
    signature = functions, predicates
    if profile == 1:
        r.require(signature == ((0, 1, 2, 2), ()), "PA signature")
    if profile == 2:
        r.require(signature == ((), (1, 1, 2)), "incidence signature")
    theory = []
    if profile == 0:
        for unused in range(r.count()):
            check()
            formula = _parse_tree(r, "formula", signature)
            r.require(not _free_variables(formula, check), "open theory axiom")
            theory.append(formula)
    hypotheses = []
    for unused in range(r.count()):
        check()
        hypotheses.append(_parse_tree(r, "formula", signature))
    goal = _parse_tree(r, "formula", signature)
    r.eof()
    if mode == 0:
        r.require(not hypotheses and not _free_variables(goal, check), "open theorem mode")
    return dict(mode=mode, signature=signature, profile=profile, theory=theory,
                hypotheses=hypotheses, goal=goal)


_LOGICAL_FIELDS = (("F", "F"), ("F", "F", "F"), ("F", "F"),
                   ("F", "N", "T"), ("F", "F", "N"), ("F", "N"),
                   ("T",), ("F", "N", "T", "T"))


def _parse_certificate(body, query, check):
    r = _Reader(body, "certificate", check)
    r.require(r.take(4) == b"FPP1", "certificate magic")
    count = r.count()
    r.require(count > 0, "empty certificate")
    rows = []
    for unused in range(count):
        check()
        start = r.pos
        formula = _parse_tree(r, "formula", query["signature"])
        tag = r.natural()
        r.require(tag in (0, 1, 2, 3, 4), "rule tag")
        payload, witness_tag = [], None
        if tag == 0:
            payload = [r.natural()]
        elif tag == 1:
            witness_tag = r.natural()
            r.require(witness_tag < 8, "logical tag")
            for field in _LOGICAL_FIELDS[witness_tag]:
                check()
                payload.append(r.natural() if field == "N" else
                               _parse_tree(r, "formula" if field == "F" else "term", query["signature"]))
        elif tag == 2:
            witness_tag = r.natural()
            r.require(witness_tag in (0, 1, 2, 3), "theory witness tag")
            if witness_tag == 2:
                payload = [_parse_tree(r, "formula", query["signature"]), r.natural()]
                parameters = []
                for ignored in range(r.count()):
                    check()
                    parameters.append(r.natural())
                payload.append(parameters)
            else:
                payload = [r.natural()]
        else:
            payload = [r.natural(), r.natural()]
        rows.append(dict(formula=formula, tag=tag, witness_tag=witness_tag,
                         payload=payload, span=(start, r.pos)))
    r.eof()
    return rows


# Independent mathematical declarations, not B's expanded core AST literals.
# f is variadic function application, p predicate, A/E quantifiers,
# !/>/&/| are the stated fixed connectives/abbreviations. No call occurs here.
_PA = (
    ("A", 0, ("!", ("=", ("f", 1, ("v", 0)), ("f", 0)))),
    ("A", 0, ("A", 1, (">", ("=", ("f", 1, ("v", 0)), ("f", 1, ("v", 1))), ("=", ("v", 0), ("v", 1))))),
    ("A", 0, ("=", ("f", 2, ("v", 0), ("f", 0)), ("v", 0))),
    ("A", 0, ("A", 1, ("=", ("f", 2, ("v", 0), ("f", 1, ("v", 1))), ("f", 1, ("f", 2, ("v", 0), ("v", 1)))))),
    ("A", 0, ("=", ("f", 3, ("v", 0), ("f", 0)), ("f", 0))),
    ("A", 0, ("A", 1, ("=", ("f", 3, ("v", 0), ("f", 1, ("v", 1))), ("f", 2, ("f", 3, ("v", 0), ("v", 1)), ("v", 0))))),
)
_HI = (
    ("A", 5, ("&", ("|", ("p", 0, ("v", 5)), ("p", 1, ("v", 5))), ("!", ("&", ("p", 0, ("v", 5)), ("p", 1, ("v", 5)))))),
    ("A", 0, ("A", 3, (">", ("p", 2, ("v", 0), ("v", 3)), ("&", ("p", 0, ("v", 0)), ("p", 1, ("v", 3)))))),
    ("A", 0, ("A", 1, (">", ("&", ("p", 0, ("v", 0)), ("&", ("p", 0, ("v", 1)), ("!", ("=", ("v", 0), ("v", 1))))), ("E", 3, ("&", ("p", 1, ("v", 3)), ("&", ("p", 2, ("v", 0), ("v", 3)), ("p", 2, ("v", 1), ("v", 3)))))))),
    ("A", 0, ("A", 1, ("A", 3, ("A", 4, (">", ("&", ("p", 0, ("v", 0)), ("&", ("p", 0, ("v", 1)), ("&", ("!", ("=", ("v", 0), ("v", 1))), ("&", ("p", 1, ("v", 3)), ("&", ("p", 1, ("v", 4)), ("&", ("p", 2, ("v", 0), ("v", 3)), ("&", ("p", 2, ("v", 1), ("v", 3)), ("&", ("p", 2, ("v", 0), ("v", 4)), ("p", 2, ("v", 1), ("v", 4)))))))))), ("=", ("v", 3), ("v", 4))))))),
    ("A", 3, (">", ("p", 1, ("v", 3)), ("E", 0, ("E", 1, ("&", ("p", 0, ("v", 0)), ("&", ("p", 0, ("v", 1)), ("&", ("!", ("=", ("v", 0), ("v", 1))), ("&", ("p", 2, ("v", 0), ("v", 3)), ("p", 2, ("v", 1), ("v", 3)))))))))),
    ("E", 0, ("E", 1, ("E", 2, ("&", ("p", 0, ("v", 0)), ("&", ("p", 0, ("v", 1)), ("&", ("p", 0, ("v", 2)), ("&", ("!", ("=", ("v", 0), ("v", 1))), ("&", ("!", ("=", ("v", 0), ("v", 2))), ("&", ("!", ("=", ("v", 1), ("v", 2))), ("!", ("E", 3, ("&", ("p", 1, ("v", 3)), ("&", ("p", 2, ("v", 0), ("v", 3)), ("&", ("p", 2, ("v", 1), ("v", 3)), ("p", 2, ("v", 2), ("v", 3)))))))))))))))),
)


def _declaration(specification, check):
    todo, tokens = [specification], []
    while todo:
        check()
        node = todo.pop()
        tag = node[0]
        if tag == "&":
            todo.append(("!", (">", node[1], ("!", node[2]))))
        elif tag == "|":
            todo.append((">", ("!", node[1]), node[2]))
        elif tag == "E":
            todo.append(("!", ("A", node[1], ("!", node[2]))))
        elif tag in ("v", "f", "p"):
            if tag == "v":
                tokens.append(("var", node[1]))
            else:
                children = node[2:]
                tokens.append(("fun" if tag == "f" else "pred", node[1], len(children)))
                todo.extend(reversed(children))
        elif tag == "A":
            tokens.append(("all", node[1]))
            todo.append(node[2])
        else:
            tokens.append(({"!": "not", ">": "imp", "=": "eq"}[tag],))
            todo.extend(reversed(node[1:]))
    return _Tree(tokens, check=check)


def _logical(tag, p, check):
    if tag == 0:
        a, b = p
        return _op("imp", a, _op("imp", b, a))
    if tag == 1:
        a, b, c = p
        return _op("imp", _op("imp", a, _op("imp", b, c)),
                   _op("imp", _op("imp", a, b), _op("imp", a, c)))
    if tag == 2:
        a, b = p
        return _op("imp", _op("imp", _op("not", b), _op("not", a)), _op("imp", a, b))
    if tag == 3:
        a, x, t = p
        return _op("imp", _all(x, a), _substitute(t, x, a, check))
    if tag == 4:
        a, b, x = p
        return _op("imp", _all(x, _op("imp", a, b)), _op("imp", _all(x, a), _all(x, b)))
    if tag == 5:
        a, x = p
        _require(check, x not in _free_variables(a, check), "INVALID_CERTIFICATE", "certificate", "Q3 freshness")
        return _op("imp", a, _all(x, a))
    if tag == 6:
        return _op("eq", p[0], p[0])
    a, x, s, t = p
    return _op("imp", _op("eq", s, t), _op("imp", _substitute(s, x, a, check), _substitute(t, x, a, check)))


def _induction(a, x, parameters, check):
    _require(check, parameters == sorted(_free_variables(a, check) - {x}), "INVALID_CERTIFICATE", "certificate", "induction parameters")
    zero = _function(0, [], check)
    successor = _function(1, [_term(x, check)], check)
    base = _substitute(zero, x, a, check)
    step = _all(x, _op("imp", a, _substitute(successor, x, a, check)))
    result = _op("imp", _op("not", _op("imp", base, _op("not", step))), _all(x, a))
    for parameter in reversed(parameters):
        check()
        result = _all(parameter, result)
    return result


def _semantics(query, rows, check):
    hypotheses, profile = query["hypotheses"], query["profile"]
    for index, row in enumerate(rows):
        check()
        tag, p, witness = row["tag"], row["payload"], row["witness_tag"]
        try:
            if tag == 0:
                _require(check, p[0] < len(hypotheses), "INVALID_CERTIFICATE", "certificate", "hypothesis index")
                expected = hypotheses[p[0]]
            elif tag == 1:
                expected = _logical(witness, p, check)
            elif tag == 2:
                _require(check, (witness, profile) in ((0, 0), (1, 1), (2, 1), (3, 2)), "INVALID_CERTIFICATE", "certificate", "theory/profile mismatch")
                if witness == 2:
                    expected = _induction(p[0], p[1], p[2], check)
                else:
                    table = query["theory"] if witness == 0 else _PA if witness == 1 else _HI
                    _require(check, p[0] < len(table), "INVALID_CERTIFICATE", "certificate", "table index")
                    expected = table[p[0]] if witness == 0 else _declaration(table[p[0]], check)
            elif tag == 3:
                ante, implication = p
                _require(check, ante < index and implication < index, "INVALID_CERTIFICATE", "certificate", "MP backward references")
                expected_implication = _op("imp", rows[ante]["formula"], row["formula"])
                _require(check, rows[implication]["formula"].tokens == expected_implication.tokens, "INVALID_CERTIFICATE", "certificate", "MP operands")
                expected = row["formula"]
            else:
                source, variable = p
                _require(check, source < index, "INVALID_CERTIFICATE", "certificate", "GEN backward reference")
                for hypothesis in hypotheses:
                    check()
                    _require(check, variable not in _free_variables(hypothesis, check), "INVALID_CERTIFICATE", "certificate", "GEN global hypotheses")
                expected = _all(variable, rows[source]["formula"])
            _require(check, row["formula"].tokens == expected.tokens, "INVALID_CERTIFICATE", "certificate", "row formula mismatch")
        except BaseException as error:
            check.propagate_fault()
            if not check.owns(error):
                raise
            error.row = index
            raise
    _require(check, rows[-1]["formula"].tokens == query["goal"].tokens, "INVALID_CERTIFICATE", "certificate", "final goal")


def _view_tree(tree):
    return dict(prefix_tokens=tree.tokens, node_byte_spans=tree.spans)


def _receipt_query(query, check):
    theory, hypotheses = [], []
    for tree in query["theory"]:
        check()
        theory.append(_view_tree(tree))
    for tree in query["hypotheses"]:
        check()
        hypotheses.append(_view_tree(tree))
    return dict(mode=query["mode"], profile=query["profile"], signature=query["signature"],
                theory=theory, hypotheses=hypotheses, goal=_view_tree(query["goal"]))


def _certificate_receipt(query_bytes, certificate_bytes, *, check):
    """Complete syntax precedes inference. Foreign first faults escape unchanged."""
    try:
        check()
        query = _parse_query(query_bytes, check)
        rows = _parse_certificate(certificate_bytes, query, check)
        _semantics(query, rows, check)
        result = dict(schema=VERSION, status="VALID_DERIVATION", complete_check=True,
                      query=_receipt_query(query, check), rows=[], final_goal_equal=True)
        for index, row in enumerate(rows):
            check()
            payload = []
            for value in row["payload"]:
                check()
                payload.append(_view_tree(value) if type(value) is _Tree else value)
            result["rows"].append(dict(index=index, formula=_view_tree(row["formula"]),
                                       rule_tag=row["tag"], witness_tag=row["witness_tag"],
                                       payload=payload, byte_span=row["span"]))
        check()
        return result
    except BaseException as error:
        check.propagate_fault()
        if not check.owns(error):
            raise
        return dict(schema=VERSION, status=error.status, complete_check=True,
                    component=error.component, reason=error.reason, row=error.row,
                    final_goal_equal=False, accepted_prefix=False)


def reference_check_certificate(query_bytes, certificate_bytes, *, check):
    call = _Call(check)
    try:
        return _certificate_receipt(query_bytes, certificate_bytes, check=call)
    except BaseException:
        call.propagate_fault()
        raise


def reference_check_envelope(envelope_bytes, *, check):
    check = _Call(check)
    try:
        r = _Reader(envelope_bytes, "envelope", check)
        r.require(r.take(4) == b"FPI1", "envelope magic")
        query = r.take(r.natural())
        query_end = r.pos
        certificate = r.take(r.natural())
        certificate_end = r.pos
        r.require(r.take(4) == b"END1", "envelope trailer")
        r.eof()
        result = _certificate_receipt(query, certificate, check=check)
        result["envelope_slices"] = dict(query=(query_end-len(query), query_end),
                                         certificate=(certificate_end-len(certificate), certificate_end))
        check()
        return result
    except BaseException as error:
        check.propagate_fault()
        if not check.owns(error):
            raise
        return dict(schema=VERSION, status=error.status, complete_check=True,
                    component=error.component, reason=error.reason, row=error.row,
                    final_goal_equal=False, accepted_prefix=False)


def _inspect_binding(formula_bytes, term_bytes, variable, function_arities, predicate_arities, *, check):
    """Qualification-only binding observation from standalone typed prefix bytes."""
    _require(check, type(variable) is int and variable >= 0, "MALFORMED_INPUT", "binding", "variable")
    _require(check, type(function_arities) in (tuple, list) and type(predicate_arities) in (tuple, list),
             "MALFORMED_INPUT", "binding", "literal arity vectors")
    signature = tuple(function_arities), tuple(predicate_arities)
    for vector in signature:
        for value in vector:
            check()
            _require(check, type(value) is int and value >= 0, "MALFORMED_INPUT", "binding", "arity")
    fr = _Reader(formula_bytes, "binding", check)
    formula = _parse_tree(fr, "formula", signature)
    fr.eof()
    tr = _Reader(term_bytes, "binding", check)
    term = _parse_tree(tr, "term", signature)
    tr.eof()
    permitted = _free_for(term, variable, formula, check)
    return dict(formula_free_variables=sorted(_free_variables(formula, check)),
                term_free_variables=sorted(_free_variables(term, check)), free_for=permitted,
                substituted_prefix_tokens=_substitute(term, variable, formula, check).tokens if permitted else None)


def inspect_binding(formula_bytes, term_bytes, variable, function_arities, predicate_arities, *, check):
    """A separate call token; owned refusals may escape, never gain future authority."""
    call = _Call(check)
    try:
        return _inspect_binding(formula_bytes, term_bytes, variable,
                                function_arities, predicate_arities, check=call)
    except BaseException:
        call.propagate_fault()
        raise
