"""Independent prospective toy controls. All recipes are UNRUN Source.

No scientific/goal/codec module is imported. The caller supplies reviewed roles.
The toy finite theories and literal expectations are not the six search targets,
the previous checker bank, proofs for an evaluation target, or injected facts.
"""

import copy
import hashlib
import json

VERSION = "FPC-H1-independent-search-controls-v2"
RETURN_SCHEMA = "FPC-H1-independent-search-controls-v1"
CONTROL_IDS = (
    "codec-hi-and-exists-literal", "codec-pa-no-profile-payload",
    "codec-metadata-query-invariance", "codec-shadowed-binder-preserved",
    "codec-bool-mode-refused", "codec-open-theorem-refused",
    "codec-signature-mismatch-refused", "codec-binder-order-refused",
    "codec-extra-proof-field-refused", "codec-retained-fault-identity",
    "product-two-by-three", "product-three-binary-slots", "product-closed-empty",
    "product-zero-arity", "product-open-request-not-eof", "product-staggered-arrivals",
    "product-known-empty-dominates-open",
    "match-formula-meta", "match-consistent-repeat", "match-conflicting-repeat",
    "match-rigid-binder", "match-no-alpha-renaming", "match-term-meta",
    "match-sort-conflict", "match-variable-meta", "match-rigid-arity-conflict",
    "builder-H1-literal", "builder-H2-literal", "builder-H3-literal",
    "builder-Q1-literal", "builder-Q2-literal", "builder-Q3-literal",
    "builder-E1-literal", "builder-E2-literal", "builder-Q1-capture-refused",
    "builder-Q3-free-variable-refused", "builder-E2-capture-refused",
    "builder-induction-full-parameters-refused",
    "search-antecedent-first-closure", "search-implication-first-closure",
    "search-duplicate-source-aliases", "search-cyclic-demand-no-fact",
    "search-long-source-witness-not-fact", "search-shared-DAG-export",
    "search-late-GEN", "search-full-Gamma-GEN-refusal",
    "search-source-variable-outside-grammar", "search-source-depth-outside-grammar",
    "search-priority-record-invariants", "search-cutoff-live-prefix-no-exhaustion",
    "fault-product-first-ValueError", "fault-matcher-first-StopIteration",
    "fault-search-retained-owned-codec", "fault-search-later-RuntimeError",
    "fault-final-validator-first-identity", "fault-builder-public-class-identity",
)

P = ["pred", 0, []]
Q = ["pred", 1, []]
R = ["pred", 2, []]
S = ["pred", 3, []]
PQ = ["imp", ["pred", 0, []], ["pred", 1, []]]
QP = ["imp", ["pred", 1, []], ["pred", 0, []]]
PR = ["imp", ["pred", 0, []], ["pred", 2, []]]
RS = ["imp", ["pred", 2, []], ["pred", 3, []]]
QRS = ["imp", ["pred", 1, []], ["imp", ["pred", 2, []], ["pred", 3, []]]]

# Independently hand-written ordered tuples, not obtained from product_step.
EXPECTED_23 = [[0, 0], [0, 1], [1, 0], [0, 2], [1, 1], [1, 2]]
EXPECTED_222 = [[0, 0, 0], [0, 0, 1], [0, 1, 0], [1, 0, 0],
                [0, 1, 1], [1, 0, 1], [1, 1, 0], [1, 1, 1]]


class SearchControlFailure(AssertionError):
    """A control mismatch; never a theorem result or owned budget wrapper."""


class _Call:
    def __init__(self, check):
        if not callable(check):
            raise TypeError("check must be callable")
        self.check = check
        self.first_fault = None

    def tick(self):
        if self.first_fault is not None:
            raise self.first_fault
        try:
            self.check()
        except BaseException as error:
            self.first_fault = error
            raise

    def need(self, value, message):
        if self.first_fault is not None:
            raise self.first_fault
        if not value:
            raise SearchControlFailure(message)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def _same(left, right):
    # JSON explicitly normalizes immutable matcher tuples to ordinary arrays.
    # This is not a subject/reference proof-receipt equivalence claim.
    return _canonical(left) == _canonical(right)


def _toy_spec():
    return {"id": "synthetic-codec-only", "profile": "HILBERT_PLANE_INCIDENCE_MIN_V1",
        "profile_id": 2, "function_arities": [], "predicate_arities": [1, 1, 2],
        "mode": 0, "hypotheses": [], "goal_latex": r"\(\exists r\,(\mathrm{Pt}(r)\land\neg\mathrm{Ln}(r))\)",
        "binder_order": [2], "binder_kinds": ["exists"],
        "goal_tree": ["exists", 2, ["and", ["pred", 0, [["var", 2]]],
            ["not", ["pred", 1, [["var", 2]]]]]],
        "classification": "Synthetic codec input only, with no supplied derivation."}


def _codec(codec, spec, call):
    before = _canonical(spec)
    result = codec.encode_declared_query(spec, check=call.tick)
    call.tick()
    call.need(type(result) is dict and set(result) == {"query_bytes", "receipt"}, "codec wrapper")
    raw, receipt = result["query_bytes"], result["receipt"]
    call.need(type(raw) is bytes and type(receipt) is dict, "codec output carriers")
    call.need(receipt.get("complete") is True, "codec incomplete")
    call.need(receipt.get("query_identity") == {"bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest()}, "codec byte identity")
    call.need(receipt.get("profile_id") == spec["profile_id"]
        and _same(receipt.get("function_arities"), spec["function_arities"])
        and _same(receipt.get("predicate_arities"), spec["predicate_arities"])
        and type(receipt.get("mode")) is int and receipt["mode"] == 0
        and receipt.get("hypotheses") == [], "codec query fields")
    call.need(_canonical(spec) == before, "codec mutated input")
    return result


def _codec_refusal(codec, spec, call):
    try:
        codec.encode_declared_query(spec, check=call.tick)
    except BaseException as error:
        if call.first_fault is not None:
            raise call.first_fault
        if not (type(error) is codec.DeclarationFormatError and codec.is_owned_error(error)):
            raise
        call.tick()
        return {"type": type(error).__name__, "message": str(error)}
    call.need(False, "malformed declaration accepted")


def _fault(action, sentinel, call):
    """The intentional sentinel is distinct from the genuine outer callback."""
    seen = [0]
    later = RuntimeError("synthetic later fault must never replace first")
    def callback():
        call.tick()
        seen[0] += 1
        if seen[0] == 1:
            raise sentinel
        raise later
    try:
        action(callback)
    except BaseException as error:
        if call.first_fault is not None:
            raise call.first_fault
        if error is not sentinel:
            raise
        call.need(seen[0] == 1, "callback invoked after first intentional fault")
        return {"identity_preserved": True, "callback_invocations": seen[0],
                "fault_type": type(error).__name__}
    call.need(False, "callback fault was swallowed")


def _products(search, lengths, closed, expected, call, staggered=False):
    state = None
    observed = []
    records = []
    current = [0] * len(lengths) if staggered else list(lengths)
    flags = [False] * len(lengths) if staggered else list(closed)
    for _ in range(128):  # Diagnostic finite cursor ceiling, not search grammar.
        call.tick()
        result = search.product_step(state, current, flags, check=call.tick)
        call.need(type(result) is dict and set(result) == {"kind", "state", "indices", "requests"}, "product ABI")
        state = result["state"]
        call.need(type(state) is dict and set(state) == {"diagonal", "indices", "eof", "emitted"}, "product state ABI")
        records.append(copy.deepcopy(result))
        kind = result["kind"]
        if kind == "TUPLE":
            indices = result["indices"]
            call.need(type(indices) is list and len(indices) == len(lengths), "product tuple arity")
            call.need(all(type(x) is int and 0 <= x < lengths[i] for i, x in enumerate(indices)), "product tuple range")
            call.need(indices not in observed, "duplicate product tuple")
            observed.append(indices)
        elif kind == "WAIT":
            call.need(staggered and result["indices"] is None and result["requests"], "unexpected product WAIT")
            for request in result["requests"]:
                call.tick()
                call.need(type(request) is dict and set(request) == {"slot", "index"}, "product request ABI")
                slot, index = request["slot"], request["index"]
                call.need(type(slot) is int and 0 <= slot < len(lengths)
                    and type(index) is int and index >= current[slot] and not flags[slot], "missing index request")
                current[slot] = min(lengths[slot], index + 1)
                flags[slot] = current[slot] == lengths[slot]
        elif kind == "EOF":
            call.need(state["eof"] is True and _same(observed, expected), "product full literal coverage")
            return {"expected": expected, "observed": observed, "steps": records}
        else:
            skipped = result["indices"]
            call.need(kind == "SKIP_OUTSIDE" and type(skipped) is list
                and len(skipped) == len(current) and result["requests"] == [], "product skip carrier")
            call.need(all(type(index) is int and index >= 0 for index in skipped), "product skip indices")
            call.need(any(flags[slot] and index >= current[slot]
                for slot, index in enumerate(skipped)), "product skip lacks closed outside coordinate")
    call.need(False, "tiny finite product did not reach EOF")


def _match(search, pattern, value, matched, expected, call):
    pattern_before, value_before = _canonical(pattern), _canonical(value)
    result = search.match_pattern(pattern, value, check=call.tick)
    call.tick()
    call.need(type(result) is dict and set(result) == {"matched", "bindings", "rigid_nodes"}, "matcher ABI")
    call.need(type(result["matched"]) is bool and result["matched"] is matched, "matcher outcome")
    call.need(type(result["rigid_nodes"]) is int and result["rigid_nodes"] >= 0, "rigid count")
    if matched:
        call.need(_same(result["bindings"], expected), "literal matcher binding")
    call.need(_canonical(pattern) == pattern_before and _canonical(value) == value_before, "matcher mutation")
    return result


def _put_natural(output, value, call):
    call.need(type(value) is int and value >= 0, "toy natural")
    while True:
        call.tick()
        digit = value & 127
        value >>= 7
        output.append(digit | (128 if value else 0))
        if not value:
            return


def _put_ast(output, root, call):
    """Independent fixture wire writer only; no calculus or producer logic."""
    pending = [root]
    while pending:
        call.tick()
        node = pending.pop()
        tag = node[0]
        if tag == "var":
            _put_natural(output, 0, call)
            _put_natural(output, node[1], call)
        elif tag in ("fun", "pred"):
            _put_natural(output, 1 if tag == "fun" else 0, call)
            _put_natural(output, node[1], call)
            _put_natural(output, len(node[2]), call)
            for arg in reversed(node[2]):
                call.tick()
                pending.append(arg)
        elif tag in ("eq", "imp"):
            _put_natural(output, 1 if tag == "eq" else 3, call)
            pending.append(node[2]); pending.append(node[1])
        elif tag == "not":
            _put_natural(output, 2, call); pending.append(node[1])
        else:
            call.need(tag == "all", "toy core tag")
            _put_natural(output, 4, call); _put_natural(output, node[1], call)
            pending.append(node[2])


def _query(axioms, goal, call, *, functions=(), predicates=(0, 0, 0, 0), Gamma=(), mode=0):
    output = bytearray(b"FPC1")
    for number in (1, mode):
        _put_natural(output, number, call)
    for vector in (functions, predicates):
        _put_natural(output, len(vector), call)
        for number in vector:
            _put_natural(output, number, call)
    _put_natural(output, 0, call)  # Synthetic finite-theory profile only.
    _put_natural(output, len(axioms), call)
    for formula in axioms:
        _put_ast(output, formula, call)
    _put_natural(output, len(Gamma), call)
    for formula in Gamma:
        _put_ast(output, formula, call)
    _put_ast(output, goal, call)
    return bytes(output)


def _grammar(*, variables=0, depth=0, witness=0, derived=3):
    return {"schema": "FPC-H1-finite-producer-grammar-v1", "control_only": True,
        "variables": variables, "term_depth": depth, "witness_nodes": witness,
        "derived_nodes": derived}


def _known(receipt):
    return { _canonical(row["formula"]): row for row in receipt["known"] }


def _run(search, query, grammar, call, *, ordering="FIFO", progress=None):
    if progress is None:
        progress = []
    # Search receives no independent reference role or target/fixture identifier.
    result = search.search_fpc(query, grammar=grammar, ordering=ordering,
        modules=call.search_modules, check=call.tick, progress=progress)
    call.tick()
    call.need(type(result) is dict and set(result) == {"status", "candidate_certificate_bytes", "receipt"}, "search wrapper")
    call.need(len(progress) == 1 and progress[0] is result["receipt"], "current live search carrier")
    receipt = result["receipt"]
    call.need(receipt.get("schema") == "FPC-H1-uniform-search-receipt-v1", "search receipt schema")
    call.need(type(receipt.get("known")) is list, "known carrier")
    call.need(len(_known(receipt)) == len(receipt["known"]), "formula quotient duplicates")
    return result


def _closure(search, axioms, expected, call, *, ordering="FIFO"):
    query = _query(axioms, S, call)
    result = _run(search, query, _grammar(), call, ordering=ordering)
    call.need(result["status"] == "EXHAUSTED_DECLARED_GRAMMAR"
        and result["candidate_certificate_bytes"] is None, "tiny closure status")
    receipt = result["receipt"]
    call.need(set(_known(receipt)) == {_canonical(x) for x in expected}, "literal finite closure")
    call.need(receipt["catalogs"]["T"]["eof"] is True
        and receipt["catalogs"]["W"]["eof"] is True, "closure before catalog EOF")
    call.need(all(row["registration_complete"] is True for row in receipt["known"]), "unfinished registration at exhaustion")
    return {"query_hex": query.hex(), "expected_known": expected, "receipt": receipt}


def _accept_pair(query, certificate, modules, call):
    subject = modules["checker"].check_certificate(query, certificate, check=call.tick)
    reference = modules["reference"].reference_check_certificate(query, certificate, check=call.tick)
    call.tick()
    call.need(subject.get("status") == "VALID_DERIVATION"
        and all(subject.get(key) is True for key in ("accepted", "syntax_complete",
            "derivation_complete", "final_goal_equal", "complete")), "subject whole candidate gate")
    call.need(reference.get("status") == "VALID_DERIVATION"
        and reference.get("complete_check") is True, "reference whole candidate gate")
    return {"query_identity": {"bytes": len(query), "sha256": hashlib.sha256(query).hexdigest()},
        "certificate_identity": {"bytes": len(certificate), "sha256": hashlib.sha256(certificate).hexdigest()},
        "subject": subject, "reference": reference}


def run_search_controls(*, search, codec, modules, check):
    """Run exactly the frozen ordered independent population in a future actual."""
    call = _Call(check)
    try:
        call.tick()
        call.need(type(modules) is dict and set(modules) == {"checker", "builders", "reference"}, "control roles")
        call.search_modules = {"checker": modules["checker"], "builders": modules["builders"]}
        rows = []
        def record(identifier, evidence):
            call.tick()
            call.need(len(rows) < len(CONTROL_IDS) and CONTROL_IDS[len(rows)] == identifier, "control order")
            rows.append({"id": identifier, "passed": True, "evidence": evidence})

        spec = _toy_spec()
        encoded = _codec(codec, spec, call)
        expected_goal = ["not", ["all", 2, ["not", ["not", ["imp",
            ["pred", 0, [["var", 2]]], ["not", ["not", ["pred", 1, [["var", 2]]]]]]]]]]
        expected_bytes = (b"FPC1" b"\x01\x00\x00\x03\x01\x01\x02\x02\x00"
            b"\x02\x04\x02\x02\x02\x03\x00\x00\x01\x00\x02\x02\x02\x00\x01\x01\x00\x02")
        call.need(encoded["query_bytes"] == expected_bytes
            and _same(encoded["receipt"]["expanded_goal"], expected_goal), "literal AND/EXISTS bytes/core")
        record(CONTROL_IDS[0], {"expected_hex": expected_bytes.hex(), "receipt": encoded["receipt"]})
        pa = {"id": "synthetic-PA-codec-only", "profile": "PA_0S_PLUS_TIMES_V1",
            "profile_id": 1, "function_arities": [0, 1, 2, 2], "predicate_arities": [],
            "mode": 0, "hypotheses": [], "goal_latex": r"\(\forall v_3\,\neg(v_3=v_3)\)",
            "binder_order": [3], "goal_tree": ["all", 3, ["not", ["eq", ["var", 3], ["var", 3]]]],
            "classification": "Synthetic encoding-only statement; no truth or proof assertion."}
        pa_encoded = _codec(codec, pa, call)
        pa_bytes = b"FPC1\x01\x00\x04\x00\x01\x02\x02\x00\x01\x00\x04\x03\x02\x01\x00\x03\x00\x03"
        call.need(pa_encoded["query_bytes"] == pa_bytes
            and pa_encoded["receipt"]["profile_payload_octets"] == 0, "literal PA no-payload bytes")
        record(CONTROL_IDS[1], {"expected_hex": pa_bytes.hex(), "receipt": pa_encoded["receipt"]})
        changed = copy.deepcopy(spec)
        changed.update(id="different-metadata-name", goal_latex="metadata only", classification="metadata only")
        changed_encoded = _codec(codec, changed, call)
        call.need(changed_encoded["query_bytes"] == encoded["query_bytes"], "goal-name routing")
        record(CONTROL_IDS[2], {"same_query": True, "different_declaration_digest":
            changed_encoded["receipt"]["declaration_canonical_sha256"] != encoded["receipt"]["declaration_canonical_sha256"]})
        shadow = copy.deepcopy(pa)
        shadow["goal_tree"] = ["all", 3, ["all", 3, ["not", ["eq", ["var", 3], ["var", 3]]]]]
        shadow["binder_order"] = [3, 3]
        shadow_encoded = _codec(codec, shadow, call)
        call.need(_same(shadow_encoded["receipt"]["expanded_goal"], shadow["goal_tree"]), "shadowed binder changed")
        record(CONTROL_IDS[3], shadow_encoded["receipt"])
        malformed = copy.deepcopy(spec); malformed["mode"] = False
        record(CONTROL_IDS[4], _codec_refusal(codec, malformed, call))
        malformed = copy.deepcopy(spec); malformed["goal_tree"] = ["pred", 0, [["var", 2]]]; malformed["binder_order"] = []; malformed["binder_kinds"] = []
        record(CONTROL_IDS[5], _codec_refusal(codec, malformed, call))
        malformed = copy.deepcopy(spec); malformed["predicate_arities"] = [1, 1, 1]
        record(CONTROL_IDS[6], _codec_refusal(codec, malformed, call))
        malformed = copy.deepcopy(spec); malformed["binder_order"] = [1]
        record(CONTROL_IDS[7], _codec_refusal(codec, malformed, call))
        malformed = copy.deepcopy(spec); malformed["proof"] = []
        record(CONTROL_IDS[8], _codec_refusal(codec, malformed, call))
        retained = None
        try:
            codec.encode_declared_query(malformed, check=call.tick)
        except BaseException as error:
            if call.first_fault is not None:
                raise call.first_fault
            if not (type(error) is codec.DeclarationFormatError and codec.is_owned_error(error)):
                raise
            retained = error
        call.need(retained is not None, "prior genuine codec refusal missing")
        retained_fields = dict(vars(retained))
        record(CONTROL_IDS[9], _fault(lambda callback: codec.encode_declared_query(spec, check=callback), retained, call))
        call.need(vars(retained) == retained_fields, "retained codec error mutated")

        record(CONTROL_IDS[10], _products(search, [2, 3], [True, True], EXPECTED_23, call))
        record(CONTROL_IDS[11], _products(search, [2, 2, 2], [True, True, True], EXPECTED_222, call))
        record(CONTROL_IDS[12], _products(search, [0, 3], [True, True], [], call))
        record(CONTROL_IDS[13], _products(search, [], [], [[]], call))
        waiting = search.product_step(None, [0, 1], [False, True], check=call.tick)
        call.need(waiting["kind"] == "WAIT" and waiting["state"]["eof"] is False
            and {"slot": 0, "index": 0} in waiting["requests"], "missing current index mistaken for EOF")
        record(CONTROL_IDS[14], waiting)
        record(CONTROL_IDS[15], _products(search, [2, 3], [True, True], EXPECTED_23, call, staggered=True))
        record(CONTROL_IDS[16], _products(search, [0, 0], [True, False], [], call))

        f = {"meta": "A", "sort": "F"}
        t = {"meta": "t", "sort": "T"}
        v = {"meta": "x", "sort": "V"}
        record(CONTROL_IDS[17], _match(search, f, P, True, {"A": P}, call))
        record(CONTROL_IDS[18], _match(search, ["imp", f, f], ["imp", P, P], True, {"A": P}, call))
        record(CONTROL_IDS[19], _match(search, ["imp", f, f], PQ, False, {}, call))
        record(CONTROL_IDS[20], _match(search, ["all", 3, f], ["all", 3, P], True, {"A": P}, call))
        record(CONTROL_IDS[21], _match(search, ["all", 3, f], ["all", 4, P], False, {}, call))
        record(CONTROL_IDS[22], _match(search, ["eq", t, t], ["eq", ["var", 2], ["var", 2]], True, {"t": ["var", 2]}, call))
        record(CONTROL_IDS[23], _match(search, ["eq", f, ["var", 0]], ["eq", ["var", 1], ["var", 0]], False, {}, call))
        record(CONTROL_IDS[24], _match(search, ["all", v, f], ["all", 5, Q], True, {"x": 5, "A": Q}, call))
        record(CONTROL_IDS[25], _match(search, ["pred", 0, [["var", 0]]], ["pred", 0, []], False, {}, call))

        # The remainder is kept in a separate ordinary function for inspectable
        # independence: literal primitive expectations and toy event/closure tests.
        _remaining(search, codec, modules, call, record, retained, encoded)
        call.tick()
        call.need([row["id"] for row in rows] == list(CONTROL_IDS), "complete frozen control population")
        return {"schema": RETURN_SCHEMA, "complete": True, "control_ids": list(CONTROL_IDS),
            "controls": rows, "counts": {"total": len(rows), "passed": len(rows), "failed": 0},
            "coverage_limits": [
                "Finite toy cases are not a formal exhaustive search correctness theorem.",
                "Returned product cursors resume enumeration, not an interrupted whole search.",
                "Builder guard controls qualify constituents; live producer refusal joins remain separately audited.",
                "Priority-fourth assertions apply to saved observed dequeues; short traces may not exercise a fourth dequeue.",
                "No every-callback sweep, resource fit forecast, proof search on six goals, or target certificate is supplied.",
                "Final worker same-byte dualvalidation/admission and original caps remain external."],
            "scope": "INDEPENDENT_SYNTHETIC_CONTROLS_ONLY_NO_SEARCH_OR_THEOREM_ADMISSION"}
    except BaseException:
        if call.first_fault is not None:
            raise call.first_fault
        raise


def _remaining(search, codec, modules, call, record, retained, encoded):
    """Continuation of the single frozen control bank; not an extra public API."""
    builders = modules["builders"]
    cases = [
        (0, [P, Q], ["imp", P, ["imp", Q, P]]),
        (1, [P, Q, R], ["imp", ["imp", P, ["imp", Q, R]], ["imp", ["imp", P, Q], ["imp", P, R]]]),
        (2, [P, Q], ["imp", ["imp", ["not", Q], ["not", P]], ["imp", P, Q]]),
        (3, [["pred", 3, [["var", 0]]], 0, ["fun", 0, []]],
            ["imp", ["all", 0, ["pred", 3, [["var", 0]]]], ["pred", 3, [["fun", 0, []]]]]),
        (4, [P, Q, 2], ["imp", ["all", 2, ["imp", P, Q]], ["imp", ["all", 2, P], ["all", 2, Q]]]),
        (5, [P, 2], ["imp", P, ["all", 2, P]]),
        (6, [["fun", 0, []]], ["eq", ["fun", 0, []], ["fun", 0, []]]),
        (7, [["pred", 3, [["var", 0]]], 0, ["fun", 0, []], ["fun", 1, []]],
            ["imp", ["eq", ["fun", 0, []], ["fun", 1, []]],
                ["imp", ["pred", 3, [["fun", 0, []]]], ["pred", 3, [["fun", 1, []]]]]]),
    ]
    for i, (tag, witnesses, expected) in enumerate(cases):
        call.tick()
        result = builders.logical_axiom(tag, copy.deepcopy(witnesses), check=call.tick)
        call.need(_same(result, expected), "independent literal primitive builder")
        record(CONTROL_IDS[26 + i], {"tag": tag, "witnesses": witnesses, "expected": expected, "observed": result})
    bad = [
        ("logical", 3, [["all", 1, ["pred", 3, [["var", 0], ["var", 1]]]], 0, ["var", 1]]),
        ("logical", 5, [["pred", 0, [["var", 2]]], 2]),
        ("logical", 7, [["all", 1, ["pred", 3, [["var", 0], ["var", 1]]]], 0, ["var", 0], ["var", 1]]),
        ("induction", 0, [["eq", ["var", 0], ["var", 2]], 0, []]),
    ]
    for i, (kind, tag, witnesses) in enumerate(bad):
        call.tick()
        try:
            if kind == "logical":
                builders.logical_axiom(tag, copy.deepcopy(witnesses), check=call.tick)
            else:
                builders.pa_induction(copy.deepcopy(witnesses[0]), witnesses[1], witnesses[2], check=call.tick)
        except BaseException as error:
            if call.first_fault is not None:
                raise call.first_fault
            if type(error) is not builders.InvalidWitness:
                raise
            record(CONTROL_IDS[34 + i], {"kind": kind, "tag": tag,
                "witnesses": witnesses, "refusal": str(error)})
        else:
            call.need(False, "capture/free-variable/parameter guard not enforced")

    first = _closure(search, [P, PQ], [P, PQ, Q], call)
    record(CONTROL_IDS[38], first)
    record(CONTROL_IDS[39], _closure(search, [PQ, P], [P, PQ, Q], call))
    duplicate = _closure(search, [P, P, PQ], [P, PQ, Q], call)
    p_row = _known(duplicate["receipt"])[_canonical(P)]
    call.need(len(p_row["origins"]) >= 2, "duplicate source aliases discarded")
    record(CONTROL_IDS[40], duplicate)
    cyclic_query = _query([PQ, QP], Q, call)
    cyclic = _run(search, cyclic_query, _grammar(), call)
    call.need(cyclic["status"] == "EXHAUSTED_DECLARED_GRAMMAR"
        and set(_known(cyclic["receipt"])) == {_canonical(PQ), _canonical(QP)}, "cycle invented a fact")
    demands = cyclic["receipt"]["demands"]
    call.need(len({_canonical(row["formula"]) for row in demands}) == len(demands), "cyclic demand semantic duplication")
    call.need({_canonical(P), _canonical(Q)} <= {_canonical(row["formula"]) for row in demands}, "missing target-relevant cyclic demand")
    record(CONTROL_IDS[41], {"query_hex": cyclic_query.hex(), "receipt": cyclic["receipt"]})

    long_source = ["imp", P, ["imp", Q, R]]
    long_body = ["imp", Q, R]
    live = []
    boundary = RuntimeError("synthetic source-witness early boundary")
    observation = {}
    def early_callback():
        call.tick()
        if not live:
            return
        carrier = live[0]
        values = carrier.get("catalogs", {}).get("priority", {}).get("F", [])
        if any(_same(row["value"], long_body) for row in values):
            call.need(_canonical(long_body) not in _known(carrier), "source subtree asserted as fact")
            call.need(carrier["catalogs"]["W"]["eof"] is False, "source waited for fallback EOF")
            observation.update({"witness": long_body, "known": copy.deepcopy(carrier["known"]),
                "W_eof": False, "carrier": copy.deepcopy(carrier)})
            raise boundary
    try:
        search.search_fpc(_query([long_source], Q, call), grammar=_grammar(),
            ordering="FIFO", modules=call.search_modules, check=early_callback, progress=live)
    except BaseException as error:
        if call.first_fault is not None:
            raise call.first_fault
        if error is not boundary:
            raise
    else:
        call.need(False, "did not observe long source witness before fallback EOF")
    call.need(bool(observation), "missing source boundary observation")
    record(CONTROL_IDS[42], observation)

    shared_query = _query([P, PQ, PR, QRS], S, call)
    shared = _run(search, shared_query, _grammar(), call)
    call.need(shared["status"] == "CANDIDATE_FOUND"
        and type(shared["candidate_certificate_bytes"]) is bytes, "shared dependency candidate missing")
    dual = _accept_pair(shared_query, shared["candidate_certificate_bytes"], modules, call)
    cert_rows = dual["subject"]["certificate"]["rows"]
    call.need({_canonical(row["formula"]) for row in cert_rows}
        == {_canonical(x) for x in [P, PQ, PR, QRS, Q, R, RS, S]}, "export omitted/added shared dependency")
    call.need(len(cert_rows) == 8 and _same(cert_rows[-1]["formula"], S), "export exact goal/DAG size")
    refs = [ref for row in cert_rows for ref in row["validation"]["references"]]
    p_index = next(row["index"] for row in cert_rows if _same(row["formula"], P))
    call.need(refs.count(p_index) == 2, "shared premise was not reused")
    for row in cert_rows:
        call.tick()
        call.need(all(type(ref) is int and ref < row["index"] for ref in row["validation"]["references"]), "export backward references")
    record(CONTROL_IDS[43], {"query_hex": shared_query.hex(), "certificate_hex": shared["candidate_certificate_bytes"].hex(),
        "receipt": shared["receipt"], "dual_validation": dual})

    late = _run(search, _query([P, PQ], S, call), _grammar(variables=1, derived=4), call)
    call.need(late["status"] == "EXHAUSTED_DECLARED_GRAMMAR", "late-GEN closure incomplete")
    late_known = _known(late["receipt"])
    call.need(_canonical(["all", 0, Q]) in late_known, "late-derived formula not generalized")
    q_id = late_known[_canonical(Q)]["id"]
    call.need(any(_same(row["key"], [q_id, 0]) and row["status"] in ("NEW_FORMULA", "DUPLICATE_FORMULA")
        for row in late["receipt"]["GEN"]), "late GEN event missing")
    record(CONTROL_IDS[44], late["receipt"])
    open_hyp = ["pred", 0, [["var", 0]]]
    gamma_query = _query([], ["all", 0, open_hyp], call, predicates=(1,), Gamma=[open_hyp], mode=1)
    gamma = _run(search, gamma_query, _grammar(variables=1, derived=4), call)
    call.need(gamma["status"] == "EXHAUSTED_DECLARED_GRAMMAR"
        and _canonical(["all", 0, open_hyp]) not in _known(gamma["receipt"]), "global Gamma leaked into GEN")
    call.need(any(row["status"] == "GLOBAL_GAMMA_REFUSAL" for row in gamma["receipt"]["GEN"]), "Gamma guard not observed")
    record(CONTROL_IDS[45], {"query_hex": gamma_query.hex(), "receipt": gamma["receipt"]})
    outside_var = _run(search, _query([["all", 2, P]], S, call), _grammar(variables=1), call)
    call.need(outside_var["status"] == "SOURCE_OUTSIDE_DECLARED_GRAMMAR"
        and outside_var["candidate_certificate_bytes"] is None, "out-of-variable source silently dropped")
    record(CONTROL_IDS[46], outside_var["receipt"])
    deep = ["eq", ["fun", 1, [["fun", 0, []]]], ["fun", 0, []]]
    outside_depth = _run(search, _query([deep], deep, call, functions=(0, 1)), _grammar(depth=0), call)
    call.need(outside_depth["status"] == "SOURCE_OUTSIDE_DECLARED_GRAMMAR"
        and outside_depth["candidate_certificate_bytes"] is None, "out-of-depth source silently dropped")
    record(CONTROL_IDS[47], outside_depth["receipt"])

    scored = _closure(search, [P, PQ], [P, PQ, Q], call, ordering="MATCH_SCORE")
    dequeues = scored["receipt"]["priority_dequeues"]
    for row in dequeues:
        call.tick()
        if row["visit"] % 4 == 0:
            call.need(row["oldest"] is True, "fourth priority service not oldest")
    for task in scored["receipt"]["tasks"]:
        call.tick()
        if task["conclusion_nodes"] is None:
            call.need(task["unknown_size_score"] == 4, "incomplete task hidden size estimate")
    record(CONTROL_IDS[48], {"receipt": scored["receipt"], "observed_dequeues": len(dequeues),
        "fourth_visits_observed": sum(1 for row in dequeues if row["visit"] % 4 == 0),
        "scope": "Only observed records; not a universal fairness proof."})
    interrupted = []
    count = [0]
    cutoff = RuntimeError("synthetic interrupted ordinary work")
    def later_callback():
        call.tick()
        count[0] += 1
        if count[0] == 16:
            raise cutoff
    try:
        search.search_fpc(_query([P, PQ], S, call), grammar=_grammar(), ordering="FIFO",
            modules=call.search_modules, check=later_callback, progress=interrupted)
    except BaseException as error:
        if call.first_fault is not None:
            raise call.first_fault
        if error is not cutoff:
            raise
    else:
        call.need(False, "cutoff became search return/exhaustion")
    call.need(len(interrupted) == 1, "cutoff live carrier absent")
    record(CONTROL_IDS[49], {"callback_ordinal": 16, "receipt": interrupted[0],
        "authority": "NONE_INTERRUPTED_DIAGNOSTIC_ONLY"})

    record(CONTROL_IDS[50], _fault(lambda cb: search.product_step(None, [1], [True], check=cb), ValueError("toy product foreign"), call))
    record(CONTROL_IDS[51], _fault(lambda cb: search.match_pattern({"meta": "A", "sort": "F"}, P, check=cb), StopIteration("toy matcher foreign"), call))
    toy_query = _query([P, PQ], S, call)
    record(CONTROL_IDS[52], _fault(lambda cb: search.search_fpc(toy_query, grammar=_grammar(), ordering="FIFO",
        modules=call.search_modules, check=cb, progress=[]), retained, call))
    # A later first fault checks that first-fault preservation is not entry-only.
    count2 = [0]
    late_fault = RuntimeError("toy later callback first fault")
    later_other = ValueError("must not replace toy later callback")
    def delayed():
        call.tick()
        count2[0] += 1
        if count2[0] == 8:
            raise late_fault
        if count2[0] > 8:
            raise later_other
    try:
        search.search_fpc(toy_query, grammar=_grammar(), ordering="FIFO",
            modules=call.search_modules, check=delayed, progress=[])
    except BaseException as error:
        if call.first_fault is not None:
            raise call.first_fault
        if error is not late_fault:
            raise
    else:
        call.need(False, "later foreign callback swallowed")
    call.need(count2[0] == 8, "later callback invoked after first fault")
    record(CONTROL_IDS[53], {"identity_preserved": True, "callback_ordinal": 8})
    validator_faults = {}
    validator_faults["subject"] = _fault(lambda cb: modules["checker"].check_certificate(shared_query,
        shared["candidate_certificate_bytes"], check=cb), ValueError("toy validator subject"), call)
    validator_faults["reference"] = _fault(lambda cb: modules["reference"].reference_check_certificate(shared_query,
        shared["candidate_certificate_bytes"], check=cb), StopIteration("toy validator reference"), call)
    record(CONTROL_IDS[54], validator_faults)
    record(CONTROL_IDS[55], _fault(lambda cb: builders.logical_axiom(0, [P, Q], check=cb),
        builders.InvalidWitness("public class foreign callback"), call))
