"""FPC-H1 finite-byte checker Source offer; never executed during authorship.

Only immutable bytes are public proof inputs. Internal ASTs are tuples and
literal built-in axiom tables are recursively immutable. Every returned AST and
map is a fresh ordinary list/dict copy; receipts cannot change subsequent calls.
This is a finite certificate checker, with no search, machine or palette code.
The public callback is called without arguments and all its faults propagate.
"""

import hashlib
import time

VERSION = "FPC-H1-BYTE-CHECKER-v1"
WIRE_VERSION = "FPC-H1-exact-binary-wire-contract-v1"
CALCULUS_VERSION = "FPC-H1"
_ERROR_IDENTITY = object()
_LOGICAL_NAMES = ("H1", "H2", "H3", "Q1", "Q2", "Q3", "E1", "E2")
_RULE_NAMES = ("HYP", "LOGICAL_AXIOM", "THEORY_AXIOM", "MP", "GEN")
_THEORY_NAMES = ("FINITE_TABLE", "PA_TABLE", "PA_INDUCTION", "INCIDENCE_TABLE")

_PA_AXIOMS = (
    ('all', 0, ('not', ('eq', ('fun', 1, (('var', 0),)), ('fun', 0, ())))),
    ('all', 0, ('all', 1, ('imp', ('eq', ('fun', 1, (('var', 0),)), ('fun', 1, (('var', 1),))), ('eq', ('var', 0), ('var', 1))))),
    ('all', 0, ('eq', ('fun', 2, (('var', 0), ('fun', 0, ()))), ('var', 0))),
    ('all', 0, ('all', 1, ('eq', ('fun', 2, (('var', 0), ('fun', 1, (('var', 1),)))), ('fun', 1, (('fun', 2, (('var', 0), ('var', 1))),))))),
    ('all', 0, ('eq', ('fun', 3, (('var', 0), ('fun', 0, ()))), ('fun', 0, ()))),
    ('all', 0, ('all', 1, ('eq', ('fun', 3, (('var', 0), ('fun', 1, (('var', 1),)))), ('fun', 2, (('fun', 3, (('var', 0), ('var', 1))), ('var', 0)))))),
)
_INCIDENCE_AXIOMS = (
    ('all', 5, ('not', ('imp', ('imp', ('not', ('pred', 0, (('var', 5),))), ('pred', 1, (('var', 5),))), ('not', ('not', ('not', ('imp', ('pred', 0, (('var', 5),)), ('not', ('pred', 1, (('var', 5),)))))))))),
    ('all', 0, ('all', 3, ('imp', ('pred', 2, (('var', 0), ('var', 3))), ('not', ('imp', ('pred', 0, (('var', 0),)), ('not', ('pred', 1, (('var', 3),)))))))),
    ('all', 0, ('all', 1, ('imp', ('not', ('imp', ('pred', 0, (('var', 0),)), ('not', ('not', ('imp', ('pred', 0, (('var', 1),)), ('not', ('not', ('eq', ('var', 0), ('var', 1))))))))), ('not', ('all', 3, ('not', ('not', ('imp', ('pred', 1, (('var', 3),)), ('not', ('not', ('imp', ('pred', 2, (('var', 0), ('var', 3))), ('not', ('pred', 2, (('var', 1), ('var', 3))))))))))))))),
    ('all', 0, ('all', 1, ('all', 3, ('all', 4, ('imp', ('not', ('imp', ('pred', 0, (('var', 0),)), ('not', ('not', ('imp', ('pred', 0, (('var', 1),)), ('not', ('not', ('imp', ('not', ('eq', ('var', 0), ('var', 1))), ('not', ('not', ('imp', ('pred', 1, (('var', 3),)), ('not', ('not', ('imp', ('pred', 1, (('var', 4),)), ('not', ('not', ('imp', ('pred', 2, (('var', 0), ('var', 3))), ('not', ('not', ('imp', ('pred', 2, (('var', 1), ('var', 3))), ('not', ('not', ('imp', ('pred', 2, (('var', 0), ('var', 4))), ('not', ('pred', 2, (('var', 1), ('var', 4))))))))))))))))))))))))))), ('eq', ('var', 3), ('var', 4))))))),
    ('all', 3, ('imp', ('pred', 1, (('var', 3),)), ('not', ('all', 0, ('not', ('not', ('all', 1, ('not', ('not', ('imp', ('pred', 0, (('var', 0),)), ('not', ('not', ('imp', ('pred', 0, (('var', 1),)), ('not', ('not', ('imp', ('not', ('eq', ('var', 0), ('var', 1))), ('not', ('not', ('imp', ('pred', 2, (('var', 0), ('var', 3))), ('not', ('pred', 2, (('var', 1), ('var', 3))))))))))))))))))))))),
    ('not', ('all', 0, ('not', ('not', ('all', 1, ('not', ('not', ('all', 2, ('not', ('not', ('imp', ('pred', 0, (('var', 0),)), ('not', ('not', ('imp', ('pred', 0, (('var', 1),)), ('not', ('not', ('imp', ('pred', 0, (('var', 2),)), ('not', ('not', ('imp', ('not', ('eq', ('var', 0), ('var', 1))), ('not', ('not', ('imp', ('not', ('eq', ('var', 0), ('var', 2))), ('not', ('not', ('imp', ('not', ('eq', ('var', 1), ('var', 2))), ('not', ('not', ('not', ('all', 3, ('not', ('not', ('imp', ('pred', 1, (('var', 3),)), ('not', ('not', ('imp', ('pred', 2, (('var', 0), ('var', 3))), ('not', ('not', ('imp', ('pred', 2, (('var', 1), ('var', 3))), ('not', ('pred', 2, (('var', 2), ('var', 3))))))))))))))))))))))))))))))))))))))))))),
)

class InvalidWitness(ValueError):
    """Public refusal class. Class membership alone never establishes ownership."""


def is_owned_error(error):
    """Decoder refusal identity only; not proof authority or a callback filter."""
    return isinstance(error, InvalidWitness) and getattr(error, "_fpc_identity", None) is _ERROR_IDENTITY


class _Context:
    def __init__(self, check):
        self.check = check
        self.owner = object()
        self.first_fault = None
        self.callbacks = 0
        self.began = time.monotonic()

    def tick(self):
        if self.first_fault is not None:
            raise self.first_fault
        self.callbacks += 1
        try:
            self.check()
        except BaseException as error:
            self.first_fault = error
            raise


def _refuse(ctx, status, message, component, offset, row=None):
    # No callback between a completed refusal and its owner annotation.
    error = InvalidWitness(message)
    error._fpc_identity = _ERROR_IDENTITY
    error._fpc_owner = ctx.owner
    error.detail = {"status": status, "message": message, "component": component,
                    "offset": offset, "row": row}
    raise error


def _malformed(ctx, message, component, offset):
    _refuse(ctx, "MALFORMED_INPUT", message, component, offset)


def _copy_out(value, ctx):
    """Explicit postorder copy; no returned mutable node aliases internal data."""
    pending = [("read", value)]
    values = []
    while pending:
        ctx.tick()
        kind, node = pending.pop()
        if kind == "dict":
            keys = node
            count = len(keys)
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            result = {}
            for key, child in zip(keys, children):
                ctx.tick()
                result[key] = child
            values.append(result)
        elif kind == "list":
            count = node
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            values.append(children)
        elif type(node) is dict:
            keys = tuple(node)
            pending.append(("dict", keys))
            for key in reversed(keys):
                ctx.tick()
                pending.append(("read", node[key]))
        elif type(node) in (tuple, list):
            pending.append(("list", len(node)))
            for child in reversed(node):
                ctx.tick()
                pending.append(("read", child))
        else:
            # Internal scalars are immutable str/int/bool/None/float/bytes.
            values.append(node)
    return values[0]


def _equal(left, right, ctx):
    pending = [(left, right)]
    while pending:
        ctx.tick()
        a, b = pending.pop()
        if type(a) in (tuple, list) and type(b) in (tuple, list):
            if len(a) != len(b):
                return False
            for i in range(len(a) - 1, -1, -1):
                ctx.tick()
                pending.append((a[i], b[i]))
        elif type(a) is not type(b) or a != b:
            return False
    return True


def _identity(data, ctx):
    digest = hashlib.sha256()
    for start in range(0, len(data), 65536):
        ctx.tick()
        digest.update(data[start:start + 65536])
    return {"bytes": len(data), "sha256": digest.hexdigest()}


class _Reader:
    def __init__(self, data, component, ctx):
        ctx.tick()
        if type(data) is not bytes:
            _malformed(ctx, "immutable bytes required", component, 0)
        self.data = data
        self.component = component
        self.ctx = ctx
        self.pos = 0
        self.functions = ()
        self.predicates = ()

    def raw(self, count):
        self.ctx.tick()
        if count > len(self.data) - self.pos:
            _malformed(self.ctx, "truncated field", self.component, self.pos)
        start = self.pos
        self.pos += count
        return self.data[start:self.pos]

    def magic(self, value):
        start = self.pos
        if self.raw(len(value)) != value:
            _malformed(self.ctx, "wrong magic or trailer", self.component, start)

    def nat(self):
        start = self.pos
        value = 0
        shift = 0
        while True:
            self.ctx.tick()
            if self.pos == len(self.data):
                _malformed(self.ctx, "unterminated natural", self.component, start)
            octet = self.data[self.pos]
            self.pos += 1
            digit = octet & 127
            value |= digit << shift
            if not octet & 128:
                if self.pos - start > 1 and digit == 0:
                    _malformed(self.ctx, "overlong natural", self.component, start)
                return value
            shift += 7

    def count(self):
        start = self.pos
        value = self.nat()
        if value > len(self.data) - self.pos:
            _malformed(self.ctx, "count exceeds remaining octets", self.component, start)
        return value

    def eof(self):
        self.ctx.tick()
        if self.pos != len(self.data):
            _malformed(self.ctx, "trailing bytes", self.component, self.pos)


def _ast(reader, kind):
    """Typed prefix parser, explicit stack, preorder parent-index source map."""
    ctx = reader.ctx
    pending = [("read", kind, None, None)]
    values = []
    nodes = []
    start = reader.pos
    while pending:
        ctx.tick()
        item = pending.pop()
        if item[0] == "finish":
            _, tag, metadata, count, index = item
            children = tuple(values[-count:]) if count else ()
            if count:
                del values[-count:]
            if tag in ("fun", "pred"):
                result = (tag, metadata, children)
            elif tag == "all":
                result = (tag, metadata, children[0])
            else:
                result = (tag,) + children
            values.append(result)
            nodes[index]["span"][1] = reader.pos
            continue
        _, sort, parent, slot = item
        begin = reader.pos
        code = reader.nat()
        index = len(nodes)
        node_map = {"kind": sort, "parent": parent, "slot": slot,
                    "span": [begin, None], "tag": code}
        nodes.append(node_map)
        metadata = None
        if sort == "term":
            if code == 0:
                values.append(("var", reader.nat()))
                node_map["span"][1] = reader.pos
                continue
            if code != 1:
                _malformed(ctx, "unknown term tag", reader.component, begin)
            tag = "fun"
            metadata = reader.nat()
            count = reader.count()
            if metadata >= len(reader.functions) or count != reader.functions[metadata]:
                _malformed(ctx, "function ID or arity", reader.component, begin)
            child_sort = "term"
        elif code == 0:
            tag = "pred"
            metadata = reader.nat()
            count = reader.count()
            if metadata >= len(reader.predicates) or count != reader.predicates[metadata]:
                _malformed(ctx, "predicate ID or arity", reader.component, begin)
            child_sort = "term"
        elif code == 1:
            tag, count, child_sort = "eq", 2, "term"
        elif code == 2:
            tag, count, child_sort = "not", 1, "formula"
        elif code == 3:
            tag, count, child_sort = "imp", 2, "formula"
        elif code == 4:
            tag, count, child_sort = "all", 1, "formula"
            metadata = reader.nat()
        else:
            _malformed(ctx, "unknown formula tag", reader.component, begin)
        pending.append(("finish", tag, metadata, count, index))
        for child in range(count - 1, -1, -1):
            ctx.tick()
            pending.append(("read", child_sort, index, child))
    return values[0], {"kind": kind, "span": [start, reader.pos], "nodes": nodes}


def _nat_field(reader, name):
    start = reader.pos
    value = reader.nat()
    return value, {"name": name, "kind": "natural", "span": [start, reader.pos]}


def _nat_vector(reader, name):
    start = reader.pos
    count = reader.count()
    result = []
    fields = []
    for _ in range(count):
        reader.ctx.tick()
        value, field = _nat_field(reader, "element")
        result.append(value)
        fields.append(field)
    return tuple(result), {"name": name, "kind": "natural_vector",
                           "span": [start, reader.pos], "elements": fields}


def _formula_vector(reader, name):
    start = reader.pos
    count = reader.count()
    result = []
    fields = []
    for _ in range(count):
        reader.ctx.tick()
        value, field = _ast(reader, "formula")
        result.append(value)
        fields.append(field)
    return tuple(result), {"name": name, "kind": "formula_vector",
                           "span": [start, reader.pos], "elements": fields}


def _fv_term(term, ctx):
    result = set()
    pending = [term]
    while pending:
        ctx.tick()
        node = pending.pop()
        if node[0] == "var":
            result.add(node[1])
        else:
            for child in reversed(node[2]):
                ctx.tick()
                pending.append(child)
    return result


def _fv_formula(formula, ctx):
    result = set()
    pending = [(formula, frozenset())]
    while pending:
        ctx.tick()
        node, bound = pending.pop()
        tag = node[0]
        if tag == "all":
            pending.append((node[2], bound | {node[1]}))
        elif tag == "not":
            pending.append((node[1], bound))
        elif tag == "imp":
            pending.append((node[2], bound))
            pending.append((node[1], bound))
        else:
            terms = node[2] if tag == "pred" else node[1:3]
            for term in terms:
                ctx.tick()
                result.update(_fv_term(term, ctx) - bound)
    return result


def _free_for(term, variable, formula, ctx):
    inserted = _fv_term(term, ctx)
    pending = [(formula, frozenset())]
    while pending:
        ctx.tick()
        node, bound = pending.pop()
        tag = node[0]
        if tag == "all":
            if node[1] != variable:
                pending.append((node[2], bound | {node[1]}))
        elif tag == "not":
            pending.append((node[1], bound))
        elif tag == "imp":
            pending.append((node[2], bound))
            pending.append((node[1], bound))
        else:
            terms = node[2] if tag == "pred" else node[1:3]
            for source in terms:
                ctx.tick()
                if variable in _fv_term(source, ctx) and bound & inserted:
                    return False
    return True


def _substitute(term, variable, formula, ctx):
    """Caller already checked free-for; finite tuples, no inserted traversal."""
    pending = [("formula", formula)]
    values = []
    while pending:
        ctx.tick()
        kind, node = pending.pop()
        if kind == "rebuild":
            tag, metadata, count = node
            children = tuple(values[-count:]) if count else ()
            if count:
                del values[-count:]
            if tag in ("fun", "pred"):
                values.append((tag, metadata, children))
            elif tag == "all":
                values.append((tag, metadata, children[0]))
            else:
                values.append((tag,) + children)
            continue
        tag = node[0]
        if kind == "term":
            if tag == "var":
                values.append(term if node[1] == variable else node)
                continue
            children = node[2]
            child_kind = "term"
        elif tag == "all" and node[1] == variable:
            values.append(node)
            continue
        elif tag in ("pred", "eq"):
            children = node[2] if tag == "pred" else node[1:3]
            child_kind = "term"
        else:
            children = (node[2],) if tag == "all" else node[1:]
            child_kind = "formula"
        metadata = node[1] if tag in ("fun", "pred", "all") else None
        pending.append(("rebuild", (tag, metadata, len(children))))
        for child in reversed(children):
            ctx.tick()
            pending.append((child_kind, child))
    return values[0]


def _parse_query(data, ctx):
    reader = _Reader(data, "query", ctx)
    reader.magic(b"FPC1")
    fields = []
    version, field = _nat_field(reader, "version")
    fields.append(field)
    if version != 1:
        _malformed(ctx, "query version", "query", field["span"][0])
    mode, field = _nat_field(reader, "claim_mode")
    fields.append(field)
    if mode not in (0, 1):
        _malformed(ctx, "query claim mode", "query", field["span"][0])
    functions, field = _nat_vector(reader, "function_arities")
    fields.append(field)
    predicates, field = _nat_vector(reader, "predicate_arities")
    fields.append(field)
    profile, field = _nat_field(reader, "theory_profile")
    fields.append(field)
    if profile not in (0, 1, 2):
        _malformed(ctx, "query profile", "query", field["span"][0])
    if profile == 1 and (functions != (0, 1, 2, 2) or predicates != ()):
        _malformed(ctx, "PA signature mismatch", "query", reader.pos)
    if profile == 2 and (functions != () or predicates != (1, 1, 2)):
        _malformed(ctx, "incidence signature mismatch", "query", reader.pos)
    reader.functions, reader.predicates = functions, predicates
    if profile == 0:
        axioms, field = _formula_vector(reader, "finite_axioms")
        axiom_fields = field["elements"]
        fields.append(field)
    else:
        axioms = ()
        fields.append({"name": "profile_payload", "span": [reader.pos, reader.pos], "kind": "empty"})
    gamma, field = _formula_vector(reader, "Gamma")
    fields.append(field)
    goal, field = _ast(reader, "formula")
    field["name"] = "goal"
    fields.append(field)
    reader.eof()
    for index, axiom in enumerate(axioms):
        ctx.tick()
        if _fv_formula(axiom, ctx):
            _malformed(ctx, "finite theory axiom is open", "query", axiom_fields[index]["span"][0])
    if mode == 0 and (gamma or _fv_formula(goal, ctx)):
        _malformed(ctx, "theorem mode requires empty Gamma and closed goal", "query", fields[1]["span"][0])
    return {"version": version, "claim_mode": mode, "function_arities": functions,
            "predicate_arities": predicates, "theory_profile": profile,
            "finite_axioms": axioms, "Gamma": gamma, "goal": goal,
            "source_fields": fields, "EOF": reader.pos}


def _parse_certificate(data, query, ctx):
    reader = _Reader(data, "certificate", ctx)
    reader.functions = query["function_arities"]
    reader.predicates = query["predicate_arities"]
    reader.magic(b"FPP1")
    count = reader.count()
    if count == 0:
        _malformed(ctx, "empty certificate", "certificate", 4)
    rows = []
    for ordinal in range(count):
        ctx.tick()
        start = reader.pos
        formula, formula_map = _ast(reader, "formula")
        tag, rule_map = _nat_field(reader, "rule_tag")
        if tag > 4:
            _malformed(ctx, "unknown rule tag", "certificate", rule_map["span"][0])
        fields = []
        witness = []
        subtag = None
        if tag == 0:
            kinds = (("hypothesis_index", "natural"),)
        elif tag == 1:
            subtag, field = _nat_field(reader, "logical_tag")
            fields.append(field)
            if subtag > 7:
                _malformed(ctx, "unknown logical tag", "certificate", field["span"][0])
            kinds = (
                (("A", "formula"), ("B", "formula")),
                (("A", "formula"), ("B", "formula"), ("C", "formula")),
                (("A", "formula"), ("B", "formula")),
                (("A", "formula"), ("x", "natural"), ("t", "term")),
                (("A", "formula"), ("B", "formula"), ("x", "natural")),
                (("A", "formula"), ("x", "natural")),
                (("t", "term"),),
                (("A", "formula"), ("x", "natural"), ("s", "term"), ("t", "term")),
            )[subtag]
        elif tag == 2:
            subtag, field = _nat_field(reader, "theory_witness_tag")
            fields.append(field)
            if subtag > 3:
                _malformed(ctx, "unknown theory witness tag", "certificate", field["span"][0])
            kinds = (("A", "formula"), ("x", "natural"), ("parameters", "natural_vector")) if subtag == 2 else (("table_index", "natural"),)
        elif tag == 3:
            kinds = (("antecedent_row", "natural"), ("implication_row", "natural"))
        else:
            kinds = (("source_row", "natural"), ("variable_id", "natural"))
        for name, kind in kinds:
            ctx.tick()
            if kind == "natural":
                value, field = _nat_field(reader, name)
            elif kind == "natural_vector":
                value, field = _nat_vector(reader, name)
            else:
                value, field = _ast(reader, kind)
                field["name"] = name
            witness.append(value)
            fields.append(field)
        rows.append({"index": ordinal, "formula": formula, "rule_tag": tag,
                     "rule": _RULE_NAMES[tag], "subtag": subtag,
                     "witness": tuple(witness), "span": [start, reader.pos],
                     "formula_source": formula_map, "rule_source": rule_map,
                     "witness_source": fields, "validation": {"status": "NOT_CHECKED"}})
    reader.eof()
    return {"row_count": count, "rows": rows, "EOF": reader.pos}


def _parse_envelope(data, ctx):
    reader = _Reader(data, "envelope", ctx)
    reader.magic(b"FPI1")
    length_start = reader.pos
    size = reader.nat()
    query_start = reader.pos
    query_bytes = reader.raw(size)
    query_end = reader.pos
    certificate_length_start = reader.pos
    size = reader.nat()
    certificate_start = reader.pos
    certificate_bytes = reader.raw(size)
    certificate_end = reader.pos
    reader.magic(b"END1")
    reader.eof()
    return query_bytes, certificate_bytes, {
        "query_length_span": [length_start, query_start],
        "query_span": [query_start, query_end],
        "certificate_length_span": [certificate_length_start, certificate_start],
        "certificate_span": [certificate_start, certificate_end],
        "trailer_span": [certificate_end, certificate_end + 4], "EOF": reader.pos}


def _require(condition, name, row, ctx, detail=None):
    entry = {"name": name, "passed": bool(condition)}
    if detail is not None:
        entry["detail"] = detail
    row["validation"]["side_conditions"].append(entry)
    if not condition:
        row["validation"]["status"] = "INVALID"
        _refuse(ctx, "INVALID_CERTIFICATE", name, "certificate", row["span"][0], row["index"])


def _logical(row, ctx):
    tag = row["subtag"]
    w = row["witness"]
    row["validation"]["witness_name"] = _LOGICAL_NAMES[tag]
    if tag == 0:
        a, b = w
        return ("imp", a, ("imp", b, a))
    if tag == 1:
        a, b, c = w
        return ("imp", ("imp", a, ("imp", b, c)), ("imp", ("imp", a, b), ("imp", a, c)))
    if tag == 2:
        a, b = w
        return ("imp", ("imp", ("not", b), ("not", a)), ("imp", a, b))
    if tag == 3:
        a, x, t = w
        _require(_free_for(t, x, a, ctx), "Q1 free-for", row, ctx)
        return ("imp", ("all", x, a), _substitute(t, x, a, ctx))
    if tag == 4:
        a, b, x = w
        return ("imp", ("all", x, ("imp", a, b)), ("imp", ("all", x, a), ("all", x, b)))
    if tag == 5:
        a, x = w
        _require(x not in _fv_formula(a, ctx), "Q3 free variable absent", row, ctx)
        return ("imp", a, ("all", x, a))
    if tag == 6:
        (t,) = w
        return ("eq", t, t)
    a, x, s, t = w
    left_ok = _free_for(s, x, a, ctx)
    right_ok = _free_for(t, x, a, ctx)
    _require(left_ok and right_ok, "E2 both free-for", row, ctx,
             {"left_free_for": left_ok, "right_free_for": right_ok})
    return ("imp", ("eq", s, t), ("imp", _substitute(s, x, a, ctx), _substitute(t, x, a, ctx)))


def _theory(row, query, ctx):
    tag = row["subtag"]
    w = row["witness"]
    row["validation"]["witness_name"] = _THEORY_NAMES[tag]
    _require(query["theory_profile"] == (0, 1, 1, 2)[tag], "theory witness profile", row, ctx)
    if tag != 2:
        table = query["finite_axioms"] if tag == 0 else (_PA_AXIOMS if tag == 1 else _INCIDENCE_AXIOMS)
        index = w[0]
        _require(index < len(table), "theory table index", row, ctx)
        return table[index]
    a, x, parameters = w
    expected_parameters = tuple(sorted(_fv_formula(a, ctx) - {x}))
    _require(_equal(parameters, expected_parameters, ctx), "induction parameters", row, ctx,
             {"computed_parameters": expected_parameters})
    zero = ("fun", 0, ())
    successor_term = ("fun", 1, (("var", x),))
    _require(_free_for(zero, x, a, ctx) and _free_for(successor_term, x, a, ctx),
             "induction computed substitutions free-for", row, ctx)
    base = _substitute(zero, x, a, ctx)
    successor = _substitute(successor_term, x, a, ctx)
    step = ("all", x, ("imp", a, successor))
    result = ("imp", ("not", ("imp", base, ("not", step))), ("all", x, a))
    for parameter in reversed(parameters):
        ctx.tick()
        result = ("all", parameter, result)
    _require(not _fv_formula(result, ctx), "induction whole sentence closed", row, ctx)
    return result


def _validate(query, certificate, ctx):
    gamma_free = set()
    for hypothesis in query["Gamma"]:
        ctx.tick()
        gamma_free.update(_fv_formula(hypothesis, ctx))
    rows = certificate["rows"]
    for row in rows:
        ctx.tick()
        validation = {"status": "CHECKING", "side_conditions": [], "references": []}
        row["validation"] = validation
        tag, w, index = row["rule_tag"], row["witness"], row["index"]
        if tag == 0:
            _require(w[0] < len(query["Gamma"]), "hypothesis index", row, ctx)
            expected = query["Gamma"][w[0]]
        elif tag == 1:
            expected = _logical(row, ctx)
        elif tag == 2:
            expected = _theory(row, query, ctx)
        elif tag == 3:
            antecedent, implication = w
            validation["references"] = [antecedent, implication]
            _require(antecedent < index and implication < index, "MP strictly earlier references", row, ctx)
            _require(_equal(rows[implication]["formula"], ("imp", rows[antecedent]["formula"], row["formula"]), ctx),
                     "MP exact ordered operands", row, ctx)
            expected = row["formula"]
        else:
            source, variable = w
            validation["references"] = [source]
            _require(source < index, "GEN strictly earlier reference", row, ctx)
            _require(variable not in gamma_free, "GEN variable absent from every hypothesis", row, ctx,
                     {"Gamma_free_variables": tuple(sorted(gamma_free))})
            expected = ("all", variable, rows[source]["formula"])
        _require(_equal(row["formula"], expected, ctx), "exact whole row formula", row, ctx)
        validation["status"] = "VALID"
    if not _equal(rows[-1]["formula"], query["goal"], ctx):
        _refuse(ctx, "INVALID_CERTIFICATE", "last formula is not exact goal", "certificate",
                rows[-1]["span"][0], rows[-1]["index"])


def _checked(query_bytes, certificate_bytes, envelope_bytes, check, *, envelope=False):
    ctx = _Context(check)
    ctx.tick()
    state = {"schema": "FPC-H1-finite-byte-check-receipt-v1", "version": VERSION,
             "calculus": CALCULUS_VERSION, "wire": WIRE_VERSION,
             "complete": False, "accepted": False, "syntax_complete": False,
             "derivation_complete": False, "no_prefix_authority": True,
             "query": None, "certificate": None, "envelope": None,
             "raw_inputs": {}, "final_goal_equal": False}
    try:
        if envelope:
            if type(envelope_bytes) is bytes:
                state["raw_inputs"]["envelope"] = _identity(envelope_bytes, ctx)
            query_bytes, certificate_bytes, envelope_map = _parse_envelope(envelope_bytes, ctx)
            state["envelope"] = envelope_map
        if type(query_bytes) is bytes:
            state["raw_inputs"]["query"] = _identity(query_bytes, ctx)
        if type(certificate_bytes) is bytes:
            state["raw_inputs"]["certificate"] = _identity(certificate_bytes, ctx)
        query = _parse_query(query_bytes, ctx)
        state["query"] = query
        certificate = _parse_certificate(certificate_bytes, query, ctx)
        state["certificate"] = certificate
        state["syntax_complete"] = True
        _validate(query, certificate, ctx)
        state["status"] = "VALID_DERIVATION"
        state["accepted"] = True
        state["derivation_complete"] = True
        state["final_goal_equal"] = True
        state["claim"] = "CLOSED_THEOREM_RELATIVE_TO_THEORY" if query["claim_mode"] == 0 else "CONSEQUENCE_RELATIVE_TO_THEORY_AND_GAMMA"
    except BaseException as error:
        # The exact first callback fault wins even if it has our public class,
        # a forged owned marker, or a class also used by a parser refusal.
        if ctx.first_fault is not None:
            raise ctx.first_fault
        if not is_owned_error(error) or getattr(error, "_fpc_owner", None) is not ctx.owner:
            raise
        state["status"] = error.detail["status"]
        state["failure"] = error.detail
        error.__traceback__ = None
    state["complete"] = True
    result = _copy_out(state, ctx)
    # Copying and this final callback are inside the successful checking window.
    # A fault here prevents any receipt from returning, even after logical work.
    ctx.tick()
    result["cost"] = {"callbacks": ctx.callbacks, "elapsed_seconds": time.monotonic() - ctx.began,
                      "scope": "entry through final checked receipt copy; caller serialization/output excluded"}
    return result


def check_certificate(query_bytes, certificate_bytes, *, check):
    """Return a complete positive/negative receipt, or propagate a genuine fault."""
    return _checked(query_bytes, certificate_bytes, None, check)


def check_envelope(envelope_bytes, *, check):
    """Strict FPI1/END1 wrapper; same exact query/certificate relation."""
    return _checked(None, None, envelope_bytes, check, envelope=True)


def decode_query(query_bytes, *, check):
    """Parse-only copy; refusal raises owned InvalidWitness, never a proof receipt."""
    ctx = _Context(check)
    query = _parse_query(query_bytes, ctx)
    result = _copy_out(query, ctx)
    ctx.tick()
    return result


def decode_certificate(certificate_bytes, query_bytes, *, check):
    """Reparse immutable query bytes; never trust a caller-supplied decoded AST."""
    ctx = _Context(check)
    query = _parse_query(query_bytes, ctx)
    result = _copy_out(_parse_certificate(certificate_bytes, query, ctx), ctx)
    ctx.tick()
    return result


def decode_envelope(envelope_bytes, *, check):
    """Envelope syntax only; returned byte slices stay immutable, no proof check."""
    ctx = _Context(check)
    query_bytes, certificate_bytes, spans = _parse_envelope(envelope_bytes, ctx)
    result = {"query_bytes": query_bytes, "certificate_bytes": certificate_bytes,
              "source": _copy_out(spans, ctx), "proof_checked": False}
    ctx.tick()
    return result
