"""Ordinary symbolic FPC-H1 producer; Source-only, never imported at authorship.

No target IDs, proof templates, histories, learning, geometry or admission.
Exact dependencies and caller immutability are part of the separate API.
"""
from collections import deque
import hashlib
import heapq

VERSION = "FPC-H1-UNIFORM-SEARCH-v1"
GRAMMAR_SCHEMA = "FPC-H1-finite-producer-grammar-v1"
_OWNER = object()


class InvalidSearchInput(ValueError):
    """Owned completed intake failure only; callback identity is never normalized."""


def is_owned_error(error):
    return getattr(error, "_search_owner", None) is _OWNER


class _Call:
    def __init__(self, check):
        self.check = check
        self.fault = None
        self.callbacks = 0

    def tick(self):
        if self.fault is not None:
            raise self.fault
        try:
            self.check()
        except BaseException as error:
            self.fault = error
            raise
        self.callbacks += 1

    def require(self, condition, message):
        self.tick()
        if not condition:
            error = InvalidSearchInput(message)
            error._search_owner = _OWNER
            raise error

    def helper(self, function, *args, refusal=None):
        self.tick()
        try:
            value = function(*args, check=self.tick)
        except BaseException as error:
            if self.fault is not None:
                raise self.fault
            # Validated immutable arguments + exact pinned original helper code
            # are required. Public class membership alone is not ownership.
            if refusal is not None and type(error) is refusal:
                return False, str(error)
            raise
        if self.fault is not None:
            raise self.fault
        self.tick()
        return True, value

    def advance(self, generator):
        self.tick()
        try:
            next(generator)
        except BaseException as error:
            if self.fault is not None:
                raise self.fault
            if isinstance(error, StopIteration):
                return False
            raise
        return True


def _freeze(value, call):
    """Iterative list/tuple to immutable tuple; no shared mutable input retained."""
    stack = [(False, value)]
    values = []
    while stack:
        call.tick()
        rebuild, node = stack.pop()
        if rebuild:
            count = node
            children = tuple(values[-count:]) if count else ()
            if count:
                del values[-count:]
            values.append(children)
        elif type(node) in (list, tuple):
            stack.append((True, len(node)))
            for child in reversed(node):
                call.tick()
                stack.append((False, child))
        else:
            call.require(type(node) in (str, int), "AST scalar")
            values.append(node)
    return values[0]


def _walk(formula, call):
    stack = [("F", formula, ())]
    while stack:
        call.tick()
        sort, node, path = stack.pop()
        yield sort, node, path
        tag = node[0]
        if tag in ("fun", "pred"):
            for index in range(len(node[2]) - 1, -1, -1):
                call.tick()
                stack.append(("T", node[2][index], path + (2, index)))
        elif tag == "eq":
            stack.append(("T", node[2], path + (2,)))
            stack.append(("T", node[1], path + (1,)))
        elif tag == "not":
            stack.append(("F", node[1], path + (1,)))
        elif tag == "imp":
            stack.append(("F", node[2], path + (2,)))
            stack.append(("F", node[1], path + (1,)))
        elif tag == "all":
            stack.append(("F", node[2], path + (2,)))


def _info(node, sort, functions, predicates, call):
    count, depth, variables = 0, 0, set()
    stack = [(sort, node, 0)]
    while stack:
        call.tick()
        kind, value, term_depth = stack.pop()
        call.require(type(value) in (list, tuple) and bool(value), "AST node")
        tag = value[0]
        count += 1
        if kind == "T":
            call.require(tag in ("var", "fun"), "term tag")
            if tag == "var":
                call.require(len(value) == 2 and type(value[1]) is int and value[1] >= 0, "variable")
                variables.add(value[1])
                depth = max(depth, term_depth)
            else:
                call.require(len(value) == 3 and type(value[1]) is int and 0 <= value[1] < len(functions), "function")
                call.require(type(value[2]) in (list, tuple) and len(value[2]) == functions[value[1]], "function arity")
                depth = max(depth, term_depth)
                for child in reversed(value[2]):
                    call.tick()
                    stack.append(("T", child, term_depth + 1))
        else:
            call.require(tag in ("pred", "eq", "not", "imp", "all"), "formula tag")
            if tag == "pred":
                call.require(len(value) == 3 and type(value[1]) is int and 0 <= value[1] < len(predicates), "predicate")
                call.require(type(value[2]) in (list, tuple) and len(value[2]) == predicates[value[1]], "predicate arity")
                for child in reversed(value[2]):
                    call.tick()
                    stack.append(("T", child, 0))
            elif tag == "eq":
                call.require(len(value) == 3, "equality shape")
                stack.extend((("T", value[2], 0), ("T", value[1], 0)))
            elif tag == "not":
                call.require(len(value) == 2, "negation shape")
                stack.append(("F", value[1], 0))
            elif tag == "imp":
                call.require(len(value) == 3, "implication shape")
                stack.extend((("F", value[2], 0), ("F", value[1], 0)))
            else:
                call.require(len(value) == 3 and type(value[1]) is int and value[1] >= 0, "binder")
                variables.add(value[1])
                stack.append(("F", value[2], 0))
    return {"nodes": count, "term_depth": depth, "variables": tuple(sorted(variables))}


def _next_composition(indices, diagonal, call):
    result = list(indices)
    for position in range(len(result) - 2, -1, -1):
        call.tick()
        tail = 0
        for number in result[position + 1:]:
            call.tick()
            tail += number
        if tail:
            result[position] += 1
            for index in range(position + 1, len(result) - 1):
                call.tick()
                result[index] = 0
            prefix = 0
            for number in result[:-1]:
                call.tick()
                prefix += number
            result[-1] = diagonal - prefix
            return result
    return None


def _product_step(state, lengths, closed, call):
    call.require(type(lengths) is list and type(closed) is list and len(lengths) == len(closed), "product dimensions")
    for length, done in zip(lengths, closed):
        call.require(type(length) is int and length >= 0 and type(done) is bool, "product catalog")
    if state is None:
        state = {"diagonal": 0, "indices": [0] * len(lengths), "eof": False, "emitted": 0}
    else:
        call.require(type(state) is dict and set(state) == {"diagonal", "indices", "eof", "emitted"}, "product state keys")
        call.require(type(state["diagonal"]) is int and state["diagonal"] >= 0 and type(state["emitted"]) is int and state["emitted"] >= 0 and type(state["eof"]) is bool, "product state types")
        call.require(type(state["indices"]) is list and len(state["indices"]) == len(lengths), "product indices")
        total = 0
        for index in state["indices"]:
            call.require(type(index) is int and index >= 0, "product index")
            total += index
        call.require(not lengths or total == state["diagonal"], "product diagonal")
        state = dict(state, indices=list(state["indices"]))
    if state["eof"]:
        return {"kind": "EOF", "state": state, "indices": None, "requests": []}
    empty = False
    all_closed, maximum = True, 0
    for length, done in zip(lengths, closed):
        call.tick()
        empty = empty or (done and length == 0)
        all_closed = all_closed and done
        maximum += max(0, length - 1)
    if empty or (all_closed and state["diagonal"] > maximum) or (not lengths and state["emitted"]):
        state["eof"] = True
        return {"kind": "EOF", "state": state, "indices": None, "requests": []}
    requests = []
    outside = False
    for slot, (index, length, done) in enumerate(zip(state["indices"], lengths, closed)):
        call.tick()
        if index >= length:
            if done:
                outside = True
            else:
                requests.append({"slot": slot, "index": index})
    if requests and not outside:
        return {"kind": "WAIT", "state": state, "indices": None, "requests": requests}
    indices = list(state["indices"])
    following = _next_composition(indices, state["diagonal"], call)
    if following is None:
        state["diagonal"] += 1
        state["indices"] = [0] * len(lengths)
        if lengths:
            state["indices"][-1] = state["diagonal"]
    else:
        state["indices"] = following
    if outside:
        return {"kind": "SKIP_OUTSIDE", "state": state, "indices": indices, "requests": []}
    state["emitted"] += 1
    return {"kind": "TUPLE", "state": state, "indices": indices, "requests": []}


def product_step(state, lengths, closed, *, check):
    """Pure one-position diagonal step; WAIT never advances its current tuple."""
    return _product_step(state, lengths, closed, _Call(check))


def _meta(pattern):
    return type(pattern) is dict and set(pattern) == {"meta", "sort"}


def _match(pattern, value, bindings, call):
    result = dict(bindings or {})
    pending = [(pattern, value)]
    rigid = 0
    while pending:
        call.tick()
        left, right = pending.pop()
        if _meta(left):
            name, sort = left["meta"], left["sort"]
            call.require(type(name) is str and bool(name) and sort in ("F", "T", "V"), "pattern meta")
            valid = (type(right) is int and right >= 0) if sort == "V" else (type(right) in (list, tuple) and bool(right) and right[0] in (("var", "fun") if sort == "T" else ("pred", "eq", "not", "imp", "all")))
            if not valid:
                return {"matched": False, "bindings": result, "rigid_nodes": rigid}
            frozen = right if type(right) is int else _freeze(right, call)
            # Values are concrete core syntax: no metas can occur in a value.
            if name in result and result[name] != frozen:
                return {"matched": False, "bindings": result, "rigid_nodes": rigid}
            result[name] = frozen
        elif type(left) in (list, tuple):
            if type(right) not in (list, tuple) or len(left) != len(right):
                return {"matched": False, "bindings": result, "rigid_nodes": rigid}
            for index in range(len(left) - 1, -1, -1):
                call.tick()
                pending.append((left[index], right[index]))
        else:
            rigid += 1
            if type(left) is not type(right) or left != right:
                return {"matched": False, "bindings": result, "rigid_nodes": rigid}
    return {"matched": True, "bindings": result, "rigid_nodes": rigid}


def match_pattern(pattern, value, bindings=None, *, check):
    """Concrete typed pattern matching, not higher-order/inverse substitution."""
    call = _Call(check)
    call.require(bindings is None or type(bindings) is dict, "binding carrier")
    clean = {}
    for key, item in (bindings or {}).items():
        call.require(type(key) is str, "binding name")
        clean[key] = item if type(item) is int else _freeze(item, call)
    return _match(pattern, value, clean, call)


def _compositions(total, count, call):
    if count == 0:
        if total == 0:
            yield ()
        return
    if total < count:
        return
    state = [1] * count
    state[-1] += total - count
    while True:
        call.tick()
        yield tuple(state)
        next_value = _next_composition([x - 1 for x in state], total - count, call)
        if next_value is None:
            return
        state = [x + 1 for x in next_value]


def _tuples(groups, call):
    # Snapshot lengths and borrow stable groups, never materialize their pools.
    lengths, indices = [], []
    for group in groups:
        call.tick()
        lengths.append(len(group))
        indices.append(0)
    for length in lengths:
        call.tick()
        if length == 0:
            return
    while True:
        values = []
        for group, index, length in zip(groups, indices, lengths):
            call.tick()
            call.require(len(group) == length, "stable internal product group")
            values.append(group[index])
        call.tick()
        yield tuple(values)
        position = len(indices) - 1
        while position >= 0:
            call.tick()
            indices[position] += 1
            if indices[position] < lengths[position]:
                break
            indices[position] = 0
            position -= 1
        if position < 0:
            return


def _nat(number, output, call):
    call.require(type(number) is int and number >= 0, "encoder natural")
    while True:
        call.tick()
        digit = number & 127
        number >>= 7
        output.append(digit | (128 if number else 0))
        if not number:
            return


def _ast_bytes(node, output, call):
    pending = [("node", node)]
    while pending:
        call.tick()
        kind, value = pending.pop()
        if kind == "nat":
            _nat(value, output, call)
            continue
        tag = value[0]
        wire = {"var": 0, "fun": 1, "pred": 0, "eq": 1, "not": 2, "imp": 3, "all": 4}[tag]
        _nat(wire, output, call)
        if tag == "var":
            _nat(value[1], output, call)
        elif tag in ("fun", "pred"):
            _nat(value[1], output, call)
            _nat(len(value[2]), output, call)
            for child in reversed(value[2]):
                call.tick()
                pending.append(("node", child))
        elif tag == "all":
            _nat(value[1], output, call)
            pending.append(("node", value[2]))
        else:
            for child in reversed(value[1:]):
                call.tick()
                pending.append(("node", child))


# Only the already frozen primitive schema patterns; no derived theorem schema.
_SLOTS = (("A", "B"), ("A", "B", "C"), ("A", "B"), ("A", "x", "t"), ("A", "B", "x"), ("A", "x"), ("t",), ("A", "x", "s", "t"), ("A", "x"))
_SORTS = (("F", "F"), ("F", "F", "F"), ("F", "F"), ("F", "V", "T"), ("F", "F", "V"), ("F", "V"), ("T",), ("F", "V", "T", "T"), ("F", "V"))


def _patterns():
    a, z, c = ({"meta": name, "sort": "F"} for name in ("A", "B", "C"))
    x = {"meta": "x", "sort": "V"}
    s, t = ({"meta": name, "sort": "T"} for name in ("s", "t"))
    return (
        (("imp", a, ("imp", z, a)), a),
        (("imp", ("imp", a, ("imp", z, c)), ("imp", ("imp", a, z), ("imp", a, c))), ("imp", a, ("imp", z, c))),
        (("imp", ("imp", ("not", z), ("not", a)), ("imp", a, z)), ("imp", ("not", z), ("not", a))),
        (None, ("all", x, a)),
        (("imp", ("all", x, ("imp", a, z)), ("imp", ("all", x, a), ("all", x, z))), ("all", x, ("imp", a, z))),
        (("imp", a, ("all", x, a)), a),
        (("eq", t, t), None),
        (None, ("eq", s, t)),
        (None, None),
    )


class _Engine:
    def __init__(self, raw, grammar, ordering, modules, call, progress):
        self.c = call
        call.require(type(raw) is bytes, "raw query bytes required")
        call.require(type(modules) is dict and set(modules) == {"checker", "builders"}, "module roles")
        self.checker, self.builders = modules["checker"], modules["builders"]
        call.require(self.checker.VERSION == "FPC-H1-BYTE-CHECKER-v1" and self.builders.VERSION == "FPC-H1-AST-BUILDERS-v1", "pinned dependency versions")
        call.require(type(grammar) is dict and set(grammar) == {"schema", "control_only", "variables", "term_depth", "witness_nodes", "derived_nodes"}, "grammar keys")
        call.require(grammar["schema"] == GRAMMAR_SCHEMA and type(grammar["control_only"]) is bool, "grammar identity")
        for key, maximum in (("variables", 8), ("term_depth", 2), ("witness_nodes", 9), ("derived_nodes", 512)):
            call.require(type(grammar[key]) is int and 0 <= grammar[key] <= maximum, "grammar bound " + key)
            if not grammar["control_only"]:
                call.require(grammar[key] == maximum, "production fixed grammar")
        call.require(ordering in ("FIFO", "MATCH_SCORE"), "ordering")
        call.require(progress is None or (type(progress) is list and not progress), "empty progress owner")
        self.g, self.ordering, self.raw = dict(grammar), ordering, raw
        self.r = {"schema": "FPC-H1-uniform-search-receipt-v1", "version": VERSION, "status": "RUNNING_NO_PREFIX_AUTHORITY", "complete": False, "proof_admitted": False, "grammar": dict(grammar), "ordering": ordering, "known": [], "candidates": [], "demands": [], "events": [], "matches": [], "demand_joins": [], "priority_refusals": [], "task_refusals": [], "tasks": [], "residual_slices": [], "priority_dequeues": [], "MP": [], "GEN": [], "catalogs": {}, "coverage": {"lane_visits": [0] * 8, "next_lane": 0, "cycles": 0, "fallback_turn": 0, "fallback": [], "requests": []}}
        if progress is not None:
            progress.append(self.r)
        self.r["coverage"].update(all_closed=False, source_eof=False, goal_eof=False, census=None)
        ok, self.q = call.helper(self.checker.decode_query, raw)
        assert ok
        self.functions, self.predicates = tuple(self.q["function_arities"]), tuple(self.q["predicate_arities"])
        self.gamma = tuple(_freeze(x, call) for x in self.q["Gamma"])
        self.goal = _freeze(self.q["goal"], call)
        profile = self.q["theory_profile"]
        table = self.q["finite_axioms"] if profile == 0 else (self.builders.PA_AXIOMS if profile == 1 else self.builders.INCIDENCE_AXIOMS)
        self.table = tuple(_freeze(x, call) for x in table)
        self.sources = self.gamma + self.table
        self.source_set, self.source_W = set(self.sources), set()
        self.outside = None
        for number, formula in enumerate(self.sources + (self.goal,)):
            call.tick()
            info = self.info(formula, "F")
            if not self.alphabet(info):
                self.outside = {"source_index": number, "info": info}
            if number < len(self.sources):
                for sort, node, path in _walk(formula, call):
                    call.tick()
                    if sort == "F":
                        self.source_W.add(node)
        self.r["goal_outside_U"] = not self.universe(self.goal)
        if self.r["goal_outside_U"]:
            self.outside = {"kind": "GOAL_OUTSIDE_U", "info": self.info(self.goal, "F")}
        self.Gamma_FV = set()
        for formula in self.gamma:
            call.tick()
            ok, variables = call.helper(self.builders.formula_free_variables, formula)
            assert ok
            self.Gamma_FV.update(variables)
        self.formula_ids, self.demand_ids = {}, {}
        self.imp_ante, self.imp_conseq = {}, {}
        self.mp_keys, self.gen_keys, self.task_keys, self.join_keys = set(), set(), {}, set()
        self.receptor_demand_keys = set()
        self.candidate_keys, self.origin_keys = {}, {}
        self.patterns = _patterns()
        self.queues = [deque() for _ in range(8)]
        self.term_entries, self.w_entries, self.term_keys, self.w_keys = [], [], set(), set()
        self.term_eof = self.w_eof = self.source_eof = self.goal_eof = False
        self.priority = {"F": [], "T": [], "V": []}
        self.priority_keys = {"F": {}, "T": {}, "V": {}}
        self.serial = 0
        self.heap, self.oldest, self.priority_visits = [], deque(), 0
        self.term_gen, self.w_gen = self.term_generator(), self.formula_generator()
        self.fallback = [{"tag": i, "state": None, "eof": profile != 1 and i == 8, "requests": []} for i in range(9)]
        self.r["coverage"]["fallback"] = self.fallback
        self.r["catalogs"] = {"T": {"entries": self.term_entries, "eof": False, "owner": "fallback_catalog_T", "cursor": {"phase": "NOT_STARTED"}}, "W": {"entries": self.w_entries, "eof": False, "owner": "source_walk_then_fallback_catalog_W", "cursor": {"phase": "SOURCE_PREFIX"}}, "priority": self.priority}
        self.found = None
        self.certificate = None
        self.add_event(0, "seed", self.seed())
        self.add_event(1, "source_walk", self.source_walk())
        self.add_event(2, "goal_walk", self.goal_walk())
        for x in range(grammar["variables"]):
            call.tick()
            self.add_priority("V", x, ("variable", x))
            self.add_priority("T", ("var", x), ("variable", x))
        for index, arity in enumerate(self.functions):
            call.tick()
            if arity == 0:
                self.add_priority("T", ("fun", index, ()), ("nullary", index))
        for tag in range(9):
            call.tick()
            if tag != 8 or profile == 1:
                self.task(tag, {}, 0, ("base_schema", tag))
        self.demand(self.goal, ("exact_goal",))

    def info(self, node, sort):
        return _info(node, sort, self.functions, self.predicates, self.c)

    def alphabet(self, info):
        return info["term_depth"] <= self.g["term_depth"] and all(x < self.g["variables"] for x in info["variables"])

    def member(self, sort, value):
        self.c.tick()
        if sort == "V":
            return type(value) is int and 0 <= value < self.g["variables"]
        info = self.info(value, sort)
        return self.alphabet(info) and (sort == "T" or info["nodes"] <= self.g["witness_nodes"] or value in self.source_W)

    def universe(self, formula):
        info = self.info(formula, "F")
        return self.alphabet(info) and (info["nodes"] <= self.g["derived_nodes"] or formula in self.source_set)

    def add_event(self, lane, kind, generator, owner=None):
        self.c.tick()
        record = {"id": len(self.r["events"]), "lane": lane, "kind": kind, "owner": owner, "phase": "START", "cursor": 0, "steps": 0, "status": "PENDING"}
        self.r["events"].append(record)
        self.queues[lane].append((record, generator))

    def event_step(self, lane):
        if not self.queues[lane]:
            return
        record, generator = self.queues[lane].popleft()
        record["status"] = "RUNNING"
        self.active_event = record
        if self.c.advance(generator):
            record["steps"] += 1
            record["status"] = "PENDING"
            self.queues[lane].append((record, generator))
        else:
            record["status"] = "COMPLETED"

    def phase(self, name, cursor):
        self.c.tick()
        self.active_event["phase"] = name
        self.active_event["cursor"] = cursor

    def add_priority(self, sort, value, origin):
        self.c.tick()
        if not self.member(sort, value):
            self.r["priority_refusals"].append({"sort": sort, "value": value, "origin": origin, "reason": "OUTSIDE_WITNESS_DOMAIN"})
            return
        old = self.priority_keys[sort].get(value)
        if old is not None:
            self.priority[sort][old]["origins"].append(origin)
            return
        self.serial += 1
        index = len(self.priority[sort])
        entry = {"value": value, "serial": self.serial, "origins": [origin]}
        self.priority_keys[sort][value] = index
        self.priority[sort].append(entry)
        self.add_event(3, "catalog_delta", self.delta(sort, index, self.serial, len(self.r["tasks"])), (sort, index, self.serial))

    def delta(self, sort, index, serial, limit):
        for task_id in range(limit):
            self.c.tick()
            self.phase("TASK_DELTA", task_id)
            task = self.r["tasks"][task_id]
            if task["born_serial"] < serial and sort in task["residual_sorts"]:
                self.slice(task_id, serial)
            yield

    def task(self, tag, bindings, rigid, origin, request=None):
        self.c.tick()
        for name, sort in zip(_SLOTS[tag], _SORTS[tag]):
            self.c.tick()
            if name in bindings and not self.member(sort, bindings[name]):
                self.r["task_refusals"].append({"tag": tag, "bindings": dict(bindings), "slot": name, "origin": origin, "reason": "OUTSIDE_PRODUCER_BOUND"})
                return
        ordered = tuple((name, bindings[name]) for name in _SLOTS[tag] if name in bindings)
        request_key = None if request is None else (request["demand_id"], request["path"])
        key = (tag, ordered, request_key)
        if key in self.task_keys:
            self.r["tasks"][self.task_keys[key]]["origins"].append(origin)
            return
        task_id = len(self.r["tasks"])
        residual = tuple(name for name in _SLOTS[tag] if name not in bindings)
        sorts = tuple(sort for name, sort in zip(_SLOTS[tag], _SORTS[tag]) if name not in bindings)
        record = {"id": task_id, "tag": tag, "bindings": dict(ordered), "residual_slots": residual, "residual_sorts": sorts, "rigid_nodes": rigid, "conclusion_nodes": None, "unknown_size_score": self.g["derived_nodes"] + 1, "born_serial": self.serial, "origins": [origin], "request": request}
        self.task_keys[key] = task_id
        self.r["tasks"].append(record)
        self.slice(task_id, None)

    def slice(self, task_id, event_serial):
        task = self.r["tasks"][task_id]
        lengths = [len(self.priority[sort]) for sort in task["residual_sorts"]]
        job = {"id": len(self.r["residual_slices"]), "task": task_id, "event_serial": event_serial, "lengths": lengths, "state": None, "status": "PENDING", "ticket": 0, "origins_visited": 0}
        self.r["residual_slices"].append(job)
        self.requeue(job)

    def requeue(self, job):
        self.c.tick()
        job["ticket"] += 1
        task = self.r["tasks"][job["task"]]
        key = (len(task["residual_slots"]), -task["rigid_nodes"], task["unknown_size_score"], job["id"], job["ticket"])
        heapq.heappush(self.heap, key)
        self.oldest.append((job["id"], job["ticket"]))

    def priority_step(self):
        next_visit = self.priority_visits + 1
        use_oldest = self.ordering == "FIFO" or next_visit % 4 == 0
        job = None
        queue = self.oldest if use_oldest else self.heap
        while queue:
            self.c.tick()
            entry = queue.popleft() if use_oldest else heapq.heappop(queue)
            job_id, ticket = (entry[0], entry[1]) if use_oldest else (entry[3], entry[4])
            current = self.r["residual_slices"][job_id]
            if current["status"] == "PENDING" and current["ticket"] == ticket:
                job = current
                break
            # One stale ticket is one lane microstep; do not sweep the backlog.
            return
        if job is None:
            return
        self.priority_visits = next_visit
        self.r["priority_dequeues"].append({"visit": self.priority_visits, "oldest": use_oldest, "slice": job["id"], "ticket": job["ticket"]})
        job["status"] = "RUNNING"
        step = _product_step(job["state"], job["lengths"], [True] * len(job["lengths"]), self.c)
        job["state"] = step["state"]
        if step["kind"] == "EOF":
            job["status"] = "COMPLETED"
            return
        if step["kind"] == "TUPLE":
            task = self.r["tasks"][job["task"]]
            binding, serials = dict(task["bindings"]), []
            for name, sort, index in zip(task["residual_slots"], task["residual_sorts"], step["indices"]):
                self.c.tick()
                entry = self.priority[sort][index]
                binding[name] = entry["value"]
                serials.append(entry["serial"])
            if job["event_serial"] is None or (serials and max(serials) == job["event_serial"]):
                self.candidate(task["tag"], [binding[name] for name in _SLOTS[task["tag"]]], ("priority_slice", job["id"], tuple(step["indices"])))
            job["origins_visited"] += 1
        job["status"] = "PENDING"
        self.requeue(job)

    def seed(self):
        for index, formula in enumerate(self.gamma):
            self.c.tick()
            self.phase("HYP", index)
            self.insert(formula, {"rule": 0, "subtag": None, "witness": [index], "refs": []}, ("Gamma", index))
            yield
        profile = self.q["theory_profile"]
        subtag = {0: 0, 1: 1, 2: 3}[profile]
        for index, formula in enumerate(self.table):
            self.c.tick()
            self.phase("TABLE", index)
            self.insert(formula, {"rule": 2, "subtag": subtag, "witness": [index], "refs": []}, ("table", index))
            yield

    def source_walk(self):
        for index, formula in enumerate(self.sources):
            for sort, node, path in _walk(formula, self.c):
                self.c.tick()
                self.phase("SOURCE", (index, path))
                self.add_priority(sort, node, ("source", index, path))
                if sort == "F" and node not in self.w_keys:
                    self.w_keys.add(node)
                    self.w_entries.append(node)
                yield
        self.source_eof = True
        self.r["coverage"]["source_eof"] = True

    def goal_walk(self):
        for sort, node, path in _walk(self.goal, self.c):
            self.c.tick()
            self.phase("GOAL_SYNTAX", path)
            self.add_priority(sort, node, ("goal_syntax", path))
            yield
        self.goal_eof = True
        self.r["coverage"]["goal_eof"] = True

    def insert(self, formula, derivation, origin):
        self.c.tick()
        old = self.formula_ids.get(formula)
        if old is not None:
            self.r["known"][old]["origins"].append(origin)
            return old, False
        number = len(self.r["known"])
        for reference in derivation["refs"]:
            self.c.require(type(reference) is int and 0 <= reference < number, "internal backward dependency")
        record = {"id": number, "formula": formula, "derivation": derivation, "origins": [origin], "registration_complete": False}
        self.formula_ids[formula] = number
        self.r["known"].append(record)
        self.add_event(3, "formula_registration", self.register(number), number)
        if formula == self.goal:
            self.found = number
        return number, True

    def candidate(self, tag, witnesses, origin):
        self.c.tick()
        key = (tag, tuple(witnesses))
        if key in self.candidate_keys:
            existing = self.r["candidates"][self.candidate_keys[key]]
            existing["origins"].append(origin)
            self.receptor_demands(existing, origin)
            return
        record = {"id": len(self.r["candidates"]), "tag": tag, "witness": witnesses, "origins": [origin], "status": "STARTED"}
        self.candidate_keys[key] = record["id"]
        self.r["candidates"].append(record)
        if tag == 8:
            body, x = witnesses
            ok, variables = self.c.helper(self.builders.formula_free_variables, body)
            assert ok
            parameters = sorted(variables - {x})
            ok, formula = self.c.helper(self.builders.pa_induction, body, x, parameters, refusal=self.builders.InvalidWitness)
            derivation = {"rule": 2, "subtag": 2, "witness": [body, x, parameters], "refs": []}
        else:
            ok, formula = self.c.helper(self.builders.logical_axiom, tag, list(witnesses), refusal=self.builders.InvalidWitness)
            derivation = {"rule": 1, "subtag": tag, "witness": list(witnesses), "refs": []}
        if not ok:
            record.update(status="BUILDER_GUARD_REFUSAL", reason=formula)
            return
        formula = _freeze(formula, self.c)
        if not self.universe(formula):
            record.update(status="OUTSIDE_OUTPUT_BOUND", formula=formula)
            return
        number, fresh = self.insert(formula, derivation, ("candidate", record["id"]))
        record.update(status="NEW_FORMULA" if fresh else "DUPLICATE_FORMULA", formula_id=number, formula=formula)
        self.receptor_demands(record, origin)

    def receptor_demands(self, candidate, origin):
        self.c.tick()
        if origin[0] != "priority_slice" or candidate["status"] not in ("NEW_FORMULA", "DUPLICATE_FORMULA"):
            return
        task = self.r["tasks"][self.r["residual_slices"][origin[1]]["task"]]
        request = task["request"]
        if request is None:
            return
        key = (candidate["id"], request["demand_id"], request["path"])
        if key in self.receptor_demand_keys:
            return
        formula, antecedents = candidate["formula"], []
        for slot in request["path"]:
            self.c.tick()
            self.c.require(slot == 2 and formula[0] == "imp", "rigid schema site path")
            antecedents.append(formula[1])
            formula = formula[2]
        self.c.require(formula == self.r["demands"][request["demand_id"]]["formula"], "instantiated schema site")
        self.receptor_demand_keys.add(key)
        for index, antecedent in enumerate(antecedents):
            self.c.tick()
            self.demand(antecedent, ("schema_site_need", candidate["id"], request["demand_id"], request["path"], index))

    def demand(self, formula, origin):
        self.c.tick()
        if not self.universe(formula):
            return
        if formula in self.demand_ids:
            self.r["demands"][self.demand_ids[formula]]["origins"].append(origin)
            return
        number = len(self.r["demands"])
        self.demand_ids[formula] = number
        self.r["demands"].append({"id": number, "formula": formula, "origins": [origin], "complete": False})
        self.add_event(2, "demand", self.demand_event(number), number)

    def demand_join(self, demand_id, implication_id):
        key = (demand_id, implication_id)
        self.c.tick()
        if key not in self.join_keys:
            self.join_keys.add(key)
            self.r["demand_joins"].append({"key": key, "status": "COMPLETED"})
            implication = self.r["known"][implication_id]["formula"]
            self.demand(implication[1], ("implication_demand", demand_id, implication_id))

    def demand_event(self, number):
        record = self.r["demands"][number]
        formula = record["formula"]
        self.phase("GEN_NEED", number)
        if formula[0] == "all":
            self.demand(formula[2], ("GEN_need", number))
        yield
        position = 0
        subscribed = self.imp_conseq.setdefault(formula, [])
        while position < len(subscribed):
            self.c.tick()
            self.phase("CONSEQUENT_JOIN", position)
            self.demand_join(number, subscribed[position])
            position += 1
            yield
        for tag, (conclusion, premise) in enumerate(self.patterns):
            self.c.tick()
            self.phase("CONCLUSION_PATTERN", tag)
            if conclusion is not None:
                site, path, required = conclusion, (), ()
                while True:
                    self.c.tick()
                    self.phase("CONCLUSION_SITE", (tag, path))
                    match = _match(site, formula, None, self.c)
                    self.r["matches"].append({"key": ("demand", number, tag, path), "site_path": path, "required_premise_patterns": required, "status": "MATCHED" if match["matched"] else "MISMATCH", "bindings": match["bindings"], "rigid_nodes": match["rigid_nodes"]})
                    if match["matched"]:
                        self.task(tag, match["bindings"], match["rigid_nodes"], ("demand_match", number, tag, path), {"demand_id": number, "path": path})
                    yield
                    if type(site) is not tuple or not site or site[0] != "imp":
                        break
                    required += (site[1],)
                    path += (2,)
                    site = site[2]
            else:
                self.r["matches"].append({"key": ("demand", number, tag, ()), "site_path": (), "required_premise_patterns": (), "status": "PRIORITY_NOT_HANDLED_COMPUTED_FIELD"})
            yield
        record["complete"] = True

    def mp(self, ante, implication):
        key = (ante, implication)
        self.c.tick()
        if key in self.mp_keys:
            return
        self.mp_keys.add(key)
        record = {"key": key, "status": "PENDING"}
        self.r["MP"].append(record)
        self.add_event(5, "MP", self.mp_event(record), key)

    def mp_event(self, record):
        ante, implication = record["key"]
        self.phase("EXACT_MP", record["key"])
        a, imp = self.r["known"][ante]["formula"], self.r["known"][implication]["formula"]
        self.c.require(imp[0] == "imp" and imp[1] == a, "MP subscription invariant")
        if self.universe(imp[2]):
            number, fresh = self.insert(imp[2], {"rule": 3, "subtag": None, "witness": [], "refs": [ante, implication]}, ("MP", ante, implication))
            record.update(status="NEW_FORMULA" if fresh else "DUPLICATE_FORMULA", formula_id=number)
        else:
            record["status"] = "OUTSIDE_OUTPUT_BOUND"
        yield

    def gen_event(self, record):
        number, x = record["key"]
        self.c.tick()
        self.phase("EXACT_GEN", record["key"])
        if x in self.Gamma_FV:
            record["status"] = "GLOBAL_GAMMA_REFUSAL"
        else:
            formula = ("all", x, self.r["known"][number]["formula"])
            if self.universe(formula):
                result, fresh = self.insert(formula, {"rule": 4, "subtag": None, "witness": [x], "refs": [number]}, ("GEN", number, x))
                record.update(status="NEW_FORMULA" if fresh else "DUPLICATE_FORMULA", formula_id=result)
            else:
                record["status"] = "OUTSIDE_OUTPUT_BOUND"
        yield

    def register(self, number):
        record = self.r["known"][number]
        formula = record["formula"]
        self.phase("IMPLICATION_SUBSCRIPTIONS", number)
        if formula[0] == "imp":
            self.imp_ante.setdefault(formula[1], []).append(number)
            self.imp_conseq.setdefault(formula[2], []).append(number)
            existing = self.formula_ids.get(formula[1])
            if existing is not None:
                self.mp(existing, number)
            need = self.demand_ids.get(formula[2])
            if need is not None:
                self.demand_join(need, number)
        yield
        position = 0
        subscribers = self.imp_ante.setdefault(formula, [])
        while position < len(subscribers):
            self.phase("ANTECEDENT_SUBSCRIPTIONS", position)
            self.mp(number, subscribers[position])
            position += 1
            yield
        for x in range(self.g["variables"]):
            self.c.tick()
            self.phase("REGISTER_GEN", x)
            key = (number, x)
            if key not in self.gen_keys:
                self.gen_keys.add(key)
                item = {"key": key, "status": "PENDING"}
                self.r["GEN"].append(item)
                self.add_event(6, "GEN", self.gen_event(item), key)
            yield
        for sort, node, path in _walk(formula, self.c):
            self.phase("DISCOVERED_SYNTAX", path)
            self.add_priority(sort, node, ("discovered_syntax", number, path))
            yield
        for tag, (conclusion, premise) in enumerate(self.patterns):
            self.c.tick()
            self.phase("PREMISE_PATTERN", tag)
            if premise is not None:
                match = _match(premise, formula, None, self.c)
                self.r["matches"].append({"key": ("known", number, tag), "status": "MATCHED" if match["matched"] else "MISMATCH", "bindings": match["bindings"], "rigid_nodes": match["rigid_nodes"]})
                if match["matched"]:
                    self.task(tag, match["bindings"], match["rigid_nodes"], ("premise_match", number, tag))
            else:
                self.r["matches"].append({"key": ("known", number, tag), "status": "NO_PREMISE_SITE"})
            yield
        record["registration_complete"] = True

    def term_generator(self):
        by_depth = []
        for x in range(self.g["variables"]):
            self.c.tick()
            self.r["catalogs"]["T"]["cursor"] = {"phase": "VARIABLE", "index": x}
            yield ("var", x)
        for symbol, arity in enumerate(self.functions):
            self.c.tick()
            self.r["catalogs"]["T"]["cursor"] = {"phase": "NULLARY", "symbol": symbol}
            if arity == 0:
                yield ("fun", symbol, ())
            else:
                yield None
        for depth in range(1, self.g["term_depth"] + 1):
            by_depth.clear()
            for pool_index, term in enumerate(self.term_entries):
                self.c.tick()
                self.r["catalogs"]["T"]["cursor"] = {"phase": "DEPTH_POOL", "depth": depth, "index": pool_index}
                if self.info(term, "T")["term_depth"] < depth:
                    by_depth.append(term)
                yield None
            for symbol, arity in enumerate(self.functions):
                self.c.tick()
                if arity == 0:
                    yield None
                    continue
                groups = []
                for slot in range(arity):
                    self.c.tick()
                    groups.append(by_depth)
                for product_index, children in enumerate(_tuples(groups, self.c)):
                    self.r["catalogs"]["T"]["cursor"] = {"phase": "FUNCTION_PRODUCT", "depth": depth, "symbol": symbol, "position": product_index, "pool_length": len(by_depth)}
                    node = ("fun", symbol, children)
                    if self.info(node, "T")["term_depth"] == depth:
                        yield node
                    else:
                        yield None

    def formula_generator(self):
        # Owner will not advance this until the independent source walk and T EOF.
        terms, formulas = {}, {}
        for bucket_index, term in enumerate(self.term_entries):
            self.c.tick()
            self.r["catalogs"]["W"]["cursor"] = {"phase": "TERM_BUCKET", "index": bucket_index}
            terms.setdefault(self.info(term, "T")["nodes"], []).append(term)
            yield None
        for bucket_index, formula in enumerate(self.w_entries):
            self.c.tick()
            self.r["catalogs"]["W"]["cursor"] = {"phase": "SOURCE_BUCKET", "index": bucket_index}
            size = self.info(formula, "F")["nodes"]
            if size <= self.g["witness_nodes"]:
                formulas.setdefault(size, []).append(formula)
            yield None
        for size in range(1, self.g["witness_nodes"] + 1):
            for tag in ("pred", "eq", "not", "imp", "all"):
                signatures = enumerate(self.predicates) if tag == "pred" else ((None, {"eq": 2, "not": 1, "imp": 2, "all": 1}[tag]),)
                for symbol, count in signatures:
                    for partition in _compositions(size - 1, count, self.c):
                        groups = []
                        table = terms if tag in ("pred", "eq") else formulas
                        for weight in partition:
                            self.c.tick()
                            groups.append(table.get(weight, []))
                        for product_index, children in enumerate(_tuples(groups, self.c)):
                            variants = range(self.g["variables"]) if tag == "all" else (None,)
                            for variable in variants:
                                self.c.tick()
                                self.r["catalogs"]["W"]["cursor"] = {"phase": "CONSTRUCTOR_PRODUCT", "size": size, "tag": tag, "symbol": symbol, "partition": partition, "position": product_index, "variable": variable}
                                if tag == "pred":
                                    node = (tag, symbol, children)
                                elif tag == "all":
                                    node = (tag, variable, children[0])
                                else:
                                    node = (tag,) + children
                                if node not in self.w_keys:
                                    formulas.setdefault(size, []).append(node)
                                yield node
                    yield None

    def catalog_step(self, kind):
        self.c.tick()
        if kind == "T":
            if self.term_eof:
                return
            try:
                node = next(self.term_gen)
            except BaseException as error:
                if self.c.fault is not None:
                    raise self.c.fault
                if not isinstance(error, StopIteration):
                    raise
                self.term_eof = True
                self.r["catalogs"]["T"]["eof"] = True
                self.r["catalogs"]["T"]["cursor"] = {"phase": "EOF"}
                return
            if node is not None and node not in self.term_keys:
                self.term_keys.add(node)
                self.term_entries.append(node)
                self.add_priority("T", node, ("fallback_T", len(self.term_entries) - 1))
        else:
            if self.w_eof or not self.source_eof or not self.term_eof:
                return
            try:
                node = next(self.w_gen)
            except BaseException as error:
                if self.c.fault is not None:
                    raise self.c.fault
                if not isinstance(error, StopIteration):
                    raise
                self.w_eof = True
                self.r["catalogs"]["W"]["eof"] = True
                self.r["catalogs"]["W"]["cursor"] = {"phase": "EOF"}
                return
            if node is not None and node not in self.w_keys:
                self.w_keys.add(node)
                self.w_entries.append(node)
                self.add_priority("F", node, ("fallback_W", len(self.w_entries) - 1))

    def fallback_step(self):
        turn = self.r["coverage"]["fallback_turn"]
        self.r["coverage"]["fallback_turn"] += 1
        if turn % 3 == 0:
            self.catalog_step("T")
            return
        if turn % 3 == 1:
            self.catalog_step("W")
            return
        producer = self.fallback[(turn // 3) % 9]
        if producer["eof"]:
            return
        catalogs, closed = [], []
        for sort in _SORTS[producer["tag"]]:
            self.c.tick()
            catalogs.append(self.w_entries if sort == "F" else (self.term_entries if sort == "T" else list(range(self.g["variables"]))))
            closed.append(self.w_eof if sort == "F" else (self.term_eof if sort == "T" else True))
        step = _product_step(producer["state"], [len(x) for x in catalogs], closed, self.c)
        producer["state"], producer["requests"] = step["state"], step["requests"]
        for request in step["requests"]:
            self.c.tick()
            self.r["coverage"]["requests"].append({"producer": producer["tag"], "sort": _SORTS[producer["tag"]][request["slot"]], "index": request["index"], "owner": "fallback_catalog_T" if _SORTS[producer["tag"]][request["slot"]] == "T" else "source_walk_then_fallback_catalog_W"})
        if step["kind"] == "EOF":
            producer["eof"] = True
        elif step["kind"] == "TUPLE":
            values = [catalog[index] for catalog, index in zip(catalogs, step["indices"])]
            self.candidate(producer["tag"], values, ("fallback", producer["tag"], tuple(step["indices"])))

    def quiescent(self):
        self.c.tick()
        if not (self.source_eof and self.goal_eof and self.term_eof and self.w_eof):
            return False
        for producer in self.fallback:
            self.c.tick()
            if not producer["eof"]:
                return False
        for queue in self.queues:
            self.c.tick()
            if queue:
                return False
        for job in self.r["residual_slices"]:
            self.c.tick()
            if job["status"] != "COMPLETED":
                return False
        census = {"T_entries": len(self.term_entries), "W_entries": len(self.w_entries), "fallback_products": len(self.fallback), "fallback_open": 0, "events_pending": 0, "residual_pending": 0, "MP_pending": 0, "GEN_pending": 0, "registrations_pending": 0, "demands_pending": 0}
        for event in self.r["events"]:
            self.c.tick()
            census["events_pending"] += event["status"] != "COMPLETED"
        for kind in ("MP", "GEN"):
            for record in self.r[kind]:
                self.c.tick()
                census[kind + "_pending"] += record["status"] == "PENDING"
        for record in self.r["known"]:
            self.c.tick()
            census["registrations_pending"] += not record["registration_complete"]
        for record in self.r["demands"]:
            self.c.tick()
            census["demands_pending"] += not record["complete"]
        self.r["coverage"]["census"] = census
        for key, count in census.items():
            self.c.tick()
            if key.endswith("pending") and count:
                return False
        self.r["coverage"]["all_closed"] = True
        return True

    def export(self):
        pending, seen, heap = [self.found], set(), []
        while pending:
            self.c.tick()
            number = pending.pop()
            if number in seen:
                continue
            seen.add(number)
            heapq.heappush(heap, number)
            for reference in self.r["known"][number]["derivation"]["refs"]:
                self.c.tick()
                self.c.require(reference < number, "export acyclicity")
                pending.append(reference)
        ids = []
        while heap:
            self.c.tick()
            ids.append(heapq.heappop(heap))
        self.c.require(bool(ids) and ids[-1] == self.found, "export final goal")
        remap, rows = {}, []
        output = bytearray(b"FPP1")
        _nat(len(ids), output, self.c)
        for old in ids:
            self.c.tick()
            record = self.r["known"][old]
            derivation = record["derivation"]
            number = len(rows)
            references = [remap[x] for x in derivation["refs"]]
            remap[old] = number
            row = {"index": number, "source_formula_id": old, "formula": record["formula"], "rule_tag": derivation["rule"], "subtag": derivation["subtag"], "witness": derivation["witness"], "references": references}
            rows.append(row)
            _ast_bytes(record["formula"], output, self.c)
            rule = derivation["rule"]
            _nat(rule, output, self.c)
            witness = derivation["witness"]
            if rule == 0:
                _nat(witness[0], output, self.c)
            elif rule == 1:
                tag = derivation["subtag"]
                _nat(tag, output, self.c)
                for sort, value in zip(_SORTS[tag], witness):
                    self.c.tick()
                    if sort == "V":
                        _nat(value, output, self.c)
                    else:
                        _ast_bytes(value, output, self.c)
            elif rule == 2:
                _nat(derivation["subtag"], output, self.c)
                if derivation["subtag"] == 2:
                    _ast_bytes(witness[0], output, self.c)
                    _nat(witness[1], output, self.c)
                    _nat(len(witness[2]), output, self.c)
                    for x in witness[2]:
                        _nat(x, output, self.c)
                else:
                    _nat(witness[0], output, self.c)
            elif rule == 3:
                _nat(references[0], output, self.c)
                _nat(references[1], output, self.c)
            else:
                _nat(references[0], output, self.c)
                _nat(witness[0], output, self.c)
        self.c.tick()
        return bytes(output), rows

    def run(self):
        if self.outside is not None:
            self.r.update(status="SOURCE_OUTSIDE_DECLARED_GRAMMAR", outside=self.outside, complete=True)
            self.c.tick()
            return self.r
        lane = 0
        while self.found is None:
            self.c.tick()
            self.r["coverage"]["lane_visits"][lane] += 1
            if lane == 4:
                self.priority_step()
            elif lane == 7:
                self.fallback_step()
            else:
                self.event_step(lane)
            lane = (lane + 1) % 8
            self.r["coverage"]["next_lane"] = lane
            if lane == 0:
                self.r["coverage"]["cycles"] += 1
                if self.found is None and self.quiescent():
                    self.r.update(status="EXHAUSTED_DECLARED_GRAMMAR", complete=True)
                    self.c.tick()
                    return self.r
        raw, rows = self.export()
        self.certificate = raw
        self.r.update(status="CANDIDATE_FOUND", complete=True, candidate_rows=rows, candidate_goal_formula_id=self.found, candidate_validation="NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED")
        self.c.tick()
        return self.r


def search_fpc(query_bytes, *, grammar, ordering, modules, check, progress=None):
    """Discover a primitive certificate candidate, never issue proof admission.

    progress is an optional exclusive empty list retaining one live diagnostic
    carrier on a propagated fault. It is not a resume token or admitted prefix.
    All dependencies must be exact reviewed/pinned original modules; callers
    may not mutate inputs/progress/modules or monkeypatch namespaces mid-call.
    """
    call = _Call(check)
    call.tick()
    engine = _Engine(query_bytes, grammar, ordering, modules, call, progress)
    result = engine.run()
    digest = hashlib.sha256()
    for offset in range(0, len(query_bytes), 16384):
        call.tick()
        digest.update(query_bytes[offset:offset + 16384])
    result["query_sha256"] = digest.hexdigest()
    result["callbacks"] = call.callbacks
    call.tick()
    return {"status": result["status"], "candidate_certificate_bytes": engine.certificate, "receipt": result}
