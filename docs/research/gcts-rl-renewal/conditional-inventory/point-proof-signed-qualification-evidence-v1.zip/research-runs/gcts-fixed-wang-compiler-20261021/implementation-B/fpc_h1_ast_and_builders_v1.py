"""FPC-H1 exact AST specification, not a byte checker.

Source only: these hand-written literals and algorithm definitions have not been
imported, called or semantically qualified. Inputs to builders are finite,
wellformed, already signature-checked core ASTs; validating that precondition is
the future parser/checker's obligation. No object-level alpha conversion occurs.
Returned trees may share read-only subtrees with their inputs. Callers must not
mutate any supplied or returned AST, including the table literals.
"""

VERSION = "FPC-H1-AST-BUILDERS-v1"
PA_FUNCTION_ARITIES = [0, 1, 2, 2]
PA_PREDICATE_ARITIES = []
INCIDENCE_FUNCTION_ARITIES = []
INCIDENCE_PREDICATE_ARITIES = [1, 1, 2]
PA_NAMES = ["PA1", "PA2", "PA3", "PA4", "PA5", "PA6"]
INCIDENCE_NAMES = ["HI-SORT", "HI-TYPE", "HI-EXIST", "HI-UNIQUE", "HI-TWO", "HI-NONCOLLINEAR"]

# Every entry is a literal in the five-constructor formula language. No table
# entry is built by a function, abbreviation, interpretation or schema call.
PA_AXIOMS = [
    ["all", 0, ["not", ["eq", ["fun", 1, [["var", 0]]], ["fun", 0, []]]]],
    ["all", 0, ["all", 1, ["imp",
        ["eq", ["fun", 1, [["var", 0]]], ["fun", 1, [["var", 1]]]],
        ["eq", ["var", 0], ["var", 1]]]]],
    ["all", 0, ["eq", ["fun", 2, [["var", 0], ["fun", 0, []]]], ["var", 0]]],
    ["all", 0, ["all", 1, ["eq",
        ["fun", 2, [["var", 0], ["fun", 1, [["var", 1]]]]],
        ["fun", 1, [["fun", 2, [["var", 0], ["var", 1]]]]]]]],
    ["all", 0, ["eq", ["fun", 3, [["var", 0], ["fun", 0, []]]], ["fun", 0, []]]],
    ["all", 0, ["all", 1, ["eq",
        ["fun", 3, [["var", 0], ["fun", 1, [["var", 1]]]]],
        ["fun", 2, [["fun", 3, [["var", 0], ["var", 1]]], ["var", 0]]]]]],
]

INCIDENCE_AXIOMS = [
    # ALL z: AND(OR(Pt(z),Ln(z)), NOT(AND(Pt(z),Ln(z)))).
    ["all", 5, ["not", ["imp",
        ["imp", ["not", ["pred", 0, [["var", 5]]]], ["pred", 1, [["var", 5]]]],
        ["not", ["not", ["not", ["imp", ["pred", 0, [["var", 5]]],
            ["not", ["pred", 1, [["var", 5]]]]]]]]]]],
    # ALL p,l: I(p,l) -> AND(Pt(p),Ln(l)).
    ["all", 0, ["all", 3, ["imp", ["pred", 2, [["var", 0], ["var", 3]]],
        ["not", ["imp", ["pred", 0, [["var", 0]]], ["not", ["pred", 1, [["var", 3]]]]]]]]],
    # ALL p,q: AND(Pt(p),Pt(q),NEQ(p,q)) -> EXISTS l: AND(Ln(l),I(p,l),I(q,l)).
    ["all", 0, ["all", 1, ["imp",
        ["not", ["imp", ["pred", 0, [["var", 0]]], ["not",
            ["not", ["imp", ["pred", 0, [["var", 1]]],
                ["not", ["not", ["eq", ["var", 0], ["var", 1]]]]]]]]],
        ["not", ["all", 3, ["not", ["not", ["imp", ["pred", 1, [["var", 3]]],
            ["not", ["not", ["imp", ["pred", 2, [["var", 0], ["var", 3]]],
                ["not", ["pred", 2, [["var", 1], ["var", 3]]]]]]]]]]]]]]],
    # ALL p,q,l,m: right-associated conjunction of nine guards -> l=m.
    ["all", 0, ["all", 1, ["all", 3, ["all", 4, ["imp",
        ["not", ["imp", ["pred", 0, [["var", 0]]], ["not",
        ["not", ["imp", ["pred", 0, [["var", 1]]], ["not",
        ["not", ["imp", ["not", ["eq", ["var", 0], ["var", 1]]], ["not",
        ["not", ["imp", ["pred", 1, [["var", 3]]], ["not",
        ["not", ["imp", ["pred", 1, [["var", 4]]], ["not",
        ["not", ["imp", ["pred", 2, [["var", 0], ["var", 3]]], ["not",
        ["not", ["imp", ["pred", 2, [["var", 1], ["var", 3]]], ["not",
        ["not", ["imp", ["pred", 2, [["var", 0], ["var", 4]]],
            ["not", ["pred", 2, [["var", 1], ["var", 4]]]]]]]
        ]]]]]]]]]]]]]]]]]]]],
        ["eq", ["var", 3], ["var", 4]]]]]]],
    # ALL l: Ln(l) -> EXISTS p,q: AND(Pt(p),Pt(q),NEQ(p,q),I(p,l),I(q,l)).
    ["all", 3, ["imp", ["pred", 1, [["var", 3]]],
        ["not", ["all", 0, ["not", ["not", ["all", 1, ["not",
        ["not", ["imp", ["pred", 0, [["var", 0]]], ["not",
        ["not", ["imp", ["pred", 0, [["var", 1]]], ["not",
        ["not", ["imp", ["not", ["eq", ["var", 0], ["var", 1]]], ["not",
        ["not", ["imp", ["pred", 2, [["var", 0], ["var", 3]]],
            ["not", ["pred", 2, [["var", 1], ["var", 3]]]]]]]
        ]]]]]]]]]]]]]]]],
    # EXISTS p,q,r: AND(Pt(p),Pt(q),Pt(r),NEQ(p,q),NEQ(p,r),NEQ(q,r),
    #                      NOT EXISTS l: AND(Ln(l),I(p,l),I(q,l),I(r,l))).
    ["not", ["all", 0, ["not", ["not", ["all", 1, ["not", ["not", ["all", 2, ["not",
        ["not", ["imp", ["pred", 0, [["var", 0]]], ["not",
        ["not", ["imp", ["pred", 0, [["var", 1]]], ["not",
        ["not", ["imp", ["pred", 0, [["var", 2]]], ["not",
        ["not", ["imp", ["not", ["eq", ["var", 0], ["var", 1]]], ["not",
        ["not", ["imp", ["not", ["eq", ["var", 0], ["var", 2]]], ["not",
        ["not", ["imp", ["not", ["eq", ["var", 1], ["var", 2]]], ["not",
            ["not", ["not", ["all", 3, ["not",
                ["not", ["imp", ["pred", 1, [["var", 3]]], ["not",
                ["not", ["imp", ["pred", 2, [["var", 0], ["var", 3]]], ["not",
                ["not", ["imp", ["pred", 2, [["var", 1], ["var", 3]]],
                    ["not", ["pred", 2, [["var", 2], ["var", 3]]]]]]]
                ]]]]]]]]
        ]]]]]]]]]]]]]]]]]]]]]]]]]]]],
]


class InvalidWitness(ValueError):
    """A completed builder-side condition failed; never a resource wrapper."""


def term_free_variables(term, *, check):
    result = set()
    pending = [term]
    while pending:
        check()
        node = pending.pop()
        if node[0] == "var":
            result.add(node[1])
        else:
            for child in reversed(node[2]):
                check()
                pending.append(child)
    return result


def formula_free_variables(formula, *, check):
    result = set()
    pending = [(formula, frozenset())]
    while pending:
        check()
        node, bound = pending.pop()
        tag = node[0]
        if tag == "all":
            pending.append((node[2], bound | {node[1]}))
        elif tag == "not":
            pending.append((node[1], bound))
        elif tag == "imp":
            pending.append((node[2], bound))
            pending.append((node[1], bound))
        else:
            terms = node[2] if tag == "pred" else node[1:3]
            for term in terms:
                check()
                result.update(term_free_variables(term, check=check) - bound)
    return result


def free_for(term, variable, formula, *, check):
    inserted = term_free_variables(term, check=check)
    pending = [(formula, frozenset())]
    while pending:
        check()
        node, bound = pending.pop()
        tag = node[0]
        if tag == "all":
            if node[1] != variable:
                pending.append((node[2], bound | {node[1]}))
        elif tag == "not":
            pending.append((node[1], bound))
        elif tag == "imp":
            pending.append((node[2], bound))
            pending.append((node[1], bound))
        else:
            terms = node[2] if tag == "pred" else node[1:3]
            for source_term in terms:
                check()
                if variable in term_free_variables(source_term, check=check) and bound & inserted:
                    return False
    return True


def substitute(term, variable, formula, *, check):
    """Finite postorder traversal; do not traverse inserted term or shadowed body."""
    if not free_for(term, variable, formula, check=check):
        raise InvalidWitness("substitution capture")
    pending = [("formula", formula)]
    values = []
    while pending:
        check()
        kind, node = pending.pop()
        if kind == "rebuild":
            tag, metadata, count = node
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            if tag in ("fun", "pred"):
                values.append([tag, metadata, children])
            elif tag == "all":
                values.append([tag, metadata, children[0]])
            else:
                values.append([tag] + children)
            continue
        tag = node[0]
        if kind == "term":
            if tag == "var":
                values.append(term if node[1] == variable else node)
                continue
            children = node[2]
            pending.append(("rebuild", (tag, node[1], len(children))))
            for child in reversed(children):
                check()
                pending.append(("term", child))
        elif tag == "all" and node[1] == variable:
            values.append(node)
        elif tag in ("pred", "eq"):
            children = node[2] if tag == "pred" else node[1:3]
            pending.append(("rebuild", (tag, node[1] if tag == "pred" else None, len(children))))
            for child in reversed(children):
                check()
                pending.append(("term", child))
        else:
            children = [node[2]] if tag == "all" else node[1:]
            pending.append(("rebuild", (tag, node[1] if tag == "all" else None, len(children))))
            for child in reversed(children):
                check()
                pending.append(("formula", child))
    return values[0]


def logical_axiom(tag, witnesses, *, check):
    """Witness order is the exact binary contract; no extra witness accepted."""
    check()
    if type(tag) is not int or tag < 0 or tag > 7 or type(witnesses) is not list:
        raise InvalidWitness("logical tag or witness carrier")
    if len(witnesses) != [2, 3, 2, 3, 3, 2, 1, 4][tag]:
        raise InvalidWitness("logical witness count")
    if tag == 0:
        a, b = witnesses
        return ["imp", a, ["imp", b, a]]
    if tag == 1:
        a, b, c = witnesses
        return ["imp", ["imp", a, ["imp", b, c]], ["imp", ["imp", a, b], ["imp", a, c]]]
    if tag == 2:
        a, b = witnesses
        return ["imp", ["imp", ["not", b], ["not", a]], ["imp", a, b]]
    if tag == 3:
        a, x, t = witnesses
        return ["imp", ["all", x, a], substitute(t, x, a, check=check)]
    if tag == 4:
        a, b, x = witnesses
        return ["imp", ["all", x, ["imp", a, b]], ["imp", ["all", x, a], ["all", x, b]]]
    if tag == 5:
        a, x = witnesses
        if x in formula_free_variables(a, check=check):
            raise InvalidWitness("Q3 free variable")
        return ["imp", a, ["all", x, a]]
    if tag == 6:
        (t,) = witnesses
        return ["eq", t, t]
    a, x, s, t = witnesses
    left = substitute(s, x, a, check=check)
    right = substitute(t, x, a, check=check)
    return ["imp", ["eq", s, t], ["imp", left, right]]


def pa_induction(formula, variable, parameters, *, check):
    """Exact parameter vector, right-associated core AND, ascending closure."""
    expected = sorted(formula_free_variables(formula, check=check) - {variable})
    if type(parameters) is not list or any(type(x) is not int or x < 0 for x in parameters):
        raise InvalidWitness("induction parameter carrier")
    if parameters != expected:
        raise InvalidWitness("induction parameters")
    base = substitute(["fun", 0, []], variable, formula, check=check)
    successor = substitute(["fun", 1, [["var", variable]]], variable, formula, check=check)
    step = ["all", variable, ["imp", formula, successor]]
    antecedent = ["not", ["imp", base, ["not", step]]]
    result = ["imp", antecedent, ["all", variable, formula]]
    for parameter in reversed(parameters):
        check()
        result = ["all", parameter, result]
    return result
