"""Inert administrative emitter: Source/metadata only; never read scientific data."""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parent.parent
API_PATH = STUDY / 'implementation-B/frozen-target-contextual-reuse-worker-API-v3.json'
API_PIN = {'path': str(API_PATH), 'bytes': 38571,
           'sha256': '54507750f4da8e073941b58bd7ea400f3aec510b2bc6990cd18d2e1840a7e3e6'}
WORKER_PIN = {'path': str(STUDY / 'implementation-B/fpc_frozen_target_contextual_reuse_worker_v2.py'),
              'bytes': 97393, 'sha256': 'ff6ae8c81832b09dec2de1b1a8c11251b925d701177adaf78b03b933362d57b8'}
PROTOCOL = ROOT / 'frozen-target-contextual-reuse-protocol-v2.json'
PREPARATION = ROOT / 'frozen-target-contextual-reuse-study-preparation-v2.json'
ARMS = ('NO_LIBRARY', 'CONDITIONAL_LEMMA_CD', 'RECEPTOR_DAG')
ROLES = ('checker', 'builders', 'reference', 'instance', 'consumer')
Q_ROLES = ('checker', 'builders', 'reference', 'instance', 'ordinary', 'consumer', 'wide_encoder', 'bank')
Q_FIELDS = ('Root_admission', 'C_actual_review', 'plan', 'result', 'bank')
SOURCE_ACCEPTANCE_FIELDS = {'schema', 'Source_component_accepted', 'metadata_Source_accepted',
    'worker', 'worker_API', 'worker_offer', 'worker_handoff', 'metadata_Source',
    'module_pins', 'component_reviews', 'additional_current_guards'}
CAPS = dict(work_seconds=160, positive_seconds=180, custody_seconds=210,
    observer_fallback_seconds=225, memory_bytes=1073741824, physical_bytes=134217728,
    result_bytes=50331648, log_bytes=4194304, reserved_outer_bytes=9437184,
    root_callbacks=400000000)
CONFIGURATION = dict(schema='FPC-H1-obligation-configuration-v1', control_only=False,
    variables=8, term_depth=2, fallback_witness_nodes=9, obligation_nodes=512,
    priority_subformula_nodes=512, intro_depth=8, oldest_period=4, ordering='FOCUSED')


def fields(value, names):
    assert type(value) is dict and set(value) == set(names)
    return value


def pin_fields(value):
    fields(value, ('path', 'bytes', 'sha256'))
    assert type(value['path']) is str and Path(value['path']).is_absolute()
    assert str(Path(value['path'])) == value['path'] and '..' not in Path(value['path']).parts
    assert type(value['bytes']) is int and value['bytes'] >= 0
    digest = value['sha256']
    assert type(digest) is str and len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
    return value


def source_path(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path and not path.is_symlink()
    assert '/actual/' not in str(path) and not str(path).endswith('.observer/observer.json')
    assert path.suffix != '.bin' and '.partial' not in path.name
    assert path.name not in ('index.html', '.gcts-active')
    assert path.is_file()
    return path


def raw(path):
    return source_path(path).read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(Path(path)), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def exact(record):
    pin_fields(record)
    assert record == pin(record['path'])
    return record


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result
        result[key] = value
    return result


def invalid_constant(value):
    raise AssertionError('Nonfinite JSON constant: ' + value)


def load(record):
    exact(record)
    return json.loads(raw(record['path']), object_pairs_hook=no_duplicates,
                      parse_constant=invalid_constant)


def contains(value, sought):
    if value == sought:
        return True
    if type(value) is dict:
        return any(contains(v, sought) for v in value.values())
    if type(value) is list:
        return any(contains(v, sought) for v in value)
    return False


def js(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                       allow_nan=False) + '\n').encode('ascii')


def write(path, body):
    with path.open('xb') as stream:
        assert stream.write(body) == len(body)
    assert raw(path) == body


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--acceptance', required=True)
    parser.add_argument('--qualification', required=True)
    args = parser.parse_args()
    self_pin = pin(Path(__file__).resolve())
    acceptance_pin = pin(Path(args.acceptance))
    acceptance = fields(load(acceptance_pin), SOURCE_ACCEPTANCE_FIELDS)
    assert acceptance['schema'] == 'Root-frozen-target-contextual-study-Source-acceptance-v2'
    assert acceptance['Source_component_accepted'] is True and acceptance['metadata_Source_accepted'] is True
    assert acceptance['worker'] == WORKER_PIN and acceptance['worker_API'] == API_PIN
    assert acceptance['metadata_Source'] == self_pin
    assert Path(acceptance_pin['path']).parent == ROOT
    api = load(API_PIN)
    assert api['Source'] == WORKER_PIN and api['stage_literal'] == 'evaluation'
    assert api['ARMS'] == list(ARMS) and api['EXPERIMENT'] == 'frozen-target-contextual-reuse-v2'
    assert api['PROFILE'] == 'frozen-holdout0-contextual-reuse-v2'
    assert api['PROTOCOL_SCHEMA'] == 'Root-FPC-frozen-target-contextual-reuse-protocol-v2'
    assert api['limits'] == CAPS and api['configuration'] == CONFIGURATION
    assert api['control_populations'] == [] and api['qualification_rerun'] is False
    assert list(api['module_pins']) == list(ROLES)
    assert acceptance['module_pins'] == api['module_pins']
    assert api['input_authority'] == api['protocol_metadata_values']['input_authority']
    assert api['Source_components'] == api['protocol_metadata_values']['Source_components']
    assert api['protocol_metadata_values']['reference_integer_policy'] == ['FPC-original-json-integer-policy-v1', 4300]
    authority = fields(api['input_authority'], ('selection_authority', 'frozen_input_Root_admission',
        'input_carrier', 'target_path', 'target_identity', 'all3_snapshot_identity',
        'selection_snapshot_identity', 'inventory_Root_admission', 'inventory_C_review', 'library_result'))
    # Scientific body pins are compared only as metadata. No stat/read/hash/parse follows them.
    for name in ('input_carrier', 'library_result'):
        pin_fields(authority[name])
        assert '/actual/' in authority[name]['path']
    qualification_pin = pin(Path(args.qualification))
    assert Path(qualification_pin['path']).parent == ROOT
    qualification = fields(load(qualification_pin), Q_FIELDS)
    for record in qualification.values():
        pin_fields(record)
    for name in ('Root_admission', 'C_actual_review', 'plan'):
        assert qualification[name] == api['qualification']['fixed_admin_pins'][name]
    qroot = load(qualification['Root_admission'])
    qreview = load(qualification['C_actual_review'])
    qplan = load(qualification['plan'])
    assert qroot['schema'] == 'Root-ledger-bank3-v2case0-complete-whole-admission-v1'
    assert qroot['status'] == 'FINITE_LEDGER_NORMAL_MODE_CONTROLS_ADMITTED'
    assert qroot['qualification_admitted'] is True and qroot['resources_and_custody_accepted'] is True
    assert qroot['case_id'] == 'ledger-normal-mode-controls-v2-case-0'
    assert qroot['holdout_loaded'] is False and qroot['holdout_searched'] is False
    assert qroot['complete_C_review'] == qualification['C_actual_review']
    assert qreview['schema'] == 'C-ledger-bank3-v2case0-complete-whole-actual-review-v2'
    assert qreview['complete_review'] is True and qreview['blockers'] == []
    assert type(qreview['decision']) is dict
    assert qreview['decision']['eligible_for_Root_exact_finite_controls_qualification'] is True
    assert qreview['decision']['C_complete_whole_actual_evidence_assessment'] == 'PASS'
    assert type(qreview['subjects']) is dict
    assert pin_fields(qroot['plan']) == pin_fields(qreview['subjects']['plan']) == qualification['plan']
    owned = qreview['all_owned_files']
    assert type(owned) is list and len(owned) == 11
    owned_by_path = {}
    for record in owned:
        pin_fields(record)
        assert record['path'] not in owned_by_path
        owned_by_path[record['path']] = record
    for name in ('result', 'bank'):
        assert pin_fields(qroot[name]) == owned_by_path.get(qualification[name]['path']) == qualification[name]
    assert qplan['schema'] == 'proof-search-case-once-plan-v1'
    assert qplan['case_id'] == qroot['case_id'] and qplan['stage'] == 'qualification'
    fields(qplan['limits'], CAPS)
    assert all(type(qplan['limits'][name]) is int and qplan['limits'][name] == limit for name, limit in CAPS.items())
    assert pin_fields(qplan['python']) == api['custody_runtime']['python']
    assert type(qplan['module_pins']) is dict and set(qplan['module_pins']) == set(Q_ROLES)
    assert qroot['module_pins'] == qplan['module_pins']
    for name, record in qplan['module_pins'].items():
        pin_fields(record)
        if name in ROLES:
            assert record == api['module_pins'][name]
    # Deliberately do not load qualification result/bank or recursively collect the old plan's files.
    files = {}

    def include(record):
        exact(record)
        name = record['path']
        if name in files:
            assert files[name] == record
        else:
            files[name] = record

    reviews = fields(acceptance['component_reviews'], ('worker', 'metadata_Source'))
    for role, record in reviews.items():
        assert Path(record['path']).parent == STUDY / 'review-C'
        reviewed = load(record)
        assert reviewed['review_passed'] is True and reviewed['blockers'] == []
        assert contains(reviewed, WORKER_PIN if role == 'worker' else self_pin)
        include(record)
    for name in ('worker_offer', 'worker_handoff'):
        document = load(acceptance[name])
        assert contains(document, WORKER_PIN) and contains(document, API_PIN)
        include(acceptance[name])
    assert type(acceptance['additional_current_guards']) is list
    for record in list(api['module_pins'].values()) + list(api['custody_runtime'].values()) + api['Source_components'] + api['required_metadata_guards'] + acceptance['additional_current_guards']:
        include(record)
    for name in ('selection_authority', 'frozen_input_Root_admission', 'inventory_Root_admission', 'inventory_C_review'):
        include(authority[name])
    for record in (WORKER_PIN, API_PIN, self_pin, acceptance_pin, qualification_pin,
                   qualification['Root_admission'], qualification['C_actual_review'], qualification['plan']):
        include(record)
    recipes = [dict(case_id=api['EXPERIMENT'] + '-' + arm, stage='evaluation', arm=arm) for arm in ARMS]
    assert api['job_recipes'] == recipes and api['CASES'] == [r['case_id'] for r in recipes]
    protocol = dict(schema=api['PROTOCOL_SCHEMA'], experiment=api['EXPERIMENT'], limits=CAPS,
        module_pins=api['module_pins'], control_populations=[], job_recipes=recipes,
        metadata=dict(profile=api['PROFILE'], input_authority=authority,
            Source_components=api['Source_components'], reference_integer_policy=['FPC-original-json-integer-policy-v1', 4300],
            configuration=CONFIGURATION, qualification=qualification))
    assert set(protocol) == set(api['protocol_fields'])
    assert set(protocol['metadata']) == set(api['protocol_metadata_fields'])
    protocol_body = js(protocol)
    protocol_pin = dict(path=str(PROTOCOL), bytes=len(protocol_body), sha256=hashlib.sha256(protocol_body).hexdigest())
    assert str(PROTOCOL) not in files
    files[str(PROTOCOL)] = protocol_pin
    plans = []
    for recipe in recipes:
        case = recipe['case_id']
        plan_path = ROOT / 'plans' / (case + '.json')
        actual = STUDY / 'actual' / case
        assert not plan_path.exists() and not actual.exists() and not Path(str(actual) + '.observer').exists()
        plan = dict(schema='proof-search-case-once-plan-v1', case_id=case, stage='evaluation',
            experiment=api['EXPERIMENT'], actual_dir=str(actual), worker_path=WORKER_PIN['path'],
            runner_path=api['custody_runtime']['runner']['path'], python=api['custody_runtime']['python'],
            files=list(files.values()), limits=CAPS, protocol=protocol_pin, profile=api['PROFILE'],
            module_pins=api['module_pins'], input_authority=authority, Source_components=api['Source_components'],
            arm=recipe['arm'], qualification=qualification)
        assert set(plan) == set(api['PLAN_FIELDS'])
        plans.append((plan_path, js(plan)))
    assert not PROTOCOL.exists() and not PREPARATION.exists()
    (ROOT / 'plans').mkdir(exist_ok=True)
    write(PROTOCOL, protocol_body)
    for path, body in plans:
        write(path, body)
    preparation = dict(schema='Root-frozen-target-contextual-study-preparation-v2',
        status='PREPARED_METADATA_NO_GRANTS_NO_EXECUTION', Source_acceptance=acceptance_pin,
        qualification_metadata=qualification_pin, protocol=pin(PROTOCOL), plans=[pin(p) for p, _ in plans],
        serial_case_order=[r['case_id'] for r in recipes], Source_guard_count=len(files),
        scientific_data_bodies_read_or_hashed=False, qualification_result_or_bank_read=False,
        project_imports_or_calls=0, grants_issued=0, configuration=CONFIGURATION, limits=CAPS,
        scope='Three fixed serial target metadata plans only. No selector, query/library body intake, qualification replay, grant or actual. Independent whole-plan review and once gates remain required.')
    write(PREPARATION, js(preparation))
    print(json.dumps(pin(PREPARATION)))


if __name__ == '__main__':
    main()
