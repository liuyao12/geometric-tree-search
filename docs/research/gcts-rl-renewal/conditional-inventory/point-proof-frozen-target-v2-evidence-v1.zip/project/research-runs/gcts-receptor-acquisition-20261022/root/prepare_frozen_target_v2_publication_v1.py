"""Inert administrative explicit-manifest bundler; never a scientific validator."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse
import binascii
import hashlib
import io
import json
import math
import re
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
STAGE = ROOT / 'publication-frozen-target-v2-v1'
P2 = STUDY.parent / 'gcts-batch-20261020/publisher-recovery-6338a77'
PAYLOAD = P2 / 'publication-payload-frozen-target-v2-v1'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html',
         'point-proof-frozen-target-v2-summary-v1.json',
         'point-proof-frozen-target-v2-evidence-v1.zip')
MAX_OUTPUT = 100 * 1024 * 1024
MAX_ADMIN = 2 * 1024 * 1024
MAX_MEMBERS = 512
PIN_KEYS = {'path', 'bytes', 'sha256'}
MANIFEST_KEYS = {'schema', 'aggregate', 'baseline',
                 'direct_user_archive_authorization', 'summary', 'fragment',
                 'members', 'external_runtime'}
AUTHORITY_KEYS = {'schema', 'authorized', 'uses', 'Source', 'Source_review', 'manifest'}
CATEGORIES = {'source_guard', 'owned_evidence', 'provenance',
              'scientific_input_opaque', 'prior_evidence_archive'}
ARMS = ('NO_LIBRARY', 'CONDITIONAL_LEMMA_CD', 'RECEPTOR_DAG')
POSITIVE_FIELD_NAMES = ('qualification_provenance', 'input_freeze',
                        'library_provenance', 'producer_result',
                        'subject_receipt', 'reference_receipt', 'scientific_result')
PROTECTED_NAMES = {'index.html', '.gcts-active', 'GCTS-I.html',
                   'point-proof-discovered-proofs-v1.html'}
BASELINE = dict(path=str(ROOT / 'publication-ledger-qualification-v2' / NAMES[0]),
                bytes=124220,
                sha256='d476c15d342adc65621176f86e34921ba0631f8cacf4efebea70da86b186bb55')
ARCHIVE_PRIOR = dict(
    path=str(ROOT / 'publication-ledger-qualification-v2' /
             'point-proof-ledger-qualification-evidence-v2.zip'),
    bytes=18166216,
    sha256='3a7c5f3c9f45ede0d26a43db386ce60bc0a7200a7dfc36efee94cbd62616cc15')
ARCHIVE_AUTH = dict(
    path=str(ROOT / 'full-evidence-archive-direct-user-publication-authorization-v1.json'),
    bytes=1707,
    sha256='e8915b67f7125aad3842e118fd405e91f4d646d703edf589a10373ac539cf039')
SOURCE_CONTRACT = dict(
    path=str(ROOT / 'frozen-target-v2-publication-preparer-Source-CONTRACT-v1.json'),
    bytes=6958,
    sha256='89f750dfd16e2fe3889523e4c0a5b7c96b62f38fe197cce570ac5b12d85e80a8')
AGGREGATE = dict(
    path=str(ROOT / 'frozen-target-contextual-three-arm-Root-complete-whole-disposition-v2.json'),
    bytes=57269,
    sha256='0cf4ec7591574fd92e3e7b1d8a9e9aad061d9a74a07ff996e760b3fbc9994dba')
EXTERNAL_RUNTIME = dict(
    path='/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
    bytes=18058560,
    sha256='d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840')


class PreparerInputError(ValueError):
    pass


def need(test, message):
    if not test:
        raise PreparerInputError(message)


def pin_object(value):
    """Metadata only: this function never stats or reads a referenced path."""
    need(type(value) is dict and set(value) == PIN_KEYS, 'exact raw pin3')
    need(type(value['path']) is str and Path(value['path']).is_absolute(), 'absolute pin path')
    need(type(value['bytes']) is int and 0 <= value['bytes'] <= MAX_OUTPUT, 'exact bounded byte count')
    need(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None,
         'exact lowercase SHA256')
    return dict(value)


def input_path(value):
    need(type(value) is str and str(Path(value)) == value, 'canonical path spelling')
    path = Path(value)
    need(path.is_absolute() and path.is_relative_to(REPO), 'repository input only')
    need(not any(part.startswith('.') or part in ('.', '..') for part in path.parts),
         'no hidden or traversal path component')
    need(path.name not in PROTECTED_NAMES and '.partial' not in path.name, 'protected/partial input forbidden')
    need(path.resolve() == path and path.is_file() and not path.is_symlink(), 'resolved regular input')
    return path


def read_raw(path):
    path = input_path(str(path))
    size = path.stat().st_size
    need(size <= MAX_OUTPUT, 'bounded raw input')
    body = path.read_bytes()
    need(len(body) == size, 'raw input size stable')
    return body


def raw_pin(path):
    path = input_path(str(path))
    body = read_raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read_pinned(record):
    record = pin_object(record)
    body = read_raw(record['path'])
    need(len(body) == record['bytes'] and hashlib.sha256(body).hexdigest() == record['sha256'],
         'complete raw pin mismatch')
    return body


def reject_constant(value):
    raise PreparerInputError('nonfinite JSON constant ' + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate administrative JSON key')
        result[key] = value
    return result


def finite_json(value, depth=0):
    need(depth <= 64, 'bounded administrative JSON depth')
    if value is None or type(value) in (bool, int, str):
        return
    if type(value) is float:
        need(math.isfinite(value), 'finite administrative float')
        return
    need(type(value) in (dict, list), 'ordinary JSON carrier')
    for item in value.values() if type(value) is dict else value:
        finite_json(item, depth + 1)


def object_bytes(body):
    need(len(body) <= MAX_ADMIN, 'bounded administrative object')
    value = json.loads(body, object_pairs_hook=unique_object, parse_constant=reject_constant)
    need(type(value) is dict, 'administrative JSON object')
    finite_json(value)
    return value


def administrative(record):
    path = input_path(pin_object(record)['path'])
    need(path.is_relative_to(STUDY) and not path.is_relative_to(STUDY / 'actual'),
         'administrative object outside actual data')
    return object_bytes(read_pinned(record))


def json_bytes(value):
    finite_json(value)
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def contains_pin(value, wanted):
    if type(value) is dict:
        if value == wanted:
            return True
        return any(contains_pin(item, wanted) for item in value.values())
    if type(value) is list:
        return any(contains_pin(item, wanted) for item in value)
    return False


def pin_map(records):
    need(type(records) is list, 'explicit pin vector')
    result = {}
    for item in records:
        ref = pin_object(item)
        need(ref['path'] not in result, 'duplicate original path in authority vector')
        result[ref['path']] = ref
    return result


def validate_aggregate(aggregate):
    need(aggregate.get('schema') == 'Root-frozen-target-contextual-three-arm-complete-whole-disposition-v2',
         'exact aggregate schema')
    need(aggregate.get('status') == 'ALL_THREE_ONCE_CONTROLLED_SEARCH_MEMORY_FAILURES_NOT_ADMITTED',
         'complete three-arm negative aggregate required')
    need(aggregate.get('complete_aggregate') is True and
         aggregate.get('complete_all3_C_reviews_read') is True and
         aggregate.get('all_three_failed_during_search') is True and
         aggregate.get('all_original_actuals_immutable') is True and
         aggregate.get('all_new_grants_consumed') is True, 'complete adopted immutable aggregate')
    for key in ('normal_returns', 'new_proofs_admitted', 'contextual_uses_admitted',
                'qualified_resource_results', 'case_retries'):
        need(type(aggregate.get(key)) is int and aggregate[key] == 0, 'exact zero aggregate admission counter')
    cases = aggregate.get('cases')
    need(type(cases) is list and len(cases) == 3 and
         all(type(row) is dict for row in cases) and
         tuple(row.get('arm') for row in cases) == ARMS, 'exact ordered arms')
    case_ids = []
    for row in cases:
        for key in ('scientific_case_accepted', 'proof_admitted', 'contextual_use_admitted',
                    'resource_qualified', 'normal_return'):
            need(row.get(key) is False, 'negative case admission/return flag')
        need(type(row.get('all7_positive_fields_null')) is list and
             tuple(row['all7_positive_fields_null']) == POSITIVE_FIELD_NAMES and
             type(row.get('owned_files')) is int and row['owned_files'] == 11,
             'exact seven null-field names and complete owned census')
        case_id = row.get('case_id')
        need(type(case_id) is str and re.fullmatch('[A-Za-z0-9_-]+', case_id) is not None,
             'safe explicit case identity')
        case_ids.append(case_id)
    need(len(set(case_ids)) == 3, 'distinct three cases')
    guards = pin_map(aggregate.get('all65_common_guard_records'))
    need(len(guards) == 65 and aggregate.get('python') == EXTERNAL_RUNTIME and
         guards.get(EXTERNAL_RUNTIME['path']) == EXTERNAL_RUNTIME, '65 guards with exact external D90 metadata')
    del guards[EXTERNAL_RUNTIME['path']]
    owned = pin_map(aggregate.get('all_owned_files'))
    need(len(owned) == 33 and aggregate.get('owned_files') == 33 and
         sum(ref['bytes'] for ref in owned.values()) == aggregate.get('owned_bytes'), 'complete 33-owned vector')
    for case_id in case_ids:
        case_root = STUDY / 'actual' / case_id
        observer_root = STUDY / 'actual' / (case_id + '.observer')
        selected = [ref for ref in owned.values()
                    if Path(ref['path']).parent in (case_root, observer_root)]
        need(len(selected) == 11, 'exact 11 files per declared case and observer')
    authority = aggregate.get('input_authority')
    need(type(authority) is dict, 'administrative input authority')
    scientific = pin_map([authority['input_carrier'], authority['library_result']])
    need(len(scientific) == 2, 'two exact opaque scientific inputs')
    return guards, owned, scientific


def required_provenance(aggregate, source, source_review, manifest):
    result = {}

    def add(record):
        record = pin_object(record)
        old = result.get(record['path'])
        need(old is None or old == record, 'consistent explicit provenance pin')
        result[record['path']] = record

    for record in (source, source_review, SOURCE_CONTRACT, AGGREGATE, BASELINE, ARCHIVE_AUTH,
                   manifest['summary'], manifest['fragment']):
        add(record)
    for key in ('Root_whole_prospective_adoption', 'complete_C_Source_review',
                'complete_C_prospective_review', 'master', 'protocol',
                'publication_preparer_contract', 'whole_Source_acceptance'):
        add(aggregate[key])
    for case in aggregate['cases']:
        for key in ('Root_disposition', 'complete_C_review', 'C_complete_actual_audit',
                    'Root_raw_actual_audit', 'Root_once_acceptance', 'consumed_grant', 'plan'):
            add(case[key])
    for key in ('C_actual_review', 'Root_admission', 'plan'):
        add(aggregate['qualification'][key])
    for key in ('frozen_input_Root_admission', 'inventory_C_review',
                'inventory_Root_admission', 'selection_authority'):
        add(aggregate['input_authority'][key])
    return result


def validate_members(manifest, aggregate, source, source_review, manifest_path, authority_path):
    guards, owned, scientific = validate_aggregate(aggregate)
    entries = manifest['members']
    need(type(entries) is list and 100 <= len(entries) <= MAX_MEMBERS, 'bounded explicit member vector')
    selected = {}
    archive_names = set()
    category_maps = {category: {} for category in CATEGORIES}
    for row in entries:
        need(type(row) is dict and set(row) == {'rawpin', 'archive_path', 'category'}, 'exact member record3')
        category = row['category']
        need(type(category) is str and category in CATEGORIES, 'fixed archive category')
        ref = pin_object(row['rawpin'])
        path = input_path(ref['path'])
        need(path not in (manifest_path, authority_path), 'manifest/authority self-hash cycle forbidden')
        name = row['archive_path']
        expected = 'project/' + path.relative_to(REPO).as_posix()
        need(type(name) is str and name == expected and '\\' not in name and
             not PurePosixPath(name).is_absolute() and
             '..' not in PurePosixPath(name).parts and name != 'catalog.json', 'exact safe project member path')
        need(ref['path'] not in selected and name not in archive_names, 'duplicate original or archive path')
        if category == 'provenance':
            need(path.is_relative_to(STUDY) and not path.is_relative_to(STUDY / 'actual'),
                 'explicit study provenance, never actual scientific bodies')
        selected[ref['path']] = dict(rawpin=ref, archive_path=name, category=category)
        category_maps[category][ref['path']] = ref
        archive_names.add(name)
    need(category_maps['source_guard'] == guards, 'exact 64 selected source/admin guards')
    need(category_maps['owned_evidence'] == owned, 'exact 33 owned original files')
    need(category_maps['scientific_input_opaque'] == scientific, 'exact two opaque carrier/library pins')
    need(category_maps['prior_evidence_archive'] == {ARCHIVE_PRIOR['path']: ARCHIVE_PRIOR},
         'exact single complete opaque prior archive')
    for path, ref in required_provenance(aggregate, source, source_review, manifest).items():
        need(path in selected and selected[path]['rawpin'] == ref, 'complete explicit required provenance')
        need(selected[path]['category'] in ('source_guard', 'provenance'), 'provenance category association')
    need(sum(row['rawpin']['bytes'] for row in selected.values()) <= MAX_OUTPUT,
         'bounded total original raw input bytes')
    return sorted(selected.values(), key=lambda row: row['archive_path'])


class ArchiveBuffer(io.BytesIO):
    def write(self, body):
        need(self.tell() + len(body) <= MAX_OUTPUT, 'bounded in-memory archive extent')
        return super().write(body)


def write_complete(path, body):
    need(len(body) <= MAX_OUTPUT, 'bounded complete output')
    with path.open('xb') as stream:
        stream.write(body)
    need(read_raw(path) == body, 'complete output readback')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--authority', required=True)
    args = parser.parse_args()
    authority_path = input_path(args.authority)
    need(authority_path.is_relative_to(ROOT), 'Root administrative authority only')
    authority_body = read_raw(authority_path)
    authority = object_bytes(authority_body)
    need(set(authority) == AUTHORITY_KEYS and
         authority['schema'] == 'Root-frozen-target-v2-publication-preparer-admin-once-authority-v1' and
         authority['authorized'] is True and
         type(authority['uses']) is int and authority['uses'] == 1, 'exact one-use administrative authority')
    source = pin_object(authority['Source'])
    need(source['path'] == str(Path(__file__).resolve()), 'current preparer identity')
    read_pinned(source)
    source_review = pin_object(authority['Source_review'])
    reviewed = administrative(source_review)
    need(reviewed.get('review_passed') is True and reviewed.get('blockers') == [] and
         contains_pin(reviewed, source), 'complete Source review of this exact preparer')
    manifest_ref = pin_object(authority['manifest'])
    manifest_path = input_path(manifest_ref['path'])
    need(manifest_path.is_relative_to(ROOT), 'Root manifest only')
    manifest = administrative(manifest_ref)
    need(set(manifest) == MANIFEST_KEYS and
         manifest['schema'] == 'Root-frozen-target-v2-publication-manifest-v1', 'exact manifest8')
    need(manifest['aggregate'] == AGGREGATE and manifest['baseline'] == BASELINE and
         manifest['direct_user_archive_authorization'] == ARCHIVE_AUTH and
         manifest['external_runtime'] == EXTERNAL_RUNTIME, 'fixed aggregate/baseline/authorization/runtime metadata')
    aggregate = administrative(AGGREGATE)
    auth = administrative(ARCHIVE_AUTH)
    need(auth.get('direct_human_answer') == 'Approve publishing the full archive', 'explicit human full-archive authority')
    summary_ref = pin_object(manifest['summary'])
    fragment_ref = pin_object(manifest['fragment'])
    need(input_path(summary_ref['path']).is_relative_to(ROOT) and
         input_path(fragment_ref['path']).is_relative_to(ROOT), 'Root-authored summary and fragment')
    summary_body = read_pinned(summary_ref)
    object_bytes(summary_body)
    fragment_body = read_pinned(fragment_ref)
    need(len(fragment_body) <= MAX_ADMIN, 'bounded HTML fragment')
    fragment = fragment_body.decode('utf-8')
    need(fragment and '<section' in fragment.lower() and
         re.search(r'<\s*/?\s*(html|body|main|script)(?:\s|>)', fragment, re.I) is None,
         'scriptless section fragment without document/main wrappers')
    baseline_body = read_pinned(BASELINE)
    baseline = baseline_body.decode('utf-8')
    need(baseline.count('<main>') == 1, 'unique exact main insertion anchor')
    need(fragment not in baseline, 'new unique fragment')
    page = baseline.replace('<main>', '<main>' + fragment, 1).encode('utf-8')
    need(page.decode('utf-8').replace('<main>' + fragment, '<main>', 1).encode('utf-8') == baseline_body,
         'exact insert-only baseline inverse')
    entries = validate_members(manifest, aggregate, source, source_review, manifest_path, authority_path)
    need(not STAGE.exists() and not PAYLOAD.exists(), 'fresh fixed Root/P2 directories')
    authority_pin = dict(path=str(authority_path), bytes=len(authority_body),
                         sha256=hashlib.sha256(authority_body).hexdigest())
    consumed = json_bytes(dict(schema='Root-frozen-target-v2-preparer-admin-consumed-v1',
                               uses=1, authority=authority_pin, Source=source,
                               Source_review=source_review, manifest=manifest_ref,
                               scientific_execution=False,
                               scope='Administrative invocation consumed; incomplete output is not publishable.'))
    STAGE.mkdir()
    write_complete(STAGE / 'ADMIN-ONCE-CONSUMED.json', consumed)
    PAYLOAD.mkdir()
    bodies = {}
    census = []
    for row in entries:
        body = read_pinned(row['rawpin'])
        bodies[row['archive_path']] = body
        census.append(dict(**row, CRC32=f'{binascii.crc32(body) & 0xffffffff:08x}'))
    catalog = dict(schema='Root-frozen-target-v2-evidence-catalog-v1',
                   issued_utc=datetime.now(timezone.utc).isoformat(),
                   authority=authority_pin, administrative_authority=authority,
                   manifest=manifest_ref, administrative_manifest=manifest,
                   Source=source, Source_review=source_review, aggregate=AGGREGATE,
                   direct_user_archive_authorization=ARCHIVE_AUTH,
                   members=census, external_runtime=EXTERNAL_RUNTIME,
                   runtime_association_only=True, scientific_execution=False,
                   scope='Only exact explicit manifest originals. Two scientific inputs and prior archive are opaque; no semantic proof/result decoder, recursive citation closure or scientific admission.')
    catalog_body = json_bytes(catalog)
    buffer = ArchiveBuffer()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, body in [('catalog.json', catalog_body)] + list(bodies.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 26, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    archive_body = buffer.getvalue()
    buffer.close()
    with zipfile.ZipFile(io.BytesIO(archive_body), 'r') as bundle:
        need(bundle.testzip() is None, 'complete archive CRC')
        need(len(bundle.namelist()) == len(entries) + 1 and
             set(bundle.namelist()) == set(bodies) | {'catalog.json'}, 'exact unique archive census')
        need(bundle.read('catalog.json') == catalog_body, 'complete catalog readback')
        for row in entries:
            name = row['archive_path']
            need(bundle.read(name) == bodies[name] == read_pinned(row['rawpin']),
                 'complete archive/current original body readback')
            need(bundle.getinfo(name).CRC == int(next(x['CRC32'] for x in census
                                                     if x['archive_path'] == name), 16), 'original member CRC')
    payload_bodies = (page, summary_body, archive_body)
    rows = []
    for name, body in zip(NAMES, payload_bodies):
        rows.append(dict(path=PREFIX + name, root_source=str(STAGE / name),
                         publisher_source=str(PAYLOAD / name), bytes=len(body),
                         sha256=hashlib.sha256(body).hexdigest(),
                         git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()))
    staging = json_bytes(dict(
        schema='Root-frozen-target-v2-three-path-staging-v1', scientific_execution=False,
        aggregate=AGGREGATE, baseline=BASELINE, summary=summary_ref, fragment=fragment_ref,
        direct_user_archive_authorization=ARCHIVE_AUTH, authority=authority_pin,
        manifest=manifest_ref, Source=source, Source_review=source_review,
        files=rows, archive_entries=len(entries) + 1, archive_members_verified=True,
        catalog=dict(bytes=len(catalog_body), sha256=hashlib.sha256(catalog_body).hexdigest()),
        external_runtime=EXTERNAL_RUNTIME, runtime_association_only=True,
        scope='Complete adopted three-arm negative publication inputs only; no proof/use/resource admission, replay or scientific validation. Final content/visual/publication/live review separate.'))
    need(len(consumed) + len(staging) + 2 * sum(len(body) for body in payload_bodies) <= MAX_OUTPUT,
         'total physical Root/P2/admin output at most 100MiB')
    for name, body in zip(NAMES, payload_bodies):
        write_complete(STAGE / name, body)
        write_complete(PAYLOAD / name, body)
    write_complete(STAGE / 'P2-staging.json', staging)
    need(set(path.name for path in PAYLOAD.iterdir()) == set(NAMES), 'exact three P2 payload files')
    print(json.dumps(raw_pin(STAGE / 'P2-staging.json'), sort_keys=True))


if __name__ == '__main__':
    main()
