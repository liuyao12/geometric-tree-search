"""Administrative read-only normal-TLS verification of the exact three current publication bodies."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = 'https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html', 'point-proof-frozen-target-v2-summary-v1.json', 'point-proof-frozen-target-v2-evidence-v1.zip')
parser = argparse.ArgumentParser()
parser.add_argument('--commit', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
assert re.fullmatch('[0-9a-f]{40}', args.commit)
out = Path(args.output)
assert out.parent == ROOT and not out.exists()
out.mkdir()
staging = json.loads((ROOT / 'publication-frozen-target-v2-v1/P2-staging.json').read_bytes())
assert [row['path'] for row in staging['files']] == [PREFIX + name for name in NAMES]
refs = [dict(name=Path(row['path']).name, bytes=row['bytes'], sha256=row['sha256'], kind='CURRENT') for row in staging['files']]
results = []
for ref in refs:
    target = out / ref['name']
    url = BASE + ref['name'] + '?v=' + args.commit
    proc = subprocess.run(['curl', '--fail', '--show-error', '--silent', '--location',
        '--proto', '=https', '--proto-redir', '=https', '--tlsv1.2', '--connect-timeout', '15',
        '--max-time', '45', '--output', str(target), url],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if proc.returncode:
        with (out / 'curl-failure.json').open('x') as stream:
            json.dump(dict(url=url, returncode=proc.returncode,
                stderr=proc.stderr.decode(errors='replace')), stream, indent=2)
            stream.write('\n')
        raise RuntimeError('Read-only HTTPS verification failed; no insecure fallback')
    body = target.read_bytes()
    assert dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest()) == {
        k: ref[k] for k in ('bytes', 'sha256')}, ref['name']
    results.append(dict(**ref, url=url, match=True))
    print(ref['name'] + ': MATCH', flush=True)
with (out / 'verification.json').open('x') as stream:
    json.dump(dict(schema='Root-frozen-target-v2-live-TLS-verification-v1',
        commit=args.commit, all_three_match=True, normal_TLS=True, certificate_bypass=False,
        files=results, scientific_calls=0), stream, indent=2)
    stream.write('\n')
