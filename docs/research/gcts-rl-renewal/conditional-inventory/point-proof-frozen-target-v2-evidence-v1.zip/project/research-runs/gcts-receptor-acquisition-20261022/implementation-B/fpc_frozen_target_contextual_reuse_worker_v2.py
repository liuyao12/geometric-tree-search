"""Inert frozen-target contextual reuse caller. Source only until reviewed once."""
from pathlib import Path


import hashlib


import importlib.util


import json


import math


import os


import resource


import sys


import time


import traceback


class RootBudget(RuntimeError):
    """Genuine whole-caller resource or complete-output ceiling."""


def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    stream = None
    primary = None
    try:
        stream = temporary.open('xb')
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    temporary.replace(path)


def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module


def _validate_json_image(value, check):
    """Validate only; no copied tree, coercion, memo cache or codec-private API."""
    active = set()
    stack = [('node', value, None, 0)]
    while stack:
        check()
        action, item, keys, index = stack.pop()
        if action == 'node':
            kind = type(item)
            if item is None or kind is bool or kind is int or kind is str:
                continue
            if kind is float:
                if not math.isfinite(item):
                    raise ValueError('finite original JSON-image float required')
                continue
            if not (kind is list or kind is tuple or kind is dict):
                raise ValueError('exact original JSON-image type required')
            identity = id(item)
            if identity in active:
                raise ValueError('active original JSON-image cycle refused')
            active.add(identity)
            if kind is dict:
                keys = []
                for key in item:
                    check()
                    if type(key) is not str:
                        raise ValueError('all exactstr keys required before lookup')
                    keys.append(key)
                stack.append(('object', item, keys, 0))
            else:
                stack.append(('array', item, None, 0))
        elif index == len(item):
            active.remove(id(item))
        else:
            # The node/edge checkpoint above precedes each child lookup.
            stack.append((action, item, keys, index + 1))
            child = item[keys[index]] if action == 'object' else item[index]
            stack.append(('node', child, None, 0))


def _checked_byte_equal(left, right, check):
    if len(left) != len(right):
        return False
    for offset in range(0, len(left), 65536):
        check()
        if left[offset:offset + 65536] != right[offset:offset + 65536]:
            return False
    return True


def _write_bank_and_readback(path, body, check, progress):
    """New positive IO only. Close cannot replace an earlier actual E."""
    temporary = path.with_name(path.name + '.partial')
    check()
    if path.exists():
        raise ValueError('exclusive new bank artifact required')
    stream = None
    primary = None
    try:
        check()
        stream = temporary.open('xb')
        progress['phase'] = 'WRITING_PARTIAL'
        offset = 0
        while offset < len(body):
            check()
            chunk = body[offset:offset + 65536]
            written = stream.write(chunk)
            if type(written) is not int or not 0 < written <= len(chunk):
                raise ValueError('complete bounded bank write required')
            offset += written
        check()
        stream.flush()
        check()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    temporary.replace(path)
    progress['phase'] = 'PUBLISHED_PROVISIONAL'
    stream = None
    primary = None
    try:
        check()
        stream = path.open('rb')
        digest = hashlib.sha256()
        offset = 0
        while offset < len(body):
            check()
            chunk = stream.read(min(65536, len(body) - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('complete original bank readback required')
            check()
            if chunk != body[offset:offset + len(chunk)]:
                raise ValueError('exact original bank readback mismatch')
            check()
            digest.update(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'':
            raise ValueError('original bank readback strict EOF required')
        answer = dict(bytes=offset, sha256=digest.hexdigest())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    progress['phase'] = 'READBACK_COMPLETE'
    progress['readback_complete'] = True
    return answer


def _keys(value, names, check):
    check()
    if type(value) is not dict or len(value) != len(names):
        raise ValueError('exact plain object carrier required')
    for key in value:
        check()
        if type(key) is not str:
            raise ValueError('exactstr keys required before membership or lookup')
    if set(value) != set(names):
        raise ValueError('exact public object fields required')


def _natural(value):
    return type(value) is int and value >= 0


def _digest(body, check):
    if type(body) is not bytes:
        raise ValueError('original immutable byte body required')
    digest = hashlib.sha256()
    for offset in range(0, len(body), 65536):
        check()
        digest.update(body[offset:offset + 65536])
    check()
    return dict(bytes=len(body), sha256=digest.hexdigest())


def _same(left, right, check):
    """Checked exact JSON-image association; list/tuple denote one array image."""
    stack = [(left, right)]
    while stack:
        check()
        a, b = stack.pop()
        ak, bk = type(a), type(b)
        aa, ba = ak is list or ak is tuple, bk is list or bk is tuple
        if aa or ba:
            if not (aa and ba and len(a) == len(b)):
                return False
            for index in range(len(a) - 1, -1, -1):
                check()
                stack.append((a[index], b[index]))
        elif ak is dict or bk is dict:
            if not (ak is dict and bk is dict and len(a) == len(b)):
                return False
            for key in a:
                check()
                if type(key) is not str or key not in b:
                    return False
                stack.append((a[key], b[key]))
        elif ak is not bk:
            return False
        elif ak is str or ak is bytes:
            if not _checked_byte_equal(a, b, check):
                return False
        elif a is None or ak is bool or ak is int or ak is float:
            if ak is float and (not math.isfinite(a) or not math.isfinite(b)):
                raise ValueError('finite exact JSON-image equality required')
            if a != b:
                return False
        else:
            raise ValueError('ordinary exact JSON-image equality required')
    return True


def _read_original(row, check):
    expected = pin_fields(row)
    path = Path(expected['path'])
    check()
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete declared original required')
    stream, primary, chunks = None, None, []
    try:
        check()
        stream = path.open('rb')
        offset, digest = 0, hashlib.sha256()
        while offset < expected['bytes']:
            check()
            chunk = stream.read(min(65536, expected['bytes'] - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('entire declared original read required')
            check()
            digest.update(chunk)
            chunks.append(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'' or digest.hexdigest() != expected['sha256']:
            raise ValueError('original full raw length/hash/EOF association required')
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    answer = b''.join(chunks)
    check()
    return answer



VERSION = 'FPC-frozen-target-contextual-reuse-worker-v2'
EXPERIMENT = 'frozen-target-contextual-reuse-v2'
PROFILE = 'frozen-holdout0-contextual-reuse-v2'
PROTOCOL_SCHEMA = 'Root-FPC-frozen-target-contextual-reuse-protocol-v2'
ARMS = ('NO_LIBRARY', 'CONDITIONAL_LEMMA_CD', 'RECEPTOR_DAG')
CASES = ('frozen-target-contextual-reuse-v2-NO_LIBRARY',
 'frozen-target-contextual-reuse-v2-CONDITIONAL_LEMMA_CD',
 'frozen-target-contextual-reuse-v2-RECEPTOR_DAG')
MODULE_ROLES = ('checker', 'builders', 'reference', 'instance', 'consumer')
MODULE_PINS = {'checker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_byte_checker_v1.py',
             'bytes': 31557,
             'sha256': '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'},
 'builders': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_ast_and_builders_v1.py',
              'bytes': 11348,
              'sha256': 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'},
 'reference': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_reference_v2.py',
               'bytes': 24681,
               'sha256': 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'},
 'instance': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_instance_service_v2.py',
              'bytes': 46609,
              'sha256': '7b7ca98d3e3dd2e48680d5f499594a8ec7322753bf7a6e8511d5cc667526fae9'},
 'consumer': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_contextual_library_producer_v3.py',
              'bytes': 153867,
              'sha256': '040ab9c296f709177c87a4e87b8c709acc58475c5266043cbccf99a4485fca4d'}}
MODULE_VERSIONS = {'checker': 'FPC-H1-BYTE-CHECKER-v1',
 'builders': 'FPC-H1-AST-BUILDERS-v1',
 'reference': 'FPC-H1-independent-flat-reference-v2',
 'instance': 'FPC-RECEPTOR-INSTANCE-SERVICE-v2',
 'consumer': 'FPC-H1-CONTEXTUAL-LIBRARY-PRODUCER-v2'}
PUBLIC_ENTRIES = {'checker': ('decode_query', 'check_certificate'),
 'builders': ('logical_axiom', 'pa_induction'),
 'reference': ('reference_check_certificate',),
 'instance': ('match_receptor',),
 'consumer': ('search_with_library',)}
CAPS = {'custody_seconds': 210,
 'log_bytes': 4194304,
 'memory_bytes': 1073741824,
 'observer_fallback_seconds': 225,
 'physical_bytes': 134217728,
 'positive_seconds': 180,
 'reserved_outer_bytes': 9437184,
 'result_bytes': 50331648,
 'root_callbacks': 400000000,
 'work_seconds': 160}
CUSTODY_RUNTIME = {'runner': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/run_conditional_once_v1.py',
            'bytes': 12973,
            'sha256': '98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'},
 'observer': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/observe_conditional_once_v1.py',
              'bytes': 10113,
              'sha256': '24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'},
 'python': {'bytes': 18058560,
            'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
            'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}}
POLICY_BINDING = ('FPC-original-json-integer-policy-v1', 4300)
PLAN_FIELDS = ('schema',
 'case_id',
 'stage',
 'experiment',
 'actual_dir',
 'worker_path',
 'runner_path',
 'python',
 'files',
 'limits',
 'protocol',
 'profile',
 'module_pins',
 'input_authority',
 'Source_components',
 'arm',
 'qualification')
QUALIFICATION_FIELDS = ('Root_admission', 'C_actual_review', 'plan', 'result', 'bank')
QUERY_FIELDS = ('version',
 'claim_mode',
 'function_arities',
 'predicate_arities',
 'theory_profile',
 'finite_axioms',
 'Gamma',
 'goal')
CONFIGURATION = {'schema': 'FPC-H1-obligation-configuration-v1',
 'control_only': False,
 'variables': 8,
 'term_depth': 2,
 'fallback_witness_nodes': 9,
 'obligation_nodes': 512,
 'priority_subformula_nodes': 512,
 'intro_depth': 8,
 'oldest_period': 4,
 'ordering': 'FOCUSED'}
POSITIVE_FIELDS = ('qualification_provenance',
 'input_freeze',
 'library_provenance',
 'producer_result',
 'subject_receipt',
 'reference_receipt',
 'scientific_result')
INPUT_AUTHORITY = {'selection_authority': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-input-authority-v1.json',
                         'bytes': 11909,
                         'sha256': '6c0c25d3163411efc666bdc147df41213b26725f6fe9368b9ad53c10f0b48b44'},
 'frozen_input_Root_admission': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-0-Root-complete-whole-admission-v1.json',
                                 'bytes': 8205,
                                 'sha256': '5e43a84fb44d32dc78aba88456d73524b94eb5895e3b591b5abdddbafb6d3570'},
 'input_carrier': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-0/result.json',
                   'bytes': 9300972,
                   'sha256': '8d8d97d5935c709687491f80f2a7b5236a7da31bf2a61fa712ee652e48b62375'},
 'target_path': ['input_freeze', 'slots', 'holdout0', 'query_hex'],
 'target_identity': {'bytes': 38,
                     'sha256': '8e56b3ed583f537881ffebcd40dc32443e5b0e204e52a978f9b7e65ee6104f24'},
 'all3_snapshot_identity': {'bytes': 10047,
                            'sha256': '1c5d387554e93e8714f72c71c348900ffdaadc03a05bac833517484177307182'},
 'selection_snapshot_identity': {'bytes': 188021,
                                 'sha256': 'd509ab8b76083ddba1260850aa424711fa0791ab339b56e0688594635c2f28c5'},
 'inventory_Root_admission': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/stratified-schema-acquisition-case-0-Root-complete-whole-admission-v1.json',
                              'bytes': 14751,
                              'sha256': 'b9b1a195df2c2e0133262a92af632b0d450d9d50fa7450e288c660a6c8f57290'},
 'inventory_C_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-stratified-schema-acquisition-case-0-complete-whole-actual-review-v1.json',
                        'bytes': 40739,
                        'sha256': '4bb3d4d08f4d41eae7e56a3a1919452c1b4c85f976b8a6d2f7dae8038b2d1ee5'},
 'library_result': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/two-admitted-donor-stratified-schema-acquisition-v1-case-0/result.json',
                    'bytes': 25788552,
                    'sha256': '193dfcc28a34206512f916aa3f574d9ed11f16d539dafd16c82d46dc2eef546a'}}
SOURCE_COMPONENTS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/frozen-target-contextual-reuse-Source-CONTRACT-v1.json',
  'bytes': 7418,
  'sha256': 'cfac145a5a6236d446321db30fe73bea52c6c8fbe903d8b47beeb63fb3192c15'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/frozen-target-input-cost-and-qualification-ABI-v1.json',
  'bytes': 3035,
  'sha256': 'aadd98fb8f687c329e72ea0f7185f884536bcbefd33861146facf171ae73b0e6'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/contextual-library-consumer-Root-Source-acceptance-v1.json',
  'bytes': 2099,
  'sha256': 'b95f493b6857e77b974553967906b756a5027db3fe8039790b770bed79215255'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/contextual-library-consumer-Source-handoff-v1.json',
  'bytes': 3221,
  'sha256': 'aa81971327f500a88d636c3504af5bdfaf31f577a0042b6bfce2ccff34d867b4'}]
REQUIRED_METADATA_GUARDS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/frozen-target-contextual-reuse-Source-CONTRACT-v1.json',
  'bytes': 7418,
  'sha256': 'cfac145a5a6236d446321db30fe73bea52c6c8fbe903d8b47beeb63fb3192c15'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/frozen-target-input-cost-and-qualification-ABI-v1.json',
  'bytes': 3035,
  'sha256': 'aadd98fb8f687c329e72ea0f7185f884536bcbefd33861146facf171ae73b0e6'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/contextual-library-consumer-Root-Source-acceptance-v1.json',
  'bytes': 2099,
  'sha256': 'b95f493b6857e77b974553967906b756a5027db3fe8039790b770bed79215255'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/contextual-library-consumer-Source-handoff-v1.json',
  'bytes': 3221,
  'sha256': 'aa81971327f500a88d636c3504af5bdfaf31f577a0042b6bfce2ccff34d867b4'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/contextual-library-consumer-public-ABI-v1.json',
  'bytes': 13323,
  'sha256': 'b660eba1f568ece8085954d963b1bf490e420d86f6d589a8e46d637985b94d9c'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/contextual-library-consumer-manual-v1.json',
  'bytes': 8689,
  'sha256': 'dab2552b7c1510a210c3952c31a1a6fc191ed0c247f97fc77fdda06236695529'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/contextual_controls_worker_v1.py',
  'bytes': 31005,
  'sha256': '0f66ab577b8247839e53a3746bea7463aa41c023965fc0734a9ebbf9216135b1'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-contextual-controls-worker-and-metadata-complete-Source-review-v1.json',
  'bytes': 9289,
  'sha256': '69d0fd786eaf5f75ec3a281ba98568e8a0d6394f367c4459414ccd1b1c0399d0'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md',
  'bytes': 21657,
  'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-input-authority-v1.json',
  'bytes': 11909,
  'sha256': '6c0c25d3163411efc666bdc147df41213b26725f6fe9368b9ad53c10f0b48b44'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-0-Root-complete-whole-admission-v1.json',
  'bytes': 8205,
  'sha256': '5e43a84fb44d32dc78aba88456d73524b94eb5895e3b591b5abdddbafb6d3570'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/stratified-schema-acquisition-case-0-Root-complete-whole-admission-v1.json',
  'bytes': 14751,
  'sha256': 'b9b1a195df2c2e0133262a92af632b0d450d9d50fa7450e288c660a6c8f57290'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-stratified-schema-acquisition-case-0-complete-whole-actual-review-v1.json',
  'bytes': 40739,
  'sha256': '4bb3d4d08f4d41eae7e56a3a1919452c1b4c85f976b8a6d2f7dae8038b2d1ee5'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/frozen-target-contextual-reuse-Source-CONTRACT-v2.json',
  'bytes': 11306,
  'sha256': '598f845d10c872e20f4bfec71e789676ada175b69ae3f1dd9c98b83a303b5e2a'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/frozen-target-v2-current-metadata-lineage-Root-addendum-v1.json',
  'bytes': 3983,
  'sha256': '305b945ff046e583a57ef270759af952e775fe0e49d331cfc4b705fe4803598e'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/contextual-library-consumer-public-ABI-v3.json',
  'bytes': 19981,
  'sha256': 'c17ab5585e63be3213fd73987c6dd2ff5025680ade8a4e43c1c1341d7ce9a6a3'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-contextual-consumer-single-owned-alternative-ledger-complete-Source-review-v3.json',
  'bytes': 19413,
  'sha256': '6f24be6092f49ed3027471c5e88c0b26659423ba4f083283b98742b3c2276afa'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/ledger-Source3-controls-role-component-acceptance-v1.json',
  'bytes': 1398,
  'sha256': '8a4271c4c2231119bd6aefcdbb943601f14c2768ef065e6155b97a2b490a29d4'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/single-owned-alternative-ledger-Source3-Root-component-acceptance-v1.json',
  'bytes': 3420,
  'sha256': '80fbcb61b32146bd77162a0807652edc2320e9612104d25eb3d30a3405392bb9'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/ledger-qualification-current-interpreter-Source-authority-v1.json',
  'bytes': 1659,
  'sha256': 'b28803d9a39d6dda082790f63f80785c725099bbf6f5e2217872e7785fdcd454'}]


def _subst(pattern, bindings, check):
    images={}
    for row in bindings:
        check(); images[row['parameter_id']]=row['formula']
    pending,values=[('read',pattern)],[]
    while pending:
        check(); action,node=pending.pop()
        if action=='read':
            if node[0]=='param': values.append(images[node[1]])
            elif node[0]=='not': pending.extend([('not',None),('read',node[1])])
            elif node[0]=='imp': pending.extend([('imp',None),('read',node[2]),('read',node[1])])
            else: raise ValueError('declared param/not/imp pattern required')
        elif action=='not': values.append(['not',values.pop()])
        else:
            right,left=values.pop(),values.pop(); values.append(['imp',left,right])
    if len(values)!=1: raise ValueError('complete simultaneous Formula substitution required')
    return values[0]



def _pair_joined_span(subject, reference, limit, c, path):
    for span in (subject, reference):
        _pair_array(span, c, path)
        c.need(len(span) == 2 and _natural(span[0]) and _natural(span[1])
               and span[0] < span[1] <= limit, path, 'original nonempty in-body byte span')
    c.need(_pair_equal(subject, reference, c), path, 'identical original view byte spans', 'INVALID_INSTANCE')
    return subject



def _pair_join_tree_view(tree, source, flat, limit, c, path):
    """Associate actual nested AST occurrences with the original flat layout."""
    _pair_keys(flat, ('prefix_tokens', 'node_byte_spans'), c, path)
    tokens = _pair_array(flat['prefix_tokens'], c, path)
    spans = _pair_array(flat['node_byte_spans'], c, path)
    nodes = _pair_array(source['nodes'], c, path)
    c.need(bool(tokens) and len(tokens) == len(spans) == len(nodes),
           path, 'complete matching original preorder node counts', 'INVALID_INSTANCE')
    c.need(type(source['kind']) is str and source['kind'] in ('formula', 'term'),
           path, 'original Formula or Term source map')
    outer = _pair_joined_span(source['span'], spans[0], limit, c, path)
    todo, ordinal = [(source['kind'], tree, None, None)], 0
    while todo:
        c.tick()
        sort, node, parent, slot = todo.pop()
        _pair_array(node, c, path)
        c.need(bool(node) and type(node[0]) is str and ordinal < len(tokens),
               path, 'complete typed AST occurrence for each flat token', 'INVALID_INSTANCE')
        tag, children = node[0], []
        if sort == 'term' and tag == 'var':
            c.need(len(node) == 2 and _natural(node[1]), path, 'rigid variable token')
            token, code, child_sort = ('var', node[1]), 0, 'term'
        elif (sort == 'term' and tag == 'fun') or (sort == 'formula' and tag == 'pred'):
            c.need(len(node) == 3 and _natural(node[1]), path, 'rigid symbol token')
            children = _pair_array(node[2], c, path)
            token, code, child_sort = (tag, node[1], len(children)), (1 if tag == 'fun' else 0), 'term'
        elif sort == 'formula' and tag == 'all':
            c.need(len(node) == 3 and _natural(node[1]), path, 'rigid binder token')
            token, code, child_sort, children = ('all', node[1]), 4, 'formula', [node[2]]
        elif sort == 'formula' and tag == 'not':
            c.need(len(node) == 2, path, 'unary negation token')
            token, code, child_sort, children = ('not',), 2, 'formula', [node[1]]
        elif sort == 'formula' and (tag == 'eq' or tag == 'imp'):
            c.need(len(node) == 3, path, 'binary Formula token')
            token, code = (tag,), (1 if tag == 'eq' else 3)
            child_sort, children = ('term' if tag == 'eq' else 'formula'), [node[1], node[2]]
        else:
            c.fail('INVALID_INSTANCE', path, 'original typed AST token required')
        metadata = nodes[ordinal]
        c.need(type(metadata['kind']) is str and metadata['kind'] == sort
               and type(metadata['tag']) is int and metadata['tag'] == code,
               path, 'original source node sort/tag association', 'INVALID_INSTANCE')
        c.need(_pair_equal(metadata['parent'], parent, c) and _pair_equal(metadata['slot'], slot, c),
               path, 'original preorder parent/child-slot association', 'INVALID_INSTANCE')
        span = _pair_joined_span(metadata['span'], spans[ordinal], limit, c, path)
        c.need(outer[0] <= span[0] < span[1] <= outer[1], path, 'node lies in original tree span')
        if parent is not None:
            parent_span = nodes[parent]['span']
            c.need(parent_span[0] < span[0] and span[1] <= parent_span[1],
                   path, 'child occurrence lies in original parent span')
        c.need(_pair_equal(tokens[ordinal], token, c), path, 'exact independent preorder token', 'INVALID_INSTANCE')
        current = ordinal
        ordinal += 1
        for child in range(len(children) - 1, -1, -1):
            c.tick()
            todo.append((child_sort, children[child], current, child))
    c.need(ordinal == len(tokens), path, 'no omitted or extra independent tree occurrence', 'INVALID_INSTANCE')



def _pair_join_witness_views(row, independent, limit, c, path):
    tag, subtag = row['rule_tag'], row['subtag']
    payload = _pair_array(independent['payload'], c, path)
    witness = _pair_array(row['witness'], c, path)
    fields = _pair_array(row['witness_source'], c, path)
    c.need(_pair_equal(independent['witness_tag'], subtag, c), path,
           'exact independent logical/theory witness tag', 'INVALID_INSTANCE')
    offset = 1 if tag == 1 or tag == 2 else 0
    c.need(len(fields) == len(witness) + offset and len(payload) == len(witness),
           path, 'complete ordered witness fields and payload', 'INVALID_INSTANCE')
    cursor = row['rule_source']['span'][1]
    if offset:
        field = fields[0]
        c.need(field['name'] == ('logical_tag' if tag == 1 else 'theory_witness_tag')
               and field['kind'] == 'natural', path, 'original witness tag field')
        span = _pair_joined_span(field['span'], field['span'], limit, c, path)
        c.need(span[0] == cursor, path, 'contiguous original witness tag field')
        cursor = span[1]
    if tag == 0:
        specification = (('hypothesis_index', 'natural'),)
    elif tag == 1:
        specification = (
            (('A', 'formula'), ('B', 'formula')),
            (('A', 'formula'), ('B', 'formula'), ('C', 'formula')),
            (('A', 'formula'), ('B', 'formula')),
            (('A', 'formula'), ('x', 'natural'), ('t', 'term')),
            (('A', 'formula'), ('B', 'formula'), ('x', 'natural')),
            (('A', 'formula'), ('x', 'natural')),
            (('t', 'term'),),
            (('A', 'formula'), ('x', 'natural'), ('s', 'term'), ('t', 'term')))[subtag]
    elif tag == 2:
        specification = (('A', 'formula'), ('x', 'natural'), ('parameters', 'natural_vector')) if subtag == 2 else (('table_index', 'natural'),)
    elif tag == 3:
        specification = (('antecedent_row', 'natural'), ('implication_row', 'natural'))
    else:
        specification = (('source_row', 'natural'), ('variable_id', 'natural'))
    c.need(len(witness) == len(specification), path, 'original exact witness arity')
    for index, (name, kind) in enumerate(specification):
        c.tick()
        field, value, other = fields[index + offset], witness[index], payload[index]
        c.need(field['name'] == name and field['kind'] == kind, path, 'original ordered typed witness field')
        span = _pair_joined_span(field['span'], field['span'], limit, c, path)
        c.need(span[0] == cursor, path, 'contiguous original witness payload span')
        if kind == 'formula' or kind == 'term':
            _pair_join_tree_view(value, field, other, limit, c, path + (index,))
        elif kind == 'natural':
            c.need(_natural(value) and _natural(other) and value == other, path, 'exact independent natural witness', 'INVALID_INSTANCE')
        else:
            _pair_array(value, c, path); _pair_array(other, c, path)
            elements = _pair_array(field['elements'], c, path)
            c.need(len(value) == len(other) == len(elements), path, 'complete ordered natural vector')
            previous = span[0]
            for number, alternate, element in zip(value, other, elements):
                c.need(_natural(number) and _natural(alternate) and number == alternate,
                       path, 'exact independent natural-vector payload', 'INVALID_INSTANCE')
                element_span = _pair_joined_span(element['span'], element['span'], limit, c, path)
                c.need(element['name'] == 'element' and element['kind'] == 'natural'
                       and previous < element_span[0] and element_span[1] <= span[1],
                       path, 'ordered original natural-vector element spans')
                previous = element_span[0]
        cursor = span[1]
    c.need(cursor == row['span'][1], path, 'witness payload covers complete original row')



def _pair_join_views(subject, reference, query_bytes, certificate_bytes, c):
    """Explicit association only: neither view is reparsed or substituted."""
    query, alternate = subject['query'], reference['query']
    c.need(type(query['version']) is int and query['version'] == 1
           and _pair_equal(query['claim_mode'], alternate['mode'], c)
           and _pair_equal(query['theory_profile'], alternate['profile'], c)
           and _pair_equal((query['function_arities'], query['predicate_arities']), alternate['signature'], c),
           ('query',), 'full independent original query header association', 'INVALID_INSTANCE')
    fields = _pair_array(query['source_fields'], c, ('query',))
    c.need(len(fields) == 8, ('query',), 'original eight-field query source map')
    for name, other_name, position in (('finite_axioms', 'theory', 5), ('Gamma', 'hypotheses', 6)):
        left = _pair_array(query[name], c, ('query', name))
        right = _pair_array(alternate[other_name], c, ('query', name))
        c.need(len(left) == len(right), ('query', name), 'complete ordered independent query vector')
        if name == 'finite_axioms' and query['theory_profile'] != 0:
            c.need(not left and fields[position]['kind'] == 'empty', ('query', name), 'original empty nonfinite-profile payload')
            continue
        maps = _pair_array(fields[position]['elements'], c, ('query', name))
        c.need(fields[position]['name'] == name and fields[position]['kind'] == 'formula_vector'
               and len(maps) == len(left), ('query', name), 'original query vector source maps')
        for index, (tree, source, flat) in enumerate(zip(left, maps, right)):
            c.tick()
            _pair_join_tree_view(tree, source, flat, len(query_bytes), c, ('query', name, index))
    _pair_join_tree_view(query['goal'], fields[7], alternate['goal'], len(query_bytes), c, ('query', 'goal'))
    previous_end = None
    for index, (row, independent) in enumerate(zip(subject['certificate']['rows'], reference['rows'])):
        c.tick()
        path = ('certificate', index)
        c.need(type(row['index']) is int and type(independent['index']) is int
               and row['index'] == independent['index'] == index
               and type(row['rule_tag']) is int and type(independent['rule_tag']) is int
               and row['rule_tag'] == independent['rule_tag'], path, 'identical physical row index and rule tag', 'INVALID_INSTANCE')
        span = _pair_joined_span(row['span'], independent['byte_span'], len(certificate_bytes), c, path)
        c.need(previous_end is None or previous_end == span[0], path, 'contiguous original physical rows')
        _pair_join_tree_view(row['formula'], row['formula_source'], independent['formula'], len(certificate_bytes), c, path + ('formula',))
        c.need(row['formula_source']['span'][0] == span[0]
               and row['formula_source']['span'][1] == row['rule_source']['span'][0]
               and row['rule_source']['name'] == 'rule_tag' and row['rule_source']['kind'] == 'natural',
               path, 'original formula then rule field association')
        rule_span = _pair_joined_span(row['rule_source']['span'], row['rule_source']['span'], len(certificate_bytes), c, path)
        c.need(rule_span[1] <= span[1], path, 'original rule field lies inside physical row')
        _pair_join_witness_views(row, independent, len(certificate_bytes), c, path + ('witness',))
        previous_end = span[1]
    c.need(previous_end == len(certificate_bytes), ('certificate',), 'last independent row reaches original certificate EOF')


class _PairCall:
    def __init__(self, check):
        self.tick = check

    def need(self, condition, path, reason, code='INVALID_PAIR'):
        if not condition:
            raise ValueError(code + ': ' + reason + ' at ' + repr(path))

    def fail(self, code, path, reason):
        self.need(False, path, reason, code)


def _pair_array(value, c, path):
    c.tick()
    c.need(type(value) is list or type(value) is tuple, path, 'exact ordered array')
    return value


def _pair_keys(value, names, c, path):
    _keys(value, names, c.tick)


def _pair_equal(left, right, c):
    return _same(left, right, c.tick)


def _metadata(row, check):
    raw = _read_original(row, check)
    check()
    value = json.loads(raw)
    check()
    if type(value) is not dict:
        raise ValueError('complete metadata object required')
    return value


def _qualification_gate(value, current_pins, check):
    _keys(value, QUALIFICATION_FIELDS, check)
    for name in QUALIFICATION_FIELDS:
        check(); _keys(value[name], ('path', 'bytes', 'sha256'), check); pin_fields(value[name])
    expected_admin = {'Root_admission': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/ledger-bank3-v2case0-Root-complete-whole-admission-v1.json',
                        'bytes': 24883,
                        'sha256': '561754d177d207f7046563ffe762ed2d13f6843db130df66d920f718718e41ee'},
     'C_actual_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-ledger-bank3-v2case0-complete-whole-actual-review-v2.json',
                         'bytes': 49538,
                         'sha256': '5c2b2887c00466f7a079c77f254ff60b4151f2b5a6d87217934490b3f8de6b06'},
     'plan': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/plans/ledger-normal-mode-controls-v2-case-0.json',
              'bytes': 40181,
              'sha256': '63ecc641a57d1c0b9db8cb534094ed89e528c8301e38432db65e2ac54bcf29d7'}}
    for name in ('Root_admission', 'C_actual_review', 'plan'):
        check()
        if not _same(value[name], expected_admin[name], check):
            raise ValueError('exact admitted current qualification metadata pins required')
    root = _metadata(value['Root_admission'], check)
    critical = _metadata(value['C_actual_review'], check)
    plan = _metadata(value['plan'], check)
    decision = critical.get('decision')
    if (root.get('schema') != 'Root-ledger-bank3-v2case0-complete-whole-admission-v1'
            or root.get('status') != 'FINITE_LEDGER_NORMAL_MODE_CONTROLS_ADMITTED'
            or root.get('qualification_admitted') is not True
            or root.get('resources_and_custody_accepted') is not True
            or root.get('case_id') != 'ledger-normal-mode-controls-v2-case-0'
            or root.get('holdout_loaded') is not False or root.get('holdout_searched') is not False
            or critical.get('schema') != 'C-ledger-bank3-v2case0-complete-whole-actual-review-v2'
            or critical.get('complete_review') is not True or not _same(critical.get('blockers'), [], check)
            or type(decision) is not dict
            or decision.get('eligible_for_Root_exact_finite_controls_qualification') is not True
            or decision.get('C_complete_whole_actual_evidence_assessment') != 'PASS'):
        raise ValueError('complete external Root/C six-group qualification required before data load')
    for left, right in (('complete_C_review', 'C_actual_review'), ('plan', 'plan'), ('result', 'result'), ('bank', 'bank')):
        check()
        if not _same(pin_fields(root[left]), pin_fields(value[right]), check):
            raise ValueError('qualification Root full pin association required')
    subjects = critical.get('subjects')
    if type(subjects) is not dict:
        raise ValueError('independent qualification subjects required')
    _keys(subjects['plan'], ('path', 'bytes', 'sha256'), check)
    if not _same(pin_fields(subjects['plan']), pin_fields(value['plan']), check):
        raise ValueError('independent qualification direct plan association required')
    owned = critical.get('all_owned_files')
    if type(owned) is not list or len(owned) != 11:
        raise ValueError('complete exact eleven-row owned-file pin vector required')
    owned_by_path = {}
    for row in owned:
        check(); _keys(row, ('path', 'bytes', 'sha256'), check)
        record = pin_fields(row)
        path = Path(record['path'])
        if (not path.is_absolute() or str(path) != record['path'] or '..' in path.parts
                or record['path'] in owned_by_path):
            raise ValueError('typed canonical duplicate-free owned-file pin vector required')
        owned_by_path[record['path']] = record
    for name in ('result', 'bank'):
        check()
        if not _same(owned_by_path.get(value[name]['path']), pin_fields(value[name]), check):
            raise ValueError('independent qualification exact owned body association required')
    qualified_roles = ('checker', 'builders', 'reference', 'instance', 'ordinary', 'consumer', 'wide_encoder', 'bank')
    _keys(root['module_pins'], qualified_roles, check)
    _keys(plan['module_pins'], qualified_roles, check)
    if (plan.get('case_id') != root['case_id'] or plan.get('stage') != 'qualification'
            or not _same(plan['module_pins'], root['module_pins'], check)
            or not _same(plan.get('limits'), CAPS, check)
            or not _same(pin_fields(plan['python']), CUSTODY_RUNTIME['python'], check)):
        raise ValueError('the exact completely reviewed qualification plan, current Python and original caps are required')
    for role in qualified_roles:
        check(); pin_fields(root['module_pins'][role])
    for role in MODULE_ROLES:
        check()
        if not _same(pin_fields(root['module_pins'][role]), current_pins[role], check):
            raise ValueError('qualification subject Source differs from target case: ' + role)
    return dict(schema='FPC-contextual-qualification-applicability-v1', accepted=False,
                qualification_rerun=False, complete_external_qualification=True,
                qualification_pins=value, Root_admission=root, C_actual_review=critical,
                qualification_plan=plan, exact_current_Source_projection=current_pins,
                scope='Prior finite six-group evidence only; exercised/unexercised limits retained verbatim. No transfer admission.')


def _inventory_metadata(check):
    root = _metadata(INPUT_AUTHORITY['inventory_Root_admission'], check)
    critical = _metadata(INPUT_AUTHORITY['inventory_C_review'], check)
    if (root.get('schema') != 'Root-stratified-schema-acquisition-case-0-complete-whole-admission-v1'
            or root.get('finite_schematic_inventory_admitted') is not True
            or root.get('resources_and_custody_accepted') is not True
            or root.get('holdout_loaded') is not False or root.get('holdout_searched') is not False
            or critical.get('schema') != 'C-stratified-schema-acquisition-complete-whole-actual-review-v1'
            or critical.get('review_passed') is not True or not _same(critical.get('blockers'), [], check)
            or not _same(pin_fields(root['complete_C_review']), INPUT_AUTHORITY['inventory_C_review'], check)
            or not _same(pin_fields(root['result']), INPUT_AUTHORITY['library_result'], check)
            or not _same(pin_fields(critical['subjects']['result.json']), INPUT_AUTHORITY['library_result'], check)
            or type(root.get('family_summaries')) is not list or len(root['family_summaries']) != 7):
        raise ValueError('same complete admitted seven-family inventory provenance required')
    return root, critical


def _target_from_original_carrier(check, canonical):
    admission = _metadata(INPUT_AUTHORITY['frozen_input_Root_admission'], check)
    if (admission.get('proof_admitted') is not True
            or not _same(pin_fields(admission['result']), INPUT_AUTHORITY['input_carrier'], check)
            or not _same(admission['all3_query_identities']['holdout0'], INPUT_AUTHORITY['target_identity'], check)
            or not _same(admission['all3_input_snapshot_identity'], INPUT_AUTHORITY['all3_snapshot_identity'], check)
            or not _same(admission['selection_snapshot_identity'], INPUT_AUTHORITY['selection_snapshot_identity'], check)):
        raise ValueError('original frozen input-carrier metadata association required')
    carrier = _metadata(INPUT_AUTHORITY['input_carrier'], check)
    frozen = carrier['input_freeze']
    if (frozen['schema'] != 'FPC-cohort-proof-input-freeze-v1'
            or not _same(frozen['input_authority'], INPUT_AUTHORITY['selection_authority'], check)
            or not _same(_digest(canonical(frozen['slots']), check), INPUT_AUTHORITY['all3_snapshot_identity'], check)
            or not _same(_digest(canonical(frozen['selection']), check), INPUT_AUTHORITY['selection_snapshot_identity'], check)
            or not _same(frozen['all3_snapshot_identity'], INPUT_AUTHORITY['all3_snapshot_identity'], check)
            or not _same(frozen['selection_snapshot_identity'], INPUT_AUTHORITY['selection_snapshot_identity'], check)):
        raise ValueError('whole immutable original input and selection snapshots required')
    slot = frozen['slots']['holdout0']
    text = slot['query_hex']
    if type(text) is not str or len(text) != 2 * INPUT_AUTHORITY['target_identity']['bytes']:
        raise ValueError('exact saved original holdout hex byte leaf required')
    check(); original = bytes.fromhex(text); check()
    if (original.hex() != text or not _same(_digest(original, check), INPUT_AUTHORITY['target_identity'], check)
            or not _same(slot['query_identity'], INPUT_AUTHORITY['target_identity'], check)
            or slot['EOF'] != len(original)
            or not _same(slot['declaration'], frozen['selection']['slots']['holdout0']['query'], check)):
        raise ValueError('unchanged original target byte and semantic snapshot required')
    result = dict(schema='FPC-frozen-holdout-input-carrier-association-v1', accepted=False,
        slot='holdout0', original_carrier=INPUT_AUTHORITY['input_carrier'],
        original_field_path=INPUT_AUTHORITY['target_path'], original_query_identity=INPUT_AUTHORITY['target_identity'],
        all3_snapshot_identity=INPUT_AUTHORITY['all3_snapshot_identity'],
        selection_snapshot_identity=INPUT_AUTHORITY['selection_snapshot_identity'], saved_slot=slot,
        selector_rerun=False, encoder_rerun=False, query_regenerated=False,
        donor_proof_fields_passed_to_search=False)
    # Only the saved slot and exact byte leaf survive. Donor proof/search rows
    # and all other carrier fields are never offered as inference input.
    carrier = frozen = admission = None
    check()
    return original, result


def _admitted_families(root, check, canonical):
    saved = _metadata(INPUT_AUTHORITY['library_result'], check)
    extraction = saved['extraction_result']
    families = extraction['families']
    if (extraction.get('schema') != 'FPC-stratified-schematic-receptor-library-candidate-v1'
            or extraction.get('complete') is not True or extraction.get('accepted') is not False
            or extraction.get('status') != 'LIBRARY_CANDIDATE'
            or type(families) is not list or len(families) != 7):
        raise ValueError('all seven complete actually admitted family records required')
    links = extraction['selection_coverage']['selected_representatives']
    if type(links) is not list or len(links) != 8:
        raise ValueError('all eight admitted source occurrences required')
    associations = []
    for index, (family, summary) in enumerate(zip(families, root['family_summaries'])):
        check()
        key = {name: family[name] for name in ('parameters', 'root_local_id', 'internal_nodes', 'boundary_nodes')}
        # The complete original file is authenticated; this additional digest
        # checks its public ID spelling, while full values establish equality.
        key_bytes = canonical(key)[:-1]
        if (summary['index'] != index or family['family_id'] != summary['family_id']
                or not _same(family['family_key'], key, check)
                or _digest(key_bytes, check)['sha256'] != family['family_id']
                or len(family['parameters']) != summary['parameters']
                or len(family['internal_nodes']) != summary['internal_nodes']
                or len(family['boundary_nodes']) != summary['boundary_count']
                or len(family['source_occurrences']) != summary['occurrences']):
            raise ValueError('full ordered generic key and admitted shape required')
        candidate_indices, provenance = [], []
        for link in links:
            check()
            if link['family_index'] != index:
                continue
            occurrence_index = link['source_occurrence_index']
            candidate_index = link['candidate_index']
            candidate = extraction['candidates'][candidate_index]
            source = candidate['inference']['family']
            if (type(occurrence_index) is not int or occurrence_index != len(candidate_indices)
                    or candidate['candidate_index'] != candidate_index
                    or candidate['donor_validation_index'] != link['donor_validation_index']
                    or len(source['source_occurrences']) != 1
                    or not _same(source['family_key'], family['family_key'], check)
                    or not _same(source['source_occurrences'][0], family['source_occurrences'][occurrence_index], check)):
                raise ValueError('every selected full source occurrence must join its admitted candidate')
            candidate_indices.append(candidate_index); provenance.append(link['donor_validation_index'])
        if (not _same(candidate_indices, summary['candidate_indices'], check)
                or not _same(provenance, family['validation_provenance'], check)):
            raise ValueError('complete ordered occurrence/provenance association required')
        associations.append(dict(family_index=index, family_id=family['family_id'],
            candidate_indices=candidate_indices, validation_provenance=provenance,
            source_occurrences=family['source_occurrences'], full_key=family['family_key']))
    saved = extraction = None
    check()
    return families, associations


def _arena_values(records, check):
    values = []
    for index, row in enumerate(records):
        check(); _keys(row, ('id', 'sort', 'tag', 'symbol', 'children'), check)
        if row['id'] != index or type(row['id']) is not int or type(row['children']) is not list:
            raise ValueError('complete ordered arena required')
        children = []
        for child in row['children']:
            check()
            if not _natural(child) or child >= index:
                raise ValueError('backward complete AST references required')
            children.append(values[child])
        tag, symbol = row['tag'], row['symbol']
        if tag == 'var':
            value = ['var', symbol]
        elif tag == 'fun' or tag == 'pred':
            value = [tag, symbol, children]
        elif tag == 'all':
            if len(children) != 1: raise ValueError('one quantified body required')
            value = ['all', symbol, children[0]]
        elif tag == 'not':
            if len(children) != 1: raise ValueError('one negated body required')
            value = ['not', children[0]]
        else:
            if tag not in ('imp', 'eq') or len(children) != 2:
                raise ValueError('original binary Formula required')
            value = [tag, children[0], children[1]]
        values.append(value)
    return values


def _whole_pair(query, certificate, search, subject, reference, check):
    if (subject.get('schema') != 'FPC-H1-finite-byte-check-receipt-v1'
            or subject.get('version') != MODULE_VERSIONS['checker']
            or subject.get('accepted') is not True or subject.get('complete') is not True
            or subject.get('syntax_complete') is not True or subject.get('derivation_complete') is not True
            or subject.get('final_goal_equal') is not True or subject.get('no_prefix_authority') is not True
            or subject.get('status') != 'VALID_DERIVATION'
            or reference.get('schema') != MODULE_VERSIONS['reference']
            or reference.get('complete_check') is not True or reference.get('final_goal_equal') is not True
            or reference.get('status') != 'VALID_DERIVATION'
            or subject['query']['EOF'] != len(query) or subject['certificate']['EOF'] != len(certificate)):
        raise ValueError('both complete fresh original valid byte-pair receipts required')
    for name, raw in (('query', query), ('certificate', certificate)):
        check()
        if not _same(subject['raw_inputs'][name], _digest(raw, check), check):
            raise ValueError('identical original immutable input objects must be validated')
    rows = search['candidate_rows']
    if (type(rows) is not list or not rows or len(rows) != subject['certificate']['row_count']
            or len(rows) != len(subject['certificate']['rows']) or len(rows) != len(reference['rows'])):
        raise ValueError('every physical kernel row and full independent view required')
    _pair_join_views(subject, reference, query, certificate, _PairCall(check))
    associations = []
    for index, (candidate, actual, independent) in enumerate(zip(rows, subject['certificate']['rows'], reference['rows'])):
        check()
        if (candidate['index'] != index or not _same(candidate['formula'], actual['formula'], check)
                or candidate['rule_tag'] != actual['rule_tag'] or candidate['subtag'] != actual['subtag']):
            raise ValueError('every candidate row must join complete original views')
        tag, witness, refs = candidate['rule_tag'], candidate['witness'], candidate['references']
        if (type(refs) is not list or len(refs) != (2 if tag == 3 else (1 if tag == 4 else 0))
                or (tag == 3 and witness is not None)):
            raise ValueError('complete exact ordered reference arity and MP null witness required')
        expected = [witness] if tag == 0 else (list(refs) if tag == 3 else
                   ([refs[0], witness] if tag == 4 else (witness if tag == 1 else [witness])))
        if tag == 2 and candidate['subtag'] == 2:
            expected = witness
        if not _same(expected, actual['witness'], check):
            raise ValueError('complete logical/natural/ordered-reference kernel witness association required')
        associations.append(dict(row=index, primitive=candidate['primitive'],
            subject_span=actual['span'], reference_span=independent['byte_span'],
            formula_source_path=['subject_receipt','certificate','rows',index,'formula_source'],
            witness_source_path=['subject_receipt','certificate','rows',index,'witness_source']))
    return associations


def _use_associations(search, families, check):
    """Recompute symbolic/quotient/discharge/export associations, not booleans."""
    library, plan, compiled = search['library'], search['selected_plan'], search['elaboration']
    if not _same(library['families'], families, check) or not _same(search['candidate_rows'], compiled['candidate_rows'], check):
        raise ValueError('identical offered family bodies and complete compiler rows required')
    values = _arena_values(search['arena'], check)
    if not _same(search['arena'], compiled['arena'], check):
        raise ValueError('one full compiler/search arena association required')
    nodes, primitive = plan['nodes'], compiled['primitive_nodes']
    outputs = []
    for index, row in enumerate(compiled['plan_outputs']):
        check()
        if row['node'] != index or not _natural(row['primitive']) or row['primitive'] >= len(primitive):
            raise ValueError('complete ordered plan to primitive images required')
        outputs.append(row['primitive'])
    if len(outputs) != len(nodes):
        raise ValueError('every selected plan node needs an exact compiler image')
    for index, row in enumerate(nodes):
        check(); actual = primitive[outputs[index]]
        if (row['id'] != index or actual['context'] != row['context'] or actual['formula'] != row['formula']):
            raise ValueError('exact selected context and Formula image required')
        if row['operator'] == 'INTRO':
            continue
        tag = {'HYP':0, 'LOGICAL_AXIOM':1, 'THEORY_AXIOM':2, 'MP':3, 'GEN':4}[row['operator']]
        subtag = row['payload'].get('tag') if tag == 1 or tag == 2 else None
        refs = []
        for ref in row['premises']:
            check(); refs.append(outputs[ref])
        if (actual['rule_tag'] != tag or actual['subtag'] != subtag
                or not _same(actual['witness'], row['payload'], check)
                or not _same(actual['premises'], refs, check)):
            raise ValueError('complete quotient key equality required, never origins/hash equality')
    export = {}
    for index, item in enumerate(compiled['export_map']):
        check()
        if item['row'] != index or item['primitive'] in export:
            raise ValueError('complete distinct final physical export map required')
        export[item['primitive']] = index
        if compiled['candidate_rows'][index]['primitive'] != item['primitive']:
            raise ValueError('candidate row and primitive map association required')
    reachable, todo = set(), [outputs[plan['root']]]
    while todo:
        check(); number = todo.pop()
        if number not in reachable:
            reachable.add(number)
            for child in primitive[number]['premises']:
                check(); todo.append(child)
    if len(reachable) != len(export):
        raise ValueError('all and only final-root dependencies must be exported')
    for number in reachable:
        check()
        if number not in export: raise ValueError('every final dependency must be exported')
        actual = primitive[number]
        row = compiled['candidate_rows'][export[number]]
        refs = []
        for premise in actual['premises']:
            check(); refs.append(export[premise])
        rule, data = actual['rule_tag'], actual['witness']
        if rule == 0:
            witness = data['index']
        elif rule == 1:
            witness = []
            for field in data['witness']:
                check(); witness.append(field['value'] if field['sort']=='V' else values[field['id']])
        elif rule == 2:
            witness = [values[data['formula']],data['variable'],data['parameters']] if data['tag']==2 else data['index']
        elif rule == 3:
            witness = None
        else:
            witness = data['variable']
        if (actual['context'] != 0 or row['rule_tag'] != rule or row['subtag'] != actual['subtag']
                or not _same(row['formula'],values[actual['formula']],check)
                or not _same(row['references'],refs,check) or not _same(row['witness'],witness,check)):
            raise ValueError('every complete primitive Formula/rule/witness/ref joins original kernel row')
    gamma_lengths = []
    for index, context in enumerate(plan['contexts']):
        check()
        if context['id'] != index: raise ValueError('exact ordered plan contexts required')
        gamma_lengths.append(len(search['query']['Gamma']) if index==0 else gamma_lengths[context['parent']]+1)
    for record in compiled['discharges']:
        check(); row = nodes[record['intro_node']]
        child = outputs[row['premises'][0]]
        context = plan['contexts'][record['child_context']]
        matches = []
        for edge in record['mapping']:
            check()
            if edge['input_primitive'] == child: matches.append(edge['output_primitive'])
        if (row['operator'] != 'INTRO' or row['payload']['child_context'] != record['child_context']
                or row['context'] != record['parent_context'] or matches != [outputs[row['id']]]
                or context['parent'] != record['parent_context'] or context['opener'] != row['id']
                or record['discharged_hypothesis_index'] != gamma_lengths[record['child_context']]-1):
            raise ValueError('exact occurrence-sensitive INTRO root image required')
    def trace(plan_node):
        check()
        if plan_node is None:
            return dict(status='PRUNED', primitive=None, transformations=[], final_primitive=None, wire_row=None)
        current, transformations = outputs[plan_node], []
        initial = current
        for record_index, record in enumerate(compiled['discharges']):
            check(); before = primitive[current]
            if before['context'] != record['child_context']: continue
            found = None
            for edge_index, edge in enumerate(record['mapping']):
                check()
                if edge['input_primitive'] == current:
                    if found is not None: raise ValueError('unique discharge edge per input required')
                    found, found_index = edge, edge_index
            if found is None: continue
            after = primitive[found['output_primitive']]
            assumption = plan['contexts'][record['child_context']]['assumption']
            rule = before['rule_tag']
            expected_case = ('DISCHARGED_HYP' if rule==0 and before['witness']['index']==record['discharged_hypothesis_index'] else
                             ('LIFT_HYP_OR_AXIOM' if rule in (0,1,2) else ('LIFT_MP' if rule==3 else 'LIFT_GEN')))
            if (after['context'] != record['parent_context']
                    or found['case'] != expected_case
                    or not _same(values[after['formula']], ['imp',values[assumption],values[before['formula']]],check)):
                raise ValueError('full context/implication transformation required')
            transformations.append(dict(intro_node=record['intro_node'],child_context=record['child_context'],
                parent_context=record['parent_context'],assumption_formula_id=assumption,
                discharged_hypothesis_index=record['discharged_hypothesis_index'],edge=found,
                discharge_record_index=record_index,mapping_edge_index=found_index,
                full_record_path=['elaboration','discharges',record_index]))
            current = found['output_primitive']
        return dict(status='FINAL_ROOT_DEPENDENCY' if current in reachable else 'NOT_FINAL_ROOT_DEPENDENCY',
            primitive=initial,transformations=transformations,final_primitive=current,wire_row=export.get(current))
    lowering = library['selected_lowering']
    prune = {}
    for index, row in enumerate(lowering['pruning']):
        check()
        if row['unpruned_plan_node'] != index: raise ValueError('complete ordered pruning map required')
        prune[index] = row['plan_node']
    context_map = {}
    for row in lowering['context_map']:
        check()
        if row['search_context'] in context_map: raise ValueError('unique context map required')
        context_map[row['search_context']] = row['plan_context']
    results = []
    for application in lowering['applications']:
        check(); family = families[application['family_index']]
        offer = library['offers'][application['offer_id']]
        owner = search['obligations'][application['owner_obligation_id']]
        alternative = search['alternatives'][application['selected_alternative_id']]
        if (not _same(application['family_key'],family['family_key'],check)
                or not _same(application['binding'],offer['binding'],check)
                or offer['alternative_id'] != alternative['id'] or alternative['operator'] != 'LIBRARY'
                or alternative['owner'] != owner['id'] or owner['state'] != 'SOLVED'
                or owner['selected_alternative_id'] != alternative['id']
                or owner['solved_serial'] != application['selected_serial']
                or owner['context_id'] != application['owner_context_id']):
            raise ValueError('actual selected live application, never post-hoc relabeling, required')
        binding, local, ports = application['binding'], application['internal_nodes'], application['boundaries']
        if len(binding) != len(family['parameters']) or len(local) != len(family['internal_nodes']) or len(ports) != len(family['boundary_nodes']):
            raise ValueError('every parameter/local/ordered boundary identity required')
        for index, row in enumerate(binding):
            check()
            if row['parameter_id'] != index or not _same(row['formula'], values[row['formula_id']],check):
                raise ValueError('full chosen binding and arena association required')
        owner_context = context_map[owner['context_id']]
        body_context = application['lowering_context_ids'][-1] if application['lowering_context_ids'] else owner_context
        for index, row in enumerate(ports):
            check(); obligation = search['obligations'][row['obligation_id']]
            formula = _subst(family['boundary_nodes'][index]['formula_pattern'],binding,check)
            if (row['boundary_id'] != index or alternative['premise_ids'][index] != obligation['id']
                    or obligation['context_id'] != owner['context_id'] or obligation['state'] != 'SOLVED'
                    or obligation['solved_serial'] != row['proof_serial'] or not row['proof_serial'] < owner['solved_serial']
                    or not _same(formula,values[row['formula_id']],check)
                    or not _same(formula,values[obligation['formula_id']],check)
                    or prune[row['unpruned_proof_plan_node']] != row['proof_plan_node']
                    or prune[row['unpruned_body_plan_node']] != row['body_plan_node']):
                raise ValueError('strict earlier same-context real boundary proof and pruning map required')
            proof_node,body_node = nodes[row['proof_plan_node']],nodes[row['body_plan_node']]
            if (proof_node['context'] != owner_context or not _same(values[proof_node['formula']],formula,check)
                    or body_node['context'] != body_context or not _same(values[body_node['formula']],formula,check)):
                raise ValueError('both boundary proof and actual lowering body association required')
            if application['arm'] == 'CONDITIONAL_LEMMA_CD':
                expected_index = len(search['contexts'][owner['context_id']]['full_Gamma_formula_ids'])+index
                if body_node['operator'] != 'HYP' or body_node['payload'] != dict(index=expected_index):
                    raise ValueError('distinct ordered local assumption occurrence required')
            elif row['proof_plan_node'] != row['body_plan_node']:
                raise ValueError('direct boundary must be actual proof output, not extra HYP')
            if not _same(row['proof_trace'],trace(row['proof_plan_node']),check) or not _same(row['body_trace'],trace(row['body_plan_node']),check):
                raise ValueError('full original boundary transformation paths required')
        physical = []
        for index, row in enumerate(local):
            check(); definition = family['internal_nodes'][index]; actual = nodes[row['plan_node']]
            formula = _subst(definition['formula_pattern'],binding,check)
            if (row['local_id'] != index or prune[row['unpruned_plan_node']] != row['plan_node']
                    or actual['context'] != body_context or actual['formula'] != row['formula_id']
                    or not _same(values[row['formula_id']],formula,check)):
                raise ValueError('every symbolic local identity and instantiated body Formula required')
            if definition['rule_tag'] == 1:
                if actual['operator'] != 'LOGICAL_AXIOM' or actual['payload']['tag'] != definition['subtag']:
                    raise ValueError('exact internal logical rule and subtag required')
                expected = []
                for pattern in definition['witness_pattern']:
                    check(); expected.append(_subst(pattern,binding,check))
                observed = []
                for witness in actual['payload']['witness']:
                    check(); observed.append(values[witness['id']])
                if not _same(expected,observed,check): raise ValueError('every ordered whole Formula witness required')
            else:
                refs = []
                for ref in definition['references']:
                    check(); refs.append(local[ref['id']]['plan_node'] if ref['kind']=='internal' else ports[ref['id']]['body_plan_node'])
                if actual['operator'] != 'MP' or not _same(actual['premises'],refs,check):
                    raise ValueError('every authoritative ordered local/port MP reference required')
            expected_trace = trace(row['plan_node'])
            if not _same(expected_trace,row['trace'],check): raise ValueError('complete final-used transformation path required')
            physical.append(dict(local_id=index,plan_node=row['plan_node'],trace=expected_trace))
        output_trace = trace(application['output_plan_node'])
        current = local[family['root_local_id']]['plan_node']
        if application['arm'] == 'CONDITIONAL_LEMMA_CD':
            contexts = application['lowering_context_ids']
            if len(contexts)!=len(ports) or len(application['INTRO_nodes'])!=len(ports) or len(application['application_MP_nodes'])!=len(ports):
                raise ValueError('complete conditional assumption/discharge/application chain required')
            parent = owner_context
            for index, child_context in enumerate(contexts):
                check(); context = plan['contexts'][child_context]
                if context['parent'] != parent or context['assumption'] != ports[index]['formula_id']:
                    raise ValueError('ordered distinct lowering-context assumptions required')
                parent = child_context
            for position, intro in enumerate(application['INTRO_nodes']):
                check(); port_index = len(ports)-1-position
                child_context = contexts[port_index]; row = nodes[intro]
                if (prune[application['unpruned_INTRO_nodes'][position]] != intro
                        or row['operator'] != 'INTRO' or row['payload']['child_context'] != child_context
                        or plan['contexts'][child_context]['opener'] != intro
                        or row['context'] != plan['contexts'][child_context]['parent']
                        or not _same(row['premises'],[current],check)
                        or not _same(values[row['formula']],['imp',values[ports[port_index]['formula_id']],values[nodes[current]['formula']]],check)):
                    raise ValueError('every exact reverse-port INTRO and implication transformation required')
                current = intro
            for index, application_mp in enumerate(application['application_MP_nodes']):
                check(); row = nodes[application_mp]
                previous = values[nodes[current]['formula']]
                if (prune[application['unpruned_application_MP_nodes'][index]] != application_mp
                        or row['operator'] != 'MP' or row['context'] != owner_context
                        or not _same(row['premises'],[ports[index]['proof_plan_node'],current],check)
                        or previous[0]!='imp' or not _same(previous[1],values[ports[index]['formula_id']],check)
                        or not _same(values[row['formula']],previous[2],check)):
                    raise ValueError('every ordered real-boundary conditional detachment required')
                current = application_mp
        elif application['lowering_context_ids'] or application['INTRO_nodes'] or application['application_MP_nodes']:
            raise ValueError('direct DAG has no invented local-assumption/detachment chain')
        if (prune[application['unpruned_output_plan_node']] != current or current != application['output_plan_node']
                or nodes[current]['context'] != owner_context or nodes[current]['formula'] != owner['formula_id']):
            raise ValueError('exact selected application output must be the actual lowered family chain')
        if not _same(application['output_trace'],output_trace,check):
            raise ValueError('complete selected application output transformation required')
        all_final = True
        for row in physical:
            check()
            if row['trace']['status'] != 'FINAL_ROOT_DEPENDENCY': all_final = False
        results.append(dict(application_id=application['application_id'],family_index=application['family_index'],
            owner_obligation_id=owner['id'],selected_alternative_id=alternative['id'],selected_serial=owner['solved_serial'],
            internal_associations=physical,output_trace=output_trace,
            all_internal_final=all_final,
            accepted=False,proof_use_admitted=False))
    return dict(schema='FPC-frozen-target-contextual-application-associations-v1',complete=True,accepted=False,
        applications=results,selected_applications=len(results),distinct_exported_primitive_rows=len(export),
        final_root_primitive=outputs[plan['root']],full_original_validator_rows_joined=True,
        symbolic_placement_claim=False,proof_use_admitted=False)


def main(plan_path, actual_dir, root_start):
    if not (sys.platform == 'darwin' and sys.implementation.name == 'cpython'
            and sys.version.split()[0] == '3.12.14' and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode and os.getpid() == os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start) and 0 <= root_start <= time.monotonic()):
        raise ValueError('exact isolated owned child and inherited genuine parent start required')
    began = root_start
    study = Path(__file__).resolve().parents[1]
    directory, plan_path = Path(actual_dir), Path(plan_path)
    plan_pin = raw_pin(plan_path)
    plan_body = plan_path.read_bytes()
    if byte_identity(plan_body) != {k:plan_pin[k] for k in ('bytes','sha256')}:
        raise ValueError('stable entire plan bytes required')
    plan = json.loads(plan_body)
    if type(plan) is not dict or set(plan) != set(PLAN_FIELDS):
        raise ValueError('exact seventeen-field plan required')
    arm = plan['arm']
    if type(arm) is not str or arm not in ARMS:
        raise ValueError('one prospectively fixed arm required')
    case = CASES[ARMS.index(arm)]
    if (plan['schema'] != 'proof-search-case-once-plan-v1' or plan['case_id'] != case
            or plan['experiment'] != EXPERIMENT or plan['stage'] != 'evaluation' or plan['profile'] != PROFILE
            or directory != study/'actual'/case or plan['actual_dir'] != str(directory)
            or not directory.is_absolute() or directory.resolve() != directory or directory.is_symlink()
            or not directory.is_dir() or plan_path.parent != study/'root'/'plans'
            or Path(plan['worker_path']) != Path(__file__).resolve()):
        raise ValueError('one exact serial frozen-target arm and original once layout required')
    if (type(plan['limits']) is not dict or set(plan['limits']) != set(CAPS)
            or any(type(plan['limits'][k]) is not int or plan['limits'][k] != v for k,v in CAPS.items())):
        raise ValueError('all ten original ceilings unchanged')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'],CAPS['physical_bytes']))
    consumed = json.loads((directory/'CONSUMED.json').read_bytes())
    if (consumed['schema'] != 'proof-search-case-consumed-v1' or consumed['plan_sha256'] != plan_pin['sha256']
            or consumed['case_id'] != case or type(consumed['uses']) is not int or consumed['uses'] != 1):
        raise ValueError('fresh exact once consumption required')
    state = dict(stage='PIN_INTAKE',callbacks=0,first_fault=None,first_fault_monotonic_ns=None,stages=[],versions={})
    primary = None
    guards,modules,bindings = [],{},[]
    projection = None
    positives = {name:None for name in POSITIVE_FIELDS}
    committed_bytes,provisional,output_rejection = 0,[],None
    source_unchanged = False
    normal_status = None

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        error = None
        if state['callbacks'] > CAPS['root_callbacks']:
            error = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic()-began >= CAPS['work_seconds']:
            error = RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            error = RootBudget('whole Python high-water ceiling')
        if error is not None:
            state['first_fault'] = error
            state['first_fault_monotonic_ns'] = time.monotonic_ns()
            raise error

    def policy_check():
        check()
        if sys.get_int_max_str_digits() != POLICY_BINDING[1]:
            raise ValueError('original native integer policy drift')

    def stage(name, operation):
        policy_check(); state['stage'] = name
        row = dict(name=name,began=time.monotonic()-began,status='STARTED')
        state['stages'].append(row)
        value = operation()
        policy_check(); row.update(status='COMPLETED',seconds=time.monotonic()-began-row['began'])
        return value

    def verify_files(cooperative):
        for row in guards:
            if cooperative: check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed declared Source/metadata: '+row['path'])

    def canonical(value):
        _validate_json_image(value,check); policy_check()
        body = (json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':'))+'\n').encode('ascii')
        policy_check()
        return body

    def decide_size(body, name):
        nonlocal output_rejection
        policy_check()
        prospective = committed_bytes+len(body)
        if prospective > CAPS['result_bytes']:
            if output_rejection is None:
                output_rejection = dict(component=name,exact_attempt_bytes=len(body),committed_positive_bytes_before=committed_bytes,
                    prospective_positive_bytes=prospective,cap_bytes=CAPS['result_bytes'])
            error = RootBudget('original query/certificate plus ENTIRE result exceeds shared48MiB')
            state['first_fault'] = error
            state['first_fault_monotonic_ns'] = time.monotonic_ns()
            raise error

    def export(name, body):
        nonlocal committed_bytes
        if type(body) is not bytes:
            raise ValueError('complete immutable original artifact bytes required')
        decide_size(body,name)
        progress = dict(basename=name,phase='BEFORE_WRITE',readback_complete=False)
        provisional.append(progress)
        expected = _digest(body,policy_check)
        actual = _write_bank_and_readback(directory/name,body,policy_check,progress)
        if not _same(actual,expected,check):
            raise ValueError('entire original immutable artifact readback required')
        committed_bytes += len(body)
        return dict(schema='FPC-original-byte-artifact-ref-v1',path=name,bytes=actual['bytes'],sha256=actual['sha256'])

    def stable():
        for role,name,entry in bindings:
            check()
            if (getattr(modules[role],name) is not entry or type(modules[role].VERSION) is not str
                    or modules[role].VERSION != MODULE_VERSIONS[role]):
                raise ValueError('exact public namespace identity changed')
        if projection is not None:
            _keys(projection,('checker','builders','instance'),check)
            for role in ('checker','builders','instance'):
                check()
                if projection[role] is not modules[role]: raise ValueError('same public search projection required')

    def retire():
        for name in POSITIVE_FIELDS:
            positives[name] = None

    search_result = search = subject = reference = families = frozen_query = None
    frozen_inputs = configuration = original_slot = inventory_root = inventory_C = None
    try:
        check(); _keys(plan['module_pins'],MODULE_ROLES,check)
        if (not _same(plan['module_pins'],MODULE_PINS,check) or not _same(plan['input_authority'],INPUT_AUTHORITY,check)
                or not _same(plan['Source_components'],SOURCE_COMPONENTS,check)
                or type(plan['files']) is not list or not plan['files']):
            raise ValueError('exact current Sources/input authority/components and explicit closure required')
        _keys(plan['qualification'],QUALIFICATION_FIELDS,check)
        guards = [pin_fields(row) for row in plan['files']]
        by_path = {row['path']:row for row in guards}
        if len(by_path) != len(guards): raise ValueError('unique Source guard paths required')
        for row in guards:
            check()
            if '/actual/' in row['path'] or row['path'].endswith('.bin'):
                raise ValueError('scientific data bodies are not Source guards')
        required = list(MODULE_PINS.values())+list(CUSTODY_RUNTIME.values())+REQUIRED_METADATA_GUARDS+[plan['protocol']]
        required += [plan['qualification'][key] for key in ('Root_admission','C_actual_review','plan')]
        for row in required:
            check(); row = pin_fields(row)
            if by_path.get(row['path']) != row: raise ValueError('every used Source/metadata must be explicitly guarded')
        if (pin_fields(plan['python']) != CUSTODY_RUNTIME['python']
                or raw_pin(Path(sys.executable).resolve()) != CUSTODY_RUNTIME['python']
                or plan['runner_path'] != CUSTODY_RUNTIME['runner']['path']
                or by_path.get(str(Path(__file__).resolve())) != raw_pin(Path(__file__).resolve())):
            raise ValueError('exact current worker/environment/custody required')
        verify_files(True); policy_check()
        protocol = _metadata(plan['protocol'],policy_check)
        _keys(protocol,('schema','experiment','limits','module_pins','control_populations','job_recipes','metadata'),check)
        recipes = []
        for candidate_arm,candidate_case in zip(ARMS,CASES):
            check(); recipes.append(dict(case_id=candidate_case,stage='evaluation',arm=candidate_arm))
        metadata = dict(profile=PROFILE,input_authority=INPUT_AUTHORITY,Source_components=SOURCE_COMPONENTS,
                        reference_integer_policy=list(POLICY_BINDING),configuration=CONFIGURATION,qualification=plan['qualification'])
        if (protocol['schema'] != PROTOCOL_SCHEMA or protocol['experiment'] != EXPERIMENT
                or not _same(protocol['limits'],CAPS,check) or not _same(protocol['module_pins'],MODULE_PINS,check)
                or not _same(protocol['control_populations'],[],check)
                or not _same(protocol['job_recipes'],recipes,check) or not _same(protocol['metadata'],metadata,check)):
            raise ValueError('exact three-arm prospective protocol and late qualification binding required')
        positives['qualification_provenance'] = stage('QUALIFICATION BEFORE DATA',lambda:
            _qualification_gate(plan['qualification'],MODULE_PINS,policy_check))
        inventory_root,inventory_C = stage('INVENTORY METADATA',lambda:_inventory_metadata(policy_check))
        for role in MODULE_ROLES:
            row = MODULE_PINS[role]
            modules[role] = stage('IMPORT '+role,lambda role=role,row=row:
                load_exact(row,'_frozen_target_'+role+'_once_v1',check))
            if type(modules[role].VERSION) is not str or modules[role].VERSION != MODULE_VERSIONS[role]:
                raise ValueError('exact current Source VERSION required')
            state['versions'][role] = modules[role].VERSION
            for name in PUBLIC_ENTRIES[role]:
                check(); entry = getattr(modules[role],name)
                if not callable(entry): raise ValueError('genuine public callable required')
                bindings.append((role,name,entry))
        frozen_query,frozen_inputs = stage('LOAD ORIGINAL HOLDOUT CARRIER',lambda:
            _target_from_original_carrier(policy_check,canonical))
        decoded = stage('DECODE ORIGINAL QUERY',lambda:modules['checker'].decode_query(frozen_query,check=check))
        original_slot = frozen_inputs['saved_slot']
        if decoded['EOF'] != len(frozen_query): raise ValueError('original query strict EOF required')
        for name in QUERY_FIELDS:
            check()
            if (not _same(decoded[name],original_slot['declaration'][name],check)
                    or not _same(decoded[name],original_slot['decoded_query'][name],check)):
                raise ValueError('all eight original target semantic fields must be unchanged')
        if (decoded['version'] != 1 or decoded['claim_mode'] != 0 or decoded['theory_profile'] != 0
                or not _same(decoded['function_arities'],[],check) or not _same(decoded['predicate_arities'],[0,0,0],check)
                or not _same(decoded['finite_axioms'],[],check) or not _same(decoded['Gamma'],[],check)):
            raise ValueError('unchanged original input-only target profile required')
        if arm == 'NO_LIBRARY':
            families,source_associations = [],[]
        else:
            families,source_associations = stage('LOAD ALL SEVEN FAMILIES',lambda:
                _admitted_families(inventory_root,policy_check,canonical))
        family_snapshot = canonical(families)
        configuration = dict(CONFIGURATION)
        query_ref = stage('EXPORT ORIGINAL QUERY',lambda:export('query.bin',frozen_query))
        frozen_inputs['original_query_artifact'] = query_ref
        positives['input_freeze'] = frozen_inputs
        positives['library_provenance'] = dict(inventory_Root=inventory_root,inventory_C=inventory_C,
            library_result=INPUT_AUTHORITY['library_result'],library_body_read=arm!='NO_LIBRARY',
            families_offered=len(families),complete_source_associations=source_associations,
            current_family_records=families,accepted=False,prior_acquisition_cost_reported_separately=True)
        projection = {role:modules[role] for role in ('checker','builders','instance')}
        consumer_arm = 'RECEPTOR_DAG' if arm == 'NO_LIBRARY' else arm
        search_result = stage('SEARCH '+arm,lambda:modules['consumer'].search_with_library(
            frozen_query,families=families,arm=consumer_arm,configuration=configuration,modules=projection,check=check,progress=None))
        stable(); _keys(search_result,('status','candidate_certificate_bytes','receipt'),check)
        normal_status = search_result['status']
        if normal_status not in ('CANDIDATE_FOUND','UNKNOWN_DECLARED_PRODUCER','SOURCE_OUTSIDE_DECLARED_SCOPE'):
            raise ValueError('exact public normal search status required')
        search = search_result['receipt']; _validate_json_image(search,check)
        if (search['schema'] != 'FPC-H1-contextual-library-search-receipt-v1'
                or search['version'] != MODULE_VERSIONS['consumer'] or search['accepted'] is not False
                or search['status'] != normal_status or not _same(search['configuration'],CONFIGURATION,check)
                or not _same(configuration,CONFIGURATION,check) or not _checked_byte_equal(canonical(families),family_snapshot,check)
                or not _same(search['library']['families'],families,check) or search['library']['arm'] != consumer_arm
                or not _same({k:search['query'][k] for k in ('bytes','sha256')},INPUT_AUTHORITY['target_identity'],check)):
            raise ValueError('complete original search configuration/input/library association required')
        for name in QUERY_FIELDS:
            check()
            if not _same(search['query'][name],decoded[name],check): raise ValueError('untouched original query in search receipt required')
        certificate = search_result['candidate_certificate_bytes']
        row_associations,use_associations,certificate_ref = None,None,None
        if normal_status == 'CANDIDATE_FOUND':
            if type(certificate) is not bytes or not certificate: raise ValueError('complete original candidate bytes required')
            subject = stage('SUBJECT SAME ORIGINAL PAIR',lambda:modules['checker'].check_certificate(frozen_query,certificate,check=check))
            reference = stage('REFERENCE SAME ORIGINAL PAIR',lambda:modules['reference'].reference_check_certificate(frozen_query,certificate,check=check))
            row_associations = stage('JOIN EVERY ORIGINAL KERNEL ROW',lambda:
                _whole_pair(frozen_query,certificate,search,subject,reference,policy_check))
            use_associations = stage('JOIN SELECTED CONTEXTUAL USE',lambda:_use_associations(search,families,policy_check))
            certificate_ref = stage('EXPORT ORIGINAL CERTIFICATE',lambda:export('certificate.bin',certificate))
            positives['subject_receipt'],positives['reference_receipt'] = subject,reference
        elif certificate is not None:
            raise ValueError('normal unknown/outside must have certificate None and no validators')
        positives['producer_result'] = dict(status=normal_status,candidate_certificate_bytes=certificate_ref,receipt=search)
        positives['scientific_result'] = dict(schema='FPC-frozen-target-contextual-reuse-candidate-v1',accepted=False,
            arm=arm,consumer_arm=consumer_arm,normal_status=normal_status,original_target_identity=INPUT_AUTHORITY['target_identity'],
            proof_admitted=False,contextual_use_admitted=False,candidate_same_byte_dual_complete=normal_status=='CANDIDATE_FOUND',
            complete_kernel_row_associations=row_associations,contextual_application_associations=use_associations,
            qualification_rerun=False,selector_rerun=False,encoder_rerun=False,holdout_changed=False,
            library_body_loaded=arm!='NO_LIBRARY',families_offered=len(families),
            acquisition_and_qualification_costs_reported_separately=True,cold_OS_page_cache_claim=False,
            GCTS_RL_advantage=False,positive_body_bytes_before_result=committed_bytes,
            scope='One fresh fixed-target arm only; complete normal unknown is diagnostic, not proof. External whole review alone admits any proof/use or cross-arm comparison.')
        stable(); verify_files(True); policy_check()
    except BaseException as error:
        primary = state['first_fault'] if state['first_fault'] is not None else error
    finally:
        source_unchanged = False
        try:
            verify_files(primary is None); source_unchanged = bool(guards)
        except BaseException as error:
            if primary is None: primary = state['first_fault'] if state['first_fault'] is not None else error
        if primary is not None: retire()
    search_result = search = subject = reference = families = frozen_query = None
    frozen_inputs = configuration = original_slot = inventory_root = inventory_C = projection = None
    bindings.clear(); modules.clear()

    def receipt():
        value = dict(schema='FPC-frozen-target-contextual-reuse-whole-receipt-v1',case_id=case,stage='evaluation',arm=arm,
            worker_version=VERSION,status=normal_status if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            accepted=False,proof_admitted=False,contextual_use_admitted=False,case_complete=primary is None,
            stages=state['stages'],callbacks=state['callbacks'],elapsed_seconds=time.monotonic()-began,
            python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,source_unchanged=source_unchanged,native_peak_bytes=0,
            native_transport=dict(closed=True,all_reaped=True,native_exit_code=0,native_high_water_bytes=0,subprocesses_started=0,scope='VACUOUS_NO_NATIVE_SUBPROCESS'),
            component_versions=state['versions'],error=None if primary is None else dict(type=type(primary).__name__,message=str(primary),traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,first_fault_monotonic_ns=state['first_fault_monotonic_ns'],output_rejection=output_rejection,
            provisional_artifacts=provisional,STOP=None if primary is None else 'STOP_WHOLE_NOT_ADMITTED',
            scope='Fixed holdout0, one serial arm; earlier inventory/qualification separate. No GCTS/RL, useful-transfer or comparative-advantage admission from a raw candidate/header.')
        for name in POSITIVE_FIELDS: value[name] = positives[name] if primary is None else None
        return value

    try:
        if primary is None:
            body = canonical(receipt()); decide_size(body,'ENTIRE_RESULT_JSON'); policy_check()
        else:
            body = serialize(receipt(),CAPS['result_bytes'])
    except BaseException as error:
        if primary is None: primary = state['first_fault'] if state['first_fault'] is not None else error
        retire(); body = serialize(receipt(),CAPS['result_bytes'])
    output = directory/('result.json' if primary is None else 'failure.json')
    if primary is None:
        progress = dict(phase='BEFORE_WRITE',readback_complete=False)
        try:
            _write_bank_and_readback(output,body,policy_check,progress)
            source_unchanged = False; verify_files(True); source_unchanged = bool(guards); policy_check()
        except BaseException as error:
            if progress['phase'] in ('BEFORE_WRITE','WRITING_PARTIAL'):
                primary = state['first_fault'] if state['first_fault'] is not None else error
                retire(); body = serialize(receipt(),CAPS['result_bytes']); output = directory/'failure.json'; write_body(output,body)
            else:
                raise
    else:
        write_body(output,body)
    body = None
    header = dict(schema='proof-search-case-worker-header-v1',case_id=case,status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'],seconds=time.monotonic()-began,python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0,source_unchanged=source_unchanged,native_closed_and_reaped=True,first_Root_fault=state['first_fault'] is not None,
        result=raw_pin(output),native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory/'worker-header.json',serialize(header,CAPS['log_bytes']))
    print(json.dumps(dict(case_id=case,status=header['status'],callbacks=state['callbacks'],seconds=time.monotonic()-began)))
    return 0 if primary is None and source_unchanged and time.monotonic()-began < CAPS['positive_seconds'] and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < CAPS['memory_bytes'] else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: fpc_frozen_target_contextual_reuse_worker_v2.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1],sys.argv[2],float(sys.argv[3])))

