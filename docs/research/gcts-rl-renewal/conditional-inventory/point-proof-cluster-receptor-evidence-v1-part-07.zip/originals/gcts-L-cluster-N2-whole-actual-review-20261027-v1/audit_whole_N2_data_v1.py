"""Independent standard-data review only. Never imports/calls a subject module."""
from pathlib import Path
import base64, collections, hashlib, json, math, os, stat, zlib
R=Path('/private/tmp/gcts-cluster-receptors-20261027-v2'); A=R/'actual-v1'; OUT=Path(__file__).parent
CAP=67108864; AGG=268435456

def encoded(x): return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(x): return hashlib.sha256(encoded(x)).hexdigest()
def bh(x): return hashlib.sha256(x).hexdigest()
def need(x,m):
 if not x: raise AssertionError(m)
def parse(b):
 def pairs(xs):
  d={}
  for k,v in xs: need(k not in d,'duplicate key'); d[k]=v
  return d
 def no(x): raise ValueError('nonfinite '+x)
 return json.loads(b,object_pairs_hook=pairs,parse_constant=no)
def raw(p,cap=CAP):
 need(p.is_absolute() and p.resolve()==p and not any(q.is_symlink() for q in (p,*p.parents)),'canonical nonsymlink '+str(p))
 s=p.stat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=cap,'file type/extent '+str(p));b=p.read_bytes();t=p.stat();need((s.st_dev,s.st_ino,s.st_mtime_ns,s.st_size)==(t.st_dev,t.st_ino,t.st_mtime_ns,t.st_size) and len(b)==s.st_size,'stable '+str(p));return b
def pin(p,b=None):
 if b is None:b=raw(p,max(CAP,p.stat().st_size))
 return {'path':str(p),'bytes':len(b),'sha256':bh(b)}
def ref(r,cap=CAP):
 need(type(r)is dict and set(r)=={'path','bytes','sha256'} and type(r['bytes'])is int and 0<=r['bytes']<=cap and type(r['path'])is str and type(r['sha256'])is str and len(r['sha256'])==64,'rawref3');b=raw(Path(r['path']),cap);need(pin(Path(r['path']),b)==r,'rawref matches '+r['path']);return b
def load(p):
 b=raw(p);return parse(b)

def decode(env,schema,encoding,cap):
 need(type(env)is dict and set(env)=={'schema','encoding','record_count','raw_bytes','raw_sha256','compressed_bytes','compressed_sha256','data_base64'},'envelope8')
 need(env['schema']==schema and env['encoding']==encoding,'envelope literals')
 for k in ('record_count','raw_bytes','compressed_bytes'):need(type(env[k])is int and env[k]>=0,'typed codec count')
 need(env['raw_bytes']<=cap,'codec raw limit')
 for k in ('raw_sha256','compressed_sha256'):need(type(env[k])is str and len(env[k])==64 and all(c in '0123456789abcdef' for c in env[k]),'codec digest')
 need(type(env['data_base64'])is str,'codec string');c=base64.b64decode(env['data_base64'],validate=True);need(base64.b64encode(c).decode()==env['data_base64'] and len(c)==env['compressed_bytes'] and bh(c)==env['compressed_sha256'],'full compressed bytes')
 z=zlib.decompressobj();d=hashlib.sha256();parts=[];n=0
 for i in range(0,len(c),32768):
  pending=c[i:i+32768]
  while pending:
   before=len(pending);v=z.decompress(pending,32768);pending=z.unconsumed_tail
   need(not z.unused_data and (v or len(pending)<before),'single stream/progress');n+=len(v);need(n<=cap,'decoded cap');d.update(v);parts.append(v)
 need(z.eof and not z.unused_data and not z.unconsumed_tail and n==env['raw_bytes'] and d.hexdigest()==env['raw_sha256'],'complete decoded extent/hash/EOF')
 b=b''.join(parts);need(b.count(b'\n')==env['record_count'] and b.endswith(b'\n'),'whole document/row count');return b

capture_path=R/'root/cluster-N2-owned-complete-capture-association-v1.json';capture=load(capture_path);need(pin(capture_path)['sha256']=='820884a1a403ad54939dc12e46932028fe3e4fe0efe036574dd18e4e099820b7','capture pin')
custody=load(A/'custody-terminal.json');result=load(A/'result.json');index=load(A/'whole-study-index.json')
plan=parse(ref(custody['plan'],1048576));authority=parse(ref(custody['authority'],1048576));consume=parse(ref(custody['consume'],1048576))
need(set(plan)=={'schema','run_id','role_pins','python','limits','actual_dir','source_contract','offer'} and plan['actual_dir']==str(A),'plan8')
need(authority=={'schema':'GCTS-cluster-receptor-once-authority-v1','authorized':True,'uses':1,'plan':custody['plan'],'observer':plan['role_pins']['observer'],'python':plan['python']},'A6')
need(consume=={'schema':'GCTS-cluster-receptor-once-consumed-v1','uses':1,'authority':custody['authority'],'plan':custody['plan'],'observer':plan['role_pins']['observer'],'python':plan['python'],'child_started_at_consume':False},'consume7')
need(custody['worker_returncode']==0 and custody['status']=='COMPLETE_NORMAL_WORKER_REVIEW_PENDING' and custody['scientific_admission'] is False and custody['cleanup']==[],'normal custody')
need(capture['authoritative_tool_completion']['exit_code']==0 and capture['owned_session_id']==41795,'authoritative terminal')
for k in ['outer_stdout','outer_stderr','worker_stdout','worker_stderr','custody','result','authority','consume']:ref(capture[k])
outer=parse(raw(Path(capture['outer_stdout']['path'])).splitlines()[-1]);need(outer==custody,'whole outer last receipt')
wlines=raw(A/'worker-stdout.bin').splitlines();worker_terminal=parse(wlines[-1]);need(worker_terminal=={'schema':'GCTS-cluster-receptor-worker-terminal-v1','status':'COMPLETE','result':pin(A/'result.json'),'actual_named_bytes':custody['named_worker_output_bytes'],'actual_named_files':custody['named_worker_output_files']},'full worker terminal')
need(not raw(A/'worker-stderr.bin') and not raw(Path(capture['outer_stderr']['path'])),'both empty stderrs')
need(result['role_pins']==custody['role_pins']==plan['role_pins'] and result['status']=='COMPLETE_BOUNDED_STUDY_REVIEW_PENDING' and result['run_id']==plan['run_id']==custody['run_id'],'result associations')
guards=[]
for r in plan['role_pins'].values():ref(r,2097152);guards.append(r)
ref(plan['python'],18058560);guards.append(plan['python'])
contract=parse(ref(plan['source_contract'],1048576));offer=parse(ref(plan['offer'],1048576));guards.extend([plan['source_contract'],plan['offer']])
need(set(contract)=={'schema','resolution','inputs','role_pins','module_versions','configuration','public_ABIs','scope','execution_authorized'} and contract['role_pins']==plan['role_pins'] and contract['configuration']['limits']==plan['limits'] and contract['execution_authorized'] is False,'contract9')
resolution=parse(ref(contract['resolution'],1048576));guards.append(contract['resolution']);need(contract['inputs']==resolution['inputs'],'input associations')
need(len(contract['public_ABIs'])==18,'18 public guards')
for r in contract['public_ABIs']:ref(r,1048576);guards.append(r)
for r in contract['inputs'].values():ref(r);guards.append(r)
refs=result['artifacts'];need(len(refs)==183 and custody['artifacts']==refs,'183 all originals');names=[Path(r['path']).name for r in refs];need(len(set(names))==183,'unique names');rank={n:i for i,n in enumerate(names)}
original_census=[];total=0
for rr in refs:
 need(Path(rr['path']).parent==A and Path(rr['path']).suffix=='.json','direct output');b=ref(rr);need(encoded(parse(b))==b,'canonical named body');total+=len(b);original_census.append(rr)
need(total==result['named_bytes_before_final_result']==145318744 and total+pin(A/'result.json')['bytes']==custody['named_worker_output_bytes']==145355866 and custody['named_worker_output_files']==184,'stored aggregate')
need(total+pin(A/'result.json')['bytes']<=AGG,'aggregate cap')
physical={p.name for p in A.iterdir()};need(physical==set(names)|{'result.json','worker-stdout.bin','worker-stderr.bin','custody-terminal.json'} and len(physical)==187,'187 exact census')
need(custody['owned_child_lifetime_RSS_highwater_bytes']==449232896<=plan['limits']['observed_worker_RSS_limit_bytes'] and custody['before_Popen_through_owned_wait_seconds']<720 and result['worker_main_entry_before_final_result_seconds']<600,'measured budgets')
need(custody['authenticated_worker_source_bytes_delivered']==plan['role_pins']['worker']['bytes']==59201,'retained bytes delivered')
need(custody['owned_process_group']==custody['owned_worker_pid'] and custody['command'][0]==plan['python']['path'] and custody['command'][1:5]==['-I','-S','-B','-c'],'command bootstrap')
bootstrap=custody['command'][5];need(len(bootstrap.encode())==344 and bh(bootstrap.encode())=='f0fb00e11e4d22c78467a2182f4f1e980578d5ec064c3fb3031c6c8dad345b62','bootstrap bytes')

NORM={'schema','selected','assigned','excluded','active_candidates','physical_domains','eligible_domains','forward_incidence','reverse_incidence'}
NATIVE={'schema','selected','excluded','totals','markings','point_generations','tile_generations','frontier','candidate_rows','active_candidates','forward_incidence','reverse_incidence','trail_size'}
arm_rows=[];compact={};cost_by_name={Path(t['body']['path']).name:t for t in index['arm_costs']}
main_rows=index['training']+index['evaluation'];need(len(main_rows)==112 and len(cost_by_name)==112,'112 full arms/costs')
for num,item in enumerate(main_rows):
 name=Path(item['record']['path']).name;rr=item['record'];need(rr==refs[rank[name]],'index rawref');env=parse(ref(rr));b=decode(env,'GCTS-lossless-cluster-main-arm-v1','CANONICAL_JSON_ZLIB1_BASE64',CAP);need(env['record_count']==1,'outer single doc');arm=parse(b);need(encoded(arm)==b and arm['schema']=='GCTS-cluster-receptor-main-arm-v1','canonical decoded whole arm')
 mh=sha(arm['model']);sp=arm['spec'];sh=None if sp is None else sha(sp);engine=arm['engine'];need(engine==item['engine'],'engine association')
 need(arm['restored']==arm['entry'] and arm['restored_entry_exact'] is True,'complete exact rollback '+name)
 need(set(arm['entry'])==(NATIVE if engine=='POINT' else NORM) and set(arm['native_final'])==set(arm['entry']) and set(arm['restored'])==set(arm['entry']),'complete native carriers')
 need(arm['checkpoint_receipt']['state_sha256']==sha(arm['entry']) and arm['checkpoint_receipt']['model_sha256']==mh and arm['rollback_check']['checkpoint_sha256']==sha(arm['entry']),'checkpoint/rollback hashes')
 for key in ['indexed_preparation','cluster_preparation']:
  if arm[key]is not None:need(arm[key]['model_sha256']==mh and (arm[key]['raw_model_sha256']==mh if key=='indexed_preparation' else arm[key]['raw_model_sha256'] is None),'prepared model binding')
 for key in ['result_check','final_check','rollback_check']:
  need(arm[key]['status']=='VERIFIED' and arm[key]['model_sha256']==mh and arm[key]['raw_model_sha256']==mh,'independent return model/status')
 if engine=='POINT':need(arm['return']['model']==arm['model'] and arm['result_check']['status_checked']==arm['return']['status'],'point result full model')
 else:
  need(sp['model']==arm['model'] and arm['return']['model_sha256']==mh and arm['return']['spec_sha256']==sh and arm['return']['entry']==arm['entry'] and arm['return']['final']==arm['native_final'],'CSP result/spec/entry/final')
  need(arm['result_check']['spec_sha256']==sh and arm['result_check']['event_scope']=='CERTIFICATE_ENTRY_FINAL_ONLY','CSP certificate scope')
  ck=arm['return']['certificate'];need(ck['model_sha256']==mh and ck['spec_sha256']==sh,'CSP whole certificate hash associations')
 need(arm['return']['selected']==arm['native_final']['selected'] and arm['return']['context']=={'selected':arm['entry']['selected'],'excluded':arm['entry']['excluded']},'exact result context/selected')
 if arm['search_window']['triggered']:need(arm['return']['status']=='UNKNOWN','window unknown')
 need(arm['feedback_required_points'] in (20,72),'nonseed obligations')
 # Decode complete inner stream independently; every row is parsed and hash-bound.
 inner=arm['audit_log'];ib=decode(inner,'GCTS-lossless-runtime-audit-log-v1','CANONICAL_JSONL_ZLIB1_BASE64',AGG)
 event_trace=[];kinds=collections.Counter();observed={};pchecks={};events=0;maxfilled=0;receipt_counts=collections.Counter();proposal_sha={x['index']:sha(x) for x in arm['proposal_evidence']}
 def state_check(v,native_hash=None):
  need(v['status']=='VERIFIED' and v['model_sha256']==mh and v['raw_model_sha256']==mh,'row verified/model');s=v['normalized_state'];need(set(s)==NORM and v['state_sha256']==sha(s) and v['domains_sha256']==sha(s['eligible_domains']),'whole normalized9 hashes')
  if sh is not None:need(v['spec_sha256']==sh,'row spec hash')
  if native_hash is not None and 'snapshot_sha256'in v:need(v['snapshot_sha256']==native_hash,'native snapshot argument hash')
  receipt_counts[v['schema']]+=1;return s
 for rowb in ib.splitlines(keepends=True):
  need(len(rowb)<=CAP,'decoded inner row cap');row=parse(rowb);need(encoded(row)==rowb,'canonical whole inner row');kinds[row['kind']]+=1
  if row['kind']=='NATIVE_EVENT':
   s=state_check(row['verification'],row['native_snapshot_sha256']);events+=1;need(row['verification']['events_checked']==events,'event cursor count');maxfilled=max(maxfilled,len(s['assigned']));e=row['event'];data={'restored_state_sha256':sha(s)} if e['kind']=='ROLLED_BACK' else e['data'];event_trace.append({'seq':len(event_trace),'kind':e['kind'],'data':data,'domains_sha256':sha(s['eligible_domains']),'state_sha256':sha(s)})
  elif row['kind']=='PROPOSAL_OBSERVATION':
   s=state_check(row['verification'],row['native_snapshot_sha256']);ob=row['observation'];oh=sha(ob);v=row['observation_check'];need(v['status']=='VERIFIED' and v['model_sha256']==mh and v['state_sha256']==sha(s) and v['observation_sha256']==oh,'observation check binding');need(ob['selected']==s['selected'] and ob['excluded']==[x['id'] for x in s['excluded']] and ob['model_sha256']==mh,'full observation context');observed[oh]=sha(s)
  elif row['kind']=='PROPOSAL_VALIDATED':
   s=state_check(row['state_verification'],row['native_snapshot_sha256']);p=row['producer_receipt'];v=row['independent_verification'];need(v['status']=='VERIFIED_COMPLETE_CLUSTER_ORDER' and v['model_sha256']==mh and v['receipt_sha256']==sha(p)==proposal_sha[p['index']] and v['state_sha256']==sha(s) and v['observation_sha256']==p['observation_sha256'] and v['ordered_candidates']==p['ordered_candidates'],'complete same-instance proposal binding');pchecks[p['index']]=v['status']
  elif row['kind']=='PROPOSAL_NONFINAL':
   p=row['producer_receipt'];v=row['independent_verification'];need(v['status']=='VERIFIED_NONFINAL_ENVELOPE_ONLY' and p['status']!='VALIDATED' and sha(p)==proposal_sha[p['index']] and sha(row['observed_normalized_state'])==observed[p['observation_sha256']],'nonfinal origin/state');pchecks[p['index']]=v['status']
  else:raise AssertionError('unknown log row kind '+row['kind'])
 need(len(ib.splitlines())==inner['record_count'] and event_trace==arm['trace']+arm['cleanup_trace'] and maxfilled==arm['max_verified_filled'],'complete event/trace/maxfilled joins')
 need(set(pchecks)==set(proposal_sha),'all producer receipts independently associated')
 if arm['actor_final']is None:need(not arm['proposal_evidence'] and arm['actor_entry']is None and arm['independent_actor_check']is None and all(x==0 for x in arm['proposal_metrics'].values()),'no-proposer zero path')
 else:
  ac=arm['independent_actor_check'];need(ac['status']=='VERIFIED_BOUND_ACTOR_TRAJECTORY' and ac['model_sha256']==mh and ac['snapshot_sha256']==sha(arm['actor_final']) and ac['policy_sha256']==sha(arm['actor_final']['policy']) and ac['constructor_config_sha256']==sha(arm['actor_entry']['config']) and ac['kernel_receipt_sha256']==sha(arm['proposal_evidence']),'whole actor/kernel check bindings');need(arm['actor_entry']['policy']==arm['actor_final']['policy'] and arm['actor_entry']['calls']==[],'frozen fresh actor')
 for k in ['final_check','rollback_check']:
  v=arm[k];need(v['status']=='VERIFIED' and set(v['normalized_state'])==NORM,'complete final/rollback normalized')
 need(arm['final_check'].get('snapshot_sha256',arm['final_check']['state_sha256'])==sha(arm['native_final']),'final complete carrier hash')
 ct=cost_by_name[name];need(ct['body']==rr and type(ct['through_complete_body_write_seconds'])is float and math.isfinite(ct['through_complete_body_write_seconds']) and ct['through_complete_body_write_seconds']>=arm['elapsed_before_outer_body_serialization']>=0,'throughwrite clock')
 arow={'name':name,'stored':rr,'decoded_outer':{k:v for k,v in env.items()if k!='data_base64'},'decoded_inner':{k:v for k,v in inner.items()if k!='data_base64'},'engine':engine,'strategy':arm['strategy'],'input':arm['input'],'seed':arm['seed'],'marking_version':arm['marking_version'],'model_sha256':mh,'spec_sha256':sh,'status':arm['return']['status'],'reason':arm['return']['reason'],'nodes':arm['return']['nodes'],'search_window':arm['search_window'],'result_check':arm['result_check'],'event_rows':events,'row_kinds':dict(kinds),'proposal_rows':len(pchecks),'actor_calls':0 if arm['actor_final']is None else len(arm['actor_final']['calls']),'actor_policy_sha256':None if arm['actor_final']is None else sha(arm['actor_final']['policy']),'actor_snapshot_sha256':None if arm['actor_final']is None else sha(arm['actor_final']),'actor_entry_config':None if arm['actor_entry']is None else arm['actor_entry']['config'],'all_rows_current_state_hash_bound':True,'exact_entry_rollback':True,'through_complete_body_write_seconds':ct['through_complete_body_write_seconds']}
 arm_rows.append(arow)
 compact[name]={'record':rr,'model_sha256':mh,'context':arm['return']['context'],'trace':arm['trace'],'cleanup_trace':arm['cleanup_trace'],'status':arm['return']['status'],'nodes':arm['return']['nodes'],'metrics':arm['return']['metrics'],'window':arm['search_window'],'result_check':arm['result_check'],'actor_final_sha256':arow['actor_snapshot_sha256'],'policy_sha256':arow['actor_policy_sha256'],'actor_candidate_visits':None if arm['actor_final']is None else arm['actor_final']['costs']['candidate_feature_visits'],'required':arm['feedback_required_points'],'maxfilled':arm['max_verified_filled'],'input':arm['input'],'marking_version':arm['marking_version'],'seed':arm['seed'],'strategy':arm['strategy'],'engine':engine}
 if num%8==7:print('FULL_ARMS_CHECKED',num+1,flush=True)

data={'schema':'L-cluster-N2-whole-raw-and-stream-audit-v1','scope':'Independent standard-data raw/JSON/zlib/hash/field association only; no project imports, helpers, scientific checker or proof algorithm replay. All arms and every inner row checked, not sampled.','capture':pin(capture_path),'custody':pin(A/'custody-terminal.json'),'result':pin(A/'result.json'),'index':pin(A/'whole-study-index.json'),'all183_originals':original_census,'all_current_direct_guards':guards,'physical187':[pin(A/n)for n in sorted(physical)],'named_stored_bytes':custody['named_worker_output_bytes'],'named_count':184,'physical_count':187,'arms':arm_rows,'compact_for_remaining_paired_data_joins':compact,'clock_and_RSS':{k:custody[k]for k in ['Popen_call_seconds','before_Popen_through_owned_wait_seconds','after_Popen_return_through_owned_wait_seconds','owned_child_lifetime_RSS_highwater_bytes','observer_lifetime_RSS_highwater_bytes_at_sample','clock_tail','RSS_scope']},'worker_cost_sample':{k:result[k]for k in ['worker_main_entry_before_final_result_seconds','worker_lifetime_RSS_bytes_at_sample','budget_callbacks_at_sample','clock_tail']},'subject_execution_count':0,'status':'COMPLETE_RAW_AND_ALL112_STREAM_CHECKS_PASS_REMAINING_COHORT_QUALIFICATION_JOINS_PENDING'}
p=OUT/'cluster-N2-complete-raw-and-112-stream-audit-v1.json';p.write_bytes((json.dumps(data,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode());print('RAW_STREAM_SUPPORT',pin(p),flush=True)
