Cluster/receptor complete evidence volume 7 of 8

ALL EIGHT FILES ARE NEEDED for the complete evidence collection. Each file is an ordinary, independent ZIP archive; extract every volume normally into one empty common directory, or extract separately and combine their nonoverlapping original paths. Do not concatenate ZIP files or treat them as a split ZIP stream.

The complete self-excluding global original manifest is catalogue/complete-evidence-global-manifest-v1.json in volume 1. It maps every immutable original absolute path to its stable relative extraction name, part, byte count and SHA256. Each original is present once; no content deduplication or scientific reencoding occurred.

Volume files:
point-proof-cluster-receptor-evidence-v1.zip
point-proof-cluster-receptor-evidence-v1-part-02.zip
point-proof-cluster-receptor-evidence-v1-part-03.zip
point-proof-cluster-receptor-evidence-v1-part-04.zip
point-proof-cluster-receptor-evidence-v1-part-05.zip
point-proof-cluster-receptor-evidence-v1-part-06.zip
point-proof-cluster-receptor-evidence-v1-part-07.zip
point-proof-cluster-receptor-evidence-v1-part-08.zip

This part contains 89 original files, 59272728 raw original bytes. N1 failed originals remain failed/unadmitted/spent. N2 admission is only the exact stored finite-study Root disposition. Final web HTML/summary and later publication/TLS/browser receipts are deliberately outside this archive preparation cut. Source/static/old draft documents preserve chronology, not an independent new admission.
