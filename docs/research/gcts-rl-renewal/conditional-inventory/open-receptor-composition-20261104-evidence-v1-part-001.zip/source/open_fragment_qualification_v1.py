"""Inert local-fragment qualification recipes; execute only after freeze.

The small fixture is synthetic local ABI data, not a target theorem, searched
proof, full RF/N admission or observed E state. It supplies no target witness.
Actual materialization controls use the newly materialized library unchanged.
"""
import copy
import time


def need(ok,reason):
    if not ok:raise ValueError(reason)


def limits(ctx):
    return dict(ctx.limits.get('family',ctx.limits.get('X',{})))


def run_library(ctx,old,library):
    x=ctx.mods['X'];rows=[]
    for name in ('actual-materialization','foreign-source','missing-fragment','outside-payload','missing-receptor','zero-work'):
        value=copy.deepcopy(library);lim=limits(ctx)
        if name=='foreign-source':value['source_library_sha256']='0'*64
        elif name=='missing-fragment':
            need(value['fragments'],'MATERIALIZATION_FIXTURE_NOT_EXERCISED');value['fragments'].pop()
        elif name=='outside-payload':
            need(value['fragments'],'MATERIALIZATION_FIXTURE_NOT_EXERCISED');f=value['fragments'][0]
            f['outside_payloads']=[];f['id']=ctx.sha({k:v for k,v in f.items() if k!='id'})
        elif name=='missing-receptor':
            need(value['fragments'],'MATERIALIZATION_FIXTURE_NOT_EXERCISED');f=value['fragments'][0]
            f['receptors']=[];f['id']=ctx.sha({k:v for k,v in f.items() if k!='id'})
        elif name=='zero-work':lim['max_work']=0
        prefix='data/open-qualification/library/'+name
        inp=ctx.save(prefix+'-input.json.gz',dict(source_library=old,library=value,limits=lim))
        started=time.perf_counter();answer=x.verify_materialization(old,value,lim)
        ref=ctx.save(prefix+'-receipt.json',answer)
        expected='VERIFIED_MATERIALIZATION' if name=='actual-materialization' else 'UNKNOWN' if name=='zero-work' else 'REJECTED'
        rows.append(dict(id=name,input=inp,receipt=ref,status=answer['status'],seconds=time.perf_counter()-started))
        need(answer['status']==expected,'OPEN_LIBRARY_CONTROL:'+name)
    return dict(status='QUALIFIED',records=rows,scope='Exact newly materialized source extraction and corrupted-data controls only; no native or target proof claim.')


def fixture(ctx):
    c=['fun','c',[]];p=lambda t:['pred','P',[t]];q=lambda t:['pred','Q',[t]]
    pc,qc=p(c),q(c);imp=['imp',pc,qc];allq=['all','u',qc]
    theory=dict(functions={'c':0,'d':0},predicates={'P':1,'Q':1},axioms={'p':pc,'h':imp})
    zero_p=dict(rule='axiom',name='p',formula=pc);zero_h=dict(rule='axiom',name='h',formula=imp)
    forms=[pc,qc,imp,allq];definitions=dict(zeros=[dict(id='zP',output=1,native=zero_p),dict(id='zH',output=3,native=zero_h)],
        mp=[dict(id='mp:3',antecedent=1,implication=3,output=2)],
        gen=[dict(id='gen:4',source=2,output=4,variable='u')])
    statement=dict(theory=theory,goal=allq)
    cat=dict(statement=statement,formulas=forms,zeros=[dict(id='zP',native=zero_p),dict(id='zH',native=zero_h)],
        mp=[dict(antecedent=1,implication=3,output=2)],gen=[dict(source=2,output=4,variable='u')])
    prepared=dict(schema='Shared-fact-prepared-v2',status='PREPARED_UNVERIFIED',statement=statement,catalogue=cat,
        binding=dict(slots=4,scope='SYNTHETIC_LOCAL_ABI_NOT_RF_ADMITTED',catalogue_sha256=ctx.sha(cat),original_statement_sha256=ctx.sha(statement)),
        definitions=definitions)
    def row(slot,kind,did,refs,fid,premises,extra=()):
        marks={'a:'+str(slot):'1','f:'+str(slot):str(fid)}
        for s,f in premises:marks['a:'+str(s)]='1';marks['f:'+str(s)]=str(f)
        marks.update(dict(extra))
        return dict(id=ctx.wire([slot,kind,did,refs]).decode('ascii'),t=[['q:'+str(slot),1]],m=sorted([[k,v] for k,v in marks.items()]))
    rows=[row(0,'ZERO','zP',[],1,[]),row(1,'ZERO','zH',[],3,[]),
        row(2,'MP','mp:3',[0,1],2,[(0,1),(1,3)]),row(3,'GEN','gen:4',[2],4,[(2,2)],[['guard','0']]),
        row(2,'ZERO','zP',[],1,[])]
    rows.sort(key=lambda r:r['id'])
    model=dict(schema='Z-growing-point-model-v3',version='OPEN_SYNTHETIC_LOCAL_ABI_v1',capacity=1,
        roots=['q:0','q:1','q:2','q:3'],seed=dict(t=[],m=[['guard','0']]),
        inventory=dict(kind='EXPLICIT',placements=rows),pair_nogoods=[],unary_nogoods=[])
    t=['_term','T0'];pt,qt=p(t),q(t)
    f=dict(family_id='synthetic-source-family',cluster_id='synthetic-source-cluster',root=3,members=[2,3],
        lines=[[2,dict(rule='mp',antecedent=0,implication=1,formula=qt)],
               [3,dict(rule='generalize',source=2,variable='u',formula=['all','u',qt])]],
        receptors=[[0,pt],[1,['imp',pt,qt]]],parameters=dict(terms=['T0'],contexts=[]))
    f=dict(id=ctx.sha(f),**f)
    axiom_fragment=dict(family_id='synthetic-source-family',cluster_id='synthetic-axiom-cluster',root=2,members=[1,2],
        lines=[[1,dict(rule='axiom',name='h',formula=['imp',pt,qt])],
               [2,dict(rule='mp',antecedent=0,implication=1,formula=qt)]],
        receptors=[[0,pt]],parameters=dict(terms=['T0'],contexts=[]))
    axiom_fragment=dict(id=ctx.sha(axiom_fragment),**axiom_fragment)
    library=dict(schema='Open-fragment-library-v1',status='MATERIALIZED',source_library_sha256='0'*64,
        donor_lines=5,fragments=sorted([f,axiom_fragment],key=lambda f:f['id']),costs={},limits=limits(ctx),
        scope='SYNTHETIC_LOCAL_ABI_NOT_MATERIALIZATION_OR_THEOREM')
    prepared['universe']=copy.deepcopy(rows)
    mp=next(r['id'] for r in rows if r['id']==ctx.wire([2,'MP','mp:3',[0,1]]).decode('ascii'))
    gen=next(r['id'] for r in rows if r['id']==ctx.wire([3,'GEN','gen:4',[2]]).decode('ascii'))
    inst=dict(fragment_id=f['id'],bindings=dict(terms={'T0':c},contexts={}),slot_map=[[0,0],[1,1],[2,2],[3,3]],
        line_cids=[[2,mp],[3,gen]],receptors=[[0,0,pc],[1,1,imp]],anchor_cid=gen)
    inst=dict(id=ctx.sha(inst),**inst)
    return prepared,model,library,inst


def run_instances(ctx,prepared,model,library):
    # Original caller objects are not mutated or treated as the synthetic model.
    x=ctx.mods['X'];p,m,lib,instance=fixture(ctx);lim=limits(ctx);records=[]
    prefix='data/open-qualification/instances/'+prepared['binding']['scope'][:16]
    setup=ctx.save(prefix+'/synthetic-fixture.json.gz',dict(prepared=p,model=m,library=lib,instance=instance,
        scope='Synthetic local admission/state requests; not an RF/N-admitted target or observed E state.'))
    checker=x.AdmissionChecker(p,m,lib,lim)
    index=ctx.save(prefix+'/index.json',dict(status=checker.status,reason=checker.reason))
    need(checker.status=='READY','SYNTHETIC_OPEN_INDEX_READY')
    for name in ('actual-local-fragment','wrong-parameter','wrong-receptor-formula','wrong-receptor-slot','wrong-current-CID','zero-work'):
        value=copy.deepcopy(instance);limit=dict(lim)
        if name=='wrong-parameter':value['bindings']['terms']['T0']=['fun','d',[]]
        elif name=='wrong-receptor-formula':value['receptors'][0][2]=['pred','Q',[['fun','c',[]]]]
        elif name=='wrong-receptor-slot':value['receptors'][0][1]=1
        elif name=='wrong-current-CID':value['line_cids'][0][1]='not-a-current-CID'
        elif name=='zero-work':limit['max_work']=0
        value['id']=ctx.sha({k:v for k,v in value.items() if k!='id'})
        inp=ctx.save(prefix+'/'+name+'-input.json.gz',dict(instance=value,limits=limit))
        subject=x.AdmissionChecker(p,m,lib,limit) if name=='zero-work' else checker
        answer=subject.admit(value);ref=ctx.save(prefix+'/'+name+'-receipt.json',answer)
        expected='VERIFIED_INSTANCE' if name=='actual-local-fragment' else 'UNKNOWN' if name=='zero-work' else 'REJECTED'
        records.append(dict(id=name,input=inp,receipt=ref,status=answer['status']))
        need(answer['status']==expected,'OPEN_INSTANCE_CONTROL:'+name)
    # Mutate a real GEN binder while preserving every ordinary ID preimage.
    badlib=copy.deepcopy(lib);f=next(f for f in badlib['fragments'] if any(line['rule']=='generalize' for i,line in f['lines']))
    f['lines'][1][1]['variable']='other'
    f['id']=ctx.sha({k:v for k,v in f.items() if k!='id'});bad=copy.deepcopy(instance);bad['fragment_id']=f['id']
    badlib['fragments'].sort(key=lambda f:f['id'])
    bad['id']=ctx.sha({k:v for k,v in bad.items() if k!='id'})
    inp=ctx.save(prefix+'/wrong-binder-input.json.gz',dict(library=badlib,instance=bad))
    answer=x.AdmissionChecker(p,m,badlib,lim).admit(bad);ref=ctx.save(prefix+'/wrong-binder-receipt.json',answer)
    records.append(dict(id='wrong-binder',input=inp,receipt=ref,status=answer['status']));need(answer['status']=='REJECTED','OPEN_BINDER_MUTANT')
    mp,gen=[c for i,c in instance['line_cids']]
    alternative=ctx.wire([2,'ZERO','zP',[]]).decode('ascii')
    base=dict(schema='Z-candidate-order-request-v1',model_sha256=checker.model_sha256,point='q:2',generation=0,
        legal=[mp],selected=[],excluded=[])
    states=[]
    for name in ('missing-receptors-permitted','shared-once-anchor-selected','distinct-owner-overlap','local-excluded','restored-exclusion'):
        query=copy.deepcopy(base)
        if name=='shared-once-anchor-selected':query['selected']=[gen]
        elif name=='distinct-owner-overlap':query['selected']=[alternative]
        elif name=='local-excluded':query['excluded']=[gen]
        inp=ctx.save(prefix+'/'+name+'-input.json.gz',dict(instance=instance,request=query))
        charged=[0]
        def charge(n):charged[0]+=n
        answer=checker.check(instance,query,charge);ref=ctx.save(prefix+'/'+name+'-receipt.json',answer)
        expected='REJECTED' if name in ('distinct-owner-overlap','local-excluded') else 'COMPATIBLE'
        states.append(dict(id=name,input=inp,receipt=ref,status=answer['status'],charged_work=charged[0]))
        need(answer['status']==expected,'OPEN_STATE_CONTROL:'+name)
        if name=='shared-once-anchor-selected':need(answer['shared_members']==1,'OPEN_SHARED_SELECTED_COUNTED_ONCE')
    # An explicit seed zero rejects a row with one; absent seed assignment permits it.
    marked=copy.deepcopy(m)
    for r in marked['inventory']['placements']:
        if r['id']==gen:r['m']=[[k,'1' if k=='guard' else v] for k,v in r['m']]
    zero_records=[]
    for name in ('assigned-zero','absent-zero'):
        variant=copy.deepcopy(marked)
        if name=='absent-zero':variant['seed']['m']=[]
        inp=ctx.save(prefix+'/'+name+'-input.json.gz',dict(model=variant,instance=instance))
        answer=x.AdmissionChecker(p,variant,lib,lim).admit(instance)
        ref=ctx.save(prefix+'/'+name+'-receipt.json',answer);zero_records.append(dict(id=name,input=inp,receipt=ref,status=answer['status']))
        need(answer['status']==('REJECTED' if name=='assigned-zero' else 'VERIFIED_INSTANCE'),'OPEN_ZERO_IS_ASSIGNED:'+name)
    class ChargeStop(Exception):pass
    inp=ctx.save(prefix+'/charge-stop-input.json.gz',dict(instance=instance,request=base))
    def stop(n):raise ChargeStop('QUALIFICATION_SENTINEL')
    try:checker.check(instance,base,stop)
    except ChargeStop:answer=dict(status='PROPAGATED')
    else:answer=dict(status='NOT_PROPAGATED')
    ref=ctx.save(prefix+'/charge-stop-receipt.json',answer);need(answer['status']=='PROPAGATED','OPEN_CHARGE_PROPAGATION')
    # Actual local matching, with a poisoned irrelevant global statement/field.
    # The modified prepared packet is deliberately NOT an RF/N-admitted model.
    l=ctx.mods['L'];proposer=l.LocalProposer(p,m,lib,lim)
    query_input=ctx.save(prefix+'/local-proposal-input.json.gz',dict(prepared=p,model=m,library=lib,anchor_cid=gen))
    proposals=proposer.propose(gen);query_ref=ctx.save(prefix+'/local-proposal-receipt.json.gz',proposals)
    need(proposals['status']=='CANDIDATE_FRAGMENTS' and proposals['instances'],'ACTUAL_LOCAL_PROPOSAL_EXERCISED')
    admitted=[]
    for i,value in enumerate(proposals['instances']):
        answer=checker.admit(value);answer_ref=ctx.save(prefix+'/local-proposal-admit-'+str(i)+'.json',answer)
        admitted.append(dict(instance_sha256=ctx.sha(value),receipt=answer_ref))
        need(answer['status']=='VERIFIED_INSTANCE','PROPOSED_LOCAL_INSTANCE_INDEPENDENT_ADMISSION')
    admitted_ref=ctx.save(prefix+'/local-proposal-admissions.json.gz',admitted)
    # Internal native axiom gate regression: actual key is name, not axiom.
    axiom_input=ctx.save(prefix+'/internal-axiom-proposal-input.json.gz',dict(anchor_cid=mp,prepared=p,model=m,library=lib))
    axiom_proposals=proposer.propose(mp)
    axiom_ref=ctx.save(prefix+'/internal-axiom-proposals.json.gz',axiom_proposals)
    need(axiom_proposals['status']=='CANDIDATE_FRAGMENTS' and axiom_proposals['instances'],'INTERNAL_AXIOM_PROPOSAL_EXERCISED')
    axiom_admissions=[]
    for i,value in enumerate(axiom_proposals['instances']):
        fragment=next(f for f in lib['fragments'] if f['id']==value['fragment_id'])
        need(any(line['rule']=='axiom' and 'name' in line for j,line in fragment['lines']),'INTERNAL_NATIVE_AXIOM_PRESENT')
        answer=checker.admit(value);answer_ref=ctx.save(prefix+'/internal-axiom-admit-'+str(i)+'.json',answer)
        axiom_admissions.append(dict(instance_sha256=ctx.sha(value),receipt=answer_ref))
        need(answer['status']=='VERIFIED_INSTANCE','INTERNAL_NATIVE_NAMED_AXIOM_ADMISSION')
    axiom_admissions_ref=ctx.save(prefix+'/internal-axiom-admissions.json.gz',axiom_admissions)
    changed=copy.deepcopy(p);changed['statement']=copy.deepcopy(p['statement'])
    changed['statement']['goal']=['pred','P',[['fun','c',[]]]]
    changed['unrelated_outside_field']={'unused':'OUTSIDE_PAYLOAD_SENTINEL'}
    invariant_input=ctx.save(prefix+'/stage-invariance-input.json.gz',dict(prepared=changed,model=m,library=lib,
        anchor_cid=gen,scope='Intentionally changed irrelevant global metadata; no full RF/N admission claim.'))
    repeated=l.LocalProposer(changed,m,lib,lim).propose(gen)
    invariant_ref=ctx.save(prefix+'/stage-invariance-receipt.json.gz',repeated)
    need(repeated['status']=='CANDIDATE_FRAGMENTS' and ctx.wire(repeated['instances'])==ctx.wire(proposals['instances']),
         'LOCAL_PROPOSAL_INDEPENDENT_OF_WHOLE_GOAL_AND_OUTSIDE_FIELD')
    try:proposer.propose(gen,stop)
    except ChargeStop:hook=dict(status='PROPAGATED')
    else:hook=dict(status='NOT_PROPAGATED')
    hook_ref=ctx.save(prefix+'/proposer-charge-stop-receipt.json',hook)
    need(hook['status']=='PROPAGATED','OPEN_PROPOSER_CHARGE_PROPAGATION')
    return dict(status='QUALIFIED',fixture=setup,index=index,instance_records=records,state_records=states,
        zero_records=zero_records,charge_stop=dict(input=inp,receipt=ref),
        local_proposal=dict(input=query_input,receipt=query_ref,admissions=admitted_ref,
            invariance_input=invariant_input,invariance_receipt=invariant_ref,charge_stop=hook_ref),
        internal_axiom=dict(input=axiom_input,receipt=axiom_ref,admissions=axiom_admissions_ref),
        current_context=dict(prepared_scope=prepared['binding']['scope'],library_sha256=ctx.sha(library)),
        scope='Synthetic partial MP/GEN fragment with unresolved external owners; no complete cover, proof search, native theorem, original RF/N model admission or observed E state claimed.')
