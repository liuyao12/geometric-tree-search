"""Independent finite shared-fact rank constraint checker, stdlib only.

No compiler, rank producer, model helper, engine or native kernel is imported.
VERIFIED_REDUNDANT_RANK_CONSTRAINT is conditional on separate complete RF/N
model admission and native ZERO truth. It is neither a learned hypothesis nor
a proof of the target, a search trace, or an absence certificate.
"""
import hashlib
import json
import math
import time

VERSION = 'Independent-shared-fact-rank-checker-v1'
GUARD = 'certified:rank:guard:v1'
DEFAULT_LIMITS = dict(max_formulas=1024, max_rows=250000, max_slots=16,
                      max_work=1000000000, wall_seconds=120.0)
ZERO_RULES = {'axiom', 'instantiate', 'refl', 'eq_subst', 'distribute', 'tautology'}


class _Bad(Exception):
    pass


class _Stop(Exception):
    pass


def need(ok, why):
    if not ok:
        raise _Bad(why)


def integer(value, minimum=0):
    return type(value) is int and value >= minimum and value.bit_length() <= 256


def fields(value, names, why):
    need(type(value) is dict and set(value) == set(names), why)


def limits_value(value):
    out = dict(DEFAULT_LIMITS)
    if value is not None:
        need(type(value) is dict and set(value) <= set(out), 'LIMIT_FIELDS')
        out.update(value)
    for key, v in out.items():
        if key == 'wall_seconds':
            need(type(v) in (int, float) and math.isfinite(v) and 0 < v <= DEFAULT_LIMITS[key], 'WALL_LIMIT')
        else:
            need(integer(v, 0 if key == 'max_work' else 1) and v <= DEFAULT_LIMITS[key], 'LIMIT:'+key)
    return out


class Meter:
    def __init__(self, limits):
        self.limits = limits
        self.work = 0
        self.started = time.perf_counter()

    def tick(self, amount=1):
        self.work += amount
        if self.work > self.limits['max_work']:
            raise _Stop('CHECKER_MAX_WORK')
        if time.perf_counter()-self.started > self.limits['wall_seconds']:
            raise _Stop('CHECKER_WALL_SECONDS')

    def scan(self, value):
        active = set()
        stack = [(value, 0, False)]
        while stack:
            v, depth, leaving = stack.pop()
            if leaving:
                active.remove(id(v))
                continue
            self.tick()
            if depth > 128:
                raise _Stop('CHECKER_JSON_DEPTH')
            if type(v) in (list, dict):
                need(id(v) not in active, 'JSON_CYCLE')
                active.add(id(v)); stack.append((v, depth, True))
                if type(v) is dict:
                    for k, child in v.items():
                        need(type(k) is str, 'NATIVE_STRING_KEYS')
                        stack.append((child, depth+1, False)); stack.append((k, depth+1, False))
                else:
                    stack.extend((child, depth+1, False) for child in v)
            elif type(v) is str:
                self.tick(len(v))
            elif type(v) is int:
                need(v.bit_length() <= 256, 'INTEGER_BITS')
            else:
                need(v is None or type(v) is bool or type(v) is float and math.isfinite(v), 'NATIVE_FINITE_JSON')

    def same(self, a, b, why):
        stack = [(a, b)]
        while stack:
            left, right = stack.pop(); self.tick()
            need(type(left) is type(right), why+':TYPE')
            if type(left) is dict:
                need(left.keys() == right.keys(), why+':KEYS')
                stack.extend((v, right[k]) for k, v in left.items())
            elif type(left) is list:
                need(len(left) == len(right), why+':LENGTH')
                stack.extend(zip(left, right))
            else:
                if type(left) is str:
                    self.tick(len(left)+len(right))
                need(left == right, why)

    def sha(self, value):
        h = hashlib.sha256()
        encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)
        for part in encoder.iterencode(value):
            self.tick(len(part)); h.update(part.encode('ascii'))
        h.update(b'\n'); self.tick()
        return h.hexdigest()

    def key(self, value):
        raw = json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)+'\n'
        self.tick(len(raw)); return raw


def ast_shape(value, kind, theory, variables, meter):
    stack = [(value, kind)]
    while stack:
        a, sort = stack.pop(); meter.tick()
        need(type(a) is list and a and type(a[0]) is str, 'AST_LIST')
        tag = a[0]
        if sort == 'term':
            if tag == 'var':
                need(len(a) == 2 and type(a[1]) is str and a[1] in variables, 'VARIABLE')
            else:
                need(tag == 'fun' and len(a) == 3 and type(a[1]) is str and a[1] in theory['functions']
                     and type(a[2]) is list and len(a[2]) == theory['functions'][a[1]], 'FUNCTION')
                stack.extend((x, 'term') for x in a[2])
        elif tag == 'pred':
            need(len(a) == 3 and type(a[1]) is str and a[1] in theory['predicates']
                 and type(a[2]) is list and len(a[2]) == theory['predicates'][a[1]], 'PREDICATE')
            stack.extend((x, 'term') for x in a[2])
        elif tag in ('imp', 'and', 'or', 'eq'):
            need(len(a) == 3, 'BINARY_FORMULA')
            stack.extend((x, 'term' if tag == 'eq' else 'formula') for x in a[1:])
        elif tag == 'not':
            need(len(a) == 2, 'NOT_FORMULA'); stack.append((a[1], 'formula'))
        elif tag == 'all':
            need(len(a) == 3 and type(a[1]) is str and a[1] in variables, 'ALL_FORMULA')
            stack.append((a[2], 'formula'))
        else:
            need(tag == 'bot' and len(a) == 1, 'FORMULA_TAG')


def catalogue_data(prepared, meter):
    need(type(prepared) is dict and prepared.get('schema') == 'Shared-fact-prepared-v2'
         and prepared.get('status') == 'PREPARED_UNVERIFIED', 'PREPARED_ABI')
    cat = prepared['catalogue']
    fields(cat, ('schema', 'statement', 'formulas', 'zeros', 'mp', 'gen', 'profile', 'provenance'), 'CATALOGUE_FIELDS')
    need(cat['schema'] == 'Shared-fact-finite-catalogue-v1' and type(cat['provenance']) is dict, 'CATALOGUE_ABI')
    statement = cat['statement']; fields(statement, ('theory', 'goal'), 'STATEMENT_FIELDS')
    theory = statement['theory']; fields(theory, ('functions', 'predicates', 'axioms'), 'THEORY_FIELDS')
    for name in ('functions', 'predicates'):
        need(type(theory[name]) is dict and all(type(k) is str and k and integer(v)
             for k, v in theory[name].items()), 'SIGNATURE')
    need(type(theory['axioms']) is dict and all(type(k) is str and k for k in theory['axioms']), 'AXIOMS')
    profile = cat['profile']
    need(type(profile) is dict and {'kind','slots','formula_universe_version','zero_instance_profile','variables','allow_gen'} <= set(profile), 'PROFILE_FIELDS')
    need(type(profile['allow_gen']) is bool and profile['formula_universe_version'] == 'LITERAL_SORTED_CANONICAL_JSON_V1'
         and type(profile['kind']) is str and profile['kind'] and type(profile['zero_instance_profile']) is str
         and profile['zero_instance_profile'], 'PROFILE_ABI')
    variables = profile['variables']
    need(type(variables) is list and all(type(v) is str and v for v in variables)
         and len(set(variables)) == len(variables), 'VARIABLE_POOL')
    slots = prepared['binding']['slots']
    need(integer(slots, 1) and type(profile['slots']) is int and slots == profile['slots'], 'SLOT_BINDING')
    if slots > meter.limits['max_slots']:
        raise _Stop('CHECKER_MAX_SLOTS')
    forms = cat['formulas']; need(type(forms) is list and forms, 'FORMULA_REGISTRY')
    if len(forms) > meter.limits['max_formulas']:
        raise _Stop('CHECKER_MAX_FORMULAS')
    keys = []
    for f in forms:
        ast_shape(f, 'formula', theory, variables, meter); keys.append(meter.key(f))
    need(keys == sorted(set(keys)), 'SORTED_UNIQUE_FORMULAS')
    ids = {key:i+1 for i,key in enumerate(keys)}
    ast_shape(statement['goal'], 'formula', theory, variables, meter)
    need(meter.key(statement['goal']) in ids, 'GOAL_IN_REGISTRY')
    for f in theory['axioms'].values():
        ast_shape(f, 'formula', theory, variables, meter); need(meter.key(f) in ids, 'AXIOM_IN_REGISTRY')
    zeros = cat['zeros']; need(type(zeros) is list, 'ZERO_LIST')
    if len(zeros) > 8000:
        raise _Stop('CHECKER_MAX_ZERO_DEFINITIONS')
    zdefs = []; znames = []
    for z in zeros:
        fields(z, ('id','native'), 'ZERO_FIELDS'); native=z['native']
        need(type(z['id']) is str and z['id'] and type(native) is dict
             and native.get('rule') in ZERO_RULES and 'formula' in native, 'ZERO_PAYLOAD')
        key=meter.key(native['formula']);need(key in ids, 'ZERO_FORMULA_IN_REGISTRY')
        znames.append(z['id']); zdefs.append(dict(id=z['id'],output=ids[key],native=native))
    need(znames == sorted(set(znames)), 'SORTED_UNIQUE_ZERO_IDS')
    mp=[];gen=[]
    for fid,f in enumerate(forms,1):
        meter.tick()
        if f[0]=='imp' and meter.key(f[1]) in ids and meter.key(f[2]) in ids:
            mp.append(dict(antecedent=ids[meter.key(f[1])],implication=fid,output=ids[meter.key(f[2])]))
        if profile['allow_gen'] and f[0]=='all' and meter.key(f[2]) in ids:
            gen.append(dict(source=ids[meter.key(f[2])],output=fid,variable=f[1]))
    mp.sort(key=lambda d:(d['antecedent'],d['implication'],d['output']))
    gen.sort(key=lambda d:(d['source'],d['output'],d['variable']))
    meter.same(cat['mp'],mp,'ALL_STRUCTURAL_MP');meter.same(cat['gen'],gen,'ALL_STRUCTURAL_GEN')
    definitions=dict(zeros=zdefs,mp=[dict(id='mp:'+str(d['implication']),**d) for d in mp],
        gen=[dict(id='gen:'+str(d['output']),**d) for d in gen],pad=dict(id='pad',active=0,formula_id=0))
    meter.same(prepared['definitions'],definitions,'ALL_PREPARED_DEFINITIONS')
    logical={k:cat[k] for k in ('schema','statement','formulas','zeros','mp','gen','profile')}
    preimage=dict(schema='Shared-fact-point-scope-v2',catalogue=logical,slots=slots,allow_padding=True,
                  point_version='DAG-slot-ports-v2',candidate_version='DAG-candidate-v2')
    binding=dict(scope=meter.sha(preimage),scope_preimage=preimage,slots=slots,
        goal_id=ids[meter.key(statement['goal'])],catalogue_sha256=meter.sha(cat),original_statement_sha256=meter.sha(statement))
    meter.same(prepared['binding'],binding,'EXACT_PREPARED_SCOPE_BINDING');meter.same(prepared['statement'],statement,'UNCHANGED_STATEMENT')
    return cat,definitions,binding


def validate_base(prepared, base, definitions, binding, meter):
    slots=binding['slots']; rows=prepared['universe'];need(type(rows) is list, 'UNIVERSE_LIST')
    if len(rows)>meter.limits['max_rows']:
        raise _Stop('CHECKER_MAX_ROWS')
    counts=dict(formulas=len(prepared['catalogue']['formulas']),zero_definitions=len(definitions['zeros']),
        mp_definitions=len(definitions['mp']),gen_definitions=len(definitions['gen']),slots=slots)
    sum_i=slots*(slots-1)//2;sum_square=slots*(slots-1)*(2*slots-1)//6
    potential=slots*(counts['zero_definitions']+1)+sum_square*counts['mp_definitions']+sum_i*counts['gen_definitions']
    conflicts=sum_i*counts['mp_definitions']
    census=dict(counts,potential_rows=potential,self_conflicting_rows=conflicts,rows=potential-conflicts,
                points_required=slots,mark_only_ports=2*slots)
    meter.same(prepared['census'],census,'COMPLETE_UNIVERSE_CENSUS')
    need(len(rows)==census['rows'], 'FULL_ROW_COUNT')
    seed=dict(t=[],m=sorted([['a:'+str(slots-1),'1'],['f:'+str(slots-1),str(binding['goal_id'])]]))
    old=dict(schema='Z-growing-point-model-v1',version='Shared-fact-slots-active-formula-v2:'+binding['scope'],capacity=1,
        roots=sorted('q:'+str(i) for i in range(slots)),seed=seed,inventory=dict(kind='EXPLICIT',placements=rows))
    meter.same(prepared['model'],old,'PREPARED_LITERAL_MODEL')
    expected=dict(old,schema='Z-growing-point-model-v3',version=old['version']+':engine-v4',pair_nogoods=[],unary_nogoods=[])
    meter.same(base,expected,'EXACT_UNFILTERED_ENGINE_MIGRATION')
    lookup={kind:{d['id']:d for d in definitions[name]} for kind,name in (('ZERO','zeros'),('MP','mp'),('GEN','gen'))}
    previous=None
    for row in rows:
        meter.tick();fields(row,('id','t','m'),'ROW_FIELDS')
        cid=row['id'];need(type(cid) is str and (previous is None or previous<cid),'SORTED_UNIQUE_CIDS');previous=cid
        token=json.loads(cid);need(type(token) is list and len(token)==4 and meter.key(token)==cid,'CANONICAL_CID')
        slot,kind,did,refs=token
        need(integer(slot) and slot<slots and type(kind) is str and type(did) is str and type(refs) is list
             and all(integer(j) and j<slot for j in refs),'CID_TYPED_PRIOR_REFS')
        demands=[]
        if kind=='PAD':
            need(did=='pad' and refs==[],'PAD_CID');active=0;output=0
        else:
            need(kind in lookup and did in lookup[kind],'NATIVE_DEFINITION_ID');d=lookup[kind][did];active=1;output=d['output']
            if kind=='ZERO':need(refs==[],'ZERO_REFS')
            elif kind=='GEN':
                need(len(refs)==1,'GEN_REFS');demands=[(refs[0],1,d['source'])]
            else:
                need(len(refs)==2 and refs[0]!=refs[1],'MP_REFS_WITHOUT_SELF_CONFLICT')
                demands=[(refs[0],1,d['antecedent']),(refs[1],1,d['implication'])]
        m={}
        for j,a,fid in [(slot,active,output)]+demands:
            for p,v in (('a:'+str(j),str(a)),('f:'+str(j),str(fid))):
                need(p not in m or m[p]==v,'ROW_SELF_CONFLICT');m[p]=v
        meter.same(row['t'],[['q:'+str(slot),1]],'EXACT_POSITIVE_SUPPORT')
        meter.same(row['m'],sorted([[p,v] for p,v in m.items()]),'ALL_OWN_AND_RECEPTOR_MARKS')
    return census


def independent_ranks(size, definitions, meter):
    ranks=[None]*(size+1)
    for z in definitions['zeros']:meter.tick();ranks[z['output']]=1
    passes=0
    while True:
        passes+=1;need(passes<=size+1,'FINITE_RANK_FIXED_POINT_INVARIANT')
        later=list(ranks)
        for d in definitions['gen']:
            meter.tick();h=ranks[d['source']]
            if h is not None:
                value=h+1;old=later[d['output']]
                if old is None or value<old:later[d['output']]=value
        for d in definitions['mp']:
            meter.tick();a,b=ranks[d['antecedent']],ranks[d['implication']]
            if a is not None and b is not None:
                value=1+max(a,b);old=later[d['output']]
                if old is None or value<old:later[d['output']]=value
        if later==ranks:return ranks,passes
        ranks=later


def run(prepared,base,packet,marked,control,meter):
    for value in (prepared,base,packet,marked,control):meter.scan(value)
    cat,definitions,binding=catalogue_data(prepared,meter)
    census=validate_base(prepared,base,definitions,binding,meter)
    fields(packet,('schema','status','bindings','ranks','forbidden','reasons','costs','limits','scope'),'RANK_PACKET_FIELDS')
    need(packet['schema']=='Rank-pruning-analysis-v1' and packet['status']=='CANDIDATE','COMPLETE_RANK_CANDIDATE_REQUIRED')
    need(type(packet['scope']) is str and packet['scope'],'PRODUCER_SCOPE')
    plimits=limits_value(packet['limits']);meter.same(plimits,packet['limits'],'ALL_PRODUCER_LIMIT_FIELDS')
    costs=packet['costs'];fields(costs,('seconds','work','relaxation_passes','producer_visits','row_visits'),'PRODUCER_COST_FIELDS')
    need(type(costs['seconds']) in (int,float) and math.isfinite(costs['seconds']) and costs['seconds']>=0,'COST_SECONDS')
    for k in ('work','relaxation_passes','producer_visits','row_visits'):need(integer(costs[k]),'COST_INTEGER:'+k)
    need(costs['work']<=plimits['max_work'] and census['formulas']<=plimits['max_formulas']
         and census['rows']<=plimits['max_rows'] and census['slots']<=plimits['max_slots'],'CANDIDATE_WITHIN_PRODUCER_CAPS')
    bindings=dict(catalogue_sha256=binding['catalogue_sha256'],prepared_scope=binding['scope'],
        base_model_sha256=meter.sha(base),slots=binding['slots'])
    meter.same(packet['bindings'],bindings,'EXACT_RANK_INPUT_BINDINGS')
    ranks,passes=independent_ranks(len(cat['formulas']),definitions,meter)
    meter.same(packet['ranks'],[[i,ranks[i]] for i in range(1,len(ranks))],'COMPLETE_LEAST_HEIGHT_TABLE')
    forbidden=[];reasons=[]
    for row in base['inventory']['placements']:
        meter.tick();bad=[]
        for p,v in row['m']:
            meter.tick()
            if p.startswith('f:') and v!='0':
                slot=int(p[2:]);fid=int(v);h=ranks[fid]
                if h is None or h>slot+1:bad.append([fid,slot,h])
        if bad:
            bad.sort(key=lambda r:(r[1],r[0]));forbidden.append(row['id']);reasons.append([row['id'],bad])
    meter.same(packet['forbidden'],forbidden,'ALL_AND_ONLY_RANK_FORBIDDEN_CIDS')
    meter.same(packet['reasons'],reasons,'EVERY_IMPOSSIBLE_OWN_OR_RECEPTOR_DEMAND')
    fields(marked,tuple(base),'MARKED_MODEL_FIELDS');fields(control,tuple(base),'CONTROL_MODEL_FIELDS')
    for key in ('schema','capacity','roots','pair_nogoods'):
        meter.same(marked[key],base[key],'UNCHANGED_MARKED:'+key);meter.same(control[key],base[key],'UNCHANGED_CONTROL:'+key)
    need(marked['version']==base['version']+':rank-marked-v1' and control['version']==base['version']+':rank-filter-v1','OVERLAY_VERSION')
    meter.same(marked['unary_nogoods'],[],'NO_HIDDEN_MARKED_FILTER')
    meter.same(control['unary_nogoods'],forbidden,'MATCHED_ORDINARY_UNARY_FILTER')
    points=set(base['roots'])
    for kind in ('t','m'):points.update(p for p,v in base['seed'][kind])
    for row in base['inventory']['placements']:
        meter.tick();points.update(p for p,v in row['t']);points.update(p for p,v in row['m'])
    need(GUARD not in points,'FRESH_MARK_ONLY_GUARD')
    meter.same(control['seed'],base['seed'],'CONTROL_OLD_SEED')
    meter.same(marked['seed'],dict(t=base['seed']['t'],m=sorted(base['seed']['m']+[[GUARD,'0']])),'ONLY_GUARD_SEED_ADDITION')
    fields(marked['inventory'],('kind','placements'),'MARKED_INVENTORY_FIELDS')
    fields(control['inventory'],('kind','placements'),'CONTROL_INVENTORY_FIELDS')
    need(marked['inventory']['kind']==control['inventory']['kind']=='EXPLICIT','UNCHANGED_EXPLICIT_INVENTORY')
    base_rows=base['inventory']['placements'];mrows=marked['inventory']['placements'];frows=control['inventory']['placements']
    need(type(mrows) is list and type(frows) is list and len(mrows)==len(frows)==len(base_rows),'ALL_ROWS_RETAINED')
    rejected=set(forbidden)
    for original,m,f in zip(base_rows,mrows,frows):
        meter.tick();meter.same(f,original,'ORDINARY_FILTER_LEAVES_ALL_BASE_ROWS')
        expected=dict(original,m=sorted(original['m']+([[GUARD,'1']] if original['id'] in rejected else [])))
        meter.same(m,expected,'EXACT_CERTIFIED_LITERAL_LAYER')
    model_bindings=dict(base=bindings['base_model_sha256'],marked=meter.sha(marked),control=meter.sha(control))
    meter.tick()
    return dict(status='VERIFIED_REDUNDANT_RANK_CONSTRAINT',bindings=bindings,model_bindings=model_bindings,
        ranks_sha256=meter.sha(packet['ranks']),forbidden_sha256=meter.sha(forbidden),reasons_sha256=meter.sha(reasons),
        counts=dict(formulas=census['formulas'],rows=census['rows'],slots=census['slots'],
            forbidden_rows=len(forbidden),unreachable_formulas=sum(h is None for h in ranks[1:]),
            fixed_point_passes=passes,zero_definitions=census['zero_definitions'],
            mp_definitions=census['mp_definitions'],gen_definitions=census['gen_definitions']),
        bounded_absence=False,learned=False,guard_point=GUARD,
        preservation='ALL_ORIGINAL_COMPLETE_POINT_SOLUTIONS_INCLUDING_PAD_AND_UNUSED_ACTIVE_FACTS',
        scope='Conditional on separate complete RF/catalogue/model admission and all native ZERO truth checks. Independent finite grammar ranks and complete compact-row inventory checked; no native truth, target proof, scheduler/rollback, search exhaustion, infinite tiling or universality claim.')


def verify(prepared,base,packet,marked,control,limits=None):
    started=time.perf_counter();meter=None
    try:
        effective=limits_value(limits);meter=Meter(effective)
        result=run(prepared,base,packet,marked,control,meter)
        meter.tick()  # includes final result hashing in the cooperative wall gate
    except (_Stop,MemoryError,RecursionError) as error:
        result=dict(status='UNKNOWN',reason=str(error) or type(error).__name__,bounded_absence=False,learned=False)
    except (_Bad,ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError) as error:
        result=dict(status='REJECTED',reason=str(error) or type(error).__name__,bounded_absence=False,learned=False)
    result.update(version=VERSION,seconds=time.perf_counter()-started,work=0 if meter is None else meter.work,
        work_scope='Cooperative native JSON/string/producer/row/serialization units; no CPU-instruction or physical-memory accounting.')
    return result
