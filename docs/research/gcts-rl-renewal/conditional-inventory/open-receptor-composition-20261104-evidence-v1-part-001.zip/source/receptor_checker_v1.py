"""Independent receptor provenance, concrete-row and current-state checks.

Stdlib only. No learner, engine, native checker or private helper is imported.
Library provenance is not schematic proof validity; concrete primitive rows and
compatible partial unions are not final native theorem acceptance.
"""
import hashlib
import json
import math
import time

VERSION='Independent-receptor-checker-v1'
DEFAULT_LIMITS=dict(max_work=100000000,wall_seconds=30.0,max_families=4096,max_instances=4096,max_lines=16)
ZERO_RULES={'axiom','refl','instantiate','eq_subst','distribute','tautology'}


class _Reject(Exception):
    pass


class _Budget(Exception):
    pass


def need(ok,why):
    if not ok:raise _Reject(why)


def integer(v,low=0):
    return type(v) is int and v>=low and v.bit_length()<=256


def fields(v,names,why):
    need(type(v) is dict and set(v)==set(names),why)


def limits_value(value):
    out=dict(DEFAULT_LIMITS)
    if value is not None:
        need(type(value) is dict and set(value)<=set(out),'LIMIT_FIELDS');out.update(value)
    for k,v in out.items():
        if k=='wall_seconds':need(type(v) in (int,float) and math.isfinite(v) and 0<v<=DEFAULT_LIMITS[k],'WALL_LIMIT')
        else:need(integer(v) and v<=DEFAULT_LIMITS[k],'LIMIT:'+k)
    return out


class _Meter:
    def __init__(self,limits):
        self.limits=limits;self.work=0;self.started=time.perf_counter()

    def tick(self,n=1):
        self.work+=n
        if self.work>self.limits['max_work']:raise _Budget('MAX_WORK')
        if time.perf_counter()-self.started>self.limits['wall_seconds']:raise _Budget('WALL_SECONDS')

    def scan(self,value):
        active=set();stack=[(value,0,False)]
        while stack:
            v,d,leave=stack.pop()
            if leave:active.remove(id(v));continue
            self.tick()
            if d>128:raise _Budget('JSON_DEPTH')
            if type(v) in (dict,list):
                need(id(v) not in active,'JSON_CYCLE');active.add(id(v));stack.append((v,d,True))
                if type(v) is dict:
                    for k,x in v.items():
                        need(type(k) is str,'STRING_KEYS');stack.extend(((k,d+1,False),(x,d+1,False)))
                else:stack.extend((x,d+1,False) for x in v)
            elif type(v) is str:self.tick(len(v))
            elif type(v) is int:need(v.bit_length()<=256,'INTEGER_BITS')
            else:need(v is None or type(v) is bool or type(v) is float and math.isfinite(v),'NATIVE_FINITE_JSON')

    def wire(self,v):
        text=json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n'
        self.tick(len(text));return text.encode('ascii')

    def sha(self,v):
        h=hashlib.sha256()
        for text in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(v):
            self.tick(len(text));h.update(text.encode('ascii'))
        h.update(b'\n');self.tick();return h.hexdigest()

    def same(self,a,b,why):
        stack=[(a,b)]
        while stack:
            x,y=stack.pop();self.tick();need(type(x) is type(y),why+':TYPE')
            if type(x) is dict:
                need(x.keys()==y.keys(),why+':KEYS');self.tick(len(x));stack.extend((v,y[k]) for k,v in x.items())
            elif type(x) is list:
                need(len(x)==len(y),why+':SIZE');self.tick(len(x));stack.extend(zip(x,y))
            else:
                if type(x) is str:self.tick(len(x)+len(y))
                need(x==y,why)


def clone(value,m):
    return json.loads(m.wire(value))


def term(value,m,hole=False):
    m.tick();need(type(value) is list and value and type(value[0]) is str,'TERM_AST')
    if value[0]=='_hole':need(hole and value==['_hole'],'ONE_HOLE_AST');return 1
    if value[0]=='var':need(len(value)==2 and type(value[1]) is str and value[1],'VARIABLE_AST');return 0
    need(value[0]=='fun' and len(value)==3 and type(value[1]) is str and value[1] and type(value[2]) is list,'FUNCTION_AST')
    return sum(term(x,m,hole) for x in value[2])


def syntax_formula(f,theory,m):
    stack=[(f,'formula')]
    while stack:
        a,kind=stack.pop();m.tick();need(type(a) is list and a and type(a[0]) is str,'SYNTAX_AST')
        tag=a[0]
        if kind=='term':
            if tag=='var':need(len(a)==2 and type(a[1]) is str and a[1],'SYNTAX_VARIABLE')
            else:
                need(tag=='fun' and len(a)==3 and type(a[1]) is str and a[1] in theory['functions']
                     and type(a[2]) is list and len(a[2])==theory['functions'][a[1]],'SYNTAX_FUNCTION')
                stack.extend((x,'term') for x in a[2])
        elif tag=='pred':
            need(len(a)==3 and type(a[1]) is str and a[1] in theory['predicates'] and type(a[2]) is list
                 and len(a[2])==theory['predicates'][a[1]],'SYNTAX_PREDICATE');stack.extend((x,'term') for x in a[2])
        elif tag in ('eq','imp','and','or'):
            need(len(a)==3,'SYNTAX_BINARY');stack.extend((x,'term' if tag=='eq' else 'formula') for x in a[1:])
        elif tag=='not':need(len(a)==2,'SYNTAX_NOT');stack.append((a[1],'formula'))
        elif tag=='all':
            need(len(a)==3 and type(a[1]) is str and a[1],'SYNTAX_BINDER');stack.append((a[2],'formula'))
        else:need(tag=='bot' and len(a)==1,'SYNTAX_FORMULA_TAG')


def statement_shape(s,m):
    fields(s,('theory','goal'),'STATEMENT_FIELDS');t=s['theory'];fields(t,('functions','predicates','axioms'),'THEORY_FIELDS')
    for kind in ('functions','predicates'):
        need(type(t[kind]) is dict and all(type(k) is str and k and integer(v) for k,v in t[kind].items()),'SIGNATURE')
    need(type(t['axioms']) is dict and all(type(k) is str and k for k in t['axioms']),'AXIOM_NAMES')
    syntax_formula(s['goal'],t,m)
    for f in t['axioms'].values():syntax_formula(f,t,m)


def proof_edges(proof,m):
    need(type(proof) is list and proof,'NONEMPTY_DONOR_PROOF')
    if len(proof)>m.limits['max_lines']:raise _Budget('MAX_LINES')
    edges=[]
    for i,line in enumerate(proof):
        m.tick();need(type(line) is dict and type(line.get('rule')) is str and 'formula' in line,'PROOF_LINE')
        rule=line['rule']
        if rule=='mp':
            fields(line,('rule','formula','antecedent','implication'),'MP_FIELDS');refs=('antecedent','implication')
        elif rule=='generalize':
            fields(line,('rule','formula','source','variable'),'GEN_FIELDS')
            need(type(line['variable']) is str and line['variable'],'GEN_VARIABLE');refs=('source',)
        else:need(rule in ZERO_RULES,'PRIMITIVE_RULE');refs=()
        for key in refs:
            need(integer(line[key]) and line[key]<i,'STRICT_PRIOR_DONOR_REFERENCE');edges.append([line[key],i,key])
    return sorted(edges)


def rooted_clusters(proof,m):
    edges=proof_edges(proof,m);n=len(proof);out=[]
    for mask in range(1,1<<n):
        m.tick(n);members=[i for i in range(n) if mask>>i&1];chosen=set(members);root=members[-1]
        inside=[e for e in edges if e[0] in chosen and e[1] in chosen];outside=[e for e in edges if e[0] not in chosen and e[1] in chosen]
        m.tick(2*len(edges));seen={root};todo=[root]
        while todo:
            v=todo.pop();m.tick(len(inside)+1)
            for a,b,key in inside:
                if b==v and a not in seen:seen.add(a);todo.append(a)
        if seen!=chosen:continue
        body=dict(root=root,members=members,internal_edges=inside,external_edges=outside,
                  receptor_indices=sorted({e[0] for e in outside}))
        out.append(dict(id=m.sha(dict(schema='Receptor-cluster-v1',**body)),**body))
    out.sort(key=lambda x:x['id']);return out


def substitute(v,bindings,m):
    m.tick()
    if type(v) is list:
        if v and v[0]=='_term':
            need(len(v)==2 and v[1] in bindings['terms'],'TERM_PARAMETER');return clone(bindings['terms'][v[1]],m)
        if v and v[0]=='_ctx':
            need(len(v)==3 and v[1] in bindings['contexts'],'CONTEXT_PARAMETER')
            argument=substitute(v[2],bindings,m)
            def fill(x):
                m.tick()
                if x==['_hole']:return clone(argument,m)
                return [fill(y) for y in x] if type(x) is list else x
            return fill(bindings['contexts'][v[1]])
        return [substitute(x,bindings,m) for x in v]
    if type(v) is dict:return {k:substitute(x,bindings,m) for k,x in v.items()}
    return v


def transformed(value,bindings,m):
    terms=[(m.wire(t),name) for name,t in bindings['terms'].items()]
    def replace(v):
        m.tick()
        if type(v) is list:
            if v and v[0] in ('var','fun'):
                key=m.wire(v)
                for source,name in terms:
                    m.tick()
                    if key==source:return ['_term',name]
            return [replace(x) for x in v]
        if type(v) is dict:return {k:replace(x) for k,x in v.items()}
        return v
    first=replace(value)
    if not bindings['contexts']:return first
    name,context=next(iter(bindings['contexts'].items()));fun=context[1]
    def abstract(v):
        m.tick()
        if type(v) is list:
            if len(v)==3 and v[0]=='fun' and v[1]==fun and type(v[2]) is list and len(v[2])==1:
                return ['_ctx',name,abstract(v[2][0])]
            return [abstract(x) for x in v]
        if type(v) is dict:return {k:abstract(x) for k,x in v.items()}
        return v
    return abstract(first)


def parameters(family,donor,m):
    p=family['parameters'];fields(p,('terms','contexts'),'PARAMETER_FIELDS')
    need(type(p['terms']) is list and 1<=len(p['terms'])<=2 and type(p['contexts']) is list and len(p['contexts'])<=1,'PARAMETER_COUNTS')
    for names in p.values():need(all(type(x) is str and x for x in names) and names==sorted(set(names)),'PARAMETER_NAMES')
    b=family['prototype_bindings'];fields(b,('terms','contexts'),'PROTOTYPE_BINDING_FIELDS')
    for kind in ('terms','contexts'):need(type(b[kind]) is dict and set(b[kind])==set(p[kind]),'EXACT_PROTOTYPE_PARAMETERS')
    keys=[]
    for t in b['terms'].values():
        term(t,m);need(t[0]=='var' or len(t[2])>0,'NONCONSTANT_TERM_ABSTRACTION');keys.append(m.wire(t))
    need(len(keys)==len(set(keys)),'DISTINCT_TERM_PROTOTYPES')
    for c in b['contexts'].values():
        need(type(c) is list and len(c)==3 and c[0]=='fun' and type(c[1]) is str and c[2]==[['_hole']]
             and donor['theory']['functions'].get(c[1])==1,'DECLARED_UNARY_PROTOTYPE_CONTEXT')
        need(term(c,m,True)==1,'ONE_PROTOTYPE_HOLE')
    visible={'terms':set(),'contexts':set()};stack=[family['statement_template']['goal']]
    while stack:
        x=stack.pop();m.tick()
        if type(x) is list:
            if x and x[0] in ('_term','_ctx'):
                need(len(x)>1 and type(x[1]) is str,'VISIBLE_PARAMETER')
                visible['terms' if x[0]=='_term' else 'contexts'].add(x[1])
            stack.extend(x)
        elif type(x) is dict:stack.extend(x.values())
    for kind in ('terms','contexts'):need(visible[kind]==set(p[kind]),'EVERY_PARAMETER_IN_GOAL')


def library_data(statement,proof,library,m):
    fields(library,('schema','status','donor','families','clusters','costs','limits','scope'),'LIBRARY_FIELDS')
    need(library['schema']=='Receptor-family-library-v1' and library['status']=='CANDIDATE_LIBRARY','LIBRARY_SCHEMA_STATUS')
    statement_shape(statement,m);edges=proof_edges(proof,m)
    for line in proof:syntax_formula(line['formula'],statement['theory'],m)
    m.same(proof[-1]['formula'],statement['goal'],'DONOR_FINAL_GOAL')
    m.same(library['donor'],dict(statement_sha256=m.sha(statement),proof_sha256=m.sha(proof),lines=len(proof)),'EXACT_DONOR_BINDING')
    need(type(library['families']) is list and type(library['clusters']) is list,'LIBRARY_COLLECTIONS')
    if len(library['families'])>m.limits['max_families']:raise _Budget('MAX_FAMILIES')
    ids=[]
    for f in library['families']:
        fields(f,('id','parameters','statement_template','proof_template','prototype_bindings'),'FAMILY_FIELDS')
        body={k:v for k,v in f.items() if k!='id'}
        need(type(f['id']) is str and f['id']==m.sha(dict(schema='Receptor-family-v1',**body)),'FAMILY_ID')
        parameters(f,statement,m)
        m.same(f['statement_template'],transformed(statement,f['prototype_bindings'],m),'EXACT_STATEMENT_ABSTRACTION')
        m.same(f['proof_template'],transformed(proof,f['prototype_bindings'],m),'EXACT_PROOF_ABSTRACTION')
        m.same(substitute(f['statement_template'],f['prototype_bindings'],m),statement,'RESTORED_DONOR_STATEMENT')
        m.same(substitute(f['proof_template'],f['prototype_bindings'],m),proof,'RESTORED_DONOR_PROOF');ids.append(f['id'])
    need(ids==sorted(set(ids)),'SORTED_DISTINCT_FAMILIES')
    m.same(library['clusters'],rooted_clusters(proof,m),'EVERY_EXACT_ROOTED_DONOR_SUBDAG')
    limits_value(library['limits']);need(type(library['costs']) is dict and type(library['scope']) is str,'LIBRARY_METADATA')
    return {f['id']:f for f in library['families']},{c['id']:c for c in library['clusters']}


def _receipt(status,m,**extra):
    return dict(status=status,version=VERSION,work=0 if m is None else m.work,
        seconds=0.0 if m is None else time.perf_counter()-m.started,**extra)


def verify_library(statement,proof,library,limits=None):
    m=None
    try:
        m=_Meter(limits_value(limits))
        for value in (statement,proof,library):m.scan(value)
        families,clusters=library_data(statement,proof,library,m)
        binding=dict(statement_sha256=m.sha(statement),proof_sha256=m.sha(proof),library_sha256=m.sha(library))
        m.tick();return _receipt('VERIFIED_PROVENANCE',m,bindings=binding,families=len(families),clusters=len(clusters),
            scope='Exact donor/template/prototype/rooted-cluster provenance only. External donor custody/native validity and every current concrete instance admission remain separate; no universal family theorem or completeness of abstraction enumeration.')
    except (_Budget,MemoryError,RecursionError) as e:return _receipt('UNKNOWN',m,reason=str(e) or type(e).__name__)
    except (_Reject,ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError) as e:return _receipt('REJECTED',m,reason=str(e) or type(e).__name__)


def model_index(model,m):
    fields(model,('schema','version','capacity','roots','seed','inventory','pair_nogoods','unary_nogoods'),'MODEL_FIELDS')
    need(model['schema']=='Z-growing-point-model-v3' and type(model['version']) is str and model['version']
         and integer(model['capacity'],1),'MODEL_ABI');cap=model['capacity']
    need(type(model['roots']) is list and all(type(p) is str and p for p in model['roots'])
         and len(set(model['roots']))==len(model['roots']),'ROOTS')
    def supports(rows,mark):
        need(type(rows) is list,'SUPPORT_LIST');seen=set();out=[]
        for r in rows:
            m.tick();need(type(r) is list and len(r)==2 and type(r[0]) is str and r[0] and r[0] not in seen,'SUPPORT_POINT')
            need(type(r[1]) is str if mark else integer(r[1]) and r[1]<=cap,'SUPPORT_VALUE')
            seen.add(r[0]);out.append(list(r))
        m.tick(len(out)*max(1,len(out).bit_length()));return sorted(out)
    fields(model['seed'],('t','m'),'SEED_FIELDS')
    seed=dict(t=supports(model['seed']['t'],False),m=supports(model['seed']['m'],True))
    fields(model['inventory'],('kind','placements'),'INVENTORY_FIELDS');need(model['inventory']['kind']=='EXPLICIT','EXPLICIT_ONLY')
    need(type(model['inventory']['placements']) is list,'ROW_LIST');rows={}
    for r in model['inventory']['placements']:
        m.tick();fields(r,('id','t','m'),'ROW_FIELDS');cid=r['id']
        need(type(cid) is str and cid and cid not in rows,'DISTINCT_ROW_ID')
        t=supports(r['t'],False);need(t and all(u>0 for p,u in t),'POSITIVE_ROW_SUPPORT')
        rows[cid]=dict(id=cid,t=t,m=supports(r['m'],True))
    need(type(model['unary_nogoods']) is list and model['unary_nogoods']==sorted(set(model['unary_nogoods']))
         and set(model['unary_nogoods'])<=set(rows),'UNARY_FILTER')
    pairs=model['pair_nogoods'];need(type(pairs) is list,'PAIR_FILTER')
    for pair in pairs:
        m.tick();need(type(pair) is list and len(pair)==2 and all(type(cid) is str and cid in rows for cid in pair)
                     and pair[0]<pair[1],'PAIR_IDENTITIES')
    need(pairs==[list(p) for p in sorted(set(tuple(p) for p in pairs))],'SORTED_UNIQUE_PAIRS')
    normalized=dict(schema=model['schema'],version=model['version'],capacity=cap,roots=sorted(model['roots']),seed=seed,
        inventory=dict(kind='EXPLICIT',placements=[rows[c] for c in sorted(rows)]),
        pair_nogoods=clone(pairs,m),unary_nogoods=list(model['unary_nogoods']))
    return normalized,rows,m.sha(normalized)


def aggregate(model,rows,ids,m):
    totals=dict(model['seed']['t']);marks=dict(model['seed']['m']);chosen=set(ids)
    m.tick(len(chosen)+len(model['seed']['t'])+len(model['seed']['m'])+len(model['unary_nogoods'])+len(model['pair_nogoods']))
    need(not chosen.intersection(model['unary_nogoods']),'UNARY_EXCLUDED')
    for a,b in model['pair_nogoods']:need(not(a in chosen and b in chosen),'PAIR_EXCLUDED')
    for cid in sorted(chosen):
        m.tick();need(cid in rows,'UNKNOWN_SELECTED_ID')
        for p,u in rows[cid]['t']:
            m.tick();totals[p]=totals.get(p,0)+u;need(totals[p]<=model['capacity'],'POINT_CAPACITY')
        for p,v in rows[cid]['m']:
            m.tick();need(p not in marks or marks[p]==v,'LITERAL_MARK_DISAGREEMENT');marks[p]=v
    return totals,marks


class AdmissionChecker:
    """One current immutable index; work/wall are cumulative across admissions."""
    def __init__(self,statement,prepared,model,library,limits=None):
        self.m=None;self.status='REJECTED';self.reason=None;self.cache={};self.calls=0
        try:
            self.m=_Meter(limits_value(limits));m=self.m
            for v in (statement,prepared,model,library):m.scan(v)
            self.statement=clone(statement,m);self.library=clone(library,m)
            need(prepared['schema']=='Shared-fact-prepared-v2' and prepared['status']=='PREPARED_UNVERIFIED','PREPARED_ABI')
            m.same(prepared['statement'],statement,'CURRENT_PREPARED_STATEMENT');m.same(prepared['catalogue']['statement'],statement,'CURRENT_CATALOGUE_STATEMENT')
            statement_shape(statement,m)
            need(type(library['families']) is list,'LIBRARY_FAMILIES')
            if library['families']:
                f=library['families'][0];donor=substitute(f['statement_template'],f['prototype_bindings'],m)
                proof=substitute(f['proof_template'],f['prototype_bindings'],m)
                self.families,self.clusters=library_data(donor,proof,library,m)
            else:
                need(library['schema']=='Receptor-family-library-v1' and library['status']=='CANDIDATE_LIBRARY','EMPTY_LIBRARY_ABI')
                self.families={};self.clusters={c['id']:c for c in library['clusters']}
            self.families=clone(self.families,m);self.clusters=clone(self.clusters,m)
            need(integer(library['donor']['lines'],1) and prepared['binding']['slots']==library['donor']['lines'],'FIXED_DONOR_LINE_SLOT_MAPPING')
            self.lines=library['donor']['lines'];self.prepared_scope=prepared['binding']['scope']
            self.model,self.rows,self.model_sha256=model_index(model,m)
            self.library_sha256=m.sha(library);self.statement_sha256=m.sha(statement)
            cat=prepared['catalogue'];forms=cat['formulas'];need(type(forms) is list and forms,'CURRENT_FORMULAS')
            need(prepared['binding']['catalogue_sha256']==m.sha(cat)
                 and prepared['binding']['original_statement_sha256']==self.statement_sha256,'CURRENT_PREPARED_CONTENT_BINDINGS')
            self.formulas={m.wire(f):i+1 for i,f in enumerate(forms)};need(len(self.formulas)==len(forms),'DISTINCT_CURRENT_FORMULAS')
            self.zeros={};self.mp={};self.gen={}
            for z in cat['zeros']:
                m.tick();key=m.wire(z['native']);self.zeros.setdefault(key,[]).append(z['id'])
            for values in self.zeros.values():values.sort()
            for d in cat['mp']:
                m.tick();key=(d['antecedent'],d['implication'],d['output']);need(key not in self.mp,'DISTINCT_MP');self.mp[key]='mp:'+str(d['implication'])
            for d in cat['gen']:
                m.tick();key=(d['source'],d['output'],d['variable']);need(key not in self.gen,'DISTINCT_GEN');self.gen[key]='gen:'+str(d['output'])
            m.tick();self.status='READY'
        except (_Budget,MemoryError,RecursionError) as e:self.status='UNKNOWN';self.reason=str(e) or type(e).__name__
        except (_Reject,ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError) as e:self.status='REJECTED';self.reason=str(e) or type(e).__name__

    def _expansion(self,family,instance):
        m=self.m;b=instance['bindings'];fields(b,('terms','contexts'),'INSTANCE_BINDINGS')
        for kind in ('terms','contexts'):need(type(b[kind]) is dict and set(b[kind])==set(family['parameters'][kind]),'INSTANCE_PARAMETER_SET')
        for t in b['terms'].values():need(term(t,m)==0,'GROUND_TERM_PARAMETER_SHAPE')
        for c in b['contexts'].values():need(term(c,m,True)==1,'EXACT_ONE_HOLE_CONTEXT')
        cache_key=m.sha(dict(model=self.model_sha256,family=family['id'],bindings=b,expansion=instance['expansion']))
        if cache_key in self.cache:return self.cache[cache_key]
        s=substitute(family['statement_template'],b,m);proof=substitute(family['proof_template'],b,m)
        m.same(proof,instance['expansion'],'ENTIRE_INSTANTIATED_PROOF');need(len(proof)==self.lines,'FULL_FIXED_LINE_EXPANSION')
        target=self.statement;statement_shape(target,m)
        m.same(s['goal'],target['goal'],'CURRENT_EXACT_GOAL')
        for kind in ('functions','predicates'):
            for name,arity in s['theory'][kind].items():
                m.tick()
                if name in target['theory'][kind]:need(type(arity) is int and target['theory'][kind][name]==arity,'SURVIVING_SIGNATURE_ARITY')
        for name,f in s['theory']['axioms'].items():
            m.tick();need(name in target['theory']['axioms'],'CURRENT_NAMED_HYPOTHESIS');m.same(f,target['theory']['axioms'][name],'CURRENT_HYPOTHESIS_FORMULA')
        proof_edges(proof,m);line_cids=[];fids=[]
        for i,line in enumerate(proof):
            m.tick();syntax_formula(line['formula'],target['theory'],m);k=m.wire(line['formula'])
            need(k in self.formulas,'CURRENT_LITERAL_FORMULA');fid=self.formulas[k];fids.append(fid);rule=line['rule']
            if rule in ZERO_RULES:
                key=m.wire(line);need(key in self.zeros,'EXACT_CURRENT_NATIVE_ZERO_PAYLOAD');did=self.zeros[key][0];kind='ZERO';refs=[]
            elif rule=='mp':
                refs=[line['antecedent'],line['implication']];key=(fids[refs[0]],fids[refs[1]],fid)
                need(key in self.mp,'CURRENT_MP_DEFINITION');did=self.mp[key];kind='MP'
            else:
                refs=[line['source']];key=(fids[refs[0]],fid,line['variable'])
                need(key in self.gen,'CURRENT_GEN_DEFINITION');did=self.gen[key];kind='GEN'
            cid=m.wire([i,kind,did,refs]).decode('ascii');need(cid in self.rows,'ACTUAL_CURRENT_PRIMITIVE_CID')
            row=self.rows[cid];m.same(row['t'],[['q:'+str(i),1]],'CURRENT_OWN_CENTER')
            demands={('a:'+str(i)):'1',('f:'+str(i)):str(fid)}
            for j in refs:demands['a:'+str(j)]='1';demands['f:'+str(j)]=str(fids[j])
            actual=dict(row['m'])
            for p,v in demands.items():m.tick();need(actual.get(p)==v,'CURRENT_PRIMITIVE_FORMULA_RECEPTOR')
            line_cids.append(cid)
        m.same(proof[-1]['formula'],target['goal'],'INSTANCE_LAST_GOAL')
        totals,marks=aggregate(self.model,self.rows,line_cids,m)
        need(all(totals.get(p,0)==self.model['capacity'] for p in self.model['roots']),'FULL_FIXED_MAPPING_POINT_COVER')
        result=(proof,line_cids);self.cache[cache_key]=result;return result

    def admit(self,instance):
        m=self.m
        if self.status!='READY':return _receipt(self.status,m,reason=self.reason,scope='No current concrete instance admitted.')
        try:
            self.calls+=1
            if self.calls>m.limits['max_instances']:raise _Budget('MAX_INSTANCES')
            m.scan(instance);fields(instance,('id','family_id','cluster_id','bindings','line_cids','receptors','root','expansion'),'INSTANCE_FIELDS')
            body={k:v for k,v in instance.items() if k!='id'}
            need(instance['id']==m.sha(dict(schema='Receptor-instance-v1',**body)),'INSTANCE_ID')
            need(instance['family_id'] in self.families and instance['cluster_id'] in self.clusters,'ADMITTED_FAMILY_CLUSTER_ID')
            family=self.families[instance['family_id']];cluster=self.clusters[instance['cluster_id']]
            proof,cids=self._expansion(family,instance)
            m.same(instance['root'],cluster['root'],'CLUSTER_ROOT')
            m.same(instance['line_cids'],[[i,cids[i]] for i in cluster['members']],'EXACT_CLUSTER_PRIMITIVE_MEMBERS')
            m.same(instance['receptors'],[[i,proof[i]['formula']] for i in cluster['receptor_indices']],'EXACT_EXTERNAL_RECEPTORS')
            binding=dict(model_sha256=self.model_sha256,instance_sha256=m.sha(instance),
                statement_sha256=self.statement_sha256,library_sha256=self.library_sha256)
            m.tick();return _receipt('VERIFIED_INSTANCE',m,bindings=binding,prepared_scope=self.prepared_scope,
                family_id=instance['family_id'],cluster_id=instance['cluster_id'],
                cluster_cids=[cids[i] for i in cluster['members']],all_line_cids=[[i,c] for i,c in enumerate(cids)],
                scope='Concrete current primitive-row/full-expansion/fixed-slot and receptor admission. Separate complete RF/N/native ZERO/custody gates and final M/N/B target acceptance remain mandatory; not a universal family proof or extension claim.')
        except (_Budget,MemoryError,RecursionError) as e:
            self.status='UNKNOWN';self.reason=str(e) or type(e).__name__;return _receipt('UNKNOWN',m,reason=self.reason)
        except (_Reject,ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError) as e:
            return _receipt('REJECTED',m,reason=str(e) or type(e).__name__)


def admit(statement,prepared,model,library,instance,limits=None):
    return AdmissionChecker(statement,prepared,model,library,limits).admit(instance)


class StateChecker:
    """Caller passes only raw instances with independently bound admissions."""
    def __init__(self,model,admitted_instances,limits=None):
        self.status='REJECTED';self.reason=None;self.instances={}
        try:
            m=_Meter(limits_value(limits));m.scan(model);m.scan(admitted_instances)
            self.model,self.rows,self.model_sha256=model_index(model,m)
            need(type(admitted_instances) is list,'APPROVED_RAW_INSTANCE_LIST')
            if len(admitted_instances)>m.limits['max_instances']:raise _Budget('MAX_INSTANCES')
            for instance in admitted_instances:
                m.tick();fields(instance,('id','family_id','cluster_id','bindings','line_cids','receptors','root','expansion'),'APPROVED_INSTANCE_FIELDS')
                need(type(instance['id']) is str and instance['id'] not in self.instances,'DISTINCT_APPROVED_INSTANCE')
                need(instance['id']==m.sha(dict(schema='Receptor-instance-v1',**{k:v for k,v in instance.items() if k!='id'})),'APPROVED_INSTANCE_ID')
                pairs=instance['line_cids'];need(type(pairs) is list and pairs,'NONEMPTY_CLUSTER')
                indices=[];cids=[]
                for pair in pairs:
                    m.tick();need(type(pair) is list and len(pair)==2 and integer(pair[0]) and type(pair[1]) is str and pair[1] in self.rows,'APPROVED_CURRENT_MEMBER')
                    indices.append(pair[0]);cids.append(pair[1])
                need(indices==sorted(set(indices)) and len(cids)==len(set(cids)) and integer(instance['root'])
                     and instance['root'] in indices,'APPROVED_CLUSTER_ROOT_MEMBERS')
                proof=instance['expansion'];proof_edges(proof,m)
                need(all(i<len(proof) for i in indices),'APPROVED_MEMBER_LINE_RANGE')
                receptors=instance['receptors'];need(type(receptors) is list,'APPROVED_RECEPTOR_LIST');outside=[]
                for pair in receptors:
                    m.tick();need(type(pair) is list and len(pair)==2 and integer(pair[0]) and pair[0]<len(proof)
                         and pair[0] not in indices,'APPROVED_RECEPTOR_SHAPE')
                    m.same(pair[1],proof[pair[0]]['formula'],'APPROVED_RECEPTOR_FORMULA');outside.append(pair[0])
                need(outside==sorted(set(outside)),'SORTED_APPROVED_RECEPTORS')
                self.instances[instance['id']]=dict(value=clone(instance,m),sha256=m.sha(instance),cids=tuple(cids))
            m.tick();self.status='READY'
        except (_Budget,MemoryError,RecursionError) as e:self.status='UNKNOWN';self.reason=str(e) or type(e).__name__
        except (_Reject,ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError) as e:self.status='REJECTED';self.reason=str(e) or type(e).__name__

    def check(self,instance,request,charge):
        # Only our own rejection is caught. Any exception from the engine's
        # charge hook, including one of our private types, is re-raised intact.
        hook_error=[None]
        class Hook(_Meter):
            def __init__(self):self.work=0;self.started=time.perf_counter();self.limits=DEFAULT_LIMITS
            def tick(self,n=1):
                self.work+=n
                try:charge(n)
                except BaseException as e:hook_error[0]=e;raise
        m=Hook()
        try:
            m.tick();need(self.status=='READY','STATE_INDEX_UNAVAILABLE:'+str(self.reason))
            need(type(instance) is dict and type(instance.get('id')) is str and instance['id'] in self.instances,'UNKNOWN_APPROVED_INSTANCE')
            entry=self.instances[instance['id']];m.same(instance,entry['value'],'UNCHANGED_APPROVED_INSTANCE')
            fields(request,('schema','model_sha256','point','generation','legal','selected','excluded'),'REQUEST_FIELDS')
            need(request['schema']=='Z-candidate-order-request-v1' and request['model_sha256']==self.model_sha256,'CURRENT_REQUEST_MODEL')
            need(type(request['point']) is str and request['point'] and integer(request['generation']),'REQUEST_POINT_GENERATION')
            for key in ('legal','selected','excluded'):
                value=request[key];need(type(value) is list and all(type(c) is str and c in self.rows for c in value),'CURRENT_REQUEST_IDS')
                m.tick(len(value)*max(1,len(value).bit_length()));need(value==sorted(set(value)),'SORTED_UNIQUE_REQUEST_IDS')
            selected=set(request['selected']);excluded=set(request['excluded']);members=set(entry['cids'])
            m.tick(len(selected)+len(excluded)+len(members));need(not selected.intersection(excluded),'SELECTED_EXCLUDED_DISJOINT')
            need(not members.intersection(excluded),'CLUSTER_HAS_LOCAL_EXCLUDED_MEMBER')
            totals,marks=aggregate(self.model,self.rows,selected,m)
            active=set(self.model['roots'])|{p for p,u in totals.items() if u>0}
            need(request['point'] in active and totals.get(request['point'],0)<self.model['capacity'],'CURRENT_FRONTIER_POINT')
            for cid in request['legal']:
                m.tick(1+len(self.rows[cid]['t']));need(cid not in selected and cid not in excluded and any(p==request['point'] and u>0 for p,u in self.rows[cid]['t']),'CURRENT_LEGAL_POINT_CONTACT')
            preferred=sorted(members.intersection(request['legal']));m.tick(len(preferred))
            need(preferred,'NO_NEW_CURRENT_LEGAL_CLUSTER_MEMBER')
            union=selected|members;aggregate(self.model,self.rows,union,m)
            receptors=entry['value']['receptors'];need(type(receptors) is list,'ADMITTED_RECEPTOR_LIST')
            for outside,formula in receptors:
                m.tick();need(integer(outside) and outside<len(entry['value']['expansion']),'ADMITTED_RECEPTOR_INDEX')
                m.same(formula,entry['value']['expansion'][outside]['formula'],'UNCHANGED_RECEPTOR_ASSERTION')
            binding=dict(model_sha256=self.model_sha256,instance_sha256=entry['sha256'],
                selected_sha256=m.sha(request['selected']),excluded_sha256=m.sha(request['excluded']),union_sha256=m.sha(sorted(union)))
            m.tick();return dict(status='COMPATIBLE',bindings=binding,preferred=preferred,
                shared_members=len(selected&members),new_members=len(members-selected),receptors=len(receptors),work=m.work,
                scope='Consistent current distinct-placement t/m/filter union, with an actual requested-point legal member. Missing receptor owners are permitted literal demands, not an extension certificate. Scheduler/domain completeness, admitted-instance provenance and final theorem validity remain separate.')
        except _Reject as e:
            if hook_error[0] is not None:raise
            return dict(status='REJECTED',reason=str(e),work=m.work,
                scope='Proposal refusal only; complete primitive fallback must remain. Not a negative proof-search label.')
