"""Goal-directed conventional control over all admitted finite producers.

This is an explicitly specialized unique-formula acyclic shared-fact planner,
not the GCTS scheduler. It returns only an inventory-selected candidate;
independent complete M/N decoding and native B validation remain mandatory.
No goal-specific derivation, prior witness or proof bank is imported.
"""
import importlib.util
from pathlib import Path
import time

DEFAULT_LIMITS = dict(max_states=100000, max_work=1000000000, wall_seconds=120.0)
SCOPE = ('Specialized deterministic goal-directed AND/OR search with shared '
         'formula facts over every original ZERO/MP/GEN producer. Acyclic '
         'unique-formula plans only; failure/line overflow/resource refusal is '
         'UNKNOWN, never finite absence. Full slots/PAD and final-goal position '
         'are checked against actual original CIDs. No GCTS/performance claim.')


def _rank_module():
    # Runtime dependency is this run's frozen sibling Source, never old outputs.
    source = Path(__file__).resolve().with_name('rank_pruning_v1.py')
    spec = importlib.util.spec_from_file_location('rank_control_helpers', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Planner:
    def __init__(self, data, reader, ranks, max_states):
        self.data, self.reader, self.ranks, self.max_states = data, reader, ranks, max_states
        self.counts = dict(states=0, producer_choices=0, cycle_skips=0,
                           line_bound_skips=0, rank_skips=0, best_plan_lines=0)
        self.producers = {fid: [] for fid in range(1, data['n'] + 1)}
        for definition in data['definitions']['zeros']:
            reader.tick()
            self.producers[definition['output']].append(('ZERO', definition['id'], ()))
        for definition in data['definitions']['mp']:
            reader.tick()
            self.producers[definition['output']].append(('MP', definition['id'],
                (definition['antecedent'], definition['implication'])))
        for definition in data['definitions']['gen']:
            reader.tick()
            self.producers[definition['output']].append(('GEN', definition['id'], (definition['source'],)))

    def _choice_key(self, producer, known):
        kind, definition_id, dependencies = producer
        self.reader.tick(1 + len(dependencies))
        height = max((self.ranks[fid] if self.ranks[fid] is not None else self.data['n'] + 1
                      for fid in dependencies), default=0) if self.ranks is not None else 0
        missing = len(set(dependencies) - known)
        return height, missing, len(dependencies), kind, definition_id

    def prove(self, fid, plan=(), ancestors=frozenset()):
        self.reader.tick(1 + len(plan) + len(ancestors))
        self.counts['states'] += 1
        if self.counts['states'] > self.max_states:
            raise self.budget('MAX_STATES')
        self.counts['best_plan_lines'] = max(self.counts['best_plan_lines'], len(plan))
        known = {node[0] for node in plan}
        if fid in known:
            yield plan
            return
        if fid in ancestors:
            self.counts['cycle_skips'] += 1
            return
        if len(plan) + len(ancestors) >= self.data['slots']:
            self.counts['line_bound_skips'] += 1
            return
        if self.ranks is not None and (self.ranks[fid] is None or self.ranks[fid] > self.data['slots']):
            self.counts['rank_skips'] += 1
            return
        choices = self.producers[fid]
        self.reader.tick(len(choices) * max(1, len(choices).bit_length()))
        for producer in sorted(choices, key=lambda item: self._choice_key(item, known)):
            self.reader.tick()
            self.counts['producer_choices'] += 1
            for expanded in self._premises(producer[2], 0, plan, ancestors | {fid}):
                self.reader.tick(1 + len(expanded))
                if len(expanded) >= self.data['slots']:
                    self.counts['line_bound_skips'] += 1
                    continue
                if fid in {node[0] for node in expanded}:
                    # Ancestor protection should already prevent this shape.
                    raise ValueError('ACYCLIC_UNIQUE_FORMULA_INVARIANT')
                result = expanded + ((fid, producer[0], producer[1], producer[2]),)
                self.counts['best_plan_lines'] = max(self.counts['best_plan_lines'], len(result))
                yield result

    def _premises(self, premises, index, plan, ancestors):
        self.reader.tick()
        if index == len(premises):
            yield plan
            return
        for expanded in self.prove(premises[index], plan, ancestors):
            yield from self._premises(premises, index + 1, expanded, ancestors)

    def emit(self, plan):
        reader, slots = self.reader, self.data['slots']
        if not plan or len(plan) > slots or plan[-1][0] != self.data['goal']:
            raise ValueError('FINAL_GOAL_WITHIN_SLOT_BOUND')
        reader.tick(len(self.data['rows']))
        rows = {row['id']: row for row in self.data['rows']}
        assigned = {node[0]: (slots - 1 if index == len(plan) - 1 else index)
                    for index, node in enumerate(plan)}
        if len(assigned) != len(plan):
            raise ValueError('UNIQUE_FACT_PLAN')
        selected, records, used_slots = [], [], set()
        for fid, kind, definition_id, dependencies in plan:
            reader.tick(1 + len(dependencies))
            slot = assigned[fid]
            refs = [assigned[source] for source in dependencies]
            if any(reference >= slot for reference in refs):
                raise ValueError('STRICT_PRIOR_PLAN_REFERENCES')
            cid = reader.text([slot, kind, definition_id, refs])
            if cid not in rows:
                raise ValueError('ACTUAL_COMPLETE_INVENTORY_MEMBERSHIP')
            selected.append(cid)
            used_slots.add(slot)
            records.append(dict(formula_id=fid, kind=kind, definition_id=definition_id,
                                premises=list(dependencies), slot=slot, cid=cid))
        for slot in range(slots):
            reader.tick()
            if slot not in used_slots:
                cid = reader.text([slot, 'PAD', 'pad', []])
                if cid not in rows:
                    raise ValueError('ACTUAL_PADDING_INVENTORY_MEMBERSHIP')
                selected.append(cid)
        if len(selected) != slots or len(set(selected)) != slots:
            raise ValueError('ONE_FULL_OWNER_PER_SLOT')
        totals, marks = {}, {}
        for port, value in self.seed['t']:
            totals[port] = value
        for port, value in self.seed['m']:
            marks[port] = value
        for cid in selected:
            reader.tick()
            for port, value in rows[cid]['t']:
                reader.tick()
                totals[port] = totals.get(port, 0) + value
                if totals[port] > 1:
                    raise ValueError('CANDIDATE_POINT_CAPACITY')
            for port, value in rows[cid]['m']:
                reader.tick()
                if port in marks and marks[port] != value:
                    raise ValueError('CANDIDATE_MARK_AGREEMENT')
                marks[port] = value
        if any(totals.get('q:' + str(slot), 0) != 1 for slot in range(slots)):
            raise ValueError('CANDIDATE_FULL_SLOT_TARGET')
        selected.sort()
        return selected, records


def search(prepared, analysis=None, limits=None):
    started, reader, effective, planner = time.perf_counter(), None, None, None
    try:
        rank = _rank_module()
        effective = rank.effective_limits(limits, DEFAULT_LIMITS)
        input_limits = dict(rank.DEFAULT_LIMITS, max_work=effective['max_work'], wall_seconds=effective['wall_seconds'])
        reader = rank.Reader(input_limits)
        reader.started = started
        data = rank._input(prepared, None, reader)
        heights = None
        if analysis is not None:
            reader.scan(analysis)
            rank.need(type(analysis) is dict and analysis['schema'] == 'Rank-pruning-analysis-v1'
                      and analysis['status'] == 'CANDIDATE', 'COMPLETED_RANK_PACKET')
            rank.need(reader.same(analysis['bindings'], data['bindings']), 'SAME_COMPLETE_RANK_SCOPE')
            table = analysis['ranks']
            rank.need(type(table) is list and len(table) == data['n'], 'FULL_RANK_TABLE')
            heights = {}
            for index, pair in enumerate(table, 1):
                reader.tick()
                rank.need(type(pair) is list and len(pair) == 2 and type(pair[0]) is int
                          and pair[0] == index and (pair[1] is None or type(pair[1]) is int
                          and 1 <= pair[1] <= data['n']), 'LITERAL_RANK_ENTRY')
                heights[index] = pair[1]
        planner = Planner(data, reader, heights, effective['max_states'])
        planner.budget, planner.seed = rank.Budget, prepared['model']['seed']
        for plan in planner.prove(data['goal']):
            selected, records = planner.emit(plan)
            if analysis is not None:
                reader.tick(len(analysis['forbidden']) + len(selected))
                rank.need(not set(selected).intersection(analysis['forbidden']), 'PLAN_PRESERVES_ADMITTED_RANK_EXCLUSIONS')
            selected_sha256 = reader.digest(selected)
            reader.tick(0)
            return dict(schema='Conventional-proof-search-v1', status='FOUND_CANDIDATE', bindings=data['bindings'],
                selected=selected, selected_sha256=selected_sha256, plan=records,
                used_rank_analysis=analysis is not None,
                costs=dict(seconds=time.perf_counter() - started, work=reader.work, **planner.counts),
                limits=effective, scope=SCOPE,
                admission='Unverified candidate only; fresh complete M/N decode and native B required.')
        status, reason = 'UNKNOWN', 'NO_PLAN_IN_SPECIALIZED_SEARCH_SPACE'
    except (MemoryError, RecursionError) as error:
        status, reason = 'UNKNOWN', str(error) or type(error).__name__
    except Exception as error:
        if reader is not None and type(error).__name__ == 'Budget':
            status, reason = 'UNKNOWN', str(error)
        elif isinstance(error, (ValueError, TypeError, KeyError, IndexError, AttributeError, OverflowError)):
            status, reason = 'REJECTED_INPUT', str(error)
        else:
            raise
    if reader is not None:
        try:
            reader.tick(0)
        except Exception as error:
            if type(error).__name__ == 'Budget':
                reason = str(error)
                status = 'UNKNOWN'
            else:
                raise
    return dict(schema='Conventional-proof-search-v1', status=status, reason=reason,
        used_rank_analysis=analysis is not None, limits=effective,
        costs=dict(seconds=time.perf_counter() - started, work=0 if reader is None else reader.work,
                   **({} if planner is None else planner.counts)), scope=SCOPE)
