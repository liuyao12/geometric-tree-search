"""Erased open fragments and bounded, root-CID-local recommendation sampling.

No compiler, kernel, engine, proof decoder or donor/target proof mapper imports.
Independent fragment provenance, instance/state admission and final native
validation are external. An empty/refused recommendation never prunes a move.
"""
import hashlib
import itertools
import json
import math
import time

DEFAULT_LIMITS = dict(max_work=100000000, wall_seconds=30.0,
                      max_families=4096, max_instances=4096, max_lines=16)
QUERY_CEILINGS = dict(max_work=2000000, wall_seconds=1.0, max_instances=32)
ZERO_RULES = frozenset(('axiom', 'instantiate', 'refl', 'eq_subst', 'distribute', 'tautology'))
SCOPE = ('Empirical erased proper fragments, not axioms. Only internal primitive '
         'placements are mapped at an actual current root CID; external receptors '
         'remain unresolved demands. Deterministic bounded recommendations have '
         'no completeness, absence, whole-goal, whole-cover or pruning claim. '
         'Independent current instance/state checks and final native checks remain external.')


class Reject(Exception):
    pass


class Budget(Exception):
    pass


class _Hook(BaseException):
    def __init__(self, error):
        self.error = error


def need(condition, reason):
    if not condition:
        raise Reject(reason)


def _limits(value):
    result = dict(DEFAULT_LIMITS)
    if value is not None:
        need(type(value) is dict and set(value) <= set(result), 'LIMIT_FIELDS')
        result.update(value)
    for key, value in result.items():
        if key == 'wall_seconds':
            need(type(value) in (int, float) and math.isfinite(value) and value > 0,
                 'FINITE_POSITIVE_WALL')
        else:
            need(type(value) is int and value >= 0, 'NATIVE_NONNEGATIVE_LIMIT:' + key)
        need(value <= DEFAULT_LIMITS[key], 'LIMIT_EXCEEDS_CEILING:' + key)
    return result


class Reader:
    def __init__(self, limits, charge=None):
        self.limits, self.charge = limits, charge
        self.started, self.work = time.perf_counter(), 0

    def tick(self, units=1):
        self.work += units
        if self.charge is not None:
            try:
                self.charge(units)
            except BaseException as error:
                raise _Hook(error)
        if self.work > self.limits['max_work']:
            raise Budget('MAX_WORK')
        if time.perf_counter() - self.started > self.limits['wall_seconds']:
            raise Budget('WALL_SECONDS')

    def scan(self, value):
        active, stack = set(), [(value, 0, False)]
        while stack:
            item, depth, leaving = stack.pop()
            if leaving:
                active.remove(id(item))
                continue
            self.tick()
            if depth > 128:
                raise Budget('NATIVE_JSON_DEPTH')
            if type(item) in (dict, list):
                need(id(item) not in active, 'NATIVE_JSON_CYCLE')
                active.add(id(item)); stack.append((item, depth, True))
                self.tick(len(item))
                if type(item) is dict:
                    for key, child in item.items():
                        need(type(key) is str, 'NATIVE_STRING_KEYS')
                        stack.extend(((key, depth + 1, False), (child, depth + 1, False)))
                else:
                    stack.extend((child, depth + 1, False) for child in item)
            elif type(item) is str:
                self.tick(len(item))
            else:
                need(item is None or type(item) in (int, bool) or
                     type(item) is float and math.isfinite(item), 'FINITE_NATIVE_JSON')
                if type(item) is int:
                    self.tick(item.bit_length() // 3 + 1)

    def text(self, value):
        self.scan(value)
        result = json.dumps(value, sort_keys=True, ensure_ascii=True,
                            separators=(',', ':'), allow_nan=False) + '\n'
        self.tick(len(result))
        return result

    def sha(self, value):
        self.scan(value)
        digest = hashlib.sha256()
        encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                                   separators=(',', ':'), allow_nan=False)
        for part in encoder.iterencode(value):
            self.tick(len(part) + 1)
            digest.update(part.encode('ascii'))
            self.tick(0)
        digest.update(b'\n'); self.tick()
        return digest.hexdigest()

    def same(self, left, right):
        return self.text(left) == self.text(right)

    def clone(self, value):
        self.tick()
        if type(value) is list:
            return [self.clone(child) for child in value]
        if type(value) is dict:
            return {key: self.clone(child) for key, child in value.items()}
        if type(value) is str:
            self.tick(len(value))
        return value


def _refs(line):
    if line['rule'] == 'mp':
        return [('antecedent', line['antecedent']), ('implication', line['implication'])]
    if line['rule'] == 'generalize':
        return [('source', line['source'])]
    need(line['rule'] in ZERO_RULES, 'PRIMITIVE_RULE')
    return []


def _visible(value, reader):
    terms, contexts, stack = set(), set(), [value]
    while stack:
        item = stack.pop(); reader.tick()
        if type(item) is list:
            if item and item[0] == '_term':
                need(len(item) == 2 and type(item[1]) is str, 'TERM_PARAMETER_SYNTAX')
                terms.add(item[1])
            elif item and item[0] == '_ctx':
                need(len(item) == 3 and type(item[1]) is str, 'CONTEXT_PARAMETER_SYNTAX')
                contexts.add(item[1])
            stack.extend(item)
        elif type(item) is dict:
            stack.extend(item.values())
    return terms, contexts


def _cluster_body(proof, members, reader):
    chosen, internal, external = set(members), [], []
    root = members[-1]
    for i in members:
        for field, premise in _refs(proof[i]):
            reader.tick()
            need(type(premise) is int and 0 <= premise < i, 'DONOR_STRICT_PRIOR_REFERENCE')
            (internal if premise in chosen else external).append([premise, i, field])
    reached, pending = set(), [root]
    while pending:
        i = pending.pop(); reader.tick()
        if i not in reached:
            reached.add(i)
            pending.extend(p for p, c, field in internal if c == i)
    if reached != chosen:
        return None
    return dict(root=root, members=members, internal_edges=sorted(internal),
                external_edges=sorted(external),
                receptor_indices=sorted({edge[0] for edge in external}))


def _finish(schema, status, reader, limits, counts, **fields):
    if reader is not None:
        reader.tick(0)
    return dict(schema=schema, status=status, **fields, costs=dict(
        seconds=0.0 if reader is None else time.perf_counter() - reader.started,
        work=0 if reader is None else reader.work, **counts), limits=limits, scope=SCOPE)


def materialize(old_library, limits=None):
    """Export every boundary-visible proper rooted 2..4-node source cluster."""
    reader = effective = None
    counts = dict(source_families=0, source_clusters=0, fragments=0,
                  ineligible_boundary_parameters=0)
    try:
        effective = _limits(limits); reader = Reader(effective)
        reader.scan(old_library)
        need(old_library['schema'] == 'Receptor-family-library-v1' and
             old_library['status'] == 'CANDIDATE_LIBRARY', 'SOURCE_LIBRARY')
        n = old_library['donor']['lines']
        need(type(n) is int and n > 0, 'DONOR_LINE_COUNT')
        if n > effective['max_lines']:
            raise Budget('MAX_LINES')
        families, clusters = old_library['families'], old_library['clusters']
        need(type(families) is list and type(clusters) is list, 'SOURCE_COLLECTIONS')
        if len(families) > effective['max_families']:
            raise Budget('MAX_FAMILIES')
        counts.update(source_families=len(families), source_clusters=len(clusters))
        cluster_map = {}
        for cluster in clusters:
            reader.tick()
            body = {key: cluster[key] for key in ('root', 'members', 'internal_edges',
                    'external_edges', 'receptor_indices')}
            need(cluster['id'] == reader.sha(dict(schema='Receptor-cluster-v1', **body)), 'SOURCE_CLUSTER_ID')
            need(cluster['id'] not in cluster_map, 'DUPLICATE_SOURCE_CLUSTER')
            cluster_map[cluster['id']] = cluster
        fragments, family_ids = {}, set()
        for family in families:
            reader.tick()
            body = {key: family[key] for key in ('parameters', 'statement_template',
                                                'proof_template', 'prototype_bindings')}
            need(family['id'] == reader.sha(dict(schema='Receptor-family-v1', **body)), 'SOURCE_FAMILY_ID')
            need(family['id'] not in family_ids, 'DUPLICATE_SOURCE_FAMILY')
            family_ids.add(family['id'])
            proof = family['proof_template']
            need(type(proof) is list and len(proof) == n, 'SOURCE_PROOF_LENGTH')
            for i, line in enumerate(proof):
                need(type(line) is dict and 'formula' in line, 'SOURCE_LINE')
                for field, premise in _refs(line):
                    need(type(premise) is int and 0 <= premise < i, 'DONOR_STRICT_PRIOR_REFERENCE')
            for size in range(2, min(4, n - 1) + 1):
                for subset in itertools.combinations(range(n), size):
                    reader.tick()
                    members = list(subset)
                    cb = _cluster_body(proof, members, reader)
                    if cb is None or not cb['receptor_indices']:
                        continue
                    cluster_id = reader.sha(dict(schema='Receptor-cluster-v1', **cb))
                    need(cluster_id in cluster_map and reader.same(cb,
                         {key: cluster_map[cluster_id][key] for key in cb}), 'COMPLETE_SOURCE_CLUSTER')
                    lines = [[i, proof[i]] for i in members]
                    receptors = [[i, proof[i]['formula']] for i in cb['receptor_indices']]
                    used_t, used_c = _visible([lines, receptors], reader)
                    boundary_t, boundary_c = _visible([proof[cb['root']]['formula'], receptors], reader)
                    need(used_t <= set(family['parameters']['terms']) and
                         used_c <= set(family['parameters']['contexts']), 'DECLARED_PARAMETERS')
                    if not used_t <= boundary_t or not used_c <= boundary_c:
                        counts['ineligible_boundary_parameters'] += 1
                        continue
                    value = dict(family_id=family['id'], cluster_id=cluster_id,
                        root=cb['root'], members=members, lines=reader.clone(lines),
                        receptors=reader.clone(receptors),
                        parameters=dict(terms=sorted(used_t), contexts=sorted(used_c)))
                    identifier = reader.sha(value)
                    need(identifier not in fragments, 'DUPLICATE_FRAGMENT')
                    fragments[identifier] = dict(id=identifier, **value)
                    if len(fragments) > effective['max_families']:
                        raise Budget('MAX_FAMILIES')
        counts['fragments'] = len(fragments)
        reader.tick(len(fragments) * max(1, len(fragments).bit_length()))
        return _finish('Open-fragment-library-v1', 'MATERIALIZED', reader, effective, counts,
            source_library_sha256=reader.sha(old_library), donor_lines=n,
            fragments=[fragments[key] for key in sorted(fragments)])
    except (Budget, MemoryError, RecursionError) as error:
        status, reason = 'UNKNOWN', str(error) or type(error).__name__
    except (Reject, ValueError, TypeError, KeyError, IndexError, AttributeError, OverflowError) as error:
        status, reason = 'REJECTED', str(error)
    return dict(schema='Open-fragment-library-v1', status=status, reason=reason,
        costs=dict(work=0 if reader is None else reader.work,
                   seconds=0.0 if reader is None else time.perf_counter() - reader.started,
                   **counts), limits=effective, scope=SCOPE)


def _term(value):
    return type(value) is list and bool(value) and value[0] in ('var', 'fun')


def _positions(term, reader, path=()):
    reader.tick()
    yield path, term
    if term[0] == 'fun':
        for i, child in enumerate(term[2]):
            yield from _positions(child, reader, path + (i,))


def _context(term, path, reader):
    reader.tick()
    if not path:
        return ['_hole']
    return ['fun', term[1], [reader.clone(child) if i != path[0]
            else _context(child, path[1:], reader) for i, child in enumerate(term[2])]]


def _match_many(left, right, i, binding, reader):
    reader.tick()
    if i == len(left):
        yield binding
    else:
        for new in _match(left[i], right[i], binding, reader):
            yield from _match_many(left, right, i + 1, new, reader)


def _match(template, target, binding, reader):
    reader.tick()
    if type(template) is list and template:
        if template[0] == '_term':
            if not _term(target):
                return
            name = template[1]
            if name in binding['terms']:
                if reader.same(binding['terms'][name], target):
                    yield binding
            else:
                yield dict(terms=dict(binding['terms'], **{name: target}), contexts=binding['contexts'])
            return
        if template[0] == '_ctx':
            if not _term(target):
                return
            name = template[1]
            for path, argument in _positions(target, reader):
                context = _context(target, path, reader)
                if name in binding['contexts'] and not reader.same(binding['contexts'][name], context):
                    continue
                new = dict(terms=binding['terms'], contexts=dict(binding['contexts'], **{name: context}))
                yield from _match(template[2], argument, new, reader)
            return
    if type(template) is not type(target):
        return
    if type(template) is list:
        if len(template) == len(target):
            yield from _match_many(template, target, 0, binding, reader)
    elif type(template) is dict:
        if template.keys() == target.keys():
            keys = sorted(template); reader.tick(len(keys))
            yield from _match_many([template[k] for k in keys], [target[k] for k in keys], 0, binding, reader)
    else:
        if type(template) is str:
            reader.tick(len(template) + len(target))
        if template == target:
            yield binding


def _normal_model(model, reader):
    need(model['schema'] == 'Z-growing-point-model-v3' and type(model['capacity']) is int
         and model['capacity'] == 1 and model['inventory']['kind'] == 'EXPLICIT', 'CURRENT_UNIT_EXPLICIT_MODEL')
    rows = []
    for row in model['inventory']['placements']:
        reader.tick(1 + len(row['t']) + len(row['m']))
        rows.append(dict(row, t=sorted(row['t']), m=sorted(row['m'])))
    reader.tick(len(rows) * max(1, len(rows).bit_length()))
    return dict(model, roots=sorted(model['roots']),
        seed=dict(t=sorted(model['seed']['t']), m=sorted(model['seed']['m'])),
        inventory=dict(model['inventory'], placements=sorted(rows, key=lambda row: row['id'])),
        pair_nogoods=sorted(model['pair_nogoods']), unary_nogoods=sorted(model['unary_nogoods']))


class LocalProposer:
    """Detached immutable-content indexes; every query has a fresh local budget."""
    def __init__(self, prepared, model, library, limits=None):
        self.failure, self.total_work, self.query_count = None, 0, 0
        self.setup_seconds, reader, self.limits = 0.0, None, None
        try:
            self.limits = _limits(limits); reader = Reader(self.limits)
            reader.scan(library); reader.scan(model)
            need(prepared['schema'] == 'Shared-fact-prepared-v2' and
                 prepared['status'] == 'PREPARED_UNVERIFIED', 'CURRENT_PREPARED')
            need(library['schema'] == 'Open-fragment-library-v1' and
                 library['status'] == 'MATERIALIZED', 'ERASED_LIBRARY_REQUIRED')
            need(type(library['donor_lines']) is int and library['donor_lines'] > 0, 'DONOR_LINES')
            if library['donor_lines'] > self.limits['max_lines']:
                raise Budget('MAX_LINES')
            if len(library['fragments']) > self.limits['max_families']:
                raise Budget('MAX_FAMILIES')
            self.fragments = []
            for fragment in library['fragments']:
                reader.tick()
                need(set(fragment) == {'id', 'family_id', 'cluster_id', 'root', 'members',
                     'lines', 'receptors', 'parameters'}, 'FRAGMENT_FIELDS')
                body = {key: value for key, value in fragment.items() if key != 'id'}
                need(fragment['id'] == reader.sha(body), 'FRAGMENT_ID')
                need(2 <= len(fragment['members']) <= 4 and len(fragment['members']) < library['donor_lines']
                     and fragment['members'] == sorted(set(fragment['members']))
                     and fragment['root'] == fragment['members'][-1], 'PROPER_ROOTED_MEMBERS')
                need([row[0] for row in fragment['lines']] == fragment['members'] and
                     fragment['receptors'] and [row[0] for row in fragment['receptors']] ==
                     sorted({row[0] for row in fragment['receptors']}), 'LOCAL_LINE_RECEPTOR_IDS')
                used = _visible([fragment['lines'], fragment['receptors']], reader)
                boundary = _visible([dict(fragment['lines'])[fragment['root']]['formula'], fragment['receptors']], reader)
                need(all(used[i] == set(fragment['parameters'][key]) and used[i] <= boundary[i]
                         for i, key in enumerate(('terms', 'contexts'))), 'USED_BOUNDARY_PARAMETERS')
                self.fragments.append(reader.clone(fragment))
            self.fragments.sort(key=lambda f: f['id'])
            reader.scan(prepared['binding']); reader.scan(prepared['catalogue']['formulas'])
            reader.scan(prepared['definitions'])
            self.formulas = reader.clone(prepared['catalogue']['formulas'])
            self.slots = prepared['binding']['slots']
            need(type(self.slots) is int and 0 < self.slots <= 16, 'CURRENT_SLOTS')
            definitions = reader.clone(prepared['definitions'])
            defs = {kind: {d['id']: d for d in definitions[name]}
                    for kind, name in (('ZERO', 'zeros'), ('MP', 'mp'), ('GEN', 'gen'))}
            self.rows, self.children = {}, {}
            original = {row['id'] for row in prepared['universe']}
            reader.tick(len(prepared['universe']))
            need(len(original) == len(prepared['universe']), 'UNIQUE_PREPARED_IDS')
            for row in model['inventory']['placements']:
                cid = row['id']; reader.tick(len(cid))
                parsed = json.loads(cid)
                need(type(parsed) is list and len(parsed) == 4 and reader.text(parsed) == cid, 'CANONICAL_CURRENT_CID')
                slot, kind, did, refs = parsed
                need(type(slot) is int and 0 <= slot < self.slots and type(kind) is str
                     and type(did) is str and type(refs) is list and
                     all(type(j) is int and 0 <= j < slot for j in refs), 'CURRENT_CID_FIELDS')
                need(cid not in self.rows, 'UNIQUE_CURRENT_IDS')
                if kind == 'PAD':
                    need(did == 'pad' and not refs, 'PAD_CID')
                    record = (slot, kind, None, (), 0, ())
                else:
                    need(kind in defs and did in defs[kind], 'CURRENT_DEFINITION')
                    definition = defs[kind][did]
                    demand = () if kind == 'ZERO' else (definition['antecedent'], definition['implication']) if kind == 'MP' else (definition['source'],)
                    need(len(refs) == len(demand), 'CURRENT_REFERENCE_COUNT')
                    fid = definition['output']
                    need(type(fid) is int and 1 <= fid <= len(self.formulas) and
                         all(type(f) is int and 1 <= f <= len(self.formulas) for f in demand), 'CURRENT_FORMULA_IDS')
                    record = (slot, kind, definition, tuple(refs), fid, tuple(demand))
                    self.children.setdefault((slot, kind, fid), []).append(cid)
                self.rows[cid] = record
            need(set(self.rows) == original, 'FULL_CURRENT_INVENTORY_IDS')
            for values in self.children.values():
                reader.tick(len(values) * max(1, len(values).bit_length())); values.sort()
            self.bindings = dict(prepared_scope=prepared['binding']['scope'],
                model_sha256=reader.sha(_normal_model(model, reader)), library_sha256=reader.sha(library))
            reader.tick(0)
        except (Budget, MemoryError, RecursionError) as error:
            self.failure = ('UNKNOWN', str(error) or type(error).__name__)
        except (Reject, ValueError, TypeError, KeyError, IndexError, AttributeError, OverflowError) as error:
            self.failure = ('REJECTED', str(error))
        if reader is not None:
            self.total_work = reader.work
            self.setup_seconds = time.perf_counter() - reader.started

    def _payload(self, cid, reader):
        reader.tick()
        slot, kind, definition, refs, fid, demand = self.rows[cid]
        if kind == 'ZERO':
            return definition['native']
        if kind == 'MP':
            return dict(rule='mp', formula=self.formulas[fid - 1])
        return dict(rule='generalize', formula=self.formulas[fid - 1], variable=definition['variable'])

    def _bind_slot(self, state, donor, slot, fid, reader):
        reader.tick(1 + len(state['slots']))
        old = state['slots'].get(donor)
        if old is not None:
            return state if old == (slot, fid) else None
        if any(value[0] == slot for value in state['slots'].values()):
            return None
        return dict(state, slots={**state['slots'], donor: (slot, fid)})

    def _expand(self, donor, cid, state, templates, receptors, reader, counts):
        reader.tick(); counts['internal_nodes_examined'] += 1
        if donor in state['lines']:
            if state['lines'][donor] == cid:
                yield state
            return
        record = self.rows[cid]
        slot, kind, definition, refs, fid, demand = record
        template = templates[donor]
        expected = 'MP' if template['rule'] == 'mp' else 'GEN' if template['rule'] == 'generalize' else 'ZERO'
        if kind != expected:
            return
        bound = self._bind_slot(state, donor, slot, fid, reader)
        if bound is None:
            return
        payload = {key: value for key, value in template.items()
                   if key not in {field for field, premise in _refs(template)}}
        for binding in _match(payload, self._payload(cid, reader), bound['bindings'], reader):
            new = dict(bound, bindings=binding, lines={**bound['lines'], donor: cid})
            yield from self._premises(_refs(template), refs, demand, 0, new,
                                      templates, receptors, reader, counts)

    def _premises(self, fields, refs, demands, pos, state, templates, receptors, reader, counts):
        reader.tick()
        if pos == len(fields):
            yield state
            return
        donor = fields[pos][1]; slot, fid = refs[pos], demands[pos]
        bound = self._bind_slot(state, donor, slot, fid, reader)
        if bound is None:
            return
        if donor in templates:
            line = templates[donor]
            kind = 'MP' if line['rule'] == 'mp' else 'GEN' if line['rule'] == 'generalize' else 'ZERO'
            options = [bound['lines'][donor]] if donor in bound['lines'] else self.children.get((slot, kind, fid), ())
            for cid in options:
                reader.tick(); counts['candidate_rows_examined'] += 1
                for new in self._expand(donor, cid, bound, templates, receptors, reader, counts):
                    yield from self._premises(fields, refs, demands, pos + 1, new,
                                              templates, receptors, reader, counts)
        else:
            need(donor in receptors, 'DECLARED_EXTERNAL_RECEPTOR')
            counts['receptor_demands_examined'] += 1
            formula = self.formulas[fid - 1]
            for binding in _match(receptors[donor], formula, bound['bindings'], reader):
                new = dict(bound, bindings=binding)
                yield from self._premises(fields, refs, demands, pos + 1, new,
                                          templates, receptors, reader, counts)

    def propose(self, anchor_cid, charge=None):
        """Return at most 32 deterministic local recommendations; never prune."""
        limits = dict(DEFAULT_LIMITS if self.limits is None else self.limits)
        for key, ceiling in QUERY_CEILINGS.items():
            limits[key] = min(limits[key], ceiling)
        reader = None
        counts = dict(fragments_examined=0, candidate_rows_examined=0,
            internal_nodes_examined=0, receptor_demands_examined=0, instances=0,
            proposal_cap_reached=False)
        try:
            need(charge is None or callable(charge), 'CALLABLE_CHARGE')
            reader = Reader(limits, charge); reader.tick()
            if self.failure:
                status, reason = self.failure
                reader.tick(0)
                self.total_work += reader.work; self.query_count += 1
                return dict(schema='Open-fragment-proposals-v1', status=status, reason=reason,
                    instances=[], costs=dict(work=reader.work, seconds=time.perf_counter() - reader.started,
                        cumulative_work=self.total_work, query_count=self.query_count,
                        setup_seconds=self.setup_seconds, **counts), limits=limits, scope=SCOPE)
            need(type(anchor_cid) is str and anchor_cid in self.rows, 'CURRENT_ANCHOR_CID')
            bindings = dict(self.bindings, anchor_cid=anchor_cid)
            instances = {}; cap = limits['max_instances']
            if cap == 0:
                counts['proposal_cap_reached'] = True
            else:
                for fragment in self.fragments:
                    reader.tick(); counts['fragments_examined'] += 1
                    templates, receptors = dict(fragment['lines']), dict(fragment['receptors'])
                    state = dict(slots={}, lines={}, bindings=dict(terms={}, contexts={}))
                    for mapped in self._expand(fragment['root'], anchor_cid, state,
                                               templates, receptors, reader, counts):
                        reader.tick()
                        if set(mapped['lines']) != set(fragment['members']):
                            continue
                        if any(set(mapped['bindings'][key]) != set(fragment['parameters'][key])
                               for key in ('terms', 'contexts')):
                            continue
                        expected = set(fragment['members']) | set(receptors)
                        if set(mapped['slots']) != expected:
                            continue
                        value = dict(fragment_id=fragment['id'],
                            bindings=reader.clone(mapped['bindings']),
                            slot_map=[[i, mapped['slots'][i][0]] for i in sorted(mapped['slots'])],
                            line_cids=[[i, mapped['lines'][i]] for i in fragment['members']],
                            receptors=[[i, mapped['slots'][i][0], reader.clone(
                                self.formulas[mapped['slots'][i][1] - 1])] for i in sorted(receptors)],
                            anchor_cid=anchor_cid)
                        identifier = reader.sha(value)
                        instances[identifier] = dict(id=identifier, **value)
                        counts['instances'] = len(instances)
                        if len(instances) >= cap:
                            counts['proposal_cap_reached'] = True
                            break
                    if counts['proposal_cap_reached']:
                        break
            reader.tick(0)
            result = _finish('Open-fragment-proposals-v1', 'CANDIDATE_FRAGMENTS', reader, limits,
                dict(counts, cumulative_work=self.total_work + reader.work, query_count=self.query_count + 1,
                     setup_seconds=self.setup_seconds), bindings=bindings,
                instances=list(instances.values()))
            reader.tick(0)
            self.query_count += 1; self.total_work += reader.work
            return result
        except _Hook as error:
            if reader is not None:
                self.total_work += reader.work
            raise error.error
        except (Budget, MemoryError, RecursionError) as error:
            status, reason = 'UNKNOWN', str(error) or type(error).__name__
        except (Reject, ValueError, TypeError, KeyError, IndexError, AttributeError, OverflowError) as error:
            status, reason = 'REJECTED', str(error)
        if reader is not None:
            self.total_work += reader.work
        self.query_count += 1
        return dict(schema='Open-fragment-proposals-v1', status=status, reason=reason,
            instances=[], costs=dict(work=0 if reader is None else reader.work,
                seconds=0.0 if reader is None else time.perf_counter() - reader.started,
                cumulative_work=self.total_work, query_count=self.query_count,
                setup_seconds=self.setup_seconds, **counts), limits=limits, scope=SCOPE)


def propose(prepared, model, library, anchor_cid, limits=None):
    """Convenience wrapper; callback callers should reuse one LocalProposer."""
    return LocalProposer(prepared, model, library, limits).propose(anchor_cid)
