"""Prospective warm receptor-family study; no scientific work at import time.

One declared published donor is training data. Families are hypotheses until
their actual primitive expansions are admitted. Policies change order only.
Every positive requires a fresh exact M/N projection and whole native B check.
"""
import copy
import hashlib
from pathlib import Path
import time


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def authenticated(ctx, ref):
    return ctx.mods['D'].read_ref(ctx, ref)


class CaseContext:
    """Reuse unchanged preparation/rank Sources with literal path namespaces."""
    def __init__(self, ctx, spec):
        self.parent, self.spec = ctx, spec
        self.root, self.mods, self.limits = ctx.root, ctx.mods, ctx.limits
        self.sha, self.wire = ctx.sha, ctx.wire

    def mapped(self, name):
        if name == 'input/arithmetic-declaration-v1.json':
            return self.spec['path']
        if name.startswith(('data/prepare/', 'data/rank/')):
            return 'data/cases/' + self.spec['id'] + '/' + name[5:]
        return name

    def read(self, name):
        return self.parent.read(self.mapped(name))

    def save(self, name, value):
        return self.parent.save(self.mapped(name), value)


def qualify(ctx):
    old = ctx.mods['K'].run(ctx)
    original = ctx.save('data/qualify/existing-qualification.json.gz', old)
    need(old['status'] == 'QUALIFIED', 'FRESH_EXISTING_QUALIFICATION')
    callbacks = ctx.mods['G'].run(ctx)
    callback_ref = ctx.save('data/qualify/callback-qualification.json.gz', callbacks)
    need(callbacks['status'] == 'QUALIFIED', 'FRESH_CALLBACK_QUALIFICATION')
    return dict(status='QUALIFIED', existing=original, callbacks=callback_ref,
                scope='Original full point/rank qualification plus new complete branch-order profile; no theorem transfer yet.')


def donor(ctx):
    manifest = ctx.read('input/donor-manifest-v1.json')
    need(manifest['schema'] == 'Receptor-donor-evidence-v1', 'DECLARED_DONOR_MANIFEST')
    seen = set()
    for entry in manifest['files']:
        name = entry['path']
        need(name not in seen and not Path(name).is_absolute() and '..' not in Path(name).parts,
             'DONOR_UNIQUE_CONTAINED_PATH')
        seen.add(name)
        path = ctx.root/'input/donor'/name
        raw = path.read_bytes()
        need(len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'],
             'DONOR_PHYSICAL_BINDING:' + name)
    def read(name):
        need(name in seen, 'DECLARED_DONOR_ONLY')
        return ctx.read('input/donor/' + name)
    protocol = read('protocol/frozen-protocol-v1.json')
    for entry in protocol['files']:
        need(entry['path'] in seen, 'COMPLETE_DONOR_FROZEN_CLOSURE')
        actual = next(x for x in manifest['files'] if x['path'] == entry['path'])
        need(all(actual[k] == entry[k] for k in ('bytes', 'sha256')), 'DONOR_PROTOCOL_PIN')
    started, invocation, observer = [read('run/evaluate/' + n + '.json')
                                    for n in ('started', 'invocation', 'observer')]
    need(started['pid'] == invocation['pid'] == observer['pid'] and type(started['pid']) is int,
         'DONOR_NATIVE_PID_JOIN')
    need(invocation['status'] == 'COMPLETE' and invocation['error_type'] is None
         and invocation['postcheck_error'] is None and invocation['result']['complete_json'] is True,
         'DONOR_COMPLETE_NATIVE_INVOCATION')
    need(observer['status'] == 'TERMINAL' and type(observer['native_exit_code']) is int
         and observer['native_exit_code'] == 0 and all(observer[k] is None
            for k in ('guard_reason', 'observer_error', 'reap_error', 'postcheck_error')),
         'DONOR_OWNED_TERMINAL_EXIT')
    for item in (observer['log'], invocation['result'], started['protocol']):
        actual = next(x for x in manifest['files'] if x['path'] == item['path'])
        need(all(actual[k] == item[k] for k in ('bytes', 'sha256')), 'DONOR_PROCESS_PHYSICAL_JOIN')
    declaration = read('input/arithmetic-declaration-v1.json')
    proof = read(manifest['proof'])
    model = read('data/engine/evaluate-rank_marks/model.json.gz')
    raw = read('data/engine/evaluate-rank_marks/raw.json.gz')
    need(raw['status'] == 'SAT', 'AUTOMATIC_DONOR_POSITIVE')
    projections = [read('data/evaluate/rank_marks-native/' + name + '.json.gz')
                   for name in ('adapter-decoded', 'independent-decoded')]
    for projected in projections:
        need(ctx.wire(projected['proof']) == ctx.wire(proof)
             and ctx.wire(projected['statement']) == ctx.wire(declaration['problem'])
             and sorted(projected['selected']) == sorted(raw['selected']), 'EXACT_DONOR_PROOF_POINT_JOIN')
    refs, costs = {}, {}
    start = time.perf_counter()
    semantic = ctx.mods['C'].verify_explicit_events(model, raw, **ctx.limits['semantic'])
    costs['donor_fresh_semantic_seconds'] = time.perf_counter()-start
    refs['semantic'] = ctx.save('data/learn/donor-fresh-semantic.json.gz', semantic)
    need(semantic['status'] == 'VERIFIED', 'FRESH_DONOR_SEMANTIC_GATE')
    start = time.perf_counter()
    native = ctx.mods['B'].check(declaration['problem']['theory'], proof,
                                declaration['problem']['goal'], ctx.limits['native'])
    costs['donor_fresh_native_seconds'] = time.perf_counter()-start
    refs['native'] = ctx.save('data/learn/donor-fresh-native.json.gz', native)
    need(native['status'] == 'VERIFIED' and native['checked_lines'] == len(proof),
         'FRESH_DONOR_WHOLE_PROOF_GATE')
    return declaration['problem'], proof, refs, costs


def learn(ctx):
    statement, proof, refs, costs = donor(ctx)
    start = time.perf_counter()
    library = ctx.mods['L'].learn(statement, proof, limits=ctx.limits['family'])
    costs['learning_seconds'] = time.perf_counter()-start
    refs['library'] = ctx.save('data/learn/library.json.gz', library)
    answer = dict(status='LEARNING_RECORDED', family_status=library['status'], refs=refs, costs=costs,
                  learned_proof_count=1, RL=False, bounded_absence=False,
                  scope='Warm term/context abstraction and rooted proof-cluster extraction from one automatically searched donor. No universal instance soundness and no new proof accepted at this stage.')
    if library['status'] != 'CANDIDATE_LIBRARY':
        return answer
    start = time.perf_counter()
    receipt = ctx.mods['X'].verify_library(statement, proof, library, limits=ctx.limits['family'])
    costs['library_check_seconds'] = time.perf_counter()-start
    refs['library_receipt'] = ctx.save('data/learn/library-receipt.json.gz', receipt)
    answer['provenance_status'] = receipt['status']
    if receipt['status'] == 'VERIFIED_PROVENANCE':
        need(receipt['bindings'] == dict(statement_sha256=ctx.sha(statement),
             proof_sha256=ctx.sha(proof), library_sha256=ctx.sha(library)), 'EXACT_LIBRARY_CHECK_BINDINGS')
        checks = ctx.mods['Y'].run_library(ctx, statement, proof, library)
        refs['qualification'] = ctx.save('data/learn/library-qualification.json.gz', checks)
        need(checks['status'] == 'QUALIFIED', 'FRESH_LIBRARY_MUTATION_QUALIFICATION')
        answer['qualification_status'] = checks['status']
    return answer


def prepare(ctx, spec):
    d, sub = ctx.mods['D'], CaseContext(ctx, spec)
    preparation = d.run('prepare', sub)
    prep_ref = sub.save('data/prepare/result.json', preparation)
    answer = dict(status='CASE_RECORDED', id=spec['id'], preparation=prep_ref,
                  preparation_status=preparation['status'], family_status='NOT_ATTEMPTED',
                  rank_status='NOT_ATTEMPTED', refs={}, costs={}, bounded_absence=False)
    if preparation['status'] != 'PREPARED':
        return answer
    prepared, base = d.load_prepared(sub)
    rank = ctx.mods['H'].rank(sub)
    answer['refs']['rank'] = sub.save('data/rank/result.json', rank)
    answer['rank_status'] = rank['status']
    if rank['status'] != 'RANK_ADMITTED':
        return answer
    model = authenticated(ctx, rank['refs']['marked_model'])
    learned = ctx.admitted('learn')
    if learned.get('provenance_status') != 'VERIFIED_PROVENANCE' or learned.get('qualification_status') != 'QUALIFIED':
        answer['family_status'] = 'UNADMITTED_LIBRARY'
        return answer
    library = authenticated(ctx, learned['refs']['library'])
    prefix = 'data/cases/' + spec['id'] + '/families'
    start = time.perf_counter()
    proposed = ctx.mods['L'].instantiate(library, prepared['statement'], prepared, model,
                                       limits=ctx.limits['family'])
    answer['costs']['instantiation_seconds'] = time.perf_counter()-start
    answer['refs']['proposed'] = ctx.save(prefix + '/proposed.json.gz', proposed)
    answer['family_status'] = proposed['status']
    if proposed['status'] != 'CANDIDATE_INSTANCES':
        return answer
    need(proposed['bindings'] == dict(library_sha256=ctx.sha(library),
         statement_sha256=ctx.sha(prepared['statement']), prepared_scope=prepared['binding']['scope'],
         model_sha256=ctx.sha(model)), 'EXACT_CURRENT_PROPOSAL_BINDINGS')
    start = time.perf_counter()
    checker = ctx.mods['X'].AdmissionChecker(prepared['statement'], prepared, model, library,
                                            limits=ctx.limits['family'])
    identity = dict(model_sha256=ctx.sha(model), statement_sha256=ctx.sha(prepared['statement']),
                    library_sha256=ctx.sha(library))
    admitted, receipts = [], []
    for index, instance in enumerate(proposed['instances']):
        instance_sha256 = ctx.sha(instance)
        receipt = checker.admit(instance)
        receipts.append(dict(index=index, instance_sha256=instance_sha256, receipt=receipt))
        if receipt['status'] == 'VERIFIED_INSTANCE':
            need(receipt['bindings'] == dict(identity, instance_sha256=instance_sha256),
                 'EXACT_INSTANCE_CHECK_BINDINGS')
            admitted.append(instance)
    answer['costs']['instance_check_seconds'] = time.perf_counter()-start
    answer['refs']['instance_receipts'] = ctx.save(prefix + '/instance-receipts.json.gz', receipts)
    answer['refs']['admitted'] = ctx.save(prefix + '/admitted.json.gz', admitted)
    answer.update(proposed_count=len(proposed['instances']), admitted_count=len(admitted),
                  rejected_or_unknown_count=len(receipts)-len(admitted),
                  family_status='INSTANCE_ADMISSIONS_RECORDED')
    if admitted:
        checks = ctx.mods['Y'].run_instances(ctx, prepared['statement'], prepared, model, library, admitted)
        answer['refs']['qualification'] = ctx.save(prefix + '/instance-qualification.json.gz', checks)
        need(checks['status'] == 'QUALIFIED', 'FRESH_INSTANCE_STATE_QUALIFICATION')
        answer['qualification_status'] = checks['status']
    return answer


class FamilyPolicy:
    """Validated continuation preferences, never a replacement for base domains."""
    def __init__(self, ctx, model, admitted, receptor_only=False):
        self.ctx, self.model = ctx, model
        ordered = sorted([i for i in admitted if not receptor_only or i['receptors']],
                         key=lambda i: (-len(i['line_cids']), ctx.wire(i)))
        self.instances = [dict(instance=i, sha256=ctx.sha(i),
                              cids=tuple(cid for _, cid in i['line_cids'])) for i in ordered]
        self.cid_costs = {row['id']: 1+len(row['id']) for row in model['inventory']['placements']}
        self.checker = ctx.mods['X'].StateChecker(model, admitted)
        self.cached = None
        self.log, self.counts = [], dict(callbacks=0, instance_checks=0, preferences=0,
            cached_compatible=0, no_preference=0, check_seconds=0.0,
            state_index_status=self.checker.status, state_index_reason=self.checker.reason)

    def __call__(self, request, charge):
        charge(1 + len(self.instances))
        self.counts['callbacks'] += 1
        if len(self.log) >= 100000:
            charge(self.ctx.limits['engine']['max_work'] + 1)
        for name in ('legal', 'selected', 'excluded'):
            charge(1+len(request[name]))
            for cid in request[name]:
                charge(self.cid_costs[cid])
        charge(1+len(request['point'])+len(request['model_sha256']))
        checked, chosen, preferred = [], None, []
        candidates = ([self.cached] if self.cached is not None else []) + self.instances
        seen = set()
        for entry in candidates:
            charge(65)
            key = entry['sha256']
            if key in seen:
                continue
            seen.add(key)
            start = time.perf_counter()
            receipt = self.checker.check(entry['instance'], request, charge)
            self.counts['check_seconds'] += time.perf_counter()-start
            self.counts['instance_checks'] += 1
            charge(10+len(receipt['status'])+len(receipt.get('reason', '')))
            checked.append(dict(instance_sha256=key, status=receipt['status'],
                                reason=receipt.get('reason')))
            if receipt['status'] != 'COMPATIBLE':
                continue
            legal = set(request['legal'])
            charge(len(entry['cids'])*(2+len(entry['cids']).bit_length()))
            preferred = sorted(cid for cid in entry['cids'] if cid in legal)
            if not preferred:
                continue
            if entry is self.cached:
                self.counts['cached_compatible'] += 1
            chosen = entry
            break
        self.cached = chosen
        self.counts['preferences'] += len(preferred)
        self.counts['no_preference'] += not preferred
        charge(20+len(checked)+len(preferred))
        self.log.append(dict(request=copy.deepcopy(request), checked=checked,
            chosen_sha256=chosen['sha256'] if chosen else None, preferred=preferred))
        return preferred


def finish_positive(ctx, prepared, selected, prefix, row):
    try:
        decoded = ctx.mods['D'].decode(ctx, prepared, selected, prefix)
    except ctx.mods['D'].StopPhase as failure:
        row.update(admitted_status=failure.status, native_reason=failure.reason,
                   native_refs=failure.refs)
    else:
        row.update(admitted_status='VERIFIED_NATIVE_POSITIVE',
            native_lines=len(decoded['proof']), native_refs=decoded['refs'])
        row['costs'].update(decoded['costs'])


def evaluate(ctx, spec):
    prep = ctx.admitted('prepare-' + spec['id'])
    answer = dict(status='CASE_RECORDED', id=spec['id'], rows=[], bounded_absence=False,
                  scope='Same complete rank-marked model and engine limits; guidance changes candidate order only. Direct expansion is a warm same-library control, not GCTS search. No RL or performance superiority assumed.')
    if prep['preparation_status'] != 'PREPARED' or prep['rank_status'] != 'RANK_ADMITTED':
        answer['reason'] = 'UNADMITTED_PREPARATION_OR_RANK'
        return answer
    prepared, _ = ctx.mods['D'].load_prepared(CaseContext(ctx, spec))
    rank = authenticated(ctx, prep['refs']['rank'])
    model = authenticated(ctx, rank['refs']['marked_model'])
    admitted = authenticated(ctx, prep['refs']['admitted']) if 'admitted' in prep['refs'] else []
    prefix = 'data/cases/' + spec['id'] + '/evaluation'
    for name in ('RANK_ONLY', 'RECEPTOR_GUIDED', 'FAMILY_GUIDED'):
        setup_started = time.perf_counter()
        policy = None if name == 'RANK_ONLY' else FamilyPolicy(ctx, model, admitted,
                                                              receptor_only=name == 'RECEPTOR_GUIDED')
        setup_seconds = time.perf_counter()-setup_started
        start = time.perf_counter()
        run = ctx.engine('transfer-' + spec['id'] + '-' + name.lower(), model, order=policy)
        elapsed = time.perf_counter()-start
        row = dict(method=name, model_sha256=ctx.sha(model), raw_status=run['raw']['status'],
            semantic_status=run['semantic']['status'], stats=run['raw']['stats'],
            admitted_status='UNKNOWN', refs=run['refs'], costs=dict(policy_setup_seconds=setup_seconds,
                engine_and_semantic_seconds=elapsed))
        if policy is not None:
            row['policy_counts'] = policy.counts
            row['refs']['policy_log'] = ctx.save(prefix + '/' + name.lower() + '-policy.json.gz', policy.log)
        if run['raw']['status'] == 'SAT' and run['semantic']['status'] == 'VERIFIED':
            finish_positive(ctx, prepared, run['raw']['selected'], prefix + '/' + name.lower() + '-native', row)
        answer['rows'].append(row)
    start = time.perf_counter()
    ordinary = ctx.mods['S'].search(prepared, authenticated(ctx, rank['refs']['analysis']),
                                    limits=ctx.limits['S'])
    ordinary_row = dict(method='CONVENTIONAL_AND_OR', search_status=ordinary['status'],
        admitted_status='UNKNOWN', costs=dict(search_seconds=time.perf_counter()-start),
        refs=dict(search=ctx.save(prefix + '/conventional-search.json.gz', ordinary)),
        scope='Specialized goal-directed acyclic shared-formula control over the same full primitive catalogue and rank information. No learned library input and no reference-GCTS scheduler claim; failure is UNKNOWN.')
    if ordinary['status'] == 'FOUND_CANDIDATE':
        finish_positive(ctx, prepared, ordinary['selected'], prefix + '/conventional-native', ordinary_row)
    answer['rows'].append(ordinary_row)
    start = time.perf_counter()
    complete = [i for i in admitted if len(i['line_cids']) == prepared['binding']['slots'] and not i['receptors']]
    complete.sort(key=ctx.wire)
    direct = dict(method='DIRECT_SAME_LIBRARY', admitted_status='UNKNOWN',
                  costs=dict(selection_seconds=time.perf_counter()-start),
                  reason='NO_ADMITTED_WHOLE_CLUSTER' if not complete else None)
    if complete:
        chosen = complete[0]
        direct['instance_sha256'] = ctx.sha(chosen)
        direct['selected'] = sorted(cid for _, cid in chosen['line_cids'])
        finish_positive(ctx, prepared, direct['selected'], prefix + '/direct-native', direct)
    answer['rows'].append(direct)
    return answer


def run(phase, ctx):
    started = time.perf_counter()
    if phase in ('qualify', 'learn'):
        result = dict(qualify=qualify, learn=learn)[phase](ctx)
    else:
        kind, identifier = phase.split('-', 1)
        cases = ctx.read('input/transfer-cases-v1.json')['cases']
        spec = next(x for x in cases if x['id'] == identifier)
        result = dict(prepare=prepare, evaluate=evaluate)[kind](ctx, spec)
    result.update(schema='Receptor-' + phase + '-result-v1', phase=phase,
                  module_seconds=time.perf_counter()-started)
    return result
