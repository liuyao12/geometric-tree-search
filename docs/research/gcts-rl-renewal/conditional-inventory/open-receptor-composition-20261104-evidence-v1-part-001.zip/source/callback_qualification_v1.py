"""Fresh bounded callback qualification; inert until Root's reviewed freeze.

Only stdlib imports. E/C4/T and paired receiver graphs are called through the
owned Context, which persists actual raw results before assurance. No target
proof, donor or family library is used by this qualification.
"""
import copy
import hashlib
import time

VERSION = 'Complete-permutation-callback-qualification-v1'
PROFILE = 'COMPLETE_PERMUTATION_V1'


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def fixtures():
    def model(name, capacity, roots, rows):
        return dict(schema='Z-growing-point-model-v3', version=name,
                    capacity=capacity, roots=roots, seed=dict(t=[], m=[]),
                    inventory=dict(kind='EXPLICIT', placements=rows),
                    pair_nogoods=[], unary_nogoods=[])
    simple = model('callback-simple-v1', 1, ['p'], [
        dict(id='a', t=[['p', 1]], m=[]),
        dict(id='b', t=[['p', 1]], m=[])])
    rollback = model('callback-rollback-v1', 2, ['p'], [
        dict(id='a-bad', t=[['p', 2], ['r', 1]], m=[]),
        dict(id='b-good', t=[['p', 2]], m=[]),
        dict(id='c-bad', t=[['p', 2], ['s', 1]], m=[])])
    forced = model('callback-forced-before-branch-v1', 1, ['p', 'z'], [
        dict(id='a', t=[['p', 1]], m=[]),
        dict(id='b', t=[['p', 1]], m=[]),
        dict(id='z-only', t=[['z', 1]], m=[])])
    return simple, rollback, forced


def callback(mode, requests, maximum_work):
    def order(request, charge):
        # The requests are actual engine inputs, not precomputed witnesses.
        charge(1 + len(request['legal']) + len(request['selected']) + len(request['excluded']))
        for key in ('legal', 'selected', 'excluded'):
            for cid in request[key]:
                charge(1 + len(cid))
        requests.append(copy.deepcopy(request))
        if mode == 'budget':
            charge(maximum_work + 1)
            raise AssertionError('HOOK_BUDGET_MUST_PROPAGATE_ENGINE_STOP')
        if mode == 'reverse':
            return list(reversed(request['legal']))
        need(mode == 'prefix', 'DECLARED_CALLBACK_MODE')
        return request['legal'][-1:]
    return order


def complete(ctx, identifier, model, mode):
    requests = []
    order = None if mode is None else callback(mode, requests, ctx.limits['E']['max_work'])
    start = time.perf_counter()
    packet = ctx.engine('callback-qualify/' + identifier, model, actual=True, order=order)
    seconds = time.perf_counter() - start
    refs = dict(packet['refs'])
    refs['requests'] = ctx.save('data/callback-qualify/' + identifier + '-requests.json', requests)
    raw, c, t, paired = packet['raw'], packet['semantic'], packet['trace'], packet['graphs']
    need(raw['status'] == 'SAT' and c['status'] == t['status'] == paired['status'] == 'VERIFIED',
         'COMPLETE_CALLBACK_ENGINE_AND_INDEPENDENT_MAP_GATES:' + identifier)
    n = len(packet['observations'])
    need(n == len(raw['events']) == raw['event_extent']['total']
         and t['counts']['observations_checked'] == paired['events_checked'] == n,
         'ALL_ACTUAL_CALLBACK_GRAPHS:' + identifier)
    expected_calls = 0 if mode is None else raw['stats']['branches']
    need(raw['stats']['ordering_calls'] == len(requests) == expected_calls,
         'ACTUAL_COMPLETE_CALLBACK_CENSUS:' + identifier)
    need(c['order_profile'] == ('LEXICAL_V1' if mode is None else PROFILE), 'EXPLICIT_CHECKER_PROFILE')
    return packet, dict(id=identifier, status='QUALIFIED', mode=mode or 'LEXICAL_DEFAULT',
        engine_calls=1, actual_snapshots=n, branches=raw['stats']['branches'],
        ordering_calls=raw['stats']['ordering_calls'], checker_profile=c['order_profile'],
        semantic_status=c['status'], full_graph_status=t['status'], paired_graph_status=paired['status'],
        refs=refs, pipeline_seconds=seconds)


def rehash_events(ctx, result):
    h = hashlib.sha256()
    for event in result['events']:
        h.update(ctx.wire(event))
    result['event_extent']['sha256'] = h.hexdigest()


def check_mutant(ctx, identifier, model, raw, profile=PROFILE):
    prefix = 'data/callback-qualify/mutants/' + identifier
    inp = ctx.save(prefix + '-input.json.gz',
                   dict(model=model, result=raw, order_profile=profile,
                        role='DELIBERATELY_MUTATED_TEST_DATA_NOT_EXECUTED_SEARCH'))
    started = time.perf_counter()
    result = ctx.mods['C'].verify_explicit_events(model, raw, order_profile=profile, **ctx.limits['C'])
    seconds = time.perf_counter() - started
    ref = ctx.save(prefix + '-receipt.json', result)
    need(result['status'] == 'REJECTED' and result['bounded_absence'] is False,
         'CALLBACK_MUTANT_REJECTED:' + identifier)
    return dict(id=identifier, status=result['status'], reason=result['reason'],
                input=inp, receipt=ref, seconds=seconds)


def run(ctx):
    """Use after Root's first existing K.run(ctx) and frozen Source admission.

    Context requires mods E/C4/T, limits E/C, save/wire and engine(...,
    actual=True,order=...). engine also runs independent paired Reader maps.
    All paths are new callback-qualify paths; existing K artifacts are untouched.
    """
    started = time.perf_counter()
    simple, rollback, forced = fixtures()
    records, packets = [], {}
    for identifier, model, mode in [
            ('lexical-default', simple, None), ('reverse', simple, 'reverse'),
            ('reverse-rollback', rollback, 'reverse'), ('prefix-rollback', rollback, 'prefix'),
            ('forced-before-prefix', forced, 'prefix')]:
        packet, record = complete(ctx, identifier, model, mode)
        packets[identifier] = packet;records.append(record)
    for identifier in ('reverse-rollback', 'prefix-rollback'):
        raw = packets[identifier]['raw']
        need(raw['stats']['exclusions'] >= 1 and any(e['kind'] == 'EXCLUDE' for e in raw['events']),
             'ACTUAL_FAILED_CHILD_AND_ROLLBACK:' + identifier)
    prefix = packets['prefix-rollback']['raw']
    first = next(e for e in prefix['events'] if e['kind'] == 'BRANCH')
    need(first['data']['order'] == [first['data']['legal'][-1]] + first['data']['legal'][:-1],
         'PREFIX_PREFERENCE_RETAINS_COMPLETE_LEXICAL_FALLBACK')
    forced_events = packets['forced-before-prefix']['raw']['events']
    first_decision = next(e for e in forced_events if e['kind'] != 'READY')
    need(first_decision['kind'] == 'FORCED' and first_decision['candidate'] == 'z-only',
         'GLOBAL_FORCED_PREEMPTS_ORDER_CALLBACK')
    requests = ctx.read(records[-1]['refs']['requests']['path'])
    need(bool(requests) and 'z-only' in requests[0]['selected'], 'CALLBACK_SEES_ACTUAL_FORCED_PARENT')
    mutants = []
    for kind in ('missing-fallback', 'duplicate-order', 'foreign-order', 'missing-legal',
                 'wrong-first-placement', 'wrong-exclusion', 'zero-callback-stat',
                 'extra-callback-stat', 'boolean-callback-stat'):
        bad = copy.deepcopy(prefix)
        event = next(e for e in bad['events'] if e['kind'] == 'BRANCH')
        if kind == 'missing-fallback':
            event['data']['order'] = event['data']['order'][:-1]
        elif kind == 'duplicate-order':
            event['data']['order'][-1] = event['data']['order'][0]
        elif kind == 'foreign-order':
            event['data']['order'][-1] = 'FOREIGN_CALLBACK_CID'
        elif kind == 'missing-legal':
            event['data']['legal'] = event['data']['legal'][:-1]
        elif kind == 'wrong-first-placement':
            placed = next(e for e in bad['events'] if e['kind'] == 'PLACED')
            placed['candidate'] = event['data']['order'][1]
        elif kind == 'wrong-exclusion':
            excluded = next(e for e in bad['events'] if e['kind'] == 'EXCLUDE')
            excluded['candidate'] = event['data']['order'][1]
        elif kind == 'zero-callback-stat':
            bad['stats']['ordering_calls'] = 0
        elif kind == 'extra-callback-stat':
            bad['stats']['ordering_calls'] = bad['stats']['branches'] + 1
        else:
            bad['stats']['ordering_calls'] = True
        rehash_events(ctx, bad)
        mutants.append(check_mutant(ctx, kind, rollback, bad))
    mutants.append(check_mutant(ctx, 'default-rejects-callback', rollback, prefix, 'LEXICAL_V1'))
    hook_requests = []
    stopped = ctx.engine('callback-qualify/hook-budget', rollback, actual=True,
        order=callback('budget', hook_requests, ctx.limits['E']['max_work']))
    hook_ref = ctx.save('data/callback-qualify/hook-budget-requests.json', hook_requests)
    raw, c = stopped['raw'], stopped['semantic']
    need(raw['status'] == c['status'] == 'UNKNOWN' and c['bounded_absence'] is False
         and stopped['trace']['status'] == stopped['graphs']['status'] == 'UNKNOWN',
         'HOOK_BUDGET_UNKNOWN_NEVER_ABSENCE')
    need(raw['stats']['ordering_calls'] == len(hook_requests) == 1 and raw['stats']['branches'] == 0,
         'ACTUAL_INTERRUPTED_CALLBACK_WITHOUT_BRANCH_EVENT')
    need(c['ordering_metadata']['unjoined_calls'] == 1, 'CHECKED_SINGLE_INTERRUPTED_CALLBACK')
    bad = copy.deepcopy(raw);bad['stats']['ordering_calls'] += 1
    mutants.append(check_mutant(ctx, 'two-unjoined-callbacks', rollback, bad))
    return dict(schema='Callback-order-qualification-v1', version=VERSION,
        status='QUALIFIED', cases=records, mutants=mutants,
        hook_unknown=dict(refs=stopped['refs'], requests=hook_ref, status=raw['status'],
                          semantic_status=c['status'], ordering_metadata=c['ordering_metadata']),
        counts=dict(complete_engine_calls=len(records), unknown_engine_calls=1,
                    actual_complete_graphs=sum(x['actual_snapshots'] for x in records),
                    rejected_mutants=len(mutants)),seconds=time.perf_counter()-started,
        scope='Fresh tiny E/C4/T/independent paired-map callback checks. No target/donor proof, family soundness, learned pruning, RL or performance conclusion.')
