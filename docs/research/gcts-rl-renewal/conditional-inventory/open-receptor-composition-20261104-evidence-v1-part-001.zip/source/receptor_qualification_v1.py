"""Inert qualification of actual learned outputs; no supplied proof/search.

Root freezes and executes later. All inputs/answers are saved before assertions.
State fixtures are synthetic data requests over actual admitted members, not
claims that the GCTS engine reached those states. E/C callback tests are separate.
"""
import copy
import time


def need(ok,why):
    if not ok:raise ValueError(why)


def limits(ctx):
    return dict(ctx.limits['family'])


def family_id(ctx,f):
    f['id']=ctx.sha(dict(schema='Receptor-family-v1',**{k:v for k,v in f.items() if k!='id'}))


def instance_id(ctx,i):
    i['id']=ctx.sha(dict(schema='Receptor-instance-v1',**{k:v for k,v in i.items() if k!='id'}))


def save_call(ctx,prefix,inputs,call,expected):
    inp=ctx.save(prefix+'-input.json.gz',inputs);start=time.perf_counter();answer=call()
    elapsed=time.perf_counter()-start;out=ctx.save(prefix+'-receipt.json.gz',answer)
    need(answer['status']==expected,'RECEPTOR_QUALIFICATION:'+prefix)
    return dict(id=prefix.rsplit('/',1)[-1],status=answer['status'],reason=answer.get('reason'),
        input=inp,receipt=out,seconds=elapsed)


def run_library(ctx,statement,proof,library):
    X=ctx.mods['X'];budget=limits(ctx);prefix='data/learn/receptor-qualification/library';rows=[]
    rows.append(save_call(ctx,prefix+'/actual-provenance',dict(statement=statement,proof=proof,library=library,limits=budget),
        lambda:X.verify_library(statement,proof,library,budget),'VERIFIED_PROVENANCE'))
    need(library['families'] and any(len(c['members'])>1 for c in library['clusters']),'ACTUAL_MUTATION_ANCHORS_REQUIRED')
    for kind in ('donor-binding','prototype-binding','cluster-membership','goal-parameter'):
        changed=copy.deepcopy(library)
        if kind=='donor-binding':
            old=changed['donor']['proof_sha256'];changed['donor']['proof_sha256']=('0' if old[0]!='0' else '1')+old[1:]
        elif kind=='cluster-membership':
            c=next(c for c in changed['clusters'] if len(c['members'])>1)
            c['members']=[i for i in c['members'] if i!=c['members'][0]]
            c['id']=ctx.sha(dict(schema='Receptor-cluster-v1',**{k:v for k,v in c.items() if k!='id'}))
            changed['clusters'].sort(key=lambda c:c['id'])
        else:
            f=changed['families'][0];name=f['parameters']['terms'][0]
            if kind=='prototype-binding':
                f['prototype_bindings']['terms'][name]=['var','__receptor_qualification_foreign_parameter__']
            else:
                original=copy.deepcopy(f['prototype_bindings']['terms'][name])
                def remove_parameter(v):
                    if type(v) is list:
                        if v==['_term',name]:return copy.deepcopy(original)
                        return [remove_parameter(x) for x in v]
                    if type(v) is dict:return {k:remove_parameter(x) for k,x in v.items()}
                    return v
                f['statement_template']['goal']=remove_parameter(f['statement_template']['goal'])
            family_id(ctx,f);changed['families'].sort(key=lambda f:f['id'])
        rows.append(save_call(ctx,prefix+'/'+kind,dict(statement=statement,proof=proof,library=changed,limits=budget),
            lambda changed=changed:X.verify_library(statement,proof,changed,budget),'REJECTED'))
    zero=dict(budget,max_work=0)
    rows.append(save_call(ctx,prefix+'/zero-work',dict(statement=statement,proof=proof,library=library,limits=zero),
        lambda:X.verify_library(statement,proof,library,zero),'UNKNOWN'))
    return dict(status='QUALIFIED',records=rows,
        scope='Actual learned library provenance plus independently rehashed donor/prototype/cluster/goal-parameter refusals and resource refusal. No fabricated process receipt, target derivation or schematic native-validity claim.')


def run_instances(ctx,statement,prepared,model,library,admitted_instances):
    X=ctx.mods['X'];budget=limits(ctx);prefix='data/instance-qualification/'+ctx.sha(statement)[:16]
    need(admitted_instances,'ACTUAL_ADMITTED_INSTANCE_REQUIRED')
    ordinary=max(admitted_instances,key=lambda i:(len(i['line_cids']),i['id']))
    receptor=next((i for i in admitted_instances if i['receptors']),None)
    need(len(ordinary['line_cids'])>=2 and receptor is not None,'ACTUAL_OVERLAP_AND_RECEPTOR_ANCHORS_REQUIRED')
    context=X.AdmissionChecker(statement,prepared,model,library,budget)
    context_ref=ctx.save(prefix+'/admission-index.json',dict(status=context.status,reason=context.reason,
        scope='Actual independent index-construction status, not a mathematical or process receipt.'))
    need(context.status=='READY','FRESH_QUALIFICATION_ADMISSION_INDEX')
    rows=[]
    rows.append(save_call(ctx,prefix+'/actual-instance',dict(instance=ordinary),lambda:context.admit(ordinary),'VERIFIED_INSTANCE'))
    for kind in ('wrong-parameter','wrong-binder','wrong-native-payload','wrong-primitive-CID','wrong-receptor'):
        changed=copy.deepcopy(receptor if kind=='wrong-receptor' else ordinary)
        if kind=='wrong-parameter':
            name=next(iter(changed['bindings']['terms']))
            changed['bindings']['terms'][name]=['var','__receptor_qualification_foreign_parameter__']
        elif kind=='wrong-binder':
            def alter(v):
                if type(v) is list:
                    if len(v)==3 and v[0]=='all':v[1]+='__qualification_binder__';return True
                    return any(alter(x) for x in v)
                if type(v) is dict:return any(alter(x) for x in v.values())
                return False
            need(alter(changed['expansion']),'ACTUAL_BINDER_MUTATION_ANCHOR')
        elif kind=='wrong-native-payload':
            line=next((l for l in changed['expansion'] if l['rule'] not in ('mp','generalize')),None)
            need(line is not None,'ACTUAL_NATIVE_ZERO_MUTATION_ANCHOR');line['_qualification_corrupt_payload']=0
        elif kind=='wrong-primitive-CID':
            chosen={c for i,c in changed['line_cids']}
            foreign=next((r['id'] for r in model['inventory']['placements'] if r['id'] not in chosen),None)
            need(foreign is not None,'ACTUAL_ALTERNATIVE_CID_MUTATION_ANCHOR');changed['line_cids'][0][1]=foreign
        else:
            old=changed['receptors'][0][1];changed['receptors'][0][1]=['not',old]
        instance_id(ctx,changed)
        rows.append(save_call(ctx,prefix+'/'+kind,dict(instance=changed),
            lambda changed=changed:context.admit(changed),'REJECTED'))
    changed_model=copy.deepcopy(model);mark_row=next((r for r in changed_model['inventory']['placements'] if r['m']),None)
    need(mark_row is not None,'ACTUAL_MARK_LITERAL_MUTATION_ANCHOR');mark_row['m'][0][1]=1
    rows.append(save_call(ctx,prefix+'/nonliteral-model-mark',dict(model=changed_model,instance=ordinary),
        lambda:X.admit(statement,prepared,changed_model,library,ordinary,budget),'REJECTED'))
    zero=dict(budget,max_work=0)
    rows.append(save_call(ctx,prefix+'/zero-work',dict(instance=ordinary,limits=zero),
        lambda:X.admit(statement,prepared,model,library,ordinary,zero),'UNKNOWN'))
    state_inputs=[ordinary]+([receptor] if receptor['id']!=ordinary['id'] else [])
    state=X.StateChecker(model,state_inputs,budget)
    state_ref=ctx.save(prefix+'/state-index.json',dict(status=state.status,reason=state.reason,
        scope='Actual independent state-index construction status, not a GCTS state or process receipt.'))
    need(state.status=='READY','STATE_QUALIFICATION_INDEX')
    byid={r['id']:r for r in model['inventory']['placements']};members=[c for i,c in ordinary['line_cids']]
    anchor=members[-1];point=byid[anchor]['t'][0][0]
    request=dict(schema='Z-candidate-order-request-v1',model_sha256=state.model_sha256,point=point,
        generation=0,legal=[anchor],selected=[],excluded=[])
    charge_counts=dict(calls=0,units=0)
    def charge(n=1):charge_counts['calls']+=1;charge_counts['units']+=n
    def state_call(name,instance,query,expected):
        return save_call(ctx,prefix+'/state-'+name,dict(instance=instance,request=query,
            scope='SYNTHETIC_DATA_REQUEST_NOT_AN_OBSERVED_GCTS_STATE'),lambda:state.check(instance,query,charge),expected)
    states=[state_call('consistent-union',ordinary,request,'COMPATIBLE')]
    overlap=members[0];overlap_request=dict(request,selected=[overlap])
    states.append(state_call('shared-member-once',ordinary,overlap_request,'COMPATIBLE'))
    shared=ctx.read(states[-1]['receipt']['path'])
    need(shared['shared_members']==1 and shared['new_members']==len(members)-1,'SHARED_IDENTITIES_COUNT_ONCE')
    overlap_index=next(i for i,c in ordinary['line_cids'] if c==overlap)
    pad=ctx.wire([overlap_index,'PAD','pad',[]]).decode('ascii')
    need(pad in byid and pad not in members,'ACTUAL_DISTINCT_SAME_SLOT_OWNER_ANCHOR')
    states.append(state_call('distinct-owner-overcapacity',ordinary,dict(request,selected=[pad]),'REJECTED'))
    states.append(state_call('local-exclusion',ordinary,dict(request,excluded=[overlap]),'REJECTED'))
    states.append(state_call('restored-exclusion',ordinary,request,'COMPATIBLE'))
    before=ctx.read(states[0]['receipt']['path']);restored=ctx.read(states[-1]['receipt']['path'])
    need(ctx.wire(before['bindings'])==ctx.wire(restored['bindings']) and before['preferred']==restored['preferred'],'STATE_RESTORATION_EXACT_BINDING')
    wrong=dict(request,model_sha256=('0' if request['model_sha256'][0]!='0' else '1')+request['model_sha256'][1:])
    states.append(state_call('foreign-model',ordinary,wrong,'REJECTED'))
    states.append(state_call('foreign-selected',ordinary,dict(request,selected=['__not_a_current_CID__']),'REJECTED'))
    receptor_anchor=receptor['line_cids'][-1][1]
    rq=dict(request,point=byid[receptor_anchor]['t'][0][0],legal=[receptor_anchor])
    states.append(state_call('missing-owner-is-demand-only',receptor,rq,'COMPATIBLE'))
    # A zero-only nonroot seed key is not an active point. This is a separate
    # modified point-model fixture, not the original cohort's RF/N model or an
    # observed E request. Fresh concrete-row admission must precede its use.
    fixture=copy.deepcopy(model);inactive=byid[overlap]['t'][0][0]
    fixture['roots']=[p for p in fixture['roots'] if p!=inactive]
    fixture['seed']['t']=sorted([r for r in fixture['seed']['t'] if r[0]!=inactive]+[[inactive,0]])
    fixture_scope='GENERIC_MODIFIED_POINT_MODEL_ONLY_NOT_ORIGINAL_RF_N_ADMISSION_OR_OBSERVED_E_STATE'
    fixture_admission=save_call(ctx,prefix+'/zero-seed-fixture-row-admission',
        dict(model=fixture,instance=ordinary,scope=fixture_scope),
        lambda:X.admit(statement,prepared,fixture,library,ordinary,budget),'VERIFIED_INSTANCE')
    fixture_state=X.StateChecker(fixture,[ordinary],budget)
    fixture_index=ctx.save(prefix+'/zero-seed-fixture-state-index.json',dict(status=fixture_state.status,
        reason=fixture_state.reason,scope=fixture_scope))
    need(fixture_state.status=='READY','ZERO_SEED_FIXTURE_STATE_INDEX')
    fixture_receipt=ctx.read(fixture_admission['receipt']['path'])
    need(fixture_receipt['bindings']['model_sha256']==fixture_state.model_sha256
         and fixture_receipt['bindings']['instance_sha256']==ctx.sha(ordinary),'FIXTURE_ADMISSION_BINDINGS')
    forged=dict(request,model_sha256=fixture_state.model_sha256,point=inactive,legal=[overlap])
    fixture_check=save_call(ctx,prefix+'/state-inactive-nonroot-zero',
        dict(model=fixture,instance=ordinary,request=forged,scope=fixture_scope),
        lambda:fixture_state.check(ordinary,forged,charge),'REJECTED')
    actual_fixture_rejection=ctx.read(fixture_check['receipt']['path'])
    need(actual_fixture_rejection['reason']=='CURRENT_FRONTIER_POINT','EXACT_INACTIVE_NONROOT_ZERO_REFUSAL')
    class ChargeStop(Exception):pass
    sentinel=ChargeStop('DECLARED_QUALIFICATION_CHARGE_STOP');stop_calls=[]
    def stop(n=1):stop_calls.append(n);raise sentinel
    stop_input=ctx.save(prefix+'/state-charge-stop-input.json.gz',dict(instance=ordinary,request=request))
    try:state.check(ordinary,request,stop)
    except ChargeStop as actual:need(actual is sentinel and stop_calls,'CHARGE_STOP_IDENTITY_AND_CALL')
    else:raise ValueError('CHARGE_STOP_MUST_PROPAGATE')
    stop_ref=ctx.save(prefix+'/state-charge-stop-receipt.json',dict(status='PROPAGATED',calls=stop_calls,
        scope='Actual local hook exception propagation only; not an engine run, UNKNOWN search certificate or process receipt.'))
    return dict(status='QUALIFIED',instance_records=rows,state_records=states,
        admission_index=context_ref,state_index=state_ref,charge_stop=dict(input=stop_input,receipt=stop_ref),charge_counts=charge_counts,
        zero_seed_fixture=dict(admission=fixture_admission,state_index=fixture_index,check=fixture_check,scope=fixture_scope),
        scope='Actual current admitted expansions, rehashed semantic primitive/binding/receptor mutations, resource refusal and synthetic state-union/rollback fixtures. No additional E call, supplied target proof, native theorem assertion or fabricated successful provenance.')
