"""Cold rank-pruning study phases; inert until the frozen owned worker."""
import copy
import time

SITE = 'certified:rank:guard:v1'


def need(ok, why):
    if not ok:
        raise ValueError(why)


def models(base, forbidden):
    marked, control = copy.deepcopy(base), copy.deepcopy(base)
    marked['version'] += ':rank-marked-v1'
    control['version'] += ':rank-filter-v1'
    marked['seed']['m'] = sorted(marked['seed']['m'] + [[SITE, '0']])
    bad = set(forbidden)
    for row in marked['inventory']['placements']:
        if row['id'] in bad:
            row['m'] = sorted(row['m'] + [[SITE, '1']])
    control['unary_nogoods'] = list(forbidden)
    return marked, control


def applied_controls(ctx, prepared, base, packet, marked, control, prefix):
    rows = []
    for name in ('boolean-rank', 'foreign-exclusion', 'missing-guard', 'wrong-filter', 'zero-work'):
        p, m, c = copy.deepcopy(packet), copy.deepcopy(marked), copy.deepcopy(control)
        lim = dict(ctx.limits['V'])
        if name == 'boolean-rank':
            p['ranks'][0][1] = True
        elif name == 'foreign-exclusion':
            p['forbidden'] = sorted(p['forbidden'] + ['not-an-admitted-candidate'])
        elif name == 'missing-guard':
            m['seed']['m'] = [x for x in m['seed']['m'] if x[0] != SITE]
        elif name == 'wrong-filter':
            c['unary_nogoods'] = ['not-an-admitted-candidate']
        else:
            lim['max_work'] = 0
        inputs = ctx.save(prefix + '/' + name + '-input.json.gz',
                          dict(packet=p, marked=m, control=c, limits=lim))
        start = time.perf_counter()
        result = ctx.mods['V'].verify(prepared, base, p, m, c, limits=lim)
        seconds = time.perf_counter() - start
        receipt = ctx.save(prefix + '/' + name + '-receipt.json', result)
        expected = 'UNKNOWN' if name == 'zero-work' else 'REJECTED'
        need(result['status'] == expected, 'ACTUAL_RANK_CONTROL:' + name)
        rows.append(dict(id=name, status=result['status'], expected=expected,
                         seconds=seconds, input=inputs, receipt=receipt))
    return rows


def rank(ctx):
    d = ctx.mods['D']
    prepared, base = d.load_prepared(ctx)
    refs, costs = {}, {}
    start = time.perf_counter()
    packet = ctx.mods['P'].analyse(prepared, base, limits=ctx.limits['P'])
    costs['analyse_seconds'] = time.perf_counter() - start
    refs['analysis'] = ctx.save('data/rank/analysis.json.gz', packet)
    if packet['status'] != 'CANDIDATE':
        return dict(status='REJECTED' if packet['status'].startswith('REJECTED') else 'UNKNOWN',
                    stopped_stage='rank_analysis', refs=refs,
                    costs=costs, reason=packet.get('reason'), activation_admitted=False)
    start = time.perf_counter()
    marked, control = models(base, packet['forbidden'])
    costs['model_construction_seconds'] = time.perf_counter() - start
    refs['marked_candidate'] = ctx.save('data/rank/marked-candidate.json.gz', marked)
    refs['control_candidate'] = ctx.save('data/rank/control-candidate.json.gz', control)
    start = time.perf_counter()
    receipt = ctx.mods['V'].verify(prepared, base, packet, marked, control, limits=ctx.limits['V'])
    costs['rank_check_seconds'] = time.perf_counter() - start
    refs['rank_receipt'] = ctx.save('data/rank/rank-receipt.json.gz', receipt)
    if receipt['status'] != 'VERIFIED_REDUNDANT_RANK_CONSTRAINT':
        return dict(status='UNKNOWN' if receipt['status'] == 'UNKNOWN' else 'REJECTED',
                    stopped_stage='independent_rank_gate', refs=refs, costs=costs,
                    reason=receipt.get('reason'), activation_admitted=False)
    bindings = {k: ctx.sha(v) for k, v in [('base', base), ('marked', marked), ('control', control)]}
    need(ctx.wire(receipt['bindings']) == ctx.wire(packet['bindings']), 'EXACT_CHECKED_RANK_PACKET_BINDING')
    need(ctx.wire(receipt['model_bindings']) == ctx.wire(bindings), 'EXACT_CHECKED_ALL_LANE_MODELS')
    need(receipt['bounded_absence'] is False and receipt['learned'] is False
         and receipt['preservation'] == 'ALL_ORIGINAL_COMPLETE_POINT_SOLUTIONS_INCLUDING_PAD_AND_UNUSED_ACTIVE_FACTS',
         'ALL_SOLUTION_REDUNDANCY_SCOPE')
    start = time.perf_counter()
    controls = applied_controls(ctx, prepared, base, packet, marked, control, 'data/rank/controls')
    costs['activation_controls_seconds'] = time.perf_counter() - start
    refs['activation_controls'] = ctx.save('data/rank/activation-controls.json', controls)
    refs['base_model'] = ctx.save('data/rank/base-model.json.gz', base)
    refs['marked_model'] = ctx.save('data/rank/marked-model.json.gz', marked)
    refs['control_model'] = ctx.save('data/rank/control-model.json.gz', control)
    return dict(status='RANK_ADMITTED', activation_admitted=True, refs=refs, costs=costs,
        forbidden_count=len(packet['forbidden']), prepared_scope=prepared['binding']['scope'],
        model_bindings=bindings,
        scope='Certified redundant structural constraint, not a learned marking. Full original rows and problem-defining logical markings retained; exact same exclusions supplied to literal guard and ordinary unary filter. Conditional on fresh full RF/native/model admission.')


def evaluate(ctx):
    d = ctx.mods['D']
    prepared, base = d.load_prepared(ctx)
    admission = ctx.read('data/rank/result.json')
    need(admission['status'] == 'RANK_ADMITTED' and admission['activation_admitted'] is True,
         'ACTUAL_PRIOR_RANK_ADMISSION')
    need(admission['prepared_scope'] == prepared['binding']['scope'], 'RANK_ORIGINAL_SCOPE')
    variants = [('BASE', 'base', base),
        ('RANK_MARKS', 'marked', d.read_ref(ctx, admission['refs']['marked_model'])),
        ('RANK_FILTER', 'control', d.read_ref(ctx, admission['refs']['control_model']))]
    rows, refs = [], {}
    for lane, key, model in variants:
        need(ctx.sha(model) == admission['model_bindings'][key], 'EXACT_ADMITTED_MODEL')
        need([x['id'] for x in model['inventory']['placements']] ==
             [x['id'] for x in base['inventory']['placements']], 'FULL_UNCHANGED_CANDIDATE_IDS')
        run, seconds = d.engine(ctx, 'evaluate-' + lane.lower(), model)
        raw, semantic = run['raw'], run['semantic']
        item = dict(lane=lane, model_sha256=ctx.sha(model), raw_status=raw['status'],
            semantic_status=semantic['status'], reason=raw['reason'], stats=raw['stats'],
            refs=run['refs'], costs=dict(engine_and_C_seconds=seconds),
            admitted_status='UNKNOWN', native_status='NOT_APPLICABLE', bounded_absence=False)
        if raw['status'] == 'SAT' and semantic['status'] == 'VERIFIED':
            need(semantic['run_status'] == 'SAT' and semantic['bounded_absence'] is False
                 and semantic['claim'] == 'SEMANTIC_COMPLETE_SAT_CERTIFICATE', 'COMPLETE_POINT_SAT')
            try:
                proof = d.decode(ctx, prepared, raw['selected'], 'data/evaluate/' + lane.lower() + '-native')
            except d.StopPhase as error:
                item.update(native_status=error.status, native_refs=error.refs,
                            native_reason=error.reason, admitted_status=
                            'REJECTED_NATIVE_PROOF' if error.status == 'REJECTED' else 'UNKNOWN')
            else:
                item.update(native_status='VERIFIED', admitted_status='VERIFIED_NATIVE_POSITIVE',
                            native_refs=proof['refs'], native_proof_lines=len(proof['proof']))
                item['costs'].update(proof['costs'])
        elif raw['status'] == 'UNSAT' and semantic['status'] == 'VERIFIED':
            need(semantic['run_status'] == 'UNSAT' and semantic['bounded_absence'] is True
                 and semantic['claim'] == 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION', 'FINITE_ABSENCE_ONLY')
            item.update(admitted_status='VERIFIED_BOUNDED_EXHAUSTION', bounded_absence=True)
        else:
            need(semantic.get('bounded_absence') is False, 'NO_UNKNOWN_NEGATIVE')
            if semantic['status'] == 'REJECTED':
                item['admitted_status'] = 'REJECTED_ASSURANCE'
        refs[lane] = ctx.save('data/evaluate/' + lane.lower() + '-summary.json.gz', item)
        rows.append(item)
    return dict(status='EVALUATED', lanes=rows, refs=refs,
        native_positives=sum(x['admitted_status'] == 'VERIFIED_NATIVE_POSITIVE' for x in rows),
        finite_exhaustions=sum(x['bounded_absence'] for x in rows),
        scope='One fresh attempt per full-inventory lane, original E/C limits and reference scheduler. Fixed order and single executions do not establish comparative speed; rank acquisition/admission/control and native assurance costs remain separate.')


def baseline(ctx):
    d = ctx.mods['D']
    prepared, base = d.load_prepared(ctx)
    packet = None
    rank_custody = 'ABSENT_OPTIONAL_RANK_PHASE'
    path = ctx.root / 'data/rank/result.json'
    if path.exists():
        try:
            admission = ctx.admitted('rank')
        except (OSError, ValueError, KeyError, TypeError) as error:
            rank_custody = 'UNADMITTED_OPTIONAL_RANK_PHASE:' + type(error).__name__ + ':' + str(error)
        else:
            need(admission['activation_admitted'] is True, 'ADMITTED_RANK_ACTIVATION')
            packet = d.read_ref(ctx, admission['refs']['analysis'])
            rank_custody = 'CLEAN_NATIVE_RANK_PHASE_ADMITTED'
    start = time.perf_counter()
    result = ctx.mods['S'].search(prepared, packet, limits=ctx.limits['S'])
    search_seconds = time.perf_counter() - start
    refs = dict(search=ctx.save('data/baseline/search.json.gz', result))
    answer = dict(status='BASELINE_RECORDED', search_status=result['status'], refs=refs,
        costs=dict(search_seconds=search_seconds), admitted_status='UNKNOWN',
        native_status='NOT_APPLICABLE', bounded_absence=False, rank_information=packet is not None,
        rank_custody=rank_custody,
        scope='Specialized conventional shared-formula AND/OR control, not the reference GCTS scheduler. Same full catalogue, original statement and proof-slot bound. No prior target proof or GCTS search output read. Failure never certifies bounded absence; a candidate requires exact original point/model projection and fresh native proof admission.')
    if result['status'] == 'FOUND_CANDIDATE':
        try:
            proof = d.decode(ctx, prepared, result['selected'], 'data/baseline/native')
        except d.StopPhase as error:
            answer.update(native_status=error.status, native_refs=error.refs,
                          native_reason=error.reason, admitted_status=
                          'REJECTED_NATIVE_PROOF' if error.status == 'REJECTED' else 'UNKNOWN')
        else:
            answer.update(native_status='VERIFIED', admitted_status='VERIFIED_NATIVE_POSITIVE',
                          native_refs=proof['refs'], native_proof_lines=len(proof['proof']))
            answer['costs'].update(proof['costs'])
    return answer


def run(phase, ctx):
    if phase == 'prepare':
        return ctx.mods['D'].run(phase, ctx)
    started = time.perf_counter()
    result = dict(rank=rank, evaluate=evaluate, baseline=baseline)[phase](ctx)
    result.update(schema='Ranked-' + phase + '-result-v1', phase=phase,
                  module_seconds=time.perf_counter() - started)
    return result
