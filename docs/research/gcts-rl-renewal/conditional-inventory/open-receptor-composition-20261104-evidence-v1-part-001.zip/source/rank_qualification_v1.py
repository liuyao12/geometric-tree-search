"""Fresh engine qualification and tiny exhaustive rank preservation checks."""
import copy
import time


def need(ok, why):
    if not ok:
        raise ValueError(why)


def covers(ctx, value):
    need(value['status'] == 'EXHAUSTED', 'COMPLETE_TINY_SUBSET_ORACLE')
    return sorted(ctx.wire(sorted(x['selected'])).decode('ascii') for x in value['solutions'])


def literal_catalogue(ctx, declaration):
    forms = copy.deepcopy(declaration['formulas'])
    ids = {ctx.wire(f): i + 1 for i, f in enumerate(forms)}
    mp, gen = [], []
    for fid, f in enumerate(forms, 1):
        if f[0] == 'imp' and ctx.wire(f[1]) in ids and ctx.wire(f[2]) in ids:
            mp.append(dict(antecedent=ids[ctx.wire(f[1])], implication=fid, output=ids[ctx.wire(f[2])]))
        if declaration['profile']['allow_gen'] and f[0] == 'all' and ctx.wire(f[2]) in ids:
            gen.append(dict(source=ids[ctx.wire(f[2])], output=fid, variable=f[1]))
    return dict(schema='Shared-fact-finite-catalogue-v1', statement=copy.deepcopy(declaration['statement']),
        formulas=forms, zeros=copy.deepcopy(declaration['zeros']), profile=copy.deepcopy(declaration['profile']),
        mp=sorted(mp, key=lambda x: (x['antecedent'], x['implication'], x['output'])),
        gen=sorted(gen, key=lambda x: (x['source'], x['output'], x['variable'])),
        provenance=dict(case_id=declaration['id'], declaration_sha256=ctx.sha(declaration),
            scope='Entire prospectively declared literal tiny catalogue, all structural producers and native ZERO payloads. Generic N model plus native ZERO checks apply; no complete RF-profile claim.'))


def rank_case(ctx, identifier, prepared, base, expected_exists):
    h, d = ctx.mods['H'], ctx.mods['D']
    prefix = 'data/qualify/rank/' + identifier
    refs, costs = {}, {}
    refs['prepared'] = ctx.save(prefix + '/prepared.json.gz', prepared)
    refs['base_model'] = ctx.save(prefix + '/base-model.json.gz', base)
    start = time.perf_counter()
    packet = ctx.mods['P'].analyse(prepared, base, limits=ctx.limits['P'])
    refs['analysis'] = ctx.save(prefix + '/analysis.json.gz', packet)
    need(packet['status'] == 'CANDIDATE', 'TINY_RANK_CANDIDATE')
    marked, control = h.models(base, packet['forbidden'])
    receipt = ctx.mods['V'].verify(prepared, base, packet, marked, control, limits=ctx.limits['V'])
    refs['rank_receipt'] = ctx.save(prefix + '/rank-receipt.json', receipt)
    need(receipt['status'] == 'VERIFIED_REDUNDANT_RANK_CONSTRAINT', 'TINY_RANK_INDEPENDENT_GATE')
    costs['rank_analysis_and_check_seconds'] = time.perf_counter() - start
    oracle_records, actual_records, all_covers = [], [], None
    for lane, model in [('BASE', base), ('RANK_MARKS', marked), ('RANK_FILTER', control)]:
        raw, ref, cost = ctx.mods['J'].oracle(ctx, prefix + '/' + lane.lower(), model)
        subset = covers(ctx, raw)
        need(raw['exists'] is expected_exists, 'DECLARED_TINY_EXISTENCE')
        if all_covers is None:
            all_covers = subset
        else:
            need(subset == all_covers, 'PRESERVES_EVERY_TINY_POINT_SOLUTION')
        oracle_records.append(dict(lane=lane, receipt=ref, cost=cost, solutions=len(subset)))
        run, observed = ctx.mods['J'].complete_engine(ctx, prefix + '/' + lane.lower() + '/search', model)
        need((run['raw']['status'] == 'SAT') is expected_exists, 'ACTUAL_TINY_RANK_EXISTENCE')
        actual_records.append(dict(lane=lane, **observed))
    control_records = h.applied_controls(ctx, prepared, base, packet, marked, control, prefix + '/controls')
    start = time.perf_counter()
    search = ctx.mods['S'].search(prepared, packet, limits=ctx.limits['S'])
    costs['conventional_search_seconds'] = time.perf_counter() - start
    refs['conventional_search'] = ctx.save(prefix + '/conventional-search.json.gz', search)
    native = None
    if expected_exists:
        need(search['status'] == 'FOUND_CANDIDATE', 'POSITIVE_TINY_PLANNER_CANDIDATE')
        native = d.decode(ctx, prepared, search['selected'], prefix + '/conventional-native')
        refs['conventional_native'] = native['refs']
    else:
        need(search['status'] == 'UNKNOWN', 'PLANNER_FAILURE_NOT_ABSENCE')
    stopped = ctx.mods['S'].search(prepared, packet, limits=dict(ctx.limits['S'], max_work=0))
    refs['conventional_zero_work'] = ctx.save(prefix + '/conventional-zero-work.json', stopped)
    need(stopped['status'] == 'UNKNOWN', 'PLANNER_ZERO_WORK_UNKNOWN')
    return dict(id=identifier, status='QUALIFIED', refs=refs, costs=costs,
        forbidden_count=len(packet['forbidden']), original_rows=len(base['inventory']['placements']),
        oracle=oracle_records, actual=actual_records, controls=control_records,
        conventional_status=search['status'], native_status=None if native is None else native['status'],
        native_lines=None if native is None else len(native['proof']),
        scope='All subsets and exact complete cover sets compared on the full tiny inventories; all actual emitted producer graphs checked by C/T and paired reconstruction. Not a large arithmetic search or a proof of unrestricted planner completeness.')


def run(ctx):
    started = time.perf_counter()
    original = ctx.mods['J'].run(ctx)
    original_ref = ctx.save('data/qualify/original-engine-qualification.json.gz', original)
    need(original['status'] == 'QUALIFIED', 'FRESH_ORIGINAL_ENGINE_QUALIFICATION')
    cases, d = [], ctx.mods['D']
    for logical in original['logical']:
        prepared = d.read_ref(ctx, logical['refs']['prepared'])
        base = d.read_ref(ctx, logical['engine']['refs']['model'])
        cases.append(rank_case(ctx, logical['id'], prepared, base, True))
    extra = ctx.read('input/rank-qualification-declarations-v1.json')['cases']
    for declaration in extra:
        prefix = 'data/qualify/rank-extra/' + declaration['id']
        literal = declaration.get('kind') == 'LITERAL'
        catalogue = literal_catalogue(ctx, declaration) if literal else ctx.mods['J'].ground_catalogue(ctx, declaration)
        refs = dict(catalogue=ctx.save(prefix + '/catalogue.json.gz', catalogue))
        prepared = ctx.mods['M'].prepare(catalogue, declaration['profile']['slots'], ctx.limits['M'])
        refs['prepared'] = ctx.save(prefix + '/prepared.json.gz', prepared)
        need(prepared['status'] == 'PREPARED_UNVERIFIED', 'FULL_EXTRA_PREPARATION')
        for role in (['model'] if literal else ['model', 'basis']):
            result = (ctx.mods['N'].verify_model(catalogue, prepared, **ctx.limits['N']) if role == 'model'
                      else ctx.mods['N'].verify_basis(declaration, catalogue, **ctx.limits['N']))
            refs[role] = ctx.save(prefix + '/' + role + '-receipt.json', result)
            need(result['status'] == 'VERIFIED', 'COMPLETE_EXTRA_' + role)
        zero_receipts = []
        for zero in catalogue['zeros']:
            result = ctx.mods['B'].check(catalogue['statement']['theory'], [zero['native']],
                                       zero['native']['formula'], ctx.limits['B'])
            saved = ctx.save(prefix + '/native-zero-' + zero['id'] + '.json', result)
            zero_receipts.append(dict(id=zero['id'], receipt=saved))
            need(result['status'] == 'VERIFIED' and result['checked_lines'] == 1, 'EVERY_EXTRA_NATIVE_ZERO')
        refs['zeros'] = ctx.save(prefix + '/native-zeros.json', zero_receipts)
        case = rank_case(ctx, declaration['id'], prepared, d.migrate(ctx, prepared['model']),
                         declaration['expected_exists'])
        case['input_admission'] = refs
        cases.append(case)
    return dict(schema='Rank-search-qualification-v1', status='QUALIFIED',
        original_qualification=original_ref, original_counts=original['counts'], rank_cases=cases,
        rank_actual_snapshots=sum(x['actual_snapshots'] for c in cases for x in c['actual']),
        total_rank_engine_calls=sum(len(c['actual']) for c in cases),
        total_rank_oracle_calls=sum(len(c['oracle']) for c in cases),
        module_seconds=time.perf_counter() - started,
        scope='Fresh original 20-point/two-logical engine qualification plus six full tiny rank-preservation cases. Five use complete RF/ground profiles; the declared literal nested-GEN case uses generic full-model and native ZERO admission without a complete RF-profile claim. Literal marking/filter mutations and work refusals precede target preparation. No prior target search output or proof witness is read.')
