"""Single-donor term/context hypotheses and concrete rooted-cluster proposals.

No kernel, engine, compiler, model helper or prior-run code is imported. A
library has provenance only, not universal schematic soundness. Current X
admission/state checks and final native validation remain external.
"""
import hashlib
import itertools
import json
import math
import time

DEFAULT_LIMITS = dict(max_work=100000000, wall_seconds=30.0,
                      max_families=4096, max_instances=4096, max_lines=16)
ZERO_RULES = frozenset(('axiom', 'instantiate', 'refl', 'eq_subst', 'distribute', 'tautology'))
SCOPE = ('Warm single-donor empirical schemas; literal binders/names and fixed '
         'line-to-slot mapping. Current primitive expansions and state compatibility '
         'require independent X admission; no universal axiom, target proof, '
         'negative, learned pruning or RL/performance claim is made by L.')


class Reject(Exception):
    pass


class Budget(Exception):
    pass


def need(condition, reason):
    if not condition:
        raise Reject(reason)


def _limits(value):
    result = dict(DEFAULT_LIMITS)
    if value is not None:
        need(type(value) is dict and set(value) <= set(result), 'LIMIT_FIELDS')
        result.update(value)
    for key, limit in result.items():
        if key == 'wall_seconds':
            need(type(limit) in (int, float) and math.isfinite(limit) and limit > 0, 'FINITE_POSITIVE_WALL')
        else:
            need(type(limit) is int and limit >= 0, 'NATIVE_NONNEGATIVE_LIMIT:' + key)
        need(limit <= DEFAULT_LIMITS[key], 'LIMIT_EXCEEDS_CEILING:' + key)
    return result


class Reader:
    def __init__(self, limits, started):
        self.limits, self.started, self.work = limits, started, 0

    def tick(self, units=1):
        self.work += units
        if self.work > self.limits['max_work']:
            raise Budget('MAX_WORK')
        if time.perf_counter() - self.started > self.limits['wall_seconds']:
            raise Budget('WALL_SECONDS')

    def scan(self, value):
        active, stack = set(), [(value, 0, False)]
        while stack:
            item, depth, leaving = stack.pop()
            if leaving:
                active.remove(id(item))
                continue
            self.tick()
            if depth > 128:
                raise Budget('NATIVE_JSON_DEPTH')
            if type(item) in (dict, list):
                need(id(item) not in active, 'NATIVE_JSON_CYCLE')
                active.add(id(item))
                stack.append((item, depth, True))
                self.tick(len(item))
                if type(item) is dict:
                    for key, child in item.items():
                        need(type(key) is str, 'NATIVE_STRING_KEYS')
                        stack.extend(((key, depth + 1, False), (child, depth + 1, False)))
                else:
                    stack.extend((child, depth + 1, False) for child in item)
            elif type(item) is str:
                self.tick(len(item))
            else:
                need(item is None or type(item) in (int, bool) or
                     type(item) is float and math.isfinite(item), 'FINITE_NATIVE_JSON')
                if type(item) is int:
                    self.tick(item.bit_length() // 3 + 1)

    def text(self, value):
        text = json.dumps(value, sort_keys=True, ensure_ascii=True,
                          separators=(',', ':'), allow_nan=False) + '\n'
        self.tick(len(text))
        return text

    def sha(self, value):
        digest = hashlib.sha256()
        encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                                   separators=(',', ':'), allow_nan=False)
        for part in encoder.iterencode(value):
            raw = part.encode('ascii')
            self.tick(len(raw) + 1)
            digest.update(raw)
            self.tick(0)
        digest.update(b'\n')
        self.tick()
        return digest.hexdigest()

    def same(self, left, right):
        return self.text(left) == self.text(right)

    def clone(self, value):
        self.tick()
        if type(value) is list:
            return [self.clone(child) for child in value]
        if type(value) is dict:
            return {key: self.clone(child) for key, child in value.items()}
        if type(value) is str:
            self.tick(len(value))
        return value


def _term(value):
    return type(value) is list and value and value[0] in ('var', 'fun')


def _syntax(value, kind, theory, reader, hole=False):
    reader.tick()
    need(type(value) is list and value and type(value[0]) is str, 'NATIVE_AST')
    tag = value[0]
    if kind == 'term':
        if hole and value == ['_hole']:
            return
        if tag == 'var':
            need(len(value) == 2 and type(value[1]) is str and value[1], 'LITERAL_VARIABLE')
            return
        need(tag == 'fun' and len(value) == 3 and type(value[1]) is str
             and value[1] in theory['functions'] and type(value[2]) is list
             and len(value[2]) == theory['functions'][value[1]], 'CURRENT_FUNCTION_ARITY')
        for child in value[2]:
            _syntax(child, 'term', theory, reader, hole)
        return
    if tag in ('eq', 'imp', 'and', 'or'):
        need(len(value) == 3, 'BINARY_FORMULA')
        for child in value[1:]:
            _syntax(child, 'term' if tag == 'eq' else 'formula', theory, reader, hole)
    elif tag == 'pred':
        need(len(value) == 3 and type(value[1]) is str and value[1] in theory['predicates']
             and type(value[2]) is list and len(value[2]) == theory['predicates'][value[1]], 'CURRENT_PREDICATE_ARITY')
        for child in value[2]:
            _syntax(child, 'term', theory, reader, hole)
    elif tag == 'all':
        need(len(value) == 3 and type(value[1]) is str and value[1], 'LITERAL_BINDER')
        _syntax(value[2], 'formula', theory, reader, hole)
    elif tag == 'not':
        need(len(value) == 2, 'NEGATION_ARITY')
        _syntax(value[1], 'formula', theory, reader, hole)
    else:
        need(value == ['bot'], 'FORMULA_TAG')


def _statement(statement, reader):
    need(type(statement) is dict and set(statement) == {'theory', 'goal'}, 'STATEMENT_FIELDS')
    theory = statement['theory']
    need(type(theory) is dict and set(theory) == {'functions', 'predicates', 'axioms'}, 'THEORY_FIELDS')
    for category in ('functions', 'predicates'):
        need(type(theory[category]) is dict, 'SIGNATURE_DICTIONARY')
        for name, arity in theory[category].items():
            reader.tick()
            need(type(name) is str and name and type(arity) is int and arity >= 0, 'SIGNATURE_VALUE')
    need(type(theory['axioms']) is dict, 'AXIOM_DICTIONARY')
    for name, formula in theory['axioms'].items():
        need(type(name) is str and name, 'AXIOM_NAME')
        _syntax(formula, 'formula', theory, reader)
    _syntax(statement['goal'], 'formula', theory, reader)


def _edges(proof, reader):
    need(type(proof) is list and proof, 'NONEMPTY_NATIVE_PROOF')
    if len(proof) > reader.limits['max_lines']:
        raise Budget('MAX_LINES')
    edges = []
    for index, line in enumerate(proof):
        reader.tick()
        need(type(line) is dict and 'formula' in line, 'NATIVE_LINE')
        rule = line.get('rule')
        need(rule in ZERO_RULES or rule in ('mp', 'generalize'), 'PRIMITIVE_NATIVE_RULE')
        fields = ('antecedent', 'implication') if rule == 'mp' else ('source',) if rule == 'generalize' else ()
        for field in fields:
            premise = line[field]
            need(type(premise) is int and 0 <= premise < index, 'STRICT_EARLIER_NATIVE_REFERENCE')
            edges.append([premise, index, field])
    edges.sort()
    return edges


def _collect_terms(value, terms, reader):
    reader.tick()
    if _term(value):
        if value[0] == 'var' or value[0] == 'fun' and value[2]:
            terms[reader.text(value)] = value
    if type(value) is list:
        for child in value:
            _collect_terms(child, terms, reader)
    elif type(value) is dict:
        for child in value.values():
            _collect_terms(child, terms, reader)


def _size(term, reader):
    reader.tick()
    return 1 + sum(_size(child, reader) for child in term[2]) if term[0] == 'fun' else 1


def _abstract(value, selected, unary, reader):
    reader.tick()
    if _term(value):
        key = reader.text(value)
        if key in selected:
            return ['_term', selected[key]]
        if value[0] == 'fun' and value[1] == unary:
            return ['_ctx', 'C0', _abstract(value[2][0], selected, unary, reader)]
    if type(value) is list:
        return [_abstract(child, selected, unary, reader) for child in value]
    if type(value) is dict:
        return {key: _abstract(child, selected, unary, reader) for key, child in value.items()}
    return value


def _visible(value, terms, contexts, reader):
    reader.tick()
    if type(value) is list:
        if value and value[0] == '_term':
            terms.add(value[1])
        elif value and value[0] == '_ctx':
            contexts.add(value[1])
        for child in value:
            _visible(child, terms, contexts, reader)
    elif type(value) is dict:
        for child in value.values():
            _visible(child, terms, contexts, reader)


def _fill(context, argument, reader):
    reader.tick()
    if context == ['_hole']:
        return reader.clone(argument)
    if type(context) is list:
        return [_fill(child, argument, reader) for child in context]
    if type(context) is dict:
        return {key: _fill(child, argument, reader) for key, child in context.items()}
    return context


def _apply(value, bindings, reader):
    reader.tick()
    if type(value) is list:
        if value and value[0] == '_term':
            need(len(value) == 2 and value[1] in bindings['terms'], 'BOUND_TERM_PARAMETER')
            return reader.clone(bindings['terms'][value[1]])
        if value and value[0] == '_ctx':
            need(len(value) == 3 and value[1] in bindings['contexts'], 'BOUND_CONTEXT_PARAMETER')
            return _fill(bindings['contexts'][value[1]], _apply(value[2], bindings, reader), reader)
        return [_apply(child, bindings, reader) for child in value]
    if type(value) is dict:
        return {key: _apply(child, bindings, reader) for key, child in value.items()}
    return value


def _clusters(proof, reader):
    edges, result = _edges(proof, reader), []
    incoming = {index: [] for index in range(len(proof))}
    for premise, conclusion, field in edges:
        incoming[conclusion].append(premise)
    for mask in range(1, 1 << len(proof)):
        reader.tick(len(proof))
        members = [index for index in range(len(proof)) if mask & (1 << index)]
        member_set, root = set(members), members[-1]
        reached, pending = set(), [root]
        while pending:
            reader.tick()
            index = pending.pop()
            if index not in reached:
                reached.add(index)
                pending.extend(premise for premise in incoming[index] if premise in member_set)
        if reached != member_set:
            continue
        internal, external = [], []
        for edge in edges:
            reader.tick()
            if edge[1] in member_set:
                (internal if edge[0] in member_set else external).append(list(edge))
        preimage = dict(schema='Receptor-cluster-v1', root=root, members=members,
            internal_edges=internal, external_edges=external,
            receptor_indices=sorted({edge[0] for edge in external}))
        result.append(dict(id=reader.sha(preimage), **{key: value for key, value in preimage.items() if key != 'schema'}))
    reader.tick(len(result) * max(1, len(result).bit_length()))
    return sorted(result, key=lambda row: row['id'])


def _result(schema, status, started, reader, effective, counts, **fields):
    if reader is not None:
        reader.tick(0)
    return dict(schema=schema, status=status, **fields,
        costs=dict(seconds=time.perf_counter() - started, work=0 if reader is None else reader.work, **counts),
        limits=effective, scope=SCOPE)


def learn(statement, proof, limits=None):
    started, reader, effective = time.perf_counter(), None, None
    counts = dict(term_candidates=0, abstraction_attempts=0, families=0, clusters=0)
    try:
        effective = _limits(limits)
        reader = Reader(effective, started)
        reader.scan(statement); reader.scan(proof)
        _statement(statement, reader)
        _edges(proof, reader)
        for line in proof:
            _syntax(line['formula'], 'formula', statement['theory'], reader)
        need(reader.same(proof[-1]['formula'], statement['goal']), 'DONOR_LAST_GOAL')
        terms = {}
        _collect_terms(statement, terms, reader); _collect_terms(proof, terms, reader)
        ordered = sorted(terms, key=lambda key: (-_size(terms[key], reader), key))
        counts['term_candidates'] = len(ordered)
        unary = sorted(name for name, arity in statement['theory']['functions'].items() if arity == 1)
        families = {}
        for count in (1, 2):
            for chosen in itertools.combinations(ordered, count):
                selected = {key: 'T' + str(index) for index, key in enumerate(chosen)}
                for function in [None] + unary:
                    reader.tick()
                    counts['abstraction_attempts'] += 1
                    st = _abstract(statement, selected, function, reader)
                    pt = _abstract(proof, selected, function, reader)
                    parameters = dict(terms=list(selected.values()), contexts=[] if function is None else ['C0'])
                    seen_terms, seen_contexts = set(), set()
                    _visible(st['goal'], seen_terms, seen_contexts, reader)
                    if seen_terms != set(parameters['terms']) or seen_contexts != set(parameters['contexts']):
                        continue
                    prototype = dict(terms={name: reader.clone(terms[key]) for key, name in selected.items()},
                        contexts={} if function is None else {'C0': ['fun', function, [['_hole']]]})
                    need(reader.same(_apply(st, prototype, reader), statement)
                         and reader.same(_apply(pt, prototype, reader), proof), 'EXACT_WHOLE_PROTOTYPE_RESTORATION')
                    preimage = dict(schema='Receptor-family-v1', parameters=parameters,
                        statement_template=st, proof_template=pt, prototype_bindings=prototype)
                    identifier = reader.sha(preimage)
                    family = dict(id=identifier, **{key: value for key, value in preimage.items() if key != 'schema'})
                    if identifier in families:
                        need(reader.same(families[identifier], family), 'FAMILY_HASH_COLLISION')
                    families[identifier] = family
                    counts['families'] = len(families)
                    if len(families) > effective['max_families']:
                        raise Budget('MAX_FAMILIES')
        clusters = _clusters(proof, reader)
        counts['clusters'] = len(clusters)
        donor = dict(statement_sha256=reader.sha(statement), proof_sha256=reader.sha(proof), lines=len(proof))
        reader.tick(len(families) * max(1, len(families).bit_length()))
        return _result('Receptor-family-library-v1', 'CANDIDATE_LIBRARY', started, reader, effective, counts,
            donor=donor, families=[families[key] for key in sorted(families)], clusters=clusters)
    except (Budget, MemoryError, RecursionError) as error:
        status, reason = 'UNKNOWN', str(error) or type(error).__name__
    except (Reject, ValueError, TypeError, KeyError, IndexError, AttributeError, OverflowError) as error:
        status, reason = 'REJECTED', str(error)
    return dict(schema='Receptor-family-library-v1', status=status, reason=reason,
        costs=dict(seconds=time.perf_counter() - started, work=0 if reader is None else reader.work, **counts),
        limits=effective, scope=SCOPE)


def _positions(term, reader, path=()):
    reader.tick()
    yield path, term
    if term[0] == 'fun':
        for index, child in enumerate(term[2]):
            yield from _positions(child, reader, path + (index,))


def _context(term, path, reader):
    reader.tick()
    if not path:
        return ['_hole']
    need(term[0] == 'fun', 'CONTEXT_TERM_PATH')
    children = [reader.clone(child) if index != path[0] else _context(child, path[1:], reader)
                for index, child in enumerate(term[2])]
    return ['fun', term[1], children]


def _match_sequence(left, right, index, bindings, reader):
    reader.tick()
    if index == len(left):
        yield bindings
        return
    for expanded in _match(left[index], right[index], bindings, reader):
        yield from _match_sequence(left, right, index + 1, expanded, reader)


def _match(template, target, bindings, reader):
    reader.tick()
    if type(template) is list and template:
        if template[0] == '_term':
            need(len(template) == 2 and type(template[1]) is str, 'TERM_SCHEMA')
            if not _term(target):
                return
            old = bindings['terms'].get(template[1])
            if old is not None:
                if reader.same(old, target):
                    yield bindings
            else:
                yield dict(terms=dict(bindings['terms'], **{template[1]: target}), contexts=bindings['contexts'])
            return
        if template[0] == '_ctx':
            need(len(template) == 3 and type(template[1]) is str, 'CONTEXT_SCHEMA')
            if not _term(target):
                return
            for path, argument in _positions(target, reader):
                context = _context(target, path, reader)
                old = bindings['contexts'].get(template[1])
                if old is not None and not reader.same(old, context):
                    continue
                expanded = dict(terms=bindings['terms'], contexts=dict(bindings['contexts'], **{template[1]: context}))
                yield from _match(template[2], argument, expanded, reader)
            return
    if type(template) is not type(target):
        return
    if type(template) is list:
        if len(template) == len(target):
            yield from _match_sequence(template, target, 0, bindings, reader)
    elif type(template) is dict:
        if template.keys() == target.keys():
            keys = sorted(template)
            yield from _match_sequence([template[key] for key in keys], [target[key] for key in keys], 0, bindings, reader)
    elif template == target:
        if type(template) is str:
            reader.tick(len(template) + len(target))
        yield bindings


def _theory_gate(expanded, statement, proof, reader):
    donor, current = expanded['theory'], statement['theory']
    if not reader.same(expanded['goal'], statement['goal']):
        return False
    for category in ('functions', 'predicates'):
        for name, arity in donor[category].items():
            reader.tick()
            if name in current[category] and current[category][name] != arity:
                return False
    for name, formula in donor['axioms'].items():
        reader.tick()
        if name not in current['axioms'] or not reader.same(formula, current['axioms'][name]):
            return False
    try:
        for line in proof:
            _syntax(line['formula'], 'formula', current, reader)
            for field in ('left', 'right', 'term'):
                if field in line:
                    _syntax(line[field], 'term', current, reader)
            for field in ('universal', 'template'):
                if field in line:
                    _syntax(line[field], 'formula', current, reader)
    except Reject:
        return False
    return True


def _normal_model(model, reader):
    reader.tick()
    need(type(model) is dict and model['schema'] == 'Z-growing-point-model-v3'
         and type(model['capacity']) is int and model['capacity'] == 1
         and model['inventory']['kind'] == 'EXPLICIT', 'CURRENT_EXPLICIT_SHARED_MODEL')
    rows = []
    for row in model['inventory']['placements']:
        reader.tick(1 + len(row['t']) + len(row['m']))
        rows.append(dict(row, t=sorted(row['t']), m=sorted(row['m'])))
    reader.tick(len(rows) * max(1, len(rows).bit_length()))
    return dict(model, roots=sorted(model['roots']),
        seed=dict(t=sorted(model['seed']['t']), m=sorted(model['seed']['m'])),
        inventory=dict(model['inventory'], placements=sorted(rows, key=lambda row: row['id'])),
        pair_nogoods=sorted(model['pair_nogoods']), unary_nogoods=sorted(model['unary_nogoods']))


class Index:
    def __init__(self, prepared, model, reader):
        self.reader, self.prepared = reader, prepared
        self.formulas = {reader.text(formula): fid for fid, formula in enumerate(prepared['catalogue']['formulas'], 1)}
        self.zeros, self.mp, self.gen = {}, {}, {}
        for definition in prepared['definitions']['zeros']:
            reader.tick()
            key = reader.text(definition['native'])
            self.zeros[key] = min(definition['id'], self.zeros.get(key, definition['id']))
        for definition in prepared['definitions']['mp']:
            reader.tick()
            self.mp[(definition['antecedent'], definition['implication'], definition['output'])] = definition['id']
        for definition in prepared['definitions']['gen']:
            reader.tick()
            self.gen[(definition['source'], definition['output'], definition['variable'])] = definition['id']
        self.ids = {row['id'] for row in model['inventory']['placements']}
        original = {row['id'] for row in prepared['universe']}
        reader.tick(len(self.ids) + len(original))
        need(len(self.ids) == len(model['inventory']['placements']) and self.ids == original, 'FULL_CURRENT_INVENTORY_IDS')

    def map(self, proof):
        reader, fids, cids = self.reader, [], []
        _edges(proof, reader)
        for index, line in enumerate(proof):
            reader.tick()
            output = self.formulas.get(reader.text(line['formula']))
            if output is None:
                return None
            rule, refs = line['rule'], []
            if rule in ZERO_RULES:
                kind, definition = 'ZERO', self.zeros.get(reader.text(line))
            elif rule == 'mp':
                refs = [line['antecedent'], line['implication']]
                kind, definition = 'MP', self.mp.get((fids[refs[0]], fids[refs[1]], output))
                if not reader.same(line, dict(rule='mp', formula=line['formula'], antecedent=refs[0], implication=refs[1])):
                    return None
            else:
                refs = [line['source']]
                kind, definition = 'GEN', self.gen.get((fids[refs[0]], output, line['variable']))
                if not reader.same(line, dict(rule='generalize', formula=line['formula'], source=refs[0], variable=line['variable'])):
                    return None
            if definition is None:
                return None
            cid = reader.text([index, kind, definition, refs])
            if cid not in self.ids:
                return None
            fids.append(output); cids.append(cid)
        return cids


def instantiate(library, statement, prepared, model, limits=None):
    started, reader, effective = time.perf_counter(), None, None
    counts = dict(goal_bindings_tested=0, full_expansions_mapped=0, unmapped_expansions=0, instances=0)
    try:
        effective = _limits(limits)
        reader = Reader(effective, started)
        for value in (library, statement, prepared, model):
            reader.scan(value)
        need(library['schema'] == 'Receptor-family-library-v1' and library['status'] == 'CANDIDATE_LIBRARY', 'CANDIDATE_LIBRARY_REQUIRED')
        if len(library['families']) > effective['max_families']:
            raise Budget('MAX_FAMILIES')
        _statement(statement, reader)
        need(prepared['schema'] == 'Shared-fact-prepared-v2' and prepared['status'] == 'PREPARED_UNVERIFIED'
             and reader.same(prepared['statement'], statement), 'CURRENT_COMPLETE_PREPARED_STATEMENT')
        lines = library['donor']['lines']
        need(type(lines) is int and lines > 0 and type(prepared['binding']['slots']) is int
             and prepared['binding']['slots'] == lines, 'FIXED_DONOR_LINE_TO_SLOT_COUNT')
        if lines > effective['max_lines']:
            raise Budget('MAX_LINES')
        normalized = _normal_model(model, reader)
        index = Index(prepared, model, reader)
        bindings = dict(library_sha256=reader.sha(library), statement_sha256=reader.sha(statement),
            prepared_scope=prepared['binding']['scope'], model_sha256=reader.sha(normalized))
        instances, expansion_cache = {}, {}
        for family in library['families']:
            reader.tick()
            preimage = dict(schema='Receptor-family-v1', **{key: family[key] for key in
                ('parameters', 'statement_template', 'proof_template', 'prototype_bindings')})
            need(family['id'] == reader.sha(preimage) and len(family['proof_template']) == lines, 'EXACT_FAMILY_ID_AND_LINES')
            seen = set()
            for binding in _match(family['statement_template']['goal'], statement['goal'], dict(terms={}, contexts={}), reader):
                reader.tick()
                if set(binding['terms']) != set(family['parameters']['terms']) or set(binding['contexts']) != set(family['parameters']['contexts']):
                    continue
                key = reader.text(binding)
                if key in seen:
                    continue
                seen.add(key)
                counts['goal_bindings_tested'] += 1
                expanded_statement = _apply(family['statement_template'], binding, reader)
                expansion = _apply(family['proof_template'], binding, reader)
                if not _theory_gate(expanded_statement, statement, expansion, reader):
                    counts['unmapped_expansions'] += 1
                    continue
                expansion_key = reader.text(expansion)
                if expansion_key not in expansion_cache:
                    expansion_cache[expansion_key] = index.map(expansion)
                    if expansion_cache[expansion_key] is not None:
                        counts['full_expansions_mapped'] += 1
                cids = expansion_cache[expansion_key]
                if cids is None:
                    counts['unmapped_expansions'] += 1
                    continue
                for cluster in library['clusters']:
                    reader.tick(1 + len(cluster['members']) + len(cluster['receptor_indices']))
                    concrete = dict(schema='Receptor-instance-v1', family_id=family['id'], cluster_id=cluster['id'],
                        bindings=reader.clone(binding), line_cids=[[i, cids[i]] for i in cluster['members']],
                        receptors=[[i, reader.clone(expansion[i]['formula'])] for i in cluster['receptor_indices']],
                        root=cluster['root'], expansion=reader.clone(expansion))
                    identifier = reader.sha(concrete)
                    value = dict(id=identifier, **{key: child for key, child in concrete.items() if key != 'schema'})
                    if identifier in instances:
                        need(reader.same(instances[identifier], value), 'INSTANCE_HASH_COLLISION')
                    instances[identifier] = value
                    counts['instances'] = len(instances)
                    if len(instances) > effective['max_instances']:
                        raise Budget('MAX_INSTANCES')
        reader.tick(len(instances) * max(1, len(instances).bit_length()))
        return _result('Receptor-instances-v1', 'CANDIDATE_INSTANCES', started, reader, effective, counts,
            bindings=bindings, instances=[instances[key] for key in sorted(instances)])
    except (Budget, MemoryError, RecursionError) as error:
        status, reason = 'UNKNOWN', str(error) or type(error).__name__
    except (Reject, ValueError, TypeError, KeyError, IndexError, AttributeError, OverflowError) as error:
        status, reason = 'REJECTED', str(error)
    return dict(schema='Receptor-instances-v1', status=status, reason=reason,
        costs=dict(seconds=time.perf_counter() - started, work=0 if reader is None else reader.work, **counts),
        limits=effective, scope=SCOPE)
