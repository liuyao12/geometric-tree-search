"""Independent local open-fragment admission; Source only until review/freeze.

No proposer/engine/native helper imports. Exact local row membership is not a
whole proof, extension certificate, native theorem or universal schema proof.
Low-level JSON/AST/point helpers are copied from the pinned independent V5
checker; whole-proof, prototype and full-cover admission are deliberately absent.
"""
import hashlib
import json
import math
import time

VERSION='Independent-open-fragment-checker-v1'
DEFAULT_LIMITS=dict(max_work=100000000,wall_seconds=30.0,max_families=4096,max_instances=4096,max_lines=16)
ZERO_RULES={'axiom','refl','instantiate','eq_subst','distribute','tautology'}


class _Reject(Exception):
    pass


class _Budget(Exception):
    pass


def need(ok,why):
    if not ok:raise _Reject(why)


def integer(v,low=0):
    return type(v) is int and v>=low and v.bit_length()<=256


def fields(v,names,why):
    need(type(v) is dict and set(v)==set(names),why)


def limits_value(value):
    out=dict(DEFAULT_LIMITS)
    if value is not None:
        need(type(value) is dict and set(value)<=set(out),'LIMIT_FIELDS');out.update(value)
    for k,v in out.items():
        if k=='wall_seconds':need(type(v) in (int,float) and math.isfinite(v) and 0<v<=DEFAULT_LIMITS[k],'WALL_LIMIT')
        else:need(integer(v) and v<=DEFAULT_LIMITS[k],'LIMIT:'+k)
    return out


class _Meter:
    def __init__(self,limits):
        self.limits=limits;self.work=0;self.started=time.perf_counter()

    def tick(self,n=1):
        self.work+=n
        if self.work>self.limits['max_work']:raise _Budget('MAX_WORK')
        if time.perf_counter()-self.started>self.limits['wall_seconds']:raise _Budget('WALL_SECONDS')

    def scan(self,value):
        active=set();stack=[(value,0,False)]
        while stack:
            v,d,leave=stack.pop()
            if leave:active.remove(id(v));continue
            self.tick()
            if d>128:raise _Budget('JSON_DEPTH')
            if type(v) in (dict,list):
                need(id(v) not in active,'JSON_CYCLE');active.add(id(v));stack.append((v,d,True))
                if type(v) is dict:
                    for k,x in v.items():
                        need(type(k) is str,'STRING_KEYS');stack.extend(((k,d+1,False),(x,d+1,False)))
                else:stack.extend((x,d+1,False) for x in v)
            elif type(v) is str:self.tick(len(v))
            elif type(v) is int:need(v.bit_length()<=256,'INTEGER_BITS')
            else:need(v is None or type(v) is bool or type(v) is float and math.isfinite(v),'NATIVE_FINITE_JSON')

    def wire(self,v):
        text=json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n'
        self.tick(len(text));return text.encode('ascii')

    def sha(self,v):
        h=hashlib.sha256()
        for text in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(v):
            self.tick(len(text));h.update(text.encode('ascii'))
        h.update(b'\n');self.tick();return h.hexdigest()

    def same(self,a,b,why):
        stack=[(a,b)]
        while stack:
            x,y=stack.pop();self.tick();need(type(x) is type(y),why+':TYPE')
            if type(x) is dict:
                need(x.keys()==y.keys(),why+':KEYS');self.tick(len(x));stack.extend((v,y[k]) for k,v in x.items())
            elif type(x) is list:
                need(len(x)==len(y),why+':SIZE');self.tick(len(x));stack.extend(zip(x,y))
            else:
                if type(x) is str:self.tick(len(x)+len(y))
                need(x==y,why)


def clone(value,m):
    return json.loads(m.wire(value))


def term(value,m,hole=False):
    m.tick();need(type(value) is list and value and type(value[0]) is str,'TERM_AST')
    if value[0]=='_hole':need(hole and value==['_hole'],'ONE_HOLE_AST');return 1
    if value[0]=='var':need(len(value)==2 and type(value[1]) is str and value[1],'VARIABLE_AST');return 0
    need(value[0]=='fun' and len(value)==3 and type(value[1]) is str and value[1] and type(value[2]) is list,'FUNCTION_AST')
    return sum(term(x,m,hole) for x in value[2])


def syntax_formula(f,theory,m):
    stack=[(f,'formula')]
    while stack:
        a,kind=stack.pop();m.tick();need(type(a) is list and a and type(a[0]) is str,'SYNTAX_AST')
        tag=a[0]
        if kind=='term':
            if tag=='var':need(len(a)==2 and type(a[1]) is str and a[1],'SYNTAX_VARIABLE')
            else:
                need(tag=='fun' and len(a)==3 and type(a[1]) is str and a[1] in theory['functions']
                     and type(a[2]) is list and len(a[2])==theory['functions'][a[1]],'SYNTAX_FUNCTION')
                stack.extend((x,'term') for x in a[2])
        elif tag=='pred':
            need(len(a)==3 and type(a[1]) is str and a[1] in theory['predicates'] and type(a[2]) is list
                 and len(a[2])==theory['predicates'][a[1]],'SYNTAX_PREDICATE');stack.extend((x,'term') for x in a[2])
        elif tag in ('eq','imp','and','or'):
            need(len(a)==3,'SYNTAX_BINARY');stack.extend((x,'term' if tag=='eq' else 'formula') for x in a[1:])
        elif tag=='not':need(len(a)==2,'SYNTAX_NOT');stack.append((a[1],'formula'))
        elif tag=='all':
            need(len(a)==3 and type(a[1]) is str and a[1],'SYNTAX_BINDER');stack.append((a[2],'formula'))
        else:need(tag=='bot' and len(a)==1,'SYNTAX_FORMULA_TAG')


def statement_shape(s,m):
    fields(s,('theory','goal'),'STATEMENT_FIELDS');t=s['theory'];fields(t,('functions','predicates','axioms'),'THEORY_FIELDS')
    for kind in ('functions','predicates'):
        need(type(t[kind]) is dict and all(type(k) is str and k and integer(v) for k,v in t[kind].items()),'SIGNATURE')
    need(type(t['axioms']) is dict and all(type(k) is str and k for k in t['axioms']),'AXIOM_NAMES')
    syntax_formula(s['goal'],t,m)
    for f in t['axioms'].values():syntax_formula(f,t,m)


def proof_edges(proof,m):
    need(type(proof) is list and proof,'NONEMPTY_DONOR_PROOF')
    if len(proof)>m.limits['max_lines']:raise _Budget('MAX_LINES')
    edges=[]
    for i,line in enumerate(proof):
        m.tick();need(type(line) is dict and type(line.get('rule')) is str and 'formula' in line,'PROOF_LINE')
        rule=line['rule']
        if rule=='mp':
            fields(line,('rule','formula','antecedent','implication'),'MP_FIELDS');refs=('antecedent','implication')
        elif rule=='generalize':
            fields(line,('rule','formula','source','variable'),'GEN_FIELDS')
            need(type(line['variable']) is str and line['variable'],'GEN_VARIABLE');refs=('source',)
        else:need(rule in ZERO_RULES,'PRIMITIVE_RULE');refs=()
        for key in refs:
            need(integer(line[key]) and line[key]<i,'STRICT_PRIOR_DONOR_REFERENCE');edges.append([line[key],i,key])
    return sorted(edges)


def substitute(v,bindings,m):
    m.tick()
    if type(v) is list:
        if v and v[0]=='_term':
            need(len(v)==2 and v[1] in bindings['terms'],'TERM_PARAMETER');return clone(bindings['terms'][v[1]],m)
        if v and v[0]=='_ctx':
            need(len(v)==3 and v[1] in bindings['contexts'],'CONTEXT_PARAMETER')
            argument=substitute(v[2],bindings,m)
            def fill(x):
                m.tick()
                if x==['_hole']:return clone(argument,m)
                return [fill(y) for y in x] if type(x) is list else x
            return fill(bindings['contexts'][v[1]])
        return [substitute(x,bindings,m) for x in v]
    if type(v) is dict:return {k:substitute(x,bindings,m) for k,x in v.items()}
    return v


def model_index(model,m):
    fields(model,('schema','version','capacity','roots','seed','inventory','pair_nogoods','unary_nogoods'),'MODEL_FIELDS')
    need(model['schema']=='Z-growing-point-model-v3' and type(model['version']) is str and model['version']
         and integer(model['capacity'],1),'MODEL_ABI');cap=model['capacity']
    need(type(model['roots']) is list and all(type(p) is str and p for p in model['roots'])
         and len(set(model['roots']))==len(model['roots']),'ROOTS')
    def supports(rows,mark):
        need(type(rows) is list,'SUPPORT_LIST');seen=set();out=[]
        for r in rows:
            m.tick();need(type(r) is list and len(r)==2 and type(r[0]) is str and r[0] and r[0] not in seen,'SUPPORT_POINT')
            need(type(r[1]) is str if mark else integer(r[1]) and r[1]<=cap,'SUPPORT_VALUE')
            seen.add(r[0]);out.append(list(r))
        m.tick(len(out)*max(1,len(out).bit_length()));return sorted(out)
    fields(model['seed'],('t','m'),'SEED_FIELDS')
    seed=dict(t=supports(model['seed']['t'],False),m=supports(model['seed']['m'],True))
    fields(model['inventory'],('kind','placements'),'INVENTORY_FIELDS');need(model['inventory']['kind']=='EXPLICIT','EXPLICIT_ONLY')
    need(type(model['inventory']['placements']) is list,'ROW_LIST');rows={}
    for r in model['inventory']['placements']:
        m.tick();fields(r,('id','t','m'),'ROW_FIELDS');cid=r['id']
        need(type(cid) is str and cid and cid not in rows,'DISTINCT_ROW_ID')
        t=supports(r['t'],False);need(t and all(u>0 for p,u in t),'POSITIVE_ROW_SUPPORT')
        rows[cid]=dict(id=cid,t=t,m=supports(r['m'],True))
    need(type(model['unary_nogoods']) is list and model['unary_nogoods']==sorted(set(model['unary_nogoods']))
         and set(model['unary_nogoods'])<=set(rows),'UNARY_FILTER')
    pairs=model['pair_nogoods'];need(type(pairs) is list,'PAIR_FILTER')
    for pair in pairs:
        m.tick();need(type(pair) is list and len(pair)==2 and all(type(cid) is str and cid in rows for cid in pair)
                     and pair[0]<pair[1],'PAIR_IDENTITIES')
    need(pairs==[list(p) for p in sorted(set(tuple(p) for p in pairs))],'SORTED_UNIQUE_PAIRS')
    normalized=dict(schema=model['schema'],version=model['version'],capacity=cap,roots=sorted(model['roots']),seed=seed,
        inventory=dict(kind='EXPLICIT',placements=[rows[c] for c in sorted(rows)]),
        pair_nogoods=clone(pairs,m),unary_nogoods=list(model['unary_nogoods']))
    return normalized,rows,m.sha(normalized)


def aggregate(model,rows,ids,m):
    totals=dict(model['seed']['t']);marks=dict(model['seed']['m']);chosen=set(ids)
    m.tick(len(chosen)+len(model['seed']['t'])+len(model['seed']['m'])+len(model['unary_nogoods'])+len(model['pair_nogoods']))
    need(not chosen.intersection(model['unary_nogoods']),'UNARY_EXCLUDED')
    for a,b in model['pair_nogoods']:need(not(a in chosen and b in chosen),'PAIR_EXCLUDED')
    for cid in sorted(chosen):
        m.tick();need(cid in rows,'UNKNOWN_SELECTED_ID')
        for p,u in rows[cid]['t']:
            m.tick();totals[p]=totals.get(p,0)+u;need(totals[p]<=model['capacity'],'POINT_CAPACITY')
        for p,v in rows[cid]['m']:
            m.tick();need(p not in marks or marks[p]==v,'LITERAL_MARK_DISAGREEMENT');marks[p]=v
    return totals,marks


def used(value,m):
    result=dict(terms=set(),contexts=set());todo=[value]
    while todo:
        x=todo.pop();m.tick()
        if type(x) is list:
            if x and x[0] in ('_term','_ctx'):
                need(len(x)==(2 if x[0]=='_term' else 3) and type(x[1]) is str and x[1],'PARAMETER_NODE')
                result['terms' if x[0]=='_term' else 'contexts'].add(x[1])
            todo.extend(x)
        elif type(x) is dict:todo.extend(x.values())
    return result


def fragment_shape(f,n,m):
    fields(f,('id','family_id','cluster_id','root','members','lines','receptors','parameters'),'FRAGMENT_FIELDS')
    body={k:v for k,v in f.items() if k!='id'}
    need(type(f['id']) is str and f['id']==m.sha(body),'FRAGMENT_ID')
    need(all(type(f[k]) is str and f[k] for k in ('family_id','cluster_id')),'SOURCE_IDENTITIES')
    members=f['members'];need(type(members) is list and 2<=len(members)<=4 and len(members)<n
        and all(integer(i) and i<n for i in members) and members==sorted(set(members)),'PROPER_INTERNAL_MEMBERS')
    need(f['root']==members[-1] and type(f['root']) is int,'ROOT_INDEX')
    lines=f['lines'];receptors=f['receptors']
    need(type(lines) is list and all(type(p) is list and len(p)==2 for p in lines)
         and [p[0] for p in lines]==members,'INTERNAL_PAYLOAD_CENSUS')
    need(type(receptors) is list and receptors and all(type(p) is list and len(p)==2
         and integer(p[0]) and p[0]<n and p[0] not in members for p in receptors),'EXTERNAL_RECEPTORS')
    outside=[p[0] for p in receptors];need(outside==sorted(set(outside)),'SORTED_RECEPTORS')
    edges=[]
    for i,line in lines:
        need(type(line) is dict and 'formula' in line and type(line.get('rule')) is str,'INTERNAL_LINE')
        rule=line['rule']
        if rule=='mp':fields(line,('rule','formula','antecedent','implication'),'MP_FIELDS');keys=('antecedent','implication')
        elif rule=='generalize':
            fields(line,('rule','formula','source','variable'),'GEN_FIELDS')
            need(type(line['variable']) is str and line['variable'],'GEN_VARIABLE');keys=('source',)
        else:need(rule in ZERO_RULES,'PRIMITIVE_RULE');keys=()
        for key in keys:
            j=line[key];need(integer(j) and j<i and j in set(members+outside),'STRICT_DECLARED_PREMISE')
            edges.append((j,i,key))
    need(sorted({a for a,b,k in edges if a not in members})==outside,'EXACT_EXTERNAL_BOUNDARY')
    seen={f['root']};todo=[f['root']]
    while todo:
        v=todo.pop();m.tick(len(edges)+1)
        for a,b,k in edges:
            if b==v and a in members and a not in seen:seen.add(a);todo.append(a)
    need(seen==set(members),'ROOTED_CONNECTED_INTERNAL')
    p=f['parameters'];fields(p,('terms','contexts'),'PARAMETERS')
    all_used=used([lines,receptors],m);boundary=used([dict(lines)[f['root']]['formula'],receptors],m)
    for kind in p:
        need(type(p[kind]) is list and all(type(x) is str and x for x in p[kind])
             and p[kind]==sorted(set(p[kind])) and set(p[kind])==all_used[kind]
             and all_used[kind]<=boundary[kind],'EXACT_BOUNDARY_VISIBLE_PARAMETERS')
    return edges


def library_index(library,m):
    fields(library,('schema','status','source_library_sha256','donor_lines','fragments','costs','limits','scope'),'LIBRARY_FIELDS')
    need(library['schema']=='Open-fragment-library-v1' and library['status']=='MATERIALIZED','LIBRARY_SCHEMA_STATUS')
    need(type(library['source_library_sha256']) is str and len(library['source_library_sha256'])==64,'SOURCE_LIBRARY_SHA')
    n=library['donor_lines'];need(integer(n,1),'DONOR_LINES')
    if n>m.limits['max_lines']:raise _Budget('MAX_LINES')
    fs=library['fragments'];need(type(fs) is list,'FRAGMENT_LIST')
    if len(fs)>m.limits['max_families']:raise _Budget('MAX_FAMILIES')
    for f in fs:fragment_shape(f,n,m)
    ids=[f['id'] for f in fs];need(ids==sorted(set(ids)),'SORTED_DISTINCT_FRAGMENTS')
    limits_value(library['limits']);need(type(library['costs']) is dict and type(library['scope']) is str,'LIBRARY_METADATA')
    return {f['id']:f for f in fs}


def receipt(status,m,before=0,started=None,**extra):
    return dict(status=status,version=VERSION,work_delta=0 if m is None else m.work-before,costs=dict(work=0 if m is None else m.work-before,
        cumulative_work=0 if m is None else m.work,seconds=0.0 if started is None else time.perf_counter()-started),**extra)


def verify_materialization(old,library,limits=None):
    m=None;start=time.perf_counter()
    try:
        m=_Meter(limits_value(limits));m.scan(old);m.scan(library);library_index(library,m)
        need(old['schema']=='Receptor-family-library-v1' and old['status']=='CANDIDATE_LIBRARY','SOURCE_LIBRARY_SCHEMA')
        need(library['source_library_sha256']==m.sha(old) and library['donor_lines']==old['donor']['lines'],'SOURCE_LIBRARY_BINDING')
        n=library['donor_lines'];expected=[];families=old['families'];clusters=old['clusters']
        need(type(families) is list and type(clusters) is list,'SOURCE_COLLECTIONS')
        need([f['id'] for f in families]==sorted({f['id'] for f in families}),'SOURCE_FAMILY_IDS')
        need([c['id'] for c in clusters]==sorted({c['id'] for c in clusters}),'SOURCE_CLUSTER_IDS')
        for f in families:
            m.tick();need(f['id']==m.sha(dict(schema='Receptor-family-v1',**{k:v for k,v in f.items() if k!='id'})),'SOURCE_FAMILY_PREIMAGE')
            proof=f['proof_template'];need(type(proof) is list and len(proof)==n,'SOURCE_LINE_COUNT')
            edges=proof_edges(proof,m)
            for c in clusters:
                m.tick();body={k:v for k,v in c.items() if k!='id'}
                need(c['id']==m.sha(dict(schema='Receptor-cluster-v1',**body)),'SOURCE_CLUSTER_PREIMAGE')
                members=c['members']
                if not 2<=len(members)<=4 or len(members)>=n or not c['receptor_indices']:continue
                need(members==sorted(set(members)) and all(integer(i) and i<n for i in members),'SOURCE_MEMBER_RANGE')
                chosen=set(members);inside=[e for e in edges if e[0] in chosen and e[1] in chosen]
                outside=[e for e in edges if e[0] not in chosen and e[1] in chosen]
                m.same(c['internal_edges'],inside,'SOURCE_INTERNAL_EDGES');m.same(c['external_edges'],outside,'SOURCE_EXTERNAL_EDGES')
                m.same(c['receptor_indices'],sorted({e[0] for e in outside}),'SOURCE_RECEPTOR_INDICES')
                lines=[[i,proof[i]] for i in members];receptors=[[i,proof[i]['formula']] for i in c['receptor_indices']]
                u=used([lines,receptors],m);b=used([proof[c['root']]['formula'],receptors],m)
                if any(not u[k]<=b[k] for k in u):continue
                for k in u:need(u[k]<=set(f['parameters'][k]),'SOURCE_DECLARED_PARAMETERS')
                frag=dict(family_id=f['id'],cluster_id=c['id'],root=c['root'],members=members,
                    lines=lines,receptors=receptors,parameters={k:sorted(u[k]) for k in u})
                frag=dict(id=m.sha(frag),**frag);fragment_shape(frag,n,m);expected.append(frag)
        expected.sort(key=lambda f:f['id']);m.same(library['fragments'],expected,'ALL_AND_ONLY_PROPER_BOUNDARY_FRAGMENTS')
        bindings=dict(source_library_sha256=m.sha(old),library_sha256=m.sha(library))
        m.tick();return receipt('VERIFIED_MATERIALIZATION',m,started=start,bindings=bindings,fragments=len(expected),
            scope='Exact local extraction from the supplied separately authenticated old library. No donor native replay, universal theorem, whole target goal or proof expansion.')
    except (_Budget,MemoryError,RecursionError) as e:return receipt('UNKNOWN',m,started=start,reason=str(e) or type(e).__name__)
    except (_Reject,ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError) as e:return receipt('REJECTED',m,started=start,reason=str(e) or type(e).__name__)


def free_vars(f,m,bound=frozenset()):
    m.tick()
    if type(f) is not list:return set()
    if f and f[0]=='var':return set() if f[1] in bound else {f[1]}
    if f and f[0]=='all':return free_vars(f[2],m,bound|{f[1]})
    result=set()
    for x in f[1:]:
        if type(x) is list:
            if x and type(x[0]) is list:
                for y in x:result.update(free_vars(y,m,bound))
            else:result.update(free_vars(x,m,bound))
    return result


class AdmissionChecker:
    """One immutable current index; exact instance cache, no whole expansion."""
    def __init__(self,prepared,model,library,limits=None):
        self.status='REJECTED';self.reason=None;self.m=None;self.cache={};self.calls=0
        try:
            m=self.m=_Meter(limits_value(limits))
            for x in (prepared,model,library):m.scan(x)
            self.fragments=clone(library_index(library,m),m);self.library_sha256=m.sha(library)
            need(prepared['schema']=='Shared-fact-prepared-v2' and prepared['status']=='PREPARED_UNVERIFIED','PREPARED_ABI')
            self.statement=clone(prepared['statement'],m);statement_shape(self.statement,m)
            self.slots=prepared['binding']['slots'];need(integer(self.slots,1) and self.slots<=16,'CURRENT_SLOTS')
            self.prepared_scope=prepared['binding']['scope'];cat=prepared['catalogue']
            m.same(cat['statement'],self.statement,'CURRENT_CATALOGUE_STATEMENT')
            self.statement_sha256=m.sha(self.statement)
            need(prepared['binding']['catalogue_sha256']==m.sha(cat)
                 and prepared['binding']['original_statement_sha256']==self.statement_sha256,'CURRENT_PREPARED_BINDINGS')
            self.formulas={m.wire(f):i+1 for i,f in enumerate(cat['formulas'])}
            need(len(self.formulas)==len(cat['formulas']),'DISTINCT_CURRENT_FORMULAS')
            self.model,self.rows,self.model_sha256=model_index(model,m)
            need(self.model['capacity']==1,'SYMBOLIC_SLOT_CAPACITY')
            ds=prepared['definitions'];self.zeros={d['id']:d for d in ds['zeros']}
            self.mp={d['id']:d for d in ds['mp']};self.gen={d['id']:d for d in ds['gen']}
            self.gamma_free=set()
            for f in self.statement['theory']['axioms'].values():self.gamma_free.update(free_vars(f,m))
            m.tick();self.status='READY'
        except (_Budget,MemoryError,RecursionError) as e:self.status='UNKNOWN';self.reason=str(e) or type(e).__name__
        except (_Reject,ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError) as e:self.reason=str(e) or type(e).__name__

    def admit(self,instance):
        m=self.m;before=0 if m is None else m.work;start=time.perf_counter();self.calls+=1
        if self.status!='READY':return receipt(self.status,m,before,start,reason=self.reason)
        m.started=start  # Each call has its own wall ceiling; work is cumulative.
        try:
            m.scan(instance);fields(instance,('id','fragment_id','bindings','slot_map','line_cids','receptors','anchor_cid'),'INSTANCE_FIELDS')
            key=m.sha(instance);need(instance['id']==m.sha({k:v for k,v in instance.items() if k!='id'}),'INSTANCE_ID')
            if key in self.cache:
                m.tick();return receipt('VERIFIED_INSTANCE',m,before,start,**self.cache[key]['receipt'])
            if len(self.cache)>=m.limits['max_instances']:raise _Budget('MAX_INSTANCES')
            need(instance['fragment_id'] in self.fragments,'KNOWN_FRAGMENT');f=self.fragments[instance['fragment_id']]
            bindings=instance['bindings'];fields(bindings,('terms','contexts'),'BINDING_FIELDS')
            for k in bindings:need(type(bindings[k]) is dict and set(bindings[k])==set(f['parameters'][k]),'SHARED_PARAMETER_KEYS')
            for t in bindings['terms'].values():need(term(t,m)==0,'TERM_BINDING')
            for c in bindings['contexts'].values():need(term(c,m,True)==1,'ONE_HOLE_CONTEXT_BINDING')
            mapping=instance['slot_map'];donors=sorted(f['members']+[i for i,v in f['receptors']])
            need(type(mapping) is list and all(type(p) is list and len(p)==2 and integer(p[0])
                 and integer(p[1]) and p[1]<self.slots for p in mapping)
                 and [i for i,j in mapping]==donors and len({j for i,j in mapping})==len(mapping),'EXACT_INJECTIVE_SLOT_MAP')
            slots=dict(mapping);lines={i:substitute(v,bindings,m) for i,v in f['lines']}
            boundary={i:substitute(v,bindings,m) for i,v in f['receptors']};forms=dict(boundary)
            forms.update({i:v['formula'] for i,v in lines.items()});fids={}
            for i,formula in forms.items():
                syntax_formula(formula,self.statement['theory'],m);k=m.wire(formula)
                need(k in self.formulas,'CURRENT_LITERAL_FORMULA');fids[i]=self.formulas[k]
            m.same(instance['receptors'],[[i,slots[i],boundary[i]] for i in sorted(boundary)],'EXACT_RECEPTOR_FORMULA_AND_SLOT')
            members=instance['line_cids'];need(type(members) is list and all(type(p) is list and len(p)==2 for p in members)
                and [i for i,cid in members]==f['members'],'EXACT_INTERNAL_CID_CENSUS')
            concrete=[]
            for i,cid in members:
                need(type(cid) is str and cid in self.rows,'CURRENT_INTERNAL_CID');action=json.loads(cid)
                need(type(action) is list and len(action)==4 and m.wire(action).decode('ascii')==cid,'CANONICAL_CID')
                slot,kind,did,refs=action;need(type(slot) is int and slot==slots[i] and type(did) is str,'CURRENT_OWNER_SLOT')
                line=lines[i];rule=line['rule'];fid=fids[i]
                if rule in ZERO_RULES:
                    need(kind=='ZERO' and refs==[] and did in self.zeros,'CURRENT_ZERO_DEFINITION');d=self.zeros[did]
                    m.same(d['native'],line,'EXACT_NATIVE_ZERO_PAYLOAD');need(d['output']==fid,'ZERO_OUTPUT')
                    if rule=='axiom':
                        need(line['name'] in self.statement['theory']['axioms'],'CURRENT_NAMED_AXIOM')
                        m.same(self.statement['theory']['axioms'][line['name']],line['formula'],'CURRENT_GAMMA_AXIOM')
                    prior=[]
                elif rule=='mp':
                    prior=[line['antecedent'],line['implication']]
                    need(kind=='MP' and did in self.mp,'CURRENT_MP_DEFINITION');d=self.mp[did]
                    need((d['antecedent'],d['implication'],d['output'])==(fids[prior[0]],fids[prior[1]],fid),'MP_LITERAL_FORMULAS')
                else:
                    need(rule=='generalize' and kind=='GEN' and did in self.gen,'CURRENT_GEN_DEFINITION');d=self.gen[did];prior=[line['source']]
                    need((d['source'],d['output'],d['variable'])==(fids[prior[0]],fid,line['variable'])
                         and line['variable'] not in self.gamma_free,'CURRENT_GEN_FORMULAS_AND_GAMMA_HYGIENE')
                    m.same(line['formula'],['all',line['variable'],forms[prior[0]]],'GEN_SOURCE_FORMULA')
                need(all(slots[j]<slot for j in prior),'STRICT_PRIOR_CURRENT_REFERENCES')
                m.same(refs,[slots[j] for j in prior],'ACTUAL_CURRENT_REFERENCE_SLOTS')
                row=self.rows[cid];m.same(row['t'],[['q:'+str(slot),1]],'EXACT_CURRENT_OWNER_SUPPORT')
                demand={'a:'+str(slot):'1','f:'+str(slot):str(fid)}
                for j in prior:demand['a:'+str(slots[j])]='1';demand['f:'+str(slots[j])]=str(fids[j])
                marks=dict(row['m'])
                for p,v in demand.items():m.tick();need(marks.get(p)==v,'CURRENT_LOCAL_RECEPTOR_DEMAND')
                concrete.append(cid)
            need(len(concrete)==len(set(concrete)) and instance['anchor_cid']==dict(members)[f['root']],'DISTINCT_ROOT_ANCHOR')
            aggregate(self.model,self.rows,concrete,m)
            binding=dict(model_sha256=self.model_sha256,instance_sha256=key,statement_sha256=self.statement_sha256,
                library_sha256=self.library_sha256,prepared_scope=self.prepared_scope,fragment_id=instance['fragment_id'])
            result=dict(bindings=binding,cluster_cids=concrete,receptors=instance['receptors'],
                scope='Only concrete internal current primitive rows and external formula/slot demands. No outside payload, target-goal matching, full expansion, cover, decoder or native proof checked.')
            entry=dict(value=clone(instance,m),cids=tuple(concrete),receipt=result)
            m.tick();self.cache[key]=entry
            return receipt('VERIFIED_INSTANCE',m,before,start,**result)
        except (_Budget,MemoryError,RecursionError) as e:return receipt('UNKNOWN',m,before,start,reason=str(e) or type(e).__name__)
        except (_Reject,ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError) as e:return receipt('REJECTED',m,before,start,reason=str(e) or type(e).__name__)

    def check(self,instance,request,charge):
        hook_error=[None]
        class Hook(_Meter):
            def __init__(self):self.work=0;self.started=time.perf_counter();self.limits=DEFAULT_LIMITS
            def tick(self,n=1):
                self.work+=n
                try:charge(n)
                except BaseException as e:hook_error[0]=e;raise
        m=Hook();start=time.perf_counter()
        try:
            need(self.status=='READY','STATE_INDEX_UNAVAILABLE');key=m.sha(instance)
            need(key in self.cache,'INSTANCE_NOT_INDEPENDENTLY_ADMITTED');entry=self.cache[key]
            m.same(instance,entry['value'],'UNCHANGED_ADMITTED_INSTANCE')
            fields(request,('schema','model_sha256','point','generation','legal','selected','excluded'),'REQUEST_FIELDS')
            need(request['schema']=='Z-candidate-order-request-v1' and request['model_sha256']==self.model_sha256,'CURRENT_REQUEST_MODEL')
            need(type(request['point']) is str and integer(request['generation']),'CURRENT_POINT_GENERATION')
            for k in ('legal','selected','excluded'):
                xs=request[k];need(type(xs) is list and all(type(c) is str and c in self.rows for c in xs)
                    and xs==sorted(set(xs)),'CURRENT_REQUEST_IDENTITIES');m.tick(len(xs))
            selected=set(request['selected']);excluded=set(request['excluded']);members=set(entry['cids'])
            need(not selected&excluded and not members&excluded,'CURRENT_LOCAL_EXCLUSION')
            totals,marks=aggregate(self.model,self.rows,selected,m)
            active=set(self.model['roots'])|{p for p,u in totals.items() if u>0}
            need(request['point'] in active and totals.get(request['point'],0)<self.model['capacity'],'CURRENT_FRONTIER_POINT')
            for cid in request['legal']:
                need(cid not in selected and cid not in excluded and any(p==request['point'] for p,u in self.rows[cid]['t']),'CURRENT_LEGAL_CONTACT')
            preferred=sorted(members&set(request['legal']));need(preferred,'NO_REMAINING_LEGAL_MEMBER')
            union=selected|members;aggregate(self.model,self.rows,union,m)
            bindings=dict(model_sha256=self.model_sha256,instance_sha256=key,selected_sha256=m.sha(request['selected']),
                excluded_sha256=m.sha(request['excluded']),union_sha256=m.sha(sorted(union)))
            m.tick();return receipt('COMPATIBLE',m,started=start,bindings=bindings,preferred=preferred,
                shared_members=len(selected&members),new_members=len(members-selected),
                scope='Distinct selected/internal t/m/filter union only. Missing receptor owners are consistent demands, not solved obligations. Engine owns complete domains/scheduler/rollback; whole native acceptance remains separate.')
        except _Reject as e:
            if hook_error[0] is not None:raise
            return receipt('REJECTED',m,started=start,reason=str(e))


StateChecker=AdmissionChecker


def admit(prepared,model,library,instance,limits=None):
    return AdmissionChecker(prepared,model,library,limits).admit(instance)


