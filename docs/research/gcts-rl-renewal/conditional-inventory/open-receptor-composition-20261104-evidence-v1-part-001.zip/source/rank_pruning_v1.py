"""Candidate-only derivation-height exclusions; no model mutation or proof claim.

All ZERO truth, catalogue/model completeness and pruning preservation require
external independent admission. This module imports only the standard library.
"""
import hashlib
import json
import math
import time

DEFAULT_LIMITS = dict(max_formulas=1024, max_rows=250000, max_slots=16,
                      max_work=1000000000, wall_seconds=120.0)
SCOPE = ('Least derivation-height ranks over the entire admitted finite ZERO/MP/GEN '
         'catalogue. Height is a lower bound, not minimum proof-line/DAG size. '
         'Every positive formula-port demand is tested; all original rows remain. '
         'CANDIDATE is not independent proof of preservation or logical validity.')


class Budget(Exception):
    pass


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def effective_limits(value, defaults=None):
    defaults = DEFAULT_LIMITS if defaults is None else defaults
    result = dict(defaults)
    if value is not None:
        need(type(value) is dict and set(value) <= set(result), 'LIMIT_FIELDS')
        result.update(value)
    for key, limit in result.items():
        if key == 'wall_seconds':
            need(type(limit) in (int, float) and math.isfinite(limit) and limit > 0,
                 'POSITIVE_FINITE_WALL')
        else:
            need(type(limit) is int and limit >= 0, 'NATIVE_NONNEGATIVE_LIMIT:' + key)
        need(limit <= defaults[key], 'LIMIT_EXCEEDS_CEILING:' + key)
    return result


class Reader:
    def __init__(self, limits):
        self.limits, self.work = limits, 0
        self.started = time.perf_counter()

    def tick(self, units=1):
        self.work += units
        if self.work > self.limits['max_work']:
            raise Budget('MAX_WORK')
        if time.perf_counter() - self.started > self.limits['wall_seconds']:
            raise Budget('WALL_SECONDS')

    def scan(self, value):
        stack = [(value, 0)]
        while stack:
            item, depth = stack.pop()
            self.tick()
            if depth > 128:
                raise Budget('NATIVE_JSON_DEPTH')
            if type(item) is str:
                self.tick(len(item))
            elif type(item) is list:
                self.tick(len(item))
                stack.extend((child, depth + 1) for child in item)
            elif type(item) is dict:
                self.tick(len(item))
                for key, child in item.items():
                    need(type(key) is str, 'NATIVE_STRING_KEYS')
                    stack.extend(((key, depth + 1), (child, depth + 1)))
            else:
                need(item is None or type(item) in (bool, int) or
                     type(item) is float and math.isfinite(item), 'FINITE_NATIVE_JSON')
                if type(item) is int:
                    self.tick(item.bit_length() // 3 + 1)

    def same(self, left, right):
        stack = [(left, right)]
        while stack:
            a, b = stack.pop()
            self.tick()
            if type(a) is not type(b):
                return False
            if type(a) is dict:
                self.tick(sum(len(k) + 1 for k in a) + sum(len(k) + 1 for k in b))
                if a.keys() != b.keys():
                    return False
                stack.extend((a[k], b[k]) for k in a)
            elif type(a) is list:
                self.tick(len(a) + len(b))
                if len(a) != len(b):
                    return False
                stack.extend(zip(a, b))
            else:
                if type(a) is str:
                    self.tick(len(a) + len(b))
                if a != b:
                    return False
        return True

    def text(self, value):
        text = json.dumps(value, sort_keys=True, ensure_ascii=True,
                          separators=(',', ':'), allow_nan=False) + '\n'
        self.tick(len(text))
        return text

    def digest(self, value):
        digest = hashlib.sha256()
        encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                                   separators=(',', ':'), allow_nan=False)
        for part in encoder.iterencode(value):
            raw = part.encode('ascii')
            self.tick(len(raw) + 1)
            digest.update(raw)
            self.tick(0)
        digest.update(b'\n')
        self.tick()
        return digest.hexdigest()


def _fid(value, n):
    return type(value) is int and 1 <= value <= n


def _input(prepared, base_model, reader):
    """Structural binding checks, not an independent RF/native/model checker."""
    reader.scan(prepared)
    if base_model is not None:
        reader.scan(base_model)
    need(type(prepared) is dict and prepared['schema'] == 'Shared-fact-prepared-v2'
         and prepared['status'] == 'PREPARED_UNVERIFIED', 'ADMITTED_PREPARED_ABI')
    catalogue, binding = prepared['catalogue'], prepared['binding']
    need(type(catalogue) is dict and catalogue['schema'] == 'Shared-fact-finite-catalogue-v1', 'CATALOGUE_SCHEMA')
    formulas, slots = catalogue['formulas'], binding['slots']
    need(type(formulas) is list and formulas and type(slots) is int and slots > 0, 'FORMULAS_AND_SLOTS')
    if len(formulas) > reader.limits['max_formulas'] or slots > reader.limits['max_slots']:
        raise Budget('FORMULA_OR_SLOT_BOUND')
    keys = [reader.text(formula) for formula in formulas]
    reader.tick(len(keys) * max(1, len(keys).bit_length()))
    need(keys == sorted(set(keys)), 'SORTED_LITERAL_FORMULA_IDS')
    ids = {key: index for index, key in enumerate(keys, 1)}
    n = len(formulas)
    need(reader.same(prepared['statement'], catalogue['statement']), 'ORIGINAL_STATEMENT')
    need(type(catalogue['profile']['slots']) is int and catalogue['profile']['slots'] == slots
         and type(catalogue['profile']['allow_gen']) is bool, 'DECLARED_PROFILE')
    need(binding['goal_id'] == ids[reader.text(catalogue['statement']['goal'])]
         and type(binding['goal_id']) is int, 'GOAL_LITERAL_ID')
    logical = {key: catalogue[key] for key in ('schema', 'statement', 'formulas', 'zeros', 'mp', 'gen', 'profile')}
    preimage = dict(schema='Shared-fact-point-scope-v2', catalogue=logical, slots=slots,
        allow_padding=True, point_version='DAG-slot-ports-v2', candidate_version='DAG-candidate-v2')
    need(reader.same(binding['scope_preimage'], preimage) and binding['scope'] == reader.digest(preimage), 'PREPARED_SCOPE')
    need(binding['catalogue_sha256'] == reader.digest(catalogue)
         and binding['original_statement_sha256'] == reader.digest(prepared['statement']), 'PREPARED_DIGESTS')
    zeros, mp, gen, zero_ids = [], [], [], []
    for item in catalogue['zeros']:
        reader.tick()
        need(type(item) is dict and set(item) == {'id', 'native'} and type(item['id']) is str
             and item['id'] and type(item['native']) is dict, 'ZERO_DEFINITION')
        output = ids[reader.text(item['native']['formula'])]
        zeros.append(dict(id=item['id'], output=output, native=item['native']))
        zero_ids.append(item['id'])
    need(zero_ids == sorted(set(zero_ids)), 'ALL_DISTINCT_ZERO_IDS')
    for fid, formula in enumerate(formulas, 1):
        reader.tick()
        need(type(formula) is list and formula and type(formula[0]) is str, 'LITERAL_FORMULA')
        if formula[0] == 'imp':
            need(len(formula) == 3, 'IMPLICATION_ARITY')
            a, b = reader.text(formula[1]), reader.text(formula[2])
            if a in ids and b in ids:
                mp.append(dict(antecedent=ids[a], implication=fid, output=ids[b]))
        if catalogue['profile']['allow_gen'] and formula[0] == 'all':
            need(len(formula) == 3 and type(formula[1]) is str, 'GENERALIZATION_AST')
            body = reader.text(formula[2])
            if body in ids:
                gen.append(dict(source=ids[body], output=fid, variable=formula[1]))
    mp.sort(key=lambda d: (d['antecedent'], d['implication'], d['output']))
    gen.sort(key=lambda d: (d['source'], d['output'], d['variable']))
    need(reader.same(catalogue['mp'], mp) and reader.same(catalogue['gen'], gen), 'ALL_STRUCTURAL_MP_GEN')
    definitions = dict(zeros=zeros, mp=[dict(id='mp:' + str(d['implication']), **d) for d in mp],
        gen=[dict(id='gen:' + str(d['output']), **d) for d in gen], pad=dict(id='pad', active=0, formula_id=0))
    need(reader.same(prepared['definitions'], definitions), 'ALL_PREPARED_DEFINITIONS')
    rows = prepared['universe']
    need(type(rows) is list, 'COMPLETE_ROW_LIST')
    if len(rows) > reader.limits['max_rows']:
        raise Budget('ROW_BOUND')
    cids = []
    for row in rows:
        reader.tick()
        need(type(row) is dict and set(row) == {'id', 't', 'm'} and type(row['id']) is str,
             'COMPLETE_CANDIDATE_ROW')
        action = json.loads(row['id'])
        need(type(action) is list and len(action) == 4 and reader.text(action) == row['id']
             and type(action[0]) is int and 0 <= action[0] < slots, 'CANONICAL_CANDIDATE_SLOT')
        need(type(row['m']) is list, 'MARK_ROWS')
        previous = None
        for port, value in row['m']:
            reader.tick()
            need(type(port) is str and type(value) is str and (previous is None or previous < port), 'SORTED_LITERAL_MARKS')
            previous = port
            need(port[:2] in ('a:', 'f:') and port[2:].isdigit() and str(int(port[2:])) == port[2:]
                 and 0 <= int(port[2:]) < slots, 'COMPACT_MARK_PORT')
            if port.startswith('f:'):
                need(value.isdigit() and str(int(value)) == value and 0 <= int(value) <= n, 'FORMULA_PORT_VALUE')
        cids.append(row['id'])
    need(cids == sorted(set(cids)), 'ALL_DISTINCT_SORTED_CANDIDATES')
    scope = binding['scope']
    expected = dict(schema='Z-growing-point-model-v1', version='Shared-fact-slots-active-formula-v2:' + scope,
        capacity=1, roots=sorted('q:' + str(i) for i in range(slots)),
        seed=dict(t=[], m=sorted([['a:' + str(slots - 1), '1'], ['f:' + str(slots - 1), str(binding['goal_id'])]])),
        inventory=dict(kind='EXPLICIT', placements=rows))
    need(reader.same(prepared['model'], expected), 'ORIGINAL_FULL_POINT_MODEL')
    migrated = dict(expected, schema='Z-growing-point-model-v3', version=expected['version'] + ':engine-v4',
                    pair_nogoods=[], unary_nogoods=[])
    if base_model is not None:
        need(reader.same(base_model, migrated), 'EXACT_FULL_UNMARKED_BASE_MODEL')
    bindings = dict(catalogue_sha256=binding['catalogue_sha256'], prepared_scope=scope,
                    base_model_sha256=reader.digest(migrated), slots=slots)
    return dict(n=n, slots=slots, goal=binding['goal_id'], definitions=definitions,
                rows=rows, bindings=bindings)


def _heights(data, reader, counts):
    heights = [None] * (data['n'] + 1)
    for definition in data['definitions']['zeros']:
        reader.tick()
        heights[definition['output']] = 1
    for _ in range(data['n'] + 1):
        previous = heights
        heights = list(previous)
        changed = False
        counts['relaxation_passes'] += 1
        for kind, fields in (('mp', ('antecedent', 'implication')), ('gen', ('source',))):
            for definition in data['definitions'][kind]:
                reader.tick()
                counts['producer_visits'] += 1
                ranks = [previous[definition[field]] for field in fields]
                if all(rank is not None for rank in ranks):
                    rank, output = 1 + max(ranks), definition['output']
                    if heights[output] is None or rank < heights[output]:
                        heights[output], changed = rank, True
        if not changed:
            return heights
    raise ValueError('FINITE_HEIGHT_FIXED_POINT_INVARIANT')


def analyse(prepared, base_model, limits=None):
    started, reader, effective = time.perf_counter(), None, None
    counts = dict(relaxation_passes=0, producer_visits=0, row_visits=0)
    try:
        effective = effective_limits(limits)
        reader = Reader(effective)
        reader.started = started
        data = _input(prepared, base_model, reader)
        heights = _heights(data, reader, counts)
        forbidden, reasons = [], []
        for row in data['rows']:
            reader.tick()
            counts['row_visits'] += 1
            bad = []
            for port, value in row['m']:
                reader.tick()
                if port.startswith('f:') and value != '0':
                    fid, slot = int(value), int(port[2:])
                    rank = heights[fid]
                    if rank is None or rank > slot + 1:
                        bad.append([fid, slot, rank])
            if bad:
                bad.sort(key=lambda item: (item[1], item[0]))
                forbidden.append(row['id'])
                reasons.append([row['id'], bad])
        reader.tick(data['n'])
        result = dict(schema='Rank-pruning-analysis-v1', status='CANDIDATE', bindings=data['bindings'],
            ranks=[[fid, heights[fid]] for fid in range(1, data['n'] + 1)], forbidden=forbidden,
            reasons=reasons, costs=dict(seconds=time.perf_counter() - started, work=reader.work, **counts),
            limits=effective, scope=SCOPE)
        reader.tick(0)
        result['costs'].update(seconds=time.perf_counter() - started, work=reader.work)
        return result
    except (Budget, MemoryError, RecursionError) as error:
        status = 'UNKNOWN'
        reason = str(error) or type(error).__name__
    except (ValueError, TypeError, KeyError, IndexError, AttributeError, OverflowError) as error:
        status, reason = 'REJECTED_INPUT', str(error)
    return dict(schema='Rank-pruning-analysis-v1', status=status, reason=reason, limits=effective,
        costs=dict(seconds=time.perf_counter() - started, work=0 if reader is None else reader.work, **counts), scope=SCOPE)
