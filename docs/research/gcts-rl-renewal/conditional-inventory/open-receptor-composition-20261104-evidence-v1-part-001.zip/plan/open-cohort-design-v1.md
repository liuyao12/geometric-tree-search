# Prospective open-receptor cohort

Design only. No compiler, engine, checker, learner, helper or test was imported or
called. These are statement-level declarations, not target proofs, proof paths,
expected CIDs or derivation skeletons. Root chooses and freezes all inputs and
limits before classification. Every refusal/UNKNOWN remains in the cohort.

## Two fixed statements

Root selected the existing unary-transfer declaration as calibration, together
with a new nested-addition statement. Display names below stand for the literal
`qmtx`, `qmtadd`, `qmtzero`, `qmtS`, `qmtH` symbols in the input files. Both use
only the closed named hypothesis

\[
\Gamma=\{\forall x\;\operatorname{add}(x,0)=x\}.
\]

| Case | Original target statement | Declared slots | Purpose |
|---|---|---:|---|
| `unary-transfer` | \(\forall x\;H(\operatorname{add}(S(S(x)),0))=H(S(S(x)))\) | 8 | Previously examined one-redex term/context calibration; explicitly seen, not untouched evidence. |
| `chained-equality` | \(\forall x\;\operatorname{add}(\operatorname{add}(x,0),0)=x\) | 12 | New target structure with two nested addition occurrences, rather than one whole one-redex donor conclusion. |

The first is `input/case-unary-transfer-v1.json` (1,099 bytes,
`4ac0096937a81666ee832879e4acde9a9edca8e27d81664422538f4780d9a717`).
The second is Root's `input/case-chained-equality-v1.json` (1,002 bytes,
`36238f4ff1103216bdfe50e83946b19e7320a405a23fc7ca4ac5454d1bef2528`).
The latter's signature also retains the unused declared unary symbols; unused
signature symbols do not supply terms, rules or hypotheses.

This is a difference in target syntax, not a prospective claim that every proof
has a prescribed topology or must use any chosen fragment. Actual proof graphs,
fragment use and receptor fulfillment are measured only after search. The two
slot bounds are different problem declarations, not an equal-size performance
comparison or independent held-out theorem families.

## Unchanged finite logical basis

Use the full existing original-context RF profile: `terms=[]`, one UI round,
original theory/goal subterms frozen before UI, all original EQ occurrence/hole
contexts, all retained ordered equality-substitution term pairs, reflexivity,
all native ZERO payloads and every structural MP/GEN/reference tuple. No
target-shaped thinning, extra derived lemma, theorem axiom, added tautology or
selected proof is allowed. Keep native ZERO, RF, bridge, model and whole-proof
independent gates. Gamma is closed; this is the finite addition-zero/equality
fragment, without induction or full PA completeness.

Keep the existing ceilings: 20 original terms, 24 original EQ templates, 8,000
definitions, 1,024 formulas, 250,000 explicit rows and at most 16 slots. The
actual complete constructor either admits its entire basis or returns UNKNOWN;
it never truncates to those limits. No equality conjunction/introduction rule
is silently added merely to make a multi-conclusion benchmark expressible.

For the new target only, a Source-level conservative input bound is available:
four distinct original subterms and at most ten raw original EQ-hole occurrences.
Thus at most 160 EQ-substitution ZERO instances, eight UI instances, four
reflexivities and one hypothesis ZERO occur; these give upper bounds of 173
ZERO, 328 MP and two GEN definitions. Formula closure is bounded by 840 and
the twelve-slot unfiltered row count by 168,188. These are supplied static
resource bounds, not measured catalogue counts, a proof, a search outcome or
an admission. Actual counts and all independent checks must still be saved.

The inherited preparation guard accepted only eight slots. Root's prospective
`arithmetic_phases_v3.py` changes only that guard/reason to permit the frozen
eight or twelve slots. Generic M/N, rank and conventional interfaces already
allow the larger bound. No logical predicate, primitive rule, term pool or
resource ceiling changes with that guard.

## What genuinely open guidance must expose

Materialize only proper rooted fragments with two to four internal nodes and
nonempty external receptors. Erase all outside donor payloads and any complete
instantiated expansion from the serialized library. The warm V5 library is
untrusted proposal input, not an admitted theorem bank; no fresh relearning or
target proof is supplied. Concrete internal primitives and dependencies must be
independently checked in the recipient's current catalogue and theory.

Match the local root to an actual legal chosen-point CID. Bind terms/contexts
and a partial injective node-to-slot map from that anchor, requiring strictly
earlier primitive references. A receptor is an outside slot/formula demand with
no supplied proof owner. Matching/admission may not call a whole-proof mapper,
require a whole point cover, finish all receptors recursively, invoke a native
decoder/kernel, or require recipient length to equal donor length. Full native
M/N/B acceptance occurs only for the complete actual final certificate.

The policy returns preferences only. The unchanged engine appends every legal
base candidate and still performs global dead, global forced and earliest-
generation decisions. Revalidate against selected/excluded state after rollback;
shared CIDs contribute once. A refused match is no preference, never a negative
label or candidate removal. Record actual attempts, placements, final surviving
fragment members and receptor fulfillments separately; proposing a fragment
does not mean the engine adopted or completed it.

## Comparisons and process limits

Run `RANK_ONLY`, proper-open-fragment-guided GCTS and the existing primitive
`CONVENTIONAL_AND_OR` separately on each same complete rank-marked case/model,
with identical primitive universe and final native acceptance. The conventional
planner has no learned fragment library: label it an **unmatched-information
control**. Its unique-formula acyclic plans are a specialized search class; a
failure is UNKNOWN, never bounded absence or reference-GCTS exhaustion.

A same-fragment AND/OR control is deferred unless a complete reviewed ABI is
ready before freeze. Such a control must receive exactly the same sanitized
fragment library, original primitive fallback and current theory/rank/bound;
it must explicitly compose unresolved receptors and emit a final original CID
certificate. A library-only restricted solver is not an equally equipped
baseline. Without this control, even successful open-guided runs demonstrate
safe finite composition/reuse, not a distinctive GCTS advantage over ordinary
proof search using the same information. No RL is used.

Use a separately owned method child with the existing 120-second engine,
300-second semantic checker, work/capture/candidate limits and owned CPU/wall/RSS
guards. The parent retains refs and compact metadata, not prior method graphs.
This removes cross-method object retention; it does not prove a single method
fits the memory limit. Preserve every first attempt, native exit and guard stop;
do not restart, enlarge caps or promote a failed-process prefix automatically.
Report warm acquisition provenance, current materialization, preparation/rank,
proposal/admission, policy, E/C, capture and M/N/B costs separately.

Before publication, require actual tiny complete-domain/state/rollback checks,
typed/malformed/interface mutations, no-full-expansion qualification, frozen
Source/runtime/input custody and whole native proof gates. Complete emitted
events alone do not make a raw UNKNOWN search an absence certificate. Future
theory transfer, learned markings and RL remain separate milestones.
