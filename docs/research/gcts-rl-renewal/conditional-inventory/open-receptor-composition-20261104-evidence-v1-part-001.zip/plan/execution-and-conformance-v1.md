# Prospective execution and conformance

This experiment is a finite symbolic point adaptation, with integer capacity
one, slot centers and active/formula mark ports. It is not a single finite
universal Wang palette or a geometric representation of arithmetic objects.
Placements have identity orientation; all proof references are strictly prior.
The complete original RF catalogue, reference tuples, literal marks and rank
certificates remain mandatory. Rank is a proved structural constraint, not a
new learned failure marking. The new learned-data role is fragment advice only.

The master contract is the current copied `reference/basic-tiling-algorithm.md`.
Its unchanged E engine retains the complete point/candidate bipartite graph,
global dead checks before forced moves, earliest-generation branches, complete
primitive fallback, and exact rollback. C4 independently replays every emitted
decision. Fresh tiny subset/original graph/rank/callback tests precede the
experiment; actual intermediate graphs are captured for tiny qualification,
while larger runs retain complete events and endpoint graphs. These are finite
qualification results, not a general implementation proof.

There are ten declared owned children: qualification, materialization, and one
preparation plus three separate methods for each of two cases. All are sequential.
Each child has the unchanged polling RSS threshold, CPU/wall guards, scientific
limits and capture cap in `run_open_composition_v1.py`. The simple sum of child
guard ceilings is 12,000 wall seconds and 9,000 CPU seconds. This is a new cohort,
not a comparison of equal total process allowances to the older five-method
single-child phase. All three new methods have equal engine/search ceilings
where their different algorithms expose corresponding limits. Single executions
and unequal information do not establish a speed or method-superiority claim.

Each method authenticates the admitted preparation/rank and current erased
library refs it needs. The supervisor retains only exact file refs and statuses.
No method consumes another method's discovered proof. Raw E output is persisted
before C4; only a successful whole enclosing child with fresh M/N projection
agreement and B acceptance admits a proof. Native wait, PID/log/result/protocol
joins and unchanged Source are separate custody gates. Method failures retain
their prefix and never trigger a retry, changed cap, negative training label or
promotion. Other independently eligible controls may continue.

Policy proposal output is capped at 32 candidates per local query, with the
proposer's separate two-million work/one-second query bounds. These sample only
recommendations. A policy records at most 128 complete callback payloads and
queries at most 1,024 anchors; reaching either cap disables further preferences
and retains primitive fallback. Complete engine orders/events remain captured.
Successful concrete admission and state receipts are bound to the exact current
model, statement, library, instance and selected/excluded context. Actual
admission work is charged to E, with setup and wall costs recorded separately.

Frozen Sources and inputs are reviewed before any scientific import or call.
No new target proof, expected path or selected-CID skeleton is provided. The old
whole candidate library is warm untrusted data used only during materialization;
method proposal and admission operate on erased internal fragments and external
formula demands. Local synthetic qualification is explicitly separate from
target proof discovery and full RF/native model admission.

The existing public GitHub Pages destination and full evidence categories are
already authorized. Publication must preserve unrelated files and the primary
Git index, verify the deployed report and exact archive bytes, and label any
postcut custody records as later evidence rather than members of their own
earlier ZIP. The long-term research goal remains active.
