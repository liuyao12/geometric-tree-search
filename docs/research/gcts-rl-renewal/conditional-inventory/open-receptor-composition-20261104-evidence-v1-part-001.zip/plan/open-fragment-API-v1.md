# Erased open fragments and local recommendations

This is Source-only prospective code. The module imports only the Python standard
library. No engine, compiler, donor proof mapper, decoder or native kernel is
called. The materialization child alone reads the old library. Method children
receive the erased library, current prepared catalogue and current full model.

`source/open_fragments_v1.py` exports:

```python
materialize(old_library, limits=None)
LocalProposer(prepared, model, library, limits=None)
LocalProposer.propose(anchor_cid, charge=None)
propose(prepared, model, library, anchor_cid, limits=None)
```

The last function is a convenience wrapper. Callback code should construct one
`LocalProposer` during timed policy setup and reuse its detached indexes. Its
constructor records a refusal internally; `propose` then returns that refusal.
No construction failure is a negative label or a reason to remove a base move.

All hashes use SHA256 of canonical ASCII JSON with sorted keys, compact
separators, finite native values and one trailing LF. Fragment and instance ID
preimages are exactly their bodies without the `id` field, with no additional
schema field. IDs and data provenance require independent X admission.

## Materialization

Success has exactly these fields:

```text
schema = Open-fragment-library-v1
status = MATERIALIZED
source_library_sha256
donor_lines
fragments
costs
limits
scope
```

Each fragment has exactly:

```text
id, family_id, cluster_id, root, members,
lines = [[donor_index, native_payload_template], ...],
receptors = [[external_donor_index, formula_template], ...],
parameters = {terms: [...], contexts: [...]}
```

Families, their IDs and all selected source cluster IDs are checked against their
source preimages. Every proper rooted source subset with between two and four
members is independently enumerated from primitive references. It is kept if it
has at least one external receptor and all used parameters are boundary-visible.
Every such source cluster must be present in the source cluster table. Each
member is reachable from the maximum-index root through internal premise edges.
`members`, `lines` and `receptors` are sorted by donor index; output fragments
are sorted by ID.

A used parameter is a `_term` or `_ctx` reference anywhere in internal payloads
or external receptor formulas. It is boundary-visible when it occurs in the root
formula or an external receptor formula. Only used parameters are exported;
unused global family parameters are erased. Parameters used internally but not
at the boundary make that family/cluster combination ineligible. This is an
empirical proposal profile, not a completeness theorem about useful fragments.

The result contains no source statement, source goal, prototype bindings,
outside line payloads, full expansion, proof bank or target proof. Receptor
formulas alone survive from outside nodes. Existing family/cluster IDs remain
opaque provenance references. The source library hash and donor line count are
metadata, not an instruction to map a whole proof.

Malformed input is `REJECTED`. A size/work/time/memory/depth refusal is `UNKNOWN`.
Failure results have no `fragments` field. Independent verification of extraction
and old donor/native provenance is external; a matching ID alone is not proof of
logical validity.

## Current local proposal

The prepared packet is `Shared-fact-prepared-v2`; the current capacity-one model
is `Z-growing-point-model-v3` with a complete explicit inventory. The proposer
requires the exact current inventory CID set to equal `prepared.universe`, so
rank markings may decorate rows but cannot thin the primitive inventory. Model
syntax, full row correctness, rank preservation and logical ZERO truth remain
external admissions. The proposer clones the formulas, definitions and erased
fragments used by its indexes; subsequent caller mutation does not update them.
Model hashes use the engine normalization: sorted roots, seed/support rows,
placements by CID, and pair/unary filters.

The successful outer packet is:

```text
schema = Open-fragment-proposals-v1
status = CANDIDATE_FRAGMENTS
bindings = {prepared_scope, model_sha256, library_sha256, anchor_cid}
instances = [...]
costs, limits, scope
```

Each instance has exactly:

```text
id, fragment_id,
bindings = {terms: {name: term}, contexts: {name: one_hole_term_context}},
slot_map = [[donor_index, current_slot], ...],
line_cids = [[internal_donor_index, actual_current_CID], ...],
receptors = [[external_donor_index, current_slot, current_formula], ...],
anchor_cid
```

All three maps are sorted by donor index. The root member maps to the exact
supplied anchor CID. There is no donor-index-equals-slot requirement and no
requirement that donor proof length equal the current slot bound. The entire
partial slot map is injective across internal and external donor indices. This
is a conservative recommendation restriction; it does not remove any primitive
search alternative. Different fragment instances can share a current CID.

Matching starts at the actual anchor's output and complete native payload. MP
and GEN donor reference integers are replaced by propagation through the
anchor/current rows' actual references. Internal dependencies recursively
enumerate actual current rows at the resulting slot, primitive kind and output
FID. Shared donor nodes must map to the same current slot, formula and CID.
Every current primitive reference is strictly earlier than its owner slot.

An external dependency only matches its formula template to the formula demanded
by that actual current producer definition. Its slot is recorded; no external
owner is chosen or solved. ZERO templates match the entire current native ZERO
payload, including named assumption and UI/EQ-substitution fields. Any actual
ZERO definition ID is eligible, including duplicate native payloads with
different valid IDs. No lexicographically minimum duplicate-ID convention is
imposed. GEN literal variables remain literal. There is no alpha conversion or
goal/formula renaming. Native capture and current-Gamma validity are established
by the externally admitted catalogue, X and final M/N/B gates.

Term parameters match complete current term ASTs. Context parameters match a
one-hole context obtained by replacing exactly one position of a current term;
the identity context is allowed. Matching can produce several bindings and
local internal expansions. A proposal does not inspect the current whole goal,
instantiate the whole donor statement/proof, test a full cover, decode a target
proof, call B, or solve external receptors. Independent X verifies each concrete
partial expansion and state union before the scheduler uses any preference.

## Budgets, costs and fallback

Recognized lower-only setup/materialization limits are exactly:

```json
{"max_work":100000000,"wall_seconds":30.0,"max_families":4096,
 "max_instances":4096,"max_lines":16}
```

`max_families` caps both source-family count and exported-fragment count.
`max_lines` caps donor lines. `max_instances` does not restrict materialization;
it is an output bound per query. Every proposal query clips its local limits to
at most `max_work=2000000`, `wall_seconds=1.0`, `max_instances=32`. Query budgets
restart for each call, while `cumulative_work` includes setup and previous calls.
X may separately impose a cumulative admission budget. Caller callback/log caps
and the enclosing engine's work/time guards remain separate and disclosed.

The deterministic first at most 32 unique recommendations are returned in
traversal order, with `costs.proposal_cap_reached` when the cap is reached.
This is recommendation sampling, not complete enumeration of possible
instances. Reaching the output cap is `CANDIDATE_FRAGMENTS`; no finite absence is
claimed even when the returned list is empty. A local work/time/resource refusal
discards partial recommendations and returns `UNKNOWN` with `instances=[]`.
Malformed input returns `REJECTED` with `instances=[]`.

All query meter ticks, including validation, matching, copying, canonicalization
and refused cached-setup calls, invoke `charge(units)` if supplied. Exceptions
raised by that hook propagate unchanged to the engine, including its resource
stop. They are not converted into local rejections/refusals. Work is cooperative
implementation units, not hardware instructions or allocated bytes. Native
strings/keys, nested values and integer magnitudes are charged; input cycles and
nonfinite values are rejected, excessive depth is a resource refusal. Final
cooperative wall checks follow output/hash work.

Costs expose `work`, `seconds`, `cumulative_work`, `query_count`, `setup_seconds`,
`fragments_examined`, `candidate_rows_examined`, `internal_nodes_examined`,
`receptor_demands_examined`, `instances`, and `proposal_cap_reached`. Setup index
construction is charged outside engine callbacks and must be included in method
costs. No timing, memory, success, transfer or RL outcome is asserted by this
Source-only API.

All recommendations are ordering advice after the base graph's global dead,
forced and earliest-generation checks. No model row, primitive branch, mandatory
mark or existing filter is removed. Unknown/refused proposals use complete base
fallback. Current-state compatibility must be rechecked after every rollback;
these immutable local indexes are not a cache of state legality.
