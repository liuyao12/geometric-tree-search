"""Passive saved-byte/projection audit. Never imports a scientific module.

No point transition, proof decode, logical check, search or schema matching is
replayed. Scientific receipt validity is conditional on the frozen reviewed
producers; this audit binds those receipts to their actual inputs and processes.
"""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = 'protocol/frozen-protocol-v1.json'
AUDIT = 'publication/saved-data-audit-v1.json'
DATA = 'data/report-data-v1.json'
CASES = ('unary-transfer', 'chained-equality')
METHODS = ('rank-only', 'open-fragments', 'conventional')
PHASES = ('qualify', 'materialize') + tuple(p for c in CASES for p in
    ('prepare-' + c,) + tuple('evaluate-' + c + '-' + m for m in METHODS))
SEMANTIC_FIELDS = ('statement', 'proof', 'slots', 'slot_to_native', 'native_to_slot',
    'reference_mapping', 'proof_dag', 'selected', 'selected_sha256', 'original_statement_sha256', 'scope')
RULES = ('axiom', 'refl', 'instantiate', 'eq_subst', 'distribute', 'tautology', 'mp', 'generalize')
MAX_JSON = 134217728
MASTER_SHA = 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
LIMITATION = ('Passive byte/content associations, not scientific replay. Native truth and complete '
    'semantic-event assurance are separate frozen-producer receipts. Large runs expose actual '
    'endpoints and semantic events, not intermediate producer map qualification. UNKNOWN or '
    'failed-process prefixes never become a proof or refutation. Fragment guidance leaves '
    'external receptors unresolved and retains full primitive fallback; the conventional '
    'control lacks the library. No RL, speed advantage or universal-schema claim.')


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(value):
    h = hashlib.sha256()
    for part in json.JSONEncoder(sort_keys=True, ensure_ascii=True,
            separators=(',', ':'), allow_nan=False).iterencode(value):
        h.update(part.encode('ascii'))
    h.update(b'\n')
    return h.hexdigest()


def same(a, b, why):
    need(wire(a) == wire(b), why)


def path(name):
    need(type(name) is str and name and not Path(name).is_absolute()
         and '..' not in name.split('/'), 'RELATIVE_CURRENT_PATH:' + str(name))
    p = ROOT / name
    need(not p.is_symlink() and p.resolve().is_relative_to(ROOT), 'CURRENT_CONTAINMENT:' + name)
    return p


def pin(p):
    h, size = hashlib.sha256(), 0
    with p.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            size += len(block); h.update(block)
    return dict(bytes=size, sha256=h.hexdigest())


def ref(name):
    return dict(path=name, **pin(path(name)))


PINS, VISITED, EXTERNAL = {}, set(), []


def exact(r):
    need(type(r) is dict and {'path', 'bytes', 'sha256'} <= set(r)
         and type(r['bytes']) is int and r['bytes'] >= 0, 'THREE_FIELD_REFERENCE')
    actual = ref(r['path'])
    same(actual, {k: r[k] for k in ('path', 'bytes', 'sha256')}, 'REFERENCE_BYTES:' + r['path'])
    if r['path'] in PINS:
        same(actual, PINS[r['path']], 'REFERENCE_CHANGED:' + r['path'])
    PINS[r['path']] = actual
    return actual


def load(name):
    p = path(name)
    with (gzip.open(p, 'rb') if p.suffix == '.gz' else p.open('rb')) as stream:
        raw = stream.read(MAX_JSON + 1)
    need(len(raw) <= MAX_JSON, 'PASSIVE_JSON_ALLOCATION_BOUND:' + name)
    value = json.loads(raw)
    return value


def read_ref(r):
    exact(r)
    need(r.get('complete_json', True) is True, 'COMPLETE_JSON_REFERENCE:' + r['path'])
    return load(r['path'])


def all_refs(value):
    """Only authenticate current references; historical absolute metadata is explicit."""
    todo = [value]
    while todo:
        v = todo.pop()
        if type(v) is dict:
            if {'path', 'bytes', 'sha256'} <= set(v):
                if Path(v['path']).is_absolute():
                    EXTERNAL.append({k: v[k] for k in ('path', 'bytes', 'sha256')})
                else:
                    exact(v)
                    if v['path'] not in VISITED and v.get('complete_json', True) is True:
                        VISITED.add(v['path'])
                        # Frozen review/source ancestry is bytes-only heritage,
                        # never an implicit import of the old run's namespace.
                        if v['path'].startswith(('data/', 'run/')) and v['path'].endswith(('.json', '.json.gz')):
                            todo.append(load(v['path']))
            todo.extend(v.values())
        elif type(v) is list:
            todo.extend(v)


def output(name, value):
    p = path(name); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as stream:
        for part in json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                separators=(',', ':'), allow_nan=False).iterencode(value):
            stream.write(part.encode('ascii'))
        stream.write(b'\n')
    return ref(name)


def frozen():
    protocol = load(PROTOCOL)
    need(protocol['schema'] == 'Open-fragment-composition-protocol-v1'
         and protocol['status'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'FROZEN_PROTOCOL')
    same(protocol['phases'], list(PHASES), 'EXACT_TEN_PHASES')
    admission = load('review/root-source-admission-v1.json')
    need(admission['status'] == 'PASS_SOURCE_REVIEW_BEFORE_FREEZE', 'SOURCE_ADMISSION')
    names = {'review/root-source-admission-v1.json'}
    for folder in ('source', 'reference', 'input', 'plan'):
        for p in (ROOT / folder).rglob('*'):
            need(not p.is_symlink(), 'NO_SCIENTIFIC_SYMLINK')
            if p.is_file():
                need(p.suffix != '.pyc' and '__pycache__' not in p.parts, 'NO_BYTECODE')
                names.add(p.relative_to(ROOT).as_posix())
    names.update(r['path'] for r in admission['reviewed'])
    same(sorted(names), sorted(r['path'] for r in protocol['files']), 'EXACT_FROZEN_FILE_SET')
    need(len(names) == len(protocol['files']), 'UNIQUE_FROZEN_FILES')
    for r in protocol['files']:
        exact(r)
    for r in admission['reviewed']:
        exact(r)
    runtime = protocol['runtime']; executable = Path(sys.executable).resolve()
    same(runtime['executable'], dict(path=str(executable), **pin(executable)), 'CURRENT_RUNTIME_BINARY')
    need(runtime['version'] == sys.version and runtime['isolated'] == sys.flags.isolated == 1
         and runtime['no_site'] == sys.flags.no_site == 1
         and runtime['dont_write_bytecode'] is sys.dont_write_bytecode is True, 'CURRENT_RUNTIME_FLAGS')
    master = protocol['master']; same(pin(Path(master['path'])), {k: master[k] for k in ('bytes', 'sha256')}, 'CURRENT_MASTER')
    need(master['sha256'] == MASTER_SHA, 'MASTER_SHA')
    same(pin(path('reference/basic-tiling-algorithm.md')), pin(Path(master['path'])), 'MASTER_COPY')
    return protocol, dict(file_count=len(names), exact_set=True, current_runtime=runtime,
                          current_master=master)


def process(name, protocol):
    refs, values, parse_errors = {}, {}, {}
    for key, filename in (('started', 'started.json'), ('invocation', 'invocation.json'),
                          ('observer', 'observer.json'), ('result', '../../data/' + name + '/result.json')):
        target = 'data/' + name + '/result.json' if key == 'result' else 'run/' + name + '/' + filename
        if path(target).exists():
            refs[key] = ref(target)
            try:
                values[key] = load(target)
            except (ValueError, UnicodeError, EOFError, gzip.BadGzipFile) as error:
                parse_errors[key] = type(error).__name__ + ':' + str(error)[:1024]
            else:
                all_refs(values[key])
    if path('run/' + name + '/stdout.log').exists():
        refs['log'] = ref('run/' + name + '/stdout.log')
    started, invocation, observer = (values.get(k) for k in ('started', 'invocation', 'observer'))
    available = [v for v in (started, invocation, observer) if v is not None]
    for v in available:
        need(v['phase'] == name and type(v['pid']) is int and v['pid'] > 0, 'PHASE_PID:' + name)
    pid = available[0]['pid'] if available else None
    need(all(v['pid'] == pid for v in available), 'OWNED_PID_ASSOCIATION:' + name)
    if started:
        same(started['protocol'], ref(PROTOCOL), 'STARTED_PROTOCOL:' + name)
    if observer:
        same(observer['log'], refs['log'], 'OBSERVER_LOG:' + name)
    result = values.get('result')
    if invocation:
        if result is not None:
            need(invocation['scientific_status'] == result['status'], 'INVOCATION_RESULT_STATUS:' + name)
        if invocation['result'] is not None:
            need(invocation['result'].get('complete_json') is True and result is not None, 'COMPLETE_RESULT:' + name)
            exact(invocation['result']); same(refs['result'], {k: invocation['result'][k] for k in ('path', 'bytes', 'sha256')}, 'RESULT_REF:' + name)
    clean = bool(not parse_errors and started and invocation and observer and result is not None
        and invocation['status'] == 'COMPLETE' and invocation['error_type'] is None
        and observer['status'] == 'TERMINAL' and type(observer['native_exit_code']) is int
        and observer['native_exit_code'] == 0
        and all(observer[k] is None for k in ('guard_reason', 'observer_error', 'reap_error', 'postcheck_error'))
        and invocation['postcheck_error'] is None
        and observer['frozen_postcheck'] == invocation['frozen_postcheck'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS')
    admitted = clean and result['status'] == protocol['admitted_statuses'][name]
    phase = dict(name=name, pid=pid, native_exit_code=None if observer is None else observer['native_exit_code'],
        scientific_status=None if result is None else result['status'], process_clean=clean,
        scientific_admitted=admitted, process_status='NOT_ATTEMPTED' if not available else
        'COMPLETE' if clean else 'FAILED_OR_INCOMPLETE', refs=refs,
        costs=dict(observed_process_seconds=None if observer is None else observer['seconds'],
            worker_seconds=None if invocation is None else invocation['seconds'],
            module_seconds=None if result is None else result.get('module_seconds')),
        observer=observer, parse_errors=parse_errors)
    return phase, result


def normalized(model):
    return dict(model, roots=sorted(model['roots']), seed=dict(t=sorted(model['seed']['t']), m=sorted(model['seed']['m'])),
        inventory=dict(model['inventory'], placements=sorted((dict(r, t=sorted(r['t']), m=sorted(r['m']))
            for r in model['inventory']['placements']), key=lambda r: r['id'])),
        pair_nogoods=sorted(model['pair_nogoods']), unary_nogoods=sorted(model['unary_nogoods']))


def library_data(result, admitted):
    answer = dict(status='NOT_ADMITTED', library=None, refs={} if result is None else result['refs'],
                  costs={} if result is None else result.get('costs', {}))
    if not admitted:
        return answer
    lib = read_ref(result['refs']['library']); answer['status'] = lib['status']
    if lib['status'] != 'MATERIALIZED':
        return answer
    receipt = read_ref(result['refs']['receipt'])
    if receipt['status'] != 'VERIFIED_MATERIALIZATION':
        answer['status'] = receipt['status']
        return answer
    need(receipt['bindings']['library_sha256'] == sha(lib)
         and receipt['bindings']['source_library_sha256'] == lib['source_library_sha256']
         == sha(load('input/donor-library.json.gz')), 'LIBRARY_SOURCE_HASHES')
    need(read_ref(result['refs']['qualification'])['status'] == 'QUALIFIED', 'LIBRARY_QUALIFICATION')
    need(receipt['fragments'] == result['fragment_count'] == len(lib['fragments']), 'FRAGMENT_COUNTS')
    for fragment in lib['fragments']:
        need(set(fragment) == {'id', 'family_id', 'cluster_id', 'root', 'members', 'lines', 'receptors', 'parameters'}, 'ERASED_FRAGMENT_FIELDS')
        need(2 <= len(fragment['members']) <= 4 and len(fragment['members']) < lib['donor_lines']
             and fragment['receptors'] and [i for i, line in fragment['lines']] == fragment['members'], 'OPEN_PROPER_FRAGMENT')
        need(fragment['id'] == sha({k: v for k, v in fragment.items() if k != 'id'}), 'FRAGMENT_ID')
    answer.update(status='VERIFIED_MATERIALIZATION', library=lib)
    return answer


def preparation(case, result, admitted):
    base = 'data/cases/' + case
    answer = dict(status='NOT_ADMITTED', refs={} if result is None else result['refs'], costs={})
    if not admitted or result['preparation_status'] != 'PREPARED':
        return answer, None, None, None
    p = read_ref(result['refs']['preparation']); refs = p['refs']
    need(p['status'] == 'PREPARED', 'PREPARED_STATUS')
    declaration, compiled, generation = (read_ref(refs[k]) for k in ('declaration', 'compiled', 'generation'))
    same(declaration, load('input/case-' + case + '-v1.json'), 'EXACT_CASE_DECLARATION')
    r, bridge, q, prepared, n = (read_ref(refs[k]) for k in ('rf_receipt', 'bridge', 'bridge_receipt', 'prepared', 'model_receipt'))
    need(r['status'] == q['status'] == n['status'] == 'VERIFIED', 'FULL_RF_BRIDGE_MODEL_RECEIPTS')
    need(r['declaration_sha256'] == sha(declaration)
         and r['compiled_core_sha256'] == generation['compiled_core_sha256'], 'RF_RECEIPT_ASSOCIATIONS')
    same(q['bindings'], bridge['bindings'], 'BRIDGE_BINDINGS')
    same(prepared['catalogue'], bridge['catalogue'], 'PREPARED_FULL_CATALOGUE')
    same(prepared['statement'], declaration['problem'], 'EXACT_ORIGINAL_STATEMENT')
    need(n['catalogue_sha256'] == sha(bridge['catalogue'])
         and n['original_statement_sha256'] == sha(declaration['problem'])
         and n['model_sha256'] == sha(prepared['model']), 'MODEL_RECEIPT_ASSOCIATIONS')
    zeros = read_ref(refs['zero_native_receipts'])
    need(len(zeros) == len(compiled['zero_instances']) == p['ZERO_checks'], 'ALL_ZERO_RECEIPTS')
    for zero, checked in zip(compiled['zero_instances'], zeros):
        need(checked['id'] == zero['id'] and checked['formula_id'] == zero['formula_id']
             and checked['native_line_sha256'] == sha(zero['line']), 'ZERO_LITERAL_ASSOCIATION')
        native_counts(checked['receipt'], [zero['line']])
    model = read_ref(refs['model']); migration = read_ref(refs['migration'])
    need(migration['status'] == 'VERIFIED_LITERAL_SCHEMA_MIGRATION'
         and migration['prepared_model_sha256'] == sha(prepared['model'])
         and migration['migrated_model_sha256'] == sha(model), 'MIGRATION_BINDING')
    same(model['inventory'], prepared['model']['inventory'], 'MIGRATED_FULL_INVENTORY')
    answer.update(status='PREPARED', census=p['census'], costs=p['costs'], refs=refs,
                  ZERO_checks=len(zeros), declaration=declaration)
    rank = read_ref(result['refs']['rank'])
    if rank['status'] != 'RANK_ADMITTED':
        return answer, prepared, None, rank
    analysis, receipt, marked, control = (read_ref(rank['refs'][k]) for k in
        ('analysis', 'rank_receipt', 'marked_model', 'control_model'))
    need(receipt['status'] == 'VERIFIED_REDUNDANT_RANK_CONSTRAINT' and rank['activation_admitted'] is True
         and receipt['bounded_absence'] is False and receipt['learned'] is False, 'RANK_ADMISSION')
    same(receipt['bindings'], analysis['bindings'], 'RANK_PACKET_BINDING')
    same(receipt['model_bindings'], {k: sha(v) for k, v in
        (('base', model), ('marked', marked), ('control', control))}, 'RANK_LANE_BINDINGS')
    same(rank['model_bindings'], receipt['model_bindings'], 'RANK_RESULT_BINDINGS')
    need(rank['forbidden_count'] == len(analysis['forbidden']), 'FORBIDDEN_COUNTS')
    same([r['id'] for r in model['inventory']['placements']], [r['id'] for r in marked['inventory']['placements']], 'FULL_RANK_INVENTORY')
    if result['qualification_status'] == 'QUALIFIED':
        need(read_ref(result['refs']['qualification'])['status'] == 'QUALIFIED', 'LOCAL_INSTANCE_QUALIFICATION')
    return answer, prepared, marked, rank


def native_counts(receipt, proof):
    need(receipt['status'] == 'VERIFIED' and type(receipt['checked_lines']) is int
         and receipt['checked_lines'] == len(proof), 'NATIVE_WHOLE_PROOF')
    counts = collections.Counter(line['rule'] for line in proof)
    need(set(counts) <= set(RULES) and set(receipt['rule_counts']) == set(RULES), 'NATIVE_RULE_KEYS')
    for rule in RULES:
        value = receipt['rule_counts'][rule]
        need(type(value) is int and value >= 0 and value == counts[rule], 'NATIVE_RULE_COUNT:' + rule)


def target_proof(case, method, result, prepared, model, selected):
    refs = result['native_refs']
    m, n, projection, proof, b = (read_ref(refs[k]) for k in
        ('adapter_decoded', 'independent_decoded', 'projection', 'native_proof', 'native_receipt'))
    need(m['status'] == n['status'] == 'UNVERIFIED_NATIVE_CERTIFICATE'
         and projection['status'] == 'VERIFIED_LITERAL_PROJECTION', 'DECODE_PROJECTION_STATUSES')
    for key in SEMANTIC_FIELDS:
        same(m[key], n[key], 'EXACT_M_N:' + key)
    same(m['statement'], prepared['statement'], 'ORIGINAL_NATIVE_STATEMENT')
    same(m['selected'], sorted(selected), 'EXACT_NATIVE_SELECTED')
    same(m['proof'], proof, 'NATIVE_PROOF_BYTES_CONTENT')
    need(proof and wire(proof[-1]['formula']) == wire(prepared['statement']['goal']), 'LAST_NATIVE_GOAL')
    need(projection['selected_sha256'] == m['selected_sha256'] == sha(sorted(selected))
         and projection['adapter_decoded_sha256'] == sha(m)
         and projection['independent_decoded_sha256'] == sha(n), 'PROJECTION_HASH_BINDINGS')
    need(m['original_statement_sha256'] == sha(prepared['statement'])
         and projection['prepared_scope'] == prepared['binding']['scope'], 'NATIVE_ORIGINAL_BINDINGS')
    native_counts(b, proof)
    need(result['native_lines'] == len(proof), 'RESULT_NATIVE_LINE_COUNT')
    rows = {r['id']: r for r in model['inventory']['placements']}
    need(len(selected) == len(set(selected)) and set(selected) <= set(rows), 'SELECTED_CURRENT_MEMBERSHIP')
    return dict(id=case + '--' + method, role='SPECIALIZED_CONTROL' if method == 'conventional' else 'POINT_SEARCH',
        lines=len(proof), statement_sha256=sha(m['statement']), selected_sha256=sha(sorted(selected)),
        proof_sha256=sha(proof), proof_ref=refs['native_proof'], native_ref=refs['native_receipt'],
        statement=m['statement'], proof=proof, selected=sorted(selected), selected_rows=[rows[c] for c in sorted(selected)],
        **{key: m[key] for key in ('slots', 'slot_to_native', 'native_to_slot', 'reference_mapping', 'proof_dag')})


def event_binding(raw, semantic, model, expected_limits):
    model_sha = sha(normalized(model))
    if raw['model_sha256'] is not None:
        need(raw['model_sha256'] == model_sha, 'RAW_NORMALIZED_MODEL')
    events, extent = raw['events'], raw['event_extent']
    need(len(events) == extent['retained'] <= extent['total'], 'EVENT_EXTENT')
    need([e['seq'] for e in events] == list(range(len(events))), 'EVENT_SEQUENCE')
    digest = hashlib.sha256()
    for event in events:
        digest.update(wire(event))
    if extent['retained'] == extent['total']:
        need(digest.hexdigest() == extent['sha256'], 'COMPLETE_EMITTED_EVENT_HASH')
    for key, value in expected_limits.items():
        same(raw['limits'][key], value, 'EXACT_ENGINE_LIMIT:' + key)
    if semantic['status'] == 'VERIFIED':
        need(semantic['run_status'] == raw['status'] and semantic['model_sha256'] == model_sha
             and semantic['event_sha256'] == extent['sha256'] and semantic['event_coverage'] == 'COMPLETE'
             and len(events) == extent['total'], 'SEMANTIC_COMPLETE_ASSOCIATION')
        need(semantic['claim'] == ('SEMANTIC_COMPLETE_SAT_CERTIFICATE' if raw['status'] == 'SAT'
             else 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION'), 'SEMANTIC_SCOPE')
    else:
        need(semantic.get('bounded_absence') is False, 'NO_UNKNOWN_ABSENCE')
    if raw['status'] == 'UNKNOWN':
        need(not raw['selected'] and raw['certificate'] is None and semantic['status'] != 'VERIFIED', 'UNKNOWN_HAS_NO_FINAL_PROOF')
    if raw['status'] == 'SAT':
        same(raw['certificate']['placements'], [r for r in model['inventory']['placements'] if r['id'] in set(raw['selected'])], 'CERTIFICATE_SELECTED_ROWS')
    return events


def policy_projection(log, counts, raw, model, library, prepared, final_admitted):
    events = raw['events']; branches = [e for e in events if e['kind'] == 'BRANCH']
    need(type(log) is list and len(log) <= 128 and len(log) <= counts['callbacks'], 'BOUNDED_POLICY_LOG')
    need(counts['callbacks'] == raw['stats']['ordering_calls'], 'CALLBACK_ORDERING_COUNT')
    need(len(log) <= len(branches) + (1 if raw['status'] == 'UNKNOWN' else 0), 'PENDING_CALLBACK_BOUND')
    final = set(raw['selected']) if final_admitted else None
    selected_rows = {json.loads(c)[0]: c for c in final} if final is not None else {}
    forms = prepared['catalogue']['formulas']
    definitions = {kind: {d['id']: d for d in prepared['definitions'][key]}
                   for kind, key in (('ZERO', 'zeros'), ('MP', 'mp'), ('GEN', 'gen'))}
    identity = dict(model_sha256=sha(normalized(model)), statement_sha256=sha(prepared['statement']),
                    library_sha256=sha(library), prepared_scope=prepared['binding']['scope'])
    metrics = collections.Counter(); examples = []; known = {}
    rows = {r['id']: r for r in model['inventory']['placements']}
    for i, item in enumerate(log):
        request = item['request']; need(request['model_sha256'] == identity['model_sha256'], 'POLICY_REQUEST_MODEL')
        branch = branches[i] if i < len(branches) else None
        if branch:
            same(request['legal'], branch['data']['legal'], 'POLICY_ACTUAL_BRANCH_LEGAL')
            need(request['point'] == branch['point'] and request['generation'] == branch['data']['generation'], 'POLICY_ACTUAL_BRANCH_POINT')
            same(branch['data']['order'], item['preferred'] + [c for c in request['legal'] if c not in item['preferred']], 'POLICY_COMPLETE_FALLBACK_ORDER')
        for proposal in item['proposals']:
            packet = proposal['packet']; metrics['offer_queries_logged'] += 1
            if packet['status'] != 'CANDIDATE_FRAGMENTS':
                continue
            same(packet['bindings'], {k: identity[k] for k in ('prepared_scope', 'model_sha256', 'library_sha256')} |
                 dict(anchor_cid=proposal['anchor']), 'LOCAL_PROPOSAL_BINDING')
            need(len(packet['instances']) <= 32, 'LOCAL_PROPOSAL_CAP')
            metrics['offered_instances_logged'] += len(packet['instances'])
            for instance in packet['instances']:
                need(instance['id'] == sha({k: v for k, v in instance.items() if k != 'id'}), 'LOCAL_INSTANCE_ID')
                known[instance['id']] = instance
        chosen = item['chosen']
        if chosen is not None:
            need(chosen['id'] == sha({k: v for k, v in chosen.items() if k != 'id'}), 'CHOSEN_INSTANCE_ID')
            known[chosen['id']] = chosen
        admitted_here, compatible_here = set(), {}
        for checked in item['checked']:
            receipt = checked['receipt']; instance = known.get(checked['instance_id'])
            need(instance is not None, 'CHECKED_OFFER_OR_PRIOR_CHOSEN_INSTANCE')
            digest = sha(instance)
            if checked['stage'] == 'admit' and receipt['status'] == 'VERIFIED_INSTANCE':
                metrics['admitted_instance_occurrences_logged'] += 1
                admitted_here.add(instance['id'])
                same(receipt['bindings'], dict(identity, instance_sha256=digest, fragment_id=instance['fragment_id']), 'X_ADMISSION_BINDING')
            if checked['stage'] == 'state' and receipt['status'] == 'COMPATIBLE':
                metrics['compatible_instance_occurrences_logged'] += 1
                compatible_here[instance['id']] = receipt
                union = sorted(set(request['selected']) | {c for j, c in instance['line_cids']})
                same(receipt['bindings'], dict(model_sha256=identity['model_sha256'], instance_sha256=digest,
                    selected_sha256=sha(request['selected']), excluded_sha256=sha(request['excluded']), union_sha256=sha(union)), 'X_CURRENT_STATE_BINDING')
        if chosen is None:
            need(not item['preferred'], 'NO_CHOSEN_NO_PREFERENCE')
            continue
        metrics['chosen_occurrences_logged'] += 1
        need(chosen['id'] in admitted_here and chosen['id'] in compatible_here, 'CHOSEN_ACTUAL_X_ADMISSION_AND_STATE')
        same(item['preferred'], compatible_here[chosen['id']]['preferred'], 'ACTUAL_COMPATIBLE_PREFERENCE')
        cids = {c for j, c in chosen['line_cids']}
        need(item['preferred'] and set(item['preferred']) <= cids & set(request['legal']), 'CHOSEN_LEGAL_FRAGMENT_MEMBERS')
        placed = None
        if branch and branch['seq'] + 1 < len(events):
            following = events[branch['seq'] + 1]
            if following['kind'] == 'PLACED':
                placed = following
                need(following['candidate'] == branch['data']['order'][0], 'ACTUAL_FIRST_ORDERED_PLACED')
        actual = placed is not None and placed['candidate'] in cids
        metrics['actual_chosen_first_placed_occurrences'] += int(actual)
        surviving = None if final is None else sorted(cids & final)
        all_survive = None if final is None else cids <= final
        receptors = []
        for donor, slot, formula in chosen['receptors']:
            owner = selected_rows.get(slot) if all_survive else None
            fulfilled = None
            if all_survive is not None:
                fulfilled = False
                if owner is not None:
                    _, kind, did, refs = json.loads(owner)
                    if kind != 'PAD':
                        output = definitions[kind][did]['output']
                        fulfilled = wire(forms[output - 1]) == wire(formula)
            receptors.append(dict(donor_index=donor, slot=slot, formula=formula,
                                  owner_cid=owner, fulfilled=fulfilled))
        complete = None if all_survive is None else bool(all_survive and all(r['fulfilled'] for r in receptors))
        metrics['all_internal_survive_occurrences'] += int(all_survive is True)
        metrics['all_receptors_fulfilled_occurrences'] += int(complete is True)
        if len(examples) < 8:
            examples.append(dict(callback_index=i, instance=chosen, request=request, branch_event=branch,
                placed_event=placed, actual_first_placed=actual, final_internal_cids=surviving,
                all_internal_survive=all_survive, receptors=receptors, all_receptors_fulfilled=complete,
                internal_rows=[rows[c] for j, c in chosen['line_cids']]))
    for key, measured in (('proposals', 'offer_queries_logged'), ('candidate_instances', 'offered_instances_logged'),
                          ('admitted', 'admitted_instance_occurrences_logged'), ('compatible', 'compatible_instance_occurrences_logged')):
        need(type(counts[key]) is int and counts[key] >= metrics[measured], 'POLICY_LOG_PREFIX_COUNTER:' + key)
        if len(log) == counts['callbacks']:
            need(counts[key] == metrics[measured], 'COMPLETE_POLICY_COUNTER:' + key)
    projected_metrics = {key: metrics[key] for key in ('offer_queries_logged', 'offered_instances_logged',
        'admitted_instance_occurrences_logged', 'compatible_instance_occurrences_logged',
        'chosen_occurrences_logged', 'actual_chosen_first_placed_occurrences',
        'all_internal_survive_occurrences', 'all_receptors_fulfilled_occurrences')}
    if not final_admitted:
        for key in ('all_internal_survive_occurrences', 'all_receptors_fulfilled_occurrences'):
            projected_metrics[key] = None
    return dict(counts=counts, coverage=dict(logged_callbacks=len(log), reported_callbacks=counts['callbacks'],
        branch_events=len(branches), unlogged_callbacks=counts['callbacks'] - len(log),
        pending_callback_possible=counts['callbacks'] > len(branches), displayed_examples=len(examples),
        examples_total=metrics['chosen_occurrences_logged'], raw_final_proof_admitted=final_admitted),
        metrics=projected_metrics, examples=examples,
        scope='Literal completed-log/BRANCH/next-PLACED associations and admitted final CID membership; no transition replay, causal speed claim or inference about unlogged proposals. A receptor is fulfilled only when the whole chosen fragment survives in an admitted final proof and its actual selected slot owner has that literal formula.')


def method_data(case, method, phase, result, prepared, model, library, protocol):
    row = dict(id=case + '--' + method, method=method, phase=phase['name'], process_admitted=phase['scientific_admitted'],
        admitted_status='NOT_ATTEMPTED' if result is None else 'UNADMITTED_PROCESS' if not phase['scientific_admitted'] else result.get('admitted_status', 'UNKNOWN'),
        raw_status=None, search_status=None, semantic_status=None, reason=None, stats={}, costs={} if result is None else result.get('costs', {}),
        refs={} if result is None else result.get('refs', {}), events=[], event_coverage=None, policy=None, native_proof_id=None)
    if not phase['scientific_admitted'] or model is None or prepared is None:
        prefix = 'data/engine/open-' + case + '-' + method
        for key in ('model', 'raw', 'semantic', 'observations'):
            name = prefix + '/' + key + '.json.gz'
            if path(name).exists():
                row['refs']['unadmitted_' + key] = ref(name)
        return row, None
    all_refs(result)
    if not result.get('refs'):
        row['reason'] = result.get('reason')
        return row, None
    selected, raw = None, None
    if method == 'conventional':
        search = read_ref(result['refs']['search']); row['search_status'] = search['status']; row['reason'] = search.get('reason')
        if search['status'] == 'FOUND_CANDIDATE':
            selected = search['selected']
    else:
        refs = result['refs']; actual_model, raw, semantic = (read_ref(refs[k]) for k in ('model', 'raw', 'semantic'))
        same(actual_model, model, 'METHOD_IDENTICAL_RANK_MARKED_MODEL')
        events = event_binding(raw, semantic, model, protocol['limits']['scientific']['engine'])
        need(result['raw_status'] == raw['status'] and result['semantic_status'] == semantic['status'], 'METHOD_RAW_STATUS')
        same(result['stats'], raw['stats'], 'METHOD_ACTUAL_RAW_STATS')
        row.update(raw_status=raw['status'], semantic_status=semantic['status'], reason=raw['reason'], stats=raw['stats'],
            events=events[:2048], event_coverage=dict(displayed=min(2048, len(events)), retained=len(events),
                emitted=raw['event_extent']['total'], sha256=raw['event_extent']['sha256'],
                complete_emitted_extent=len(events) == raw['event_extent']['total'],
                complete_search=raw['status'] in ('SAT', 'UNSAT') and semantic['status'] == 'VERIFIED'))
        if raw['status'] == 'SAT' and semantic['status'] == 'VERIFIED':
            selected = raw['selected']
    proof = None
    if result.get('admitted_status') == 'VERIFIED_NATIVE_POSITIVE':
        need(selected is not None, 'NATIVE_POSITIVE_POINT_OR_CONTROL_CANDIDATE')
        proof = target_proof(case, method, result, prepared, model, selected)
        row['native_proof_id'] = proof['id']
    if method == 'open-fragments' and 'policy_log' in result['refs']:
        row['policy'] = policy_projection(read_ref(result['refs']['policy_log']), result['policy_counts'], raw,
                                           model, library, prepared, proof is not None)
    return row, proof


def main():
    started = time.perf_counter(); protocol, closure = frozen()
    physical_outputs = []
    for folder in ('data', 'run'):
        for p in sorted((ROOT / folder).rglob('*')):
            need(not p.is_symlink(), 'NO_OUTPUT_SYMLINK')
            if p.is_file() and p.relative_to(ROOT).as_posix() != DATA:
                r = ref(p.relative_to(ROOT).as_posix()); exact(r); physical_outputs.append(r)
    phases, results = [], {}
    for name in PHASES:
        phase, result = process(name, protocol); phases.append(phase); results[name] = result
    phase_map = {p['name']: p for p in phases}
    materialization = library_data(results['materialize'], phase_map['materialize']['scientific_admitted'])
    cases, proofs = [], []
    for case in CASES:
        prepared_row, prepared, model, rank = preparation(case, results['prepare-' + case], phase_map['prepare-' + case]['scientific_admitted'])
        case_row = dict(id=case, declaration=load('input/case-' + case + '-v1.json'), preparation=prepared_row,
            rank=dict(status='NOT_ADMITTED' if rank is None else rank['status'], forbidden_count=None if rank is None else rank.get('forbidden_count'),
                refs={} if rank is None else rank['refs'], costs={} if rank is None else rank.get('costs', {})), methods=[])
        for method in METHODS:
            name = 'evaluate-' + case + '-' + method
            row, proof = method_data(case, method, phase_map[name], results[name], prepared, model,
                                    materialization['library'], protocol)
            case_row['methods'].append(row)
            if proof is not None:
                proofs.append(proof)
        cases.append(case_row)
    need(len({p['id'] for p in proofs}) == len(proofs), 'UNIQUE_NATIVE_TARGET_IDS')
    # Verify every discovered byte reference again after the data-only joins.
    for r in list(PINS.values()):
        exact(r)
    data = dict(schema='Open-receptor-report-data-v1', status='PASS_SAVED_DATA_PROJECTION', protocol=ref(PROTOCOL),
        frozen=closure, phases=phases, qualification=results['qualify'], materialization=materialization,
        cases=cases, native_proofs=proofs, limitations=LIMITATION)
    data_ref = output(DATA, data)
    metadata = [{k: p[k] for k in ('id', 'role', 'lines', 'statement_sha256', 'selected_sha256',
        'proof_sha256', 'proof_ref', 'native_ref')} for p in proofs]
    audit = dict(schema='Open-receptor-passive-audit-v1', status='PASS', protocol=ref(PROTOCOL),
        report_data=data_ref, frozen=closure, phases=phases, native_proofs=metadata,
        counts=dict(phase_positions=len(phases), clean_processes=sum(p['process_clean'] for p in phases),
            workflow_admitted=sum(p['scientific_admitted'] for p in phases), admitted_native_targets=len(proofs),
            erased_fragments=0 if materialization['library'] is None else len(materialization['library']['fragments']),
            physical_references=len(PINS)), artifact_pins=[PINS[k] for k in sorted(PINS)],
        physical_outputs=physical_outputs,
        external_absolute_metadata=EXTERNAL, seconds=time.perf_counter() - started,
        scientific_helper_calls=0, scope=LIMITATION)
    output(AUDIT, audit)
    print(json.dumps(dict(status='PASS', report_data=data_ref, audit=ref(AUDIT), counts=audit['counts'])), flush=True)


if __name__ == '__main__':
    main()
