# Independent Source peer: open-receptor reader

PASS. Complete Python/embedded HTML/JavaScript Source and full API read at these held pins:

- `publication/build_open_report_v1.py`: 30,998 bytes, SHA256 `0f10fbf357092f60e70b48358fff5c92005d7d06b1e4750b673f7ba51f2cc934`.
- `publication/report-API-v1.md`: 6,663 bytes, SHA256 `ddb34a3d91d7a0cbd1067cc496dc5b4be643576160fb54d39bb2c8120ca98cb5`.

No blocking Source finding. The builder is a thin stdlib saved-data consumer. It authenticates the audit-bound authoritative projection, exact frozen file/runtime/master association and artifact ledger; joins exact phase/native metadata; and preserves the proof bytes, selected-row IDs and whole native receipt associations. It performs no solver, proposer, checker, decoder or kernel replay. The public JSON retains the projection's fields, and build outputs are exclusive.

Only admitted native target records populate proof views. Missing, failed, guarded and UNKNOWN method selections clear proof/slot/table/download state; raw SAT or complete emitted events alone do not create a proof. Finder attribution distinguishes rank-only GCTS, local-fragment GCTS and the conventional control. Actual stop reasons and polling peaks retain their process scope; memory samples are not described as a measured allocation cause or OS out-of-memory diagnosis.

Fragment views consume only the erased local library, actual internal rows and boundary receptors. Choice views distinguish offered preference, actual next PLACED event, final shared CID survival and exact external owner fulfillment. Null final data stays unresolved. The fulfilled-first inspection policy and displayed/total counts are exposed; examples are not a success-rate sample. There is no inference of macro execution or necessity from an offer. Literal source payloads, maps and actual proof AST remain available; display aliases do not alter native data.

Formula rendering uses LaTeX through MathJax with serialized typesetting. Source names/formulas are escaped in rendered HTML and TeX paths. The scope explicitly identifies symbolic point owners, not a geometric tile or universal palette; it also discloses the unmatched conventional control, warm reuse, separate cost components, seen calibration, distinct bounds, no RL and no superiority conclusion. Final local UI/runtime rendering remains Root's later gate, not a result of this Source review.

Direct Source/API reading, byte/hash inspection and Python AST parsing only. No builder import or build, scientific import/call, replay, proof discovery, package, Git, network or sealed-file edit was performed.
