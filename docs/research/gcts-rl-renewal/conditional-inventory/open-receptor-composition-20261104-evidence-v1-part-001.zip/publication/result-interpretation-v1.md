# Interpretation of the completed first attempts

The saved-data audit passed with ten clean owned processes, four admitted native
method certificates and 650 erased proper fragments. There are two statements,
one previously examined calibration and one new nested-addition target. The
certificate count is not a count of four new theorems.

On the calibration, open guidance reduced branches from 293 to 73, but observed
owned-process time increased from 88.769 to 112.799 seconds. Matching consumed
55.398 seconds. The primitive conventional control completed in 12.207 seconds.
These are single attempts, not a statistical timing comparison. They provide no
speed advantage or distinctive GCTS advantage. No RL was used.

There is one concrete successful proper-fragment instance, selected at callbacks
71 and 72. Its instance ID is
`7dd3d104f8d92e16237787e534b61064a62fe47b7d7990816f5a3c558667e285`.
It has three internal placements at slots 3, 4 and 5, with outside receptors at
slots 1 and 2. At callback 71 the actual selected slots are 0, 6 and 7: both
external owners are still missing. They are also missing at callback 72. The
final admitted certificate contains all three internal placements and both
outside owners with the literal demanded formulas. The two fulfilled occurrence
counts therefore describe repeated use of **one** concrete fragment instance,
not two independent lemmas or multi-fragment theorem assembly. This demonstrates
finite partial reuse with genuinely open premises on a seen statement. No full
target derivation was supplied to the proposer or independent local checker.

For the new statement

\[
\forall x\;\operatorname{add}(\operatorname{add}(x,0),0)=x,
\]

both GCTS arms reached their unchanged engine time ceiling and remain UNKNOWN.
The conventional control found a nine-line native-checked proof in an observed
8.487 seconds. Open guidance exhausted its prospectively declared 1,024 offer
queries, disabled further preferences and continued with primitive fallback.
Its 28 retained callback payloads precede 994 unlogged callbacks that use that
fallback. Complete engine event streams remain retained; a fully retained
UNKNOWN trace is not a proof or refutation. No limits were changed and no
scientific attempt was rerun.

All ten processes stayed under the unchanged RSS polling guard; the largest
observed process peak was 1,082,523,648 bytes. This is evidence for this cohort,
not proof that isolation solves arbitrary single-method memory pressure.

The useful next gate is to improve local indexing and compare with a conventional
planner given exactly the same erased fragments and primitive fallback. Actual
assembly of multiple separately bound fragments on new statements remains to
be demonstrated. Learned failure markings, RL proposal training, broad theorem
benchmarks and a single fixed universal Wang palette remain open research work.
This interpretation uses only saved bytes and the admitted passive projection;
no scientific helper, proof decoder, checker or search was called again.
