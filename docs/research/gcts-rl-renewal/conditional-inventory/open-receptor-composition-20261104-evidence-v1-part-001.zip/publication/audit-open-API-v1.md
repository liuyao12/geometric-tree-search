# Passive open-receptor saved-data audit

Source-only until Root and independent peer review. The script imports stdlib
only and never calls scientific helpers. Execute once, after the owned phase
attempts have ended, using the frozen protocol's Python executable:

```text
PYTHON -I -S -B publication/audit_open_saved_data_v1.py
```

Outputs are exclusive; existing outputs cause refusal:

- `data/report-data-v1.json`: schema `Open-receptor-report-data-v1`, status
  `PASS_SAVED_DATA_PROJECTION`.
- `publication/saved-data-audit-v1.json`: schema
  `Open-receptor-passive-audit-v1`, status `PASS`.

The audit's `report_data` reference authenticates the projection bytes. There is
no circular projection-to-audit hash. Audit failure raises without a PASS
receipt; any already-written prefix is retained and never silently overwritten.

The script binds the exact current frozen scientific file set, reviewed Source
notes, runtime/version/flags/binary, current master and master copy. It binds
all ten declared process positions using available started/invocation/observer
PID, phase, protocol, result bytes, complete JSON indication, log bytes, actual
native exit, guards and Source postcheck. Workflow admission and native proof
admission are separate. Missing positions are `NOT_ATTEMPTED`; failed or partial
positions retain physical outputs and have no admitted proof. Invalid partial
JSON records are byte-bound and reported as parse errors. A claimed complete
result whose bytes do not match is an audit error.

All current `data/` and `run/` files are physically hashed, including unreferenced
failed prefixes. Every discovered current output reference is authenticated;
current data/run JSON references are recursively traversed. Static historical
protocol/admission files are byte-only heritage: their nested old relative
paths are not imported into the current namespace. Absolute historical metadata
is separately listed, never treated as a copied scientific input. Current
runtime/master paths are explicitly verified. No old proof or bank is loaded as
a scientific input by this audit.

The scientific content joins include exact declared statements, full RF/bridge/
model receipt hashes and all native ZERO receipts, materialization provenance
and fragment erasure/IDs/counts, rank packet/model receipt hashes and full CID
inventory retention. Semantic receipts bind actual model and emitted event
hashes; complete event payload is distinguished from complete search. Raw
UNKNOWN never supplies a final proof/refutation. Large-run intermediate maps
are not relabeled as independently observed/verified.

For an admitted positive, exact selected CIDs bind M/N's complete listed
semantic fields, projection hashes, original statement, proof bytes, final goal,
native B whole-line count and every rule counter including zeros. The audit
does not decode, verify proof rules, reconstruct graph transitions or replay
the scheduler. These are saved-data joins to separately frozen admitted
scientific receipts, not a second independent execution of their algorithms.

Projection fields are `protocol,frozen,phases,qualification,materialization,
cases,native_proofs,limitations`. Each phase has
`name,pid,native_exit_code,scientific_status,process_clean,scientific_admitted,
process_status,refs,costs,observer,parse_errors`. `scientific_admitted` means the
phase's declared workflow status was produced by a clean owned process; it
does not mean every target was solved.

Each case has `id,declaration,preparation,rank,methods`. Methods have
`id,method,phase,process_admitted,admitted_status,raw_status,search_status,
semantic_status,reason,stats,costs,refs,events,event_coverage,policy,
native_proof_id`. `events` displays at most the first 2048 literal events;
`event_coverage` separately reports displayed, retained, emitted, SHA, complete
emitted extent and complete search. Failed-process output references are
prefixed `unadmitted_` and do not promote a native proof.

`native_proofs` contains only admitted target positives, with ID
`<case>--<method>` and role `POINT_SEARCH` or `SPECIALIZED_CONTROL`. Fields are
`lines,statement_sha256,selected_sha256,proof_sha256,proof_ref,native_ref,
statement,proof,selected,selected_rows,slots,slot_to_native,native_to_slot,
reference_mapping,proof_dag`. Audit `native_proofs` is their compact metadata
projection. It contains no unadmitted failed-process target proof.

Policy projection authenticates the retained completed log prefix, proposals,
instance IDs, X admission/state hashes, preference and actual BRANCH ordering,
then the literal next PLACED event. Request selected/excluded context is bound
to the actual frozen callback/X receipts; the auditor does not independently
reconstruct that transition state. Later unlogged fallback and a possible
interrupted callback are disclosed. Selected final membership is credited only
for an admitted native final proof.

`policy.coverage` fields are `logged_callbacks,reported_callbacks,branch_events,
unlogged_callbacks,pending_callback_possible,displayed_examples,examples_total,
raw_final_proof_admitted`. `policy.metrics` fields are `offer_queries_logged,
offered_instances_logged,admitted_instance_occurrences_logged,
compatible_instance_occurrences_logged,chosen_occurrences_logged,
actual_chosen_first_placed_occurrences,all_internal_survive_occurrences,
all_receptors_fulfilled_occurrences`. The last two are null without an admitted
final native proof, never an invented zero. Counts are occurrences, not unique
learned lemmas, necessary steps, causal benefit or an RL result.

At most eight actual chosen examples are exported: first four with all internal
members surviving and every receptor fulfilled, followed by the first four
chronological choices, deduplicated by callback index. `policy.example_policy`
records this exact viewer policy; full metrics still cover every retained log.
Each example has `callback_index,
instance,request,branch_event,placed_event,actual_first_placed,
final_internal_cids,all_internal_survive,receptors,all_receptors_fulfilled,
internal_rows`. Each receptor has `donor_index,slot,formula,owner_cid,fulfilled`.
Fulfillment is credited only when all internal CIDs survive and the actual
selected external-slot owner has the demanded literal formula. Unknown final
membership/fulfillment is null. A proposal or compatible missing owner alone
does not imply fulfillment.

Only the erased fragment library appears in the reader projection. Full
original Source/input/raw/log/refusal/failure records remain evidence-archive
members, under the user's existing full-archive authorization. Fixed process
order and unmatched primitive conventional control preclude superiority or
fair timing conclusions. Preparation, admission, proposal, semantic and native
costs retain their saved scopes.

The final pre-execution custody closure additionally requires a nonnull,
complete, exact-byte invocation result before process admission; joins actual
compiled core, bridge/catalogue/generation, complete universe, rank arrays and
scope fields to their saved receipts; verifies actual serialized endpoint
hashes; and requires a chosen instance to have been offered already with exact
content. These are literal/hash associations, not new semantic computations.
The initially held Source is preserved under `publication/source-iterations/`,
with an exact full delta. `frozen.limits` is the literal frozen limits record;
phase `observer` retains actual guards, errors and RSS sampling metadata.
