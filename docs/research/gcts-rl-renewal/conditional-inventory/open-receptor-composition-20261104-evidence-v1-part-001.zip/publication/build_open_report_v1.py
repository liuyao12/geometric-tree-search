"""Thin passive reader builder. No scientific imports, replay or checking.

Root reviews this Source before execution. The independently audited projection
is authoritative; the builder checks physical/metadata joins and renders it.
"""
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL='protocol/frozen-protocol-v1.json'
INPUT='data/report-data-v1.json'
AUDIT='publication/saved-data-audit-v1.json'
MAIN='report/open-receptor-composition-20261104-v1.html'
DATA='report/open-receptor-composition-20261104-data-v1.json'
RECEIPT='report/build-receipt-v1.json'
SOURCE='publication/build_open_report_v1.py'


def need(ok,why):
    if not ok:raise ValueError(why)


def wire(v):
    return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def same(a,b,why):
    need(wire(a)==wire(b),why)


def local(name):
    need(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts,'LOCAL_PATH')
    p=ROOT/name;q=p
    while q!=ROOT:
        need(not q.is_symlink(),'NO_SYMLINK');q=q.parent
    need(p.resolve().is_relative_to(ROOT),'CONTAINED_PATH')
    return p


def bytepin(p):
    n=0;h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):n+=len(b);h.update(b)
    return dict(bytes=n,sha256=h.hexdigest())


def ref(name):
    return dict(path=name,**bytepin(local(name)))


def exact(r):
    need(type(r) is dict and {'path','bytes','sha256'}<=set(r),'EXACT_REF')
    same(ref(r['path']),{k:r[k] for k in ('path','bytes','sha256')},'SAVED_PHYSICAL_BYTES')


def read(name):
    with local(name).open(encoding='ascii') as f:return json.load(f)


def artifact(r):
    import gzip
    exact(r);p=local(r['path'])
    with (gzip.open(p,'rt',encoding='ascii') if p.suffix=='.gz' else p.open(encoding='ascii')) as f:v=json.load(f)
    for k in (r.get('pointer') or '').split('/')[1:]:
        k=k.replace('~1','/').replace('~0','~');v=v[int(k)] if type(v) is list else v[k]
    return v


def verify_saved():
    protocol=read(PROTOCOL);audit=read(AUDIT);data=read(INPUT)
    need(protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_PROTOCOL')
    need(audit['schema']=='Open-receptor-passive-audit-v1' and audit['status']=='PASS','PASS_SAVED_AUDIT')
    need(data['schema']=='Open-receptor-report-data-v1' and data['status']=='PASS_SAVED_DATA_PROJECTION','ADMITTED_PROJECTION')
    same(audit['report_data'],ref(INPUT),'AUDIT_BINDS_PROJECTION_BYTES')
    same(data['protocol'],ref(PROTOCOL),'PROJECTION_CURRENT_PROTOCOL')
    same(audit['protocol'],ref(PROTOCOL),'AUDIT_CURRENT_PROTOCOL')
    same(data['frozen']['limits'],protocol['limits'],'PROJECTED_CURRENT_LIMITS')
    for r in protocol['files']:exact(r)
    admission=read('review/root-source-admission-v1.json')
    need(admission['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','ROOT_SOURCE_ADMISSION')
    files={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for p in local(folder).rglob('*'):
            need(not p.is_symlink(),'NO_FROZEN_SYMLINK')
            if p.is_file():files.add(p.relative_to(ROOT).as_posix())
    for r in admission['reviewed']:exact(r);files.add(r['path'])
    same([ref(n) for n in sorted(files)],protocol['files'],'EXACT_FROZEN_FILE_SET')
    runtime=protocol['runtime'];exe=Path(sys.executable).resolve()
    same(dict(executable=dict(path=str(exe),**bytepin(exe)),version=sys.version,
              isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode),
         runtime,'FROZEN_RUNTIME')
    same(bytepin(Path(protocol['master']['path'])),{k:protocol['master'][k] for k in ('bytes','sha256')},'CURRENT_MASTER')
    for r in audit['artifact_pins']:exact(r)
    phases={p['name']:p for p in data['phases']};ap={p['name']:p for p in audit['phases']}
    need(len(phases)==len(data['phases']) and len(ap)==len(audit['phases']),'UNIQUE_PHASES')
    same(sorted(phases),sorted(protocol['phases']),'EXACT_PROTOCOL_PHASES')
    same(sorted(ap),sorted(phases),'AUDITED_PHASE_SET')
    for name,p in phases.items():
        for k in ('pid','native_exit_code','scientific_status','process_clean','scientific_admitted'):
            same(p[k],ap[name][k],'AUDITED_PHASE:'+name+':'+k)
    proofs={p['id']:p for p in data['native_proofs']};audited={p['id']:p for p in audit['native_proofs']}
    need(len(proofs)==len(data['native_proofs']) and len(audited)==len(audit['native_proofs']),'UNIQUE_PROOF_IDS')
    same(sorted(proofs),sorted(audited),'EXACT_NATIVE_PROOF_SET')
    for key,p in proofs.items():
        a=audited[key]
        for k in ('role','lines','statement_sha256','selected_sha256','proof_sha256'):
            same(p[k],a[k],'AUDITED_NATIVE:'+k)
        need(type(p['lines']) is int and p['lines']==len(p['proof']),'WHOLE_PROOF_LINES')
        same(hashlib.sha256(wire(p['proof'])).hexdigest(),p['proof_sha256'],'WHOLE_PROOF_HASH')
        same(hashlib.sha256(wire(p['statement'])).hexdigest(),p['statement_sha256'],'ORIGINAL_STATEMENT_HASH')
        same(hashlib.sha256(wire(sorted(r['id'] for r in p['selected_rows']))).hexdigest(),p['selected_sha256'],'SELECTED_ROWS_IDS')
        for field in ('proof_ref','native_ref'):
            same({k:p[field].get(k) for k in ('path','bytes','sha256','pointer')},
                 {k:a[field].get(k) for k in ('path','bytes','sha256','pointer')},'AUDITED_NATIVE_REF')
        same(artifact(p['proof_ref']),p['proof'],'LITERAL_SAVED_NATIVE_PROOF')
        native=artifact(p['native_ref'])
        need(native['status']=='VERIFIED' and type(native['checked_lines']) is int
             and native['checked_lines']==p['lines'],'WHOLE_NATIVE_RECEIPT')
    for case in data['cases']:
        for method in case['methods']:
            pid=method.get('native_proof_id')
            if pid is not None:
                need(pid in proofs and method['process_admitted'] is True
                     and method['admitted_status']=='VERIFIED_NATIVE_POSITIVE','ONLY_ADMITTED_METHOD_PROOF')
    return data,audit


def build():
    for n in (MAIN,DATA,RECEIPT):need(not local(n).exists(),'EXCLUSIVE_OUTPUT:'+n)
    data,audit=verify_saved();local('report').mkdir(exist_ok=True)
    local(DATA).open('xb').write(wire(data));local(MAIN).open('xb').write(PAGE.encode('utf-8'))
    result=dict(schema='Open-receptor-report-build-v1',status='BUILT_FROM_ADMITTED_SAVED_DATA',
        protocol=ref(PROTOCOL),source_projection=ref(INPUT),saved_data_audit=ref(AUDIT),renderer_source=ref(SOURCE),
        outputs=dict(main=ref(MAIN),data=ref(DATA)),artifact_pins=audit['artifact_pins'],
        counts=dict(cases=len(data['cases']),proofs=len(data['native_proofs'])))
    local(RECEIPT).open('xb').write(wire(result));print(json.dumps(result,sort_keys=True))


PAGE=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Open receptors and proof composition</title><style>
:root{color-scheme:light;--ink:#193e3a;--muted:#5b7069;--paper:#f5f4ed;--line:#cbd9d0}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,sans-serif}main{max-width:1180px;margin:auto;padding:26px}nav{display:flex;gap:22px;flex-wrap:wrap;font-size:14px}a{color:#267c71}h1{font:clamp(38px,6vw,70px)/1.05 Georgia,serif;margin:32px 0 18px}h2{font:29px/1.2 Georgia,serif}h3{font-size:18px}.eyebrow{font-size:12px;text-transform:uppercase;letter-spacing:.14em;margin-top:30px}.lede{font-size:20px;max-width:880px}.panel{padding:24px;margin:22px 0;border:1px solid var(--line);border-radius:10px;background:#fffef8;min-width:0}.note{padding:14px;border-left:4px solid #4b8d7b;background:#eaf3e9}.warning{border-color:#c08a43;background:#fcf1d9}.muted{font-size:14px;color:var(--muted)}.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}.controls{display:flex;flex-wrap:wrap;gap:12px;align-items:center}select,button{padding:7px 10px;border:1px solid #9cb5a8;border-radius:5px;background:white;color:inherit;font:inherit;max-width:100%}button{cursor:pointer}.scroll,.diagram,.math{overflow-x:auto;max-width:100%}.math{display:block;padding:3px 0}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;vertical-align:top;padding:10px 8px;border-bottom:1px solid var(--line)}pre{overflow:auto;max-height:430px;background:#edf1e9;padding:14px;font-size:12px}code{font-size:12px;overflow-wrap:anywhere}details{margin:14px 0}.proof{table-layout:fixed}.proof th:nth-child(1){width:5%}.proof th:nth-child(2){width:43%}.proof th:nth-child(3){width:33%}.proof th:nth-child(4){width:19%}.active{background:#e5f2e2}.diagram svg{min-width:680px;width:100%;max-height:250px}.diagram [data-slot]{cursor:pointer}.cards{display:flex;gap:10px;flex-wrap:wrap}.card{padding:10px;border:1px solid #a9c0b4;min-width:120px;background:#f6faee}#fatal{color:#9b352c;font-weight:bold}@media(max-width:750px){main{padding:14px}.panel{padding:16px}.grid{grid-template-columns:1fr}.proof{min-width:760px}}
</style><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','style','pre','code']},startup:{ready(){MathJax.startup.defaultReady();window.__mathReady=MathJax.startup.promise;}}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script></head><body><main>
<nav><a href="receptor-family-transfer-20261104-v1.html">Previous complete-expansion study</a><a href="#results">Outcomes</a><a href="#fragments">Open fragments</a><a href="#reader">Proof reader</a><a href="#evidence">Evidence</a></nav>
<p class="eyebrow">GCTS research · proper partial lemmas</p><h1>Leave the premises open.<br>Search for their owners.</h1><p class="lede">Only proper fragments survive from the warm library. Their internal primitive steps are checked locally; outside premises remain formula-and-slot receptors. The matcher supplies no complete target proof or whole-cover oracle.</p><div id="fatal"></div><div id="outcome" class="note"></div><div id="stops"></div>
<section id="results" class="panel"><h2>Actual first-attempt results</h2><div id="targets" class="grid"></div><div id="results-table" class="scroll"></div><p class="muted">The unary case is a seen calibration. The nested-addition statement and twelve-slot bound are prospectively declared; a different bound is not a held-out theorem family. Native process, raw search, semantic assurance and final native proof statuses remain separate. UNKNOWN is not nonprovability.</p><details><summary>All owned phase/process outcomes</summary><div id="phase-table" class="scroll"></div></details></section>
<section id="fragments" class="panel"><h2>Inspect an actual open fragment</h2><div id="materialization"></div><div class="controls"><select id="fragment"></select><select id="choice-method"></select><select id="choice"></select></div><div id="fragment-view"></div><div id="choice-view"></div><details><summary>Exact local payloads, receptor templates and observed choice</summary><pre id="fragment-json"></pre></details><p class="muted">A compatible offer is not a completed lemma, an executed macro or an extension certificate. The engine places one primitive candidate after global scheduling. Offered, actually first placed, final surviving internal members and fulfilled receptors are different observations. Displayed examples may prioritize fulfilled final instances; they are inspection examples, not an estimated success rate. Read complete retained-log metrics and coverage. Missing owners remain demands.</p></section>
<section id="reader" class="panel"><p class="eyebrow">Complete native-checked outputs only</p><h2>Read the proof line by line</h2><div class="controls"><select id="proof"></select><label><input id="literal" type="checkbox"> Literal names</label><button id="download">Download native proof</button></div><div id="proof-scope"></div><div id="proof-goal"></div><div id="slots" class="diagram"></div><div id="proof-table" class="scroll"></div><details><summary>Unchanged proof AST and exact maps</summary><pre id="proof-json"></pre></details><p class="muted">Square cards are symbolic slot owners, not Euclidean polygons or a uniform Wang palette. Orange is the activity layer; purple is formula-ID matching. Arrows denote actual earlier-slot dependencies. Cyan dashed boxes depict open receptor demands in a fragment view.</p></section>
<section class="grid"><div class="panel"><h2>What this can establish</h2><div id="assessment"></div><p>Unlike the previous study, local matching does not first construct the entire donor-length target proof. A checked final proof plus recorded independent receptor fulfillment would demonstrate finite open-fragment composition. A successful offer alone does not.</p><p>The conventional AND/OR control has the full primitive catalogue and rank information but no fragment library. It is an unmatched-information comparison. Without a conventional control equipped with the same fragments, this experiment establishes no distinctive GCTS or speed advantage. There is no RL, universal schematic theorem, full PA, induction or new geometry claim.</p></div><div class="panel"><h2>Costs, bounds and memory</h2><div id="costs" class="scroll"></div><p class="muted">Warm historical acquisition is reused, not free or freshly remeasured. Current materialization, full RF preparation, rank checks, matching/admission, policy setup, E/C, persistence and M/N/B all matter. Policy setup is shown separately when recorded in policy counts. Observed owned-process seconds come from the matched phase observer and are separate from row-component subtotals and policy setup. Recorded row-component subtotals may omit additional certificate persistence and aggregation and overlap process intervals; no end-to-end speed conclusion is assumed.</p><p class="muted">Each method has its own owned process. This removes cross-method object retention; it does not guarantee a single method fits the unchanged memory guard. Native high-water RSS and polling samples are distinct.</p><details><summary>All recorded costs, coverage and limits</summary><pre id="cost-json"></pre></details></div></section>
<section class="panel"><h2>Qualification and conformance</h2><div id="qualification"></div><p class="muted">Proper-fragment locality, named hypotheses, remote literal marks, selected-once unions, rollback/exclusions, complete fallback and hook/resource refusal require actual qualification. Tiny actual-map checks are distinct from the large runs' semantic reconstruction and serialized endpoints. No intermediate large producer table observation is invented.</p><details><summary>Exact saved metadata and limitations</summary><pre id="metadata"></pre></details></section>
<!-- OPEN_RECEPTOR_COMPOSITION_ARCHIVE_LINK -->
<section id="evidence" class="panel"><h2>Complete evidence</h2><p><a href="open-receptor-composition-20261104-data-v1.json">Reader data</a> · <a href="open-receptor-composition-20261104-evidence-v1-manifest.json">Physical archive manifest</a> · <a href="open-receptor-composition-20261104-evidence-v1-part-001.zip">First archive volume</a></p><p>All original Sources, inputs, proper fragments, raw events, policy records, refusals, guarded prefixes, native certificates and process logs are retained in the authorized archive.</p><details><summary>Projection, protocol and artifact references</summary><pre id="provenance"></pre></details></section>
</main><script>'use strict';const $=x=>document.getElementById(x),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),tex=x=>String(x).replace(/[\\{}_$%&#^~]/g,c=>'\\'+c),math=x=>'<span class="math">\\('+esc(x)+'\\)</span>',num=x=>x==null?'not recorded':Number(x).toLocaleString(undefined,{maximumFractionDigits:4});let D,P,A={},literal=false,queue=Promise.resolve();
function typeset(el){queue=queue.then(async()=>{while(!window.MathJax||!MathJax.typesetPromise)await new Promise(r=>setTimeout(r,25));await MathJax.startup.promise;if(el.isConnected){MathJax.typesetClear([el]);await MathJax.typesetPromise([el]);}}).catch(e=>{$('fatal').textContent='Math error: '+e.message;});}const sym=x=>literal?x:(A[x]??x);
function term(t){if(t[0]==='_term')return '\\mathsf{'+tex(t[1])+'}';if(t[0]==='_hole')return '\\square';if(t[0]==='_ctx')return '\\mathcal{C}_{'+tex(t[1])+'}['+term(t[2])+']';if(t[0]==='var')return tex(sym(t[1]));const n=sym(t[1]);return (n==='zero'?'0':'\\operatorname{'+tex(n)+'}')+(t[2].length?'('+t[2].map(term).join(',')+')':'');}
function formula(f){switch(f[0]){case'eq':return term(f[1])+'='+term(f[2]);case'pred':return '\\operatorname{'+tex(sym(f[1]))+'}'+(f[2].length?'('+f[2].map(term).join(',')+')':'');case'all':return '\\forall '+tex(sym(f[1]))+'\\,('+formula(f[2])+')';case'imp':case'and':case'or':return '('+formula(f[1])+({imp:'\\Rightarrow ',and:'\\land ',or:'\\lor '}[f[0]])+formula(f[2])+')';case'not':return '\\neg '+formula(f[1]);case'bot':return '\\bot';default:return '\\text{'+tex(JSON.stringify(f))+'}';}}
const refs=l=>l.rule==='mp'?[l.antecedent,l.implication]:l.rule==='generalize'?[l.source]:[];function english(l){switch(l.rule){case'axiom':return 'Use hypothesis '+l.name+'.';case'refl':return 'A term equals itself.';case'instantiate':return 'Use universal instantiation at the recorded term; this is the checked implication schema.';case'eq_subst':return 'Substitute equals for equals in the recorded formula context; this line is the checked schema.';case'distribute':return 'Use quantified distribution with its checked side conditions.';case'tautology':return 'Use a checked propositional tautology.';case'mp':return 'From line '+(l.antecedent+1)+' and its implication on line '+(l.implication+1)+', infer the consequent.';case'generalize':return 'Universally quantify '+sym(l.variable)+' in line '+(l.source+1)+' under the closed hypothesis context.';default:return l.rule;}}
function table(headers,rows){return '<table><thead><tr>'+headers.map(h=>'<th>'+esc(h)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(x=>'<td>'+x+'</td>').join('')+'</tr>').join('')+'</tbody></table>';}
function aliases(c){return {...Object.fromEntries(Object.entries(c?.declaration?.names??{}).map(([k,v])=>[v,k])),qmtH:'H'};}
function slots(ss,open=[],chosen=null){const all=[...ss.map(s=>s.slot),...open.map(r=>r.slot)],w=Math.max(650,(Math.max(-1,...all)+1)*112);let out='<svg viewBox="0 0 '+w+' 225" role="img" aria-label="Actual symbolic owners and formula dependencies">';for(const s of ss){for(const j of JSON.parse(s.cid)[3]){const a=55+s.slot*112,b=55+j*112;out+='<path d="M'+a+',108 Q'+((a+b)/2)+',18 '+b+',108" fill="none" stroke="#ab8fc0"/><circle cx="'+b+'" cy="108" r="3" fill="#9b7aaf"/>';}}for(const r of open){const a=9+r.slot*112;out+='<rect x="'+a+'" y="108" width="94" height="96" fill="#f2fcfc" stroke="#3b959e" stroke-dasharray="5 4"/><text x="'+(a+7)+'" y="128" font-size="11">receptor '+r.slot+'</text><rect x="'+(a+7)+'" y="145" width="80" height="10" fill="#84c6cb"/><text x="'+(a+7)+'" y="182" font-size="11">outside owner</text>';}for(const s of ss){const a=9+s.slot*112,active=chosen!==null&&s.native_line_index_or_null===chosen;out+='<g data-slot="'+s.slot+'"><rect x="'+a+'" y="108" width="94" height="96" fill="'+(active?'#e0f2de':'#fafcf2')+'" stroke="#7a9c8b" stroke-width="'+(active?3:1)+'"/><text x="'+(a+7)+'" y="127" font-size="11">slot '+s.slot+' · '+esc(JSON.parse(s.cid)[1])+'</text><rect x="'+(a+7)+'" y="137" width="80" height="10" fill="'+(s.active?'#c48c44':'#dde4d9')+'"/><rect x="'+(a+7)+'" y="154" width="80" height="10" fill="#b39acb"/><text x="'+(a+7)+'" y="183" font-size="10">active '+s.active+' · FID '+s.formula_id+'</text><text x="'+(a+7)+'" y="198" font-size="10">one unit at center</text></g>';}return out+'</svg>';}
function showProof(){P=D.native_proofs.find(p=>p.id===$('proof').value);if(!P){for(const k of ['proof-goal','slots','proof-table'])$(k).innerHTML='';$('proof-json').textContent='';$('proof-scope').innerHTML='<p class="note warning">No clean native-admitted proof belongs to this selected method. UNKNOWN, guarded prefixes and skipped methods have no invented certificate.</p>';$('download').disabled=true;return;}const c=D.cases.find(c=>c.methods.some(m=>m.native_proof_id===P.id));A=aliases(c);literal=$('literal').checked;$('download').disabled=false;const method=c.methods.find(m=>m.native_proof_id===P.id);$('proof-scope').innerHTML='<p class="note"><b>'+esc(method.method==='conventional'?'Primitive conventional AND/OR control':method.method==='rank-only'?'Rank-only GCTS without fragment library':'GCTS with proper open-fragment ordering')+'</b> · '+esc(P.id)+' · '+P.lines+' checked native lines.</p>';$('proof-goal').innerHTML=math(formula(P.statement.goal))+'<details><summary>Exact hypotheses and display-only aliases</summary><pre>'+esc(JSON.stringify({theory:P.statement.theory,aliases:A},null,2))+'</pre></details>';$('proof-table').innerHTML='<table class="proof"><thead><tr><th>Line</th><th>Assertion</th><th>Natural reading</th><th>Rule / refs</th></tr></thead><tbody>'+P.proof.map((l,i)=>'<tr id="line-'+i+'"><td><button data-line="'+i+'">'+(i+1)+'</button></td><td>'+math(formula(l.formula))+'</td><td>'+esc(english(l))+'</td><td><code>'+esc(l.rule)+'</code><br>'+refs(l).map(j=>'line '+(j+1)).join(', ')+'<br>slot '+P.native_to_slot[i]+'</td></tr>').join('')+'</tbody></table>';$('proof-json').textContent=JSON.stringify(P,null,2);const bind=()=>{for(const g of $('slots').querySelectorAll('[data-slot]'))g.onclick=()=>choose(P.slots.find(s=>s.slot===+g.dataset.slot).native_line_index_or_null);};const choose=i=>{for(const tr of $('proof-table').querySelectorAll('tbody tr'))tr.classList.toggle('active',tr.id==='line-'+i);$('slots').innerHTML=slots(P.slots,[],i);bind();};for(const b of $('proof-table').querySelectorAll('[data-line]'))b.onclick=()=>choose(+b.dataset.line);$('slots').innerHTML=slots(P.slots);bind();typeset($('reader'));}
function showFragment(){const fs=D.materialization?.library?.fragments??[],f=fs.find(f=>f.id===$('fragment').value);A={qmtx:'x',qmtS:'S',qmtadd:'add',qmtzero:'zero',qmtH:'H'};literal=false;if(!f){$('fragment-view').innerHTML='<p class="note warning">No admitted materialized fragment is available in this snapshot.</p>';$('fragment-json').textContent='';return;}const root=f.lines.find(([i])=>i===f.root)[1];$('fragment-view').innerHTML='<h3>Library fragment '+esc(f.id.slice(0,14))+' · '+f.members.length+' internal members / '+f.receptors.length+' open receptors</h3><div class="grid"><div><b>Root formula template</b>'+math(formula(root.formula))+'</div><div><b>Outside formula templates</b>'+f.receptors.map(([i,v])=>'<div class="card">donor node '+i+math(formula(v))+'</div>').join('')+'</div></div><p class="muted">Only these internal payloads and boundary templates are retained; no outside proof payload or complete target expansion is included.</p>';$('fragment-json').textContent=JSON.stringify(f,null,2);typeset($('fragments'));}
const methodRows=()=>D.cases.flatMap(c=>c.methods.map(m=>({...m,case:c})));function choiceMethod(){const m=methodRows().find(m=>m.id===$('choice-method').value),xs=m?.policy?.examples??[];$('choice').innerHTML=xs.map((x,i)=>'<option value="'+i+'">callback '+x.callback_index+' · '+(x.actual_first_placed?'actual placement observed':'not placed / pending')+'</option>').join('');showChoice();}
function showChoice(){const m=methodRows().find(m=>m.id===$('choice-method').value),x=m?.policy?.examples?.[+$('choice').value];if(!x){$('choice-view').innerHTML='<p>No retained chosen-fragment example is attached to this method.</p>'+(m?.policy?'<pre>'+esc(JSON.stringify({counts:m.policy.counts,coverage:m.policy.coverage,metrics:m.policy.metrics,example_policy:m.policy.example_policy},null,2))+'</pre>':'');return;}$('fragment').value=x.instance.fragment_id;showFragment();A=aliases(m.case);literal=false;const rows=x.internal_rows.map(r=>{const slot=JSON.parse(r.id)[0],marks=new Map(r.m);return {cid:r.id,slot,active:+marks.get('a:'+slot),formula_id:+marks.get('f:'+slot),native_line_index_or_null:null};});$('choice-view').innerHTML='<h3>'+esc(m.case.id)+' / '+esc(m.method)+' · actual callback '+x.callback_index+'</h3><p class="note '+(x.actual_first_placed?'':'warning')+'">Chosen preference: <b>'+esc(x.actual_first_placed?'an actual first PLACED event is joined':'no actual placement joined; pending or unobserved')+'</b>. '+(x.all_internal_survive===null?'No admitted final proof: final membership and receptor fulfillment are unresolved.':x.all_internal_survive?'All internal CIDs survive in the admitted final certificate.':'Some offered internal CIDs do not survive together in the final certificate.')+'</p>'+slots(rows,x.receptors)+table(['Receptor slot','Actual formula demand','Final owner / fulfillment'],x.receptors.map(r=>[esc(r.slot),math(formula(r.formula)),r.fulfilled===null?'unresolved':r.fulfilled?'fulfilled by actual final owner':'not fulfilled as this offered fragment']))+'<details><summary>Exact choice, placement and coverage record</summary><pre>'+esc(JSON.stringify({example:x,coverage:m.policy.coverage,metrics:m.policy.metrics,example_policy:m.policy.example_policy},null,2))+'</pre></details>';typeset($('choice-view'));}
const subtotal=c=>{const ns=Object.values(c??{}).filter(x=>typeof x==='number'&&Number.isFinite(x));return ns.length?ns.reduce((a,b)=>a+b,0):null;};const observedSeconds=m=>D.phases.find(p=>p.name===m?.phase)?.costs?.observed_process_seconds;function caseAssessment(){return D.cases.map(c=>{const rank=c.methods.find(m=>m.method==='rank-only'),open=c.methods.find(m=>m.method==='open-fragments'),ordinary=c.methods.find(m=>m.method==='conventional');return '<h3>'+esc(c.id)+'</h3><p>Recorded rank-only / open-guided branches: <b>'+num(rank?.stats?.branches)+' / '+num(open?.stats?.branches)+'</b>. Observed owned-process seconds: rank-only <b>'+num(observedSeconds(rank))+'</b>; open-guided <b>'+num(observedSeconds(open))+'</b>; conventional <b>'+num(observedSeconds(ordinary))+'</b>.</p>';}).join('')+'<p><b>Branch reduction does not imply speedup.</b> These are single first attempts, potentially with different outcomes and resource stops. No statistical comparison or GCTS-specific performance advantage is established.</p>'; }function init(){const ms=methodRows(),ps=D.native_proofs.filter(p=>p.role==='POINT_SEARCH'),cs=D.native_proofs.filter(p=>p.role!=='POINT_SEARCH');$('outcome').innerHTML='<b>'+ps.length+' point-search and '+cs.length+' conventional native certificate(s).</b> These are method-specific results on two declared statements, not separate new theorem counts.';const stopped=D.phases.filter(p=>p.observer&&(p.observer.guard_reason||p.observer.observer_error||p.observer.reap_error||p.observer.postcheck_error||p.observer.status!=='TERMINAL'||p.native_exit_code!==0));$('stops').innerHTML=stopped.length?'<p class="note warning"><b>Unresolved process stop(s):</b> '+stopped.map(p=>esc(p.name)+' / native '+esc(p.native_exit_code??'not observed')+' / '+esc(p.observer.guard_reason??p.observer.observer_error??p.observer.reap_error??p.observer.postcheck_error??p.observer.status)+(p.observer.guard_reason==='RSS_POLL_BOUND'?' (memory polling guard: observed peak '+num(p.observer.peak_observed_rss_bytes)+' bytes; frozen limit '+num(D.frozen.limits.guards.rss_bytes)+' bytes)':'')).join('; ')+'. Guarded prefixes are not promoted to accepted proofs or negative theorems. Exact guard records are below.</p>':'';$('targets').innerHTML=D.cases.map(c=>{A=aliases(c);literal=false;return '<div><h3>'+esc(c.id)+' · '+esc(c.declaration.slots)+' declared slots</h3>'+math(formula(c.declaration.problem.goal))+'</div>';}).join('');$('results-table').innerHTML=table(['Case / method','Raw / semantic','Native admission / reason','Branches / backtracks','Observed owned-process seconds','Recorded row-component seconds','Policy setup seconds'],ms.map(m=>[esc(m.case.id)+'<br>'+esc(m.method),esc(m.raw_status??m.search_status??'not run')+' / '+esc(m.semantic_status??'separate control'),esc(m.admitted_status)+'<br>'+esc(m.reason??''),num(m.stats?.branches)+' / '+num(m.stats?.backtracks),num(observedSeconds(m)),num(subtotal(m.costs)),num(m.policy?.counts?.setup_seconds)]));$('phase-table').innerHTML=table(['Phase / PID','Scientific / process','Native exit','Costs / exact refs'],D.phases.map(p=>[esc(p.name)+' / '+esc(p.pid??'none'),esc(p.scientific_status??'not run')+'<br>'+esc(p.process_status),esc(p.native_exit_code??'not observed'),'<details><summary>Actual record</summary><pre>'+esc(JSON.stringify(p,null,2))+'</pre></details>']));const fs=D.materialization?.library?.fragments??[];$('materialization').innerHTML='<p class="note '+(D.materialization?.status==='VERIFIED_MATERIALIZATION'?'':'warning')+'">Actual materialization status: <b>'+esc(D.materialization?.status??'not reached')+'</b> · '+fs.length+' retained proper fragments.</p>';$('fragment').innerHTML=fs.map(f=>'<option value="'+f.id+'">'+f.members.length+' internal / '+f.receptors.length+' receptors · '+f.id.slice(0,12)+'</option>').join('');$('fragment').onchange=()=>{showFragment();$('choice').selectedIndex=-1;$('choice-view').innerHTML='<p class="note">Library selection. Actual choice examples remain separately selectable above; no previous choice is being displayed for this template.</p>';};showFragment();$('choice-method').innerHTML=ms.filter(m=>m.policy).map(m=>'<option value="'+m.id+'">'+esc(m.case.id)+' / '+esc(m.method)+'</option>').join('');$('choice-method').onchange=choiceMethod;$('choice').onchange=showChoice;choiceMethod();$('proof').innerHTML=ms.map(m=>'<option value="'+esc(m.native_proof_id??m.id)+'">'+esc(m.case.id)+' / '+esc(m.method)+' / '+esc(m.admitted_status)+'</option>').join('');const preferred=D.native_proofs.find(p=>p.id.endsWith('--open-fragments'))??ps[0]??D.native_proofs[0];if(preferred)$('proof').value=preferred.id;$('proof').onchange=showProof;$('literal').onchange=showProof;showProof();$('download').onclick=()=>{if(!P)return;const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({statement:P.statement,proof:P.proof},null,2)],{type:'application/json'}));a.download=P.id+'-native.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};$('assessment').innerHTML=caseAssessment()+'<p>'+D.native_proofs.length+' actual native-admitted method outputs. Open-guided certificates, if present, must be read together with actual placed/final fragment and receptor records. The display does not infer a whole-fragment execution from a recommendation.</p>';$('costs').innerHTML=table(['Method','Recorded row components','Policy setup seconds','Policy counts / cost detail'],ms.map(m=>[esc(m.case.id)+' / '+esc(m.method),num(subtotal(m.costs)),num(m.policy?.counts?.setup_seconds),'<details><summary>Actual metadata</summary><pre>'+esc(JSON.stringify({costs:m.costs,policy:m.policy?.counts,coverage:m.policy?.coverage},null,2))+'</pre></details>']));$('cost-json').textContent=JSON.stringify({phases:D.phases,materialization:D.materialization?.costs,cases:D.cases.map(c=>({id:c.id,preparation:c.preparation,rank:c.rank,methods:c.methods.map(m=>({method:m.method,costs:m.costs,policy:m.policy?.counts}))})),frozen:D.frozen},null,2);$('qualification').innerHTML='<p>Actual qualification phase: <b>'+esc(D.phases.find(p=>p.name==='qualify')?.scientific_status??'not run')+'</b>. Materialization and local fragment qualifications remain separately recorded in case metadata.</p>';$('metadata').textContent=JSON.stringify({limitations:D.limitations,cases:D.cases.map(c=>({id:c.id,declaration:c.declaration,preparation:c.preparation,rank:c.rank})),materialization:D.materialization?.refs},null,2);$('provenance').textContent=JSON.stringify({protocol:D.protocol,frozen:D.frozen,materialization_refs:D.materialization?.refs},null,2);typeset(document.querySelector('main'));window.__readerLoaded=true;}
fetch('open-receptor-composition-20261104-data-v1.json').then(r=>{if(!r.ok)throw Error('Reader data HTTP '+r.status);return r.json();}).then(d=>{D=d;init();}).catch(e=>{$('fatal').textContent=e.stack??e.message;});
</script></body></html>'''


if __name__=='__main__':build()
