# Passive evidence archive and isolated commit preparation

Source-only until Root and independent peer review. No script has been imported,
packaged, run against Git/network, or used for scientific execution by its author.
The script imports stdlib only and never imports the auditor, renderer or any
scientific helper. It prepares a local isolated commit and **never pushes**.

Use the frozen protocol's Python executable with `-I -S -B`. After the audited
projection and thin reader build exist, execute:

```text
PYTHON -I -S -B publication/package_open_v1.py --prepare-links
```

This authenticates the exact frozen protocol (11396 bytes, SHA256
`b131b14fffc1ac9bd1846071ab6f35804677fee3fbaeed7545cde45743b5a34c`),
current scientific file set/runtime/master, saved audit and original reader
build; preserves the original pre-link HTML; creates an archive README; changes
only the declared archive-marker region; and computes a multipart fixed-point
plan. It writes `publication/archive-plan-v1.json`, preserving a changed earlier
plan under an exact-hash history name. It does not prepare Git or publish.

Root then performs final local UI checks and writes the two final gates below.
Stop all scientific children and previews that write inside this root. Redirect
the packager's own stdout outside the root: a changing log inside the archive
cut will correctly fail final exact-byte/set verification. Root must fetch the
fresh reviewed official main into the existing isolated bare repository before
the final command. The script itself obtains official GitHub GET main and
requires it to equal the optional supplied expected commit; the same remote
main is checked again immediately before commit creation.

```text
PYTHON -I -S -B publication/package_open_v1.py EXPECTED_40_HEX_MAIN
```

`EXPECTED_40_HEX_MAIN` should be the freshly reviewed main. The optional omission
uses the fresh official GET response, never a hardcoded old main. A missing base
in the isolated bare Git causes refusal rather than an implicit fetch or force.

Fixed existing repository/destination:

```text
/private/tmp/gcts-history-publication-20261102-v1.git
liuyao12/geometric-tree-search
docs/research/gcts-rl-renewal/conditional-inventory/
```

Prepared assets are exactly the new dated main and plain JSON, new evidence
manifest and volumes, plus one modified existing predecessor reader:

```text
open-receptor-composition-20261104-v1.html
open-receptor-composition-20261104-data-v1.json
open-receptor-composition-20261104-evidence-v1-manifest.json
open-receptor-composition-20261104-evidence-v1-part-NNN.zip
receptor-family-transfer-20261104-v1.html       # backlink only
```

All new paths must be absent in the official base tree. The existing reader is
copied from that exact base and receives one paragraph linking to the new
`#reader`. Its changed bytes are saved before the archive cut. No other existing
path may change. Full name-status diff, sole parent and exact tree are checked.
The primary checkout/index is never touched. The only index is
`package/index-v1`; Git hooks/lazy fetch are disabled and no push call exists.

## Exact readiness gates

The audit is `publication/saved-data-audit-v1.json`, schema
`Open-receptor-passive-audit-v1`, status `PASS`. Its current artifact ledger,
physical output ledger, ten actual phase admissions and authoritative
`data/report-data-v1.json` reference are reauthenticated. No proof success,
library benefit, missing-phase outcome or completed search is hardcoded.

The build is `report/build-receipt-v1.json`, schema
`Open-receptor-report-build-v1`, status `BUILT_FROM_ADMITTED_SAVED_DATA`, with
exact `renderer_source`, `protocol`, `saved_data_audit`, `source_projection`,
`artifact_pins` and `outputs={main,data}`. Public JSON must equal the audited
projection bytes unchanged. Native proof IDs/metadata must equal the audit.
After linking, main HTML may differ only within
`<!-- OPEN_RECEPTOR_COMPOSITION_ARCHIVE_LINK -->` and its generated end marker.

`publication/local-ui-v1.json` must have this literal field shape (additional
observations/screenshots are allowed):

```json
{"status":"PASS_LOCAL_UI","source":{"path":"report/open-receptor-composition-20261104-v1.html","bytes":0,"sha256":"ACTUAL_FINAL_SHA"},"math_errors":0,"body_overflow":false,"console":[],"fatal":""}
```

Replace the example size/hash with actual final bytes. It is a required observed
UI receipt, not a template that may be copied as a result.

`publication/root-publication-admission-v1.json` must have status
`PASS_REVIEWED_PUBLICATION_WITH_EXPLICIT_SCOPES` and nested ordinary file refs
binding at least these nine exact current paths:

```text
protocol/frozen-protocol-v1.json
report/open-receptor-composition-20261104-v1.html
report/open-receptor-composition-20261104-data-v1.json
publication/build_open_report_v1.py
publication/audit_open_saved_data_v1.py
publication/package_open_v1.py
publication/saved-data-audit-v1.json
publication/local-ui-v1.json
report/build-receipt-v1.json
```

Every reference is `{path,bytes,sha256}` with actual bytes. This final gate is
distinct from the immutable historical scientific Source-only admission.

## Physical archive and output

Every original file under the current root at the cut is physically stored
exactly once, even when two paths contain identical bytes. Only generated
`package/` contents are excluded. All publication/tool Sources, notes, original
render, changed predecessor backlink, raw/UNKNOWN/failure prefixes and local
paths are included under the user's approved full-archive scope. No unretained
historical paths are silently imported as current files. Prior archives remain
separate links. Later prepared/push/Pages/live receipts are postcut custody.

Volumes are at most 44 MiB and strictly below 50 MiB. Each includes the same
`ARCHIVE-file-manifest-v1.json`. The external manifest records every original
path, size, SHA and assigned volume. Every ZIP CRC, exact member set, member
size/SHA, internal inventory and physical volume size/SHA is verified. A member
whose compressed size cannot fit the declared ceiling causes explicit refusal.
The complete original file set/bytes are checked again after ZIP creation.

Generated outputs:

- `package/final-v1/`: volumes, evidence manifest and archive verification.
- `publication/previous-report-with-backlink-v1.html`: included before the cut.
- `publication/remote-base-at-prepare-v1.json`: official GET custody, before cut.
- `publication/prepared-v1.json`: `PREPARED_TASK_ASSETS_ONLY`, exact base/tree/
  commit/assets/diff/archive verification, `pushed=false` and
  `primary_checkout_staged=false`; created after the cut.

No packaging attempt overwrites different existing bytes. Preserve any refusal
and its outputs; Root reviews a separately versioned administrative recovery
before any retry. `verify_archive(folder, manifest)` is a public passive stdlib
helper for later full-byte live verification. Root separately authorizes and
performs normal push, official Pages commit verification and live byte/UI checks
before reporting publication complete. The research program remains active.
