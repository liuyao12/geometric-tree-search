# Open-receptor passive reader

Source-only until full Root/peer review. `publication/build_open_report_v1.py`
is a thin standard-library saved-data consumer; it imports no scientific module,
calls no algorithm/checker and replays no transition. Root runs it once with the
same pinned Python `-I -S -B` after the actual independent audit is complete.

## Authoritative inputs

- `protocol/frozen-protocol-v1.json` with the actual frozen Source/runtime set.
- `publication/saved-data-audit-v1.json`, exact schema
  `Open-receptor-passive-audit-v1`, status `PASS`.
- `data/report-data-v1.json`, exact schema `Open-receptor-report-data-v1`, status
  `PASS_SAVED_DATA_PROJECTION`. `audit.report_data` must physically bind this
  file's exact path/bytes/SHA. There is no circular projection-to-audit hash.

The builder verifies protocol/audit/projection association, the exact complete
frozen file set and admitted review refs, runtime/executable/flags/current-master
bytes and the audit's artifact ledger. It joins the exact phase set and each
phase's `pid,native_exit_code,scientific_status,process_clean,scientific_admitted`
against the audit. It does not infer missing native exits or proof acceptance.
The full nullable actual observer object supplies prominent guard/error/native
stop warnings. RSS polling peaks and the literal frozen memory limit are shown
without interpreting a signal as an OS out-of-memory diagnosis. `frozen.limits`
must exactly equal the current protocol limits.

Projection fields are consumed unchanged: `protocol,frozen,phases,materialization,
cases,native_proofs,limitations`. Cases have their original `declaration`,
preparation/rank records and method records. The same input data may represent
success, UNKNOWN, refusal, native failure, unadmitted prefix or skipped method.
Scientific/source checks remain the auditor's job; this builder adds exact
physical and presentation metadata joins, not a second scientific verifier.

## Native proof gate

`native_proofs` IDs and metadata must exactly equal the audit's target-only
collection. IDs are `case--method`; roles are `POINT_SEARCH` or
`SPECIALIZED_CONTROL`. Required metadata: `lines,statement_sha256,
selected_sha256,proof_sha256,proof_ref,native_ref`. Physical proof/receipt refs
permit an optional JSON pointer. Literal saved proofs, complete B line counts,
statement/proof hashes and selected-row IDs are joined. The proof AST, slot maps,
reference mapping, DAG and actual literal selected rows remain unchanged.

Only a method with `process_admitted:true`,
`admitted_status:VERIFIED_NATIVE_POSITIVE` may link an admitted proof ID. Missing,
guarded or UNKNOWN selections clear the proof/table/diagram and disable download.
Raw SAT or complete emitted payload alone is not theorem admission or absence.

## Proper fragments and actual policy examples

`materialization.library` is only the erased proper-fragment library. The UI
does not need or load the old whole library/proof. All retained fragments are
selectable, displaying actual internal payload/root and external formula
templates. Matching/admission does not solve those receptors or supply a whole
target expansion. Parameter syntax uses the existing term/context/hole ASTs.

For each method with policy data, the reader uses `policy.counts`, `coverage`,
`metrics` and `examples`. Examples have `callback_index,instance,request,
branch_event,placed_event,actual_first_placed,internal_rows,final_internal_cids,
all_internal_survive,receptors,all_receptors_fulfilled`. Actual internal rows
are the source of active/formula port values. Each receptor records
`donor_index,slot,formula,owner_cid,fulfilled`. Unadmitted final outcomes retain
null membership/fulfillment instead of fabricated zero or a solved premise.

Coverage explicitly distinguishes logged/reported callbacks, branch events,
unlogged callbacks, a possible pending call, displayed/total examples and
whether the final proof was admitted. Offered/independently admitted/compatible,
actually first placed and surviving whole-fragment counts remain different.
The reader does not replay policy decisions or infer macro execution from an
offer. Full literal policy records remain archived.
The actual `example_policy` is exposed: displayed examples may prioritize
fulfilled final instances before chronological choices. They are inspection
examples, not a success-rate sample. Full retained-log metrics and exact
displayed/total coverage remain visible.

## Exclusive outputs and publication handoff

- `report/open-receptor-composition-20261104-v1.html`.
- `report/open-receptor-composition-20261104-data-v1.json`: canonical plain ASCII
  JSON plus LF of the authoritative projection, without field changes. No
  browser decompression dependency is introduced.
- `report/build-receipt-v1.json`, schema `Open-receptor-report-build-v1`, status
  `BUILT_FROM_ADMITTED_SAVED_DATA`; keys `protocol,source_projection,
  saved_data_audit,renderer_source,outputs:{main,data},artifact_pins,counts`.
  Refs use task-relative path, byte count and SHA-256.

Existing outputs refuse overwrite. The builder performs no package, Git,
network or deployment operation. Root owns subsequent archive-link injection,
postlink UI/admission and existing-site publication. Marker is exactly
`<!-- OPEN_RECEPTOR_COMPOSITION_ARCHIVE_LINK -->`; anchors `#reader`, `#evidence`.
Archive stems are `open-receptor-composition-20261104-evidence-v1-part-NNN.zip`
and `open-receptor-composition-20261104-evidence-v1-manifest.json`. Predecessor
is `receptor-family-transfer-20261104-v1.html`.

## Presentation scope

The native reader renders actual formulas in LaTeX through the established
MathJax CDN with serialized startup/typesetting; English explains each recorded
native rule and its exact references. Literal ASTs, display-only aliases and
downloadable native proof JSON remain available. Slot cards use orange activity,
purple formula-ID and cyan open-receptor layers. They depict semantic point
owners and remote marks, not geometry or a uniform Wang palette.

The unary calibration is seen; the nested statement has its own twelve-slot
bound. Plain primitive AND/OR lacks the fragment library, so no equally equipped
control or distinctive GCTS advantage is asserted. No RL, full PA, induction,
universal schematic theorem or geometric transfer is claimed. Current and reused
costs, policy setup, process guards and polling/high-water memory observations
are kept separate. Component subtotals are not assumed end-to-end timings.

The results table additionally joins each method's `phase` to `phases[].name`
and displays `costs.observed_process_seconds` separately from recorded row
components and policy setup. The casewise assessment reports actual rank/open
branch counts and rank/open/conventional observed process times, without
hardcoded outcomes. Missing values stay unrecorded. Fewer branches do not imply
speedup; single attempts do not establish a statistical or GCTS-specific claim.
Manual library-fragment changes clear the prior choice view and its selection;
actual observed choices remain separately selectable, preventing a stale
example from being presented for the newly selected template.

Before execution only Python AST and embedded JavaScript syntax inspection are
allowed. This file/API live outside all frozen scientific paths.
