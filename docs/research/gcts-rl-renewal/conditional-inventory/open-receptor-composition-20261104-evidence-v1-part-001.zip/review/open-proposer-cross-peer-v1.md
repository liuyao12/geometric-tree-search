# Open-fragment cross-peer Source review

Status: **PASS_SOURCE_REVIEW**. No remaining blocking Source/interface defect was
found after the authorized native-field correction below. This is a Source-only
review before scientific freeze/execution, not a qualification result.

The reviewer authored L and independently read X/Y in full, their API, the
authorized final narrow patches and the current H call sites. This note is not
an independent peer certification of the reviewer's own L implementation.

Exact held files rechecked at closure:

| File | Bytes | SHA256 |
|---|---:|---|
| `source/open_fragments_v1.py` | 30251 | `47f40989fb865db48d42a768540ab23e4a510d2a41b65b5a60cfc3956d8d5e04` |
| `plan/open-fragment-API-v1.md` | 9425 | `a3216a0ab9d78687eaeec5e26459d699f50097aa6a25f336c1636976549175ac` |
| `source/open_fragment_checker_v1.py` | 30717 | `cdf5af542d05eaeeaead00bb12db7a79bbb866ce2c3caef44b166bb2fb12ff02` |
| `source/open_fragment_qualification_v1.py` | 15123 | `270242611e514ff8ee9a322c4cd07bffa84c6bb3f9f40cd727c3b2c703ee34c5` |
| `review/open-fragment-checker-API-v1.md` | 10378 | `702fa572f120643394c72f1628e8ecb771c8169951b4421c274aeb40f8420cd7` |

The current primary master was read before authoring. Its SHA256 is
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.

The draft X used `line['axiom']` in its current-Gamma gate, while actual native
ZERO payloads use `name`. That would have rejected internal named-axiom
fragments. It was reported before any scientific execution. The final two X
accesses use `name`; Y's synthetic ZERO payloads now use the actual native field.
Y additionally includes an internal named-axiom plus MP fragment with an
unresolved external receptor, proposes it at an actual MP CID and independently
admits the resulting local instances. Exact previous drafts and narrow patches
are preserved under `review/source-iterations/`. No other X body changed.

X/Y match L's exact fragment and instance ID preimages: canonical body without
`id`, with no extra schema wrapper. X checks source/family/cluster associations,
erased fragment shape, rooted internal reachability, exact external boundary,
used boundary-visible parameters and all-and-only extraction relative to the
separately authenticated source library. Authentication/completeness/native
validity of that old library remain caller-owned conditions; X does not replay
the donor proof or prove universal schematic soundness.

Concrete admission substitutes only local payloads and receptor formulas. It
checks actual current formula IDs, full ZERO payloads, structural MP/GEN,
current named assumptions, GEN's current-Gamma side condition, strict earlier
reference slots, exact logical receptor demands and actual current CID
membership. The slot map contains precisely internal and external donor
indices, is injective and may move to different current slots. Root anchoring
is strict: the supplied anchor equals the root member's actual CID. Neither
current slots equal donor indices nor donor length equals current slot count is
required. Duplicate valid ZERO definition IDs are allowed by exact membership.

The full current RF/catalogue/model and native-ZERO admissions are external.
X's `VERIFIED_INSTANCE` is a local primitive-membership/compatibility receipt;
it is not a whole cover or a completed native proof. No outside payload or full
target expansion is restored, and external owners are never solved here.

The state path uses an independently admitted exact cached instance, verifies
request/model identity and exclusions, and aggregates distinct selected/internal
CIDs once. It checks all t/m/filter contributions, including remote mark-only
values, with assigned zero distinct from absence. The requested point must be
active and incomplete. A remaining member must be a legal contact at that
actual requested point; the original anchor may already be selected. Missing
external owners remain unresolved consistent demands. Complete domains,
generation/scheduler correctness and exact rollback are still E/C obligations.

X's cooperative admission budget is cumulative; local work/resource refusal is
UNKNOWN. Callback state work is charged to the engine, and hook exceptions
propagate unchanged. L has a separate timed setup index and per-query limits,
including at most 32 recommendations. Root H calls the agreed class/method and
records setup, proposal, admission and state costs. Empty/refused advice retains
all primitive alternatives; no proposal is turned into an absence certificate.

Y saves inputs and answers before assertions. Its synthetic local fixtures
exercise unresolved receptors, shared selected members, local exclusions and
restoration, binding/reference/binder mutations, zero-versus-absence, actual
local proposer/X integration and callback stop propagation. The goal-invariance
control changes only detached global metadata while retaining the local
catalogue/model, and explicitly makes no full RF/N admission claim for that
modified packet. These are planned executions, not observed outcomes. They do
not constitute native theorem or actual E-state qualification by themselves.

Only stdlib Source/data reads, exact byte hashes and Python AST parsing were
performed during this review. No scientific module was imported or invoked; no
materializer, proposer, checker, qualification, model builder, engine, decoder or
native kernel was executed. No old/frozen run was changed.
