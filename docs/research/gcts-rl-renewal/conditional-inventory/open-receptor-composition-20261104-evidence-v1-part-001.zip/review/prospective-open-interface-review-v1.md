# Open-interface and conventional-control review

Status: **DESIGN_REVIEW_ONLY**. No science, module import, constructor, helper,
search, checker call or test was executed. This note is not final Source closure
for the forthcoming proposer/checker/phase modules.

Read the complete current master, full RF constructor, full existing conventional
planner and V5's postcut open-interface/memory notes. Pinned inherited Sources:

| Source | Bytes | SHA-256 |
|---|---:|---|
| Master reference | 21657 | `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9` |
| `reference/finite_basis_v1.py` | 14044 | `97225dcffd98dd5386aeb560a2fc5634dfcc4606ff475a46536207768932a0dc` |
| `source/conventional_proof_search_v1.py` | 11127 | `d24bcafa8f7c3b6de91d7b41d7d76b9669b4a7e9f292061f7b87ecec73225a4f` |

The existing conventional planner consumes the complete admitted ZERO/MP/GEN
catalogue and optional scoped rank information. It creates shared-formula
acyclic candidates, checks original slot CIDs/PAD and primitive point markings,
then requires external M/N/B. It does not use the reference point scheduler or
a learned library. Its generator restrictions and resource/line failures remain
UNKNOWN. This makes it useful as a primitive-only control, not an equally
equipped comparator for warm fragment guidance. The proposed same-fragment
control must not be presumed implemented by merely passing rank information to
this unchanged API.

The key substantive gate is removal of the V5 whole-expansion oracle. The
serialized proper-fragment interface must omit outside primitive payloads;
neither proposer nor independent checker may reconstruct a complete donor-
length expansion or whole target proof as an admission prerequisite. Root and
external receptors define parameter visibility; unbound internal parameters
must be boundedly enumerated from the current catalogue or refused. Recursively
solving every receptor during matching would recreate the old shortcut.

Concrete fragment checks must bind the current model, statement/catalogue,
fragment template, term/context bindings, exact current CIDs and partial slot
map. Distinct owners and strict-prior references, actual named hypothesis
payloads, literal binders/capture conditions, seed/remote marks, ordinary filters
and selected-once union semantics remain mandatory. Missing owners are demands,
not new axioms or proved premises. Generalization refers to the actual closed
Gamma; importing a training hypothesis or temporarily treating a receptor as
an assumption would change the object theory.

Qualification should include an actually admitted proper fragment with an
unresolved receptor, a non-donor-length recipient, slot relocation preserving
strict-prior dependencies, an incompatible remote mark and selected owner,
shared selected identity, local exclusion then restoration, foreign/typed CID
and map mutations, and hook/resource refusal. Compare local matching under
irrelevant outside-donor/goal changes separately from global seed/state checks;
global compatibility may legitimately differ. Every current legal fallback and
the global scheduler must remain intact. A policy choice must be joined to
actual placement events before claiming adoption or composition.

Per-method process isolation addresses a documented cross-method retention
risk without weakening assurance. It is not a demonstrated memory bound or
algorithmic speedup. Guarded methods retain unadmitted prefixes and actual exit
status, not certificates promoted from a failed enclosing process.

No design-level blocker remains if these gates are implemented and independently
qualified. The two frozen statement choices are recorded in
`plan/open-cohort-design-v1.md`; they contain no target proof or skeleton.
Conformance and any claim of real open composition depend on the forthcoming
Sources and actual final certificates. Performance/novelty claims, a full PA or
Wang compiler, target/theory generalization and RL remain unestablished.
