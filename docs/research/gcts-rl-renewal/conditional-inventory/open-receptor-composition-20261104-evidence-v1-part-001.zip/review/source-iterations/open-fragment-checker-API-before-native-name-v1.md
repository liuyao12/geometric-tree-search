# Independent open-fragment checker and qualification

Source-only until full Root/peer review and prospective freeze. No scientific module has been imported or called during authorship. Python AST parsing is syntax inspection only. The checker imports stdlib `hashlib`, `json`, `math` and `time`; the qualification Source imports only `copy` and `time`.

Held Source pins:

- `source/open_fragment_checker_v1.py`: 30,719 bytes, SHA256 `a6e251332d4cfcdf50db8cc402860695320d0d96934ecb11c95976ebba925cae`.
- `source/open_fragment_qualification_v1.py`: 13,309 bytes, SHA256 `83d510406315ef067de766a64d45ccf3fb0ae7b1f2492d3357b4de9d637d5b17`.

The low-level JSON meter, substitution, literal AST syntax, model normalization and distinct-placement aggregation are copied from the independent V5 checker `source/receptor_checker_v1.py` (`f86ae81ccb0bc3cf1edc8b51572f47c66878a672707c16908eb70b9d77e8e1c1`). There is no V5 scientific import. Its whole-proof expansion, target-goal/template/prototype restoration and full-cover admission are absent from the new concrete checker.

## Public calls

```python
verify_materialization(old_library, library, limits=None)
AdmissionChecker(prepared, model, library, limits=None)
checker.admit(instance)
checker.check(instance, request, charge)
StateChecker = AdmissionChecker
admit(prepared, model, library, instance, limits=None)  # convenience only
```

Constructor `.status` is `READY`, `REJECTED` or `UNKNOWN`, with `.reason`. The long-lived indexed object must be constructed once per current model/method, not once per proposal. It exposes `.model_sha256` for the exact normalized current model. Each admitted instance is cached only after all checks and the final resource gate succeed. Cache keys hash the entire exact instance within that fixed model/library index; repeat lookup still validates the instance preimage. No complete target expansion, outside native payload, final cover or solver is cached.

All receipts contain `status`, `version`, native integer `work_delta`, and `costs={work,cumulative_work,seconds}`. `work_delta` equals the per-call `costs.work`; Root must charge that actual admission delta to E, including rejected/UNKNOWN calls. Constructor work/time is setup cost outside E. Admission work is cumulative across index construction and calls; each `.admit` call has its own declared wall ceiling, so idle time between callbacks is not counted as active checking. A resource refusal returns `UNKNOWN`, never an incompatibility proof or a complete negative.

Limits use the inherited exact five-key upper bounds: `max_work=100000000`, `wall_seconds=30.0`, `max_families=4096`, `max_instances=4096`, `max_lines=16`, lowerable only. `max_families` bounds stored fragments; `max_instances` bounds distinct successfully cached instances, not repeat cache hits. The current slot bound is 16; it is independent of donor length. Work is declared cooperative loop/string/serialization accounting, not physical memory or exact CPU instructions. Zero work gives UNKNOWN; malformed limits reject.

## Materialization

The exact library keys are `schema,status,source_library_sha256,donor_lines,fragments,costs,limits,scope`, with schema `Open-fragment-library-v1` and status `MATERIALIZED`. A fragment has exactly:

```text
id, family_id, cluster_id, root, members, lines, receptors, parameters
```

`lines` retains only internal donor-index/payload-template pairs. `receptors` retains only external donor-index/formula-template pairs. There is no full outside payload, source theory/goal, complete proof or prototype field. Fragment IDs hash their exact body without `id`; no extra schema wrapper is added. Every proper rooted connected source cluster of two through four internal members with a nonempty external boundary is retained iff all used parameters occur in its root formula or receptor formulas. Only those used term/context names are carried. IDs, sorted membership, strict references, exact external boundary, rooted reachability and boundary visibility are checked independently.

`verify_materialization` checks both source-library/cluster/family preimages and the exact extraction, omissions and extras against the supplied old library. It returns `VERIFIED_MATERIALIZATION` with `bindings={source_library_sha256,library_sha256}` and the complete fragment count, or `REJECTED`/`UNKNOWN`. Authentication/native validity and completeness of the original V5 library remain separate caller-owned gates; this call does not replay donor native logic or assert universal validity of a learned template.

## Concrete local admission

Instance fields are exactly `id,fragment_id,bindings,slot_map,line_cids,receptors,anchor_cid`. The ID hashes the exact body without `id`. `bindings` supplies the shared used term/context assignments; terms have no holes and contexts exactly one. `slot_map` is sorted by donor index, contains every internal and external index exactly once, is injective into current slots, and respects all internal strict-prior references. There is no requirement that current slots equal donor length. `line_cids` contains only internal donor-index/current-CID pairs; `receptors` contains external donor-index/current-slot/current-formula triples.

The checker substitutes only these local templates and receptors, checks their current syntax/formula IDs and exact current ZERO/MP/GEN definitions, named current axioms and GEN freedom from free variables in the current Gamma. It checks actual native payload equality for ZERO, current reference slots and logical active/formula receptor marks, the distinct internal t/m/filter union against the current seed, and requires `anchor_cid` to equal the root member's actual current CID. Duplicate valid ZERO definitions are permitted when their actual CID/native payload is correct; no lexicographic-minimum requirement is imposed.

Success is `VERIFIED_INSTANCE`, with `bindings={model_sha256,instance_sha256,statement_sha256,library_sha256,prepared_scope,fragment_id}`, `cluster_cids`, and the exact receptor list. This is concrete local membership/compatibility only. Full RF/basis/native-ZERO/generic model admission is external. Neither current whole goal equality nor outside payload validity, receptor solution, full cover, decoder or native theorem validity is asserted.

## State check and fallback

`.check` requires the exact instance to be in this index's independently admitted cache. It consumes the unchanged `Z-candidate-order-request-v1` fields: `schema,model_sha256,point,generation,legal,selected,excluded`. It checks current IDs and context exclusions, aggregates selected plus internal members with shared CIDs counted once, and checks all t/m/filter contributions including far mark-only literals. An assigned string zero is a value; absence is unconstrained.

The requested point must be active and incomplete. At least one remaining internal member must occur in the actual requested legal contacts. The original root anchor may already be selected. Missing external owners are allowed: their receptor marks are unresolved consistent demands, not solved obligations. `COMPATIBLE` includes `preferred`, exact model/instance/selected/excluded/union hashes, shared/new member counts and costs. The index does not reconstruct the complete engine domain or choose a point; scheduler and complete primitive fallback remain E/C4 obligations. `REJECTED` refuses this proposal only.

Every callback charge is forwarded. Any exception from `charge`, including one sharing a checker exception type, escapes unchanged so cleanup stays under the engine's control. Only genuine checker-local rejection is converted to a rejection receipt.

## Qualification Source, not results

```python
Y.run_library(ctx, old_library, newly_materialized_library)
Y.run_instances(ctx, prepared, model, materialized_library)
```

`ctx` supplies `.mods['L'/'X']`, `.limits['family']` (or X alias), `.save`, `.sha`, `.wire`. Both return `QUALIFIED` only after actual saved outcomes match their declared controls. They perform no E or native-kernel call. `run_library` compares the actual materialization plus foreign source, missing fragment, forbidden outside payload, missing receptor and work-zero controls.

`run_instances` uses an explicitly synthetic partial MP/GEN fragment with two unresolved external receptor owners, three-point demands, shared parameter and a real assigned mark-only zero. This static fixture is local ABI data, not a target theorem/proof witness, complete RF/N model admission or observed GCTS state. It tests current binding, receptor formula/slot, CID and GEN binder mutations; work-zero UNKNOWN; unresolved receptors; already-selected root/shared-once union; distinct-owner overlap; local exclusion/restoration; assigned-zero versus absence; and charge-stop propagation.

It additionally calls the actual L `LocalProposer` on that small local anchor, requires nonempty local recommendations and independent X admission, then changes only an irrelevant detached `prepared.statement.goal` and unrelated outside metadata while keeping catalogue, definitions, boundary and model fixed. Matching instances must be identical; the modified packet is deliberately not globally RF/N-admitted. A proposer hook sentinel must propagate. This tests the intended stage separation, not proof validity of the modified whole statement.

Inputs and answers are saved before assertions. Per-case instance-qualification paths include the actual current prepared scope prefix, avoiding collisions between two declared cases. No qualification output is claimed until Root actually executes the prospectively frozen Source.
