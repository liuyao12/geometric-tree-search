Open receptor composition: complete physical evidence, explicit finite scope.

Download all open-receptor-composition-20261104-evidence-v1-part-NNN.zip files
and open-receptor-composition-20261104-evidence-v1-manifest.json. Extract the
volumes together. Every volume is at most 44 MiB, below 50 MiB, and contains the
same ARCHIVE-file-manifest-v1.json. Every original run path at the cut is
physically stored exactly once. Identical bytes at different paths are retained
as separate members. Member sizes, SHA256, ZIP CRC and exact path sets are
verified before a task-only isolated commit is prepared. No push is performed.

The full current Sources, input/reference/plan/reviews, raw results/endpoints/
events, UNKNOWN/refusal/failure prefixes, native receipts, fragment/proposal/
state records, logs and local paths are included. Only generated package/
outputs are excluded. Reader/tool Sources, original pre-link render and the
changed predecessor-reader backlink are included before the cut. Later commit,
push/Pages/live receipts are later custody, not claimed inside their own archive.
The existing public destination and all these evidence categories were approved
by the user. Prior milestone archives are linked separately, not silently copied.

The old library is untrusted warm proposal data. Only proper rooted fragments
with two through four internal nodes and unresolved external receptors are
exported to current method workers. Their local primitive/current-state checks
are separate from final native theorem acceptance. Arbitrary partial slot
relocation is allowed; no full donor proof or whole target goal is instantiated
by the local proposer. External demands are not pre-solved. All primitive
fallbacks, mandatory markings, complete graph scheduling and rollback remain.

Read actual ten phase/process records and target proof admissions separately.
A workflow status, complete emitted UNKNOWN prefix, compatible proposal or
failed-process positive prefix is not an admitted target proof/refutation.
The conventional control lacks the fragment library, so no equally equipped
comparison, speed superiority, RL, universal-schema or fixed-Wang claim follows.
Costs include preparation, local proposal/admission, semantic and native checks.
Serve the extracted directory and open report/open-receptor-composition-20261104-v1.html.
The larger research program remains ACTIVE.
