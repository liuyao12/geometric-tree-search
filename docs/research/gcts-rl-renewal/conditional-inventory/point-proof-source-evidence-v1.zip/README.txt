Source implementation milestone, 22 October 2026

No scientific implementation is imported or executed by this packaging.
All prospective16 point groups remain unrun. No theorem, proof, resource fit or GCTS/RL effect is admitted.
The v1 kernel keyword negative and v2 correction are both retained.
This component archive is not a closed runnable whole experiment; referenced original runtime/calculus documents remain external.
For each raw member use MANIFEST.json for exact bytes and SHA256.
