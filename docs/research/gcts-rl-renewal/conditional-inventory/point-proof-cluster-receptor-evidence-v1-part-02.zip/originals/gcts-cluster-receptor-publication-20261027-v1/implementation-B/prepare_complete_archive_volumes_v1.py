"""Targeted complete immutable-byte packaging; no scientific Source imports/replay."""
from pathlib import Path
import os,stat,json,hashlib,zipfile,collections,datetime,time
PUB=Path('/private/tmp/gcts-cluster-receptor-publication-20261027-v1')
B=PUB/'implementation-B'
OUT=B/'complete-archive-volumes-v1'
N1=Path('/private/tmp/gcts-cluster-receptors-20261027-v1')
N2=Path('/private/tmp/gcts-cluster-receptors-20261027-v2')
PARENT=Path('/private/tmp/gcts-corner-family-publication-20261027-v1/root/publication-corner-family-v1/point-proof-corner-family-evidence-v1.zip')
NAMES=['point-proof-cluster-receptor-evidence-v1.zip']+['point-proof-cluster-receptor-evidence-v1-part-'+str(i).zfill(2)+'.zip'for i in range(2,9)]
CAP=67108864;PREFERRED=60*1024*1024
started=time.perf_counter()
def enc(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def stable(p):
 assert p.is_absolute() and p.resolve()==p and not p.is_symlink(),str(p)
 a=p.stat(follow_symlinks=False);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1,str(p)
 b=p.read_bytes();z=p.stat(follow_symlinks=False)
 assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns) and len(b)==a.st_size,str(p)
 return b,{'source_path':str(p),'bytes':len(b),'sha256':sha(b),'original_mode':stat.S_IMODE(a.st_mode),'cut_mtime_ns':a.st_mtime_ns}
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(n,v):
 p=OUT/n;assert not p.exists();p.write_bytes(enc(v));return pin(p)
assert not OUT.exists(),'new immutable output directory required'
OUT.mkdir()
discovery=json.loads((B/'archive-peer-discovery-cut-v2.json').read_text())
external=[Path(p)for p in discovery['included_external_peer_directories']]
# Every discovered exact review/support pin is authenticated, without following old Source/data ancestry.
for r in discovery['bounded_exact_refs_from_current_Root_adoptions_and_named_peer_packet_refs']:
 bb,_=stable(Path(r['path']));assert len(bb)==r['bytes'] and sha(bb)==r['sha256'],r['path']
roots=[N1,N2,PUB]+external
singlefiles=[Path(r['path'])for r in discovery['other_exact_singlefiles']]+[PARENT]
# Explicit task-defined cuts. Files created after the enumerated cut are not implicit members.
excluded_roots=[OUT,PUB/'publisher-payload',PUB/'publisher-multipart-payload',PUB/'independent-L',PUB/'root/publication-cluster-receptor-v1',PUB/'root/publication-cluster-receptor-multipart-v1',PUB/'root/publication-cluster-receptor-api-v1',PUB/'root/publication-cluster-receptor-multipart-api-v1',PUB/'root/cluster-receptor-live-TLS-verification-v1',PUB/'root/cluster-receptor-multipart-live-TLS-verification-v1']
exclusions=[];paths=set()
def reason(p):
 for q in excluded_roots:
  if p==q or p.is_relative_to(q):return 'Explicit output/staging/execution-receipt/final-summary root outside archive preparation cut: '+str(q)
 if p.parent==PUB/'root/report-assembly-v1' and p.suffix=='.html':return 'Final current section/web HTML outside archive preparation cut; assembler Source/provenance/static JS retained.'
 if p.suffix.lower()=='.zip' and p!=PARENT:return 'Draft/output ZIP excluded; only exact separately authorized Mark20 parent ZIP included.'
 return None
for root in roots:
 assert root.is_dir() and not root.is_symlink(),str(root)
 for dp,dirs,files in os.walk(root,topdown=True,followlinks=False):
  directory=Path(dp);keep=[]
  for n in sorted(dirs):
   q=directory/n;assert not q.is_symlink(),str(q);r=reason(q)
   if r:exclusions.append({'path':str(q),'kind':'directory','reason':r})
   else:keep.append(n)
  dirs[:]=keep
  for n in sorted(files):
   p=directory/n;r=reason(p)
   if r:exclusions.append({'path':str(p),'kind':'file','reason':r})
   else:paths.add(p)
for p in singlefiles:
 assert p.is_file() and not p.is_symlink();paths.add(p)
# Full original raw-byte inventory. No JSON decoding of scientific originals.
rows=[];byroot=collections.Counter();cut_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
for p in sorted(paths,key=str):
 bb,row=stable(p);row['archive_name']='originals/'+str(p.relative_to('/private/tmp'))
 assert not row['archive_name'].startswith('/') and '..'not in Path(row['archive_name']).parts
 rows.append(row)
 for root in roots:
  if p.is_relative_to(root):byroot[str(root)]+=1;break
 else:byroot['exact_singlefiles']+=1
assert len({r['archive_name']for r in rows})==len(rows) and len({r['source_path']for r in rows})==len(rows)
# Raw-size LPT balancing is deterministic, all bytes preserved. No dedup/reencoding of originals.
bins=[[]for _ in range(8)];raw_sizes=[0]*8
for row in sorted(rows,key=lambda r:(-r['bytes'],r['archive_name'])):
 i=min(range(8),key=lambda k:(raw_sizes[k],k));bins[i].append(row);raw_sizes[i]+=row['bytes'];row['part']=i+1;row['volume_name']=NAMES[i]
assert max(raw_sizes)<=PREFERRED,('raw60MiBpreferred bins exceeded',raw_sizes)
for part in bins:part.sort(key=lambda r:r['archive_name'])
cut={'schema':'Root-cluster-receptor-complete-archive-original-cut-v1','cut_utc':cut_utc,'cut_definition':'Exact enumerated immutable file list, not an atomic filesystem snapshot and not future directory contents. Included files stable whole-read and rehashed at write/postread. New later publication/report/summary/TLS/browser artifacts are external cut, not silently admitted.','targeted_directory_roots':[str(r)for r in roots],'exact_singlefiles':[str(p)for p in singlefiles],'discovery':pin(B/'archive-peer-discovery-cut-v2.json'),'all_original_file_count':len(rows),'all_original_raw_bytes':sum(r['bytes']for r in rows),'by_root_counts':dict(byroot),'explicit_excluded_roots':[str(r)for r in excluded_roots],'encountered_exclusions':exclusions,'never_accessed':'No repository/index/primary reader/.gcts-active/protected paths; no broad /private/tmp or repository scan. Parent history is opaque exact published Mark20 ZIP, not recursive body expansion.','raw_original_rows':sorted(rows,key=lambda r:r['archive_name']),'raw_bin_bytes':raw_sizes,'all_original_bytes_preserved':True,'compression':'Normal independent ZIP_DEFLATED level6; deterministic1980 timestamp, regular0644 entries; raw content byteexact, original mode/mtime recorded above.','scientific_execution':False}
cutref=write('complete-evidence-original-cut-and-inventory-v1.json',cut)
manifest={'schema':'Root-cluster-receptor-complete-eight-volume-global-manifest-v1','archive_names':NAMES,'all8_required':True,'normal_independent_ZIP_volumes':True,'all_original_file_count':len(rows),'all_original_raw_bytes':sum(r['bytes']for r in rows),'cut_utc':cut_utc,'cut_inventory_sha256':cutref['sha256'],'scope':'Complete enumerated immutable N1 failed and N2 admitted files, Sources/ABIs/peer/Root/captures/current consent and Mark20 parent ZIP. N1 whole failed attempt remains unadmitted/spent; N2 scope is exactly current finite Root adoption. No theorem/infinite/FOL/universal/causal superiority claim. Final web HTML/summary and subsequent publication/TLS/browser receipts excluded by explicit preparation cut.','self_exclusion':'Manifest,8derived READMEs,package cut/inventory,ZIP volumes and readback/handoff outputs are generated packaging metadata, not original rows. ZIP hashes live only in external package inventory to avoid self cycles.','originals':[{'original_path':r['source_path'],'archive_name':r['archive_name'],'part':r['part'],'volume_name':r['volume_name'],'bytes':r['bytes'],'sha256':r['sha256']}for r in sorted(rows,key=lambda r:r['archive_name'])]}
manifestbytes=enc(manifest);manifestref=write('complete-evidence-global-manifest-v1.json',manifest)
readmes=[]
for i in range(8):
 text=('Cluster/receptor complete evidence volume '+str(i+1)+' of 8\n\n'
       'ALL EIGHT FILES ARE NEEDED for the complete evidence collection. Each file is an ordinary, independent ZIP archive; extract every volume normally into one empty common directory, or extract separately and combine their nonoverlapping original paths. Do not concatenate ZIP files or treat them as a split ZIP stream.\n\n'
       'The complete self-excluding global original manifest is catalogue/complete-evidence-global-manifest-v1.json in volume 1. It maps every immutable original absolute path to its stable relative extraction name, part, byte count and SHA256. Each original is present once; no content deduplication or scientific reencoding occurred.\n\n'
       'Volume files:\n'+'\n'.join(NAMES)+'\n\n'
       'This part contains '+str(len(bins[i]))+' original files, '+str(raw_sizes[i])+' raw original bytes. N1 failed originals remain failed/unadmitted/spent. N2 admission is only the exact stored finite-study Root disposition. Final web HTML/summary and later publication/TLS/browser receipts are deliberately outside this archive preparation cut. Source/static/old draft documents preserve chronology, not an independent new admission.\n')
 readmes.append(text.encode())
expected_generated={};volume_refs=[]
for i,name in enumerate(NAMES):
 zp=OUT/name;assert not zp.exists()
 with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True)as z:
  def add(arc,raw):
   info=zipfile.ZipInfo(arc,date_time=(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
   z.writestr(info,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
  rname='README-part-'+str(i+1).zfill(2)+'.txt';add(rname,readmes[i]);expected_generated[(i+1,rname)]={'bytes':len(readmes[i]),'sha256':sha(readmes[i])}
  if i==0:
   mname='catalogue/complete-evidence-global-manifest-v1.json';add(mname,manifestbytes);expected_generated[(i+1,mname)]={'bytes':len(manifestbytes),'sha256':sha(manifestbytes)}
  for row in bins[i]:
   raw,current=stable(Path(row['source_path']));assert current['bytes']==row['bytes']and current['sha256']==row['sha256']and current['cut_mtime_ns']==row['cut_mtime_ns'];add(row['archive_name'],raw)
 assert zp.stat().st_size<=CAP,(name,zp.stat().st_size)
 volume_refs.append(pin(zp));print('WROTE',i+1,len(bins[i]),raw_sizes[i],volume_refs[-1]['bytes'],flush=True)
# Whole ZIP CRC plus complete every-member byte/hash readback. No archive member is executed or interpreted as science.
readbacks=[];global_seen=set();original_seen=set()
for i,vr in enumerate(volume_refs):
 with zipfile.ZipFile(vr['path'],'r')as z:
  assert z.testzip()is None
  infos=z.infolist();names_now=[x.filename for x in infos];assert len(names_now)==len(set(names_now))
  expected={r['archive_name']:{'bytes':r['bytes'],'sha256':r['sha256'],'original_path':r['source_path']}for r in bins[i]}
  expected.update({n:v for (part,n),v in expected_generated.items()if part==i+1})
  assert set(names_now)==set(expected)
  for info in infos:
   assert info.compress_type==zipfile.ZIP_DEFLATED and not info.is_dir()and info.filename not in global_seen
   global_seen.add(info.filename);raw=z.read(info.filename);wanted=expected[info.filename]
   assert len(raw)==info.file_size==wanted['bytes']and sha(raw)==wanted['sha256']
   if 'original_path'in wanted:original_seen.add(wanted['original_path'])
   readbacks.append({'part':i+1,'volume_name':NAMES[i],'archive_name':info.filename,'bytes':len(raw),'sha256':sha(raw),'CRC32':format(info.CRC,'08x'),'full_readback':'MATCH','original_path':wanted.get('original_path'),'derived_packaging_metadata':'original_path'not in wanted})
 assert pin(Path(vr['path']))==vr;print('VERIFIED',i+1,'CRC+allbytes',len(infos),flush=True)
assert len(original_seen)==len(rows)and original_seen==set(r['source_path']for r in rows)
# Full original postguard byte identity, not just a stat comparison.
for row in rows:
 bb,rr=stable(Path(row['source_path']));assert rr['bytes']==row['bytes']and rr['sha256']==row['sha256']and rr['cut_mtime_ns']==row['cut_mtime_ns']
verify={'schema':'Root-cluster-receptor-eight-volume-complete-CRC-byte-readback-v1','status':'COMPLETE_ADMIN_BYTE_INTEGRITY_PASS','volumes':volume_refs,'original_cut':cutref,'global_manifest':manifestref,'all8_independent_normal_DEFLATE':True,'all8_bytes_le64MiB':True,'preferred_raw_bins_le60MiB':True,'all_original_full_postguards_matched':True,'all_original_count':len(rows),'all_original_raw_bytes':sum(r['bytes']for r in rows),'total_ZIP_member_count':len(readbacks),'original_member_count':len(original_seen),'derived_README_count':8,'derived_manifest_count':1,'unique_archive_names_across_all8':True,'all_zip_testzip_CRC_passed':True,'every_member_full_bytes_hash_readback':readbacks,'no_original_omitted_deduplicated_or_reencoded':True,'scientific_calls':0,'network_publication':False,'no_self_cycle':'ZIP hashes and generated receipt hashes are outside volumes; included global manifest lists originals only and excludes itself.'}
verifyref=write('complete-evidence-volumes-CRC-and-all-member-readback-v1.json',verify)
inventory={'schema':'Root-cluster-receptor-complete-eight-volume-package-inventory-v1','status':'COMPLETE_ADMIN_PACKAGE_READY_ROOT_ACCEPTANCE_PENDING','volumes':[dict(v,part=i+1,original_count=len(bins[i]),original_raw_bytes=raw_sizes[i])for i,v in enumerate(volume_refs)],'all_original_count':len(rows),'all_original_raw_bytes':sum(r['bytes']for r in rows),'total_volume_bytes':sum(v['bytes']for v in volume_refs),'original_cut':cutref,'global_manifest':manifestref,'complete_CRC_and_raw_member_readback':verifyref,'packager_Source':pin(Path(__file__)),'scope':'Archive preparation cut, not final report/summary or later pub/TLS/browser receipts. Same approved audience. Preserves all complete immutable cut files and exact Mark20 parent ZIP; no original scientific codec/solver/helper executed. Root package/source/content/admission and A9/live gates remain separate.','targeted_external_peer_directories':[str(x)for x in external],'encountered_exclusions':exclusions,'declared_excluded_roots':[str(x)for x in excluded_roots],'publication_authorized':False,'scientific_execution':False}
invref=write('complete-evidence-eight-volume-package-inventory-v1.json',inventory)
handoff={'schema':'Root-cluster-receptor-complete-eight-volume-package-handoff-v1','status':'COMPLETE_ADMIN_BYTE_PACKAGE_NO_PUBLICATION','package_inventory':invref,'volumes':volume_refs,'all_original_count':len(rows),'all_original_raw_bytes':sum(r['bytes']for r in rows),'global_manifest':manifestref,'cut':cutref,'readback':verifyref,'parent_Mark20_archive_included':next(r for r in rows if r['source_path']==str(PARENT)),'targeted_peer_directory_count':len(external),'full_originals_and_generated_member_counts':[len(rows),9],'every_original_and_member_full_hash_postguard':True,'scope':'All8needed. Final report/summary and later publication/TLS/browser evidence are external this package preparation cut; Root will review exact inventory before staging/once. No automatic publisher invocation.','elapsed_administrative_seconds':time.perf_counter()-started,'scientific_calls':0,'network_calls':0,'terminal_state':'IDLE'}
hr=write('complete-evidence-eight-volume-package-handoff-v1.json',handoff)
print(json.dumps({'handoff':hr,'inventory':invref,'cut':cutref,'readback':verifyref,'original_count':len(rows),'raw_original_bytes':sum(r['bytes']for r in rows),'volumes':volume_refs,'exclusions':exclusions,'external_peer_dirs':len(external)},sort_keys=True),flush=True)
