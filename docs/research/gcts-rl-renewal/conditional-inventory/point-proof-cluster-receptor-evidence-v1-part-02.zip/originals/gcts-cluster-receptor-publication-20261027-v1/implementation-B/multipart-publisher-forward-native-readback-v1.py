"""Inert, once-authorized P2-only ten-path Git Data API multipart publication.

No local Git operations or scientific imports. No automatic network retry.
An uncertain mutation outcome is retained for read-only reconciliation.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

SELF = Path(__file__).resolve()
ROOT = Path("/private/tmp/gcts-cluster-receptor-publication-20261027-v1/root")
STUDY = ROOT.parent
REPO = Path("/Users/liuyao/Documents/Codex/projects/geometric-tree-search")
P2 = REPO / "research-runs/gcts-batch-20261020/publisher-recovery-6338a77"
STAGE = Path("/private/tmp/gcts-cluster-receptor-publication-20261027-v1/publisher-multipart-payload")
ROOT_STAGE = ROOT / "publication-cluster-receptor-multipart-v1"
OUT = ROOT / "publication-cluster-receptor-multipart-api-v1"
PREFIX = "docs/research/gcts-rl-renewal/conditional-inventory/"
NAMES = ("point-proof-parallel-progress-v1.html",
         "point-proof-cluster-receptor-summary-v1.json",
         "point-proof-cluster-receptor-evidence-v1.zip",
         "point-proof-cluster-receptor-evidence-v1-part-02.zip",
         "point-proof-cluster-receptor-evidence-v1-part-03.zip",
         "point-proof-cluster-receptor-evidence-v1-part-04.zip",
         "point-proof-cluster-receptor-evidence-v1-part-05.zip",
         "point-proof-cluster-receptor-evidence-v1-part-06.zip",
         "point-proof-cluster-receptor-evidence-v1-part-07.zip",
         "point-proof-cluster-receptor-evidence-v1-part-08.zip")
BASELINE = "5e2663862dddd3892591e9149169da50b20ca457"
PYTHON = {"path": "/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12",
          "bytes": 18058560,
          "sha256": "d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840"}
GH = "/Users/liuyao/bin/gh"
API = "repos/liuyao12/geometric-tree-search/"
CAP = 67108864
ADMIN_CAP = 1048576


def need(ok, message):
    if not ok:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def parse(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, "duplicate JSON key")
            out[key] = value
        return out

    def nonfinite(value):
        raise ValueError("nonfinite JSON constant: " + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def canonical(value):
    need(type(value) is str, "literal absolute path required")
    p = Path(value)
    need(p.is_absolute() and str(p) == value and os.path.normpath(value) == value
         and all(not a.is_symlink() for a in (p, *p.parents)) and p.resolve() == p,
         "canonical nonsymlink path required")
    return p


def pin(path, raw):
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def read(path, cap=CAP):
    canonical(str(path))
    before = path.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= cap,
         "bounded single-link regular file required")
    with path.open("rb") as handle:
        raw = handle.read(cap + 1)
    after = path.stat(follow_symlinks=False)
    need(len(raw) <= cap and len(raw) == before.st_size == after.st_size
         and (before.st_dev, before.st_ino, before.st_mtime_ns)
         == (after.st_dev, after.st_ino, after.st_mtime_ns), "changed or incomplete input")
    return raw


def ref(value, cap=CAP):
    need(type(value) is dict and set(value) == {"path", "bytes", "sha256"}
         and type(value["bytes"]) is int and 0 <= value["bytes"] <= cap
         and type(value["sha256"]) is str
         and re.fullmatch("[0-9a-f]{64}", value["sha256"]), "exact bounded rawref required")
    p = canonical(value["path"])
    raw = read(p, cap)
    need(pin(p, raw) == value, "full rawref mismatch")
    return raw


def write(path, raw):
    need(len(raw) <= CAP, "administrative output bound")
    canonical(str(path))
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    need(read(path) == raw, "complete administrative output readback")
    return pin(path, raw)


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def api(label, method, suffix, body=None):
    need(re.fullmatch("[a-z0-9_-]+", label) is not None, "fixed response label")
    argv = [GH, "api", "--hostname", "github.com", "--method", method,
            "-H", "Accept: application/vnd.github+json", API + suffix]
    request = None
    if body is not None:
        argv += ["--input", "-"]
        request = encode(body)
    result = subprocess.run(argv, input=request, capture_output=True, timeout=60,
                            check=False, cwd=P2)
    write(OUT / (label + "-stdout.json"), result.stdout)
    write(OUT / (label + "-stderr.bin"), result.stderr)
    need(result.returncode == 0 and len(result.stderr) <= 65536,
         "GitHub request failed; no automatic retry: " + label)
    return parse(result.stdout)


def sha(value):
    need(type(value) is str and re.fullmatch("[0-9a-f]{40}", value), "Git object SHA required")
    return value


def head(label):
    value = api(label, "GET", "git/ref/heads/main")
    need(value["ref"] == "refs/heads/main" and value["object"]["type"] == "commit",
         "fixed main commit ref required")
    return sha(value["object"]["sha"])


def leaves(label, tree):
    value = api(label, "GET", "git/trees/" + sha(tree) + "?recursive=1")
    need(value["sha"] == tree and value["truncated"] is False
         and type(value["tree"]) is list, "complete recursive tree required")
    out, seen = {}, set()
    for item in value["tree"]:
        path = item["path"]
        need(type(path) is str and path and path not in seen, "unique tree path required")
        seen.add(path)
        sha(item["sha"])
        need(item["type"] in ("tree", "blob", "commit"), "known tree entry type")
        if item["type"] != "tree":
            out[path] = {k: item[k] for k in ("mode", "type", "sha")}
    return out


def publish(authority_arg):
    need(SELF == Path("/private/tmp/gcts-cluster-receptor-publication-20261027-v1/implementation-B/publish_cluster_receptor_multipart_api_v1.py")
         and Path.cwd() == P2, "fixed Source and isolated P2 working directory required")
    need(__debug__ and sys.flags.isolated and sys.flags.no_site
         and sys.flags.no_user_site and sys.flags.safe_path and sys.flags.ignore_environment
         and sys.dont_write_bytecode and sys.flags.optimize == 0
         and sys.platform == "darwin" and sys.version_info[:3] == (3, 12, 14)
         and Path(sys.executable).resolve() == Path(PYTHON["path"]), "D90 -I -S -B required")
    authority_path = canonical(authority_arg)
    need(authority_path.parent == ROOT and authority_path.suffix == ".json", "Root authority path")
    authority_raw = read(authority_path, ADMIN_CAP)
    a = parse(authority_raw)
    need(type(a) is dict and set(a) == {"schema", "authorized", "uses", "staging",
         "publisher", "python", "expected_baseline_blob", "human_publication_authorization", "expected_main_head"},
         "authority exact nine fields")
    need(a["schema"] == "Root-cluster-receptor-multipart-P2-publication-once-authority-v1"
         and a["authorized"] is True and type(a["uses"]) is int and a["uses"] == 1
         and a["python"] == PYTHON and a["expected_baseline_blob"] == BASELINE,
         "fixed once authority values")
    sha(a["expected_main_head"])
    need(a["publisher"]["path"] == str(SELF), "own Source binding")
    ref(a["publisher"], ADMIN_CAP)
    ref(PYTHON, PYTHON["bytes"])
    approval_path = canonical(a["human_publication_authorization"]["path"])
    need(approval_path.parent == ROOT, "Root human authorization record required")
    ref(a["human_publication_authorization"], ADMIN_CAP)
    need(a["staging"]["path"] == str(ROOT_STAGE / "P2-staging.json"), "fixed staging metadata")
    stage_raw = ref(a["staging"], ADMIN_CAP)
    stage = parse(stage_raw)
    files = stage["files"]
    need(stage["schema"] == "Root-cluster-receptor-multipart-publication-ten-path-staging-v1"
         and stage["scientific_execution"] is False and stage["publication"] is False
         and type(files) is list and len(files) == 10, "reviewed preparer ten files required")
    need({p.name for p in STAGE.iterdir()} == set(NAMES), "P2 exact ten-file payload census")
    for row, name in zip(files, NAMES, strict=True):
        need(set(row) == {"path", "root_source", "publisher_source", "bytes", "sha256", "git_blob_sha1"}
             and row["path"] == PREFIX + name and row["root_source"] == str(ROOT_STAGE / name)
             and row["publisher_source"] == str(STAGE / name), "fixed ten payload rows")
        need(type(row["bytes"]) is int and 0 <= row["bytes"] <= CAP
             and re.fullmatch("[0-9a-f]{64}", row["sha256"]) is not None,
             "bounded payload extent/hash")
        sha(row["git_blob_sha1"])
    marker = Path(str(authority_path) + ".CONSUMED.json")
    need(not marker.exists() and not marker.is_symlink() and not OUT.exists()
         and not OUT.is_symlink(), "fresh once marker and API receipt directory required")
    consume = write(marker, encode({"schema": "Root-cluster-receptor-multipart-P2-publication-consumed-v1",
         "authority": pin(authority_path, authority_raw), "publisher": a["publisher"],
         "staging": a["staging"], "uses": 1, "network_started_at_consume": False}))
    sync_dir(ROOT)
    OUT.mkdir(mode=0o700)
    bodies = []
    for row in files:
        raw = ref({"path": row["publisher_source"], "bytes": row["bytes"], "sha256": row["sha256"]})
        need(raw == ref({"path": row["root_source"], "bytes": row["bytes"], "sha256": row["sha256"]})
             and hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
             == row["git_blob_sha1"], "complete twins and Git blob hash required")
        bodies.append(raw)
    before_head = head("01-head-before")
    need(before_head == a["expected_main_head"], "fresh main differs from reviewed head; refuse without retry")
    commit_before = api("02-commit-before", "GET", "git/commits/" + before_head)
    need(commit_before["sha"] == before_head, "fresh parent commit identity")
    before_tree = sha(commit_before["tree"]["sha"])
    before = leaves("03-tree-before", before_tree)
    targets = {row["path"] for row in files}
    need(before.get(files[0]["path"]) == {"mode": "100644", "type": "blob", "sha": BASELINE}
         and all(row["path"] not in before for row in files[1:]), "remote baseline/new-path guard")
    for i, (row, raw) in enumerate(zip(files, bodies, strict=True)):
        created = api("04-blob-" + str(i), "POST", "git/blobs",
                      {"content": base64.b64encode(raw).decode("ascii"), "encoding": "base64"})
        need(created["sha"] == row["git_blob_sha1"], "remote complete payload blob identity")
    tree = api("05-create-tree", "POST", "git/trees", {"base_tree": before_tree,
          "tree": [{"path": row["path"], "mode": "100644", "type": "blob",
                    "sha": row["git_blob_sha1"]} for row in files]})
    after_tree = sha(tree["sha"])
    after = leaves("06-tree-after", after_tree)
    need({k: v for k, v in before.items() if k not in targets}
         == {k: v for k, v in after.items() if k not in targets}, "all nontarget leaves must be identical")
    need(all(after.get(row["path"]) == {"mode": "100644", "type": "blob",
         "sha": row["git_blob_sha1"]} for row in files), "all ten target leaves exact")
    commit = api("07-create-commit", "POST", "git/commits", {
        "message": "Publish cluster-receptor outcomes and complete multipart evidence",
        "tree": after_tree, "parents": [before_head]})
    new_head = sha(commit["sha"])
    need(commit["tree"]["sha"] == after_tree
         and [p["sha"] for p in commit["parents"]] == [before_head], "single fresh parent/tree")
    need(head("08-head-before-update") == before_head, "main moved; refuse without retry")
    updated = api("09-update-main", "PATCH", "git/refs/heads/main", {"sha": new_head, "force": False})
    need(updated["ref"] == "refs/heads/main" and updated["object"]["sha"] == new_head,
         "main update receipt mismatch; reconcile without retry")
    need(head("10-head-after") == new_head, "post-update main differs; reconcile without retry")
    need(read(authority_path, ADMIN_CAP) == authority_raw and ref(a["staging"], ADMIN_CAP) == stage_raw,
         "post metadata guards")
    ref(a["publisher"], ADMIN_CAP)
    ref(PYTHON, PYTHON["bytes"])
    result = {"schema": "Root-cluster-receptor-multipart-P2-publication-terminal-v1",
        "status": "EXACT_TEN_PATHS_COMMITTED_LIVE_CHECK_PENDING", "commit": new_head,
        "parent": before_head, "before_tree": before_tree, "after_tree": after_tree,
        "before_leaf_count": len(before), "after_leaf_count": len(after),
        "nontarget_leaves_preserved": len(before) - 1, "files": files,
        "authority": pin(authority_path, authority_raw), "consume": consume,
        "all_nontarget_leaf_values_equal": True, "force": False,
        "local_git_operations": 0, "scientific_execution": False,
        "scope": "Publication API only. GitHub Pages build, complete live TLS bodies and visual QA remain separate."}
    write(OUT / "terminal.json", encode(result))
    sync_dir(OUT)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--authority", required=True)
    args = p.parse_args()
    try:
        result = publish(args.authority)
        sys.stdout.buffer.write(encode(result))
        sys.stdout.buffer.flush()
        return 0
    except BaseException as error:
        sys.stderr.buffer.write(encode({"schema": "Root-cluster-receptor-multipart-P2-publication-terminal-v1",
            "status": "STOPPED_NO_AUTOMATIC_RETRY_RECONCILE_SAVED_RESPONSES",
            "error": type(error).__name__ + ": " + str(error)[:2048],
            "scope": "A mutation may already have succeeded. Never infer no publication from failure; reconcile saved responses and remote ref read-only."}))
        sys.stderr.buffer.flush()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
