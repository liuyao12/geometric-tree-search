"""Inert complete cluster/receptor training and matched-control once worker.

No scientific call before separately reviewed complete Source/once authority.
All main native states are audited; complete L return/event rows are losslessly
retained. Native transient argument histories are hashes, not full histories.
"""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import sys
import time
import types
import zlib

ROOT = Path('/private/tmp/gcts-cluster-receptors-20261027-v2')
ACTUAL = ROOT / 'actual-v1'
SELF = ROOT / 'root/cluster_receptor_worker_v1.py'
OBSERVER = ROOT / 'implementation-B/cluster_receptor_once_observer_v1.py'
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
ROLE_KEYS = ('point_engine', 'cell_csp', 'fragment_learner', 'independent_oracle', 'indexed_oracle', 'cluster_qualification', 'actor', 'worker', 'observer')
CAPS = {'worker_main_entry_seconds': 600, 'observer_owned_wait_seconds': 720, 'observed_worker_RSS_limit_bytes': 1610612736, 'per_output_body_bytes': 67108864, 'named_output_aggregate_bytes': 268435456, 'combined_worker_logs_bytes': 1048576, 'per_eval_small_seconds': 5, 'per_eval_large_seconds': 10, 'per_training_search_seconds': 2, 'per_training_node_limit': 128, 'per_benchmark_node_limit': 5000, 'named_output_file_count': 256}
RESOLUTION = {'path': '/private/tmp/gcts-cluster-receptors-20261027-v2/root/cluster-worker-input-and-retention-resolution-v4.json', 'bytes': 7667, 'sha256': '945b6b977d6ce844b375f7da63f44b9d40091982638f52e1f34999ec31935108'}
INVENTORY = 'GCTS_CLUSTER_GENERATOR_V1'
MODULE_VERSIONS = {'fragment_learner': 'GCTS-corner-marking-synthesis-v1', 'independent_oracle': 'GCTS-CORNER-LEARNING-INDEPENDENT-ORACLE-v1', 'point_engine': 'GCTS-FINITE-POINT-CLUSTER-ENGINE-v1', 'cell_csp': 'FINITE-UNIT-CELL-CLUSTER-CSP-v1', 'indexed_oracle': 'GCTS-INDEXED-UNIT-INDEPENDENT-v2', 'cluster_qualification': 'GCTS-CLUSTER-RECEPTOR-INDEPENDENT-QUALIFICATION-v2', 'actor': 'GCTS-CLUSTER-TOKEN-ACTOR-v1'}
CONFIGURATION = {'limits': {'worker_main_entry_seconds': 600, 'observer_owned_wait_seconds': 720, 'observed_worker_RSS_limit_bytes': 1610612736, 'per_output_body_bytes': 67108864, 'named_output_aggregate_bytes': 268435456, 'combined_worker_logs_bytes': 1048576, 'per_eval_small_seconds': 5, 'per_eval_large_seconds': 10, 'per_training_search_seconds': 2, 'per_training_node_limit': 128, 'per_benchmark_node_limit': 5000, 'named_output_file_count': 256}, 'policy_initialization': {'max_members': 4, 'learning_rate': 0.04, 'weight_clip': 4.0, 'baseline_beta': 0.2, 'weights': 'TWELVE_ZERO_FLOATS', 'baseline': 0.0, 'updates': 0}, 'training': {'words': ['000', '011', '101', '110'], 'steps': 2, 'repeats': 4, 'negative_order': [False, True], 'ordering': 'REPEAT_WORD_NEGATIVE', 'seed_base': 41001, 'seed_stride': 131, 'even_engine_order': ['POINT', 'CSP'], 'odd_engine_order': ['CSP', 'POINT'], 'strategy': 'TRAINED_CLUSTER', 'feedback_reference': 'POINT', 'terminal_bonus': 'PAIRED_INDEPENDENT_COMPLETE_AGREEMENT', 'feedback_progress': 'UNSEEDED_REQUIRED_ANCHORS_AND_L_ASSIGNED'}, 'evaluation': {'contexts': [{'width': 5, 'steps': 2, 'word': '001', 'negative': False}, {'width': 5, 'steps': 2, 'word': '001', 'negative': True}, {'width': 9, 'steps': 6, 'word': '0010111', 'negative': False}, {'width': 9, 'steps': 6, 'word': '0010111', 'negative': True}], 'seed_base': 71001, 'seed_stride': 1, 'information_order': ['ORIGINAL_WANG', 'REUSED_CERTIFIED_CORNER20'], 'original_strategies': ['LEX_NO_CLUSTER', 'UNTRAINED_CLUSTER', 'TRAINED_FIRST_ONLY', 'TRAINED_CLUSTER'], 'reused_strategies': ['LEX_NO_CLUSTER', 'TRAINED_CLUSTER'], 'positive_engine_order': ['POINT', 'CSP'], 'negative_engine_order': ['CSP', 'POINT'], 'negative_reverse_strategies': True, 'evaluation_updates': False}, 'inventory_version': 'GCTS_CLUSTER_GENERATOR_V1', 'original_marking_version': 'ORIGINAL_WANG', 'reused_marking_version_prefix': 'REUSED_CERTIFIED_CORNER20:', 'planned_main_solves': 112, 'planned_training_episodes': 32, 'planned_evaluation_arms': 48}
FRAME = ((-1,-1),(-1,1),(1,-1),(1,1))
D = ((1,0),(0,1),(1,1),(-1,1))

class Refusal(RuntimeError):
    pass


class RunBudget(RuntimeError):
    pass


def need(ok, message):
    if not ok:
        raise Refusal(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'),
                       allow_nan=False) + '\n').encode()


def sha(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def strict(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def nonfinite(value):
        raise Refusal('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def raw(path, cap=67108864):
    need(path.is_absolute() and path.resolve() == path and
         all(not q.is_symlink() for q in (path, *path.parents)), 'canonical path')
    before = path.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= cap,
         'bounded single-link regular file')
    body = path.read_bytes()
    after = path.stat(follow_symlinks=False)
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) and
         len(body) == before.st_size, 'whole stable file')
    return body


def pin(path, body=None):
    if body is None:
        body = raw(path)
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def same(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return set(left) == set(right) and all(same(left[k], right[k]) for k in left)
    if type(left) is list:
        return len(left) == len(right) and all(same(a, b) for a, b in zip(left, right))
    return left == right


def ref(row, cap=67108864):
    need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'} and
         type(row['path']) is str and type(row['bytes']) is int and
         0 <= row['bytes'] <= cap and type(row['sha256']) is str and
         len(row['sha256']) == 64 and all(c in '0123456789abcdef' for c in row['sha256']),
         'exact bounded rawref3')
    path = Path(row['path'])
    body = raw(path, cap)
    need(same(pin(path, body), row), 'complete current rawref')
    return body


def verified(receipt):
    need(type(receipt) is dict and receipt.get('status') == 'VERIFIED',
         'independent check did not verify')
    return receipt


def main_arm_transport(body, tick):
    """Encode the entire original arm body; no scientific value is changed."""
    tick()
    compressed = zlib.compress(body, level=1)
    tick()
    return {'schema': 'GCTS-lossless-cluster-main-arm-v1',
            'encoding': 'CANONICAL_JSON_ZLIB1_BASE64', 'record_count': 1,
            'raw_bytes': len(body), 'raw_sha256': hashlib.sha256(body).hexdigest(),
            'compressed_bytes': len(compressed),
            'compressed_sha256': hashlib.sha256(compressed).hexdigest(),
            'data_base64': base64.b64encode(compressed).decode('ascii')}


def verify_main_arm_transport(envelope, original, tick):
    """Bounded standard decode, full equality; never evaluate decoded data."""
    tick()
    need(type(original) is bytes and len(original) <= CAPS['per_output_body_bytes']
         and original.endswith(b'\n') and original.count(b'\n') == 1,
         'whole canonical original arm document')
    need(type(envelope) is dict and set(envelope) == {
        'schema', 'encoding', 'record_count', 'raw_bytes', 'raw_sha256',
        'compressed_bytes', 'compressed_sha256', 'data_base64'}, 'arm transport exact8')
    need(type(envelope['schema']) is str and
         envelope['schema'] == 'GCTS-lossless-cluster-main-arm-v1' and
         type(envelope['encoding']) is str and
         envelope['encoding'] == 'CANONICAL_JSON_ZLIB1_BASE64' and
         type(envelope['record_count']) is int and envelope['record_count'] == 1 and
         type(envelope['raw_bytes']) is int and envelope['raw_bytes'] == len(original) and
         type(envelope['compressed_bytes']) is int and envelope['compressed_bytes'] >= 0 and
         type(envelope['data_base64']) is str, 'typed arm transport metadata')
    for key in ('raw_sha256', 'compressed_sha256'):
        need(type(envelope[key]) is str and len(envelope[key]) == 64 and
             all(c in '0123456789abcdef' for c in envelope[key]), 'scalar arm transport SHA256')
    compressed = base64.b64decode(envelope['data_base64'], validate=True)
    need(base64.b64encode(compressed).decode('ascii') == envelope['data_base64'] and
         len(compressed) == envelope['compressed_bytes'] and
         hashlib.sha256(compressed).hexdigest() == envelope['compressed_sha256'],
         'complete canonical base64 compressed arm bytes')
    decoder = zlib.decompressobj()
    parts, size, lines = [], 0, 0
    digest = hashlib.sha256()
    for start in range(0, len(compressed), 65536):
        pending = compressed[start:start + 65536]
        while pending:
            tick()
            previous = len(pending)
            block = decoder.decompress(pending, 65536)
            pending = decoder.unconsumed_tail
            need(not decoder.unused_data and (block or len(pending) < previous),
                 'no trailing or nonprogressing compressed arm data')
            size += len(block)
            need(size <= CAPS['per_output_body_bytes'], 'decoded whole arm extent')
            lines += block.count(b'\n')
            digest.update(block)
            parts.append(block)
    need(decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and
         size == envelope['raw_bytes'] and lines == envelope['record_count'] and
         digest.hexdigest() == envelope['raw_sha256'] and b''.join(parts) == original,
         'full original arm bytes/hash/count readback')
    tick()


class Context:
    def __init__(self, plan, main_start):
        self.plan = plan
        self.start = main_start
        self.artifacts = []
        self.output_bytes = 0
        self.callbacks = 0

    def tick(self):
        self.callbacks += 1
        if time.perf_counter() - self.start > CAPS['worker_main_entry_seconds']:
            raise RunBudget('worker main-entry time ceiling')
        if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss > CAPS['observed_worker_RSS_limit_bytes']:
            raise RunBudget('observed worker lifetime RSS ceiling')
        logs = sum((ACTUAL / name).stat().st_size for name in ('worker-stdout.bin', 'worker-stderr.bin')
                   if (ACTUAL / name).exists())
        if logs > CAPS['combined_worker_logs_bytes']:
            raise RunBudget('combined worker logs ceiling')
        return None

    def log(self, phase, **data):
        self.tick()
        print(encoded({'phase': phase, 'elapsed_from_main': time.perf_counter() - self.start,
                       **data}).decode().rstrip(), flush=True)

    def write(self, name, value):
        self.tick()
        need('/' not in name and name.endswith('.json'), 'fixed output basename')
        body = encoded(value)
        original_arm = None
        if type(value) is dict and value.get('schema') == 'GCTS-cluster-receptor-main-arm-v1':
            if len(body) > CAPS['per_output_body_bytes']:
                raise RunBudget('decoded original arm byte ceiling')
            original_arm = body
            value = main_arm_transport(original_arm, self.tick)
            body = encoded(value)
        if (len(body) > CAPS['per_output_body_bytes'] or
                self.output_bytes + len(body) > CAPS['named_output_aggregate_bytes'] or
                len(self.artifacts) + 1 > CAPS['named_output_file_count']):
            raise RunBudget('named complete evidence byte ceiling')
        if original_arm is not None:
            verify_main_arm_transport(value, original_arm, self.tick)
        path = ACTUAL / name
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        readback = raw(path)
        need(readback == body, 'complete output readback')
        if original_arm is not None:
            verify_main_arm_transport(strict(readback), original_arm, self.tick)
        result = pin(path, body)
        self.output_bytes += len(body)
        self.artifacts.append(result)
        self.tick()
        return result


def make_palette():
    alphabet = ('#', '0', '1')
    tiles = []
    for a in alphabet:
        for b in alphabet:
            for c in alphabet:
                out = '#' if b == '#' else ('1' if (a == '1') != (c == '1') else '0')
                tiles.append({'id': 'C:' + a + ':' + b + ':' + c, 'N': 'S:' + b,
                              'E': 'P:' + b + ':' + c, 'S': 'S:' + out,
                              'W': 'P:' + a + ':' + b})
    for s in alphabet:
        tiles.append({'id': 'I:' + s, 'N': 'I:' + s, 'E': 'ROW:TOP',
                      'S': 'S:' + s, 'W': 'ROW:TOP'})
        tiles.append({'id': 'O:' + s, 'N': 'S:' + s, 'E': 'ROW:BOT',
                      'S': 'O:' + s, 'W': 'ROW:BOT'})
    return sorted(tiles, key=lambda row: row['id'])


def augment(model, marking):
    result = copy.deepcopy(model)
    maps = {}
    for channel in marking['channels']:
        for value, key in (('0', 'zeros'), ('1', 'ones')):
            for tile, x, y in channel[key]:
                maps.setdefault(tile, []).append([x, y, channel['id'], value])
    for row in result['placements']:
        identity = strict(row['type'].encode())
        if identity[0] == 'WANG':
            dx, dy = row['translation']
            row['m'] += [[x + dx, y + dy, channel, value]
                         for x, y, channel, value in maps.get(identity[1], [])]
            row['m'].sort(key=lambda term: (term[0], term[1], term[2]))
    return result


def digest_event(trace, kind, data, state):
    state_hash = sha(state)
    common_data = ({'restored_state_sha256': state_hash}
                   if kind == 'ROLLED_BACK' else copy.deepcopy(data))
    trace.append({'seq': len(trace), 'kind': kind, 'data': common_data,
                  'domains_sha256': sha(state['eligible_domains']),
                  'state_sha256': state_hash})


class SearchWindow:
    """Cooperative solve interval only; global budget always propagates."""
    def __init__(self, ctx, seconds, owned_exception):
        self.ctx, self.seconds, self.owned_exception = ctx, seconds, owned_exception
        self.started = None
        self.started_since_main = None
        self.triggered = False
        self.elapsed = None

    def tick(self):
        self.ctx.tick()
        if self.started is not None and time.perf_counter() - self.started > self.seconds:
            self.triggered = True
            raise self.owned_exception('ARM_SEARCH_WINDOW')
        return None

    def begin(self):
        if self.seconds is not None:
            self.started = time.perf_counter()
            self.started_since_main = self.started - self.ctx.start

    def close(self):
        if self.started is not None:
            self.elapsed = time.perf_counter() - self.started
        self.started = None

    def receipt(self):
        return {'limit_seconds': self.seconds, 'started_since_worker_main': self.started_since_main,
                'solve_return_interval_seconds': self.elapsed, 'triggered': self.triggered,
                'scope': 'Window begins immediately before solve; includes solve-time audit elapsed. Cooperative producer budget checkpoints only; an untriggered final audit may overrun. Construction/export/entry and post-return verification/cleanup/write are outside window, inside total arm/global budget.'}


def compare_pair(point, csp):
    p, c = point['return'], csp['return']
    interrupted = point['search_window']['triggered'] or csp['search_window']['triggered']
    pd = [ev for ev in point['trace'] if ev['kind'] == 'DECISION']
    cd = [ev for ev in csp['trace'] if ev['kind'] == 'DECISION']
    common = min(len(pd), len(cd))
    def decision_values(events):
        return [{key: ev[key] for key in ('kind', 'data', 'domains_sha256', 'state_sha256')}
                for ev in events]
    need(same(decision_values(pd[:common]), decision_values(cd[:common])), 'shared completed decision prefix mismatch')
    if not interrupted:
        need(same(point['trace'], csp['trace']) and p['status'] == c['status'] and p['nodes'] == c['nodes'],
             'uninterrupted full semantic trace/status/node mismatch')
        need(same(dict(p['metrics'], nodes=p['nodes']), c['metrics']), 'uninterrupted common metric mismatch')
    return {'mode': 'DECISION_PREFIX_ONLY' if interrupted else 'COMPLETE_SEMANTIC_TRACE',
            'point_decisions': len(pd), 'csp_decisions': len(cd), 'common_decisions': common,
            'overlap_vacuous': common == 0, 'all_common_decisions_equal': True,
            'full_trace_status_nodes_and_common_metrics_asserted': not interrupted,
            'point_window_triggered': point['search_window']['triggered'],
            'csp_window_triggered': csp['search_window']['triggered'],
            'scope': 'Wall-window cutoffs may differ. No equal-status/node/metric or speed claim follows from a shared decision prefix.'}


class AuditLog:
    """Lossless data encoding, not a verifier or a replay of search."""
    def __init__(self, ctx):
        self.ctx = ctx
        self.encoder = zlib.compressobj(level=1)
        self.parts = []
        self.records = 0
        self.raw_bytes = 0
        self.digest = hashlib.sha256()

    def append(self, value):
        self.ctx.tick()
        body = encoded(value)
        need(len(body) <= CAPS['per_output_body_bytes'], 'audit row byte limit')
        need(self.raw_bytes + len(body) <= CAPS['named_output_aggregate_bytes'],
             'decoded arm audit byte limit')
        self.raw_bytes += len(body)
        self.records += 1
        self.digest.update(body)
        self.parts.append(self.encoder.compress(body))

    def finish(self):
        self.ctx.tick()
        self.parts.append(self.encoder.flush())
        compressed = b''.join(self.parts)
        decoder = zlib.decompressobj()
        digest = hashlib.sha256()
        size = count = tail_size = 0
        def accept(block):
            nonlocal size, count, tail_size
            size += len(block)
            need(size <= CAPS['named_output_aggregate_bytes'], 'decoded audit extent')
            digest.update(block)
            pieces = block.split(b'\n')
            if len(pieces) == 1:
                tail_size += len(block)
            else:
                need(tail_size + len(pieces[0]) + 1 <= CAPS['per_output_body_bytes'],
                     'decoded audit row extent')
                need(all(len(x) + 1 <= CAPS['per_output_body_bytes'] for x in pieces[1:-1]),
                     'decoded audit row extent')
                count += len(pieces) - 1
                tail_size = len(pieces[-1])
            need(tail_size <= CAPS['per_output_body_bytes'], 'decoded audit row tail')
        for start in range(0, len(compressed), 65536):
            pending = compressed[start:start + 65536]
            while pending:
                self.ctx.tick()
                previous = len(pending)
                block = decoder.decompress(pending, 65536)
                pending = decoder.unconsumed_tail
                need(not decoder.unused_data, 'trailing compressed audit data')
                need(block or len(pending) < previous, 'nonprogressing audit decoder')
                accept(block)
        accept(decoder.flush())
        need(decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
             and tail_size == 0 and size == self.raw_bytes and count == self.records
             and digest.hexdigest() == self.digest.hexdigest(), 'full audit byte readback')
        return {'schema': 'GCTS-lossless-runtime-audit-log-v1',
                'encoding': 'CANONICAL_JSONL_ZLIB1_BASE64', 'record_count': count,
                'raw_bytes': size, 'raw_sha256': digest.hexdigest(),
                'compressed_bytes': len(compressed),
                'compressed_sha256': hashlib.sha256(compressed).hexdigest(),
                'data_base64': base64.b64encode(compressed).decode('ascii')}


def problem(palette, width, steps, negative, word):
    need(type(word) is str and len(word) == width - 2 and set(word) <= {'0', '1'},
         'fixed binary interior word')
    initial = list('#' + word + '#')
    final = list(initial)
    for unused in range(steps):
        final = ['#'] + ['1' if (final[i - 1] == '1') != (final[i + 1] == '1') else '0'
                         for i in range(1, width - 1)] + ['#']
    if negative:
        i = width // 2
        final[i] = '0' if final[i] == '1' else '1'
    last = steps + 1
    region = [[x, y] for x in range(width) for y in range(last + 1)]
    boundary = [[x, 0, 'N', 'I:' + initial[x]] for x in range(width)]
    boundary += [[x, last, 'S', 'O:' + final[x]] for x in range(width)]
    for y in range(last + 1):
        color = 'ROW:TOP' if y == 0 else 'ROW:BOT' if y == last else 'P:#:#'
        boundary += [[0, y, 'W', color], [width - 1, y, 'E', color]]
    return {'width': width, 'steps': steps, 'initial': initial, 'final': final,
            'negative_final': negative, 'region': region, 'boundary': boundary}


def public_preparation(handle):
    return {'version': handle.version, 'model_sha256': handle.model_sha256,
            'raw_model_sha256': getattr(handle, 'raw_model_sha256', None),
            'id_order_sha256': getattr(handle, 'id_order_sha256', None),
            'preparation_costs': dict(handle.preparation_costs)}


def expected_actor_config(seed, strategy, marking_version):
    return {'seed': seed, 'continuations': strategy != 'TRAINED_FIRST_ONLY',
            'inventory_version': INVENTORY, 'marking_version': marking_version,
            'max_pending': 64, 'selection': 'STOCHASTIC'}


def run_arm(ctx, modules, specification, strategy, policy, seed, seconds, nodes,
            engine_kind, marking, marking_version):
    """Every callback audits complete live state; all producer values retained."""
    started = time.perf_counter()
    E, B, I, C, A = [modules[k] for k in
                    ('point_engine', 'cell_csp', 'indexed_oracle', 'cluster_qualification', 'actor')]
    palette = make_palette()
    model = E.compile_wang(palette, specification['region'], specification['boundary'])
    if marking is not None:
        model = augment(model, marking)
    seed_ids = set(model['seeds'])
    seed_anchors = {tuple(row['t'][0][:2]) for row in model['placements'] if row['id'] in seed_ids}
    feedback_required = sum(tuple(p) not in seed_anchors for p in model['required'])
    indexed = I.prepare_model(model, budget=ctx.tick)
    cluster_index = C.prepare_cluster_model(model, budget=ctx.tick) if strategy != 'LEX_NO_CLUSTER' else None
    spec = B.export_unit_cell_csp(model, value_policy=(
        'LEX_ID' if strategy == 'LEX_NO_CLUSTER' else 'VALIDATED_CLUSTER_PREFERENCE_THEN_COMPLETE_LEX')) if engine_kind == 'CSP' else None
    indexed_spec = I.prepare_unit_cell_spec(indexed, spec, budget=ctx.tick) if spec is not None else None
    actor = None if strategy == 'LEX_NO_CLUSTER' else A.ClusterProposer(
        model, policy, seed=seed, continuations=(strategy != 'TRAINED_FIRST_ONLY'),
        inventory_version=INVENTORY, marking_version=marking_version, budget=ctx.tick)
    actor_entry = None if actor is None else actor.snapshot()
    value_policy = 'LEX_ID' if actor is None else 'VALIDATED_CLUSTER_PREFERENCE_THEN_COMPLETE_LEX'
    log = AuditLog(ctx)
    trace, observed_states, checked_proposals = [], {}, set()
    holder = {'engine': None, 'cursor': None, 'proposal_cursor': None, 'max_filled': 0}
    window = SearchWindow(ctx, seconds, E.BudgetExceeded if engine_kind == 'POINT' else B.CSPBudgetExceeded)
    def check_current(engine):
        snapshot = engine.snapshot()
        receipt = (I.verify_point_snapshot(indexed, snapshot, value_policy=value_policy, budget=ctx.tick)
                   if engine_kind == 'POINT' else I.verify_normalized_state(indexed_spec, snapshot, budget=ctx.tick))
        return snapshot, verified(receipt)
    def observe(engine, event):
        snapshot = engine.snapshot()
        receipt, cursor = (I.verify_point_event(indexed, snapshot, event, holder['cursor'],
                            value_policy=value_policy, budget=ctx.tick) if engine_kind == 'POINT' else
                           I.verify_normalized_event(indexed_spec, snapshot, event, holder['cursor'], budget=ctx.tick))
        verified(receipt)
        holder['cursor'] = cursor
        state = receipt['normalized_state']
        holder['max_filled'] = max(holder['max_filled'], len(state['assigned']))
        digest_event(trace, event['kind'], event['data'], state)
        log.append({'kind': 'NATIVE_EVENT', 'event': copy.deepcopy(event),
                    'native_snapshot_sha256': sha(snapshot), 'verification': receipt})
    def propose(observation):
        snapshot, receipt = check_current(holder['engine'])
        observation_check = verified(I.verify_cluster_observation(
            indexed, receipt['normalized_state'], observation, inventory_version=INVENTORY,
            marking_version=marking_version, budget=ctx.tick))
        key = sha(observation)
        observed_states[key] = receipt['normalized_state']
        log.append({'kind': 'PROPOSAL_OBSERVATION', 'observation': copy.deepcopy(observation),
                    'native_snapshot_sha256': sha(snapshot), 'verification': receipt,
                    'observation_check': observation_check})
        return actor(observation)
    def proposal_audit(receipt):
        snapshot, current = check_current(holder['engine'])
        check, cursor = C.verify_proposal_receipt(
            cluster_index, receipt, current['normalized_state'], previous=holder['proposal_cursor'],
            proposal_audit_enabled=True, inventory_version=INVENTORY,
            marking_version=marking_version, budget=ctx.tick)
        need(check['status'] == 'VERIFIED_COMPLETE_CLUSTER_ORDER', 'complete live cluster check')
        holder['proposal_cursor'] = cursor
        checked_proposals.add(receipt['index'])
        log.append({'kind': 'PROPOSAL_VALIDATED', 'producer_receipt': copy.deepcopy(receipt),
                    'native_snapshot_sha256': sha(snapshot), 'state_verification': current,
                    'independent_verification': check})
    options = {'audit': observe, 'budget': window.tick,
               'proposer': None if actor is None else propose,
               'proposal_audit': None if actor is None else proposal_audit,
               'inventory_version': INVENTORY, 'marking_version': marking_version}
    engine = E.Engine(model, **options) if engine_kind == 'POINT' else B.CellCSP(spec, **options)
    holder['engine'] = engine
    entry = engine.snapshot()
    cp = engine.checkpoint()
    checkpoint = I.checkpoint(indexed, entry, native=(engine_kind == 'POINT'), budget=ctx.tick)
    checkpoint_metadata = {'version': checkpoint.version,
        'raw_model_sha256': checkpoint.raw_model_sha256, 'model_sha256': checkpoint.model_sha256,
        'native': checkpoint.native, 'state_sha256': checkpoint.state_sha256,
        'preparation_costs': dict(checkpoint.preparation_costs),
        'scope': 'Opaque handle passed unchanged to verifier; complete checkpoint body is retained as entry.'}
    window.begin()
    try:
        result = engine.solve(node_limit=nodes)
    finally:
        window.close()
    ctx.tick()
    need(not window.triggered or result['status'] == 'UNKNOWN', 'search expiry decisive result')
    final, final_check = check_current(engine)
    result_check = verified(I.verify_point_result(indexed, result, budget=ctx.tick) if engine_kind == 'POINT'
                            else I.verify_unit_cell_result(indexed_spec, result, budget=ctx.tick))
    solve_trace = copy.deepcopy(trace)
    proposals = engine.proposal_evidence
    for receipt in proposals:
        if receipt['index'] not in checked_proposals:
            need(receipt['status'] != 'VALIDATED', 'missing live validation callback')
            state = observed_states[receipt['observation_sha256']]
            check, cursor = C.verify_proposal_receipt(
                cluster_index, receipt, state, previous=holder['proposal_cursor'],
                proposal_audit_enabled=True, inventory_version=INVENTORY,
                marking_version=marking_version, budget=ctx.tick)
            need(check['status'] == 'VERIFIED_NONFINAL_ENVELOPE_ONLY' and cursor is None,
                 'partial proposal cannot certify complete order')
            log.append({'kind': 'PROPOSAL_NONFINAL', 'producer_receipt': receipt,
                        'observed_normalized_state': state, 'independent_verification': check})
    engine.rollback(cp)
    restored = engine.snapshot()
    need(same(restored, entry), 'full native entry restoration')
    rollback_check = verified(I.verify_rollback(indexed, checkpoint, restored, budget=ctx.tick))
    actor_final = None if actor is None else actor.snapshot()
    actor_check = None
    if actor_final is not None:
        need(actor_final['policy_sha256'] == sha(policy), 'frozen arm policy')
        actor_check = C.verify_actor_snapshot(
            cluster_index, actor_final, policy, expected_actor_config(seed, strategy, marking_version),
            proposals, budget=ctx.tick)
        need(type(actor_check) is dict and
             set(actor_check) == {'schema', 'status', 'verifier_version', 'model_sha256',
                'policy_sha256', 'constructor_config_sha256', 'snapshot_sha256',
                'kernel_receipt_sha256', 'checks', 'costs'} and
             actor_check['schema'] == 'GCTS-cluster-actor-independent-trajectory-v1' and
             actor_check['status'] == 'VERIFIED_BOUND_ACTOR_TRAJECTORY' and
             actor_check['verifier_version'] == C.VERSION and
             actor_check['model_sha256'] == sha(model) and
             actor_check['policy_sha256'] == sha(policy) and
             actor_check['constructor_config_sha256'] == sha(expected_actor_config(seed, strategy, marking_version)) and
             actor_check['snapshot_sha256'] == sha(actor_final) and
             actor_check['kernel_receipt_sha256'] == sha(proposals),
             'complete independent actor verification return')
    audit_envelope = log.finish()
    data = {'schema': 'GCTS-cluster-receptor-main-arm-v1', 'input': specification,
            'strategy': strategy, 'engine': engine_kind, 'seed': seed,
            'marking_version': marking_version, 'model': model, 'spec': spec,
            'indexed_preparation': public_preparation(indexed),
            'indexed_spec_preparation': None if indexed_spec is None else {
                'version': indexed_spec.version, 'spec_sha256': indexed_spec.spec_sha256,
                'preparation_costs': dict(indexed_spec.preparation_costs)},
            'cluster_preparation': None if cluster_index is None else public_preparation(cluster_index),
            'return': result, 'result_check': result_check,
            'entry': entry, 'checkpoint_receipt': checkpoint_metadata,
            'native_final': final, 'final_check': final_check,
            'restored': restored, 'rollback_check': rollback_check, 'restored_entry_exact': True,
            'trace': solve_trace, 'cleanup_trace': trace[len(solve_trace):],
            'search_window': window.receipt(), 'actor_entry': actor_entry, 'actor_final': actor_final,
            'independent_actor_check': actor_check,
            'proposal_evidence': proposals, 'proposal_metrics': engine.proposal_metrics,
            'audit_log': audit_envelope, 'feedback_required_points': feedback_required,
            'max_verified_filled': holder['max_filled'],
            'elapsed_before_outer_body_serialization': time.perf_counter() - started,
            'scope': 'Full actual states audited every callback; all full L return/event rows retained losslessly. Main native transient arguments are hashes, not full native history. Entry/final/restored native bodies complete. Search window excludes construction and post-return checking/codec finalization/body write; all cost paid globally and separately.'}
    return data, cluster_index


def save_arm(ctx, modules, specification, strategy, policy, seed, seconds, nodes,
             engine_kind, marking, marking_version, name):
    start = time.perf_counter()
    ctx.log('ARM_STARTED', name=name, strategy=strategy, engine=engine_kind, seed=seed)
    data, cluster_index = run_arm(ctx, modules, specification, strategy, policy, seed, seconds, nodes,
                                  engine_kind, marking, marking_version)
    reference = ctx.write(name, data)
    timing = {'body': reference, 'through_complete_body_write_seconds': time.perf_counter() - start,
              'scope': 'Fresh model/index/actor/engine, solve/audits, checking/rollback, complete codec and body serialization/fsync/readback/hash. Later timing/index serialization excluded; whole main clock includes it.'}
    ctx.log('ARM_SAVED', name=name, status=data['return']['status'],
            nodes=data['return']['nodes'], window_triggered=data['search_window']['triggered'])
    return data, reference, timing, cluster_index


def feedback_for_pair(point, csp, point_ref, csp_ref, comparison):
    p, c = point['return'], csp['return']
    complete = (p['status'] == c['status'] and p['status'] in
                ('FINITE_EXACT_SOLUTION', 'EXHAUSTED_FINITE_SEARCH'))
    if complete:
        expected = 'SAT' if p['status'] == 'FINITE_EXACT_SOLUTION' else 'UNSAT'
        need(csp['result_check']['certificate_kind'] == expected,
             'paired terminal requires complete independent CSP certificate')
    else:
        expected = 'UNKNOWN'
    association = {'schema': 'GCTS-cluster-training-feedback-association-v1',
                   'point': point_ref, 'csp': csp_ref,
                   'model_sha256': sha(point['model']), 'context': p['context'],
                   'point_check': point['result_check'], 'csp_certificate_check': csp['result_check'],
                   'paired_comparison_rawref': comparison, 'raw_statuses': [p['status'], c['status']]}
    metrics, snapshot = p['metrics'], point['actor_final']
    feedback = {'status': expected, 'verified_terminal': complete,
                'verification_sha256': sha(association), 'required_points': point['feedback_required_points'],
                'max_verified_filled': point['max_verified_filled'], 'attempts': metrics['attempts'],
                'branches': metrics['branch_decisions'], 'backtracks': metrics['backtracks'],
                'actor_candidate_visits': snapshot['costs']['candidate_feature_visits'],
                'certificate_kind': expected if complete else 'INCOMPLETE'}
    return feedback, association


def reused_marking(ctx, modules, raw_inputs, input_refs):
    C, O = modules['fragment_learner'], modules['independent_oracle']
    inputs = {name: strict(body) for name, body in raw_inputs.items()}
    catalogue, result = inputs['catalogue'], inputs['mark_result']
    marking = result['marking']
    palette = make_palette()
    system = {'schema': 'GCTS-corner-free-rectangle-system-v1', 'palette': palette,
              'directions': {'N': [0, -1], 'E': [1, 0], 'S': [0, 1], 'W': [-1, 0]},
              'frame': [list(q) for q in FRAME], 'offsets': [list(d) for d in D],
              'translation_lattice': '2Z2', 'local_boundary': 'FREE_RECTANGLE'}
    need(same(inputs['prior_system']['system'], system)
         and inputs['prior_system']['system_sha256'] == sha(system), 'reused exact system')
    need(catalogue['system_sha256'] == result['system_sha256'] == marking['system_sha256'] == sha(system)
         and len(catalogue['labels']) == 4356 and
         all(row['status'] != 'UNKNOWN' for row in catalogue['labels']) and
         result['status'] == 'COMPLETE_COVER' and len(marking['channels']) == 20,
         'explicit resolved certified Mark20 control')
    audit = C.audit_corner_marking(catalogue, marking, budget=ctx.tick)
    check = verified(O.verify_corner_audit(catalogue, marking, audit, budget=ctx.tick))
    contacts = verified(O.reconstruct_corner_contacts(catalogue, marking, budget=ctx.tick))
    need(audit['wellformed'] is True and not audit['missing_required_negatives']
         and not audit['uncertified_conflicts'] and not contacts['missing_required_negatives']
         and not contacts['uncertified_conflicts'] and contacts['channels'] == 20,
         'complete reused representation audit')
    reference = ctx.write('reused-marking-control.json', {
        'schema': 'GCTS-cluster-explicit-reused-marking-control-v1', 'rawrefs': input_refs,
        'complete_inputs': inputs, 'production_audit': audit, 'independent_audit': check,
        'independent_contacts': contacts,
        'scope': 'Explicit reused admitted control, not cold marking learning. Prior adoption and rectangle theorem are authenticated provenance associations, not proof replay. Training consumed only freshly constructed ORIGINAL_WANG models.'})
    version = 'REUSED_CERTIFIED_CORNER20:' + input_refs['mark_result']['sha256']
    return marking, version, reference


def run_study(ctx, modules, raw_inputs, resolution):
    E, B, F, O, I, C, A = [modules[k] for k in
        ('point_engine', 'cell_csp', 'fragment_learner', 'independent_oracle',
         'indexed_oracle', 'cluster_qualification', 'actor')]
    palette = make_palette()
    palette_check = verified(O.validate_palette(palette, budget=ctx.tick))
    need(same(palette_check['palette'], palette), 'fixed33 palette')
    input_ref = ctx.write('inputs-and-configuration.json', {
        'schema': 'GCTS-cluster-receptor-current-inputs-v1', 'resolution': resolution,
        'palette': palette, 'palette_check': palette_check, 'caps': CAPS,
        'source_versions': {key: getattr(modules[key], 'VERSION', None) for key in modules},
        'scope': 'Training and evaluation descriptor Source frozen before once; no held-out result feedback. Reused map inputs remain opaque until training is complete.'})
    ctx.log('LEGACY_QUALIFICATION_STARTED')
    legacy = verified(O.qualify_public_apis(palette, E, B, F, budget=ctx.tick))
    legacy_ref = ctx.write('legacy-qualification.json', legacy)
    ctx.log('CLUSTER_QUALIFICATION_STARTED')
    qualification = C.run_cluster_qualification(E, B, I, A, budget=ctx.tick)
    need(qualification['schema'] == 'GCTS-cluster-receptor-independent-qualification-result-v1'
         and qualification['status'] == 'PASS', 'complete independent cluster qualification')
    qualification_ref = ctx.write('cluster-qualification.json', qualification)
    initial = A.new_policy()
    expected_initial = {'schema': 'GCTS-cluster-token-policy-v1',
        'feature_names': list(A.FEATURES), 'max_members': 4, 'learning_rate': 0.04,
        'weight_clip': 4.0, 'baseline_beta': 0.2, 'weights': [0.0] * 12,
        'baseline': 0.0, 'updates': 0}
    need(same(initial, expected_initial), 'fresh exact zero policy initialization')
    initial_ref = ctx.write('initial-policy.json', initial)
    policy = copy.deepcopy(initial)
    train_records, updates, train_checks, timings = [], [], [], []
    episode = 0
    for repeat in range(4):
        for word in ('000', '011', '101', '110'):
            for negative in (False, True):
                specification = problem(palette, 5, 2, negative, word)
                seed = 41001 + 131 * episode
                frozen = copy.deepcopy(policy)
                pair, references, indexes = {}, {}, {}
                order = ('POINT', 'CSP') if episode % 2 == 0 else ('CSP', 'POINT')
                for kind in order:
                    name = 'train-' + str(episode) + '-' + kind + '.json'
                    data, reference, timing, cluster_index = save_arm(
                        ctx, modules, specification, 'TRAINED_CLUSTER', frozen, seed,
                        CAPS['per_training_search_seconds'], CAPS['per_training_node_limit'],
                        kind, None, 'ORIGINAL_WANG', name)
                    pair[kind], references[kind] = data, reference
                    indexes[kind] = cluster_index
                    timings.append(timing)
                    train_records.append({'episode': episode, 'repeat': repeat, 'word': word,
                                          'negative': negative, 'engine': kind, 'record': reference})
                need(same(policy, frozen), 'policy frozen through both paired originals')
                need(sha(pair['POINT']['model']) == sha(pair['CSP']['model']) and
                     same(pair['POINT']['return']['context'], pair['CSP']['return']['context']),
                     'same-model same-entry paired training')
                comparison = compare_pair(pair['POINT'], pair['CSP'])
                pair_check_ref = ctx.write('training-pair-check-' + str(episode) + '.json', {
                    'schema': 'GCTS-cluster-training-pair-check-v1', 'episode': episode,
                    'point': references['POINT'], 'csp': references['CSP'], 'comparison': comparison,
                    'model_sha256': sha(pair['POINT']['model']),
                    'context': pair['POINT']['return']['context'],
                    'point_check': pair['POINT']['result_check'],
                    'csp_certificate_check': pair['CSP']['result_check']})
                train_checks.append(pair_check_ref)
                feedback, association = feedback_for_pair(pair['POINT'], pair['CSP'],
                    references['POINT'], references['CSP'], pair_check_ref)
                update_start = time.perf_counter()
                update_callbacks = 0
                def update_budget():
                    nonlocal update_callbacks
                    update_callbacks += 1
                    return ctx.tick()
                update = A.reinforce_update(frozen, pair['POINT']['actor_final'], feedback,
                                            budget=update_budget)
                update_elapsed = time.perf_counter() - update_start
                need(update['before_policy_sha256'] == sha(frozen) and
                     update['evidence_sha256'] == sha(pair['POINT']['actor_final']) and
                     same(update['feedback'], feedback), 'complete point-only feedback association')
                update_check_started = time.perf_counter()
                update_check = C.verify_actor_update(
                    indexes['POINT'], frozen, pair['POINT']['actor_final'],
                    expected_actor_config(seed, 'TRAINED_CLUSTER', 'ORIGINAL_WANG'),
                    pair['POINT']['proposal_evidence'], feedback, update, budget=ctx.tick)
                need(type(update_check) is dict and
                     set(update_check) == {'schema', 'status', 'verifier_version', 'model_sha256',
                        'policy_sha256', 'snapshot_sha256', 'feedback_sha256', 'update_sha256', 'checks', 'costs'} and
                     update_check['schema'] == 'GCTS-cluster-actor-independent-update-v1' and
                     update_check['status'] == 'VERIFIED_BOUND_ACTOR_UPDATE' and
                     update_check['verifier_version'] == C.VERSION and
                     update_check['model_sha256'] == sha(pair['POINT']['model']) and
                     update_check['policy_sha256'] == sha(frozen) and
                     update_check['snapshot_sha256'] == sha(pair['POINT']['actor_final']) and
                     update_check['feedback_sha256'] == sha(feedback) and update_check['update_sha256'] == sha(update),
                     'complete independent actor update verification')
                update_check_elapsed = time.perf_counter() - update_check_started
                update_ref = ctx.write('training-update-' + str(episode) + '.json', {
                    'schema': 'GCTS-cluster-paired-training-update-v1', 'episode': episode,
                    'before_policy': frozen, 'point': references['POINT'], 'csp': references['CSP'],
                    'comparison': comparison, 'paired_check': pair_check_ref, 'verification_association': association,
                    'update': update, 'update_elapsed_seconds': update_elapsed,
                    'independent_update_check': update_check,
                    'independent_update_check_elapsed_seconds': update_check_elapsed,
                    'observed_update_budget_callbacks': update_callbacks,
                    'scope': 'Both raw pair originals saved before this sole POINT-trajectory update. Terminal bonus requires paired independently certified agreement; actual raw statuses remain unchanged. Update costs are separate from frozen proposer snapshot.'})
                policy = copy.deepcopy(update['after_policy'])
                updates.append(update_ref)
                ctx.log('TRAINING_UPDATE_SAVED', episode=episode, feedback=feedback['status'],
                        policy_sha256=sha(policy))
                episode += 1
    need(episode == 32 and len(train_records) == 64 and len(updates) == 32,
         'complete training census')
    trained = copy.deepcopy(policy)
    trained_sha = sha(trained)
    trained_ref = ctx.write('frozen-trained-policy.json', trained)
    marking, marking_version, marking_ref = reused_marking(ctx, modules, raw_inputs,
                                                         resolution['inputs'])
    eval_records, comparisons = [], []
    contexts = ((5, 2, '001', False), (5, 2, '001', True),
                (9, 6, '0010111', False), (9, 6, '0010111', True))
    for context, (width, steps, word, negative) in enumerate(contexts):
        specification = problem(palette, width, steps, negative, word)
        for use_marking in (False, True):
            strategies = (('LEX_NO_CLUSTER', 'TRAINED_CLUSTER') if use_marking else
                          ('LEX_NO_CLUSTER', 'UNTRAINED_CLUSTER', 'TRAINED_FIRST_ONLY', 'TRAINED_CLUSTER'))
            if negative:
                strategies = tuple(reversed(strategies))
            for strategy in strategies:
                selected_policy = initial if strategy in ('LEX_NO_CLUSTER', 'UNTRAINED_CLUSTER') else trained
                pair, references = {}, {}
                order = ('CSP', 'POINT') if negative else ('POINT', 'CSP')
                for kind in order:
                    name = 'eval-' + str(context) + '-' + ('MAP20-' if use_marking else 'WANG-') + strategy + '-' + kind + '.json'
                    data, reference, timing, cluster_index = save_arm(
                        ctx, modules, specification, strategy, selected_policy, 71001 + context,
                        CAPS['per_eval_small_seconds'] if width == 5 else CAPS['per_eval_large_seconds'],
                        CAPS['per_benchmark_node_limit'], kind,
                        marking if use_marking else None, marking_version if use_marking else 'ORIGINAL_WANG', name)
                    pair[kind], references[kind] = data, reference
                    timings.append(timing)
                    eval_records.append({'context': context, 'reused_marking': use_marking,
                        'strategy': strategy, 'engine': kind, 'record': reference})
                need(sha(pair['POINT']['model']) == sha(pair['CSP']['model']) and
                     same(pair['POINT']['return']['context'], pair['CSP']['return']['context']),
                     'same-information same-context evaluation')
                comparisons.append({'context': context, 'reused_marking': use_marking,
                    'strategy': strategy, 'point': references['POINT'], 'csp': references['CSP'],
                    'comparison': compare_pair(pair['POINT'], pair['CSP'])})
                need(sha(trained) == trained_sha and same(policy, trained), 'no evaluation feedback')
    need(len(eval_records) == 48 and len(comparisons) == 24, 'complete evaluation census')
    index = ctx.write('whole-study-index.json', {
        'schema': 'GCTS-cluster-receptor-whole-study-index-v1', 'inputs': input_ref,
        'legacy_qualification': legacy_ref, 'cluster_qualification': qualification_ref,
        'initial_policy': initial_ref, 'frozen_trained_policy': trained_ref,
        'explicit_reused_marking': marking_ref, 'training': train_records,
        'training_pair_checks': train_checks, 'updates': updates,
        'evaluation': eval_records, 'evaluation_pairs': comparisons, 'arm_costs': timings,
        'main_solve_calls': 112,
        'scope': 'All32paired training episodes and48evaluation arms retained, no completion/policy selection. Unknown remains unknown. Main native transient argument history is not serialized; complete full L receipt/event logs are lossless and verified. Qualification retains all promised raw histories. No causal utility/generalization/speed/universal/FOL/infinite claim from this bounded study alone.'})
    return {'index': index, 'training_arm_count': len(train_records), 'update_count': len(updates),
            'evaluation_arm_count': len(eval_records), 'main_solve_calls': 112,
            'final_policy_sha256': trained_sha, 'all_planned_arms_saved': True}


def main():
    main_start = time.perf_counter()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--consume', required=True)
    args = parser.parse_args()
    ctx = None
    try:
        need(Path(__file__).resolve() == SELF and sys.platform == 'darwin' and
             sys.version_info[:3] == (3, 12, 14) and sys.flags.isolated and sys.flags.no_site
             and sys.dont_write_bytecode and sys.flags.optimize == 0 and __debug__ and
             Path(sys.executable).resolve() == Path(PYTHON['path']), 'fixed D90 -I-S-B runtime')
        ref(PYTHON, PYTHON['bytes'])
        plan_path, consume_path = Path(args.plan), Path(args.consume)
        need(plan_path.parent == ROOT / 'root' and plan_path.suffix == '.json', 'fixed Root plan')
        plan_raw = raw(plan_path, 1048576)
        plan = strict(plan_raw)
        need(type(plan) is dict and set(plan) == {'schema', 'run_id', 'role_pins', 'python',
             'limits', 'actual_dir', 'source_contract', 'offer'}, 'plan exact8')
        need(plan['schema'] == 'GCTS-cluster-receptor-once-plan-v1' and
             type(plan['run_id']) is str and plan['run_id'] and same(plan['python'], PYTHON)
             and same(plan['limits'], CAPS) and plan['actual_dir'] == str(ACTUAL), 'fixed plan values')
        need(type(plan['role_pins']) is dict and set(plan['role_pins']) == set(ROLE_KEYS), 'closed9roles')
        source_bodies, paths = {}, set()
        for name in ROLE_KEYS:
            row = plan['role_pins'][name]
            need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'} and
                 type(row['path']) is str, 'exact Source role path')
            path = Path(row['path'])
            need(path.is_relative_to(ROOT) and path.suffix == '.py' and path not in paths and
                 (name != 'worker' or path == SELF) and (name != 'observer' or path == OBSERVER),
                 'closed unique current study Source paths')
            paths.add(path)
            source_bodies[name] = ref(row, 2097152)
        contract_raw = ref(plan['source_contract'], 1048576)
        contract = strict(contract_raw)
        need(type(contract) is dict and set(contract) == {'schema', 'resolution', 'inputs',
             'role_pins', 'module_versions', 'configuration', 'public_ABIs', 'scope',
             'execution_authorized'}, 'functional contract exact9')
        need(contract['schema'] == 'Root-cluster-receptor-worker-functional-contract-v1' and
             same(contract['resolution'], RESOLUTION) and
             same(contract['role_pins'], plan['role_pins']) and
             same(contract['module_versions'], MODULE_VERSIONS) and
             same(contract['configuration'], CONFIGURATION) and
             contract['scope'] == 'FINITE_UNIT_ANCHOR_CLUSTER_RECEPTOR_RL_BOUNDED_STUDY' and
             contract['execution_authorized'] is False, 'exact Source-only functional contract')
        need(type(contract['public_ABIs']) is list and 1 <= len(contract['public_ABIs']) <= 32,
             'bounded explicit public ABI guard list')
        public_bodies, public_paths = [], set()
        for item in contract['public_ABIs']:
            need(type(item) is dict and type(item.get('path')) is str,
                 'explicit public ABI rawref')
            path = Path(item['path'])
            need(path.is_relative_to(ROOT) and path.suffix == '.json' and path not in public_paths,
                 'unique current-study public ABI path')
            public_paths.add(path)
            public_bodies.append(ref(item, 1048576))
        ref(plan['offer'], 1048576)
        resolution_raw = ref(RESOLUTION, 1048576)
        resolution = strict(resolution_raw)
        need(resolution['execution_authorized'] is False and set(resolution['inputs']) ==
             {'catalogue', 'mark_result', 'prior_adoption', 'prior_system', 'rectangle_factor_theorem'},
             'exact frozen prospective input resolution')
        need(same(contract['inputs'], resolution['inputs']), 'exact five input associations')
        consume_raw = raw(consume_path, 1048576)
        consume = strict(consume_raw)
        need(type(consume) is dict and set(consume) == {'schema', 'uses', 'authority', 'plan',
             'observer', 'python', 'child_started_at_consume'}, 'consume exact7')
        authority_raw = ref(consume['authority'], 1048576)
        authority_path = Path(consume['authority']['path'])
        authority = strict(authority_raw)
        need(authority_path.parent == ROOT / 'root' and authority_path.suffix == '.json'
             and authority_path != plan_path and consume_path == Path(str(authority_path) + '.CONSUMED.json'),
             'fixed adjacent authority/consume')
        need(same(authority, {'schema': 'GCTS-cluster-receptor-once-authority-v1',
             'authorized': True, 'uses': 1, 'plan': pin(plan_path, plan_raw),
             'observer': plan['role_pins']['observer'], 'python': PYTHON}), 'complete A6 association')
        need(same(consume, {'schema': 'GCTS-cluster-receptor-once-consumed-v1', 'uses': 1,
             'authority': pin(authority_path, authority_raw), 'plan': pin(plan_path, plan_raw),
             'observer': plan['role_pins']['observer'], 'python': PYTHON, 'child_started_at_consume': False}),
             'complete consumed association')
        need(ACTUAL.is_dir() and not ACTUAL.is_symlink(), 'fresh observer-owned actual directory')
        ctx = Context(plan, main_start)
        raw_inputs = {key: ref(value) for key, value in resolution['inputs'].items()}
        modules = {}
        for name in ('point_engine', 'cell_csp', 'fragment_learner', 'independent_oracle',
                     'indexed_oracle', 'cluster_qualification', 'actor'):
            module_name = 'gcts_cluster_once_' + name
            need(module_name not in sys.modules, 'fresh role module namespace')
            module = types.ModuleType(module_name)
            module.__file__, module.__package__ = plan['role_pins'][name]['path'], None
            sys.modules[module_name] = module
            exec(compile(source_bodies[name], module.__file__, 'exec'), module.__dict__)
            modules[name] = module
        need(all(getattr(modules[name], 'VERSION', None) == version
                 for name, version in MODULE_VERSIONS.items()), 'current seven module versions')
        outcome = run_study(ctx, modules, raw_inputs, resolution)
        def guards():
            for item in plan['role_pins'].values():
                ref(item, 2097152)
            for key, item in resolution['inputs'].items():
                need(ref(item) == raw_inputs[key], 'complete reused input postguard')
            ref(PYTHON, PYTHON['bytes'])
            need(ref(plan['source_contract'], 1048576) == contract_raw, 'functional contract postguard')
            for item, body in zip(contract['public_ABIs'], public_bodies, strict=True):
                need(ref(item, 1048576) == body, 'complete public ABI postguard')
            ref(plan['offer'], 1048576)
            need(ref(RESOLUTION, 1048576) == resolution_raw and raw(plan_path, 1048576) == plan_raw
                 and raw(consume_path, 1048576) == consume_raw and
                 raw(authority_path, 1048576) == authority_raw, 'complete metadata postguards')
        guards()
        ctx.tick()
        result = {'schema': 'GCTS-cluster-receptor-worker-result-v1', 'run_id': plan['run_id'],
                  'status': 'COMPLETE_BOUNDED_STUDY_REVIEW_PENDING', 'outcome': outcome,
                  'artifacts': list(ctx.artifacts), 'named_bytes_before_final_result': ctx.output_bytes,
                  'named_output_files_before_final_result': len(ctx.artifacts),
                  'worker_main_entry_before_final_result_seconds': time.perf_counter() - ctx.start,
                  'worker_lifetime_RSS_bytes_at_sample': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  'budget_callbacks_at_sample': ctx.callbacks, 'role_pins': plan['role_pins'],
                  'clock_tail': 'Final result encoding/write/fsync/readback/hash, postguards and shutdown follow sample; no full lifetime claim.',
                  'claims': 'Finite unit-anchor cluster ordering/RL matched-control study only. No theorem discovery, formal proof lemma, causal benefit, universal/FOL palette, infinite construction or speed claim admitted by this transport envelope.'}
        result_pin = ctx.write('result.json', result)
        guards()
        print(encoded({'schema': 'GCTS-cluster-receptor-worker-terminal-v1', 'status': 'COMPLETE',
                       'result': result_pin, 'actual_named_bytes': ctx.output_bytes,
                       'actual_named_files': len(ctx.artifacts)}).decode().rstrip(), flush=True)
        return 0
    except BaseException as error:
        failure = {'schema': 'GCTS-cluster-receptor-worker-terminal-v1', 'status': 'FAILED_UNADMITTED',
                   'error': type(error).__name__ + ': ' + str(error)[:2048],
                   'scientific_outcome_admitted': False,
                   'artifacts_so_far': [] if ctx is None else ctx.artifacts,
                   'scope': 'Consumed once and partial originals remain spent; no retry or prefix promotion.'}
        sys.stderr.buffer.write(encoded(failure))
        sys.stderr.buffer.flush()
        return 2


if __name__ == '__main__':
    raise SystemExit(main())


