from pathlib import Path
import ast,hashlib,json,symtable,sys,difflib,subprocess
OLD=Path('/private/tmp/gcts-cluster-receptors-20261027-v1')
NEW=Path('/private/tmp/gcts-cluster-receptors-20261027-v2')
B=NEW/'implementation-B'
def sh(b):return hashlib.sha256(b).hexdigest()
def jb(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def wr(name,x):
 p=B/name;p.write_bytes(jb(x));return pin(p)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sh(b)}
def dump(n,pos=False):return ast.dump(n,include_attributes=pos)
def literals(t):
 out={}
 for q in t.body:
  if isinstance(q,ast.Assign) and len(q.targets)==1 and isinstance(q.targets[0],ast.Name):
   try:out[q.targets[0].id]=ast.literal_eval(q.value)
   except ValueError:pass
 return out
def defs(t,s):
 lines=s.splitlines(keepends=True);out={}
 def visit(n,path):
  for child in ast.iter_child_nodes(n):
   if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    key='.'.join(path+[child.name]);a=min([child.lineno]+[d.lineno for d in child.decorator_list]);raw=''.join(lines[a-1:child.end_lineno]).encode()
    out[key]={'name':key,'kind':type(child).__name__,'lineno':a,'end_lineno':child.end_lineno,'raw_bytes':len(raw),'raw_sha256':sh(raw),'AST_sha256':sh(dump(child).encode()),'positioned_AST_sha256':sh(dump(child,True).encode()),'signature':ast.unparse(child.args) if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)) else None,'full_descendant_callset':sorted({ast.unparse(q.func) for q in ast.walk(child) if isinstance(q,ast.Call)})}
    visit(child,path+[child.name])
   else:visit(child,path)
 visit(t,[]);return out
def symbols(st,path='module'):
 entries=[]
 for name in sorted(st.get_identifiers()):
  q=st.lookup(name);entries.append(dict(name=name,parameter=q.is_parameter(),referenced=q.is_referenced(),assigned=q.is_assigned(),global_=q.is_global(),local=q.is_local(),free=q.is_free(),nonlocal_=q.is_nonlocal(),imported=q.is_imported()))
 out=[{'path':path,'type':st.get_type(),'line':st.get_lineno(),'complete_symbol_entries':entries,'entries_sha256':sh(jb(entries))}]
 for i,c in enumerate(st.get_children()):out+=symbols(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
 return out
records={};patches=[];preservation={}
for role,rel in [('worker','root/cluster_receptor_worker_v1.py'),('observer','implementation-B/cluster_receptor_once_observer_v1.py')]:
 p=NEW/rel;op=OLD/rel;new=p.read_bytes();old=op.read_bytes();s=new.decode();os=old.decode();t=ast.parse(s,filename=str(p));ot=ast.parse(os,filename=str(op))
 # Create code objects only; no execution/import of any subject Source.
 unused=compile(new,str(p),'exec',dont_inherit=True,optimize=0);del unused
 ds,ods=defs(t,s),defs(ot,os);joins=[]
 for name,row in ods.items():
  current=ds[name];joins.append({'name':name,'old':row,'new':current,'raw_equal':row['raw_sha256']==current['raw_sha256'],'AST_equal':row['AST_sha256']==current['AST_sha256']})
 added=sorted(set(ds)-set(ods));removed=sorted(set(ods)-set(ds));changed=[r['name'] for r in joins if not r['raw_equal'] or not r['AST_equal']]
 assert removed==[]
 if role=='worker':assert added==['main_arm_transport','verify_main_arm_transport'] and changed==['Context','Context.write']
 else:assert added==[] and changed==[]
 li,oli=literals(t),literals(ot)
 for name in ['CAPS','PYTHON','ROLE_KEYS']+(['CONFIGURATION','MODULE_VERSIONS','INVENTORY','FRAME','D'] if role=='worker' else ['BOOTSTRAP']):assert type(li[name]) is type(oli[name]) and li[name]==oli[name],name
 assert len(li['CAPS'])==12 and len(li['ROLE_KEYS'])==9
 forward=''.join(difflib.unified_diff(os.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/'+op.name,tofile='b/'+p.name))
 inverse=''.join(difflib.unified_diff(s.splitlines(keepends=True),os.splitlines(keepends=True),fromfile='a/'+p.name,tofile='b/'+op.name))
 for direction,patch,base,expected in [('forward',forward,op,new),('inverse',inverse,p,old)]:
  pp=B/(role+'-N1-N2-'+direction+'-v1.patch');pp.write_text(patch);out=B/(role+'-'+direction+'-native-patch-readback-v1.py')
  result=subprocess.run(['/usr/bin/patch','-s','-o',str(out),str(base),str(pp)],capture_output=True)
  assert result.returncode==0,(result.returncode,result.stdout,result.stderr)
  assert out.read_bytes()==expected
  patches.append({'role':role,'direction':direction,'patch':pin(pp),'native_apply_exit':0,'complete_raw_output':pin(out),'byte_identity':True})
 imports=[ast.unparse(n) for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom))];assert imports==[ast.unparse(n) for n in ot.body if isinstance(n,(ast.Import,ast.ImportFrom))]
 scopes=symbols(symtable.symtable(s,str(p),'exec'))
 records[role]={'Source':pin(p),'predecessor':pin(op),'whole_AST_sha256':sh(dump(t).encode()),'whole_positioned_AST_sha256':sh(dump(t,True).encode()),'imports_unchanged':imports,'complete_definition_count':len(ds),'complete_definitions':list(ds.values()),'complete_symbol_scope_count':len(scopes),'complete_symbol_scopes':scopes,'unused_compile':'PASS; code object discarded, never executed','global_constants_unchanged':['CAPS','PYTHON','ROLE_KEYS']+(['CONFIGURATION','MODULE_VERSIONS','INVENTORY','FRAME','D'] if role=='worker' else ['BOOTSTRAP'])}
 preservation[role]={'old_definition_count':len(ods),'new_definition_count':len(ds),'added':added,'removed':removed,'changed':changed,'unchanged_raw_AST_count':len(joins)-len(changed),'all_old_definitions':joins}
assert sys.version_info[:3]==(3,12,14) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
contract=json.loads((NEW/'root/cluster-lossless-successor-authoring-contract-v1.json').read_text());res=json.loads((NEW/'root/cluster-worker-input-and-retention-resolution-v4.json').read_text());alias=json.loads((NEW/'root/cluster-seven-library-and-input-byte-aliases-v1.json').read_text())
worker=records['worker'];observer=records['observer'];wt=ast.parse((NEW/'root/cluster_receptor_worker_v1.py').read_text());wl=literals(wt)
assert wl['CONFIGURATION']==contract['unchanged_configuration'] and wl['CAPS']==contract['unchanged_limits']
assert wl['RESOLUTION']==pin(NEW/'root/cluster-worker-input-and-retention-resolution-v4.json')
assert res['library_aliases']==pin(NEW/'root/cluster-seven-library-and-input-byte-aliases-v1.json')
assert len(alias['source_aliases'])==7 and len(alias['inputs'])==5 and len(alias['public_ABI_aliases'])==13
assert len(worker['complete_definitions'])==51 and len(observer['complete_definitions'])==13
static=wr('cluster-N2-worker-observer-complete-static-and-helper-ledger-v1.json',{'schema':'Root-cluster-N2-complete-Source-static-helper-ledger-v1','runtime':{'executable':sys.executable,'version':sys.version,'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'mode':'AST/symtable/unused compile only'},'roles':records,'preservation':preservation,'four_complete_native_patch_checks':patches,'source_function_calls':0,'codec_calls':0,'failed_actual_or_inputs_intake':False,'scientific_execution_authorized':False})
wr('cluster-N2-worker-observer-exact-delta-and-inverse-v1.json',{'schema':'Root-cluster-N2-Source-exact-delta-inverse-v1','worker':{'Source':worker['Source'],'predecessor':worker['predecessor'],'allowed_changes':['Two N1 root strings relocate to N2 (ROOT and resolution path); resolution filename/bytes/SHA bind exact Root v4.','Two complete new transport-only functions.','Only Context.write changes among inherited executable helpers; Context class raw/AST changes due to that method.'],'helper_counts':{k:preservation['worker'][k] for k in ['old_definition_count','new_definition_count','added','removed','changed','unchanged_raw_AST_count']}},'observer':{'Source':observer['Source'],'predecessor':observer['predecessor'],'allowed_changes':['Exactly one ROOT literal N1→N2; all13 definitions raw+AST unchanged, imports/344-byte bootstrap/limits unchanged.'],'helper_counts':{k:preservation['observer'][k] for k in ['old_definition_count','new_definition_count','added','removed','changed','unchanged_raw_AST_count']}},'four_native_patch_results':patches,'full_ledger':static,'unchanged_recipe':{'main_solves':112,'train_episodes':32,'train_solves':64,'evaluation_arms':48,'pair_checks':32,'updates':32,'before_final_result_named':183,'including_final_result_named':184,'physical_after_observer_receipt':187},'all12_caps_and_CONFIG_equal_to_predecessor_and_Root_contract':True,'all7_scientific_versions_unchanged':True,'no_codec_execution':True})
print(json.dumps({'worker':worker['Source'],'observer':observer['Source'],'static':static,'helper_counts':{r:[records[r]['complete_definition_count'],records[r]['complete_symbol_scope_count']] for r in records},'changed':{r:preservation[r]['changed'] for r in records},'patches':4},sort_keys=True,indent=2))
