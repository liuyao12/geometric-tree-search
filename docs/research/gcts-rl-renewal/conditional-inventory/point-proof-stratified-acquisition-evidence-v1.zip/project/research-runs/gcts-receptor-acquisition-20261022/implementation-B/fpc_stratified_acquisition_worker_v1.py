"""Bounded ordinary stratified schema acquisition caller; inert Source authorship.

Only a separately reviewed once child loads the nine exact namespaces and two
admitted original training byte pairs. No selector, old library/result, holdout,
search, private dependency endpoint or target route enters this profile.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'FPC-stratified-acquisition-worker-v1'
EXPERIMENT = 'two-admitted-donor-stratified-schema-acquisition-v1'
PROTOCOL_SCHEMA = 'Root-FPC-stratified-schema-acquisition-protocol-v1'
PROFILE = 'stratified-schema-whole-acquisition-v1'
CASE = 'two-admitted-donor-stratified-schema-acquisition-v1-case-0'
MODULE_ROLES = ('checker',
 'builders',
 'reference',
 'instance',
 'schema',
 'extractor',
 'wide_instance',
 'wide_encoder',
 'acquisition_bank')
MODULE_PINS = {'checker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_byte_checker_v1.py',
             'bytes': 31557,
             'sha256': '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'},
 'builders': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_ast_and_builders_v1.py',
              'bytes': 11348,
              'sha256': 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'},
 'reference': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_reference_v2.py',
               'bytes': 24681,
               'sha256': 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'},
 'instance': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_instance_service_v2.py',
              'bytes': 46609,
              'sha256': '7b7ca98d3e3dd2e48680d5f499594a8ec7322753bf7a6e8511d5cc667526fae9'},
 'schema': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_skeleton_schema_v1.py',
            'bytes': 32008,
            'sha256': '6d2aedd01f5fc6dc85e9c908bcd947e9d9aba04e68b2bc18f2107bfd81363338'},
 'extractor': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_stratified_receptor_schema_extractor_v1.py',
               'bytes': 63355,
               'sha256': '1d3e0a087d4d9eb9bc3104ac318626e2f69619a5b6c21cbf291d5968094e5b75'},
 'wide_instance': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_wide_instance_service_v1.py',
                   'bytes': 46623,
                   'sha256': 'f1e606ec472945032a506a186016793759ec8bf8f086cc3373da84a9cce0410b'},
 'wide_encoder': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/wide_fpc_query_encoder_v1.py',
                  'bytes': 9022,
                  'sha256': 'bcd3e43fe7938cd0bb0f15558e2c5ebcd4cd43c59bcd860b88d5592a20dcd502'},
 'acquisition_bank': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/fpc_stratified_acquisition_independent_bank_v2.py',
                      'bytes': 38072,
                      'sha256': 'd9c38d12e942123c62b9d2c9648b6c5a9092d1c7d0d7a6ae9525f43a2b9cc6d3'}}
MODULE_VERSIONS = {'checker': 'FPC-H1-BYTE-CHECKER-v1',
 'builders': 'FPC-H1-AST-BUILDERS-v1',
 'reference': 'FPC-H1-independent-flat-reference-v2',
 'instance': 'FPC-RECEPTOR-INSTANCE-SERVICE-v2',
 'schema': 'FPC-RECEPTOR-SKELETON-SCHEMA-v1',
 'extractor': 'FPC-STRATIFIED-RECEPTOR-SCHEMA-EXTRACTOR-v1',
 'wide_instance': 'FPC-RECEPTOR-WIDE-INSTANCE-SERVICE-v1',
 'wide_encoder': 'L-wide-FPC-query-encoder-v1',
 'acquisition_bank': 'FPC-STRATIFIED-ACQUISITION-INDEPENDENT-BANK-v1'}
CONTROL_IDS = {'stratified_acquisition6': ('strata-and-full-prefix-scan',
                             'generic-key-and-representative',
                             'size-boundary-bin-selection',
                             'structural-sharing-and-support',
                             'wide-generic-carrier',
                             'first-fault-and-nonmutation')}
CONTROL_POPULATIONS = [{'population': 'stratified_acquisition6',
  'control_ids': ['strata-and-full-prefix-scan',
                  'generic-key-and-representative',
                  'size-boundary-bin-selection',
                  'structural-sharing-and-support',
                  'wide-generic-carrier',
                  'first-fault-and-nonmutation'],
  'groups': 6,
  'bank_role': 'acquisition_bank',
  'subject_role': ['extractor', 'schema', 'instance', 'wide_instance', 'wide_encoder'],
  'scope': 'Synthetic genuine-byte stratified acquisition and wide-carrier controls only; no production '
           'donor, library, holdout, contextual-use, GCTS or RL admission.'}]
CAPS = {'custody_seconds': 210,
 'log_bytes': 4194304,
 'memory_bytes': 1073741824,
 'observer_fallback_seconds': 225,
 'physical_bytes': 134217728,
 'positive_seconds': 180,
 'reserved_outer_bytes': 9437184,
 'result_bytes': 50331648,
 'root_callbacks': 400000000,
 'work_seconds': 160}
INPUT_AUTHORITY = [{'donor_id': 'donor0',
  'Root_admission': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-0-Root-complete-whole-admission-v1.json',
                     'bytes': 8205,
                     'sha256': '5e43a84fb44d32dc78aba88456d73524b94eb5895e3b591b5abdddbafb6d3570'},
  'C_actual_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-cohort-backed-per-proof-donor-0-complete-whole-actual-review-v1.json',
                      'bytes': 16253,
                      'sha256': '7f02e115b155bb9331dd9625714226d60aaef29e021c13873f7f780409e28ba9'},
  'query': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-0/query.bin',
            'bytes': 30,
            'sha256': '353d584927c405f1350729890920dee7265f03f3af148855e171c4cc52e77169'},
  'certificate': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-0/certificate.bin',
                  'bytes': 104490,
                  'sha256': 'c91a47c2ff3ec42a13db73f84f0b7b373205a3b766025b664c21dfb2027e83c1'}},
 {'donor_id': 'donor1',
  'Root_admission': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-1-Root-complete-whole-admission-v1.json',
                     'bytes': 9272,
                     'sha256': '0c0ad2007f61f476d0230da74ba377602543e844cc53ba25fc895f0a49ac5feb'},
  'C_actual_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-cohort-backed-per-proof-donor-1-complete-whole-actual-review-v1.json',
                      'bytes': 17983,
                      'sha256': '8408d8731fb620ededc0b30206d4685ec409794406fec59ceb318ce633034b25'},
  'query': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-1/query.bin',
            'bytes': 37,
            'sha256': 'de00382d25dc4a96696ce98fc7bfa95c87ef9c8a51440390fa0e4cb6d3c063b5'},
  'certificate': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-1/certificate.bin',
                  'bytes': 262088,
                  'sha256': 'fbe1f4429a6023c25e951d3edba81b3dc57c25a9c8743909bc81ade043b80e1b'}}]
SOURCE_COMPONENTS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/stratified-schematic-acquisition-Source-CONTRACT-v1.json',
  'bytes': 16267,
  'sha256': '3894c2de0b0473d640999c15f204576cafdcd9529d957d68a3b9915f9bcc6a73'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/stratified-acquisition-components-Source-handoff-v1.json',
  'bytes': 5886,
  'sha256': '3d0bd6a66fca10e0e63dbe0e277fada2bff29c6e7baecdbbc06829ff1418d325'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/wide-FPC-query-encoder-Source-handoff-v1.json',
  'bytes': 6830,
  'sha256': 'b95d708bfcc497d652dd54b1e3bfba8a05202c9ce656017230dc7eb1316a54a4'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/stratified-acquisition-independent-bank-Source-handoff-v2.json',
  'bytes': 23508,
  'sha256': '39bebafd9a7e5baf2af6814dbbc63f50befcc136dafd89bed3bf6942df95de28'}]
CUSTODY_RUNTIME = {'runner': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/run_conditional_once_v1.py',
            'bytes': 12973,
            'sha256': '98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'},
 'observer': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/observe_conditional_once_v1.py',
              'bytes': 10113,
              'sha256': '24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'},
 'python': {'bytes': 18058560,
            'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
            'sha256': 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'}}
REQUIRED_METADATA_GUARDS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/stratified-acquisition-parallel-worker-Source-CONTRACT-v1.json',
  'bytes': 11581,
  'sha256': '159b657908106529ba3f8d7c6b8cba15e182a6c02666791bf6e3b03c36ae9d44'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/stratified-acquisition-bank-Source2-Root-path-binding-v1.json',
  'bytes': 2043,
  'sha256': '2bd3330422d24f3e1a5dc818d378667bc95376384a4fbca362fdc1ac05e350ab'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/stratified-schematic-acquisition-Source-CONTRACT-v1.json',
  'bytes': 16267,
  'sha256': '3894c2de0b0473d640999c15f204576cafdcd9529d957d68a3b9915f9bcc6a73'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/stratified-acquisition-components-Source-handoff-v1.json',
  'bytes': 5886,
  'sha256': '3d0bd6a66fca10e0e63dbe0e277fada2bff29c6e7baecdbbc06829ff1418d325'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/wide-FPC-query-encoder-Source-handoff-v1.json',
  'bytes': 6830,
  'sha256': 'b95d708bfcc497d652dd54b1e3bfba8a05202c9ce656017230dc7eb1316a54a4'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/stratified-acquisition-independent-bank-Source-handoff-v2.json',
  'bytes': 23508,
  'sha256': '39bebafd9a7e5baf2af6814dbbc63f50befcc136dafd89bed3bf6942df95de28'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/stratified-acquisition-public-ABI-v1.json',
  'bytes': 10432,
  'sha256': 'd5c19d851e148bf06bbc631860cd3cb68e31c3cbf4c16358d986e37e2e9964ac'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/stratified-acquisition-API-v1.json',
  'bytes': 16838,
  'sha256': '2deff2f314584cc27bfe7e2bc405db54e74e84151dd8f1f1c4f0551ca5fa4825'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/stratified-acquisition-manual-v1.json',
  'bytes': 7288,
  'sha256': '2242924aa0edefd9e7fd16fd36a8111edf784c933aa776e11aa0254bcd8320db'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/stratified-acquisition-dependency-offer-v1.json',
  'bytes': 6334,
  'sha256': '904ad21615deed8cdf083482d9af7dcfd7cb34e3219f137f01106e2bb603478b'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-family-and-instance-API-v2.json',
  'bytes': 27122,
  'sha256': '74f10ef380e7a86c145d18e3e27f12aefedbaeebf55f2bf7853fded14275a917'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-skeleton-schema-API-v1.json',
  'bytes': 8556,
  'sha256': '8b4c61f7b9531b466710658eb2029041be817139840a2c982b948a6ea422302b'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-0-Root-complete-whole-admission-v1.json',
  'bytes': 8205,
  'sha256': '5e43a84fb44d32dc78aba88456d73524b94eb5895e3b591b5abdddbafb6d3570'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-cohort-backed-per-proof-donor-0-complete-whole-actual-review-v1.json',
  'bytes': 16253,
  'sha256': '7f02e115b155bb9331dd9625714226d60aaef29e021c13873f7f780409e28ba9'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-1-Root-complete-whole-admission-v1.json',
  'bytes': 9272,
  'sha256': '0c0ad2007f61f476d0230da74ba377602543e844cc53ba25fc895f0a49ac5feb'},
 {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-cohort-backed-per-proof-donor-1-complete-whole-actual-review-v1.json',
  'bytes': 17983,
  'sha256': '8408d8731fb620ededc0b30206d4685ec409794406fec59ceb318ce633034b25'}]
POLICY_BINDING = ('FPC-original-json-integer-policy-v1', 4300)
PLAN_FIELDS = ('schema',
 'case_id',
 'stage',
 'experiment',
 'actual_dir',
 'worker_path',
 'runner_path',
 'python',
 'files',
 'limits',
 'protocol',
 'profile',
 'module_pins',
 'input_authority',
 'Source_components')
QUERY_FIELDS = ('version',
 'claim_mode',
 'function_arities',
 'predicate_arities',
 'theory_profile',
 'finite_axioms',
 'Gamma',
 'goal')
INSTANCE_FIELDS = ('schema',
 'complete',
 'accepted',
 'context_query_identity',
 'binding',
 'expansion_rows',
 'family_to_wire_rows',
 'boundary_query_bytes',
 'boundary_certificate_bytes',
 'subject_receipt',
 'reference_receipt')
SCHEMA_FIELDS = ('schema',
 'version',
 'complete',
 'accepted',
 'library_admitted',
 'method',
 'source_family',
 'family',
 'specialization',
 'source_associations',
 'input_guards',
 'output_guards',
 'costs',
 'scope')
SCHEMA_COST_FIELDS = ('successful_callbacks',
 'copy_visits',
 'comparison_visits',
 'fresh_metavariables',
 'unification_pairs',
 'dereference_steps',
 'occurs_visits',
 'resolved_term_visits',
 'normalization_visits',
 'specialization_pairs',
 'equation_checks',
 'source_backprojection_checks',
 'public_input_guard_calls',
 'public_output_guard_calls',
 'canonical_bytes')
CONFIGURATION = {'schema': 'FPC-stratified-schematic-acquisition-v1',
 'policy': 'quantile-MP-all-prefix-size-boundary-diversity-v1',
 'roots_per_donor': 8,
 'min_nodes': 2,
 'max_nodes': 8,
 'max_distinct_boundary_nodes': 4,
 'per_donor_quota': 4,
 'library_quota': 8}
WIDE_LIMITS = {'symbols_per_sort': 64,
 'axioms': 4,
 'hypotheses': 4,
 'total_nodes': 4096,
 'depth': 128,
 'natural': 65535,
 'query_bytes': 65536}
POSITIVE_FIELDS = ('donor_provenance',
 'input_freeze',
 'acquisition6_qualification',
 'extraction_result',
 'source_instance_results',
 'generic_exercise_results',
 'scientific_result')
PUBLIC_ENTRIES = {'checker': ('decode_query', 'check_certificate'),
 'builders': ('logical_axiom',),
 'reference': ('reference_check_certificate',),
 'instance': ('match_receptor', 'compile_instance'),
 'schema': ('infer_schematic_family',),
 'extractor': ('extract_schematic_families',),
 'wide_instance': ('compile_instance',),
 'wide_encoder': ('encode_tiny_declared_query',),
 'acquisition_bank': ('run_bank',)}


class RootBudget(RuntimeError):
    """Genuine whole-caller resource or complete-output ceiling."""


def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    stream = None
    primary = None
    try:
        stream = temporary.open('xb')
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    temporary.replace(path)


def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module


def _validate_json_image(value, check):
    """Validate only; no copied tree, coercion, memo cache or codec-private API."""
    active = set()
    stack = [('node', value, None, 0)]
    while stack:
        check()
        action, item, keys, index = stack.pop()
        if action == 'node':
            kind = type(item)
            if item is None or kind is bool or kind is int or kind is str:
                continue
            if kind is float:
                if not math.isfinite(item):
                    raise ValueError('finite original JSON-image float required')
                continue
            if not (kind is list or kind is tuple or kind is dict):
                raise ValueError('exact original JSON-image type required')
            identity = id(item)
            if identity in active:
                raise ValueError('active original JSON-image cycle refused')
            active.add(identity)
            if kind is dict:
                keys = []
                for key in item:
                    check()
                    if type(key) is not str:
                        raise ValueError('all exactstr keys required before lookup')
                    keys.append(key)
                stack.append(('object', item, keys, 0))
            else:
                stack.append(('array', item, None, 0))
        elif index == len(item):
            active.remove(id(item))
        else:
            # The node/edge checkpoint above precedes each child lookup.
            stack.append((action, item, keys, index + 1))
            child = item[keys[index]] if action == 'object' else item[index]
            stack.append(('node', child, None, 0))


def _checked_byte_equal(left, right, check):
    if len(left) != len(right):
        return False
    for offset in range(0, len(left), 65536):
        check()
        if left[offset:offset + 65536] != right[offset:offset + 65536]:
            return False
    return True


def _write_bank_and_readback(path, body, check, progress):
    """New positive IO only. Close cannot replace an earlier actual E."""
    temporary = path.with_name(path.name + '.partial')
    check()
    if path.exists():
        raise ValueError('exclusive new bank artifact required')
    stream = None
    primary = None
    try:
        check()
        stream = temporary.open('xb')
        progress['phase'] = 'WRITING_PARTIAL'
        offset = 0
        while offset < len(body):
            check()
            chunk = body[offset:offset + 65536]
            written = stream.write(chunk)
            if type(written) is not int or not 0 < written <= len(chunk):
                raise ValueError('complete bounded bank write required')
            offset += written
        check()
        stream.flush()
        check()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    temporary.replace(path)
    progress['phase'] = 'PUBLISHED_PROVISIONAL'
    stream = None
    primary = None
    try:
        check()
        stream = path.open('rb')
        digest = hashlib.sha256()
        offset = 0
        while offset < len(body):
            check()
            chunk = stream.read(min(65536, len(body) - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('complete original bank readback required')
            check()
            if chunk != body[offset:offset + len(chunk)]:
                raise ValueError('exact original bank readback mismatch')
            check()
            digest.update(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'':
            raise ValueError('original bank readback strict EOF required')
        answer = dict(bytes=offset, sha256=digest.hexdigest())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    progress['phase'] = 'READBACK_COMPLETE'
    progress['readback_complete'] = True
    return answer


def _keys(value, names, check):
    check()
    if type(value) is not dict or len(value) != len(names):
        raise ValueError('exact plain object carrier required')
    for key in value:
        check()
        if type(key) is not str:
            raise ValueError('exactstr keys required before membership or lookup')
    if set(value) != set(names):
        raise ValueError('exact public object fields required')


def _natural(value):
    return type(value) is int and value >= 0


def _digest(body, check):
    if type(body) is not bytes:
        raise ValueError('original immutable byte body required')
    digest = hashlib.sha256()
    for offset in range(0, len(body), 65536):
        check()
        digest.update(body[offset:offset + 65536])
    check()
    return dict(bytes=len(body), sha256=digest.hexdigest())


def _same(left, right, check):
    """Checked exact JSON-image association; list/tuple denote one array image."""
    stack = [(left, right)]
    while stack:
        check()
        a, b = stack.pop()
        ak, bk = type(a), type(b)
        aa, ba = ak is list or ak is tuple, bk is list or bk is tuple
        if aa or ba:
            if not (aa and ba and len(a) == len(b)):
                return False
            for index in range(len(a) - 1, -1, -1):
                check()
                stack.append((a[index], b[index]))
        elif ak is dict or bk is dict:
            if not (ak is dict and bk is dict and len(a) == len(b)):
                return False
            for key in a:
                check()
                if type(key) is not str or key not in b:
                    return False
                stack.append((a[key], b[key]))
        elif ak is not bk:
            return False
        elif ak is str or ak is bytes:
            if not _checked_byte_equal(a, b, check):
                return False
        elif a is None or ak is bool or ak is int or ak is float:
            if ak is float and (not math.isfinite(a) or not math.isfinite(b)):
                raise ValueError('finite exact JSON-image equality required')
            if a != b:
                return False
        else:
            raise ValueError('ordinary exact JSON-image equality required')
    return True


def _read_original(row, check):
    expected = pin_fields(row)
    path = Path(expected['path'])
    check()
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete declared original required')
    stream, primary, chunks = None, None, []
    try:
        check()
        stream = path.open('rb')
        offset, digest = 0, hashlib.sha256()
        while offset < expected['bytes']:
            check()
            chunk = stream.read(min(65536, expected['bytes'] - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('entire declared original read required')
            check()
            digest.update(chunk)
            chunks.append(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'' or digest.hexdigest() != expected['sha256']:
            raise ValueError('original full raw length/hash/EOF association required')
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    answer = b''.join(chunks)
    check()
    return answer


def _backproject(family, occurrence, result, donor, check):
    _keys(result, INSTANCE_FIELDS, check)
    if (result['schema'] != 'FPC-receptor-instance-candidate-v1'
            or result['complete'] is not True or result['accepted'] is not False):
        raise ValueError('complete explicitly unadmitted instance required')
    source_subject, source_reference = donor['subject_receipt'], donor['reference_receipt']
    subject, reference = result['subject_receipt'], result['reference_receipt']
    if (subject['accepted'] is not True or subject['complete'] is not True
            or subject['status'] != 'VALID_DERIVATION' or reference['complete_check'] is not True
            or reference['status'] != 'VALID_DERIVATION' or not subject['final_goal_equal'] is True
            or reference['final_goal_equal'] is not True):
        raise ValueError('both complete fresh original instance views required')
    if not _same(result['binding'], occurrence['source_bindings'], check):
        raise ValueError('stored complete source binding must be used unchanged')
    for name in QUERY_FIELDS:
        check()
        if not _same(result['context_query_identity'][name], source_subject['query'][name], check):
            raise ValueError('all original donor context semantics retained')
    rows, nodes, ports = result['expansion_rows'], family['internal_nodes'], family['boundary_nodes']
    if not 2 <= len(nodes) <= 8 or len(ports) > 4:
        raise ValueError('fixed original family internal and boundary bounds required')
    count, boundary_count = len(nodes) + len(ports), len(ports)
    if (len(rows) != count or subject['certificate']['row_count'] != count
            or len(subject['certificate']['rows']) != count or len(reference['rows']) != count):
        raise ValueError('complete noncontracted physical instance rows required')
    maps = result['family_to_wire_rows']
    _keys(maps, ('boundary_to_wire', 'internal_to_wire'), check)
    if (not _same(maps['boundary_to_wire'], [[i,i] for i in range(boundary_count)], check)
            or not _same(maps['internal_to_wire'], [[i,boundary_count+i] for i in range(len(nodes))], check)):
        raise ValueError('complete canonical source identity to wire maps required')
    source_to_wire, selected_sources = {}, []
    for name, expected_count, shift in (('boundary_source_to_port', boundary_count, 0), ('source_to_local', len(nodes), boundary_count)):
        mapping = occurrence[name]
        if len(mapping) != expected_count:
            raise ValueError('complete chosen source occurrence map required')
        for index, pair in enumerate(mapping):
            check()
            if (not (type(pair) is list or type(pair) is tuple) or len(pair) != 2
                    or not _natural(pair[0]) or type(pair[1]) is not int or pair[1] != index
                    or pair[0] >= len(source_reference['rows']) or pair[0] in source_to_wire):
                raise ValueError('strict distinct source occurrence map required')
            source_to_wire[pair[0]] = shift + index
            if name == 'source_to_local':
                selected_sources.append(pair[0])
    checks, gamma = [], []
    for name, kind, shift in (('boundary_source_to_port','boundary',0), ('source_to_local','internal',boundary_count)):
        for source_index, local_index in occurrence[name]:
            check()
            wire_index = shift + local_index
            old = source_subject['certificate']['rows'][source_index]
            flat_old = source_reference['rows'][source_index]
            emitted, actual, flat = rows[wire_index], subject['certificate']['rows'][wire_index], reference['rows'][wire_index]
            _keys(emitted,('wire_index','origin_kind','origin_id','formula','rule_tag','subtag','witness','references'),check)
            if (emitted['origin_kind'] != kind or emitted['origin_id'] != local_index
                    or emitted['wire_index'] != wire_index or actual['index'] != wire_index or flat['index'] != wire_index
                    or old['index'] != source_index or flat_old['index'] != source_index
                    or not _same(emitted['formula'], old['formula'], check)
                    or not _same(actual['formula'], old['formula'], check)
                    or not _same(flat['formula']['prefix_tokens'], flat_old['formula']['prefix_tokens'], check)):
                raise ValueError('every physical original formula and identity backprojects in both views')
            if kind == 'boundary':
                gamma.append(old['formula'])
                if (actual['rule_tag'] != 0 or actual['subtag'] is not None
                        or not _same(actual['witness'], [local_index], check)
                        or flat['rule_tag'] != 0 or flat['witness_tag'] is not None
                        or not _same(flat['payload'], [local_index], check)):
                    raise ValueError('distinct boundary occurrence is its exact standalone HYP port')
            else:
                if (actual['rule_tag'] != old['rule_tag'] or actual['subtag'] != old['subtag']
                        or flat['rule_tag'] != flat_old['rule_tag'] or flat['witness_tag'] != flat_old['witness_tag']):
                    raise ValueError('original selected primitive tag/subtag backprojection required')
                if old['rule_tag'] == 1:
                    if (type(old['subtag']) is not int or not 0 <= old['subtag'] <= 2
                            or not _same(actual['witness'], old['witness'], check) or len(flat['payload']) != len(flat_old['payload'])):
                        raise ValueError('complete original logical witnesses required')
                    for current, original in zip(flat['payload'], flat_old['payload']):
                        check()
                        if not _same(current['prefix_tokens'], original['prefix_tokens'], check):
                            raise ValueError('independent ordered logical witness backprojection required')
                elif old['rule_tag'] == 3:
                    if not _same(old['witness'], flat_old['payload'], check):
                        raise ValueError('ordered original MP references join both source views')
                    expected = []
                    for original_reference in old['witness']:
                        check()
                        if not _natural(original_reference) or original_reference not in source_to_wire:
                            raise ValueError('all actual source MP ports covered by chosen full map')
                        expected.append(source_to_wire[original_reference])
                    if (not _same(actual['witness'], expected, check) or not _same(flat['payload'], expected, check)
                            or not _same(emitted['references'], expected, check) or not _same(emitted['witness'], expected, check)):
                        raise ValueError('translate original ordered MP source indices to exact emitted wire refs')
                else:
                    raise ValueError('only original H1/H2/H3 or MP selected internal rows')
            checks.append(dict(source_row=source_index,wire_row=wire_index,origin_kind=kind,origin_id=local_index,
                original_row_span=old['span'], independent_original_row_span=flat_old['byte_span'],
                emitted_row_span=actual['span'],independent_emitted_row_span=flat['byte_span']))
    root_source = occurrence['root_source_row']
    for key in ('version','function_arities','predicate_arities'):
        check()
        if not _same(subject['query'][key],source_subject['query'][key],check):
            raise ValueError('exact original signature and version in boundary query required')
    if (not selected_sources or root_source != selected_sources[-1]
            or source_to_wire[root_source] != count-1 or not _same(subject['query']['goal'], source_subject['certificate']['rows'][root_source]['formula'], check)
            or not _same(subject['query']['Gamma'], gamma, check)
            or subject['query']['claim_mode'] != 1 or subject['query']['theory_profile'] != 0
            or subject['query']['finite_axioms'] != []):
        raise ValueError('exact standalone boundary context and mapped source root required')
    return dict(schema='FPC-receptor-source-occurrence-backprojection-v1',complete=True,accepted=False,
        source_root_row=root_source,source_to_wire_rows=sorted(source_to_wire.items()),physical_rows=checks,
        meaning='Standalone boundary consequence/source occurrence only; no original theorem or final-used-map admission.')


def _subst(pattern, bindings, check):
    images={}
    for row in bindings:
        check(); images[row['parameter_id']]=row['formula']
    pending,values=[('read',pattern)],[]
    while pending:
        check(); action,node=pending.pop()
        if action=='read':
            if node[0]=='param': values.append(images[node[1]])
            elif node[0]=='not': pending.extend([('not',None),('read',node[1])])
            elif node[0]=='imp': pending.extend([('imp',None),('read',node[2]),('read',node[1])])
            else: raise ValueError('declared param/not/imp pattern required')
        elif action=='not': values.append(['not',values.pop()])
        else:
            right,left=values.pop(),values.pop(); values.append(['imp',left,right])
    if len(values)!=1: raise ValueError('complete simultaneous Formula substitution required')
    return values[0]


def _tokens(formula,check):
    result=[]; pending=[('F',formula)]
    while pending:
        check(); sort,node=pending.pop(); tag=node[0]
        if sort=='T' and tag=='var': result.append(['var',node[1]])
        elif (sort=='T' and tag=='fun') or (sort=='F' and tag=='pred'):
            result.append([tag,node[1],len(node[2])])
            for child in reversed(node[2]): check(); pending.append(('T',child))
        elif tag=='all': result.append(['all',node[1]]); pending.append(('F',node[2]))
        elif tag=='not': result.append(['not']); pending.append(('F',node[1]))
        elif tag=='eq' or tag=='imp':
            result.append([tag]); child_sort='T' if tag=='eq' else 'F'
            pending.extend([(child_sort,node[2]),(child_sort,node[1])])
        else: raise ValueError('complete typed core Formula token association required')
    return result


def _inference_complete(value,source,check):
    _validate_json_image(value,check); _keys(value,SCHEMA_FIELDS,check)
    if (value['schema']!='FPC-receptor-skeleton-schema-candidate-v1' or value['version']!=MODULE_VERSIONS['schema']
            or value['complete'] is not True or value['accepted'] is not False or value['library_admitted'] is not False
            or value['method']!='fixed-proof-skeleton-first-order-unification-v1'
            or not _same(value['source_family'],source,check)):
        raise ValueError('complete detached nonadmitting inference and original full family required')
    _keys(value['costs'],SCHEMA_COST_FIELDS,check)
    for number in value['costs'].values():
        check()
        if not _natural(number): raise ValueError('exact normal inference cost integers required')
    family=value['family']
    for name in ('root_local_id','distinct_base_nodes','size_band','validation_provenance'):
        if not _same(family[name],source[name],check): raise ValueError('unchanged source topology/provenance metadata')
    for name in ('parameters','root_local_id','internal_nodes','boundary_nodes'):
        if not _same(family['family_key'][name],family[name],check): raise ValueError('complete generalized full key required')
    if len(family['source_occurrences'])!=len(source['source_occurrences']): raise ValueError('every original occurrence retained')
    if len(value['specialization'])!=len(family['parameters']): raise ValueError('complete old-pattern specialization required')
    for index,row in enumerate(value['specialization']):
        check(); _keys(row,('parameter_id','source_pattern'),check)
        if type(row['parameter_id']) is not int or row['parameter_id']!=index: raise ValueError('ordered strict specialization IDs')
    for name in ('input_guards','output_guards','source_associations'):
        if len(value[name])!=len(source['source_occurrences']): raise ValueError('all source guard/backprojection rows retained')
    for index,(old,new,association) in enumerate(zip(source['source_occurrences'],family['source_occurrences'],value['source_associations'])):
        check()
        for name in ('donor_id','root_source_row','source_to_local','boundary_source_to_port'):
            if not _same(old[name],new[name],check) or not _same(old[name],association[name],check):
                raise ValueError('unchanged exact source identity maps required')
        if (association['occurrence_index']!=index
                or not _same(association['original_source_bindings'],old['source_bindings'],check)
                or not _same(association['generalized_source_bindings'],new['source_bindings'],check)):
            raise ValueError('complete source binding association required')
        for field in ('boundary_checks','internal_checks'):
            for row in association[field]:
                check()
                if row['formula_equal'] is not True or ('witness_equal' in row and row['witness_equal'] is not True):
                    raise ValueError('every exact source formula/witness comparison completed')
        for name in ('input_guards','output_guards'):
            row=value[name][index]
            if row['occurrence_index']!=index or row['match_result']['matched'] is not True:
                raise ValueError('every complete public normal guard required')


def _instance_join(family,binding,result,context,context_bytes,check):
    _keys(result,INSTANCE_FIELDS,check)
    if (result['schema']!='FPC-receptor-instance-candidate-v1' or result['complete'] is not True or result['accepted'] is not False
            or not _same(result['binding'],binding,check)): raise ValueError('complete exact-bound instance candidate required')
    for name in QUERY_FIELDS:
        if not _same(result['context_query_identity'][name],context[name],check): raise ValueError('full original context retained')
    identity=_digest(context_bytes,check)
    for name in ('bytes','sha256'):
        if not _same(result['context_query_identity'][name],identity[name],check): raise ValueError('original context raw identity retained')
    if not _same(result['context_query_identity']['query_hex'],context_bytes.hex(),check): raise ValueError('full original context byte image retained')
    q,cert=result['boundary_query_bytes'],result['boundary_certificate_bytes']
    if type(q) is not bytes or type(cert) is not bytes: raise ValueError('exact two immutable service byte leaves required')
    subject,reference=result['subject_receipt'],result['reference_receipt']
    if (subject['accepted'] is not True or subject['complete'] is not True or subject['status']!='VALID_DERIVATION'
            or subject['final_goal_equal'] is not True or subject['syntax_complete'] is not True or subject['derivation_complete'] is not True
            or reference['status']!='VALID_DERIVATION' or reference['complete_check'] is not True or reference['final_goal_equal'] is not True
            or subject['query']['EOF']!=len(q) or subject['certificate']['EOF']!=len(cert)):
        raise ValueError('complete fresh original identical-byte dual evidence required')
    for name,body in (('query',q),('certificate',cert)):
        if not _same(subject['raw_inputs'][name],_digest(body,check),check): raise ValueError('same original service byte identity')
    ports,nodes=family['boundary_nodes'],family['internal_nodes']; count=len(ports)+len(nodes)
    rows=result['expansion_rows']
    if len(rows)!=count or len(subject['certificate']['rows'])!=count or len(reference['rows'])!=count or subject['certificate']['row_count']!=count:
        raise ValueError('all physical rows retained without contraction')
    expected_maps=dict(boundary_to_wire=[[i,i] for i in range(len(ports))],internal_to_wire=[[i,len(ports)+i] for i in range(len(nodes))])
    if not _same(result['family_to_wire_rows'],expected_maps,check): raise ValueError('all canonical physical maps required')
    gamma=[]; evidence=[]
    for index,(emitted,actual,flat) in enumerate(zip(rows,subject['certificate']['rows'],reference['rows'])):
        check(); boundary=index<len(ports); local=index if boundary else index-len(ports)
        record=ports[local] if boundary else nodes[local]
        formula=_subst(record['formula_pattern'],binding,check)
        if (emitted['wire_index']!=index or actual['index']!=index or flat['index']!=index
                or emitted['origin_kind']!=('boundary' if boundary else 'internal') or emitted['origin_id']!=local
                or not _same(formula,emitted['formula'],check) or not _same(formula,actual['formula'],check)
                or not _same(_tokens(formula,check),flat['formula']['prefix_tokens'],check)
                or not _same(actual['span'],flat['byte_span'],check)):
            raise ValueError('every instantiated Formula/physical index/span joins both complete views')
        if boundary:
            gamma.append(formula); tag,subtag,witness,refs=0,None,[local],[]
        else:
            tag,subtag=record['rule_tag'],record['subtag']; refs=[]
            for ref in record['references']:
                check(); refs.append(ref['id'] if ref['kind']=='boundary' else len(ports)+ref['id'])
            witness=[_subst(p,binding,check) for p in record['witness_pattern']] if tag==1 else list(refs)
        if (emitted['rule_tag']!=tag or actual['rule_tag']!=tag or flat['rule_tag']!=tag
                or emitted['subtag']!=subtag or actual['subtag']!=subtag or flat['witness_tag']!=subtag
                or not _same(emitted['witness'],witness,check) or not _same(actual['witness'],witness,check)
                or not _same(emitted['references'],refs,check)):
            raise ValueError('all original logical witness and ordered reference joins required')
        if tag==1:
            if len(flat['payload'])!=len(witness): raise ValueError('complete independent logical payload')
            for value,other in zip(witness,flat['payload']):
                if not _same(_tokens(value,check),other['prefix_tokens'],check): raise ValueError('independent witness Formula token association')
        elif not _same(flat['payload'],witness,check): raise ValueError('independent ordered natural payload association')
        evidence.append(dict(wire_row=index,origin_kind=emitted['origin_kind'],origin_id=local,
            subject_row_span=actual['span'],reference_row_span=flat['byte_span'],formula_witness_reference_joined=True))
    expected=dict(version=1,claim_mode=1,function_arities=context['function_arities'],predicate_arities=context['predicate_arities'],
                  theory_profile=0,finite_axioms=[],Gamma=gamma,goal=_subst(nodes[-1]['formula_pattern'],binding,check))
    for name in QUERY_FIELDS:
        if not _same(subject['query'][name],expected[name],check): raise ValueError('exact complete standalone query semantics')
    return dict(schema='FPC-skeleton-instance-full-row-association-v1',complete=True,accepted=False,
                family_to_wire_rows=expected_maps,physical_rows=evidence,standalone_only=True)



def _bank_complete(value,check):
    _validate_json_image(value,check)
    _keys(value,('schema','version','population','complete','control_ids','controls','counts','scope','coverage_limits'),check)
    if (value['schema']!='FPC-stratified-acquisition-independent-controls-v1'
            or value['version']!=MODULE_VERSIONS['acquisition_bank']
            or value['population']!='stratified_acquisition6' or value['complete'] is not True
            or not _same(value['control_ids'],list(CONTROL_IDS['stratified_acquisition6']),check)
            or not _same(value['counts'],dict(groups=6,passed=6,failed=0),check)
            or value['scope']!=CONTROL_POPULATIONS[0]['scope'] or len(value['controls'])!=6
            or type(value['coverage_limits']) is not list):
        raise ValueError('complete six-group scoped acquisition bank required')
    for name,row in zip(CONTROL_IDS['stratified_acquisition6'],value['controls']):
        check(); _keys(row,('id','passed','observations','coverage_limits'),check)
        if (row['id']!=name or row['passed'] is not True or type(row['observations']) is not list
                or type(row['coverage_limits']) is not list):
            raise ValueError('every full scoped observation and coverage limit required')


def _descriptor_backproject(family,occurrence,donor,check):
    subject,reference=donor['subject_receipt'],donor['reference_receipt']
    selected,boundary=occurrence['source_to_local'],occurrence['boundary_source_to_port']
    if (len(selected)!=len(family['internal_nodes']) or len(boundary)!=len(family['boundary_nodes'])
            or not selected or occurrence['root_source_row']!=selected[-1][0]):
        raise ValueError('complete physical descriptor source maps required')
    source_lists=[boundary,selected]; checks=[]; seen=set()
    for kind,vector,records in (('boundary',boundary,family['boundary_nodes']),('internal',selected,family['internal_nodes'])):
        previous=-1
        for local,(pair,node) in enumerate(zip(vector,records)):
            check()
            if (type(pair) is not list or len(pair)!=2 or not _natural(pair[0])
                    or type(pair[1]) is not int or pair[1]!=local or pair[0]<=previous
                    or pair[0]>=len(subject['certificate']['rows']) or pair[0] in seen):
                raise ValueError('strict distinct ordered physical source maps required')
            source=pair[0]; previous=source; seen.add(source)
            row,flat=subject['certificate']['rows'][source],reference['rows'][source]
            formula=_subst(node['formula_pattern'],occurrence['source_bindings'],check)
            if (row['index']!=source or flat['index']!=source
                    or not _same(formula,row['formula'],check)
                    or not _same(_tokens(formula,check),flat['formula']['prefix_tokens'],check)
                    or not _same(row['span'],flat['byte_span'],check)):
                raise ValueError('all descriptor formulas and physical spans join both original views')
            if kind=='internal':
                if row['rule_tag']!=node['rule_tag'] or row['subtag']!=node['subtag']:
                    raise ValueError('every descriptor primitive tag/subtag backprojects')
                refs=[]
                for ref in node['references']:
                    check(); vector_index=0 if ref['kind']=='boundary' else 1
                    refs.append(source_lists[vector_index][ref['id']][0])
                if node['rule_tag']==1:
                    witness=[]
                    for pattern in node['witness_pattern']:
                        check(); witness.append(_subst(pattern,occurrence['source_bindings'],check))
                    if not _same(witness,row['witness'],check) or len(witness)!=len(flat['payload']):
                        raise ValueError('all original logical witness images retained')
                    for tree,other in zip(witness,flat['payload']):
                        check()
                        if not _same(_tokens(tree,check),other['prefix_tokens'],check):
                            raise ValueError('all independent logical witness images retained')
                elif node['rule_tag']==3:
                    if not _same(refs,row['witness'],check) or not _same(refs,flat['payload'],check):
                        raise ValueError('all ordered descriptor MP refs backproject physically')
                else: raise ValueError('only declared primitive internal descriptor rows')
            checks.append(dict(origin_kind=kind,origin_id=local,source_row=source,
                subject_row_span=row['span'],reference_row_span=flat['byte_span'],
                formula_witness_reference_joined=True))
    return dict(complete=True,accepted=False,source_root_row=occurrence['root_source_row'],physical_rows=checks)


def _extraction_complete(value,donors,check):
    _validate_json_image(value,check)
    _keys(value,('schema','status','complete','accepted','donor_validation','candidates','families','selection_coverage'),check)
    if (value['schema']!='FPC-stratified-schematic-receptor-library-candidate-v1'
            or value['status']!='LIBRARY_CANDIDATE' or value['complete'] is not True or value['accepted'] is not False):
        raise ValueError('STOP: complete usable nonadmitting stratified acquisition required')
    views,candidates,families,coverage=value['donor_validation'],value['candidates'],value['families'],value['selection_coverage']
    if len(views)!=2 or not 2<=len(families)<=8 or len(candidates)>112:
        raise ValueError('full fixed two-donor candidate/family bounds required')
    for index,(view,donor) in enumerate(zip(views,donors)):
        check(); _keys(view,('validation_index','donor_id','query_identity','certificate_identity','provenance','subject_receipt','reference_receipt'),check)
        subject,reference=view['subject_receipt'],view['reference_receipt']
        if (type(view['validation_index']) is not int or view['validation_index']!=index
                or view['donor_id']!=donor['donor_id'] or not _same(view['provenance'],donor['provenance'],check)
                or not _same(view['query_identity'],_digest(donor['query_bytes'],check),check)
                or not _same(view['certificate_identity'],_digest(donor['certificate_bytes'],check),check)
                or subject['accepted'] is not True or subject['complete'] is not True
                or subject['status']!='VALID_DERIVATION' or subject['final_goal_equal'] is not True
                or reference['status']!='VALID_DERIVATION' or reference['complete_check'] is not True
                or reference['final_goal_equal'] is not True or subject['query']['EOF']!=len(donor['query_bytes'])
                or subject['certificate']['EOF']!=len(donor['certificate_bytes'])
                or len(subject['certificate']['rows'])!=len(reference['rows'])):
            raise ValueError('complete identical original byte donor validation views required')
    _keys(coverage,('configuration','exhaustive_connected_subgraphs','donors','groups','selected_representatives',
        'selected_occurrences','distinct_keys','represented_donors','library_gate','source_occurrence_instance_gate',
        'sharing_or_multiscale_coverage_claim'),check)
    if (not _same(coverage['configuration'],CONFIGURATION,check) or coverage['exhaustive_connected_subgraphs'] is not False
            or coverage['library_gate'] is not True or coverage['sharing_or_multiscale_coverage_claim'] is not False
            or coverage['source_occurrence_instance_gate']!='NOT_RUN_EXTERNAL_INSTANCE_CALLER_REQUIRED'
            or not _same(coverage['represented_donors'],['donor0','donor1'],check)
            or coverage['distinct_keys']!=len(families) or len(coverage['donors'])!=2):
        raise ValueError('full fixed sampled acquisition coverage/gate required')
    candidate_audits=[]
    for index,candidate in enumerate(candidates):
        check(); _keys(candidate,('candidate_index','donor_validation_index','sample_ordinal','root_source_row',
            'prefix_size','prefix_source_rows','inference','metrics'),check)
        donor_index=candidate['donor_validation_index']
        if (type(candidate['candidate_index']) is not int or candidate['candidate_index']!=index
                or type(donor_index) is not int or not 0<=donor_index<2
                or not 2<=candidate['prefix_size']<=8 or candidate['prefix_size']!=len(candidate['prefix_source_rows'])):
            raise ValueError('all complete ordered candidate records required')
        inference=candidate['inference']; source=inference['source_family']; _inference_complete(inference,source,check)
        if len(source['source_occurrences'])!=1 or len(inference['family']['source_occurrences'])!=1:
            raise ValueError('one physical donor occurrence per inferred prefix required')
        original=source['source_occurrences'][0]; generalized=inference['family']['source_occurrences'][0]
        source_ids=[]
        for pair in original['source_to_local']: check(); source_ids.append(pair[0])
        if (original['donor_id']!=donors[donor_index]['donor_id']
                or original['root_source_row']!=candidate['root_source_row']
                or not _same(source_ids,candidate['prefix_source_rows'],check)):
            raise ValueError('full candidate-to-donor source identity required')
        original_join=_descriptor_backproject(source,original,views[donor_index],check)
        generalized_join=_descriptor_backproject(inference['family'],generalized,views[donor_index],check)
        _keys(candidate['metrics'],('internal_nodes','MP_nodes','sharing_excess','boundary_count','root_pattern_nodes','root_in_boundary','root_support'),check)
        for name,number in candidate['metrics'].items():
            check()
            if name=='root_in_boundary':
                if type(number) is not bool: raise ValueError('exact diagnostic subtree bool required')
            elif not _natural(number): raise ValueError('strict normal metric counts required')
        candidate_audits.append(dict(candidate_index=index,donor_validation_index=donor_index,
            source_family_backprojection=original_join,generalized_family_backprojection=generalized_join))
    seen_candidates=set()
    for donor_index,record in enumerate(coverage['donors']):
        check(); _keys(record,('donor_id','donor_validation_index','reachable_row_count','reachable_MP_rows','samples',
            'prefix_attempts','bin_selection','fill_selection','selected_group_indices','selected_candidate_indices'),check)
        if record['donor_id']!=donors[donor_index]['donor_id'] or record['donor_validation_index']!=donor_index or len(record['samples'])>8:
            raise ValueError('both exact donor/root coverage records required')
        samples={}
        for sample_index,sample in enumerate(record['samples']):
            check(); _keys(sample,('sample_index','mp_ordinal','root_source_row'),check)
            ordinal=sample['mp_ordinal']
            if (sample['sample_index']!=sample_index or not _natural(ordinal) or ordinal>=len(record['reachable_MP_rows'])
                    or record['reachable_MP_rows'][ordinal]!=sample['root_source_row'] or ordinal in samples):
                raise ValueError('complete unique sampled MP associations required')
            samples[ordinal]=sample['root_source_row']
        for attempt in record['prefix_attempts']:
            check(); _keys(attempt,('sample_ordinal','root_source_row','prefix_size','prefix_source_rows','eligibility','candidate_index'),check)
            if attempt['sample_ordinal'] not in samples or samples[attempt['sample_ordinal']]!=attempt['root_source_row']:
                raise ValueError('every attempted prefix joins an actual sample')
            ci=attempt['candidate_index']
            if attempt['eligibility']=='ELIGIBLE':
                if not _natural(ci) or ci>=len(candidates) or ci in seen_candidates: raise ValueError('every inference exactly one attempted prefix')
                seen_candidates.add(ci); candidate=candidates[ci]
                for name in ('sample_ordinal','root_source_row','prefix_size','prefix_source_rows'):
                    if not _same(attempt[name],candidate[name],check): raise ValueError('entire prefix-to-candidate association')
                if candidate['donor_validation_index']!=donor_index: raise ValueError('exact candidate donor required')
            elif attempt['eligibility'] not in ('BOUNDARY_LIMIT','UNSUPPORTED_INTERNAL') or ci is not None:
                raise ValueError('only original declared ordinary ineligibility is allowed')
    if len(seen_candidates)!=len(candidates): raise ValueError('no omitted candidate inference')
    groups=coverage['groups']; grouped=set()
    for group_index,group in enumerate(groups):
        check(); _keys(group,('group_index','family_key','family_id','candidate_indices','support','root_support','representatives','selected_donors'),check)
        if group['group_index']!=group_index: raise ValueError('ordered complete full-key groups')
        for ci in group['candidate_indices']:
            check()
            if not _natural(ci) or ci>=len(candidates) or ci in grouped: raise ValueError('one full group per candidate')
            grouped.add(ci)
            if not _same(group['family_key'],candidates[ci]['inference']['family']['family_key'],check):
                raise ValueError('group by full generic key, never display hash')
        for rep in group['representatives']:
            check(); _keys(rep,('donor_validation_index','candidate_index','source_tuple','bin','rank'),check)
            ci=rep['candidate_index']
            if ci not in group['candidate_indices'] or candidates[ci]['donor_validation_index']!=rep['donor_validation_index']:
                raise ValueError('complete donor/key representative association')
    if len(grouped)!=len(candidates): raise ValueError('no candidate omitted from full grouping')
    links=coverage['selected_representatives']; linked=set(); donor_counts=[0,0]
    if not 2<=len(links)<=8 or coverage['selected_occurrences']!=len(links): raise ValueError('all bounded selected occurrences required')
    for link in links:
        check(); _keys(link,('family_index','group_index','donor_validation_index','candidate_index','source_occurrence_index'),check)
        fi,gi,di,ci,oi=[link[k] for k in ('family_index','group_index','donor_validation_index','candidate_index','source_occurrence_index')]
        if (not all(_natural(x) for x in (fi,gi,di,ci,oi)) or fi>=len(families) or gi>=len(groups)
                or di>=2 or ci>=len(candidates) or oi>=len(families[fi]['source_occurrences']) or (fi,oi) in linked
                or candidates[ci]['donor_validation_index']!=di or ci not in groups[gi]['candidate_indices']):
            raise ValueError('exact complete selected occurrence links required')
        linked.add((fi,oi)); donor_counts[di]+=1
        family=families[fi]; inferred=candidates[ci]['inference']['family']
        if (not _same(family['family_key'],inferred['family_key'],check)
                or not _same(family['family_key'],groups[gi]['family_key'],check)
                or not _same(family['source_occurrences'][oi],inferred['source_occurrences'][0],check)):
            raise ValueError('every selected family and composed source binding retained exactly')
    total=0
    for fi,family in enumerate(families):
        check()
        for before in families[:fi]:
            if _same(before['family_key'],family['family_key'],check): raise ValueError('full-key selected diversity')
        if not 1<=len(family['source_occurrences'])<=2: raise ValueError('original occurrence bound')
        for oi in range(len(family['source_occurrences'])):
            check(); total+=1
            if (fi,oi) not in linked: raise ValueError('every selected source compile obligation present')
    if total!=len(links) or not all(1<=n<=4 for n in donor_counts): raise ValueError('fixed per-donor selected coverage')
    return total,candidate_audits



def main(plan_path,actual_dir,root_start):
    if not (sys.platform=='darwin' and sys.implementation.name=='cpython' and sys.version.split()[0]=='3.12.14'
            and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and os.getpid()==os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start) and 0<=root_start<=time.monotonic()):
        raise ValueError('exact isolated owned pinned child and inherited genuine parent clock required')
    began=root_start; directory=Path(actual_dir); plan_path=Path(plan_path); study=Path(__file__).resolve().parents[1]
    plan_pin=raw_pin(plan_path); plan_body=plan_path.read_bytes()
    if byte_identity(plan_body)!={k:plan_pin[k] for k in ('bytes','sha256')}: raise ValueError('stable entire plan required')
    plan=json.loads(plan_body); plan_body=None
    if type(plan) is not dict or set(plan)!=set(PLAN_FIELDS): raise ValueError('exact narrow profile plan fields required')
    if (plan['schema']!='proof-search-case-once-plan-v1' or plan['case_id']!=CASE or plan['experiment']!=EXPERIMENT
            or plan['stage']!='acquisition' or plan['profile']!=PROFILE or directory!=study/'actual'/CASE
            or plan['actual_dir']!=str(directory) or not directory.is_absolute() or directory.resolve()!=directory
            or directory.is_symlink() or not directory.is_dir() or plan_path.parent!=study/'root'/'plans'
            or Path(plan['worker_path'])!=Path(__file__).resolve()): raise ValueError('one exact fresh acquisition case required')
    if type(plan['limits']) is not dict or set(plan['limits'])!=set(CAPS) or any(type(plan['limits'][k]) is not int or plan['limits'][k]!=v for k,v in CAPS.items()):
        raise ValueError('all original exact ten caps required')
    resource.setrlimit(resource.RLIMIT_FSIZE,(CAPS['physical_bytes'],CAPS['physical_bytes']))
    consumed=json.loads((directory/'CONSUMED.json').read_bytes())
    if consumed['schema']!='proof-search-case-consumed-v1' or consumed['plan_sha256']!=plan_pin['sha256'] or consumed['case_id']!=CASE or type(consumed['uses']) is not int or consumed['uses']!=1:
        raise ValueError('one fresh owned consumption required')
    state=dict(stage='PIN_INTAKE',callbacks=0,first_fault=None,first_fault_monotonic_ns=None,stages=[],versions={})
    primary=None; guards=[]; source_unchanged=False; modules={}; public_bindings=[]; projections={}
    positives={name:None for name in POSITIVE_FIELDS}; provisional=[]; committed_bytes=0; output_rejection=None
    originals=[]; donors=[]; donor_metadata=[]; contexts={}; source_instances=[]; generic_instances=[]
    extraction=None; input_freeze=None; input_frozen=None; configuration=None; configuration_frozen=None
    data_refs=[record[name] for record in INPUT_AUTHORITY for name in ('query','certificate')]

    def check():
        if state['first_fault'] is not None: raise state['first_fault']
        state['callbacks']+=1; error=None
        if state['callbacks']>CAPS['root_callbacks']: error=RootBudget('cumulative Root callback ceiling')
        elif time.monotonic()-began>=CAPS['work_seconds']: error=RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>=CAPS['memory_bytes']: error=RootBudget('strict Python whole high-water ceiling')
        if error is not None:
            state['first_fault']=error; state['first_fault_monotonic_ns']=time.monotonic_ns(); raise error

    def policy_check():
        check(); value=sys.get_int_max_str_digits()
        if type(value) is not int or value!=POLICY_BINDING[1]: raise ValueError('reference effective native integer policy drift')
        return value

    def stage(name,operation):
        policy_check(); state['stage']=name
        row=dict(name=name,began=time.monotonic()-began,status='STARTED'); state['stages'].append(row)
        value=operation(); policy_check(); row.update(status='COMPLETED',seconds=time.monotonic()-began-row['began']); return value

    def verify_files(cooperative):
        for row in guards:
            if cooperative: check()
            if raw_pin(row['path'])!=row: raise ValueError('changed declared Source/metadata: '+row['path'])

    def canonical(value):
        _validate_json_image(value,check); policy_check()
        body=(json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':'))+'\n').encode('ascii')
        policy_check(); return body

    def metadata(ref):
        ref=pin_fields(ref)
        if by_path.get(ref['path'])!=ref: raise ValueError('explicit guarded metadata required')
        body=_read_original(ref,policy_check); value=json.loads(body); policy_check(); return value

    def stable():
        policy_check()
        if input_frozen is not None and not _checked_byte_equal(canonical(input_freeze),input_frozen,check): raise ValueError('full input metadata freeze mutated')
        if configuration_frozen is not None and not _checked_byte_equal(canonical(configuration),configuration_frozen,check): raise ValueError('extraction config mutated')
        for role,name,entry in public_bindings:
            check()
            if getattr(modules[role],name) is not entry or type(modules[role].VERSION) is not str or modules[role].VERSION!=MODULE_VERSIONS[role]:
                raise ValueError('exact original public namespace identity changed')
        for name,expected in (('bank',tuple(role for role in MODULE_ROLES if role!='acquisition_bank')),('service',('checker','builders','reference'))):
            if name in projections:
                _keys(projections[name],expected,check)
                for role in expected:
                    check()
                    if projections[name][role] is not modules[role]: raise ValueError('exact projection mutated')
        for index,donor in enumerate(donors):
            check()
            if (donor['query_bytes'] is not originals[index][0] or donor['certificate_bytes'] is not originals[index][1]
                    or donor['donor_id']!=INPUT_AUTHORITY[index]['donor_id']
                    or not _same(donor['provenance'],input_freeze['donors'][index]['provenance'],check)):
                raise ValueError('exact immutable admitted original pair/provenance changed')

    def decide_size(body,name):
        nonlocal output_rejection
        policy_check(); prospective=committed_bytes+len(body)
        if prospective>CAPS['result_bytes']:
            if output_rejection is None:
                output_rejection=dict(schema='FPC-stratified-acquisition-output-rejection-v1',component=name,
                    exact_attempt_bytes=len(body),committed_positive_bytes_before=committed_bytes,
                    prospective_positive_bytes=prospective,cap_bytes=CAPS['result_bytes'])
            error=RootBudget('bank+original+generated bytes+ENTIRE result exceed shared48MiB')
            state['first_fault']=error; state['first_fault_monotonic_ns']=time.monotonic_ns(); raise error

    def export(name,body):
        nonlocal committed_bytes
        if type(body) is not bytes: raise ValueError('original immutable artifact bytes required')
        decide_size(body,name); progress=dict(basename=name,phase='BEFORE_WRITE',readback_complete=False); provisional.append(progress)
        expected=_digest(body,policy_check); actual=_write_bank_and_readback(directory/name,body,policy_check,progress)
        if not _same(actual,expected,check): raise ValueError('complete original artifact readback required')
        committed_bytes+=len(body)
        return dict(schema='FPC-receptor-original-bytes-artifact-ref-v1',path=name,bytes=actual['bytes'],sha256=actual['sha256'])

    def saved_instance(result,prefix):
        q=result['boundary_query_bytes']; cert=result['boundary_certificate_bytes']
        qref=stage('EXPORT '+prefix+' QUERY',lambda:export(prefix+'-query.bin',q))
        cref=stage('EXPORT '+prefix+' CERTIFICATE',lambda:export(prefix+'-certificate.bin',cert))
        saved=dict(result); saved['boundary_query_bytes']=qref; saved['boundary_certificate_bytes']=cref
        _validate_json_image(saved,check); return saved

    def retire_positive():
        nonlocal extraction,input_freeze,input_frozen,configuration,configuration_frozen,source_instances,generic_instances,contexts,originals,donors,donor_metadata
        for name in POSITIVE_FIELDS: positives[name]=None
        extraction=input_freeze=input_frozen=configuration=configuration_frozen=None
        source_instances=[]; generic_instances=[]; contexts={}; originals=[]; donors=[]; donor_metadata=[]

    try:
        check(); _keys(plan['module_pins'],MODULE_ROLES,check)
        if not _same(plan['module_pins'],MODULE_PINS,check) or not _same(plan['input_authority'],INPUT_AUTHORITY,check) or not _same(plan['Source_components'],SOURCE_COMPONENTS,check):
            raise ValueError('exact current module pins/input authority/components required')
        if type(plan['files']) is not list or not plan['files']: raise ValueError('nonempty explicit Source closure required')
        guards=[pin_fields(row) for row in plan['files']]; by_path={row['path']:row for row in guards}
        if len(by_path)!=len(guards): raise ValueError('unique guard paths required')
        for ref in guards:
            check()
            if '/actual/' in ref['path'] or ref['path'].endswith('.bin'): raise ValueError('data bodies never Source guards')
        for ref in list(MODULE_PINS.values())+list(CUSTODY_RUNTIME.values())+REQUIRED_METADATA_GUARDS:
            check()
            if by_path.get(ref['path'])!=ref: raise ValueError('every exact used runtime/metadata guard required')
        if (pin_fields(plan['python'])!=CUSTODY_RUNTIME['python'] or raw_pin(Path(sys.executable).resolve())!=CUSTODY_RUNTIME['python']
                or plan['runner_path']!=CUSTODY_RUNTIME['runner']['path']
                or by_path.get(str(Path(__file__).resolve()))!=raw_pin(Path(__file__).resolve())):
            raise ValueError('exact inherited custody/current caller/environment required')
        protocol=metadata(plan['protocol']); _keys(protocol,('schema','experiment','limits','module_pins','control_populations','job_recipes','metadata'),check)
        expected_metadata=dict(profile=PROFILE,input_authority=INPUT_AUTHORITY,Source_components=SOURCE_COMPONENTS,reference_integer_policy=list(POLICY_BINDING))
        if (protocol['schema']!=PROTOCOL_SCHEMA or protocol['experiment']!=EXPERIMENT or not _same(protocol['limits'],CAPS,check)
                or not _same(protocol['module_pins'],MODULE_PINS,check) or not _same(protocol['control_populations'],CONTROL_POPULATIONS,check)
                or not _same(protocol['job_recipes'],[dict(case_id=CASE,stage='acquisition')],check)
                or not _same(protocol['metadata'],expected_metadata,check)): raise ValueError('exact prospective compact protocol required')
        verify_files(True); reference_policy=[POLICY_BINDING[0],policy_check()]
        # Handoffs/contracts are exact guard metadata; external Source/whole acceptance remains Root/C, without a self-pin cycle.
        for ref in SOURCE_COMPONENTS: metadata(ref)
        for index,record in enumerate(INPUT_AUTHORITY):
            root_admission=metadata(record['Root_admission']); review=metadata(record['C_actual_review'])
            if (root_admission['schema']!='Root-FPC-cohort-backed-donor-admission-v1'
                    or type(root_admission['donor_index']) is not int or root_admission['donor_index']!=index
                    or root_admission['proof_admitted'] is not True or root_admission['resources_and_custody_accepted'] is not True
                    or root_admission['fresh_whole_original_byte_dual_gate'] is not True
                    or not _same(root_admission['C_actual_review'],record['C_actual_review'],check)
                    or not _same(root_admission['complete_C_review'],record['C_actual_review'],check)
                    or not _same(root_admission['query'],record['query'],check) or not _same(root_admission['certificate'],record['certificate'],check)
                    or review['schema']!='C-cohort-backed-per-proof-donor-complete-whole-actual-review-v1'
                    or type(review['donor_index']) is not int or review['donor_index']!=index
                    or review['review_passed'] is not True or review['blockers']!=[]
                    or not _same(review['subjects']['original_query'],record['query'],check)
                    or not _same(review['subjects']['original_certificate'],record['certificate'],check)
                    or not _same(root_admission['plan'],review['subjects']['plan'],check)):
                raise ValueError('complete exact original-byte Root/C donor association required')
            donor_metadata.append(dict(donor_id=record['donor_id'],Root_admission=record['Root_admission'],
                C_actual_review=record['C_actual_review'],prior_ordinary_acquisition_metrics=root_admission['metrics']))
        positives['donor_provenance']=dict(schema='FPC-stratified-acquisition-donor-provenance-v1',complete=True,accepted=False,
            admitted_originals=donor_metadata,old229_DAG8_schema6_rerun=False,old_library_or_result_loaded=False)
        for role in MODULE_ROLES:
            modules[role]=stage('IMPORT '+role,lambda role=role:load_exact(MODULE_PINS[role],'_stratified_acquisition_'+role+'_once_v1',check))
            if type(modules[role].VERSION) is not str or modules[role].VERSION!=MODULE_VERSIONS[role]: raise ValueError('exact namespace VERSION required')
            state['versions'][role]=modules[role].VERSION
            for name in PUBLIC_ENTRIES[role]:
                check(); entry=getattr(modules[role],name)
                if not callable(entry): raise ValueError('original public callable required')
                public_bindings.append((role,name,entry))
        projections['bank']={role:modules[role] for role in MODULE_ROLES if role!='acquisition_bank'}
        projections['service']={role:modules[role] for role in ('checker','builders','reference')}
        bank=stage('ACQUISITION6',lambda:modules['acquisition_bank'].run_bank(projections['bank'],check=check)); stable(); _bank_complete(bank,check)
        bank_ref=stage('EXPORT ACQUISITION6',lambda:export('acquisition-bank.json',canonical(bank)))
        positives['acquisition6_qualification']=dict(complete_return=bank,artifact=bank_ref)
        input_freeze=dict(schema='FPC-stratified-acquisition-input-freeze-v1',donors=[],configuration=dict(CONFIGURATION),
            runtime_module_pins=MODULE_PINS,Source_components=SOURCE_COMPONENTS,reference_integer_policy=reference_policy,
            no_input_selection=True,holdout_loaded=False)
        for index,record in enumerate(INPUT_AUTHORITY):
            query=stage('LOAD ORIGINAL QUERY '+str(index),lambda record=record:_read_original(record['query'],policy_check))
            certificate=stage('LOAD ORIGINAL CERTIFICATE '+str(index),lambda record=record:_read_original(record['certificate'],policy_check))
            originals.append((query,certificate))
            provenance=dict(schema='FPC-receptor-donor-provenance-v1',Root_admission=record['Root_admission'],C_actual_review=record['C_actual_review'],
                query=_digest(query,check),certificate=_digest(certificate,check),
                module_pins={role:MODULE_PINS[role] for role in ('checker','builders','reference')})
            donors.append(dict(donor_id=record['donor_id'],query_bytes=query,certificate_bytes=certificate,provenance=provenance))
            qref=stage('EXPORT ORIGINAL QUERY '+str(index),lambda index=index,query=query:export('donor-'+str(index)+'-query.bin',query))
            cref=stage('EXPORT ORIGINAL CERTIFICATE '+str(index),lambda index=index,certificate=certificate:export('donor-'+str(index)+'-certificate.bin',certificate))
            input_freeze['donors'].append(dict(donor_id=record['donor_id'],provenance=provenance,query=qref,certificate=cref,
                original_query=record['query'],original_certificate=record['certificate']))
        if _checked_byte_equal(originals[0][0],originals[1][0],check): raise ValueError('two distinct full original query bytes required')
        configuration=dict(CONFIGURATION); configuration_frozen=canonical(configuration); input_frozen=canonical(input_freeze)
        positives['input_freeze']=input_freeze; stable()
        extraction=stage('EXTRACT STRATIFIED ONCE',lambda:modules['extractor'].extract_schematic_families(donors,
            modules=projections['service'],schema=modules['schema'],instance=modules['instance'],configuration=configuration,check=check))
        stable(); occurrence_count,candidate_audits=_extraction_complete(extraction,donors,check)
        for index,view in enumerate(extraction['donor_validation']): contexts[INPUT_AUTHORITY[index]['donor_id']]=view['subject_receipt']['query']
        positives['extraction_result']=extraction
        families_freeze=canonical(extraction['families'])
        for family_index,family in enumerate(extraction['families']):
            family_frozen=canonical(family)
            for occurrence_index,occurrence in enumerate(family['source_occurrences']):
                donor_index=0 if occurrence['donor_id']=='donor0' else 1; donor=INPUT_AUTHORITY[donor_index]['donor_id']
                service=stage('SOURCE INSTANCE '+str(family_index)+':'+str(occurrence_index),lambda family=family,occurrence=occurrence,donor_index=donor_index:
                    modules['wide_instance'].compile_instance(originals[donor_index][0],family,occurrence['source_bindings'],
                    encoder=modules['wide_encoder'].encode_tiny_declared_query,modules=projections['service'],check=check))
                stable(); join=_instance_join(family,occurrence['source_bindings'],service,contexts[donor],originals[donor_index][0],check)
                backprojection=_backproject(family,occurrence,service,extraction['donor_validation'][donor_index],check)
                if not _checked_byte_equal(family_frozen,canonical(family),check): raise ValueError('selected family mutated')
                saved=saved_instance(service,'source-'+str(len(source_instances)))
                source_instances.append(dict(family_index=family_index,source_occurrence_index=occurrence_index,donor_validation_index=donor_index,
                    source_occurrence=occurrence,instance=saved,full_row_association=join,source_backprojection=backprojection))
                service=saved=join=backprojection=None
            count=len(family['parameters'])
            if not 1<=count<=64: raise ValueError('whole STOP: independent generic signature outside frozen scope')
            predicates=[]; binding=[]
            for index,parameter in enumerate(family['parameters']):
                check()
                if type(parameter['id']) is not int or parameter['id']!=index or parameter['sort']!='Formula': raise ValueError('exact ordered whole Formula parameters')
                predicates.append(0); binding.append(dict(parameter_id=index,formula=['pred',index,[]]))
            semantic=dict(version=1,claim_mode=0,function_arities=[],predicate_arities=predicates,theory_profile=0,finite_axioms=[],Gamma=[],goal=['pred',0,[]])
            semantic_freeze=canonical(semantic)
            encoded=stage('ENCODE GENERIC CONTEXT '+str(family_index),lambda semantic=semantic:modules['wide_encoder'].encode_tiny_declared_query(semantic,check=check))
            stable(); _keys(encoded,('query_bytes','receipt'),check); er=encoded['receipt']
            _keys(er,('schema','version','complete','semantic_query','query_identity','limits','expanded_nodes','scope'),check)
            context_bytes=encoded['query_bytes']
            if (type(context_bytes) is not bytes or er['schema']!='independent-wide-FPC-query-encoding-v1'
                    or er['version']!=MODULE_VERSIONS['wide_encoder'] or er['complete'] is not True
                    or not _same(er['limits'],WIDE_LIMITS,check) or not _same(er['semantic_query'],semantic,check)
                    or not _same(er['query_identity'],_digest(context_bytes,check),check)
                    or not _natural(er['expanded_nodes']) or er['expanded_nodes']>4096
                    or not _checked_byte_equal(semantic_freeze,canonical(semantic),check)):
                raise ValueError('entire fresh generic-context encoding receipt/semantics/bytes required')
            context_ref=stage('EXPORT GENERIC CONTEXT '+str(family_index),lambda context_bytes=context_bytes,family_index=family_index:
                export('generic-'+str(family_index)+'-context-query.bin',context_bytes))
            service=stage('GENERIC INSTANCE '+str(family_index),lambda family=family,binding=binding,context_bytes=context_bytes:
                modules['wide_instance'].compile_instance(context_bytes,family,binding,encoder=modules['wide_encoder'].encode_tiny_declared_query,
                    modules=projections['service'],check=check))
            stable(); join=_instance_join(family,binding,service,semantic,context_bytes,check)
            if not _checked_byte_equal(family_frozen,canonical(family),check): raise ValueError('generic family mutated')
            saved=saved_instance(service,'generic-'+str(family_index))
            generic_instances.append(dict(family_index=family_index,independent_atom_binding=binding,
                context_encoding=dict(query_bytes=context_ref,receipt=er),instance=saved,full_row_association=join))
            service=saved=join=encoded=er=context_bytes=semantic=semantic_freeze=binding=None
        if (len(source_instances)!=occurrence_count or len(generic_instances)!=len(extraction['families'])
                or not _checked_byte_equal(families_freeze,canonical(extraction['families']),check)):
            raise ValueError('every selected source and generic obligation required together')
        positives['source_instance_results']=source_instances; positives['generic_exercise_results']=generic_instances
        positives['scientific_result']=dict(schema='FPC-stratified-schema-acquisition-observation-v1',accepted=False,library_admitted=False,proof_admitted=False,
            scoped_bank_groups=6,extractor_calls=1,candidate_inference_calls=len(extraction['candidates']),candidate_association_audits=candidate_audits,
            selected_unique_keys=len(extraction['families']),selected_source_occurrences=occurrence_count,
            source_instance_calls=len(source_instances),generic_instance_calls=len(generic_instances),
            old229_DAG8_schema6_rerun=False,old_library_or_result_loaded=False,holdout_loaded=False,holdout_searched=False,
            contextual_use=False,principal_schema_claim=False,GCTS_RL_claim=False,
            positive_body_bytes_before_result=committed_bytes,
            cost_scope='Inherited parent-start entire cold setup/imports/new6/admission and original byte intake/all sampled acquisition/all source and generic compile/dual maps/export/readback/retirement/custody; old qualification/acquisition costs separate.')
        stable()
        for ref in data_refs: _read_original(ref,policy_check)
        verify_files(True); policy_check()
    except BaseException as error:
        primary=state['first_fault'] if state['first_fault'] is not None else error
    finally:
        source_unchanged=False
        try: verify_files(primary is None); source_unchanged=bool(guards)
        except BaseException as error:
            if primary is None: primary=state['first_fault'] if state['first_fault'] is not None else error
        if primary is not None: retire_positive()
    extraction=None; originals=[]; donors=[]; donor_metadata=[]; contexts={}; source_instances=[]; generic_instances=[]
    service=saved=join=backprojection=family=occurrence=encoded=er=context_bytes=semantic=binding=None
    bank=bank_ref=source_records=candidate_audits=family_frozen=families_freeze=input_frozen=configuration_frozen=None
    query=certificate=provenance=configuration=input_freeze=semantic_freeze=None
    public_bindings.clear(); projections.clear(); modules.clear()

    def receipt():
        value=dict(schema='FPC-stratified-schema-whole-acquisition-receipt-v1',case_id=CASE,stage='acquisition',worker_version=VERSION,
            status='STRATIFIED_SCHEMA_ACQUISITION_CANDIDATE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            accepted=False,library_admitted=False,proof_admitted=False,candidate_complete=primary is None,qualification_complete=False,
            prior_qualification_rerun=False,stages=state['stages'],callbacks=state['callbacks'],elapsed_seconds=time.monotonic()-began,
            python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,source_unchanged=source_unchanged,
            native_peak_bytes=0,native_requests_started=0,native_queries=[],native_transport=dict(closed=True,all_reaped=True,native_exit_code=0,
                native_high_water_bytes=0,subprocesses_started=0,scope='VACUOUS_NO_NATIVE_SUBPROCESS'),guard_compilations=[],
            component_versions=state['versions'],error=None if primary is None else dict(type=type(primary).__name__,message=str(primary),traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,first_fault_monotonic_ns=state['first_fault_monotonic_ns'],output_rejection=output_rejection,
            provisional_artifacts=provisional,STOP=None if primary is None else 'STOP_WHOLE_NOT_ADMITTED',
            scope='Distinct six-group training-only stratified acquisition/all selected source and independent-atom compilation feasibility; no old229/DAG8/schema6 rerun, contextual use, principal-schema theorem, GCTS/RL advantage or library/proof admission.')
        for name in POSITIVE_FIELDS: value[name]=positives[name] if primary is None else None
        return value

    try:
        if primary is None:
            body=canonical(receipt()); decide_size(body,'ENTIRE_RESULT_JSON'); policy_check()
        else: body=serialize(receipt(),CAPS['result_bytes'])
    except BaseException as error:
        if primary is None: primary=state['first_fault'] if state['first_fault'] is not None else error
        retire_positive(); body=serialize(receipt(),CAPS['result_bytes'])
    output=directory/('result.json' if primary is None else 'failure.json')
    if primary is None:
        progress=dict(phase='BEFORE_WRITE',readback_complete=False)
        try:
            _write_bank_and_readback(output,body,policy_check,progress)
            source_unchanged=False; verify_files(True); source_unchanged=bool(guards); policy_check()
        except BaseException as error:
            if progress['phase']=='BEFORE_WRITE' or progress['phase']=='WRITING_PARTIAL':
                primary=state['first_fault'] if state['first_fault'] is not None else error
                retire_positive(); body=serialize(receipt(),CAPS['result_bytes']); output=directory/'failure.json'; write_body(output,body)
            else: raise
    else: write_body(output,body)
    body=None
    header=dict(schema='proof-search-case-worker-header-v1',case_id=CASE,status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'],seconds=time.monotonic()-began,python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0,source_unchanged=source_unchanged,native_closed_and_reaped=True,first_Root_fault=state['first_fault'] is not None,
        result=raw_pin(output),native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory/'worker-header.json',serialize(header,CAPS['log_bytes']))
    print(json.dumps(dict(case_id=CASE,status=header['status'],callbacks=state['callbacks'],seconds=time.monotonic()-began)))
    return 0 if primary is None and source_unchanged and time.monotonic()-began<CAPS['positive_seconds'] and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<CAPS['memory_bytes'] else 2


if __name__=='__main__':
    if len(sys.argv)!=4: raise SystemExit('usage: fpc_stratified_acquisition_worker_v1.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1],sys.argv[2],float(sys.argv[3])))
