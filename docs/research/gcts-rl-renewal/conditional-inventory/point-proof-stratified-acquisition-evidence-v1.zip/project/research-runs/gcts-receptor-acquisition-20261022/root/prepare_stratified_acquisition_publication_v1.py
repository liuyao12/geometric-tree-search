"""Administrative report and exact task-evidence packaging; no scientific replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import html
import json
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
P2 = STUDY.parent / 'gcts-batch-20261020/publisher-recovery-6338a77'
CASE = STUDY / 'actual/two-admitted-donor-stratified-schema-acquisition-v1-case-0'
STAGE = ROOT / 'publication-stratified-acquisition-v1'
PAYLOAD = P2 / 'publication-payload-stratified-acquisition-v1'
PRIOR = ROOT / 'publication-skeleton-schema-v2'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html',
         'point-proof-stratified-acquisition-summary-v1.json',
         'point-proof-stratified-acquisition-evidence-v1.zip')


def raw(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    assert path.name not in ('index.html', '.gcts-active')
    return path.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def js(value):
    return (json.dumps(value, ensure_ascii=True, allow_nan=False, indent=2) + '\n').encode()


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert raw(path) == body


def formula(tree):
    tag = tree[0]
    if tag == 'param':
        return 'A_{' + str(tree[1]) + '}'
    if tag == 'pred':
        assert tree[2] == []
        return 'P_{' + str(tree[1]) + '}'
    if tag == 'not':
        return r'\neg\bigl(' + formula(tree[1]) + r'\bigr)'
    assert tag == 'imp'
    return r'\bigl(' + formula(tree[1]) + r'\to ' + formula(tree[2]) + r'\bigr)'


def math(value):
    return r'\(' + html.escape(str(value)) + r'\)'


def proof_rows(family):
    out = []
    for port in family['boundary_nodes']:
        out.append(dict(line=len(out)+1, role='boundary', rule='Hypothesis',
            formula=port['formula_pattern'], references=[],
            english='Assume this required boundary premise. Later use must supply a proof of it.'))
    shift = len(out)
    for node in family['internal_nodes']:
        refs = [1 + ref['id'] + (shift if ref['kind'] == 'internal' else 0)
                for ref in node['references']]
        if node['rule_tag'] == 1:
            rule = 'H' + str(node['subtag']+1)
            role = 'axiom'
            english = 'Use an instance of logical axiom ' + rule + '.'
        else:
            assert node['rule_tag'] == 3 and len(refs) == 2
            rule, role = 'Modus ponens', 'inference'
            english = f'Apply the implication in line {refs[1]} to line {refs[0]}.'
        out.append(dict(line=len(out)+1, role=role, rule=rule,
                        formula=node['formula_pattern'], references=refs, english=english))
    return out


def table(rows):
    out = ['<div class="schema-scroll"><table><thead><tr><th>Line</th><th>Rule / inputs</th><th>Formula</th><th>English</th></tr></thead><tbody>']
    for row in rows:
        refs = '<br>' + math(','.join(map(str, row['references']))) if row['references'] else ''
        out.append('<tr><td>' + math(row['line']) + '</td><td><span class="schema-role ' +
            row['role'] + '">' + row['rule'] + '</span>' + refs + '</td><td>' +
            math(formula(row['formula'])) + '</td><td>' + html.escape(row['english']) + '</td></tr>')
    return ''.join(out) + '</tbody></table></div>'


def main():
    admission_path = ROOT / 'stratified-schema-acquisition-case-0-Root-complete-whole-admission-v1.json'
    admission = json.loads(raw(admission_path))
    assert admission['finite_schematic_inventory_admitted'] is True
    assert admission['result'] == pin(CASE / 'result.json')
    c_review = admission['complete_C_review']
    assert c_review == pin(Path(c_review['path']))
    assert json.loads(raw(c_review['path']))['review_passed'] is True
    authorization = ROOT / 'full-evidence-archive-direct-user-publication-authorization-v1.json'
    assert json.loads(raw(authorization))['direct_human_answer'] == 'Approve publishing the full archive'
    audit = json.loads(raw(admission['passive_audit']['path']))
    assert admission['passive_audit'] == pin(Path(admission['passive_audit']['path']))
    result = json.loads(raw(CASE / 'result.json'))
    plan_path = ROOT / 'plans' / (CASE.name + '.json')
    plan = json.loads(raw(plan_path))
    families = result['extraction_result']['families']
    coverage = result['extraction_result']['selection_coverage']
    assert len(families) == 7 and len(result['source_instance_results']) == 8
    assert len(result['generic_exercise_results']) == 7
    members, external = {}, []

    def include(path, role, expected=None):
        path = Path(path)
        body = raw(path)
        ref = dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
        if expected is not None:
            assert ref == {key: expected[key] for key in ('path', 'bytes', 'sha256')}
        try:
            member = 'project/' + path.relative_to(REPO).as_posix()
        except ValueError:
            assert ref == plan['python']
            external.append(dict(role=role, **ref, supplied_separately=True))
            return
        assert not any(part in ('.git', '.aws', '.ssh') for part in path.parts)
        if member in members:
            assert members[member]['ref'] == ref
        else:
            members[member] = dict(role=role, ref=ref, body=body)

    for row in plan['files']:
        include(row['path'], 'exact-current-Source-or-metadata-guard', row)
    for row in audit['file_census']:
        include(row['path'], 'complete-current-actual-or-observer-file', row)
    extras = [admission_path, Path(c_review['path']), Path(admission['passive_audit']['path']),
        Path(admission['display_assessment']['path']), plan_path, authorization,
        ROOT / 'grants' / (CASE.name+'.json'),
        ROOT / 'stratified-schema-acquisition-case-0-Root-once-acceptance-v1.json',
        ROOT / 'stratified-schema-acquisition-case-0-Root-idle-barrier-v1.json',
        ROOT / 'stratified-schema-acquisition-study-preparation-v1.json',
        ROOT / 'stratified-schema-acquisition-prospective-metadata-Root-passive-audit-v1.json',
        STUDY / 'review-C/typed-stratified-schema-acquisition-complete-whole-prospective-review-v1.json',
        STUDY / 'review-C/typed-stratified-acquisition-bank-complete-successor-Source-review-v2.json',
        STUDY / 'review-C/typed-stratified-acquisition-bank-Source1-complete-negative-v1.json',
        STUDY / 'review-C/typed-stratified-acquisition-worker-Source1-complete-negative-v1.json',
        STUDY / 'review-C/typed-stratified-acquisition-metadata-emitter-successor-Source-review-v2.json',
        STUDY / 'diagnostics-L/stratified-acquisition-independent-bank-API-expectations-v1.json',
        STUDY / 'diagnostics-L/stratified-acquisition-independent-bank-API-expectations-v2.json',
        STUDY / 'diagnostics-L/fpc_stratified_acquisition_independent_bank_v1.py',
        STUDY / 'implementation-B/fpc_stratified_acquisition_worker_v1.py',
        ROOT / 'prepare_stratified_acquisition_study_v1.py', Path(__file__).resolve(),
        ROOT / 'publish_stratified_acquisition_api_v1.py',
        ROOT / 'verify_stratified_acquisition_live_v1.py']
    for name in ('stratified-acquisition-components-Source-handoff-v1.json',
                 'stratified-acquisition-worker-Source-handoff-v1.json',
                 'stratified-acquisition-worker-Source-handoff-v2.json'):
        packet_path = STUDY / 'implementation-B' / name
        extras.append(packet_path)
        packet = json.loads(raw(packet_path))
        for key in ('API', 'manual', 'static', 'dependency_offer', 'delta'):
            extras.append(Path(packet[key]['path']))
        for patch in packet.get('patches', []):
            extras.extend(Path(patch[key]['path']) for key in ('forward', 'inverse'))
    prior_zip = PRIOR / 'point-proof-skeleton-schema-evidence-v1.zip'
    extras.append(prior_zip)
    for path in extras:
        include(path, 'explicit-complete-admission-Source-review-provenance-or-prior-archive')
    catalog = dict(schema='Root-stratified-acquisition-full-evidence-catalog-v1',
        issued_utc=datetime.now(timezone.utc).isoformat(), case_id=CASE.name,
        Root_admission=pin(admission_path), complete_C_review=c_review,
        direct_user_archive_authorization=pin(authorization),
        members=[dict(member=name, role=row['role'], **row['ref']) for name,row in sorted(members.items())],
        external_runtime=external, prior_archive=pin(prior_zip), scientific_replay=False,
        scope='Every current38 guard except the separately supplied Python runtime, all52 original case/observer files, complete scientific admissions/reviews and explicit current/inherited Source packets. The unchanged prior complete archive contains earlier schema/library/donor/cohort evidence. Not a recursive closure of all historical citations or later publication receipts.')
    STAGE.mkdir()
    PAYLOAD.mkdir()
    archive_path = STAGE / NAMES[2]
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name,body in [('catalog.json',js(catalog))] + [(name,row['body']) for name,row in sorted(members.items())]:
            info=zipfile.ZipInfo(name,(2026,10,25,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16
            bundle.writestr(info,body,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(archive_path) as bundle:
        assert len(bundle.namelist()) == len(set(bundle.namelist())) == len(members)+1
        assert set(bundle.namelist()) == set(members)|{'catalog.json'}
        for name,row in members.items():
            assert bundle.read(name) == row['body']
    summaries=[]
    for index,family in enumerate(families):
        links=[x for x in coverage['selected_representatives'] if x['family_index']==index]
        metric=result['extraction_result']['candidates'][links[0]['candidate_index']]['metrics']
        summaries.append(dict(index=index, family_id=family['family_id'],
            parameters=family['parameters'], internal_nodes=len(family['internal_nodes']),
            boundary_count=len(family['boundary_nodes']), metrics=metric,
            source_occurrences=len(family['source_occurrences']),
            boundary_patterns=[x['formula_pattern'] for x in family['boundary_nodes']],
            conclusion_pattern=family['internal_nodes'][family['root_local_id']]['formula_pattern'],
            line_by_line=proof_rows(family)))
    summary=dict(schema='public-stratified-acquisition-summary-v1',
        status='FINITE_SEVEN_FAMILY_INVENTORY_ADMITTED',
        training_proofs=2,sampled_roots=16,prefix_attempts=81,eligible_inferences=52,
        full_key_groups=19,selected_keys=7,selected_source_occurrences=8,
        checked_source_instances=8,checked_generic_instances=7,new_control_groups=6,
        candidate_internal_sharing_nonzero=0,holdout_loaded=False,holdout_searched=False,
        contextual_transfer_demonstrated=False,GCTS_RL_advantage_demonstrated=False,
        metrics={k:audit[k] for k in ('observer_elapsed_seconds','observer_final_gate_seconds',
            'header_seconds','header_callbacks','conservative_whole_peak_bytes',
            'combined_positive_artifact_bytes','entire_result_bytes','shared_positive_bytes',
            'shared_cap_bytes','complete_physical_bytes')},
        families=summaries,evidence_archive=dict(name=NAMES[2],**{k:pin(archive_path)[k] for k in ('bytes','sha256')},entries=len(members)+1),
        scope='Automatically acquired ordinary propositional proof schemas from two previously found proofs, not new benchmark proofs or a fixed finite Wang palette. Full original and generic instances checked by original paired validators. Colors are reader annotations; no learned marking or trained RL.')
    overview=[]
    for f in summaries:
        inputs=r',\;'.join(formula(x) for x in f['boundary_patterns'])
        sequent=(inputs+r'\ \vdash '+formula(f['conclusion_pattern']))
        overview.append('<tr><td><a href="#stratified-family-'+str(f['index'])+'">'+math('S_{'+str(f['index'])+'}')+'</a></td><td>'+math(f['internal_nodes'])+'</td><td>'+math(f['boundary_count'])+'</td><td>'+math(sequent)+'</td></tr>')
    panels=[]
    for f,generic in zip(summaries,result['generic_exercise_results']):
        assert generic['family_index']==f['index']
        actual=[]
        for row in generic['instance']['expansion_rows']:
            actual.append('<li>'+math(formula(row['formula']))+'</li>')
        panels.append('<details class="panel" id="stratified-family-'+str(f['index'])+'"><summary>Family '+math('S_{'+str(f['index'])+'}')+' · '+('closed lemma' if f['boundary_count']==0 else 'conditional cluster')+'</summary><p>'+math(f['internal_nodes'])+' internal nodes; '+math(f['boundary_count'])+' boundary ports; '+math(len(f['parameters']))+' formula parameters. Parameters used only in intermediate axiom witnesses are retained.</p>'+table(f['line_by_line'])+'<details><summary>Actual independently checked predicate instance</summary><p>These formulas come directly from the saved paired-checker expansion rows. Each parameter maps to its own predicate in a fresh signature.</p><ol>'+''.join(actual)+'</ol></details></details>')
    identity=proof_rows(families[0]);tiles=[]
    for row in identity:
        tiles.append('<div class="symbol-tile '+row['role']+'"><span>Line '+math(row['line'])+' · '+row['rule']+'</span><div>'+math(r'\small '+formula(row['formula']))+'</div><small>'+('Inputs '+math(','.join(map(str,row['references']))) if row['references'] else 'Logical axiom instance')+'</small></div>')
    section=r'''<style>.inventory-overview{overflow-x:auto}.inventory-overview table{min-width:920px}.identity-strip{display:grid;grid-template-columns:repeat(5,minmax(190px,1fr));gap:10px;min-width:1020px}.identity-strip .symbol-tile{height:200px;aspect-ratio:auto;overflow:auto}.identity-strip .symbol-tile div{font-size:14px}.inventory-lead{border-top:6px solid var(--teal)}.inventory-visual{overflow-x:auto;padding:14px 0}.inventory-note{font-size:15px}</style>
<section class="panel inventory-lead" id="stratified-acquisition-current"><p class="status">Current result · complete finite inventory admitted · 25 October 2026 UTC</p>
<h1>Seven automatically acquired proof families</h1>
<p>A broader declared extraction policy sampled across the same two automatically found training proofs. It examined every reached prefix before selecting by size and boundary diversity. The whole run passed independent review: all six new test groups, all selected source occurrences and one independent-parameter instance per selected key were checked. No human supplied these schema targets or their proof trees to the acquisition worker.</p>
<div class="grid"><article class="card"><h3>Selected inventory</h3><span class="fact">\(7\)</span><p>Distinct parameterized proof families from \(52\) eligible prefixes and \(19\) complete structural-key groups.</p></article><article class="card"><h3>Checked instances</h3><span class="fact">\(8+7\)</span><p>Eight original source occurrences and seven generic instances, each checked by both original validators.</p></article><article class="card"><h3>Whole observer time</h3><span class="fact">\(54.970\,\mathrm{s}\)</span><p>Includes setup, tests, original validation, acquisition, all compilation/checking, output and custody.</p></article></div>
<p>The policy sampled \(16\) roots and attempted \(81\) prefixes; \(29\) exceeded the boundary-port limit. It selected internal sizes \(5,8,3,4,5,8,3\), with \(0,3,0,3,0,3,4\) boundary ports. This moves beyond the earlier two- and three-node inventory. Three selected schemas are closed lemmas; four require explicit boundary proofs.</p>
<div class="notice"><strong>The important limit:</strong> all \(52\) candidates have zero internal sharing by the declared distinct-consumer measure. Larger fragments were acquired, but shared or hierarchical cluster acquisition was not demonstrated. Useful contextual transfer, learned GCTS markings and RL benefit remain untested.</div>
<h2>The inventory, in formulas</h2><p>Each formula parameter can stand for a whole formula. A boundary premise is an obligation, not an automatically available fact. The eight-node entries include ordinary implication chains; size alone is not a search advantage.</p>
<div class="inventory-overview"><table><thead><tr><th>Family</th><th>Internal nodes</th><th>Boundary ports</th><th>Premises and conclusion</th></tr></thead><tbody>'''+''.join(overview)+r'''</tbody></table></div>
<h2>One discovered closed lemma, as fixed-orientation cells</h2><p>The first selected family proves reflexivity, \(\vdash A_0\to A_0\). The cells below are the actual saved symbolic row patterns, with their ordered inputs. Purple marks axiom instances and amber marks modus ponens. They are reader annotations, not learned markings or a compiled finite Wang palette.</p>
<div class="inventory-visual"><div class="identity-strip">'''+''.join(tiles)+r'''</div></div>
<h2>Inspect every line</h2><p>Open a family for its complete formula and English translation, then its actual checked predicate instance. Line references start at one. Teal rows are boundary premises whose proofs must be provided by a future contextual consumer.</p>'''+''.join(panels)+r'''
<h2>What this contributes</h2><p>Automatic acquisition now produces a more varied, parameterized inventory with exact primitive expansions and source maps. Schema inference and lemma reuse are established symbolic methods. This result does not show that GCTS or RL is doing the proof search, matching another prover, or surpassing one. No new arithmetic or Hilbert-geometry benchmark theorem was searched in this experiment.</p>
<p>The next test is contextual use: supply real proofs for boundary ports, expand only genuinely selected applications into the final proof, retain primitive fallback, and give the conventional lemma/CD control the same acquired information. The frozen evaluation target remains unopened and unsearched. No easier target or supplied intermediate lemma is introduced.</p>
<p>The conservative whole memory peak was \(408059904\,\mathrm{bytes}\). All positive artifacts plus the entire result used \(27500776\,\mathrm{bytes}\) of the unchanged \(50331648\,\mathrm{bytes}\) allowance. The complete case and observer contain \(52\) files totaling \(27507900\,\mathrm{bytes}\). Earlier training-proof acquisition and qualification costs are separate; this is not a speedup comparison.</p>
<p><a href="'''+NAMES[1]+r'''">Public formulas, rows and exact metrics</a> · <a href="'''+NAMES[2]+r'''">Full approved evidence archive</a> · <a href="point-proof-discovered-proofs-v1.html">Original training proofs</a></p>
<p class="caption">The full archive includes exact Source snapshots, original certificates, execution logs, complete scientific reviews and local provenance paths under direct user approval. It includes the unchanged prior archive; the pinned external Python runtime must be supplied separately. Historical milestone panels below retain their original dated status.</p></section>
<p class="notice"><strong>Earlier milestones below.</strong> Their old current-status and unrun labels describe earlier checkpoints. The admitted seven-family inventory above is the current result.</p>'''
    page=raw(PRIOR/NAMES[0]).decode()
    assert page.count('<body><main>')==1
    page=page.replace('<body><main>','<body><main>'+section,1)
    page=page.replace('<title>Reusable proof families: parallel research and policy review</title>','<title>Acquired proof families: seven checked schemas</title>',1)
    assert not any(ord(c)<32 and c not in '\n\t' for c in page)
    rows=[]
    for name,body in zip(NAMES,(page.encode(),js(summary),raw(archive_path))):
        if name!=NAMES[2]:write(STAGE/name,body)
        write(PAYLOAD/name,body)
        rows.append(dict(path=PREFIX+name,root_source=str(STAGE/name),publisher_source=str(PAYLOAD/name),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),git_blob_sha1=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()))
    staging=dict(schema='Root-stratified-acquisition-three-path-staging-v1',scientific_execution=False,admission=pin(admission_path),baseline=pin(PRIOR/NAMES[0]),direct_user_archive_authorization=pin(authorization),files=rows,archive_entries=len(members)+1,archive_members_verified=True,external_runtime=external,scope='Only exact report, new public summary and full approved task archive; no main checkout staging or unrelated publication.')
    write(STAGE/'P2-staging.json',js(staging))
    print(json.dumps(pin(STAGE/'P2-staging.json')))


if __name__=='__main__':
    main()
