"""Inert genuine-byte controls; no production data or private project hooks."""
import hashlib
import json
import math

VERSION = 'FPC-STRATIFIED-ACQUISITION-INDEPENDENT-BANK-v1'
SCHEMA = 'FPC-stratified-acquisition-independent-controls-v1'
POPULATION = 'stratified_acquisition6'
IDS = ('strata-and-full-prefix-scan', 'generic-key-and-representative', 'size-boundary-bin-selection', 'structural-sharing-and-support', 'wide-generic-carrier', 'first-fault-and-nonmutation')
ROLES = ('checker','builders','reference','instance','schema','extractor','wide_instance','wide_encoder')
SCOPE = 'Synthetic genuine-byte stratified acquisition and wide-carrier controls only; no production donor, library, holdout, contextual-use, GCTS or RL admission.'
BINS = ('LARGE_CLOSED','LARGE_OPEN','SMALL_CLOSED','SMALL_OPEN')
CONFIG = dict(schema='FPC-stratified-schematic-acquisition-v1',policy='quantile-MP-all-prefix-size-boundary-diversity-v1',roots_per_donor=8,min_nodes=2,max_nodes=8,max_distinct_boundary_nodes=4,per_donor_quota=4,library_quota=8)
WIDE = dict(symbols_per_sort=64,axioms=4,hypotheses=4,total_nodes=4096,depth=128,natural=65535,query_bytes=65536)
LIMITS = ['Finite authored synthetic DAGs only; no exhaustive connected-subgraph, semantic occurs-check or forced hash collision coverage.', 'Selected first-public-callback/schema/encoder faults only; no arbitrary late cutoff, native allocation or cleanup witness.', 'No production donor, contextual consumer, primitive fallback transaction or final-root-used proof is exercised.']
COST_FIELDS = ('successful_callbacks','copy_visits','comparison_visits','fresh_metavariables','unification_pairs','dereference_steps','occurs_visits','resolved_term_visits','normalization_visits','specialization_pairs','equation_checks','source_backprojection_checks','public_input_guard_calls','public_output_guard_calls','canonical_bytes')


class StratifiedControlError(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise StratifiedControlError(message)


class _Call:
    def __init__(self, check):
        _need(callable(check), 'callable check')
        self.check,self.first = check,None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first=error
            raise


def _same(a,b,c):
    c.tick()
    if type(a) is not type(b): return False
    if type(b) is dict: return set(a)==set(b) and all(_same(a[k],v,c) for k,v in b.items())
    if type(b) in (list,tuple): return len(a)==len(b) and all(_same(x,y,c) for x,y in zip(a,b))
    return a==b


def _plain(x,c,active=None):
    c.tick()
    if type(x) is bytes:
        return dict(schema='L-immutable-bytes-hex-v1',bytes=len(x),sha256=hashlib.sha256(x).hexdigest(),hex=x.hex())
    if x is None or type(x) in (str,bool,int): return x
    if type(x) is float:
        _need(math.isfinite(x),'finite diagnostics');return x
    _need(type(x) in (dict,list,tuple),'ordinary carrier')
    active=set() if active is None else active
    _need(id(x) not in active,'acyclic carrier');active.add(id(x))
    if type(x) is dict:
        _need(all(type(k) is str for k in x),'string keys')
        out={k:_plain(v,c,active) for k,v in x.items()}
    else: out=[_plain(v,c,active) for v in x]
    active.remove(id(x));return out


def _i(a,b): return ['imp',a,b]
def _p(j): return ['pred',j,[]]
def _v(j): return ['param',j]


def _logical(tag,w):
    a,b=w[:2]
    if tag==0:return _i(a,_i(b,a))
    if tag==1:
        z=w[2];return _i(_i(a,_i(b,z)),_i(_i(a,b),_i(a,z)))
    _need(tag==2,'logical subtag');return _i(_i(['not',b],['not',a]),_i(a,b))


def _axiom(w,tag=0):
    return dict(formula=_logical(tag,w),rule_tag=1,subtag=tag,witness=w,references=[])


def _mp(a,b,f):
    return dict(formula=f,rule_tag=3,subtag=None,witness=[a,b],references=[a,b])


def _rows(case,donor):
    a,b=_p(2*donor),_p(2*donor+1);f=_i(a,_i(b,a))
    out=[_axiom([a,b])]
    if case=='zero': return out
    if case=='unsupported':
        u=['all',0,f]
        return out+[dict(formula=u,rule_tag=4,subtag=None,witness=[0,0],references=[0]),_axiom([u,u]),_mp(1,2,_i(u,u)),_mp(1,3,u)]
    out.append(_axiom([f,f]));previous=0
    for unused in range(1 if case=='one' else 10):
        out.append(_mp(previous,1,_i(f,f)))
        if case=='one':break
        out.append(_mp(previous,len(out)-1,f));previous=len(out)-1
    return out


def _nat(n,b,c):
    c.tick();_need(type(n) is int and 0<=n<=65535,'wire natural')
    while n>=128:
        c.tick();b.append((n&127)|128);n>>=7
    b.append(n)


def _formula(f,b,c):
    c.tick();tag=f[0]
    _nat({'pred':0,'not':2,'imp':3,'all':4}[tag],b,c)
    if tag=='pred':_nat(f[1],b,c);_nat(0,b,c)
    elif tag=='not':_formula(f[1],b,c)
    elif tag=='imp':_formula(f[1],b,c);_formula(f[2],b,c)
    else:_nat(f[1],b,c);_formula(f[2],b,c)


def _certificate(rows,c):
    out=bytearray(b'FPP1');_nat(len(rows),out,c)
    for row in rows:
        c.tick();_formula(row['formula'],out,c);_nat(row['rule_tag'],out,c)
        if row['rule_tag']==1:
            _nat(row['subtag'],out,c)
            for f in row['witness']:_formula(f,out,c)
        else:
            for n in row['witness']:_nat(n,out,c)
    return bytes(out)


def _query(goal,count):
    return dict(version=1,claim_mode=0,function_arities=[],predicate_arities=[0]*count,theory_profile=0,finite_axioms=[],Gamma=[],goal=goal)


def _encoded(m,q,c):
    before=_plain(q,c);z=m['wide_encoder'].encode_tiny_declared_query(q,check=c.tick)
    _need(set(z)=={'query_bytes','receipt'} and type(z['query_bytes']) is bytes,'encoder full return')
    r=z['receipt'];_need(set(r)=={'schema','version','complete','semantic_query','query_identity','limits','expanded_nodes','scope'},'encoder receipt8')
    _need(r['schema']=='independent-wide-FPC-query-encoding-v1' and r['version']=='L-wide-FPC-query-encoder-v1' and r['complete'] is True,'wide encoder identity')
    _need(_same(r['limits'],WIDE,c) and _same(r['semantic_query'],q,c) and _same(before,_plain(q,c),c),'encoder scope/nonmutation')
    _need(r['query_identity']==dict(bytes=len(z['query_bytes']),sha256=hashlib.sha256(z['query_bytes']).hexdigest()),'encoded identity')
    return z


def _donors(case,m,c):
    result=[];graphs=[];encodings=[];empty=dict(path='/synthetic-control-only/no-file',bytes=0,sha256='0'*64)
    for d in range(2):
        rows=_rows(case,d);encoded=_encoded(m,_query(rows[-1]['formula'],4),c);encodings.append(encoded);q=encoded['query_bytes'];p=_certificate(rows,c)
        provenance=dict(schema='FPC-receptor-donor-provenance-v1',Root_admission=dict(empty),C_actual_review=dict(empty),query=dict(bytes=len(q),sha256=hashlib.sha256(q).hexdigest()),certificate=dict(bytes=len(p),sha256=hashlib.sha256(p).hexdigest()),module_pins={k:dict(empty) for k in ('checker','builders','reference')})
        result.append(dict(donor_id='synthetic'+str(d),query_bytes=q,certificate_bytes=p,provenance=provenance));graphs.append(rows)
    return result,graphs,encodings


def _extract(m,donors,c,schema=None,check=None,configuration=None):
    cfg=dict(CONFIG) if configuration is None else configuration;before=_plain(cfg,c)
    result=m['extractor'].extract_schematic_families(donors,modules={k:m[k] for k in ('checker','builders','reference')},schema=m['schema'] if schema is None else schema,instance=m['instance'],configuration=cfg,check=c.tick if check is None else check)
    _need(_same(before,_plain(cfg,c),c),'configuration nonmutation');return result


def _prop(f):
    if f[0]=='pred':return f[2]==[]
    return f[0] in ('imp','not') and all(_prop(x) for x in f[1:])


def _prefixes(rows,c):
    mp=[i for i,r in enumerate(rows) if r['rule_tag']==3];s=min(8,len(mp))
    ords=[] if not s else [0] if s==1 else [j*(len(mp)-1)//(s-1) for j in range(s)]
    samples=[dict(sample_index=j,mp_ordinal=o,root_source_row=mp[o]) for j,o in enumerate(ords)];out=[]
    for o in ords:
        root=mp[o];chosen={root}
        while len(chosen)<8:
            c.tick();boundary={p for i in chosen for p in rows[i]['references']}-chosen
            if not boundary:break
            chosen.add(min(boundary));boundary={p for i in chosen for p in rows[i]['references']}-chosen
            why='BOUNDARY_LIMIT' if len(boundary)>4 else 'UNSUPPORTED_INTERNAL' if any(rows[i]['rule_tag'] not in (1,3) or not _prop(rows[i]['formula']) for i in chosen) else 'ELIGIBLE'
            out.append(dict(sample_ordinal=o,root_source_row=root,prefix_size=len(chosen),prefix_source_rows=sorted(chosen),eligibility=why,boundary=sorted(boundary)))
    return mp,samples,out


def _subst(f,images,c):
    c.tick()
    if f[0]=='param':return images[f[1]]
    return [f[0]]+[_subst(x,images,c) for x in f[1:]]


def _key(f,c):
    c.tick();key={k:f[k] for k in ('parameters','root_local_id','internal_nodes','boundary_nodes')}
    _need(_same(f['family_key'],key,c),'complete key')
    text=json.dumps(key,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
    _need(f['family_id']==hashlib.sha256(text.encode('ascii')).hexdigest(),'display digest')
    return key,text


def _inference(z,attempt,rows,c):
    _need(set(z)=={'schema','version','complete','accepted','library_admitted','method','source_family','family','specialization','source_associations','input_guards','output_guards','costs','scope'},'all14 inference fields')
    _need(z['complete'] is True and z['accepted'] is False and z['library_admitted'] is False,'inference flags')
    old,new=z['source_family'],z['family'];indices=attempt['prefix_source_rows'];boundary=attempt['boundary']
    _key(old,c);_key(new,c)
    for f in (old,new):
        _need(set(f)=={'family_key','family_id','parameters','root_local_id','internal_nodes','boundary_nodes','source_occurrences','distinct_base_nodes','size_band','validation_provenance'},'family10')
        _need(len(f['internal_nodes'])==len(indices) and len(f['boundary_nodes'])==len(boundary) and f['root_local_id']==len(indices)-1 and f['distinct_base_nodes']==len(indices),'complete physical graph')
        _need(f['parameters']==[dict(id=i,sort='Formula') for i in range(len(f['parameters']))],'canonical parameter records')
    for k in ('root_local_id','distinct_base_nodes','size_band','validation_provenance'):_need(_same(old[k],new[k],c),'preserved family metadata')
    _need(len(old['source_occurrences'])==len(new['source_occurrences'])==1,'one prefix occurrence')
    src=old['source_occurrences'][0];dst=new['source_occurrences'][0]
    _need(src['source_to_local']==[[r,j] for j,r in enumerate(indices)] and src['boundary_source_to_port']==[[r,j] for j,r in enumerate(boundary)],'literal source maps')
    _need(src['root_source_row']==attempt['root_source_row'] and [b['parameter_id'] for b in src['source_bindings']]==list(range(len(old['parameters']))) and all(b['formula'][0]=='pred' and b['formula'][2]==[] for b in src['source_bindings']),'source root and complete atom binding')
    images=[b['formula'] for b in src['source_bindings']];special=[b['source_pattern'] for b in z['specialization']]
    _need([p['parameter_id'] for p in z['specialization']]==list(range(len(new['parameters']))),'complete specialization')
    _need(dst['source_bindings']==[dict(parameter_id=j,formula=_subst(p,images,c)) for j,p in enumerate(special)],'composed source binding')
    for field in ('donor_id','root_source_row','source_to_local','boundary_source_to_port'):_need(dst[field]==src[field],'preserved occurrence')
    for port,r in zip(old['boundary_nodes'],boundary):_need(_subst(port['formula_pattern'],images,c)==rows[r]['formula'],'original boundary')
    for j,(a,b) in enumerate(zip(old['internal_nodes'],new['internal_nodes'])):
        c.tick();r=rows[indices[j]]
        _need(a['local_id']==b['local_id']==j and a['rule_tag']==b['rule_tag']==r['rule_tag'] and a['subtag']==b['subtag']==r['subtag'],'node identity/rule')
        _need(_subst(a['formula_pattern'],images,c)==r['formula'] and _subst(b['formula_pattern'],special,c)==a['formula_pattern'],'all formula backprojections')
        _need(a['references']==b['references'],'ordered references')
        mapped=[indices[x['id']] if x['kind']=='internal' else boundary[x['id']] for x in a['references']]
        _need(mapped==r['references'],'source reference order')
        if b['rule_tag']==1:
            _need(b['formula_pattern']==_logical(b['subtag'],b['witness_pattern']),'generic logical equation')
            _need([_subst(x,special,c) for x in b['witness_pattern']]==a['witness_pattern'] and [_subst(x,images,c) for x in a['witness_pattern']]==r['witness'],'all logical witnesses')
        else:
            args=[new['internal_nodes'][x['id']]['formula_pattern'] if x['kind']=='internal' else new['boundary_nodes'][x['id']]['formula_pattern'] for x in b['references']]
            _need(args[1]==_i(args[0],b['formula_pattern']),'ordered generic MP')
    for j,(a,b) in enumerate(zip(old['boundary_nodes'],new['boundary_nodes'])):
        _need(a['boundary_id']==b['boundary_id']==j and _subst(b['formula_pattern'],special,c)==a['formula_pattern'],'boundary specialization')
    _need(len(z['input_guards'])==len(z['output_guards'])==len(z['source_associations'])==1,'all guard/association returns')
    assoc=z['source_associations'][0]
    _need(set(assoc)=={'occurrence_index','donor_id','root_source_row','source_to_local','boundary_source_to_port','original_source_bindings','generalized_source_bindings','boundary_checks','internal_checks'},'association9')
    _need(assoc['occurrence_index']==0 and assoc['original_source_bindings']==src['source_bindings'] and assoc['generalized_source_bindings']==dst['source_bindings'],'association bindings')
    for k in ('donor_id','root_source_row','source_to_local','boundary_source_to_port'):_need(assoc[k]==src[k],'association physical identity')
    _need(assoc['boundary_checks']==[dict(boundary_id=j,source_row=r,formula_equal=True) for j,r in enumerate(boundary)],'all boundary joins')
    checks=[]
    for j,r in enumerate(indices):
        refs=[dict(position=k,kind=ref['kind'],id=ref['id'],source_row=rows[r]['references'][k]) for k,ref in enumerate(new['internal_nodes'][j]['references'])]
        checks.append(dict(local_id=j,source_row=r,formula_equal=True,witness_equal=True,reference_checks=refs))
    _need(_same(assoc['internal_checks'],checks,c),'all ordered source reference joins')
    for g,f,occ in zip(z['input_guards']+z['output_guards'],(old,new),(src,dst)):
        _need(set(g)=={'occurrence_index','match_result'} and g['occurrence_index']==0,'guard order')
        result=g['match_result'];used=_parameter_ids(f['internal_nodes'][f['root_local_id']]['formula_pattern'])
        for port in f['boundary_nodes']:used|=_parameter_ids(port['formula_pattern'])
        expected=dict(matched=True,bindings=[b for b in occ['source_bindings'] if b['parameter_id'] in used],residual_parameters=[p for p in f['parameters'] if p['id'] not in used])
        _need(_same(result,expected,c),'full genuine matcher return')
    _need(set(z['costs'])==set(COST_FIELDS) and all(type(v) is int and v>=0 for v in z['costs'].values()),'complete normal cost scalars')
    return new


def _nodes(f):return 1+sum(_nodes(x) for x in f[1:]) if f[0]!='param' else 1
def _inside(root,f):return root==f or f[0]!='param' and any(_inside(root,x) for x in f[1:])
def _parameter_ids(f):return {f[1]} if f[0]=='param' else set().union(*(_parameter_ids(x) for x in f[1:]))


def _metrics(f):
    uses=[set() for n in f['internal_nodes']]
    for n in f['internal_nodes']:
        for ref in n['references']:
            if ref['kind']=='internal':uses[ref['id']].add(n['local_id'])
    root=f['internal_nodes'][f['root_local_id']]['formula_pattern']
    return dict(internal_nodes=len(uses),MP_nodes=sum(n['rule_tag']==3 for n in f['internal_nodes']),sharing_excess=sum(max(0,len(x)-1) for x in uses),boundary_count=len(f['boundary_nodes']),root_pattern_nodes=_nodes(root),root_in_boundary=any(_inside(root,b['formula_pattern']) for b in f['boundary_nodes']))


def _bin(metric):
    return ('LARGE' if metric['internal_nodes']>=5 else 'SMALL')+('_CLOSED' if not metric['boundary_count'] else '_OPEN')


def _audit_result(z,donors,graphs,c):
    _need(set(z)=={'schema','status','complete','accepted','donor_validation','candidates','families','selection_coverage'},'complete extractor8')
    _need(z['schema']=='FPC-stratified-schematic-receptor-library-candidate-v1' and z['complete'] is True and z['accepted'] is False,'extractor identity')
    cv=z['selection_coverage'];_need(set(cv)=={'configuration','exhaustive_connected_subgraphs','donors','groups','selected_representatives','selected_occurrences','distinct_keys','represented_donors','library_gate','source_occurrence_instance_gate','sharing_or_multiscale_coverage_claim'},'coverage11')
    _need(cv['configuration']==CONFIG and cv['exhaustive_connected_subgraphs'] is False and cv['sharing_or_multiscale_coverage_claim'] is False and cv['source_occurrence_instance_gate']=='NOT_RUN_EXTERNAL_INSTANCE_CALLER_REQUIRED','coverage scope')
    _need(len(z['donor_validation'])==len(cv['donors'])==2,'both donor views')
    ci=0;expected_groups=[];metrics=[]
    for d,rows in enumerate(graphs):
        v=z['donor_validation'][d];dc=cv['donors'][d];mp,samples,attempts=_prefixes(rows,c)
        _need(set(v)=={'validation_index','donor_id','query_identity','certificate_identity','provenance','subject_receipt','reference_receipt'},'donor validation7')
        _need(set(dc)=={'donor_id','donor_validation_index','reachable_row_count','reachable_MP_rows','samples','prefix_attempts','bin_selection','fill_selection','selected_group_indices','selected_candidate_indices'},'donor coverage10')
        _need(_same(v['provenance'],donors[d]['provenance'],c),'complete control-only provenance')
        _need(v['donor_id']==dc['donor_id']==donors[d]['donor_id'] and v['validation_index']==dc['donor_validation_index']==d,'donor order')
        _need(v['query_identity']==donors[d]['provenance']['query'] and v['certificate_identity']==donors[d]['provenance']['certificate'],'original bytes identities')
        _need(v['subject_receipt']['accepted'] is True and v['reference_receipt']['complete_check'] is True,'genuine paired donor views')
        _need(dc['reachable_row_count']==len(rows) and dc['reachable_MP_rows']==mp and dc['samples']==samples,'literal reachable/sample set')
        _need(len(dc['prefix_attempts'])==len(attempts),'all prefixes despite quota/refusal')
        for a,given in zip(attempts,dc['prefix_attempts']):
            wanted={k:v for k,v in a.items() if k!='boundary'};wanted['candidate_index']=ci if a['eligibility']=='ELIGIBLE' else None
            _need(_same(given,wanted,c),'complete ordered attempt')
            if a['eligibility']!='ELIGIBLE':continue
            x=z['candidates'][ci]
            _need(set(x)=={'candidate_index','donor_validation_index','sample_ordinal','root_source_row','prefix_size','prefix_source_rows','inference','metrics'},'candidate8')
            _need(x['candidate_index']==ci and x['donor_validation_index']==d and all(x[k]==a[k] for k in ('sample_ordinal','root_source_row','prefix_size','prefix_source_rows')),'candidate order')
            f=_inference(x['inference'],a,rows,c);key,text=_key(f,c);met=_metrics(f);metrics.append(met)
            found=next((g for g in expected_groups if _same(g['key'],key,c)),None)
            if found is None:
                found=dict(key=key,text=text,members=[],support=[],representatives={});expected_groups.append(found)
            found['members'].append(ci);pair=[d,a['root_source_row']]
            if pair not in found['support']:found['support'].append(pair)
            source=[a['root_source_row'],a['prefix_source_rows'],a['boundary'],ci]
            if d not in found['representatives'] or source<found['representatives'][d]['source_tuple']:
                found['representatives'][d]=dict(donor_validation_index=d,candidate_index=ci,source_tuple=source,bin=_bin(met))
            ci+=1
    _need(ci==len(z['candidates']) and len(expected_groups)==len(cv['groups']),'no omitted/duplicate candidate/group')
    for gi,(g,given) in enumerate(zip(expected_groups,cv['groups'])):
        _need(set(given)=={'group_index','family_key','family_id','candidate_indices','support','root_support','representatives','selected_donors'},'group8')
        _need(given['family_id']==hashlib.sha256(g['text'].encode('ascii')).hexdigest(),'group display label')
        for index in g['members']:
            metrics[index]['root_support']=len(g['support']);_need(_same(z['candidates'][index]['metrics'],metrics[index],c),'independent metrics/support')
        for d,rep in g['representatives'].items():
            m=metrics[rep['candidate_index']];rep['rank']=[-m['sharing_excess'],-m['MP_nodes'],-m['internal_nodes'],-len(g['support']),m['boundary_count'],m['root_pattern_nodes'],g['text'],rep['source_tuple']]
        _need(given['group_index']==gi and _same(given['family_key'],g['key'],c) and given['candidate_indices']==g['members'] and given['support']==g['support'] and given['root_support']==len(g['support']),'full-key group ledger')
        _need(_same(given['representatives'],list(g['representatives'].values()),c),'least source representatives/rank')
    selections=[]
    for d in range(2):
        dc=cv['donors'][d];chosen=[];bin_records=[]
        for name in BINS:
            eligible=[i for i,g in enumerate(expected_groups) if d in g['representatives'] and g['representatives'][d]['bin']==name]
            ranked=sorted(eligible,key=lambda i:expected_groups[i]['representatives'][d]['rank'])
            pick=ranked[0] if ranked else None
            bin_records.append(dict(bin=name,ranked_group_indices=ranked,chosen_group_index=pick))
            if pick is not None:chosen.append(pick)
        remaining=sorted([i for i,g in enumerate(expected_groups) if d in g['representatives'] and i not in chosen],key=lambda i:expected_groups[i]['representatives'][d]['rank'])
        fill=remaining[:4-len(chosen)];chosen+=fill
        _need(_same(dc['bin_selection'],bin_records,c) and _same(dc['fill_selection'],dict(ranked_group_indices=remaining,chosen_group_indices=fill),c),'bin/fill order')
        indices=[expected_groups[i]['representatives'][d]['candidate_index'] for i in chosen]
        _need(dc['selected_group_indices']==chosen and dc['selected_candidate_indices']==indices,'donor selected links')
        selections.extend((d,g,index) for g,index in zip(chosen,indices))
    order=[];occurrences={};links=[]
    for d,g,index in selections:
        if g not in order:order.append(g);occurrences[g]=[]
        f=z['candidates'][index]['inference']['family'];oi=len(occurrences[g]);occurrences[g].append(f['source_occurrences'][0])
        links.append(dict(family_index=order.index(g),group_index=g,donor_validation_index=d,candidate_index=index,source_occurrence_index=oi))
    _need(len(z['families'])==len(order) and _same(cv['selected_representatives'],links,c),'every selected occurrence stored')
    for f,g in zip(z['families'],order):
        _need(_same(f['family_key'],expected_groups[g]['key'],c) and _same(f['source_occurrences'],occurrences[g],c),'selected full family')
        ds=sorted(d for d,gi,index in selections if gi==g)
        _need(f['validation_provenance']==ds and cv['groups'][g]['selected_donors']==ds,'selected provenance')
        _key(f,c)
    for gi,g in enumerate(cv['groups']):_need(g['selected_donors']==sorted(d for d,gid,index in selections if gid==gi),'all selected/unselected donor labels')
    represented=[donors[d]['donor_id'] for d in range(2) if any(x[0]==d for x in selections)]
    gate=len(order)>=2 and len(represented)==2
    _need(cv['selected_occurrences']==len(links) and cv['distinct_keys']==len(order) and cv['represented_donors']==represented and cv['library_gate'] is gate,'final counts/gate')
    _need(z['status']==('LIBRARY_CANDIDATE' if gate else 'NO_USABLE_LIBRARY'),'normal status')
    return dict(prefixes=sum(len(d['prefix_attempts']) for d in cv['donors']),inferences=ci,groups=len(expected_groups),selected_keys=len(order),selected_occurrences=len(links),metrics=metrics)


def _wide_family(c):
    a,b,z,d,e=(_v(i) for i in range(5));h=_logical(1,[a,b,z])
    def ln(i,tag,w):return dict(local_id=i,rule_tag=1,subtag=tag,formula_pattern=_logical(tag,w),witness_pattern=w,references=[])
    def mp(i,f,x,y):return dict(local_id=i,rule_tag=3,subtag=None,formula_pattern=f,witness_pattern=None,references=[dict(kind='internal',id=x),dict(kind='internal',id=y)])
    nodes=[ln(0,1,[a,b,z]),ln(1,0,[h,d]),mp(2,_i(d,h),0,1),ln(3,0,[_i(d,h),e]),mp(4,_i(e,_i(d,h)),2,3)]
    key=dict(parameters=[dict(id=i,sort='Formula') for i in range(5)],root_local_id=4,internal_nodes=nodes,boundary_nodes=[])
    text=json.dumps(key,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
    occurrence=dict(donor_id='synthetic-wide5',root_source_row=4,source_to_local=[[i,i] for i in range(5)],boundary_source_to_port=[],source_bindings=[dict(parameter_id=i,formula=_p(i)) for i in range(5)])
    return dict(family_key=_plain(key,c),family_id=hashlib.sha256(text.encode('ascii')).hexdigest(),**key,source_occurrences=[occurrence],distinct_base_nodes=5,size_band='LARGE_5_8',validation_provenance=[0])


def _flat(f,c):
    c.tick();tag=f[0]
    if tag=='pred':return [['pred',f[1],0]]
    out=[[tag,f[1]]] if tag=='all' else [[tag]]
    for child in f[2:] if tag=='all' else f[1:]:out+=_flat(child,c)
    return out


def _tree_size(f):
    if f[0]=='pred':return 1,1
    parts=[_tree_size(x) for x in f[2:] if f[0]=='all'] if f[0]=='all' else [_tree_size(x) for x in f[1:]]
    return 1+sum(x[0] for x in parts),1+max(x[1] for x in parts)


def _wide_audit(z,f,bindings,context,expected_query,m,c):
    _need(set(z)=={'schema','complete','accepted','context_query_identity','binding','expansion_rows','family_to_wire_rows','boundary_query_bytes','boundary_certificate_bytes','subject_receipt','reference_receipt'},'wide instance11')
    _need(z['schema']=='FPC-receptor-instance-candidate-v1' and z['complete'] is True and z['accepted'] is False,'wide candidate flags')
    _need(z['binding']==bindings and z['context_query_identity']['query_hex']==context.hex() and z['context_query_identity']['bytes']==len(context) and z['context_query_identity']['sha256']==hashlib.sha256(context).hexdigest(),'context/binding identity')
    identity=z['context_query_identity'];context_fields=_query(_p(63),64)
    _need(set(identity)==set(context_fields)|{'query_hex','bytes','sha256'} and all(_same(identity[k],v,c) for k,v in context_fields.items()),'all eleven context identity fields')
    expected=_encoded(m,expected_query,c)
    _need(z['boundary_query_bytes']==expected['query_bytes'] and expected['receipt']['expanded_nodes']==297 and _tree_size(expected_query['goal'])==(297,46),'wide exact query/size/depth')
    _need(type(z['boundary_certificate_bytes']) is bytes,'immutable original certificate')
    _need(z['family_to_wire_rows']==dict(boundary_to_wire=[],internal_to_wire=[[i,i] for i in range(5)]),'all physical maps')
    subject,reference=z['subject_receipt'],z['reference_receipt']
    _need(subject['accepted'] is True and reference['complete_check'] is True and reference['status']=='VALID_DERIVATION','real full dual validation')
    sr,rr=subject['certificate']['rows'],reference['rows'];_need(len(sr)==len(rr)==len(z['expansion_rows'])==5,'five physical rows')
    images=[b['formula'] for b in bindings];previous=None
    for i,(node,row,s,r) in enumerate(zip(f['internal_nodes'],z['expansion_rows'],sr,rr)):
        c.tick();refs=[x['id'] for x in node['references']]
        witnesses=[_subst(x,images,c) for x in node['witness_pattern']] if node['rule_tag']==1 else refs
        formula=_subst(node['formula_pattern'],images,c)
        wanted=dict(wire_index=i,origin_kind='internal',origin_id=i,formula=formula,rule_tag=node['rule_tag'],subtag=node['subtag'],witness=witnesses,references=refs)
        _need(_same(row,wanted,c),'each immutable physical identity/formula/witness/reference')
        _need(s['index']==r['index']==i and s['rule_tag']==r['rule_tag']==row['rule_tag'] and s['subtag']==r['witness_tag']==row['subtag'],'paired row index/rule')
        _need(_same(s['formula'],formula,c) and _same(s['witness'],witnesses,c),'emitted/subject exact fields')
        _need(r['formula']['prefix_tokens']==_flat(formula,c) and s['span']==r['byte_span'],'paired flat formula/span')
        if previous is not None:_need(previous==r['byte_span'][0],'physical span continuity')
        previous=r['byte_span'][1]
        if row['rule_tag']==1:
            _need(len(r['payload'])==len(witnesses),'complete ordered flat payload')
            for flat,w in zip(r['payload'],witnesses):_need(flat['prefix_tokens']==_flat(w,c),'all ordered independent witness occurrences')
        else:_need(r['payload']==refs,'independent MP order')
    _need(previous==len(z['boundary_certificate_bytes']),'physical certificate EOF')
    return expected


class _Probe:
    def __init__(self,c,error):self.c,self.error,self.raised,self.after,self.hits=c,error,False,0,0
    def check(self):
        if self.raised:self.after+=1;raise self.error
        self.c.tick()
    def boom(self,*args,**kwargs):
        self.check();self.hits+=1;self.raised=True;raise self.error


class _FaultNamespace:
    def __init__(self,version,endpoint,probe):self.VERSION,self.endpoint,self.probe=version,endpoint,probe
    def __getattr__(self,name):
        if name==self.endpoint:return self.probe.boom
        raise AttributeError(name)


def _expect_fault(action,probe,c,label):
    try:action()
    except BaseException as error:
        if c.first is not None:raise c.first
        if error is not probe.error:raise
        _need(probe.hits==1 and probe.after==0,'first identical fault/no later selected callback '+label)
        return dict(locator=label,error_class=type(error).__name__,same_object=True,selected_fault_hits=probe.hits,later_selected_checks=probe.after)
    raise StratifiedControlError('missing selected fault '+label)


def run_bank(modules,*,check):
    c=_Call(check);c.tick();_need(type(modules) is dict and set(modules)==set(ROLES),'exact eight genuine namespaces')
    m=modules
    for role,version in dict(extractor='FPC-STRATIFIED-RECEPTOR-SCHEMA-EXTRACTOR-v1',schema='FPC-RECEPTOR-SKELETON-SCHEMA-v1',instance='FPC-RECEPTOR-INSTANCE-SERVICE-v2',wide_instance='FPC-RECEPTOR-WIDE-INSTANCE-SERVICE-v1',wide_encoder='L-wide-FPC-query-encoder-v1').items():
        _need(getattr(m[role],'VERSION',None)==version,'public dependency '+role)
    controls=[];cases=[];main=None;main_inputs=None;main_before=None
    for name in ('zero','one','main','unsupported'):
        c.tick();donors,graphs,encodings=_donors(name,m,c);before=_plain(donors,c)
        result=_extract(m,donors,c);_need(_same(before,_plain(donors,c),c),'complete input/provenance nonmutation')
        summary=_audit_result(result,donors,graphs,c)
        if name=='zero':_need(summary['prefixes']==summary['inferences']==0,'zero MP path')
        if name=='one':_need(summary['prefixes']==summary['inferences']==4,'one MP complete two-prefix pairs')
        if name=='unsupported':_need(summary['prefixes']==14 and summary['inferences']==0,'complete unsupported roots')
        if name=='main':
            _need(summary['prefixes']==96 and summary['inferences']==62 and summary['selected_keys']==4 and summary['selected_occurrences']==8,'manual main census')
            for dc in result['selection_coverage']['donors']:
                _need([s['mp_ordinal'] for s in dc['samples']]==[0,2,5,8,10,13,16,19] and [s['root_source_row'] for s in dc['samples']]==[2,4,7,10,12,15,18,21],'literal twenty-MP quantiles')
                recovery=[x for x in dc['prefix_attempts'] if x['root_source_row']==10 and x['prefix_size'] in (6,7,8)]
                _need([x['eligibility'] for x in recovery]==['BOUNDARY_LIMIT','ELIGIBLE','ELIGIBLE'],'post-boundary refusal recovery')
            main,main_inputs,main_before=result,donors,before
        cases.append(dict(case=name,donors=_plain(donors,c),complete_query_encodings=_plain(encodings,c),complete_result=_plain(result,c),summary=_plain(summary,c)))
    controls.append(dict(id=IDS[0],passed=True,observations=cases,coverage_limits=[LIMITS[0]]))
    cv=main['selection_coverage']
    controls.append(dict(id=IDS[1],passed=True,observations=dict(complete_result_pointer='/controls/0/observations/2/complete_result',full_groups=cv['groups'],all_candidates_accounted=True,representatives_recomputed=True),coverage_limits=['Digest collisions are not forced; full structural key comparison remains independently audited and Source-reviewed.']))
    for dc in cv['donors']:_need(all(b['chosen_group_index'] is not None for b in dc['bin_selection']),'all four literal bins populated')
    controls.append(dict(id=IDS[2],passed=True,observations=dict(complete_result_pointer='/controls/0/observations/2/complete_result',per_donor_selections=[dict(donor_id=d['donor_id'],bin_selection=d['bin_selection'],fill_selection=d['fill_selection']) for d in cv['donors']],rank_recomputed=True),coverage_limits=['Finite four-bin instance only; no selection-usefulness or transfer conclusion.']))
    sharing=[]
    for x in main['candidates']:
        if x['donor_validation_index']==0 and (x['root_source_row'],x['prefix_size']) in ((2,3),(4,5)):
            expected=0 if x['root_source_row']==2 else 2
            _need(x['metrics']['sharing_excess']==expected and x['metrics']['boundary_count']==0,'literal physical sharing')
            sharing.append(dict(candidate_index=x['candidate_index'],root=x['root_source_row'],sharing_excess=expected))
    _need(len(sharing)==2,'both physical sharing controls')
    controls.append(dict(id=IDS[3],passed=True,observations=dict(literal_sharing=sharing,all_candidate_metrics_recomputed=True,unique_root_support_recomputed=True),coverage_limits=['Repeated formulas and boundary ports do not establish internal sharing.']))
    family=_wide_family(c);saved_family=_plain(family,c);context_encoding=_encoded(m,_query(_p(63),64),c);context=context_encoding['query_bytes']
    images=[_p(i) for i in range(5)]
    for i in range(3):
        for unused in range(40):c.tick();images[i]=['not',images[i]]
    bindings=[dict(parameter_id=i,formula=f) for i,f in enumerate(images)];saved_bindings=_plain(bindings,c)
    goal=_i(images[4],_i(images[3],_logical(1,images[:3])));q=_query(goal,64);q['claim_mode']=1
    normal=m['wide_instance'].compile_instance(context,family,bindings,encoder=m['wide_encoder'].encode_tiny_declared_query,modules={k:m[k] for k in ('checker','builders','reference')},check=c.tick)
    expected=_wide_audit(normal,family,bindings,context,q,m,c)
    _need(_same(saved_family,_plain(family,c),c) and _same(saved_bindings,_plain(bindings,c),c),'wide family/binding nonmutation')
    matched=m['instance'].match_receptor(family,input_formulas=[],output_formula=goal,check=c.tick)
    _need(_same(matched,dict(matched=True,bindings=bindings,residual_parameters=[]),c),'original instance remains genuine matcher')
    try:m['wide_encoder'].encode_tiny_declared_query(_query(_p(0),65),check=c.tick)
    except BaseException as error:
        if c.first is not None:raise c.first
        if not m['wide_encoder'].is_owned_error(error):raise
        bound_error=dict(error_class=type(error).__name__,owned_normal_refusal=True)
    else:raise StratifiedControlError('missing wide symbol bound')
    controls.append(dict(id=IDS[4],passed=True,observations=dict(family=saved_family,complete_context_encoding=_plain(context_encoding,c),binding=_plain(bindings,c),complete_instance=_plain(normal,c),complete_expected_encoding=_plain(expected,c),original_match_result=_plain(matched,c),symbol65_refusal=bound_error,expanded_goal_nodes=297,goal_depth=46),coverage_limits=['No maximum4096-node/128-depth saturation or native-allocation fault is exercised.']))
    faults=[]
    try:_extract(m,main_inputs,c,configuration={})
    except BaseException as error:
        if c.first is not None:raise c.first
        if not m['extractor'].is_owned_error(error):raise
        retained=error
    else:raise StratifiedControlError('missing configuration refusal')
    for label,error in [('first-check-StopIteration',StopIteration('synthetic')),('first-check-same-class',m['extractor'].FamilyInputError('synthetic')),('first-check-retained-owned',retained)]:
        probe=_Probe(c,error)
        faults.append(_expect_fault(lambda p=probe:_extract(m,main_inputs,c,check=p.boom),probe,c,label))
    probe=_Probe(c,StopIteration('schema dependency'))
    proxy=_FaultNamespace(m['schema'].VERSION,'infer_schematic_family',probe)
    faults.append(_expect_fault(lambda:_extract(m,main_inputs,c,schema=proxy,check=probe.check),probe,c,'schema-first-inference'))
    probe=_Probe(c,StopIteration('explicit encoder'))
    faults.append(_expect_fault(lambda:m['wide_instance'].compile_instance(context,family,bindings,encoder=probe.boom,modules={k:m[k] for k in ('checker','builders','reference')},check=probe.check),probe,c,'wide-instance-explicit-encoder'))
    main['families'][0]['source_occurrences'][0]['donor_id']='mutated-return-only'
    _need(_same(main_before,_plain(main_inputs,c),c) and _same(saved_family,_plain(family,c),c),'detached result mutation')
    controls.append(dict(id=IDS[5],passed=True,observations=dict(selected_faults=faults,retained_owned_refusal=True,input_provenance_unchanged=True,output_mutation_isolated=True),coverage_limits=[LIMITS[1],LIMITS[2]]))
    _need(tuple(r['id'] for r in controls)==IDS,'exact ordered six groups')
    result=dict(schema=SCHEMA,version=VERSION,population=POPULATION,complete=True,control_ids=list(IDS),controls=controls,counts=dict(groups=6,passed=6,failed=0),scope=SCOPE,coverage_limits=list(LIMITS))
    result=_plain(result,c);c.tick();return result
