"""Administrative metadata only; reads frozen Source as text/AST, never imports it."""
from pathlib import Path
import argparse
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
CASE = 'two-admitted-donor-stratified-schema-acquisition-v1-case-0'
WORKER = STUDY / 'implementation-B/fpc_stratified_acquisition_worker_v1.py'
PROTOCOL = ROOT / 'stratified-schema-acquisition-protocol-v1.json'
PREPARATION = ROOT / 'stratified-schema-acquisition-study-preparation-v1.json'
NAMES = ('MODULE_PINS', 'MODULE_ROLES', 'CONTROL_POPULATIONS', 'CAPS',
         'INPUT_AUTHORITY', 'SOURCE_COMPONENTS', 'CUSTODY_RUNTIME',
         'REQUIRED_METADATA_GUARDS', 'EXPERIMENT', 'PROFILE', 'CASE',
         'PROTOCOL_SCHEMA')


def raw(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    assert path.name not in ('index.html', '.gcts-active')
    return path.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def exact(record):
    assert type(record) is dict and set(record) == {'path', 'bytes', 'sha256'}
    assert record == pin(Path(record['path']))
    return record


def load(record):
    exact(record)
    return json.loads(raw(record['path']))


def js(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                       allow_nan=False) + '\n').encode('ascii')


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert raw(path) == body


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--acceptance', required=True)
    args = parser.parse_args()
    acceptance_path = Path(args.acceptance)
    acceptance = json.loads(raw(acceptance_path))
    assert acceptance['Source_component_accepted'] is True
    assert acceptance['Source'] == pin(WORKER)
    assert acceptance['metadata_Source'] == pin(Path(__file__).resolve())
    review = load(acceptance['independent_review'])
    assert review['review_passed'] is True and review['blockers'] == []

    # Only inert literal assignments are interpreted. No Source code is evaluated.
    tree = ast.parse(raw(WORKER), filename=str(WORKER))
    values = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name) and target.id in NAMES:
                assert target.id not in values
                values[target.id] = ast.literal_eval(node.value)
    assert set(values) == set(NAMES) and values['CASE'] == CASE
    assert len(values['MODULE_ROLES']) == 9
    assert set(values['MODULE_PINS']) == set(values['MODULE_ROLES'])
    assert values['CAPS'] == {
        'work_seconds': 160, 'positive_seconds': 180, 'custody_seconds': 210,
        'observer_fallback_seconds': 225, 'memory_bytes': 1073741824,
        'physical_bytes': 134217728, 'result_bytes': 50331648,
        'log_bytes': 4194304, 'reserved_outer_bytes': 9437184,
        'root_callbacks': 400000000}
    assert len(values['CONTROL_POPULATIONS']) == 1
    assert values['CONTROL_POPULATIONS'][0]['groups'] == 6
    assert len(values['INPUT_AUTHORITY']) == 2

    files = {}

    def include(record):
        exact(record)
        name = record['path']
        assert '/actual/' not in name and not name.endswith('.bin')
        if name in files:
            assert files[name] == record
        else:
            files[name] = record

    for record in list(values['MODULE_PINS'].values()) + list(values['CUSTODY_RUNTIME'].values()):
        include(record)
    for record in values['REQUIRED_METADATA_GUARDS'] + values['SOURCE_COMPONENTS']:
        include(record)
    for record in acceptance['component_acceptances']:
        component = load(record)
        assert component['Source_component_accepted'] is True
        c_review = load(component['independent_review'])
        assert c_review['review_passed'] is True and c_review['blockers'] == []
        include(record)
        include(component['independent_review'])
    include(pin(WORKER))
    include(pin(Path(__file__).resolve()))
    include(pin(acceptance_path))
    include(acceptance['independent_review'])

    protocol = dict(schema=values['PROTOCOL_SCHEMA'], experiment=values['EXPERIMENT'],
        limits=values['CAPS'], module_pins=values['MODULE_PINS'],
        control_populations=values['CONTROL_POPULATIONS'],
        job_recipes=[dict(case_id=CASE, stage='acquisition')],
        metadata=dict(profile=values['PROFILE'], input_authority=values['INPUT_AUTHORITY'],
                      Source_components=values['SOURCE_COMPONENTS'],
                      reference_integer_policy=['FPC-original-json-integer-policy-v1', 4300]))
    protocol_body = js(protocol)
    protocol_pin = dict(path=str(PROTOCOL), bytes=len(protocol_body),
                        sha256=hashlib.sha256(protocol_body).hexdigest())
    assert str(PROTOCOL) not in files
    # This prospective pin is included without reading a not-yet-created file.
    files[str(PROTOCOL)] = protocol_pin
    plan_path = ROOT / 'plans' / (CASE + '.json')
    plan = dict(schema='proof-search-case-once-plan-v1', case_id=CASE,
        stage='acquisition', experiment=values['EXPERIMENT'],
        actual_dir=str(STUDY / 'actual' / CASE), worker_path=str(WORKER),
        runner_path=values['CUSTODY_RUNTIME']['runner']['path'],
        python=values['CUSTODY_RUNTIME']['python'], files=list(files.values()),
        limits=values['CAPS'], protocol=protocol_pin, profile=values['PROFILE'],
        module_pins=values['MODULE_PINS'], input_authority=values['INPUT_AUTHORITY'],
        Source_components=values['SOURCE_COMPONENTS'])
    assert not PROTOCOL.exists() and not plan_path.exists() and not PREPARATION.exists()
    assert not Path(plan['actual_dir']).exists()
    assert not Path(plan['actual_dir'] + '.observer').exists()
    plan_path.parent.mkdir(exist_ok=True)
    write(PROTOCOL, protocol_body)
    write(plan_path, js(plan))
    result = dict(schema='Root-stratified-schema-study-preparation-v1',
        status='PREPARED_METADATA_NO_GRANT_NO_SCIENTIFIC_EXECUTION',
        acceptance=pin(acceptance_path), protocol=pin(PROTOCOL), plan=pin(plan_path),
        Source_guard_count=len(files), scientific_imports_or_calls=0,
        data_bodies_read_or_hashed=False,
        scope='Nine-role six-group training-only sampled acquisition. All original ten caps; no historical bank rerun.')
    write(PREPARATION, js(result))
    print(json.dumps(pin(PREPARATION)))


if __name__ == '__main__':
    main()
