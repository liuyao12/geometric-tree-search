"""Root raw-metadata grant adoption only. Never imports or launches search."""
from pathlib import Path
import hashlib
import json
import sys

R = Path(__file__).resolve().parent
I = Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1/authorized-index-v1.json')

def load(p):
    return json.loads(Path(p).read_bytes())

def pin(p):
    p=Path(p).resolve(); b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def main(peer_path):
    idx=load(I)
    assert pin(I)['sha256']=='81a907b726aad1febb9b6781f7eadac519aeba6c073dd6dfade7cc5d03fdff33'
    peer=load(peer_path)
    assert peer['schema']=='and-support-final-grant-delta-review-v1'
    assert peer['final_grant_delta_review_passed'] is True
    assert peer['reviewer_identity']=='/root/conventional_library'
    assert peer['author_identity']=='/root'
    assert peer['source_only'] is True and peer['scientific_calls']==0
    assert peer['actual_execution_authorized'] is False
    # The independent reviewer must bind the complete exact authorized index.
    def contains(v, target):
        if v==target:return True
        if type(v)is dict:return any(contains(q,target) for q in v.values())
        if type(v)is list:return any(contains(q,target) for q in v)
        return False
    assert contains(peer,pin(I))
    seen={}
    def verify(v):
        if type(v)is dict:
            if set(v)=={'path','sha256','bytes'}:
                if v['path'] not in seen:
                    assert pin(v['path'])==v, v['path'];seen[v['path']]=v
            else:
                for q in v.values():verify(q)
        elif type(v)is list:
            for q in v:verify(q)
    verify(idx)
    subjects=[]
    for row in idx['schedule']:
        true=load(row['runner_plan']['path']);false=load(row['runner_plan_draft']['path'])
        subject={k:v for k,v in true.items() if k!='authorization'}
        assert len(subject)==17
        assert subject=={k:v for k,v in false.items() if k!='authorization'}
        raw=json.dumps(subject,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
        assert hashlib.sha256(raw).hexdigest()==row['subject_sha256']
        grant=load(row['authorization']['path']);draft=load(row['authorization_draft']['path'])
        delta={'actual_execution_authorized','review_roles','scope'}
        assert {k:v for k,v in grant.items() if k not in delta}=={k:v for k,v in draft.items() if k not in delta}
        assert grant['maximum_actual_invocations']==1 and grant['actual_execution_authorized'] is True
        assert grant['subject_sha256']==row['subject_sha256']
        assert set(grant['review_roles'])==set(idx['review_role_schemas'])
        for role,binding in grant['review_roles'].items():
            spec=idx['review_role_schemas'][role];receipt=load(binding['receipt']['path'])
            assert receipt['schema']==spec['schema'] and receipt[spec['pass']] is True
            assert binding['receipt']==idx['current_review_roles'][role]
            assert receipt['reviewer_identity']==binding['reviewer_identity']==spec['reviewer']
            assert receipt['source_only'] is True and receipt['scientific_calls']==0
            assert receipt['actual_execution_authorized'] is False
            for desc in binding['required_subjects']:assert contains(receipt,desc)
        verify(true);verify(grant);verify(load(row['worker_plan']['path']))
        actual=Path(row['actual_directory'])
        observer=Path(row['runner_plan']['path']).with_name(Path(row['runner_plan']['path']).stem+'-terminal-observation')
        assert not actual.exists() and not observer.exists()
        subjects.append(dict(invocation_id=row['invocation_id'],subject_sha256=row['subject_sha256'],actual_directory=str(actual),terminal_observation=str(observer)))
    assert len(subjects)==4
    out=dict(schema='ROOT-and-support-final-grant-adoption-v1',authorized_index=pin(I),final_grant_peer=pin(peer_path),
        raw_descriptors_verified=len(seen),unchanged_full_subjects=subjects,actuals_started=0,scientific_calls=0,
        metadata_adoption_passed=True,actual_execution_authorized=True,goal_complete=False,
        scope='Root adopts independently reviewed exact four max-one grants. All actual/observer directories absent at adoption. All-agent idle snapshot still required before first launch. No scientific code evaluated or mathematical admission by this script; exact Source scopes and inherited authorship caveats retained.')
    p=R/'ROOT-final-grant-adoption-v1.json'
    with p.open('x') as f:f.write(json.dumps(out,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(json.dumps(pin(p)))

if __name__=='__main__':
    assert len(sys.argv)==2
    main(sys.argv[1])
