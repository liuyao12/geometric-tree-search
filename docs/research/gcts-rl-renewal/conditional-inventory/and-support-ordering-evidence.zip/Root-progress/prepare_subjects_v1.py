"""Raw Source/AST/ordinary metadata preparation; no target evaluation."""
from pathlib import Path
import ast,hashlib,json,sys
R=Path(__file__).resolve().parent
S=Path('/private/tmp/gcts-and-support-cold-source-20261018')
P=Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1')
def load(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):
 with Path(p).open('x') as f:f.write(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n')
 return pin(p)
def verify(d):assert pin(d['path'])==d;return Path(d['path']).read_bytes()
def main():
 hand=load(S/'handoff-v1.json');mapping=load(S/'generated-Source-map-v1.json');api=load(S/'API-v1.json')
 assert hand['scientific_calls']==0 and hand['actual_execution_authorized'] is False
 assert hand['sources']==mapping['sources']==api['sources']
 for d in list(hand['sources'].values())+[hand['generated_Source_map'],hand['API']]:verify(d)
 parent_ref=mapping['parent_runtime_closure'];parent=load(parent_ref['path']);verify(parent_ref)
 design=load(R/'prospective-design-v1.json')
 projects=dict(parent['project_sources'])
 old_deleted={n:projects.pop(n) for n in ('semantic_inventory_search','quantified_symbolic_control_v1')}
 projects.update(mapping['expected_project_sources'])
 assert projects==mapping['expected_project_sources'] and len(projects)==22
 components=dict(parent['additional_nonseed_components'],receiver_driver=hand['sources']['receiver_driver'])
 aliases=dict(projects,semantic_receiver_driver=components['receiver_driver'],bounded_request_oracle=components['bounded_transport'])
 assert len(aliases)==24
 imports=[];dynamic=[];edges={k:set() for k in aliases};stdlib=set();external=set();unresolved=[]
 for module,d in sorted(aliases.items()):
  tree=ast.parse(verify(d),filename=d['path'])
  for node in ast.walk(tree):
   names=[]
   if isinstance(node,ast.Import):names=[a.name for a in node.names]
   elif isinstance(node,ast.ImportFrom):
    assert node.level==0;names=[node.module]
   for name in names:
    root=name.split('.')[0]
    kind='project' if root in aliases else 'stdlib' if root in sys.stdlib_module_names else 'external' if root=='z3' else 'unresolved'
    imports.append(dict(source_module=module,form=type(node).__name__,import_name=name,root=root,line=node.lineno,kind=kind))
    if kind=='project':edges[module].add(root)
    elif kind=='stdlib':stdlib.add(root)
    elif kind=='external':external.add(root)
    else:unresolved.append(imports[-1])
   if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='__import__':
    if node.args and isinstance(node.args[0],ast.Constant) and isinstance(node.args[0].value,str):
     dynamic.append(dict(module=module,line=node.lineno,import_name=node.args[0].value,call_AST=ast.dump(node,include_attributes=False)))
    else:raise ValueError('undeclared nonliteral project import')
 assert not unresolved and sorted(external)==parent['external_imports']
 closure=dict(parent)
 closure.update(schema=api['closure_schema'],parent_closure=parent_ref,Source_design=hand['composition_contract'],project_sources=projects,additional_nonseed_components=components,materialized_aliases=aliases,project_module_count=22,materialized_project_and_component_count=24,project_import_edges={k:sorted(v) for k,v in edges.items()},import_sites=imports,literal_dynamic_import_sites=dynamic,stdlib_import_roots=sorted(stdlib),unresolved_project_imports=[],seeds=[n for n in parent['seeds'] if n not in old_deleted]+['semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1'],bridge_scope='All4 same24module imports; current sharedhelper and standalone point/symbolic successors replace oldorderingSources. Native/compiler/Model/fullinventory/runtime/resultrepresentation/profile unchanged. Raw custody only; no Source self-cert or runtime result.',status='ROOT_RAW_SOURCE_CLOSURE_NO_EXECUTION_GRANT',author_identity='/root',actual_execution_authorized=False,scientific_calls=0,scientific_acceptance=False,source_only=True,ordering_parent_sources=old_deleted,ordering_current_sources=mapping['ordering_sources'],current_composition_handoff=pin(S/'handoff-v1.json'))
 for k in ('Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python'):assert closure[k]==parent[k]
 cref=save(R/'runtime-closure-v1.json',closure)
 declaration=dict(design)
 declaration.update(schema=api['declaration_schema'],runtime_closure=cref,selected_receiver_id=design['selected_receiver']['id'],result_reader='interned',model_storage='literal_interned',source_state='FROZEN_CODE_AND_EXACT_COMMON_CLOSURE_SUBJECT_TO_DISTINCT_AUTH_SOURCE_GATES',ordering_Source_handoff=pin('/private/tmp/gcts-and-support-ordering-source-20261018/handoff-v1.json'),point_Source_handoff=pin('/private/tmp/gcts-and-support-point-source-20261018/handoff-v1.json'),composition_Source_handoff=pin(S/'handoff-v1.json'),source_gate='Current distinct ordering/composition/once/prospectiveplan receipts authenticated in fresh authorization before launch. This declaration alone grants no execution.')
 dref=save(R/'experiment-declaration-v1.json',declaration)
 runner=hand['sources']['once_runner'];observer=hand['sources']['terminal_observer'];cold=hand['sources']['cold'];python=closure['runtime']['Python_executable']
 tree=ast.parse(verify(runner))
 limits=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets))
 assert limits==dict(work_seconds=180,overall_seconds=210,aggregate_peak_bytes=1073741824,stdout_bytes=4194304,stderr_bytes=4194304,result_bytes=134217728,worker_receipt_bytes=4194304,runner_plan_bytes=16777216,failure_cleanup_seconds=5,poll_milliseconds=20)
 zfiles=[{k:p[k] for k in ('path','sha256','bytes')} for p in closure['Z3']['files']]
 library=next(p for p in zfiles if p['path']==str(Path(closure['Z3']['package_root'])/'z3/lib/libz3.dylib'))
 native=dict(program_and_template=closure['fixed_native_inputs']['program_and_template'],opaque_microcode_gzip=closure['fixed_native_inputs']['opaque_microcode_gzip'],native_cpp=closure['native_CPP']['binary'])
 policy=pin('/private/tmp/gcts-semantic-family-next-audit-20261018/semantic-inventory-policy-001.json')
 for d in [python,policy]+zfiles+list(native.values()):verify(d)
 rows=declaration['schedule']
 assert len(rows)==4 and len({r['invocation_id'] for r in rows})==4 and len({r['actual_directory'] for r in rows})==4
 assert {(r['mode'],r['search_ordering']) for r in rows}=={(m,o) for m in ('fixed','symbolic') for o in ('legacy','and_support')}
 P.mkdir()
 for name in ('worker-plans','authorization-drafts','runner-plan-drafts'):(P/name).mkdir()
 subjects=[]
 for row in rows:
  assert not Path(row['actual_directory']).exists()
  base={k:row[k] for k in ('invocation_id','mode','search_ordering','model_storage','result_reader','receiver_id','actual_directory')}
  worker=dict(base,schema=api['worker_schema'],cold=cold,python=python,project_sources=projects,components=components,native_inputs=native,policy=policy,declaration=declaration['parent_structural_declaration'],integration_declaration=dref,runtime_closure=cref,z3=dict(root=closure['Z3']['package_root'],files=zfiles,library=library))
  assert set(worker)==set(api['worker_fields'])
  iid=row['invocation_id'];wref=save(P/'worker-plans'/(iid+'.json'),worker)
  subject=dict(base,schema=api['once_schema'],runner=runner,observer=observer,python=python,cold=cold,worker_plan=wref,integration_declaration=dref,runtime_closure=cref,limits=limits,environment=dict(LANG='en_US.UTF-8',LC_ALL='en_US.UTF-8',TZ='UTC'))
  sha=hashlib.sha256(canonical(subject)).hexdigest()
  auth=dict(schema=api['authorization_schema'],author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=1,subject_sha256=sha,review_roles={},scope='FALSE prospective4arm subject only. Exact4current reviewedroles and separate finaldelta/Rootadoption/allagentsidle still required. No scientific execution.')
  assert set(auth)==set(api['authorization_fields'])
  aref=save(P/'authorization-drafts'/(iid+'.json'),auth)
  final=dict(subject,authorization=aref);assert set(final)==set(api['once_fields'])
  qref=save(P/'runner-plan-drafts'/(iid+'.json'),final)
  subjects.append(dict(row,worker_plan=wref,authorization_draft=aref,runner_plan_draft=qref,subject_sha256=sha))
 idx=dict(schema='ROOT-and-support-prospective-plan-index-v1',source_only=True,author_identity='/root',scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,goal_complete=False,declaration=dref,runtime_closure=cref,cold=cold,runner=runner,observer=observer,composition_handoff=pin(S/'handoff-v1.json'),ordering_handoff=declaration['ordering_Source_handoff'],point_handoff=declaration['point_Source_handoff'],API=hand['API'],review_role_schemas=api['review_roles'],schedule=subjects,scope='Four same24module c3 completepipeline controls, compact Model/internedReader fixed. All false max-one drafts unlaunchable. Current Source/plan reviews and truegrant delta remain execution gates. No9fixture or new10suite execution.',actuals_started=0)
 ref=save(P/'prospective-index-v1.json',idx)
 print(json.dumps(dict(index=ref,declaration=dref,closure=cref,subjects=len(subjects),actuals_started=0)))
if __name__=='__main__':main()
