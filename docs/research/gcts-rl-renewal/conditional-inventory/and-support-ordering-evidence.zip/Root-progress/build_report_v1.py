"""Retained data publication and pure display only; never reruns proof search."""
from pathlib import Path
import hashlib
import json
import gzip
import importlib.util
import html

R=Path(__file__).resolve().parent
SITE=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
P=Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1')

def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,raw):
    if type(raw)is str:raw=raw.encode()
    p=SITE/name;p.write_bytes(raw);return pin(p)
def js(v):return json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n'

HEAD=r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Joint-premise guidance finds the curried proof — GCTS research</title>
<link rel="stylesheet" href="reader.css?v=native-head-20261017">
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>.table-wrap{overflow:auto}table{table-layout:auto;min-width:650px}.result-grid,.support-flow,.roles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}.result-card,.support-flow article,.roles article{border:1px solid #b9cfd6;background:white;padding:20px}.result-card{border-top:6px solid #398276}.baseline{background:#84949b}.support{background:#278477}.bar-track{background:#e7edf0;height:22px;max-width:100%;margin:6px 0 15px}.bar{height:100%;min-width:3px}.small{font-size:13px;color:#476270}.support-flow{grid-template-columns:repeat(3,minmax(0,1fr));background:#edf4f6;padding:18px}.support-flow article{border-top:5px solid #7155a4}.proof-links{background:#e8f3ee;padding:20px;border-left:5px solid #278477}.status{border-left-color:#278477}.outcome-pass{color:#246d5e;font-weight:700}.outcome-unknown{color:#765622;font-weight:700}.roles{grid-template-columns:repeat(3,minmax(0,1fr))}.roles h3{margin-top:0}.caption{font-size:14px}.detail{padding:14px;background:#f0f4f6}.scope{border-left:4px solid #b48132;padding:15px 20px;background:#fff7e7}@media(max-width:760px){.result-grid,.support-flow,.roles{grid-template-columns:1fr}.support-flow{padding:12px}}</style>
</head><body><main>
<nav><a href="reader.html#and-support-ordering">Research notebook</a><a href="#outcomes">All four results</a><a href="#proofs">Inspect the proofs</a><a href="#parallel">Parallel roles</a><a href="#evidence">Evidence</a></nav>
'''

def main():
    admitted=load(R/'ROOT-actual-admission-v1.json');assert not admitted['findings'] and admitted['fresh_native_proofs']==2
    rows=admitted['actuals'];assert all(x['ROOT_resource_admitted'] for x in rows)
    renderer_path=Path('/private/tmp/gcts-semantic-proof-renderer-source-20261018/semantic_proof_renderer_v2.py')
    assert pin(renderer_path)['sha256']=='bd929c531205dfd9fcfd6732c9de554d71e2abdd492a80aac1dd094965b77e77'
    spec=importlib.util.spec_from_file_location('retained_display_only',renderer_path)
    renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
    assets=[];proof_readers=[]
    names={('fixed','legacy'):'GCTS · legacy advice',('fixed','and_support'):'GCTS · joint-premise advice',('symbolic','legacy'):'Symbolic · legacy ordering',('symbolic','and_support'):'Symbolic · joint-premise ordering'}
    for row in rows:
        stem='and-support-'+row['mode']+'-'+row['search_ordering'].replace('_','-')
        raw=Path(row['result']['path']).read_bytes();assert pin(row['result']['path'])==row['result']
        assets.append(write(stem+'-result.json.gz',gzip.compress(raw,compresslevel=9,mtime=0)))
        if row['fresh_native_proof']:
            data=json.loads(raw);fragment=renderer.render_result(data,names[row['mode'],row['search_ordering']],raw_href=stem+'-result.json.gz')
            note=r'''<p class="eyebrow">AUTOMATICALLY FOUND · 18 OCTOBER 2026</p><h1>A machine-found curried proof.</h1><p class="lead">Every command row, its human formula and explanation, actual colored point tiles and the reusable lemma expansions are shown below. No target proof sequence was supplied to the search. The Root admission and distinct retained audits are linked from the comparison report.</p><p><a href="and-support-ordering.html#outcomes">Return to all four outcomes</a> · <a href="#proof-reader">Go to proof rows and markings</a>.</p><p class="scope">This is a finite quantified proof encoding with translation-only C/G/input point roles and nonlocal markings. The square icons are display glyphs for actual selected point tiles, not a claim of a fixed finite universal nearest-neighbor Wang palette. The full fixed-length word contains padding; green rows follow the retained target-ancestry observation.</p>'''
            assets.append(write(stem+'-proof.html',HEAD.replace('href="#', 'href="and-support-ordering.html#')+note+'<div id="proof-reader">'+fragment+'</div></main></body></html>'))
            proof_readers.append(stem+'-proof.html')
        del raw
    summary=dict(schema='and-support-ordering-public-summary-v1',date='2026-10-18',actuals=rows,
        total_actuals=4,admitted_proof_instances=2,distinct_newly_solved_program_cases=1,mathematical_novelty_claimed=False,
        all_four_within_profile=True,common_semantics_equal_old_c3=True,new_RL_training=False,
        new_ten_case_suite_executed=False,nine_algorithm_fixtures_executed=False,goal_complete=False,
        controls='Same complete compiler, registry, Model, Native checker, primitive alternatives and profile. Same support helper in both methods; point row-Join setting24 plus arbitrary sampled proposals and defer versus symbolic64candidate windows. Different work units.',
        interpretation='Generic joint-premise guidance succeeds in both methods on one familiar development assertion; symbolic is faster in this cohort. No GCTS-specific advantage, RL result, broad benchmark or novel mathematical theorem.',
        Root_admission=pin(R/'ROOT-actual-admission-v1.json'),declaration=pin(R/'experiment-declaration-v1.json'),proof_readers=proof_readers)
    assets.append(write('and-support-ordering-summary.json',js(summary)))
    assets.append(write('and-support-ordering-admission.json',(R/'ROOT-actual-admission-v1.json').read_bytes()))
    assets.append(write('and-support-ordering-declaration.json',(R/'experiment-declaration-v1.json').read_bytes()))
    assets.append(write('and-support-ordering-runtime-closure.json',(R/'runtime-closure-v1.json').read_bytes()))
    table=[]
    for row in rows:
        unit='point placements' if row['mode']=='fixed' else 'row extensions'
        count=row['search_counters'].get('attempts',row['search_counters'].get('prefix_extensions'))
        label='Checked proof' if row['fresh_native_proof'] else 'UNKNOWN · search budget'
        cls='outcome-pass' if row['fresh_native_proof'] else 'outcome-unknown'
        table.append(f'<tr><th>{names[row["mode"],row["search_ordering"]]}</th><td class="{cls}">{label}</td><td>\\({count}\\) {unit}</td><td>\\({row["search_seconds"]:.3f}\\)</td><td>\\({row["outer_terminal_seconds"]:.3f}\\)</td><td>\\({row["peak_sum_MiB"]:.1f}\\)</td></tr>')
    cards=[]
    for mode,label in [('fixed','GCTS point search'),('symbolic','Conventional symbolic search')]:
        pair={r['search_ordering']:r for r in rows if r['mode']==mode}
        body='<article class="result-card"><h3>'+label+'</h3>'
        for ordering,caption in [('legacy','Legacy · UNKNOWN'),('and_support','Joint-premise · proof')]:
            r=pair[ordering];width=r['outer_terminal_seconds']/150*100
            body+=f'<p>{caption}: \\({r["outer_terminal_seconds"]:.2f}\\) seconds</p><div class="bar-track"><div class="bar {"baseline" if ordering=="legacy" else "support"}" style="width:{width:.5f}%"></div></div>'
        cards.append(body+'</article>')
    report=HEAD+r'''<p class="eyebrow">MEASURED SEARCH RESULT · 18 OCTOBER 2026</p>
<h1>Keeping premises together finds the proof.</h1>
<p class="lead">Parallel diagnosis, implementation and independent review led to a useful general search improvement. On the previously unsolved curried example, both GCTS and conventional symbolic search now discover a checked proof with joint-premise guidance. Both contemporary legacy controls return UNKNOWN.</p>
<p class="status">Four fresh, sequential runs; two admitted proof instances of one familiar assertion; all four within the original full resource profile. No proof sequence was supplied. This is evidence for the shared heuristic on this development case. It establishes no GCTS-specific or RL advantage.</p>
<section id="statement"><h2>The concrete statement</h2>
\[\forall x\bigl(P(x)\rightarrow(Q(x)\rightarrow R(x))\bigr),\quad\forall xP(x),\quad\forall xQ(x)\ \vdash\ \forall xR(x).\]
<p>If every object satisfying the two premises satisfies the conclusion, and every object satisfies both premises, then every object satisfies the conclusion. This is a basic first-order assertion, not an arithmetic or geometric axiom. It is familiar development data, not a blind test or a new mathematical theorem.</p></section>
<section id="outcomes"><h2>Every declared outcome</h2><div class="table-wrap"><table><thead><tr><th>Method and ordering</th><th>Full admitted outcome</th><th>Search work</th><th>Search seconds</th><th>Full seconds</th><th>Memory MiB</th></tr></thead><tbody>'''+''.join(table)+r'''</tbody></table></div>
<p class="caption">The table follows the frozen execution order. Point placements and proof-row extensions are different work units. Each run allowed \(5000\) such units or \(30\) search seconds. UNKNOWN means that search reached its budget, not that the statement is unprovable. Both successful runs had no backtracking.</p>
<div class="result-grid">'''+''.join(cards)+r'''</div>
<p class="caption">Bars share the same full-time scale. The legacy runs did not find proofs, so these are completion times for different outcomes, not proof-time speedup ratios. Full seconds run from the outer runner’s Source entry to externally observed termination; interpreter and observer preparation are separately recorded. Inventory construction, complete point-model construction, Native compilation/checking, heuristic work, output, literal reconstruction and shutdown are charged.</p>
<details class="detail"><summary>Resource and common-input details</summary><p>The unchanged profile allows \(180\) seconds of work, including a positive result and worker exit, and \(210\) seconds through external termination. Memory is the conservative sum of separate Python-worker and Native-process high-water values, bounded by \(1\) GiB; it is not a simultaneous live peak. Parent/observer memory is excluded. Complete raw JSON is bounded by \(128\) MiB.</p><p>All four runs materialize the same \(24\) module aliases, including both search implementations and the helper. Complete compiler, inventory, candidate-model and initial-state preimages are literally equal across all four and to the previous curried case, excluding only declared setup timings. The model has \(11440\) candidates, \(60\) required point slots, \(13\) formulas, maximum input arity \(3\), and \(8\) admitted interfaces. No candidate, primitive fallback, proof rule or theory axiom was removed or added. Compact model storage and lossless interned result reading are fixed in every arm.</p><p>Both proofs pass fresh whole-request Native acceptance, independent raw finite-region occupancy/mark agreement checks, exact row decoding, complete-output reconstruction and terminal/resource gates. All owned workers were reaped, Native groups were absent, logs reached EOF, and no cleanup signals or reappearance were reported. The external runner alone does not certify mathematical validity.</p></details></section>
<section id="mechanism"><h2>What changed</h2>
<p>The old distance ranking could favor a legal instantiation licence for the desired universal statement even while that universal remained unproved. The new heuristic models inference as a dependency with all required premises attached. It seeds only justified completed rows, assigns positive cost to each new inference, and ranks the available choices by their effect on the remaining support for the target.</p>
<div class="support-flow"><article><h3>Justified facts</h3><p>A complete row needs its actual earlier input rows. A guard tile alone supplies no fact.</p></article><article><h3>Joint dependencies</h3><p>All premises of a rule must be supported together. A licence for \((\forall xR(x))\rightarrow R(x)\) does not supply \(\forall xR(x)\).</p></article><article><h3>Rank the choices</h3><p>Positive inference costs keep circular support from seeding itself. Scores reorder available choices; the checker decides validity.</p></article></div>
\[c(\text{rule})=1+\sum_{i=1}^{k}c(\text{premise}_i).\]
<p>This is a heuristic potential, not a certified lower bound. The same implementation is used by both methods. GCTS retains the original row-Join setting of \(24\), plus arbitrary sampled proposals and the defer option; that setting is not a cap on the total pool. Symbolic search ranks stable windows of \(64\) legal row candidates. Those application domains differ. Unselected alternatives and the rest of the candidate iterator remain available. The GCTS global dead-end, forced-move, earliest-generation scheduler and exact rollback are preserved.</p>
<p>The point treatment recorded \(11\) support-ranking calls and \(6\) changes to the original frozen hint choice, with no recorded fallback in those calls. It finished \(60\) placements with \(18\) branches and \(42\) forced moves. The symbolic treatment finished \(12\) row extensions. Shared inference knowledge, rather than a new multirow proposer or trained policy, explains the tested intervention.</p></section>
<section id="proofs"><h2>Read the discovered proofs</h2>
<div class="proof-links"><p><a href="and-support-fixed-and-support-proof.html#proof-reader"><b>GCTS proof: formulas, English and colored point tiles</b></a></p><p><a href="and-support-symbolic-and-support-proof.html#proof-reader"><b>Symbolic proof: formulas, English and colored point tiles</b></a></p></div>
<p>Each reader retains all \(12\) command rows, including redundant padding in this fixed-length encoding. Green highlighting identifies the target ancestry reported by the retained observer. Expand any lemma call to see its exact premises and primitive body; expand a colored tile to inspect every actual occupancy and marking value.</p>
<p>Both target derivations use three admitted level-one lemma instances: an application of modus ponens and two two-step applications. Their target-essential primitive expansion has three theory axioms, three instantiation licences, five applications of modus ponens and one generalization. No nested hierarchy of newly learned lemmas is demonstrated.</p>
<p>The human tables are lossless display projections of retained evidence, not another proof search or independent proof checker. The symbolic search is a conventional chronological control projected into the same finite point region for final checking. The GCTS search actually maintains the complete point/candidate graph; the two representations should not be conflated.</p></section>
<section id="parallel"><h2>Parallel agents are helping</h2>
<div class="roles"><article><h3>Search and comparison</h3><p><code>conventional_control_review</code> diagnosed the old failure and implemented the shared scorer and symbolic integration. It independently reviewed the new outer orchestration delta and now audits retained resources, with inherited authorship disclosed.</p></article><article><h3>Receptor families and point search</h3><p><code>conventional_library</code> assessed lemma-family capabilities and implemented point-search integration. It separately reviewed new driver/plan metadata and now analyzes the comparison.</p></article><article><h3>Verification and integration</h3><p><code>receiver_driver_review</code> froze the prospective test inputs and implemented orchestration. It independently reviewed the ordering components and now audits retained mathematical and point evidence.</p></article></div>
<p>Root owns the full experiment declaration, exact one-use launch subjects, integration, independently repeated retained-data admission, report and deployment. Changed code is reviewed by another author. Inherited code and reviewer authorship overlap are explicitly recorded; these are scoped reviews, not three wholly independent implementations.</p><p>Design, coding and review run in parallel. All measured executions run sequentially with the other agents idle. Parallel research throughput does not itself demonstrate faster automated proof search.</p></section>
<section id="assessment"><h2>What the result establishes</h2>
<p>The system discovers checked proofs without a human supplying the target proof sequence. This cohort fixes one previously failing development example. The generic joint-premise heuristic helps both methods, and the symbolic treatment is faster in this cohort in both search and full measured time. These observations support continued work on automated search, while leaving a distinctive GCTS advantage unestablished.</p>
<p class="scope">This is one deterministic familiar example per arm, with no repetitions or statistical generalization. There is no new RL training, external-prover benchmark, Peano arithmetic result, Hilbert geometry result, fixed universal Wang palette, Turtle/Penrose experiment or infinite-plane tiling proof in this update. The nine supplied algorithm-fixture inputs remain unexecuted. The ten prospective first-order benchmark inputs remain unexecuted.</p>
<p>The next contribution test is to freeze this reviewed implementation and apply it to the <a href="parallel-search-planning.html#benchmarks">already frozen ten inputs across eight structural groups</a>, retaining renamed cases, failures and full preparation costs. Recursive construction of several missing-premise rows is a separate future change. A learned cluster policy should then be compared against the same generic heuristic and charged for training and reuse.</p></section>
<section id="evidence"><h2>Inspect the complete evidence</h2><p><a href="and-support-ordering-summary.json">Results and scope</a> · <a href="and-support-ordering-admission.json">Root admission</a> · <a href="and-support-ordering-declaration.json">Prospective declaration</a> · <a href="and-support-ordering-runtime-closure.json">Complete runtime identities</a> · <a href="and-support-ordering-evidence-manifest.json">Published hashes</a> · <a href="and-support-ordering-evidence.zip">Complete outputs, Sources, plans and reviews</a>.</p>
<p><a href="and-support-ordering-data-review.json">Distinct retained-data and point review</a> · <a href="and-support-ordering-resource-review.json">Distinct resource and terminal review</a> · <a href="and-support-ordering-comparison-review.json">Comparison assessment</a> · <a href="and-support-ordering-report-review.json">Distinct report review</a>.</p>
<ul><li><a href="and-support-fixed-legacy-result.json.gz">Complete GCTS legacy output</a></li><li><a href="and-support-symbolic-and-support-result.json.gz">Complete symbolic treatment output</a></li><li><a href="and-support-symbolic-legacy-result.json.gz">Complete symbolic legacy output</a></li><li><a href="and-support-fixed-and-support-result.json.gz">Complete GCTS treatment output</a></li></ul>
<p>Each gzip is lossless compression of the complete raw result, with no omitted fields. These are ordinary publication files, not a decoded replacement for the pinned opaque Native input. The archive records external runtime and library prerequisites by exact raw identities; it does not package a new interpreter or solver distribution.</p></section>
<footer>The research goal remains active. Earlier <a href="parallel-search-planning.html#roles">parallel planning</a> and <a href="structural-transfer.html#outcomes">curried UNKNOWN results</a> remain historical evidence.</footer>
</main></body></html>'''
    assets.append(write('and-support-ordering.html',report))
    # Update only this task's child reader and add a dated notice to the previous milestone.
    reader=SITE/'reader.html';s=reader.read_text()
    old='<p class="lead">Parallel diagnosis, receptor-family design and a frozen input suite prepare the next search experiment. This Source and retained-data update reports \\(0\\) new scientific runs. The latest measured compact-storage results remain below.</p>'
    new=r'<p class="lead">Joint-premise guidance now finds the previously unsolved curried proof in both GCTS and conventional symbolic search. Both legacy controls return UNKNOWN. All four runs meet the full profile; the shared heuristic has useful evidence on one familiar development case, with no GCTS-specific or RL advantage established.</p>'
    assert old in s;s=s.replace(old,new,1)
    block=r'<section id="and-support-ordering"><p class="eyebrow">LATEST MEASURED SEARCH RESULT · PARALLEL RESEARCH</p><h2>Shared guidance finds the curried proof in both searches.</h2><p>Two fresh admitted proofs, two legacy search-budget UNKNOWNs, and all four runs within profile. The generic joint-premise heuristic succeeds in both point and symbolic search; symbolic search is faster in this cohort. The result concerns one familiar first-order assertion, with no new RL training or broader benchmark claim.</p><p><a href="and-support-ordering.html#outcomes"><b>All four results and full costs</b></a> · <a href="and-support-ordering.html#proofs">Machine-found proofs, English and colored markings</a> · <a href="and-support-ordering.html#parallel">How the three agents contributed</a>.</p></section>'
    assert '<section id="parallel-search-planning">' in s
    s=s.replace('<section id="parallel-search-planning">',block+'<section id="parallel-search-planning">',1)
    s=s.replace('CURRENT RESEARCH · SOURCE AND RETAINED DATA','EARLIER PLANNING · SOURCE AND RETAINED DATA',1)
    s=s.replace('LATEST MEASURED RESULT · COMPLETE PIPELINE','EARLIER STORAGE RESULT · COMPLETE PIPELINE',1)
    s=s.replace('LATEST PROOF-SEARCH RESULT · PARALLEL RESEARCH','EARLIER PROOF-SEARCH RESULT · PARALLEL RESEARCH',1)
    reader.write_text(s);assets.append(pin(reader))
    previous=SITE/'parallel-search-planning.html';s=previous.read_text()
    marker='<section id="roles">';assert marker in s
    s=s.replace(marker,r'<p class="status">Subsequent measured result: the shared heuristic is now implemented and finds checked curried proofs in both GCTS and symbolic search. <a href="and-support-ordering.html#outcomes">Read all four fresh outcomes and the proof readers</a>. The planning record below describes the earlier unexecuted state.</p>'+marker,1)
    previous.write_text(s);assets.append(pin(previous))
    result=R/'report-draft-assets-v1.json';result.write_text(js(dict(schema='ROOT-and-support-report-draft-assets-v1',assets=assets,scientific_replays=0,pure_renderer=pin(renderer_path),peer_reviews_pending=True,goal_complete=False)))
    print(js(dict(draft_assets=pin(result),files=len(assets),proof_readers=proof_readers)))

if __name__=='__main__':main()
