"""Lossless retained-artifact packaging. No solver/search/Native evaluation."""
from pathlib import Path
import json
import hashlib
import zipfile
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote

R=Path(__file__).resolve().parent
SITE=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
P=Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1')

def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def js(v):return json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n'

REVIEWS={
 'data':Path('/private/tmp/gcts-and-support-retained-data-peer-20261018'),
 'resource':Path('/private/tmp/gcts-and-support-retained-resource-peer-20261018'),
 'comparison':Path('/private/tmp/gcts-and-support-comparison-peer-20261018'),
 'report':Path('/private/tmp/gcts-and-support-report-peer-20261018')}

def main():
    # Exact typed review paths are supplied in a Root-owned binding after all
    # independent checks close. This packager does not infer semantic approval.
    bindings=load(R/'ROOT-retained-review-adoption-v1.json')
    assert bindings['adoption_passed'] is True
    assets=[Path(d['path']) for d in load(R/'report-draft-assets-v3.json')['assets']]
    for role,desc in bindings['reviews'].items():
        assert pin(desc['path'])==desc
        out=SITE/('and-support-ordering-'+role+'-review.json')
        out.write_bytes(Path(desc['path']).read_bytes());assets.append(out)
    members={}
    def add(p,arc):
        p=Path(p)
        if not p.is_file():raise ValueError('missing full artifact '+str(p))
        assert arc not in members,arc
        members[arc]=p
    def folder(p,arc):
        p=Path(p)
        for child in sorted(p.iterdir()):
            if child.is_file() and child.suffix in ['.json','.py','.html','.txt','.md']:
                add(child,arc+'/'+child.name)
    folder(R,'Root-progress')
    folder(R/'report-draft-v1-before-corrections','superseded-report-draft-v1')
    folder(R/'report-draft-v2-before-label-correction','superseded-reader-v2')
    for path in [
        '/private/tmp/gcts-and-support-ordering-source-20261018',
        '/private/tmp/gcts-and-support-point-source-20261018',
        '/private/tmp/gcts-and-support-cold-source-20261018',
        '/private/tmp/gcts-and-support-ordering-independent-peer-20261018',
        '/private/tmp/gcts-and-support-composition-peer-20261018',
        '/private/tmp/gcts-and-support-once-peer-20261018',
        '/private/tmp/gcts-and-support-prospective-peer-20261018',
        '/private/tmp/gcts-and-support-final-grant-peer-20261018']:
        folder(path,'Source-and-reviews/'+Path(path).name)
    for role,path in REVIEWS.items():folder(path,'retained-reviews/'+role)
    add(P/'authorized-index-v1.json','plans/authorized-index-v1.json')
    add(P/'prospective-index-v1.json','plans/prospective-index-v1.json')
    for name in ['worker-plans','runner-plans','runner-plan-drafts','authorizations','authorization-drafts']:
        folder(P/name,'plans/'+name)
    idx=load(P/'authorized-index-v1.json')
    for row in idx['schedule']:
        a=Path(row['actual_directory']);arc='actuals/'+a.name
        # Full result, exact receipts, complete logs and every owned module and
        # Native wire artifact are retained. No field or failed arm is filtered.
        for child in sorted(a.iterdir()):
            if child.is_file():add(child,arc+'/'+child.name)
            elif child.name in ['modules','native']:
                for f in sorted(child.iterdir()):
                    if f.is_file():add(f,arc+'/'+child.name+'/'+f.name)
        obs=P/'runner-plans'/(row['invocation_id']+'-terminal-observation')
        for f in sorted(obs.iterdir()):
            if f.is_file():add(f,'observations/'+row['invocation_id']+'/'+f.name)
    for p in sorted((R/'semantic-preimages').iterdir()):add(p,'complete-semantic-preimages/'+p.name)
    closure=load(R/'runtime-closure-v1.json')
    for name,desc in closure['materialized_aliases'].items():
        assert pin(desc['path'])==desc
        add(desc['path'],'complete-runtime-Source/'+name+'.py')
    for role in ['opaque_microcode_gzip','program_and_template']:
        desc=closure['fixed_native_inputs'][role];assert pin(desc['path'])==desc
        add(desc['path'],'fixed-native-inputs/'+Path(desc['path']).name)
    for role in ['binary','source','build_receipt','preserved_failed_build_receipt']:
        desc=closure['native_CPP'][role];assert pin(desc['path'])==desc
        add(desc['path'],'Native-runtime/'+Path(desc['path']).name)
    add('/private/tmp/gcts-semantic-proof-renderer-source-20261018/semantic_proof_renderer_v2.py','pure-display/semantic_proof_renderer_v2.py')
    for p in assets:
        if p.suffix in ['.html','.json']:add(p,'published-reader/'+p.name)
    add(SITE/'reader.css','published-reader/reader.css')
    manifest={name:pin(path) for name,path in members.items()}
    archive=SITE/'and-support-ordering-evidence.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in members.items():z.write(path,name)
        z.writestr('archive-manifest.json',js(dict(schema='and-support-complete-archive-manifest-v1',members=manifest,
            scope='Complete four owned actuals, native wire artifacts, fixed Native inputs and executable/Source/build receipts, literal common preimages, Sources/contracts/plans/grants/reviews. External Python/stdlib and Z3 distribution remain exact pinned prerequisites; no new interpreter or solver distribution packaged. Nine fixture inputs unexecuted. No scientific replay or opaque Native gzip decoding.')))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name,desc in manifest.items():
            raw=z.read(name);assert len(raw)==desc['bytes'] and hashlib.sha256(raw).hexdigest()==desc['sha256']
    assets.append(archive)
    # All local anchors and paths in the new report and two proof readers.
    class Links(HTMLParser):
        def __init__(self):super().__init__();self.links=[];self.ids=set()
        def handle_starttag(self,tag,attrs):
            d=dict(attrs)
            if 'id'in d:self.ids.add(d['id'])
            if tag=='a' and 'href'in d:self.links.append(d['href'])
    checked=[]
    for name in ['and-support-ordering.html','and-support-fixed-and-support-proof.html','and-support-symbolic-and-support-proof.html']:
        p=SITE/name;parser=Links();parser.feed(p.read_text())
        for href in parser.links:
            u=urlsplit(href)
            if u.scheme or u.netloc:continue
            target=(p.parent/unquote(u.path)).resolve() if u.path else p
            assert target.is_file() or (target==SITE/'and-support-ordering-evidence-manifest.json' and not u.fragment),str(target)
            if u.fragment:
                other=parser
                if target!=p:
                    other=Links();other.feed(target.read_text())
                assert unquote(u.fragment) in other.ids,(name,href)
            checked.append(dict(source=name,href=href))
    published={p.name:pin(p) for p in assets}
    out=dict(schema='and-support-public-evidence-manifest-v1',published=published,archive_members=len(manifest),
        archive=pin(archive),all_archive_raw_hashes_verified=True,local_links_checked=len(checked),local_links=checked,
        Root_review_adoption=pin(R/'ROOT-retained-review-adoption-v1.json'),
        protected_overview_unchanged=True,mathematical_assertions=1,admitted_instances=2,retained_actuals=4,
        new_RL_training=False,goal_complete=False,scope='This manifest excludes its own raw identity; archive manifest separately covers internal objects. Report and proof display never replay Native/search.')
    p=SITE/'and-support-ordering-evidence-manifest.json';p.write_text(js(out))
    for entry in checked:
        u=urlsplit(entry['href'])
        target=(SITE/unquote(u.path)).resolve() if u.path else SITE/entry['source']
        assert target.is_file(),str(target)
    (R/'ROOT-publication-assets-v1.json').write_text(js(dict(schema='ROOT-and-support-publication-assets-v1',assets=[pin(p) for p in assets]+[pin(p)],goal_complete=False)))
    print(js(dict(manifest=pin(p),archive=pin(archive),members=len(manifest),links=len(checked),assets=len(assets)+1)))

if __name__=='__main__':main()
