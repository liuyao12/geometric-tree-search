"""Root retained evidence admission; no scientific imports or replay."""
from pathlib import Path
import hashlib
import json
import gc

R=Path(__file__).resolve().parent
P=Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1')

def load(path):
    return json.loads(Path(path).read_bytes())

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def pin(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    with Path(path).open('x') as f:
        f.write(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')
    return pin(path)

def regions(data):
    model=data['outputs']['model'];initial=data['initial_state']
    def point(p):
        assert type(p)is list and len(p)==2 and all(type(v)is int for v in p)
        return tuple(p)
    required={point(p) for p in model['roots']}
    assert len(required)==len(model['roots']) and required=={point(p) for p in initial['allowed_points']}
    totals={point(p):v for p,v in initial['totals']};marks={point(p):v for p,v in initial['marks']}
    assert len(totals)==len(initial['totals']) and len(marks)==len(initial['marks'])
    assert set(totals)<=required and all(type(v)is int and 0<=v<=12 for v in totals.values())
    candidates={tuple(c['key']):c for c in model['placements']}
    assert len(candidates)==len(model['placements'])
    search=data['outputs']['search'];selected=[tuple(k) for k in search['placements']]
    assert len(set(selected))==len(selected)
    proof=search['proof'];slots={}
    for key in selected:
        assert key in candidates and len(key)==4 and all(type(v)is int for v in key)
        assert 0<=key[0]<len(proof) and 0<=key[1]<2+model['arity'] and key[:2] not in slots
        c=candidates[key];slots[key[:2]]=c
        assert c['occupancy']==[[[4*key[0],key[1]],12]]
        for p,v in c['occupancy']:
            p=point(p);assert p in required and type(v)is int and v>0
            totals[p]=totals.get(p,0)+v;assert totals[p]<=12
        for p,v in c['marks']:
            p=point(p);assert type(v)is int and (p not in marks or marks[p]==v)
            marks[p]=v
    assert set(totals)==required and all(v==12 for v in totals.values())
    assert len(slots)==len(proof)*(2+model['arity'])
    defs={d['name']:d['definition'] for d in data['outputs']['register']['definitions']}
    for j,line in enumerate(proof):
        row=[slots[j,n] for n in range(2+model['arity'])]
        command=dict(row[0]['command']);assert command==row[1]['command']
        if command['rule']=='block':
            n=len(defs[command['name']]['premises'])
            inputs=[row[2+i]['source'] for i in range(n)]
            assert all(type(i)is int and 0<=i<j for i in inputs)
            command['inputs']=inputs
        assert command==line
    assert data['outputs']['final_request']['proof']==proof
    return dict(status='VERIFIED_WHOLE_FINITE_POINT_REGION',required_points=len(required),
        selected_placements=len(selected),assigned_mark_points=len(marks),decoded_rows=len(proof),
        union_sha256=hashlib.sha256(canonical(dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected)))).hexdigest())

def semantic_parts(data):
    outputs=data['outputs']
    return dict(compiler={k:v for k,v in outputs['compile'].items() if k!='seconds'},
        inventory={k:outputs['register'][k] for k in ('definitions','interfaces','native_blocks')},
        model={k:v for k,v in outputs['model'].items() if k!='compile_seconds'},
        initial=data['initial_state'])

def main():
    idx=load(P/'authorized-index-v1.json');declaration=load(idx['declaration']['path'])
    assert pin(idx['declaration']['path'])==idx['declaration']
    assert len(idx['schedule'])==4
    closure=load(R/'ROOT-cohort-closure-v1.json')
    assert closure['all_workers_and_native_groups_closed'] and closure['all_terminal_gates_passed']
    old_path=R.parent/'structural-quantified-c3-fixed-ROOT-20261018-v1/result.json'
    old=load(old_path);reference={k:canonical(v) for k,v in semantic_parts(old).items()}
    old_pin=pin(old_path);del old;gc.collect()
    directory=R/'semantic-preimages';directory.mkdir()
    findings=[];rows=[]
    for row in idx['schedule']:
        a=Path(row['actual_directory']);r=dict(row)
        r.update(admission_checks_passed=False,ROOT_resource_admitted=False,fresh_native_proof=False)
        try:
            q=load(a/'runner-receipt.json');w=load(a/'worker-receipt.json')
            tp=P/'runner-plans'/(row['invocation_id']+'-terminal-observation')/'terminal.json';t=load(tp)
            c=load(a/'CONSUMED.json');plan=load(row['runner_plan']['path']);wp=load(row['worker_plan']['path'])
            assert q['plan']==t['plan']==c['plan']==row['runner_plan']==pin(row['runner_plan']['path'])
            assert w['worker_plan']==row['worker_plan']==pin(row['worker_plan']['path'])
            assert q['authorization']==row['authorization']==pin(row['authorization']['path'])
            assert q['subject_sha256']==row['subject_sha256']
            assert q['consumed_once'] is True and q['worker_launch_attempts']==1
            assert q['python_reaped'] and q['python_exit_code']==0 and t['runner_exit_code']==0
            assert q['owned_group_absent'] and q['stdout_eof'] and q['stderr_eof'] and q['log_capture_complete']
            assert q['owned_group_reappearance_observed_ns'] is None and not q['signals'] and not q['errors']
            assert pin(a/'worker-receipt.json')==q['outputs']['worker_receipt']
            assert pin(a/'runner-receipt.json')==t['runner_receipt']
            assert q['began_ns']==w['began_ns']==c['began_ns']
            assert q['work_deadline_ns']==w['work_deadline_ns']==q['began_ns']+180_000_000_000
            assert q['overall_deadline_ns']==w['overall_deadline_ns']==q['began_ns']+210_000_000_000
            assert t['terminal_observed_ns']<q['overall_deadline_ns']
            native=w['native_transport'];assert native==q['native_transport']
            assert q['python_pid']==q['owned_pgid']==native['parent_pid']==native['parent_pgid']
            assert native['closed'] and native['all_reaped'] and native['native_exit_code']==0
            assert native['stderr_complete'] and native['stdout_eof'] and native['stdout_pending_bytes']==0
            peak=q['python_wait4_usage']['ru_maxrss']+native['native_high_water_bytes']
            assert peak==q['conservative_parent_plus_native_peak_bytes'] and peak<=1073741824
            raw=(a/'result.json').read_bytes();rp=pin(a/'result.json')
            assert len(raw)<=134217728 and rp==q['outputs']['result']==w['result']
            body=memoryview(raw)[:-1] if raw.endswith(b'\n') else memoryview(raw)
            reading=w['result_reading'];literal=reading['roundtrip']
            assert reading['reader']==row['result_reader']=='interned'
            assert literal['literal_bytes_equal'] and literal['body_bytes']==len(body)
            assert literal['body_sha256']==hashlib.sha256(body).hexdigest()
            data=json.loads(raw);del raw,body
            assert data['mode']==w['mode']==q['mode']==row['mode']
            assert data['search_ordering']==w['search_ordering']==q['search_ordering']==row['search_ordering']
            assert data['receiver_id']==w['receiver_id']==row['receiver_id']
            assert data['declaration']==declaration['selected_receiver']
            assert w['integration_declaration']==idx['declaration']
            epoch=data['source_epoch']
            assert epoch['schema']=='semantic-family-receiver-source-epoch-v3-and-support-ordering'
            assert epoch['search_ordering']==row['search_ordering']
            assert epoch['model_storage']==w['model_storage']==row['model_storage']=='literal_interned'
            assert epoch['result_representation']==dict(reader='interned',integration_declaration=idx['declaration'])
            assert len(epoch['sources']['project'])==24
            for role,header,alias in [('family_model','selected_family_model','interned_quantified_family_points_v1'),
                    ('support_ordering','support_ordering_module','receptor_support_ordering_v1'),
                    ('family_search' if row['mode']=='fixed' else 'symbolic_control','selected_search_module',
                     'semantic_inventory_search_v2' if row['mode']=='fixed' else 'quantified_symbolic_control_v2')]:
                v=w[header]
                assert v['module']==alias and v['original']==wp['project_sources'][alias]
                assert data['module_pins'][role]==v['owned']==pin(v['owned']['path'])
                assert pin(v['original']['path'])==v['original']
            profile=q['resource_candidate_accepted'] and t['terminal_gate_passed']
            assert profile is True
            has_proof=data['native_proof_accepted'] is True
            assert has_proof==w['logical_proof_accepted']
            point=None
            if has_proof:
                assert data['status']==w['status']=='native_proof_discovered'
                assert q['worker_terminal_observed_ns']<q['work_deadline_ns']
                assert reading['completed_ns']<w['work_deadline_ns']
                final=data['outputs']['final_native'];request=data['outputs']['final_request']
                assert data['records'][final['id']]==final and final['request']==request
                assert final['result']['status']=='accepted'
                assert final['request_sha256']==hashlib.sha256(canonical(request)).hexdigest()
                assert request['target']==data['declaration']['target']
                assert request['proof']==data['outputs']['search']['proof']
                point=regions(data)
                assert all(w['final_region_verification'][k]==v for k,v in point.items())
            else:
                assert data['status']==w['status']=='unknown_search_budget'
                assert data['outputs']['search']['proof'] is None
            parts=semantic_parts(data);refs={}
            for key,value in parts.items():
                b=canonical(value);assert b==reference[key],'complete old c3 literal '+key
                path=directory/(row['invocation_id']+'-'+key+'.json')
                with path.open('xb') as f:f.write(b)
                refs[key]=pin(path)
                if key=='compiler':assert hashlib.sha256(b).hexdigest()==data['compiled_semantics_sha256']
                if key=='inventory':assert hashlib.sha256(b).hexdigest()==data['inventory_semantics_sha256']
                if key=='model':assert hashlib.sha256(b).hexdigest()==data['model_identity_sha256']==data['model_after_identity_sha256']
            s=data['outputs']['search']
            r.update(admission_checks_passed=True,ROOT_resource_admitted=True,fresh_native_proof=has_proof,
                outcome_class='ADMITTED_BOUNDED_PROOF' if has_proof else 'IN_PROFILE_UNKNOWN',status=data['status'],
                result=rp,worker_receipt=pin(a/'worker-receipt.json'),runner_receipt=pin(a/'runner-receipt.json'),terminal=pin(tp),
                whole_region=point,reading=reading,peak_sum_bytes=peak,peak_sum_MiB=peak/1048576,
                python_peak_MiB=q['python_wait4_usage']['ru_maxrss']/1048576,native_peak_MiB=native['native_high_water_bytes']/1048576,
                outer_terminal_seconds=t['runner_clock_elapsed_seconds'],instrument_seconds=t['observed_instrument_elapsed_seconds'],
                worker_seconds=(q['worker_terminal_observed_ns']-q['began_ns'])/1e9,
                search_seconds=s['seconds'],search_counters=s['metrics'],search_status=s['status'],
                search_preparation_seconds=s.get('preparation_seconds'),search_support_metadata=s.get('support_ordering_metadata'),
                model_placements=len(data['outputs']['model']['placements']),required_points=len(data['outputs']['model']['roots']),
                model_arity=data['outputs']['model']['arity'],basis_count=len(data['outputs']['compile']['basis']),
                interfaces=len(data['outputs']['register']['interfaces']),native_queries=len(data['records']),semantic_preimages=refs,
                proof=s['proof'],selected_placements=s['placements'],
                essential_ancestry=data['outputs'].get('essential_ancestry'),winning_hint_links=data['outputs'].get('winning_hint_links'),
                stage_seconds={k:v.get('seconds') for k,v in data['outputs'].items() if type(v)is dict and 'seconds' in v},
                owned_group_absent=True,log_capture_complete=True,signals=[],errors=[])
            del data,parts,s;gc.collect()
        except Exception as error:
            finding=dict(invocation_id=row['invocation_id'],type=type(error).__name__,message=str(error))
            findings.append(finding);r.update(outcome_class='ADMISSION_CHECK_FAILURE_RETAINED',finding=finding)
            r['available_outputs']={n:pin(a/n) for n in ['result.json','worker-receipt.json','runner-receipt.json','worker-failure.json'] if (a/n).is_file()}
        rows.append(r)
    out=dict(schema='ROOT-and-support-four-actual-admission-v1',actuals=rows,authorized_index=pin(P/'authorized-index-v1.json'),
        declaration=idx['declaration'],cohort_closure=pin(R/'ROOT-cohort-closure-v1.json'),retained_old_c3_reference=old_pin,
        fresh_native_proofs=sum(r['fresh_native_proof'] for r in rows),within_resource_profile=sum(r['ROOT_resource_admitted'] for r in rows),
        all_common_full_semantic_preimages_equal=not findings,findings=findings,retained_actuals=len(rows),scientific_replays=0,
        new_mathematical_assertions=1 if any(r['fresh_native_proof'] for r in rows) else 0,new_RL_training=False,goal_complete=False,
        scope='Four sequential contemporary same24module development arms on one familiar quantified assertion. Shared generic AND-support ordering succeeds in both methods if all recorded gates hold. Different work units and ordering application domains; no GCTS-specific advantage or broader benchmark conclusion. Root raw point union/custody admission does not replay Native proof evaluation. Complete compiler/inventory/Model/initial literals equal old c3, excluding only declared setup timings.')
    print(json.dumps(dict(admission=save(R/'ROOT-actual-admission-v1.json',out),fresh=out['fresh_native_proofs'],findings=findings)))

if __name__=='__main__':main()

