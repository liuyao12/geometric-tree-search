"""Read-only human projection of a retained semantic receiver result.

This renderer is authored by the driver author, not an independent checker.
It imports no model/kernel/prover, reconstructs no search, and certifies nothing.
The surrounding report owns admission, raw-result publication and MathJax.
"""
import hashlib
import html
import json
from urllib.parse import urlsplit

VERSION = 'semantic-family-saved-result-proof-renderer-v2'
INPUT_SCHEMA = 'semantic-family-fresh-receiver-result-v1'
MAX_FRAGMENT_BYTES = 32 * 1024 * 1024
MAX_AST_DEPTH = 128


class RenderDataError(ValueError):
    pass


def _e(value):
    return html.escape(str(value), quote=True)


def _json(value):
    return json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)


def _name(value):
    if type(value) is not str or len(value) > 512:
        raise RenderDataError('finite literal symbol name required')
    replacements = {'\\': r'\backslash{}', '{': r'\{', '}': r'\}',
                    '_': r'\_', '^': r'\text{\^{}}', '#': r'\#',
                    '$': r'\$', '%': r'\%', '&': r'\&', '~': r'\text{\~{}}'}
    safe = ''.join(replacements.get(c, c if c.isprintable() else r'\text{[U+' + format(ord(c), '04X') + ']}') for c in value)
    return safe if len(value) == 1 and value.isascii() and value.isalpha() else r'\operatorname{' + safe + '}'


def _term(value, depth=0):
    if depth > MAX_AST_DEPTH or type(value) is not list or not value:
        raise RenderDataError('term is not a bounded literal AST')
    if value[0] == 'var' and len(value) == 2:
        return _name(value[1])
    if value[0] == 'fun' and len(value) == 3 and type(value[2]) is list:
        name = _name(value[1])
        args = [_term(t, depth + 1) for t in value[2]]
        return name + (r'\left(' + ','.join(args) + r'\right)' if args else '')
    raise RenderDataError('unsupported literal term AST')


def _formula(value, depth=0):
    if depth > MAX_AST_DEPTH or type(value) is not list or not value:
        raise RenderDataError('formula is not a bounded literal AST')
    tag = value[0]
    if tag == 'eq' and len(value) == 3:
        return _term(value[1], depth + 1) + '=' + _term(value[2], depth + 1)
    if tag == 'pred' and len(value) == 3 and type(value[2]) is list:
        args = [_term(t, depth + 1) for t in value[2]]
        return _name(value[1]) + (r'\left(' + ','.join(args) + r'\right)' if args else '')
    if tag == 'all' and len(value) == 3:
        return r'\forall ' + _name(value[1]) + r'\;\left(' + _formula(value[2], depth + 1) + r'\right)'
    if tag == 'not' and len(value) == 2:
        return r'\neg\left(' + _formula(value[1], depth + 1) + r'\right)'
    operators = {'imp': r'\Rightarrow ', 'and': r'\land ', 'or': r'\lor '}
    if tag in operators and len(value) == 3:
        return r'\left(' + _formula(value[1], depth + 1) + operators[tag] + _formula(value[2], depth + 1) + r'\right)'
    if value == ['bot']:
        return r'\bot'
    raise RenderDataError('unsupported literal formula AST')


def _math(tex):
    return '<span class="sr-math">\\(' + _e(tex) + '\\)</span>'


def _f(value):
    return _math(_formula(value))


def _code(value):
    return '<code>' + _e(value) + '</code>'


def _details(label, value):
    return '<details><summary>' + _e(label) + '</summary><pre>' + _e(_json(value)) + '</pre></details>'


def _index(value, bound, label):
    if type(value) is not int or not 0 <= value < bound:
        raise RenderDataError('literal index out of display scope: ' + label)
    return value


def _line_link(index, scope):
    return '<a href="#' + _e(scope) + '-line-' + str(index) + '">line ' + str(index + 1) + '</a>'


def _reason(command, row, scope, assumptions, labels):
    rule = command['rule']
    if rule == 'axiom':
        return 'Use the given theory premise ' + _code(command['name']) + '.'
    if rule == 'tautology':
        return 'Use a propositional tautology, as named by this recorded rule.'
    if rule == 'refl':
        return 'Introduce equality of a term with itself.'
    if rule == 'mp':
        a = _index(command['antecedent'], row, 'MP antecedent')
        b = _index(command['implication'], row, 'MP implication')
        return 'Apply the implication on ' + _line_link(b, scope) + ' to ' + _line_link(a, scope) + '.'
    if rule == 'generalize':
        source = _index(command['source'], row, 'generalization source')
        return 'Universally generalize ' + _line_link(source, scope) + ' in ' + _math(_name(command['variable'])) + '. The native checker supplies the scope side condition.'
    if rule == 'instantiate':
        return 'Introduce the universal-instantiation license for ' + _f(command['universal']) + ' at term ' + _math(_term(command['term'])) + '.'
    if rule == 'distribute':
        return 'Introduce universal distribution over implication for variable ' + _math(_name(command['variable'])) + '. The native checker enforces its free-variable side condition.'
    if rule == 'eq_subst':
        return 'Introduce the equality-substitution license with placeholder ' + _math(_name(command['variable'])) + ' and formula context ' + _f(command['template']) + '.'
    if rule == 'induction':
        return 'Use the recorded induction-schema instance for ' + _math(_name(command['variable'])) + '. Schema authorization remains a native-theory check.'
    if rule == 'assumption':
        port = _index(command['index'], len(assumptions), 'local assumption')
        return 'Use local input ' + str(port + 1) + ', whose declared formula is ' + _f(assumptions[port]) + '.'
    if rule == 'block':
        name = command['name']
        if name not in labels:
            raise RenderDataError('recorded block has no retained definition')
        refs = [_index(i, row, 'block input') for i in command['inputs']]
        sources = ', '.join(_line_link(i, scope) for i in refs) if refs else 'no earlier inputs'
        return 'Apply <a href="#' + _e(labels[name]['anchor']) + '">' + _e(labels[name]['label']) + '</a> to ' + sources + ', in the recorded port order.'
    raise RenderDataError('unknown recorded rule cannot be translated')


def _ports(command, row, scope, lines, definitions, labels):
    if command['rule'] != 'block':
        return ''
    definition = definitions[command['name']]
    refs = command['inputs']
    if len(refs) != len(definition['premises']):
        raise RenderDataError('block ports cannot be displayed with mismatched arity')
    rows = []
    for port, (source, premise) in enumerate(zip(refs, definition['premises'])):
        source = _index(source, row, 'displayed ordered block port')
        rows.append('<tr><td>' + str(port + 1) + '</td><td>' + _line_link(source, scope) + '</td><td>' + _f(premise) + '</td><td>' + _f(lines[source]['formula']) + '</td></tr>')
    if not rows:
        return '<p class="sr-small">This call has no premise ports.</p>'
    return '<details><summary>Ordered lemma input ports</summary><table><thead><tr><th>Port</th><th>Source</th><th>Declared input</th><th>Recorded source formula</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table></details>'


def _proof_table(lines, scope, assumptions, definitions, labels, essential=None):
    if type(lines) is not list:
        raise RenderDataError('literal proof row list required')
    marked = set(essential) if essential is not None else set()
    rows = []
    for i, command in enumerate(lines):
        if type(command) is not dict or 'formula' not in command or 'rule' not in command:
            raise RenderDataError('literal command fields missing')
        badge = '<span class="sr-badge">essential</span>' if i in marked else '<span class="sr-muted">not marked essential</span>' if essential is not None else '<span class="sr-muted">ancestry not observed</span>'
        rows.append('<tr id="' + _e(scope) + '-line-' + str(i) + '" class="' + ('sr-essential' if i in marked else '') + '"><td>' + str(i + 1) + '<br>' + badge + '</td><td>' + _f(command['formula']) + '</td><td>' + _reason(command, i, scope, assumptions, labels) + _ports(command, i, scope, lines, definitions, labels) + _details('Literal command', command) + '</td></tr>')
    return '<table class="sr-proof"><thead><tr><th>Line</th><th>Recorded formula</th><th>English reading of the recorded rule</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table>'


def _key(value):
    if not isinstance(value, (list, tuple)) or len(value) != 4 or any(type(v) is not int for v in value):
        raise RenderDataError('literal four-field point-placement key required')
    return tuple(value)


def _layer(point):
    x, y = point
    if x % 4 == 0 and y >= 100:
        return 'formula', '#25845b'
    if x % 4 == 1 and y >= 100:
        return 'command', '#2865a5'
    if x % 4 == 2 and y == 90:
        return 'mode', '#8b52a5'
    if x % 4 == 2 and y >= 100:
        return 'source', '#b5771a'
    return 'other', '#60717e'


def _tile(candidate, serial):
    key = _key(candidate['key'])
    role = key[1]
    title = 'C' if role == 0 else 'G' if role == 1 else 'I' + str(role - 1)
    color = '#2865a5' if role == 0 else '#8b52a5' if role == 1 else '#b5771a'
    counts = {}
    for point, value in candidate['marks']:
        name, layer_color = _layer(point)
        counts[name] = (counts.get(name, (0, layer_color))[0] + 1, layer_color)
    dots = []
    for i, (name, (count, layer_color)) in enumerate(sorted(counts.items())):
        dots.append('<circle cx="' + str(18 + i * 13) + '" cy="65" r="4" fill="' + layer_color + '"><title>' + _e(name + ': ' + str(count) + ' point assignments') + '</title></circle>')
    glyph = '<svg viewBox="0 0 92 92" role="img" aria-label="' + _e('Schematic point placement ' + title) + '"><rect x="7" y="6" width="77" height="77" rx="2" fill="#f7fafc" stroke="' + color + '" stroke-width="2"/><circle cx="46" cy="39" r="13" fill="' + color + '"/><text x="46" y="44" text-anchor="middle" fill="white" font-family="system-ui" font-size="13">' + title + '</text>' + ''.join(dots) + '</svg>'
    table = []
    for point, value in candidate['occupancy']:
        table.append('<tr><td>base occupancy</td><td>' + _math('(' + ','.join(map(str, point)) + ')') + '</td><td>' + _math(str(value) + '/12') + '</td></tr>')
    for point, value in candidate['marks']:
        name, layer_color = _layer(point)
        table.append('<tr><td><span class="sr-dot" style="background:' + layer_color + '"></span>' + name + ' marking</td><td>' + _math('(' + ','.join(map(str, point)) + ')') + '</td><td>' + _math(str(value)) + '</td></tr>')
    source = ''
    if candidate.get('kind') == 'lemma_input':
        source = '<p>Reads root line ' + str(candidate['source'] + 1) + '.</p>'
    elif candidate.get('kind') == 'unused_input':
        source = '<p>Unused input filler; its source sentinel is ' + _math('-1') + '.</p>'
    return '<details class="sr-tile"><summary>' + glyph + '<strong>' + title + '</strong> <span>selected placement ' + str(serial + 1) + '</span></summary><p>Exact key ' + _code(_json(list(key))) + '.</p>' + source + '<table><thead><tr><th>Assigned layer</th><th>Point</th><th>Exact value</th></tr></thead><tbody>' + ''.join(table) + '</tbody></table>' + _details('Full selected placement packet', candidate) + '</details>'


def _tile_rows(search, model, prefix):
    if type(model) is not dict or not isinstance(search.get('placements'), list):
        return '<p>No retained selected point region is available.</p>'
    indexed = {}
    for candidate in model['placements']:
        key = _key(candidate['key'])
        if key in indexed:
            raise RenderDataError('duplicate key in retained model display data')
        indexed[key] = candidate
    groups = {}
    seen = set()
    for serial, raw_key in enumerate(search['placements']):
        key = _key(raw_key)
        if key in seen:
            raise RenderDataError('duplicate selected placement in retained data')
        seen.add(key)
        if key not in indexed:
            raise RenderDataError('selected key absent from retained model')
        groups.setdefault(key[0], []).append((key[1], serial, indexed[key]))
    blocks = []
    for row, candidates in sorted(groups.items()):
        cards = [_tile(candidate, serial) for role, serial, candidate in sorted(candidates)]
        blocks.append('<div class="sr-tile-row"><h4><a href="#' + _e(prefix) + '-root-line-' + str(row) + '">Root line ' + str(row + 1) + '</a></h4><div class="sr-tiles">' + ''.join(cards) + '</div></div>')
    return '<p>These are actual selected factored point placements, arranged by their recorded proof-row role. Positive occupancy is ' + _math('12/12=1') + ' at the recorded support point. All exact marking assignments remain expandable.</p><p class="sr-small">The square is a display glyph, not an ordinary Wang square with edge matching. Colored dots summarize formula, command, mode and source-index point layers. No rotation, geometric edge rule or primitive-body inlining is implied.</p><div class="sr-legend"><span><i style="background:#25845b"></i>formula words</span><span><i style="background:#2865a5"></i>command words</span><span><i style="background:#8b52a5"></i>mode values</span><span><i style="background:#b5771a"></i>source indices</span></div>' + ''.join(blocks)


def _definition_sections(inventory, observations, labels, prefix):
    definitions = {d['name']: d for d in inventory.get('native_blocks', [])}
    metadata = {d['name']: d for d in inventory.get('definitions', [])}
    summaries = observations.get('ground_definition_summaries', {})
    sections = []
    for name, label in labels.items():
        definition = definitions[name]
        meta = metadata.get(name, {})
        args = meta.get('arguments', [])
        bindings = ''.join('<tr><td>' + str(i) + '</td><td>' + _f(argument) + '</td></tr>' for i, argument in enumerate(args))
        premise_list = ''.join('<li>' + _f(a) + '</li>' for a in definition['premises'])
        detail = '<p>Literal registry name ' + _code(name) + '.</p><p>Family ' + _code(meta.get('family', 'not retained')) + '; recorded level ' + _code(meta.get('level', 'not retained')) + '.</p>'
        if bindings:
            detail += '<table><thead><tr><th>Source parameter slot</th><th>Actual ground formula binding</th></tr></thead><tbody>' + bindings + '</tbody></table>'
        detail += '<p>Declared local premise ports:</p>' + ('<ol>' + premise_list + '</ol>' if premise_list else '<p>None.</p>')
        detail += '<p>Declared conclusion: ' + _f(definition['conclusion']) + '.</p>'
        essential = summaries.get(name, {}).get('essential_rows')
        detail += _proof_table(definition['proof'], label['anchor'], definition['premises'], definitions, labels, essential)
        detail += _details('Literal registered definition and metadata', dict(definition=definition, metadata=meta))
        sections.append('<details id="' + _e(label['anchor']) + '" class="sr-definition"><summary>' + _e(label['label']) + ': ' + _f(definition['conclusion']) + '</summary>' + detail + '</details>')
    return ''.join(sections)


def _hint_summary(observation):
    if not observation:
        return '<p>No winning-path family-hint observation was returned.</p>'
    links = observation.get('links', [])
    rows = []
    for link in links:
        rows.append('<tr><td>' + str(link['row'] + 1) + '</td><td>' + _code(link['hint_id']) + '</td><td>' + _code(link['family']) + '</td><td>' + _e(link['nonidentity']) + '</td><td>' + _e(link['compound_argument_indices']) + '</td><td>' + _e(link['full_hint_members_on_winning_path']) + '</td><td>' + _e(link['exact_ordered_input_sources']) + '</td><td>' + _e(link['changed_original_order']) + '</td></tr>')
    return '<p>Recorded observer status: ' + _code(observation.get('status')) + '. Same-instance family-hint use: ' + _code(observation.get('strong_family_hint_use')) + '; preference changed original order: ' + _code(observation.get('changed_order_family_hint_use')) + '.</p><p class="sr-small">These are driver observations, not independent checking or evidence of speed benefit. Root-row hint use is separate from nested definition calls.</p>' + ('<div class="sr-scroll"><table><thead><tr><th>Root line</th><th>Hint</th><th>Family</th><th>Nonidentity</th><th>Compound argument slots</th><th>Full row selected</th><th>Exact ports</th><th>Order changed</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div>' if rows else '')


def render_result(data, mode_label, *, raw_href=None):
    """Return one HTML fragment. Never imports/runs a model, prover or checker.

    raw_href, if supplied by the enclosing admitted report, links the complete
    retained JSON; otherwise an internal link exposes the full literal final
    request/proof. The enclosing page must load its established MathJax setup.
    Structural display errors raise RenderDataError, not a proof rejection.
    """
    if type(data) is not dict or data.get('schema') != INPUT_SCHEMA:
        raise RenderDataError('exact semantic receiver result schema required')
    if type(mode_label) is not str or len(mode_label) > 256:
        raise RenderDataError('finite report mode label required')
    if raw_href is not None:
        if type(raw_href) is not str or any(ord(c) < 32 for c in raw_href) or urlsplit(raw_href).scheme not in ('', 'https', 'http'):
            raise RenderDataError('raw result link must be report-owned ordinary URL')
    prefix = 'semantic-proof-' + hashlib.sha256((mode_label + '\0' + data.get('mode', '') + '\0' + data.get('declaration', {}).get('id', '')).encode()).hexdigest()[:16]
    outputs = data.get('outputs', {})
    search = outputs.get('search', {})
    inventory = outputs.get('register', {})
    observation = outputs.get('essential_ancestry', {})
    hint = outputs.get('winning_hint_links', {})
    definitions = inventory.get('native_blocks', [])
    labels = {d['name']: dict(label='Definition ' + str(i + 1), anchor=prefix + '-definition-' + str(i + 1)) for i, d in enumerate(definitions)}
    if len(labels) != len(definitions):
        raise RenderDataError('duplicate retained definition name')
    definition_map = {d['name']: d for d in definitions}
    raw_anchor = prefix + '-literal-proof'
    raw_link = '<a href="' + _e(raw_href if raw_href is not None else '#' + raw_anchor) + '">' + ('Full raw result' if raw_href is not None else 'Full raw proof') + '</a>'
    native_status = outputs.get('final_native', {}).get('result', {}).get('status', 'no final native record')
    recorded_success = data.get('status') == 'native_proof_discovered' and data.get('native_proof_accepted') is True and native_status == 'accepted'
    state_label = 'Recorded fresh native acceptance; report admission remains external.' if recorded_success else 'Retained candidate or unfinished result; no accepted-proof claim is made here.'
    declaration = data.get('declaration', {})
    target = declaration.get('target')
    style = '''<style>.sr-reader{font:16px/1.5 system-ui,sans-serif;color:#173047}.sr-reader table{border-collapse:collapse;width:100%}.sr-reader th,.sr-reader td{border-bottom:1px solid #ccd8e1;padding:.6rem;vertical-align:top;text-align:left}.sr-reader .sr-proof>tbody>tr.sr-essential{background:#edf6ef}.sr-reader .sr-proof>tbody>tr:target{outline:2px solid #377cb0}.sr-reader .sr-badge{font-size:.72rem;background:#d8ebda;border-radius:.2rem;padding:.12rem .3rem}.sr-reader .sr-muted,.sr-reader .sr-small{font-size:.86rem;color:#556c7b}.sr-reader .sr-notice{padding:1rem;border-left:4px solid #b47b20;background:#fff4da}.sr-reader details{margin:.5rem 0}.sr-reader pre{overflow:auto;max-height:28rem;white-space:pre-wrap;word-break:break-word;background:#f3f6f8;padding:.8rem;font-size:.8rem}.sr-reader code{font-size:.82em;word-break:break-all}.sr-reader .sr-tiles{display:flex;flex-wrap:wrap;gap:.65rem;align-items:start}.sr-reader .sr-tile{border:1px solid #c4d1dc;border-radius:.35rem;padding:.45rem;min-width:95px;max-width:100%}.sr-reader .sr-tile>summary{cursor:pointer;display:flex;flex-direction:column;align-items:center;max-width:125px;font-size:.8rem}.sr-reader .sr-tile svg{width:92px;height:92px}.sr-reader .sr-tile[open]{flex-basis:100%}.sr-reader .sr-dot,.sr-reader .sr-legend i{display:inline-block;width:.65rem;height:.65rem;border-radius:50%;margin-right:.3rem}.sr-reader .sr-legend{display:flex;gap:1rem;flex-wrap:wrap}.sr-reader .sr-tile-row{padding:.4rem 0;border-bottom:1px solid #ccd8e1}.sr-reader .sr-scroll{overflow:auto}.sr-reader h3{margin-top:1.6rem}.sr-reader .sr-definition{border:1px solid #c4d1dc;padding:.7rem}</style>'''
    body = ['<section class="sr-reader" id="' + prefix + '">', style,
            '<h2>' + _e(mode_label) + ': the recorded proof, line by line</h2>',
            '<p class="sr-notice">' + _e(state_label) + ' This is a data projection by the driver author, not an independent checker. Native mathematical validity and Root resource/admission evidence are supplied separately.</p>',
            '<p>Status ' + _code(data.get('status')) + '; mode ' + _code(data.get('mode')) + '; final native disposition ' + _code(native_status) + '. ' + raw_link + '.</p>']
    axioms = declaration.get('theory', {}).get('axioms', {})
    if axioms:
        given = ''.join('<tr><td>' + _code(name) + '</td><td>' + _f(formula) + '</td></tr>' for name, formula in sorted(axioms.items()))
        body.append('<h3>Given theory premises</h3><table><thead><tr><th>Literal name</th><th>Declared formula</th></tr></thead><tbody>' + given + '</tbody></table>')
    if target is not None:
        body.append('<p>Declared target: ' + _f(target) + '.</p>')
    proof = search.get('proof')
    if proof is not None:
        body.append('<h3>Root command rows</h3><p>Display line numbers are one-based; literal command indices remain unchanged in the expandable JSON. Green highlighting comes from the retained driver essential-ancestry observation.</p>')
        body.append(_proof_table(proof, prefix + '-root', [], definition_map, labels, observation.get('root', {}).get('essential_rows')))
        body.append('<h3>Actual selected C/G/input point rows</h3>')
        body.append(_tile_rows(search, outputs.get('model'), prefix))
    else:
        body.append('<p>No selected proof was returned. No proof lines or placements have been invented for this status.</p>')
    if definitions:
        body.append('<h3>Retained registered lemma bodies</h3><p>Inventory disposition: ' + _code(inventory.get('status')) + '. Each table is the exact stored primitive body under its declared local assumptions. A high-level block call is not physical placement of those primitive rows on the point board.</p>')
        body.append(_definition_sections(inventory, observation, labels, prefix))
    body.append('<h3>Family use and preference observations</h3>' + _hint_summary(hint))
    if observation:
        body.append(_details('Full essential root/nested-call and recursive-use observation', observation))
    raw = outputs.get('final_request')
    if raw is None:
        raw = dict(retained_candidate_proof=proof, target=target, inventory_status=inventory.get('status'))
    body.append('<details id="' + raw_anchor + '"><summary>Full literal retained proof request or candidate</summary><pre>' + _e(_json(raw)) + '</pre></details>')
    body.append('<p class="sr-small">Renderer ' + _code(VERSION) + '. No model import, proof replay, hidden derivation, invented intermediate formula or independent proof/resource admission is performed.</p></section>')
    fragment = ''.join(body)
    if len(fragment.encode('utf-8')) > MAX_FRAGMENT_BYTES:
        raise RenderDataError('complete renderer fragment exceeds32MiB; no truncated proof view returned')
    return fragment
