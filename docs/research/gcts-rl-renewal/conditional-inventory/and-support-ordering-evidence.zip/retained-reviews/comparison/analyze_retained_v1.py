from pathlib import Path
import collections,gc,hashlib,json

D=Path('/private/tmp/gcts-and-support-comparison-peer-20261018')
R=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active')
P=Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1')
checks=[]
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def ck(n,x):
 checks.append(dict(check=n,passed=bool(x)))
 if not x:raise AssertionError(n)
def emit(n,x):
 p=D/n;p.write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n');return desc(p)
C=R/'and-support-ordering-progress-20261018/ROOT-cohort-closure-v1.json'
ck('exact Root closed cohort pin',desc(C)['sha256']=='d3e3c078bda2c11584bb76157d827f86085ee8d4355d7fe5b95f98dfc8368654')
closed=json.loads(C.read_bytes());idx=json.loads((P/'authorized-index-v1.json').read_bytes())
ck('exact final authorized index',desc(P/'authorized-index-v1.json')['sha256']=='81a907b726aad1febb9b6781f7eadac519aeba6c073dd6dfade7cc5d03fdff33')
ck('all4 closed before this read',closed['retained_actuals']==4 and closed['all_agents_idle_during_measurement'] is True and closed['all_terminal_gates_passed'] is True)
records=[];proofs={};point_first_contexts={};graph_words=[];stable=[]
for row,crow in zip(idx['schedule'],closed['actuals']):
 iid=row['invocation_id'];base=Path(row['actual_directory'])
 ck(iid+' closure order literal',iid==crow['invocation_id'])
 for k in ('runner_receipt','worker_receipt','terminal','consumed'):ck(iid+' raw '+k,desc(crow[k]['path'])==crow[k])
 w=json.loads(Path(crow['worker_receipt']['path']).read_bytes());rr=json.loads(Path(crow['runner_receipt']['path']).read_bytes());t=json.loads(Path(crow['terminal']['path']).read_bytes())
 ck(iid+' exact full raw result',desc(w['result']['path'])==w['result'])
 data=json.loads(Path(w['result']['path']).read_bytes());s=data['outputs']['search'];inv=data['outputs']['register'];model=data['outputs']['model']
 ck(iid+' literal identities',data['mode']==row['mode'] and data['search_ordering']==row['search_ordering'] and data['receiver_id']==row['receiver_id'])
 ck(iid+' common complete admitted model',data['outputs']['compile']['status']=='complete' and inv['status']=='native_accepted' and model['arity']==3 and len(model['placements'])==11440 and len(inv['interfaces'])==8 and len(inv['definitions'])==8)
 ck(iid+' recorded profile and terminal candidate gates',rr['resource_candidate_accepted'] is True and t['terminal_gate_passed'] is True and rr['python_exit_code']==0)
 ck(iid+' no late Root mathematical selfadmission',rr['ROOT_resource_accepted'] is False and rr['mathematical_proof_accepted'] is False)
 stable.append({k:data[k] for k in ('model_identity_sha256','compiled_semantics_sha256','inventory_semantics_sha256')})
 durations={a['stage']:a['returned_monotonic']-a['started_monotonic'] for a in data['stage_intervals']}
 record=dict(invocation_id=iid,mode=row['mode'],search_ordering=row['search_ordering'],raw_result=w['result'],worker_receipt=crow['worker_receipt'],runner_receipt=crow['runner_receipt'],terminal=crow['terminal'],
  status=data['status'],native_proof_recorded=data['native_proof_accepted'],family_hint_success_recorded=data['family_hint_success'],quantified_reasoning_success_recorded=data['quantified_reasoning_success'],
  search_status=s['status'],search_seconds=s['seconds'],search_metrics=s['metrics'],search_reason=s.get('reason'),preparation_seconds=s.get('preparation_seconds'),enumeration_and_return_seconds=s.get('enumeration_and_return_seconds'),
  root_restored=s.get('root_restored',s.get('root_path_restored')),native_records=len(data['records']),events=len(s['events']),hints=len(s.get('hints',[])),stage_durations_seconds=durations,
  conservative_worker_plus_native_MiB=rr['conservative_parent_plus_native_peak_bytes']/1048576,
  Source_entry_to_external_terminal_seconds=t['runner_clock_elapsed_seconds'],observer_instrument_elapsed_seconds=t['observed_instrument_elapsed_seconds'],
  serialization_to_preflight_seconds=w['driver_output_receipt']['output']['serialization_to_preflight_seconds'],
  result_reading_seconds=(w['result_reading']['completed_ns']-w['result_reading']['started_ns'])/1e9,
  common_model=dict(arity=model['arity'],placements=len(model['placements']),required_roots=len(model['roots']),definitions=len(inv['definitions']),interfaces=len(inv['interfaces']),source_families=len({d['family'] for d in inv['definitions']})),
  terminal_profile_candidate=True,ROOT_mathematical_acceptance=False)
 if row['mode']=='fixed':
  point_first_contexts[row['search_ordering']]=[dict(point=e['point'],chosen=e['chosen'],items=e['items'],index=e['index']) for e in s['events'][:4]]
  record['hint_kind_counts']=dict(collections.Counter(h['item']['kind'] for h in s['hints']))
 if row['search_ordering']=='and_support':
  sm=s['support_ordering_metadata'] if row['mode']=='fixed' else s['support_ordering'];g=sm['graph'];graph_words.append(canon(g['graph_preimage']))
  record['support_graph']=dict(graph_sha256=g['graph_sha256'],status=g['status'],counts=g['counts'],formulas=len(g['graph_preimage']['formulas']),edges=len(g['graph_preimage']['edges']))
  ck(iid+' complete common support graph',g['status']=='COMPLETE' and len(g['graph_preimage']['formulas'])==13 and len(g['graph_preimage']['edges'])==25)
  if row['mode']=='fixed':
   choices=[]
   for e in s['events']:
    choice=e['support_ordering'];rank=choice['ranking'];selected_position=next(j for j,o in enumerate(rank['options']) if o['option_id']['original_item_index']==choice['selected_index']);legacy_position=next(j for j,o in enumerate(rank['options']) if o['option_id']['original_item_index']==choice['legacy_index'])
    selected_score=rank['distinct_output_scores'][rank['option_scores'][selected_position]['score_id']];legacy_score=rank['distinct_output_scores'][rank['option_scores'][legacy_position]['score_id']]
    ck(iid+' scorecall'+str(e['id'])+' complete multiplicity/no fallback',choice['status']=='SCORED' and sorted(choice['after_order'])==list(range(len(e['items']))) and rank['status']=='SCORED')
    choices.append(dict(event=e['id'],point=e['point'],chosen_prefix=e['chosen'],legacy_index=choice['legacy_index'],selected_index=choice['selected_index'],changed=choice['legacy_index']!=choice['selected_index'],
      selected_kind=None if e['items'][choice['selected_index']] is None else e['items'][choice['selected_index']]['kind'],
      original_scores=choice['original_policy_scores'],target_cost_before=selected_score['target_cost_before'],selected_target_cost_after=selected_score['target_cost_after'],legacy_target_cost_after=legacy_score['target_cost_after'],
      selected_projected_rows=rank['options'][selected_position]['rows'],legacy_projected_rows=rank['options'][legacy_position]['rows'],
      added_formulas=[g['graph_preimage']['formulas'][j]['formula'] for j in selected_score['added_formula_ids']],
      base_justification=rank['base_justification'],selected_justification=rank['option_scores'][selected_position]['projected_justification'],
      projection=choice['projection'],ranking_counts=rank['counts']))
   record['support_choices']=choices;record['graph_seconds']=sm['graph_seconds'];record['ranking_copy_nodes']=sum(e['support_ordering']['ranking']['counts']['copy_nodes'] for e in s['events'])
  else:
   calls=[]
   for k,c in enumerate(sm['ranking_calls']):
    ranking=c['ranking'];first=ranking['order'][0];score=ranking['distinct_output_scores'][ranking['option_scores'][first]['score_id']]
    ck(iid+' window'+str(k)+' complete no fallback',c['complete_window'] is True and ranking['status']=='SCORED' and sorted(ranking['order'])==list(range(len(c['candidates']))))
    calls.append(dict(row=c['row'],candidate_count=len(c['candidates']),source_iterator_exhausted=c['source_iterator_exhausted'],selected_original_window_index=first,
      selected_candidate=c['candidates'][first],selected_differs_from_first=first!=0,
      target_cost_before=score['target_cost_before'],target_cost_after=score['target_cost_after'],counts=ranking['counts']))
   record['support_windows']=calls;record['support_metrics']=sm['metrics'];record['support_total_work']=sum(c['ranking']['counts']['work'] for c in sm['ranking_calls']);record['support_total_copy_nodes']=sum(c['ranking']['counts']['copy_nodes'] for c in sm['ranking_calls'])
 if s['proof'] is not None:
  proof=s['proof'];ob=data['outputs']['essential_ancestry'];links=data['outputs']['winning_hint_links'];final=data['outputs']['final_request'];n=data['outputs']['final_native']
  ck(iid+' exact final proof/target/whole native record literal',final['proof']==proof and final['target']==data['declaration']['target'] and n['request']==final and data['records'][n['id']]==n and n['result']['status']=='accepted')
  ck(iid+' full12root rows and60 point keys',len(proof)==12 and len(s['placements'])==60)
  ck(iid+' recorded essential quantifier3UI1GEN',ob['essential_instantiate_count']==3 and ob['essential_generalize_count']==1)
  ck(iid+' three essential level1 nonidentity family calls',len(ob['essential_calls'])==3 and all(c['level']==1 and c['nonidentity'] is True and len(c['path'])==1 for c in ob['essential_calls']))
  definitions={d['name']:d for d in inv['definitions']}
  used=[dict(row=j,command=c,ground_definition=definitions[c['name']]) for j,c in enumerate(proof) if c['rule']=='block']
  essence=dict(essential_rows=ob['root']['essential_rows'],essential_calls=ob['essential_calls'],essential_root_summary=ob['root'],essential_UI=ob['essential_instantiate_count'],essential_GEN=ob['essential_generalize_count'],
    winning_hint_links=links,full_root_rule_counts=dict(collections.Counter(c['rule'] for c in proof)),nonessential_rows=[j for j in range(len(proof)) if j not in ob['root']['essential_rows']])
  proofs[row['mode']]=dict(raw_result=w['result'],proof=proof,essential_observation=essence,used_root_blocks=used,final_request=final,final_native_record_id=n['id'],final_native_result=n['result'],
   current_ground_registry=inv['definitions'],native_body_scope='Literal returned rows/bodies and recorded acceptance only; no independent logical replay or renderer execution.')
  record['proof_summary']={k:v for k,v in essence.items() if k!='winning_hint_links'}
  record['winning_hint_summary']=dict(status=links['status'],strong=links['strong_family_hint_use'],changed=links['changed_order_family_hint_use'],member_links=len(links['links']),
    changed_branch_links=[{k:l[k] for k in ('row','name','family','hint_id','key','path_depth','selection_kind','changed_original_order')} for l in links['links'] if l['selection_kind']=='branch' and l['changed_original_order']])
 records.append(record)
 del data,s;gc.collect()
ck('full model/compiler/inventory semantics identical all4',all(x==stable[0] for x in stable))
ck('full shared support graph preimages literally equal across point/control',len(graph_words)==2 and graph_words[0]==graph_words[1])
ck('same physical first3 Join advice contexts before divergence',all(point_first_contexts['legacy'][i]==point_first_contexts['and_support'][i] for i in range(3)))
old4=point_first_contexts['legacy'][3];new4=point_first_contexts['and_support'][3]
ck('fourth advice exact common context andpool but newchoice',all(old4[k]==new4[k] for k in ('point','chosen','items')) and old4['index']==9 and new4['index']==6)
raw=emit('retained-comparison-data-v1.json',dict(schema='and-support-retained-comparison-data-v1',retained_data_only=True,scientific_replays=0,native_calls=0,scientific_acceptance=False,
 root_closed_cohort=desc(C),authorized_index=desc(P/'authorized-index-v1.json'),same_semantic_identity=stable[0],full_graph_preimages_equal=True,records=records,proofs=proofs,
 first_point_advice_divergence=dict(event=3,exact_same_context_and_pool=True,legacy_index=old4['index'],support_index=new4['index']),checks=checks,check_count=len(checks),mismatches=0))
sources={
 'helper':desc('/private/tmp/gcts-and-support-ordering-source-20261018/receptor_support_ordering_v1.py'),
 'symbolic':desc('/private/tmp/gcts-and-support-ordering-source-20261018/quantified_symbolic_control_v2.py'),
 'point':desc('/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py'),
 'driver':desc('/private/tmp/gcts-and-support-cold-source-20261018/and_support_receiver_driver_v1.py'),
 'historical_policy':desc('/private/tmp/gcts-semantic-family-next-audit-20261018/semantic-inventory-policy-001.json')}
analysis=dict(schema='and-support-retained-comparison-analysis-v1',analysis_completed=True,retained_data_only=True,source_inspection_only=True,scientific_replays=0,scientific_calls=0,native_calls=0,scientific_acceptance=False,
 author_identity='/root/conventional_library',subject_authors=['/root','/root/conventional_control_review','/root/receiver_driver_review','/root/conventional_library'],
 source_ancestry='I authored the point successor and old quantified/compact Models/driver bridge, and reviewed coupling/plans/grants. This is Source-informed saved-data interpretation, not independent certification of own Source or Native checking. Independent current implementation peer84c4 remains separate.',
 root_closed_cohort=desc(C),authorized_index=desc(P/'authorized-index-v1.json'),retained_data=raw,sources=sources,
 implementation_peer=desc('/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json'),
 conclusion='A substantive automated proof-search milestone on one familiar development assertion: both unchanged-palette shared-support treatments returned fresh Native-accepted proof records; both legacy controls returned UNKNOWN within their different search stops. Actual parameterized registry families were consumed. The gain is evidence for the shared joint-premise support heuristic, not for a GCTS-specific advantage.',
 formula='\\forall x(P(x)\\to(Q(x)\\to R(x))),\\quad\\forall xP(x),\\quad\\forall xQ(x)\\quad\\vdash\\quad\\forall xR(x)',
 precise_comparison=[{k:r[k] for k in ('mode','search_ordering','status','search_seconds','search_metrics','Source_entry_to_external_terminal_seconds','conservative_worker_plus_native_MiB','native_records','serialization_to_preflight_seconds','result_reading_seconds')} for r in records],
 interpretation=[
  'Point support consumed exactly60 base placements,18 genuine branches and42 forced placements, with no backtracking; these are the five fixed C/G/I roles across12rows. Symbolic support consumed12 complete chronological row extensions with no backtracking. The two counters are not comparable work units.',
  'Both proof records have three target-essential root calls from two automatically extracted historical formula-template families: one MP instance and two different two-hop instances. Actual arguments include quantified and implication formulas, so this is nonidentity compound-formula transfer. No essential nested/dependent family or fresh family promotion occurred.',
  'Both recorded essential primitive cores count3axioms,3UI licences,5MP uses and1GEN=12 primitives after excluding assumption rows and irrelevant padding. Full selected root words contain12high-level rows; full recursive primitive counts differ14symbolic/15point because nonessential rows remain. Do not call them shortest/minimal proofs.',
  'Point has11 scored support choices,6 differ from the old FIXED preferred hint at those same contexts; all original pool items and primitive alternatives were retained. Actual first divergence event3 has an identical prefix/pool: old9 vs support6. Its old projected P-body option has target potential7, while the UI-Q licence reduces7to6. Later curried source/licence and actual closed block rows reduce joint support to a proved target.',
  'Point event9 is row-sensitive: old actual complete target row11 reads source10, which is missing; completing row10 with an R body re-justifies row11. Merely having R at row8 is insufficient for that selected ordered source. This is recursively justified complete-row credit, not guard-only promotion or new multirow proposal generation.',
  'Point winning-hint observations link three essential exact family instances to actual selected constituent placements, with changed canonical alternative order on three branch links. Six support-changed hint choices is a different statistic and includes useful primitive advice and a nonessential block atrow8; it is not six essential lemmas.',
  'Symbolic support also solves, with recorded search0.1747s vs point1.5601s on this run. Shared semantic guidance succeeds in a specialized chronological control as well as the factored point engine. This supplies no evidence that the geometric scheduler is uniquely responsible or faster.',
 ],
 overhead=[
  'All four arms freshly paid complete Native compiler catalog (~15.3–16.2s), all-interface registry (~10.5–11.4s), common complete Model (~1.54–1.72s), source/custody/initial/model-identity work and full output/Reader inverse. Successful arms additionally paid fresh final Native checking (~9.94–10.64s). These are observed stage intervals, not exclusive allocation/profiling measures.',
  'Point support graph construction reports0.002150625s/113semantic operations/3169copy nodes; full graph has13formula nodes25edges. Eleven ranking calls report14412ranking work operations; point row projection109209structural-copy/key/role operations and167fresh aggregate checks. Full proposal_seconds0.669967749 includes Join/features/aggregate/rank/event work; it is not an exclusive support-only timing.',
  'Symbolic support preparation0.11488475s includes intake/grammar/legacy priority and graph construction; no exclusive graph/rank wall timer exists there. Total search0.17472675s includes all support cost. Twelve scored complete windows prefetched133legal candidates, with no fallback. Compare ranking windows to point Join pools only as distinct application domains.',
  'Source-entry terminal cost is137.1575s pointlegacy UNKNOWN,53.4545s symbolic support proof,49.8984s symboliclegacy UNKNOWN,61.9046s point support proof. UNKNOWN terminal times do not establish time-to-proof speedups. No statistical speed ratio is warranted from one observation perarm.',
  'Large trace retention matters: pointlegacy raw output83.85MB/33.80s serialization-to-preflight vs point support41.73MB/5.87s. This cost is part of full cold outcome; lower trace volume follows fewer traversed nodes and is not a separate storage intervention.',
 ],
 mechanism=dict(joint_support='Positive-cost AND relaxation uses all ordered premises together and current fully recursively justified row seeds. Unseeded cycles cannot supply themselves. Zero-read UI/EQ edges supply only their actual implication licence formula.',
  scoring_scope='Row/macro cost one is a heuristic abstraction. It ignores sharing/capacity and recursive primitive cost; not an admissible lower bound or proof authority.',
  unchanged='Full4historical templates,8native-admitted ground definitions,13basis formulas,11440placements,arity3,60root points,12rows/two UI catalog rounds, complete original candidate universes and current Native rules retained.',
  provenance='Historical policy declares fresh searched donor proofs/ground Native checking and saved training. Current fixed arms use literal FIXED weights; current shared support is a hand-designed deterministic Source algorithm, with no new RL update or family mining in this cohort.'),
 next_research_step=dict(status='RECOMMENDED_NOT_AUTHORIZED_OR_EXECUTED',
  action='Freeze these exact strategies and evaluate the already predeclared10case/eightgroup input suite with the same four arms and complete per-case admission/cost reporting; no c3 retuning or case deletion.',
  endpoints='Fresh complete native+point+wholeprofile proof success; distinct point/symbolic counters; all UNKNOWN/capacity/output/memory failures; cold time and Native/compile/registration costs; exact target-essential compound family reuse and winning-path family-hint links.',
  stop_rule='Treat current c3 as development. Do not use new-suite outcomes for tuning until cohort closure; any tuned case/group becomes development and needs fresh evaluation.',
  later_ablation='A separately predeclared family-use/primitive-expansion ablation is needed to attribute speed specifically to macro reuse rather than shared ordering. Current essential use proves participation, not necessity or acceleration. Do not silently alter the all-template universe in these four arms.',
  hierarchy='Keep multirow closure/new lemma promotion/RL deferred until this frozen ordering receives broader evidence. Level2family matching/promotion remains a separate unproved search milestone.'),
 limitations=[
  'One authored, familiar c3 development assertion, one fresh observation perarm, fixed order. Not blinded/representative/official TPTP/CASC comparison and not statistical generalization.',
  'Raw retained JSON and Source only; no helper score recomputation, proof/kernel/native replay, renderer or solver execution. Native acceptance and essentiality are recorded evidence; independent saved-data/math/resource admission remains Root/other peers.',
  'Point authorship and parent-adapter authorship disclosed; no own Source certificate. Full raw proof bodies and trace pointers retained, no fabricated proof rows.',
  'No GCTS superiority, newly trained RL, learned marking, new universal Wang palette, fullFOL completeness, PA induction or Hilbert geometry achievement follows.',
  'All profile flags/initial Instrument ROOT_admission=false remain untouched in raws; this analysis does not itself promote mathematical or resource acceptance.',
 ],
 check_count=len(checks),mismatches=0)
analysis_pin=emit('typed-comparison-analysis-v1.json',analysis)
handoff=emit('handoff-v1.json',dict(schema='and-support-comparison-handoff-v1',analysis=analysis_pin,retained_data=raw,scientific_calls=0,scientific_replays=0,scientific_acceptance=False))
print(json.dumps(dict(analysis=analysis_pin,retained_data=raw,handoff=handoff,checks=len(checks),science=0)))
