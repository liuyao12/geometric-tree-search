"""Narrow saved winning-path/event joins; no scientific/project evaluation."""
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).parent
def raw(p):
    p=Path(p)
    if p.stat().st_flags&0x40000000:raise ValueError('no dataless read')
    return p.read_bytes()
def load(p):return json.loads(raw(p))
def pin(p):
    b=raw(p);return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def emit(name,x):
    q=OUT/name
    if q.exists():raise ValueError('preserve versioned peer')
    q.write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False)+'\n');return pin(q)
checks=[]
def check(ok,label):
    checks.append(dict(check=label,passed=bool(ok)))
    if not ok:raise ValueError(label)

prior=load(OUT/'typed-data-review-v1.json')
point=next(a for a in prior['actuals'] if a['mode']=='fixed' and a['search_ordering']=='and_support')
x=load(point['result']['path']);s=x['outputs']['search'];keys=s['placements'];node=s['tree'];path=[]
for depth,key in enumerate(keys):
    children=[c for c in node['children'] if c['key']==key]
    if len(children)!=1:raise ValueError('actual selected path child')
    path.append(node);node=children[0]['tree']
check(node['kind']=='empty' and len(path)==len(keys),'full retained winning tree path matches all selected keys and empty leaf')
for hint in s['hints']:
    starts=[(depth,n) for depth,n in enumerate(path) if n.get('hint_start')==hint['id']]
    if len(starts)!=1:raise ValueError('hint unique actual path start')
    depth,n=starts[0];event=s['events'][n['policy_event']]
    assert event['items'][event['index']]==hint['item'] and event['chosen']==keys[:depth]==hint['chosen']
    assert n['kind']=='branch' and all(k in keys for k in hint['item']['members'])
check(True,'all11 actual hint starts join current policy event/item and full selected prefix/members')
links=x['outputs']['winning_hint_links']['links'];joined=[]
for link in links:
    n=path[link['path_depth']];hint=s['hints'][link['hint_id']]
    assert keys[link['path_depth']]==link['key'] and link['key'] in hint['item']['members']
    assert n['kind']==link['selection_kind'] and n.get('hint_start',n.get('hint_in'))==hint['id']
    census=next(c for c in n['census'] if c['point']==n['point'])
    assert sorted(census['keys'])==link['original_order'] and n['alternatives']==link['preferred_order']
    starts=[n0 for n0 in path if n0.get('hint_start')==hint['id']]
    event=s['events'][starts[0]['policy_event']];order=event['support_ordering']
    joined.append(dict(row=link['row'],hint_id=hint['id'],policy_event=event['id'],
        root_call_name=link['name'],selected_key=link['key'],depth=link['path_depth'],
        graph_alternative_order_changed=link['changed_original_order'],
        support_changed_hint_choice=order['selected_index']!=order['legacy_index'],
        selected_hint_index=order['selected_index'],legacy_hint_index=order['legacy_index']))
check(True,'all15 essential-family link keys/active hints/current census/alternatives and policy events joined')
essential_rows=sorted({j['row'] for j in joined})
changed_rows=sorted({j['row'] for j in joined if j['support_changed_hint_choice']})
point_change=dict(all_ranking_permutations_changed=sum(e['support_ordering']['after_order']!=e['support_ordering']['legacy_order'] for e in s['events']),
    actual_selected_hint_choices_changed=sum(e['support_ordering']['selected_index']!=e['support_ordering']['legacy_index'] for e in s['events']),
    graph_alternative_links_changed=sum(j['graph_alternative_order_changed'] for j in joined),
    essential_root_rows=essential_rows,essential_rows_with_changed_hint_choice=changed_rows,
    links=joined)
del x,s,node,path
symbolic=next(a for a in prior['actuals'] if a['mode']=='symbolic' and a['search_ordering']=='and_support')
x=load(symbolic['result']['path']);s=x['outputs']['search'];r=s['support_ordering']['ranking_calls']
check([e['row'] for e in s['events'] if e['action']=='winning_candidate_path']==list(range(len(s['proof']))) and len(s['events'])==len(s['proof']),'all symbolic recorded extensions are the literal winning word, no discarded candidate path')
check(all(call['candidates'][call['ranking']['order'][0]]==s['candidate_rows'][i] and call['complete_window'] is True and call['source_iterator_exhausted'] is True for i,call in enumerate(r)),'every selected symbolic candidate joins full natural-tail ranked window')
symbolic_change=dict(full_window_permutations_changed=sum(call['ranking']['order']!=list(range(len(call['candidates']))) for call in r),
    selected_first_candidates_changed=sum(call['ranking']['order'][0]!=0 for call in r),
    changed_first_candidate_rows=[call['row'] for call in r if call['ranking']['order'][0]!=0],
    complete_windows=len(r),prefetched_candidates=sum(len(call['candidates']) for call in r),
    interruption_gaps_observed=False)
addendum=emit('winning-path-join-addendum-v1.json',dict(schema='and-support-saved-path-join-addendum-v1',reviewer_identity='/root/receiver_driver_review',retained_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,parent_review=pin(OUT/'typed-data-review-v1.json'),raw_results=[point['result'],symbolic['result']],checks=checks,check_count=len(checks),findings=[],point=point_change,symbolic=symbolic_change,scope='Direct additional saved-path/event/census/option joins only. Changed whole-pool permutation, changed selected hint, changed geometric incident order and essential ancestry are different counts. No counterfactual rerun, uniqueness/necessity/causal-speed or Native recheck.'))
current=dict(prior)
current.update(metadata_revision=2,parent_review=pin(OUT/'typed-data-review-v1.json'),winning_path_join_addendum=addendum,checks=prior['checks']+len(checks),winning_path_findings=dict(point=point_change,symbolic=symbolic_change))
review=emit('typed-data-review-v2.json',current)
handoff=emit('handoff-v2.json',dict(schema='and-support-retained-data-peer-handoff-v2',review=review,parent_review=pin(OUT/'typed-data-review-v1.json'),audit=prior['audit'],path_join_addendum=addendum,data_review_passed=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False))
print(json.dumps(dict(review=review,addendum=addendum,handoff=handoff,point_counts={k:v for k,v in point_change.items() if k!='links'},symbolic_counts=symbolic_change),sort_keys=True))
