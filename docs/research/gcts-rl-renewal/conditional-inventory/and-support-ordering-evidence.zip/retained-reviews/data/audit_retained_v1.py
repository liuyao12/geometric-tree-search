"""Stdlib saved-data audit only; no project/Native/search/helper evaluation."""
import collections
import gc
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).parent
REPO=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
INDEX=Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1/authorized-index-v1.json')
CLOSURE=REPO/'.gcts-active/and-support-ordering-progress-20261018/ROOT-cohort-closure-v1.json'
OLD=REPO/'.gcts-active/structural-quantified-c3-fixed-ROOT-20261018-v1/result.json'
ROOT_ADMISSION=REPO/'.gcts-active/and-support-ordering-progress-20261018/ROOT-actual-admission-v1.json'
checks=[];pins={};arms=[];telemetry=[]

def check(ok,label):
    checks.append({'check':label,'passed':bool(ok)})
    if not ok:raise ValueError(label)

def raw(p):
    p=Path(p)
    if p.stat().st_flags&0x40000000:raise ValueError('no dataless read: '+str(p))
    return p.read_bytes()

def pin(p):
    p=Path(p);info=p.stat()
    if info.st_flags&0x40000000:raise ValueError('no dataless hash: '+str(p))
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        while True:
            b=f.read(1048576)
            if not b:break
            n+=len(b);h.update(b)
    d=dict(path=str(p),sha256=h.hexdigest(),bytes=n);pins[str(p)]=d;return d

def load(p):return json.loads(raw(p))
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(x):return hashlib.sha256(canonical(x)).hexdigest()
def verified(d):
    actual=pins.get(d['path']) or pin(d['path'])
    check(actual=={k:d[k] for k in ('path','sha256','bytes')},'whole raw pin '+d['path'])

def emit(name,x):
    q=OUT/name
    if q.exists():raise ValueError('preserve frozen peer')
    q.write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(q)

def project(x):
    return dict(compiler={k:v for k,v in x['outputs']['compile'].items() if k!='seconds'},
        inventory={k:x['outputs']['register'][k] for k in ('definitions','interfaces','native_blocks')},
        model={k:v for k,v in x['outputs']['model'].items() if k!='compile_seconds'},
        initial=x['initial_state'],spec=x['declaration'],policy=x['policy'])

def complete_rows(keys,model,candidates):
    by={}
    for key in set(map(tuple,keys)):
        p=candidates[key];row,role=key[:2]
        if role in by.setdefault(row,{}):raise ValueError('duplicate selected row role')
        by[row][role]=p
    result=[]
    defs={d['name']:d for d in model['_inventory']['definitions']}
    for row,roles in sorted(by.items()):
        if set(roles)!=set(range(model['arity']+2)):continue
        command=roles[0]['command'];guard=roles[1]
        if command!=guard['command']:raise ValueError('C/G command mismatch')
        if command['rule']=='block':
            definition=defs[command['name']]['definition'];req=[]
            for port in range(model['arity']):
                packet=roles[2+port]
                if packet['mode']!=model['mode_ids'][command['name']]:raise ValueError('block mode mismatch')
                if port<len(definition['premises']):req.append([packet['source'],definition['premises'][port]])
                elif packet['source'] is not None:raise ValueError('block filler source')
        else:req=guard['requirements']
        result.append(dict(row=row,formula=command['formula'],requirements=req,
            role_keys=[roles[r]['key'] for r in range(model['arity']+2)],command=command))
    return result

def justified(rows):
    indexed={}
    for row in rows:
        i=row['row']
        if type(i)is not int or i<0:raise ValueError('saved row index')
        if i in indexed and any(indexed[i][k]!=row[k] for k in ('formula','requirements')):raise ValueError('saved conflicting row packet')
        indexed[i]=row
    facts={};trace=[]
    for i,row in sorted(indexed.items()):
        missing=[]
        for pos,(source,wanted) in enumerate(row['requirements']):
            if type(source)is not int or not 0<=source<i:raise ValueError('saved strict prior receptor')
            if source not in facts or facts[source]!=wanted:missing.append(pos)
        if not missing:facts[i]=row['formula']
        trace.append(dict(row=i,justified=not missing,missing_requirement_positions=missing))
    return facts,trace

def check_cost_vector(vector,seed_ids,g):
    formulas=g['graph_preimage']['formulas'];edges=g['graph_preimage']['edges']
    if [r['formula_id'] for r in vector]!=list(range(len(formulas))):raise ValueError('full cost vector')
    costs=[r['cost'] for r in vector]
    for i,r in enumerate(vector):
        cost,origin=r['cost'],r['origin']
        if cost is None:
            if origin is not None:raise ValueError('null cost with source')
        elif type(cost)is not int or cost<0:raise ValueError('exact nonnegative cost')
        elif cost==0:
            if i not in seed_ids or origin!={'kind':'CURRENT_JUSTIFIED_FACT'}:raise ValueError('zero without actual seed')
        else:
            e=edges[origin['edge_id']]
            ps=[costs[p] for p in e['ordered_premises']]
            if origin['kind']!='HYPEREDGE' or not e['active_in_root_formula_grammar'] or e['conclusion']!=i or any(v is None for v in ps) or cost!=1+sum(ps) or any(v>=cost for v in ps):raise ValueError('positive cost origin arithmetic / acyclicity')
    if {i for i,v in enumerate(costs) if v==0}!=set(seed_ids):raise ValueError('complete seed zero-cost set')
    # Check recorded fixed-point inequalities, not recompute/execute relaxation.
    for e in edges:
        ps=[costs[p] for p in e['ordered_premises']]
        if e['active_in_root_formula_grammar'] and all(v is not None for v in ps):
            c=costs[e['conclusion']]
            if c is None or c>1+sum(ps):raise ValueError('incoherent complete recorded potential')
    return costs

def audit_ranking(r,g,label):
    if r['graph_sha256']!=g['graph_sha256'] or r['candidate_pruning'] or r['logical_authority'] or not r['complete_option_multiplicity']:raise ValueError('ranking authority/version')
    n=len(r['options']);check(type(r['order'])is list and all(type(i)is int for i in r['order']) and sorted(r['order'])==list(range(n)),label+' all option indices/multiplicity')
    words={canonical(f['formula']):f['formula_id'] for f in g['graph_preimage']['formulas']}
    facts,trace=justified(r['known_rows']);seeds=sorted({words[canonical(f)] for f in facts.values() if canonical(f) in words})
    check(trace==r['base_justification'] and seeds==r['base_seed_formula_ids'],label+' complete recursively justified seed/trace literal joins')
    if r['status']!='SCORED':
        check(r['order']==list(range(n)),label+' inoperative partial scoring/identity fallback')
        return dict(status=r['status'],options=n,known_rows=len(r['known_rows']))
    base=check_cost_vector(r['base_costs'],seeds,g);target=g['target_formula_id'];by={p['option_index']:p for p in r['option_scores']}
    if set(by)!=set(range(n)):raise ValueError('every option score reference')
    scores=[]
    for i,o in enumerate(r['options']):
        f,t=justified(r['known_rows']+o['rows']);ids=sorted({words[canonical(v)] for v in f.values() if canonical(v) in words})
        row=by[i];d=r['distinct_output_scores'][row['score_id']]
        if t!=row['projected_justification'] or d['seed_formula_ids']!=ids or d['added_formula_ids']!=[v for v in ids if v not in seeds]:raise ValueError('option full justification / added seed list')
        costs=check_cost_vector(d['costs'],ids,g)
        before,after=d['target_cost_before'],d['target_cost_after']
        if before!=base[target] or after!=costs[target] or d['marginal_reduction']!=(before-after if before is not None and after is not None else None) or d['makes_target_potential_finite']!=(before is None and after is not None):raise ValueError('saved target cost arithmetic')
        scores.append(after)
    check(r['order']==sorted(range(n),key=lambda i:(scores[i] is None,scores[i] or 0,i)),label+' saved scalar costs explain stable ordering')
    check(True,label+' all positive origins/strict cost decrease/no circular zero support')
    return dict(status=r['status'],options=n,known_rows=len(r['known_rows']),seed_ids=seeds,base_target_cost=base[target],first_option_after_cost=scores[r['order'][0]] if n else None,changed_order=r['order']!=list(range(n)),work=r['counts']['work'])

def audit_graph(g,x):
    p=g['graph_preimage'];co=x['outputs']['compile'];inv=x['outputs']['register'];basis={canonical(f) for f in co['basis']}
    check(g['status']=='COMPLETE' and digest(p)==g['graph_sha256'] and p['input_projection']==dict(spec=x['declaration'],compiled={k:v for k,v in co.items() if k!='seconds'},inventory={k:inv[k] for k in ('status','definitions','interfaces','native_blocks')}),'support graph whole current compiler/spec/inventory preimages')
    fs=p['formulas'];words={canonical(f['formula']):f['formula_id'] for f in fs}
    check(len(words)==len(fs) and all(f['formula_id']==i and f['literal_preimage']==canonical(f['formula']).decode() and f['in_root_basis']==(canonical(f['formula']) in basis) for i,f in enumerate(fs)),'full graph formula literal words and IDs')
    check(g['target_formula']==x['declaration']['target'] and g['target_formula_id']==words[canonical(x['declaration']['target'])],'literal support target')
    block_modes=[];zero_licences=[]
    for i,e in enumerate(p['edges']):
        if e['edge_id']!=i or e['positive_row_cost']!=1:raise ValueError('full positive ordered hyperedges')
        output=fs[e['conclusion']]['formula'];premises=[fs[j]['formula'] for j in e['ordered_premises']];pro=e['provenance'];rule=e['rule']
        if rule=='axiom':assert output==x['declaration']['theory']['axioms'][pro['name']] and not premises
        elif rule=='tautology':assert output==co['tautologies'][pro['admitted_tautology_index']] and not premises
        elif rule in ('instantiate','eq_subst'):
            c=co['admitted_schemes'][pro['admitted_scheme_index']]
            assert c==pro['exact_command'] and c['formula']==output and not premises and pro['zero_read_licence_only'] is True
            zero_licences.append(dict(rule=rule,output=output,ordered_premises=premises))
        elif rule=='mp':assert output==fs[e['ordered_premises'][1]]['formula'][2] and premises[1][0]=='imp' and premises[1][1]==premises[0]
        elif rule=='generalize':assert output[0]=='all' and premises==[output[2]]
        elif rule=='refl':assert output[0]=='eq' and output[1]==output[2] and not premises
        elif rule=='block':
            mode=pro['interface_mode'];name=inv['interfaces'][mode-1];d=next(d for d in inv['definitions'] if d['name']==name)
            assert pro['exact_definition_record']==d and output==d['definition']['conclusion'] and premises==d['definition']['premises'];block_modes.append(mode)
        else:raise ValueError('unknown saved support edge')
    check(sorted(block_modes)==list(range(1,len(inv['interfaces'])+1)), 'every exported interface represented once, no filtering')
    check(True,'all saved graph edge provenance/literal zero-read licences/joint ordered premises joined')
    return dict(graph_sha256=g['graph_sha256'],formulas=len(fs),edges=len(p['edges']),zero_read_licences=zero_licences)

def region(x,w,candidates):
    model=x['outputs']['model'];initial=x['initial_state'];s=x['outputs']['search'];proof=s['proof'];required=set(map(tuple,model['roots']))
    totals={tuple(p):v for p,v in initial['totals']};marks={tuple(p):v for p,v in initial['marks']};selected=list(map(tuple,s['placements']))
    check(len(required)==len(model['roots']) and required==set(map(tuple,initial['allowed_points'])) and len(totals)==len(initial['totals']) and len(marks)==len(initial['marks']),'whole literal required roots/initial point domains')
    check(len(selected)==len(set(selected)) and all(k in candidates for k in selected),'all selected original unique full keys')
    for k in selected:
        p=candidates[k]
        for q,v in p['occupancy']:
            q=tuple(q)
            if q not in required or type(v)is not int or v<=0:raise ValueError('exact occupancy')
            totals[q]=totals.get(q,0)+v
            if totals[q]>12:raise ValueError('overcapacity')
        for q,v in p['marks']:
            q=tuple(q)
            if type(v)is not int or q in marks and marks[q]!=v:raise ValueError('assigned marking disagreement')
            marks[q]=v
    check(set(totals)==required and all(v==12 for v in totals.values()),'entire selected finite region exact12 occupancy')
    enriched=dict(model,_inventory=x['outputs']['register'])
    rows=complete_rows(selected,enriched,candidates)
    check([r['row'] for r in rows]==list(range(len(proof))) and len(selected)==len(proof)*(model['arity']+2),'complete all-row/all-role selected rectangle')
    decoded=[]
    for r in rows:
        command=dict(r['command'])
        if command['rule']=='block':command['inputs']=[i for i,_ in r['requirements']]
        if any(not 0<=i<r['row'] or proof[i]['formula']!=f for i,f in r['requirements']):raise ValueError('selected ordered prior port formula')
        decoded.append(command)
    check(decoded==proof==x['outputs']['final_request']['proof'],'all C/G/input rows decode literal final Native word')
    union=dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected))
    check(digest(union)==w['final_region_verification']['union_sha256'] and len(marks)==w['final_region_verification']['assigned_mark_points'],'independent whole raw union matches worker receipt')
    return dict(required_points=len(required),selected_placements=len(selected),decoded_rows=len(rows),mark_points=len(marks),explicit_zero_marks=sum(v==0 for v in marks.values()),union_sha256=digest(union),proof=proof)

def ancestry(x):
    proof=x['outputs']['search']['proof'];inventory=x['outputs']['register'];defs={d['name']:d for d in inventory['definitions']};cache={}
    def scope(lines):
        used=set();assumptions=set();counts=collections.Counter()
        def refs(command):
            if command['rule']=='mp':return [command['antecedent'],command['implication']]
            if command['rule']=='generalize':return [command['source']]
            if command['rule']=='block':return [command['inputs'][i] for i in definition(command['name'])['assumptions']]
            return []
        def visit(i):
            if i in used:return
            if type(i)is not int or not 0<=i<len(lines):raise ValueError('saved proof index')
            used.add(i);c=lines[i]
            if c['rule']=='assumption':assumptions.add(c['index'])
            elif c['rule']=='block':counts.update(definition(c['name'])['counts'])
            else:counts[c['rule']]+=1
            for j in refs(c):
                if not 0<=j<i:raise ValueError('saved proof not strictly prior DAG')
                visit(j)
        visit(len(lines)-1)
        return dict(rows=sorted(used),assumptions=sorted(assumptions),counts=dict(counts),references=[dict(row=i,references=refs(lines[i]),all_declared_references=(lines[i].get('inputs') or refs(lines[i]))) for i in sorted(used)])
    def definition(name):
        if name not in cache:cache[name]=scope(defs[name]['definition']['proof'])
        return cache[name]
    result=scope(proof);saved=x['outputs']['essential_ancestry'];root=saved['root']
    check(result['rows']==root['essential_rows'] and result['references']==root['essential_ordered_references'] and result['counts']==root['essential_recursive_primitive_rule_counts'],'independent saved strict-prior essential ancestry and primitive occurrence arithmetic')
    check(sum(result['counts'].values())==root['essential_recursive_primitive_commands'] and saved['essential_generalize_count']==result['counts'].get('generalize',0) and saved['essential_instantiate_count']==result['counts'].get('instantiate',0),'actual essential UI/GEN counts, excluding padding')
    calls=saved['essential_calls'];expected=[i for i in result['rows'] if proof[i]['rule']=='block']
    check([c['root_row'] for c in calls]==expected and all(len(c['path'])==1 for c in calls),'all actual essential calls are exact root-level instances')
    for c in calls:
        i=c['root_row'];d=defs[c['name']];family=next(f for f in x['policy']['library'] if f['id']==c['family'])
        assert proof[i]['name']==d['name']==c['name'] and proof[i]['inputs']==c['inputs'] and c['arguments']==d['arguments'] and c['family']==d['family'] and c['level']==d['level']
        assert c['nonidentity']==(c['arguments']!=[['pred',n,[]] for n in family['donor_atoms']]) and c['essential_input_indices']==definition(c['name'])['assumptions']
    check(True,'each essential ground family/name/arguments/ordered ports/nonidentity joined')
    return dict(essential_rows=result['rows'],padding_rows=[i for i in range(len(proof)) if i not in result['rows']],essential_rule_counts=result['counts'],essential_calls=[{k:c[k] for k in ('root_row','name','family','inputs','arguments','nonidentity','compound_argument_indices')} for c in calls])

def telemetry_audit(x,candidates):
    s=x['outputs']['search'];model=dict(x['outputs']['model'],_inventory=x['outputs']['register']);inv=x['outputs']['register']
    if x['search_ordering']=='legacy':
        check((s['support_ordering'] is None) if x['mode']=='symbolic' else (s['support_ordering']=='legacy' and s['support_ordering_metadata']['graph'] is None),'legacy support graph absent/disabled')
        return dict(disabled=True)
    shared=s['support_ordering'] if x['mode']=='symbolic' else s['support_ordering_metadata']
    g=shared['graph'];gs=audit_graph(g,x);rows=[]
    if x['mode']=='symbolic':
        calls=shared['ranking_calls'];chosen=s['candidate_rows'];proof=s['proof'];prefetched=0
        for i,call in enumerate(calls):
            r=call['ranking'];check(call['complete_window'] is True and r is not None and call['row']==i,'symbolic complete retained ranking window '+str(i))
            for cand in call['candidates']:
                row,k,v,mode=cand['row'],cand['skeleton_index'],cand['guard_variant'],cand['mode'];command=dict(cand['command']);ports=command.pop('inputs',[])
                assert candidates[(row,0,k,0)]['command']==command and candidates[(row,1,k,v)]['command']==command
                for p,source in enumerate(ports):assert (row,2+p,mode,source+1) in candidates and 0<=source<row
            check(len(r['options'])==len(call['candidates']) and chosen[i]==call['candidates'][r['order'][0]],'symbolic selected candidate and all prefetched options '+str(i))
            check([p['provenance']['chosen_candidate']['command'] for p in r['known_rows']]==proof[:i],'symbolic full prefix seed provenance '+str(i))
            for j,o in enumerate(r['options']):assert o['rows'][0]['provenance']['candidate']==call['candidates'][j] and o['rows'][0]['formula']==call['candidates'][j]['command']['formula']
            rows.append(audit_ranking(r,g,'symbolic row '+str(i)));prefetched+=len(call['candidates'])
        check(prefetched==shared['metrics']['prefetched_candidates'] and len(calls)==shared['metrics']['complete_windows'] and all(r['status']=='SCORED' for r in rows),'all symbolic ranking/prefetch counters and no returned partial ranking')
    else:
        for event in s['events']:
            receipt=event['support_ordering'];r=receipt['ranking'];items=event['items'];before=sorted(range(len(items)),key=lambda i:(-event['scores'][i],i))
            check(receipt['legacy_order']==before and receipt['legacy_index']==before[0] and receipt['selected_index']==event['index'] and receipt['after_order']==[before[i] for i in r['order']],'point full old/new item-order provenance '+str(event['id']))
            current=complete_rows(event['chosen'],model,candidates)
            check([{k:p[k] for k in ('row','formula','requirements')} for p in r['known_rows']]==[{k:p[k] for k in ('row','formula','requirements')} for p in current],'point complete selected rows, not guard-only facts '+str(event['id']))
            ids={p['row'] for p in current}
            for j,o in enumerate(r['options']):
                item=items[before[j]];union=event['chosen']+(item['members'] if item else [])
                expected=[p for p in complete_rows(union,model,candidates) if p['row'] not in ids] if item else []
                assert o['option_id']['original_item_index']==before[j]
                assert [{k:p[k] for k in ('row','formula','requirements')} for p in o['rows']]==[{k:p[k] for k in ('row','formula','requirements')} for p in expected]
                for p in o['rows']:assert p['provenance']['role_keys']==next(v['role_keys'] for v in expected if v['row']==p['row'])
            for a in receipt['validated_aggregates']:
                item=items[a['original_index']];assert a['aggregate']=={k:item[k] for k in ('members','pending','aggregate_sha256','new_occupancy','new_marks')}
            rows.append(dict(event_id=event['id'],legacy_index=receipt['legacy_index'],selected_index=receipt['selected_index'],**audit_ranking(r,g,'point event '+str(event['id']))))
        check(sum(r['legacy_index']!=r['selected_index'] for r in rows)==s['metrics']['support_changed_hint_choices'] and len(rows)==s['metrics']['support_order_calls'],'point changed actual hint choices and complete receipt count')
    return dict(graph=gs,ranking_calls=rows,changed_rankings=sum(r['changed_order'] for r in rows),interrupted_returned_rankings=0,scope='Saved literal row/provenance/seed/positive-cost-origin arithmetic checked; no helper relaxation or search was rerun.')

def tree_summary(s):
    todo=[s['tree']];counts=collections.Counter();edges=0;cutoffs=[]
    while todo:
        n=todo.pop();counts[n['kind']]+=1;edges+=len(n['children'])
        if 'cutoff'in n:cutoffs.append(n['cutoff'])
        todo.extend(c['tree'] for c in n['children'])
    check(sum(counts.values())==s['metrics']['nodes'] and edges==s['metrics']['attempts'],'full recorded point tree node/placement counters')
    return dict(nodes=dict(counts),edges=edges,cutoffs=cutoffs)

idx=load(INDEX);closed=load(CLOSURE);verified(pin(INDEX));verified(pin(CLOSURE))
check(len(idx['schedule'])==len(closed['actuals'])==4 and [r['invocation_id'] for r in idx['schedule']]==closed['order'],'exact closed four actuals/order, no reruns inferred')
decl=load(idx['declaration']['path']);verified(idx['declaration'])
old=load(OLD);oldproj=project(old)
reference_paths={}
for k,v in oldproj.items():
    q=OUT/('old-c3-complete-'+k+'-canonical.json');q.write_bytes(canonical(v));reference_paths[k]=pin(q)
old_pin=pin(OLD);del old,oldproj;gc.collect()
common_source_map=None;common_graph=None
for row,endpoints in zip(idx['schedule'],closed['actuals']):
    for d in (row['worker_plan'],row['runner_plan'],row['authorization'],endpoints['consumed'],endpoints['worker_receipt'],endpoints['runner_receipt'],endpoints['terminal']):verified(d)
    p=Path(row['actual_directory']);worker=load(endpoints['worker_receipt']['path']);runner=load(endpoints['runner_receipt']['path']);terminal=load(endpoints['terminal']['path']);marker=load(endpoints['consumed']['path']);wp=load(row['worker_plan']['path']);rp=load(row['runner_plan']['path']);auth=load(row['authorization']['path'])
    for packet in (marker,worker,runner):check(all(packet[k]==row[k] for k in ('invocation_id','mode','search_ordering','model_storage')),'current full method/ordering endpoint join '+row['invocation_id'])
    check(auth['actual_execution_authorized'] is True and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==digest({k:v for k,v in rp.items() if k!='authorization'}),'exact max-one whole once subject')
    check(terminal['terminal_gate_passed'] is True and runner['resource_candidate_accepted'] is True and runner['python_reaped'] is True and runner['python_exit_code']==0 and runner['owned_group_absent'] is True and runner['owned_group_reappearance_observed_ns'] is None and runner['stdout_eof'] and runner['stderr_eof'] and runner['log_capture_complete'],'closed normal resource/terminal/group/EOF receipt scope')
    verified(worker['result']);verified(runner['outputs']['result'])
    x=load(worker['result']['path']);s=x['outputs']['search'];co=x['outputs']['compile'];inv=x['outputs']['register'];model=x['outputs']['model']
    check(x['mode']==row['mode'] and x['search_ordering']==row['search_ordering']==x['source_epoch']['search_ordering'] and x['receiver_id']==row['receiver_id']==decl['selected_receiver_id'],'whole receiver/ordering result binding')
    check(x['source_epoch']['receiver_selection']['spec']==x['declaration'] and worker['source_epoch_sha256']==digest(x['source_epoch']) and worker['driver_output_receipt']['output']['sha256']==worker['result']['sha256'],'whole epoch/selection/output receipt preimages')
    for k,v in project(x).items():check(canonical(v)==raw(reference_paths[k]['path']),'complete current versus historical c3 literal '+k+' (timing exclusions only)')
    original={**wp['project_sources'],'semantic_receiver_driver':wp['components']['receiver_driver'],'bounded_request_oracle':wp['components']['bounded_transport']}
    check(len(original)==24 and x['source_epoch']['sources']['original']==original,'full current24 Source originals, no inventory selection')
    if common_source_map is None:common_source_map=original
    check(original==common_source_map,'identical complete Source acquisition all arms')
    for alias,d in original.items():verified(d);verified(x['source_epoch']['sources']['project'][alias])
    for d in x['source_epoch']['native_inputs'].values():verified(d)
    check(x['module_pins']['support_ordering']==x['source_epoch']['sources']['project']['receptor_support_ordering_v1'],'actual protected helper pin joined')
    inverse=worker['result_reading']['roundtrip'];whole=raw(worker['result']['path']);body=whole[:-1] if whole.endswith(b'\n') else whole
    check(inverse['literal_bytes_equal'] and inverse['body_bytes']==len(body) and inverse['body_sha256']==hashlib.sha256(body).hexdigest(),'saved full Reader inverse body-byte/hash scope');del whole,body
    records=x['records'];check([r['id'] for r in records]==list(range(len(records))),'complete sequential Native record IDs')
    for r in records:check(r['request_sha256']==digest(r['request']) and r['request']['theory']==x['declaration']['theory'],'whole saved Native request/theory/hash '+str(r['id']))
    expected=[(dict(rule='tautology',formula=['imp',['bot'],['bot']]),'first_order_theory_admission')]+[(dict(rule='tautology',formula=f),'first_order_tautology') for f in co['catalog']['basis']]+[(c,'first_order_scheme') for c in co['catalog']['schemes']]
    check(len(co['queries'])==len(expected),'full compiler query prefix')
    for rid,(command,purpose) in zip(co['queries'],expected):
        request=dict(protocol='gcts-fol-1',theory=x['declaration']['theory'],blocks=[],proof=[command],target=command['formula'])
        check(records[rid]['purpose']==purpose and records[rid]['request']==request,'complete literal compiler Native request '+str(rid))
    reg_request=dict(protocol='gcts-fol-1',theory=x['declaration']['theory'],blocks=inv['native_blocks'],proof=[dict(rule='tautology',formula=['imp',['bot'],['bot']])],target=['imp',['bot'],['bot']])
    check(records[inv['query']]['request']==reg_request and records[inv['query']]['result']['status']=='accepted','whole complete inventory Native registration record')
    candidates={tuple(c['key']):c for c in model['placements']};check(len(candidates)==len(model['placements']),'complete unique full literal placement inventory')
    t=telemetry_audit(x,candidates);telemetry.append(dict(invocation_id=row['invocation_id'],data=t))
    if row['search_ordering']=='and_support':
        g=(s['support_ordering'] if row['mode']=='symbolic' else s['support_ordering_metadata'])['graph']
        b=canonical(g['graph_preimage'])
        if common_graph is None:common_graph=b
        check(b==common_graph,'full common literal support graph across treatment methods')
    data=dict(invocation_id=row['invocation_id'],mode=row['mode'],search_ordering=row['search_ordering'],result=worker['result'],worker_receipt=endpoints['worker_receipt'],runner_receipt=endpoints['runner_receipt'],terminal=endpoints['terminal'],status=x['status'],Native_positive=x['native_proof_accepted'],resource_candidate=runner['resource_candidate_accepted'],observed_worker_plus_native_peak_bytes=runner['conservative_parent_plus_native_peak_bytes'],worker_terminal_seconds=(runner['worker_terminal_observed_ns']-runner['began_ns'])/1e9,search_seconds=s['seconds'],metrics=s['metrics'],record_count=len(records),model_placements=len(candidates),model_arity=model['arity'],declared_rows=x['declaration']['length'],support_summary=t)
    if x['mode']=='fixed':data['recorded_tree']=tree_summary(s);check(s['root_restored'] is True and worker['driver_output_receipt']['status']==x['status'],'point root-restored/current status saved flags')
    if x['native_proof_accepted']:
        r=x['outputs']['final_native'];request=x['outputs']['final_request']
        check(r==records[r['id']] and r['request']==request and request['target']==x['declaration']['target'] and request['proof']==s['proof'] and s['proof'][-1]['formula']==request['target'] and r['result']['status']=='accepted','positive final Native record/request/proof/target whole literal joins')
        defs={d['name']:d['definition'] for d in inv['definitions']};used={c['name'] for c in s['proof'] if c['rule']=='block'}
        check(request['blocks']==[defs[n] for n in inv['interfaces'] if n in used],'full used registered block definitions (including padding calls) in Native request')
        check(pin(p/'native/input.bin')['sha256']==r['input_sha256'] and pin(p/'native/output.bin')['sha256']==r['output_sha256'],'retained LAST Native binary input/output hashes only; no decoding')
        data['whole_region']=region(x,worker,candidates);data['essential_ancestry']=ancestry(x)
        lines=[]
        for i,c in enumerate(s['proof']):lines.append(dict(human_line=i+1,formula=c['formula'],rule=c['rule'],ordered_human_inputs=[j+1 for j in c.get('inputs',[])],generalize_source=(c['source']+1 if c['rule']=='generalize' else None),essential=i in data['essential_ancestry']['essential_rows']))
        data['proof_lines']=lines
        if x['mode']=='symbolic':check(s['root_path_restored'] is True and s['proof']==[r['command'] for r in s['candidate_rows']],'symbolic complete actual selected word/row packets')
        else:
            selected=set(map(tuple,s['placements']));calls={c['root_row']:c for c in x['outputs']['essential_ancestry']['essential_calls']}
            links=x['outputs']['winning_hint_links']['links']
            for link in links:
                call=calls[link['row']];hint=s['hints'][link['hint_id']]
                assert link['name']==call['name'] and link['arguments']==call['arguments'] and link['family']==call['family']
                assert all(tuple(k) in selected for k in hint['item']['members']) and tuple(link['key']) in selected
                assert link['changed_original_order']==(link['original_order']!=link['preferred_order']) and link['full_hint_members_on_winning_path'] and link['exact_ordered_input_sources']
                assert s['proof'][link['row']]['inputs']==call['inputs']
            check(any(l['changed_original_order'] for l in links) and x['outputs']['winning_hint_links']['changed_order_family_hint_use'],'actual essential family hint members and ordered ports on changed winning point path')
            data['winning_family_hint_links']=dict(total_links=len(links),changed_links=sum(l['changed_original_order'] for l in links),essential_rows=sorted({l['row'] for l in links}))
    else:
        check(s['proof'] is None and x['status']=='unknown_search_budget' and x['family_hint_success'] is False,'legacy UNKNOWN is not proof/refutation/exhaustion')
    arms.append(data);del x,s,co,inv,model,candidates,t;gc.collect()

root_admission=pin(ROOT_ADMISSION)
check(root_admission['sha256']=='992b19037bf368767b7f8ed56238c6eea4a231b76439f7eec82b689996d57d0c' and root_admission['bytes']==398509,'exact separately authored Root admission binding; independent raw checks above')
audit=emit('audit-v1.json',dict(schema='and-support-retained-literal-data-audit-v1',reviewer_identity='/root/receiver_driver_review',source_only=False,retained_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,checks=checks,check_count=len(checks),findings=[],plans=pin(INDEX),cohort_closure=pin(CLOSURE),Root_admission=root_admission,historical_c3=old_pin,complete_historical_reference_preimages=reference_paths,raw_pins=list(pins.values()),actuals=arms,authorship='Reviewer authored the current driver/cold/outer/observer and prior qualification harness/input corpus; did not execute actuals. This is retained-data inspection, NOT independent own-Source certification. Distinct Source peers and Root measured/admission gates remain separate.'))
review=emit('typed-data-review-v1.json',dict(schema='and-support-ordering-retained-data-review-v1',reviewer_identity='/root/receiver_driver_review',author_identity='/root',data_review_passed=True,source_only=False,retained_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,plans=pin(INDEX),cohort_closure=pin(CLOSURE),Root_admission=root_admission,audit=audit,audit_Source=pin(Path(__file__)),checks=len(checks),findings=[],actuals=arms,authorship_disclosure='Current orchestration author and prior qualification-harness/input-corpus author; prior independent ordering-component Source reviewer. No self-certified orchestration Source, no actual execution by reviewer.',limitations=['Native truth is conditional on fresh recorded accepted transcripts and reviewed pinned Native checker/transport; no logical kernel/Native/codec replay or re-encoding occurred.','Complete literal Model/inventory/compiler/initial/spec/policy data compared, not hash-only; excludes ONLY compiler.seconds and model.compile_seconds. All point/mark fields and explicit zero values preserved.','Saved seed/reference/cost-origin and ordering arithmetic/provenance checked without recomputing helper relaxation or running search. Scope is current protected row/graph projection and recorded receipts; no all-state or arbitrary-callback theorem.','Root/stack restoration flags and fingerprints are Source-backed saved observations; no independent Graph re-enumeration or runtime state replay.','Both positive proofs retain fixed12-row padding outside essential ancestry. All family uses are existing level1 ground instances, no new hierarchy or live RL.','Four one-shot development-case observations support a generic ordering hypothesis only. They do not establish GCTS-specific superiority, equal operation units, generalization, statistical performance, a new ten-case corpus outcome or unrestricted FOL/geometry/PA result.']))
handoff=emit('handoff-v1.json',dict(schema='and-support-retained-data-peer-handoff-v1',review=review,audit=audit,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False))
print(json.dumps(dict(review=review,audit=audit,handoff=handoff,checks=len(checks)),sort_keys=True))
