from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import collections,gc,gzip,hashlib,json,re

D=Path('/private/tmp/gcts-and-support-report-peer-20261018')
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/and-support-ordering-progress-20261018')
PUB=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
CP=Path('/private/tmp/gcts-and-support-comparison-peer-20261018/retained-comparison-data-v1.json')
checks=[];counts=collections.Counter()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def ck(n,x,detail=None):
 checks.append(dict(check=n,passed=bool(x),detail=detail))
 if not x:raise AssertionError(n)
def emit(n,v):
 p=D/n;p.write_text(json.dumps(v,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n');return desc(p)
class Node:
 def __init__(self,t='root',a=None):self.tag=t;self.attrs=dict(a or []);self.children=[]
 def text(self):return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
 def nodes(self):
  yield self
  for c in self.children:
   if isinstance(c,Node):yield from c.nodes()
 def find(self,tag=None,cls=None):return [n for n in self.nodes() if (tag is None or n.tag==tag) and (cls is None or cls in n.attrs.get('class','').split())]
 def direct(self,tag):return [c for c in self.children if isinstance(c,Node) and c.tag==tag]
class DOM(HTMLParser):
 void={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
 def __init__(self,text):
  super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(text);self.close()
 def handle_starttag(self,t,a):
  n=Node(t,a);self.stack[-1].children.append(n)
  if t not in self.void:self.stack.append(n)
 def handle_startendtag(self,t,a):self.stack[-1].children.append(Node(t,a))
 def handle_endtag(self,t):
  for j in range(len(self.stack)-1,0,-1):
   if self.stack[j].tag==t:self.stack=self.stack[:j];return
 def handle_data(self,data):self.stack[-1].children.append(data)
def mathword(n):
 s=n.text().strip();ck('MathJax inline delimiters',s.startswith('\\(') and s.endswith('\\)'));return s[2:-2]
# A restricted reader of displayed TeX, not a formula generator or proof checker.
# It only parses the actual forall/imp/predicate/variable notation in these saved pages.
def parse_formula(tex):
 tex=tex.replace('\\left','').replace('\\right','').replace('\\;','')
 toks=re.findall(r'\\forall|\\Rightarrow|\\rightarrow|[A-Za-z]+|[(),]',tex)
 if ''.join(toks)!=re.sub(r'\s+','',tex):raise ValueError('unexpected displayed formula token: '+tex)
 at=0
 def get():
  nonlocal at
  x=toks[at];at+=1;return x
 def atom():
  x=get()
  if x=='\\forall':
   variable=get();return ['all',variable,atom()]
  if x=='(':
   f=expr()
   if get()!=')':raise ValueError('display formula parenthesis')
   return f
  if x not in ('P','Q','R') or get()!='(':raise ValueError('display predicate syntax')
  args=[]
  if toks[at]!=')':
   while True:
    args.append(['var',get()])
    if toks[at]!=',':break
    get()
  if get()!=')':raise ValueError('display term parenthesis')
  return ['pred',x,args]
 def expr():
  f=atom()
  if at<len(toks) and toks[at] in ('\\Rightarrow','\\rightarrow'):
   get();f=['imp',f,expr()]
  return f
 f=expr()
 if at!=len(toks):raise ValueError('trailing display formula')
 return f

def labeled_pre(node,label):
 result=[]
 for d in node.find('details'):
  s=d.direct('summary')
  if s and s[0].text()==label:
   p=d.direct('pre');ck('one literal pre for '+label,len(p)==1);result.append(json.loads(p[0].text()))
 ck('exact one '+label,len(result)==1);return result[0]
def leading_nodes(cell):
 out=[]
 for x in cell.children:
  if isinstance(x,Node) and x.tag=='details':break
  out.append(x)
 return out
def lead_text(cell):return ''.join(x if isinstance(x,str) else x.text() for x in leading_nodes(cell))
def lead_find(cell,tag):return [n for x in leading_nodes(cell) if isinstance(x,Node) for n in x.nodes() if n.tag==tag]
def tbody_rows(table):return table.direct('tbody')[0].direct('tr')
def formula_spans(node):return node.find('span','sr-math')
def check_table(table,lines,premises,definitions,labels,ess,scope,label):
 rows=tbody_rows(table);ck(label+' full row count',len(rows)==len(lines))
 for j,(tr,cmd) in enumerate(zip(rows,lines)):
  counts['displayed_proof_rows']+=1
  cells=tr.direct('td');ck(label+str(j)+' three cells',len(cells)==3)
  ck(label+str(j)+' exact row ID',tr.attrs['id']==scope+'-line-'+str(j))
  ck(label+str(j)+' one-based display',cells[0].children[0]==str(j+1))
  ck(label+str(j)+' retained essential highlight',('sr-essential' in tr.attrs.get('class','').split())==(j in ess))
  ff=formula_spans(cells[1]);ck(label+str(j)+' one formula',len(ff)==1)
  ck(label+str(j)+' literal formula LaTex AST',canon(parse_formula(mathword(ff[0])))==canon(cmd['formula']))
  ck(label+str(j)+' full literal command',canon(labeled_pre(tr,'Literal command'))==canon(cmd))
  english=lead_text(cells[2]);links=lead_find(cells[2],'a');rule=cmd['rule']
  if rule=='axiom':ck(label+str(j)+' English AX name',english=='Use the given theory premise '+cmd['name']+'.')
  elif rule=='instantiate':
   ck(label+str(j)+' English UI licence',english.startswith('Introduce the universal-instantiation license for ') and english.endswith('.') and ' at term ' in english)
   m=[x for x in lead_find(cells[2],'span') if 'sr-math' in x.attrs.get('class','').split()]
   ck(label+str(j)+' English actual UI universal/term',len(m)==2 and canon(parse_formula(mathword(m[0])))==canon(cmd['universal']) and mathword(m[1])==cmd['term'][1])
   ck(label+str(j)+' no fabricated UI prior read',links==[])
  elif rule=='generalize':
   ck(label+str(j)+' English actual GEN source',[x.attrs['href'] for x in links]==['#'+scope+'-line-'+str(cmd['source'])] and english.startswith('Universally generalize line '+str(cmd['source']+1)+' in ') and 'native checker supplies the scope side condition.' in english)
   m=[x for x in lead_find(cells[2],'span') if 'sr-math'in x.attrs.get('class','').split()];ck(label+str(j)+' exact GEN variable',len(m)==1 and mathword(m[0])==cmd['variable'])
  elif rule=='mp':ck(label+str(j)+' English ordered MP reads',[x.attrs['href'] for x in links]==['#'+scope+'-line-'+str(cmd['implication']),'#'+scope+'-line-'+str(cmd['antecedent'])] and english=='Apply the implication on line '+str(cmd['implication']+1)+' to line '+str(cmd['antecedent']+1)+'.')
  elif rule=='assumption':
   ck(label+str(j)+' English exact assumption port',english.startswith('Use local input '+str(cmd['index']+1)+', whose declared formula is '))
   m=[x for x in lead_find(cells[2],'span') if 'sr-math'in x.attrs.get('class','').split()];ck(label+str(j)+' exact assumption formula',len(m)==1 and canon(parse_formula(mathword(m[0])))==canon(premises[cmd['index']]))
  elif rule=='block':
   target=labels[cmd['name']]
   ck(label+str(j)+' English exact block/ordered sources',[x.attrs['href'] for x in links]==['#'+target]+['#'+scope+'-line-'+str(i) for i in cmd['inputs']] and english.endswith(', in the recorded port order.'))
   details=[n for n in tr.find('details') if n.direct('summary') and n.direct('summary')[0].text()=='Ordered lemma input ports'];ck(label+str(j)+' ordered port table present',len(details)==1)
   portrows=tbody_rows(details[0].find('table')[0]);ps=definitions[cmd['name']]['premises'];ck(label+str(j)+' exact complete port count',len(portrows)==len(cmd['inputs'])==len(ps))
   for port,(pr,source,premise) in enumerate(zip(portrows,cmd['inputs'],ps)):
    cc=pr.direct('td');ck(label+str(j)+' port'+str(port)+' exact ordinal/index',cc[0].text()==str(port+1) and cc[1].find('a')[0].attrs['href']=='#'+scope+'-line-'+str(source))
    ck(label+str(j)+' port'+str(port)+' declared and actual formula',canon(parse_formula(mathword(formula_spans(cc[2])[0])))==canon(premise) and canon(parse_formula(mathword(formula_spans(cc[3])[0])))==canon(lines[source]['formula']))
    counts['ordered_port_rows']+=1
  else:raise ValueError('unexpected recorded rendered rule '+rule)

v3=json.loads((ROOT/'report-draft-assets-v3.json').read_bytes());v2=json.loads((ROOT/'report-draft-assets-v2.json').read_bytes());v1=json.loads((ROOT/'report-draft-assets-v1.json').read_bytes());correction=json.loads((ROOT/'ROOT-publication-correction-v1.json').read_bytes())
ck('exact current v3 asset index',desc(ROOT/'report-draft-assets-v3.json')['sha256']=='b376052d1c6296c12ccfc1c62f932bb8ad28eee57745d36f0e5c61dcc6c7e0b6')
for p in v3['assets']:ck('full final asset raw '+Path(p['path']).name,desc(p['path'])==p)
manifest={Path(p['path']).name:p for p in v3['assets']}
cp=json.loads(CP.read_bytes());records={r['invocation_id']:r for r in cp['records']}
# Ordinary report gzip only: streaming byte hash equals retained full raw result.
for label in ('fixed-legacy','symbolic-and-support','symbolic-legacy','fixed-and-support'):
 name='and-support-'+label+'-result.json.gz';raw=records['and-support-c3-'+label+'-ROOT-20261018-v1']['raw_result'];h=hashlib.sha256();n=0
 with gzip.open(PUB/name,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 ck(name+' lossless full ordinary JSON download',h.hexdigest()==raw['sha256'] and n==raw['bytes'])
 counts['lossless_publication_gzips']+=1
# Main table all four exact observed values/order/units; Root admission is an external reviewed artifact.
main=(PUB/'and-support-ordering.html').read_text();md=DOM(main).root;out=next(n for n in md.nodes() if n.attrs.get('id')=='outcomes');table=out.find('table')[0]
rr=tbody_rows(table);ck('all4 table rows',len(rr)==4)
for tr,r in zip(rr,cp['records']):
 cc=[n.text() for n in tr.children if isinstance(n,Node) and n.tag in ('th','td')]
 work=r['search_metrics'].get('attempts',r['search_metrics'].get('prefix_extensions'))
 ck(r['invocation_id']+' exact main table figures',str(work) in cc[2] and format(r['search_seconds'],'.3f') in cc[3] and format(r['Source_entry_to_external_terminal_seconds'],'.3f') in cc[4] and format(r['conservative_worker_plus_native_MiB'],'.1f') in cc[5])
 ck(r['invocation_id']+' outcome label honest',('Checked proof' in cc[1])==r['native_proof_recorded'] and ('UNKNOWN' in cc[1])==(not r['native_proof_recorded']))
summary=json.loads((PUB/'and-support-ordering-summary.json').read_bytes());admission=json.loads((PUB/'and-support-ordering-admission.json').read_bytes())
ck('whole public Root admission copy exact',desc(summary['Root_admission']['path'])['sha256']==desc(PUB/'and-support-ordering-admission.json')['sha256'])
ck('summary/admission all4 outcomes same literal data',summary['actuals']==admission['actuals'] and summary['admitted_proof_instances']==admission['fresh_native_proofs']==2 and summary['all_four_within_profile'] is True and admission['within_resource_profile']==4)
for a in summary['actuals']:
 r=records[a['invocation_id']]
 ck(a['invocation_id']+' summary literal counters/region facts',a['status']==r['status'] and a['search_seconds']==r['search_seconds'] and a['peak_sum_MiB']==r['conservative_worker_plus_native_MiB'] and a['outer_terminal_seconds']==r['Source_entry_to_external_terminal_seconds'] and a['model_placements']==11440 and a['interfaces']==8 and a['model_arity']==3 and a['native_queries']==r['native_records'])
ck('current all4 common exact identities externally admitted',admission['all_common_full_semantic_preimages_equal'] is True and summary['common_semantics_equal_old_c3'] is True)
ck('public declaration copy exact',desc(PUB/'and-support-ordering-declaration.json')['sha256']==admission['declaration']['sha256'])
ck('public closure copy exact',desc(PUB/'and-support-ordering-runtime-closure.json')['sha256']=='8246d2d2afdd3045067af2ae12b45f9fe6619451bbd33fd47e6b09d0ae5f06b8')
# Complete displayed root rows, registered bodies, ports, selected packets and every t/m table value.
proof_details=[]
for mode in ('fixed','symbolic'):
 name='and-support-'+mode+'-and-support-proof.html';html=(PUB/name).read_text();dom=DOM(html).root
 r=records['and-support-c3-'+mode+'-and-support-ROOT-20261018-v1'];data=json.loads(Path(r['raw_result']['path']).read_bytes())
 proof=data['outputs']['search']['proof'];inventory=data['outputs']['register'];ob=data['outputs']['essential_ancestry'];model=data['outputs']['model'];search=data['outputs']['search']
 defs={d['name']:d for d in inventory['native_blocks']};metas={d['name']:d for d in inventory['definitions']};sections=dom.find('details','sr-definition');labels={};by_definition={}
 ck(mode+' all8 full registered bodies shown',len(sections)==len(defs)==8)
 for sec in sections:
  packet=labeled_pre(sec,'Literal registered definition and metadata');dn=packet['definition']['name'];labels[dn]=sec.attrs['id'];by_definition[dn]=sec
  ck(mode+dn+' full definition/metadata literal',canon(packet['definition'])==canon(defs[dn]) and canon(packet['metadata'])==canon(metas[dn]))
  ck(mode+dn+' conclusion summary formula',canon(parse_formula(mathword(formula_spans(sec.direct('summary')[0])[0])))==canon(defs[dn]['conclusion']))
 ck(mode+' registered labels preserve all distinct identities',set(labels)==set(defs))
 tables=dom.find('table','sr-proof');root_table=tables[0];scope=tbody_rows(root_table)[0].attrs['id'].rsplit('-line-',1)[0]
 check_table(root_table,proof,[],defs,labels,set(ob['root']['essential_rows']),scope,mode+' root ')
 for dn,sec in by_definition.items():
  t=sec.find('table','sr-proof');ck(mode+dn+' one complete proof table',len(t)==1)
  check_table(t[0],defs[dn]['proof'],defs[dn]['premises'],defs,labels,set(ob['ground_definition_summaries'][dn]['essential_rows']),sec.attrs['id'],mode+' '+dn+' ')
  counts['registered_bodies']+=1
 tiles=dom.find('details','sr-tile');rows=dom.find('div','sr-tile-row');ck(mode+' all12 actual point rows and60glyphs',len(tiles)==60 and len(rows)==12)
 indexed={tuple(p['key']):p for p in model['placements']};selected={tuple(k) for k in search['placements']};seen=set();numeric=0
 for tile in tiles:
  packet=labeled_pre(tile,'Full selected placement packet');key=tuple(packet['key']);candidate=indexed[key];seen.add(key)
  ck(mode+str(key)+' complete selected packet exact',key in selected and canon(packet)==canon(candidate))
  title='C' if key[1]==0 else 'G' if key[1]==1 else 'I'+str(key[1]-1)
  ck(mode+str(key)+' actual C/G/I role glyph',tile.direct('summary')[0].find('strong')[0].text()==title and tile.find('svg')[0].attrs['aria-label']=='Schematic point placement '+title)
  expected_color='#2865a5' if key[1]==0 else '#8b52a5' if key[1]==1 else '#b5771a'
  ck(mode+str(key)+' role color',tile.find('svg')[0].find('rect')[0].attrs['stroke']==expected_color)
  trs=tbody_rows(tile.direct('table')[0]);wanted=[('base occupancy',p,v,'') for p,v in candidate['occupancy']]
  for p,v in candidate['marks']:
   x,y=p
   layer,color=('formula','#25845b') if x%4==0 and y>=100 else ('command','#2865a5') if x%4==1 and y>=100 else ('mode','#8b52a5') if x%4==2 and y==90 else ('source','#b5771a') if x%4==2 and y>=100 else ('other','#60717e')
   wanted.append((layer+' marking',p,v,color))
  ck(mode+str(key)+' every exact occupancy/mark row',len(trs)==len(wanted))
  for tr,(layer,p,v,color) in zip(trs,wanted):
   cells=tr.direct('td');point='('+','.join(map(str,p))+')';value=str(v)+'/12' if layer=='base occupancy' else str(v)
   if cells[0].text()!=layer or mathword(formula_spans(cells[1])[0])!=point or mathword(formula_spans(cells[2])[0])!=value:raise AssertionError('literal point value mismatch '+mode+str(key)+str(p))
   if color and cells[0].find('span')[0].attrs['style']!='background:'+color:raise AssertionError('mark layer color mismatch')
   numeric+=1
  ck(mode+str(key)+' full scalar table equals packet',True)
  if candidate['kind']=='lemma_input':ck(mode+str(key)+' exact English input source','Reads root line '+str(candidate['source']+1)+'.' in tile.text())
  elif candidate['kind']=='unused_input':ck(mode+str(key)+' no fabricated input source','Unused input filler; its source sentinel is ' in tile.text())
  counts['selected_tiles']+=1
 ck(mode+' no selected tile omitted/duplicated',seen==selected and len(seen)==len(tiles))
 counts['point_value_rows']+=numeric
 ck(mode+' actual point output glyph limitation explicit','square is a display glyph' in html and 'No rotation' in html and '12/12=1' in html)
 ck(mode+' proof reader raw gzip exact href',('and-support-'+mode+'-and-support-result.json.gz') in html)
 proof_details.append(dict(mode=mode,root_rows=len(proof),registered_bodies=len(defs),rendered_lemma_rows=sum(len(d['proof']) for d in defs.values()),selected_tiles=len(tiles),point_value_rows=numeric,essential_rows=ob['root']['essential_rows']))
 del data,model,dom;gc.collect()
# Internal and local cross-page anchors in all five changed display pages.
pages=['and-support-ordering.html','and-support-fixed-and-support-proof.html','and-support-symbolic-and-support-proof.html','reader.html','parallel-search-planning.html'];doms={n:DOM((PUB/n).read_text()).root for n in pages};ids={n:{x.attrs['id'] for x in d.nodes() if 'id'in x.attrs} for n,d in doms.items()}
for n,d in doms.items():
 allids=[x.attrs['id'] for x in d.nodes() if 'id'in x.attrs];ck(n+' unique HTML IDs',len(allids)==len(set(allids)))
 ck(n+' established MathJax support',any(x.tag=='script' and x.attrs.get('src')=='https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js' for x in d.nodes()))
 for a in d.find('a'):
  u=urlsplit(a.attrs.get('href',''))
  if u.scheme or u.netloc:continue
  target=u.path or n
  if target in ids and u.fragment:ck(n+' local anchor '+a.attrs['href'],u.fragment in ids[target])
 ck(n+' no Unicode math substitutes',not any(c in (PUB/n).read_text() for c in ['∀','⇒','⊢','∧','∈']))
reader=doms['reader.html'];current=next(x for x in reader.nodes() if x.attrs.get('id')=='and-support-ordering');old=next(x for x in reader.nodes() if x.attrs.get('id')=='structural-transfer')
ck('child reader current vs historical cards clear','LATEST MEASURED SEARCH RESULT' in current.text() and 'Two fresh admitted proofs' in current.text() and 'EARLIER PROOF-SEARCH RESULT' in old.text())
ck('dated old planning explicitly superseded','Subsequent measured result:' in doms['parallel-search-planning.html'].text() and 'planning record below describes the earlier unexecuted state' in doms['parallel-search-planning.html'].text())
ck('main key contribution and limits accurate',all(t in md.text() for t in ['both contemporary legacy controls return UNKNOWN','It establishes no GCTS-specific or RL advantage','three instantiation licences','five applications of modus ponens','No nested hierarchy','no repetitions or statistical generalization','fixtures remain unexecuted']) if False else all(t in main for t in ['Both contemporary legacy controls return UNKNOWN','It establishes no GCTS-specific or RL advantage','three instantiation licences','five applications of modus ponens','No nested hierarchy','no repetitions or statistical generalization','remain unexecuted']))
ck('main correct proposal setting and full fallback scope','row-Join' in main and 'arbitrary sampled' in main and 'up to \\(24\\) proposals' not in main)
# Whole-byte successor corrections only; original immutable snapshots remain auditable.
for before,after in zip(correction['before'],correction['after']):
 ck('immutable v1 before '+Path(before['path']).name,desc(before['path'])==before)
 ck('exact v2 after '+Path(after['path']).name,desc(after['path'])==after)
 if 'proof.html' in after['path']:
  cur=Path(after['path']).read_text();orig=Path(before['path']).read_text()
  for anchor in ('outcomes','proofs','parallel','evidence'):cur=cur.replace('href="and-support-ordering.html#'+anchor+'"','href="#'+anchor+'"',1)
  ck('whole proof body unchanged after nav repair '+Path(after['path']).name,cur==orig)
oldreader=ROOT/'report-draft-v2-before-label-correction/reader.html'
ck('whole child reader only earlier-label delta',(PUB/'reader.html').read_text().replace('EARLIER PROOF-SEARCH RESULT · PARALLEL RESEARCH','LATEST PROOF-SEARCH RESULT · PARALLEL RESEARCH')==oldreader.read_text())
# Pending package/review files are an explicit later finalization gate, not treated as proof claims.
pending=['and-support-ordering-evidence-manifest.json','and-support-ordering-evidence.zip','and-support-ordering-data-review.json','and-support-ordering-resource-review.json','and-support-ordering-comparison-review.json','and-support-ordering-report-review.json']
data_peer=desc('/private/tmp/gcts-and-support-retained-data-peer-20261018/typed-data-review-v2.json');resource_peer=desc('/private/tmp/gcts-and-support-retained-resource-peer-20261018/typed-resource-review-v1.json')
ck('exact external data peer pin',data_peer['sha256']=='764d7d49c28a12cb0735cba15edaccefc637e15a1a0f6b71d6bbb0c9b7d9cd6b')
ck('exact external resource peer pin',resource_peer['sha256']=='0d3423c80dc0c8eb685852c52f4cda4967b632a2b07325b9dde653bf19ad7ef6')
ancestry=dict(reviewer_identity='/root/conventional_library',report_author='/root',authored_point_ordering_and_old_Model_driver_bridge=True,authored_parent_pure_renderer=True,
 current_scope='Saved raw HTML/JSON/LaTex/English/ports/point packets and publication delta only; not own Source audit, independent proof checking, rendering or Native replay.',current_Source_peer=desc('/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json'))
limitations=['No renderer/Model/compiler/logic/helper/search/Native/solver/codec or scientific code evaluated. Ordinary publication gzip streams were decompressed only to compare whole raw result bytes, not opaque Native inputs.',
 'Restricted displayed-LaTex parser compares literal formula AST syntax; it is not a proof rule checker. Mathematical validity and essentiality remain independently audited Native/Root evidence.',
 'Point/parent-adapter/parent-renderer authorship disclosed. This is a distinct Root-authored report/display audit, not an independent Source certificate for own implementations.',
 'Archive, final evidence/review-copy hashes and live browser/MathJax/layout inspection remain Root finalization/live-QA tasks. Six pending evidence links listed explicitly; no final publication/live update accepted here.',
 'One familiar development assertion and four single observations. No statistical/general speed, GCTS superiority, RL, nested lemma promotion, external prover comparison, allFOL, PA/Hilbert geometry or plane-tiling claim.']
negative=emit('typed-report-review-v1-negative.json',dict(schema='and-support-human-report-review-v1',metadata_revision=1,report_review_passed=False,source_only=True,retained_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,author_identity='/root',reviewer_identity='/root/conventional_library',
 reviewed_asset_index=desc(ROOT/'report-draft-assets-v1.json'),findings=[dict(id='R1',blocking=True,scope='both proof topnav',finding='Eight dangling same-page links outcomes/proofs/parallel/evidence.'),dict(id='R2',blocking=True,scope='main/summary pool wording',finding='24 is row-Join setting; sampled proposals/defer append, so total pool cap24 is imprecise.'),dict(id='R3',blocking=True,scope='inherited reader card label',finding='Old structural result still labeled LATEST despite new result; data itself remains historical.')],
 disposition='All3 publication issues repaired only in successors; v1 originals preserved. Proof/formula/English/tile content verified via unchanged current body and wholebyte delta checks.',ancestry=ancestry,limitations=limitations))
audit=emit('raw-report-audit-v3.json',dict(schema='and-support-report-raw-audit-v3',scientific_calls=0,scientific_replays=0,scientific_acceptance=False,checks=checks,check_count=len(checks),mismatches=0,
 counts=dict(counts),proof_details=proof_details,current_asset_index=desc(ROOT/'report-draft-assets-v3.json'),assets=v3['assets'],pending_finalization_links=pending,negative_v1=negative,publication_correction=desc(ROOT/'ROOT-publication-correction-v1.json'),ancestry=ancestry,limitations=limitations))
review=emit('typed-report-review-v3.json',dict(schema='and-support-human-report-review-v1',metadata_revision=3,report_review_passed=True,retained_data_only=True,source_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,
 author_identity='/root',reviewer_identity='/root/conventional_library',reviewed_asset_index=desc(ROOT/'report-draft-assets-v3.json'),assets=v3['assets'],Root_admission=summary['Root_admission'],
 data_review=data_peer,resource_review=resource_peer,comparison_analysis=desc('/private/tmp/gcts-and-support-comparison-peer-20261018/typed-comparison-analysis-v1.json'),pure_renderer=v3['pure_renderer'],
 check_count=len(checks),mismatches=0,counts=dict(counts),findings=[],blocking_findings=[],closed_findings=['R1','R2','R3'],negative_v1=negative,audit=audit,ancestry=ancestry,limitations=limitations,pending_finalization_links=pending))
print(json.dumps(dict(review=review,audit=audit,negative=negative,checks=len(checks),counts=dict(counts),science=0)))
