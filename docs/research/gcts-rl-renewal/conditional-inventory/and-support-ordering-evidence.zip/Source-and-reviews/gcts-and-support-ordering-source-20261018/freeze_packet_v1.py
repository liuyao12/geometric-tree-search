"""Raw/AST/compile-without-evaluation and inert text-patch packaging only."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

D = Path('/private/tmp/gcts-and-support-ordering-source-20261018')
PARENT = Path('/private/tmp/gcts-symbolic-control-source-20261018/quantified_symbolic_control_v1.py')
ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')

def pin(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return dict(path=str(p), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))

def write(name, value):
    p = D / name
    p.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    return pin(p)

sources = {
    'support_ordering': pin(D / 'receptor_support_ordering_v1.py'),
    'symbolic_control': pin(D / 'quantified_symbolic_control_v2.py')}
fixture = pin(D / 'support_algorithm_fixtures_v1.py')
author = '/root/conventional_control_review'
ancestry = dict(author_identity=author,
                authored_parent_symbolic_control=True,
                also_authored_prior_quantified_driver_and_outer_protocols=True,
                independent_source_certification=False,
                distinct_reviewer_required=True)
scope = dict(source_only=True, scientific_calls=0, scientific_acceptance=False,
             target_imports=0, actual_execution_authorized=False,
             native_calls=0, search_evaluations=0, no_activation=True)
checks = []
asts = {}
for role, descriptor in dict(sources, prospective_fixture=fixture).items():
    p = Path(descriptor['path'])
    raw = p.read_bytes()
    tree = ast.parse(raw)
    compile(tree, str(p), 'exec')  # Produces a code object; never exec/eval/import it.
    asts[role] = tree
    imports = [n.names[0].name for n in tree.body if isinstance(n, ast.Import)]
    assert not any(isinstance(n, ast.ImportFrom) for n in ast.walk(tree))
    checks.append(dict(kind='parse_and_compile_without_evaluation', role=role,
                       source=descriptor, imports=imports, passed=True))

parent_raw = PARENT.read_text()
new_raw = (D / 'quantified_symbolic_control_v2.py').read_text()
parent_tree = ast.parse(parent_raw)
new_tree = asts['symbolic_control']
def region(text, node):
    return ''.join(text.splitlines(keepends=True)[node.lineno - 1:node.end_lineno])
parent_nodes = {n.name: n for n in parent_tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
new_nodes = {n.name: n for n in new_tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
retained = []
for name, node in parent_nodes.items():
    if name == 'search_symbolic':
        continue
    raw_equal = region(parent_raw, node) == region(new_raw, new_nodes[name])
    ast_equal = ast.dump(node, include_attributes=False) == ast.dump(new_nodes[name], include_attributes=False)
    assert raw_equal and ast_equal, name
    retained.append(dict(name=name, raw_equal=raw_equal, AST_equal=ast_equal,
                         original_line=node.lineno, successor_line=new_nodes[name].lineno))
checks.append(dict(kind='all_parent_top_regions_except_search_retained', regions=retained, passed=True))

patch_results = []
for role, before, after in [
        ('symbolic_control', PARENT, D / 'quantified_symbolic_control_v2.py'),
        ('support_ordering', None, D / 'receptor_support_ordering_v1.py'),
        ('prospective_fixture', None, D / 'support_algorithm_fixtures_v1.py')]:
    before_text = before.read_text() if before else ''
    after_text = after.read_text()
    folder = D / ('inert-patch-' + role)
    folder.mkdir(exist_ok=True)
    target = folder / 'payload.py'
    target.write_text(before_text)
    forward = ''.join(difflib.unified_diff(before_text.splitlines(True), after_text.splitlines(True),
                                          fromfile='payload.py', tofile='payload.py'))
    inverse = ''.join(difflib.unified_diff(after_text.splitlines(True), before_text.splitlines(True),
                                          fromfile='payload.py', tofile='payload.py'))
    (folder / 'forward.patch').write_text(forward)
    (folder / 'inverse.patch').write_text(inverse)
    for direction, patch, expected in [('forward', forward, after_text), ('inverse', inverse, before_text)]:
        result = subprocess.run(['patch', '--batch', '-p0'], input=patch.encode(),
                                cwd=folder, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert result.returncode == 0 and target.read_text() == expected, (role, direction)
        patch_results.append(dict(role=role, direction=direction, exit_code=result.returncode,
                                  resulting_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                                  stdout=result.stdout.decode(), stderr=result.stderr.decode(),
                                  real_patch_on_inert_copy_only=True))

audit = write('Source-audit-v1.json', dict(schema='and-support-author-Source-audit-v1',
                                          **scope, ancestry=ancestry, checks=checks,
                                          inert_patch_directions=patch_results,
                                          no_fixture_or_implementation_execution=True))
api = {
    'schema': 'and-support-ordering-API-v1', **scope,
    'helper': dict(module_alias='receptor_support_ordering_v1', role='support_ordering',
                   version='receptor-and-support-ordering-v1',
                   strategy='ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1',
                   build='build_support_graph(*,spec,compiled,inventory,check,work_limit=200000)',
                   rank='rank_support_options(*,graph,known_rows,options,check,work_limit=200000)',
                   graph_statuses=['COMPLETE', 'UNKNOWN_WORK_BUDGET'],
                   ranking_statuses=['SCORED', 'STABLE_FALLBACK'],
                   graph_schema='receptor-and-support-graph-v1',
                   ranking_schema='receptor-and-support-ranking-v1'),
    'row_packet': dict(required_fields=['row', 'formula', 'requirements', 'provenance'],
                       row='exact nonnegative int; same row conflicts reject',
                       requirements='ordered [[strict_prior_absolute_row,exact_literal_formula],...] preserving duplicate ports',
                       provenance='full protected-caller command/guard/input-role or symbolic candidate evidence',
                       caller_obligation='Rows must be complete and valid under the unchanged current primitive/interface/point rules. Helper checks only literal strict-prior recursive references, not proof or point legality.'),
    'options': dict(layout="[{'option_id':builtin_provenance,'rows':[complete_projected_rows]},...]",
                    order='Exact full input-index permutation. Ties stable input order. Own quota/incomplete graph means identity. Every duplicate option/index remains.',
                    point_ties='Caller pre-orders the unchanged full Join pool by original FIXED score/index; helper then preserves that order on equal potential or fallback.',
                    partial_items='rows=[]; no invented or unfilled output credit',
                    additions_only_preferred='Existing complete row packets remain in known_rows, including currently unjustified rows. New earlier complete rows may recursively justify them; no missing premise becomes a fact.'),
    'graph_receipt': dict(full_preimage_once=True,
                          fields=['input_projection', 'formulas', 'edges', 'graph_sha256', 'target_formula_id', 'counts', 'work_limit'],
                          edges='All admitted zero-read literal outputs, basis MP antecedent+implication ordered ports, GEN actual body, all exported ground block ordered interfaces. Positive cost one; retain full provenance. Outside-root-basis edges retained inactive, never promoted as root commands.'),
    'ranking_receipt': dict(fields=['graph_sha256', 'known_rows', 'options', 'order', 'base_justification',
                                    'base_seed_formula_ids', 'base_costs', 'distinct_output_scores',
                                    'option_scores', 'counts', 'work_limit', 'status', 'reason'],
                            cache='Only per-call exact added-justified-formula-ID tuple; base seeds common, every original option references the distinct score. No cross-state authority or candidate deduplication.',
                            score='Least positive-cost AND relaxation, sum over ordered ports. Lower target potential after a valid projected output is greater marginal gain under the common base. None is an unknown stable tie, never impossibility.'),
    'check_and_budget': dict(check='Required protected callback invoked during copying, graph/projection and relaxation. Every delegated exception, including ValueError, propagates unchanged.',
                            own_limit='Exact int0..200000 per build/rank operation. Counts graph/projection/relaxation operations. Only private owner-matched own stop produces normal fallback. Copy/JSON/hash/receipt costs additionally charged to the caller absolute clock; copy_nodes disclosed separately.',
                            no_reset='Same overall/search absolute clock. No helper deadline or search extension reset.'),
    'symbolic': dict(module_alias='quantified_symbolic_control_v2', role='symbolic_control',
                     version='quantified-symbolic-prefix-control-v2-and-support-ordering',
                     signature="search_symbolic(*,spec,compiled,inventory,compiler,attempts=5000,seconds=30,strategy='NOVEL_BACKWARD_PRIORITY_DFS_V1',support_ordering=None)",
                     legacy_strategies=['NOVEL_BACKWARD_PRIORITY_DFS_V1', 'LEXICAL_PREFIX_DFS_V1'],
                     default_unchanged=True, standalone_no_parent_import=True,
                     support_strategy='ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1',
                     support_module_required_only_for_treatment=True,
                     stable_window=64,
                     source_order='The new treatment retains old NOVEL_BACKWARD candidate order as the input order of each bounded window. Only completed size64 or naturally exhausted tail windows are ranked. No all-candidate materialization or truncation.',
                     full_source_ref_multiplicity_preserved=True,
                     metadata='support_ordering=None in legacy; treatment full graph once plus ranking_calls containing exact full prefetched candidates, complete_window/natural iterator exhaustion flags and receipts. Partial window retained on owned search stop.',
                     exact_grammar='Original rows/skeleton k/basis variant v/mode/strict-prior ordered block source products/duplicate formulas/padding/key projection unchanged.',
                     unknown='Search wall/extension stop remains UNKNOWN. Helper scoring fallback does not mean grammar exhaustion. Exhaustion requires the full source iterator and all recursive alternatives to finish.'),
    'prospective_fixture': dict(source=fixture, version='receptor-and-support-provided-algorithm-fixtures-v1',
                                entry='run_algorithm_fixtures(*,helper,check)',
                                cases=['joint_and', 'positive_cycle', 'zero_read_licence', 'ordered_duplicate_ports',
                                       'duplicate_options', 'unjustified_row', 'own_work_fallback',
                                       'returned_ownership_and_input_restore', 'exact_caller_exception_origin'],
                                author_has_not_executed=True,
                                status='INACTIVE_SOURCE_PROPOSAL_REQUIRES_ROOT_DECLARATION_GRANT',
                                limits='Provided synthetic admission labels/rows, not native proof fixtures. First delegated callback exception paths only. Input/returned-packet restoration, not whole Graph/Model rollback.'),
    'sources': sources, 'ancestry': ancestry}
api_pin = write('API-v1.json', api)
contract = {
    'schema': 'and-support-ordering-Source-contract-v1', **scope,
    'author_identity': author, 'ancestry': ancestry,
    'source': sources['support_ordering'], 'sources': sources,
    'prospective_fixture': fixture, 'API': api_pin,
    'parent_control': pin(PARENT),
    'master': pin(ROOT / 'docs/basic-tiling-algorithm.md'),
    'frozen_design': pin('/private/tmp/gcts-curried-search-diagnosis-20261018/ordering-design-v1.json'),
    'dependency_contract': {
        'runtime_imports': 'Only Python standard-library modules in both runtime Sources. Helper is injected into symbolic V2, imported/sealed independently by the Root composition. No V1 runtime alias required.',
        'input_authority': 'Root must supply current complete compiler and all-or-none native registry under current full Source epoch/custody. Helper reads owned clones; caller validated row projections are a trust boundary, not facts accepted by this module.',
        'caller_check': 'Absolute current cooperative clock/source guard callback; callbacks assumed not to maliciously mutate protected implementation/graph/data. No formal OS/continuous seal or arbitrary mutating callback adversary is claimed.',
        'future_native': 'Every proposed final word still requires unchanged full point projection/decode and fresh whole native acceptance within the declared whole profile.'},
    'conformance': {
        'point_scheduler': 'This module never selects a point, edits t/m, mutates Graph or prunes. Library point integration must call only after global dead/forced and earliest-generation branch selection, preserve all alternatives and per-constituent validation/update/rollback.',
        'symbolic_control': 'Specialized conventional chronological symbolic search remains distinct from the GCTS scheduler. Its completed language and exact index/ref/key projection are preserved; trace or unit equivalence is not asserted.',
        'ranking_only': 'Positive AND support is not a theorem/proof, admissible lower bound, new native rule, sound pruning lemma or learned marking. Cycles without a genuine seed cannot self-seed; shared proofs/scope/row capacity can make estimates inaccurate.',
        'source_evidence': audit,
        'runtime_gaps': ['No helper or fixture or symbolic search has been evaluated by author.',
                         'No measured fit, proof, speed, search advantage, RL or generalization is claimed.',
                         'Finite synthetic qualification is only proposed and does not cover all inputs/checkpoint interleavings.',
                         'Full point adapter/driver/cold/outer/current epoch/grants and exact rollback/native admission require distinct current reviews and Root-only actuals.']},
    'review_ABI': {
        'schema': 'and-support-ordering-independent-Source-review-v1',
        'required_fields': ['reviewer_identity', 'author_identity', 'source_review_passed',
                            'source_only', 'scientific_calls', 'actual_execution_authorized',
                            'sources', 'contract', 'API', 'ancestry', 'limitations'],
        'reviewer_must_not_author_current_runtime_sources': True,
        'pass_scope': 'Raw Source/AST/dependency/complete-multiplicity/error-origin/budget/patch review only; no runtime or scientific acceptance.'}}
contract_pin = write('Source-contract-v1.json', contract)
delta_pin = write('Source-delta-v1.json', dict(schema='and-support-ordering-Source-delta-v1',
                  **scope, parent=pin(PARENT), successor=sources['symbolic_control'],
                  retained_top_regions=retained,
                  changed='VERSION/strategy declarations, optional helper ABI gate, support graph once, bounded-window wrapper/complete-row projections, extra result metadata/scope; original guard/candidate iterator/visitation rollback/key projection retained.',
                  added_runtime_helper=sources['support_ordering'], prospective_fixture=fixture,
                  audit=audit, inert_patch_directions=patch_results))
handoff = write('handoff-v1.json', dict(schema='and-support-ordering-author-handoff-v1', **scope,
                author_identity=author, ancestry=ancestry, source=sources['support_ordering'],
                sources=sources, prospective_fixture=fixture, contract=contract_pin,
                API=api_pin, delta=delta_pin, author_audit=audit,
                source_authoring_scripts=[pin(D/'author_symbolic_v2.py'), pin(Path(__file__))],
                review_ABI=contract['review_ABI'],
                next_action='Distinct Source review, Root prospective qualification/composition/declaration/grants only. No activation or actual is authorized.'))
print(json.dumps(handoff, sort_keys=True))
