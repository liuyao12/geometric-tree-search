"""Prospective pure-algorithm fixtures, unexecuted by the Source author.

All admission labels and complete rows here are explicitly PROVIDED synthetic
data. They test ordering mechanics, not native validity, theorem discovery,
point legality, exact row-language equivalence or arbitrary interruption paths.
Only Root may execute under a separately declared qualification grant.
"""
import hashlib
import json

VERSION = 'receptor-and-support-provided-algorithm-fixtures-v1'
CASE_IDS = ('joint_and', 'positive_cycle', 'zero_read_licence',
            'ordered_duplicate_ports', 'duplicate_options', 'unjustified_row',
            'own_work_fallback', 'returned_ownership_and_input_restore',
            'exact_caller_exception_origin')


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def _copy(value):
    return json.loads(_json(value))


def _fixture():
    atoms = {name: ['pred', name, []] for name in ('A', 'B', 'C', 'D', 'E', 'Z', 'W')}
    a, b, c, d, e, z, w = (atoms[n] for n in ('A', 'B', 'C', 'D', 'E', 'Z', 'W'))
    u = ['all', 'x', d]
    licence = ['imp', u, d]
    definitions = [dict(name=name, definition=dict(name=name, premises=ps,
                                                   conclusion=out, proof=[]),
                        fixture_status='PROVIDED_SYNTHETIC_NOT_NATIVE_CHECKED')
                   for name, ps, out in [('and_pair', [a, b], c),
                                         ('duplicate_pair', [a, a], e),
                                         ('cycle_zw', [z], w), ('cycle_wz', [w], z)]]
    basis = [a, b, c, d, e, z, w, u, licence]
    catalog = dict(basis=basis, variables=['x'], root_context='PROVIDED_SYNTHETIC_CLOSED_ROOT')
    compiled = dict(status='complete', catalog=catalog, basis=basis, variables=['x'],
                    tautologies=[], admitted_schemes=[dict(rule='instantiate', formula=licence,
                                                         universal=u, term=['var', 'x'])],
                    queries=['PROVIDED_FIXTURE_NO_NATIVE_QUERY'])
    spec = dict(length=12, target=c, theory=dict(axioms={'a': a}, schemas=[],
                                               functions={}, predicates={n: 0 for n in atoms}),
                fixture_status='PROVIDED_SYNTHETIC_NO_NATIVE_ADMISSION')
    inventory = dict(status='native_accepted', definitions=definitions,
                     interfaces=[r['name'] for r in definitions],
                     native_blocks=[r['definition'] for r in definitions],
                     fixture_status='PROVIDED_SYNTHETIC_LABEL_ONLY')
    return spec, compiled, inventory, atoms


def run_algorithm_fixtures(*, helper, check):
    """Root-only future invocation. No project/native/solver APIs are accepted."""
    check()
    spec, compiled, inventory, atoms = _fixture()
    originals = _json([spec, compiled, inventory])
    graph = helper.build_support_graph(spec=spec, compiled=compiled,
                                       inventory=inventory, check=check)
    results = []
    records = graph['graph_preimage']['formulas']
    identifiers = {_json(r['formula']): r['formula_id'] for r in records}

    def row(index, name, requirements=None):
        return dict(row=index, formula=atoms[name], requirements=requirements or [],
                    provenance=dict(fixture='PROVIDED_VALID_COMPLETE_ROW_ONLY', name=name))

    def rank(known, options, limit=200000):
        return helper.rank_support_options(graph=graph, known_rows=known, options=options,
                                            check=check, work_limit=limit)

    def cost(receipt, name):
        identifier = identifiers[_json(atoms[name])]
        return next(r['cost'] for r in receipt['base_costs'] if r['formula_id'] == identifier)

    known = [row(0, 'A')]
    options = [dict(option_id='no_new_fact', rows=[]), dict(option_id='provided_B', rows=[row(1, 'B')])]
    joint = rank(known, options)
    results.append(dict(case_id='joint_and', passed=joint['status'] == 'SCORED' and
                        cost(joint, 'C') is None and joint['order'] == [1, 0], receipt=joint))
    results.append(dict(case_id='positive_cycle', passed=cost(joint, 'Z') is None and cost(joint, 'W') is None,
                        receipt_reference='joint_and'))
    results.append(dict(case_id='zero_read_licence', passed=cost(joint, 'D') is None and
                        any(e['rule'] == 'instantiate' and e['ordered_premises'] == []
                            for e in graph['graph_preimage']['edges']), receipt_reference='joint_and'))
    empty = rank([], [])
    duplicate_edge = next(e for e in graph['graph_preimage']['edges']
                          if e['rule'] == 'block' and e['provenance']['interface_name'] == 'duplicate_pair')
    results.append(dict(case_id='ordered_duplicate_ports', passed=cost(empty, 'E') == 3 and
                        duplicate_edge['ordered_premises'][0] == duplicate_edge['ordered_premises'][1],
                        receipt=empty))
    duplicates = rank(known, [dict(option_id=0, rows=[row(1, 'B')]),
                              dict(option_id=1, rows=[row(1, 'B')])])
    results.append(dict(case_id='duplicate_options', passed=duplicates['order'] == [0, 1] and
                        len(duplicates['option_scores']) == 2 and len(duplicates['distinct_output_scores']) == 1,
                        receipt=duplicates))
    unsupported = rank(known, [dict(option_id='unfilled', rows=[row(2, 'B', [[1, atoms['A']]])])])
    results.append(dict(case_id='unjustified_row', passed=unsupported['status'] == 'SCORED' and
                        unsupported['distinct_output_scores'][0]['added_formula_ids'] == [], receipt=unsupported))
    budget_graph = helper.build_support_graph(spec=spec, compiled=compiled,
                                              inventory=inventory, check=check, work_limit=0)
    budget_rank = rank(known, options, 0)
    graph_fallback = helper.rank_support_options(graph=budget_graph, known_rows=known,
                                                 options=options, check=check)
    results.append(dict(case_id='own_work_fallback', passed=budget_graph['status'] == 'UNKNOWN_WORK_BUDGET' and
                        budget_rank['status'] == graph_fallback['status'] == 'STABLE_FALLBACK' and
                        budget_rank['order'] == graph_fallback['order'] == [0, 1],
                        graph=budget_graph, ranking=budget_rank, graph_ranking=graph_fallback))
    pristine = _json([known, options])
    returned = rank(known, options)
    returned['options'][1]['rows'][0]['formula'][1] = 'RETURNED_PACKET_MUTATION'
    repeat = rank(known, options)
    results.append(dict(case_id='returned_ownership_and_input_restore',
                        passed=_json([known, options]) == pristine and
                        _json([spec, compiled, inventory]) == originals and repeat == joint,
                        repeat_receipt=repeat,
                        limit='Literal input/returned builtin packets only; not Model/state/Graph rollback.'))
    exceptions = []
    for operation in ('graph', 'rank'):
        for exception_type in (ValueError, RuntimeError):
            marker = exception_type('PROVIDED_CALLER_CHECK_SENTINEL')
            def delegated_check():
                check()
                raise marker
            caught = None
            try:
                if operation == 'graph':
                    helper.build_support_graph(spec=spec, compiled=compiled,
                                               inventory=inventory, check=delegated_check)
                else:
                    helper.rank_support_options(graph=graph, known_rows=known,
                                                options=options, check=delegated_check)
            except BaseException as error:
                if error is not marker:
                    raise
                caught = error
            exceptions.append(dict(operation=operation, exception_type=exception_type.__name__,
                                   exact_identity_propagated=caught is marker))
    results.append(dict(case_id='exact_caller_exception_origin',
                        passed=all(e['exact_identity_propagated'] for e in exceptions), observations=exceptions,
                        limit='First delegated callback in each operation only; not all interleavings or late checkpoints.'))
    check()
    return dict(schema='receptor-and-support-provided-fixture-result-v1', version=VERSION,
                declared_case_ids=list(CASE_IDS), case_results=results,
                complete_case_inventory=len(results) == len(CASE_IDS),
                full_case_inventory_pass=len(results) == len(CASE_IDS) and all(r['passed'] for r in results),
                graph=graph, input_sha256=hashlib.sha256(originals).hexdigest(),
                scientific_acceptance=False, native_proof_accepted=False,
                provided_fixture_not_native_admission=True,
                scope='Pure ordering implementation fixtures only; no target theorem, real point state, graph rollback, native proof or search comparison.')
