"""Source text successor generation only; does not import/evaluate either control."""
from pathlib import Path

D = Path('/private/tmp/gcts-and-support-ordering-source-20261018')
parent = Path('/private/tmp/gcts-symbolic-control-source-20261018/quantified_symbolic_control_v1.py')
text = parent.read_text()
text = text.replace("VERSION = 'quantified-symbolic-prefix-control-v1'", "VERSION = 'quantified-symbolic-prefix-control-v2-and-support-ordering'")
text = text.replace("STRATEGIES = ('NOVEL_BACKWARD_PRIORITY_DFS_V1', 'LEXICAL_PREFIX_DFS_V1')", "STRATEGIES = ('NOVEL_BACKWARD_PRIORITY_DFS_V1', 'LEXICAL_PREFIX_DFS_V1',\n              'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1')\nSUPPORT_VERSION = 'receptor-and-support-ordering-v1'\nSUPPORT_WINDOW = 64\nSUPPORT_WORK_LIMIT = 200000")
old = "                    seconds=30, strategy='NOVEL_BACKWARD_PRIORITY_DFS_V1'):"
new = "                    seconds=30, strategy='NOVEL_BACKWARD_PRIORITY_DFS_V1',\n                    support_ordering=None):"
assert text.count(old) == 1
text = text.replace(old, new)
old = "    if strategy not in STRATEGIES:\n        raise SymbolicDataError('undeclared symbolic strategy')"
new = old + "\n    if strategy == 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1' and (\n            getattr(support_ordering, 'VERSION', None) != SUPPORT_VERSION or\n            getattr(support_ordering, 'STRATEGY', None) != strategy or\n            not callable(getattr(support_ordering, 'build_support_graph', None)) or\n            not callable(getattr(support_ordering, 'rank_support_options', None))):\n        raise SymbolicDataError('current injected support ordering required')"
assert text.count(old) == 1
text = text.replace(old, new)
old = '    distances_record = []\n    try:'
new = "    distances_record = []\n    support_record = None\n    if strategy == 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1':\n        support_record = dict(version=SUPPORT_VERSION, graph=None, ranking_calls=[],\n                              window_size=SUPPORT_WINDOW, work_limit=SUPPORT_WORK_LIMIT,\n                              metrics=dict(prefetched_candidates=0, complete_windows=0,\n                                           scored_windows=0, fallback_windows=0),\n                              scope='Bounded stable windows over the unchanged complete candidate iterator; no candidate/ref/word/padding quotient or pruning. Only completed windows are ranked. Partial prefetch is retained on an owned search stop.')\n    try:"
assert text.count(old) == 1
text = text.replace(old, new)
old = "            grammar['preparation_complete'] = True"
new = "            if support_record is not None:\n                support_record['graph'] = support_ordering.build_support_graph(\n                    spec=spec, compiled=compiled, inventory=inventory,\n                    check=budget.check, work_limit=SUPPORT_WORK_LIMIT)\n            grammar['preparation_complete'] = True"
assert text.count(old) == 1
text = text.replace(old, new)
text = text.replace("                if strategy == 'NOVEL_BACKWARD_PRIORITY_DFS_V1':", "                if strategy in ('NOVEL_BACKWARD_PRIORITY_DFS_V1',\n                                 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1'):")
marker = '            def visit(parent_event):'
addition = '''            def complete_row_packet(command, row, source_commands, provenance):
                rule = command['rule']
                if rule == 'block':
                    definition = definitions[command['name']]['definition']
                    requirements = [[source, formula] for source, formula in
                                    zip(command['inputs'], definition['premises'])]
                    if len(command['inputs']) != len(definition['premises']):
                        raise SymbolicDataError('full ordered block port tuple required')
                elif rule == 'mp':
                    requirements = [[command['antecedent'], source_commands[command['antecedent']]['formula']],
                                    [command['implication'], source_commands[command['implication']]['formula']]]
                elif rule == 'generalize':
                    requirements = [[command['source'], command['formula'][2]]]
                else:
                    requirements = []
                return dict(row=row, formula=_owned(command['formula']),
                            requirements=_owned(requirements), provenance=_owned(provenance))

            def ranked_candidates(row):
                iterator = candidates(row)
                if support_record is None:
                    yield from iterator
                    return
                # Enumeration and every prefetch/scoring check use the same
                # original absolute budget; there is no scoring-clock reset.
                known_rows = [complete_row_packet(command, source, path,
                                                  dict(chosen_candidate=chosen[source]))
                              for source, command in enumerate(path)]
                while True:
                    window = []
                    record = dict(row=row, complete_window=False,
                                  source_iterator_exhausted=False,
                                  candidates=window, ranking=None)
                    support_record['ranking_calls'].append(record)
                    for unused in range(SUPPORT_WINDOW):
                        budget.check()
                        try:
                            candidate = next(iterator)
                        except StopIteration:
                            record['source_iterator_exhausted'] = True
                            break
                        window.append(candidate)
                        support_record['metrics']['prefetched_candidates'] += 1
                    record['complete_window'] = True
                    if not window:
                        # Natural end is recorded; it is never replaced by a
                        # shortlist, scoring failure or yielded-candidate cap.
                        return
                    support_record['metrics']['complete_windows'] += 1
                    options = [dict(option_id=dict(window_option=index,
                                                    skeleton_index=candidate['skeleton_index'],
                                                    guard_variant=candidate['guard_variant'],
                                                    mode=candidate['mode']),
                                    rows=[complete_row_packet(candidate['command'], row, path,
                                                              dict(candidate=candidate))])
                               for index, candidate in enumerate(window)]
                    receipt = support_ordering.rank_support_options(
                        graph=support_record['graph'], known_rows=known_rows,
                        options=options, check=budget.check,
                        work_limit=SUPPORT_WORK_LIMIT)
                    record['ranking'] = receipt
                    order = receipt['order']
                    if sorted(order) != list(range(len(window))):
                        raise SymbolicDataError('support order changed candidate multiplicity')
                    label = 'scored_windows' if receipt['status'] == 'SCORED' else 'fallback_windows'
                    support_record['metrics'][label] += 1
                    for index in order:
                        budget.check()
                        yield window[index]
                    if record['source_iterator_exhausted']:
                        return

'''
assert text.count(marker) == 1
text = text.replace(marker, addition + marker)
text = text.replace('                    for candidate in candidates(len(path)):', '                    for candidate in ranked_candidates(len(path)):')
old = '                backward_distances=distances_record, events=events, metrics=metrics,'
new = old + '\n                support_ordering=support_record,'
assert text.count(old) == 1
text = text.replace(old, new)
old = "scope='Bounded conventional chronological symbolic control. Novel-output/backward distance is ordering only:"
new = "scope='Bounded conventional chronological symbolic control. Novel-output/backward distance and optional positive-cost AND support are ordering only:"
assert text.count(old) == 1
text = text.replace(old, new)
(D / 'quantified_symbolic_control_v2.py').write_text(text)
print('Authored Source text only.')
