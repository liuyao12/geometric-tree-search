"""Distinct new outer DELTA review. Raw/AST/compile-only/inert text patches.

No research module, worker, native program, solver, codec or target is imported
or evaluated. This reviewer authored the parent outer: inherited semantics are
relied on via the genuine parent peer, not independently self-certified here.
"""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

D = Path('/private/tmp/gcts-and-support-once-peer-20261018')
SOURCE = Path('/private/tmp/gcts-and-support-cold-source-20261018')
HANDOFF = SOURCE / 'handoff-v1.json'
CONTRACT = SOURCE / 'once-Source-contract-v1.json'
PARENT_PEER = Path('/private/tmp/gcts-compact-model-cold-once-independent-peer-20261018/typed-Source-review-v2.json')
D.mkdir(exist_ok=True)

def pin(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return dict(path=str(p), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))

def load(path):
    return json.loads(Path(path).read_bytes())

def write(name, value):
    p = D / name
    p.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    return pin(p)

checks = []
def ck(name, value, details=None):
    checks.append(dict(check=name, passed=bool(value), details=details))
    if not value:
        raise AssertionError(name)

handoff, contract, parent_peer = load(HANDOFF), load(CONTRACT), load(PARENT_PEER)
ck('exact new handoff pin', pin(HANDOFF) == dict(path=str(HANDOFF), sha256='c00fd42acaf6353ac235a833c90863174c9f72304e6ad35843cf74d9d418380e', bytes=3074))
ck('exact current once contract pin', pin(CONTRACT) == handoff['once_contract'])
ck('genuine inherited distinct Source peer', pin(PARENT_PEER)['sha256'] == 'd1fed0448738dbe07efbd2482a6259dc58ecf21473a3cbf46bf09e61a242d4a2' and
   parent_peer['reviewer_identity'] == '/root/receiver_driver_review' and parent_peer['author_identity'] == '/root/conventional_control_review' and
   parent_peer['source_review_passed'] is True and parent_peer['source_only'] is True and parent_peer['scientific_calls'] == 0)
ck('new author independent of reviewer', contract['author_identity'] == '/root/receiver_driver_review')
ck('review ABI exact scoped schema', contract['review_ABI']['schema'] == 'and-support-once-typed-Source-review-v1' and
   contract['review_ABI']['scope'] == 'and-support-once-Source')
for name in ('API', 'delta', 'inert_false_fixtures'):
    ck('raw pinned contract attachment ' + name, pin(contract[name]['path']) == contract[name])
api = load(contract['API']['path'])
delta = load(contract['delta']['path'])
sources = contract['sources']
parents = contract['parents']
texts, trees, parent_texts, parent_trees = {}, {}, {}, {}
retained, changed, diffs, patch_results = {}, {}, {}, []

def top_regions(tree):
    return {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}

def raw_region(text, node):
    return ''.join(text.splitlines(True)[node.lineno - 1:node.end_lineno])

def dump(node):
    return ast.dump(node, include_attributes=False)

def globals_literal(tree):
    answer = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                answer[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    return answer

for role, descriptor in sources.items():
    ck('exact new Source raw pin ' + role, pin(descriptor['path']) == descriptor == handoff['sources'][role])
    ck('exact retained parent raw pin ' + role, pin(parents[role]['path']) == parents[role] == parent_peer['sources'][role])
    texts[role], parent_texts[role] = Path(descriptor['path']).read_text(), Path(parents[role]['path']).read_text()
    trees[role], parent_trees[role] = ast.parse(texts[role]), ast.parse(parent_texts[role])
    compile(trees[role], descriptor['path'], 'exec')
    ck('parse and compile WITHOUT evaluation ' + role, True)
    new_nodes, old_nodes = top_regions(trees[role]), top_regions(parent_trees[role])
    ck('same top-level callable inventory ' + role, set(new_nodes) == set(old_nodes))
    retained[role], changed[role] = [], []
    for name in old_nodes:
        raw_equal = raw_region(texts[role], new_nodes[name]) == raw_region(parent_texts[role], old_nodes[name])
        ast_equal = dump(new_nodes[name]) == dump(old_nodes[name])
        if raw_equal and ast_equal:
            retained[role].append(name)
        else:
            changed[role].append(name)
    ck('only declared changed callable regions ' + role,
       changed[role] == delta['changed_top_level_raw_and_AST'][role], changed[role])
    folder = D / ('inert-patch-' + role)
    folder.mkdir(exist_ok=True)
    target = folder / 'payload.py'
    target.write_text(parent_texts[role])
    diff = ''.join(difflib.unified_diff(parent_texts[role].splitlines(True), texts[role].splitlines(True), fromfile='payload.py', tofile='payload.py'))
    inverse = ''.join(difflib.unified_diff(texts[role].splitlines(True), parent_texts[role].splitlines(True), fromfile='payload.py', tofile='payload.py'))
    (folder / 'forward.patch').write_text(diff)
    (folder / 'inverse.patch').write_text(inverse)
    diffs[role] = diff
    for direction, patch, expected in [('forward', diff, texts[role]), ('inverse', inverse, parent_texts[role])]:
        result = subprocess.run(['patch', '--batch', '-p0'], input=patch.encode(), cwd=folder,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        ck('real independent inert F0 direction ' + role + '/' + direction,
           result.returncode == 0 and target.read_text() == expected)
        patch_results.append(dict(role=role, direction=direction, exit_code=result.returncode,
                                  whole_output=pin(target), stdout=result.stdout.decode(), stderr=result.stderr.decode()))

runner = trees['once_runner']
old_runner = parent_trees['once_runner']
g, oldg = globals_literal(runner), globals_literal(old_runner)
ck('LIMITS literal whole equality to independently reviewed parent', g['LIMITS'] == oldg['LIMITS'])
ck('fixed scientific profile unchanged', g['LIMITS']['work_seconds'] == 180 and g['LIMITS']['overall_seconds'] == 210 and
   g['LIMITS']['aggregate_peak_bytes'] == 1073741824 and g['LIMITS']['result_bytes'] == 134217728 and
   g['LIMITS']['stdout_bytes'] == g['LIMITS']['stderr_bytes'] == 4194304)
ck('only fixed and symbolic modes', g['KINDS'] == ('fixed', 'symbolic'))
ck('mandatory fixed compact storage and two orderings', g['STORAGES'] == ('literal_interned',) and g['ORDERINGS'] == ('legacy', 'and_support'))
ck('exact frozen new cold pin', g['COLD_PIN'] == handoff['sources']['cold'] and pin(g['COLD_PIN']['path']) == g['COLD_PIN'])
ck('exact expected four review roles', set(g['REVIEW_ROLES']) == {'ordering_Source','composition_Source','once_Source','prospective_plans'})
expected_reviews = {
    'ordering_Source': ('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
    'composition_Source': ('and-support-driver-cold-typed-Source-review-v1','source_review_passed','/root/conventional_library'),
    'once_Source': ('and-support-once-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
    'prospective_plans': ('and-support-prospective-plan-review-v1','prospective_review_passed','/root/conventional_library')}
ck('current exact reviewer/schema/pass-field map', g['REVIEW_ROLES'] == expected_reviews)
for role, triplet in expected_reviews.items():
    a = api['review_roles'][role]
    ck('API reviewer schema/pass binding ' + role, (a['schema'], a['pass'], a['reviewer']) == triplet)

def inner_by_name(tree, name):
    return {n.name: n for n in ast.walk(top_regions(tree)[name]) if isinstance(n, ast.FunctionDef) and n.name != name}

new_inner, old_inner = inner_by_name(runner, 'run_once'), inner_by_name(old_runner, 'run_once')
ck('same nested lifecycle callable inventory', set(new_inner) == set(old_inner), list(new_inner))
for name in old_inner:
    ck('INHERITED ONLY exact nested raw/AST lifecycle ' + name,
       raw_region(texts['once_runner'], new_inner[name]) == raw_region(parent_texts['once_runner'], old_inner[name]) and
       dump(new_inner[name]) == dump(old_inner[name]))
for name in retained['once_runner']:
    ck('INHERITED ONLY unchanged helper ' + name, name in delta['retained_top_level_raw_and_AST']['once_runner'])

rt = texts['once_runner']
manual = [
 ('18 mandatory once fields including ordering', "'schema','invocation_id','mode','search_ordering','model_storage','result_reader','receiver_id','actual_directory'"),
 ('exact full plan field set and current schema', 'set(plan)==fields and plan[\'schema\']==PLAN_SCHEMA'),
 ('strict string ordering gate', "type(plan['search_ordering'])is str and plan['search_ordering'] in ORDERINGS"),
 ('complete worker/once ordering join', "('invocation_id','mode','search_ordering','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure')"),
 ('complete22 project plus2 component alias join', "len(names)==24 and closure['schema']=='ROOT-and-support-ordering-raw-runtime-closure-v1'"),
 ('full literal alias maps equal', "closure['materialized_aliases']==names and closure['runtime']['Python_executable']==plan['python']"),
 ('four unique IDs and four unique dirs', "len({r['actual_directory'] for r in schedule})==4"),
 ('complete method-ordering factorial', "{(m,o) for m in KINDS for o in ORDERINGS}"),
 ('all common assertion storage reader', "r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned'"),
 ('mandatory own arm ordering schedule join', "('mode','search_ordering','result_reader','receiver_id','actual_directory','model_storage')"),
 ('original nominal scientific compile/search profile', "'search_seconds':30,'search_max_nodes':5000,'compile_queries':512"),
 ('ordering Source minimum subjects exact three modules', "('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')"),
 ('composition Source minimum cold and driver', "'composition_Source':[plan['cold'],worker['components']['receiver_driver']]"),
 ('once Source minimum both Sources', "'once_Source':[plan['runner'],plan['observer']]"),
 ('plans review minimum declaration closure worker', "'prospective_plans':[plan['integration_declaration'],plan['runtime_closure'],plan['worker_plan']]"),
 ('all raw review schema/pass/author mismatch/current identity gates', "review['schema']==schema and review[passed] is True and review['reviewer_identity']==reviewer"),
 ('review no scientific or actual authority', "review['scientific_acceptance'] is False and review['actual_execution_authorized'] is False"),
 ('required whole descriptor containment', "contains_literal(review,subject)"),
 ('exact seven auth fields', "set(auth)==auth_fields and auth['schema']==AUTH_SCHEMA"),
 ('Root maximum-one literal true authorization', "auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations'])is int"),
 ('subject removes only authorization descriptor', "subject={k:v for k,v in plan.items() if k!='authorization'}"),
 ('marker records mandatory ordering before Popen', "'mode':plan['mode'],'search_ordering':plan['search_ordering'],'model_storage':plan['model_storage']"),
 ('worker receipt mandatory method-ordering join', "('invocation_id','mode','search_ordering','model_storage','receiver_id','integration_declaration')"),
 ('result and epoch bind ordering', "result['search_ordering']==plan['search_ordering'] and result['source_epoch']['search_ordering']==plan['search_ordering']"),
 ('selected search role depends only closed mode', "search_role='family_search' if plan['mode']=='fixed' else 'symbolic_control'"),
 ('search alias binds original and owned whole preimages', "search_subject['original']==worker['project_sources'][search_alias]"),
 ('search owned matches result module pin', "search_subject['owned']==result['module_pins'][search_role]"),
 ('helper alias binds full original preimage', "support_subject['original']==worker['project_sources']['receptor_support_ordering_v1']"),
 ('helper owned matches result module pin', "support_subject['owned']==result['module_pins']['support_ordering']"),
 ('receipt emits method ordering subject', "'mode':plan['mode'],'search_ordering':plan['search_ordering']")]
for name, snippet in manual:
    ck('NEW DELTA reviewed: ' + name, snippet in rt)

# Literal set extraction, without invoking a Source function.
run_node = top_regions(runner)['run_once']
field_sets = {n.targets[0].id: ast.literal_eval(n.value) for n in run_node.body
              if isinstance(n, ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)
              and n.targets[0].id in ('fields','auth_fields')}
ck('literal once18 schema equals API', len(field_sets['fields']) == 18 and field_sets['fields'] == set(api['once_fields']))
ck('literal auth7 schema equals API', len(field_sets['auth_fields']) == 7 and field_sets['auth_fields'] == set(api['authorization_fields']))

observer_text = texts['terminal_observer']
ck('observer binds current runner SHA', sources['once_runner']['sha256'] in observer_text)
ck('observer current plan and terminal schema', api['once_schema'] in observer_text and "and-support-ordering-final-terminal-observation-v1" in observer_text)
ck('observer method-ordering exact terminal join', "receipt['search_ordering']==plan['search_ordering']" in observer_text)
ck('observer old 225 failure-only wait unchanged', "process.wait(timeout=225)" in observer_text and "process.kill();process.wait(timeout=5)" in observer_text)
ck('observer unchanged positive gate conjunction retained', "receipt['owned_group_absent'] is True" in observer_text and
   "receipt['stdout_eof'] is True and receipt['stderr_eof'] is True and receipt['log_capture_complete'] is True" in observer_text and
   "observed<receipt['overall_deadline_ns']" in observer_text)

# Cross-artifact producer/consumer coupling only. This is NOT a scientific
# review of cold/driver/helper/point implementation semantics.
cold_text = Path(handoff['sources']['cold']['path']).read_text()
cold_tree = ast.parse(cold_text)
cg = globals_literal(cold_tree)
ck('cold and once worker receipt schema agree', cg['WORKER_SCHEMA'] == g['WORKER_RECEIPT_SCHEMA'] == api['worker_receipt_schema'])
ck('cold and once worker schema agree', cg['PLAN_SCHEMA'] == api['worker_schema'])
ck('cold fixed selected role aliases', cg['ROLE_MODULES']['family_search'] == 'semantic_inventory_search_v2' and
   cg['ROLE_MODULES']['symbolic_control'] == 'quantified_symbolic_control_v2' and cg['ROLE_MODULES']['support_ordering'] == 'receptor_support_ordering_v1')
for role, alias in [('family_search','semantic_inventory_search_v2'), ('symbolic_control','quantified_symbolic_control_v2'), ('support_ordering','receptor_support_ordering_v1')]:
    ck('current raw dependency descriptor coupling only ' + role,
       cg['ORDERING_COMPONENT_SOURCES'][role] == contract['external_ordering_sources'][role] == contract['expected_project_sources'][alias])
ck('complete dependency Source map22 present', len(contract['expected_project_sources']) == 22)
ck('cold authenticates literal whole expected Source maps', "plan['project_sources']==closure['project_sources']==expected_project" in cold_text)
ck('cold copies full24 aliases before selecting modes', "len(plan['project_sources'])==22 and len(names)==24" in cold_text)
ck('cold epoch includes ordering', "search_ordering=plan['search_ordering']" in cold_text and
   "result_data['source_epoch']['search_ordering']==plan['search_ordering']" in cold_text)
ck('cold emits selected search and helper original/owned bindings', "selected_search_module=dict" in cold_text and
   "support_ordering_module=dict" in cold_text)

inherited_scope = {
    'genuine_parent_peer': pin(PARENT_PEER), 'reviewer_authored_parent': True,
    'parent_source_author': '/root/conventional_control_review',
    'parent_independent_reviewer': '/root/receiver_driver_review',
    'retained_logic_not_self_certified': True,
    'exact_parent_scope_reused': ['strict parser/duplicate/nonfinite rejection',
                                'Source-entry original180 positive known worker exit/210 terminal',
                                'exclusive max-one marker and exact four cold argv',
                                'known Python/native wait4 and conservative separate high-water sum',
                                'authoritative postreap group absence/EOF/log drain',
                                'no signals after absence and permanent reappearance veto',
                                'stable OS metadata polling/whole intake and conditional final Python custody'],
    'conditional_final_raw_loop': 'The inherited final outer whole Python/source loop follows aggregate profile acceptance. Earlier or memory-failed diagnostics skip it and cannot claim its success.'}
audit = write('raw-Source-delta-audit-v1.json', dict(
    schema='and-support-once-independent-delta-audit-v1', source_only=True,
    scientific_calls=0, actual_execution_authorized=False, scientific_acceptance=False,
    author_identity='/root/receiver_driver_review', reviewer_identity='/root/conventional_control_review',
    handoff=pin(HANDOFF), source_contract=pin(CONTRACT), API=contract['API'],
    sources=sources, parents=parents, inherited_scope=inherited_scope,
    checks=checks, check_count=len(checks), mismatch_count=0,
    retained_regions=retained, changed_regions=changed,
    complete_raw_diffs=diffs, actual_inert_patch_directions=patch_results,
    no_runtime_or_scientific_implementation_evaluation=True))
limitations = [
    'This reviewer authored inherited parent outerV2 and current helper/symbolic Sources. This receipt independently reviews Receiver-authored new binding delta only. Exact retained lifecycle/parser/runtime logic relies on genuine prior Receiver peer d1fed; it is not a fresh independent self-certificate.',
    'Helper/point/symbolic semantics, driver/cold scientific implementation and prospective cohort/declaration/full grants require separate distinct peers. Their descriptors are joined here as custody evidence only.',
    'Four runtime review roles check exact schemas/PASS/expected reviewer/raw descriptors and minimum containment, not mathematical scope/ancestry. Root must externally validate exact current subjects, author/reviewer scope, the full24Source closure and every prospective worker/grant. Two different roles intentionally share Library reviewer identity.',
    'No current declaration, actual, grant, process launch, target import, result decode, native/solver/compiler/Model/search/codec/renderer or fixture evaluation occurred. Compile-without-eval and genuinely inert text patches only.',
    'Parent-only OS metadata/callable assumptions are unchanged; no formal continuous worker seal, escaped descendant guarantee or live aggregate memory limit. Conservative separate Darwin worker plus native peaks exclude outer/observer RAM.',
    'Positive output and known worker exit must precede original180; all terminal gates before210. Failed memory diagnostics may have EOF/group data while skipping later outer whole raw loop. UNKNOWN is never a proof or nonprovability result.',
    'Source PASS grants no execution, resource fit, proof/native acceptance, RL/GCTS/search advantage, publication or goal completion.']
receipt = write('typed-Source-review-v1.json', dict(
    schema='and-support-once-typed-Source-review-v1', scope='and-support-once-Source',
    author_identity='/root/receiver_driver_review', reviewer_identity='/root/conventional_control_review',
    sources=sources, source=sources['once_runner'], source_contract=pin(CONTRACT),
    handoff=pin(HANDOFF), API=contract['API'], source_delta=contract['delta'],
    inherited_parent_review=pin(PARENT_PEER), parents=parents,
    source_only=True, source_review_passed=True, scientific_calls=0,
    scientific_acceptance=False, actual_execution_authorized=False,
    resource_acceptance=False, project_imports=0, target_imports=0, native_calls=0,
    solver_calls=0, search_calls=0, model_calls=0, compiler_calls=0, codec_calls=0,
    renderer_calls=0, runtime_evaluations=0, compile_without_evaluation_count=2,
    actual_F0_patch_directions=4, check_count=len(checks), mismatch_count=0,
    findings=[dict(id='CURRENT_BINDING_DELTA', severity='evidence',
                   finding='New mandatory ordering joins are present through plan/declaration/four factorial slots/marker/worker/result epoch/current search+helper owned/original pins/outer and terminal receipts. Four scoped current review roles bind full raw subjects. No parser, resource, lifecycle, reappearance-veto, argv or Python-custody change was found.'),
              dict(id='INHERITED_AUTHOR_OVERLAP', severity='scope', finding=inherited_scope)],
    ancestry=dict(reviewed_new_delta_independently=True, authored_inherited_parent=True,
                  authored_helper_and_symbolic=True, new_outer_author_is_distinct=True,
                  inherited_logic_relies_on_genuine_prior_peer=True),
    audit=audit, review_Source=pin(Path(__file__)), limitations=limitations))
handoff_pin = write('handoff-v1.json', dict(schema='and-support-once-peer-handoff-v1',
                       source_only=True, scientific_calls=0, scientific_acceptance=False,
                       actual_execution_authorized=False, receipt=receipt, audit=audit,
                       source_contract=pin(CONTRACT), sources=sources))
print(json.dumps(handoff_pin, sort_keys=True))
