from pathlib import Path
import ast, hashlib, json

D=Path('/private/tmp/gcts-and-support-prospective-peer-20261018')
P=Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1')
A=Path('/private/tmp/gcts-and-support-cold-source-20261018')
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
I=P/'prospective-index-v1.json'
checks=[];checked_pins={}
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
    p=Path(p);h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=n)
def ck(name,ok,detail=None):
    checks.append(dict(check=name,passed=bool(ok),detail=detail))
    if not ok:raise AssertionError(name)
def pin(p,name):
    key=(p['path'],p['sha256'],p['bytes'])
    if key not in checked_pins:
        ck(name,desc(p['path'])==p)
        checked_pins[key]=dict(p)
    else:ck(name+' duplicate literal pin',checked_pins[key]==p)
def load(p,name):pin(p,name);return json.loads(Path(p['path']).read_bytes())
def emit(name,obj):
    p=D/name;p.write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n');return desc(p)
index=json.loads(I.read_bytes())
ck('exact current false index',desc(I)==dict(path=str(I),sha256='1b171500c4ed8d3d2e7eb32e32718051ec10642ce869ebf65cc67cb6153cfb5a',bytes=9481))
ck('false Source-only index',index['actual_execution_authorized'] is False and index['actuals_started']==0 and index['scientific_calls']==0)
API=load(index['API'],'exact current composition API')
handoff=load(index['composition_handoff'],'exact composition handoff')
declaration=load(index['declaration'],'exact current Root integration declaration')
closure=load(index['runtime_closure'],'exact current Root runtime closure')
cc=load(handoff['composition_contract'],'current Source coupling contract')
old=load(closure['parent_closure'],'literal parent63fa closure')
parentdecl=load(declaration['parent_structural_declaration'],'whole original19fab benchmark declaration')
load(declaration['parent_storage_declaration'],'whole parent storage declaration b4a')
load(declaration['frozen_next_work'],'Root frozen next work')
ck('new public schemas exact',declaration['schema']==API['declaration_schema'] and closure['schema']==API['closure_schema'])
ck('no activation in declaration and closure',declaration['actual_execution_authorized'] is False and closure['actual_execution_authorized'] is False and declaration['scientific_calls']==closure['scientific_calls']==0)
ck('declaration binds exact closure',declaration['runtime_closure']==index['runtime_closure'])
ck('index Source roles exactly API',index['review_role_schemas']==API['review_roles'])
for key in ('runner','observer','cold'):ck('current exact '+key+' Source',index[key]==handoff['sources'][{'runner':'once_runner','observer':'terminal_observer','cold':'cold'}[key]])
for role,source in handoff['sources'].items():pin(source,'current composition executable Source '+role)
ck('Root current handoffs exact',declaration['composition_Source_handoff']==index['composition_handoff'] and declaration['ordering_Source_handoff']==index['ordering_handoff'] and declaration['point_Source_handoff']==index['point_handoff'])
load(index['ordering_handoff'],'full frozen ordering handoff')
load(index['point_handoff'],'full frozen point handoff')
# No scientific formula evaluation: compare the complete receiver input to the old declaration occurrence.
receivers=parentdecl['receivers'];ids=[r['id'] for r in receivers]
ck('original whole declaration receiver IDs unique',len(ids)==len(set(ids)))
selected=declaration['selected_receiver'];rid=declaration['selected_receiver_id']
ck('exact selected c3 literal assertion unchanged',rid=='quantified-curried-two-premise-001' and selected==receivers[ids.index(rid)])
ck('original12 rows/two catalog snapshots',type(selected['length']) is int and selected['length']==12 and type(selected['instantiation_rounds']) is int and selected['instantiation_rounds']==2)
ck('ordinary input-only envelope',set(selected)<={'id','title','scope','theory','target','length','instantiation_rounds'} and set(selected['theory'])=={'functions','predicates','axioms','schemas'} and selected['theory']['schemas']==[])
ck('not a proof-route input',not (set(selected)&{'proof','commands','blocks','assumptions','bindings','families','rows','placements'}))
# Exact parent Source/runtime maps. No imported Source is evaluated.
expected=dict(old['project_sources'])
expected.pop('semantic_inventory_search');expected.pop('quantified_symbolic_control_v1')
expected.update({API['runtime_role_aliases'][r]:p for r,p in API['ordering_sources'].items()})
ck('exact22 complete current project Sources',closure['project_sources']==expected==cc['expected_project_sources'] and len(expected)==22)
for k in ('Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python'):
    ck('complete old map unchanged '+k,closure[k]==old[k])
ck('complete common two components',closure['additional_nonseed_components']==dict(receiver_driver=handoff['sources']['receiver_driver'],bounded_transport=old['additional_nonseed_components']['bounded_transport']))
aliases=dict(expected,semantic_receiver_driver=closure['additional_nonseed_components']['receiver_driver'],bounded_request_oracle=closure['additional_nonseed_components']['bounded_transport'])
ck('exact24 materialized aliases common',closure['materialized_aliases']==aliases and closure['materialized_project_and_component_count']==len(aliases)==24 and closure['project_module_count']==22)
for name,p in aliases.items():pin(p,'raw full alias Source '+name)
# Independently enumerate every raw AST import site, including nested statements.
imports=[];dynamic=[];edges={n:[] for n in aliases};stdlib=set();external=set();unknown=[]
for name,p in sorted(aliases.items()):
    tree=ast.parse(Path(p['path']).read_text())
    for n in ast.walk(tree):
        targets=[]
        if isinstance(n,ast.Import):targets=[a.name for a in n.names]
        elif isinstance(n,ast.ImportFrom):targets=[n.module or '']
        for target in targets:
            root=target.split('.')[0]
            if root in aliases:kind='project';edges[name].append(root)
            elif root in closure['external_imports']:kind='external';external.add(root)
            elif root in closure['stdlib_import_roots']:kind='stdlib';stdlib.add(root)
            else:kind='unknown';unknown.append((name,root,n.lineno))
            imports.append(dict(source_module=name,line=n.lineno,form=type(n).__name__,import_name=target,root=root,kind=kind))
        if (isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='__import__'):
            ck('literal dynamic import '+name+':'+str(n.lineno),len(n.args)>=1 and isinstance(n.args[0],ast.Constant) and type(n.args[0].value) is str)
            dynamic.append(dict(module=name,line=n.lineno,import_name=n.args[0].value,call_AST=ast.dump(n,include_attributes=False)))
            stdlib.add(n.args[0].value.split('.')[0])
# Match multisets/order-independent; Source locations remain exact literal evidence.
ck('all126 current import sites exact',sorted(imports,key=canonical)==sorted(closure['import_sites'],key=canonical) and len(imports)==126)
ck('all current project import edges exact',{n:sorted(set(v)) for n,v in edges.items()}==closure['project_import_edges'])
ck('both literal dynamic math imports exact',sorted(dynamic,key=canonical)==sorted(closure['literal_dynamic_import_sites'],key=canonical) and len(dynamic)==2)
ck('no unknown import roots',not unknown and closure['unresolved_project_imports']==[] and closure['raw_project_import_closure_complete_for_declared_seeds'] is True)
ck('all stdlib roots match',sorted(stdlib)==closure['stdlib_import_roots'])
ck('all external imports match',sorted(external)==closure['external_imports'])
# Whole opaque native input hashes, no decoding.
for name,p in closure['fixed_native_inputs'].items():
    if type(p) is dict and set(p)=={'path','sha256','bytes'}:pin(p,'opaque native fixed input '+name)
pin(closure['native_CPP']['binary'],'exact existing native binary raw')
pin(closure['native_CPP']['source'],'exact existing native compiler Source raw')
pin(closure['runtime']['Python_executable'],'exact original Python executable raw')
for p in closure['Z3']['files']:
    q={k:p[k] for k in ('path','sha256','bytes')};pin(q,'exact fixed Z3 file '+Path(p['path']).name)
ck('all41 Z3 files retained',len(closure['Z3']['files'])==closure['Z3']['file_count']==41)
# Compare numeric profile to the fixed declaration and literal outer Source LIMITS AST.
runnertext=Path(index['runner']['path']).read_text();runnertree=ast.parse(runnertext)
runnerconst={}
for n in runnertree.body:
    if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
        try:runnerconst[n.targets[0].id]=ast.literal_eval(n.value)
        except (ValueError,TypeError):pass
limits=runnerconst['LIMITS']
ck('exact original outer work/closure/memory/output/log caps',limits==dict(work_seconds=180,overall_seconds=210,aggregate_peak_bytes=1073741824,result_bytes=134217728,runner_plan_bytes=16777216,worker_receipt_bytes=4194304,stdout_bytes=4194304,stderr_bytes=4194304,poll_milliseconds=20,failure_cleanup_seconds=5))
expected_scientific=dict(work_seconds=180,overall_seconds=210,conservative_worker_plus_native_peak_bytes=1073741824,result_bytes=134217728,search_seconds=30,search_max_nodes=5000,compile_queries=512,guard_steps=10**9,registry_steps=5*10**9,proposal_steps=24,check_steps=2048,seed=64000)
ck('all scientific limits prospectively fixed',declaration['limits']==expected_scientific)
ck('fixed common storage/reader',declaration['model_storage']=='literal_interned' and declaration['result_reader']=='interned')
expected_order=[('fixed','legacy'),('symbolic','and_support'),('symbolic','legacy'),('fixed','and_support')]
ck('four scheduled fullfactorial same declared order',len(index['schedule'])==len(declaration['schedule'])==4 and [(r['mode'],r['search_ordering']) for r in index['schedule']]==expected_order)
ck('all invocation IDs unique',len({r['invocation_id'] for r in index['schedule']})==4)
ck('all actual dirs unique',len({r['actual_directory'] for r in index['schedule']})==4)
workers=[];subjects=[];auths=[];fresh=[]
common_worker=None
for ordinal,row in enumerate(index['schedule'],1):
    iid=row['invocation_id'];w=load(row['worker_plan'],iid+' worker plan');rp=load(row['runner_plan_draft'],iid+' once draft');au=load(row['authorization_draft'],iid+' false authorization')
    ck(iid+' exact18 worker fields',set(w)==set(API['worker_fields']) and len(w)==18 and w['schema']==API['worker_schema'])
    ck(iid+' exact18 once fields',set(rp)==set(API['once_fields']) and len(rp)==18 and rp['schema']==API['once_schema'])
    ck(iid+' exact7 false auth',set(au)==set(API['authorization_fields']) and len(au)==7 and au['schema']==API['authorization_schema'] and au['author_identity']=='/root' and au['actual_execution_authorized'] is False and type(au['maximum_actual_invocations']) is int and au['maximum_actual_invocations']==1 and au['review_roles']=={})
    subject={k:v for k,v in rp.items() if k!='authorization'}
    subject_sha=hashlib.sha256(canonical(subject)).hexdigest()
    ck(iid+' exact17field subject canonical preimage',len(subject)==17 and subject_sha==row['subject_sha256']==au['subject_sha256'])
    ck(iid+' index exactly matches declaration schedule',{k:row[k] for k in declaration['schedule'][ordinal-1]}==declaration['schedule'][ordinal-1] and row['order']==ordinal)
    ck(iid+' full worker/once/index/declaration identity',all(w[k]==rp[k]==row[k] for k in ('invocation_id','mode','search_ordering','actual_directory','receiver_id','model_storage','result_reader')))
    ck(iid+' complete Root artifact descriptors',w['integration_declaration']==rp['integration_declaration']==index['declaration'] and w['runtime_closure']==rp['runtime_closure']==index['runtime_closure'] and w['declaration']==declaration['parent_structural_declaration'])
    ck(iid+' all executable Source pins',rp['runner']==index['runner'] and rp['observer']==index['observer'] and rp['cold']==w['cold']==index['cold'])
    ck(iid+' exact full current Sources',w['project_sources']==expected and w['components']==closure['additional_nonseed_components'])
    ck(iid+' same fixed native inputs',w['native_inputs']==dict(program_and_template=closure['fixed_native_inputs']['program_and_template'],opaque_microcode_gzip=closure['fixed_native_inputs']['opaque_microcode_gzip'],native_cpp=closure['native_CPP']['binary']))
    ck(iid+' unchanged fourtemplate policy',w['policy']['sha256']=='f5f0c22121f4c503db319fe6e01c4c3a146ac9db9deb7e2ccec0aab1a2f32161' and w['policy']['bytes']==4502)
    pin(w['policy'],iid+' full policy raw')
    ck(iid+' current original Python runtime',rp['python']==w['python']==closure['runtime']['Python_executable'])
    ck(iid+' complete Z3 files and owned library',w['z3']['files']==[{k:p[k] for k in ('path','sha256','bytes')} for p in closure['Z3']['files']] and w['z3']['root']==closure['Z3']['package_root'] and w['z3']['library'] in w['z3']['files'] and w['z3']['library']['path']==str(Path(w['z3']['root'])/'z3/lib/libz3.dylib'))
    ck(iid+' exact current oncecaps',rp['limits']==limits)
    ck(iid+' no runtime loader override',rp['environment']==dict(LANG='en_US.UTF-8',LC_ALL='en_US.UTF-8',TZ='UTC'))
    ck(iid+' authorization and worker literal full descriptors',rp['authorization']==row['authorization_draft'] and rp['worker_plan']==row['worker_plan'])
    wc={k:v for k,v in w.items() if k not in ('invocation_id','mode','search_ordering','actual_directory')}
    if common_worker is None:common_worker=wc
    ck(iid+' all other18worker contents equal across arms',wc==common_worker)
    paths=[Path(row['actual_directory']),P/'runner-plans'/(iid+'-terminal-observation'),P/'runner-plan-drafts'/(iid+'-terminal-observation')]
    ck(iid+' all actual/observer output paths still absent',all(not p.exists() for p in paths))
    ck(iid+' canonical fresh actual parent',paths[0].is_absolute() and paths[0]==paths[0].resolve() and paths[0].parent.is_dir())
    fresh.append(dict(invocation_id=iid,paths=[dict(path=str(p),exists=p.exists()) for p in paths]))
    workers.append(row['worker_plan']);auths.append(row['authorization_draft'])
    subjects.append(dict(invocation_id=iid,worker_plan=row['worker_plan'],runner_plan_draft=row['runner_plan_draft'],authorization_draft=row['authorization_draft'],subject_sha256=subject_sha,subject_preimage=subject))
# Distinct current Source gate provenance, never own Source recertification.
component_review=Path('/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json')
comp_review=Path('/private/tmp/gcts-and-support-composition-peer-20261018/typed-Source-review-v1.json')
cr=json.loads(component_review.read_bytes());dr=json.loads(comp_review.read_bytes())
ck('component peer genuine current identity/pass',cr['reviewer_identity']=='/root/receiver_driver_review' and cr['source_review_passed'] is True and cr['scientific_calls']==0 and cr['scientific_acceptance'] is False and cr['actual_execution_authorized'] is False)
ck('component peer exact three Sources',cr['sources']==API['ordering_sources'])
ck('composition peer exact new sources',dr['sources']==cc['sources'] and dr['source_review_passed'] is True and dr['reviewer_identity']=='/root/conventional_library')
ancestry=dict(reviewer_identity='/root/conventional_library',author_identity='/root',
    authored_new_point_search_and_old_Model_driver_cold_bridge=True,
    authored_current_scoped_composition_Source_peer=True,
    current_review_scope='Root false prospective subjects and exact raw configuration/custody only; no self semantic certification of point/Model/own prior Sources or review.',
    distinct_ordering_Source_peer=desc(component_review),composition_Source_peer=desc(comp_review))
limitations=[
 'Source/raw/AST/descriptor metadata review only. No scientific import/evaluation, model generation, Native/solver/search/helper/codec/renderer or actual launched.',
 'False authorizations intentionally contain empty review_roles and cannot satisfy true-authorization/runtime role gate. This review and declaration authorize no actual.',
 'Current independent outer Source peer and final truegrant role adoption remain separate. False subjects must stay exactly identical except authorization descriptor when grants are issued.',
 'Raw Python/Z3/native opaque files were hashed only; no program/microcode or proof decoding. Runtime platform/origin/EOF/reaping/resource gates remain prospective actual obligations.',
 'Parent/observer memory remains excluded from conservative worker+Native separate-highwater admission. Source-entry wall includes complete shared setup; interpreter/observer prelude is separately observed, not silently relabeled.',
 'One known development c3 assertion/four single arms, no speed statistics, heldout result, new10case execution, RL or generic proof-search advantage.',
 'Full original Model, inventory, all ordered refs/candidates and raw output retained; point placements and symbolic row extensions remain different operation units.',
 'Closure nested_and_dynamic_scope retains stale descriptive all23 text while actual full literal map is24 and independent AST inventory is126 sites. This does not omit an alias; current exact counts/maps are authoritative.',
]
findings=[dict(id='P1',severity='nonblocking_metadata_prose',location='runtime_closure.nested_and_dynamic_scope',text='Inherited sentence says all23; literal22project+2components=24 and all126 AST importsites/2dynamic sites match current raw Sources.',disposition='No runtime/configuration mismatch; preserve as scoped stale wording, no Source/subject change required.'),
 dict(id='P2',severity='activation_boundary',text='No truegrant or actual is authorized by this scoped receipt; all four false/max1/emptyrole subjects remain deliberately unlaunchable.',disposition='Distinct final truegrant delta/current role review required.')]
audit=emit('raw-prospective-audit-v1.json',dict(schema='and-support-prospective-raw-audit-v1',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatches=0,
    raw_pins=list(checked_pins.values()),source_AST_imports=imports,dynamic_imports=dynamic,project_import_edges=edges,absent_paths=fresh,subjects=subjects,findings=findings,limitations=limitations,ancestry=ancestry))
review=emit('typed-prospective-plan-review-v1.json',dict(schema='and-support-prospective-plan-review-v1',scope='Root-and-support-false-prospective-subjects',author_identity='/root',reviewer_identity='/root/conventional_library',
    prospective_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    prospective_index=desc(I),declaration=index['declaration'],integration_declaration=index['declaration'],runtime_closure=index['runtime_closure'],
    worker_plans=workers,draft_runner_plans=[r['runner_plan_draft'] for r in index['schedule']],authorization_drafts=auths,subjects=subjects,
    sources=dict(cold=index['cold'],runner=index['runner'],observer=index['observer'],receiver_driver=cc['sources']['receiver_driver']),
    current_source_peers=dict(ordering=desc(component_review),composition=desc(comp_review)),
    audit=audit,check_count=len(checks),mismatches=0,findings=findings,blocking_findings=[],limitations=limitations,ancestry=ancestry))
handoff=emit('handoff-v1.json',dict(schema='and-support-prospective-review-handoff-v1',review=review,audit=audit,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False))
print(json.dumps(dict(review=review,audit=audit,handoff=handoff,checks=len(checks),raw_pins=len(checked_pins),science=0)))
