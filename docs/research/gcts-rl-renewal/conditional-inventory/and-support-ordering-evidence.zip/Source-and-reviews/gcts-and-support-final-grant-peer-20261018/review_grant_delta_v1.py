from pathlib import Path
import hashlib, json

D=Path('/private/tmp/gcts-and-support-final-grant-peer-20261018')
P=Path('/private/tmp/gcts-and-support-plans-ROOT-20261018-v1')
I=P/'authorized-index-v1.json'
F=P/'prospective-index-v1.json'
PR=Path('/private/tmp/gcts-and-support-prospective-peer-20261018/typed-prospective-plan-review-v1.json')
checks=[];rawpins=[]
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def descriptor(path):
    p=Path(path);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def ck(name,ok,detail=None):
    checks.append(dict(check=name,passed=bool(ok),detail=detail))
    if not ok:raise AssertionError(name)
def pin(p,name):
    ck(name,descriptor(p['path'])==p)
    if p not in rawpins:rawpins.append(p)
def load(p,name):pin(p,name);return json.loads(Path(p['path']).read_bytes())
def contains(value,literal):
    if value==literal:return True
    if type(value)is dict:return any(contains(v,literal) for v in value.values())
    if type(value)is list:return any(contains(v,literal) for v in value)
    return False
def emit(name,obj):
    p=D/name;p.write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n');return descriptor(p)
expected=dict(path=str(I),sha256='81a907b726aad1febb9b6781f7eadac519aeba6c073dd6dfade7cc5d03fdff33',bytes=13245)
pin(expected,'exact current authorized index')
index=json.loads(I.read_bytes());false=json.loads(F.read_bytes());prospective=json.loads(PR.read_bytes())
ck('false index remains exact own frozen review subject',descriptor(F)==prospective['prospective_index']==index['prospective_index'])
ck('own scoped false prospective peer exact current pin',descriptor(PR)==index['current_review_roles']['prospective_plans'] and prospective['prospective_review_passed'] is True and prospective['scientific_calls']==0)
ck('authorized index Root-owned metadata, no launched actuals',index['schema']=='ROOT-and-support-authorized-plan-index-v1' and index['author_identity']=='/root' and index['actual_execution_authorized'] is True and type(index['actuals_started'])is int and index['actuals_started']==0 and index['scientific_calls']==0 and index['source_only'] is True and index['scientific_acceptance'] is False and index['final_delta_still_required'] is True)
ck('four exact subjects',index['subject_count']==4 and len(index['schedule'])==len(false['schedule'])==4)
allowed_index={'schema','actual_execution_authorized','schedule','scope'}
ck('all preexisting index fields unchanged except declared metadata delta',all(index[k]==v for k,v in false.items() if k not in allowed_index))
adopt=load(index['Source_and_plan_adoption'],'exact Root Source-and-plan adoption')
sourceadopt=load(adopt['Source_adoption'],'exact Root scoped Source adoption')
ck('adoption binds exact frozen false index',adopt['prospective_index']==index['prospective_index'] and adopt['accepted_for_exact_prospective_subjects'] is True and adopt['actuals_started']==0 and adopt['actual_execution_authorized'] is False and adopt['scientific_calls']==0)
ck('adoption exact current four review roles',adopt['review_roles']==index['current_review_roles'])
ck('Source adoption exact current three implementation scopes',sourceadopt['review_roles']=={r:p for r,p in index['current_review_roles'].items() if r!='prospective_plans'} and sourceadopt['source_reviews_adopted_for_plan_review'] is True)
API=load(index['API'],'current API raw')
ck('review schemas unchanged frozen API',index['review_role_schemas']==false['review_role_schemas']==API['review_roles'])
roles=index['current_review_roles'];review_data={};role_evidence={}
expected_scope={'ordering_Source':'and-support-ordering-components-Source','composition_Source':'and-support-driver-cold-Source','once_Source':'and-support-once-Source','prospective_plans':'Root-and-support-false-prospective-subjects'}
for role,p in roles.items():
    r=load(p,'current typed '+role+' receipt')
    spec=API['review_roles'][role]
    ck(role+' exact typed pass/schema/reviewer/author distinction',r['schema']==spec['schema'] and r[spec['pass']] is True and r['reviewer_identity']==spec['reviewer'] and r['author_identity']!=r['reviewer_identity'])
    ck(role+' exact Source-only no-admission scope',r['scope']==expected_scope[role] and r['source_only'] is True and type(r['scientific_calls'])is int and r['scientific_calls']==0 and r['scientific_acceptance'] is False and r['actual_execution_authorized'] is False)
    ck(role+' explicit ancestry scope available','ancestry' in r and type(r['limitations'])is list and bool(r['limitations']))
    if role!='prospective_plans':
        ck(role+' Root Source-adoption scope matches exact receipt',sourceadopt['scopes'][role]['schema']==r['schema'] and sourceadopt['scopes'][role]['reviewer_identity']==r['reviewer_identity'] and sourceadopt['scopes'][role]['author_identity']==r['author_identity'] and sourceadopt['scopes'][role]['scope']==r['scope'])
    review_data[role]=r
    role_evidence[role]=dict(receipt=p,schema=r['schema'],scope=r['scope'],author_identity=r['author_identity'],reviewer_identity=r['reviewer_identity'],ancestry=r['ancestry'],limitations=r['limitations'])
ck('exact four distinct raw reviews across three external identities',len(roles)==4 and len({p['sha256'] for p in roles.values()})==4 and {r['reviewer_identity'] for r in review_data.values()}=={'/root/receiver_driver_review','/root/conventional_control_review','/root/conventional_library'})
ck('own point Source independently reviewed by Receiver',review_data['ordering_Source']['reviewer_identity']=='/root/receiver_driver_review' and review_data['ordering_Source']['sources']['family_search']['sha256']=='35443c958f2115efa18cc923fb4a4f1070e6e03ccf1d1adf2bb56ce1f7bab28b')
ck('own parent overlap is excluded from current coupling certificate',review_data['composition_Source']['ancestry']['authored_new_point_search'] is True and review_data['composition_Source']['author_identity']=='/root/receiver_driver_review')
ck('Control new outer delta peer uses external inherited-parent provenance',review_data['once_Source']['ancestry']['authored_inherited_parent'] is True and review_data['once_Source']['ancestry']['new_outer_author_is_distinct'] is True and review_data['once_Source']['inherited_parent_review']['sha256']=='d1fed0448738dbe07efbd2482a6259dc58ecf21473a3cbf46bf09e61a242d4a2')
# Fresh custody of exact raw Sources/declaration/closure/workerplans; no imports or execution.
for key in ('declaration','runtime_closure','runner','observer','cold','ordering_handoff','point_handoff','composition_handoff'):
    ck('current immutable top binding '+key,index[key]==false[key]);pin(index[key],'current raw '+key)
closure=json.loads(Path(index['runtime_closure']['path']).read_bytes())
for alias,p in closure['materialized_aliases'].items():pin(p,'raw current materialized Source '+alias)
ck('all24 Source aliases preserved',len(closure['materialized_aliases'])==24 and closure['materialized_project_and_component_count']==24)
all_rows=[];all_auth=[];all_plans=[];fresh=[]
for old,row,oldsubject in zip(false['schedule'],index['schedule'],prospective['subjects']):
    iid=row['invocation_id']
    ck(iid+' every old schedule field unchanged',all(row[k]==v for k,v in old.items()))
    ck(iid+' only final auth and once descriptors added',set(row)-set(old)=={'authorization','runner_plan'})
    w=load(row['worker_plan'],iid+' current raw worker unchanged')
    draft=load(row['runner_plan_draft'],iid+' false raw once draft unchanged')
    final=load(row['runner_plan'],iid+' final raw once plan')
    au0=load(row['authorization_draft'],iid+' false raw auth unchanged')
    au=load(row['authorization'],iid+' final raw true auth')
    ck(iid+' exact18 final and draft plan fields',set(final)==set(draft)==set(API['once_fields']) and len(final)==18)
    subject0={k:v for k,v in draft.items() if k!='authorization'};subject={k:v for k,v in final.items() if k!='authorization'}
    ck(iid+' only authorization descriptor changes final once plan',subject==subject0==oldsubject['subject_preimage'] and len(subject)==17)
    sha=hashlib.sha256(canonical(subject)).hexdigest()
    ck(iid+' exact same original subject sha',sha==row['subject_sha256']==au['subject_sha256']==au0['subject_sha256']==oldsubject['subject_sha256'])
    ck(iid+' exact18 worker and immutable rawpin',set(w)==set(API['worker_fields']) and len(w)==18 and row['worker_plan']==old['worker_plan']==oldsubject['worker_plan'] and final['worker_plan']==row['worker_plan'])
    ck(iid+' final auth and draft auth proper exact pins',final['authorization']==row['authorization'] and draft['authorization']==row['authorization_draft'])
    ck(iid+' exact original seven auth fields',set(au)==set(au0)==set(API['authorization_fields']) and len(au)==7)
    changes={k for k in au if au[k]!=au0[k]}
    ck(iid+' only flag fourroles and scope auth delta',changes=={'actual_execution_authorized','review_roles','scope'})
    ck(iid+' true Root max-one auth, no retry counter',au['actual_execution_authorized'] is True and au0['actual_execution_authorized'] is False and au['author_identity']=='/root' and type(au['maximum_actual_invocations'])is int and au['maximum_actual_invocations']==1 and au0['review_roles']=={} and au['schema']==API['authorization_schema'])
    ck(iid+' scope authorizes only exact once subject no salvage',type(au['scope'])is str and 'max-one' in au['scope'] and 'No retries or salvage' in au['scope'])
    ck(iid+' complete four review roles',set(au['review_roles'])==set(API['review_roles'])==set(roles))
    expected_subjects=dict(ordering_Source=[w['project_sources'][n] for n in ('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],composition_Source=[final['cold'],w['components']['receiver_driver']],once_Source=[final['runner'],final['observer']],prospective_plans=[final['integration_declaration'],final['runtime_closure'],final['worker_plan']])
    for role,binding in au['review_roles'].items():
        spec=API['review_roles'][role];r=review_data[role]
        ck(iid+'/'+role+' exact binding schema identity current receipt',set(binding)=={'receipt','reviewer_identity','required_subjects'} and binding['receipt']==roles[role] and binding['reviewer_identity']==spec['reviewer']==r['reviewer_identity'])
        ck(iid+'/'+role+' exact full minimum subjects, no arbitrary extras',binding['required_subjects']==expected_subjects[role])
        for s in binding['required_subjects']:
            ck(iid+'/'+role+' full literal raw subject in scoped receipt '+Path(s['path']).name,set(s)=={'path','sha256','bytes'} and contains(r,s))
        if role=='ordering_Source':ck(iid+' all3 ordering subjects semantically reviewed by distinct author',set(r['sources'])=={'family_search','support_ordering','symbolic_control'} and r['sources']['family_search']==expected_subjects[role][0] and r['sources']['symbolic_control']==expected_subjects[role][1] and r['sources']['support_ordering']==expected_subjects[role][2])
        elif role=='composition_Source':ck(iid+' coupling only correct2 current Source subjects',r['sources']==dict(cold=expected_subjects[role][0],receiver_driver=expected_subjects[role][1]))
        elif role=='once_Source':ck(iid+' outer only correct2 current Source subjects',r['sources']==dict(once_runner=expected_subjects[role][0],terminal_observer=expected_subjects[role][1]))
        else:ck(iid+' exact own Root plan review coverage, not Source cert',r['declaration']==expected_subjects[role][0] and r['runtime_closure']==expected_subjects[role][1] and expected_subjects[role][2] in r['worker_plans'])
    paths=[Path(row['actual_directory']),P/'runner-plans'/(iid+'-terminal-observation'),P/'runner-plan-drafts'/(iid+'-terminal-observation')]
    ck(iid+' actual and terminal observation folders remain absent',all(not p.exists() for p in paths))
    ck(iid+' exact full method/ordering/case/storage identity',all(w[k]==final[k]==row[k] for k in ('invocation_id','mode','search_ordering','actual_directory','receiver_id','model_storage','result_reader')))
    all_rows.append(dict(invocation_id=iid,order=row['order'],mode=row['mode'],search_ordering=row['search_ordering'],worker_plan=row['worker_plan'],draft_runner_plan=row['runner_plan_draft'],final_runner_plan=row['runner_plan'],draft_authorization=row['authorization_draft'],final_authorization=row['authorization'],subject_sha256=sha,subject_preimage=subject,review_roles=au['review_roles'],authorization_changed_fields=sorted(changes),maximum_actual_invocations=au['maximum_actual_invocations']))
    all_auth.append(row['authorization']);all_plans.append(row['runner_plan'])
    fresh.extend(dict(path=str(p),exists=False) for p in paths)
ck('all4 actual output directories unique',len({r['actual_directory'] for r in index['schedule']})==4)
ck('actual order unchanged fullfactorial',[(r['mode'],r['search_ordering']) for r in index['schedule']]==[('fixed','legacy'),('symbolic','and_support'),('symbolic','legacy'),('fixed','and_support')])
ancestry=dict(reviewer_identity='/root/conventional_library',author_identity='/root',
    authored_new_point_ordering_source_and_old_Model_driver_cold_bridge=True,
    authored_scoped_current_composition_and_falseplan_reviews=True,
    current_scope='Only Root-issued final truegrant metadata delta, raw immutable subject equality and current role/scope adoption; not self Source certification or new scientific acceptance.',
    independent_current_ordering_peer=roles['ordering_Source'],independent_current_outer_peer=roles['once_Source'])
limitations=[
 'Metadata/rawhash audit only. No project/Model/engine/helper/compiler/native/solver/codec/search/renderer/harness code imported or evaluated; no target result decoding, process launch or trial.',
 'This receipt has actual_execution_authorized=false and grants no launch. Existing Root true grants are described as data; Root must separately adopt final audit and require every agent idle before sequential execution.',
 'Four typed scopes use three external reviewer identities; Library legitimately fills coupling and Root-plan roles. Raw receipt hashes are distinct, exact minimum subjects and actual scope/ancestry are checked, not just PASS count.',
 'Reviewer authored own point/Model/parent compositions and earlier scoped reviews. Those implementations are not self-certified here; distinct Receiver ordering peer covers new point, and Control outer peer is limited to Receiver delta with genuine inherited-parent review.',
 'Whole scientific input, Source closure, compiler/registry/Model/native palette, grammar/candidates/fallback/output and original180/210/1GiB/128MiB caps are unchanged via exact17field subjects and worker rawpins. Runtime mathematical/resource/custody success remains an unperformed future gate.',
 'Inherited stale all23 closure prose is nonoperative; exact24 aliases/maps/counts and126 imports are the binding reviewed representation.',
 'No nine algorithm fixture or ten-case new input suite has been executed. Four known c3 development arms are not statistical/general/RL advantage evidence.',
 'Absent-path observations are at this audit point only; max-one exclusive consumption and post-run reaping/EOF/no-owned-group/time/memory/output checks remain Root runtime obligations.'
]
audit=emit('raw-final-grant-delta-audit-v1.json',dict(schema='and-support-raw-final-grant-delta-audit-v1',checks=checks,check_count=len(checks),mismatches=0,raw_pins=rawpins,
    role_evidence=role_evidence,grant_bindings=all_rows,absent_paths=fresh,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,ancestry=ancestry,limitations=limitations))
review=emit('typed-final-grant-delta-review-v1.json',dict(schema='and-support-final-grant-delta-review-v1',scope='Root-final-truegrant-metadata-delta-only',author_identity='/root',reviewer_identity='/root/conventional_library',
    final_grant_delta_review_passed=True,grant_delta_review_passed=True,source_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,
    authorized_index=expected,prospective_index=descriptor(F),prospective_plan_review=descriptor(PR),Root_Source_and_plan_adoption=index['Source_and_plan_adoption'],
    declaration=index['declaration'],runtime_closure=index['runtime_closure'],current_review_roles=roles,
    final_runner_plans=all_plans,final_authorizations=all_auth,grant_bindings=all_rows,
    check_count=len(checks),mismatches=0,findings=[],blocking_findings=[],fresh_absent_paths=fresh,audit=audit,ancestry=ancestry,limitations=limitations))
handoff=emit('handoff-v1.json',dict(schema='and-support-final-grant-review-handoff-v1',review=review,audit=audit,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,stop_tools=True))
print(json.dumps(dict(review=review,audit=audit,handoff=handoff,checks=len(checks),science=0)))
