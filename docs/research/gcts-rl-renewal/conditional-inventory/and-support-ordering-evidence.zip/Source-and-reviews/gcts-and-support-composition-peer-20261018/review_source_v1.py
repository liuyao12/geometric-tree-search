from pathlib import Path
import ast, hashlib, json, subprocess, difflib

D=Path('/private/tmp/gcts-and-support-composition-peer-20261018')
A=Path('/private/tmp/gcts-and-support-cold-source-20261018')
C=json.loads((A/'composition-Source-contract-v1.json').read_bytes())
H=json.loads((A/'handoff-v1.json').read_bytes())
checks=[]
def ck(name,ok,detail=None):
    checks.append(dict(check=name,passed=bool(ok),detail=detail))
    if not ok:raise AssertionError(name)
def desc(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def pin(pin,name):
    ck(name,desc(pin['path'])==pin);return Path(pin['path']).read_text()
def literal_assignments(tree):
    out={}
    for n in tree.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            try:out[n.targets[0].id]=ast.literal_eval(n.value)
            except (ValueError,TypeError):pass
    return out
def nodes(tree):
    return {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def astword(n):return ast.dump(n,include_attributes=False)
def emit(name,obj):
    p=D/name;p.write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n');return desc(p)
ck('exact declared composition contract',desc(A/'composition-Source-contract-v1.json')==H['composition_contract'])
ck('exact API',desc(A/'API-v1.json')==H['API'])
API=json.loads((A/'API-v1.json').read_bytes())
newtexts={};oldtexts={};trees={};constants={};retained={};patchruns=[]
for role in ('receiver_driver','cold'):
    new=pin(C['sources'][role],role+' current full Source')
    old=pin(C['parents'][role],role+' parent full Source')
    ck(role+' handoff descriptor agrees',C['sources'][role]==H['sources'][role]==API['sources'][role])
    newtexts[role]=new;oldtexts[role]=old
    newtree=ast.parse(new);oldtree=ast.parse(old);trees[role]=newtree;constants[role]=literal_assignments(newtree)
    compile(new,C['sources'][role]['path'],'exec')
    ck(role+' compile without evaluating',True)
    nn=nodes(newtree);oo=nodes(oldtree)
    ck(role+' complete top-level callable inventory preserved',list(nn)==list(oo))
    changed={'_Boundary','run_receiver'} if role=='receiver_driver' else {'main'}
    retained[role]=[]
    for name,n0 in oo.items():
        n1=nn[name]
        if name in changed:continue
        ra=ast.get_source_segment(old,n0);rb=ast.get_source_segment(new,n1)
        ck(role+'/'+name+' raw and AST retained',ra==rb and astword(n0)==astword(n1))
        retained[role].append(dict(name=name,parent_lines=[n0.lineno,n0.end_lineno],source_lines=[n1.lineno,n1.end_lineno],raw_sha256=hashlib.sha256(ra.encode()).hexdigest()))
    if role=='receiver_driver':
        for name in ('observe','check','remaining'):
            m0=next(n for n in oo['_Boundary'].body if isinstance(n,ast.FunctionDef) and n.name==name)
            m1=next(n for n in nn['_Boundary'].body if isinstance(n,ast.FunctionDef) and n.name==name)
            ck('Boundary '+name+' raw and AST retained',astword(m0)==astword(m1) and ast.get_source_segment(old,m0)==ast.get_source_segment(new,m1))
        for name in ('stage',):
            f0=next(n for n in oo['run_receiver'].body if isinstance(n,ast.FunctionDef) and n.name==name)
            f1=next(n for n in nn['run_receiver'].body if isinstance(n,ast.FunctionDef) and n.name==name)
            ck('driver '+name+' stage custody raw/AST retained',astword(f0)==astword(f1) and ast.get_source_segment(old,f0)==ast.get_source_segment(new,f1))
    else:
        for name in ('overall_tick','now','stage','full_artifacts','source_guard','observed_cdll','oracle_factory','reader_tick'):
            f0=next(n for n in ast.walk(oo['main']) if isinstance(n,ast.FunctionDef) and n.name==name)
            f1=next(n for n in ast.walk(nn['main']) if isinstance(n,ast.FunctionDef) and n.name==name)
            ck('cold '+name+' raw/AST retained',astword(f0)==astword(f1) and ast.get_source_segment(old,f0)==ast.get_source_segment(new,f1))
    for direction,pre,expected in [('forward',old,new),('inverse',new,old)]:
        patch=A/(role+'-'+direction+'-v1.patch')
        scratch=D/(role+'-'+direction+'-scratch-v1b');scratch.mkdir(exist_ok=False)
        target=scratch/Path(C['sources'][role]['path']).name;target.write_text(pre)
        cp=subprocess.run(['patch','-F','0','-p0','-i',str(patch)],cwd=scratch,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        ck(role+' independent actual F0 '+direction,cp.returncode==0 and target.read_text()==expected)
        patchruns.append(dict(role=role,direction=direction,patch=desc(patch),command=['patch','-F','0','-p0','-i',str(patch)],returncode=cp.returncode,stdout=cp.stdout,stderr=cp.stderr,result=desc(target)))
    (D/(role+'-independent-raw-delta-v1.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent',tofile='current')))

# Exact imported project Sources and only declared parent-map replacements.
closure=json.loads(pin(C['parent_runtime_closure'],'complete current parent runtime closure'))
expected=dict(closure['project_sources'])
oldsearch=expected.pop('semantic_inventory_search');oldsymbolic=expected.pop('quantified_symbolic_control_v1')
expected['semantic_inventory_search_v2']=C['external_ordering_sources']['family_search']
expected['quantified_symbolic_control_v2']=C['external_ordering_sources']['symbolic_control']
expected['receptor_support_ordering_v1']=C['external_ordering_sources']['support_ordering']
ck('exact full expected project delta',expected==C['expected_project_sources'] and len(expected)==22)
for name,p in expected.items():pin(p,'exact project Source '+name)
ck('cold complete parent closure constant',constants['cold']['PARENT_RUNTIME_CLOSURE']==C['parent_runtime_closure'])
ck('cold exact external Source constants',constants['cold']['ORDERING_COMPONENT_SOURCES']==C['external_ordering_sources'])
ck('cold exact receiver driver constant',constants['cold']['RECEIVER_DRIVER_SOURCE']==C['sources']['receiver_driver'])
role_alias=constants['cold']['ROLE_MODULES'];dp=constants['receiver_driver']['DEPENDENCY_PINS']
ck('driver exact roles equal cold dispatch roles',set(dp)==set(role_alias)==set(API['driver_module_roles']))
for role,alias in role_alias.items():
    p=expected[alias]
    ck('driver exact selected dependency '+role,tuple(dp[role])==(p['sha256'],p['bytes']))
ck('all ordering aliases match API',all(role_alias[r]==alias for r,alias in API['runtime_role_aliases'].items()))
ck('no old search aliases in current map','semantic_inventory_search' not in expected and 'quantified_symbolic_control_v1' not in expected)
ck('compact and ordinary Model are both common Sources','quantified_family_points_v2' in expected and 'interned_quantified_family_points_v1' in expected)
ck('unchanged compact Model pin',constants['cold']['COMPACT_MODEL_SOURCE']==expected['interned_quantified_family_points_v1'])
ck('fixed full policy unchanged',constants['receiver_driver']['POLICY_SHA256']=='f5f0c22121f4c503db319fe6e01c4c3a146ac9db9deb7e2ccec0aab1a2f32161' and constants['receiver_driver']['POLICY_BYTES']==4502)
capnode=next(n.value for n in trees['receiver_driver'].body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='OUTPUT_CAP_BYTES' for t in n.targets))
ck('same128MiB result cap',ast.get_source_segment(newtexts['receiver_driver'],capnode).replace(' ','')=='128*1024*1024')
ck('epoch and worker schemas match public API',constants['cold']['EPOCH_SCHEMA']==constants['receiver_driver']['SOURCE_EPOCH_SCHEMA']==API['epoch_schema'] and constants['cold']['PLAN_SCHEMA']==API['worker_schema'] and constants['cold']['WORKER_SCHEMA']==API['worker_receipt_schema'])
# AST-call ABI coupling only; no function is called.
searchcalls={}
for n in ast.walk(trees['receiver_driver']):
    if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('search','search_symbolic'):
        searchcalls[n.func.attr]=n
point=searchcalls['search'];symbolic=searchcalls['search_symbolic']
ck('point explicit enum keyword forwarded',next(k for k in point.keywords if k.arg=='support_ordering').value.id=='search_ordering')
ck('point original complete arguments retained',[k.arg for k in point.keywords]==['attempts','seconds','proposal_limit','proposal_checks','seed','stochastic','weights','support_ordering'])
ck('point original work/pool/proposal/seed limits',all(ast.literal_eval(next(k for k in point.keywords if k.arg==key).value)==v for key,v in {'attempts':5000,'proposal_limit':24,'proposal_checks':2048,'seed':64000,'stochastic':False,'weights':None}.items()))
ck('symbolic strategy and shared helper injected',next(k for k in symbolic.keywords if k.arg=='strategy').value.id=='symbolic_strategy' and ast.get_source_segment(newtexts['receiver_driver'],next(k for k in symbolic.keywords if k.arg=='support_ordering').value)=="modules['support_ordering']")
ck('symbolic original exact input/limits retained',[k.arg for k in symbolic.keywords]==['spec','compiled','inventory','compiler','attempts','seconds','strategy','support_ordering'])
ck('search seconds still min30 whole remaining',"seconds = min(30, boundary.remaining())" in newtexts['receiver_driver'])
ck('actual module roles point distinct logical symbolic',role_alias['family_search']=='semantic_inventory_search_v2' and role_alias['symbolic_control']=='quantified_symbolic_control_v2')
# Exact Source clauses independently traced by reviewer above; these records locate them.
clauses={
 'mandatory caller ordering joins epoch':('receiver_driver',"source_epoch.get('search_ordering') != search_ordering"),
 'full output receipt ordering':('receiver_driver',"version=VERSION, mode=mode, search_ordering=search_ordering"),
 'native whole proof request exact':('receiver_driver',"native = stage('final_native', lambda: oracle.request(request, 5*10**9, 'fresh_quantified_receiver_final'))"),
 'proof accepted only exact returned native record':('receiver_driver',"selected proof rejected by unchanged whole native checker"),
 'complete policy/source input frozen':('receiver_driver',"receiver input, working spec or complete library changed"),
 'postsearch full model identity':('receiver_driver',"candidate model changed during search"),
 'exact current marker ordering':('cold',"marker['search_ordering']==plan['search_ordering']"),
 'four exact method-by-ordering schedule':('cold',"{(m,o) for m in ('fixed','symbolic') for o in ('legacy','and_support')}"),
 'common full24 module custody':('cold',"len(plan['project_sources'])==22 and len(names)==24"),
 'whole native fixed Source maps unchanged':('cold',"'Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime'"),
 'full owned epoch Source maps':('cold',"sources=dict(project=owned,original=names,cold=plan['cold'])"),
 'full output ordering epoch joins':('cold',"result_data['source_epoch']['search_ordering']==plan['search_ordering']"),
 'exact current selected search owned Source':('cold',"result_data['module_pins']['family_search' if plan['mode']=='fixed' else 'symbolic_control']=="),
 'whole literal result inverse remains mandatory':('cold',"literal=verify_literal_result(result_data,result_raw,reader_tick)"),
 'whole raw point/row check for native success':('cold',"region_check=(verify_raw_region(result_data,work_ns) if receipt['native_proof_accepted']"),
 'strict positive original work and full checked deadline':('cold',"need(checked<work_ns and _NOW_NS()<work_ns,'positive result and full Root checks within work')"),
 'native closure exact reaped0':('cold',"transport['native_exit_code']==0,'native exactly closed and reaped'"),
 'original noreset180/210':('cold',"work_ns==began+180000000000 and overall_ns==began+210000000000"),
 'unaccepted diagnostic resource header scope':('cold',"outer exact terminal/resource gates remain required"),
}
locations={}
for name,(role,snippet) in clauses.items():
    ck(name,snippet in newtexts[role])
    locations[name]=dict(role=role,line=newtexts[role][:newtexts[role].index(snippet)].count('\n')+1,literal_clause=snippet)
# This is a Source inventory only; no project import is performed.
imports=[]
for alias,p in expected.items():
    tr=ast.parse(Path(p['path']).read_text())
    for n in ast.walk(tr):
        rootname=n.module.split('.')[0] if isinstance(n,ast.ImportFrom) and n.module else None
        if rootname in expected:
            imports.append(dict(alias=alias,project_import=rootname,line=n.lineno))
        if isinstance(n,ast.Import):
            for a in n.names:
                if a.name.split('.')[0] in expected:imports.append(dict(alias=alias,project_import=a.name.split('.')[0],line=n.lineno))
ck('new point helper literal import resolves current map',any(i['alias']=='semantic_inventory_search_v2' and i['project_import']=='receptor_support_ordering_v1' for i in imports))

ancestry=dict(reviewer_identity='/root/conventional_library',current_author='/root/receiver_driver_review',
    authored_parent_driver_and_cold_bridge=True,authored_quantified_adapter_Model_and_compact_Model=True,
    authored_new_point_search=True,review_scope='Only new Receiver-authored coupling/delta/composition and exact inherited-region retention; not an independent semantic certification of own parent/Model/point Sources.',
    external_ordering_group='Distinct Receiver review required separately for helper/symbolic/point.',
    parent_independent_Source_peer=desc('/private/tmp/gcts-compact-model-cold-bridge-independent-peer-20261018/typed-Source-review-v1.json'))
limitations=[
 'Source-only review. No target/project/Model/compiler/helper/search/native/solver/codec/renderer or harness evaluated/imported. compile creates inert code objects only.',
 'Parent driver/cold and Model/point authorship disclosed; own implementations not re-certified. Exact new Source binding and preserved raw/AST regions are reviewed independently from their semantics.',
 'New complete Root runtime closure, profile/cohort declaration, falseplans, outer Source review, current ordering component peer and truegrant delta remain separate prospective activation gates.',
 'Root all24 aliases/raw imported component maps must match this exact composition in every arm. Whole setup costs differ from historical runs; no timing replication or equal point/symbolic work units claimed.',
 'Inherited trusted Python/stdlib/OS loader boundary and captured callable identity scope are not formal continuous worker sealing or arbitrary malicious callback protection.',
 'Inherited stop before Oracle construction may be a cold failure rather than salvageable UNKNOWN; no new fallback/repair is claimed.',
 'Own point search deadline can yield typed unknown empty-census setup tree; composition retains that as UNKNOWN, never exact exhaustion. Whole final proof still requires existing fresh Native and full raw point/row checks.',
 'After conservative memory failure outer final wholePython/source loop may be skipped as inherited; worker checks and prior resource diagnostics must be reported separately, no posthoc salvage.',
 'No runtime/proof, correctness of new support potential itself, speed, memory fit, RL or theorem-search advantage accepted by this review.'
]
findings=[dict(id='C1',severity='scope',status='CONDITIONAL_EXTERNAL_GATES',text='No blocking Source coupling issue found. Current ordering semantic peer and Root full closure/declaration/once/prospective/grant gates required; this receipt alone never authorizes execution.'),
          dict(id='C2',severity='limitation',status='INHERITED',text='Driver retains a syntactically unreachable z3 branch after explicit fixed/symbolic validation; its raw body is preserved and cannot run in this cohort.'),
          dict(id='C3',severity='limitation',status='INPUT_BOUNDARY',text='The run entry reads source_epoch.get before Boundary strict type validation; malformed non-dict direct callers can see AttributeError. Exact cold always constructs ordinary dict epoch; error propagates and cannot yield acceptance.'),]
audit=emit('raw-Source-audit-v1.json',dict(schema='and-support-driver-cold-raw-Source-audit-v1',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    checks=checks,check_count=len(checks),mismatches=0,retained_raw_AST=retained,retained_region_count=sum(map(len,retained.values())),patch_runs=patchruns,
    compile_without_evaluation_count=2,raw_changes={r:desc(D/(r+'-independent-raw-delta-v1.patch')) for r in newtexts},
    full_dependency_sources=expected,project_import_sites=imports,clause_locations=locations,
    external_ordering_sources_bound_not_semantically_certified=C['external_ordering_sources'],ancestry=ancestry,limitations=limitations))
review=emit('typed-Source-review-v1.json',dict(schema=C['review_ABI']['schema'],scope=C['review_ABI']['scope'],
    author_identity='/root/receiver_driver_review',reviewer_identity='/root/conventional_library',sources=C['sources'],source_contract=desc(A/'composition-Source-contract-v1.json'),
    source_handoff=desc(A/'handoff-v1.json'),API=desc(A/'API-v1.json'),source_only=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    findings=findings,blocking_findings=[],ancestry=ancestry,limitations=limitations,audit=audit,
    check_count=len(checks),mismatches=0,compile_without_evaluation_count=2,actual_inert_F0_patch_directions=4,
    review_subjects=dict(cold=C['sources']['cold'],components=dict(receiver_driver=C['sources']['receiver_driver'])),
    external_ordering_sources_bound_not_semantically_certified=C['external_ordering_sources']))
print(json.dumps(dict(review=review,audit=audit,check_count=len(checks),retained_regions=sum(map(len,retained.values())),scientific_calls=0)))
