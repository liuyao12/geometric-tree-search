from pathlib import Path
import hashlib

out = Path('/private/tmp/gcts-and-support-point-source-20261018')
parent = Path('/private/tmp/gcts-semantic-family-next-audit-20261018/semantic_inventory_search.py')
original = parent.read_bytes()
assert hashlib.sha256(original).hexdigest() == 'df296cb1ac2398cee3c23eb9436a6c27906802360489b20a7bb0e6a59736b188'
text = original.decode()
imports = '''from semantic_inventory_guidance import row_requirements
from receptor_support_ordering_v1 import (VERSION as SUPPORT_VERSION,
    STRATEGY as SUPPORT_STRATEGY, GRAPH_SCHEMA, RANK_SCHEMA,
    build_support_graph, rank_support_options)

VERSION = 'semantic-inventory-search-v2-shared-and-support'
SUPPORT_PROJECTION_WORK_LIMIT = 200000
SUPPORT_WORK_LIMIT = 200000


class _SupportDeadline(TimeoutError):
    """Only this module's own search-clock stop is converted to UNKNOWN."""


class _ProjectionStop(Exception):
    """A finite proposal projection abstains; it removes no original item."""


def _literal(value, charge):
    charge()
    if type(value) is dict:
        if any(type(k) is not str for k in value):
            raise ValueError('literal point projection dictionaries')
        return {k: _literal(v, charge) for k, v in value.items()}
    if type(value) in (list, tuple):
        return [_literal(v, charge) for v in value]
    if value is None or type(value) in (str, int, bool, float):
        return value
    raise ValueError('literal point projection values')


def _complete_rows(model, keys, charge):
    """Project actual complete C/G/all-input rows, without declaring facts.

    The shared helper independently checks literal ordered strict-prior
    requirements and recursively derives justified rows. Guard-only outputs
    and incomplete arbitrary samples never create a row packet here.
    """
    by_row = {}
    for key in sorted(set(keys)):
        charge()
        if key not in model.metadata or len(key) != 4:
            raise ValueError('actual point key required')
        row, role = key[:2]
        if (type(row) is not int or type(role) is not int or
                not 0 <= row < model.spec['length'] or
                not 0 <= role < 2 + model.arity):
            raise ValueError('actual row and declared input role required')
        roles = by_row.setdefault(row, {})
        if role in roles:
            raise ValueError('multiple placements on one row role')
        roles[role] = key
    result = []
    for row, roles in sorted(by_row.items()):
        charge()
        if len(roles) != 2 + model.arity:
            continue
        ordered = []
        for role in range(2 + model.arity):
            charge()
            ordered.append(roles[role])
        requirements = row_requirements(model, ordered, row)
        if requirements is None:
            continue
        command = model.metadata[roles[0]]['command']
        guard = model.metadata[roles[1]]['command']
        if command != guard:
            raise ValueError('complete row C/G agreement')
        result.append(dict(row=row,
            formula=_literal(guard['formula'], charge),
            requirements=_literal(requirements, charge),
            provenance=dict(kind='ACTUAL_COMPLETE_POINT_ROW',
                role_keys=_literal(ordered, charge),
                command=_literal(command, charge))))
    return result


def _support_choice(model, state, items, event, support_graph, check):
    """Rank the unchanged pool; original FIXED score/index breaks all ties."""
    projection = dict(work=0, limit=SUPPORT_PROJECTION_WORK_LIMIT,
                      aggregate_checks=0)
    legacy_order = sorted(range(len(items)),
                          key=lambda i: (-event['scores'][i], i))
    before = event['index']
    receipt = dict(schema='point-and-support-choice-v1',
        status='STABLE_FALLBACK', reason=None,
        legacy_index=before, selected_index=before,
        legacy_order=legacy_order, after_order=legacy_order[:],
        original_policy_scores=event['scores'][:],
        original_policy_probabilities=event['probabilities'][:],
        original_policy_probabilities_scope='Unchanged policy evidence; support ordering is deterministic.',
        projection=projection, validated_aggregates=[], ranking=None)

    def charge():
        check()
        if projection['work'] >= projection['limit']:
            raise _ProjectionStop('point_support_projection_work_budget')
        projection['work'] += 1

    try:
        known = _complete_rows(model, state.selected, charge)
        known_ids = {packet['row'] for packet in known}
        options = []
        for index in legacy_order:
            charge()
            item = items[index]
            rows = []
            if item is not None:
                check()
                actual = aggregate(model, item['members'], state)
                check()
                projection['aggregate_checks'] += 1
                if actual != {k: item[k] for k in
                        ('members', 'pending', 'aggregate_sha256',
                         'new_occupancy', 'new_marks')}:
                    raise ValueError('current support option aggregate')
                receipt['validated_aggregates'].append(dict(
                    original_index=index, aggregate=_literal(actual, charge)))
                union = set(state.selected).union(item['members'])
                rows = [packet for packet in _complete_rows(model, union, charge)
                        if packet['row'] not in known_ids]
            options.append(dict(option_id=dict(original_item_index=index), rows=rows))
        check()
        ranking = rank_support_options(graph=support_graph, known_rows=known,
            options=options, check=check, work_limit=SUPPORT_WORK_LIMIT)
        check()
        if (ranking.get('schema') != RANK_SCHEMA or
                ranking.get('version') != SUPPORT_VERSION or
                ranking.get('strategy') != SUPPORT_STRATEGY or
                ranking.get('status') not in ('SCORED', 'STABLE_FALLBACK')):
            raise ValueError('current shared support ranking protocol')
        order = ranking['order']
        if (type(order) is not list or any(type(i) is not int for i in order) or
                sorted(order) != list(range(len(items)))):
            raise ValueError('all original option multiplicity required')
        if ranking['status'] == 'STABLE_FALLBACK' and order != list(range(len(items))):
            raise ValueError('support abstention must preserve stable policy order')
        after = [legacy_order[i] for i in order]
        receipt.update(status=ranking['status'], reason=ranking['reason'],
                       after_order=after, selected_index=after[0], ranking=ranking)
    except _ProjectionStop:
        receipt['reason'] = 'point_support_projection_work_budget'
    check()
    return items[receipt['selected_index']], receipt

'''
needle='from turtle import Graph\n'
assert text.count(needle)==1
text=text.replace(needle,needle+imports)
old="def search(model,mode='base',weights=None,stochastic=False,seed=0,attempts=20000,seconds=60,proposal_limit=24,proposal_checks=2048):"
new=old[:-2]+",support_ordering='legacy'):"
assert old in text
text=text.replace(old,new)
needle="    if mode not in ('base','zero','fixed','learned','no-family'):raise ValueError('ordering lane')\n"
text=text.replace(needle,needle+"    if support_ordering not in ('legacy','and_support'):raise ValueError('support ordering lane')\n    if support_ordering=='and_support' and (mode!='fixed' or stochastic):raise ValueError('AND support requires deterministic fixed mode')\n")
needle="    def review(state,g,hint,p):\n"
setup='''    support_graph=None;support_stopped=False
    support_metadata=dict(schema='point-and-support-metadata-v1',version=VERSION,
        ordering=support_ordering,strategy=SUPPORT_STRATEGY,
        status='LEGACY_DISABLED',graph=None,graph_seconds=0.,
        helper_work_limit=SUPPORT_WORK_LIMIT,
        projection_work_limit=SUPPORT_PROJECTION_WORK_LIMIT,
        choice_receipts='Each applicable events[i].support_ordering retains full literal ranking evidence.',
        logical_authority=False,candidate_pruning=False,
        scope='Ordering existing validated Join items only; no new proposer, fact, marking, rule or bulk placement.')
    def support_check():
        if time.perf_counter()-began>=seconds:
            raise _SupportDeadline('point_support_search_deadline')
    if support_ordering=='and_support':
        if SUPPORT_VERSION!='receptor-and-support-ordering-v1' or SUPPORT_STRATEGY!='ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1':raise ValueError('shared support implementation')
        stage=time.perf_counter()
        try:
            support_check()
            support_graph=build_support_graph(spec=model.spec,compiled=model.compiled,
                inventory=model.inventory,check=support_check,work_limit=SUPPORT_WORK_LIMIT)
            support_check()
            if (support_graph.get('schema')!=GRAPH_SCHEMA or support_graph.get('version')!=SUPPORT_VERSION or support_graph.get('strategy')!=SUPPORT_STRATEGY or support_graph.get('status') not in ('COMPLETE','UNKNOWN_WORK_BUDGET')):raise ValueError('current shared support graph protocol')
            support_metadata.update(status=support_graph['status'],graph=support_graph)
            metrics['support_graph_work']+=support_graph['counts']['work']
        except _SupportDeadline:
            support_stopped=True;support_metadata['status']='UNKNOWN_SEARCH_DEADLINE';metrics['support_deadline_stops']+=1
        support_metadata['graph_seconds']=time.perf_counter()-stage
'''
assert text.count(needle)==1
text=text.replace(needle,setup+needle)
needle="        nonlocal found\n"
insert="""        if support_stopped:
            return None,dict(kind='unknown',point=None,census=[],state_sha256=root_state,
                hint_in=None,review=dict(phase='absent',pending=[],eligible=[]),
                children=[],cutoff='support_graph_deadline')
"""
text=text.replace(needle,needle+insert)
needle="            features=[vector(item,model,state,g) for item in items];item,event=choose(items,features,scoring,rng,stochastic)\n"
insert='''            support_deadline=False
            if support_ordering=='and_support':
                metrics['support_order_calls']+=1
                try:
                    item,support_choice=_support_choice(model,state,items,event,support_graph,support_check)
                    event['support_ordering']=support_choice;event['index']=support_choice['selected_index']
                    metrics['support_projection_work']+=support_choice['projection']['work']
                    metrics['support_aggregate_checks']+=support_choice['projection']['aggregate_checks']
                    if support_choice['ranking'] is not None:metrics['support_ranking_work']+=support_choice['ranking']['counts']['work']
                    if support_choice['status']=='STABLE_FALLBACK':metrics['support_stable_fallbacks']+=1
                    if support_choice['selected_index']!=support_choice['legacy_index']:metrics['support_changed_hint_choices']+=1
                except _SupportDeadline:
                    support_deadline=True;metrics['support_deadline_stops']+=1
                    event['support_ordering']=dict(schema='point-and-support-choice-v1',
                        status='UNKNOWN_SEARCH_DEADLINE',reason='point_support_search_deadline',
                        legacy_index=event['index'],selected_index=None,ranking=None,
                        scope='No support score or hint was consumed; full unchanged items retained in this event.')
'''
assert text.count(needle)==1
text=text.replace(needle,needle+insert)
needle="            if item is not None:\n                if aggregate(model,item['members'],state)"
assert text.count(needle)==1
text=text.replace(needle,"            if support_deadline:tree['cutoff']='support_ordering_deadline';return None,tree\n"+needle)
needle="                stochastic=stochastic,seed=seed,seconds=time.perf_counter()-began,root_state_sha256=root_state,root_restored=restored,\n"
assert text.count(needle)==1
text=text.replace(needle,needle+"                support_ordering=support_ordering,support_ordering_metadata=support_metadata,\n")
(out/'semantic_inventory_search_v2.py').write_text(text)
(out/'parent-semantic_inventory_search.py').write_bytes(original)
print({'source_bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()})
