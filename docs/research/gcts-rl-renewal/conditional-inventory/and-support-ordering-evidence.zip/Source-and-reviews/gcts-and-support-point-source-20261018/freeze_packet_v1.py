from pathlib import Path
import ast, copy, difflib, hashlib, json, subprocess

D=Path('/private/tmp/gcts-and-support-point-source-20261018')
P=Path('/private/tmp/gcts-semantic-family-next-audit-20261018/semantic_inventory_search.py')
S=D/'semantic_inventory_search_v2.py'
root=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')

def desc(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def emit(name,value):
    p=D/name;p.write_text(json.dumps(value,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n');return desc(p)
def dump(node):return ast.dump(node,include_attributes=False)
def segment(src,node):return ast.get_source_segment(src,node)
old=P.read_text();new=S.read_text()
assert desc(P)['sha256']=='df296cb1ac2398cee3c23eb9436a6c27906802360489b20a7bb0e6a59736b188'
assert desc(S)['sha256']=='35443c958f2115efa18cc923fb4a4f1070e6e03ccf1d1adf2bb56ce1f7bab28b'
parent=ast.parse(old);current=ast.parse(new)
# Compile creates an inert code object; it is never executed/imported.
compile(new,str(S),'exec')
fn0=next(n for n in parent.body if isinstance(n,ast.FunctionDef) and n.name=='search')
fn1=next(n for n in current.body if isinstance(n,ast.FunctionDef) and n.name=='search')
review0=next(n for n in fn0.body if isinstance(n,ast.FunctionDef) and n.name=='review')
review1=next(n for n in fn1.body if isinstance(n,ast.FunctionDef) and n.name=='review')
assert dump(review0)==dump(review1) and segment(old,review0)==segment(new,review1)
legacy=copy.deepcopy(fn1)
assert legacy.args.args[-1].arg=='support_ordering'
legacy.args.args.pop();legacy.args.defaults.pop()
# Delete only declared added setup/validation; retain the actual current nodes.
legacy.body=[n for n in legacy.body if not (156 <= n.lineno <= 157 or 161 <= n.lineno <= 186)]
visit=next(n for n in legacy.body if isinstance(n,ast.FunctionDef) and n.name=='visit')
assert isinstance(visit.body[1],ast.If) and isinstance(visit.body[1].test,ast.Name) and visit.body[1].test.id=='support_stopped'
visit.body.pop(1)
branch=next(n for n in visit.body if isinstance(n,ast.If) and segment(new,n.test)=="kind=='branch' and active is None and mode!='base'")
branch.body=[n for n in branch.body if not (
    isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='support_deadline' for t in n.targets)
    or isinstance(n,ast.If) and (isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Name) and n.test.left.id=='support_ordering'
        or isinstance(n.test,ast.Name) and n.test.id=='support_deadline'))]
ret=legacy.body[-1]
assert isinstance(ret,ast.Return)
ret.value.keywords=[k for k in ret.value.keywords if k.arg not in ('support_ordering','support_ordering_metadata')]
assert dump(legacy)==dump(fn0), 'declared AST inverse must exactly recover original search'
# Whole module inverse: remove only new imports/globals/callables and project the actual changed search.
module_inverse=ast.Module(body=[copy.deepcopy(n) for n in current.body if any(dump(n)==dump(o) for o in parent.body if not isinstance(o,ast.FunctionDef))]+[legacy],type_ignores=[])
assert dump(module_inverse)==dump(parent)
retained=[]
for n0 in ast.walk(fn0):
    if isinstance(n0,(ast.For,ast.FunctionDef,ast.If,ast.Return)):
        matches=[n1 for n1 in ast.walk(fn1) if type(n1) is type(n0) and dump(n1)==dump(n0)]
        raw=[n1 for n1 in matches if segment(new,n1)==segment(old,n0)]
        if raw:
            n1=raw[0];retained.append(dict(kind=type(n0).__name__,parent_lines=[n0.lineno,n0.end_lineno],source_lines=[n1.lineno,n1.end_lineno],raw_sha256=hashlib.sha256(segment(old,n0).encode()).hexdigest(),AST_equal=True,raw_equal=True))
# Genuine inert text patch directions against independently prepared scratch files.
forward=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/semantic_inventory_search.py',tofile='b/semantic_inventory_search.py'))
inverse=''.join(difflib.unified_diff(new.splitlines(True),old.splitlines(True),fromfile='a/semantic_inventory_search.py',tofile='b/semantic_inventory_search.py'))
(D/'forward-v1.patch').write_text(forward);(D/'inverse-v1.patch').write_text(inverse)
patches=[]
for direction,pre,expected,patch in [('forward',old,new,D/'forward-v1.patch'),('inverse',new,old,D/'inverse-v1.patch')]:
    scratch=D/('patch-'+direction+'-v1');scratch.mkdir(exist_ok=False)
    target=scratch/'semantic_inventory_search.py';target.write_text(pre)
    result=subprocess.run(['patch','-F','0','-p1','-i',str(patch)],cwd=scratch,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert result.returncode==0 and target.read_text()==expected
    patches.append(dict(direction=direction,command=['patch','-F','0','-p1','-i',str(patch)],exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr,result=desc(target),whole_bytes_exact=True))

helper=Path('/private/tmp/gcts-and-support-ordering-source-20261018/receptor_support_ordering_v1.py')
assert desc(helper)['sha256']=='18cf90ebd75d746db3eb251eaffa92cd6a25432b70f34653b57f3d58ef5d8adc'
A=Path('/private/tmp/gcts-semantic-family-next-audit-20261018')
deps={name:desc(A/(name+'.py')) for name in ['native_receptor_points','native_inventory_policy','native_inference_inventory','semantic_inventory_guidance','turtle']}
deps['support_ordering']=desc(helper)
master=desc(root/'docs/basic-tiling-algorithm.md')
nextwork=desc(root/'.gcts-active/parallel-search-planning-progress-20261018/ROOT-next-work-v1.json')
prospective=desc(root/'.gcts-active/and-support-ordering-progress-20261018/prospective-design-v1.json')
closure=desc(root/'.gcts-active/compact-model-cold-integration-progress-20261018/runtime-closure-v1.json')
ancestry=dict(author_identity='/root/conventional_library',authored_this_point_successor=True,
    authored_quantified_compiler_and_models=True,authored_compact_Model=True,
    authored_current_storage_driver_and_cold_bridge=True,
    helper_and_symbolic_author='/root/conventional_control_review',
    original_semantic_search_is_inherited_not_newly_authored=True,
    independent_Source_certification=False,distinct_current_Source_peer_required=True)
common=dict(author_identity='/root/conventional_library',source_only=True,scientific_calls=0,
    target_imports=0,search_evaluations=0,native_calls=0,scientific_acceptance=False,
    actual_execution_authorized=False,no_activation=True)
audit=emit('Source-audit-v1.json',dict(common,schema='point-and-support-Source-audit-v1',source=desc(S),parent=desc(P),
    compile_without_evaluation=True,target_code_objects_executed=0,
    current_source_lines=len(new.splitlines()),parent_lines=len(old.splitlines()),
    full_search_AST_inverse_exact=True,full_module_AST_inverse_exact=True,
    inverse_scope='Delete only exact declared new parameter, validation/setup/projection/ranking/deadline hooks, output metadata and new module globals; all retained AST nodes originate in actual new Source.',
    retained_raw_AST_regions=retained,retained_region_count=len(retained),
    exact_review_function=True,exact_branch_alternatives_and_placement_loop=True,
    patches=patches,raw_forward_patch=desc(D/'forward-v1.patch'),raw_inverse_patch=desc(D/'inverse-v1.patch'),
    added_callables=['_SupportDeadline','_ProjectionStop','_literal','_complete_rows','_support_choice','search.support_check'],
    unchanged_external_sources=deps,
    authoring_preflight=dict(scope='Own Source author script only',initial_failure='Needle-count assertion before executable Source write; ambiguous old/new internal if-item text.',repair='Narrowed exact original aggregate-check anchor.',scientific_calls=0,executable_source_written_before_failure=False),
    no_runtime_qualification=True))
api=emit('API-v1.json',dict(common,schema='point-and-support-search-API-v1',source=desc(S),ancestry=ancestry,
    module_alias='semantic_inventory_search_v2',role='family_search',version='semantic-inventory-search-v2-shared-and-support',
    signature="search(model,mode='base',weights=None,stochastic=False,seed=0,attempts=20000,seconds=60,proposal_limit=24,proposal_checks=2048,support_ordering='legacy')",
    ordering=dict(legacy='Default. Every old mode, policy and stochastic path retained; no helper graph, projection or rank calls.',
        and_support='Explicit deterministic mode=fixed only. Reject other modes or stochastic=True. Original FIXED features/scores remain unchanged.',
        parameter_mapping='Future driver maps mandatory epoch/plan search_ordering to support_ordering keyword; this Source does not read plans or grants.'),
    helper=dict(source=desc(helper),version='receptor-and-support-ordering-v1',strategy='ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1',
        API=desc(helper.parent/'API-v1.json'),contract=desc(helper.parent/'Source-contract-v1.json'),
        graph='build_support_graph(*,spec=model.spec,compiled=model.compiled,inventory=model.inventory,check=support_check,work_limit=200000)',
        rank='rank_support_options(*,graph,known_rows,options,check=support_check,work_limit=200000)'),
    point_projection=dict(scope='Actual selected row keys plus one whole existing currently aggregate-validated Join item.',
        complete_row='Exactly one C placement, one matching G placement, and all declared input-role placements. Incomplete rows produce no packet.',
        formula='Actual guard.command.formula, copied as full literal AST.',
        requirements='Unchanged row_requirements gives ordered [strict_prior_row,literal_formula] entries, retaining repeated ports. Shared helper independently re-justifies full row dependency chains by literal formula equality.',
        known_rows='Every complete selected row, including rows not yet recursively justified.',
        options='All original items, including None, in stable original (-FIXEDscore,index) order. Each packet retains original_item_index. rows are complete union rows with row IDs absent from known_rows; partial sampled items gain no guard-only credit.',
        sampled='All original arbitrary samples remain in pool and may complete actual rows; no sample-generated fact unless complete and recursively justified.'),
    choice=dict(original_pool_unchanged=True,original_policy_scores_unchanged=True,
        helper_order='Exact full option permutation; potential ties and finite-work fallback preserve original FIXED score/index order.',
        event_index='Actual selected original item index, potentially changed only by support rank. Old policy evidence remains in features/scores/probabilities; receipt has legacy_index and original_policy_scores/probabilities.',
        alternatives='Unchanged selected-hint eligible members first at genuine branch; all original keys follow. Forced keys untouched. No bulk placement.'),
    receipts=dict(result_additions=['support_ordering','support_ordering_metadata'],
        setup='support_ordering_metadata.graph holds whole literal source graph once; status is graph setup disposition, not final search success.',
        event='events[i].support_ordering: choice schema, exact legacy/selected indices, original scores/probabilities, before/after item order, validated aggregates, structural projection count, full shared ranking receipt with seeds/justification/options/scores.',
        old_result_fields='All old fields and full tree/events/hints remain. Default legacy adds metadata only.'),
    limits=dict(helper_graph_work=200000,helper_rank_work_per_call=200000,point_projection_work_per_call=200000,
        limit_semantics='Graph/rank helper work counts semantic operations; helper copy_nodes and JSON/hash/receipt costs additionally charged to same search absolute clock. Point projection counts literal copying/key/role operations; full aggregate calls separately counted and bracketed by clock checks.',
        no_search_clock_reset=True,caller_whole_profile='Root still owns whole work/closure/memory/output/native gates; no new profile or grant is established.'),
    stops=dict(projection_work='Private _ProjectionStop -> exact original FIXED choice, full item pool remains. No candidate exclusion.',
        helper_work='UNKNOWN_WORK_BUDGET graph or STABLE_FALLBACK rank -> original stable choice; no negative/exhaustion.',
        search_deadline='Private _SupportDeadline -> unknown_search_budget before new hint consumption; root fingerprint checks retained.',
        setup_deadline_tree="kind='unknown', cutoff='support_graph_deadline', census=[] explicitly unavailable; not DEAD, EMPTY, or exhaustion.",
        branch_deadline='Full old item/event retained with UNKNOWN_SEARCH_DEADLINE and selected_index=None; no support hint consumed.',
        other_errors='No broad exception catch. Data, Source/import, callback, native/resource faults outside the module-owned private stops propagate. No native calls made here.'),
    scientific_scope='High-level factored point adapter with current checked ground family inventory; heuristic support is not a proof, admissible lower bound, new marking, learned policy, universal family or pruning certificate.'))
contract=emit('Source-contract-v1.json',dict(common,schema='point-and-support-search-Source-contract-v1',source=desc(S),sources={'family_search':desc(S)},
    source_versions={'family_search':'semantic-inventory-search-v2-shared-and-support'},API=api,ancestry=ancestry,
    parent=desc(P),dependencies=deps,helper_contract=desc(helper.parent/'Source-contract-v1.json'),
    parent_runtime_closure=closure,master=master,frozen_next_work=nextwork,prospective_Root_design=prospective,
    changed_regions=[dict(lines=[8,151],purpose='Shared helper import/version/private stops and actual complete-row projection/ranking adapter.'),
        dict(lines=[154,186],purpose='New explicit parameter/validation, same-clock once-only helper graph and setup UNKNOWN.'),
        dict(lines=[197,200],purpose='Typed setup timeout returns UNKNOWN without pretending to inspect a decision.'),
        dict(lines=[211,229],purpose='At original branch advice only, score unchanged pool with stable old ties or stop UNKNOWN.'),
        dict(lines=[249,249],purpose='Additional treatment metadata only.')],
    retained_science=dict(Join='Whole imported 744948... Source unchanged; row generator, anchor quotas, validation quotas and arbitrary samples unchanged.',
        Graph='Whole imported Turtle 9eefe... Source unchanged, complete global DEAD then FORCED then earliest generation, complete dependencies/incidence.',
        policy='Whole choose/FIXED/vector Sources unchanged; exact original features and scores computed first.',
        placement='Raw exact final preferred/remaining alternatives and placement loop; every placement copied, placed and globally updated normally.',
        rollback='Raw exact root restoration and state/graph child copies; support metadata observational and not installed as state.',
        native='No constructor/compiler/model/native/rule/registry/primitive/target/term/marking/domain/scope change. Caller final full point/native gates still mandatory.'),
    cost_and_authority=dict(imports='New helper must be imported/copied/origin-sealed in both contemporary arms; no historical timing replication claim.',
        caller='Current protected Model/metadata, complete compiler, whole all-or-none native registry and full source epoch are a caller custody boundary. Point version check alone is not Source authentication.',
        mutation='Helper is standard-library-only trusted Source under caller custody. It receives owned projected row packets; no Graph/State write or candidate removal.',
        charge='Search began remains original initialization clock. Added graph/projection/aggregate/ranking/JSON/hash/receipt work all inside search duration and outer total; no independent time reset.',
        units='Point attempts are base-placement attempts, not symbolic row-extension units. Same potential does not imply same proposal universe or operation counts.'),
    conformance_evidence=audit,
    conformance_gaps=[
        'No current source has been evaluated/imported by author. No qualification, proof, fit, speed or treatment benefit is claimed.',
        'Legacy equivalence is Source raw/AST evidence plus inert patch inverses, not runtime trace or timing identity.',
        'Finite helper fixtures are separately authored by Control and inactive; they do not qualify actual point projections, full Graph copies or every rollback interleaving.',
        'Prospective Root-owned checks still needed: complete-row vs guard-only/partial projection; repeated strict-prior ports; helper/projection fallback; exact private deadline UNKNOWN; all original alternatives and forced precedence; root/child rollback; retained full output and fresh whole native target check.',
        'Private search clock is cooperative; individual original aggregate, builtin JSON/hash and receipt operations are not preemptible. Root outer whole gates remain necessary.',
        'Support relaxation ignores exact row capacity/sharing/capture complexity and is ordering only; zero-read schemes contribute literal implication licences, never their unproved conclusions.',
        'No multirow closure proposer, new inventory mining/training, new RL, new theorem or universal Wang-system result.'
    ],
    review_ABI=dict(schema='point-and-support-independent-Source-review-v1',reviewer_must_not_author_this_source=True,
        scope='Current raw/AST/closure/patch/error-origin/full alternatives/projection/rollback Source inspection only; no scientific/runtime acceptance.',
        required_fields=['schema','author_identity','reviewer_identity','source','sources','source_contract','source_review_passed','source_only','scientific_calls','scientific_acceptance','actual_execution_authorized','ancestry','findings','limitations'])))
handoff=emit('handoff-v1.json',dict(common,schema='point-and-support-Source-handoff-v1',source=desc(S),sources={'family_search':desc(S)},
    contract=contract,API=api,source_audit=audit,forward_patch=desc(D/'forward-v1.patch'),inverse_patch=desc(D/'inverse-v1.patch'),
    parent=desc(P),helper=desc(helper),helper_handoff=desc(helper.parent/'handoff-v1.json'),ancestry=ancestry,
    role_alias={'family_search':'semantic_inventory_search_v2','support_ordering':'receptor_support_ordering_v1'},
    required_driver_keyword="support_ordering=search_ordering for deterministic fixed point arms; legacy default preserved.",
    stop_after_freeze=True))
print(json.dumps(dict(handoff=handoff,source=desc(S),contract=contract,API=api,audit=audit,retained_regions=len(retained),scientific_calls=0),sort_keys=True))
