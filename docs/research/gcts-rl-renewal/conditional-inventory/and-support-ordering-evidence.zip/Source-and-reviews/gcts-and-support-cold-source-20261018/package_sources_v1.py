"""Build Source-only packet from already generated literal text, no evaluation."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

HERE = Path(__file__).parent


def raw(path):
    p = Path(path)
    if p.stat().st_flags & 0x40000000:
        raise ValueError('dataless path forbidden')
    return p.read_bytes()


def pin(path):
    b = raw(path)
    return {'path': str(path), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}


def emit(name, obj):
    p = HERE / name
    if p.exists():
        raise ValueError('do not overwrite packet: ' + name)
    p.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + '\n')
    return pin(p)


def regions(text):
    return {n.name: (ast.get_source_segment(text, n), ast.dump(n, include_attributes=False))
            for n in ast.parse(text).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}


def main():
    m = json.loads(raw(HERE / 'generated-Source-map-v1.json'))
    sources = m['sources']; parents = m['parent_sources']
    allowed_changes = {'receiver_driver': {'run_receiver', '_Boundary'}, 'cold': {'main'},
                       'once_runner': {'intake_subject', 'authenticate_reviews', 'run_once'},
                       'terminal_observer': {'main'}}
    checks = []

    def check(ok, label):
        checks.append({'check': label, 'passed': bool(ok)})
        if not ok:
            raise ValueError(label)

    retained = {}; changed = {}
    for role, d in sources.items():
        check(pin(d['path']) == d and pin(parents[role]['path']) == parents[role], 'new and parent full Source pin ' + role)
        before = raw(parents[role]['path']).decode(); after = raw(d['path']).decode()
        compile(after, d['path'], 'exec')  # code object discarded, never evaluated
        old = regions(before); new = regions(after)
        check(set(old) == set(new), 'same top-level callable inventory ' + role)
        retained[role] = []; changed[role] = []
        for name in old:
            same = old[name] == new[name]
            if name in allowed_changes[role]:
                check(not same, 'declared changed Source body ' + role + '/' + name)
                changed[role].append(name)
            else:
                check(same, 'retained exact raw and AST body ' + role + '/' + name)
                retained[role].append(name)
        # Apply real forward and inverse patches to inert text in disposable dirs.
        filename = Path(d['path']).name
        for direction, initial, expected in [('forward', before, after), ('inverse', after, before)]:
            with tempfile.TemporaryDirectory(prefix='gcts-and-support-inert-F0-', dir='/private/tmp') as folder:
                p = Path(folder) / filename; p.write_text(initial)
                patch = HERE / (role + '-' + direction + '-v1.patch')
                r = subprocess.run(['/usr/bin/patch', '--batch', '--fuzz=0', '-p0', '-i', str(patch)], cwd=folder, capture_output=True, text=True)
                check(r.returncode == 0 and raw(p) == expected.encode(), 'actual inert F0 text patch ' + role + '/' + direction)
    # High-value inherited guards/bodies are literal, not mirror implementation tests.
    for role, names in {
        'receiver_driver': ['_receiver_input','_input_custody','_compile_record_joins','_inventory_record_join','_closed_receiver','_proof_observation','_winning_hint_links','_atomic_output','_symbolic_point_projection'],
        'cold': ['raw_file','seal_callables','verify_raw_region','verify_literal_result','select_receiver'],
        'once_runner': ['LIMITS','parse','reject_pairs','reject_constant','finite_float','python_custody'],
    }.items():
        old = raw(parents[role]['path']).decode(); new = raw(sources[role]['path']).decode()
        for name in names:
            if name == 'LIMITS':
                def literal(text):
                    n = next(n for n in ast.parse(text).body if isinstance(n, ast.Assign) and any(isinstance(t,ast.Name) and t.id == name for t in n.targets))
                    return ast.get_source_segment(text,n), ast.dump(n,include_attributes=False)
                check(literal(old) == literal(new), 'original whole LIMITS exact')
            else:
                check(regions(old)[name] == regions(new)[name], 'high-value inherited verification/custody exact ' + role + '/' + name)
    api = json.loads(raw(HERE / 'API-draft-v2.json'))
    api['schema'] = 'and-support-composition-API-v1'; api['status'] = 'FROZEN_SOURCE_ONLY_NO_ACTIVATION'
    api['source_state'] = 'Exact generated Sources and external ordering Sources pinned; separate Root closure/declaration/plans/grants required.'
    api['sources'] = sources; api['ordering_sources'] = m['ordering_sources']
    api_pin = emit('API-v1.json', api)
    # False metadata only. These are not runtime plans and contain no real actual path.
    parent_closure = json.loads(raw(m['parent_runtime_closure']['path']))
    def absent(name):
        return {'path':'/private/tmp/AND_SUPPORT_INERT_UNCREATED_' + name + '.json','sha256':'0'*64,'bytes':0}
    z3_files = [{k:d[k] for k in ('path','sha256','bytes')} for d in parent_closure['Z3']['files']]
    z3_root = parent_closure['Z3']['package_root']
    native_inputs = {k:parent_closure['fixed_native_inputs'][k] for k in ('program_and_template','opaque_microcode_gzip')}
    native_inputs['native_cpp'] = parent_closure['native_CPP']['binary']
    old_tree = ast.parse(raw(parents['once_runner']['path']))
    old_limits = ast.literal_eval(next(n.value for n in old_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets)))
    worker_template = dict(schema=m['schemas']['worker_plan'], invocation_id='INERT_FALSE_DO_NOT_EXECUTE',
        mode='fixed',search_ordering='legacy',actual_directory='/private/tmp/AND_SUPPORT_INERT_FALSE_ACTUAL_NOT_CREATED',
        cold=sources['cold'],python=parent_closure['runtime']['Python_executable'],
        project_sources=m['expected_project_sources'],
        components=dict(receiver_driver=sources['receiver_driver'],bounded_transport=parent_closure['additional_nonseed_components']['bounded_transport']),
        native_inputs=native_inputs,
        policy=pin(Path('/private/tmp/gcts-semantic-family-next-audit-20261018/semantic-inventory-policy-001.json')),
        declaration=pin(Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/structural-quantified-progress-20261018/experiment-declaration-v2.json')),
        runtime_closure=absent('RUNTIME_CLOSURE'),
        z3=dict(files=z3_files,root=z3_root,library=next(d for d in z3_files if d['path']==str(Path(z3_root)/'z3/lib/libz3.dylib'))),
        receiver_id='quantified-curried-two-premise-001',result_reader='interned',
        integration_declaration=absent('INTEGRATION_DECLARATION'),model_storage='literal_interned')
    once_template = {k:worker_template[k] for k in ('invocation_id','mode','search_ordering','model_storage','result_reader','receiver_id','actual_directory','python','cold','integration_declaration','runtime_closure')}
    once_template.update(schema=m['schemas']['once_plan'],runner=sources['once_runner'],observer=sources['terminal_observer'],
        worker_plan=absent('WORKER_PLAN'),authorization=absent('FALSE_AUTHORIZATION'),limits=old_limits,environment={})
    check(set(worker_template)==set(api['worker_fields']) and set(once_template)==set(api['once_fields']), 'complete inert18field worker/once templates')
    check(not Path(worker_template['actual_directory']).exists(), 'inert fixture actual directory absent; never created')
    fixture = {
        'schema': 'and-support-inert-false-plan-fixtures-v1', 'source_only': True,
        'scientific_calls': 0, 'scientific_acceptance': False, 'actual_execution_authorized': False,
        'purpose': 'Field/enum/subject-hash documentation only. No actual_directory created, no closure/grant invented, no runner invocation. All placeholders deliberately outside valid runtime descriptors.',
        'worker_fields': api['worker_fields'], 'once_fields': api['once_fields'],
        'worker_plan_template':worker_template,'once_plan_template':once_template,
        'enums': {'mode': ['fixed','symbolic'], 'search_ordering': ['legacy','and_support'],
                  'model_storage': ['literal_interned'], 'result_reader': ['interned']},
        'false_authorization': {'schema': m['schemas']['authorization'], 'author_identity': '/root',
            'actual_execution_authorized': False, 'maximum_actual_invocations': 0,
            'subject_sha256': hashlib.sha256(json.dumps({k:v for k,v in once_template.items() if k!='authorization'},sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest(), 'review_roles': {},
            'scope': 'INERT_FALSE_METADATA_NOT_AUTHORIZATION'},
        'required_subject_rule': 'Final Root subject is complete once plan excluding only authorization; full worker plan includes search_ordering. Changed authorization path alone must not change mathematical inputs.',
        'review_roles': api['review_roles'], 'new_actuals_or_grants': 0,
    }
    fixture_pin = emit('inert-false-plan-fixtures-v1.json', fixture)
    delta_pin = emit('Source-delta-v1.json', {
        'schema':'and-support-composition-Source-delta-v1','author_identity':'/root/receiver_driver_review',
        'source_only':True,'scientific_calls':0,'scientific_acceptance':False,'actual_execution_authorized':False,
        'sources':sources,'parents':parents,'retained_top_level_raw_and_AST':retained,
        'changed_top_level_raw_and_AST':changed,'checks':checks,'check_count':len(checks),'findings':[],
        'compile_without_evaluation':4,'actual_inert_text_patch_directions':8,
        'runtime_evaluations':0,'own_Source_review_passed':False,
        'limits':'Author checks, not an independent Source review or runtime/proof/resource acceptance.'})
    common = {
        'author_identity':'/root/receiver_driver_review','source_only':True,'scientific_calls':0,
        'scientific_acceptance':False,'actual_execution_authorized':False,
        'author_ancestry':'Author reviewed prior scientific Sources/data and authored a separate qualification harness; these are new composition/outer Sources, not self-certified. Library authored parent driver/cold/Model/point module; Control authored inherited outer V2 and new helper/symbolic. Independent review must disclose those overlaps and separate own implementations.',
        'API':api_pin,'delta':delta_pin,'inert_false_fixtures':fixture_pin,
        'external_ordering_sources':m['ordering_sources'],
        'parent_runtime_closure':m['parent_runtime_closure'],
        'expected_project_sources':m['expected_project_sources'],
        'fixed_profile':'Same closed c3 development input selected from original19fab structural declaration;12rows/2UI catalog snapshots; complete old4-template policy, every admitted interface/derivedarity/whole Model/initial;compact Model and interned Reader fixed common;180work+positive worker exit/210terminal/1GiB conservative worker+CPP highwater/128MiB result/original logs. No new10case activation.',
        'same_knowledge_cost':'All four modes import/copy/seal exact same24 aliases. Graph/scoring costs charged inside the same original work/search clocks. No claim of historical timing replication, equal operation units, live aggregate limit, dedicated FOL baseline or new RL.',
        'mandatory_ordering_custody':['worker plan','integration declaration schedule','once plan/auth whole subject','CONSUMED marker','Source epoch','driver result','driver output receipt','worker receipt','outer receipt','terminal mode/order binding'],
        'negative_and_UNKNOWN_scope':'Only inherited owned work stop serializes full UNKNOWN in closure210; delegated scientific/callback/resource failures propagate. Failure diagnostics cannot be promoted to proof. Exact output/point/native/resource gates remain separate. No posthoc salvage.',
        'trusted_boundary':'Pinned Python/bundled stdlib/OS loader and trusted OS metadata assumption remain. Callable seals preserve identities/code/default containers, not every mutable object graph. Parent-only polling guard and whole intake/final Python bytes are not formal continuous worker seal. Aggregate-memory failure skips the later final outer whole-Python/source loop as before; failed diagnostics cannot claim that gate.',
    }
    composition = dict(common, schema='and-support-driver-cold-Source-contract-v1',
        sources={k:sources[k] for k in ('receiver_driver','cold')},
        parents={k:parents[k] for k in ('receiver_driver','cold')},
        review_ABI={'schema':'and-support-driver-cold-typed-Source-review-v1','scope':'and-support-driver-cold-Source','reviewer_identity':'/root/conventional_library','required_fields':['schema','scope','author_identity','reviewer_identity','sources','source_contract','source_only','source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings']},
        source_changes=['Mandatory search_ordering argument and full epoch/result/receipt custody; explicit fixed/symbolic dispatch and legacy/new strategy.',
            'Only new dependency pins/import aliases/helper role; exact literal parent closure delta, all24 aliases common.',
            'Current selected search/helper original+owned source metadata; full native/raw region/row/inverse bodies unchanged.'],
        retained_verification=['Compiler admission/whole catalog','complete registry/native definition order','complete candidate Model and initial snapshot','root restoration','actual selected proof/fresh whole Native request','recursive essential ancestry and winning hint observations','whole exact t/m region/row decode','canonical output and full result Reader/inverse'],
        Root_required_next=['Genuine ordering component Source receipt','Distinct composition+outer Source reviews','Root fresh full raw AST closure and integration declaration','Distinct prospective plan review and exact truegrant delta','Root-only once sequential actuals, all agents idle'])
    comp_pin = emit('composition-Source-contract-v1.json', composition)
    outer = dict(common,schema='and-support-once-Source-contract-v1',
        sources={k:sources[k] for k in ('once_runner','terminal_observer')},
        parents={k:parents[k] for k in ('once_runner','terminal_observer')},
        review_ABI={'schema':'and-support-once-typed-Source-review-v1','scope':'and-support-once-Source','reviewer_identity':'/root/conventional_control_review','required_fields':['schema','scope','author_identity','reviewer_identity','sources','source_contract','source_only','source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings']},
        source_changes=['Mandatory search_ordering plan/subject/marker/current-result/receipt/terminal joins.',
            'Four unique exact mode-by-ordering schedule slots, fixed compact/interned, same24 current alias map/schema and exact four distinct scoped review roles.',
            'Only current Source/schema/pin identities, no parser/resource/reap/search alteration.'],
        inherited_native_custody=['Strict whole finite JSON parse with duplicate/nonfinite rejection','exclusive consumption before exactly one Popen','four cold worker arguments','direct known Python wait4 and native wait4 highwater sum','full bounded pipe EOF and postreap authoritative group absence','no signal after latched absence and permanent reappearance veto','180 positive result+worker exit,210 all terminal checks','late marker cannot accept output','225observer failure-only direct-child cleanup/no residual group claim'])
    outer_pin = emit('once-Source-contract-v1.json', outer)
    handoff = {
        'schema':'and-support-composition-Source-handoff-v1','author_identity':'/root/receiver_driver_review',
        'source_only':True,'scientific_calls':0,'scientific_acceptance':False,'actual_execution_authorized':False,
        'sources':sources,'composition_contract':comp_pin,'once_contract':outer_pin,
        'API':api_pin,'delta':delta_pin,'inert_false_fixtures':fixture_pin,
        'generated_Source_map':pin(HERE/'generated-Source-map-v1.json'),
        'authoring_sources':{'builder':pin(HERE/'build_sources_v1.py'),'packager':pin(Path(__file__))},
        'status':'FROZEN_SOURCE_ONLY_REQUIRES_DISTINCT_REVIEW_NO_ACTIVATION',
        'own_Source_certificate':False,
    }
    h = emit('handoff-v1.json', handoff)
    print(json.dumps({'handoff':h,'composition_contract':comp_pin,'once_contract':outer_pin,'checks':len(checks)},sort_keys=True))


if __name__ == '__main__':
    main()
