"""Stdlib Source authoring only. Never import or evaluate emitted modules.

Required bindings-v1.json is authored only after the three component freezes.
This builder generates new Source, inert metadata fixtures and real text patches;
it does not generate a grant, execute a runner, or perform a scientific call.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).parent
PARENTS = {
    'receiver_driver': Path('/private/tmp/gcts-compact-model-cold-bridge-source-20261018/storage_receiver_driver_v1.py'),
    'cold': Path('/private/tmp/gcts-compact-model-cold-bridge-source-20261018/compact_model_cold_bridge_v1.py'),
    'once_runner': Path('/private/tmp/gcts-compact-model-cold-once-v2-source-20261018/compact_model_cold_once_runner_v2.py'),
    'terminal_observer': Path('/private/tmp/gcts-compact-model-cold-once-v2-source-20261018/observe_compact_model_cold_runner_v2.py'),
}
OUTPUT_NAMES = {
    'receiver_driver': 'and_support_receiver_driver_v1.py',
    'cold': 'and_support_cold_v1.py',
    'once_runner': 'and_support_once_runner_v1.py',
    'terminal_observer': 'observe_and_support_runner_v1.py',
}
PARENT_CLOSURE = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/compact-model-cold-integration-progress-20261018/runtime-closure-v1.json', 'sha256': '63fa8e0d66175a925c61b38ff6c727f5d180f738e2735eb07a3317849c3ed5cf', 'bytes': 69562}
EPOCH = 'semantic-family-receiver-source-epoch-v3-and-support-ordering'
WORKER_PLAN = 'ROOT-and-support-ordering-worker-plan-v1'
WORKER_RECEIPT = 'and-support-ordering-worker-receipt-v1'
DECLARATION = 'ROOT-and-support-ordering-experiment-declaration-v1'
CLOSURE = 'ROOT-and-support-ordering-raw-runtime-closure-v1'
ONCE_PLAN = 'ROOT-and-support-ordering-once-plan-v1'
AUTH = 'ROOT-and-support-ordering-once-authorization-v1'
ONCE_RECEIPT = 'and-support-ordering-external-once-receipt-v1'


def raw(path):
    p = Path(path)
    if p.stat().st_flags & 0x40000000:
        raise ValueError('dataless Source forbidden: ' + str(p))
    return p.read_bytes()


def pin(path):
    b = raw(path)
    return {'path': str(path), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}


def read_pin(d):
    if pin(d['path']) != d:
        raise ValueError('Source pin mismatch')
    return raw(d['path'])


def replace(source, old, new):
    if source.count(old) != 1:
        raise ValueError('expected one exact authoring region: ' + old[:90])
    return source.replace(old, new, 1)


def literal_assignment(source, name, value):
    tree = ast.parse(source)
    nodes = [n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    if len(nodes) != 1:
        raise ValueError('one literal assignment: ' + name)
    node = nodes[0]
    return replace(source, ast.get_source_segment(source, node), name + ' = ' + repr(value))


def write_source(role, text, parent):
    # Parsing and compile-to-code only; no import/exec/eval of the resulting code.
    ast.parse(text)
    compile(text, OUTPUT_NAMES[role], 'exec')
    path = HERE / OUTPUT_NAMES[role]
    if path.exists():
        raise ValueError('preserve frozen/generated Source')
    path.write_text(text)
    for direction, a, b in [('forward', parent, text), ('inverse', text, parent)]:
        patch = ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile=OUTPUT_NAMES[role], tofile=OUTPUT_NAMES[role]))
        (HERE / (role + '-' + direction + '-v1.patch')).write_text(patch)
    return pin(path)


def main():
    bindings = json.loads(raw(HERE / 'bindings-v1.json'))
    if bindings['schema'] != 'and-support-authoring-bindings-v1' or bindings['actual_execution_authorized'] is not False:
        raise ValueError('Source-only frozen component bindings required')
    components = bindings['sources']
    if set(components) != {'family_search', 'symbolic_control', 'support_ordering'}:
        raise ValueError('exact three new external Source roles')
    for d in components.values():
        read_pin(d)
    parent_closure = json.loads(read_pin(PARENT_CLOSURE))
    current_project = dict(parent_closure['project_sources'])
    del current_project['semantic_inventory_search']
    current_project['semantic_inventory_search_v2'] = components['family_search']
    # Symbolic V2 is standalone; freeze refuses an undisclosed parent import.
    symbolic_tree = ast.parse(read_pin(components['symbolic_control']))
    if any((isinstance(n, ast.Import) and any(x.name == 'quantified_symbolic_control_v1' for x in n.names)) or (isinstance(n, ast.ImportFrom) and n.module == 'quantified_symbolic_control_v1') for n in ast.walk(symbolic_tree)):
        raise ValueError('old symbolic runtime import requires explicit expanded closure')
    del current_project['quantified_symbolic_control_v1']
    current_project['quantified_symbolic_control_v2'] = components['symbolic_control']
    current_project['receptor_support_ordering_v1'] = components['support_ordering']
    if len(current_project) != 22:
        raise ValueError('exact declared 22-project successor map')
    originals = {k: raw(p).decode() for k, p in PARENTS.items()}
    generated = {}

    s = originals['receiver_driver']
    s = literal_assignment(s, 'VERSION', 'semantic-family-and-support-ordering-driver-v1')
    s = literal_assignment(s, 'SOURCE_EPOCH_SCHEMA', EPOCH)
    pins_node = next(n for n in ast.parse(s).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'DEPENDENCY_PINS' for t in n.targets))
    dependency_pins = ast.literal_eval(pins_node.value)
    dependency_pins.update({k: (d['sha256'], d['bytes']) for k, d in components.items()})
    s = literal_assignment(s, 'DEPENDENCY_PINS', dependency_pins)
    s = replace(s, "        if not isinstance(source_epoch.get('sources'), dict) or not isinstance(source_epoch.get('native_inputs'), dict):", "        if type(source_epoch.get('search_ordering')) is not str or source_epoch['search_ordering'] not in ('legacy', 'and_support'):\n            raise DriverDataError('explicit legacy/and_support Source-epoch ordering required')\n        if not isinstance(source_epoch.get('sources'), dict) or not isinstance(source_epoch.get('native_inputs'), dict):")
    s = replace(s, 'def run_receiver(*, receiver_spec, mode, policy_bytes, modules, oracle_factory, source_epoch,', 'def run_receiver(*, receiver_spec, mode, search_ordering, policy_bytes, modules, oracle_factory, source_epoch,')
    s = replace(s, "    if mode not in ('base', 'fixed', 'z3', 'symbolic'):\n        raise DriverDataError('receiver mode')", "    if mode not in ('fixed', 'symbolic'):\n        raise DriverDataError('declared fixed/symbolic mechanism-control mode')\n    if type(search_ordering) is not str or search_ordering not in ('legacy', 'and_support'):\n        raise DriverDataError('mandatory explicit legacy/and_support ordering')\n    if source_epoch.get('search_ordering') != search_ordering:\n        raise DriverDataError('caller/Source-epoch ordering mismatch')\n    symbolic_strategy = ('NOVEL_BACKWARD_PRIORITY_DFS_V1' if search_ordering == 'legacy'\n                         else 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1')")
    s = replace(s, 'result = dict(schema=RESULT_SCHEMA, version=VERSION, mode=mode,', 'result = dict(schema=RESULT_SCHEMA, version=VERSION, mode=mode, search_ordering=search_ordering,')
    s = replace(s, "                              symbolic_strategy='NOVEL_BACKWARD_PRIORITY_DFS_V1',", "                              search_ordering=search_ordering, symbolic_strategy=symbolic_strategy,")
    s = replace(s, "                                   status=result['status'], mode=mode,", "                                   status=result['status'], mode=mode, search_ordering=search_ordering,")
    s = replace(s, "                            strategy='NOVEL_BACKWARD_PRIORITY_DFS_V1'))", "                            strategy=symbolic_strategy, support_ordering=modules['support_ordering']))")
    s = replace(s, '                            stochastic=False, weights=None))', '                            stochastic=False, weights=None, support_ordering=search_ordering))')
    s = replace(s, 'return dict(schema=RECEIPT_SCHEMA, version=VERSION, mode=mode,', 'return dict(schema=RECEIPT_SCHEMA, version=VERSION, mode=mode, search_ordering=search_ordering,')
    generated['receiver_driver'] = write_source('receiver_driver', s, originals['receiver_driver'])

    s = originals['cold']
    for name, val in [('VERSION', 'and-support-ordering-cold-v1'), ('PLAN_SCHEMA', WORKER_PLAN), ('EPOCH_SCHEMA', EPOCH), ('WORKER_SCHEMA', WORKER_RECEIPT), ('PARENT_RUNTIME_CLOSURE', PARENT_CLOSURE), ('RECEIVER_DRIVER_SOURCE', generated['receiver_driver'])]:
        s = literal_assignment(s, name, val)
    role_node = next(n for n in ast.parse(s).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'ROLE_MODULES' for t in n.targets))
    roles = ast.literal_eval(role_node.value)
    roles['family_search'] = 'semantic_inventory_search_v2'
    roles['symbolic_control'] = 'quantified_symbolic_control_v2'
    roles['support_ordering'] = 'receptor_support_ordering_v1'
    s = literal_assignment(s, 'ROLE_MODULES', roles)
    s = replace(s, 'MODEL_STORAGE_MODULES = {', 'ORDERING_COMPONENT_SOURCES = ' + repr(components) + '\n\nMODEL_STORAGE_MODULES = {')
    s = replace(s, "            'runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage'}", "            'runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage','search_ordering'}")
    s = replace(s, "    need(plan['mode'] in ('base','fixed','symbolic'),'declared mode')", "    need(plan['mode'] in ('fixed','symbolic'),'declared mechanism-control mode')\n    need(type(plan['search_ordering']) is str and plan['search_ordering'] in ('legacy','and_support'),\n         'mandatory explicit search ordering')")
    s = replace(s, "    need(plan['result_reader'] in ('builtin','interned'),'declared complete result reader')", "    need(plan['result_reader']=='interned','fixed complete interned result reader')")
    s = replace(s, "type(plan['model_storage']) is str and plan['model_storage'] in MODEL_STORAGE_MODULES", "type(plan['model_storage']) is str and plan['model_storage']=='literal_interned'")
    s = replace(s, "marker['invocation_id']==plan['invocation_id'] and marker['mode']==plan['mode'] and", "marker['invocation_id']==plan['invocation_id'] and marker['mode']==plan['mode'] and\n         marker['search_ordering']==plan['search_ordering'] and")
    s = replace(s, "integration['schema']=='ROOT-compact-model-cold-bridge-experiment-declaration-v1'", "integration['schema']==" + repr(DECLARATION))
    s = replace(s, "             ('mode','result_reader','receiver_id','actual_directory','model_storage')), 'complete declared storage-subject binding')", "             ('mode','search_ordering','result_reader','receiver_id','actual_directory','model_storage')), 'complete declared method/ordering subject binding')\n        schedule=integration['schedule']\n        need(len(schedule)==4 and len({r['invocation_id'] for r in schedule})==4 and\n             len({r['actual_directory'] for r in schedule})==4 and\n             {(r['mode'],r['search_ordering']) for r in schedule}==\n                 {(m,o) for m in ('fixed','symbolic') for o in ('legacy','and_support')} and\n             all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and\n                 r['result_reader']=='interned' for r in schedule),\n             'four unique complete method-by-ordering subjects with common assertion/storage/reader')")
    s = replace(s, "closure['schema']=='ROOT-compact-model-cold-bridge-raw-runtime-closure-v1'", "closure['schema']==" + repr(CLOSURE))
    s = replace(s, "        expected_project['interned_quantified_family_points_v1']=COMPACT_MODEL_SOURCE", "        del expected_project['semantic_inventory_search']\n        expected_project['semantic_inventory_search_v2']=ORDERING_COMPONENT_SOURCES['family_search']\n        del expected_project['quantified_symbolic_control_v1']\n        expected_project['quantified_symbolic_control_v2']=ORDERING_COMPONENT_SOURCES['symbolic_control']\n        expected_project['receptor_support_ordering_v1']=ORDERING_COMPONENT_SOURCES['support_ordering']\n        need(expected_project['interned_quantified_family_points_v1']==COMPACT_MODEL_SOURCE,\n             'unchanged compact Model full Source')")
    s = replace(s, "        need(len(plan['project_sources'])==21 and len(names)==23 and\n             closure['materialized_aliases']==names, 'complete same23 project/component modules in both storage arms')", "        need(len(plan['project_sources'])==22 and len(names)==24 and\n             closure['materialized_aliases']==names, 'complete same24 project/component aliases in all four arms')")
    s = replace(s, "epoch=dict(schema=EPOCH_SCHEMA,model_storage=plan['model_storage'],", "epoch=dict(schema=EPOCH_SCHEMA,model_storage=plan['model_storage'],search_ordering=plan['search_ordering'],")
    s = replace(s, "run_receiver(receiver_spec=receiver_selection['spec'],mode=plan['mode'],", "run_receiver(receiver_spec=receiver_selection['spec'],mode=plan['mode'],search_ordering=plan['search_ordering'],")
    s = replace(s, "        need(receipt['receiver_id']==plan['receiver_id'],'returned exact receiver identity')", "        need(receipt['receiver_id']==plan['receiver_id'] and receipt['search_ordering']==plan['search_ordering'],\n             'returned exact receiver and ordering identity')")
    s = replace(s, "result_data['source_epoch']['schema']==EPOCH_SCHEMA and", "result_data['source_epoch']['schema']==EPOCH_SCHEMA and\n             result_data['search_ordering']==plan['search_ordering'] and\n             result_data['source_epoch']['search_ordering']==plan['search_ordering'] and\n             result_data['module_pins']['support_ordering']==owned[ROLE_MODULES['support_ordering']] and\n             result_data['module_pins']['family_search' if plan['mode']=='fixed' else 'symbolic_control']==\n                 owned[ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control']] and")
    s = replace(s, "header=dict(schema=WORKER_SCHEMA,invocation_id=plan['invocation_id'],mode=plan['mode'],", "header=dict(schema=WORKER_SCHEMA,invocation_id=plan['invocation_id'],mode=plan['mode'],search_ordering=plan['search_ordering'],")
    s = replace(s, "            model_storage=plan['model_storage'],", "            model_storage=plan['model_storage'],\n            selected_search_module=dict(role=('family_search' if plan['mode']=='fixed' else 'symbolic_control'),\n                module=ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control'],\n                original=ORDERING_COMPONENT_SOURCES['family_search' if plan['mode']=='fixed' else 'symbolic_control'],\n                owned=owned[ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control']]),\n            support_ordering_module=dict(module=ROLE_MODULES['support_ordering'],\n                original=ORDERING_COMPONENT_SOURCES['support_ordering'],owned=owned[ROLE_MODULES['support_ordering']]),")
    generated['cold'] = write_source('cold', s, originals['cold'])

    s = originals['once_runner']
    for name, val in [('VERSION', 'and-support-ordering-external-once-runner-v1'), ('PLAN_SCHEMA', ONCE_PLAN), ('AUTH_SCHEMA', AUTH), ('WORKER_RECEIPT_SCHEMA', WORKER_RECEIPT), ('RECEIPT_SCHEMA', ONCE_RECEIPT), ('KINDS', ('fixed','symbolic')), ('STORAGES', ('literal_interned',)), ('COLD_PIN', generated['cold'])]:
        s = literal_assignment(s, name, val)
    review_roles = {
        'ordering_Source': ('and-support-ordering-components-typed-Source-review-v1', 'source_review_passed', '/root/receiver_driver_review'),
        'composition_Source': ('and-support-driver-cold-typed-Source-review-v1', 'source_review_passed', '/root/conventional_library'),
        'once_Source': ('and-support-once-typed-Source-review-v1', 'source_review_passed', '/root/conventional_control_review'),
        'prospective_plans': ('and-support-prospective-plan-review-v1', 'prospective_review_passed', '/root/conventional_library'),
    }
    s = literal_assignment(s, 'REVIEW_ROLES', review_roles)
    s = replace(s, "STORAGES = ('literal_interned',)", "STORAGES = ('literal_interned',)\nORDERINGS = ('legacy','and_support')")
    s = replace(s, "('invocation_id','mode','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure')", "('invocation_id','mode','search_ordering','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure')")
    s = replace(s, "worker['schema']=='ROOT-semantic-family-worker-plan-v1' and\n         len(worker['project_sources'])==21", "worker['schema']==" + repr(WORKER_PLAN) + " and\n         len(worker['project_sources'])==22")
    s = replace(s, "'complete21project+2component worker intake'", "'complete22project+2component worker intake'")
    s = replace(s, "len(names)==23 and closure['schema']=='ROOT-compact-model-cold-bridge-raw-runtime-closure-v1'", "len(names)==24 and closure['schema']==" + repr(CLOSURE))
    s = replace(s, "'same full23 alias closure/native runtime intake'", "'same full24 alias closure/native runtime intake'")
    s = replace(s, "declaration['schema']=='ROOT-compact-model-cold-bridge-experiment-declaration-v1'", "declaration['schema']==" + repr(DECLARATION))
    s = replace(s, "need(len(ids)==6 and len(set(ids))==6 and ids.count(plan['invocation_id'])==1,'complete unique six-arm declaration')", "need(len(ids)==4 and len(set(ids))==4 and ids.count(plan['invocation_id'])==1 and\n         len({r['actual_directory'] for r in schedule})==4 and\n         {(r['mode'],r['search_ordering']) for r in schedule}==\n             {(m,o) for m in KINDS for o in ORDERINGS} and\n         all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and\n             r['result_reader']=='interned' for r in schedule),'complete unique four-arm factorial declaration')")
    s = replace(s, "('mode','result_reader','receiver_id','actual_directory','model_storage')", "('mode','search_ordering','result_reader','receiver_id','actual_directory','model_storage')")
    s = replace(s, "'exact three current review roles'", "'exact four current review roles'")
    s = replace(s, "minimum={'bridge_Source':[plan['cold'],worker['components']['receiver_driver']],", "minimum={'ordering_Source':[worker['project_sources'][k] for k in\n                 ('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],\n             'composition_Source':[plan['cold'],worker['components']['receiver_driver']],")
    s = replace(s, "fields={'schema','invocation_id','mode','model_storage','result_reader','receiver_id','actual_directory',", "fields={'schema','invocation_id','mode','search_ordering','model_storage','result_reader','receiver_id','actual_directory',")
    s = replace(s, "need(plan['mode'] in KINDS and type(plan['invocation_id'])is str", "need(plan['mode'] in KINDS and type(plan['search_ordering'])is str and plan['search_ordering'] in ORDERINGS and type(plan['invocation_id'])is str")
    s = replace(s, "'mode':plan['mode'],'model_storage':plan['model_storage'],'result_reader':plan['result_reader'],", "'mode':plan['mode'],'search_ordering':plan['search_ordering'],'model_storage':plan['model_storage'],'result_reader':plan['result_reader'],")
    s = replace(s, "('invocation_id','mode','model_storage','receiver_id','integration_declaration')", "('invocation_id','mode','search_ordering','model_storage','receiver_id','integration_declaration')")
    s = replace(s, "result['source_epoch']['model_storage']==plan['model_storage'] and result['module_pins']['family_model']==selected['owned']", "result['source_epoch']['model_storage']==plan['model_storage'] and result['module_pins']['family_model']==selected['owned'] and\n             result['search_ordering']==plan['search_ordering'] and result['source_epoch']['search_ordering']==plan['search_ordering']")
    s = replace(s, "        native=worker_receipt['native_transport']", "        search_role='family_search' if plan['mode']=='fixed' else 'symbolic_control'\n        search_alias='semantic_inventory_search_v2' if plan['mode']=='fixed' else 'quantified_symbolic_control_v2'\n        search_subject=worker_receipt['selected_search_module'];support_subject=worker_receipt['support_ordering_module']\n        need(search_subject['role']==search_role and search_subject['module']==search_alias and\n             search_subject['original']==worker['project_sources'][search_alias] and\n             search_subject['owned']==result['module_pins'][search_role] and\n             support_subject['module']=='receptor_support_ordering_v1' and\n             support_subject['original']==worker['project_sources']['receptor_support_ordering_v1'] and\n             support_subject['owned']==result['module_pins']['support_ordering'],\n             'current method/helper original and owned Source preimage joins')\n        native=worker_receipt['native_transport']")
    s = replace(s, "receipt={'schema':RECEIPT_SCHEMA,'version':VERSION,'invocation_id':plan['invocation_id'],'mode':plan['mode'],", "receipt={'schema':RECEIPT_SCHEMA,'version':VERSION,'invocation_id':plan['invocation_id'],'mode':plan['mode'],'search_ordering':plan['search_ordering'],")
    generated['once_runner'] = write_source('once_runner', s, originals['once_runner'])

    s = originals['terminal_observer']
    s = literal_assignment(s, 'VERSION', 'and-support-ordering-final-terminal-observer-v1')
    s = replace(s, "plan['schema']=='ROOT-compact-model-cold-once-plan-v1'", "plan['schema']==" + repr(ONCE_PLAN))
    s = replace(s, "plan['runner']['sha256']=='3e85dcfc124bd9dd59f5e89c771b408f8c7340ecfa19ccb4057b94d1754bf485'", "plan['runner']['sha256']==" + repr(generated['once_runner']['sha256']))
    s = replace(s, "schema='ROOT-compact-model-cold-final-terminal-observation-v1'", "schema='and-support-ordering-final-terminal-observation-v1'")
    s = replace(s, "receipt['invocation_id']==plan['invocation_id'] and receipt['mode']==plan['mode'] and", "receipt['invocation_id']==plan['invocation_id'] and receipt['mode']==plan['mode'] and\n            receipt['search_ordering']==plan['search_ordering'] and")
    generated['terminal_observer'] = write_source('terminal_observer', s, originals['terminal_observer'])
    metadata = {'schema': 'and-support-generated-Source-map-v1', 'author_identity': '/root/receiver_driver_review', 'source_only': True, 'scientific_calls': 0, 'scientific_acceptance': False, 'actual_execution_authorized': False, 'sources': generated, 'ordering_sources': components, 'parent_sources': {k: pin(p) for k,p in PARENTS.items()}, 'parent_runtime_closure': PARENT_CLOSURE, 'expected_project_sources': current_project, 'schemas': {'epoch':EPOCH,'worker_plan':WORKER_PLAN,'worker_receipt':WORKER_RECEIPT,'declaration':DECLARATION,'runtime_closure':CLOSURE,'once_plan':ONCE_PLAN,'authorization':AUTH,'once_receipt':ONCE_RECEIPT}, 'review_roles': review_roles, 'status': 'SOURCE_ONLY_NOT_ACTIVATED'}
    path = HERE / 'generated-Source-map-v1.json'
    if path.exists(): raise ValueError('preserve generated Source map')
    path.write_text(json.dumps(metadata, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'Source_map':pin(path),'sources':generated,'scientific_calls':0},sort_keys=True))


if __name__ == '__main__':
    if len(sys.argv) != 1:
        raise ValueError('Source builder takes no arguments')
    main()
