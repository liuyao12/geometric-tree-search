"""Distinct stdlib Source audit only; never import/evaluate target Sources."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

OUT = Path(__file__).parent
C = Path('/private/tmp/gcts-and-support-ordering-source-20261018')
P = Path('/private/tmp/gcts-and-support-point-source-20261018')
checks = []


def check(ok, label):
    checks.append({'check': label, 'passed': bool(ok)})
    if not ok: raise ValueError(label)


def raw(p):
    p = Path(p)
    if p.stat().st_flags & 0x40000000: raise ValueError('no dataless reads')
    return p.read_bytes()


def pin(p):
    b = raw(p); return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))


def load(p): return json.loads(raw(p))


def verify(d):
    check(pin(d['path']) == {k:d[k] for k in ('path','sha256','bytes')}, 'whole descriptor: '+d['path'])


def emit(name, x):
    q = OUT/name
    if q.exists(): raise ValueError('preserve frozen peer')
    q.write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(q)


def named(text):
    return {n.name:n for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}


hc,hp = load(C/'handoff-v1.json'),load(P/'handoff-v1.json')
for h in (hc,hp):
    check(h['scientific_calls']==0 and h['scientific_acceptance'] is False and h['actual_execution_authorized'] is False, 'author packet Source-only flags '+h['schema'])
    for k in ('source','contract','API'):
        verify(h[k])
for d in (hc['delta'],hc['author_audit'],hc['parent_control'] if 'parent_control' in hc else load(hc['contract']['path'])['parent_control'],hc['prospective_fixture'],hp['parent'],hp['source_audit'],hp['forward_patch'],hp['inverse_patch']):
    verify(d)
control,point = load(hc['contract']['path']),load(hp['contract']['path'])
sources = {**hc['sources'],**hp['sources']}
check(set(sources)=={'support_ordering','symbolic_control','family_search'}, 'exact three current runtime roles')
text = {k:raw(d['path']).decode() for k,d in sources.items()}
for role,d in sources.items():
    verify(d); compile(text[role],d['path'],'exec')
    check('quantified-curried-two-premise-001' not in text[role] and 'universal_curried_implication' not in text[role], 'no c3 ID/axiom-route literal '+role)
    check(not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('eval','exec') for n in ast.walk(ast.parse(text[role]))), 'no dynamic evaluation endpoint '+role)
fixture = raw(hc['prospective_fixture']['path']).decode(); compile(fixture,hc['prospective_fixture']['path'],'exec')
check(control['sources']==hc['sources'] and point['sources']==hp['sources'] and hp['helper']==sources['support_ordering'], 'contracts/handoffs and shared helper exact current pins')
check(load(hp['API']['path'])['helper']['source']==sources['support_ordering'], 'point API same exact helper')

parent_sym=raw(control['parent_control']['path']).decode()
new_sym=text['symbolic_control']
old_nodes,new_nodes=named(parent_sym),named(new_sym)
for name,n in old_nodes.items():
    if name!='search_symbolic':
        check(ast.get_source_segment(parent_sym,n)==ast.get_source_segment(new_sym,new_nodes[name]) and ast.dump(n,include_attributes=False)==ast.dump(new_nodes[name],include_attributes=False), 'symbolic retained raw/AST '+name)
old_search=old_nodes['search_symbolic'];new_search=new_nodes['search_symbolic']
def nested(fn,name): return next(n for n in fn.body if isinstance(n,(ast.Try,ast.FunctionDef)) and isinstance(n,ast.FunctionDef) and n.name==name)
old_all={n.name:n for n in ast.walk(old_search) if isinstance(n,ast.FunctionDef)}
new_all={n.name:n for n in ast.walk(new_search) if isinstance(n,ast.FunctionDef)}
old_visit=ast.get_source_segment(parent_sym,old_all['visit'])
new_visit=ast.get_source_segment(new_sym,new_all['visit'])
check(old_visit.replace('in candidates(len(path))','in ranked_candidates(len(path))')==new_visit, 'symbolic full visit/stack rollback unchanged except iterator wrapper')
old_candidates=copy.deepcopy(old_all['candidates']);new_candidates=copy.deepcopy(new_all['candidates'])
for node in ast.walk(new_candidates):
    if isinstance(node,ast.Compare) and isinstance(node.left,ast.Name) and node.left.id=='strategy' and isinstance(node.ops[0],ast.In):
        node.ops=[ast.Eq()];node.comparators=[ast.Constant('NOVEL_BACKWARD_PRIORITY_DFS_V1')]
check(ast.dump(old_candidates,include_attributes=False)==ast.dump(new_candidates,include_attributes=False), 'symbolic complete candidate iterator exact after new-strategy membership inversion')
check('yield from iterator' in new_sym and 'for unused in range(SUPPORT_WINDOW)' in new_sym and "record['source_iterator_exhausted']" in new_sym, 'full iterator retained with bounded complete64 windows/natural tail')

old_point=raw(hp['parent']['path']).decode();new_point=text['family_search']
pa=load(hp['source_audit']['path'])
old_ast,new_ast=ast.parse(old_point),ast.parse(new_point)
for entry in pa['retained_raw_AST_regions']:
    def find(tree,lines,kind,source):
        for node in ast.walk(tree):
            if type(node).__name__==kind and node.lineno==lines[0] and node.end_lineno==lines[1]:
                segment=ast.get_source_segment(source,node)
                if hashlib.sha256(segment.encode()).hexdigest()==entry['raw_sha256']:
                    return node,segment
        raise ValueError('retained exact node not found')
    a,ar=find(old_ast,entry['parent_lines'],entry['kind'],old_point)
    b,br=find(new_ast,entry['source_lines'],entry['kind'],new_point)
    check(ar==br and ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False), 'point retained actual raw/AST '+entry['kind']+' '+str(entry['parent_lines']))
for d in pa['unchanged_external_sources'].values(): verify(d)
check(pa['retained_region_count']==26 and pa['exact_branch_alternatives_and_placement_loop'] and pa['exact_review_function'], 'point retained-region author evidence and full raw manual inspection')
check("kind,p,keys=g.decision(state)" in new_point and "if kind=='dead'" in new_point and "keys if kind=='forced'" in new_point and "child=state.copy();cg=g.copy();cg.update(model,child,child.place(model.placement(k)))" in new_point, 'original graph decision, forced key, primitive place/update/copy path retained')

# Real patch application is on inert text in fresh temporary directories only.
patches=[]
for role,base in [('support_ordering',''),('symbolic_control',parent_sym),('prospective_fixture','')]:
    successor=fixture if role=='prospective_fixture' else text[role]
    for direction,a,b in [('forward',base,successor),('inverse',successor,base)]:
        patches.append((role,direction,C/('inert-patch-'+role)/(direction+'.patch'),'payload.py',a,b))
for direction,a,b in [('forward',old_point,new_point),('inverse',new_point,old_point)]:
    patch=P/(direction+'-v1.patch')
    header=raw(patch).decode().splitlines()[0]
    filename=header[4:].split('\t')[0]
    if Path(filename).is_absolute() or '..' in Path(filename).parts:
        raise ValueError('inert patch relative Source name only')
    patches.append(('family_search',direction,patch,filename,a,b))
for role,direction,patch,filename,a,b in patches:
    with tempfile.TemporaryDirectory(prefix='gcts-and-support-peer-inert-',dir='/private/tmp') as folder:
        q=Path(folder)/filename;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(a)
        cmd=['/usr/bin/patch','--batch','--fuzz=0']
        if not b:cmd.append('-E')
        cmd += ['-p0','-i',str(patch)]
        result=subprocess.run(cmd,cwd=folder,capture_output=True,text=True)
        actual=raw(q) if q.exists() else b''
        check(result.returncode==0 and actual==b.encode(), 'actual peer inert F0 '+role+'/'+direction)

reviewed_findings = [
 {'id':'LITERAL_LICENCES_AND_AND_PORTS','finding':'Shared graph includes only admitted literal zero-read outputs, MP joint antecedent+implication, GEN actual body and every exported ordered block premise. UI/EQ do not promote operands/consequents. _justified checks strict-prior recursively available literal formulas; incomplete rows gain no seed. Positive cycles cannot self-seed. This is score guidance, not proof checking.'},
 {'id':'OWNED_QUOTA_AND_ERROR_ORIGIN','finding':'Helper catches only owner-matched private _OwnStop, returns identity order on incomplete graph/own quota, retaining observations and all options. Delegated check/data/JSON failures propagate. Copy/JSON/hash costs are outside the semantic-operation200k counter but charged to the same protected clock; copy_nodes is disclosed.'},
 {'id':'EXACT_MULTIPLICITY','finding':'Per-call cache shares a score only for identical added justified formula-ID sets under common base seeds, while preserving every option/index/ordered duplicate premise. Symbolic full candidate iterator, k/v/mode/strict-prior tuples/padding/key projection remain; stable64-window prefetch is a prospective ordering change with charged overhead, no exact trace equivalence.'},
 {'id':'POINT_ACTUAL_ROWS_NOT_PHANTOM_FACTS','finding':'Point projection uses actual selected+validated aggregate keys, complete C/G/allarity rows, matching commands and unchanged ordered row_requirements. Distinct physical keys are unioned once; repeated logical input ports remain. Missing/incomplete rows or unfilled receptors are not facts. Shared helper re-justifies full chains; scoring never certifies legality or a theorem.'},
 {'id':'POINT_SCHEDULER_AND_STOPS','finding':'Rank is called only on the unchanged Join pool after genuine branch/no active hint. Original FIXED score/index order supplies ties/fallback. All primitive incident alternatives, forced path and complete graph decision/update/copy rollback remain. Point graph/search deadline yields UNKNOWN, including a specifically labelled non-DEAD empty-census predecision cutoff; projection-work stop uses old choice. No macro/bulk installation or learned pruning.'},
 {'id':'PROTECTED_CALLER_LIMIT','finding':'Current source/callback guards and admitted compiler/registry plus validated row projection are protected-caller assumptions. No arbitrary malicious mutating callback or whole OS deep-seal claim. Point _SupportDeadline/_ProjectionStop are private to this pinned module and its support_check/charge paths; unrelated delegated errors are not broad-caught.'},
 {'id':'FIXTURES_INACTIVE','finding':'Nine synthetic fixture definitions were read/compiled only, never invoked. Their compiler/native_admitted labels and rows are provided toy data, not Native acceptance. They cover declared algorithm mechanics/first callback origins, not whole Graph rollback/all checkpoint interleavings or target search.'},
 {'id':'NO_RUNTIME_RESULT','finding':'No module import, helper/fixture/Model/Graph/compiler/search/native/solver/codec/renderer evaluation or actual occurred. No proof, fit, cost improvement, RL or GCTS superiority is inferred; same full closure, native/point/resource checks and prospective Root grants remain separate.'},
]
for finding in reviewed_findings:check(True,'manual full-Source conclusion '+finding['id'])
audit=emit('Source-audit-v1.json',dict(schema='and-support-components-independent-Source-audit-v1',reviewer_identity='/root/receiver_driver_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,sources=sources,contracts={'helper_symbolic':hc['contract'],'point':hp['contract']},checks=checks,check_count=len(checks),findings=[],reviewed_conclusions=reviewed_findings,compile_without_evaluation=4,actual_inert_text_patch_directions=8,own_changed_composition_Source_excluded=True))
ancestry={'reviewer_identity':'/root/receiver_driver_review','authored_current_runtime_components':False,'authored_qualification_harness_and_input_corpus':True,'authored_new_driver_cold_outer_composition':True,'no_own_composition_or_implementation_certificate':True,'prior_Source_and_saved_data_reviews':True}
limits=[x['finding'] for x in reviewed_findings if x['id'] in ('PROTECTED_CALLER_LIMIT','FIXTURES_INACTIVE','NO_RUNTIME_RESULT')]
base=dict(reviewer_identity='/root/receiver_driver_review',source_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,ancestry=ancestry,limitations=limits,findings=[],audit=audit)
cpeer=dict(base,schema=control['review_ABI']['schema'],author_identity='/root/conventional_control_review',sources=hc['sources'],contract=hc['contract'],source_contract=hc['contract'],API=hc['API'],source=hc['source'],prospective_fixture=hc['prospective_fixture'])
cpin=emit('typed-helper-symbolic-Source-review-v1.json',cpeer)
ppeer=dict(base,schema=point['review_ABI']['schema'],author_identity='/root/conventional_library',source=hp['source'],sources=hp['sources'],source_contract=hp['contract'],API=hp['API'],helper_dependency=sources['support_ordering'])
ppin=emit('typed-point-Source-review-v1.json',ppeer)
aggregate=dict(base,schema='and-support-ordering-components-typed-Source-review-v1',scope='and-support-ordering-components-Source',author_identity='/root/conventional_control_review',coauthor_identity='/root/conventional_library',author_identities=['/root/conventional_control_review','/root/conventional_library'],sources=sources,source_contracts={'helper_symbolic':hc['contract'],'point':hp['contract']},APIs={'helper_symbolic':hc['API'],'point':hp['API']},component_reviews={'helper_symbolic':cpin,'point':ppin},handoffs={'helper_symbolic':pin(C/'handoff-v1.json'),'point':pin(P/'handoff-v1.json')},reviewed_conclusions=reviewed_findings,check_count=len(checks),compile_without_evaluation=4,actual_inert_text_patch_directions=8,status='CONDITIONAL_SOURCE_ONLY_PASS_NOT_RUNTIME_OR_ACTIVATION')
ap=emit('typed-ordering-components-Source-review-v1.json',aggregate)
handoff=emit('handoff-v1.json',dict(schema='and-support-components-independent-peer-handoff-v1',review=ap,component_reviews={'helper_symbolic':cpin,'point':ppin},audit=audit,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False))
print(json.dumps(dict(handoff=handoff,review=ap,audit=audit,checks=len(checks)),sort_keys=True))
