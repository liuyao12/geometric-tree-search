Source and manual reconstruction milestone only. No new scientific actual or target proof. Original evidence remains byte-identical.
