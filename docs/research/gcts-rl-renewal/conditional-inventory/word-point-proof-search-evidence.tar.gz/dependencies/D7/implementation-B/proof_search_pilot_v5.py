"""Small matched Native/point proof-search pilot; Source-only until Root actual.

All logical acceptance belongs to the injected unchanged Native oracle. This
module adds a compact search record and certified redundant auxiliary m-values.
Learned clusters only order existing primitive commands/placements. No RL,
physical Wang acceptance, block command candidate, or imported proof is claimed.
"""
import collections
import copy
import itertools
import json
import math
import time
import compact_point_model_v1 as compact
import compact_reference_verifier_v1 as reference

VERSION = 'native-point-matched-proof-search-pilot-v5-per-arm-cluster-prerequisites'
MODULE_ROLES = ('compiler', 'model', 'points', 'symbolic', 'miner', 'host')
LIMITS = dict(search_attempts=600, search_seconds=2.0,
              compile_queries=512, native_steps=1000000000,
              marking_proposals=48, marking_certificates=12,
              marking_work=200000, cluster_instances=12,
              cluster_binding_work=20000, cluster_proposals=16,
              domain_audits=2)


def literal(value):
    return json.loads(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                 ensure_ascii=False, allow_nan=False))


def word(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def need(condition, message):
    if not condition:
        raise ValueError(message)


class _Cutoff(Exception):
    pass


class _Budget:
    def __init__(self, check, limits):
        self.root_check = check
        self.end = time.perf_counter() + limits['search_seconds']
        self.limit = limits['search_attempts']
        self.attempts = 0
        self.stop = _Cutoff('owned search budget')

    def check(self):
        self.root_check()
        if time.perf_counter() >= self.end:
            raise self.stop

    def extend(self):
        self.check()
        if self.attempts >= self.limit:
            raise self.stop
        self.attempts += 1


def _request(oracle, spec, proof, check, limits, purpose, blocks=None, target=None):
    check()
    request = dict(protocol='gcts-fol-1', theory=spec['theory'],
                   blocks=[] if blocks is None else blocks,
                   proof=literal(proof), target=spec['target'] if target is None else target)
    record = oracle.request(request, limits['native_steps'], purpose)
    check()
    need(record['request'] == request and type(record['id']) is int and
         oracle.records[record['id']] is record, 'exact current Native record/request')
    return record


def _tuple_ast(value):
    if type(value) is list:
        return tuple(_tuple_ast(x) for x in value)
    if type(value) is dict:
        return {k: _tuple_ast(v) for k, v in value.items()}
    return value


def host_check(spec, proof, target, host, check):
    check()
    need(all(c['rule'] not in ('block', 'assumption') for c in proof), 'flat primitive Host certificate')
    kernel = host.Kernel(spec['theory']['functions'], spec['theory']['predicates'],
                         {k: _tuple_ast(v) for k, v in spec['theory']['axioms'].items()})
    accepted = kernel.check(_tuple_ast(proof), _tuple_ast(target))
    check()
    return dict(accepted=accepted, rows=len(proof), target=literal(target),
                scope='independent flat Host Kernel; syntax helpers also used by compiler; exact case theory, no extra premises')


def _empty_inventory():
    return dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[])


def _root_of(model, key):
    occupancy = model.placement(key).occupancy
    need(len(occupancy) == 1 and occupancy[0][1] == 12, 'pilot unit-center adapter')
    return occupancy[0][0]


def _reason(model, state, key, owners=None):
    """Independent literal local witness, never a candidate shortlist."""
    c = model.placement(key)
    if key in state.selected:
        return dict(kind='already_selected', key=key)
    for point, value in c.occupancy:
        if state.allowed_points is not None and point not in state.allowed_points:
            return dict(kind='outside_target', point=point)
        if state.totals.get(point, 0) + value > 12:
            return dict(kind='capacity', point=point, candidate_value=value,
                        assigned_value=state.totals.get(point, 0))
    for point, value in c.marks:
        if point in state.marks and state.marks[point] != value:
            return dict(kind='marking', point=point, candidate_value=value,
                        assigned_value=state.marks[point],
                        assigned_owner=None if owners is None else owners.get(point))
    return None


def audit_domains(model, state, graph, check):
    """Complete independent original-domain census at this actual state."""
    expected = {}
    for point in sorted(state.frontier()):
        check()
        expected[point] = set()
        for key in model.alignments(point):
            check()
            if _reason(model, state, key) is None:
                expected[point].add(key)
    need(expected == graph.domains, 'independent full point-domain comparison')
    edges = collections.defaultdict(set)
    for point, keys in expected.items():
        for key in keys:
            check()
            edges[key].add(point)
    need(dict(edges) == graph.edges, 'independent complete inverse incidence')
    dead = sorted(p for p, keys in expected.items() if not keys)
    forced = sorted(p for p, keys in expected.items() if len(keys) == 1)
    if dead:
        decision = ('dead', dead[0], [])
    elif forced:
        p = forced[0]; decision = ('forced', p, sorted(expected[p]))
    elif not expected:
        decision = ('empty', None, [])
    else:
        p = min(expected, key=lambda q: (state.generations.get(q, state.roots.get(q, 0)),
                                        len(expected[q]), q))
        decision = ('branch', p, sorted(expected[p]))
    need(decision == graph.decision(state), 'global DEAD/FORCED/generation scheduler')
    return dict(frontier_points=len(expected), incidences=sum(map(len, expected.values())),
                decision=decision, complete=True)


def verify_region(model, placements, proof, check):
    """Whole t/m and decoded word verification independent of State/Graph."""
    initial = model.initial(); totals = dict(initial.totals); marks = dict(initial.marks)
    seen = set()
    for key in placements:
        check(); need(key not in seen and key in model.cache, 'distinct actual placement')
        seen.add(key); c = model.placement(key)
        for p, v in c.occupancy:
            totals[p] = totals.get(p, 0) + v
        for p, v in c.marks:
            need(p not in marks or marks[p] == v, 'whole exact m-value agreement')
            marks[p] = v
    need(set(totals) == set(model.align_cache) and all(v == 12 for v in totals.values()),
         'whole target exact t-value capacity')
    decoded = model.decode(placements)
    need(decoded == proof and all(c['rule'] != 'block' for c in decoded),
         'whole decoded primitive word')
    return dict(complete=True, required_points=len(totals), selected_placements=len(seen),
                mark_points=len(marks), decoded_rows=len(decoded))


def compile_markings(model, check, limits):
    """Discover unary failed extensions; certify a full mandatory support domain.

    A certificate is sound because any completion containing the trial candidate
    must fill the exhibited unfilled root, yet every original root candidate has
    a literal t/m conflict already forced by that trial. No partial scan licenses
    a marking. Trials and certificates are bounded proposals, never search pruning.
    """
    result = dict(schema='certified-unary-point-failures-v1', proposals=[],
                  certificates=[], work=0, complete_proposal_prefix=True,
                  stopped=None, soundness='full original mandatory-root support exhaustion')
    for key in sorted(model.cache):
        check()
        if len(result['proposals']) >= limits['marking_proposals']:
            result['stopped'] = 'proposal_limit'; break
        if len(result['certificates']) >= limits['marking_certificates']:
            result['stopped'] = 'certificate_limit'; break
        state = model.initial()
        if _reason(model, state, key) is not None:
            continue
        trial = dict(key=key, status='NO_CERTIFICATE', tested_roots=[])
        result['proposals'].append(trial)
        owners = {p: 'initial' for p in state.marks}
        state.place(model.placement(key))
        for p, unused in model.placement(key).marks:
            owners[p] = key
        for root in sorted(state.frontier()):
            check(); witnesses = []; supported = False
            for candidate in model.alignments(root):
                check()
                if result['work'] >= limits['marking_work']:
                    trial['status'] = 'INCOMPLETE_SCAN'
                    result['complete_proposal_prefix'] = False
                    result['stopped'] = 'work_limit'
                    return result
                result['work'] += 1
                why = _reason(model, state, candidate, owners)
                if why is None:
                    supported = True; break
                witnesses.append(dict(key=candidate, witness=why))
            trial['tested_roots'].append(dict(root=root, supported=supported,
                                              tested_candidates=len(witnesses) + int(supported)))
            if not supported:
                ordinal = len(result['certificates']); point = (-100, ordinal)
                certificate = dict(id=ordinal, trial=[key], exhausted_root=root,
                                   all_candidates=witnesses,
                                   auxiliary=dict(point=point, initial_value=1,
                                                  placement=key, placement_value=0))
                result['certificates'].append(certificate)
                trial.update(status='CERTIFIED', certificate=ordinal)
                break
    return result


def verify_markings(model, packet, check):
    """Recheck every whole root and exact witness using the unmarked base model."""
    seen = set()
    for ordinal, certificate in enumerate(packet['certificates']):
        check(); key, = certificate['trial']; state = model.initial()
        need(certificate['id'] == ordinal and key not in seen, 'marking certificate order')
        seen.add(key); need(_reason(model, state, key) is None, 'legal trial')
        owners = {p: 'initial' for p in state.marks}
        state.place(model.placement(key))
        owners.update({p: key for p, unused in model.placement(key).marks})
        root = certificate['exhausted_root']; need(root in state.frontier(), 'mandatory unfilled root')
        expected = []
        for candidate in model.alignments(root):
            check(); why = _reason(model, state, candidate, owners)
            need(why is not None, 'every original root candidate must conflict')
            expected.append(dict(key=candidate, witness=why))
        need(expected == certificate['all_candidates'], 'complete literal support certificate')
        need(certificate['auxiliary'] == dict(point=(-100, ordinal), initial_value=1,
             placement=key, placement_value=0), 'exact redundant unary auxiliary marking')
    return dict(complete=True, certificates=len(seen), authority='finite point-support theorem only')


_MarkedModel = compact.MarkedModel


def _same_wire(wire, actual, check):
    """Strict JSON carrier equality; declared tuple sequences decode as arrays."""
    pending = [(wire, actual)]
    while pending:
        check(); left, right = pending.pop()
        if type(right) in (tuple, list):
            if type(left) is not list or len(left) != len(right):
                return False
            pending.extend(zip(left, right))
        elif type(right) is dict:
            if type(left) is not dict or set(left) != set(right):
                return False
            pending.extend((left[k], right[k]) for k in right)
        elif type(left) is not type(right) or left != right:
            return False
    return True


def indexed_model(model, check):
    return compact.evidence_view(model, check)


def verify_indexed_model(packet, model, check):
    return compact.verify_evidence(packet, model, check)


def _essential(proof, check):
    """Extract actual final-assertion ancestry, preserving primitive references."""
    needed = set(); pending = [len(proof) - 1]
    while pending:
        check(); index = pending.pop()
        if index in needed:
            continue
        need(0 <= index < len(proof), 'actual donor ancestry reference')
        needed.add(index); c = proof[index]
        refs = ([c['antecedent'], c['implication']] if c['rule'] == 'mp'
                else [c['source']] if c['rule'] == 'generalize' else [])
        need(all(type(r) is int and 0 <= r < index for r in refs), 'strict-prior donor references')
        pending.extend(refs)
    mapping = {old: new for new, old in enumerate(sorted(needed))}; output = []
    for old in sorted(needed):
        check(); c = copy.deepcopy(proof[old])
        if c['rule'] == 'mp':
            c['antecedent'] = mapping[c['antecedent']]; c['implication'] = mapping[c['implication']]
        elif c['rule'] == 'generalize':
            c['source'] = mapping[c['source']]
        need(c['rule'] != 'block', 'primitive essential donor')
        output.append(c)
    return output, sorted(needed)


def _ground_clusters(library, compiled, spec, miner, oracle, check, limits):
    """Finite syntactic proposals; complete fallback does not depend on coverage."""
    basis = [spec['target']] + [f for f in compiled['basis'] if f != spec['target']]
    instances = []; seen = set(); work = 0
    for family in library:
        interface = [family['template']['conclusion']] + family['template']['premises']
        family_start = len(instances)
        family_quota = max(1, limits['cluster_instances'] // max(1, len(library)))
        def visit(index, binding):
            nonlocal work
            check()
            if (work >= limits['cluster_binding_work'] or len(instances) >= limits['cluster_instances'] or
                    len(instances) - family_start >= family_quota):
                return
            if index == len(interface):
                if len(binding) != family['parameters']:
                    return
                args = [binding[j] for j in range(family['parameters'])]
                ground = miner.replace(family['template'], args)
                signature = word(ground)
                if signature in seen:
                    return
                seen.add(signature)
                name = 'pilot_cluster_' + str(len(instances))
                definition = dict(name=name, premises=ground['premises'],
                                  conclusion=ground['conclusion'], proof=ground['proof'])
                need(not any(c['rule'] == 'block' for c in definition['proof']), 'primitive donor only')
                instances.append(dict(id=name, family=family['id'], arguments=args,
                                      definition=definition))
                return
            for f in basis:
                check(); work += 1
                if work > limits['cluster_binding_work']:
                    return
                bound = miner.unify(interface[index], f, binding)
                if bound is not None:
                    visit(index + 1, bound)
                if (len(instances) >= limits['cluster_instances'] or
                        len(instances) - family_start >= family_quota):
                    return
        visit(0, {})
    taut = ['imp', ['bot'], ['bot']]
    q = _request(oracle, spec, [dict(rule='tautology', formula=taut)], check, limits,
                 'pilot_ground_cluster_admission', blocks=[i['definition'] for i in instances], target=taut)
    native_status = q['result']['status']
    need(type(native_status) is str and native_status in
         ('accepted', 'rejected', 'unknown_step_budget', 'unknown_space_budget'),
         'unrecognized Native ground admission status')
    need(native_status != 'rejected', 'Native rejected actual ground cluster acquisition')
    accepted = native_status == 'accepted'
    return dict(instances=instances, admission_query=q['id'], native_status=native_status, status='native_accepted' if accepted else 'unknown_cluster_admission',
                usable=instances if accepted else [], binding_work=work,
                proposal_coverage='bounded ordering proposals; no primitive candidate removed')


def _expand(instance, prefix, spec, host, check):
    """Resolve learned assumption receptors to actual earlier rows or named axioms."""
    definition = instance['definition']; proof = copy.deepcopy(prefix); expansion = []; remap = {}
    for index, original in enumerate(definition['proof']):
        check(); c = copy.deepcopy(original)
        if c['rule'] == 'assumption':
            port = c['index']
            need(0 <= port < len(definition['premises']) and c['formula'] == definition['premises'][port],
                 'actual learned premise receptor')
            sources = [j for j, old in enumerate(proof) if old['formula'] == c['formula']]
            if sources:
                remap[index] = sources[0]; continue
            names = [n for n, f in sorted(spec['theory']['axioms'].items()) if f == c['formula']]
            if not names:
                return None
            c = dict(rule='axiom', formula=c['formula'], name=names[0])
        elif c['rule'] == 'mp':
            c['antecedent'] = remap[c['antecedent']]; c['implication'] = remap[c['implication']]
        elif c['rule'] == 'generalize':
            c['source'] = remap[c['source']]
        need(c['rule'] != 'block', 'no block primitive expansion')
        remap[index] = len(proof); proof.append(c); expansion.append(c)
    if not expansion or len(proof) > spec['length']:
        return None
    host_receipt = host_check(spec, proof, definition['conclusion'], host, check)
    if not host_receipt['accepted']:
        return None
    return dict(instance=instance['id'], prefix_rows=len(prefix), commands=expansion,
                result_formula=definition['conclusion'], host_check=host_receipt,
                checked_primitive_proof=proof)


def _prefix(model, state):
    by_role = {(k[0], k[1]): k for k in state.selected}; prefix = []
    for row in range(model.spec['length']):
        if (row, 0) not in by_role or (row, 1) not in by_role:
            break
        a = model.metadata[by_role[row, 0]]['command']; b = model.metadata[by_role[row, 1]]['command']
        if a != b:
            break
        prefix.append(a)
    return prefix


def _keys_for_commands(model, prefix_count, commands, check):
    keys = []
    basis_index = {word(f): j for j, f in enumerate(model.compiled['basis'])}
    for offset, c in enumerate(commands):
        check(); row = prefix_count + offset
        if row >= model.spec['length']:
            return None
        matches = [k for k, item in enumerate(model.domains[row]) if item == c]
        if len(matches) != 1:
            return None
        k = matches[0]
        guards = [key for key in model.alignments((4 * row, 1)) if key[2] == k]
        if c['rule'] == 'mp':
            # The command carries references; its actual antecedent implication
            # is selected by the guard's existing literal variant, never invented.
            pass
        if not guards:
            return None
        # Keep all guard variants as separate cluster proposals in caller.
        keys.append(((row, 0, k, 0), guards))
    return keys


def _point_hint(model, state, graph, point, instances, host, check, limits):
    prefix = _prefix(model, state); proposals = []
    for instance in instances:
        check()
        if len(proposals) >= limits['cluster_proposals']:
            break
        expansion = _expand(instance, prefix, model.spec, host, check)
        if expansion is None:
            continue
        skeleton = _keys_for_commands(model, len(prefix), expansion['commands'], check)
        if skeleton is None:
            continue
        # All compatible primitive guard variants are eligible proposals. A
        # bounded proposer can abstain; search still keeps every primitive key.
        for variants in itertools.product(*(guards for command, guards in skeleton)):
            check()
            members = [key for (command, unused), guard in zip(skeleton, variants) for key in (command, guard)]
            trial = state.copy(); valid = True
            for key in members:
                check()
                if key in trial.selected:
                    continue
                if _reason(model, trial, key) is not None:
                    valid = False; break
                trial.place(model.placement(key))
            if not valid:
                continue
            pending = [k for k in members if k not in state.selected]
            if not any(k in graph.domains[point] for k in pending):
                continue
            packet = dict(expansion, members=members, pending=pending)
            proposals.append(packet)
            if len(proposals) >= limits['cluster_proposals']:
                break
    return proposals


def _aux_removals(model, state, before, after, check):
    witnesses = []
    for point, keys in sorted(before.items()):
        for key in sorted(keys - after.get(point, set())):
            check()
            c = model.placement(key)
            for p, value in c.marks:
                if p[0] == -100 and p in state.marks and state.marks[p] != value:
                    witnesses.append(dict(frontier_point=point, candidate=key, auxiliary_point=p,
                                          channel='certified-failure', candidate_value=value,
                                          assigned_value=state.marks[p], assigned_owner='initial'))
                    break
    return witnesses


def search_points(model, instances, enabled, modules, check, limits):
    points = modules['points']; began = time.perf_counter(); budget = _Budget(check, limits)
    initial = model.initial(); graph = points.Graph(model, initial)
    state_pre = copy.deepcopy(initial.__dict__)
    graph_pre = graph.fingerprint(); trace = []; audits = []; metrics = collections.Counter(); found = None
    def visit(state, g, hint):
        nonlocal found
        budget.check(); kind, point, keys = g.decision(state); metrics['nodes'] += 1
        if len(audits) < limits['domain_audits']:
            audits.append(audit_domains(model, state, g, budget.check))
        node = len(trace); trace.append(dict(event='decision', ordinal=node, kind=kind, point=point,
                                             original_alternatives=keys))
        if kind == 'dead':
            metrics['dead'] += 1; return False
        if kind == 'empty':
            found = state; return True
        metrics[kind] += 1; preferred = []
        if hint is not None:
            pending = [k for k in hint['pending'] if k not in state.selected]
            if not pending or any(_reason(model, state, k) is not None for k in pending):
                hint = None
            else:
                preferred = [k for k in pending if k in g.domains[point]]
        if kind == 'branch' and hint is None and enabled:
            proposals = _point_hint(model, state, g, point, instances, modules['host'], budget.check, limits)
            trace.append(dict(event='cluster_proposals', decision=node, proposals=proposals))
            metrics['cluster_proposals'] += len(proposals)
            if proposals:
                hint = proposals[0]; preferred = [k for k in hint['pending'] if k in g.domains[point]]
                metrics['cluster_hints'] += 1
        alternatives = keys if kind == 'forced' else [k for k in keys if k in preferred] + [k for k in keys if k not in preferred]
        need(sorted(alternatives) == sorted(keys), 'complete primitive fallback/multiplicity')
        trace.append(dict(event='order', decision=node, alternatives=alternatives, preferred=preferred))
        for key in alternatives:
            budget.extend(); metrics['attempts'] += 1
            child = state.copy(); cg = g.copy(); changed = child.place(model.placement(key))
            before = {p: set(v) for p, v in cg.domains.items()}
            cg.update(model, child, changed)
            removed = _aux_removals(model, child, before, cg.domains, check)
            trace.append(dict(event='place', decision=node, key=key, generation=child.tile_generations[-1],
                              auxiliary_removals=removed))
            metrics['auxiliary_removed_incidences'] += len(removed)
            ok = visit(child, cg, hint)
            trace.append(dict(event='return', decision=node, key=key, result=ok))
            if ok:
                return True
            metrics['backtracks'] += 1
        return False
    status = 'unknown_search_budget'
    try:
        complete = visit(initial, graph, None)
        status = 'point_proof_candidate' if complete else 'exhausted_finite_point_region'
    except _Cutoff as error:
        if error is not budget.stop:
            raise
        trace.append(dict(event='cutoff', attempts=budget.attempts))
    need(state_pre == initial.__dict__ and
         graph_pre == graph.fingerprint(), 'exact original point state/graph rollback')
    placements = [] if found is None else found.order
    proof = None if found is None else model.decode(placements)
    # Initial m eliminations are present before the first Graph update event.
    initial_aux = []
    for p in sorted(initial.frontier()):
        for key in model.alignments(p):
            check(); why = _reason(model, initial, key)
            if why and why['kind'] == 'marking' and why['point'][0] == -100:
                initial_aux.append(dict(frontier_point=p, candidate=key, auxiliary_point=why['point'],
                                        channel='certified-failure', candidate_value=why['candidate_value'],
                                        assigned_value=why['assigned_value'], assigned_owner='initial'))
    metrics['initial_auxiliary_removed_incidences'] = len(initial_aux)
    metrics['auxiliary_removed_incidences_total'] = metrics['auxiliary_removed_incidences'] + len(initial_aux)
    return dict(status=status, proof=proof, placements=placements, trace=trace, metrics=dict(metrics),
                initial_auxiliary_removals=initial_aux, domain_audits=audits, root_restored=True,
                graph_metrics=dict(model.metrics), seconds=time.perf_counter() - began,
                attempt_unit='primitive point placement', cluster_ordering=enabled)


def search_symbolic(model, instances, enabled, modules, check, limits):
    began = time.perf_counter(); budget = _Budget(check, limits); helper = modules['symbolic']
    compiled = model.compiled; spec = model.spec
    basis_index = {helper._json(f): i for i, f in enumerate(compiled['basis'])}
    tauts = {helper._json(f) for f in compiled['tautologies']}; schemes = {helper._json(c) for c in compiled['admitted_schemes']}
    distances = {}
    path = []; selected = []; trace = []; metrics = collections.Counter(); found = None
    def visit(hint=None):
        nonlocal found
        budget.check(); row = len(path); metrics['nodes'] += 1
        if row == spec['length']:
            found = (copy.deepcopy(path), list(selected)); return True
        candidates = []
        for k, c in enumerate(model.domains[row]):
            budget.check(); metrics['skeleton_tests'] += 1
            if c['rule'] == 'axiom':
                v = 0 if spec['theory']['axioms'][c['name']] == c['formula'] else None
            else:
                v = helper._primitive_guard(c, path, basis_index, tauts, schemes)
            if v is not None:
                candidates.append((k, v, c))
        available = {word(c['formula']) for c in path}
        candidates.sort(key=lambda item: (word(item[2]['formula']) in available,
                        distances.get(helper._json(item[2]['formula']), len(distances) + 1), item[0]))
        active = hint
        if active is not None and (not active['commands'] or active['prefix_rows'] != row):
            active = None
        proposals = []
        if enabled and active is None:
            for instance in instances:
                budget.check(); item = _expand(instance, path, spec, modules['host'], budget.check)
                if item is not None and any(c == item['commands'][0] for k, v, c in candidates):
                    proposals.append(item)
                if len(proposals) >= limits['cluster_proposals']:
                    break
            active = proposals[0] if proposals else None
            metrics['cluster_proposals'] += len(proposals)
        preferred = active['commands'][0] if active is not None else None
        ordered = [item for item in candidates if item[2] == preferred] + [item for item in candidates if item[2] != preferred]
        need(len(ordered) == len(candidates), 'symbolic complete primitive fallback')
        ordinal = len(trace); trace.append(dict(event='decision', row=row,
            original_candidates=[[k, v] for k, v, c in candidates],
            ordered_candidates=[[k, v] for k, v, c in ordered], proposals=proposals))
        for k, v, c in ordered:
            budget.extend(); metrics['attempts'] += 1
            trace.append(dict(event='extend', decision=ordinal, skeleton=k, variant=v))
            path.append(c); selected.extend([(row, 0, k, 0), (row, 1, k, v)])
            child_hint = None
            if active is not None and c == preferred:
                child_hint = dict(active, prefix_rows=row + 1, commands=active['commands'][1:])
            try:
                if visit(child_hint):
                    trace.append(dict(event='return', decision=ordinal, skeleton=k, result=True)); return True
                trace.append(dict(event='return', decision=ordinal, skeleton=k, result=False)); metrics['backtracks'] += 1
            finally:
                del selected[-2:]; path.pop()
        return False
    status = 'unknown_search_budget'
    try:
        dependencies = helper._backward_distances(compiled['basis'], compiled['variables'], [], budget)
        distances = helper._distances_from_target(spec['target'], dependencies, budget)
        complete = visit()
        status = 'symbolic_proof_candidate' if complete else 'exhausted_finite_symbolic_grammar'
    except _Cutoff as error:
        if error is not budget.stop:
            raise
        trace.append(dict(event='cutoff', attempts=budget.attempts))
    need(not path and not selected, 'exact symbolic prefix rollback')
    return dict(status=status, proof=None if found is None else found[0],
                placements=[] if found is None else found[1], trace=trace,
                metrics=dict(metrics), seconds=time.perf_counter() - began,
                attempt_unit='primitive proof-row extension', root_restored=True,
                cluster_ordering=enabled, strategy='existing novelty/backward order plus optional acquired cluster')


def run_pilot(input_document, *, case_id, check, limits, modules, oracle):
    """Root owns Source/runtime custody, Native lifecycle and whole resource caps.

    This one actual constructs each model and certification afresh. Full model,
    Native records, training proofs, frozen mined library, ground admissions,
    marking certificates and ordered compact search traces are returned. The
    callback is never caught/classified as our own budget. No old qualification
    result or physical Wang gate is changed by this new experiment.
    """
    check(); need(set(modules) == set(MODULE_ROLES), 'exact injected pilot roles')
    need(limits == LIMITS, 'exact preregistered scientific limits')
    original = literal(input_document); doc = literal(input_document)
    need(doc['schema'] == 'gcts-proof-search-pilot-inputs-v1', 'pilot input schema')
    need(len(doc['training']) == 3 and len(doc['tests']) == 3, 'complete new pilot input cohort')
    selected_tests = [s for s in doc['tests'] if s['id'] == case_id]
    need(type(case_id) is str and len(selected_tests) == 1, 'exact preregistered case job')
    need(not oracle.records, 'fresh cold Native query stream for this job')
    expected_arms = [dict(id=i, engine=e, certified_markings=m, acquired_clusters=c)
        for i, e, m, c in [('S0','symbolic',False,False),('SC','symbolic',False,True),
                           ('P00','point',False,False),('P01','point',False,True),
                           ('P10','point',True,False),('P11','point',True,True)]]
    need(_same_wire(doc['arms'], expected_arms, check), 'six exact typed arm configurations')
    began = time.perf_counter(); result = dict(schema=VERSION, inputs=doc,
        limits=literal(limits), selected_case_id=case_id, job_scope='all six arms plus all three cold donors for exactly one declared case; all three jobs required for overall comparison', training=[], library=[], tests=[], scope='Native/point adaptation; no RL or physical Wang acceptance',
        resource_accepted=False, complete=False, job_record_complete=False,
        all_six_searched=False, scientific_complete=False,
        completion_scope='job_record_complete denotes six explicit scientific arm records; Root output/resource/custody admission is separate.')
    def compile_case(spec):
        check(); compiled = modules['compiler'].compile_guards(spec, oracle,
                           limit=limits['native_steps'], queries=limits['compile_queries'])
        check(); need(compiled['status'] == 'complete', 'whole Native-admitted compiler required')
        inventory = _empty_inventory()
        model = modules['model'].Model(spec, compiled, inventory, arity=0, families=False, check=check)
        reference_receipt = reference.verify_compact_reference(spec, compiled, inventory, model, check=check)
        model.reference_receipt = reference_receipt
        check(); need(model.arity == 0 and not model.interfaces and
                      all(c['rule'] != 'block' for row in model.domains for c in row),
                      'same complete primitive candidate grammar')
        return compiled, model
    # Actual acquisition contains no supplied donor proof/route/library.
    training_started = time.perf_counter()
    for spec in doc['training']:
        donor_started = time.perf_counter(); check()
        stage_started = time.perf_counter(); compiled, model = compile_case(spec)
        compile_and_model_seconds = time.perf_counter() - stage_started
        stage_started = time.perf_counter()
        search = search_symbolic(model, [], False, modules, check, limits)
        search_stage_seconds = time.perf_counter() - stage_started
        entry = dict(spec=spec, compiler=compiled, domains=model.domains, reference_check=model.reference_receipt, search=search, acquired=False,
                     timings=dict(compile_and_model_seconds=compile_and_model_seconds,
                                  search_seconds=search_stage_seconds,
                                  whole_host_region_native_seconds=None,
                                  essential_extract_host_native_seconds=None, mining_seconds=None,
                                  full_donor_seconds=None))
        result['training'].append(entry)
        if search['proof'] is not None:
            stage_started = time.perf_counter()
            entry['host_check'] = host_check(spec, search['proof'], spec['target'], modules['host'], check)
            need(entry['host_check']['accepted'], 'Host rejected discovered training proof')
            entry['region'] = verify_region(model, search['placements'], search['proof'], check)
            q = _request(oracle, spec, search['proof'], check, limits, 'pilot_training_whole_primitive')
            entry['native_query'] = q['id']
            entry['timings']['whole_host_region_native_seconds'] = time.perf_counter() - stage_started
            need(q['result']['status'] != 'rejected', 'Native rejected searched training proof')
            if q['result']['status'] == 'accepted':
                stage_started = time.perf_counter()
                essential, ancestry = _essential(search['proof'], check)
                entry['essential_host_check'] = host_check(spec, essential, spec['target'], modules['host'], check)
                need(entry['essential_host_check']['accepted'], 'Host rejected extracted essential donor')
                eq = _request(oracle, spec, essential, check, limits, 'pilot_training_essential_primitive')
                entry['essential_proof'] = essential; entry['essential_ancestry'] = ancestry
                entry['essential_native_query'] = eq['id']
                entry['timings']['essential_extract_host_native_seconds'] = time.perf_counter() - stage_started
                if eq['result']['status'] != 'accepted':
                    entry['timings']['full_donor_seconds'] = time.perf_counter() - donor_started
                    result['training_and_acquisition_seconds'] = time.perf_counter() - training_started
                    result.update(status='TRAINING_INCOMPLETE', native_records=literal(oracle.records),
                                  seconds=time.perf_counter() - began)
                    return result
                need(all(c['rule'] in ('axiom', 'mp') for c in essential), 'declared training primitive rule profile')
                stage_started = time.perf_counter()
                family = modules['miner'].mine(eq['request'], [], dict(training_id=spec['id'], native_query=eq['id']))
                entry['timings']['mining_seconds'] = time.perf_counter() - stage_started
                need(not family['dependencies'], 'primitive training donor dependency')
                entry['acquired'] = True; entry['family'] = family['id']; result['library'].append(family)
        entry['timings']['full_donor_seconds'] = time.perf_counter() - donor_started
        if not entry['acquired']:
            result['training_and_acquisition_seconds'] = time.perf_counter() - training_started
            result.update(status='TRAINING_INCOMPLETE', native_records=literal(oracle.records),
                          seconds=time.perf_counter() - began)
            return result
    result['training_and_acquisition_seconds'] = time.perf_counter() - training_started
    frozen_library = literal(result['library']); result['library_frozen_before_tests'] = True
    result['diagnostics'] = run_diagnostics(modules, check, limits)
    result['compact_reference_diagnostics'] = reference.run_reference_diagnostics(compact, check=check)
    for spec in selected_tests:
        setup_started = time.perf_counter(); check()
        stage_started = time.perf_counter(); compiled, model = compile_case(spec)
        compile_and_model_seconds = time.perf_counter() - stage_started
        encoding_started = time.perf_counter()
        model_record = indexed_model(model, check)
        indexed_check = verify_indexed_model(model_record, model, check)
        encoding_seconds = time.perf_counter() - encoding_started
        marking_started = time.perf_counter()
        marking = compile_markings(model, check, limits)
        certificate_check = verify_markings(model, marking, check)
        marking['compile_and_verification_seconds'] = time.perf_counter() - marking_started
        marked = _MarkedModel(model, marking, modules['points'])
        marked_extension_check = reference.verify_marked_extension(model, marked, marking, check=check)
        cluster_started = time.perf_counter()
        clusters = _ground_clusters(frozen_library, compiled, spec, modules['miner'], oracle, check, limits)
        clusters['specialization_and_admission_seconds'] = time.perf_counter() - cluster_started
        case = dict(spec=spec, compiler=compiled, compile_and_model_seconds=compile_and_model_seconds,
                    model=model_record, reference_check=model.reference_receipt, indexed_model_check=indexed_check,
                    indexed_model_seconds=encoding_seconds, markings=marking,
                    marking_certificate_check=certificate_check, marked_extension_check=marked_extension_check,
                    clusters=clusters, arms=[])
        result['tests'].append(case)
        case['full_shared_setup_seconds'] = time.perf_counter() - setup_started
        arm_rows = {a['id']: a for a in doc['arms']}
        arm_order = doc['protocol']['arm_order'][case_id]
        need(len(arm_order) == 6 and set(arm_order) == set(arm_rows), 'whole preregistered six-arm schedule')
        for arm_id in arm_order:
            arm_started = time.perf_counter()
            arm = arm_rows[arm_id]
            check(); symbolic = arm['engine'] == 'symbolic'
            cluster_on = arm['acquired_clusters']
            marking_on = arm['certified_markings']
            if cluster_on and clusters['status'] != 'native_accepted':
                need(clusters['native_status'] in ('unknown_step_budget', 'unknown_space_budget'),
                     'only declared Native UNKNOWN may skip a cluster-dependent arm')
                case['arms'].append(dict(
                    id=arm_id, method='symbolic' if symbolic else 'point',
                    marking_enabled=marking_on, cluster_enabled=True,
                    execution_status='SKIPPED_UNKNOWN_PREREQUISITE',
                    reason='ground_registry_native_unknown',
                    prerequisite=dict(required=True, admission_query=clusters['admission_query'],
                                      native_status=clusters['native_status']),
                    search=None, host_check=None, region=None, native_query=None,
                    native_proof_accepted=None, proof_verification_status='NOT_RUN_SKIPPED_PREREQUISITE',
                    timings=dict(search_seconds=None, host_region_native_seconds=None,
                                 full_arm_seconds=None,
                                 scope='Skipped arm: no search, proof check, or measured arm execution. Shared ground query cost remains charged.')))
                check()
                continue
            active_model = marked if marking_on else model
            active_model.metrics.clear()
            usable = clusters['usable'] if cluster_on else []
            stage_started = time.perf_counter()
            search = (search_symbolic(active_model, usable, cluster_on, modules, check, limits)
                      if symbolic else search_points(active_model, usable, cluster_on, modules, check, limits))
            search_stage_seconds = time.perf_counter() - stage_started
            entry = dict(id=arm_id, method='symbolic' if symbolic else 'point',
                         marking_enabled=marking_on, cluster_enabled=cluster_on,
                         execution_status='SEARCH_RETURNED', reason=None,
                         prerequisite=dict(required=cluster_on, admission_query=clusters['admission_query'],
                                           native_status=clusters['native_status']),
                         search=search, native_proof_accepted=False,
                         proof_verification_status='NO_PROOF_CANDIDATE',
                         timings=dict(search_seconds=search_stage_seconds,
                                      host_region_native_seconds=None, full_arm_seconds=None,
                                      scope='Full arm includes search, proof gates and entry preparation. Cold shared compilation/acquisition/marking/indexed output and final job serialization remain separately charged once.'))
            case['arms'].append(entry)
            if search['proof'] is not None:
                stage_started = time.perf_counter()
                entry['host_check'] = host_check(spec, search['proof'], spec['target'], modules['host'], check)
                need(entry['host_check']['accepted'], 'Host rejected discovered test proof')
                entry['region'] = verify_region(active_model, search['placements'], search['proof'], check)
                q = _request(oracle, spec, search['proof'], check, limits, 'pilot_test_' + spec['id'] + '_' + arm_id)
                entry['native_query'] = q['id']; entry['native_proof_accepted'] = q['result']['status'] == 'accepted'
                need(q['result']['status'] != 'rejected', 'whole Native rejected candidate is experiment failure')
                entry['proof_verification_status'] = ('HOST_REGION_NATIVE_ACCEPTED'
                    if entry['native_proof_accepted'] else 'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN')
                entry['timings']['host_region_native_seconds'] = time.perf_counter() - stage_started
            check()
            entry['timings']['full_arm_seconds'] = time.perf_counter() - arm_started
        need(literal(result['library']) == frozen_library, 'no test-time library acquisition')
    check(); need(literal(input_document) == original, 'caller input unchanged')
    result['native_records'] = literal(oracle.records)
    arms = result['tests'][0]['arms']
    need(len(arms) == 6 and [a['id'] for a in arms] == doc['protocol']['arm_order'][case_id],
         'all six ordered explicit arm outcomes')
    result['job_record_complete'] = True
    result['all_six_searched'] = all(a['execution_status'] == 'SEARCH_RETURNED' for a in arms)
    result['scientific_complete'] = (result['all_six_searched'] and
        all(a['proof_verification_status'] != 'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN' for a in arms))
    result['complete'] = result['scientific_complete']
    result['comparison_status'] = ('FULL_SIX_ARM_RECORD' if result['scientific_complete'] else
                                   'INCOMPLETE_SCIENTIFIC_COMPARISON')
    result['seconds'] = time.perf_counter() - began
    return result


def run_diagnostics(modules, check, limits):
    """Actual tiny full-domain/marking checks; no theorem or benchmark substitute."""
    check(); points = modules['points']
    class Tiny:
        def __init__(self):
            self.cache = {}; self.align_cache = {(0, 0): [], (4, 0): []}
            self.dependencies = collections.defaultdict(set); self.metadata = {}
            self.metrics = collections.Counter(); self.domains = []; self.spec = {}
            self.compiled = {}; self.inventory = {}; self.arity = 0; self.mode = {}; self.interfaces = []
            for index, root, value in [(0, (0, 0), 1), (1, (0, 0), 0),
                                        (2, (4, 0), 0), (3, (4, 0), 0)]:
                key = (index, 0, 0, 0)
                c = points.Placement(key, ((root, 12),), (((1, 50), value),), ())
                self.cache[key] = c; self.align_cache[root].append(key)
                for p, unused in c.occupancy + c.marks:
                    self.dependencies[p].add(key)
        def initial(self):
            roots = {p: 0 for p in self.align_cache}
            return points.State(generations=roots.copy(), roots=roots.copy(), allowed_points=frozenset(roots))
        def placement(self, key):
            return self.cache[key]
        def alignments(self, point):
            return self.align_cache[point]
    base = Tiny(); packet = compile_markings(base, check, limits)
    verified = verify_markings(base, packet, check)
    need(any(c['trial'] == [(0, 0, 0, 0)] for c in packet['certificates']), 'tiny failed extension is discovered')
    marked = _MarkedModel(base, packet, points)
    marked_extension_check = reference.verify_marked_extension(base, marked, packet, check=check)
    solutions = []
    audits = []
    for model in (base, marked):
        state = model.initial(); graph = points.Graph(model, state)
        audits.append(audit_domains(model, state, graph, check)); rows = []
        for a in base.alignments((0, 0)):
            for b in base.alignments((4, 0)):
                check(); trial = model.initial(); legal = True
                for key in (a, b):
                    if _reason(model, trial, key) is not None:
                        legal = False; break
                    trial.place(model.placement(key))
                if legal:
                    rows.append([a, b])
        solutions.append(rows)
        for key in sorted(model.cache):
            check()
            if _reason(model, state, key) is None:
                child = state.copy(); cg = graph.copy(); cg.update(model, child, child.place(model.placement(key)))
                audits.append(audit_domains(model, child, cg, check))
        need(not state.selected and graph.fingerprint() == points.Graph(model, model.initial()).fingerprint(),
             'tiny exact independent branch rollback')
    need(solutions[0] == solutions[1] and len(solutions[0]) == 2, 'all tiny solutions preserved by real m lane')
    malformed = copy.deepcopy(packet); malformed['certificates'][0]['all_candidates'].pop()
    rejected = False; genuine_fault = []
    def guarded_check():
        try:
            check()
        except BaseException as error:
            genuine_fault.append(error)
            raise
    try:
        verify_markings(base, malformed, guarded_check)
    except ValueError as error:
        # Only our deterministic certificate rejection is expected; Root faults
        # have distinct objects/types and must escape untouched.
        if (genuine_fault and error is genuine_fault[0]) or str(error) != 'complete literal support certificate':
            raise
        rejected = True
    need(rejected, 'missing whole-domain certificate member rejected')
    probe = points.Graph(base, base.initial())
    probe.domains[(0, 0)] = {(1, 0, 0, 0)}; probe.domains[(4, 0)] = set()
    need(probe.decision(base.initial())[0] == 'dead', 'global distant DEAD precedes forced')
    probe = points.Graph(base, base.initial()); generation_state = base.initial()
    generation_state.generations[(0, 0)] = 1
    # Synthetic decision input: earlier generation has degree3, later has2.
    # Full legal graph construction is audited separately above.
    probe.domains[(4, 0)].add((99, 0, 0, 0))
    need(probe.decision(generation_state)[1] == (4, 0), 'earliest generation precedes coordinate order')
    probe.domains[(0, 0)] = {(1, 0, 0, 0)}
    need(probe.decision(generation_state)[:2] == ('forced', (0, 0)), 'global forced precedes branch generation')
    zero_work = dict(limits, marking_work=0)
    incomplete = compile_markings(base, check, zero_work)
    need(not incomplete['certificates'] and incomplete['stopped'] == 'work_limit',
         'unknown support scan never licenses a marking')
    sentinel = RuntimeError('diagnostic external callback sentinel')
    def external():
        check(); raise sentinel
    escaped = False
    try:
        compile_markings(base, external, limits)
    except BaseException as error:
        if error is not sentinel:
            raise
        escaped = True
    need(escaped, 'exact external callback identity propagated')
    return dict(schema='pilot-actual-tiny-diagnostics-v1', status='complete',
                full_domain_audits=audits, base_solutions=solutions[0], marked_solutions=solutions[1],
                markings=packet, marking_verification=verified, marked_extension_check=marked_extension_check,
                incomplete_certificate_rejected=rejected, callback_identity_propagated=escaped,
                global_dead_forced_generation_controls=True, incomplete_support_scan=incomplete,
                scope='tiny mechanism diagnostics; real complete logical case and all arms remain required')
