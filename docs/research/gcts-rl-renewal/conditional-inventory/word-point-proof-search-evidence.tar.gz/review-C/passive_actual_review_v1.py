"""Passive complete-saved-result reviewer; no scientific imports or replay."""
import collections
import hashlib
import json
from pathlib import Path

D = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-word-point-proof-pilot-20261020')
OUT = D/'review-C'


def pin(path):
    path=Path(path)
    assert '.partial' not in path.name
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def load(path):
    path=Path(path)
    assert path.suffix=='.json' and '.partial' not in path.name
    return json.loads(path.read_bytes())


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def verify(row):
    assert pin(row['path']) == {k:row[k] for k in ('path','bytes','sha256')}


offer=load(D/'root/prospective-whole-offer-v1.json')
for row in offer['files']:verify(row)
assert len(offer['files'])==41
corpus=load(next(r['path']for r in offer['files']if r['sha256']=='2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'))
bank=load(D/'verification-L/declarative-diagnostic-bank-v1.json')
control_ids=[r['id']for r in bank['controls']]
external_path=D/'root/external-tool-observer-v1.json'
external=load(external_path)
assert external['complete_tool_exits']==3 and external['remaining_once_grants']==0
case_order=['pilot-fork-join-positive','pilot-quantifier-equality-positive','pilot-fork-join-missing-Pa']
expected_pins=[('ccb0cbe9f3e545b4f5f32ce37aac6fdbac96a43f82adbe1d8d43688ef4ff5dbd',31536978),('13225d454d75887557a9f2203689186769da92bf43abfee8e85a5c4891703afa',30984092),('93ec9488a5b5a9575cecd56d17f286af9cf96d3650d7af80b2965e78ed3dbd38',31344945)]
expected_attempts=[{'S0':14,'P00':19,'P10':15},{'S0':600,'P00':16,'P10':25},{'S0':600,'P00':4,'P10':10}]
case_rows=[]; file_pins=[]; total_status=collections.Counter(); raw_search=raw_skip=raw_point_attempt=raw_audit=raw_donor_queries=0
admitted_search=admitted_skip=admitted_point_attempt=admitted_audit=0
for number,case_id in enumerate(case_order):
    path=D/'actual'/case_id
    observer_path=D/'actual'/(case_id+'.observer')/'observer.json'
    packet_path=path/('failure.json'if number==0 else 'result.json')
    pp=pin(packet_path)
    assert (pp['sha256'],pp['bytes'])==expected_pins[number]
    packet=load(packet_path); s=packet['scientific_result']; t=s['tests'][0]
    header=load(path/'worker-header.json'); terminal=load(path/'terminal.json'); observer=load(observer_path)
    plan_path=D/'root'/('plan-'+case_id+'-v1.json'); plan=load(plan_path)
    grant_path=D/'root'/('grant-'+case_id+'-v1.json'); grant=load(grant_path); consumed=load(path/'CONSUMED.json')
    tool=next(x for x in external['cases']if x['case_id']==case_id)
    assert packet['case_id']==s['selected_case_id']==header['case_id']==terminal['case_id']==observer['case_id']==case_id
    assert consumed['case_id']==grant['case_id']==case_id and consumed['uses']==grant['uses']==1
    assert consumed['plan_sha256']==grant['plan_sha256']==pin(plan_path)['sha256']
    assert consumed['grant_sha256']==pin(grant_path)['sha256']
    assert grant['authorized']is True and grant['no_retry']is True and grant['old_grants_reused']is False
    for row in grant['reviews']:verify(row)
    assert s['inputs']==corpus and s['limits']==plan['experiment_limits']
    assert s['job_record_complete']is True
    assert s['all_six_searched']is s['scientific_complete']is s['complete']is False
    assert s['resource_accepted']is False # research entry never admits its own whole job
    assert packet['source_unchanged']is True and terminal['sources_unchanged']is True
    assert packet['old_qualification_reused']is packet['full_physical_Wang_claim']is False
    assert header['result']==pp and terminal['header']==header
    assert packet['first_Root_fault']is False
    assert header['native_closed_and_reaped']is True
    transport=packet['native_transport']; queries=packet['native_queries']
    assert s['native_records']==queries and transport['complete_records']==len(queries)
    assert transport['all_reaped']is transport['closed']is True and transport['native_exit_code']==0
    assert [q['id']for q in queries]==list(range(len(queries)))
    assert len(transport['request_stages'])==len(queries)
    for q,stage in zip(queries,transport['request_stages']):
        assert hashlib.sha256(canonical(q['request'])).hexdigest()==q['request_sha256']
        assert stage['record_id']==stage['ordinal']==q['id'] and stage['stage']=='COMPLETED'
        assert stage['purpose']==q['purpose'] and stage['limit']==plan['experiment_limits']['native_steps']
        for k in ['request_sha256','input_sha256','output_sha256']:assert stage[k]==q[k]
    assert pin(path/'native/input.bin')['sha256']==queries[-1]['input_sha256']
    assert pin(path/'native/output.bin')['sha256']==queries[-1]['output_sha256']
    qs=collections.Counter(q['result']['status']for q in queries); total_status.update(qs)
    assert qs['unknown_step_budget']==1
    clusters=t['clusters']; cq=queries[clusters['admission_query']]
    assert cq['purpose']=='pilot_ground_cluster_admission' and cq['request']['theory']==t['spec']['theory']
    assert cq['request']['blocks']==[x['definition']for x in clusters['instances']]
    assert cq['result']['status']==clusters['native_status']=='unknown_step_budget'
    assert cq['result']['micro_steps']==plan['experiment_limits']['native_steps']==1000000000
    assert clusters['usable']==[] and clusters['status']=='unknown_cluster_admission'
    assert clusters['binding_work']==20003
    wr=s['word_reference_diagnostics']
    assert wr['complete']is True and [r['id']for r in wr['controls']]==control_ids
    assert all(r['status']=='PASSED'for r in wr['controls']) and wr['tiny_full_byte_pair_comparisons']==49
    assert s['diagnostics']['status']=='complete' and s['diagnostics']['base_solutions']==s['diagnostics']['marked_solutions']
    assert s['diagnostics']['global_dead_forced_generation_controls']is s['diagnostics']['callback_identity_propagated']is True
    assert t['reference_check']['complete']is t['word_model_check']['complete']is t['marked_extension_check']['complete']is t['marking_certificate_check']['complete']is True
    assert t['reference_check']['pointwise_identity']is False
    model=t['model']; placements={tuple(r['key']):r for r in model['placements']}
    assert len(placements)==len(model['placements'])==t['reference_check']['accepted_placements']
    assert model['word_terminator']==256 and len(model['word_dictionary'])==t['reference_check']['distinct_complete_words']
    assert model['initial']['marks']==[[[4*(t['spec']['length']-1),100],0]]
    assert bytes.fromhex(model['word_dictionary'][0])==canonical(t['spec']['target'])
    assert len(model['dependencies'])==t['reference_check']['dependency_points']
    assert sum(len(r['keys'])for r in model['dependencies'])==t['reference_check']['dependency_memberships']
    assert len(model['conflicts'])==t['reference_check']['internal_conflicts']
    assert len(model['domains'])==t['spec']['length']
    roots={tuple(r['point']):r['keys']for r in model['alignments']}
    certs=t['markings']['certificates'];assert len(certs)==12
    assert t['marking_certificate_check']['certificates']==t['marked_extension_check']['auxiliary_points']==12
    for i,c in enumerate(certs):
        assert c['id']==i and c['trial']==[c['auxiliary']['placement']]
        assert c['auxiliary']['point']==[-100,i] and c['auxiliary']['initial_value']==1 and c['auxiliary']['placement_value']==0
        assert c['trial'][0][0:2]==[0,0] and c['exhausted_root']==[0,1]
        assert [w['key']for w in c['all_candidates']]==roots[tuple(c['exhausted_root'])]
        assert all(w['witness']['kind']=='marking'for w in c['all_candidates'])
    assert len(s['training'])==3 and len(s['library'])==3 and s['library_frozen_before_tests']is True
    donors=[]
    for tr,rows in zip(s['training'],[3,5,5]):
        assert len(tr['search']['proof'])==len(tr['essential_proof'])==rows
        assert tr['reference_check']['complete']is tr['region']['complete']is True
        assert tr['host_check']['accepted']is tr['essential_host_check']['accepted']is True
        for field,proof in [('native_query',tr['search']['proof']),('essential_native_query',tr['essential_proof'])]:
            q=queries[tr[field]];assert q['result']['status']=='accepted'
            assert q['request']['proof']==proof and q['request']['theory']==tr['spec']['theory']
            assert q['request']['target']==tr['spec']['target'] and q['request']['blocks']==[]
            raw_donor_queries+=1
        donors.append(dict(id=tr['spec']['id'],rows=rows,whole_query=tr['native_query'],essential_query=tr['essential_native_query']))
    arms={r['id']:r for r in t['arms']};assert len(arms)==6
    assert [a['id']for a in t['arms']]==corpus['protocol']['arm_order'][case_id]
    arm_rows=[]
    for a in t['arms']:
        aid=a['id'];search=a['search']
        if aid in ['SC','P01','P11']:
            assert a['execution_status']=='SKIPPED_UNKNOWN_PREREQUISITE' and search is None
            assert a['native_query']is a['host_check']is a['region']is a['native_proof_accepted']is None
            assert all(a['timings'][k]is None for k in ['search_seconds','host_region_native_seconds','full_arm_seconds'])
            raw_skip+=1
            arm_rows.append(dict(id=aid,execution_status=a['execution_status'],search=None,reason=a['reason']))
            continue
        assert a['execution_status']=='SEARCH_RETURNED' and search['root_restored']is True
        raw_search+=1
        assert search['metrics']['attempts']==expected_attempts[number][aid]
        ec=collections.Counter(e['event']for e in search['trace'])
        row=dict(id=aid,execution_status=a['execution_status'],status=search['status'],metrics=search['metrics'],trace_events=dict(ec),search_seconds=search['seconds'],timings=a['timings'],domain_audits=search.get('domain_audits',[]),root_restored=search['root_restored'],proof_verification_status=a['proof_verification_status'])
        if aid.startswith('P'):
            assert search['status']=='unknown_search_budget' and search['proof']is None and search['placements']==[]
            assert len(search['domain_audits'])==2 and all(x['complete']is True for x in search['domain_audits'])
            assert ec['place']==search['metrics']['attempts'] and ec['decision']==search['metrics']['nodes']
            assert search['trace'][-1]==dict(event='cutoff',attempts=search['metrics']['attempts'])
            for index,event in enumerate(search['trace']):
                if event['event']=='decision':assert event['ordinal']==index
                elif event['event']=='order':
                    dec=search['trace'][event['decision']]
                    assert dec['event']=='decision' and sorted(event['alternatives'])==sorted(dec['original_alternatives'])
                elif event['event']=='place':assert event['key']in search['trace'][event['decision']+1]['alternatives']
            assert len(search['initial_auxiliary_removals'])==(12 if aid=='P10'else 0)
            assert search['metrics']['initial_auxiliary_removed_incidences']==len(search['initial_auxiliary_removals'])
            assert search['metrics']['auxiliary_removed_incidences']==0
            if aid=='P10':
                assert [w['candidate']for w in search['initial_auxiliary_removals']]==[c['auxiliary']['placement']for c in certs]
            row['initial_auxiliary_witnesses']=search['initial_auxiliary_removals']
            raw_point_attempt+=search['metrics']['attempts'];raw_audit+=2
        elif number==0:
            assert search['status']=='symbolic_proof_candidate' and a['native_proof_accepted']is True
            assert a['host_check']['accepted']is a['region']['complete']is True
            assert a['proof_verification_status']=='HOST_REGION_NATIVE_ACCEPTED'
            assert len(search['proof'])==14 and len(search['placements'])==28
            q=queries[a['native_query']]
            assert q['purpose']=='pilot_test_'+case_id+'_S0' and q['result']['status']=='accepted'
            assert q['request']['proof']==search['proof'] and q['request']['theory']==t['spec']['theory'] and q['request']['target']==t['spec']['target'] and q['request']['blocks']==[]
            for key in search['placements']:
                item=placements[tuple(key)];slot,k=item['command_reference']
                assert slot==key[0] and model['domains'][slot][k]==search['proof'][slot]
            row['raw_proof_observation']=dict(rows=14,selected_placements=28,Host=a['host_check'],region=a['region'],Native_query=a['native_query'],Native_status=q['result']['status'],rule_counts=dict(collections.Counter(x['rule']for x in search['proof'])),admitted_D8_proof=False)
        else:
            assert search['status']=='unknown_search_budget' and search['proof']is None
        arm_rows.append(row)
    p00=arms['P00']['search'];p10=arms['P10']['search']
    a0=p00['domain_audits'];a1=p10['domain_audits']
    assert a0[0]['frontier_points']==a1[0]['frontier_points']==2*t['spec']['length']
    assert a0[0]['incidences']-a1[0]['incidences']==12
    assert a0[0]['decision']==a1[0]['decision'] and a0[1]==a1[1]
    admitted=number==2
    assert observer['resource_candidate_accepted']is admitted
    assert tool['terminal_tool']['exit_code']==observer['parent_exit_code']==(0 if admitted else 2)
    assert terminal['process_exit_code']==(2 if number==0 else 0)
    if number==0:
        assert packet['status']==header['status']=='FAILED_CASE_NOT_ADMITTED' and terminal['header_valid']is False
        assert packet['error']['type']=='RootBudget' and 'combined peaks'in packet['error']['message']
        assert header['python_peak_after_output_bytes']+header['native_peak_bytes']>plan['limits']['memory_bytes']
        assert observer['conservative_whole_peak_bytes']is None and terminal['result']is None
    else:
        assert packet['status']==header['status']=='COMPLETE' and terminal['header_valid']is True
        assert terminal['result']==pp
        assert (observer['conservative_whole_peak_bytes']<plan['limits']['memory_bytes'])is admitted
    if admitted:
        admitted_search+=3;admitted_skip+=3;admitted_point_attempt+=p00['metrics']['attempts']+p10['metrics']['attempts'];admitted_audit+=4
    control=packet['independent_external_controls']
    assert control['supplied_to_proof_search']is False and control['machine_evaluated']is True
    assert all(control['base']['premise_truths']) and control['base']['goal_truth']is False
    allfiles=sorted(p for parent in [path,observer_path.parent]for p in parent.rglob('*')if p.is_file())
    assert not any('.partial'in p.name for p in allfiles)
    file_pins.extend(pin(p)for p in allfiles)
    case_rows.append(dict(case_id=case_id,resource_admitted=admitted,worker_status=packet['status'],packet=pp,header=pin(path/'worker-header.json'),terminal=pin(path/'terminal.json'),observer=pin(observer_path),tool_exit=tool['terminal_tool']['exit_code'],worker_exit=terminal['process_exit_code'],whole_peak_bytes=observer['conservative_whole_peak_bytes'],observer_gate_seconds=observer['final_observer_gate_seconds'],worker_error=packet['error'],plan=pin(plan_path),grant=pin(grant_path),consumed=pin(path/'CONSUMED.json'),native_query_count=len(queries),native_status_counts=dict(qs),query_stage_joins=len(queries),donors=donors,library_family_ids=[f['id']for f in s['library']],complete_six_outcome_record=s['job_record_complete'],all_six_searched=s['all_six_searched'],scientific_complete=s['scientific_complete'],reference_check=t['reference_check'],word_model_check=t['word_model_check'],word_reference_controls_returned=len(wr['controls']),word_reference_controls_qualified=admitted,marking_certificates=12,marking_scope='All12 are first-row command versus first-row guard exhaustion; shallow local plumbing, not new mathematical lemmas.',initial_audited_incidence_difference=12,second_audits_identical=True,full_shared_setup_seconds=t['full_shared_setup_seconds'],compile_and_model_seconds=t['compile_and_model_seconds'],word_evidence_seconds=t['word_model_seconds'],ground_admission_query=clusters['admission_query'],ground_admission_status=clusters['native_status'],binding_work=clusters['binding_work'],arms=arm_rows,proof_admitted=False))

assert raw_search==raw_skip==9 and raw_audit==12 and raw_point_attempt==89
assert admitted_search==admitted_skip==3 and admitted_audit==4 and admitted_point_attempt==14
assert raw_donor_queries==18 and dict(total_status)=={'accepted':75,'rejected':209,'unknown_step_budget':3}
assert len(file_pins)==42
checks=[
 ('exact-whole-inputs-and-complete-saved-bodies','All41 offered Source/input/runtime pins remain exact. All42 complete actual/observer files are raw-pinned; three unique consumed one-use grants join their exact plans and prior reviews. No partial file observed or parsed, no scientific execution or replay.'),
 ('resource-outcomes-control-admission','Both positive cases are explicitly rejected: first has a complete failure packet/worker2 and post-output Python+Native sum above1GiB; second worker0/COMPLETE is still rejected by parent/observer whole peak1153777664B. Only missing-Pa observer/tool0 and860045312B qualifies. No failed-job prefix, raw proof or controls are adopted as an admitted D8 result.'),
 ('whole-search-population-and-prerequisite','All three raw jobs returned six explicit arm records: nine searches and nine Native-UNKNOWN prerequisite skips. Each registry consumed1e9 microsteps and exposed no usable ground inventory. Only the admitted negative job contributes three searched/three skipped outcomes. No full six-arm comparison or cluster gain is established.'),
 ('actual-reduction-and-mechanism-controls','All48 exact L bank IDs returned PASSED in each saved packet, along with49 literal word-pair comparisons, full target reduction/wire/overlay receipts and unchanged Tiny mechanism controls. Only one full case resource-admits these observations; the other two remain diagnostic records. Passive audit does not repeat the mathematical reduction/checker.'),
 ('real-recipient-point-progress-and-trace','All six raw point calls completed both actual full-domain/inverse/scheduler audits and made placements:19/15,16/25,4/10 P00/P10 attempts. Saved decision/order/place/cutoff records reconcile counters, key membership and complete alternatives. Only the admitted negative contributes four audits and14 point attempts. All end UNKNOWN, no point proof or finite exhaustion.'),
 ('actual-marking-effect-with-correct-scope','Each P10 initial audit contains exactly12 fewer incidences than P00 at the same original frontier, with equal first branch decision and identical second audited state after the first guard. Full literal certificates and auxiliary witnesses join those12 original first-row command candidates. This supports real initial Graph pruning, rather than only a post-cutoff witness list; it does not establish improved time, hard-case reasoning, or statistically beneficial search.'),
 ('raw-positive-proof-is-not-admitted','First positive raw S0 has14 primitive rows/28 literal selected placements, exact saved domain-command/point/proof/query joins, Host/region/Native acceptance and4axiom+3instantiate+7MP. This conventional symbolic baseline observation resides in a whole failed job and is NOT an admitted D8 theorem/proof-search result. No host/native logical replay was performed.'),
 ('donor-and-Native-record-joins','All287 complete Native records join exact stored request SHA256, original theory/target/proof references and complete request-stage input/output hashes; terminal input/output bins join the last records. Eighteen raw donor whole/essential requests are accepted3/5/5, six of them in the admitted negative case. Three library families were cold acquired and frozen; no ground transfer was admitted.'),
 ('scientific-interpretation-and-next-obligation','The finite authored one-element missing-premise control returns true premises/false target and was not supplied to search; it is an independently evaluated explicit countermodel, not automatic model discovery. UNKNOWN search is not a disproof. Shared setup remains83–90s and only one complete resource fit; point carrier progress is engineering evidence, not practical general proof search, GCTS/cluster/RL advantage, physical Wang qualification, or completion of the program.'),
]
review=dict(schema='typed-word-point-actual-scientific-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_BOUNDED_PASSIVE_OUTCOME_AND_REPORTING_SCOPE_TWO_CASES_EXPLICITLY_REJECTED',passive_complete_saved_data_only=True,source_only=False,scientific_calls=0,logical_replays=0,actual_execution_authorized=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],qualified_case_ids=['pilot-fork-join-missing-Pa'],rejected_case_ids=case_order[:2],complete_pilot_comparison=False,GCTS_or_RL_advantage_established=False,new_recipient_proof_admitted=False,raw_totals=dict(searches=raw_search,skips=raw_skip,point_attempts=raw_point_attempt,point_domain_audits=raw_audit,Native_queries=287,Native_status_counts=dict(total_status),donor_whole_essential_acceptances=raw_donor_queries,word_control_returns=144),admitted_totals=dict(searches=admitted_search,skips=admitted_skip,point_attempts=admitted_point_attempt,point_domain_audits=admitted_audit,Native_queries=89,Native_status_counts=dict(accepted=22,rejected=66,unknown_step_budget=1),donor_whole_essential_acceptances=6,word_control_returns=48,recipient_proofs=0),cases=case_rows,actual_file_pins=file_pins,whole_offer=pin(D/'root/prospective-whole-offer-v1.json'),scientific_Source_review=pin(OUT/'typed-scientific-composition-Source-review-v1.json'),whole_Source_preflight=pin(OUT/'typed-whole-prospective-Source-review-v1.json'),external_tool_observer=pin(external_path),bank=pin(D/'verification-L/declarative-diagnostic-bank-v1.json'),control_ids=control_ids,first_failure_unavailable_positive_parent_whole_peak=None,partial_policy='No .partial files observed. No partial parsing/projection/admission; no failed-job rescue.',remaining='Report both resource negatives and the qualified negative-job mechanism progress. All cluster-dependent arms remain skipped; no admitted positive recipient or complete comparison. Full program goal remains active.',tools_stopped=True)
target=OUT/'typed-word-point-actual-scientific-review-v1.json'
resource_review=D/'verification-L/typed-word-point-resource-custody-review-v1.json'
assert pin(resource_review)['sha256']=='6da90efe70cffd863ee981dc4b60a4085a38207f9eaf8df2261540d77c3d200a'
assert load(resource_review)['review_passed']is True
review['independent_resource_custody_review']=pin(resource_review)
assert not target.exists()
target.write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(target),indent=2))
