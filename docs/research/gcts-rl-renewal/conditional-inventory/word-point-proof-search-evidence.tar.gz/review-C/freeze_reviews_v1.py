"""Reviewer metadata only: hash/read complete Sources, AST/unused compile, saved-JSON joins.

Never imports or executes offered research code. No scientific fixtures or partials.
"""
import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-word-point-proof-pilot-20261020'
OLD = BASE / 'research-runs/gcts-recipient-proof-pilot-20261020'
OUT = D / 'review-C'


def pin(path):
    path = Path(path)
    assert '.partial' not in path.name
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def load(path):
    path = Path(path)
    assert path.suffix == '.json' and '.partial' not in path.name
    return json.loads(path.read_bytes())


def verify(row):
    actual = pin(row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row
    return actual


def all_pins(value):
    if type(value) is dict:
        if {'path', 'bytes', 'sha256'} <= value.keys():
            yield value
        else:
            for child in value.values():
                yield from all_pins(child)
    elif type(value) is list:
        for child in value:
            yield from all_pins(child)


def save(path, value):
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    return pin(path)


def ast_source(path):
    raw = Path(path).read_bytes()
    tree = ast.parse(raw, filename=str(path))
    unused_code = compile(tree, str(path), 'exec')
    del unused_code
    return tree


def members(tree):
    return {node.name: ast.dump(node, include_attributes=False)
            for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


def check(name, finding):
    return dict(id=name, passed=True, finding=finding)


master = BASE / 'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md'
assert pin(master)['sha256'] == 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
bh = load(D / 'implementation-B/handoff-v1.json')
lh = load(D / 'verification-L/handoff-v1.json')
docs = [D/'implementation-B/handoff-v1.json', D/'implementation-B/manifest-v1.json',
        D/'implementation-B/API-v1.json', D/'implementation-B/manual-correspondence-v1.json',
        D/'implementation-B/diagnostic-construction-v1.json',
        D/'implementation-B/static-validation-v1.json',
        D/'verification-L/handoff-v1.json', D/'verification-L/freeze-manifest-v1.json',
        D/'verification-L/API-v1.json', D/'verification-L/manual-correspondence-v1.json',
        D/'verification-L/declarative-diagnostic-bank-v1.json',
        D/'verification-L/Source-AST-audit-v1.json']
verified = {}
for path in docs:
    for row in all_pins(load(path)):
        actual = verify(row)
        verified[actual['path']] = actual
    actual = pin(path)
    verified[actual['path']] = actual

entry = Path(bh['entry']['path'])
model = Path(bh['model_source']['path'])
verifier = Path(lh['source']['path'])
old_entry = OLD/'implementation-B/proof_search_pilot_v5.py'
assert pin(old_entry)['sha256'] == '964f6b630e002e41b4ab3c5982c3eb12ce70d847346ecee451fe62db1b4f9fcb'
new_ast = ast_source(entry)
old_ast = ast_source(old_entry)
new_members = members(new_ast)
old_members = members(old_ast)
changed = sorted(k for k in new_members.keys() | old_members.keys()
                 if new_members.get(k) != old_members.get(k))
assert changed == ['indexed_model', 'run_pilot', 'verify_indexed_model']
patch = ''.join(difflib.unified_diff(old_entry.read_text().splitlines(True),
                                   entry.read_text().splitlines(True),
                                   fromfile=str(old_entry.relative_to(BASE)),
                                   tofile=str(entry.relative_to(BASE))))
assert patch == (D/'implementation-B/D7-v5-to-D8-v6.patch').read_text()
new_defs = {n.name for n in ast.walk(ast_source(verifier)) if isinstance(n, ast.FunctionDef)}
assert {'verify_word_reference', 'verify_marked_extension', 'run_word_reference_diagnostics'} <= new_defs
ast_source(model)
bank = load(D/'verification-L/declarative-diagnostic-bank-v1.json')
assert bank['control_count'] == len(bank['controls']) == 48
assert len({r['id'] for r in bank['controls']}) == 48
assert all(r['status'] == 'UNRUN' for r in bank['controls'])
assert bank['tiny_explicit_byte_pair_count'] == 49

inherited = [OLD/'review-C/typed-scientific-delta-Source-review-v1.json',
             OLD/'review-C/typed-whole-prospective-Source-review-v1.json',
             OLD/'review-C/typed-recipient-actual-scientific-review-v1.json']
for path in inherited:
    assert load(path)['review_passed'] is True
negative = OUT/'draft-overlay-composition-negative-v1.json'
assert pin(negative)['sha256'] == 'fdb13fb60b61dd0fc4c017ab906c86859b12a7004533cf127c25b73b10651027'

scientific_checks = [
 check('exact-frozen-composition-and-Source-only-method',
       'All B/L Source/API/manual/bank/handoff/manifest pins reconcile. Three new Sources parsed and unused-compiled only; complete Source/manual inspection completed. No scientific import/call, constructor, fixture, simulator, sizer, probe or partial parsing. This review independently adjudicates the L-authored verifier.'),
 check('complete-word-equality-reduction',
       'At one aligned origin, equal complete payloads plus256 agree; unequal payloads differ at a byte or the shorter terminator256 conflicts with a longer byte0..255. Thus complete aligned word compatibility is exact payload equality. The frozen injective literal dictionary preserves this relation; a hash is not authority. Scope is checked boundary plus complete placement reachable states only.'),
 check('dictionary-construction-full-words-and-ID-zero',
       'Target is interned first as exact integer ID0. L independently serializes canonical full JSON payloads, checks exact first-use dictionary order and payload equality, and includes words in internally conflicted attempted guards. Every command, own formula and ordered source requirement is reconstructed. Explicit256, strict integer IDs, valid ranges, assigned0 and missing remain distinct.'),
 check('namespaces-and-unmodified-scalar-semantics',
       'Formula ports(4slot,100), command ports(4slot+1,100), scalar mode(4slot+2,90), two original t roots, and fresh auxiliary negative-x points are disjoint. Numeric equality between a scalar and a word ID has no cross-point effect. L checks complete support, initial targetID0, strict scalar0, t values, exact point types and all initial state fields.'),
 check('complete-primitive-universe-and-internal-conflicts',
       'B preserves original quantified zero-arity domain construction, ordered primitive commands/keys/guard variants, rule licensing, metadata and failed internal-merge attempts. L independently derives all domains and attempts from the authoritative catalog/spec, and joins every accepted placement, conflict, metadata row and alignment. No block candidate, new axiom, reduced proof grammar or predicate filter is introduced.'),
 check('dependency-affected-union-and-rollback',
       'Every original complete word touches its origin. A candidate sharing any byte of that aligned word necessarily shares the origin, so the union of original affected candidates over the changed whole word equals the reduced-port dependency set. L validates complete forward and reverse memberships, not a sample. Unchanged t/scalar/aux supports extend by set union; unchanged Graph/State then preserve legal domains, generation choice and exact rollback along corresponding key sequences. No arbitrary partial-byte-state relation is claimed.'),
 check('independent-verifier-scope-and-foreign-faults',
       'L does not use B domain/assignment/merge helpers or an old Model constructor to establish correspondence. Its own canonical serializer, domain/attempt/occurrence reconstruction, full dictionary and typed pair joins cover the concrete new model. Genuine check callbacks precede privately owned mismatch classification; foreign exceptions retain exact identity and are never converted into expected refusals by public type alone.'),
 check('overlay-correction-and-full-extension-gates',
       'Preserved early raw draft negative remains inspectable. Final L accepts the actual B frozenset auxiliary memberships and compares coordinate-sorted full merged marks, including repeated distinct auxiliary points on one key. It audits every base lookup, new lookup and missing/default case as well as literal tile/initial-state storage. The generic Tiny overlay check is expressly separate from the complete-word reduction and from proof of marking redundancy.'),
 check('marking-certificates-remain-real-point-eliminations',
       'Unchanged compile_markings/verify_markings certify a placement dead extension using all original mandatory-root candidate incompatibility witnesses. New auxiliary marks live in the actual Model and Graph; no run-time predicate scanner is substituted. These checks and L exact overlay gates must actually return in each future job. Certificate proposal and its separate support recheck share helpers, so this review does not label them an independent logical replay.'),
 check('full-literal-evidence-and-decode',
       'The new JSON carrier retains the whole dictionary as literal payload hex plus explicit terminator, every placement t/m/vertices/key/metadata/command reference, domains, alignments, complete dependencies, conflicts, initial boundary, declarations and timing. B strict literal wire joins reconcile every field against actual owners; L supplies a separate old-construction reduction check. No omitted word is replaced by a hash or ID with unavailable payload.'),
 check('exact-entry-delta-and-proof-acceptance',
       'Exact D7-to-D8 patch reproduced. Only indexed_model,verify_indexed_model and run_pilot top-level function/class ASTs change; imports/VERSION/MarkedModel binding change as declared. Budget, both searches, whole-region and marking verifiers, diagnostics and ground-cluster logic remain exact D7 ASTs. Case Host/full finite region/final primitive Native gates, and explicit UNKNOWN cluster-only skips, remain unchanged.'),
 check('complete-48-control-bank-adjudicated-unrun',
       'All48 literal control IDs and recipes align with Source: whole constructor positive; strict IDs/0/missing/coordinates/t; dictionary duplicates/order/payload/256; target boundary; cache/domain/metadata/alignment; missing/spurious complete incidence; conflicted guard;49 explicit byteword pairs and zero-terminator counterexample; nonvacuous proper-subset affected union; generic overlay/repeated key/lookup mutations; four exact foreign exception identities. They are prospective UNRUN controls, not observed PASS results. A single partial-byte mutation control does not broaden the stated aligned-state theorem.'),
 check('costs-fairness-and-open-scientific-claims',
       'Same public authored corpus,3/5/5 cold donors,14/13/14 recipients, six relative schedules and every quota are retained. Cooperative2s clock still begins before Graph/snapshots/audits; no hard2s guarantee or cost equality follows from Source. Shared construction/reduction verification is charged in complete setup, and per-arm/full timings remain necessary. Fit, recipient point progress, benefit from m/cluster inventory, trained RL, physical Wang equivalence and statistical superiority remain unmeasured.'),
]

science = dict(
 schema='typed-word-point-scientific-composition-Source-review-v1',
 reviewer_identity='/root/recovered_batch_review', review_passed=True,
 status='PASS_CONDITIONAL_SOURCE_REDUCTION_COMPOSITION_ONLY_NO_ACTUAL_ADMISSION',
 source_only=True, component_calls=0, scientific_calls=0,
 actual_execution_authorized=False, actual_resource_accepted=False,
 created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 check_count=len(scientific_checks), failed_checks=0, checks=scientific_checks,
 master=pin(master), new_sources=[pin(model),pin(verifier),pin(entry)],
 artifacts=list(verified.values()), predecessor_entry=pin(old_entry),
 changed_top_level_members=changed,
 unchanged_top_level_members=sorted(set(old_members)-set(changed)),
 exact_entry_patch=pin(D/'implementation-B/D7-v5-to-D8-v6.patch'),
 independent_L_authorship_adjudication=True, controls_executed=0,
 prospective_controls=bank['controls'], tiny_literal_byte_pairs=49,
 manual_mathematical_argument='Conditional Source/manual reasoning, not a mechanized theorem or a runtime conformance result.',
 preserved_negative=pin(negative),
 preserved_early_note=pin(OUT/'early-mathematical-obligations-v1.json'),
 inherited_unchanged_judgments=[pin(p) for p in inherited],
 partial_policy='No partial content opened or parsed. Only complete Sources and saved metadata were read.',
 tools_stopped_after_final_receipts=True)
science_pin = save(OUT/'typed-scientific-composition-Source-review-v1.json',science)

offer_path = D/'root/prospective-whole-offer-v1.json'
offer = load(offer_path)
assert len(offer['files']) == 41
assert len({r['path'] for r in offer['files']}) == 41
for row in offer['files']:
    verify(row)
ast_rows = offer['source_AST_checks']
assert len(ast_rows) == 33 and len({r['path'] for r in ast_rows}) == 33
assert {r['path'] for r in ast_rows} == {r['path'] for r in offer['files'] if r['path'].endswith('.py')}
for row in ast_rows:
    assert row['AST_and_unused_compile'] is True
    ast_source(row['path'])
assert offer['new_actuals'] == offer['new_grants'] == offer['old_grants_remaining'] == 0
assert offer['expected_case_jobs'] == 3 and offer['expected_explicit_arm_outcomes'] == 18
protocol = load(offer['protocol']['path'])
verify(offer['protocol'])
assert protocol['new_actuals'] == protocol['new_grants'] == protocol['old_grants_remaining'] == 0
expected_roles = load(D/'implementation-B/API-v1.json')['roles']
corpus = load(protocol['input']['path'])
verify(protocol['input'])
plans=[]
for row in offer['plans']:
    verify(row)
    plan=load(row['path'])
    assert plan['files'] == offer['files']
    assert plan['limits'] == protocol['limits']
    assert plan['experiment_limits'] == protocol['scientific_limits']
    assert plan['modules'] == expected_roles
    assert plan['protocol'] == offer['protocol']
    assert plan['python'] == offer['python']
    assert plan['entry_path'] == str(entry)
    assert plan['runtime_dir'] == str(D/'runtime')
    assert plan['input_path'] == protocol['input']['path']
    for field,name in [('worker_path','case_worker_v1.py'),('control_path','independent_countermodel_v1.py'),('runner_path','run_case_once_v3.py'),('observer_path','observe_case_once_v2.py')]:
        assert plan[field] == str(D/'root'/name)
        assert (D/'root'/name).read_bytes() == (OLD/'root'/name).read_bytes()
    assert plan['actual_dir'] == str(D/'actual'/plan['case_id'])
    assert not Path(plan['actual_dir']).exists()
    assert not Path(plan['actual_dir']+'-observer').exists()
    assert plan['native'] == load(OLD/'root'/('plan-'+plan['case_id']+'-v1.json'))['native']
    plans.append(plan)
assert {p['case_id'] for p in plans} == {'pilot-fork-join-positive','pilot-quantifier-equality-positive','pilot-fork-join-missing-Pa'}
assert len({p['actual_dir'] for p in plans}) == 3
for path in (OLD/'runtime').glob('*.py'):
    assert (D/'runtime'/path.name).read_bytes() == path.read_bytes()
assert len(list((OLD/'runtime').glob('*.py'))) == 26
assert len(list((D/'runtime').glob('*.py'))) == 28
assert (D/'runtime'/model.name).read_bytes() == model.read_bytes()
assert (D/'runtime'/verifier.name).read_bytes() == verifier.read_bytes()
old_plan=load(OLD/'root/plan-pilot-fork-join-positive-v1.json')
assert protocol['limits'] == old_plan['limits']
assert protocol['scientific_limits'] == old_plan['experiment_limits']
lreview_path=D/'verification-L/typed-word-point-whole-plan-resource-ABI-Source-review-v1.json'
lreview=load(lreview_path)
assert pin(lreview_path)['sha256'] == 'd31e2876d444ab3dd091031cb3542c67ab5566ce9bf959a7c4cc019af53c167f'
assert lreview['review_passed'] is True and lreview['scientific_self_admission'] is False
assert lreview['failed_checks'] == 0
assert lreview['whole_offer'] == pin(offer_path)
assert lreview['plans'] == offer['plans']
assert not list((D/'root').glob('grant-*.json'))
whole_checks=[
 check('exact-whole-closure', 'All41 raw file pins independently revalidated;33 offered Sources AST-parsed and unused-compiled without research imports or execution. Exact runtime Model/verifier bytes equal the separately reviewed B/L Sources.'),
 check('same-baseline-dependencies-and-outer', 'All26 old runtime Sources and all four custodian Sources match D7 byte for byte. Existing D7 scientific and L custodian judgments are reused within their original fixed-dependency nonhostile scope. No new general security/custody claim is inferred.'),
 check('independent-composition-barrier-complete', 'C exact conditional Source/reduction composition PASS is linked separately and independently adjudicates the L-authored Source. L plan/resource/ABI PASS does not self-admit its verifier. Both scopes apply to this exact offer.'),
 check('three-whole-case-plans', 'Three distinct absent actual paths bind the same complete corpus/file closure/runtime/Native assets, exact entry and six injected module roles. Target and donor semantics remain full14/13/14 and cold3/5/5. Each plan contains all six explicit relative outcomes;18 outcomes across jobs are required for a full comparison.'),
 check('unchanged-quotas-clocks-and-proof-gates', 'All outer/scientific numeric limits match D7, including cooperative2s before Graph construction/audits,600 attempts and two full domain audits. UNKNOWN cluster admission skips only dependent arms, while rejected/foreign faults remain faults. Host, complete region and final primitive Native checks remain mandatory for a proof claim.'),
 check('scoped-outer-admission-reuse', 'L exact whole-plan receipt joins this offer/plans and unchanged custodians. Future actual admission still requires complete result/header/terminal/observer/tool-exit joins, stable post-exit census, all time/memory/physical/log/Root-work gates, exact one-use grant consumption and idle barrier.225s observer fallback is distinct from180/210 gates; no OS-real-time/adversarial guarantee.'),
 check('no-present-authority-or-positive-fit', 'Offer and protocol declare zero actuals/new grants/remaining old grants; three actual paths are absent. This receipt issues no grant and starts no scientific work. Runtime fit, controls and outcomes are unmeasured; old G0/G1/cohort failures and previous attempts remain unchanged.'),
]
whole=dict(schema='typed-word-point-whole-prospective-Source-review-v1',
 reviewer_identity='/root/recovered_batch_review',review_passed=True,
 status='PASS_EXACT_NEW_EXPERIMENT_PREFLIGHT_FRESH_ROOT_ONCE_AUTHORITY_STILL_REQUIRED',
 source_only=True,component_calls=0,scientific_calls=0,
 actual_execution_authorized=False,actual_resource_accepted=False,
 check_count=len(whole_checks),failed_checks=0,checks=whole_checks,
 whole_offer=pin(offer_path),protocol=offer['protocol'],plans=offer['plans'],
 scientific_composition_review=science_pin,L_plan_resource_ABI_review=pin(lreview_path),
 master=pin(master),file_pins=offer['files'],AST_unused_compile_count=33,
 unchanged_runtime_Source_count=26,new_runtime_Source_count=2,
 unchanged_custodian_Source_count=4,
 old_case_plan=pin(OLD/'root/plan-pilot-fork-join-positive-v1.json'),
 preserved_negative=pin(negative),all_control_cases_unrun=True,
 new_grants=0,new_actuals=0,old_grants_remaining=0,
 tools_stopped=True,remaining='Root fresh exact one-use per-case grants and final idle barrier; Root alone may run three serial actuals. Every outcome and refusal remains subject to complete passive evidence review. No fit or proof-search advantage follows from this Source review.')
whole_pin=save(OUT/'typed-whole-prospective-Source-review-v1.json',whole)
print(json.dumps(dict(scientific_review=science_pin,whole_review=whole_pin,tools_stopped=True),indent=2))
