"""Independent whole-word reduction audit for the fixed primitive pilot.

Original domains and attempted placements are derived here, not read from the
word builder.  No old Model, per-candidate byte expansion, or reverse byte map
is constructed.  The reduction is limited to complete aligned canonical words
plus disjoint scalar points in states reachable from the checked boundary.
No diagnostic or audit runs at import. Source only until a fresh Root actual.
"""
import json
from collections.abc import Set

VERSION = 'aligned-complete-word-reference-verifier-v1'
CATALOG_SCHEMA = 'quantified-initial-binder-syntax-catalog-v1'
COMPILER_VERSION = 'quantified-initial-binder-receptors-v1'
TERM_POLICY = 'TARGET_FREE_SUBTERMS_UNION_ALL_INITIAL_BINDER_VARIABLES_V1'
ROOT_CONTEXT = 'CLOSED_THEORY_AXIOMS_NO_OPEN_ROOT_ASSUMPTIONS'
_OWNER = object()
_MISSING = object()

class ReferenceMismatch(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def _require(ok, message, check):
    check()
    if not ok:
        raise ReferenceMismatch(message, _OWNER)


def _same(a, b):
    stack = [(a, b)]
    while stack:
        left, right = stack.pop()
        if type(left) is not type(right):
            return False
        if type(right) in (list, tuple):
            if len(left) != len(right):
                return False
            stack.extend(zip(left, right))
        elif type(right) is dict:
            if set(left) != set(right):
                return False
            stack.extend((left[k], right[k]) for k in right)
        elif left != right:
            return False
    return True


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def _key(value):
    return type(value) is tuple and len(value) == 4 and all(type(v) is int for v in value)


def _point(value):
    return type(value) is tuple and len(value) == 2 and all(type(v) is int for v in value)


class _Words:
    """Exact target-first dictionary derivation; compare each distinct word once."""
    def __init__(self, model, check):
        self.check = check
        _require(type(model.word_dictionary) is tuple,
                 'immutable complete word dictionary', check)
        _require(type(model.word_terminator) is int and model.word_terminator == 256,
                 'nonbyte terminator exactly256', check)
        self.actual = model.word_dictionary
        seen = set()
        for payload in self.actual:
            check()
            _require(type(payload) is bytes and payload not in seen,
                     'exact unique payload bytes', check)
            seen.add(payload)
        self.ids = {}
        self.cache = {}
        self.compared = 0

    def payload(self, value):
        self.check()
        identity = id(value)
        prior = self.cache.get(identity)
        if prior is not None:
            _require(prior[0] is value, 'retained literal cache owner', self.check)
            return prior[1]
        raw = _json(value)
        # Retain owners: an id cannot be recycled into a different literal.
        self.cache[identity] = (value, raw)
        return raw

    def intern(self, value):
        raw = self.payload(value)
        prior = self.ids.get(raw, _MISSING)
        if prior is not _MISSING:
            return prior
        index = len(self.ids)
        _require(index < len(self.actual) and self.actual[index] == raw,
                 'exact target-first canonical whole-word dictionary', self.check)
        self.ids[raw] = index
        self.compared += 1
        return index

    def finish(self):
        _require(len(self.ids) == len(self.actual),
                 'no unused, missing or reordered dictionary word', self.check)


def _domain(spec, compiled, slot, words):
    catalog = compiled['catalog']
    formulas = [spec['target']] if slot + 1 == spec['length'] else catalog['basis']
    rows = []
    for formula in formulas:
        for name in sorted(spec['theory']['axioms']):
            rows.append(dict(rule='axiom', formula=formula, name=name))
        for variable in catalog['variables']:
            for source in range(slot):
                rows.append(dict(rule='generalize', formula=formula,
                                 variable=variable, source=source))
        for antecedent in range(slot):
            for implication in range(slot):
                rows.append(dict(rule='mp', formula=formula,
                                 antecedent=antecedent, implication=implication))
        for rule in ('refl', 'tautology'):
            rows.append(dict(rule=rule, formula=formula))
    for scheme in catalog['schemes']:
        if slot + 1 < spec['length'] or _same(scheme['formula'], spec['target']):
            rows.append(scheme)
    rows.sort(key=lambda command: (command['rule'], words.payload(command['formula']),
                                   words.payload(command)))
    return rows


def _attempts(spec, compiled, slot, choice, command, tautologies, schemes):
    # One command and its bounded guard variants, never the complete model.
    formula = command['formula']; rule = command['rule']
    result = [((slot, 0, choice, 0), [], 'command')]
    if rule == 'mp':
        for variant, implication in enumerate(compiled['basis']):
            if implication[0] == 'imp' and _same(implication[2], formula):
                requirements = [(command['antecedent'], implication[1]),
                                (command['implication'], implication)]
                result.append(((slot, 1, choice, variant), requirements, 'guard'))
        return result
    requirements = []
    if rule == 'axiom':
        valid = _same(spec['theory']['axioms'][command['name']], formula)
    elif rule == 'refl':
        valid = formula[0] == 'eq' and _same(formula[1], formula[2])
    elif rule == 'tautology':
        valid = _json(formula) in tautologies
    elif rule == 'generalize':
        valid = formula[0] == 'all' and formula[1] == command['variable']
        if valid:
            requirements = [(command['source'], formula[2])]
    else:
        valid = _json(command) in schemes
    if valid:
        result.append(((slot, 1, choice, 0), requirements, 'guard'))
    return result


def _occurrences(slot, command, requirements, words):
    # First-use order is original command, own formula, then each receptor.
    entries = [((4 * slot + 1, 100), words.intern(command)),
               ((4 * slot, 100), words.intern(command['formula'])),
               ((4 * slot + 2, 90), 0)]
    for source, formula in requirements:
        entries.append(((4 * source, 100), words.intern(formula)))
    merged = {}
    for point, value in entries:
        if point in merged and merged[point] != value:
            return None
        merged[point] = value
    return tuple(sorted(merged.items()))


def _word_port(point, rows):
    return (_point(point) and point[1] == 100 and 0 <= point[0] < 4 * rows
            and point[0] % 4 in (0, 1))


def _pairs(actual, expected, check, words=None, rows=None):
    check(); iterator = iter(actual)
    for wanted in expected:
        check(); pair = next(iterator, _MISSING)
        _require(pair is not _MISSING and type(pair) is tuple and len(pair) == 2
                 and _point(pair[0]) and type(pair[1]) is int and pair == wanted,
                 'exact complete ordered port/scalar assignment', check)
        if words is not None and _word_port(pair[0], rows):
            _require(0 <= pair[1] < len(words.actual),
                     'strict assigned dictionary ID including zero', check)
    _require(next(iterator, _MISSING) is _MISSING,
             'no partial, shifted or extra point assignment', check)


def _support_points(compiled, domains, key):
    slot, role, choice, variant = key
    command = domains[slot][choice]
    points = {(4 * slot, role), (4 * slot + 1, 100),
              (4 * slot, 100), (4 * slot + 2, 90)}
    if role == 1 and command['rule'] == 'mp':
        points.add((4 * command['antecedent'], 100))
        points.add((4 * command['implication'], 100))
    elif role == 1 and command['rule'] == 'generalize':
        points.add((4 * command['source'], 100))
    return points


def _lookup(dependencies, point, expected, check):
    check()
    actual = dependencies.get(point, _MISSING)
    if not expected:
        _require(actual is _MISSING, 'missing dependency point retains exact default', check)
        return
    _require(actual is not _MISSING and isinstance(actual, Set) and len(actual) == len(expected),
             'dependency lookup exact cardinality', check)
    seen = set()
    for ordinal, key in enumerate(actual):
        if ordinal % 256 == 0:
            check()
        if not (_key(key) and key in expected and key not in seen):
            _require(False, 'dependency lookup no spurious/duplicate edge', check)
        seen.add(key)
    _require(seen == expected, 'dependency lookup every expected edge', check)
    # A fresh traversal must not consume an iterator retained by a previous call.
    _require(set(actual) == expected and set(dependencies.get(point, ())) == expected,
             'repeatable dependency set and lookup', check)


def verify_word_reference(spec, compiled, inventory, model, *, check):
    check()
    _require(type(spec['length']) is int and spec['length'] > 0,
             'positive exact row count', check)
    catalog = compiled['catalog']
    _require(compiled['status'] == 'complete' and catalog['schema'] == CATALOG_SCHEMA
             and catalog['producer_version'] == COMPILER_VERSION
             and catalog['term_policy'] == TERM_POLICY
             and catalog['root_context'] == ROOT_CONTEXT and type(catalog['rounds']) is int
             and catalog['rounds'] == 2, 'unchanged admitted compiler profile', check)
    _require(_same(compiled['basis'], catalog['basis'])
             and _same(compiled['variables'], catalog['variables']), 'catalog input joins', check)
    empty_inventory = dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[])
    _require(_same(inventory, empty_inventory) and _same(model.spec, spec)
             and _same(model.compiled, compiled) and _same(model.inventory, inventory),
             'caller-authoritative exact primitive inputs', check)
    _require(type(model.arity) is int and model.arity == 0 and model.interfaces == []
             and model.mode == {} and model.mode_names == {} and model.families_enabled is False
             and type(model.required_interface_arity) is int and model.required_interface_arity == 0
             and model.arity_policy == 'EXPLICIT_COVERS_ALL_ADMITTED_INTERFACES',
             'explicit zero-arity family-disabled adapter', check)
    roots = {(4 * slot, role): 0 for slot in range(spec['length']) for role in (0, 1)}
    _require(type(model.align_cache) is dict and all(_point(p) for p in model.align_cache)
             and set(model.align_cache) == set(roots), 'complete original C/G roots', check)
    _require(type(model.domains) is list and len(model.domains) == spec['length']
             and type(model.cache) is dict and type(model.metadata) is dict
             and type(model.conflicts) is list, 'exact finite candidate carriers', check)
    words = _Words(model, check)
    target_id = words.intern(spec['target'])
    _require(target_id == 0, 'target word is assigned IDzero', check)
    tautologies = {words.payload(f) for f in compiled['tautologies']}
    schemes = {words.payload(c) for c in compiled['admitted_schemes']}
    cache_keys = iter(model.cache); metadata_keys = iter(model.metadata)
    conflict_index = attempted = accepted = occurrences = 0
    dependency_points = set(); memberships = 0
    _require(type(model.dependencies) is dict, 'ordinary complete port dependency mapping', check)
    for slot in range(spec['length']):
        check(); rows = _domain(spec, compiled, slot, words)
        _require(_same(model.domains[slot], rows), 'whole original ordered domain', check)
        alignment_position = [0, 0]; previous_command = None
        for choice, command in enumerate(rows):
            check(); current = words.payload(command)
            _require(current != previous_command, 'unique original commands', check)
            previous_command = current
            for key, requirements, kind in _attempts(spec, compiled, slot, choice, command,
                                                      tautologies, schemes):
                check(); attempted += 1
                merged = _occurrences(slot, command, requirements, words)
                if merged is None:
                    wanted = dict(key=key, reason='internally unequal markings')
                    _require(conflict_index < len(model.conflicts)
                             and _same(model.conflicts[conflict_index], wanted),
                             'complete original internal-conflict sequence', check)
                    conflict_index += 1
                    continue
                actual_key = next(cache_keys, _MISSING); metadata_key = next(metadata_keys, _MISSING)
                _require(_key(actual_key) and _key(metadata_key)
                         and actual_key == metadata_key == key,
                         'all original ordered accepted keys', check)
                tile = model.placement(key)
                _require(tile is model.cache[key] and _key(tile.key) and tile.key == key,
                         'actual placement cache owner', check)
                _pairs(tile.occupancy, (((4 * slot, key[1]), 12),), check)
                _pairs(tile.marks, merged, check, words, spec['length'])
                _require(type(tile.vertices) is tuple and tile.vertices == (),
                         'unchanged empty decorative vertices', check)
                wanted = dict(slot=slot, kind=kind, command=command, requirements=requirements)
                _require(_same(model.metadata[key], wanted), 'all original metadata', check)
                root = (4 * slot, key[1]); alignment = model.alignments(root)
                index = alignment_position[key[1]]
                _require(type(alignment) is tuple and index < len(alignment)
                         and _key(alignment[index]) and alignment[index] == key
                         and alignment is model.align_cache[root],
                         'complete ordered root alignments', check)
                alignment_position[key[1]] += 1; accepted += 1; occurrences += len(merged)
                expected_points = _support_points(compiled, model.domains, key)
                for point in expected_points:
                    check(); keys = model.dependencies.get(point, _MISSING)
                    _require(type(keys) is frozenset and key in keys,
                             'every expected port dependency membership', check)
                    dependency_points.add(point); memberships += 1
        for role in (0, 1):
            _require(len(model.alignments((4 * slot, role))) == alignment_position[role],
                     'no extra alignment', check)
    _require(next(cache_keys, _MISSING) is _MISSING and next(metadata_keys, _MISSING) is _MISSING
             and conflict_index == len(model.conflicts), 'no extra key/metadata/conflict', check)
    words.finish()
    _require(all(_point(p) for p in model.dependencies)
             and set(model.dependencies) == dependency_points,
             'no spurious or missing dependency point', check)
    observed_memberships = 0
    for point, keys in model.dependencies.items():
        check()
        _require(type(keys) is frozenset and len(keys) > 0,
                 'nonempty immutable exact dependency sets', check)
        for key in keys:
            check()
            _require(_key(key) and key in model.cache
                     and point in _support_points(compiled, model.domains, key),
                     'no spurious dependency edge', check)
            observed_memberships += 1
        _require(model.dependencies.get(point, _MISSING) is keys,
                 'repeatable ordinary dependency lookup owner', check)
    _require(observed_memberships == memberships,
             'complete bidirectional port dependency population', check)
    state = model.initial()
    _require(type(state.marks) is dict and all(_point(p) and type(v) is int for p, v in state.marks.items())
             and _same(state.marks, {(4 * (spec['length'] - 1), 100): target_id})
             and _same(state.totals, {}) and _same(state.roots, roots)
             and _same(state.generations, roots)
             and all(_point(p) and type(v) is int for p, v in state.roots.items())
             and all(_point(p) and type(v) is int for p, v in state.generations.items())
             and type(state.allowed_points) is frozenset and state.allowed_points == frozenset(roots)
             and all(_point(p) for p in state.allowed_points)
             and type(state.selected) is set and state.selected == set()
             and _same(state.order, []) and _same(state.tile_generations, []),
             'exact target-IDzero boundary and original initial state', check)
    check()
    return dict(schema='aligned-complete-word-reference-v1', complete=True,
                attempted_placements=attempted, accepted_placements=accepted,
                internal_conflicts=conflict_index, distinct_complete_words=words.compared,
                port_scalar_occurrences=occurrences, dependency_points=len(dependency_points),
                dependency_memberships=memberships, pointwise_identity=False,
                reduction_scope='Only states reached from the checked boundary by the complete checked placements: aligned complete canonical JSON words with nonbyte terminator256; scalar namespaces disjoint. Equal IDs iff equal full terminated words; unequal words conflict at first differing byte or shorter terminator. Partial/shifted words and arbitrary byte states are excluded.',
                affected_scope='Each whole-word port update represents all bytes of a complete aligned occurrence. Every occurrence contains its common origin, so union of all original byte dependencies equals the checked port dependency set. Scalar/t-support dependencies are unchanged; finite unions preserve all affected candidate sets.',
                storage_scope='Full canonical payload compared once per distinct dictionary word, small independently derived occurrence records per candidate, bidirectional port incidence without a reverse byte map. No old Model or Host/Native acceptance invoked.')


def verify_marked_extension(base, marked, packet, *, check):
    """Independent storage join; existing certificate checker owns soundness."""
    check(); extra = {}; by_key = {}; initial_marks = {}
    for certificate in packet['certificates']:
        check(); auxiliary = certificate['auxiliary']; key = auxiliary['placement']; point = auxiliary['point']
        _require(_key(key) and key in base.cache and _point(point) and point[0] == -100
                 and point not in extra and base.dependencies.get(point, _MISSING) is _MISSING
                 and point not in base.initial().marks,
                 'exact fresh auxiliary point and original candidate', check)
        _require(type(auxiliary['placement_value']) is int and type(auxiliary['initial_value']) is int,
                 'exact assigned auxiliary values', check)
        extra[point] = {key}; initial_marks[point] = auxiliary['initial_value']
        by_key.setdefault(key, []).insert(0, (point, auxiliary['placement_value']))
    _require(tuple(marked.cache) == tuple(base.cache)
             and marked.dependencies.base is base.dependencies
             and all(_point(p) and type(keys) is set and all(_key(k) for k in keys)
                     for p, keys in marked.dependencies.extra.items())
             and _same(marked.dependencies.extra, extra)
             and _same(marked.initial_auxiliary, initial_marks),
             'same complete base universe and exact auxiliary dependency map', check)
    for name in ('align_cache', 'metadata', 'domains', 'spec', 'compiled', 'inventory'):
        _require(getattr(marked, name) is getattr(base, name), 'preserved base owner: ' + name, check)
    for key in base.cache:
        check(); original = base.placement(key); tile = marked.placement(key)
        if key not in by_key:
            _require(tile is original, 'unchanged overlay placement owner', check)
            continue
        _require(_key(tile.key) and tile.key == key and tile.vertices == original.vertices,
                 'same overlay key and vertices', check)
        _pairs(tile.occupancy, tuple(original.occupancy), check)
        _pairs(tile.marks, tuple(by_key[key]) + tuple(original.marks), check)
    expected = base.initial(); expected.marks.update(initial_marks); actual = marked.initial()
    for name in ('totals', 'marks', 'generations', 'roots', 'selected', 'order', 'tile_generations', 'allowed_points'):
        _require(_same(getattr(actual, name), getattr(expected, name)),
                 'exact overlay initial state: ' + name, check)
    for point, keys in extra.items():
        _lookup(marked.dependencies, point, keys, check)
    check()
    return dict(schema='word-or-generic-marked-extension-reference-v1', complete=True,
                changed_placements=len(by_key), auxiliary_points=len(extra),
                scope='Generic exact point-value auxiliary storage extension; also supports ordinary Tiny controls without a word dictionary. Full word reduction is separately owned by verify_word_reference. Proved redundancy is owned by unchanged marking-certificate verification.')


class _ModelView:
    def __init__(self, base, **changes):
        self.base = base
        self.__dict__.update(changes)
    def __getattr__(self, name):
        return getattr(self.base, name)
    def placement(self, key):
        return self.cache[key]
    def alignments(self, point):
        return self.align_cache[point]


    def initial(self):
        return self.base.initial()


class _InitialView(_ModelView):
    def __init__(self, base, changed_marks):
        super().__init__(base)
        self.changed_marks = changed_marks
    def initial(self):
        state = self.base.initial(); state.marks = dict(self.changed_marks)
        return state


def _tiny_inputs():
    p = ['pred', 'P', []]; q = ['pred', 'Q', []]; implication = ['imp', p, q]
    spec = dict(id='synthetic-word-reduction-only', title='Synthetic aligned word control',
                theory=dict(functions={}, predicates={'P': 0, 'Q': 0},
                            axioms={'p': p, 'pq': implication}, schemas=[]),
                target=q, length=3, instantiation_rounds=2)
    catalog = dict(schema=CATALOG_SCHEMA, producer_version=COMPILER_VERSION,
                   term_policy=TERM_POLICY, root_context=ROOT_CONTEXT, rounds=2,
                   basis=[implication, p, q], variables=[], schemes=[])
    compiled = dict(status='complete', catalog=catalog, basis=catalog['basis'],
                    variables=[], tautologies=[], admitted_schemes=[])
    inventory = dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[])
    return spec, compiled, inventory


def _byte_compatible(left, right, terminator):
    # Tiny diagnostic only: explicit old aligned byte assignments.
    a = tuple(left) + (terminator,); b = tuple(right) + (terminator,)
    for i in range(min(len(a), len(b))):
        if a[i] != b[i]:
            return False
    return True


def run_word_reference_diagnostics(word_module, *, check):
    check(); spec, compiled, inventory = _tiny_inputs()
    model = word_module.Model(spec, compiled, inventory, arity=0, families=False, check=check)
    positive = verify_word_reference(spec, compiled, inventory, model, check=check)
    controls = [dict(id='full-synthetic-word-reduction', status='PASSED')]
    def reject(name, view):
        check(); caught = None
        try:
            verify_word_reference(spec, compiled, inventory, view, check=check)
        except BaseException as error:
            check()
            if type(error) is not ReferenceMismatch or error.owner is not _OWNER:
                raise
            caught = error
        _require(caught is not None, 'negative control must reject: ' + name, check)
        controls.append(dict(id=name, status='PASSED'))
    key = next(iter(model.cache)); tile = model.placement(key); marks = tuple(tile.marks)
    port_index = next(i for i, pair in enumerate(marks) if _word_port(pair[0], spec['length']))
    scalar_index = next(i for i, pair in enumerate(marks) if pair[0][1] == 90)
    def changed_tile(name, changed_marks, occupancy=None):
        cache = dict(model.cache)
        cache[key] = type(tile)(tile.key, tile.occupancy if occupancy is None else occupancy,
                                changed_marks, tile.vertices)
        reject(name, _ModelView(model, cache=cache))
    point, value = marks[port_index]
    changed_tile('bool-word-ID', marks[:port_index] + ((point, bool(value)),) + marks[port_index+1:])
    changed_tile('negative-word-ID', marks[:port_index] + ((point, -1),) + marks[port_index+1:])
    changed_tile('out-of-range-word-ID', marks[:port_index] + ((point, len(model.word_dictionary)),) + marks[port_index+1:])
    changed_tile('wrong-full-word-ID', marks[:port_index] + ((point, (value+1) % len(model.word_dictionary)),) + marks[port_index+1:])
    changed_tile('missing-word-occurrence', marks[:port_index] + marks[port_index+1:])
    changed_tile('shifted-word-origin', marks[:port_index] + (((point[0], 101), value),) + marks[port_index+1:])
    changed_tile('partial-byte-instead-of-port', marks[:port_index] + ((point, model.word_dictionary[value][0]),) + marks[port_index+1:])
    changed_tile('missing-assigned-scalar-zero', marks[:scalar_index] + marks[scalar_index+1:])
    scalar_point = marks[scalar_index][0]
    changed_tile('bool-scalar-zero', marks[:scalar_index] + ((scalar_point, False),) + marks[scalar_index+1:])
    changed_tile('extra-unconstrained-zero', marks + (((999, 999), 0),))
    changed_tile('word-scalar-namespace-collision', marks[:scalar_index] + ((point, 0),) + marks[scalar_index+1:])
    changed_tile('wrong-unit-occupancy', marks, ((tile.occupancy[0][0], 11),))
    changed_tile('bool-point-alias', marks, (((False, False), 12),))
    dictionary = model.word_dictionary
    reject('dictionary-not-immutable', _ModelView(model, word_dictionary=list(dictionary)))
    reject('duplicate-word-content', _ModelView(model, word_dictionary=dictionary+(dictionary[0],)))
    reject('unused-dictionary-word', _ModelView(model, word_dictionary=dictionary+(b'new-unused-canonical-word',)))
    reject('wrong-word-terminator-zero', _ModelView(model, word_terminator=0))
    reject('bool-word-terminator', _ModelView(model, word_terminator=True))
    reject('partial-dictionary-word', _ModelView(model, word_dictionary=(dictionary[0][:-1],)+dictionary[1:]))
    reject('proper-prefix-dictionary-word', _ModelView(model, word_dictionary=(dictionary[0]+b'0',)+dictionary[1:]))
    reject('dictionary-bytes-as-list', _ModelView(model, word_dictionary=(tuple(dictionary[0]),)+dictionary[1:]))
    reject('missing-boundary-IDzero', _InitialView(model, {}))
    reject('bool-boundary-IDzero', _InitialView(model, {(8,100):False}))
    reject('wrong-boundary-full-word', _InitialView(model, {(8,100):1}))
    reject('shifted-boundary-word', _InitialView(model, {(8,101):0}))
    cache = dict(model.cache); del cache[key]
    reject('missing-original-key', _ModelView(model, cache=cache))
    metadata = dict(model.metadata); metadata[key] = dict(metadata[key], requirements=[(0, spec['target'])])
    reject('changed-original-metadata', _ModelView(model, metadata=metadata))
    domains = list(model.domains); domains[0] = domains[0][:-1]
    reject('truncated-original-domain', _ModelView(model, domains=domains))
    alignments = dict(model.align_cache); root = tile.occupancy[0][0]; alignments[root] = alignments[root][1:]
    reject('missing-root-alignment', _ModelView(model, align_cache=alignments))
    alignments = dict(model.align_cache); alignments[root] = alignments[root]+(key,)
    reject('duplicate-root-alignment', _ModelView(model, align_cache=alignments))
    dep_point = next(iter(model.dependencies)); dep_keys = model.dependencies[dep_point]
    deps = dict(model.dependencies); deps[dep_point] = frozenset(set(dep_keys)|{(999,0,0,0)})
    reject('spurious-dependency-key', _ModelView(model, dependencies=deps))
    deps = dict(model.dependencies); deps[dep_point] = frozenset(set(dep_keys)-{next(iter(dep_keys))})
    reject('missing-dependency-edge', _ModelView(model, dependencies=deps))
    deps = dict(model.dependencies); deps[(999,100)] = frozenset({key})
    reject('spurious-dependency-point', _ModelView(model, dependencies=deps))
    deps = dict(model.dependencies); deps[dep_point] = iter(dep_keys)
    reject('consumed-dependency-iterator', _ModelView(model, dependencies=deps))
    _require(positive['internal_conflicts'] > 0, 'repeated-source conflict exercised', check)
    controls.append(dict(id='original-conflicting-guards-preserved', status='PASSED'))
    # Independent tiny full pair correspondence, including zero byte and prefix.
    tiny_words = (b'', b'0', b'00', b'1', bytes((0,)), bytes((0,0)), bytes((255,)))
    comparisons = 0
    for left in tiny_words:
        for right in tiny_words:
            check(); _require(_byte_compatible(left,right,256) == (left == right),
                              'full aligned byteword equality correspondence', check)
            comparisons += 1
    _require(_byte_compatible(b'', bytes((0,)), 0),
             'zero terminator counterexample is actually compatible', check)
    controls.append(dict(id='all49-tiny-aligned-word-pairs-and-zero-terminator-counterexample', status='PASSED'))
    # Exact unions over several changed ports, including mark-only dependencies.
    changed = {p for p in model.dependencies if p[1] in (90,100)}
    actual_union = set(); reference_union = set()
    for point in changed:
        check(); actual_union.update(model.dependencies.get(point, ()))
    for candidate in model.cache:
        check()
        if _support_points(compiled, model.domains, candidate) & changed:
            reference_union.add(candidate)
    _require(actual_union == reference_union, 'full affected-candidate union', check)
    controls.append(dict(id='affected-port-and-scalar-union', status='PASSED'))
    packet = dict(certificates=[dict(auxiliary=dict(placement=key, point=(-100,0),
                                                   placement_value=0,initial_value=1))])
    marked = word_module.MarkedModel(model, packet, None)
    overlay = verify_marked_extension(model, marked, packet, check=check)
    _require(model.initial().legal(tile) and not marked.initial().legal(marked.placement(key)),
             'fresh scalar auxiliary marking changes ordinary legality', check)
    controls.append(dict(id='generic-auxiliary-extension-and-legality', status='PASSED'))
    for error_type in (RuntimeError, ValueError, StopIteration, ReferenceMismatch):
        sentinel = error_type('external word-reference callback sentinel')
        def external():
            check(); raise sentinel
        caught = None
        try:
            verify_word_reference(spec, compiled, inventory, model, check=external)
        except BaseException as error:
            check(); caught = error
        _require(caught is sentinel, 'foreign callback identity survives', check)
        controls.append(dict(id='foreign-'+error_type.__name__, status='PASSED'))
    check()
    return dict(schema='word-reference-tiny-diagnostics-v1', complete=True,
                controls=controls, positive=positive, overlay=overlay,
                tiny_full_byte_pair_comparisons=comparisons,
                scope='Synthetic constructor and reduction controls, not Native logical admissions or target-proof evidence. Generic auxiliary extension controls do not claim word reduction for arbitrary partial-byte states. All controls unrun until fresh reviewed Root actual.')
