"""Author a report template from the established reader. No scientific calls."""
from pathlib import Path
B=Path(__file__).resolve().parent.parent
D=B.parent/'gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
s=(D/'recipient-proof-search.html').read_text()
def replace(old,new):
    global s
    assert old in s,old[:120]
    s=s.replace(old,new)
def section(start,end,new):
    global s
    a=s.index(start); b=s.index(end,a)
    s=s[:a]+new+s[b:]
replace('Recipient proof-search experiment — GCTS research','Word-valued point proof search — GCTS research')
replace('reader.html#recipient-proof-update','reader.html#word-point-update')
replace('compact-proof-search.html#outcome','recipient-proof-search.html#outcome')
replace('Previous compact setup experiment','Previous byte-point search')
replace('Read the recipient proof','Read discovered proofs')
replace('An automatically discovered recipient proof, and a measured GCTS bottleneck.','Word-valued markings: can complete GCTS proof search become practical?')
replace('Three fresh case jobs compare the available primitive controls: conventional symbolic search and point search, with or without certified failure markings. Cluster-dependent arms remain explicitly skipped when their prerequisite is unknown.','A new, explicitly checked representation compresses each complete aligned formula or command into one exact point value. We retain the same statements, candidate identities, scheduler, proof gates and search budgets, and report what actually returns.')
replace('<h3>Corpus and controls</h3><p>Freeze donor statements, recipient statements, limits and a separate missing-premise semantic control.</p>','<h3>Independent reduction verifier</h3><p>Derive the original candidate specification independently; check dictionary words, ports, metadata, dependencies and negative controls.</p>')
replace('Build actual marking certificates, automatic cluster acquisition, six search arms, and complete result records.','Implement the word-valued carrier and integrate it with the unchanged complete Graph search, markings and six arm protocol.')
insert=r'''<section id="carrier"><h2>What changed: one exact value per whole word</h2><div class="cards"><article class="card"><h3>Original byte carrier</h3><p>A formula or command occupies a vertical run of marking points: its canonical bytes followed by the terminator \(256\).</p><p class="formula">\(b_0,b_1,\ldots,b_{n-1},256\)</p></article><article class="card"><h3>Checked word carrier</h3><p>The same origin port receives a dictionary ID. The frozen dictionary retains every full literal word; equality uses exact bytes, with no logical normalization.</p><p class="formula">\(\operatorname{id}(w)=\operatorname{id}(v)\iff w=v\)</p></article><article class="card"><h3>Preserved search problem</h3><p>Candidate identities, occupancy roots, scalar mode points, certified exclusion points, initial conditions and the affected-candidate unions correspond. All Graph audits and proof checks remain.</p></article></div><p>Why compatibility is preserved: unequal words disagree at a byte, or the shorter word's terminator meets a byte of the longer word. Every word includes its origin, so replacing its byte support by that port preserves the union of affected candidates.</p><p class="warning">This is a new reduced point domain with a checked correspondence for reachable, aligned, complete-word states. It does not cover arbitrary partial or shifted byte assignments. The independent reduction verifier checks the entire declared candidate model; this is not a claim that the two representations are pointwise identical.</p></section>
'''
replace('<section id="design">',insert+'<section id="design">')
replace('Initial exclusion witnesses</th>','Auxiliary removal incidences</th>')
replace('Nine arms returned actual searches; nine cluster-dependent arms were explicitly skipped. A completed six-method comparison requires all eighteen searches and their proof gates.','Actual returned and skipped counts are reported above. A completed six-method comparison requires all eighteen searches and their proof gates.')
replace('The recipient proof was discovered by S0. Donor proofs are elementary acquisition controls.','Each proof identifies the engine that discovered it. Donor proofs are elementary acquisition controls.')
replace('Command bytes</span>','Command word ID</span>')
replace('Formula bytes / earlier-row requirements</span>','Formula word ID / earlier-row requirements</span>')
replace('Blue denotes formula bytes, purple command bytes, and green mode or occupancy.','Blue denotes formula-word IDs, purple command-word IDs, and green mode or occupancy. IDs are local to the frozen case dictionary, not global mathematical symbols.')
replace('The full exact coordinates and values remain below.','The full exact coordinates, values and dictionary payloads remain below.')
replace('Inspect every saved point/value pair for this candidate','Inspect every point/value pair and complete assigned word')
section('<p>All finite required roots start at generation zero.','</section>\n<section id="assessment">','<p>All finite required roots start at generation zero. Point search checks global dead ends, then global forced placements, then earliest-generation branching. The new carrier is checked independently against the original constructor specification, including candidate identities, internal conflicts, boundary and dependency incidence. Returned checks and search audits are distinguished from planned checks in the actual records.</p>')
replace('This implementation shares literal marking segments, groups exact dependency intervals, and exposes a compact evidence view. Independent checks compare its decoded point values and incidences with the original specification.','This implementation uses exact dictionary-valued marking ports. Independent checks derive the whole-word occurrences and establish their correspondence with the original complete byte-word construction.')
replace('recipient-proof-search','word-point-proof-search')
# Restore the historical comparison link after renaming this report's own assets.
replace('href="word-point-proof-search.html#outcome">Previous byte-point search','href="recipient-proof-search.html#outcome">Previous byte-point search')
replace("'3 primitive searches returned'","c.searches_returned+' primitive searches returned'")
replace("for(const text of [c.accepted_recipient_proofs.length?'S0 recipient proof accepted':'No recipient proof in budget','Point searches: first-audit cutoff','3 cluster arms skipped'])","for(const text of [c.accepted_recipient_proofs.length?'Recipient proof accepted':'No recipient proof in budget',c.point_status,c.skipped_cluster_arms+' cluster arms skipped'])")
replace("text==='S0 recipient proof accepted'","text==='Recipient proof accepted'")
replace("'No recipient proof in budget'","'No admitted recipient proof'")
replace("num(c.whole_peak_bytes/1048576)+' MiB'","c.memory_label")
replace("(100*c.whole_peak_bytes/1073741824)","(100*c.display_peak_bytes/1073741824)")
replace("['Complete saved job returned',c.searches_returned+' primitive searches returned']","[c.job_admission_label,c.searches_returned+' recorded searches returned']")
replace("x.className='stage ok';n.append(x)}for(const text of", "x.className='stage '+(c.resource_candidate_accepted?'ok':'stop');n.append(x)}for(const text of")
replace('Each bar shows the conservative whole peak against the unchanged memory ceiling of \\(1\\,\\mathrm{GiB}\\).','Each bar shows the conservative whole peak against the unchanged memory ceiling of \\(1\\,\\mathrm{GiB}\\), except the first failed attempt, whose available worker-plus-Native lower bound is shown and labeled. Its whole peak is unavailable.')
replace("markings:t.marks,auxiliary:t.auxiliary","markings:t.marks,word_occurrences:t.word_occurrences,auxiliary:t.auxiliary")
replace('The certified mismatch excludes this trial. The marked point runs returned initial exclusion witnesses; no complete recipient domain audit or placement followed.','The certified mismatch excludes this trial through ordinary point-value agreement. Actual domain audits and search outcomes are reported separately above.')
(B/'publication/word-point-proof-search.html').write_text(s)
print('Authored template only; actual data and independent publication review still required.')
