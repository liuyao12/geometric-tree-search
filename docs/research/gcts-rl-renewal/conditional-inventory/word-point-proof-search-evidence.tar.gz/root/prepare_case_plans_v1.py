"""Metadata and AST/unused compile only; no scientific imports or calls."""
from pathlib import Path
import ast, hashlib, json, sys

B=Path(__file__).resolve().parent.parent
D7=B.parent/'gcts-recipient-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
RUNTIME=B/'runtime'
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12').resolve()
NATIVE=D5/'implementation-B/recovered/and-support'

def pin(path):
    p=Path(path).resolve(); assert '.partial' not in p.name
    body=p.read_bytes()
    return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())

def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,sort_keys=True,indent=2); stream.write('\n')

api_path=Path(sys.argv[1]).resolve()
handoff_path=Path(sys.argv[2]).resolve()
api=json.loads(api_path.read_bytes())
entry=Path(api['entry']['path']); assert pin(entry)==api['entry']
for field in ['model_source','verifier_source']:
    source=Path(api[field]['path']); assert pin(source)==api[field]
    assert (RUNTIME/source.name).read_bytes()==source.read_bytes()
baseline=json.loads((B/'root/baseline-copy-pins-v1.json').read_bytes())
for row in baseline['files']:
    assert pin(row['source'])['sha256']==row['sha256']
    assert pin(row['target'])['sha256']==row['sha256']
assert len(baseline['files'])==30
assert len(list(RUNTIME.glob('*.py')))==28
assert json.loads(handoff_path.read_bytes())
old_api=json.loads((D7/'implementation-B/API-v1.json').read_bytes())
assert api['roles']==dict(old_api['roles'],model='word_point_model_v1')
corpus=D5/'corpus-L/pilot-inputs-v2.json'
assert pin(corpus)['sha256']=='2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'
doc=json.loads(corpus.read_bytes()); assert [s['length'] for s in doc['tests']]==[14,13,14]
tree=ast.parse(entry.read_bytes(),filename=str(entry))
node=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets))
assert isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict'
scientific={k.arg:ast.literal_eval(k.value) for k in node.keywords}
assert scientific==json.loads((D7/'root/protocol-v1.json').read_bytes())['scientific_limits']
native=dict(template_path=str(NATIVE/'fixed-native-inputs/proof-boundary-001.json'),micro_path=str(NATIVE/'fixed-native-inputs/proof-boundary-microcode-001.json.gz'),executable_path=str(NATIVE/'Native-runtime/boundary-oracle-v2'))
sources=sorted(RUNTIME.glob('*.py'))+[entry]+[B/'root'/n for n in ['observe_case_once_v2.py','run_case_once_v3.py','case_worker_v1.py','independent_countermodel_v1.py']]
checks=[]
for p in sources:
    parsed=ast.parse(p.read_bytes(),filename=str(p)); compile(parsed,str(p),'exec')
    checks.append(dict(path=str(p),AST_and_unused_compile=True))
files=sources+[api_path,handoff_path,corpus,PYTHON,NATIVE/'Native-runtime/boundary_oracle.cpp']+[Path(p) for p in native.values()]
rows=[pin(p) for p in sorted(set(files))]
limits=dict(positive_seconds=180,custody_seconds=210,observer_fallback_seconds=225,work_seconds=160,memory_bytes=1073741824,physical_bytes=134217728,reserved_outer_bytes=9437184,log_bytes=4194304,root_callbacks=400000000,result_bytes=50331648)
protocol=dict(schema='aligned-word-point-search-protocol-v1',input=pin(corpus),limits=limits,scientific_limits=scientific,
    unchanged='D7 three fresh cold donor searches, full target theories and14/13/14 primitive bounds; original candidate identities/metadata/guard variants, exact t roots, initial boundary, full frontier, complete domains, generation/scheduler, rollback, six-arm relative order,2s local clock and all numeric quotas/proof gates.',
    change='An explicit new reduced-coordinate carrier replaces every complete aligned canonical formula/command byte word plus terminator256 with one exact dictionary ID at its origin port. Scalar mode and certified auxiliary markings remain unchanged. L independently certifies the full candidate/domain/metadata/boundary/dependency correspondence; no pointwise identity or arbitrary partial/shifted byte-state claim.',
    reduction='Unequal complete words at the same origin disagree at a byte or at terminator256 versus byte0..255. Whole-word compatibility is therefore exact equality. Every word touches its origin, so the affected-candidate dependency union equals that of the reduced port. Only reachable aligned whole-word states are covered; future internal-byte markings need a new reduction.',
    prerequisites='Unchanged D7 per-arm gate: ground registry Native UNKNOWN skips SC/P01/P11 explicitly; S0/P00/P10 run. Rejected or foreign status/Root or transport faults are not skips. Full primitive alternatives remain fallback; no shortened macro proof.',
    proof_acceptance='Every candidate proof retains exact case Host, complete finite point region and final primitive Native gates. Native UNKNOWN after Host/region acceptance is candidate-only. New carrier checks and controls must actually return.',
    completion='All six explicit outcomes comprise job_record_complete. A skipped arm prevents all_six_searched and scientific_complete; bounded unsuccessful search is unknown. This stage cannot complete the research program.',
    execution='Three sequential fresh cold jobs, independent observer and exact one-use Root grants after Source/plan review. All agents idle for timed jobs. No old grant/result/prefix/library adoption.',
    costs='All acquisition, compilation, new carrier/reduction checks, encoding, markings, grounding, arm searches/proof checks, serialization and custody physically charged once per case. Report nested timers without adding them as disjoint. S0 method allocation need not charge unused library/marking; no cluster gets free acquisition.',
    search_time='Original cooperative2s budget includes Graph construction/snapshots/initial audits and active search. Operations and cleanup can overshoot checkpoints. No moved clock, omitted audit, threshold increase or ordering change.',
    baseline_scope='Same matched symbolic control, not best ATP. Shared point setup is experimental correspondence overhead and not intrinsically needed by a conventional prover. D7 is a historical development comparator, not a controlled statistical replication.',
    source='28runtime Sources:26 exact D7 copies plus newly frozen Model and independent reduction verifier;4custodian Sources exact D7. New entry imports reviewed additions. Old compact Sources remain preserved but do not qualify the new carrier.',
    observer='Fixed-dependency nonhostile research custodian, not an adversarial sandbox or OSreal-time proof. Independent225s fallback; actual180s positive/210s custody/1GiB/128MiB whole gates. Live file census is non-atomic; final census after known child exit.',
    scope='Native/point adaptation. No trainedRL, physical nearest-neighbor Wang qualification, practical plane-tiling result, fullPA/Hilbertgeometry or wholeprogram completion. All historical failed gates/cohorts preserved.',
    partial_rule='Every.partial raw length/hash only, never parsed/projected/reconstructed/admitted.',old_grants_remaining=0,new_actuals=0,new_grants=0)
protocol_path=B/'root/protocol-v1.json'; save(protocol_path,protocol)
plans=[]
for spec in doc['tests']:
    case=spec['id']; actual=B/'actual'/case
    assert not actual.exists() and not Path(str(actual)+'.observer').exists()
    plan=dict(schema='proof-search-case-once-plan-v1',experiment='aligned-word-point-search-v1',case_id=case,actual_dir=str(actual),runtime_dir=str(RUNTIME),runner_path=str(B/'root/run_case_once_v3.py'),observer_path=str(B/'root/observe_case_once_v2.py'),worker_path=str(B/'root/case_worker_v1.py'),entry_path=str(entry),control_path=str(B/'root/independent_countermodel_v1.py'),input_path=str(corpus),modules=api['roles'],native=native,python=pin(PYTHON),files=rows,limits=limits,experiment_limits=scientific,protocol=pin(protocol_path),authority='No execution from plan. Exact reviewed fresh Root once grant required.',trusted_runtime='Pinned isolated CPython/fixed research Sources; nonhostile reproducible research, not wholeOS/adversarial security proof.',old_qualifications='No old grant/cohort/failed gate adopted or rescued.')
    path=B/'root'/('plan-'+case+'-v1.json'); save(path,plan); plans.append(pin(path))
offer=dict(schema='aligned-word-point-search-whole-offer-v1',plans=plans,files=rows,protocol=pin(protocol_path),python=pin(PYTHON),source_AST_checks=checks,expected_case_jobs=3,expected_explicit_arm_outcomes=18,scientific_calls=0,new_actuals=0,new_grants=0,old_grants_remaining=0,resource_fit='UNMEASURED. Complete actual admission required.',readiness='PENDING_EXACT_REDUCTION_SOURCE_COMPOSITION_AND_PLAN_REVIEWS_ROOT_ONCE_GRANTS')
save(B/'root/prospective-whole-offer-v1.json',offer)
print(json.dumps(dict(plans=plans,files=len(rows),Source_AST_checks=len(checks),new_actuals=0,new_grants=0)))
