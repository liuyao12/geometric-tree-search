"""Root exact metadata preflight and fresh once grants; no scientific calls."""
from pathlib import Path
import hashlib,json,sys
B=Path(__file__).resolve().parent.parent; R=B/'root'
def pin(path):
    p=Path(path).resolve(); assert '.partial' not in p.name
    body=p.read_bytes();return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
opath=R/'prospective-whole-offer-v1.json';offer=json.loads(opath.read_bytes())
for row in offer['files']+offer['plans']+[offer['protocol']]:assert pin(row['path'])==row
assert len(offer['files'])==41 and len(offer['plans'])==3
reviews=[]
for argument in sys.argv[1:]:
    path=Path(argument); receipt=json.loads(path.read_bytes())
    assert receipt['review_passed'] is True
    reviews.append(pin(path))
assert len(reviews)>=3
preflight=dict(schema='Root-word-point-search-preflight-v1',offer=pin(opath),protocol=offer['protocol'],reviews=reviews,review_passed=True,new_uses=3,old_grants_remaining=0,goal_status='active',previous_turn='PROGRESS: nine D7primitive calls, one14line conventional S0proof, six point initial-audit cutoffs, published/liveverified41e8e472. No GCTS/RL advantage or complete six-arm comparison.',authority='Three fresh once attempts only, unchanged outer ceilings and local clock; no performance or completion result.',conformance='Explicit lossless reduced-coordinate aligned full-word carrier; exact original candidate identities,troots,frontier,generation,scheduler,rollback,scalar and certifiedaux markings, complete primitive fallback retained. All new reduction/Graph/wholepoint proof checks must return inside actuals.',gaps='Only reachable aligned complete-word states. No arbitrary partial/shifted byte markings. No trainedRL or physicalWang qualification, broad speed superiority or fullprogram completion. Resourcefit unmeasured.',partial_files_parsed=False)
save(R/'Root-preflight-v1.json',preflight)
for row in offer['plans']:
    plan=json.loads(Path(row['path']).read_bytes())
    assert not Path(plan['actual_dir']).exists() and not Path(plan['actual_dir']+'.observer').exists()
    grant=dict(schema='Root-fresh-word-point-case-grant-v1',authorized=True,uses=1,no_retry=True,case_id=plan['case_id'],actual_dir=plan['actual_dir'],plan_sha256=row['sha256'],runner_sha256=pin(plan['runner_path'])['sha256'],observer_sha256=pin(plan['observer_path'])['sha256'],review_passed=True,reviews=reviews,root_preflight=pin(R/'Root-preflight-v1.json'),old_grants_reused=False)
    save(R/('grant-'+plan['case_id']+'-v1.json'),grant)
print(json.dumps(dict(preflight=pin(R/'Root-preflight-v1.json'),fresh_grants=3,actuals=0)))
