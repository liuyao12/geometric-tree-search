"""Passive complete saved-JSON joins and literal word display decoding only."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent.parent
D5=B.parent/'gcts-proof-search-pilot-20261020'
OUT=B/'publication'
def pin(path):
    p=Path(path);assert '.partial' not in p.name
    raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_bytes())
def save(path,value):path.write_text(json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,indent=2)+'\n')
corpus=read(D5/'corpus-L/pilot-inputs-v2.json')
cases=[];proofs=[];donors=[];tiles=[];totals=[];pointrows=[]
for spec in corpus['tests']:
    folder=B/'actual'/spec['id'];path=folder/('result.json' if (folder/'result.json').exists() else 'failure.json');d=read(path)
    s=d['scientific_result'];c=s['tests'][0]
    header=read(folder/'worker-header.json');terminal=read(folder/'terminal.json')
    observer=read(Path(str(folder)+'.observer/observer.json'))
    assert header['result']==pin(path)
    if terminal['result'] is not None:assert terminal['result']==pin(path)
    admitted=bool(d['status']==header['status']=='COMPLETE' and terminal['process_exit_code']==observer['parent_exit_code']==0 and observer['resource_candidate_accepted'])
    assert s['job_record_complete']
    assert c['spec']==spec and [a['id'] for a in c['arms']]==corpus['protocol']['arm_order'][spec['id']]
    assert s['diagnostics']['status']=='complete' and s['word_reference_diagnostics']['complete']
    assert len(s['word_reference_diagnostics']['controls'])==48
    assert all(x['status']=='PASSED' for x in s['word_reference_diagnostics']['controls'])
    assert c['reference_check']['complete'] and c['word_model_check']['complete']
    packet=c['model'];assert packet['schema']=='pilot-aligned-whole-word-point-model-v1'
    bykey={tuple(p['key']):p for p in packet['placements']}
    def tile(chosen,label,certificate=None):
        if not admitted:label='NONADMITTED — '+label
        words=[]
        for point,value in chosen['marks']:
            if point[1]==100:
                raw=bytes.fromhex(packet['word_dictionary'][value])
                words.append(dict(point=point,word_id=value,payload_hex=raw.hex(),literal_value=json.loads(raw),terminator=packet['word_terminator']))
        ref=chosen['command_reference']; command=packet['domains'][ref[0]][ref[1]]
        aux=[x['auxiliary'] for x in c['markings']['certificates'] if x['auxiliary']['placement']==chosen['key']]
        tiles.append(dict(label=label,scope=('WHOLE CASE NOT ADMITTED — diagnostic saved artifact. ' if not admitted else 'Resource-admitted case. ')+'Exact word-port candidate from '+spec['id']+'. Fixed positional translation roles; no rotation or reflection. High-level reduced point carrier; not a physical nearest-neighbor Wang tile.',whole_job_admitted=admitted,case_id=spec['id'],key=chosen['key'],occupancy=chosen['occupancy'],marks=chosen['marks'],word_occurrences=words,auxiliary=aux,command=command,metadata=chosen['metadata'],certificate=certificate,description='Colored bands distinguish full command words, full formula words and scalar mode/exclusion values. Every displayed ID and payload is decoded literally from the complete saved case dictionary.'))
        return len(tiles)-1
    arms=[];accepted=[];checker_candidates=[];searched=0;skipped=0;casepoints=[]
    for a in c['arms']:
        if a['execution_status']=='SKIPPED_UNKNOWN_PREREQUISITE':
            skipped+=1;assert a['search'] is None and a['native_proof_accepted'] is None
            arms.append(dict(id=a['id'],outcome='SKIPPED — cluster admission unknown',attempts=None,forced_branches='—',aux_removals=None,cluster_proposals=None,times='—',status=a['execution_status']));continue
        assert a['execution_status']=='SEARCH_RETURNED';searched+=1
        search=a['search'];m=search['metrics'];attempts=m.get('attempts',0)
        if a['method']=='point':
            placements=sum(x['event']=='place' for x in search['trace'])
            assert attempts==placements and search['root_restored']
            assert all(x['complete'] for x in search['domain_audits'])
            point=dict(case_id=spec['id'],arm=a['id'],attempts=attempts,nodes=m.get('nodes',0),placed_events=placements,completed_domain_audits=len(search['domain_audits']),initial_audit=search['domain_audits'][0] if search['domain_audits'] else None,forced_decisions=m.get('forced',0),branch_decisions=m.get('branch',0),backtracks=m.get('backtracks',0),initial_auxiliary_removal_witnesses=m['initial_auxiliary_removed_incidences'],auxiliary_removal_incidences_total=m['auxiliary_removed_incidences_total'],search_seconds=a['timings']['search_seconds'],root_restored=True,status=search['status'])
            point['whole_job_admitted']=admitted
            pointrows.append(point);casepoints.append(point)
        ok=a['native_proof_accepted'] is True
        outcome='PROOF ACCEPTED — Host, point region, Native' if ok and admitted else 'CHECKERS ACCEPTED — whole job NOT ADMITTED' if ok else search['status']
        if not admitted and not ok:outcome='NOT ADMITTED — observed '+outcome
        arms.append(dict(id=a['id'],outcome=outcome,attempts=attempts,forced_branches=str(m.get('forced',0))+' / '+str(m.get('branch',0)) if a['method']=='point' else 'Not applicable',aux_removals=m.get('auxiliary_removed_incidences_total') if a['method']=='point' else None,cluster_proposals=m.get('cluster_proposals',0),times=f'{a["timings"]["search_seconds"]:.6f} / {a["timings"]["full_arm_seconds"]:.6f} s',status=a['execution_status']))
        if search['proof'] is not None:
            assert ok and a['host_check']['accepted'] and a['region']['complete']
            assert a['proof_verification_status']=='HOST_REGION_NATIVE_ACCEPTED'
            q=s['native_records'][a['native_query']]
            assert q['result']['status']=='accepted' and q['request']['proof']==search['proof'] and q['request']['theory']==spec['theory'] and q['request']['target']==spec['target']
            rows=[]
            for row,command in enumerate(search['proof']):
                selected=[bykey[tuple(k)] for k in search['placements'] if k[0]==row]
                assert len(selected)==2 and {p['metadata']['kind'] for p in selected}=={'command','guard'}
                selected.sort(key=lambda p:p['key'][1])
                indices=[tile(p,spec['title']+' — '+a['id']+' recorded proof row '+str(row+1)+' '+p['metadata']['kind']) for p in selected]
                assert all(tiles[i]['command']==command for i in indices)
                rows.append(dict(row=row+1,command=command,tile_indices=indices))
            engine='conventional symbolic control' if a['method']=='symbolic' else 'point Graph search'
            status='Automatically discovered by '+a['id']+' '+engine+'. Exact Host, full finite point-region and Native checks returned accepted. No RL policy was used.'
            if not admitted:status='NOT ADMITTED: the whole case failed its memory gate. This saved S0 observation has accepted Host/point-region/Native checker records, but is not an admitted D8 result. The previous byte-point experiment independently admitted its S0 proof.'
            proofs.append(dict(title=('Recipient — ' if admitted else 'NONADMITTED observation — ')+spec['title']+' ('+a['id']+')',spec=spec,proof=search['proof'],status=status,source=pin(path),arm=a['id'],query_id=q['id'],whole_job_admitted=admitted,tile_rows=rows,search_seconds=a['timings']['search_seconds'],full_arm_seconds=a['timings']['full_arm_seconds']))
            candidate=dict(arm=a['id'],rows=len(search['proof']),query=q['id'],search_seconds=a['timings']['search_seconds'],full_arm_seconds=a['timings']['full_arm_seconds'])
            checker_candidates.append(candidate)
            if admitted:accepted.append(candidate)
    for t in s['training']:
        assert t['acquired']
        assert s['native_records'][t['native_query']]['result']['status']==s['native_records'][t['essential_native_query']]['result']['status']=='accepted'
        if admitted:donors.append(dict(title='Admitted-case donor — '+t['spec']['title'],spec=t['spec'],proof=t['search']['proof'],status='Automatically searched elementary donor from the resource-admitted case; Host/region and whole/essential Native accepted. Cluster-dependent recipient arms require separate admission.',source=pin(path),tile_rows=[]))
    cert=c['markings']['certificates'][0]
    tile(bykey[tuple(cert['auxiliary']['placement'])],spec['title']+' — certified excluded trial',cert)
    tile(next(p for p in packet['placements'] if p['metadata']['kind']=='guard' and p['metadata']['requirements']),spec['title']+' — earlier-row receptor guard')
    ground=s['native_records'][c['clusters']['admission_query']]
    total=dict(case_id=spec['id'],observer_seconds=observer['elapsed_seconds'],whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],worker_peak_bytes=d['python_peak_bytes'],native_peak_bytes=d['native_peak_bytes'],known_exit_seconds=terminal['known_exit_seconds'],full_shared_setup_seconds=c['full_shared_setup_seconds'],compile_and_model_seconds=c['compile_and_model_seconds'],word_model_seconds=c['word_model_seconds'],training_and_acquisition_seconds=s['training_and_acquisition_seconds'],marking_seconds=c['markings']['compile_and_verification_seconds'],ground_query_seconds=ground['seconds'],ground_instances=len(c['clusters']['instances']),ground_native_status=ground['result']['status'],native_queries=len(s['native_records']),searches_returned=searched,skipped_cluster_arms=skipped,accepted_recipient_proofs=accepted,checker_accepted_candidates=checker_candidates,point_attempts=sum(x['attempts'] for x in casepoints),point_domain_audits=sum(x['completed_domain_audits'] for x in casepoints),certified_exclusions=len(c['markings']['certificates']),dictionary_words=len(packet['word_dictionary']),model_placements=len(packet['placements']),resource_candidate_accepted=admitted,scientific_complete=bool(admitted and s['scientific_complete']),result=pin(path),terminal=pin(folder/'terminal.json'),observer=pin(Path(str(folder)+'.observer/observer.json')))
    total['display_peak_bytes']=total['whole_peak_bytes'] if total['whole_peak_bytes'] is not None else total['worker_peak_bytes']+total['native_peak_bytes']
    total['memory_label']=('Whole peak: ' if total['whole_peak_bytes'] is not None else 'Worker+Native lower bound: ')+f'{total["display_peak_bytes"]/1048576:.1f} MiB'
    total['job_admission_label']='Whole job resource-admitted' if admitted else 'WHOLE JOB NOT ADMITTED — memory gate'
    total['point_status']=str(total['point_attempts'])+' point placements; '+str(total['point_domain_audits'])+' complete audits'
    p00=next(x for x in casepoints if x['arm']=='P00');p10=next(x for x in casepoints if x['arm']=='P10')
    assert p00['initial_audit']['frontier_points']==p10['initial_audit']['frontier_points']
    total['initial_audit_incidence_difference']=p00['initial_audit']['incidences']-p10['initial_audit']['incidences']
    assert total['initial_audit_incidence_difference']==12
    totals.append(total)
    costs=[f'Cold donor discovery/check/mining: {s["training_and_acquisition_seconds"]:.6f} s. Full shared setup: {c["full_shared_setup_seconds"]:.6f} s. Compilation/model/reduction: {c["compile_and_model_seconds"]:.6f} s; artifact encoding/check: {c["word_model_seconds"]:.6f} s; markings/check: {total["marking_seconds"]:.6f} s. These clocks contain nested work and must not be added as disjoint.',f'Ground registry: {len(c["clusters"]["instances"])} instances; Native status {ground["result"]["status"]}; {ground["seconds"]:.6f} s. Its full cost remains charged even when cluster arms are skipped.',f'Whole observer: {observer["elapsed_seconds"]:.6f} s. {total["memory_label"]}. Admission: {total["job_admission_label"]}. Includes outputs and custody, not merely theorem-search latency.','The original cooperative two-second local deadline is retained, including Graph construction/snapshots/audits. Operations and cleanup can overshoot checkpoints. No timer was moved to create this result.','For per-method allocation, S0 needs no unused donor library or auxiliary marking acquisition; P10 includes its marking costs. Conventional symbolic proof search does not intrinsically need the shared point-model reporting setup.','The raw grounding-work counter can reach20,003 at the20,000 cooperative threshold through recursive unwind checks; no unification follows the threshold.']
    notes=[f'{x["arm"]}: {x["attempts"]} actual placement events, {x["completed_domain_audits"]} completed exhaustive Graph audits, {x["forced_decisions"]} forced decisions, {x["branch_decisions"]} branch decisions; exact initial state/Graph restoration returned.' for x in casepoints]
    notes.append('Initial auxiliary witnesses are collected by a separate full alignment scan. Audit counts refer to actual completed Graph-domain/incidence/scheduler checks; witness counts alone are not an audited before/after domain difference. All certified failures remain first-row conditions, not learned multiscale abstractions.')
    notes.insert(0,total['job_admission_label']+' — search observations for '+spec['title']+'.')
    cases.append(dict(title=spec['title'],spec=spec,outcome=total['job_admission_label']+'. '+str(len(accepted))+' admitted recipient proof(s); '+str(searched)+' recorded searches and '+str(skipped)+' skipped cluster arms.',failure=('The complete attempt failed its memory gate. Its returned search/certificate observations are not admitted comparison results. ' if not admitted else '')+'Skipped cluster arms prevent a complete six-arm comparison. An unsuccessful bounded search does not establish theorem falsity.',metrics=[f'Whole job: {total["observer_seconds"]:.3f} s',total['memory_label'],('Admitted: ' if admitted else 'Nonadmitted observation: ')+total['point_status'],f'Admitted proofs: {len(accepted)}'],arms=arms,control=d['independent_external_controls'],cost_notes=costs,marking_notes=notes))
proofs+=donors
summary=dict(schema='Root-passive-word-point-search-assessment-v1',cases=totals,point_searches=pointrows,new_actual_case_jobs=len(totals),remaining_once_grants=0,searches_returned=sum(x['searches_returned'] for x in totals),cluster_arms_skipped=sum(x['skipped_cluster_arms'] for x in totals),accepted_recipient_proofs=sum(len(x['accepted_recipient_proofs']) for x in totals),point_placement_attempts=sum(x['attempts'] for x in pointrows),complete_point_domain_audits=sum(x['completed_domain_audits'] for x in pointrows),word_reference_controls_per_case=48,scientific_complete=all(x['scientific_complete'] for x in totals),whole_goal_complete=False,trained_RL=False,partial_files_parsed=False,scientific_calls=0,scope='Passive complete saved-file joins and literal word-dictionary display decoding; no scientific Source execution/replay. Unqualified aggregate counts include two explicitly NONADMITTED failed attempts; separate admitted counts follow.')
summary.update(resource_admitted_case_jobs=sum(x['resource_candidate_accepted'] for x in totals),resource_rejected_case_jobs=sum(not x['resource_candidate_accepted'] for x in totals),admitted_searches_returned=sum(x['searches_returned'] for x in totals if x['resource_candidate_accepted']),admitted_cluster_arms_skipped=sum(x['skipped_cluster_arms'] for x in totals if x['resource_candidate_accepted']),admitted_point_placement_attempts=sum(x['attempts'] for x in pointrows if x['whole_job_admitted']),admitted_complete_point_domain_audits=sum(x['completed_domain_audits'] for x in pointrows if x['whole_job_admitted']),checker_accepted_candidates_in_nonadmitted_jobs=sum(len(x['checker_accepted_candidates']) for x in totals if not x['resource_candidate_accepted']))
save(B/'root/passive-actual-assessment-v1.json',summary)
report=dict(schema='word-point-proof-search-report-v1',headline='Point search now advances; two whole jobs fail the memory gate.',conclusion='The resource-admitted missing-premise case completed four exhaustive point-Graph audits and14 placements across its two point arms. Both positive case attempts exceeded the unchanged memory ceiling. No GCTS-discovered proof, speed advantage or complete six-arm comparison is established.',proof_scope='The first item is a NONADMITTED S0 observation from the failed positive case: its checker records returned accepted, but it is not an admitted D8 result. The previous byte-point report separately admitted its S0 proof. Three elementary donor proofs from the admitted missing-premise job follow. Each observed recipient line links to the exact saved command and guard point tiles. No proof route was supplied to search.',cases=cases,proofs=proofs,tiles=tiles,actual_summary=summary,assessment=[
    'The explicit full-word carrier passed its actual independent construction checks. In the one resource-admitted job, both point arms finished their two exhaustive domain/inverse/scheduler audits, restored the original state/Graph exactly, and made4 and10 actual placement attempts. D7 made no point placements. This is concrete implementation progress under the unchanged local clock, not proof-search superiority.',
    'All six point calls returned positive placement counts and two complete audits, totalling89 observed placements and12 audits. Only14 placements and4 audits belong to the resource-admitted case. The remaining observations are retained for diagnosis, never promoted into a qualified comparison.',
    'The first positive attempt failed the worker combined-memory gate; its Python and Native peaks alone sum to1,079,541,760 bytes, above the1GiB ceiling. The equality attempt returned a complete child packet but failed whole custody, with conservative peak1,153,777,664 bytes. The missing-premise job passed at860,045,312 bytes. No cap is raised and no failed prefix is adopted.',
    'S0 again produced the14-line positive certificate, with accepted Host/region/Native records. Its whole case failed memory, so this is a nonadmitted saved observation. The earlier D7 S0 proof remains separately admitted; no new admitted recipient theorem was found here.',
    'Each P10 call has12 certified initial exclusions. Initial complete Graph audits show12 fewer incidences than the corresponding P00 initial audit. In the admitted negative job this demonstrates actual Graph pruning, rather than merely a post-search conflict scan. It does not establish useful tree reduction: both point searches remain budget-unknown, and the attempt counts depend on a short cooperative clock.',
    'The48 new reference controls returned in each packet. Only the controls in the one whole-admitted job count as qualified evidence for this stage. All cluster-dependent arms were explicitly skipped after unknown Native admission: nine observed skips, of which three belong to the admitted job. There was no trained RL policy.',
    'The next practical problem is peak memory and end-to-end cost. Full words/metadata/evidence and proof traces remain potentially expensive. No phase-memory instrumentation was collected, so a particular allocation cannot be named as the measured cause. Any repair needs a separately declared cold experiment and the same acceptance gates.',
    'These authored development cases do not test the strongest ATP methods or constitute a blind benchmark. Full PA, symbolic Hilbert geometry, a physical universal Wang system, learned hierarchical cluster proposals and practical Turtle/Penrose tiling remain active objectives.'
],review_summary='Separate independent Source/composition and whole-plan reviews preceded the fresh once runs. Scientific outcome and resource/custody reviews explicitly retain two failed memory cases and one admitted case. They inspect full saved records and Source arguments without claiming scientific replay outside these actuals.')
def prose_spacing(value):
    if type(value) is str:
        for old,new in [('and14','and 14'),('made4','made 4'),('and10','and 10'),('totalling89','totalling 89'),('and12','and 12'),('Only14','Only 14'),('and4','and 4'),('to1,','to 1,'),('the1GiB','the 1 GiB'),('peak1,','peak 1,'),('at860,','at 860,'),('the14-line','the 14-line'),('has12','has 12'),('show12','show 12'),('The48','The 48'),('reach20,','reach 20,'),('the20,','the 20,')]:value=value.replace(old,new)
        return value
    if type(value) is list:return [prose_spacing(x) for x in value]
    if type(value) is dict:return {k:prose_spacing(v) for k,v in value.items()}
    return value
save(OUT/'word-point-proof-search-data.json',prose_spacing(report))
save(OUT/'word-point-proof-search-engineering.json',dict(schema='word-point-proof-search-method-v1',protocol=read(B/'root/protocol-v1.json'),assessment=summary,verification_scope='Independent full model reduction/occurrence checks and actual returned tiny controls; literal evidence-owner joins; unchanged primitive Host/full-region/final Native gates. C/L subsequent reviews are passive joins and Source arguments.',partial_files_parsed=False,scientific_calls=0))
print(json.dumps(dict(assessment=pin(B/'root/passive-actual-assessment-v1.json'),proofs=len(proofs),tiles=len(tiles),point_attempts=summary['point_placement_attempts'],audits=summary['complete_point_domain_audits'])))
