"""Package complete task-owned bytes; no scientific calls or partial parsing."""
from pathlib import Path
import hashlib,io,json,tarfile
B=Path(__file__).resolve().parent.parent
D7=B.parent/'gcts-recipient-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
P=B.parent/'gcts-batch-20261020/publisher'
D=P/'docs/research/gcts-rl-renewal/conditional-inventory'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    raw=path.read_bytes();return dict(file=path.name,bytes=len(raw),sha256=sha(raw))
excluded={'archive-scan-v1.json','Root-final-milestone-v1.json','Root-next-stage-handoff-v1.json','memory-retention-assessment-v1.json'}
paths={p for p in B.rglob('*') if p.is_file() and 'publication' not in p.relative_to(B).parts and 'publication-C' not in p.relative_to(B).parts and p.name not in excluded}
offer=json.loads((B/'root/prospective-whole-offer-v1.json').read_bytes());omitted=[]
for row in offer['files']:
    path=Path(row['path'])
    if path==Path(offer['python']['path']):omitted.append(dict(pin=row,reason='Pinned trusted isolated CPython binary not redistributed; research Sources and fixed Native assets are included.'))
    else:paths.add(path)
paths.update([D7/'implementation-B/proof_search_pilot_v5.py',D7/'implementation-B/API-v1.json',D7/'root/protocol-v1.json',D7/'root/passive-actual-assessment-v1.json',P/'docs/basic-tiling-algorithm.md'])
records=[];bodies=[];partials=[]
for path in sorted(paths):
    assert not path.is_symlink()
    if path.is_relative_to(B):name=path.relative_to(B).as_posix()
    elif path.is_relative_to(D7):name='dependencies/D7/'+path.relative_to(D7).as_posix()
    elif path.is_relative_to(D5):name='dependencies/D5/'+path.relative_to(D5).as_posix()
    elif path==P/'docs/basic-tiling-algorithm.md':name='reference/basic-tiling-algorithm.md'
    else:raise ValueError('undeclared archive path '+str(path))
    raw=path.read_bytes();row=dict(file=name,bytes=len(raw),sha256=sha(raw))
    if '.partial' in path.name:partials.append(row)
    else:records.append(row);bodies.append((name,raw))
manifest=dict(schema='word-point-search-evidence-archive-v1',files=records,partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted,actual_case_attempts=3,resource_admitted_case_attempts=1,resource_rejected_case_attempts=2,complete_actual_and_observer_files=42,observed_searches=9,observed_cluster_skips=9,observed_point_placements=89,observed_point_audits=12,admitted_searches=3,admitted_cluster_skips=3,admitted_point_placements=14,admitted_point_audits=4,new_admitted_recipient_proofs=0,scientific_comparison_complete=False,scientific_calls_during_packaging=0,reproduction='Consumed grants are historical records, never reusable. New paths/plans/reviews/fresh once grants are required. This snapshot includes execution closure and all complete failed and admitted attempt bodies; the pinned CPython binary is omitted explicitly.',scope='Two failed memory jobs are diagnostic observations only and never prefix-adopted. Only the missing-premise job passed whole resource admission. Publication-only review and the prospective unexecuted memory-repair assessment are outside this scientific snapshot.')
mb=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=B/'publication/word-point-proof-search-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as stream:
    for name,raw in bodies+[('MANIFEST.json',mb)]:
        item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0;stream.addfile(item,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as stream:
    assert len(stream.getmembers())==len(records)+1
    for row in records:
        raw=stream.extractfile(row['file']).read();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    assert stream.extractfile('MANIFEST.json').read()==mb
scan=dict(schema='word-point-archive-complete-byte-scan-v1',archive=pin(archive),members=len(records)+1,payload_bytes=sum(row['bytes'] for row in records),all_members_byte_checked=True,partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted)
(B/'root/archive-scan-v1.json').write_text(json.dumps(scan,sort_keys=True,indent=2)+'\n')
for path in sorted((B/'publication').glob('word-point-proof-search*')):
    if path.name!='word-point-proof-search-manifest.json':(D/path.name).write_bytes(path.read_bytes())
owned=sorted(p for p in D.glob('word-point-proof-search*') if p.name!='word-point-proof-search-manifest.json')+[D/'reader.html']
assert len(owned)==7
public=dict(schema='word-point-proof-search-publication-manifest-v1',source_parent_commit='41e8e472c7ed17c01b2d6e9c71e500262f8e42ed',files=[pin(p) for p in owned],archive_scan=scan,conclusion='Three actuals: two rejectedmemory, one admittednegative. Observed89placements/12audits; admitted14/4.0newadmittedrecipientproofs; no complete6armcomparison or GCTS/RLgain.',reader_delta=json.loads((B/'root/reader-publication-delta-v1.json').read_bytes()))
(D/'word-point-proof-search-manifest.json').write_text(json.dumps(public,sort_keys=True,indent=2)+'\n')
print(json.dumps(scan))
