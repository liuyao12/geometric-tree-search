"""Normal-TLS full-body publication check, with no research code imports."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import ssl
import sys
import urllib.request

B=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-word-point-proof-pilot-20261020')
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory')
ORIGIN='https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/'
commit=sys.argv[1]
assert len(commit)==40 and all(c in '0123456789abcdef' for c in commit)
p=D/'word-point-proof-search-manifest.json'
manifest=json.loads(p.read_bytes())
expected=manifest['files']+[dict(file=p.name,bytes=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest())]
context=ssl.create_default_context()

def fetch(row):
    name=row['file'];assert Path(name).name==name
    url=ORIGIN+name+'?v='+commit
    request=urllib.request.Request(url,headers={'Cache-Control':'no-cache','Accept-Encoding':'identity'})
    with urllib.request.urlopen(request,timeout=30,context=context) as response:
        assert response.status==200
        body=response.read(134217729)
    actual=dict(file=name,bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    assert actual==row,(actual,row)
    return dict(**actual,url=url,normal_TLS=True,complete_body=True,matched=True)

with ThreadPoolExecutor(max_workers=4) as pool:
    rows=list(pool.map(fetch,expected))
receipt=dict(schema='recipient-pilot-full-live-body-verification-v1',commit=commit,
    files=rows,total_complete_bytes=sum(r['bytes'] for r in rows),all_matched=True,
    normal_TLS=True,scientific_imports_or_replays=0)
(B/'root/full-live-body-verification-v1.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt))
