"""Ordinary metadata successor for corrected current-master attribution."""
import hashlib
import json
from pathlib import Path
C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1')
def pin(path):
 p=Path(path);r=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
oldpath=C/'selector-VM-obligations-v1.json';note=json.loads(oldpath.read_bytes())
current=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/basic-tiling-algorithm-current.md')
assert pin(current)['sha256']=='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9' and pin(current)['bytes']==21657
before=Path(note['inputs']['master']['path']).read_text();after=current.read_text()
same_1_5=before[before.index('## 1.'):before.index('## 6.')]==after[after.index('## 1.'):after.index('## 6.')]
same_7_8=before[before.index('## 7.'):before.index('## 9.')]==after[after.index('## 7.'):after.index('## 9.')]
same_tail=before[before.index('For each current or future subproject'):]==after[after.index('For each current or future subproject'):]
assert same_1_5 and same_7_8 and same_tail
note['schema']='fixed-vm-selector-cardinality-and-conformance-review-v2'
note['superseded_note']=pin(oldpath)
note['master_reconciliation']=dict(current=pin(current),historical_prior_contract_master=note['inputs']['master'],sections1through5_rawexact=same_1_5,sections7through8_rawexact=same_7_8,final_conformance_tail_rawexact=same_tail,read_current_whole=True,provenance='Root supplied exact raw copy after reporting its current primary-master read; C read ONLY this tmp copy, not primary content/index/.gcts-active. No claim this copy equals a newly checked isolated Git HEAD.',applicability='Current section6 is shorter and more directly states rejected-negative disagreement; old6.1/6.2/6.3/6a and expanded audit rows are absent. This selector/VM strand implements no learner, so no old removed exception is used. Selector is problem-defining finite point data; complete graph/scheduler/rollback/typed marking/verification/explicit adaptation obligations remain unchanged. Historical reviews keep their old master scope.')
note['inputs']['master']=pin(current)
note['read_scope']='Complete retained architecture contract, historical36240Bmaster and newly supplied current21657Bmaster read; complete old compiler literal Source inspected. Ordinary bytes/manual algebra only; no component/generator/machine/checker/codec invoked.'
note['foundation_report_arithmetic_only']=dict(source='L message to C; exact foundation Source/census packet not yet offered for C review',Source_census_reviewed=False,full_VM_completed=False,reported=dict(Q=9108,b=37,D=225835,D0=38285),conditional_arithmetic=dict(A=337033,retained_step_tiles=954080288,full_old_plus_selector_tiles=954754816,old_colors=17724267,full_old_plus_selector_colors=17724352),scope='Integer substitution into the manually reviewed formulas only; not a generator/table materialization, Source census confirmation, completed fixed checker VM or runtime measurement. Even one literal byte per retained tile would exceed original134217728B. A different minimized/implicit encoding must supply fresh completeness/count/cost proofs; no cap or workload reduction is adopted.')
note['Root_initializer_Source_offer_pending_review']=pin('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/wang_unknown_certificate_initializer_v1.py')
out=C/'selector-VM-obligations-v2.json'
if out.exists():raise RuntimeError('immutable output exists')
out.write_bytes(json.dumps(note,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
print(json.dumps(pin(out),sort_keys=True))
