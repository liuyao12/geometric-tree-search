from pathlib import Path
import hashlib,json,sys
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1');C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1');A=D/'actual-components-v2';O=D/'component-plan-authorized-v2-terminal-observation'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_bytes())
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def equal(a,b):
 pending=[(a,b)]
 while pending:
  a,b=pending.pop()
  if type(a)is not type(b):return False
  if type(a)is dict:
   if list(a)!=list(b):return False
   pending.extend((a[k],b[k])for k in a)
  elif type(a)is list:
   if len(a)!=len(b):return False
   pending.extend(zip(a,b))
  elif a!=b:return False
 return True
checks=[]
def ck(n,x):
 checks.append(dict(name=n,passed=bool(x)))
 if not x:raise AssertionError(n)
planp=D/'component-plan-authorized-v2.json';plan=read(planp);subject={k:v for k,v in plan.items()if k!='authorization'};auth=read(plan['authorization']['path']);decl=read(plan['declaration']['path']);closure=read(plan['runtime_closure']['path']);bank=read(plan['inputs'][0]['pin']['path']);r=read(A/'runner-receipt.json');h=read(A/'worker-receipt.json');payload=read(A/'result.json');q=payload['qualification'];packet=read(A/'canonical-codec-initializer-calibration.json');term=read(O/'terminal.json');consumed=read(A/'CONSUMED.json');worker_consumed=read(A/'WORKER_CONSUMED.json');retire=read(D/'ROOT-grant-retirement-v2.json');summary=read(D/'ROOT-passive-actual-summary-v2.json');barrier=read(D/'ROOT-all-idle-fresh-barrier-v2.json')
ck('offered full canonical raw pin',pin(A/'canonical-codec-initializer-calibration.json')==dict(path=str(A/'canonical-codec-initializer-calibration.json'),bytes=2175732,sha256='a79e1877f21ea816cc6bd2da93185fa695687c6b9fa8f6c84ae86378edc2c775'))
for source_role,p in plan['sources'].items():ck('current whole Source '+source_role,pin(p['path'])==p)
for name in ['python','declaration','runtime_closure','authorization']:ck('whole '+name,pin(plan[name]['path'])==plan[name])
for item in plan['inputs']:ck('whole input '+item['id'],pin(item['pin']['path'])==item['pin'])
for p in closure['stdlib_files']:ck('whole stdlib '+p['path'],pin(p['path'])==p)
ck('current review pin',pin(auth['review']['path'])==auth['review'])
review=read(auth['review']['path']);ck('current review full subject',equal(review['subject'],subject)and review['subject_sha256']==auth['subject_sha256']=='2b87066c8c64b8a01875e732a1f3900bf5adee3ed10a26d99791dd3d62f81a32')
ck('Root grant true maxone',auth['actual_execution_authorized']is True and auth['author_identity']=='/root'and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1)
ck('closure and input full bindings',equal(closure['sources'],plan['sources'])and equal(closure['python'],plan['python'])and equal(closure['declaration'],plan['declaration'])and equal(decl['inputs'],plan['inputs']))
for name,p in [('runner',term['runner_receipt']),('worker',r['worker_receipt']),('result',r['result']),('marker',r['consumed_marker'])]:ck('whole saved '+name,pin(p['path'])==p)
ck('canonical packet output descriptor joins',equal(h['outputs'],r['outputs'])and equal(q['outputs'],r['outputs'])and equal(payload['outputs'],r['outputs'])and r['outputs']==[pin(A/'canonical-codec-initializer-calibration.json')])
for obj,label in [(r,'runner'),(h,'worker'),(payload,'result'),(term,'terminal'),(consumed,'consumed'),(worker_consumed,'worker_consumed')]:ck('same plan '+label,obj['plan']==pin(planp))
ck('same complete result declaration closure',payload['declaration']==plan['declaration']and payload['runtime_closure']==plan['runtime_closure'])
ck('whole input bank full-value match',equal(packet['inputs'],bank))
ck('all raw actual files expected8',set(p.name for p in A.iterdir())=={'CONSUMED.json','WORKER_CONSUMED.json','canonical-codec-initializer-calibration.json','result.json','worker-receipt.json','runner-receipt.json','stdout.bin','stderr.bin'})
for p in A.iterdir():
 if p.suffix=='.json':ck('complete JSON LF '+p.name,p.read_bytes().endswith(b'\n'))
ck('stored status candidates',packet['status']==q['status']=='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE')
rows=packet['integers']+packet['values']+packet['programs']+packet['selectors'];ck('288 complete unique ordered rows',[x['id']for x in rows]==decl['case_ids']==q['case_ids']and len(rows)==288 and len({x['id']for x in rows})==288)
ck('compact result rows full match',q['rows']==[dict(id=x['id'],complete=x['complete'])for x in rows])
for row in rows:ck('saved complete '+row['id'],row['complete']is True)
ck('264 integer input values exact',[x['value']for x in packet['integers']]==bank['integers']and len(packet['integers'])==264)
for x in packet['integers']:
 ck('saved integer row type/work '+x['id'],type(x['value'])is int and type(x['bits'])is str and type(x['encode_work'])is int and type(x['decode_work'])is int and 0<x['encode_work']<=400000000 and 0<x['decode_work']<=400000000)
ck('10 malformed full stored joins',[x['bits']for x in packet['malformed_integers']]==decl['malformed_integers']and equal(packet['malformed_integers'],q['malformed_integers'])and len(packet['malformed_integers'])==10)
for x in packet['malformed_integers']:ck('malformed stored refusal '+x['bits'],x['status']=='PASSED'and x['error']['type']=='Invalid')
ck('28 diagnostic literal full joins',equal(packet['diagnostics'],q['diagnostics'])and [x['id']for x in packet['diagnostics']]==decl['diagnostic_ids']==q['diagnostic_ids']and len(packet['diagnostics'])==28)
for x,e in zip(packet['diagnostics'],decl['diagnostics']):
 ck('diagnostic declared row '+x['id'],x['status']=='PASSED'and x['operation']==e['operation']and x['expected']==e['expected'])
 if e['expected']=='FOREIGN':ck('stored exact foreign '+x['id'],type(x['callback_count'])is int and x['callback_count']==1 and x['exact_foreign_identity']is True)
 else:ck('stored private refusal '+x['id'],type(x['callback_count'])is int and x['callback_count']==0 and x['exact_foreign_identity']is None)
for name in ['codec-implicit-header-bits','codec-unused-seed-ID-bits','codec-padding-encode-bits','codec-padding-decode-bits']:
 x=next(x for x in packet['diagnostics']if x['id']==name);ck('numeric repair observation '+name,x['expected']=='LIMIT'and x['error']==dict(type='ResourceLimit',message='integer_bits'))
ck('six ordered value cases',[x['id']for x in packet['values']]==[x['id']for x in bank['values']]and len(packet['values'])==6)
for x,e in zip(packet['values'],bank['values']):
 ck('value seed exact '+x['id'],equal(x['seed_nodes'],e.get('seed_nodes',[]))and equal(x['encoded_heap'][:len(x['seed_nodes'])],x['seed_nodes']))
 ck('value raw carrier counts '+x['id'],x['typed_values'][0]=='list'and len(x['roots'])==len(x['typed_values'][1])and type(x['band'])is str and x['band'].endswith(':')and x['padding']==e.get('padding',2))
 ck('value finite exported own work '+x['id'],type(x['encode_work'])is int and type(x['decode_work'])is int and 0<x['encode_work']<=400000000 and 0<x['decode_work']<=400000000)
uv=next(x for x in packet['values']if x['id']=='surrogate-pair-versus-astral')
ck('saved exact surrogate and astral carriers',uv['typed_values']==['list',[['str_utf8_surrogatepass_hex','eda080edb080'],['str_utf8_surrogatepass_hex','f0908080'],['str_utf8_surrogatepass_hex','eda08000edb080']]])
cv=next(x for x in packet['values']if x['id']=='containers-and-order')
ck('saved explicit reverse dictionary entry order',cv['typed_values'][1][-1][0]=='dict'and [kv[0][1]for kv in cv['typed_values'][1][-1][1]]==['62','61'])
pad=next(x for x in packet['values']if x['id']=='padding-255-at-eight-bits');ck('saved positive empty255 padding',pad['padding']==255 and pad['roots']==[]and pad['typed_values']==['list',[]])
ck('two retained full program groups',len(packet['programs'])==2 and equal(packet['programs'][0]['program'],bank['all_opcodes_program']))
manifest=read('/private/tmp/gcts-fixed-vm-codec-20261020-v1/whole-checker-manifest-v1.json');program_metrics=[]
for x in packet['programs']:
 p=x['program'];c=x['counts'];ck('program retained counts '+x['id'],c['heap_nodes']==len(p['nodes'])and c['constants']==len(p['constants'])and c['functions']==len(p['functions'])and c['instructions']==sum(len(f['code'])for f in p['functions'])and c['call_arguments']==sum(len(ins[3])for f in p['functions']for ins in f['code']if ins[0]=='call'))
 ck('program image raw metadata '+x['id'],type(x['image'])is str and len(x['image'])>0 and x['profile']in('generic','full_checker_69'))
 ck('program finite exported own work '+x['id'],0<x['encode_work']<=400000000 and 0<x['decode_work']<=400000000)
 program_metrics.append(dict(id=x['id'],profile=x['profile'],counts=c,image_symbols=len(x['image'])))
full=packet['programs'][1];ck('whole saved69 ordered names',[f['name']for f in full['program']['functions']]==manifest['functions_in_exact_order'])
ck('whole saved69/2158/79040',full['counts']['functions']==q['full_checker_functions']==69 and full['counts']['instructions']==q['full_checker_instructions']==2158 and len(full['image'])==79040)
wire=Path(plan['sources']['wire_source']['path']).read_bytes();fol=Path(plan['sources']['fol_source']['path']).read_bytes();combined=Path(plan['sources']['combined_source']['path']).read_bytes();ck('raw whole Source recipe unchanged',wire+fol.replace(b'def main(request):',b'def semantic_main(request):',1)==combined)
ck('one recorded actual full Compiler start/return',packet['call_started']['tree.Compiler.declaration']==packet['call_completed']['tree.Compiler.declaration']==1 and packet['call_raised'].get('tree.Compiler.declaration',0)==0)
ck('two independent image writers completed',packet['call_started']['Root.reference_program_image']==packet['call_completed']['Root.reference_program_image']==2)
ck('two independent static grammar validates',packet['call_started']['tree.validate']==packet['call_completed']['tree.validate']==2)
selector_metrics=[]
ck('16 complete ordered selector rows',[x['id']for x in packet['selectors']]==[x['id']for x in bank['selectors']]and len(packet['selectors'])==16)
for x,e in zip(packet['selectors'],bank['selectors']):
 p=x['problem'];pal=p['palette'];cc=x['cardinality']['counts'];ck('retained selector original input '+x['id'],equal(pal['machine'],e['machine'])and equal(p['fixed_prefix'],e['prefix'])and equal(p['fixed_suffix'],e['suffix'])and p['certificate_capacity']==e['capacity']and p['physical_machine_steps']==e['steps'])
 ck('retained strip lists full count '+x['id'],x['selector_rows']==len(x['full_selector_paths'])==len(x['free_words'])==len(x['reference_words']))
 # Compare already saved populations only; do not enumerate language, tiles, legality or transitions.
 ck('saved free and reference populations match '+x['id'],sorted(x['free_words'])==sorted(x['reference_words'])and len({tuple(v)for v in x['free_words']})==len(x['free_words']))
 ck('saved full palette/count join '+x['id'],cc['total_tiles']==len(pal['tiles'])and equal(pal['cardinality'],cc))
 ck('saved board population counts '+x['id'],p['board_height']==e['steps']+2 and len(p['required_centers'])==p['board_width']*p['board_height']and equal(p['required_centers'],p['admissible_origins']))
 ck('selector all candidate flags false '+x['id'],p['all_root_generations']==0 and all(p[k]is False for k in ['executed_source_qualified','mathematical_authority','public_problem_semantics_established','universal_interpreter_established'])and pal['mathematical_authority']is False)
 ck('selector exported ownwork finite '+x['id'],0<p['attempted_work']<=400000000 and 0<x['cardinality']['attempted_work']<=400000000)
 selector_metrics.append(dict(id=x['id'],selector_rows=x['selector_rows'],palette_tiles=len(pal['tiles']),colors=len(pal['color_constructors']),board_width=p['board_width'],board_height=p['board_height'],required_centers=len(p['required_centers'])))
ck('104 saved selector strips',sum(x['selector_rows']for x in packet['selectors'])==q['selector_rows']==decl['expected_selector_rows']==104)
for field in ['call_started','call_completed','call_raised']:
 ck('same saved call map '+field,equal(packet[field],h[field]))
for key,v in packet['call_started'].items():ck('entry/return/refusal count partition '+key,type(v)is int and v==packet['call_completed'].get(key,0)+packet['call_raised'].get(key,0))
ck('recorded Root callback successive cutoffs',packet['root_callbacks']==661804<q['root_check_calls']==662628<h['root_check_calls']==662636<=400000000)
ck('passive summary Root scope result cutoff',summary['root_check_calls']==q['root_check_calls'])
ck('recorded local reference count join',packet['reference_calls']==q['oracle_calls']==payload['oracle_calls']==r['oracle_calls']==6896)
for field in ['compiler_calls','search_calls','verifier_calls','oracle_calls']:ck('result/runner local call projection '+field,q[field]==payload[field]==r[field])
ck('no unexpected denied events',payload['denied_events']==[])
for obj,label,keys in [(packet,'packet',['full_VM_implemented','full_FOL_palette_qualified','proof_discovery','complete_machine_run','full_pipeline_qualified','mathematical_authority']),(q,'qualification',['full_pipeline_qualified','mathematical_proof_accepted','fixed_FOL_palette_qualified','gcts_rl_advantage_established','learned_pair_markings','trained_RL','complete_physical_VM','proof_discovery']),(payload,'result',['full_pipeline_qualified','scientific_acceptance','mathematical_proof_accepted']),(h,'header',['full_pipeline_qualified','scientific_acceptance','mathematical_proof_accepted']),(term,'terminal',['full_pipeline_qualified','scientific_acceptance','mathematical_proof_accepted','ROOT_resource_accepted'])]:ck('authority boundary '+label,all(obj[k]is False for k in keys))
for obj,label in [(payload,'result'),(h,'header')]:ck('literal no unrelated runtime '+label,all(type(obj[k])is int and obj[k]==0 for k in ['Native_calls','Model_calls','inverse_calls','Reader_calls','FOL_kernel_calls','opaque_program_decodes']))
ck('no search entries',q['search_calls']==0)
ck('once consume source epoch joins',consumed['consumed_before_Popen']is True and consumed['maximum_worker_launches']==1 and consumed['subject_sha256']==auth['subject_sha256']and consumed['began_ns']==r['began_ns']==h['began_ns'])
ck('original exact absolute deadline offsets',r['work_deadline_ns']==r['began_ns']+180000000000 and r['overall_deadline_ns']==r['began_ns']+210000000000 and h['work_deadline_ns']==consumed['work_deadline_ns']==r['work_deadline_ns']and h['overall_deadline_ns']==consumed['overall_deadline_ns']==r['overall_deadline_ns'])
ck('PID PPID owned launch joins',worker_consumed['pid']==h['pid']==r['worker_pid']==r['owned_pgid']and worker_consumed['ppid']==h['ppid']==term['runner_pid']and worker_consumed['worker_entry_ns']==h['worker_entry_ns'])
ck('known normal exit and reaping',r['worker_launch_attempts']==1 and r['worker_exit_code']==r['worker_wait4_status']==term['runner_exit_code']==0 and r['worker_reaped']is True and r['owned_group_absent']is True)
ck('positive worker/read/knownexit original work',r['began_ns']<h['worker_entry_ns']<=h['positive_worker_completed_ns']<=r['worker_terminal_observed_ns']<=r['positive_result_read_completed_ns']<r['work_deadline_ns'])
ck('all terminal before original210',r['post_child_raw_custody']['completed_ns']<r['overall_deadline_ns']and r['whole_log_custody']['completed_ns']<r['overall_deadline_ns']and r['final_physical_ledger']['completed_ns']<term['terminal_observed_ns']<r['overall_deadline_ns'])
ck('runner finite/resource true terminal true',r['resource_candidate_accepted']is True and r['finite_encoding_candidate']is True and term['terminal_gate_passed']is True)
ck('no primary/finalization/signal error',r['primary_failure']is None and r['errors']==[]and r['finalization_errors']==[]and r['signals']==[]and not(A/'POST_RECEIPT_DEADLINE_FAILURE.json').exists())
ck('cleanup unused not missing',r['cleanup']['attempted']is False and r['cleanup']['diagnostics_incomplete']is False and r['cleanup']['error_summaries']=={})
ck('positive raw/log/physical custody complete',r['post_child_raw_custody']['checked']is True and r['post_child_raw_custody']['completed_before_deadline']is True and r['whole_log_custody']['stable']is True and r['whole_log_custody']['complete']is True and r['whole_log_custody']['completed_before_deadline']is True and r['final_physical_ledger']['stable_writer_quiescence']is True and r['final_physical_ledger']['enumeration_complete']is True and r['final_physical_ledger']['completed_before_deadline']is True)
for name in ['stdout','stderr']:
 ck('whole empty stable log '+name,pin(A/(name+'.bin'))==r[name]and r[name]['bytes']==0)
 co=r['log_close_observations'][name];ck('genuine single parent close '+name,co['opened']is True and co['closed']is True and co['close_attempts']==1 and co['opened_ns']<=co['closed_ns']<term['terminal_observed_ns'])
ck('logical exact byte accounting',r['logical_result_bytes']==h['logical_result_bytes']==r['expanded_logical_result_bytes']==h['expanded_logical_result_bytes']==2175732+25631==2201363 and payload['canonical_logical_bytes']==payload['expanded_canonical_packet_bytes']==2175732)
ck('resource HWM exact standalone bytes',r['worker_peak_bytes']==r['worker_wait4_usage']['ru_maxrss']==73039872<=1073741824)
current_total=sum(p.stat().st_size for p in A.iterdir()if p.is_file());before=current_total-(A/'runner-receipt.json').stat().st_size
ck('current physical roster reconstructs pre-receipt ledger',before==r['physical_before_runner_receipt']==r['final_physical_ledger']['before_receipt_bytes']==2205020)
ck('reserve exact and cap',before+9437184==r['conservative_physical_bytes']==r['final_physical_ledger']['conservative_bytes']==11642204<=134217728 and h['outer_metadata_reservation']==9437184 and current_total<=11642204)
ck('observer folder reserved1MiB',sum(p.stat().st_size for p in O.iterdir()if p.is_file())<=1048576)
ck('elapsed exact saved epochs',(term['terminal_observed_ns']-r['began_ns'])/1e9==term['runner_clock_elapsed_seconds']==summary['elapsed_seconds']==2.887547792)
ck('observer epoch kept distinct',(term['terminal_observed_ns']-term['observer_started_ns'])/1e9==term['observed_instrument_elapsed_seconds']==2.910303792)
for k,v in [('case_rows',288),('malformed_words',10),('diagnostics',28),('selector_rows',104),('checker_functions',69),('checker_instructions',2158),('program_image_symbols',79040),('worker_peak_bytes',73039872),('logical_bytes',2201363),('physical_bytes_with_reserve',11642204)]:ck('Root passive projection '+k,summary[k]==v)
ck('barrier binds delta and exact plan',barrier['plan']==pin(planp)and pin(barrier['grant_delta']['path'])==barrier['grant_delta']and barrier['all_paths_absent']is True and barrier['all_raw_pins_exact']is True and barrier['component_calls']==0)
for key,p in [('grant',plan['authorization']),('runner',pin(A/'runner-receipt.json')),('terminal',pin(O/'terminal.json')),('consumed',pin(A/'CONSUMED.json')),('worker_consumed',pin(A/'WORKER_CONSUMED.json'))]:ck('retirement whole binding '+key,retire[key]==p)
ck('grant consumed once retired no retry',retire['actual_invocations']==1 and retire['remaining_invocations']==0 and retire['retired']is True and retire['repeat_authorized']is False and retire['mathematical_adoption']is False and retire['runner_exit']==0 and retire['terminal_gate_passed']is True)
metrics=dict(normal_cases=288,integers=264,value_groups=6,programs=program_metrics,malformed_words=10,diagnostics=28,diagnostic_classes={k:sum(x['expected']==k for x in packet['diagnostics'])for k in ['INVALID','LIMIT','FOREIGN']},selector_cases=16,top_selector_rows=104,elapsed_runner_Source_epoch_to_external_terminal_seconds=2.887547792,observer_instrument_elapsed_seconds=2.910303792,worker_peak_bytes=73039872,logical_and_expanded_bytes=2201363,physical_pre_runner_receipt_bytes=2205020,physical_with_reserved_metadata_bytes=11642204,actual_current_file_bytes=current_total,root_callback_cutoffs=dict(packet=661804,result=662628,worker_header=662636),local_wrapped_call_started=packet['call_started'],local_wrapped_call_completed=packet['call_completed'],local_wrapped_call_raised=packet['call_raised'],local_reference_counter=6896)
receipt={'schema':'fixed-codec-initializer-saved-actual-review-v2','reviewer_identity':'/root/conventional_control_review','saved_review_passed':True,'saved_data_only':True,'source_only':False,'component_calls':0,'scientific_calls':0,'subject_imports':0,'solver_calls':0,'codec_calls':0,'fixture_calls':0,'process_probes':0,'actual_execution_authorized':False,'finite_component_evidence_complete':True,'scientific_acceptance':False,'mathematical_proof_admitted':False,'full_pipeline_qualified':False,'full_physical_VM_qualified':False,'FOL_kernel_qualified':False,'outcome':'CONSISTENT_COMPLETE_FINITE_COMPONENT_CALIBRATION','mismatch_count':0,
'plan':pin(planp),'subject_sha256':auth['subject_sha256'],'authorization':plan['authorization'],'sources':plan['sources'],'declaration':plan['declaration'],'runtime_closure':plan['runtime_closure'],'input':plan['inputs'][0]['pin'],'raw_actual_files':[pin(p)for p in sorted(A.iterdir())if p.is_file()],'raw_observer_files':[pin(p)for p in sorted(O.iterdir())if p.is_file()],'Root_retirement':pin(D/'ROOT-grant-retirement-v2.json'),'Root_passive_summary':pin(D/'ROOT-passive-actual-summary-v2.json'),'Root_barrier':pin(D/'ROOT-all-idle-fresh-barrier-v2.json'),'current_master':pin(D/'basic-tiling-algorithm-current.md'),'metrics':metrics,'selector_row_metadata':selector_metrics,
'checks':checks,'check_count':len(checks),'review_methods':['Whole raw bytes/hash/size checks for current declared Sources, Python, stdlib, inputs, metadata, plans, grant and all actual/observer files.','Ordinary saved JSON full typed/value equality, ordered populations, row counts, duplicated receipt/payload joins, local counter partitions and exact deadline/ledger arithmetic.','No target imports or calls; no image/postfix parser, compiler/checker, selector/path/transition/truth legality reconstruction, reencoding, simulation, replay, rendering or process probe.'],
'historical_prelaunch_reviews':[{'pin':pin(C/'typed-component-Source-prospective-review-v2.json'),'temporal_scope':'Source/prospective-only before this actual; its unexecuted language is historical. Current codec/initializer/compiler/reference paths were subsequently exercised only by this completed finite calibration.'},{'pin':pin(C/'typed-final-grant-delta-review-v2.json'),'temporal_scope':'Point-in-time prelaunch grant/path checks; not postterminal process evidence.'},{'pin':pin(C/'typed-foundation-Source-review-v1.json'),'temporal_scope':'Still Source-only partial physical foundation; that generator was not loaded or run by this actual.'},{'pin':pin(C/'typed-codec-Source-negative-v1b.json'),'temporal_scope':'Preserved corrected Source negative and reviewer mistake, not a current runtime failure or current V2 defect.'}],
'interpretation':['One fresh authorized actual produced the full288 normal records,10 separate malformed refusals and28 diagnostic records. Saved runner finite/resource gates and external terminal gate are true under the existing trusted runtime protocol; no failure prefix was promoted.','All104 already retained top-strip paths/free-word/reference-word populations and complete palettes/problems are present. Their saved populations match; this audit does not independently rerun legality or derive the regular language.','The full69-function program is retained with272 seed nodes,63 constants,2158 instructions,940 call arguments and79040 image bits. Pinned worker Source and completed call maps support actual full Compiler, independent direct writer, full body/image comparisons and old static validator; this saved-data audit does not recompile or establish compiler/kernel semantic equivalence.','Typed carriers retain separate six-byte surrogate-pair and four-byte astral scalar spellings and reversed object entry order. No host string was reconstructed through JSON escape decode or a codec here.','Header success, known wait4 exit0, groupabsence observation, genuine log closes, stable empty logs, postchild raw custody and conservative ledger all join before the original deadlines. Root reports owned exec session48226exit0; this reviewer made no new OS probe.','Physical ledger reservation includes subsequent runner/observer metadata; current file roster exactly explains the saved pre-receipt total. Timing begins at runner Source entry, excludes observer/interpreter prelude and is not a full VM or production cost.','Literal observer ROOT_resource_accepted is false; Root narrow finite component adoption is a distinct owner action. The positive runner flag and terminal flag do not confer broader proof/FOL/GCTS/RL authority.'],
'current_limitations':['Finite selected calibration only; not exhaustive program/value/integer/string/machine language, all quota boundaries, all foreign exception classes/positions or mutation adversaries. Only the four entry callback controls and declared cases are observed.','Physical fixed interpreter/controller/BOOT/linkage and whole public-theory/target/request bridge remain absent. Partial physical foundation generator remains unexecuted, and its conditional oversized palette analysis is not rescued by this component success.','Host image roundtrip represents complete actual compiled bodies under the declared normalization; it is not a Source-to-bytecode proof, licensed closed-theory/FOL proof checker certification or unknown-certificate search/acceptance theorem.','Per-call private work counters and cumulative Root callback count are distinct finite units. Packet661804/result662628/header662636 are different cutoffs; no final total CPU/all helper calls or work comparison is inferred. Diagnostic costs are not all exported.','One instrumented cohort2.887547792s and standalone worker73039872B establish only these original finite gates, no speedup, no production/fullcold fit, no general solver, marking/RL gain or new theorem.','Runtime loader/pyc/interpreter/builtins/transitive stdlib and exclusive read-only custody remain trusted. Raw pins and callable identities are observations, not a hostile-code, continuous OS/global/default-content seal.','V1 was false/maxzero and retired without actuals. Its matching Root Source preimages were reconstructed after review, explicitly labeled; reviewer witness correction remains preserved. All old mirror negative outcomes remain rejected.','Grant is retired with0remaining; no repeat/retry, new launch or publication authority is supplied by this receipt.'],
'authorship':'One disclosed C reviewer covered Source/prospective/grant/saved scopes; C authored historical architecture/controls. Root authored selector/worker/outer and B codec; legacy Library checker/Compiler ancestry retained, not independently recertified.','tools_stopped_after_handoff':True,'audit_runtime':dict(executable=sys.executable,version=sys.version,policy='Pinned Python3.12 -I -S -B ordinary JSON/raw byte audit only')}
out=C/'typed-saved-actual-review-v2.json'
with out.open('x')as f:f.write(json.dumps(receipt,indent=2,sort_keys=True,ensure_ascii=True)+'\n')
print(json.dumps({'receipt':pin(out),'checks':len(checks),'metrics':{k:v for k,v in metrics.items()if k not in ('local_wrapped_call_started','local_wrapped_call_completed','local_wrapped_call_raised','programs')}}))
