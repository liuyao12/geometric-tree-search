import ast, hashlib, json
from pathlib import Path
D=Path('/private/tmp/gcts-fixed-vm-construction-20261020-v1')
C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1')
def desc(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
checks=[]
def ck(name, value):
 checks.append({'name':name,'passed':bool(value)})
 if not value: raise AssertionError(name)
h=json.loads((D/'handoff-v1.json').read_text())
for key in ['subject','API','arguments','source_contract','gaps','alternatives','author_static_audit','current_master','design_contract']:
 ck('whole pin '+key,desc(h[key]['path'])==h[key])
s=Path(h['subject']['path']).read_text(); t=ast.parse(s); compile(s,str(D/'fixed_vm_physical_foundation_v1.py'),'exec')
ck('no imports',not any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(t)))
constants={n.targets[0].id:ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
ck('partial status',constants['COMPLETE_INTERPRETER'] is False and constants['STATUS']=='PARTIAL_PHYSICAL_CONSTRUCTION_NO_INTERPRETER')
ck('fixed raw alphabet',constants['RAW']==('B','^','0','1',':',',',';','|','!','#'))
ck('fixed workspace length',len(constants['WORKSPACE'])==16 and len(set(constants['WORKSPACE']))==16)
ck('four terminal rows',constants['HALTS']==('DONE','DIFFERENT','REJECT','BOUND'))
expected=[('scan_to_semicolon',1,9,1),('copy_binary_word',8,44,2),('compare_binary_words',6,30,8),('increment_binary_word',3,21,2),('decode_canonical_U',17,74,5),('validate_utf8_surrogatepass_word',1785,3577,7)]
ck('manual per macro allocation agrees literal',constants['STATIC_MACRO_CENSUS']==tuple(expected))
N=sum(x[1] for x in expected); K=sum(x[2] for x in expected); K0=sum(x[3] for x in expected); M=N+4; r=10; bands=16
b=1+2*r+bands; Q=4+4*N+M; DD=3*N*b+K+N+r*M; D0=(r+1)*N+K0+r*M
actual={'assigned_microstates_N':N,'all_microstates_M':M,'micro_choices_K':K,'stationary_micro_choices_K0':K0,'fixed_workspace_bands_T':bands,'raw_symbols_r':r,'physical_alphabet_b':b,'physical_states_Q':Q,'defined_physical_transitions_D':DD,'stationary_physical_transitions_D0':D0}
ck('independent arithmetic matches literal census',actual==constants['STATIC_TOTALS'])
A=b*(Q+1); S=b*(b+1)**2+3*DD*b*(b+1)+D0*(b+1); base=S+3*b+2*A+2; total=S+12*b+2*A+18
ck('foundation retained step cardinality',S==954080288)
ck('step count exceeds 128 MiB at one byte per tile',S>134217728)
args=json.loads((D/'physical-arguments-and-census-v1.json').read_text())
ck('author census same data',args['census_derivation']['values']==actual)
ck('author retained tile arithmetic',args['census_derivation']['conditional_retained_step_tiles']==S)
funcs={n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
f=funcs['describe_fixed_vm']; ck('refusal only check then raise',len(f.body)==3 and isinstance(f.body[1],ast.Expr) and isinstance(f.body[1].value,ast.Call) and isinstance(f.body[1].value.func,ast.Name) and f.body[1].value.func.id=='check' and isinstance(f.body[2],ast.Raise) and isinstance(f.body[2].exc.func,ast.Name) and f.body[2].exc.func.id=='ConstructionIncomplete')
ck('no target program or certificate input', [a.arg for a in f.args.kwonlyargs]==['check','limits'])
ck('no try catches to replace foreign errors',not any(isinstance(n,ast.Try) for n in ast.walk(t)))
ck('no callback bearing generator wrapper',not any(isinstance(n,(ast.Yield,ast.YieldFrom)) for n in ast.walk(t)))
ck('output authority false literal',"'mathematical_authority': False" in s and "'complete_interpreter': False" in s)
ck('physical count output assertion exists',"Source/static physical census disagreement" in s)
ck('generation all state symbol pairs',"for q in range(len(states)):\n        for s in alphabet:" in s)
ck('payload marker scope explicit', 'NOT literal no-write immutability' in json.dumps(args))
ck('missing controller explicit',len(json.loads((D/'unexpanded-controller-obligations-v1.json').read_text())['absent_physical_routines'])==8)
ck('no formal or runtime cert in author arguments',args['proof_status']=='MANUAL_SOURCE_ARGUMENTS_ONLY_NOT_FORMAL_OR_RUNTIME_CERTIFICATION')
receipt={
 'schema':'fixed-vm-physical-foundation-Source-review-v1','reviewer_identity':'/root/conventional_control_review','author_identities':['/root/conventional_library'],
 'source_census_review_passed':True,'source_review_passed':True,'complete_interpreter_Source_review_passed':False,
 'outcome':'CONSISTENT_PARTIAL_SOURCE_AND_CONDITIONAL_RESOURCE_NEGATIVE','source_only':True,'component_calls':0,'scientific_calls':0,'subject_imports':0,'fixture_calls':0,'table_generation_calls':0,'simulator_calls':0,'actual_execution_authorized':False,'runtime_qualified':False,'mathematical_authority':False,
 'subject':h['subject'],'reviewed_packet':desc(D/'handoff-v1.json'),'related_pins':{k:h[k] for k in ['API','arguments','source_contract','gaps','alternatives','author_static_audit','current_master','design_contract']},
 'retained_partition_source':desc('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py'),
 'ancestry':'Reviewer authored the earlier fixed-interpreter architecture contract and historical control/helper code. Library authored this foundation and older Wang code. This independent raw Source/manual census review is not independent kernel or full VM certification.',
 'review_methods':['Whole raw descriptor verification','Full Source and packet reading','Independent manual enumeration of fixed Source allocation branches','Reviewer arithmetic over stated literal counts','AST and discarded unused compile only; no target definition executed'],
 'manual_macro_derivations':[
  {'name':'scan_to_semicolon','N_K_K0':[1,9,1],'argument':'One state, all nine raw nonfence symbols, only delimiter stop stationary.'},
  {'name':'copy_binary_word','N_K_K0':[8,44,2],'argument':'Read loop + output rewind + two literal bit writes + source rewind + three clear states; choices 3+9+2+9+21, stationary loop blank and erase blank.'},
  {'name':'compare_binary_words','N_K_K0':[6,30,8],'argument':'Read loop + exact end + two remembered-bit comparisons + two rewinds; choices 3+3+6+18, stationary 1+3+4.'},
  {'name':'increment_binary_word','N_K_K0':[3,21,2],'argument':'Carry and two rewinds; choices 3+18, stationary zero/blank carry exits.'},
  {'name':'decode_canonical_U','N_K_K0':[17,74,5],'argument':'Six prefix/count/read states, three writes, output+count rewinds, two three-state clears; choices 2+1+2+2+2+2+9+3+9+42, stationary three count ends plus two erase ends.'},
  {'name':'validate_utf8_surrogatepass_word','N_K_K0':[1785,3577,7],'argument':'Seven full depth-eight binary trees: 7 times 255 internal states, twice that many bit edges plus seven blank root exits. No input-sized state allocation.'}],
 'independent_census':actual,'derived_undefined_slots':Q*b-DD,
 'formulas_latex':{'alphabet':r'b=1+2r+T','states':r'Q=4+4N+M','transitions':r'D=3Nb+K+N+rM','stationary':r'D_0=(r+1)N+K_0+rM','step_tiles':r'S=b(b+1)^2+3Db(b+1)+D_0(b+1)'},
 'conditional_literal_counts':{'cell_alphabet_A':A,'retained_step_tiles_S':S,'old_full_palette_tiles':base,'with_Root_initializer_tiles':total,'cap_bytes':134217728,'even_one_byte_per_step_tile_exceeds_cap':True,'materialized':False,'full_VM_counts':None},
 'semantic_scope':[
 'The literal select/header/find/read/mark transport simulates one micro action under a well-formed finite workspace invariant with unique L, fixed unique headers, fences and one tagged virtual head per band. No runtime host arithmetic or opcode action appears in generated transition records.',
 'Moving the tag changes raw tape symbols. Erasing the @ prefix preserves the projected immutable source payload for source-preserving routines; this is an explicit transport representation successor, not literal no-write compliance with the earlier architecture.',
 'Binary routines require their stated distinct scratch-band, canonical-word and capacity preconditions. A BOUND or DIFFERENT path can leave scratch/head state altered; no rollback or safe arbitrary controller reuse has been established.',
 'The UTF8 byte decision tree is a finite surrogatepass range recognizer under its bit-word precondition. Complete heap-backed strings, tagged values, image BOOT and request validation remain absent.',
 'Four terminal aliases and undefined rows are not checker acceptance. The full entry point checks caller policy and then refuses; no partial substitute machine is returned.'
 ],
 'limitations':[
 'Source census PASS is not a complete interpreter PASS. All thirteen physical opcode entries, dynamic tables/registers/frames/canonical heap, BOOT, initialization, whole public/certificate parser and their linkage remain unimplemented.',
 'The retained-step count is conditional on this unminimized foundation and current fully literal Wang construction. It is not a lower bound on every fixed interpreter or a measured memory allocation.',
 'Full 69-function Source pins are context, not Source-to-bytecode, host-kernel, Unicode or public-theory licensing equivalence.',
 'ConstructionLimit has no private owner classifier. No catches mask callbacks here, but a future caller must latch exact external faults before attempting resource classification; class membership alone is insufficient.',
 'Limits and callbacks are finite construction observations, not exact CPU/allocation accounting or hostile-callback mutation protection. No constructor-failure prefix guarantee is inherited.',
 'Bitwise UTF8 minimization and certified implicit/lazy full palettes are unimplemented alternatives requiring fresh exact Sources, proofs, resource contracts and independent qualification.',
 'Current c132 master copy is supplied frozen raw context. Sections 1-5,7-8 and final conformance tail were reconciled against historical ca6ee in reviewer obligations v2; no primary reader/index or new isolated Git comparison is claimed.',
 'No generation, simulation, codec/checker/fixture call, process probe, actual grant or publication authority is supplied by this receipt.'
 ],
 'mismatch_count':0,'checks':checks,'check_count':len(checks)}
out=C/'typed-foundation-Source-review-v1.json'; out.write_text(json.dumps(receipt,indent=2,sort_keys=True,ensure_ascii=True)+'\n')
print(json.dumps({'receipt':desc(out),'checks':len(checks)}))
