from pathlib import Path
import hashlib,json
C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1');D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
p=C/'typed-saved-actual-review-v2.json';r=json.loads(p.read_bytes());sp=D/'ROOT-passive-actual-summary-v2.json';current=json.loads(sp.read_bytes());old=dict(current);scope=old.pop('root_callbacks_scope')
assert scope=='Result qualification cutoff; not final callback count or CPU-work measurement.'
reconstructed=(json.dumps(old,sort_keys=True,indent=2)+'\n').encode();assert len(reconstructed)==r['Root_passive_summary']['bytes']and hashlib.sha256(reconstructed).hexdigest()==r['Root_passive_summary']['sha256']
r['schema']='fixed-codec-initializer-saved-actual-review-v3';r['preserved_predecessor_review']=pin(p)
r['summary_metadata_amendment']={'old_summary_pin':r['Root_passive_summary'],'new_summary_pin':pin(sp),'sole_added_field':'root_callbacks_scope','value':scope,'predecessor_reconstruction':'Deleting this field and applying the exact ordinary JSON formatting reproduces the previously observed old summary hash/bytes. This is post-review reconstruction, not an archived original preimage.','scope':'Metadata-only cutoff clarification arrived after immutable V2 receipt freeze. No Source/actual/header/output/metrics/counter/gate changed, no target calls or replay. All916 existing checks and limitations retained.'}
r['Root_passive_summary']=pin(sp);r['checks'].append(dict(name='summary-only added cutoff scope reconstructs previously pinned bytes',passed=True));r['check_count']=len(r['checks'])
out=C/'typed-saved-actual-review-v3.json'
with out.open('x')as f:f.write(json.dumps(r,indent=2,sort_keys=True,ensure_ascii=True)+'\n')
print(json.dumps({'receipt':pin(out),'checks':r['check_count']}))
