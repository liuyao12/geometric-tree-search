from pathlib import Path
import json,hashlib
C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
p=C/'typed-codec-Source-negative-v1.json';r=json.loads(p.read_text());r['preserved_predecessor']=pin(p)
r['reviewer_correction']={'kind':'MANUAL_WITNESS_PATH_CORRECTION','old_example_not_valid':'encode_program_image at8bits already checks atom_max/nil via _program_snapshot->_copy->w.number; it therefore does not demonstrate unbounded header acceptance.','unchanged_required_gaps':'decode_program_image synthesizes header256 before _program_validate without the V2 check; empty decode_value_band can retain unused implicit257 seed ID. No test/function executed to establish these paths.','scope':'Corrects reviewer reasoning, not target Source/data. Original negative remains immutable; V2 owner fixes remain required.'}
f=r['findings'][0];f['manual_witness']='Without running: decode_value_band on ;: with value_count0 and seed[[0,0]] at8bits validates explicit children0 but creates unused implicit ID257 without a numeric gate. Separately, decode_program_image of a valid independent minimal main/return0 image with empty heap/constants and all explicit numeric fields below256 constructs fixed header256 while V1 _program_validate applies only equality. Neither path uses _program_snapshot. Encoding a program at8bits already rejects fixed headers via _copy and is not a witness.'
f['gap']='_heap_validate validates child numbers but stores implicit257+i IDs without checking bit length. _program_validate accepts atom_max/nil256 by strict equality without w.number; this matters on image decode, while program encode snapshots already check headers.'
out=C/'typed-codec-Source-negative-v1b.json';out.write_text(json.dumps(r,indent=2,sort_keys=True,ensure_ascii=True)+'\n');print(json.dumps(pin(out)))
