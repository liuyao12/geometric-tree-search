import ast,hashlib,json,sys
from pathlib import Path
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1');C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1')
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
checks=[]
def ck(n,x):
 checks.append(dict(name=n,passed=bool(x)))
 if not x:raise AssertionError(n)
def tree_constants(t):
 out={}
 for n in t.body:
  if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:out[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):
    if isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Name)and n.value.func.id=='dict'and not n.value.args:
     out[n.targets[0].id]={k.arg:ast.literal_eval(k.value)for k in n.value.keywords}
 return out
def defs(t):return {n.name:ast.dump(n,include_attributes=False)for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
o=json.loads((D/'component-Source-only-offer-v2.json').read_text());subject=o['subject'];plan=json.loads(Path(o['false_plan']['path']).read_text());decl=json.loads(Path(subject['declaration']['path']).read_text());closure=json.loads(Path(subject['runtime_closure']['path']).read_text());bank=json.loads(Path(subject['inputs'][0]['pin']['path']).read_text())
ck('offered descriptor',pin(D/'component-Source-only-offer-v2.json')==dict(path=str(D/'component-Source-only-offer-v2.json'),sha256='a53daba8287b2b6c5b10d32098cbbe3719efc115f40685542a72d108f117e2d5',bytes=6809))
ck('whole subject fields',set(subject)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure'})
ck('exact current subject digest',hashlib.sha256(canonical(subject)).hexdigest()==o['subject_sha256']=='2b87066c8c64b8a01875e732a1f3900bf5adee3ed10a26d99791dd3d62f81a32')
ck('whole false plan pin',pin(o['false_plan']['path'])==o['false_plan'])
ck('full false plan subject equality',{k:v for k,v in plan.items()if k!='authorization'}==subject)
ck('offer repeated Sources same',o['sources']==subject['sources'])
ck('exact ten Source roles',set(subject['sources'])=={'worker','selector','codec','tree','legacy_wang','fol_source','wire_source','combined_source','runner','observer'})
source_trees={};texts={}
for role,p in subject['sources'].items():
 ck('raw Source '+role,pin(p['path'])==p)
 raw=Path(p['path']).read_bytes();t=ast.parse(raw);compile(t,p['path'],'exec');texts[role]=raw.decode();source_trees[role]=t
for role in ['python','declaration','runtime_closure']:ck('whole '+role,pin(subject[role]['path'])==subject[role])
for item in subject['inputs']:ck('whole input '+item['id'],pin(item['pin']['path'])==item['pin'])
for p in closure['stdlib_files']:ck('whole declared stdlib '+p['path'],pin(p['path'])==p)
ck('closure full exact Source Python declaration',closure['sources']==subject['sources']and closure['python']==subject['python']and closure['declaration']==subject['declaration'])
ck('whole original limits',subject['limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576))
ck('declaration full exact limits/input',decl['limits']==subject['limits']and decl['inputs']==subject['inputs'])
wc=tree_constants(source_trees['worker']);oc=tree_constants(source_trees['runner'])
ck('worker hard outer caps',wc['OUTER_LIMITS']==subject['limits'])
ck('outer hard limits',oc['LIMITS']==subject['limits'])
ck('explicit component limits same',decl['component_limits']=={'selector':wc['SELECTOR_LIMITS'],'legacy_wang':wc['SELECTOR_LIMITS'],'codec':wc['CODEC_LIMITS']})
ck('400m callback literal',decl['checkpoint_limit']==wc['CHECKPOINT_LIMIT']==400000000)
ck('all original private numeric units retained',wc['CODEC_LIMITS']['work']==wc['SELECTOR_LIMITS']['work']==400000000 and wc['CODEC_LIMITS']['integer_bits']==4096 and wc['CODEC_LIMITS']['wire_symbols']==8000000)
for row in closure['direct_import_census']:
 t=source_trees[row['role']];imports=[]
 for n in ast.walk(t):
  if isinstance(n,ast.Import):imports +=[a.name for a in n.names]
  elif isinstance(n,ast.ImportFrom):imports.append(n.module)
 ck('direct import census '+row['role'],sorted(set(imports))==row['direct_imports'])
 ck('pinned AST '+row['role'],hashlib.sha256(ast.dump(t,include_attributes=False).encode()).hexdigest()==row['AST_sha256'])
ck('entire combined plaintext recipe',texts['wire_source']+texts['fol_source'].replace('def main(request):','def semantic_main(request):',1)==texts['combined_source'])
ck('whole69 static function count',len([n for n in source_trees['combined_source'].body if isinstance(n,ast.FunctionDef)])==69)
codec_manifest=json.loads(Path('/private/tmp/gcts-fixed-vm-codec-20261020-v1/whole-checker-manifest-v1.json').read_text())
ck('all69 original ordered names',[n.name for n in source_trees['combined_source'].body]==codec_manifest['functions_in_exact_order'])
ck('codec structural name gate same69',tree_constants(source_trees['codec'])['FULL_CHECKER_NAMES']==tuple(codec_manifest['functions_in_exact_order']))
ids=['integer-'+str(n)for n in bank['integers']]+[x['id']for x in bank['values']]+['all-thirteen-opcodes','complete-sixty-nine-function-checker']+[x['id']for x in bank['selectors']]
ck('all288 unique ordered normal IDs',ids==decl['case_ids']and len(ids)==decl['exact_cases']==288 and len(set(ids))==288)
ck('264 original declared naturals',len(bank['integers'])==264 and bank['integers'][:257]==list(range(257))and all(type(x)is int and x>=0 for x in bank['integers']))
ck('10 exact malformed integer words',bank['malformed_integers']==decl['malformed_integers']==['','1','10','100','11000','00','010','2',';','01'])
ck('six value groups',len(bank['values'])==6 and any(x.get('padding')==255 and x.get('integer_bits')==8 for x in bank['values']))
ck('surrogate versus astral codepoint input retained',any('codepoint_strings'in x and [55296,56320]in x['codepoint_strings']and [65536]in x['codepoint_strings']for x in bank['values']))
ck('ordered object entry fixture explicit',any('object_entries'in x for x in bank['values']))
ck('generic all13 opcodes explicit',set(ins[0]for f in bank['all_opcodes_program']['functions']for ins in f['code'])==set(tree_constants(source_trees['codec'])['OPCODES']))
ck('original16 selector inputs retained',len(bank['selectors'])==16 and {x['capacity']for x in bank['selectors']}=={1,2,3,4})
ck('selector domains same shape',all(type(x['capacity'])is int and x['capacity']>0 and x['suffix']and type(x['steps'])is int and x['steps']>=0 for x in bank['selectors']))
ck('declared104 top strip paths',decl['expected_selector_rows']==104)
ck('all28 explicit diagnostic rows',len(bank['diagnostics'])==28 and bank['diagnostics']==decl['diagnostics']and [r['id']for r in bank['diagnostics']]==decl['diagnostic_ids'])
ck('exact diagnostic allowed classes',{r['expected']for r in bank['diagnostics']}=={'INVALID','LIMIT','FOREIGN'}and len({r['operation']for r in bank['diagnostics']})==28)
w=texts['worker'];r=texts['runner'];ob=texts['observer']
ck('typed argument preserves exact Unicode/order/types',"x.encode('utf8','surrogatepass').hex()"in w and"if t is tuple:return ['tuple'"in w and"for k,v in x.items()"in w and"if t is bool:return ['bool',x]"in w)
ck('foreign first Root latch',"if self.first_fault is None:self.first_fault=error"in w and"s.fault_gate()"in w)
ck('actual argument guard both success and refusal',"full literal call arguments after refusal/fault"in w and"full literal call arguments unchanged"in w)
ck('four loaded components only',"for role in('selector','codec','tree','legacy_wang'):s.load(role)"in w)
ck('independent native postfix wire',"tree.encode_json(heap,value)"in w and"elif node<=256:out.append('0'+"in w)
ck('independent direct full image writer',"for byte in b'GCTSVM1':bits(byte,8)"in w and"for function in program['functions']:"in w and"if instruction[0]=='call':"in w and"entire image equals independent direct wire grammar"in w)
ck('full normalized body equality',"complete program image/body roundtrip, not name-only"in w and"complete encoder body equality"in w)
ck('whole retained Source actually compiled prospectively',"Compiler(source).declaration()"in w and"entire full checker literal Source concatenation equality"in w)
ck('full original palette retained',"palette['tiles'][:nb]"in w and"palette['color_constructors'][:nc]"in w)
ck('bound independent full palette equality',"whole palette independent of problem/capacity/horizon"in w)
ck('full unfiltered palette row reference',"for tile in palette['tiles']:"in w and"set(projected)==set(expected)"in w and"len(paths)==len(set(projected))"in w)
ck('strict head/fixed/free checks',"all fixed prefix symbols/head unchanged"in w and"all fixed suffix symbols/head unchanged"in w and"no free control heads"in w)
ck('incremental successful row journal',w.count('s.rows.append(row)')==3 and"s.rows.append(generic)"in w and"s.rows.append(checker)"in w)
ck('incremental malformed and diagnostic journals',"malformed=s.malformed"in w and"diagnostics=s.diagnostics"in w and"diagnostics.append(row)"in w)
ck('failure journal emitted without admission',"completed_malformed_integer_words=[r['bits']for r in s.malformed]"in w and"no_failed_prefix_admission=True"in w)
ck('new header check reaches decode independent image',"op=='codec_header_bits'"in w and"name='decode_program_image';limits['integer_bits']=8"in w and"reference_header_quota_image"in w)
ck('unused seed path direct empty forest',"name='decode_value_band';limits['integer_bits']=8;args=[';:'];kw=dict(value_count=0,seed_nodes=[[0,0]])"in w)
ck('padding failure both directions retained',"op=='codec_padding_encode_bits'"in w and"op=='codec_padding_decode_bits'"in w)
ck('same class external object classifiers',"Invalid('foreign same class')"in w and"DeclarationError('foreign same class')"in w and"same-class foreign invalid is not privately owned"in w)
ck('outer no substring foreign mistake',"if expected['expected']=='FOREIGN':"in r and"if 'foreign' in"not in r)
ck('complete q IDs and diagnostics joins',"q['case_ids']==declaration['case_ids']"in r and"row['expected']==expected['expected']"in r and"q['diagnostic_ids']==declaration['diagnostic_ids']"in r)
ck('positive full read and known exit180',"complete positive result/header/bytes/known-exit before180"in r and"positive_result_read_completed_ns"in ob and"worker_terminal_observed_ns"in ob)
ck('later custody210 explicitly separate',"later custody/resource checks before210"in r and"negative complete raw closure"in r)
ck('single maxone consumed before Popen',"consumed_before_Popen=True"in r and r.index("consumed_before_Popen=True")<r.index('process=subprocess.Popen'))
ck('physical plus9MiB cap',"total+9437184<=134217728"in r and"RESERVE_BYTES = 9437184"in w)
ck('expanded full byte ledger',"w['expanded_logical_result_bytes']==payload['expanded_canonical_packet_bytes']+w['result']['bytes']"in r)
ck('observer literal ROOT nonadoption false',"ROOT_resource_accepted=False"in ob)
ck('no partial VM execution permission',"complete_physical_VM=False"in w and"full_FOL_palette_qualified=False"in w)
# Exact inherited outer/observer function bodies; only module scope/version changed.
for role,name in [('runner','run_codec_initializer_once_v1.py'),('observer','observe_codec_initializer_once_v1.py')]:
 prior_text=(D/'prospective-v1-retired'/name).read_text()
 if role=='observer':
  old_scope='Finite mirror component and same-advice search comparison only; full FOL kernel and search advantage remain unqualified. Runner Source-entry epoch excludes observer/interpreter prelude. Standalone worker highwater has no Native/full-production fit authority.'
  new_scope='Finite codec/image and unknown-certificate initializer component calibration only; no physical interpreter, FOL kernel/proof search or advantage qualification. Runner Source-entry epoch excludes observer/interpreter prelude. Standalone worker highwater has no Native/full-production fit authority.'
  ck('observer only explicit prose normalization',prior_text.count(old_scope)==1 and ob.count(new_scope)==1)
  prior_text=prior_text.replace(old_scope,new_scope,1)
 prior=ast.parse(prior_text);ck('unchanged lifecycle/validator bodies after declared prose normalization '+role,defs(prior)==defs(source_trees[role]))
auth=json.loads(Path(plan['authorization']['path']).read_text());ck('whole false auth pin',pin(plan['authorization']['path'])==plan['authorization'])
ck('false maxzero exact subject',auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['subject_sha256']==o['subject_sha256']and auth['review']is None)
ck('fresh actual absent',not Path(subject['actual_directory']).exists())
ck('false observer folder absent',not Path(o['false_plan']['path']).with_name(Path(o['false_plan']['path']).stem+'-terminal-observation').exists())
ck('future authorized observer folder absent',not(D/'component-plan-authorized-v2-terminal-observation').exists())
ck('false phase no Source-call authority',o['actual_execution_authorized']is False and type(o['component_calls'])is int and o['component_calls']==0)
receipt={'schema':'wang-encoding-Source-prospective-review-v1','reviewer_identity':'/root/conventional_control_review','author_identities':['/root','/root/benchmark_design'],'review_passed':True,'source_only':True,'component_calls':0,'scientific_calls':0,'actual_execution_authorized':False,'runtime_qualified':False,
'subject':subject,'subject_sha256':o['subject_sha256'],'sources':subject['sources'],'offer':pin(D/'component-Source-only-offer-v2.json'),'false_plan':o['false_plan'],'declaration':subject['declaration'],'runtime_closure':subject['runtime_closure'],'input':subject['inputs'][0]['pin'],'current_master':pin(D/'basic-tiling-algorithm-current.md'),
'outcome':'CONDITIONAL_SOURCE_AND_FALSE_PROSPECTIVE_PASS_ONLY','mismatch_count':0,'checks':checks,'check_count':len(checks),
'parser_attribution':dict(executable=sys.executable,version=sys.version,policy='Pinned Python3.12 -I -S -B; raw hashes, ordinary JSON, AST and discarded unused compile only. No target definition or fixture executed.'),
'antecedent_reviews':[pin(C/'typed-initializer-Source-review-v1.json'),pin(C/'typed-codec-Source-review-v2.json'),pin(C/'typed-foundation-Source-review-v1.json'),pin(C/'typed-component-Source-prospective-negative-v1.json'),pin(C/'typed-codec-Source-negative-v1b.json')],
'preserved_retirement':pin(D/'ROOT-prospective-v1-retirement.json'),
'findings_resolved':[dict(id='CODEC-I1',disposition='B V2 enforces implicit seed IDs and constructed fixed headers; additional numeric fixed-field/tag/cons/padding gates. No numeric allowance increase.'),dict(id='WORKER-R1',disposition='Normal completed rows, malformed words and diagnostics accumulate incrementally; failure metadata can report their finite completed prefix. No partial admission.'),dict(id='REVIEWER-WITNESS-CORRECTION',disposition='Original V1 illustrative encode-header witness was incorrect because encode snapshot already checked fixed header. V1b identifies decode header and empty-forest unused seed as the actual paths; original reviewer mistake remains preserved.')],
'finite_population':dict(normal_cases=288,integers=264,value_groups=6,program_groups=2,selector_cases=16,expected_top_selector_paths=104,malformed_integer_words=10,diagnostics=28,full_checker_functions=69,opcodes=13),
'semantic_review':[
'Root direct image writer independently emits the fixed seven-byte low-bit-first magic, complete topological seed, constants, functions/names/arity/registers and each full opcode/operand record. Calls retain target and full argument vector. It consumes no private codec parser/writer. Complete image equality supplements codec full decoded-body equality.',
'Whole wire-wrapper plus singly renamed full FOL Source must equal the retained combined Source, which is compiled once prospectively. All69 ordered bodies/registers/constants/seed records survive explicit schema-field/tuple-row normalization and full actual comparison. No reachability trimming or target certificate is supplied.',
'Independent old Heap/encode_json and literal postfix expansion compare full value words. Exact host values use UTF8-surrogatepass hex typed carriers, preserving adjacent surrogates versus astral scalar and insertion order; raw JSON escape spellings do not decide equality.',
'Initializer returns the entire original palette plus fixed selector palette, independent of public layout/capacity/horizon for fixed machine and wire. Root enumerates every full-palette top-row color path, compares all fixed cells/no extra head and complete regular-language words with unique extension. No complete space-time run/search or universal checker palette is tested.',
'Diagnostic dispatch uses exact declared INVALID/LIMIT/FOREIGN classes. Callback sentinels invoke the real Root check first; latched policy faults bypass expected-negative classification. Same-class unowned invalid sentinels remain foreign. Missing or unexpected return rejects whole calibration.',
'Incremental journals retain finite completed IDs/malformed words/diagnostic rows when later work fails. Full successful normal records may still be unavailable if the final packet is never written; incomplete data has no admission authority.',
'Outer intake matches exact whole Source/Python/inputs/declaration/closure, max-one Root authorization and this complete review. Marker precedes worker Popen. Positive whole packet/header/read/known exit use180s Source-entry epoch; subsequent complete raw/process/log/physical/terminal custody uses210s. Original bounded cleanup,32-event/2048-poll observations, primary/error-preservation and unknown permission semantics are inherited unchanged by exact function AST comparison after normalizing only the observer scope prose literal.'
],
'limitations':[
'This receipt grants no actual execution. Root must explicitly adopt scope, create a fresh exact max-one authorization-only delta, independently verify fresh actual/observer paths and all-peer idle barrier before any worker.',
'All reviewed procedures are unexecuted in this review. Source/prospective PASS is conditional readiness, not runtime, resource, proof, compiler correctness or mathematical qualification. A later refusal/fault/unreached case rejects the whole finite calibration and is retained.',
'Only the listed288/10/28 bank is prospective coverage. No B full calibration-rule population, exhaustive program/value language, all quota boundaries, all callback positions/classes, mutation fault matrix or hostile callback domain is implied. FOREIGN tests here reach the first callback only, with PlannedForeign and unowned Invalid/DeclarationError.',
'Existing tree Compiler/Heap/validate and retained .tree bodies are trusted legacy ancestry, not freshly independent checker/lowering/kernel recertification. The full69 image roundtrip demonstrates representation of actual compiled bodies under this profile, not that they implement the host kernel or licensed mathematical theory.',
'Physical foundation is explicitly incomplete/refuses full VM and is NOT loaded or generated. Physical BOOT, complete thirteen-opcode interpreter/linkage, canonical transport restoration, public3/free2 request bridge, program-to-machine simulation and final proof/point correspondence remain absent.',
'Initializer palette is machine-and-fixed-wire dependent, independent of target and finite bound. Literal full palette times every board origin is retained; this finite selector study is not general fractional/shared/mixed-generation/infinite GCTS, learning, RL, theorem discovery or benefit evidence.',
'Root cumulative400m counts check entries. Codec/selector work400m are new per-call private units; no aggregate sum of every helper operation or CPU instruction is claimed. Call maps count explicitly wrapped starts/completions/refusals, and compiler/verifier/oracle field labels are narrower local instrumentation, not all internal functions or total work.',
'Worker highwater is standalone only, no Native/full production memory claim. JSON guards/snapshots/reference carriers/full outputs and Python native operations remain charged by actual wall/RSS/physical gates; no fit, speedup or no-copy claim is made.',
'Exclusive read-only callbacks and private raw-pinned SourceFileLoader/interpreter/pyc/builtins/transitive stdlib trust are required. Recursive function/code/default identity observations are not initial compiled-object, mutable-default-content, closure, global or continuous OS integrity seals.',
'Best-effort failure prefix/error attachment may be unavailable under diagnostic/allocation failure. Original active error and outer negative outcome prevail; no universal provenance guarantee or retry/reconstruction is authorized.',
'V1 metadata was false/maxzero and had0actuals. Its offered Root Source preimages were later reconstructed to matching earlier hashes, explicitly after review, not saved contemporaneous snapshots. Historical references and reviewer correction are preserved; no old mirror failure or grant is rescued.',
'Observer literal ROOT_resource_accepted remains false. Any future finite Root adoption must be a separate explicit saved-data judgment with exact terminal/custody gates, and cannot promote wider mathematical authority.',
'Current master is supplied c132 raw copy; this reviewer did not read primary reader/index or perform new primary hydration. Historical ca6ee obligations remain lineage only; corepoint obligations were reconciled in C obligationsv2.',
'No rendering, publishing, process probes, signals, worker launch, subject imports, codec/compiler/generator/checker/helper/fixture calls, simulation, opaque decoding, truth replay or new grants were performed.'
],
'authorship':'Root authors selector/worker/outer/prospective metadata; B authors codec. Library authors legacy tree/Wang/checker lineage and partial physical foundation. Reviewer authored earlier fixed-VM architecture and historical controls/helpers. One disclosed reviewer covers current combined scopes, with independent B/Root authorship and inherited provenance; no self/kernel certification claim.'}
out=C/'typed-component-Source-prospective-review-v2.json';out.write_text(json.dumps(receipt,indent=2,sort_keys=True,ensure_ascii=True)+'\n');print(json.dumps({'receipt':pin(out),'checks':len(checks)}))
