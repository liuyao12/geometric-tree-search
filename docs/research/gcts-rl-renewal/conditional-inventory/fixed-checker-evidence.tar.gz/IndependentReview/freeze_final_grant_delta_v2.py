from pathlib import Path
import hashlib,json,sys
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1');C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1')
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
checks=[]
def ck(n,x):
 checks.append(dict(name=n,passed=bool(x)))
 if not x:raise AssertionError(n)
planp=D/'component-plan-authorized-v2.json';authp=D/'component-authorization-once-v2.json';falsep=D/'component-plan-false-v2.json'
ck('authorized plan offered exact pin',pin(planp)==dict(path=str(planp),sha256='cbc7f9f3adff3901b814ecd3c3fea2ff2f293333a702bae83fe7f54a4d1eef36',bytes=4104))
ck('Root authorization offered exact pin',pin(authp)==dict(path=str(authp),sha256='d7c1a134b6520b1a59f8f6eb91ec1c73558b88e43627fb758cc94678d40fbf79',bytes=810))
plan=json.loads(planp.read_text());false=json.loads(falsep.read_text());auth=json.loads(authp.read_text());subject={k:v for k,v in plan.items()if k!='authorization'}
ck('only plan authorization descriptor changed',[k for k in plan if plan[k]!=false[k]]==['authorization']and set(plan)==set(false))
ck('full nine field subject retained',len(subject)==9 and subject=={k:v for k,v in false.items()if k!='authorization'})
ck('exact unchanged subject digest',hashlib.sha256(canonical(subject)).hexdigest()=='2b87066c8c64b8a01875e732a1f3900bf5adee3ed10a26d99791dd3d62f81a32'==auth['subject_sha256'])
ck('true plan references whole true grant',plan['authorization']==pin(authp))
ck('grant exact seven fields',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'})
ck('Root author/schema',auth['author_identity']=='/root'and auth['schema']=='ROOT-wang-encoding-authorization-v1')
ck('true exact maxone',auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1)
review=json.loads(Path(auth['review']['path']).read_text());ck('whole current review raw pin',pin(auth['review']['path'])==auth['review']==dict(path=str(C/'typed-component-Source-prospective-review-v2.json'),bytes=30522,sha256='9537d3fca28d15642f35e3328f6d5b3431018da5584edd9c4f724c6863760eb2'))
ck('review literal ABI',review['schema']=='wang-encoding-Source-prospective-review-v1'and review['reviewer_identity']=='/root/conventional_control_review'and review['review_passed']is True and review['source_only']is True and type(review['component_calls'])is int and review['component_calls']==0 and review['actual_execution_authorized']is False)
ck('review binds entire same subject',review['subject']==subject and review['subject_sha256']==auth['subject_sha256']and review['sources']==subject['sources'])
for name,p in subject['sources'].items():ck('current whole Source '+name,pin(p['path'])==p)
for key in ['python','declaration','runtime_closure']:ck('current whole '+key,pin(subject[key]['path'])==subject[key])
for item in subject['inputs']:ck('current whole original input '+item['id'],pin(item['pin']['path'])==item['pin'])
closure=json.loads(Path(subject['runtime_closure']['path']).read_text());decl=json.loads(Path(subject['declaration']['path']).read_text())
ck('same complete closure bindings',closure['python']==subject['python']and closure['sources']==subject['sources']and closure['declaration']==subject['declaration'])
for p in closure['stdlib_files']:ck('current declared stdlib '+p['path'],pin(p['path'])==p)
ck('same declared input and caps',decl['inputs']==subject['inputs']and decl['limits']==subject['limits'])
ck('whole finite bank count288',decl['exact_cases']==288 and len(decl['case_ids'])==288 and len(set(decl['case_ids']))==288)
ck('10 malformed and28 diagnostics exact',len(decl['malformed_integers'])==10 and len(decl['diagnostics'])==28)
ck('unchanged original outer hard gates',subject['limits']==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576))
falseauth=json.loads(Path(false['authorization']['path']).read_text());ck('false plan auth pin unchanged',pin(false['authorization']['path'])==false['authorization'])
ck('preserved false grant maxzero',falseauth['actual_execution_authorized']is False and type(falseauth['maximum_actual_invocations'])is int and falseauth['maximum_actual_invocations']==0 and falseauth['subject_sha256']==auth['subject_sha256'])
ck('grant schema/author/subject unchanged',{k:auth[k]for k in ['schema','author_identity','subject_sha256']}=={k:falseauth[k]for k in ['schema','author_identity','subject_sha256']})
actual=Path(subject['actual_directory']);observer=planp.parent/(planp.stem+'-terminal-observation')
ck('current actual directory absent',not actual.exists())
ck('current consumed marker absent',not(actual/'CONSUMED.json').exists())
ck('current worker marker absent',not(actual/'WORKER_CONSUMED.json').exists())
ck('authorized terminal observer directory absent',not observer.exists())
ck('observer consumed marker absent',not(observer/'CONSUMED.json').exists())
ck('fresh paths match reviewed suffix',actual==D/'actual-components-v2'and observer==D/'component-plan-authorized-v2-terminal-observation')
retired=json.loads((D/'ROOT-prospective-v1-retirement.json').read_text());ck('V1 remains zero-actual retired',retired['retired']is True and retired['actual_authorized']is False and retired['actual_invocations']==0 and retired['grant_maximum']==0)
r={'schema':'fixed-codec-initializer-final-grant-delta-review-v2','reviewer_identity':'/root/conventional_control_review','final_grant_delta_review_passed':True,'metadata_only':True,'source_only':True,'component_calls':0,'scientific_calls':0,'subject_imports':0,'actual_execution_authorized':False,
'subject':subject,'subject_sha256':auth['subject_sha256'],'authorized_plan':pin(planp),'authorized_plan_full':plan,'authorization':pin(authp),'authorization_full':auth,'false_plan':pin(falsep),'false_authorization':false['authorization'],'source_prospective_review':auth['review'],'sources':subject['sources'],'declaration':subject['declaration'],'runtime_closure':subject['runtime_closure'],'inputs':subject['inputs'],'retirement_v1':pin(D/'ROOT-prospective-v1-retirement.json'),
'freshness':{'actual_directory':str(actual),'actual_absent':True,'actual_consumed_absent':True,'worker_consumed_absent':True,'authorized_observer_directory':str(observer),'observer_absent':True,'observer_consumed_absent':True,'scope':'Point-in-time ordinary filesystem metadata checks only, not an OS/process/continuous freshness probe.'},
'check_count':len(checks),'checks':checks,'mismatch_count':0,
'limits_and_authority':['The exact nine-field subject is unchanged. The sole plan delta is the Root authorization descriptor; Root false/maxzero became true/exactmaxone and binds the complete existing review. No Source/input/declaration/closure/Python/cap drift observed.',
'Only one fresh288normal+10malformed+28diagnostic component calibration is in this Root grant scope. No physical foundation, mirror retry, prefix rescue, proof search, physical VM/FOL qualification, cap raise or wider benefit authority is included.',
'Review limitations9537d3… are preserved: host representation/initializer finite scope, Source-only69body attribution not compiler/kernel semantics, trusted Source loading/exclusive callback custody, per-call private units distinct from cumulative Root callbacks, no runtime PASS from this metadata receipt.',
'Root owns grant authority and must separately freeze fresh all-peer-idle/path barrier and inspect its successful completion before launching. This receipt is a delta review, not a launcher or independent grant. All target/compiler/codec/generator/helper/checker/fixture calls, process probes and signals are zero here.',
'Original180s positive worker/read/knownexit and210s later whole custody/terminal gates,1GiB standalone worker, both128MiB logical/physical constraints and9MiB metadata reserve remain exact. Actual failures cannot be admitted or retried by this receipt.',
'One reviewer covers Source/prospective/delta roles, disclosed historical architecture/control authorship. Root authored selector/worker/outer/plans; B codec; inherited Library checker/Compiler ancestry stays scoped. V1 negatives and reviewer witness correction remain preserved.'],
'tools_stopped_after_handoff':True,'parser_metadata':{'executable':sys.executable,'version':sys.version,'method':'Ordinary JSON/raw-byte/hash and explicit absent-path checks only; no AST re-review or target imports.'}}
out=C/'typed-final-grant-delta-review-v2.json'
with out.open('x')as f:f.write(json.dumps(r,sort_keys=True,indent=2,ensure_ascii=True)+'\n')
print(json.dumps({'receipt':pin(out),'checks':len(checks)}))
