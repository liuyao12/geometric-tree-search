import ast,hashlib,json
from pathlib import Path
D=Path('/private/tmp/gcts-fixed-vm-codec-20261020-v1');C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1')
def desc(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
h=json.loads((D/'handoff-v1.json').read_text());checks=[]
def ck(n,x):
 checks.append({'name':n,'passed':bool(x)})
 if not x:raise AssertionError(n)
for key in ['Source','API','Source_static_audit','calibration_proposal','design_contract','master','reasoning','whole_checker_manifest']:ck('whole pin '+key,desc(h[key]['path'])==h[key])
s=Path(h['Source']['path']).read_text();t=ast.parse(s);compile(s,str(D/'fixed_vm_codec_v1.py'),'exec')
ck('no subject imports',not any(isinstance(n,(ast.Import,ast.ImportFrom))for n in ast.walk(t)))
ck('no generator yield seams',not any(isinstance(n,(ast.Yield,ast.YieldFrom))for n in ast.walk(t)))
f={n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
for name in ['encode_integer','decode_integer','encode_program_image','decode_program_image','encode_value_band','decode_value_band']:
 body=f[name];ck('best effort prefix bare rethrow '+name,any(isinstance(n,ast.Raise)and n.exc is None for n in ast.walk(body)))
ck('strict owner classifiers',"type(error)is Invalid and error.owner is _OWNER"in s and"type(error)is ResourceLimit and error.owner is _OWNER"in s)
ck('whole input rereads',"caller program changed"in s and"caller value/seed changed"in s and"caller seed changed"in s)
ck('full program image equality',"full image encode/decode equality"in s and"entire canonical image equality"in s)
ck('full typed value and canonical wire equality',"full value encode/decode equality"in s and"full canonical band equality"in s)
ck('strict type and order comparator',"if type(a)is not type(b):return False"in s and"zip(a.items(),b.items())"in s)
ck('canonical UTF8 gate',"raw.decode('utf-8','surrogatepass')"in s and"UTF-8 byte roundtrip"in s)
ck('all opcode grammar',"OPCODES=('const','move','cons','head','tail','pair','atom','succ','not',"in s and"'branch','jump','call','return')"in s)
ck('seed prefix retained',"heap=_Heap(_seed_snapshot(seed,w),w)"in s)
ck('all code validated no trimming',"for function in functions:"in s and"for ins in code:"in s)
api=json.loads((D/'API-v1.json').read_text());ck('identified quota wording preserved', 'generated heap IDs and fixed atoms'in api['limits']['integer_bits'])
receipt={
'schema':'fixed-vm-codec-Source-review-v1','reviewer_identity':'/root/conventional_control_review','author_identities':['/root/benchmark_design'],
'source_review_passed':False,'outcome':'BOUNDED_SOURCE_NEGATIVE_INTEGER_BIT_QUOTA_CLOSURE','source_only':True,'component_calls':0,'scientific_calls':0,'subject_imports':0,'fixture_calls':0,'codec_calls':0,'actual_execution_authorized':False,'runtime_qualified':False,'mathematical_authority':False,
'subject':h['Source'],'reviewed_handoff':desc(D/'handoff-v1.json'),'related_pins':{k:h[k]for k in ['API','Source_static_audit','calibration_proposal','design_contract','master','reasoning','whole_checker_manifest']},
'ancestry':'Reviewer authored fixed-interpreter architecture and historical controls. B independently authored this codec. Raw Source/manual representation review does not certify the checker, compiler lowering or a physical interpreter.',
'methods':['Complete Source and API/reasoning/calibration reading','Whole raw descriptor hashes','AST and unused compile only','Manual grammar, heap, tagged-value, exception and quota reasoning; no examples or definitions evaluated'],
'findings':[{'id':'CODEC-I1','severity':'required_before_API_claim_or_prospective_PASS','path':h['Source']['path'],'lines':[181,185,192,194],
'claim':'API integer_bits bounds checked/decoded numbers, generated heap IDs and fixed atoms.',
'gap':'_heap_validate validates child numbers but stores implicit 257+i IDs without checking their bit length. _program_validate accepts atom_max/nil 256 by strict equality without w.number. A tightened integer_bits can therefore admit these documented bounded quantities, including unused seed IDs, beyond its bound.',
'manual_witness':'Without running: a generic one-input main with return register0, empty constants and seed [[0,0]] uses only small explicit image numbers. With integer_bits8 and otherwise sufficient limits, header256 and implicit seed ID257 are retained although they need9bits; no current validation site tests them against integer_bits.',
'repair':'Either enforce the stated integer_bits bound on fixed atom headers and every assigned seed ID before acceptance/index publication (new IDs already use w.number), or explicitly narrow the field definition and prospective expectations. Preserve V1 and bind exact successor Sources/metadata before any grant.',
'not_claimed':'No numeric Root allowance must rise; no actual or fixture has been run; this finding is a quota/API mismatch rather than evidence that a proof or image was accepted.'}],
'static_consistent_paths':[
'Self-delimiting canonical natural code, fixed low-bit-first magic/opcodes, full operand/arity/unreachable-code validation and whole normalized program reencode/decode equalities are present.',
'Canonical topological unique-pair seed validation and literal constant/function/code order are preserved. Only native heap pair tuples and schema dictionary field order are explicitly normalized.',
'Host values retain exact bool/int/null/list/dict/string distinctions and dictionary insertion order. Tagged structures reject negative zero, invalid tags/bodies, improper lists and duplicate keys; full wire and full typed values are compared.',
'UTF8-surrogatepass uses byte decode/reencode equality. A two-codepoint surrogate pair remains six bytes, a supplementary scalar four; host JSON escape parsing is not used as identity.',
'Limits require all16 positive exact-int keys. Work/data_items are invocation counters; iterative stacks, separate cardinality caps and writer-per-symbol bounds exist. This does not establish physical fit or exact CPU/allocation accounting.',
'Foreign BaseExceptions escape by bare rethrow; prefix attachment is guarded. UnicodeError translation only encloses native raw.decode without callbacks. Constructor prefix explicitly marks unavailable lower-bound cost.',
'Public success performs normalized full mutable argument rereads and final direct callback, under exclusive/read-only callback custody; no universal temporal mutation/OS seal is claimed.'
],
'prospective_requirements':[
'Use the exact whole69 retained plaintext and authenticated Compiler, retain complete native program, explicit tuple/schema normalization, image and full decoded body equality. Name order alone is not body correspondence.',
'Independent old Heap/postfix reference must distinguish semantic tagged tree/wire equality from incidental allocation order of newly constructed nonseed heap IDs. All seed records remain exact prefix.',
'Preserve string codepoint or surrogatepass-byte identity in input/results/guards. JSON escape decoding can combine an adjacent surrogate pair and must not decide exact host value identity.',
'Finite calibration must state its actual selected domain. The B12-rule proposal is unadopted selection design, not coverage inherited by a different Root whole bank.',
'No codec success filters selector free bits. Actual physical BOOT, complete fixed VM, public theory licensing and final reduction remain separate absent artifacts.',
'Fresh whole Source/input/declaration/closure/plan review, Root max-one grant and absent-path/idle barrier are still required. Current offered false/max0 tuple has no execution authority.'
],
'limitations':['Source-only no runtime roundtrip or malformed-input result is asserted.','Private ownership is cooperative Source custody, not a hostile Python/OS seal.','Full checker name/order gate is structural only; no FOL proof, universality, physical interpreter, performance or GCTS/RL benefit is admitted.','Master is current supplied raw c132 copy; no primary reader/index content was accessed.'],
'mismatch_count':1,'checks':checks,'check_count':len(checks)}
out=C/'typed-codec-Source-negative-v1.json';out.write_text(json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=True)+'\n');print(json.dumps({'receipt':desc(out),'checks':len(checks)}))
