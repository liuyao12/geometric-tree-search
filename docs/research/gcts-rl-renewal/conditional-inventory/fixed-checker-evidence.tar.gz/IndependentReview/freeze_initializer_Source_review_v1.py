"""C static initializer Source review; no offered function is imported/run."""
import ast
import copy
import hashlib
import json
from pathlib import Path
C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1');D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
def pin(p):
 p=Path(p);r=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
checks=[]
def check(name,v):checks.append(dict(name=name,passed=bool(v)))
def defs(p):return {n.name:n for n in ast.parse(Path(p).read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def dump(n):return ast.dump(n,include_attributes=False)
source=D/'wang_unknown_certificate_initializer_v1.py';raw=source.read_bytes();text=raw.decode();tree=ast.parse(raw);compile(raw,str(source),'exec',dont_inherit=True)
check('exact frozen Source',pin(source)['sha256']=='02cf1718e09c1eadb4eda4811436e1c7139cb2e1c255f9d73894e0e3b5d21b43' and len(raw)==27193)
api=load(D/'initializer-API-v1.json');check('exact API Source binding',api['source']==pin(source))
check('no module imports',not any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(tree)))
check('no generators or async callback wrappers',not any(isinstance(n,(ast.Yield,ast.YieldFrom,ast.AsyncFunctionDef,ast.Await)) for n in ast.walk(tree)))
oldpath=Path('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py');old=defs(oldpath);new=defs(source)
class Normalize(ast.NodeTransformer):
 def visit_Name(self,n):
  if n.id=='_invalid':n.id='DeclarationError'
  return n
 def visit_Call(self,n):
  self.generic_visit(n)
  if isinstance(n.func,ast.Name) and n.func.id=='CompileLimit':n.keywords=[kw for kw in n.keywords if kw.arg!='_owner']
  return n
for name in ('_integer','_machine','_machine_record','_configuration','_local_update','_Work'):
 check('legacy semantic body '+name,dump(Normalize().visit(copy.deepcopy(new[name])))==dump(old[name]))
palette=copy.deepcopy(new['_palette'])
check('tile preflight before cells or product',ast.get_source_segment(text,palette.body[1]).startswith('cardinality = _cardinality') and ast.get_source_segment(text,palette.body[2]).startswith("work.bound('tiles'"))
del palette.body[1:3]
check('old full palette generation raw AST after countpreflight',dump(palette)==dump(old['_palette']))
for newname,oldname in [('compile_legacy_palette','compile_palette'),('compile_legacy_finite_problem','compile_finite_problem')]:
 node=Normalize().visit(copy.deepcopy(new[newname]));node.name=oldname
 check('renamed legacy API body '+oldname,dump(node)==dump(old[oldname]))
check('strict private invalid helper',"return DeclarationError(message, _owner=_OWNER)" in text and "return type(error) is DeclarationError and error._owner is _OWNER" in text)
check('strict private limit helper',"return type(error) is CompileLimit and error._owner is _OWNER" in text)
check('all internal invalid raises use helper',all(not (isinstance(n.exc,ast.Call) and isinstance(n.exc.func,ast.Name) and n.exc.func.id=='DeclarationError') for n in ast.walk(tree) if isinstance(n,ast.Raise)))
check('foreign callbacks never caught',not any(isinstance(n,ast.Try) for n in ast.walk(tree)))
check('machine AND fixedwire uniformity explicit','machine AND' in text and 'One exact whole machine AND one fixed wire mapping' in api['uniformity'])
check('four distinct alphabet symbols and nonacceptBOOT',"len(set(values + (blank,))) != 4" in text and 'if initial == accepting:' in text)
check('fixedband strict type and exact head',"type(cell) is not tuple" in text and "if cell[1] != initial:" in text and 'if heads != 1:' in text)
check('free capacity strict positive and suffix closes',"type(certificate_capacity) is not int or certificate_capacity < 1" in text and "if not suffix:" in text)
check('exact horizon strict nonnegative',"type(steps) is not int or steps < 0" in text and 'height = steps + 2' in text)
check('all north constructors fixedroles only',all(s in text for s in ("('init_north', 'plain', symbol)","('init_north', 'head', initial, symbol)","('init_north', 'free')","('init_north', 'frame', 'left')","('init_north', 'frame', 'right')")))
check('horizontal phases headseen full8',"for phase in ('PRE', 'ACTIVE', 'PAD', 'POST'):" in text and 'for head_seen in (0, 1):' in text)
check('full tile count preflight before base palette',"counts = _cardinality(machine, work)\n    work.bound('tiles', counts['total_tiles'])\n    palette = _palette(machine, work)" in text)
check('cardinality charges every transition row',"for row in transitions:\n        work.step()\n        stationary += int(row[4] == 0)" in text)
check('cardinality exact reviewed step polynomial',"alphabet * (alphabet + 1) * (alphabet + 1)\n             + 3 * defined * alphabet * (alphabet + 1)\n             + stationary * (alphabet + 1)" in text)
check('selector exact count expressions',"initializer_tiles=9 * alphabet + 16" in text and "initializer_new_colors=2 * alphabet + 11" in text)
check('describing does not request overcap palette',not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('_palette','_selector_palette') for n in ast.walk(new['describe_unknown_palette_cardinality'])) and 'palette_materialized=False' in ast.get_source_segment(text,new['describe_unknown_palette_cardinality']))
check('whole original machine/wire/fixedbands rechecked',all(s in text for s in ("_machine(machine, work) != owned","_wire(wire_specification, owned, work) != wire","_fixed_band(fixed_prefix, owned, work) != prefix","_fixed_band(fixed_suffix, owned, work) != suffix")))
check('full point universe explicit and no filtered origins',"admissible_origins=[point[:] for point in required]" in text and "every full palette tile ID at every declared origin; translations only" in text)
check('publicproblem and fullVM nonauthority flags retained',"public_problem_semantics_established=False" in text and "universal_interpreter_established=False" in text and "complete_fixed_interpreter_established=False" in text)
currentmaster=D/'basic-tiling-algorithm-current.md';check('current master c132 exact',pin(currentmaster)['sha256']=='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9' and pin(currentmaster)['bytes']==21657)
reconstructed=D/'wang_unknown_certificate_initializer_PREFREEZE_v0.py';cust=load(D/'prefreeze-reconstruction-custody-v0.json')
check('prefreeze reconstructed honestly labeled',pin(reconstructed)['sha256']==cust['sha256']=='8621aaeb39f5afc08e4bee16490a2d1fca0bc3d83f231ae72d9d9546f2e31e8e' and cust['reconstructed_after_review_findings'] is True and cust['not_a_saved_actual_preimage'] is True)
if any(not c['passed'] for c in checks):print(json.dumps([c for c in checks if not c['passed']]));raise RuntimeError('C Source static mismatch')
out=C/'typed-initializer-Source-review-v1.json'
record=dict(schema='fixed-unknown-certificate-initializer-Source-review-v1',reviewer_identity='/root/conventional_control_review',source_review_passed=True,source_only=True,component_calls=0,scientific_calls=0,subject_imports=0,fixture_calls=0,compiler_calls=0,actual_execution_authorized=False,scientific_acceptance=False,full_interpreter_established=False,runtime_qualified=False,Source=pin(source),API=pin(D/'initializer-API-v1.json'),master=pin(currentmaster),legacy_compiler=pin(oldpath),prefreeze_reconstructed=pin(reconstructed),prefreeze_custody=pin(D/'prefreeze-reconstruction-custody-v0.json'),design_obligations=pin(C/'selector-VM-obligations-v2.json'),check_count=len(checks),checks=checks,mismatch_count=0,findings=[],manual_Source_conclusions=['Selector root/frame/type constructors and8state phase×head automaton enforce exactly one BOOT head and the entire freebit*;blank* language, no payload classifier. Fixed suffix/nonzero free capacity make semicolon mandatory. Literal data bits/semicolons in fixed bands do not act as free transitions.','Exactly9b+16 initializer tiles and2b+11 new colors, with complete old palette retained. Old S=b(b+1)^2+3Db(b+1)+D0(b+1), total S+12b+2b(Q+1)+18. All declared states and transitions count, not only reachable ones. Counts checked by Source algebra, not generator calls.','New count API does not materialize cells/triples/palette and intentionally can report a full count above tilecap. Generation preflights whole retained output before allocation, then retains naive A(A+1)^2 triple loop; accepted output cardinality does not promise time/work fit. New preflight/invalid ownership changes callback/work profile, so no old exact-trace qualification is inherited.','North initialization constructors are never emitted south; below the selector, the unchanged pair/seen/frame rules give exactHtransitions plus one final whole acceptance collector. Early collector cannot continue through remaining stop/done boundaries. This is generic given-machine boundary correspondence, not a complete VM/refinement/theorem proof.','Compile_unknown_problem accepts full fixed prefix/suffix tuples and one free interval; it neither chooses a proof nor checks tree/postfix syntax. It does not certify that arbitrary fixed bands really encode a complete checker/public problem. Exact external image/codec/BOOT/workspace binding remains mandatory.','Both initially reported issues are resolved in frozen Source/API: private owner tags distinguish external same-class invalids, and uniformity is explicitly machine AND fixed wire. Old8621candidate was reconstructed after findings and labeled, not called a saved actual preimage. Header-only inheritance from e5c8 includes same Source logic; the earlier candidate is not an actual.'],limitations=['This is a narrow Source-only PASS, not a prospective subject/grant or runtime/size qualification. No offered helper or compiler function, including the count function, was imported or called; AST and discarded unused compile only.','Generic machine table is supplied, not authored/verified by this initializer. The partial L foundation refuses complete VM linkage and its reported retained palette count is too large under unchanged128MiB; no full interpreter exists by virtue of this pass.','Read-only callbacks/exclusive original ownership remain preconditions. New predicates use private module provenance, not a hostile security seal; all foreign callback identities escape because no catch/generator wrapper surrounds them. Cooperative per-step callbacks and bounded full-input rereads do not prove temporal mutation seals/hard preemption.','Finite translation-only unit-center point specialization/allroots0; generic engine must separately maintain full palette×origins/remote dependencies, global DEAD/FORCED/earliest scheduler and exact rollback. No learner/RL/general/infinite/fractional/shared-support claim.','Root alone may later offer a whole69Source-to-image/codec/initializer calibration with a fresh full reviewed subject, controller, exact original caps, Root maxone grant/freshness delta and all-idle barrier. No mirror-run rescue, partialVM run or consumed retry authorized here.'],stop_state='Await separately frozen foundation/codec/worker/prospective scopes; no current actual authority.')
if out.exists():raise RuntimeError('immutable Source receipt exists')
out.write_bytes(json.dumps(record,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n');print(json.dumps(pin(out),sort_keys=True))
