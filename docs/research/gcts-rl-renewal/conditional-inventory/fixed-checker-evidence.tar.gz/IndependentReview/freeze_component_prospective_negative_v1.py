import ast,hashlib,json,sys
from pathlib import Path
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1');C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
retirement=json.loads((D/'ROOT-prospective-v1-retirement.json').read_text())
reconstructed={r['role']:r for r in retirement['source_reconstructions']}
def source_path(role):
 return Path(reconstructed[role]['path'])if role in reconstructed else Path(s['sources'][role]['path'])
o=json.loads((D/'component-Source-only-offer-v1.json').read_text());s=o['subject'];p=json.loads(Path(o['false_plan']['path']).read_text());d=json.loads(Path(s['declaration']['path']).read_text());cl=json.loads(Path(s['runtime_closure']['path']).read_text());bank=json.loads(Path(s['inputs'][0]['pin']['path']).read_text());checks=[]
def ck(n,x):
 checks.append(dict(name=n,passed=bool(x)))
 if not x:raise AssertionError(n)
ck('offer false plan raw pin',pin(o['false_plan']['path'])==o['false_plan'])
ck('whole nine field subject',len(s)==9 and {k:v for k,v in p.items()if k!='authorization'}==s)
ck('canonical whole subject SHA',hashlib.sha256(canonical(s)).hexdigest()==o['subject_sha256'])
for name,source in s['sources'].items():
 observed=pin(source_path(name));ck('whole Source observed preimage '+name,observed['sha256']==source['sha256']and observed['bytes']==source['bytes'])
for name in ['python','declaration','runtime_closure']:ck('whole '+name,pin(s[name]['path'])==s[name])
for item in s['inputs']:ck('whole input '+item['id'],pin(item['pin']['path'])==item['pin'])
ck('exact closure bindings',cl['sources']==s['sources']and cl['python']==s['python']and cl['declaration']==s['declaration'])
ck('exact declared input',d['inputs']==s['inputs'])
for row in cl['direct_import_census']:
 source=source_path(row['role']).read_bytes();t=ast.parse(source);compile(t,row['source']['path'],'exec')
 ck('pinned parser AST '+row['role'],hashlib.sha256(ast.dump(t,include_attributes=False).encode()).hexdigest()==row['AST_sha256'])
for row in cl['stdlib_files']:ck('whole stdlib '+row['path'],pin(row['path'])==row)
ids=['integer-'+str(n)for n in bank['integers']]+[x['id']for x in bank['values']]+['all-thirteen-opcodes','complete-sixty-nine-function-checker']+[x['id']for x in bank['selectors']]
ck('complete ordered normal bank',ids==d['case_ids']and len(ids)==d['exact_cases']==287 and len(set(ids))==287)
ck('all natural declared inputs',len(bank['integers'])==264 and all(type(x)is int and x>=0 for x in bank['integers']))
ck('all malformed raw inputs',bank['malformed_integers']==d['malformed_integers']and len(bank['malformed_integers'])==10)
ck('all diagnostics exact fields',bank['diagnostics']==d['diagnostics']and[x['id']for x in bank['diagnostics']]==d['diagnostic_ids']and len(d['diagnostics'])==24)
ck('all selector cases',len(bank['selectors'])==16 and all(x['capacity']in(1,2,3,4)for x in bank['selectors']))
ck('whole Source concat',Path(s['sources']['wire_source']['path']).read_text()+Path(s['sources']['fol_source']['path']).read_text().replace('def main(request):','def semantic_main(request):',1)==Path(s['sources']['combined_source']['path']).read_text())
a=json.loads(Path(p['authorization']['path']).read_text());ck('authorization false maxzero',a['actual_execution_authorized']is False and type(a['maximum_actual_invocations'])is int and a['maximum_actual_invocations']==0 and a['subject_sha256']==o['subject_sha256'])
ck('actual path absent',not Path(s['actual_directory']).exists())
ck('false observer path absent',not Path(o['false_plan']['path']).with_name(Path(o['false_plan']['path']).stem+'-terminal-observation').exists())
w=source_path('worker').read_text();outer=source_path('runner').read_text()
ck('typed exact strings guard',"x.encode('utf8','surrogatepass').hex()"in w and "if t is tuple:return ['tuple'"in w and "for k,v in x.items()"in w)
ck('independent native reference and all69 compile',"tree.encode_json(heap,value)"in w and"Compiler(source).declaration()"in w)
ck('no full VM foundation loaded',"for role in('selector','codec','tree','legacy_wang'):s.load(role)"in w)
ck('whole top row literal enumeration',"for tile in palette['tiles']:"in w and"set(projected)==set(expected)"in w)
ck('outer exact diagnostic class selector',"if expected['expected']=='FOREIGN':"in outer and"if 'foreign' in"not in outer)
ck('positive180 and later210 literal gates',"complete positive result/header/bytes/known-exit before180"in outer and"later custody/resource checks before210"in outer)
ck('bounded inherited cleanup observations',"CLEANUP_EVENT_LIMIT=32"in outer and"CLEANUP_POLL_LIMIT=2048"in outer and"negative complete raw closure"in outer)
receipt={'schema':'wang-encoding-Source-prospective-review-v1','reviewer_identity':'/root/conventional_control_review','author_identities':['/root','/root/benchmark_design'],'review_passed':False,'source_only':True,'component_calls':0,'scientific_calls':0,'actual_execution_authorized':False,'runtime_qualified':False,'subject':s,'subject_sha256':o['subject_sha256'],'sources':s['sources'],'offer':pin(D/'component-Source-only-offer-v1.json'),'retirement':pin(D/'ROOT-prospective-v1-retirement.json'),'source_preimage_custody':dict(classification='Root reconstructed matching earlier observed Source after review; not contemporaneous saved preimages',reconstructed=[dict(role=k,pin=pin(v['path']),earlier_pin=v['earlier_pin'])for k,v in reconstructed.items()],original_path_drift_observed=True),'false_plan':o['false_plan'],'current_master':pin(D/'basic-tiling-algorithm-current.md'),
'outcome':'V1_FALSE_TUPLE_NOT_ADOPTABLE_PENDING_CODEC_QUOTA_AND_FAILURE_PREFIX_SUCCESSORS','mismatch_count':2,
'findings':[{'id':'CODEC-I1','review':pin(C/'typed-codec-Source-negative-v1.json'),'summary':'Implicit seed IDs and fixed atom headers bypass documented integer_bits; preserve V1 and enforce in fresh V2.'},
{'id':'WORKER-R1','path':s['sources']['worker']['path'],'lines':[415,433,529], 'summary':'Completed rows are held only in local comprehensions until qualify() finishes every group. Failure before final assignment leaves s.rows and s.diagnostics empty, so saved completed_case_ids/diagnostic_prefix cannot represent the completed prefix.', 'repair':'Update a bounded passive completed-ID/diagnostic journal after each successful row; preserve original active error, no replay or partial admission. Full completed row values may remain local if failure receipt accurately labels retained versus unavailable data.'}],
'checks':checks,'check_count':len(checks),'parser_attribution':{'executable':sys.executable,'version':sys.version,'policy':'Reviewer pinned Python3.12 -I -S -B; ast.dump(include_attributes=False) only; unused compiled code object discarded'},
'inherited_reviews':[pin(C/'typed-initializer-Source-review-v1.json'),pin(C/'typed-foundation-Source-review-v1.json'),pin(C/'typed-codec-Source-negative-v1.json')],
'reviewed_static_scope':['Root worker full Source and original once/observer gates read. Exact source/profile/argument/callability guards, whole69 concatenation/Compiler/body equality, independent old native Heap/postfix words, complete top-strip enumeration and explicit diagnostic classes examined. No procedures or fixtures called.', 'Declaration accurately separates cumulative400m Root callback units from per-call codec/selector private work ceilings, independent original wall/HWM/physical/log gates. No all CPU-work comparison is inherited.', 'Selector calibration is 16 complete top strips with104 expected regular-language rows; it is not whole space-time search or implementation of the physical VM.'],
'limitations':['No grant, worker launch, process probe, imports of target modules, math/codec/fixture evaluation, renderer or publication action performed.','Prior architecture authorship and historical control/helper ancestry disclosed. New codec is B-authored; Root worker/outer author and selector author distinct from reviewer; no full kernel recertification.','Runtime loader/pyc/builtins/transitive stdlib/exclusive read-only custody trusted. Guards are raw/code/default identity observations, not global/default-content/closure/OS integrity sealing.','Only declared diagnostics can support future runtime coverage. Entry PlannedForeign and unowned Invalid/DeclarationError do not establish StopIteration/UnicodeError/ResourceLimit or cadence/recheck/final fault coverage.','Malformed integer words and finite generic programs/values are a selected new bank; no whole language correctness, full checker semantics, proof discovery, universality, speed or RL gain is licensed.','All old rejected mirror evidence remains rejected; no partial prefix or Source review rescues it.']}
out=C/'typed-component-Source-prospective-negative-v1.json';out.write_text(json.dumps(receipt,indent=2,sort_keys=True,ensure_ascii=True)+'\n');print(json.dumps({'receipt':pin(out),'checks':len(checks)}))
