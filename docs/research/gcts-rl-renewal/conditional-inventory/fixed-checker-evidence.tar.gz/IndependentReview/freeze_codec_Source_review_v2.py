import ast,hashlib,json
from pathlib import Path
C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1');D=Path('/private/tmp/gcts-fixed-vm-codec-20261020-v2')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
h=json.loads((D/'handoff-v2.json').read_text());checks=[]
def ck(n,x):
 checks.append(dict(name=n,passed=bool(x)))
 if not x:raise AssertionError(n)
for k in ['Source','API','Source_static_audit','master','parent_handoff','proof_delta','quota_diagnostics','same_whole69_manifest','unchanged_reasoning_with_quota_delta']:ck('whole pin '+k,pin(h[k]['path'])==h[k])
oldp=Path('/private/tmp/gcts-fixed-vm-codec-20261020-v1/fixed_vm_codec_v1.py');old=oldp.read_text();new=Path(h['Source']['path']).read_text();ot=ast.parse(old);nt=ast.parse(new);compile(nt,h['Source']['path'],'exec')
def defs(t):
 out={}
 for n in t.body:
  if isinstance(n,ast.FunctionDef):out[n.name]=n
  elif isinstance(n,ast.ClassDef):
   for m in n.body:
    if isinstance(m,ast.FunctionDef):out[n.name+'.'+m.name]=m
 return out
od,nd=defs(ot),defs(nt);ck('exact definitions and signatures',set(od)==set(nd)and all(ast.dump(od[k].args)==ast.dump(nd[k].args)for k in od))
changed={k for k in od if ast.dump(od[k])!=ast.dump(nd[k])};expected={'_heap_validate','_program_validate','_Writer.bits','_Reader.bits','_Reader.natural','_Heap.pair','_Heap.cons','_band_write','_node_value','_band_read'}
ck('only ten quota bodies changed',changed==expected)
constants=lambda t:{n.targets[0].id:ast.dump(n.value)for n in t.body if isinstance(n,ast.Assign)}
a,b=constants(ot),constants(nt);ck('all other literal constants unchanged',set(a)==set(b)and {k for k in a if a[k]!=b[k]}=={'VERSION'})
ck('no imports or yield',not any(isinstance(n,(ast.Import,ast.ImportFrom,ast.Yield,ast.YieldFrom))for n in ast.walk(nt)))
ck('all implicit heap IDs checked',"node=w.number(257+i,257)\n        _need(key not in index,'duplicate canonical heap pair');index[key]=node"in new)
ck('fixed program headers checked',"w.number(program['atom_max'],0);w.number(program['nil'],0)"in new)
ck('fixed field values checked',"self.w.number(n,0);_need(n<(1<<k),'fixed-width numeric field')"in new and"return self.w.number(value,0)"in new)
ck('seed existing pair and cons children checked',"self.w.number(node,257)"in new and"self.w.number(a,0);self.w.number(b,0)"in new)
ck('decoded tags and bodies checked',"w.number(tag,0,7)"in new and"w.number(body,0,2)"in new and"w.number(body,0);_need(body==256"in new)
ck('padding both directions checked',"w.stage='VALUE_BAND_ENCODE';w.number(padding,0)"in new and"padding+=1;w.number(padding,0)"in new)
# Exact inert raw reverse of all published hunks, no definitions evaluated.
pairs=[
("VERSION='fixed-vm-canonical-codec-v2'","VERSION='fixed-vm-canonical-codec-v1'"),
("        node=w.number(257+i,257)\n        _need(key not in index,'duplicate canonical heap pair');index[key]=node","        _need(key not in index,'duplicate canonical heap pair');index[key]=257+i"),
("    w.number(program['atom_max'],0);w.number(program['nil'],0)\n",''),
("        self.w.number(n,0);_need(n<(1<<k),'fixed-width numeric field')\n",''),
("        return self.w.number(value,0)\n    def natural(self):","        return value\n    def natural(self):"),
("        if k==0:return self.w.number(0,0)","        if k==0:return 0"),
("        self.w.number(node,257)\n",''),
("        self.w.number(a,0);self.w.number(b,0)\n",''),
("    w.stage='VALUE_BAND_ENCODE';w.number(padding,0)\n    heap=_Heap(_seed_snapshot(seed,w),w);roots=_value_roots(values,heap,w);writer=_Writer(w)","    w.stage='VALUE_BAND_ENCODE';heap=_Heap(_seed_snapshot(seed,w),w);roots=_value_roots(values,heap,w);writer=_Writer(w)"),
("            w.number(tag,0,7)","            _need(type(tag)is int and 0<=tag<=6,'known tagged value')"),
("                    w.tick();one,body=heap.pair(body);w.number(one,0);_need(one==1,'canonical unary natural')","                    w.tick();one,body=heap.pair(body);_need(one==1,'canonical unary natural')"),
("                w.number(magnitude,0)\n",''),
("                w.number(body,0,2)\n",''),
("            elif tag==6:w.number(body,0);_need(body==256,'canonical null body');w.push(results,None)","            elif tag==6:_need(body==256,'canonical null body');w.push(results,None)"),
("        _need(symbol=='B','only blank after terminator');padding+=1;w.number(padding,0)","        _need(symbol=='B','only blank after terminator');padding+=1")]
reverse=new
for i,(x,y)in enumerate(pairs):ck('one exact inert reversal hunk '+str(i),reverse.count(x)==1);reverse=reverse.replace(x,y,1)
ck('inert reverse whole V1 bytes',reverse==old)
forward=old
for x,y in reversed(pairs):
 # Empty deletion hunks make generic inversion ambiguous; full diff exact reverse already proves the tuple.
 pass
api=json.loads(Path(h['API']['path']).read_text());oldapi=json.loads(Path(h['parent_handoff']['path']).read_text());oldapi=json.loads(Path(oldapi['API']['path']).read_text())
ck('all16 quota definitions and allowances unchanged',api['limits']==oldapi['limits']and api['limits_policy']==oldapi['limits_policy'])
ck('wire and signatures unchanged',api['entries']==oldapi['entries']and api['program_wire']==oldapi['program_wire']and api['value_wire']==oldapi['value_wire'])
r={'schema':'fixed-vm-codec-Source-review-v2','reviewer_identity':'/root/conventional_control_review','author_identities':['/root/benchmark_design'],'source_review_passed':True,'source_only':True,'component_calls':0,'scientific_calls':0,'subject_imports':0,'fixture_calls':0,'codec_calls':0,'actual_execution_authorized':False,'runtime_qualified':False,'mathematical_authority':False,'subject':h['Source'],'handoff':pin(D/'handoff-v2.json'),'related_pins':{k:h[k]for k in ['API','Source_static_audit','master','parent_handoff','proof_delta','quota_diagnostics','same_whole69_manifest','unchanged_reasoning_with_quota_delta']},'inherited_review':pin(C/'typed-codec-Source-negative-v1b.json'),'preserved_original_review':pin(C/'typed-codec-Source-negative-v1.json'),
'reviewer_correction_retained':'V1b retracts the inaccurate encode-program witness: header256 was already checked by _copy on encode. Decode constructed headers and unused seed IDs were the actual gaps. V2 checks both. No function/example evaluated.',
'delta_disposition':'CODEC-I1 resolved by enforcement; additional fixed-width/cons/tag/padding checks close the same documented numeric domain without changing canonical grammar or raising limits.',
'changed_bodies':sorted(changed),'unchanged_body_count':len(od)-len(changed),'inert_reverse':{'whole_parent_restored':True,'method':'Fifteen literal text reversal hunks on reviewer-owned strings; no target import/exec'},
'interpretation':['All prior full Source/manual canonical image, strict typed value, topological seed, object order, full equality, string and foreign-error reasoning remains applicable on the bounded common admitted domain.','New charges can stop earlier and change work/callback traces. No old callback ordinals, exact old work or runtime qualification is inherited.','Empty value forests with supplied seed records now check every implicit seed ID; generated padding is bounded symmetrically in encode/decode.','The six B quota-rule groups remain unadopted design. A Root prospective bank must bind its actual chosen cases independently; this receipt does not require or claim their execution.'],
'limitations':['Host representation codec only;69 names/order are structural, not body/lowering/kernel equivalence.','Physical BOOT/string canonicality/public3-free2 phase transfer, complete VM and final point/Wang correspondence are not implemented by this codec. Selector malformed free bits must remain admitted for physical validation.','Full-value Root argument guards must retain UTF8-surrogatepass codepoints/bytes, dictionary order and tuple/list distinctions; JSON escape decode is not a host value identity test.','Private owner and read-only exclusive callback custody are cooperative, not hostile-code or OS sealing.','Writer limits and named work counters are finite local units, not exact CPU or all live memory. Original Root hard gates remain separate.','No actual, worker launch, target/fixture import/call, renderer/probe or publication authority supplied. A fresh full-subject prospective review and Root grant remain necessary.'],
'ancestry':'Reviewer authored earlier VM architecture and historical controls; B independently authored this codec. This is Source representation scrutiny, not full kernel certification.',
'mismatch_count':0,'checks':checks,'check_count':len(checks)}
out=C/'typed-codec-Source-review-v2.json';out.write_text(json.dumps(r,indent=2,sort_keys=True,ensure_ascii=True)+'\n');print(json.dumps({'receipt':pin(out),'checks':len(checks)}))
