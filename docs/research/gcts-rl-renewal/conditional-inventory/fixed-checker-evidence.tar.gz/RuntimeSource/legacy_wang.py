"""SOURCE-ONLY, UNEXECUTED finite framed Wang compilation.

No machine simulator, proof checker, tiling search, or top-level compiler call.
The palette depends only on the declared machine, never on an input or time.
All four edges of every square have exact colors; rotations are forbidden.
"""

VERSION = 'finite-framed-wang-spacetime-compiler-v1'
SCHEMA = 'finite-framed-wang-spacetime-v1'
POINT_PROFILE = 'integer-center-midpoint-translation-only-v1'
LIMIT_KEYS = ('work', 'symbols', 'states', 'tiles', 'colors', 'cells', 'dimension')
MACHINE_KEYS = ('alphabet_size', 'state_count', 'blank', 'initial', 'accepting', 'transitions')
WALL = ('wall',)


class DeclarationError(Exception):
    pass


class CompileLimit(Exception):
    def __init__(self, reason, work):
        self.reason = reason
        self.attempted_work = work
        super().__init__(reason)


class _Work:
    def __init__(self, check, limits):
        if not callable(check):
            raise DeclarationError('external check required')
        if type(limits) is not dict or any(type(key) is not str for key in limits) or set(limits) != set(LIMIT_KEYS):
            raise DeclarationError('exact declared finite limits required')
        for key in LIMIT_KEYS:
            if type(limits[key]) is not int or limits[key] <= 0:
                raise DeclarationError('positive exact-int limit required')
        self.limits = dict(limits)
        self.check = check
        self.work = 0
        check()

    def step(self):
        self.work += 1
        if self.work > self.limits['work']:
            raise CompileLimit('work', self.work)
        self.check()

    def bound(self, key, number):
        self.step()
        if number > self.limits[key]:
            raise CompileLimit(key, self.work)


def _integer(value, low, high):
    if type(value) is not int or not low <= value < high:
        raise DeclarationError('exact integer outside declared range')
    return value


def _machine(declaration, work):
    if (type(declaration) is not dict or any(type(key) is not str for key in declaration)
            or set(declaration) != set(MACHINE_KEYS)):
        raise DeclarationError('exact machine fields required')
    alphabet = declaration['alphabet_size']
    states = declaration['state_count']
    if type(alphabet) is not int or alphabet < 1 or type(states) is not int or states < 1:
        raise DeclarationError('positive finite alphabet and state counts required')
    work.bound('symbols', alphabet)
    work.bound('states', states)
    blank = _integer(declaration['blank'], 0, alphabet)
    initial = _integer(declaration['initial'], 0, states)
    accepting = _integer(declaration['accepting'], 0, states)
    rows = declaration['transitions']
    if type(rows) is not list:
        raise DeclarationError('literal transition list required')
    table = {}
    for row in rows:
        work.step()
        if type(row) is not list or len(row) != 5:
            raise DeclarationError('transition must be [state, read, next, write, displacement]')
        q, read, next_q, write, move = row
        _integer(q, 0, states)
        _integer(read, 0, alphabet)
        _integer(next_q, 0, states)
        _integer(write, 0, alphabet)
        _integer(move, -1, 2)
        if q == accepting:
            raise DeclarationError('accepting state must have no outgoing transition')
        if (q, read) in table:
            raise DeclarationError('transition domain must be deterministic, without duplicates')
        table[q, read] = (next_q, write, move)
    # Owned immutable snapshot. Input ownership and read-only callbacks are required.
    return (alphabet, states, blank, initial, accepting,
            tuple((q, read) + table[q, read] for q, read in sorted(table)))


def _machine_record(machine):
    alphabet, states, blank, initial, accepting, transitions = machine
    return dict(alphabet_size=alphabet, state_count=states, blank=blank,
                initial=initial, accepting=accepting,
                transitions=[list(row) for row in transitions])


def _configuration(initial_word, machine, work):
    if type(initial_word) is not list or not initial_word:
        raise DeclarationError('nonempty literal configuration required')
    alphabet, states, blank, initial, accepting, transitions = machine
    copied = []
    heads = 0
    for cell in initial_word:
        work.step()
        if type(cell) is not tuple or not cell or type(cell[0]) is not str:
            raise DeclarationError('exact tuple cell literal required')
        if len(cell) == 2 and cell[0] == 'plain':
            _integer(cell[1], 0, alphabet)
        elif len(cell) == 3 and cell[0] == 'head':
            _integer(cell[1], 0, states)
            _integer(cell[2], 0, alphabet)
            if cell[1] != initial:
                raise DeclarationError('initial head must have declared initial state')
            heads += 1
        else:
            raise DeclarationError('invalid complete cell literal')
        copied.append(cell)
    if heads != 1:
        raise DeclarationError('exactly one initial head required')
    return tuple(copied)


def _local_update(left, center, right, table):
    """Partial radius-one rule. This constructs tile schemas, not a run."""
    triple = (left, center, right)
    heads = [index for index, cell in enumerate(triple) if cell[0] == 'head']
    if len(heads) > 1:
        return None
    if not heads:
        return center  # center is plain because the compiler excludes wall centers.
    position = heads[0]
    head = triple[position]
    transition = table.get((head[1], head[2]))
    if transition is None:
        return None  # includes accepting and every other halting head.
    next_q, write, move = transition
    if position == 1:
        if (move == -1 and left == WALL) or (move == 1 and right == WALL):
            return None
        if move == 0:
            return ('head', next_q, write)
        return ('plain', write)
    if (position == 0 and move == 1) or (position == 2 and move == -1):
        return ('head', next_q, center[1])
    return center


def _palette(machine, work):
    alphabet, states, blank, initial, accepting, transitions = machine
    table = {(row[0], row[1]): row[2:] for row in transitions}
    cells = []
    for symbol in range(alphabet):
        work.step()
        cells.append(('plain', symbol))
    for state in range(states):
        for symbol in range(alphabet):
            work.step()
            cells.append(('head', state, symbol))
    colors = []
    color_ids = {}
    tiles = []

    def color(value):
        work.step()
        # Dict lookup uses full immutable tuple equality, not hash-only identity.
        if value not in color_ids:
            work.bound('colors', len(colors) + 1)
            color_ids[value] = len(colors)
            colors.append(value)
        return color_ids[value]

    def add(kind, origin, north, east, south, west):
        work.step()
        work.bound('tiles', len(tiles) + 1)
        edges = [color(north), color(east), color(south), color(west)]
        tiles.append(dict(id=len(tiles), kind=kind, origin=origin, edges_NESW=edges,
                          t=[[[0, 0], 1]],
                          m=[[[0, -1], 'edge', edges[0]], [[1, 0], 'edge', edges[1]],
                             [[0, 1], 'edge', edges[2]], [[-1, 0], 'edge', edges[3]]]))

    for left in cells + [WALL]:
        for center in cells:
            for right in cells + [WALL]:
                work.step()
                output = _local_update(left, center, right, table)
                if output is not None:
                    add('step', (left, center, right), ('cell', center),
                        ('pair', center, right), ('cell', output), ('pair', left, center))
    for symbol in range(alphabet):
        for flag in (0, 1):
            add('collect_plain', (symbol, flag), ('cell', ('plain', symbol)),
                ('seen', flag), ('stop',), ('seen', flag))
        add('collect_accept', (accepting, symbol), ('cell', ('head', accepting, symbol)),
            ('seen', 1), ('stop',), ('seen', 0))
    # Exact square frame tiles replace the old boundary relations/selectors.
    for center in cells:
        add('left_step_frame', (center,), ('side', 'left', 'run'), ('pair', WALL, center),
            ('side', 'left', 'run'), ('exterior', 'left'))
        add('right_step_frame', (center,), ('side', 'right', 'run'), ('exterior', 'right'),
            ('side', 'right', 'run'), ('pair', center, WALL))
    add('left_accept_frame', (), ('side', 'left', 'run'), ('seen', 0),
        ('side', 'left', 'done'), ('exterior', 'left'))
    add('right_accept_frame', (), ('side', 'right', 'run'), ('exterior', 'right'),
        ('side', 'right', 'done'), ('seen', 1))
    # Intern these even when no step can emit a given initial cell.
    for cell in cells:
        color(('cell', cell))
    for value in (('stop',), ('side', 'left', 'run'), ('side', 'right', 'run'),
                  ('side', 'left', 'done'), ('side', 'right', 'done'),
                  ('exterior', 'left'), ('exterior', 'right')):
        color(value)
    return dict(schema=SCHEMA, version=VERSION, machine=_machine_record(machine),
                color_constructors=colors, tiles=tiles, transformations='translations_only_2Z2',
                point_profile=POINT_PROFILE, edge_order='NESW', mathematical_authority=False)


def compile_palette(machine, *, check, limits):
    """Uniform finite palette from a machine alone. UNEXECUTED SOURCE."""
    work = _Work(check, limits)
    owned = _machine(machine, work)
    result = _palette(owned, work)
    if _machine(machine, work) != owned:
        raise DeclarationError('machine changed during compilation')
    check()
    return dict(status='PALETTE_CANDIDATE', palette=result, attempted_work=work.work,
                mathematical_authority=False, executed_source_qualified=False)


def compile_finite_problem(machine, initial_word, steps, *, check, limits):
    """Whole palette plus exact finite board, not a history/tiling witness.

    initial_word is a complete in-strip configuration: cell literals are exact
    tuples ('plain', symbol) or ('head', state, symbol). Time is exact, not <=.
    The word and machine must be exclusively owned with read-only callbacks.
    """
    work = _Work(check, limits)
    owned = _machine(machine, work)
    palette = _palette(owned, work)  # Never trim to the input/target/horizon.
    alphabet, states, blank, initial, accepting, transitions = owned
    if type(initial_word) is not list or not initial_word:
        raise DeclarationError('nonempty literal configuration required')
    width = len(initial_word)
    if type(steps) is not int or steps < 0:
        raise DeclarationError('nonnegative exact-int step count required')
    work.bound('dimension', width + 2)
    work.bound('dimension', steps + 1)
    work.bound('cells', (width + 2) * (steps + 1))
    copied = _configuration(initial_word, owned, work)
    if len(copied) != width:
        raise DeclarationError('input length changed before boundary construction')
    color_ids = {value: index for index, value in enumerate(palette['color_constructors'])}
    north = [color_ids[('side', 'left', 'run')]]
    north += [color_ids[('cell', cell)] for cell in copied]
    north += [color_ids[('side', 'right', 'run')]]
    south = [color_ids[('side', 'left', 'done')]]
    south += [color_ids[('stop',)]] * width
    south += [color_ids[('side', 'right', 'done')]]
    height = steps + 1
    west = [color_ids[('exterior', 'left')]] * height
    east = [color_ids[('exterior', 'right')]] * height
    required = []
    pins = []
    for y in range(height):
        for x in range(width + 2):
            work.step()
            required.append([2 * x, 2 * y])
        pins.append([[-1, 2 * y], 'edge', west[y]])
        pins.append([[2 * (width + 2) - 1, 2 * y], 'edge', east[y]])
    for x in range(width + 2):
        work.step()
        pins.append([[2 * x, -1], 'edge', north[x]])
        pins.append([[2 * x, 2 * height - 1], 'edge', south[x]])
    # Exact literal reconciliation of these small immutable declaration carriers.
    if _configuration(initial_word, owned, work) != copied or _machine(machine, work) != owned:
        raise DeclarationError('input changed during compilation')
    check()
    return dict(schema='finite-framed-wang-instance-v1', version=VERSION,
                status='FINITE_PROBLEM_CANDIDATE', palette=palette,
                initial_word=list(copied), machine_steps=steps, tape_width=width,
                board_width=width + 2, board_height=height,
                boundary_NESW=[north, east, south, west], required_centers=required,
                admissible_origins=required.copy(), fixed_background_marks=pins,
                candidate_universe='every palette tile ID at every admissible origin; no rotations/reflections',
                all_root_generations=0, attempted_work=work.work,
                mathematical_authority=False, executed_source_qualified=False)
