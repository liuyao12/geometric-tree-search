"""SOURCE ONLY: canonical fixed-VM program images and tagged value bands.

No subject imports or top-level execution. These are representation operations,
not a compiler, interpreter, proof checker, machine simulator or tiling engine.
The full_checker_69 profile binds names/order only; Source/body attribution is
an independent whole-program compiler/provenance obligation.
"""
VERSION='fixed-vm-canonical-codec-v1'
_OWNER=object()
LIMIT_KEYS=('work','data_items','data_depth','integer_bits','wire_symbols',
            'heap_nodes','constants','functions','instructions','registers',
            'arguments','string_bytes','string_chars','values','stack_items','unary_length')
PROGRAM_KEYS=('atom_max','nil','nodes','constants','functions')
FUNCTION_KEYS=('name','arity','registers','code')
MAGIC_BYTES=(71,67,84,83,86,77,49)  # GCTSVM1, each byte eight low-bit-first bits.
OPCODES=('const','move','cons','head','tail','pair','atom','succ','not',
         'branch','jump','call','return')
WIDTHS=(3,3,4,3,3,3,4,3,3,4,2,4,2)
FULL_CHECKER_NAMES=('main','wire_word','wire_ones','wire_key_seen','wire_value',
 'semantic_main','nil','same','l1','l2','l3','l4','l5','l6','size1','size2','size3',
 'second','third','append','reverse','length','nth','member','is_type','text_is',
 'get','fields','signature_ok','tag','arg1','arg2','jstr','arr','make1','make2',
 'make3','var','fun','all','imp','eq','term_ok','formula_ok','byte_less','next_byte',
 'text_less','insert','union','remove','term_free','free','subst_args','subst_term',
 'increment_digits','decimal','subst','collect_atoms','truth','valuations',
 'tautology','induction','formulas_ok','lookup','check_blocks','references',
 'proof','prior','rule_ok')


class Invalid(ValueError):
    def __init__(self,reason,*,owner=None):
        self.reason=reason;self.owner=owner;super().__init__(reason)


class ResourceLimit(RuntimeError):
    def __init__(self,reason,work,*,owner=None):
        self.reason=reason;self.work=work;self.owner=owner;super().__init__(reason)


def is_own_invalid(error):return type(error)is Invalid and error.owner is _OWNER
def is_own_limit(error):return type(error)is ResourceLimit and error.owner is _OWNER


def _need(ok,reason):
    if not ok:raise Invalid(reason,owner=_OWNER)


class _Budget:
    def __init__(self,check,limits):
        _need(callable(check),'explicit callback')
        _need(type(limits)is dict and len(limits)==len(LIMIT_KEYS)and all(type(k)is str for k in limits)and
              set(limits)==set(LIMIT_KEYS),'exact explicit codec limits')
        _need(all(type(v)is int and v>0 for v in limits.values()),'positive exact-int limits')
        self.check=check;self.limits=dict(limits);self.work=0;self.items=0;self.stage='ENTRY'
        check()
    def tick(self):
        self.work+=1
        if self.work>self.limits['work']:raise ResourceLimit('work',self.work,owner=_OWNER)
        if self.work%1024==0:self.check()
    def cap(self,key,value):
        self.tick()
        if value>self.limits[key]:raise ResourceLimit(key,self.work,owner=_OWNER)
    def number(self,value,low=None,high=None):
        self.tick();_need(type(value)is int,'exact integer, not bool')
        self.cap('integer_bits',abs(value).bit_length())
        if low is not None:_need(value>=low,'integer below grammar range')
        if high is not None:_need(value<high,'integer above grammar range')
        return value
    def push(self,stack,item):
        self.cap('stack_items',len(stack)+1);stack.append(item)
    def item(self):
        self.items+=1;self.cap('data_items',self.items)


def _prefix(error,w):
    error.fixed_vm_codec_prefix=dict(schema='fixed-vm-codec-failure-prefix-v1',
        stage='CONSTRUCTOR'if w is None else w.stage,work=0 if w is None else w.work,
        data_items=0 if w is None else w.items,cost_available=w is not None,
        cost_is_lower_bound=w is None,complete=False,authority=False)


def _object(value,keys):
    _need(type(value)is dict and len(value)==len(keys)and all(type(k)is str for k in value)and
          set(value)==set(keys),'exact object fields')


def _utf8_encode(text,w):
    _need(type(text)is str,'exact host string');w.cap('string_chars',len(text));out=bytearray()
    for char in text:
        w.tick()
        # One Python character has at most four surrogatepass bytes.
        part=char.encode('utf-8','surrogatepass')
        for byte in part:
            w.tick();w.cap('string_bytes',len(out)+1);out.append(byte)
    return bytes(out)


def _utf8_decode(raw,w):
    _need(type(raw)is bytes,'owned exact bytes');w.cap('string_bytes',len(raw))
    for unused in raw:w.tick()
    # The try contains no callback: a foreign UnicodeError from check is not caught.
    try:text=raw.decode('utf-8','surrogatepass')
    except UnicodeError:raise Invalid('noncanonical surrogatepass UTF-8',owner=_OWNER)from None
    encoded=_utf8_encode(text,w)
    _need(len(encoded)==len(raw),'UTF-8 length roundtrip')
    for left,right in zip(encoded,raw):w.tick();_need(left==right,'UTF-8 byte roundtrip')
    return text


def _copy(value,w):
    """Iterative strict JSON-value snapshot; no tuple coercion or recursion."""
    tasks=[];out=[];active=set();w.push(tasks,('visit',value,0))
    while tasks:
        w.tick();task=tasks.pop();kind=task[0]
        if kind=='visit':
            unused,x,depth=task;w.item();w.cap('data_depth',depth);t=type(x)
            if x is None or t is bool:w.push(out,x)
            elif t is int:w.push(out,w.number(x))
            elif t is str:_utf8_encode(x,w);w.push(out,x)
            else:
                _need(t in(list,dict),'strict JSON values; no floats or tuples')
                identity=id(x);_need(identity not in active,'acyclic values');active.add(identity)
                if t is list:
                    w.push(tasks,('finish_list',len(x),identity))
                    for i in range(len(x)-1,-1,-1):w.tick();w.push(tasks,('visit',x[i],depth+1))
                else:
                    keys=[];children=[]
                    for key,child in x.items():
                        w.tick();w.item();_utf8_encode(key,w);keys.append(key);children.append(child)
                    w.push(tasks,('finish_dict',keys,identity))
                    for i in range(len(children)-1,-1,-1):w.tick();w.push(tasks,('visit',children[i],depth+1))
        else:
            keys_or_n,identity=task[1:];n=keys_or_n if kind=='finish_list'else len(keys_or_n)
            children=[]
            for unused in range(n):w.tick();children.append(out.pop())
            children.reverse();active.remove(identity)
            if kind=='finish_list':w.push(out,children)
            else:
                result={}
                for key,child in zip(keys_or_n,children):w.tick();result[key]=child
                w.push(out,result)
    _need(len(out)==1,'snapshot stack');return out[0]


def _same(left,right,w):
    pending=[];w.push(pending,(left,right))
    while pending:
        w.tick();a,b=pending.pop()
        if type(a)is not type(b):return False
        t=type(a)
        if t is list:
            if len(a)!=len(b):return False
            for x,y in zip(a,b):w.tick();w.push(pending,(x,y))
        elif t is dict:
            if len(a)!=len(b):return False
            # Order is part of this canonical wire, not discarded by dict equality.
            for (ka,va),(kb,vb)in zip(a.items(),b.items()):
                w.tick();w.push(pending,(ka,kb));w.push(pending,(va,vb))
        elif t is str:
            if len(a)!=len(b):return False
            for x,y in zip(a,b):
                w.tick()
                if x!=y:return False
        elif t in(int,bool)or a is None:
            if a!=b:return False
        else:return False
    return True


def _seed_snapshot(nodes,w):
    _need(type(nodes)is list,'literal heap record list');w.cap('heap_nodes',len(nodes));out=[]
    for row in nodes:
        w.tick();_need(type(row)in(list,tuple)and len(row)==2,'heap pair list or native tuple')
        out.append([w.number(row[0],0),w.number(row[1],0)])
    return out


def _program_snapshot(program,w):
    _object(program,PROGRAM_KEYS)
    # Native Compiler nodes are pairs of tuples. This is the only tuple projection.
    functions=_copy(program['functions'],w)
    _need(type(functions)is list,'literal function array')
    normalized=[]
    for function in functions:
        w.tick();_object(function,FUNCTION_KEYS)
        normalized.append(dict(name=function['name'],arity=function['arity'],
            registers=function['registers'],code=function['code']))
    result={'atom_max':_copy(program['atom_max'],w),'nil':_copy(program['nil'],w),
            'nodes':_seed_snapshot(program['nodes'],w),
            'constants':_copy(program['constants'],w),'functions':normalized}
    return result


def _heap_validate(nodes,w):
    index={}
    for i,row in enumerate(nodes):
        w.tick();a=w.number(row[0],0,257+i);b=w.number(row[1],0,257+i);key=(a,b)
        _need(key not in index,'duplicate canonical heap pair');index[key]=257+i
    return index


def _program_validate(program,profile,w):
    w.stage='PROGRAM_VALIDATION';_need(type(profile)is str and profile in('generic','full_checker_69'),'explicit profile')
    _need(type(program['atom_max'])is int and program['atom_max']==256 and
          type(program['nil'])is int and program['nil']==256,'fixed finite atom header')
    nodes=program['nodes'];_heap_validate(nodes,w);bound=257+len(nodes)
    constants=program['constants'];_need(type(constants)is list,'literal complete constant pool')
    w.cap('constants',len(constants))
    for value in constants:w.tick();w.number(value,0,bound)
    functions=program['functions'];_need(type(functions)is list and functions,'complete nonempty functions')
    w.cap('functions',len(functions));names=[];seen=set();instruction_total=0;argument_total=0
    for function in functions:
        w.tick();_object(function,FUNCTION_KEYS);name=function['name'];_utf8_encode(name,w)
        _need(name not in seen,'unique function names');seen.add(name);names.append(name)
        registers=w.number(function['registers'],1,10000000);w.cap('registers',registers)
        w.number(function['arity'],0,registers+1)
        code=function['code'];_need(type(code)is list and code,'nonempty complete instruction list')
        instruction_total+=len(code);w.cap('instructions',instruction_total)
    _need(names[0]=='main'and functions[0]['arity']==1,'root one-input main')
    if profile=='full_checker_69':
        _need(len(names)==len(FULL_CHECKER_NAMES),'all69checker functions required')
        for actual,expected in zip(names,FULL_CHECKER_NAMES):w.tick();_need(actual==expected,'whole checker function order')
    for function in functions:
        registers=function['registers'];code=function['code']
        for ins in code:
            w.tick();_need(type(ins)is list and ins and type(ins[0])is str and ins[0]in OPCODES,'literal13-opcode grammar')
            op=OPCODES.index(ins[0]);_need(len(ins)==WIDTHS[op],'opcode record width')
            if op==0:w.number(ins[1],0,registers);w.number(ins[2],0,len(constants))
            elif op==10:w.number(ins[1],0,len(code))
            elif op==9:
                w.number(ins[1],0,registers);w.number(ins[2],0,len(code));w.number(ins[3],0,len(code))
            elif op==11:
                w.number(ins[1],0,registers);target=w.number(ins[2],0,len(functions));args=ins[3]
                _need(type(args)is list and len(args)==functions[target]['arity'],'exact target call arity')
                argument_total+=len(args);w.cap('arguments',argument_total)
                for value in args:w.tick();w.number(value,0,registers)
            else:
                for value in ins[1:]:w.tick();w.number(value,0,registers)
    return dict(heap_nodes=len(nodes),constants=len(constants),functions=len(functions),
                instructions=instruction_total,call_arguments=argument_total)


class _Writer:
    def __init__(self,w):self.w=w;self.parts=[]
    def symbol(self,s):
        self.w.tick();self.w.cap('wire_symbols',len(self.parts)+1);self.parts.append(s)
    def bits(self,n,k):
        for i in range(k):self.w.tick();self.symbol('1'if(n>>i)&1 else'0')
    def natural(self,n):
        self.w.number(n,0)
        if n==0:self.symbol('0');return
        k=n.bit_length()
        for unused in range(k):self.w.tick();self.symbol('1')
        self.symbol('0');self.bits(n,k)
    def word(self):return ''.join(self.parts)


class _Reader:
    def __init__(self,text,w):
        _need(type(text)is str,'exact wire string');w.cap('wire_symbols',len(text));self.text=text;self.w=w;self.pos=0
    def symbol(self):
        self.w.tick();_need(self.pos<len(self.text),'truncated wire');s=self.text[self.pos];self.pos+=1;return s
    def bit(self):
        s=self.symbol();_need(s in('0','1'),'binary wire symbol');return int(s=='1')
    def bits(self,k):
        value=0
        for i in range(k):self.w.tick();value|=self.bit()<<i
        return value
    def natural(self):
        k=0
        while self.bit():
            k+=1;self.w.cap('integer_bits',k)
        if k==0:return 0
        value=self.bits(k);_need((value>>(k-1))==1,'positive natural highbit must1')
        return self.w.number(value,1)
    def end(self):_need(self.pos==len(self.text),'trailing wire data')


def _image_write(program,w):
    writer=_Writer(w)
    for byte in MAGIC_BYTES:writer.bits(byte,8)
    writer.natural(len(program['nodes']))
    for a,b in program['nodes']:w.tick();writer.natural(a);writer.natural(b)
    writer.natural(len(program['constants']))
    for value in program['constants']:w.tick();writer.natural(value)
    writer.natural(len(program['functions']))
    for function in program['functions']:
        w.tick();name=_utf8_encode(function['name'],w);writer.natural(len(name))
        for byte in name:w.tick();writer.bits(byte,8)
        for key in('arity','registers'):writer.natural(function[key])
        writer.natural(len(function['code']))
        for ins in function['code']:
            w.tick();op=OPCODES.index(ins[0]);writer.bits(op,4)
            if op==11:
                writer.natural(ins[1]);writer.natural(ins[2]);writer.natural(len(ins[3]))
                for value in ins[3]:w.tick();writer.natural(value)
            else:
                for value in ins[1:]:w.tick();writer.natural(value)
    return writer.word()


def _image_read(image,w):
    reader=_Reader(image,w)
    for expected in MAGIC_BYTES:w.tick();_need(reader.bits(8)==expected,'fixed image magic/version')
    n=reader.natural();w.cap('heap_nodes',n);nodes=[]
    for unused in range(n):w.tick();nodes.append([reader.natural(),reader.natural()])
    n=reader.natural();w.cap('constants',n);constants=[]
    for unused in range(n):w.tick();constants.append(reader.natural())
    n=reader.natural();w.cap('functions',n);functions=[];instructions=0;arguments=0
    for unused in range(n):
        w.tick();length=reader.natural();w.cap('string_bytes',length);name=bytearray()
        for unused in range(length):w.tick();name.append(reader.bits(8))
        name=_utf8_decode(bytes(name),w);arity=reader.natural();registers=reader.natural()
        w.cap('registers',registers);length=reader.natural();instructions+=length;w.cap('instructions',instructions);code=[]
        for unused in range(length):
            w.tick();op=reader.bits(4);_need(op<len(OPCODES),'unknown/reserved opcode')
            if op==11:
                dst=reader.natural();target=reader.natural();argc=reader.natural();arguments+=argc;w.cap('arguments',arguments);args=[]
                for unused in range(argc):w.tick();args.append(reader.natural())
                code.append(['call',dst,target,args])
            else:
                ins=[OPCODES[op]]
                for unused in range(WIDTHS[op]-1):w.tick();ins.append(reader.natural())
                code.append(ins)
        functions.append(dict(name=name,arity=arity,registers=registers,code=code))
    reader.end();return dict(atom_max=256,nil=256,nodes=nodes,constants=constants,functions=functions)


def _result(kind,w,**fields):
    return dict(schema='fixed-vm-canonical-codec-result-v1',version=VERSION,status=kind,
        work=w.work,data_items=w.items,authority=False,formal_kernel_certified=False,
        executed_source_qualified=False,source_body_binding_established=False,**fields)


def encode_integer(value,*,check,limits):
    w=None
    try:
        w=_Budget(check,limits);w.stage='INTEGER_ENCODE';writer=_Writer(w);writer.natural(value);bits=writer.word()
        check();return _result('CANONICAL_INTEGER_ENCODED',w,value=value,bits=bits)
    except BaseException as error:
        try:_prefix(error,w)
        except BaseException:pass
        raise


def decode_integer(bits,*,check,limits):
    w=None
    try:
        w=_Budget(check,limits);w.stage='INTEGER_DECODE';reader=_Reader(bits,w);value=reader.natural();reader.end()
        check();return _result('CANONICAL_INTEGER_DECODED',w,value=value,bits=bits)
    except BaseException as error:
        try:_prefix(error,w)
        except BaseException:pass
        raise


def encode_program_image(program,*,profile,check,limits):
    w=None
    try:
        w=_Budget(check,limits);owned=_program_snapshot(program,w);counts=_program_validate(owned,profile,w)
        w.stage='IMAGE_ENCODE';image=_image_write(owned,w);decoded=_image_read(image,w)
        _program_validate(decoded,profile,w);_need(_same(owned,decoded,w),'full image encode/decode equality')
        w.stage='INPUT_RECHECK';_need(_same(owned,_program_snapshot(program,w),w),'caller program changed')
        check();return _result('CANONICAL_PROGRAM_IMAGE_ENCODED',w,profile=profile,program=owned,image=image,counts=counts)
    except BaseException as error:
        try:_prefix(error,w)
        except BaseException:pass
        raise


def decode_program_image(image,*,profile,check,limits):
    w=None
    try:
        w=_Budget(check,limits);w.stage='IMAGE_DECODE';program=_image_read(image,w);counts=_program_validate(program,profile,w)
        canonical=_image_write(program,w);_need(_same(image,canonical,w),'entire canonical image equality')
        check();return _result('CANONICAL_PROGRAM_IMAGE_DECODED',w,profile=profile,program=program,image=image,counts=counts)
    except BaseException as error:
        try:_prefix(error,w)
        except BaseException:pass
        raise


class _Heap:
    def __init__(self,nodes,w):
        self.w=w;self.nodes=nodes;self.index=_heap_validate(nodes,w)
    def valid(self,node):return type(node)is int and 0<=node<257+len(self.nodes)
    def pair(self,node):
        self.w.tick();_need(type(node)is int and 257<=node<257+len(self.nodes),'actual existing cons node')
        return self.nodes[node-257]
    def cons(self,a,b):
        self.w.tick();_need(self.valid(a)and self.valid(b),'valid existing cons children')
        key=(a,b)
        if key not in self.index:
            self.w.cap('heap_nodes',len(self.nodes)+1);node=self.w.number(257+len(self.nodes),257)
            self.index[key]=node;self.nodes.append([a,b])
        return self.index[key]
    def word(self,items):
        result=256
        for i in range(len(items)-1,-1,-1):self.w.tick();result=self.cons(items[i],result)
        return result


def _value_roots(values,heap,w):
    """Encode all host values as canonical tagged cons structures, iteratively."""
    roots=[]
    for root_value in values:
        w.tick();tasks=[];results=[];w.push(tasks,('visit',root_value,0))
        while tasks:
            w.tick();task=tasks.pop();kind=task[0]
            if kind=='visit':
                value,depth=task[1:];w.item();w.cap('data_depth',depth);t=type(value)
                if t is str:w.push(results,heap.cons(2,heap.word(_utf8_encode(value,w))))
                elif t is bool:w.push(results,heap.cons(5,int(value)))
                elif t is int:
                    w.number(value);n=abs(value);w.cap('unary_length',n);body=256
                    for unused in range(n):w.tick();body=heap.cons(1,body)
                    w.push(results,heap.cons(3 if value>=0 else 4,body))
                elif value is None:w.push(results,heap.cons(6,256))
                elif t is list:
                    w.push(tasks,('array',len(value)))
                    for i in range(len(value)-1,-1,-1):w.tick();w.push(tasks,('visit',value[i],depth+1))
                else:
                    _need(t is dict,'strict host value');keys=[];children=[]
                    for key,child in value.items():w.tick();w.item();_utf8_encode(key,w);keys.append(key);children.append(child)
                    w.push(tasks,('object',keys))
                    for i in range(len(children)-1,-1,-1):w.tick();w.push(tasks,('visit',children[i],depth+1))
            else:
                n=task[1]if kind=='array'else len(task[1]);children=[]
                for unused in range(n):w.tick();children.append(results.pop())
                children.reverse()
                if kind=='array':w.push(results,heap.cons(1,heap.word(children)))
                else:
                    rows=[]
                    for key,child in zip(task[1],children):
                        w.tick();rows.append(heap.cons(heap.word(_utf8_encode(key,w)),child))
                    w.push(results,heap.cons(0,heap.word(rows)))
        _need(len(results)==1,'tagged encode stack');roots.append(results[0])
    return roots


def _postfix(root,heap,writer,w):
    tasks=[];w.push(tasks,root)
    while tasks:
        w.tick();node=tasks.pop()
        if node is None:writer.symbol('1')
        elif node<=256:
            w.number(node,0,257);writer.symbol('0');writer.bits(node,9)
        else:
            a,b=heap.pair(node);w.push(tasks,None);w.push(tasks,b);w.push(tasks,a)


def _band_write(values,seed,padding,w):
    w.stage='VALUE_BAND_ENCODE';heap=_Heap(_seed_snapshot(seed,w),w);roots=_value_roots(values,heap,w);writer=_Writer(w)
    for root in roots:w.tick();_postfix(root,heap,writer,w)
    writer.symbol(';')
    for unused in range(padding):w.tick();writer.symbol('B')
    writer.symbol(':');return writer.word()


def _list_nodes(node,heap,w):
    result=[]
    while node!=256:
        w.tick();head,node=heap.pair(node);w.cap('data_items',len(result)+1);result.append(head)
    return result


def _byteword(node,heap,w):
    raw=bytearray()
    while node!=256:
        w.tick();head,node=heap.pair(node);w.number(head,0,256)
        w.cap('string_bytes',len(raw)+1);raw.append(head)
    return _utf8_decode(bytes(raw),w)


def _node_value(root,heap,w):
    tasks=[];results=[];w.push(tasks,('visit',root,0))
    while tasks:
        w.tick();task=tasks.pop();kind=task[0]
        if kind=='visit':
            node,depth=task[1:];w.item();w.cap('data_depth',depth);tag,body=heap.pair(node)
            _need(type(tag)is int and 0<=tag<=6,'known tagged value')
            if tag==2:w.push(results,_byteword(body,heap,w))
            elif tag in(3,4):
                magnitude=0
                while body!=256:
                    w.tick();one,body=heap.pair(body);_need(one==1,'canonical unary natural')
                    magnitude+=1;w.cap('unary_length',magnitude);w.number(magnitude,0)
                _need(tag!=4 or magnitude>0,'negative zero forbidden')
                w.push(results,-magnitude if tag==4 else magnitude)
            elif tag==5:
                _need(type(body)is int and body in(0,1),'canonical Boolean body');w.push(results,body==1)
            elif tag==6:_need(body==256,'canonical null body');w.push(results,None)
            elif tag==1:
                children=_list_nodes(body,heap,w);w.push(tasks,('array',len(children)))
                for i in range(len(children)-1,-1,-1):w.tick();w.push(tasks,('visit',children[i],depth+1))
            else:
                rows=_list_nodes(body,heap,w);keys=[];children=[];seen=set()
                for row in rows:
                    w.tick();w.item();key_node,value=heap.pair(row);key=_byteword(key_node,heap,w)
                    _need(key not in seen,'duplicate object key');seen.add(key);keys.append(key);children.append(value)
                w.push(tasks,('object',keys))
                for i in range(len(children)-1,-1,-1):w.tick();w.push(tasks,('visit',children[i],depth+1))
        else:
            n=task[1]if kind=='array'else len(task[1]);children=[]
            for unused in range(n):w.tick();children.append(results.pop())
            children.reverse()
            if kind=='array':w.push(results,children)
            else:
                obj={}
                for key,value in zip(task[1],children):w.tick();obj[key]=value
                w.push(results,obj)
    _need(len(results)==1,'tagged decode stack');return results[0]


def _band_read(band,value_count,seed,w):
    w.stage='VALUE_BAND_DECODE';reader=_Reader(band,w);heap=_Heap(_seed_snapshot(seed,w),w);stack=[]
    while True:
        symbol=reader.symbol()
        if symbol==';':break
        if symbol=='0':
            atom=w.number(reader.bits(9),0,257);w.push(stack,atom)
        elif symbol=='1':
            _need(len(stack)>=2,'postfix cons underflow');right=stack.pop();left=stack.pop();w.push(stack,heap.cons(left,right))
        else:_need(False,'postfix payload admits only0/1/semicolon')
    _need(len(stack)==value_count,'exact band root count');padding=0
    while True:
        symbol=reader.symbol()
        if symbol==':':break
        _need(symbol=='B','only blank after terminator');padding+=1
    reader.end();values=[]
    for root in stack:w.tick();values.append(_node_value(root,heap,w))
    return values,heap.nodes,stack,padding


def _value_inputs(values,value_count,seed,padding,w):
    count=w.number(value_count,0);w.cap('values',count)
    if values is not None:_need(type(values)is list and len(values)==count,'exact host value root count')
    if padding is not None:w.number(padding,0);w.cap('wire_symbols',padding)
    return count


def encode_value_band(values,*,value_count,seed_nodes,padding,check,limits):
    w=None
    try:
        w=_Budget(check,limits);owned=_copy(values,w);seed=_seed_snapshot(seed_nodes,w)
        _need(type(owned)is list,'literal host value array')
        _value_inputs(owned,value_count,seed,padding,w)
        band=_band_write(owned,seed,padding,w)
        decoded,nodes,roots,actual_padding=_band_read(band,value_count,seed,w)
        _need(_same(owned,decoded,w)and actual_padding==padding,'full value encode/decode equality')
        w.stage='INPUT_RECHECK'
        _need(_same(owned,_copy(values,w),w)and _same(seed,_seed_snapshot(seed_nodes,w),w),'caller value/seed changed')
        check();return _result('CANONICAL_VALUE_BAND_ENCODED',w,band=band,values=decoded,
            nodes=nodes,roots=roots,padding=padding,value_count=value_count,
            string_profile='UTF8_SURROGATEPASS_ROUNDTRIP_V1')
    except BaseException as error:
        try:_prefix(error,w)
        except BaseException:pass
        raise


def decode_value_band(band,*,value_count,seed_nodes,check,limits):
    w=None
    try:
        w=_Budget(check,limits);seed=_seed_snapshot(seed_nodes,w);_value_inputs(None,value_count,seed,None,w)
        values,nodes,roots,padding=_band_read(band,value_count,seed,w)
        canonical=_band_write(values,seed,padding,w);_need(_same(band,canonical,w),'full canonical band equality')
        w.stage='INPUT_RECHECK';_need(_same(seed,_seed_snapshot(seed_nodes,w),w),'caller seed changed')
        check();return _result('CANONICAL_VALUE_BAND_DECODED',w,band=band,values=values,
            nodes=nodes,roots=roots,padding=padding,value_count=value_count,
            string_profile='UTF8_SURROGATEPASS_ROUNDTRIP_V1')
    except BaseException as error:
        try:_prefix(error,w)
        except BaseException:pass
        raise
