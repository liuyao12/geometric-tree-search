"""Raw Source adaptation of the same reviewed bounded once lifecycle."""
from pathlib import Path
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
s=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1/run_mirrored_receptor_once_v1.py').read_text()
s=s.replace('mirrored-receptor-comparison-once-runner-v1','fixed-codec-initializer-component-once-runner-v1')
s=s.replace("SOURCE_ROLES=frozenset(('worker','compiler','verifier','search','census','mirror_compiler','mirror_verifier','dpll','runner','observer'))", "SOURCE_ROLES=frozenset(('worker','selector','codec','tree','legacy_wang','fol_source','wire_source','combined_source','runner','observer'))")
s=s.replace("profile='mirrored-receptor-same-advice-comparison'", "profile='fixed-codec-unknown-initializer-component-calibration'")
a=s.index('def validate_qualification(')
b=s.index('\ndef main(',a)
s=s[:a]+'''def validate_qualification(q,plan,declaration,outputs):
    need(q['schema']=='fixed-codec-initializer-component-candidate-v1'and
         q['status']=='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE','whole new component result')
    need(q['outputs']==outputs and len(outputs)==1,'one complete canonical packet')
    need(q['case_ids']==declaration['case_ids']and type(q['rows'])is list and
         [r['id']for r in q['rows']]==declaration['case_ids']and
         len(q['rows'])==declaration['exact_cases']and
         len(set(q['case_ids']))==len(q['case_ids']),'complete unique case population/order')
    need(all(r['complete']is True for r in q['rows']),'all declared cases completed')
    need([r['bits']for r in q['malformed_integers']]==declaration['malformed_integers']and
         all(r['status']=='PASSED'for r in q['malformed_integers']),'all separately declared malformed integer cases')
    need(q['diagnostic_ids']==declaration['diagnostic_ids']and
         [r['id']for r in q['diagnostics']]==declaration['diagnostic_ids']and
         len(q['diagnostics'])==len(declaration['diagnostics']),'all exact diagnostics')
    for row,expected in zip(q['diagnostics'],declaration['diagnostics']):
        need(row['status']=='PASSED'and row['operation']==expected['operation']and
             row['expected']==expected['expected'],'exact declared diagnostic classification')
        need(type(row['callback_count'])is int,'literal callback count, not bool')
        if expected['expected']=='FOREIGN':
            need(row['callback_count']==1 and row['exact_foreign_identity']is True,'exact foreign callback object')
        else:
            need(expected['expected']in('INVALID','LIMIT')and row['callback_count']==0and
                 row['exact_foreign_identity']is None,'owned refusal with no foreign callback')
    need(type(q['full_checker_functions'])is int and q['full_checker_functions']==69and
         type(q['full_checker_instructions'])is int and q['full_checker_instructions']>0,
         'whole69function image record')
    need(type(q['selector_rows'])is int and q['selector_rows']==104,'complete declared selector row populations')
    for key in('codec_calls','initializer_calls','compiler_calls','verifier_calls','oracle_calls'):
        need(type(q[key])is int and q[key]>0,'actual declared component work: '+key)
    need(type(q['search_calls'])is int and q['search_calls']==0,'no point or proof search claimed')
    need(type(q['root_check_calls'])is int and 0<q['root_check_calls']<=400000000,'same total callback ceiling')
    for key in('full_pipeline_qualified','mathematical_proof_accepted','fixed_FOL_palette_qualified',
               'gcts_rl_advantage_established','learned_pair_markings','trained_RL','complete_physical_VM','proof_discovery'):
        need(q[key]is False,'no broader authority')

'''+s[b:]
(D/'run_codec_initializer_once_v1.py').write_text(s)
observer=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1/observe_mirrored_receptor_once_v1.py').read_text()
observer=observer.replace('mirrored-receptor-terminal-observer-v1','fixed-codec-initializer-terminal-observer-v1')
(D/'observe_codec_initializer_once_v1.py').write_text(observer)
