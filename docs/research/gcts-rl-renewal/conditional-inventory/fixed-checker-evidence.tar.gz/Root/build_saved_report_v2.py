"""Saved JSON display, byte custody and archive authoring only; no replay."""
from pathlib import Path
import json,hashlib,html,tarfile,io,subprocess
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
O=D/'publication';O.mkdir(exist_ok=True)
R=Path('/private/tmp/gcts-split-controls-publish-20261015')
C=Path('/private/tmp/gcts-fixed-vm-review-20261020-v1')
def pin(path):
 p=Path(path).resolve();raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):path.write_text(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n')
summary=json.loads((D/'ROOT-passive-actual-summary-v2.json').read_bytes())
adoption=json.loads((D/'ROOT-component-adoption-v2.json').read_bytes())
assert adoption['status']=='FINITE_COMPONENT_CALIBRATION_ACCEPTED'
saved_review=json.loads(Path(adoption['independent_saved_review']['path']).read_bytes())
foundation=json.loads((C/'typed-foundation-Source-review-v1.json').read_bytes())
actual=D/'actual-components-v2';packet_raw=(actual/'canonical-codec-initializer-calibration.json').read_bytes()
(O/'fixed-checker-data.json').write_bytes(packet_raw)
(O/'fixed-checker-summary.json').write_bytes((D/'ROOT-passive-actual-summary-v2.json').read_bytes())
outcome=f'''<section id="outcome"><div class="status"><b>Finite component calibration accepted.</b><p>The whole declared run and its original resource/terminal gates passed. Independent saved-data review recorded {saved_review['check_count']:,} checks with no mismatches. Root accepted this finite component evidence; the observer’s literal <code>ROOT_resource_accepted:false</code> is preserved as a separate record.</p></div><div class="metrics"><div class="metric"><b>{summary['case_rows']:,}</b>normal component cases</div><div class="metric"><b>{summary['diagnostics']:,}</b>diagnostics, plus {summary['malformed_words']:,} malformed integer words</div><div class="metric"><b>{summary['selector_rows']:,}</b>complete saved initializer rows</div><div class="metric"><b>{summary['elapsed_seconds']:.3f} s</b>whole runner epoch through terminal observation</div></div><p class="small">Worker high-water memory: {summary['worker_peak_bytes']:,} bytes. Stored and expanded packet plus result: {summary['logical_bytes']:,} bytes. Conservative physical ledger including the original outer reservation: {summary['physical_bytes_with_reserve']:,} bytes. Result callback snapshot: {summary['root_check_calls']:,}; later header callbacks share the same ceiling. These are one instrumented component run, not a proof-search speed comparison.</p></section>'''
counts=foundation['conditional_literal_counts'];census=foundation['independent_census']
negative=f'''<div class="status warning"><b>Source-reviewed construction obstacle; no physical generator execution.</b><p>The unminimized scanning/UTF-8 foundation has an independently reviewed Source census of {census['physical_states_Q']:,} states and {census['physical_alphabet_b']:,} symbols, before the complete opcode controller and BOOT parser exist. Under the unchanged literal Wang conversion, the foundation alone retains \\({counts['retained_step_tiles_S']:,}\\) step tiles; with frames, collector and initializer it would require \\({counts['with_Root_initializer_tiles']:,}\\) tiles.</p><p>Even one raw byte per enumerated step tile exceeds the original 128 MiB output cap. This is a conditional cardinality deduction for this specific construction, not a materialized table, measured allocation, full-VM census or impossibility result. The public complete-interpreter entry point explicitly refuses while its control routines are missing.</p></div>'''
# Use LaTeX grouping for decimal separators in mathematical display text.
negative=negative.replace('954,080,288','954{,}080{,}288').replace('954,754,816','954{,}754{,}816')
review_html='<p class="small">Sources, independent static reviews, corrected pre-execution quota findings, full false/true once-plan history, resource closure and independent saved-data review are archived. The V1 prospective tuple had no execution; its reconstructed historical Source bytes are labeled explicitly. The complete new actual ran once and its grant is retired.</p>'
template=(D/'fixed-checker-template.html').read_text()
rendered=template.replace('__OUTCOME__',outcome).replace('__FOUNDATION__',negative).replace('__REVIEW__',review_html)
(O/'fixed-checker.html').write_text(rendered)
prefix='docs/research/gcts-rl-renewal/conditional-inventory/'
parent=subprocess.run(['/usr/bin/git','rev-parse','HEAD'],cwd=R,check=True,stdout=subprocess.PIPE).stdout.decode().strip()
reader=subprocess.run(['/usr/bin/git','show',parent+':'+prefix+'reader.html'],cwd=R,check=True,stdout=subprocess.PIPE).stdout
(D/'reader-preimage.html').write_bytes(reader)
addition=b'''<section id="fixed-checker-milestone"><h2>Checker image and an unknown-certificate boundary</h2><p>The complete sixty-nine-function checker now compiles to a saved canonical image, and the new initialization tiles let certificate bits vary while fixed data and the initial head remain pinned. A fresh full component calibration passed 288 normal cases, ten malformed integer words and 28 diagnostics; all 104 declared initializer rows were independently enumerated. The complete physical interpreter remains unfinished, and its unminimized foundation exposes another literal-palette size obstacle. <a href="fixed-checker.html#tiles">Inspect the actual tiles, their human reading, checker image and evidence</a>.</p></section>'''
assert reader.count(b'</main>')==1
(O/'reader.html').write_bytes(reader.replace(b'</main>',addition+b'</main>'))
save(D/'reader-append-custody-v2.json',dict(parent_commit=parent,prefix=prefix,
 preimage=pin(D/'reader-preimage.html'),result=pin(O/'reader.html'),added_bytes=len(addition),
 operation='one exact task-owned section inserted immediately before the single closing main tag',index_not_accessed=True))
# Only explicitly listed source/evidence roots; exclude this publication, UI and
# network receipts, and the detached future publication-review receipt.
members={}
for root,label in ((D,'Root'),(Path('/private/tmp/gcts-fixed-vm-codec-20261020-v1'),'CodecV1'),
 (Path('/private/tmp/gcts-fixed-vm-codec-20261020-v2'),'CodecV2'),
 (Path('/private/tmp/gcts-fixed-vm-construction-20261020-v1'),'PhysicalFoundation'),(C,'IndependentReview')):
 for path in root.rglob('*'):
  if not path.is_file()or path.is_symlink():continue
  rel=path.relative_to(root)
  if root==D and (rel.parts[0]in('publication','live-verification-v2')or path.name.startswith(('local-','live-','ROOT-live-','ROOT-final-'))):continue
  if 'publication' in path.name or path.suffix in('.png','.pyc'):continue
  members[path.resolve()]=label+'/'+str(rel)
plan=json.loads((D/'component-plan-authorized-v2.json').read_bytes())
for role,value in plan['sources'].items():
 path=Path(value['path']).resolve()
 if path not in members:members[path]='RuntimeSource/'+role+path.suffix
extra=Path('/private/tmp/gcts-fixed-VM-design-peer-20261019-v1/fixed-interpreter-encoding-contract-v1.json')
members[extra]='EarlierDesign/fixed-interpreter-encoding-contract-v1.json'
rows=[]
archive=O/'fixed-checker-evidence.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT)as tar:
 for path,name in sorted(members.items(),key=lambda item:item[1]):
  raw=path.read_bytes();record=pin(path);record['archive_member']=name;rows.append(record)
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(raw))
 raw=(json.dumps(rows,sort_keys=True,indent=2)+'\n').encode();info=tarfile.TarInfo('PATHMAP.json');info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
manifest=dict(schema='fixed-checker-component-publication-manifest-v2',
 scope=adoption['scope'],mathematical_proof_accepted=False,complete_physical_VM=False,
 full_pipeline_qualified=False,previous_mirror_run_remains_rejected=True,
 archived_files=rows,archive_member_count=len(rows)+1,
 publication_files=[pin(O/name)for name in('fixed-checker.html','fixed-checker-data.json','fixed-checker-summary.json','fixed-checker-evidence.tar.gz','reader.html')],
 saved_review=adoption['independent_saved_review'],foundation_review=pin(C/'typed-foundation-Source-review-v1.json'),
 component_adoption=pin(D/'ROOT-component-adoption-v2.json'),reader_append_custody=pin(D/'reader-append-custody-v2.json'),
 detached_publication_review='fixed-checker-review.json is independently supplied after this manifest to avoid a hash cycle.',
 interpretation='Archive is a frozen explicit source/evidence selection. Later local/live UI, HTTP/deployment/final-milestone receipts remain separate; no algorithm replay in this builder.')
save(O/'fixed-checker-manifest.json',manifest)
print(json.dumps(dict(output=str(O),archive_members=len(rows)+1,archive_bytes=archive.stat().st_size,reader_parent=parent),sort_keys=True))
