"""Raw metadata, input lists, Source AST and unused compile only."""
from pathlib import Path
import ast,hashlib,json,sys
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
SOURCES={
 'worker':D/'qualify_codec_initializer_worker_v2.py',
 'selector':D/'wang_unknown_certificate_initializer_v1.py',
 'codec':Path('/private/tmp/gcts-fixed-vm-codec-20261020-v2/fixed_vm_codec_v2.py'),
 'tree':Path('/private/tmp/gcts-semantic-family-next-audit-20261018/tree_machine.py'),
 'legacy_wang':Path('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py'),
 'fol_source':Path('/private/tmp/gcts-semantic-family-next-audit-20261018/fol_checker.tree'),
 'wire_source':Path('/private/tmp/gcts-semantic-family-next-audit-20261018/boundary_syntax.tree'),
 'combined_source':Path('/private/tmp/gcts-fixed-checker-feasibility-20261019-v1/fixed-checker-combined-plaintext-v1.tree'),
 'runner':D/'run_codec_initializer_once_v2.py',
 'observer':D/'observe_codec_initializer_once_v2.py'}
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=p.resolve();raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,v):
 p=D/name
 with p.open('xb')as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False).encode()+b'\n')
 return pin(p)
old=json.loads(Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1/declaration-v2.json').read_bytes())
bank=json.loads((D/'component-inputs-v2.json').read_bytes())
selector=dict(work=400000000,symbols=256,states=100000,tiles=100000,colors=100000,cells=100000,dimension=10000)
codec=dict(work=400000000,data_items=2000000,data_depth=128,integer_bits=4096,wire_symbols=8000000,heap_nodes=1000000,constants=100000,functions=10000,instructions=1000000,registers=100000,arguments=2000000,string_bytes=1000000,string_chars=1000000,values=10000,stack_items=4000000,unary_length=10000)
entries=[dict(id='whole-new-codec-initializer-component-bank',pin=pin(D/'component-inputs-v2.json'))]
case_ids=['integer-'+str(n)for n in bank['integers']]+[r['id']for r in bank['values']]+['all-thirteen-opcodes','complete-sixty-nine-function-checker']+[r['id']for r in bank['selectors']]
dec=dict(schema='ROOT-wang-encoding-qualification-declaration-v1',
 limits=old['limits'],checkpoint_limit=400000000,
 runtime_trust=old['runtime_trust'],
 experiment_kind='FIXED_CODEC_AND_UNKNOWN_INITIALIZER_COMPONENT_CALIBRATION',
 inputs=entries,case_ids=case_ids,exact_cases=len(case_ids),
 malformed_integers=bank['malformed_integers'],diagnostics=bank['diagnostics'],
 diagnostic_ids=[r['id']for r in bank['diagnostics']],
 component_limits=dict(selector=selector,legacy_wang=selector,codec=codec),
 expected_selector_rows=104,
 new_question='Complete new finite component bank: fixed wire/image/value codec and generic unknown-certificate initializer. Not a failed mirror rerun or a complete fixed physical interpreter.',
 whole_checker='Literal wire Source plus complete renamed FOL checker Source must equal the frozen combined Source. Actually compile all69functions once using pinned oldCompiler, encode/decode full declaration with newcodec and compare every body/register/constant/heap record. Static oldvalidate independently checks grammar. No Source-to-bytecode semantic theorem, JSONtext-versus-host equality, physical BOOT or kernel equivalence inferred.',
 integer_scope='Every declared264natural encodings independently reconstructed; all10malformed words must be exact ownedrefusals.',
 value_scope='All6declared value groups; native oldHeap+encode_json+Rootpostfix yields complete independent expected words. Codepoint declarations construct pairedsurrogates insideactual. Typed carriers use surrogatepasshex, preserving astralversuspairedsurrogate hostvalues and dictionary order. Entire band, heap, roots and full typed decoded values retained.',
 selector_scope='All16generic machine+fixedwire/capacity1..4/headprefixorsuffix cases. Full oldmachine palette retained and full newpalette equal independent of finitebound. Independently enumerate alltoprow fullpalette/color paths and match complete regular-language finite word population;104rows. No full space-time point search, machine run, FOL proof or empty-boundary theorem.',
 diagnostics_scope='All28operation IDs and exact INVALID/LIMIT/FOREIGN classes mandatory; explicit expectedclass membership, no operation substring inference. Includes Boolean/numeric, forward/duplicateheap,callarity,selectedfunctionsubset,float,negativezero,invalidUTF8,underflow/padding,wire/head/suffix/BOOT,work/outputpreflight limits,exactforeign and same-classforeign.',
 ownership='Inputs exclusive and callbacks readonly. Each actualcall guards allSource bytes and recursive callable/code/default identities before/after success/refusal; typed complete argument trees preserve dictorder,listtuple,boolint and exactUnicode throughUTF8surrogatepasshex. First Rootpolicyfault latched; foreignobjects exact and no private-owned misclassification. Not hostile-code sandbox.',
 resource_scope='Same180absolute runner Sourceentry complete positive output/header/result/knownexit;210whole custody/log/process/terminal;1GiBworkerHWM;bothstoredexpanded128MiB,physical128MiB including9MiBouterreserve;all logs4MiB;Root400mcumulativecallbacks. New explicit componentprivateunits stated incomponent_limits, not a raised oldgrant. Existing partialphysicalfoundation generator NOT executed.',
 retention='Full inputs, actual full69declaration/image, generic13opcodeprogram, integerwords, complete typedvalues/bands/nativecounterparts, all16wholepalettes/problems and complete104topselectorpaths/referencewords, all28diagnostics, call/cost/error counters. No hash-only mathematical attribution.',
 no_rescue='Fresh once exactsubject review/grant/idlebarrier only. Any fault/unreached/refusal/limit in normal cases rejects whole calibration. No prefix adoption, input bank trimming, reusedgrant, oldnegativeadmission or raised outercaps.',
 full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,
 authority='Finite representation/initializer component calibration only. No implemented fullphysicalVM, universalFOLpalette, arithmetic/Hilbert theorem discovery, RLtraining, generalizedlemmas, Turtle/Penrose/plane tiling orproof-search advantage.')
dp=save('component-declaration-v2.json',dec)
sources={role:pin(path)for role,path in SOURCES.items()};census=[]
for role,path in SOURCES.items():
 raw=path.read_bytes();tree=ast.parse(raw);compile(tree,str(path),'exec');imports=[]
 for node in ast.walk(tree):
  if isinstance(node,ast.Import):imports.extend(i.name for i in node.names)
  elif isinstance(node,ast.ImportFrom):imports.append(node.module)
 census.append(dict(role=role,source=sources[role],direct_imports=sorted(set(imports)),AST_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
prior=json.loads(Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1/runtime-closure-v2.json').read_bytes())
stdlib=[Path(r['path'])for r in prior['stdlib_files']]
base=PYTHON.parent.parent/'lib/python3.12'
for name in ('ast.py','collections/__init__.py','enum.py','contextlib.py','functools.py','operator.py','keyword.py','reprlib.py','warnings.py'):
 p=base/name
 if p not in stdlib:stdlib.append(p)
cp=save('component-runtime-closure-v2.json',dict(schema='ROOT-wang-encoding-runtime-closure-v1',
 python=pin(PYTHON),sources=sources,declaration=dp,stdlib_files=[pin(p)for p in stdlib],
 direct_import_census=census,runtime_trust=old['runtime_trust'],source_only=True,actual_execution_authorized=False))
subject=dict(schema='ROOT-wang-encoding-qualification-plan-v1',
 invocation_id='fixed-codec-unknown-initializer-components-v2',actual_directory=str(D/'actual-components-v2'),
 python=pin(PYTHON),sources=sources,inputs=entries,limits=dec['limits'],declaration=dp,runtime_closure=cp)
sha=hashlib.sha256(canonical(subject)).hexdigest()
ap=save('component-authorization-false-v2.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=sha,review=None,scope='Source-only prospective subject; no actualauthority.'))
pp=save('component-plan-false-v2.json',dict(subject,authorization=ap))
op=save('component-Source-only-offer-v2.json',dict(schema='ROOT-wang-prospective-offer-v1',subject=subject,subject_sha256=sha,false_plan=pp,sources=sources,component_calls=0,actual_execution_authorized=False))
print(json.dumps(dict(offer=op,subject_sha256=sha,exact_cases=len(case_ids),malformed_integers=len(bank['malformed_integers']),diagnostics=len(bank['diagnostics'])),sort_keys=True))
