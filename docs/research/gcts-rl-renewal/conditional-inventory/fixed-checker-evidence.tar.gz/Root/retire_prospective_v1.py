"""Preserve false/max-zero prospective tuple and exact raw Source revisions."""
from pathlib import Path
import hashlib,json,shutil
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1');O=D/'prospective-v1-retired'
O.mkdir(exist_ok=False)
offer=json.loads((D/'component-Source-only-offer-v1.json').read_bytes())
for name in ('component-Source-only-offer-v1.json','component-plan-false-v1.json','component-authorization-false-v1.json','component-declaration-v1.json','component-runtime-closure-v1.json','component-inputs-v1.json'):
 shutil.copyfile(D/name,O/name)
rows=[]
for role in ('worker','runner','observer'):
 p=Path(offer['sources'][role]['path']);raw=p.read_bytes();text=raw.decode()
 if role=='worker':
  text=text.replace('"""UNEXECUTED whole codec/image and unknown-initializer calibration worker.','"""UNEXECUTED worker Source for a complete mirrored-receptor and conventional comparison.')
  text=text.replace('Only fresh reviewed once-run execution may load/call the four components.','Only fresh reviewed once-run execution may load/call the seven components.')
  text=text.replace('No Native/FOL-kernel/Model/Reader/inverse/solver imports or calls. No hostile sandbox','No Native/FOL/Model/Reader/inverse/solver imports or calls. No hostile sandbox')
 if role=='observer':
  text=text.replace('fixed-codec-initializer-component-terminal-observer-v1','mirrored-receptor-comparison-terminal-observer-v1')
  text=text.replace('Finite codec/image and unknown-certificate initializer component calibration only; no physical interpreter, FOL kernel/proof search or advantage qualification.','Finite mirror component and same-advice search comparison only; full FOL kernel and search advantage remain unqualified.')
 raw=text.encode();out=O/p.name;out.write_bytes(raw);old=offer['sources'][role]
 rows.append(dict(role=role,path=str(out),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),earlier_pin=old,
                  reconstructed_after_review=True,matches_earlier_pin=(len(raw)==old['bytes']and hashlib.sha256(raw).hexdigest()==old['sha256'])))
receipt=dict(schema='ROOT-prospective-tuple-retirement-v1',subject_sha256=offer['subject_sha256'],
 actual_invocations=0,grant_maximum=0,retired=True,actual_authorized=False,
 reason='B Source quota mismatch; V2 enforces full documented quota. Root worker partial-completion ledger corrected and observer/header scoped. No actual existed and no prefix/grant can be rescued.',
 source_reconstructions=rows)
(D/'ROOT-prospective-v1-retirement.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(retired=True,actual_invocations=0,all_raw_Source_reconstructions_match=all(r['matches_earlier_pin']for r in rows))))
