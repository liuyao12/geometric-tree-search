"""SOURCE-ONLY, UNEXECUTED finite Wang unknown-certificate initialization.

No machine simulator, proof checker, tiling search, or top-level compiler call.
The palette depends on the fixed machine and fixed certificate wire mapping,
never on a theorem, certificate, finite capacity, board width or time horizon.
All four edges of every square have exact colors; rotations are forbidden.
"""

VERSION = 'finite-wang-unknown-certificate-initializer-v1'
SCHEMA = 'finite-framed-wang-spacetime-v1'
POINT_PROFILE = 'integer-center-midpoint-translation-only-v1'
LIMIT_KEYS = ('work', 'symbols', 'states', 'tiles', 'colors', 'cells', 'dimension')
MACHINE_KEYS = ('alphabet_size', 'state_count', 'blank', 'initial', 'accepting', 'transitions')
WALL = ('wall',)
_OWNER = object()


class DeclarationError(Exception):
    def __init__(self, message, *, _owner=None):
        self._owner = _owner
        super().__init__(message)


def _invalid(message):
    return DeclarationError(message, _owner=_OWNER)


class CompileLimit(Exception):
    def __init__(self, reason, work, *, _owner=None):
        self.reason = reason
        self.attempted_work = work
        self._owner = _owner
        super().__init__(reason)


def is_own_limit(error):
    return type(error) is CompileLimit and error._owner is _OWNER


def is_own_invalid(error):
    return type(error) is DeclarationError and error._owner is _OWNER


class _Work:
    def __init__(self, check, limits):
        if not callable(check):
            raise _invalid('external check required')
        if type(limits) is not dict or any(type(key) is not str for key in limits) or set(limits) != set(LIMIT_KEYS):
            raise _invalid('exact declared finite limits required')
        for key in LIMIT_KEYS:
            if type(limits[key]) is not int or limits[key] <= 0:
                raise _invalid('positive exact-int limit required')
        self.limits = dict(limits)
        self.check = check
        self.work = 0
        check()

    def step(self):
        self.work += 1
        if self.work > self.limits['work']:
            raise CompileLimit('work', self.work, _owner=_OWNER)
        self.check()

    def bound(self, key, number):
        self.step()
        if number > self.limits[key]:
            raise CompileLimit(key, self.work, _owner=_OWNER)


def _integer(value, low, high):
    if type(value) is not int or not low <= value < high:
        raise _invalid('exact integer outside declared range')
    return value


def _machine(declaration, work):
    if (type(declaration) is not dict or any(type(key) is not str for key in declaration)
            or set(declaration) != set(MACHINE_KEYS)):
        raise _invalid('exact machine fields required')
    alphabet = declaration['alphabet_size']
    states = declaration['state_count']
    if type(alphabet) is not int or alphabet < 1 or type(states) is not int or states < 1:
        raise _invalid('positive finite alphabet and state counts required')
    work.bound('symbols', alphabet)
    work.bound('states', states)
    blank = _integer(declaration['blank'], 0, alphabet)
    initial = _integer(declaration['initial'], 0, states)
    accepting = _integer(declaration['accepting'], 0, states)
    rows = declaration['transitions']
    if type(rows) is not list:
        raise _invalid('literal transition list required')
    table = {}
    for row in rows:
        work.step()
        if type(row) is not list or len(row) != 5:
            raise _invalid('transition must be [state, read, next, write, displacement]')
        q, read, next_q, write, move = row
        _integer(q, 0, states)
        _integer(read, 0, alphabet)
        _integer(next_q, 0, states)
        _integer(write, 0, alphabet)
        _integer(move, -1, 2)
        if q == accepting:
            raise _invalid('accepting state must have no outgoing transition')
        if (q, read) in table:
            raise _invalid('transition domain must be deterministic, without duplicates')
        table[q, read] = (next_q, write, move)
    # Owned immutable snapshot. Input ownership and read-only callbacks are required.
    return (alphabet, states, blank, initial, accepting,
            tuple((q, read) + table[q, read] for q, read in sorted(table)))


def _machine_record(machine):
    alphabet, states, blank, initial, accepting, transitions = machine
    return dict(alphabet_size=alphabet, state_count=states, blank=blank,
                initial=initial, accepting=accepting,
                transitions=[list(row) for row in transitions])


def _configuration(initial_word, machine, work):
    if type(initial_word) is not list or not initial_word:
        raise _invalid('nonempty literal configuration required')
    alphabet, states, blank, initial, accepting, transitions = machine
    copied = []
    heads = 0
    for cell in initial_word:
        work.step()
        if type(cell) is not tuple or not cell or type(cell[0]) is not str:
            raise _invalid('exact tuple cell literal required')
        if len(cell) == 2 and cell[0] == 'plain':
            _integer(cell[1], 0, alphabet)
        elif len(cell) == 3 and cell[0] == 'head':
            _integer(cell[1], 0, states)
            _integer(cell[2], 0, alphabet)
            if cell[1] != initial:
                raise _invalid('initial head must have declared initial state')
            heads += 1
        else:
            raise _invalid('invalid complete cell literal')
        copied.append(cell)
    if heads != 1:
        raise _invalid('exactly one initial head required')
    return tuple(copied)


def _local_update(left, center, right, table):
    """Partial radius-one rule. This constructs tile schemas, not a run."""
    triple = (left, center, right)
    heads = [index for index, cell in enumerate(triple) if cell[0] == 'head']
    if len(heads) > 1:
        return None
    if not heads:
        return center  # center is plain because the compiler excludes wall centers.
    position = heads[0]
    head = triple[position]
    transition = table.get((head[1], head[2]))
    if transition is None:
        return None  # includes accepting and every other halting head.
    next_q, write, move = transition
    if position == 1:
        if (move == -1 and left == WALL) or (move == 1 and right == WALL):
            return None
        if move == 0:
            return ('head', next_q, write)
        return ('plain', write)
    if (position == 0 and move == 1) or (position == 2 and move == -1):
        return ('head', next_q, center[1])
    return center


def _palette(machine, work):
    alphabet, states, blank, initial, accepting, transitions = machine
    # Exact cardinality preflight precedes any cell/product materialization.
    # This is a count of the full retained palette, never a reachable trim.
    cardinality = _cardinality(machine, work)
    work.bound('tiles', cardinality['base_tiles'])
    table = {(row[0], row[1]): row[2:] for row in transitions}
    cells = []
    for symbol in range(alphabet):
        work.step()
        cells.append(('plain', symbol))
    for state in range(states):
        for symbol in range(alphabet):
            work.step()
            cells.append(('head', state, symbol))
    colors = []
    color_ids = {}
    tiles = []

    def color(value):
        work.step()
        # Dict lookup uses full immutable tuple equality, not hash-only identity.
        if value not in color_ids:
            work.bound('colors', len(colors) + 1)
            color_ids[value] = len(colors)
            colors.append(value)
        return color_ids[value]

    def add(kind, origin, north, east, south, west):
        work.step()
        work.bound('tiles', len(tiles) + 1)
        edges = [color(north), color(east), color(south), color(west)]
        tiles.append(dict(id=len(tiles), kind=kind, origin=origin, edges_NESW=edges,
                          t=[[[0, 0], 1]],
                          m=[[[0, -1], 'edge', edges[0]], [[1, 0], 'edge', edges[1]],
                             [[0, 1], 'edge', edges[2]], [[-1, 0], 'edge', edges[3]]]))

    for left in cells + [WALL]:
        for center in cells:
            for right in cells + [WALL]:
                work.step()
                output = _local_update(left, center, right, table)
                if output is not None:
                    add('step', (left, center, right), ('cell', center),
                        ('pair', center, right), ('cell', output), ('pair', left, center))
    for symbol in range(alphabet):
        for flag in (0, 1):
            add('collect_plain', (symbol, flag), ('cell', ('plain', symbol)),
                ('seen', flag), ('stop',), ('seen', flag))
        add('collect_accept', (accepting, symbol), ('cell', ('head', accepting, symbol)),
            ('seen', 1), ('stop',), ('seen', 0))
    # Exact square frame tiles replace the old boundary relations/selectors.
    for center in cells:
        add('left_step_frame', (center,), ('side', 'left', 'run'), ('pair', WALL, center),
            ('side', 'left', 'run'), ('exterior', 'left'))
        add('right_step_frame', (center,), ('side', 'right', 'run'), ('exterior', 'right'),
            ('side', 'right', 'run'), ('pair', center, WALL))
    add('left_accept_frame', (), ('side', 'left', 'run'), ('seen', 0),
        ('side', 'left', 'done'), ('exterior', 'left'))
    add('right_accept_frame', (), ('side', 'right', 'run'), ('exterior', 'right'),
        ('side', 'right', 'done'), ('seen', 1))
    # Intern these even when no step can emit a given initial cell.
    for cell in cells:
        color(('cell', cell))
    for value in (('stop',), ('side', 'left', 'run'), ('side', 'right', 'run'),
                  ('side', 'left', 'done'), ('side', 'right', 'done'),
                  ('exterior', 'left'), ('exterior', 'right')):
        color(value)
    return dict(schema=SCHEMA, version=VERSION, machine=_machine_record(machine),
                color_constructors=colors, tiles=tiles, transformations='translations_only_2Z2',
                point_profile=POINT_PROFILE, edge_order='NESW', mathematical_authority=False)


def compile_legacy_palette(machine, *, check, limits):
    """Uniform finite palette from a machine alone. UNEXECUTED SOURCE."""
    work = _Work(check, limits)
    owned = _machine(machine, work)
    result = _palette(owned, work)
    if _machine(machine, work) != owned:
        raise _invalid('machine changed during compilation')
    check()
    return dict(status='PALETTE_CANDIDATE', palette=result, attempted_work=work.work,
                mathematical_authority=False, executed_source_qualified=False)


def compile_legacy_finite_problem(machine, initial_word, steps, *, check, limits):
    """Whole palette plus exact finite board, not a history/tiling witness.

    initial_word is a complete in-strip configuration: cell literals are exact
    tuples ('plain', symbol) or ('head', state, symbol). Time is exact, not <=.
    The word and machine must be exclusively owned with read-only callbacks.
    """
    work = _Work(check, limits)
    owned = _machine(machine, work)
    palette = _palette(owned, work)  # Never trim to the input/target/horizon.
    alphabet, states, blank, initial, accepting, transitions = owned
    if type(initial_word) is not list or not initial_word:
        raise _invalid('nonempty literal configuration required')
    width = len(initial_word)
    if type(steps) is not int or steps < 0:
        raise _invalid('nonnegative exact-int step count required')
    work.bound('dimension', width + 2)
    work.bound('dimension', steps + 1)
    work.bound('cells', (width + 2) * (steps + 1))
    copied = _configuration(initial_word, owned, work)
    if len(copied) != width:
        raise _invalid('input length changed before boundary construction')
    color_ids = {value: index for index, value in enumerate(palette['color_constructors'])}
    north = [color_ids[('side', 'left', 'run')]]
    north += [color_ids[('cell', cell)] for cell in copied]
    north += [color_ids[('side', 'right', 'run')]]
    south = [color_ids[('side', 'left', 'done')]]
    south += [color_ids[('stop',)]] * width
    south += [color_ids[('side', 'right', 'done')]]
    height = steps + 1
    west = [color_ids[('exterior', 'left')]] * height
    east = [color_ids[('exterior', 'right')]] * height
    required = []
    pins = []
    for y in range(height):
        for x in range(width + 2):
            work.step()
            required.append([2 * x, 2 * y])
        pins.append([[-1, 2 * y], 'edge', west[y]])
        pins.append([[2 * (width + 2) - 1, 2 * y], 'edge', east[y]])
    for x in range(width + 2):
        work.step()
        pins.append([[2 * x, -1], 'edge', north[x]])
        pins.append([[2 * x, 2 * height - 1], 'edge', south[x]])
    # Exact literal reconciliation of these small immutable declaration carriers.
    if _configuration(initial_word, owned, work) != copied or _machine(machine, work) != owned:
        raise _invalid('input changed during compilation')
    check()
    return dict(schema='finite-framed-wang-instance-v1', version=VERSION,
                status='FINITE_PROBLEM_CANDIDATE', palette=palette,
                initial_word=list(copied), machine_steps=steps, tape_width=width,
                board_width=width + 2, board_height=height,
                boundary_NESW=[north, east, south, west], required_centers=required,
                admissible_origins=required.copy(), fixed_background_marks=pins,
                candidate_universe='every palette tile ID at every admissible origin; no rotations/reflections',
                all_root_generations=0, attempted_work=work.work,
                mathematical_authority=False, executed_source_qualified=False)


def _wire(specification, machine, work):
    if (type(specification) is not dict or any(type(k) is not str for k in specification)
            or set(specification) != {'zero', 'one', 'terminator'}):
        raise _invalid('exact three-symbol certificate wire specification required')
    alphabet, states, blank, initial, accepting, transitions = machine
    if initial == accepting:
        raise _invalid('BOOT and ACCEPT must be distinct states in this profile')
    values = tuple(_integer(specification[k], 0, alphabet)
                   for k in ('zero', 'one', 'terminator'))
    for value in values:
        work.step()
    if len(set(values + (blank,))) != 4:
        raise _invalid('zero, one, terminator and blank must be distinct symbols')
    return values


def _fixed_band(cells, machine, work):
    if type(cells) is not list:
        raise _invalid('literal list of fixed cell tuples required')
    alphabet, states, blank, initial, accepting, transitions = machine
    copied = []
    for cell in cells:
        work.step()
        if type(cell) is not tuple or not cell or type(cell[0]) is not str:
            raise _invalid('exact immutable fixed-cell tuple required')
        if len(cell) == 2 and cell[0] == 'plain':
            _integer(cell[1], 0, alphabet)
        elif len(cell) == 3 and cell[0] == 'head':
            _integer(cell[1], 0, states)
            _integer(cell[2], 0, alphabet)
            if cell[1] != initial:
                raise _invalid('fixed head must be the machine initial head')
        else:
            raise _invalid('fixed cells are plain symbols or the exact initial head')
        copied.append(cell)
    return tuple(copied)


def _cardinality(machine, work):
    alphabet, states, blank, initial, accepting, transitions = machine
    defined = len(transitions)
    stationary = 0
    for row in transitions:
        work.step()
        stationary += int(row[4] == 0)
    cells = alphabet * (states + 1)
    steps = (alphabet * (alphabet + 1) * (alphabet + 1)
             + 3 * defined * alphabet * (alphabet + 1)
             + stationary * (alphabet + 1))
    base = steps + 3 * alphabet + 2 * cells + 2
    return dict(alphabet=alphabet, states=states, defined_transitions=defined,
                stationary_transitions=stationary, cell_alphabet=cells,
                naive_triple_attempts=cells * (cells + 1) * (cells + 1),
                retained_step_tiles=steps, base_tiles=base,
                initializer_tiles=9 * alphabet + 16,
                total_tiles=base + 9 * alphabet + 16,
                initializer_new_colors=2 * alphabet + 11)


def _selector_palette(machine, wire, work):
    """Full old machine palette plus a new finite initialization strip.

    Machine and wire are supplied as one whole fixed profile. No theory, target,
    certificate capacity, proof, execution trace or board dimensions enter.
    """
    counts = _cardinality(machine, work)
    work.bound('tiles', counts['total_tiles'])
    palette = _palette(machine, work)
    alphabet, states, blank, initial, accepting, transitions = machine
    zero, one, terminator = wire
    colors = palette['color_constructors']
    color_ids = {value: index for index, value in enumerate(colors)}
    tiles = palette['tiles']
    base_tile_count = len(tiles)
    base_color_count = len(colors)
    work.bound('tiles', base_tile_count + 9 * alphabet + 16)
    work.bound('colors', base_color_count + 2 * alphabet + 11)

    def color(value):
        work.step()
        if value not in color_ids:
            work.bound('colors', len(colors) + 1)
            color_ids[value] = len(colors)
            colors.append(value)
        return color_ids[value]

    def state(phase, head_seen):
        return ('init_horizontal', phase, head_seen)

    def add(kind, detail, north, east, south, west):
        work.step()
        work.bound('tiles', len(tiles) + 1)
        edges = [color(north), color(east), color(south), color(west)]
        tiles.append(dict(id=len(tiles), kind=kind, origin=detail, edges_NESW=edges,
                          t=[[[0, 0], 1]],
                          m=[[[0, -1], 'edge', edges[0]], [[1, 0], 'edge', edges[1]],
                             [[0, 1], 'edge', edges[2]], [[-1, 0], 'edge', edges[3]]]))

    # A fixed symbol may precede the free band, follow it, or be the first
    # fixed suffix symbol after the terminating/padding phase. ACTIVE cannot
    # exit through a fixed cell, so an actual semicolon is always required.
    for before, after in (('PRE', 'PRE'), ('PAD', 'POST'), ('POST', 'POST')):
        for symbol in range(alphabet):
            for head_seen in (0, 1):
                add('init_fixed_plain', (before, after, symbol, head_seen),
                    ('init_north', 'plain', symbol), state(after, head_seen),
                    ('cell', ('plain', symbol)), state(before, head_seen))
            add('init_fixed_head', (before, after, symbol),
                ('init_north', 'head', initial, symbol), state(after, 1),
                ('cell', ('head', initial, symbol)), state(before, 0))
    for before in ('PRE', 'ACTIVE'):
        for head_seen in (0, 1):
            for symbol in (zero, one):
                add('init_free_bit', (before, symbol, head_seen),
                    ('init_north', 'free'), state('ACTIVE', head_seen),
                    ('cell', ('plain', symbol)), state(before, head_seen))
            add('init_free_terminator', (before, head_seen),
                ('init_north', 'free'), state('PAD', head_seen),
                ('cell', ('plain', terminator)), state(before, head_seen))
    for head_seen in (0, 1):
        add('init_free_padding', (head_seen,),
            ('init_north', 'free'), state('PAD', head_seen),
            ('cell', ('plain', blank)), state('PAD', head_seen))
    add('init_left_frame', (), ('init_north', 'frame', 'left'), state('PRE', 0),
        ('side', 'left', 'run'), ('exterior', 'left'))
    add('init_right_frame', (), ('init_north', 'frame', 'right'), ('exterior', 'right'),
        ('side', 'right', 'run'), state('POST', 1))
    # All eight horizontal states occur in the generated rows even if a
    # specific fixed input makes some states unreachable. Do not trim them.
    for phase in ('PRE', 'ACTIVE', 'PAD', 'POST'):
        for head_seen in (0, 1):
            color(state(phase, head_seen))
    palette['schema'] = 'finite-wang-unknown-certificate-palette-v1'
    palette['initializer'] = dict(
        schema='one-certificate-band-finite-selector-v1',
        wire=dict(zero=zero, one=one, terminator=terminator, blank=blank),
        added_tiles=len(tiles) - base_tile_count,
        added_colors=len(colors) - base_color_count,
        expected_added_tiles=9 * alphabet + 16,
        expected_added_colors=2 * alphabet + 11,
        base_tiles=base_tile_count, base_colors=base_color_count,
        head_state=initial, phases=['PRE', 'ACTIVE', 'PAD', 'POST'],
        free_language='(zero|one)* terminator blank*',
        boot_parser_required=True,
        complete_fixed_interpreter_established=False)
    palette['cardinality'] = counts
    return palette


def describe_unknown_palette_cardinality(machine, wire_specification, *, check, limits):
    """Exact full tile count without materializing cells, triples or tiles.

    Counts may exceed the declared tile cap: no palette is requested/returned.
    The machine and fixed wire profile still receive full literal validation.
    """
    work = _Work(check, limits)
    owned = _machine(machine, work)
    wire = _wire(wire_specification, owned, work)
    counts = _cardinality(owned, work)
    if _machine(machine, work) != owned or _wire(wire_specification, owned, work) != wire:
        raise _invalid('machine or wire changed during cardinality description')
    check()
    return dict(schema='finite-wang-unknown-palette-cardinality-v1', version=VERSION,
                status='EXACT_CARDINALITY_SOURCE_CANDIDATE', counts=counts,
                palette_materialized=False, attempted_work=work.work,
                mathematical_authority=False, executed_source_qualified=False)


def compile_unknown_palette(machine, wire_specification, *, check, limits):
    """Uniform in the fixed machine AND wire; independent of public input/bounds.

    Caller exclusively owns inputs; callbacks are read-only. Foreign callback
    exceptions escape unchanged. No solver, proof checker or host syntax filter.
    """
    work = _Work(check, limits)
    owned = _machine(machine, work)
    wire = _wire(wire_specification, owned, work)
    palette = _selector_palette(owned, wire, work)
    if _machine(machine, work) != owned or _wire(wire_specification, owned, work) != wire:
        raise _invalid('machine or wire changed during palette construction')
    check()
    return dict(status='UNKNOWN_CERTIFICATE_PALETTE_CANDIDATE', palette=palette,
                attempted_work=work.work, mathematical_authority=False,
                executed_source_qualified=False)


def compile_unknown_problem(machine, wire_specification, fixed_prefix,
                            certificate_capacity, fixed_suffix, steps, *, check, limits):
    """Bind exact whole fixed data and one unknown finite certificate word.

    Prefix/suffix are complete literal cell tuples. The combined fixed data
    contains exactly one initial head, and suffix is nonempty. The caller must
    separately establish how these fixed symbols encode its complete checker
    and public theory/target; this generic compiler does not invent that binding.
    Every full palette tile remains admissible at every required center.
    """
    work = _Work(check, limits)
    owned = _machine(machine, work)
    wire = _wire(wire_specification, owned, work)
    prefix = _fixed_band(fixed_prefix, owned, work)
    suffix = _fixed_band(fixed_suffix, owned, work)
    if not suffix:
        raise _invalid('a fixed nonempty suffix closes the certificate band')
    heads = 0
    for cell in prefix + suffix:
        work.step()
        heads += int(cell[0] == 'head')
    if heads != 1:
        raise _invalid('combined fixed bands require exactly one initial head')
    if type(certificate_capacity) is not int or certificate_capacity < 1:
        raise _invalid('positive exact-int free-band capacity including terminator')
    if type(steps) is not int or steps < 0:
        raise _invalid('nonnegative exact-int physical transition horizon')
    width = len(prefix) + certificate_capacity + len(suffix)
    height = steps + 2
    work.bound('dimension', width + 2)
    work.bound('dimension', height)
    work.bound('cells', (width + 2) * height)
    palette = _selector_palette(owned, wire, work)
    colors = {value: index for index, value in enumerate(palette['color_constructors'])}
    north = [colors[('init_north', 'frame', 'left')]]
    for cell in prefix:
        work.step()
        key = ('init_north', 'plain', cell[1]) if cell[0] == 'plain' else ('init_north', 'head', cell[1], cell[2])
        north.append(colors[key])
    for index in range(certificate_capacity):
        work.step()
        north.append(colors[('init_north', 'free')])
    for cell in suffix:
        work.step()
        key = ('init_north', 'plain', cell[1]) if cell[0] == 'plain' else ('init_north', 'head', cell[1], cell[2])
        north.append(colors[key])
    north.append(colors[('init_north', 'frame', 'right')])
    south = [colors[('side', 'left', 'done')]]
    for index in range(width):
        work.step()
        south.append(colors[('stop',)])
    south.append(colors[('side', 'right', 'done')])
    west = [colors[('exterior', 'left')]] * height
    east = [colors[('exterior', 'right')]] * height
    required = []
    pins = []
    for y in range(height):
        for x in range(width + 2):
            work.step()
            required.append([2 * x, 2 * y])
        pins.append([[-1, 2 * y], 'edge', west[y]])
        pins.append([[2 * (width + 2) - 1, 2 * y], 'edge', east[y]])
    for x in range(width + 2):
        work.step()
        pins.append([[2 * x, -1], 'edge', north[x]])
        pins.append([[2 * x, 2 * height - 1], 'edge', south[x]])
    if (_machine(machine, work) != owned or _wire(wire_specification, owned, work) != wire
            or _fixed_band(fixed_prefix, owned, work) != prefix
            or _fixed_band(fixed_suffix, owned, work) != suffix):
        raise _invalid('caller-owned inputs changed during construction')
    check()
    return dict(schema='finite-wang-unknown-certificate-problem-v1', version=VERSION,
                status='UNKNOWN_CERTIFICATE_PROBLEM_CANDIDATE', palette=palette,
                fixed_prefix=list(prefix), fixed_suffix=list(suffix),
                certificate_capacity=certificate_capacity,
                physical_machine_steps=steps, tape_width=width,
                board_width=width + 2, board_height=height,
                boundary_NESW=[north, east, south, west], required_centers=required,
                admissible_origins=[point[:] for point in required], fixed_background_marks=pins,
                candidate_universe='every full palette tile ID at every declared origin; translations only',
                all_root_generations=0, attempted_work=work.work,
                public_problem_semantics_established=False,
                universal_interpreter_established=False,
                mathematical_authority=False, executed_source_qualified=False)
