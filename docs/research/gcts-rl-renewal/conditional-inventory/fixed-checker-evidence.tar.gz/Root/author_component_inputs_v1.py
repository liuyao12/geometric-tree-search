"""Ordinary input declaration authoring; no codec, solver or semantic calls."""
from pathlib import Path
import json
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
selectors=[]
for b in (4,5):
    for n in (1,2,3,4):
        for head in ('prefix','suffix'):
            selectors.append(dict(id=f'selector-b{b}-capacity{n}-head-{head}',
                machine=dict(alphabet_size=b,state_count=2,blank=0,initial=0,accepting=1,
                    transitions=[[0,read,1,read,0]for read in range(b)]),
                wire=dict(zero=1,one=2,terminator=3),capacity=n,steps=1,
                prefix=[['head',0,b-1]]if head=='prefix'else[['plain',b-1]],
                suffix=[['plain',b-1]]if head=='prefix'else[['head',0,b-1]]))
values=[
    dict(id='scalar-tags',values=[None,False,True,0,1,-1,7,-7,'']),
    dict(id='containers-and-order',values=[[],{},[False,0,None],{'b':False,'a':0}, {'inner':[1,-2,{'k':'value'}]}]),
    dict(id='unicode-boundaries',codepoint_strings=[[x]for x in(0,127,128,2047,2048,55295,55296,56319,56320,57343,57344,65535,65536,1114111)]),
    dict(id='surrogate-pair-versus-astral',codepoint_strings=[[55296,56320],[65536],[55296,0,56320]]),
    dict(id='seeded-values',values=[{'protocol':'first-order','target':['all','x',['eq','x','x']]},[],[]],seed_nodes=[[1,256],[2,257]])
]
inputs=dict(schema='fixed-codec-initializer-inputs-v1',
    integers=list(range(257))+[511,512,1023,1024,65535,65536,18446744073709551615],
    malformed_integers=['','1','10','100','11000','00','010','2',';','01'],
    values=values,selectors=selectors,
    all_opcodes_program=dict(atom_max=256,nil=256,nodes=[[1,256]],constants=[0,1,256,257],functions=[
        dict(name='main',arity=1,registers=8,code=[['const',1,1],['move',2,0],['cons',3,1,0],['head',4,3],['tail',5,3],['pair',6,3],['atom',7,4,1],['succ',4,1],['not',7,7],['branch',7,10,10],['jump',11],['call',2,1,[0]],['return',2]]),
        dict(name='identity',arity=1,registers=1,code=[['return',0]])]),
    diagnostics=[
        dict(id='codec-integer-bool',operation='codec_integer_bool',expected='INVALID'),
        dict(id='codec-integer-negative',operation='codec_integer_negative',expected='INVALID'),
        dict(id='codec-duplicate-node',operation='codec_duplicate_node',expected='INVALID'),
        dict(id='codec-forward-node',operation='codec_forward_node',expected='INVALID'),
        dict(id='codec-call-arity',operation='codec_call_arity',expected='INVALID'),
        dict(id='codec-selected-checker-subset',operation='codec_checker_subset',expected='INVALID'),
        dict(id='codec-float-value',operation='codec_float_value',expected='INVALID'),
        dict(id='codec-negative-zero-tag',operation='codec_negative_zero',expected='INVALID'),
        dict(id='codec-invalid-utf8',operation='codec_invalid_utf8',expected='INVALID'),
        dict(id='codec-postfix-underflow',operation='codec_underflow',expected='INVALID'),
        dict(id='codec-postfix-garbage-padding',operation='codec_padding',expected='INVALID'),
        dict(id='selector-equal-wire',operation='selector_equal_wire',expected='INVALID'),
        dict(id='selector-zero-head',operation='selector_zero_head',expected='INVALID'),
        dict(id='selector-two-heads',operation='selector_two_heads',expected='INVALID'),
        dict(id='selector-missing-suffix',operation='selector_missing_suffix',expected='INVALID'),
        dict(id='selector-bool-capacity',operation='selector_bool_capacity',expected='INVALID'),
        dict(id='selector-equal-boot-accept',operation='selector_equal_boot_accept',expected='INVALID'),
        dict(id='codec-owned-work',operation='codec_owned_work',expected='LIMIT'),
        dict(id='selector-owned-work',operation='selector_owned_work',expected='LIMIT'),
        dict(id='selector-owned-output-preflight',operation='selector_output_preflight',expected='LIMIT'),
        dict(id='codec-foreign',operation='codec_foreign',expected='FOREIGN'),
        dict(id='selector-foreign',operation='selector_foreign',expected='FOREIGN'),
        dict(id='codec-same-class-foreign',operation='codec_same_class_foreign',expected='FOREIGN'),
        dict(id='selector-same-class-foreign',operation='selector_same_class_foreign',expected='FOREIGN')
    ],
    scope='All declared inputs retained; no execution by this authoring script. New independent component question; no mirror grant/prefix rescue and no physical foundation/VM generation.')
(D/'component-inputs-v1.json').write_text(json.dumps(inputs,ensure_ascii=True,indent=2,sort_keys=True)+'\n')
