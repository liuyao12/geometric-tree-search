"""Raw Source text reconstruction only; never import/execute the component."""
from pathlib import Path
import hashlib, json
D = Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
p = D / 'wang_unknown_certificate_initializer_v1.py'
s = p.read_text()
s = s.replace("class DeclarationError(Exception):\n    def __init__(self, message, *, _owner=None):\n        self._owner = _owner\n        super().__init__(message)\n\n\ndef _invalid(message):\n    return DeclarationError(message, _owner=_OWNER)", "class DeclarationError(Exception):\n    pass")
s = s.replace("return type(error) is DeclarationError and error._owner is _OWNER", "return type(error) is DeclarationError")
s = s.replace('raise _invalid(', 'raise DeclarationError(')
s = s.replace("    # Exact cardinality preflight precedes any cell/product materialization.\n    # This is a count of the full retained palette, never a reachable trim.\n    cardinality = _cardinality(machine, work)\n    work.bound('tiles', cardinality['base_tiles'])\n", '')
a = s.index('\ndef _cardinality(')
b = s.index('\ndef _selector_palette(', a)
s = s[:a] + s[b:]
s = s.replace('Machine and wire are supplied as one whole fixed profile. No theory, target,', 'The machine is supplied as a whole deterministic table. No theory, target,')
s = s.replace("    counts = _cardinality(machine, work)\n    work.bound('tiles', counts['total_tiles'])\n", '')
s = s.replace("    palette['cardinality'] = counts\n", '')
a = s.index('\ndef describe_unknown_palette_cardinality(')
b = s.index('\ndef compile_unknown_palette(', a)
s = s[:a] + s[b:]
s = s.replace('Uniform in the fixed machine AND wire; independent of public input/bounds.', 'Uniform full palette; independent of public input and all finite bounds.')
raw = s.encode()
digest = hashlib.sha256(raw).hexdigest()
out = D / 'wang_unknown_certificate_initializer_PREFREEZE_v0.py'
out.write_bytes(raw)
(D / 'prefreeze-reconstruction-custody-v0.json').write_text(json.dumps({
    'schema': 'raw-Source-prefreeze-reconstruction-v0',
    'reconstructed_after_review_findings': True,
    'path': str(out), 'bytes': len(raw), 'sha256': digest,
    'earlier_observed_sha256': '8621aaeb39f5afc08e4bee16490a2d1fca0bc3d83f231ae72d9d9546f2e31e8e',
    'matches_earlier_observed_bytes': digest == '8621aaeb39f5afc08e4bee16490a2d1fca0bc3d83f231ae72d9d9546f2e31e8e',
    'component_calls': 0, 'not_a_saved_actual_preimage': True
}, indent=2, sort_keys=True) + '\n')
print(json.dumps({'sha256': digest, 'bytes': len(raw)}))
