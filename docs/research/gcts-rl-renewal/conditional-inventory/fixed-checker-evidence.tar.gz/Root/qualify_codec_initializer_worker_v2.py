"""UNEXECUTED whole codec/image and unknown-initializer calibration worker.

Only fresh reviewed once-run execution may load/call the four components.
No Native/FOL-kernel/Model/Reader/inverse/solver imports or calls. No hostile sandbox
claim: input ownership, Source/callable custody and finite external gates apply.
"""
import time
NOW = time.monotonic_ns
ENTRY_NS = NOW()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'fixed-codec-initializer-component-worker-v2'
SOURCE_ROLES = ('worker','selector','codec','tree','legacy_wang','fol_source','wire_source','combined_source','runner','observer')
SOURCE_PINS = {}  # Exact whole-subject Source pins are bound by the reviewed plan.

OUTER_LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
    stderr_bytes=4194304, worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608, observer_bytes=1048576)
SELECTOR_LIMITS=dict(work=400000000,symbols=256,states=100000,tiles=100000,colors=100000,cells=100000,dimension=10000)
CODEC_LIMITS=dict(work=400000000,data_items=2000000,data_depth=128,integer_bits=4096,wire_symbols=8000000,heap_nodes=1000000,constants=100000,functions=10000,instructions=1000000,registers=100000,arguments=2000000,string_bytes=1000000,string_chars=1000000,values=10000,stack_items=4000000,unary_length=10000)
COMPONENT_LIMITS={'selector':SELECTOR_LIMITS,'legacy_wang':SELECTOR_LIMITS,'codec':CODEC_LIMITS}

CHECKPOINT_LIMIT = 400000000
RESERVE_BYTES = 9437184
FORBIDDEN_EVENTS = ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','ctypes.dlopen')


class PolicyFailure(RuntimeError):
    pass


class PlannedForeign(BaseException):
    pass


def need(ok, message):
    if not ok:
        raise PolicyFailure(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('utf8')


def clone(value):
    return json.loads(canonical(value))



def typed_value(value):
    """Strict typed literal carrier preserves dictionary order and tuple/list.

    Only called inside the once actual. Surrogatepass bytes preserve a lone
    surrogate pair versus an astral character, which JSON escapes can alias.
    """
    def visit(x,depth):
        need(depth<=128,'bounded typed argument guard depth')
        t=type(x)
        if x is None:return ['none']
        if t is bool:return ['bool',x]
        if t is int:return ['int',x]
        if t is float:return ['float_hex',x.hex()]
        if t is str:return ['str_utf8_surrogatepass_hex',x.encode('utf8','surrogatepass').hex()]
        if t is list:return ['list',[visit(y,depth+1)for y in x]]
        if t is tuple:return ['tuple',[visit(y,depth+1)for y in x]]
        need(t is dict,'ordinary typed argument carriers')
        return ['dict',[[visit(k,depth+1),visit(v,depth+1)]for k,v in x.items()]]
    return visit(value,0)


def argument_bytes(value):
    return json.dumps(typed_value(value),ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and type(pin['path'])is str and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and
         len(pin['sha256'])==64,'strict finite raw descriptor')
    path=Path(pin['path'])
    need(path.is_absolute()and path==path.resolve()and path.is_file()and not path.is_symlink(),'canonical regular raw input')
    raw=path.read_bytes();need(descriptor(path,raw)==pin,'complete raw hash/size/path join');return raw


def information(error):
    try:return dict(type=type(error).__name__,message=str(error)[:512])
    except BaseException:return dict(type='UNAVAILABLE',message='error metadata unavailable')


def callable_seal(module):
    rows=[];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__)))
            elif type(value)is type and value.__module__==module.__name__ and id(value)not in seen:
                seen.add(id(value));rows.append((key,id(value)))
                owned={}
                for child,item in vars(value).items():
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    owned[child]=item
                pending.append((key+'.',owned))
    return tuple(sorted(rows))


class Session:
    def __init__(self,plan,plan_pin,consumed,actual):
        self.plan,self.plan_pin,self.actual=plan,plan_pin,actual
        self.began=consumed['began_ns'];self.work_deadline=consumed['work_deadline_ns']
        self.overall_deadline=consumed['overall_deadline_ns']
        self.root_calls=0;self.first_fault=None;self.stage='INTAKE';self.active=None
        self.started={};self.completed={};self.raised={};self.modules={};self.seals={};self.denied=[]
        self.oracle_work=0;self.oracle_work_unavailable=0;self.expanded_subtree_delta=0
        self.rows=[];self.diagnostics=[];self.malformed=[];self.component_rows=[];self.component_diagnostics=[];self.retained=[];self.output_pins=[]
        self.component_limits=clone(COMPONENT_LIMITS)

    def check(self):
        self.root_calls+=1
        try:
            need(self.root_calls<=CHECKPOINT_LIMIT,'invocation-total400m Root callback limit')
            need(NOW()<self.work_deadline,'original absolute180s work deadline')
            if self.first_fault is not None:raise self.first_fault
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def policy(self,action):
        try:return action()
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def guard(self):
        def action():
            self.check()
            for role,pin in self.plan['sources'].items():
                checked(pin)
            for role,module in self.modules.items():
                need(module.__file__==self.plan['sources'][role]['path'] and
                     callable_seal(module)==self.seals[role],'owned module origin/function/code/default binding')
            self.check()
        return self.policy(action)

    def fault_gate(self):
        if self.first_fault is not None:raise self.first_fault

    def call(self,role,name,data,action,expected_after=None):
        self.guard();before=argument_bytes(data()if callable(data)else data)
        self.check();key=role+'.'+name;self.started[key]=self.started.get(key,0)+1
        try:
            value=action()
        except BaseException as error:
            self.raised[key]=self.raised.get(key,0)+1
            self.fault_gate()
            self.fault_gate()
            self.guard()
            expected=before if expected_after is None else argument_bytes(expected_after)
            self.policy(lambda:need(argument_bytes(data()if callable(data)else data)==expected,'full literal call arguments after refusal/fault'))
            raise
        self.fault_gate();self.guard()
        expected=before if expected_after is None else argument_bytes(expected_after)
        self.policy(lambda:need(argument_bytes(data()if callable(data)else data)==expected,'full literal call arguments unchanged'))
        self.completed[key]=self.completed.get(key,0)+1
        return value

    def load(self,role):
        self.check();pin=self.plan['sources'][role];checked(pin)
        name='fixed_codec_actual_'+role
        spec=importlib.util.spec_from_file_location(name,pin['path'])
        need(spec is not None and spec.loader is not None,'exact Python Source loader')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module
        spec.loader.exec_module(module)
        need(module.__file__==pin['path'],'exact loaded Source origin')
        self.modules[role]=module;self.seals[role]=callable_seal(module);self.guard()
        return module

    def calls(self,role):
        return sum(value for key,value in self.started.items()if key.startswith(role+'.'))

    def write_json(self,name,value,cap,closure=False):
        path=self.actual/name;temporary=self.actual/(name+'.partial')
        need(not path.exists()and not temporary.exists(),'never overwrite or retry a packet')
        digest=hashlib.sha256();size=0;parts=0
        fd=os.open(str(temporary),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as output:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).iterencode(value):
                raw=part.encode('utf8');size+=len(raw);need(size+1<=cap,'whole JSON packet cap')
                output.write(raw);digest.update(raw);parts+=1
                if parts%1024==0:
                    if closure:need(NOW()<self.overall_deadline,'failure metadata210 deadline')
                    else:self.check()
            output.write(b'\n');digest.update(b'\n');size+=1;output.flush();os.fsync(output.fileno())
        if closure:need(NOW()<self.overall_deadline,'failure metadata completed before210')
        else:self.check()
        os.rename(temporary,path)
        return dict(path=str(path),bytes=size,sha256=digest.hexdigest())


import itertools


def invoke(s,role,name,args,kwargs=None,limits=None,check=None):
    options={}if kwargs is None else dict(kwargs)
    bound=dict(COMPONENT_LIMITS[role]if limits is None else limits)
    callback=s.check if check is None else check
    return s.call(role,name,dict(args=args,kwargs=options,limits=bound),
        lambda:getattr(s.modules[role],name)(*args,**options,check=callback,limits=bound))


def reference_band(s,values,seed,padding):
    """Existing independent native tree JSON adapter; actual-only reference."""
    tree=s.modules['tree']
    heap=tree.Heap([tuple(pair)for pair in seed]);roots=[]
    for value in values:
        s.check();roots.append(tree.encode_json(heap,value))
    out=[]
    for root in roots:
        pending=[root]
        while pending:
            s.check();node=pending.pop()
            if node is None:out.append('1')
            elif node<=256:out.append('0'+''.join('1'if(node>>i)&1 else'0'for i in range(9)))
            else:
                left,right=heap.nodes[node-257];pending.extend((None,right,left))
    s.oracle_work+=1
    return ''.join(out)+';'+'B'*padding+':'


def reference_integer(s,n):
    s.check();s.oracle_work+=1
    if n==0:return '0'
    k=n.bit_length()
    return '1'*k+'0'+''.join('1'if(n>>i)&1 else'0'for i in range(k))


def reference_program_image(s,program):
    """Independent direct grammar writer, actual only, no codec internals."""
    parts=[]
    def bits(value,width):
        s.check();parts.append(''.join('1'if(value>>i)&1 else'0'for i in range(width)))
    def natural(value):parts.append(reference_integer(s,value))
    for byte in b'GCTSVM1':bits(byte,8)
    natural(len(program['nodes']))
    for left,right in program['nodes']:s.check();natural(left);natural(right)
    natural(len(program['constants']))
    for value in program['constants']:s.check();natural(value)
    natural(len(program['functions']))
    opcodes=('const','move','cons','head','tail','pair','atom','succ','not','branch','jump','call','return')
    for function in program['functions']:
        s.check();name=function['name'].encode('utf8','surrogatepass');natural(len(name))
        for byte in name:bits(byte,8)
        natural(function['arity']);natural(function['registers']);natural(len(function['code']))
        for instruction in function['code']:
            s.check();bits(opcodes.index(instruction[0]),4)
            if instruction[0]=='call':
                natural(instruction[1]);natural(instruction[2]);natural(len(instruction[3]))
                for register in instruction[3]:natural(register)
            else:
                for operand in instruction[1:]:natural(operand)
    word=''.join(parts);need(len(word)<=CODEC_LIMITS['wire_symbols'],'whole independent image within declared wire cap')
    s.oracle_work+=1;return word


def qualify_integer(s,n):
    s.active='integer-'+str(n)
    encoded=invoke(s,'codec','encode_integer',[n])
    expected=reference_integer(s,n)
    need(encoded['value']==n and encoded['bits']==expected,'independent complete integer word')
    decoded=invoke(s,'codec','decode_integer',[expected])
    need(type(decoded['value'])is int and decoded['value']==n,'strict natural roundtrip')
    return dict(id=s.active,value=n,bits=expected,complete=True,
                encode_work=encoded['work'],decode_work=decoded['work'])


def qualify_values(s,case):
    s.active=case['id']
    values=clone(case.get('values',[]))
    if 'codepoint_strings'in case:
        for points in case['codepoint_strings']:
            s.check();values.append(''.join(chr(point)for point in points))
    if 'object_entries'in case:values.append(dict(case['object_entries']))
    seed=clone(case.get('seed_nodes',[]));padding=case.get('padding',2)
    limits=dict(CODEC_LIMITS)
    if 'integer_bits'in case:limits['integer_bits']=case['integer_bits']
    encoded=invoke(s,'codec','encode_value_band',[values],
        dict(value_count=len(values),seed_nodes=seed,padding=padding),limits=limits)
    expected=s.call('tree','Heap+encode_json+postfix',dict(values=values,seed=seed,padding=padding),
        lambda:reference_band(s,values,seed,padding))
    need(encoded['band']==expected,'new wire equals complete independent native adapter word')
    decoded=invoke(s,'codec','decode_value_band',[expected],dict(value_count=len(values),seed_nodes=seed),limits=limits)
    need(argument_bytes(decoded['values'])==argument_bytes(values),'full typed values preserved including Unicode characters/order')
    need(argument_bytes(encoded['values'])==argument_bytes(values),'encoder exact typed values')
    return dict(id=case['id'],complete=True,typed_values=typed_value(values),seed_nodes=seed,
        band=expected,encoded_heap=encoded['nodes'],roots=encoded['roots'],
        encode_work=encoded['work'],decode_work=decoded['work'],padding=padding,
        representation='Lossless tagged carrier uses UTF8-surrogatepass hex; JSON escaped surrogate pair and astral spellings are not used as identity.')


def qualify_program(s,program,profile,label):
    s.active=label
    encoded=invoke(s,'codec','encode_program_image',[program],dict(profile=profile))
    reference=s.call('Root','reference_program_image',program,lambda:reference_program_image(s,program))
    need(encoded['image']==reference,'entire image equals independent direct wire grammar')
    decoded=invoke(s,'codec','decode_program_image',[encoded['image']],dict(profile=profile))
    normalized=dict(atom_max=program['atom_max'],nil=program['nil'],
        nodes=[list(row)for row in program['nodes']],constants=program['constants'],
        functions=[dict(name=f['name'],arity=f['arity'],registers=f['registers'],code=f['code'])for f in program['functions']])
    need(argument_bytes(decoded['program'])==argument_bytes(normalized),'complete program image/body roundtrip, not name-only')
    need(argument_bytes(encoded['program'])==argument_bytes(normalized),'complete encoder body equality')
    validated=s.call('tree','validate',program,lambda:s.modules['tree'].validate(program))
    need(validated is True,'independent existing static bytecode grammar')
    s.oracle_work+=1
    return dict(id=label,complete=True,profile=profile,program=normalized,
        image=encoded['image'],counts=encoded['counts'],
        encode_work=encoded['work'],decode_work=decoded['work'],
        source_body_binding='Bound only when caller actually compiled the exact whole frozen Source; no compiler semantic theorem or kernel equivalence.')


def selector_rows(s,palette,north):
    """Independent full-palette literal row enumeration, no compiler predicates."""
    colors=palette['color_constructors'];west=colors.index(('exterior','left'))
    east=colors.index(('exterior','right'));paths=[(west,[])]
    for color in north:
        next_paths=[]
        for previous,path in paths:
            for tile in palette['tiles']:
                s.check();edges=tile['edges_NESW']
                if edges[0]==color and edges[3]==previous:
                    next_paths.append((edges[1],path+[tile['id']]))
        need(len(next_paths)<=100000,'declared row-reference finite population cap')
        paths=next_paths
    s.oracle_work+=1
    return[path for last,path in paths if last==east]


def qualify_selector(s,case):
    s.active=case['id'];machine=clone(case['machine']);wire=clone(case['wire'])
    prefix=[tuple(cell)for cell in case['prefix']];suffix=[tuple(cell)for cell in case['suffix']]
    n=case['capacity'];h=case['steps']
    result=invoke(s,'selector','compile_unknown_problem',[machine,wire,prefix,n,suffix,h])
    uniform=invoke(s,'selector','compile_unknown_palette',[machine,wire])
    counts=invoke(s,'selector','describe_unknown_palette_cardinality',[machine,wire])
    palette=result['palette']
    need(argument_bytes(palette)==argument_bytes(uniform['palette']),'whole palette independent of problem/capacity/horizon')
    base=invoke(s,'legacy_wang','compile_palette',[machine])['palette']
    nb=len(base['tiles']);nc=len(base['color_constructors'])
    need(argument_bytes(palette['tiles'][:nb])==argument_bytes(base['tiles']),'entire original machine tile inventory retained')
    need(argument_bytes(palette['color_constructors'][:nc])==argument_bytes(base['color_constructors']),'entire original color inventory retained')
    b=machine['alphabet_size'];need(len(palette['tiles'])-nb==9*b+16,'actual selector full tile count')
    need(len(palette['color_constructors'])-nc==2*b+11,'actual selector full color count')
    need(counts['counts']['total_tiles']==len(palette['tiles']),'exact preflight count equals actual full palette')
    paths=selector_rows(s,palette,result['boundary_NESW'][0]);projected=[]
    for path in paths:
        s.check();cells=[palette['color_constructors'][palette['tiles'][tile]['edges_NESW'][2]]for tile in path[1:-1]]
        need([cell[1]for cell in cells[:len(prefix)]]==prefix,'all fixed prefix symbols/head unchanged')
        need([cell[1]for cell in cells[-len(suffix):]]==suffix,'all fixed suffix symbols/head unchanged')
        payload=[cell[1]for cell in cells[len(prefix):len(prefix)+n]]
        need(all(cell[0]=='plain'for cell in payload),'no free control heads')
        projected.append(tuple(cell[1]for cell in payload))
    expected=[]
    for length in range(n):
        for bits in itertools.product((wire['zero'],wire['one']),repeat=length):
            s.check();expected.append(bits+(wire['terminator'],)+(machine['blank'],)*(n-length-1))
    need(len(paths)==len(set(projected))and set(projected)==set(expected),'complete unique selector rows equal independently enumerated regular language')
    need(result['board_height']==h+2 and len(result['required_centers'])==(len(prefix)+n+len(suffix)+2)*(h+2),'whole selector+steps+collector board')
    return dict(id=case['id'],complete=True,problem=result,cardinality=counts,
                full_selector_paths=paths,free_words=[list(word)for word in projected],
                reference_words=[list(word)for word in expected],selector_rows=len(paths),
                comparison_scope='Complete top selector strip only; no full machine run, general point-search or proof-search claim.')


def diagnostic(s,declared,inputs,program):
    s.active=declared['id'];op=declared['operation'];expected=declared['expected']
    role='selector'if op.startswith('selector_')else'codec';name='encode_integer';args=[0];kw={}
    limits=dict(COMPONENT_LIMITS[role]);callback=None;foreign=None;calls=0
    def fail():
        nonlocal calls
        s.check();calls+=1;raise foreign
    if role=='codec':
        if op=='codec_integer_bool':args=[True]
        elif op=='codec_integer_negative':args=[-1]
        elif op in('codec_duplicate_node','codec_forward_node','codec_call_arity','codec_checker_subset'):
            name='encode_program_image';p=clone(program);args=[p];kw=dict(profile='generic')
            if op=='codec_duplicate_node':p['nodes'].append(list(p['nodes'][0]))
            elif op=='codec_forward_node':p['nodes'][0][0]=257
            elif op=='codec_call_arity':p['functions'][0]['code'][11][3]=[]
            else:kw['profile']='full_checker_69'
        elif op=='codec_float_value':name='encode_value_band';args=[[0.5]];kw=dict(value_count=1,seed_nodes=[],padding=0)
        elif op in('codec_negative_zero','codec_invalid_utf8','codec_underflow','codec_padding'):
            name='decode_value_band';kw=dict(value_count=1,seed_nodes=[])
            atom=lambda x:'0'+''.join('1'if(x>>i)&1 else'0'for i in range(9))
            if op=='codec_negative_zero':word=atom(4)+atom(256)+'1;:'
            elif op=='codec_invalid_utf8':word=atom(2)+atom(255)+atom(256)+'11;:'
            elif op=='codec_underflow':word='1;:'
            else:word=atom(6)+atom(256)+'1;0:'
            args=[word]
        elif op=='codec_owned_work':limits['work']=1
        elif op=='codec_header_bits':
            name='decode_program_image';limits['integer_bits']=8;kw=dict(profile='generic')
            header_program=dict(atom_max=256,nil=256,nodes=[],constants=[],functions=[dict(name='main',arity=1,registers=1,code=[['return',0]])])
            args=[s.call('Root','reference_header_quota_image',header_program,lambda:reference_program_image(s,header_program))]
        elif op=='codec_seed_bits':
            name='decode_value_band';limits['integer_bits']=8;args=[';:'];kw=dict(value_count=0,seed_nodes=[[0,0]])
        elif op=='codec_padding_encode_bits':
            name='encode_value_band';limits['integer_bits']=8;args=[[]];kw=dict(value_count=0,seed_nodes=[],padding=256)
        elif op=='codec_padding_decode_bits':
            name='decode_value_band';limits['integer_bits']=8;args=[';'+'B'*256+':'];kw=dict(value_count=0,seed_nodes=[])
        elif op in('codec_foreign','codec_same_class_foreign'):
            foreign=PlannedForeign('planned codec callback')if op=='codec_foreign'else s.modules['codec'].Invalid('foreign same class')
            callback=fail
        else:need(False,'unknown prospective codec diagnostic')
    else:
        case=inputs['selectors'][0];machine=clone(case['machine']);wire=clone(case['wire'])
        prefix=[tuple(c)for c in case['prefix']];suffix=[tuple(c)for c in case['suffix']]
        name='compile_unknown_problem';args=[machine,wire,prefix,case['capacity'],suffix,case['steps']]
        if op=='selector_equal_wire':wire['one']=wire['zero']
        elif op=='selector_zero_head':prefix[0]=('plain',0)
        elif op=='selector_two_heads':suffix[0]=('head',0,0)
        elif op=='selector_missing_suffix':args[4]=[]
        elif op=='selector_bool_capacity':args[3]=True
        elif op=='selector_equal_boot_accept':machine['initial']=machine['accepting']
        elif op=='selector_owned_work':limits['work']=1
        elif op=='selector_output_preflight':limits['tiles']=1
        elif op in('selector_foreign','selector_same_class_foreign'):
            foreign=PlannedForeign('planned selector callback')if op=='selector_foreign'else s.modules['selector'].DeclarationError('foreign same class')
            callback=fail
        else:need(False,'unknown prospective selector diagnostic')
    try:invoke(s,role,name,args,kw,limits,callback)
    except BaseException as error:
        s.fault_gate()
        if expected=='FOREIGN':
            need(error is foreign and calls==1,'exact first callback object')
            own=s.call(role,'is_own_invalid',[],lambda:s.modules[role].is_own_invalid(error))
            need(own is False,'same-class foreign invalid is not privately owned')
        else:
            predicate='is_own_invalid'if expected=='INVALID'else'is_own_limit'
            own=s.call(role,predicate,[],lambda:getattr(s.modules[role],predicate)(error))
            need(own is True,'exact declared privately owned refusal')
        return dict(id=declared['id'],operation=op,expected=expected,status='PASSED',
                    callback_count=calls,exact_foreign_identity=(error is foreign)if expected=='FOREIGN'else None,
                    error=information(error))
    need(False,'diagnostic unexpectedly returned')


def qualify(s,inputs):
    s.stage='INTEGER_CALIBRATION';integer_rows=[]
    for n in inputs['integers']:
        row=qualify_integer(s,n);integer_rows.append(row);s.rows.append(row)
    malformed=s.malformed
    for bits in inputs['malformed_integers']:
        s.active='malformed-integer-'+bits
        try:invoke(s,'codec','decode_integer',[bits])
        except BaseException as error:
            s.fault_gate();need(s.call('codec','is_own_invalid',[],lambda:s.modules['codec'].is_own_invalid(error))is True,'planned malformed integer owned refusal')
            malformed.append(dict(bits=bits,status='PASSED',error=information(error)))
        else:need(False,'malformed integer accepted')
    s.stage='VALUE_CALIBRATION';values=[]
    for case in inputs['values']:
        row=qualify_values(s,case);values.append(row);s.rows.append(row)
    s.stage='PROGRAM_CALIBRATION'
    generic=qualify_program(s,clone(inputs['all_opcodes_program']),'generic','all-thirteen-opcodes')
    s.rows.append(generic)
    source=checked(s.plan['sources']['wire_source']).decode('utf8')+checked(s.plan['sources']['fol_source']).decode('utf8').replace('def main(request):','def semantic_main(request):',1)
    need(source.encode()==checked(s.plan['sources']['combined_source']),'entire full checker literal Source concatenation equality')
    full=s.call('tree','Compiler.declaration',source,lambda:s.modules['tree'].Compiler(source).declaration())
    checker=qualify_program(s,full,'full_checker_69','complete-sixty-nine-function-checker')
    s.rows.append(checker)
    s.stage='SELECTOR_CALIBRATION';selectors=[]
    for case in inputs['selectors']:
        row=qualify_selector(s,case);selectors.append(row);s.rows.append(row)
    s.stage='DIAGNOSTICS';diagnostics=s.diagnostics
    for declared in inputs['diagnostics']:
        row=diagnostic(s,declared,inputs,inputs['all_opcodes_program']);diagnostics.append(row)
    return dict(schema='fixed-codec-initializer-calibration-packet-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',
        inputs=inputs,integers=integer_rows,malformed_integers=malformed,values=values,
        programs=[generic,checker],selectors=selectors,diagnostics=diagnostics,
        call_started=s.started,call_completed=s.completed,call_raised=s.raised,
        root_callbacks=s.root_calls,reference_calls=s.oracle_work,
        full_VM_implemented=False,full_FOL_palette_qualified=False,proof_discovery=False,
        complete_machine_run=False,full_pipeline_qualified=False,mathematical_authority=False,
        scope='Whole declared component calibration, no rejected mirror rescue. Independent top-row regular-language enumeration, full old base palette retained and complete69Source-to-image roundtrip. No interpreter/kernel semantic proof or general point-search/theorem advantage.')


def main(plan_path):
    plan_raw=Path(plan_path).read_bytes();need(len(plan_raw)<=16777216,'bounded whole plan')
    plan=json.loads(plan_raw);plan_pin=descriptor(plan_path,plan_raw)
    need(type(plan)is dict and set(plan)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'}and
        plan['schema']=='ROOT-wang-encoding-qualification-plan-v1','exact whole once-plan')
    need(plan['limits']==OUTER_LIMITS and set(plan['sources'])==set(SOURCE_ROLES),'original caps and ten new Source roles')
    actual=Path(plan['actual_directory']);need(actual.is_absolute()and actual==actual.resolve()and actual.is_dir(),'owned fresh actual')
    consumed=json.loads((actual/'CONSUMED.json').read_bytes())
    need(consumed['plan']==plan_pin and consumed['invocation_id']==plan['invocation_id']and
        consumed['schema']=='wang-encoding-qualification-consumed-v1'and
        type(consumed['maximum_worker_launches'])is int and consumed['maximum_worker_launches']==1 and
        consumed['consumed_before_Popen']is True and type(consumed['began_ns'])is int and
        consumed['work_deadline_ns']==consumed['began_ns']+180000000000 and
        consumed['overall_deadline_ns']==consumed['began_ns']+210000000000,'same absolute Source-entry epoch')
    s=Session(plan,plan_pin,consumed,actual)
    try:
        s.check();need(descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['worker'],'whole worker pin')
        for pin in plan['sources'].values():checked(pin)
        checked(plan['python'],67108864)
        declaration=json.loads(checked(plan['declaration']));closure=json.loads(checked(plan['runtime_closure']))
        need(declaration['schema']=='ROOT-wang-encoding-qualification-declaration-v1'and
            declaration['limits']==OUTER_LIMITS and declaration['component_limits']==COMPONENT_LIMITS and
            declaration['checkpoint_limit']==CHECKPOINT_LIMIT and declaration['experiment_kind']=='FIXED_CODEC_AND_UNKNOWN_INITIALIZER_COMPONENT_CALIBRATION','whole new component declaration')
        need(closure['schema']=='ROOT-wang-encoding-runtime-closure-v1'and closure['python']==plan['python']and
            closure['sources']==plan['sources']and closure['declaration']==plan['declaration'],'exact full runtime closure')
        for pin in closure['stdlib_files']:checked(pin)
        need(plan['inputs']==declaration['inputs']and len(plan['inputs'])==1,'one whole declared calibration bank')
        inputs=json.loads(checked(plan['inputs'][0]['pin'],134217728))
        need(inputs['schema']=='fixed-codec-initializer-inputs-v1','exact input schema')
        subject={k:v for k,v in plan.items()if k!='authorization'};auth=json.loads(checked(plan['authorization']))
        need(auth['actual_execution_authorized']is True and auth['author_identity']=='/root'and
            type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and
            auth['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest(),'fresh Root exact-subject grant')
        s.write_json('WORKER_CONSUMED.json',dict(plan=plan_pin,pid=os.getpid(),ppid=os.getppid(),
            worker_entry_ns=ENTRY_NS,maximum_invocations=1),1048576)
        def audit(event,args):
            if event in FORBIDDEN_EVENTS:
                s.denied.append(event);s.policy(lambda:need(False,'forbidden process/network/dlopen'))
        sys.addaudithook(audit)
        for role in('selector','codec','tree','legacy_wang'):s.load(role)
        packet=qualify(s,inputs);s.active=None;s.guard();s.stage='FULL_PACKET_WRITE'
        output=s.write_json('canonical-codec-initializer-calibration.json',packet,134217728-RESERVE_BYTES)
        s.output_pins.append(output)
        counts=dict(compiler_calls=s.calls('selector')+s.calls('legacy_wang')+s.started.get('tree.Compiler.declaration',0),
            search_calls=0,
            verifier_calls=sum(v for k,v in s.started.items()if k.startswith('codec.decode_'))+s.started.get('tree.validate',0),
            oracle_calls=s.oracle_work)
        q=dict(schema='fixed-codec-initializer-component-candidate-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',
            outputs=s.output_pins,case_ids=[r['id']for r in s.rows],
            rows=[dict(id=r['id'],complete=r['complete'])for r in s.rows],
            malformed_integers=packet['malformed_integers'],diagnostics=s.diagnostics,
            diagnostic_ids=[r['id']for r in s.diagnostics],
            full_checker_functions=packet['programs'][1]['counts']['functions'],
            full_checker_instructions=packet['programs'][1]['counts']['instructions'],
            selector_rows=sum(r['selector_rows']for r in packet['selectors']),
            codec_calls=s.calls('codec'),initializer_calls=s.calls('selector'),
            root_check_calls=s.root_calls,root_check_calls_scope='cutoff before metadata, all later callbacks share400m ceiling',
            full_pipeline_qualified=False,mathematical_proof_accepted=False,fixed_FOL_palette_qualified=False,
            gcts_rl_advantage_established=False,learned_pair_markings=False,trained_RL=False,
            complete_physical_VM=False,proof_discovery=False,**counts)
        zeros=dict(Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,FOL_kernel_calls=0,opaque_program_decodes=0)
        payload=dict(schema='wang-encoding-qualification-result-v1',invocation_id=plan['invocation_id'],plan=plan_pin,
            declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],qualification=q,outputs=s.output_pins,
            denied_events=s.denied,canonical_logical_bytes=output['bytes'],expanded_canonical_packet_bytes=output['bytes'],
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,**counts,**zeros)
        s.stage='RESULT_WRITE';result=s.write_json('result.json',payload,134217728-RESERVE_BYTES-output['bytes'])
        s.guard()
        for pin in closure['stdlib_files']:checked(pin)
        checked(plan['inputs'][0]['pin'],134217728);s.check()
        logical=output['bytes']+result['bytes'];need(0<logical<=134217728,'full unshared stored/expanded packet')
        header=dict(schema='wang-encoding-qualification-worker-receipt-v1',version=VERSION,
            invocation_id=plan['invocation_id'],plan=plan_pin,began_ns=s.began,work_deadline_ns=s.work_deadline,
            overall_deadline_ns=s.overall_deadline,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,
            result=result,outputs=s.output_pins,logical_result_bytes=logical,expanded_logical_result_bytes=logical,
            outer_metadata_reservation=RESERVE_BYTES,finite_encoding_candidate=True,
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,
            call_started=s.started,call_completed=s.completed,call_raised=s.raised,
            root_check_calls=s.root_calls,positive_worker_completed_ns=NOW(),**zeros)
        s.stage='HEADER_WRITE';s.write_json('worker-receipt.json',header,4194304)
        need(sum(p.stat().st_size for p in actual.iterdir()if p.is_file())+RESERVE_BYTES<=134217728,'all actual files plus original outer9MiB reserve')
        s.check();return 0
    except BaseException as error:
        primary=s.first_fault if s.first_fault is not None else error
        failure=dict(schema='fixed-codec-initializer-worker-failure-v1',status='FAILED_OR_UNFINISHED',
            plan=plan_pin,invocation_id=plan['invocation_id'],stage=s.stage,active_row=s.active,
            completed_case_ids=[r['id']for r in s.rows],diagnostic_prefix=s.diagnostics,
            completed_malformed_integer_words=[r['bits']for r in s.malformed],
            call_started=s.started,call_completed=s.completed,call_raised=s.raised,root_check_calls=s.root_calls,
            first_available_fault=information(primary),outputs=s.output_pins,
            no_failed_prefix_admission=True,full_pipeline_qualified=False,mathematical_proof_accepted=False)
        try:s.write_json('worker-failure.json',failure,1048576,closure=True)
        except BaseException:pass
        return 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one exact once-plan path')
    raise SystemExit(main(sys.argv[1]))

