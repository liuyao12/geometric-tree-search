"""Root ordinary exact-subject grant metadata; no component execution."""
from pathlib import Path
import json,hashlib,sys
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
def pin(path):
 p=Path(path).resolve();r=p.read_bytes();return dict(path=str(p),bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def save(path,value):
 with path.open('xb')as f:f.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False).encode()+b'\n')
 return pin(path)
offer=json.loads((D/'component-Source-only-offer-v2.json').read_bytes());subject=offer['subject']
rp=Path(sys.argv[1]).resolve();r=json.loads(rp.read_bytes())
assert r['schema']=='wang-encoding-Source-prospective-review-v1'
assert r['reviewer_identity']=='/root/conventional_control_review'and r['review_passed']is True
assert r['source_only']is True and r['component_calls']==0 and r['actual_execution_authorized']is False
assert r['subject']==subject and r['subject_sha256']==offer['subject_sha256']==hashlib.sha256(canon(subject)).hexdigest()
for source in subject['sources'].values():assert pin(source['path'])==source
assert not Path(subject['actual_directory']).exists()
grant=dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',
 actual_execution_authorized=True,maximum_actual_invocations=1,subject_sha256=offer['subject_sha256'],
 review=pin(rp),scope='One fresh whole288case+10malformed+28diagnostic codec/image/initializer calibration only. No physical foundation generator, mirror retry/prefix rescue or broader qualification. Original180/210/1GiB/both128MiB/logs/reserves/cumulative400m unchanged. Root must separately close a fresh all-idle barrier before launching.')
gp=save(D/'component-authorization-once-v2.json',grant)
pp=save(D/'component-plan-authorized-v2.json',dict(subject,authorization=gp))
print(json.dumps(dict(grant=gp,plan=pp),sort_keys=True))
