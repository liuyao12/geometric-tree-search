"""Raw Source authoring only: no component imports or function execution."""
from pathlib import Path
import re
D=Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1')
old=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1/qualify_mirrored_receptor_worker_v2.py').read_text()
s=old[:old.index('\nimport itertools\n')]
s=s.replace('mirrored-receptor-comparison-worker-v2','fixed-codec-initializer-component-worker-v1')
s=s.replace("ensure_ascii=False", "ensure_ascii=True")
s=s.replace("name='certified_point_actual_'+role", "name='fixed_codec_actual_'+role")
s=re.sub(r'^SOURCE_ROLES = .*$',"SOURCE_ROLES = ('worker','selector','codec','tree','legacy_wang','fol_source','wire_source','combined_source','runner','observer')",s,flags=re.M)
s=re.sub(r'^SOURCE_PINS = .*$',"SOURCE_PINS = {}  # Exact whole-subject Source pins are bound by the reviewed plan.",s,flags=re.M)
s=re.sub(r'^INPUT_SHA = .*\nINPUT_BYTES = .*\n', '', s, flags=re.M)
a=s.index('POINT_LIMITS=')
b=s.index('\nCHECKPOINT_LIMIT',a)
s=s[:a]+'''SELECTOR_LIMITS=dict(work=400000000,symbols=256,states=100000,tiles=100000,colors=100000,cells=100000,dimension=10000)
CODEC_LIMITS=dict(work=400000000,data_items=2000000,data_depth=128,integer_bits=4096,wire_symbols=8000000,heap_nodes=1000000,constants=100000,functions=10000,instructions=1000000,registers=100000,arguments=2000000,string_bytes=1000000,string_chars=1000000,values=10000,stack_items=4000000,unary_length=10000)
COMPONENT_LIMITS={'selector':SELECTOR_LIMITS,'legacy_wang':SELECTOR_LIMITS,'codec':CODEC_LIMITS}
'''+s[b:]
s=s.replace("self.guard();before=canonical(data()if callable(data)else data)","self.guard();before=argument_bytes(data()if callable(data)else data)")
s=s.replace('else canonical(expected_after)','else argument_bytes(expected_after)')
s=s.replace('need(canonical(data()if callable(data)else data)==expected','need(argument_bytes(data()if callable(data)else data)==expected')
helper='''
def argument_bytes(value):
    """Strict typed literal carrier preserves dictionary order and tuple/list.

    Only called inside the once actual. Exact surrogate characters are escaped
    by JSON; type annotations prevent Boolean/integer and tuple/list aliases.
    """
    def visit(x,depth):
        need(depth<=128,'bounded typed argument guard depth')
        t=type(x)
        if x is None:return ['none']
        if t is bool:return ['bool',x]
        if t is int:return ['int',x]
        if t is str:return ['str',x]
        if t is list:return ['list',[visit(y,depth+1)for y in x]]
        if t is tuple:return ['tuple',[visit(y,depth+1)for y in x]]
        need(t is dict,'ordinary typed argument carriers')
        return ['dict',[[visit(k,depth+1),visit(v,depth+1)]for k,v in x.items()]]
    return json.dumps(visit(value,0),ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')

'''
pos=s.index('\ndef descriptor(')
s=s[:pos]+'\n'+helper+s[pos:]
(D/'qualify_codec_initializer_worker_v1.py').write_text(s)
