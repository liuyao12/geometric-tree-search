"""Unexecuted physical construction progress; NOT a complete interpreter.

No VM/opcode executor is implemented in the host language.  The only generator
below expands a fixed, image-independent finite collection of symbol-scanning
microprograms into literal single-tape transitions.  The unfinished full-VM
entry point refuses.  In particular, this file is NOT authority for a checker,
an input boundary, a machine-to-Wang reduction, or any theorem.

All numbers/names here concern a fixed workspace, never a checker register,
function, instruction address, heap address, public problem, or finite bound.
Read the accompanying API and open-obligations packet before reuse.
"""

VERSION = 'fixed-vm-physical-foundation-v1'
STATUS = 'PARTIAL_PHYSICAL_CONSTRUCTION_NO_INTERPRETER'
EXECUTION_PROFILE = 'unqualified-fixed-workspace-physical-generator-v1'
COMPLETE_INTERPRETER = False
WIRE_MAGIC = 'GCTSVM1'
WIRE_BIT_ORDER = 'least-significant-bit-first'

# The ten raw symbols have no encoded register/function/address meanings.
# # is a fixed finite band fence, B blank, ^ a band's left delimiter.
RAW = ('B', '^', '0', '1', ':', ',', ';', '|', '!', '#')
WORKSPACE = ('PROGRAM', 'PUBLIC', 'CERTIFICATE', 'HEAP', 'REGISTERS',
             'FRAMES', 'FUNCTION', 'PC', 'DESTINATION', 'LEFT_VALUE',
             'RIGHT_VALUE', 'RETURN_VALUE', 'COUNT', 'TEMPORARY',
             'PARSER_STACK', 'OUTPUT')
HALTS = ('DONE', 'DIFFERENT', 'REJECT', 'BOUND')
UTF8_MODES = ('LEAD', 'CONT1', 'CONT2', 'CONT3', 'E0_FIRST',
              'F0_FIRST', 'F4_FIRST')

# Small-integer identities derived from the Source allocation, not from a
# materialized table or any component execution.  N=assigned microstates;
# M=N+4 includes four unassigned terminal aliases; K=defined micro choices;
# K0=stationary micro choices.  Every row in the source below has fixed size.
STATIC_MACRO_CENSUS = (
    ('scan_to_semicolon', 1, 9, 1),
    ('copy_binary_word', 8, 44, 2),
    ('compare_binary_words', 6, 30, 8),
    ('increment_binary_word', 3, 21, 2),
    ('decode_canonical_U', 17, 74, 5),
    ('validate_utf8_surrogatepass_word', 1785, 3577, 7),
)
STATIC_TOTALS = {
    'assigned_microstates_N': 1820,
    'all_microstates_M': 1824,
    'micro_choices_K': 3755,
    'stationary_micro_choices_K0': 25,
    'fixed_workspace_bands_T': 16,
    'raw_symbols_r': 10,
    'physical_alphabet_b': 37,
    'physical_states_Q': 9108,
    'defined_physical_transitions_D': 225835,
    'stationary_physical_transitions_D0': 38285,
}


class ConstructionIncomplete(Exception):
    """The full fixed VM has no physical controller/boot table in this packet."""


class ConstructionLimit(Exception):
    """Finite table construction limit; never a theorem or machine rejection."""


class _Budget:
    def __init__(self, check, limits):
        if not callable(check) or type(limits) is not dict:
            raise ValueError('explicit construction callback and limits required')
        keys = {'work', 'states', 'symbols', 'transitions', 'undefined_slots'}
        if set(limits) != keys:
            raise ValueError('exact construction limit keys required')
        if any(type(limits[k]) is not int or limits[k] <= 0 for k in keys):
            raise ValueError('positive exact integer construction limits required')
        self.check = check
        self.limits = dict(limits)
        self.work = 0
        self.counts = {k: 0 for k in keys}
        check()

    def step(self, kind, amount=1):
        if type(amount) is not int or amount < 0:
            raise ValueError('internal finite construction charge')
        self.work += amount
        self.counts['work'] = self.work
        if self.work > self.limits['work']:
            raise ConstructionLimit('construction work')
        if kind != 'work':
            self.counts[kind] += amount
            if self.counts[kind] > self.limits[kind]:
                raise ConstructionLimit(kind)
        # Foreign exceptions, including StopIteration/SystemExit, propagate.
        self.check()


class _Micro:
    def __init__(self, budget):
        self.budget = budget
        self.rows = []
        self.names = []
        for name in HALTS:
            self.state(name)

    def state(self, name):
        self.budget.step('work')
        q = len(self.rows)
        self.rows.append(None)
        self.names.append(name)
        return q

    def put(self, q, tape, choices):
        if self.rows[q] is not None or not 0 <= tape < len(WORKSPACE):
            raise ValueError('internal assigned state or workspace')
        copied = {}
        for symbol, action in choices.items():
            self.budget.step('work')
            if symbol not in RAW or symbol == '#' or type(action) is not tuple:
                raise ValueError('internal literal micro choice')
            out, write, move = action
            if type(out) is not int or out < 0 or write not in RAW or move not in (-1, 0, 1):
                raise ValueError('internal literal micro action')
            copied[symbol] = (out, write, move)
        self.rows[q] = (tape, copied)

    def row(self, tape, choices, name):
        q = self.state(name)
        self.put(q, tape, choices)
        return q

    def rewind(self, tape, out, name):
        q = self.state(name)
        choices = {}
        for s in RAW:
            if s != '#':
                choices[s] = (out, s, 1) if s == '^' else (q, s, -1)
        self.put(q, tape, choices)
        return q

    def clear_word(self, tape, out, name):
        loop = self.state(name + '/erase')
        done = self.rewind(tape, out, name + '/rewind-after')
        self.put(loop, tape, {'0': (loop, 'B', 1), '1': (loop, 'B', 1),
                             'B': (done, 'B', 0)})
        return self.rewind(tape, loop, name + '/rewind-before')


def _scan_semicolon(m, tape, out):
    q = m.state('scan/semicolon')
    choices = {}
    for s in RAW:
        if s != '#':
            choices[s] = (out, s, 0) if s == ';' else (q, s, 1)
    m.put(q, tape, choices)
    return q


def _copy_word(m, src, dst, out):
    # Distinct scratch bands, source ^bits B... and destination ^bits B....
    # All destination clearing and source/destination traversals are physical.
    loop = m.state('copy/read-source')
    done = m.rewind(dst, out, 'copy/rewind-output')
    choices = {'B': (done, 'B', 0)}
    for bit in ('0', '1'):
        write = m.row(dst, {'B': (loop, bit, 1)}, 'copy/write-' + bit)
        choices[bit] = (write, bit, 1)
    m.put(loop, src, choices)
    begin = m.rewind(src, loop, 'copy/rewind-source')
    return m.clear_word(dst, begin, 'copy/clear-output')


def _compare_words(m, left, right, yes, no):
    loop = m.state('compare/read-left')
    end = m.row(right, {'0': (no, '0', 0), '1': (no, '1', 0),
                        'B': (yes, 'B', 0)}, 'compare/exact-end')
    choices = {'B': (end, 'B', 0)}
    for bit in ('0', '1'):
        compare = {}
        for s in ('0', '1', 'B'):
            compare[s] = (loop, s, 1) if s == bit else (no, s, 0)
        q = m.row(right, compare, 'compare/read-right-' + bit)
        choices[bit] = (q, bit, 1)
    m.put(loop, left, choices)
    start = m.rewind(right, loop, 'compare/rewind-right')
    return m.rewind(left, start, 'compare/rewind-left')


def _increment_word(m, tape, out):
    # Precondition: canonical nonempty LSB-first binary natural, 0 is '0'.
    carry = m.state('increment/carry')
    done = m.rewind(tape, out, 'increment/rewind-after')
    m.put(carry, tape, {'0': (done, '1', 0), '1': (carry, '0', 1),
                        'B': (done, '1', 0)})
    return m.rewind(tape, carry, 'increment/rewind-before')


def _decode_U(m, source, count, output, out, reject):
    """Canonical U prefix and exact positive high bit, no arithmetic hook.

    Consumes U(n) at the current source head; writes ordinary LSB binary n
    into output.  count is a fixed scratch band with unary prefix length.
    An unfinished prefix/word at # reaches BOUND in the physical layer.
    Invalid visible data/end/high-zero reaches REJECT or an undefined reject.
    """
    prefix = m.state('U/prefix')
    prefix_put = m.row(count, {'B': (prefix, '1', 1)}, 'U/prefix-put')
    first = m.state('U/first-count')
    next_zero = m.state('U/count-after-zero')
    next_one = m.state('U/count-after-one')
    read_bit = m.state('U/read-bit')
    done = m.rewind(output, out, 'U/rewind-output')
    write_zero = m.row(output, {'B': (next_zero, '0', 1)}, 'U/write-zero')
    write_one = m.row(output, {'B': (next_one, '1', 1)}, 'U/write-one')
    zero = m.row(output, {'B': (done, '0', 1)}, 'U/canonical-zero')
    m.put(read_bit, source, {'0': (write_zero, '0', 1),
                             '1': (write_one, '1', 1)})
    m.put(first, count, {'1': (read_bit, '1', 1), 'B': (zero, 'B', 0)})
    m.put(next_zero, count, {'1': (read_bit, '1', 1),
                            'B': (reject, 'B', 0)})
    m.put(next_one, count, {'1': (read_bit, '1', 1),
                           'B': (done, 'B', 0)})
    counted = m.rewind(count, first, 'U/rewind-count')
    m.put(prefix, source, {'1': (prefix_put, '1', 1),
                           '0': (counted, '0', 1)})
    start = m.clear_word(count, prefix, 'U/clear-count')
    return m.clear_word(output, start, 'U/clear-output')


def _utf8_next(mode, byte):
    # Used ONLY at table generation for finite byte constants, never as a
    # machine action.  ED A0..BF is deliberately allowed: surrogatepass.
    if mode == 'LEAD':
        if 0 <= byte <= 0x7f:
            return 'LEAD'
        if 0xc2 <= byte <= 0xdf:
            return 'CONT1'
        if byte == 0xe0:
            return 'E0_FIRST'
        if 0xe1 <= byte <= 0xef:
            return 'CONT2'
        if byte == 0xf0:
            return 'F0_FIRST'
        if 0xf1 <= byte <= 0xf3:
            return 'CONT3'
        if byte == 0xf4:
            return 'F4_FIRST'
    elif mode == 'CONT1' and 0x80 <= byte <= 0xbf:
        return 'LEAD'
    elif mode == 'CONT2' and 0x80 <= byte <= 0xbf:
        return 'CONT1'
    elif mode == 'CONT3' and 0x80 <= byte <= 0xbf:
        return 'CONT2'
    elif mode == 'E0_FIRST' and 0xa0 <= byte <= 0xbf:
        return 'CONT1'
    elif mode == 'F0_FIRST' and 0x90 <= byte <= 0xbf:
        return 'CONT2'
    elif mode == 'F4_FIRST' and 0x80 <= byte <= 0x8f:
        return 'CONT2'
    return None


def _utf8_word(m, tape, out, reject):
    # Seven modes times a complete depth-eight binary decision tree.  There
    # are 255 internal states/mode, not states indexed by input length/data.
    roots = {mode: m.state('utf8/' + mode + '/root') for mode in UTF8_MODES}

    def fill(mode, prefix, q):
        choices = {}
        if not prefix:
            choices['B'] = (out if mode == 'LEAD' else reject, 'B', 0)
        for bit in ('0', '1'):
            word = prefix + bit
            if len(word) == 8:
                # The finite generator interprets eight literal bits only.
                byte = sum((1 << i) for i, s in enumerate(word) if s == '1')
                next_mode = _utf8_next(mode, byte)
                nxt = reject if next_mode is None else roots[next_mode]
            else:
                nxt = m.state('utf8/' + mode + '/' + word)
                fill(mode, word, nxt)
            choices[bit] = (nxt, bit, 1)
        m.put(q, tape, choices)

    for mode in UTF8_MODES:
        fill(mode, '', roots[mode])
    return roots['LEAD']


def _micro_foundation(budget):
    m = _Micro(budget)
    done, different, reject, bound = range(4)
    entries = {
        'scan_to_semicolon': _scan_semicolon(m, 0, done),
        'copy_binary_word': _copy_word(m, 9, 15, done),
        'compare_binary_words': _compare_words(m, 9, 10, done, different),
        'increment_binary_word': _increment_word(m, 13, done),
        'decode_canonical_U': _decode_U(m, 0, 12, 15, done, reject),
        'validate_utf8_surrogatepass_word': _utf8_word(m, 13, done, reject),
    }
    # This is a construction assertion, not an executed/audited result here.
    if len(m.rows) != STATIC_TOTALS['all_microstates_M']:
        raise ValueError('Source/static allocation disagreement')
    for row in m.rows[4:]:
        if row is None:
            raise ValueError('unassigned physical foundation microstate')
        for action in row[1].values():
            if not 0 <= action[0] < len(m.rows):
                raise ValueError('dangling literal micro transition')
    return m, entries


def describe_physical_foundation(*, check, limits):
    """Generate a finite literal SINGLE-TAPE foundation, not a fixed VM.

    Later reviewed calls only.  No program/image/problem/bound argument exists.
    The result retains every explicit transition and undefined state-symbol
    pair.  Halt/undefined states cannot be treated as proof acceptance.
    Full generation cost/memory is charged; fit is neither claimed nor tested.
    """
    budget = _Budget(check, limits)
    m, micro_entries = _micro_foundation(budget)
    marked = tuple('@' + s for s in RAW)
    headers = tuple('h:' + name for name in WORKSPACE)
    alphabet = ('L',) + RAW + marked + headers
    for _ in alphabet:
        budget.step('symbols')
    states = list(HALTS)
    physical = {}
    for q, row in enumerate(m.rows):
        if row is not None:
            ids = []
            for phase in ('select', 'header', 'head', 'read'):
                ids.append(len(states))
                states.append(phase + '/' + str(q))
            physical[q] = tuple(ids)
    markers = []
    for q in range(len(m.rows)):
        markers.append(len(states))
        states.append('mark/' + str(q))
    for _ in states:
        budget.step('states')
    delta = {}

    def entry(q):
        return q if q < 4 else physical[q][0]

    def put(q, s, out, write, move):
        budget.step('transitions')
        key = (q, s)
        if key in delta or s not in alphabet or write not in alphabet:
            raise ValueError('duplicate/nonliteral physical transition')
        delta[key] = (out, write, move)

    for q, row in enumerate(m.rows):
        if row is None:
            continue
        tape, choices = row
        select, header, find, read = physical[q]
        for s in alphabet:
            put(select, s, header if s == 'L' else select, s,
                1 if s == 'L' else -1)
            put(header, s, find if s == headers[tape] else header, s, 1)
            put(find, s, read if s in marked else find, s,
                0 if s in marked else 1)
        for s, (out, write, move) in choices.items():
            put(read, '@' + s, entry(out) if move == 0 else markers[out],
                '@' + write if move == 0 else write, move)
        put(read, '@#', 3, '@#', 0)
    for q, mark in enumerate(markers):
        for s in RAW:
            put(mark, s, 3 if s == '#' else entry(q),
                s if s == '#' else '@' + s, 0)
    ordinary_delta = []
    undefined = []
    for q in range(len(states)):
        for s in alphabet:
            budget.step('work')
            if (q, s) in delta:
                out, write, move = delta[q, s]
                ordinary_delta.append([q, s, out, write, move])
            else:
                budget.step('undefined_slots')
                undefined.append([q, s])
    check()
    observed = {
        'physical_alphabet_b': len(alphabet),
        'physical_states_Q': len(states),
        'defined_physical_transitions_D': len(ordinary_delta),
        'stationary_physical_transitions_D0': sum(r[4] == 0 for r in ordinary_delta),
    }
    for k, value in observed.items():
        if value != STATIC_TOTALS[k]:
            raise ValueError('Source/static physical census disagreement: ' + k)
    return {
        'schema': 'fixed-vm-physical-foundation-v1',
        'version': VERSION, 'status': STATUS,
        'complete_interpreter': False,
        'alphabet': list(alphabet), 'states': states,
        'delta': ordinary_delta, 'undefined': undefined,
        'entries': {name: entry(q) for name, q in micro_entries.items()},
        'halts': {name: i for i, name in enumerate(HALTS)},
        'blank': 'B', 'workspace': list(WORKSPACE),
        'census': observed, 'construction_counts': dict(budget.counts),
        'mathematical_authority': False,
    }


def describe_fixed_vm(*, check, limits):
    """Fail closed: this packet contains no complete physical VM controller."""
    # No interpreter/table is substituted, and no image/problem is accepted.
    check()
    raise ConstructionIncomplete(
        'BOOT, dynamic program/register/frame/heap controller and linkage '
        'are not expanded; physical foundation is not a fixed interpreter')
