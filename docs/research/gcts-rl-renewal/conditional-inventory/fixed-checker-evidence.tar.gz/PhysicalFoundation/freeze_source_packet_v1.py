"""Ordinary raw/AST/algebra authoring only; never imports/calls the subject."""
import ast
import hashlib
import json
from pathlib import Path

D = Path('/private/tmp/gcts-fixed-vm-construction-20261020-v1')
MASTER = Path('/private/tmp/gcts-fixed-initializer-ROOT-20261020-v1/basic-tiling-algorithm-current.md')
CONTRACT = Path('/private/tmp/gcts-fixed-VM-design-peer-20261019-v1/fixed-interpreter-encoding-contract-v1.json')
SUBJECT = D / 'fixed_vm_physical_foundation_v1.py'


def pin(path):
    p = Path(path)
    raw = p.read_bytes()
    return {'path': str(p), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def save(name, value):
    p = D / name
    if p.exists():
        raise RuntimeError('refuse overwrite frozen metadata: ' + str(p))
    p.write_text(json.dumps(value, ensure_ascii=True, sort_keys=True, indent=2) + '\n')
    return pin(p)


def main():
    master = pin(MASTER)
    assert master['sha256'] == 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
    assert master['bytes'] == 21657
    specification = json.loads(CONTRACT.read_text())
    sources = specification['sources']
    for desc in sources.values():
        if 'path' in desc and 'sha256' in desc:
            actual = pin(desc['path'])
            assert actual['sha256'] == desc['sha256'] and actual['bytes'] == desc['bytes']
    combined = Path(sources['combined_plaintext']['path']).read_text()
    ast_combined = ast.parse(combined)
    fns = [n for n in ast_combined.body if isinstance(n, ast.FunctionDef)]
    assert len(fns) == 69
    syntax = Path(sources['wire_wrapper']['path']).read_text()
    fol = Path(sources['fol_checker']['path']).read_text()
    assert combined == syntax + fol.replace('def main(request):', 'def semantic_main(request):', 1)
    raw = SUBJECT.read_bytes()
    tree = ast.parse(raw, filename=str(SUBJECT))
    # This creates an unused code object only; no import, eval or exec.
    compile(tree, str(SUBJECT), 'exec', dont_inherit=True, optimize=0)
    constants = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                constants[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    assert constants['COMPLETE_INTERPRETER'] is False
    assert not any(isinstance(n, (ast.Import, ast.ImportFrom)) for n in ast.walk(tree))
    counts = constants['STATIC_MACRO_CENSUS']
    n = sum(row[1] for row in counts)
    k = sum(row[2] for row in counts)
    k0 = sum(row[3] for row in counts)
    r = len(constants['RAW'])
    t = len(constants['WORKSPACE'])
    h = len(constants['HALTS'])
    m = n + h
    b = 1 + 2 * r + t
    q = h + 4 * n + m
    d = 3 * n * b + k + n + r * m
    d0 = (r + 1) * n + k0 + r * m
    expected = {'assigned_microstates_N': n, 'all_microstates_M': m,
                'micro_choices_K': k, 'stationary_micro_choices_K0': k0,
                'fixed_workspace_bands_T': t, 'raw_symbols_r': r,
                'physical_alphabet_b': b, 'physical_states_Q': q,
                'defined_physical_transitions_D': d,
                'stationary_physical_transitions_D0': d0}
    assert expected == constants['STATIC_TOTALS']
    # Small integer algebra over the retained Source partition, NOT a table,
    # compiler, machine, generator, simulation or palette call.
    retained_steps = b * (b + 1) ** 2 + 3 * d * b * (b + 1) + d0 * (b + 1)
    assert retained_steps == 954080288 and retained_steps > 134217728
    source = pin(SUBJECT)
    common = {
        'author_identity': '/root/conventional_library', 'source_only': True,
        'scientific_calls': 0, 'subject_imports': 0,
        'subject_function_calls': 0, 'table_generation_calls': 0,
        'fixture_calls': 0, 'simulator_calls': 0, 'native_calls': 0,
        'actual_execution_authorized': False, 'mathematical_authority': False,
        'complete_interpreter_implemented': False,
        'current_master': master, 'design_contract': pin(CONTRACT),
        'subject': source,
    }
    api = dict(common, schema='fixed-vm-physical-foundation-API-v1',
               status='PARTIAL_PHYSICAL_CONSTRUCTION_NO_INTERPRETER',
               signatures=[
                   {'call': 'describe_physical_foundation(*, check, limits)',
                    'status': 'SOURCE_IMPLEMENTED_UNEXECUTED',
                    'result': 'Full literal single-tape foundation alphabet/states/delta/undefined slots, six named entries, four halt labels, static-vs-generated count assertions; not an interpreter.'},
                   {'call': 'describe_fixed_vm(*, check, limits)',
                    'status': 'REFUSES_CONSTRUCTION_INCOMPLETE',
                    'result': 'Calls check then raises ConstructionIncomplete; no alternative machine is supplied.'}],
               construction_limits=['work', 'states', 'symbols', 'transitions', 'undefined_slots'],
               data_inputs='No checker image, theory, target, certificate or bound argument is accepted by the foundation generator.',
               result_mutability='Fresh ordinary data. Immutable/runtime custody and whole-value reconstruction are not implemented by this generation-only packet.',
               failure='No catches normalize caller callback exceptions. ConstructionLimit is a generation resource error only. Undefined physical transitions reject malformed layout; no such undefined halt is acceptance.',
               entries=[row[0] for row in counts], static_conditional_census=expected)
    api_pin = save('API-v1.json', api)
    arguments = dict(common, schema='fixed-vm-physical-foundation-arguments-v1',
        proof_status='MANUAL_SOURCE_ARGUMENTS_ONLY_NOT_FORMAL_OR_RUNTIME_CERTIFICATION',
        representation={
            'physical_word': 'L followed by sixteen fixed named bands. Each band has header h:NAME, left marker ^, finite raw cells and right fence #. Exactly one @raw symbol represents its virtual head. No payload may supply headers/L/@; initialization proof is not yet implemented.',
            'fixed_not_target_specific': 'Sixteen WORKSPACE headers describe fixed storage roles, never one symbol/state per checker function/register/address. All such unbounded indices would remain binary data. No shrinking of the complete69-function language is proposed.',
            'immutability_exception': 'The transport head marker changes raw x to @x and back. Erasing the @ prefix gives the same immutable PROGRAM/PUBLIC/CERTIFICATE payload. This is payload-preserving marker transport, NOT literal no-write immutability. Complete VM write-safety is unproved.',
            'physical_step': 'Select moves left to L; header scans right to its fixed band header; find scans to that band head marker; read performs the one literal selected-tape action; a moving action releases the old marker and a separate mark state tags its destination. A fence yields BOUND. A valid one-marker band invariant is a precondition, not checked by a host predicate during machine execution.',
            'no_runtime_hooks': 'After hypothetical generation every action is one literal state/read-symbol to state/write-symbol/move triple. Finite byte arithmetic occurs solely in generation of fixed8-bit trees. No generated action invokes arithmetic, heap, inference, opcode or host callbacks.'},
        macro_arguments=[
            {'name': 'scan_to_semicolon', 'allocation': [1, 9, 1],
             'argument': 'One row moves right on each of eight raw non-fence nonterminators, stops at semicolon. A finite fence bounds a missing delimiter. No payload changes.'},
            {'name': 'copy_binary_word', 'allocation': [8, 44, 2],
             'argument': 'Three clear rows + one source rewind + one source read + two finite carry-bit write rows + one output rewind. Distinct binary scratch bands, no separators, and enough room are preconditions. Every bit copied; source preserved.'},
            {'name': 'compare_binary_words', 'allocation': [6, 30, 8],
             'argument': 'Two rewinds + read-left + two read-right carry states + exact-end row. Equal accepts only after both ends align; unequal may leave heads at mismatch, requiring caller rewind before reuse. No hashes.'},
            {'name': 'increment_binary_word', 'allocation': [3, 21, 2],
             'argument': 'Two rewinds + carry row. Canonical LSB binary precondition. Carry changes prefix ones to zero; first zero or blank becomes one. Fence exhaustion is BOUND; partial mutation before BOUND is not rolled back or accepted.'},
            {'name': 'decode_canonical_U', 'allocation': [17, 74, 5],
             'argument': 'Two3-row clears + prefix/prefix-put + count rewind + three count rows + bit-read/two writes + zero write + output rewind. Unary prefix stores length in scratch, exactly that many data bits copied, positive final high bit must1. Zero is the separate length0 path. Source bits unchanged. It does not yet parse an entire checker image.'},
            {'name': 'validate_utf8_surrogatepass_word', 'allocation': [1785, 3577, 7],
             'argument': 'Seven modes times255 internal depth8 LSB byte-tree states, two bit choices each plus a blank exit at each mode root. Continuation ranges reject overlong/out-of-range sequences; ED surrogate encodings are allowed for surrogatepass. Only LEAD can finish at blank. Partial byte/sequence rejects. Extracting heap-backed string bytewords and traversing full tagged values is missing.'}],
        census_derivation={
            'definitions': 'N assigned microstates; M=N+4 terminal-inclusive microstates; K literal micro choices; K0 stationary choices; r raw symbols; T fixed workspace bands.',
            'formulas_latex': [r'b=1+2r+T', r'Q=4+4N+M', r'D=3Nb+K+N+rM', r'D_0=(r+1)N+K_0+rM'],
            'explanation': 'Each assigned microstate gets three complete-alphabet sweep rows plus a partial read row with its K choices and one @# fence choice; every microstate, including terminals, gets r stationary marker choices. Find has r stationary marker overrides per assigned microstate. Four terminal states have no outgoing transitions.',
            'values': expected,
            'conditional_retained_step_formula_latex': r'S=b(b+1)^2+3Db(b+1)+D_0(b+1)',
            'conditional_retained_step_tiles': retained_steps,
            'retained_partition_source': sources['wang_compiler'],
            'full_vm_counts_available': False,
            'resource_obstruction': 'For THIS unminimized foundation and the retained fully literal Wang schema, step tiles alone exceed128MiB even at one byte/tile. This is Source algebra, not measured allocation or impossibility of all fixed interpreters. No table/palette was generated.'},
        full_checker_binding={
            'required_function_count': 69, 'actual_raw_AST_function_count': len(fns),
            'full_combined_source': sources['combined_plaintext'],
            'full_original_checker': sources['fol_checker'],
            'boundary_wrapper': sources['wire_wrapper'],
            'bytecode_compiler': sources['bytecode_compiler'],
            'recipe_exact_raw': True,
            'compiled_or_executed': False,
            'language_shrunk': False,
            'semantics_implemented_by_foundation': False},
        root_instruction='Stop expansion of this unminimized architecture; freeze useful bounded negative. No theoretical impossibility claim.')
    argument_pin = save('physical-arguments-and-census-v1.json', arguments)
    alternatives = dict(common, schema='fixed-vm-next-architecture-options-v1',
        implemented=False, selected_or_authorized=False,
        alternatives=[
            {'name': 'Compact bitwise UTF8-surrogatepass automaton',
             'change': 'Replace seven full256-leaf byte dispatch trees with directly reviewed bitwise classification/residual-language states respecting the fixed LSB byte order. Shared suffix states may be merged only with a proved identical residual language and exact return mode.',
             'obligations': 'Canonical overlong/continuation/U+10FFFF bounds and surrogatepass ED behavior, byte boundaries, incomplete words, exact Source alphabet/state table and full census. No host decode operation in delta.',
             'limit': 'Reduces this parser construction only. It does not implement dynamic VM tables, canonical heap, full call frames, boot parsing or complete69-function refinement, and does not establish whole palette/runtime fit.'},
            {'name': 'Certified implicit/lazy COMPLETE Wang palette',
             'change': 'Retain exact literal origin-triple tile identities and all frame/collector/selector variants in a finite symbolic indexed set. At each finite board origin, expose a complete certified iterator/domain representation with exact count, zero/singleton decisions and membership; do not materialize a billion ordinary tile records.',
             'obligations': 'Prove exact equivalence to every original literal schema, no quotient of distinct identities or boundary variants, exhaustive domain zero/singleton certificates, complete point/candidate forward/reverse incidence and all mark dependencies, global DEAD/FORCED/earliest-generation decisions, exact trailed rollback and base fallback. A compact top-k/sampled palette or color-consistency approximation is insufficient.',
             'limits': 'Current master permits certified lazy exhaustion/singleton; it does not certify an implementation. Symbolic set/intersection/iteration costs and full logical-vs-physical output semantics require an explicit common representation profile, original resource review and independent comparison. No changed allowance is selected. Literal output cannot be claimed below128MiB if its full expansion exceeds that cap.'}],
        common_warning='A fixed machine still receives the entire checker image, public problem and certificate as data. Program decoding, heap/register/frame scans, boot checks and all copying cost physical steps. A smaller byte DFA or symbolic palette alone is not an implemented interpreter, FOL equivalence proof, speedup, GCTS marking gain or RL result.')
    alternatives_pin = save('next-architecture-options-v1.json', alternatives)
    open_gaps = dict(common, schema='fixed-vm-unexpanded-controller-obligations-v1',
        status='BLOCKED_INCOMPLETE_CONSTRUCTION',
        theoretical_impossibility=False,
        absent_physical_routines=[
            'Complete immutable GCTSVM1 image record parser and well-formed program validation, beyond the standalone U decoder.',
            'Generic function/PC fetch, register table lookup/update with copied source operands, complete operand/range/alias checks.',
            'Append-only canonical cons-table search, exact existing-node validation, finite append/fence handling and topological IDs.',
            'Full caller-frame save/restore and argument-vector materialization, target arity, root return accept iff exact1.',
            'BOOT9-bit postfix parser with canonical-cons stack, exact3 fixed public values and2 free values, stack separation, padding/fence validation.',
            'Full tagged-value traversal, canonical surrogatepass byteword validation for every string/key, complete object key uniqueness and request construction.',
            'All13 opcode physical entries and linkage. There is no executable partial opcode subset substituted for the full language.',
            'Complete root/scratch/band initialization and selector grammar/unknown-certificate/Wang correspondence.'],
        opcode_obligations=specification['opcode_semantics'],
        trust_and_caps='No interpreter acceptance authority, runtime qualification, machine/table generation, launch, cap raise, or consumed grant reuse. Original180/210/1GiB/128MiB/log protocol remains a future prerequisite; generation limits are not adopted numerical allowances.',
        next_gate='A new compact physical architecture must be fully expanded and independently checked, with exact complete VM census BEFORE a literal palette materialization request. Full69-function/host-kernel/source-to-bytecode/boot/public licensing correspondence remains separate.')
    gaps_pin = save('unexpanded-controller-obligations-v1.json', open_gaps)
    contract = dict(common, schema='fixed-vm-physical-foundation-Source-contract-v1',
        scope='Source progress only; not the requested complete physical interpreter.',
        independently_reviewed=False, runtime_qualified=False,
        lineage='Library authored this foundation and historical compiler/search/verifier/evidence Source. This is an author-static packet, not independent self-certification. B codec and Root initializer remain separate Sources; neither is imported or called here.',
        gates=['Do not expose foundation DONE as checker/theorem acceptance.',
               'Do not use partial Q/b/D/D0 as full VM counts.',
               'Do not compile, import, call, test, simulate or generate a table/palette under this Source-only handoff.',
               'Keep checker/image/problem/certificate bounds out of states and alphabet.',
               'Bind current master c132, preserve historical ca6ee references as lineage.'],
        API=api_pin, arguments=argument_pin, alternatives=alternatives_pin,
        unexpanded_gaps=gaps_pin)
    contract_pin = save('Source-contract-v1.json', contract)
    audit = dict(common, schema='fixed-vm-physical-foundation-author-static-audit-v1',
        independent_Source_review=False,
        unused_compile_count=1, AST_parse_count=2,
        static_counts_not_observed_generation=expected,
        checks=[
            {'name': 'whole current master hash/bytes', 'passed': True},
            {'name': 'whole design source descriptors', 'passed': True},
            {'name': 'complete69 function Source and raw concatenation recipe', 'passed': True},
            {'name': 'subject contains no imports', 'passed': True},
            {'name': 'COMPLETE_INTERPRETER literal false', 'passed': True},
            {'name': 'small integer static census identities', 'passed': True},
            {'name': 'retained step schema exceeds literal128MiB even1byte per tile', 'passed': True},
            {'name': 'subject AST parse and unused compile', 'passed': True}],
        limits='No function bodies, bytecode, fixed machine, transition table, generator, macro, fixture or checker was evaluated. Macro/census semantics are manually reasoned Source claims pending distinct scrutiny; no runtime pass is recorded.')
    audit_pin = save('author-static-audit-v1.json', audit)
    handoff = dict(common, schema='fixed-vm-physical-construction-handoff-v1',
        status='PARTIAL_PHYSICAL_FOUNDATION_BOUNDED_SOURCE_NEGATIVE',
        source_contract=contract_pin, API=api_pin, arguments=argument_pin,
        alternatives=alternatives_pin, gaps=gaps_pin, author_static_audit=audit_pin,
        metadata_author=pin(Path(__file__)),
        frozen_prior_sources_modified=False,
        tools_stop_after_handoff=True)
    desc = save('handoff-v1.json', handoff)
    print(json.dumps({'handoff': desc, 'source': source, 'API': api_pin,
                      'conditional_step_tiles': retained_steps}, sort_keys=True))


if __name__ == '__main__':
    main()
