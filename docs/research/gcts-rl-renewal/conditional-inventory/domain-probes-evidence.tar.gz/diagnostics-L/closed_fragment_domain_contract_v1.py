"""D19 closed-fragment qualification FORMAT contract, not a proof kernel.

Only generic closed FOL syntax and phase metadata; actual probe bodies live in
one separate pinned JSON input. No file access, scientific imports, proof route,
new selector, library or policy. Calls only in separately reviewed Root actuals.
"""
import copy

_OWNER=object()
SCHEMA='gcts-conditional-selector-domain-probes-v1'
IDENTITY='D19-separate-arithmetic-incidence-qualification-v1'
IDS=('arith-zero-direct-instantiation-control', 'arith-zero-congruence-fragment', 'hilbert-ground-incidence-uniqueness-fragment')
BOUNDS={'arith-zero-direct-instantiation-control': 9, 'arith-zero-congruence-fragment': 9, 'hilbert-ground-incidence-uniqueness-fragment': 15}
PROTOCOL={'inventory': False,
 'methods': ['S0', 'P0'],
 'policy': False,
 'scope': 'Separate closed-fragment grammar/proof qualification only. Retain hard arithmetic '
          'congruence at bound9 regardless direct-control outcome; no full '
          'PA/induction/Hilbert geometry or easier-goal rescue. These proofs never feed '
          'acquisition/training/policy. Exact fresh Root plans required.',
 'stage_ids': ['qualify-arith-zero-direct-instantiation-control',
               'qualify-arith-zero-congruence-fragment',
               'qualify-hilbert-ground-incidence-uniqueness-fragment'],
 'upstream_feed': False}

class CorpusFormatError(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def is_owned_error(error):
    return type(error) is CorpusFormatError and error.owner is _OWNER


def need(value, message):
    if not value:
        raise CorpusFormatError(message, _OWNER)


def _same(left, right, check):
    check()
    if type(left) is not type(right):
        return False
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if not _same(a, b, check):
                return False
        return True
    if type(left) is dict:
        if set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key], right[key], check):
                return False
        return True
    return left == right


def _name(value, check):
    check()
    need(type(value) is str and 0 < len(value) <= 128, 'bounded literal name')


def _signature(value, check):
    check(); need(type(value) is dict, 'literal signature map')
    for name, arity in value.items():
        _name(name, check)
        need(type(arity) is int and 0 <= arity <= 2, 'exact finite arity')


def _term(value, theory, bound, check, depth=0):
    check(); need(depth <= 64 and type(value) is list and value, 'finite literal term')
    if value[0] == 'var':
        need(len(value) == 2 and type(value[1]) is str and value[1] in bound,
             'no free variable in licensed closed axiom/target')
        return
    need(len(value) == 3 and value[0] == 'fun' and type(value[1]) is str
         and value[1] in theory['functions'] and type(value[2]) is list,
         'declared function term')
    need(len(value[2]) == theory['functions'][value[1]], 'function arity')
    for item in value[2]:
        _term(item, theory, bound, check, depth+1)


def _formula(value, theory, bound, check, depth=0):
    check(); need(depth <= 64 and type(value) is list and value
                  and type(value[0]) is str, 'finite literal formula')
    tag = value[0]
    if tag == 'bot':
        need(len(value) == 1, 'bottom arity')
    elif tag == 'pred':
        need(len(value) == 3 and type(value[1]) is str and value[1] in theory['predicates']
             and type(value[2]) is list, 'declared predicate')
        need(len(value[2]) == theory['predicates'][value[1]], 'predicate arity')
        for item in value[2]:
            _term(item, theory, bound, check, depth+1)
    elif tag == 'eq':
        need(len(value) == 3, 'equality arity')
        _term(value[1], theory, bound, check, depth+1)
        _term(value[2], theory, bound, check, depth+1)
    elif tag == 'all':
        need(len(value) == 3, 'universal arity'); _name(value[1], check)
        _formula(value[2], theory, bound | {value[1]}, check, depth+1)
    elif tag == 'not':
        need(len(value) == 2, 'negation arity')
        _formula(value[1], theory, bound, check, depth+1)
    else:
        need(tag in ('imp', 'and', 'or') and len(value) == 3, 'known binary formula')
        _formula(value[1], theory, bound, check, depth+1)
        _formula(value[2], theory, bound, check, depth+1)


def validate_domain_probes(document, *, check):
    check();need(type(document) is dict and set(document)=={'schema','id','probes','protocol'},'exact physical domain statement input')
    need(document['schema']==SCHEMA and document['id']==IDENTITY,'fixed probe phase schema/identity')
    need(type(document['probes']) is list and len(document['probes'])==3,'all three probes retained')
    ids=[]
    for spec in document['probes']:
        check();need(type(spec) is dict and set(spec)=={'id','title','theory','target','length','instantiation_rounds','scope'},'statement-only probe')
        _name(spec['id'],check);need(spec['id'] in BOUNDS,'declared probe identity');ids.append(spec['id'])
        need(type(spec['title']) is str and type(spec['scope']) is str,'literal scope and title')
        need(type(spec['length']) is int and spec['length']==BOUNDS[spec['id']],'unchanged exact9/9/15 primitive rows')
        need(type(spec['instantiation_rounds']) is int and spec['instantiation_rounds']==2,'unchanged two-pass finite catalog')
        theory=spec['theory'];need(type(theory) is dict and set(theory)=={'functions','predicates','axioms','schemas'},'explicit theory licence')
        _signature(theory['functions'],check);_signature(theory['predicates'],check)
        need(type(theory['schemas']) is list and not theory['schemas'],'no added induction or schema')
        need(type(theory['axioms']) is dict and 1<=len(theory['axioms'])<=6,'finite declared closed axioms')
        for name,formula in theory['axioms'].items():_name(name,check);_formula(formula,theory,set(),check)
        _formula(spec['target'],theory,set(),check)
    need(tuple(ids)==IDS,'ordered full direct/hard/incidence probe population')
    need(_same(document['protocol'],PROTOCOL,check),'separate method/noinventory/nopolicy/no-feed scope')
    check();return dict(schema='D19-closed-fragment-format-v1',complete=True,ids=ids,
        scope='Closed FOL format/licence only; no proof, arithmetic/Hilbert completeness, representability, fit or acceptance claim. Raw plan input pins freeze all statements; hard probe is not replaced by direct control.')


CONTROL_IDS=('valid-three-probes','missing-hard-probe','unexpected-proof','bool-bound','free-axiom-variable','unknown-function','bad-function-arity','added-schema','policy-feed','foreign-RuntimeError','foreign-StopIteration','foreign-CorpusFormatError')


def run_domain_format_controls(document, *, check):
    check();validate_domain_probes(document,check=check);results=[dict(id=CONTROL_IDS[0],status='PASSED')]
    for recipe in CONTROL_IDS[1:9]:
        check();altered=copy.deepcopy(document);spec=altered['probes'][0]
        if recipe=='missing-hard-probe':altered['probes'].pop(1)
        elif recipe=='unexpected-proof':spec['proof']=[]
        elif recipe=='bool-bound':spec['length']=True
        elif recipe=='free-axiom-variable':spec['theory']['axioms']['a0']=['eq',['var','u'],['var','u']]
        elif recipe=='unknown-function':spec['target']=['eq',['fun','UNLICENSED',[]],['fun','UNLICENSED',[]]]
        elif recipe=='bad-function-arity':spec['target']=['eq',['fun','add',[]],['fun','c',[]]]
        elif recipe=='added-schema':spec['theory']['schemas']=['induction']
        else:altered['protocol']['upstream_feed']=True
        caught=None
        try:validate_domain_probes(altered,check=check)
        except CorpusFormatError as error:
            check()
            if not is_owned_error(error):raise
            caught=error
        need(caught is not None,'owned malformed probe refusal');results.append(dict(id=recipe,status='PASSED',refused=True))
    for ident,sentinel in zip(CONTROL_IDS[9:],(RuntimeError('external'),StopIteration('external'),CorpusFormatError('external'))):
        check();ticks=[0]
        def interrupt():
            check();ticks[0]+=1
            if ticks[0]==6:raise sentinel
        caught=None
        try:validate_domain_probes(document,check=interrupt)
        except BaseException as error:caught=error
        check();need(caught is sentinel,'exact nested foreign callback identity')
        results.append(dict(id=ident,status='PASSED',exact_identity_preserved=True))
    ids=[]
    for result in results:check();ids.append(result['id'])
    need(tuple(ids)==CONTROL_IDS,'all12 format controls retained')
    check();return dict(schema='D19-closed-fragment-format-controls-v1',complete=True,count=12,controls=results,
        scope='Actual-only format/callback diagnostics, not theorem/Native/grammar representability checks. No target proof or expected search route supplied.')
