"""Root passive exact saved-record admission; no scientific imports or replay."""
from pathlib import Path
import hashlib
import json

STUDY=Path(__file__).resolve().parents[1]

def pin(p):
    p=Path(p).resolve();assert '.partial' not in p.name
    b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def read(p):
    assert '.partial' not in Path(p).name
    return json.loads(Path(p).read_bytes())

def digest(v):
    return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),
        ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def main():
    rp=STUDY/'review-C/typed-domain-actual-scientific-resource-review-v1.json'
    assert pin(rp)['bytes']==182235
    assert pin(rp)['sha256']=='cd284f3effc5abdd42b88a858c323f553099463b9094c1424ff9f837776a1f76'
    review=read(rp)
    assert review['review_passed'] is True and review['failures']==[]
    assert len(review['checks'])==7 and all(x['passed'] is True for x in review['checks'])
    assert review['scientific_imports']==review['scientific_calls']==review['scientific_replays']==0
    assert review['partial_files_parsed']==0 and review['Root_admission_issued'] is False
    assert review['main_learner_feed_authorized'] is False
    for row in review['input_pins']+review['complete_actual_file_census']:
        assert pin(row['path'])==row,row['path']
    protocol=read(STUDY/'root/domain-protocol-v1.json')
    assert review['limits']==protocol['limits']
    assert review['experiment_limits']==protocol['experiment_limits']
    assert [c['case_id'] for c in review['cases']]==[c['stage_id'] for c in protocol['job_recipes']]
    jobs=[];accepted=unknown=0;targets=set()
    for case in review['cases']:
        assert all(case[k] is True for k in ('resource_admitted','scientific_qualified','stage_complete'))
        for key in ('plan','result','header','terminal','observer','grant','consumed'):
            assert pin(case[key]['path'])==case[key]
        plan=read(case['plan']['path']);result=read(case['result']['path'])
        header=read(case['header']['path']);terminal=read(case['terminal']['path'])
        observer=read(case['observer']['path']);grant=read(case['grant']['path'])
        consumed=read(case['consumed']['path']);science=result['scientific_result']
        assert plan['upstream_receipts']==plan['required_upstream_ids']==[]
        assert plan['limits']==review['limits'] and plan['experiment_limits']==review['experiment_limits']
        for row in plan['files']:assert pin(row['path'])==row
        assert grant['uses']==1 and type(grant['uses']) is int
        assert grant['authorized'] is grant['review_passed'] is True
        assert grant['plan_sha256']==consumed['plan_sha256']==case['plan']['sha256']
        assert consumed['grant_sha256']==case['grant']['sha256'] and consumed['uses']==1
        assert result['case_id']==header['case_id']==terminal['case_id']==observer['case_id']==case['case_id']
        assert result['status']==header['status']=='COMPLETE' and result['error'] is None
        assert result['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True
        assert result['first_Root_fault'] is header['first_Root_fault'] is False
        assert header['native_closed_and_reaped'] is terminal['threads_terminal'] is True
        assert header['result']==terminal['result']==case['result']
        assert terminal['header']==header and terminal['header_valid'] is True
        assert terminal['process_exit_code']==observer['parent_exit_code']==0
        assert terminal['reason'] is observer['reason'] is observer['fallback_trigger_seconds'] is None
        assert terminal['errors']==observer['errors']==[]
        assert terminal['final_custody_gate_passed'] is observer['resource_candidate_accepted'] is True
        assert terminal['known_exit_seconds']<=180 and terminal['final_custody_gate_seconds']<=210
        assert observer['final_observer_gate_seconds']<=210
        assert observer['final_conservative_whole_peak_bytes']==case['whole_peak_bytes']<1073741824
        assert observer['elapsed_seconds']==case['whole_seconds']
        assert result['callbacks']==header['callbacks']==case['callbacks']<=400000000
        assert case['artifact_bytes']<=134217728 and case['result']['bytes']<=50331648
        for logs in (terminal['logs'],observer['logs']):
            assert all(v['eof'] is True and v['overflow'] is False for v in logs.values())
        assert science['stage_complete'] is True and science['status']=='DOMAIN_PROBE_COMPLETE'
        assert science['export'] is None and science['domain_results_never_feed_acquisition_or_training'] is True
        assert science['native_queries']==result['native_queries']
        stages=result['native_transport']['request_stages']
        assert result['native_transport']['closed'] is result['native_transport']['all_reaped'] is True
        assert result['native_transport']['cleanup_errors']==[]
        assert len(stages)==len(result['native_queries'])==result['native_requests_started']<=512
        for i,(q,stage) in enumerate(zip(result['native_queries'],stages)):
            assert q['id']==stage['ordinal']==stage['record_id']==i
            assert stage['stage']=='COMPLETED' and stage['limit']==1000000000
            assert digest(q['request'])==q['request_sha256']==stage['request_sha256']
            for k in ('purpose','input_sha256','output_sha256'):assert q[k]==stage[k]
        arms=science['records'][0]['arms']
        assert [a['method'] for a in arms]==['S0','P0']
        assert all(a['search']['root_restored'] is True for a in arms)
        for arm in arms:
            check=arm['proof_check'];search=arm['search']
            if check['native_proof_accepted'] is True:
                assert check['status']=='HOST_REGION_NATIVE_ACCEPTED'
                assert check['host_check']['accepted'] is check['region']['complete'] is True
                record=check['native_record']
                assert record==result['native_queries'][record['id']]
                assert record['request']['blocks']==[] and record['request']['proof']==search['proof']
                assert record['request']['target']==science['records'][0]['spec']['target']
                assert record['result']['status']=='accepted'
                accepted+=1;targets.add(case['probe_id'])
            else:
                assert check['status']=='NO_PROOF_CANDIDATE' and check['native_record'] is None
                assert search['proof'] is None and search['status']=='unknown_search_budget'
                unknown+=1
        jobs.append(dict(case_id=case['case_id'],admitted=True,resource_admitted=True,
            scientific_qualified=True,stage_complete=True,
            plan=case['plan'],result=case['result'],header=case['header'],
            terminal=case['terminal'],observer=case['observer'],
            whole_seconds=case['whole_seconds'],whole_peak_bytes=case['whole_peak_bytes'],
            C_review=pin(rp)))
    assert (len(jobs),accepted,len(targets),unknown)==(3,2,1,4)
    out=dict(schema='D19-Root-domain-admissions-v1',complete_review=True,
        C_review=pin(rp),prospective_review=pin(STUDY/'review-C/typed-domain-whole-prospective-Source-review-v1.json'),
        jobs=jobs,summary=dict(whole_admitted_jobs=3,returned_searches=6,
            accepted_proof_occurrences=2,distinct_targets_proved=1,bounded_UNKNOWN=4),
        scientific_calls=0,scientific_imports=0,partial_files_parsed=0,
        main_learner_feed_authorized=False,broader_goal_active=True,
        scope='Root admits these complete finite observations after independent review and exact raw/record joins. Two proof occurrences prove one direct axiom instance only. No full PA/Hilbert, Wang, RL or GCTS advantage is established; no retry or upstream adoption.')
    path=STUDY/'root/Root-domain-admissions-v1.json'
    with path.open('x') as stream:
        json.dump(out,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(admission=pin(path),summary=out['summary'])))

if __name__=='__main__':
    main()
