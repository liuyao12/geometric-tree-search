"""Passive publication projection of complete saved JSON only.
No research imports, search, compiler, proof verifier or theorem inference.
Authority comes from a separate exact Root admission file.
"""
from pathlib import Path
import copy
import hashlib
import json

STUDY=Path(__file__).resolve().parents[1]

def pin(path):
    path=Path(path).resolve()
    if '.partial' in path.name:
        raise ValueError('never parse partial evidence')
    body=path.read_bytes()
    return dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())

def read(path):
    if '.partial' in Path(path).name:
        raise ValueError('never parse partial evidence')
    return json.loads(Path(path).read_bytes())

def main():
    admission_path=STUDY/'root/Root-domain-admissions-v1.json'
    admission=read(admission_path)
    assert admission['schema']=='D19-Root-domain-admissions-v1'
    assert admission['complete_review'] is True
    proofs=[];jobs=[];slots=[]
    document=read(STUDY/'diagnostics-L/domain-probes-inputs-v1.json')
    by_id={row['case_id']:row for row in admission['jobs']}
    for recipe in document['protocol']['stage_ids']:
        plan_path=STUDY/'root/domain-plans'/(recipe+'-v1.json')
        admitted=by_id[recipe];assert pin(plan_path)==admitted['plan']
        plan=read(plan_path);directory=Path(plan['actual_dir'])
        assert admitted['admitted'] is True
        result_path=directory/'result.json';assert pin(result_path)==admitted['result']
        result=read(result_path);science=result['scientific_result']
        assert result['status']=='COMPLETE' and science['stage_complete'] is True
        case=science['records'][0];spec=case['spec']
        assert spec==next(v for v in document['probes'] if 'qualify-'+v['id']==recipe)
        observer_path=Path(str(directory)+'.observer/observer.json')
        observer=read(observer_path);assert pin(observer_path)==admitted['observer']
        jobs.append(dict(case_id=recipe,spec=spec,admission=admitted,
            observer_seconds=observer['elapsed_seconds'],
            conservative_whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],
            shared_setup_seconds=case['shared_setup_seconds'],
            compile_and_model_seconds=case['compile_and_model_seconds'],
            word_model_seconds=case['word_model_seconds'],
            marking=case['marking'],callbacks=result['callbacks'],
            native_requests=result['native_requests_started'],
            controls=science['controls'],format_controls=science['format_controls'],
            saved_proof_checks=[a['proof_check'] for a in case['arms']],
            model_counts=dict(placements=len(case['model']['placements']),
                words=len(case['model']['word_dictionary']),
                rows=len(case['model']['domains'])),
            source=dict(plan=pin(plan_path),result=pin(result_path),observer=pin(observer_path))))
        model=case['model'];lookup={tuple(t['key']):t for t in model['placements']}
        assert len(lookup)==len(model['placements'])
        for arm in case['arms']:
            search=arm['search'];checks=arm['proof_check'];index=None
            accepted=checks['native_proof_accepted'] is True
            if search['proof'] is not None:
                proof=search['proof'];assert len(search['placements'])==2*len(proof)
                assert accepted and checks['status']=='HOST_REGION_NATIVE_ACCEPTED'
                assert checks['host_check']['accepted'] is True and checks['region']['complete'] is True
                assert checks['native_record']['result']['status']=='accepted'
                assert checks['native_record']['request']['proof']==proof
                assert checks['native_record']['request']['blocks']==[]
                assignments=[]
                if arm['method']=='P0':
                    assignments=[dict(c['auxiliary'],certificate_id=c['id'],
                        support_witness_count=len(c['all_candidates']))
                        for c in case['marking']['markings']['certificates']]
                overlay={}
                for a in assignments:
                    overlay.setdefault(tuple(a['placement']),[]).append([a['point'],a['placement_value']])
                tiles=[];word_ids=set()
                for key in search['placements']:
                    tile=copy.deepcopy(lookup[tuple(key)])
                    row,choice=tile['command_reference']
                    assert model['domains'][row][choice]==proof[row]
                    tile['auxiliary_overlay']=overlay.get(tuple(key),[])
                    tile['marks']+=tile['auxiliary_overlay']
                    for point,value in tile['marks']:
                        if point[1]==100:
                            assert type(value) is int and 0<=value<len(model['word_dictionary'])
                            word_ids.add(value)
                    tiles.append(tile)
                words={}
                for word_id in sorted(word_ids):
                    literal=model['word_dictionary'][word_id]
                    words[str(word_id)]=dict(hex=literal,literal=json.loads(bytes.fromhex(literal).decode('utf8')))
                index=len(proofs)
                proofs.append(dict(title=spec['title']+' · '+arm['method'],method=arm['method'],
                    admitted_proof=True,proof=proof,target=spec['target'],tiles=tiles,words=words,
                    word_terminator=model['word_terminator'],proof_check=checks,
                    fixed_auxiliary_initial=assignments,
                    source=dict(result=pin(result_path),record_index=0,method=arm['method']),
                    scope='Accepted saved primitive proof; all original fixed-length rows retained.'))
            slots.append(dict(case_id=spec['id'],stage_id=recipe,method=arm['method'],
                search_status=search['status'],proof_status=checks['status'],
                admitted_proof=accepted,proof_view_index=index,
                metrics=search['metrics'],domain_audits=search.get('domain_audits'),
                root_restored=search['root_restored'],
                attempt_unit=arm['attempt_unit'],search_seconds=search['seconds'],
                full_arm_seconds=arm['seconds'],
                auxiliary_failure_markings=arm['auxiliary_failure_markings']))
    out=dict(schema='D19-passive-closed-fragment-reader-v1',
        summary='Three complete admitted jobs; six search records; one distinct arithmetic target accepted by both methods; four bounded UNKNOWN searches. No geometry proof found and no GCTS or RL advantage established.',
        document=document,jobs=jobs,slots=slots,proofs=proofs,
        total_observer_seconds=sum(j['observer_seconds'] for j in jobs),
        admission=pin(admission_path),
        scientific_calls=0,scientific_imports=0,partial_files_parsed=0,
        scope='Passive literal projection only. No search, checker, compiler, decoder inference or new admission is run by this reader. Complete word payload decoding is for display only. No domain result is adopted by the separate learner.')
    path=STUDY/'publication/domain-probes-data.json'
    with path.open('x') as stream:
        json.dump(out,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps(pin(path),sort_keys=True))

if __name__=='__main__':
    main()
