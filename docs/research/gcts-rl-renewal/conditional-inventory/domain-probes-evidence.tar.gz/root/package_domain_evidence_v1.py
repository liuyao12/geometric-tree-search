"""Closed passive domain-only archive. No research code imports/calls.
Root invokes after independent actual/reader reviews and admission.
Unfinished main learner Sources and inputs are deliberately outside this package.
"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

STUDY=Path(__file__).resolve().parents[1]
REPO=STUDY.parents[1]
OUT=STUDY/'publication'
PARENT=REPO/'research-runs/gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory/reader.html'

def encoded(v):
    return (json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()

def pin(p):
    p=Path(p).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def read(p):
    assert '.partial' not in Path(p).name
    return json.loads(Path(p).read_bytes())

def main():
    before=PARENT.read_bytes()
    assert len(before)==120840
    assert hashlib.sha256(before).hexdigest()=='add07219148b789e4a8b3a26937d1b7ed0dce868ca7729450d89042e9f39a527'
    preimage=STUDY/'root/domain-parent-reader-before-v1.html'
    with preimage.open('xb') as stream:stream.write(before)
    paths={};omitted={}
    def add(path):
        path=Path(path).resolve()
        assert not path.is_symlink()
        assert path.is_relative_to(REPO)
        name=str(path.relative_to(STUDY)) if path.is_relative_to(STUDY) else 'declared-dependencies/'+str(path.relative_to(REPO))
        paths[name]=path
    admission_path=STUDY/'root/Root-domain-admissions-v1.json'
    admission=read(admission_path)
    assert admission['complete_review'] is True
    for row in admission['jobs']:
        plan=read(row['plan']['path']);assert row['admitted'] is True
        for p in plan['files']:
            assert pin(p['path'])==p
            source=Path(p['path'])
            if source==Path(plan['python']['path']) or source.name=='boundary-oracle-v2':
                omitted[str(source)]=dict(**p,reason='Runtime executable identity only; executable body is not redistributed.')
            else:add(source)
        add(row['plan']['path'])
        for folder in (Path(plan['actual_dir']),Path(plan['actual_dir']+'.observer')):
            for p in sorted(folder.rglob('*')):
                if p.is_file():add(p)
    for name in ('Root-domain-preflight-and-grants-v1.json','Root-domain-serial-barrier-v1.json',
                 'Root-domain-serial-window-terminal-v1.json','Root-domain-admissions-v1.json',
                 'domain-plan-family-v1.json','domain-Source-composition-v1.json',
                 'domain-entry-D18-D19-v1.patch','domain-worker-D18-D19-v1.patch',
                 'project_domain_reader_v1.py','package_domain_evidence_v1.py',
                 'domain-parent-reader-before-v1.html'):
        add(STUDY/'root'/name)
    for p in sorted((STUDY/'root/domain-grants').glob('*.json')):add(p)
    for p in ('domain-probes-inputs-v1.json','closed_fragment_domain_contract_v1.py',
              'domain-contract-API-v1.json','domain-contract-handoff-v1.json'):
        add(STUDY/'diagnostics-L'/p)
    reviews=[admission['C_review'],admission['prospective_review']]
    reviews+=read(STUDY/'root/domain-reader-reviewed-v1.json')['reviews']
    add(STUDY/'root/domain-reader-reviewed-v1.json')
    for p in reviews:
        assert pin(p['path'])==p
        add(p['path'])
    for name in ('typed-domain-contract-Source-review-v1.json','proof-language-support-and-extension-audit-v1.json'):
        add(STUDY/'review-C'/name)
    for name in ('domain-probes.html','domain-probes-data.json'):add(OUT/name)
    rows=[dict(archive_path=name,opaque_partial=('.partial' in path.name),**pin(path))
          for name,path in sorted(paths.items())]
    snapshot=dict(schema='D19-domain-only-raw-evidence-snapshot-v1',files=rows,
        omitted_runtime=list(omitted.values()),partial_files_parsed=0,scientific_calls=0,
        scope='Exact three domain Source/input/plan/grant/actual/review/admission closure and passive reader. No unfinished main selector corpus, policy or Source. Raw partials if present are opaque only. Later installation and live verification receipts remain outside this snapshot.')
    manifest=encoded(snapshot);archive=OUT/'domain-probes-evidence.tar.gz'
    with archive.open('xb') as target:
        with gzip.GzipFile(fileobj=target,mode='wb',filename='',mtime=0,compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped,mode='w') as tar:
                def member(name,body):
                    info=tarfile.TarInfo(name);info.size=len(body);info.mode=0o644
                    info.mtime=info.uid=info.gid=0
                    tar.addfile(info,io.BytesIO(body))
                member('snapshot-manifest.json',manifest)
                for row in rows:
                    body=Path(row['path']).read_bytes()
                    assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
                    member(row['archive_path'],body)
    expected={r['archive_path']:(r['bytes'],r['sha256']) for r in rows}
    expected['snapshot-manifest.json']=(len(manifest),hashlib.sha256(manifest).hexdigest())
    seen=set()
    with tarfile.open(archive,'r|gz') as tar:
        for item in tar:
            assert item.isfile() and item.name in expected and item.name not in seen
            seen.add(item.name);body=tar.extractfile(item).read()
            assert (len(body),hashlib.sha256(body).hexdigest())==expected[item.name]
    assert seen==set(expected)
    for row in rows:assert pin(row['path'])=={k:row[k] for k in ('path','bytes','sha256')}
    final=dict(snapshot,archive=pin(archive),all_members_raw_verified=True,
               regular_files=len(seen),uncompressed_bytes=sum(r['bytes'] for r in rows))
    dest=OUT/'domain-probes-manifest.json'
    with dest.open('xb') as stream:stream.write(encoded(final))
    print(json.dumps(dict(archive=pin(archive),manifest=pin(dest),members=len(seen))))

if __name__=='__main__':
    main()
