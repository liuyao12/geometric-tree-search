"""Independent codec-only qualification fixtures. Never run during authorship.

No scientific module import, private codec hook, native policy getter or parser
qualification. All synthetic construction/oracle work occurs only in a future
reviewed bounded actual. Read public codec papers before authoring this Source;
no codec implementation was read. Scalar/reference oracles use stdlib only.
"""
import hashlib
import json
import math
import struct

VERSION = 'FPC-LOSSLESS-EVIDENCE-INDEPENDENT-CONTROLS-v1'
RETURN_SCHEMA = 'FPC-lossless-evidence-independent-controls-v1'
POPULATION = 'lossless_evidence_codec8_v1'
CONTROL_IDS = (
    'original-value-inverse-and221-paths',
    'typed-scalars-and-integer-domain',
    'canonical-sharing-order-and-occurrences',
    'malformed-carriers-and-reference-refusals',
    'owned-snapshot-and-public-lifecycle',
    'first-callback-writer-and-retained-error',
    'streamed-whole-and-path-readback',
    'callable-intake-policy-and-session-isolation',
)
BANK_ORDER = ('baseline56', 'obligation47', 'intro_integration1', 'regression2',
              'point20', 'explicit16', 'tiny-full-provider10',
              'full-frame-controller10', 'constructor-index14',
              'fixed-free-slot8', 'matched-controller8', 'selector6',
              'nonwrapper_selector6', 'signed_propositional8_successor_v2',
              'occurrence_diagnostics9')
LIMITS = {'work_seconds': 160, 'positive_seconds': 180, 'custody_seconds': 210,
          'observer_fallback_seconds': 225, 'memory_bytes': 1073741824,
          'physical_bytes': 134217728, 'result_bytes': 50331648,
          'log_bytes': 4194304, 'reserved_outer_bytes': 9437184,
          'root_callbacks': 400000000}
ENVELOPE_KEYS = ('schema', 'profile', 'scope_manifest', 'bank_roots',
                 'control_index', 'nodes', 'blobs', 'qualification_root',
                 'capture_root', 'canonical_qualification')
PAYLOAD = {'types': [None, False, True, 0, 1, -1, 0.0, -0.0, 1.0, '1'],
           'strings': ['', '\\u0000', '\x00', '\\', '\u00e9', 'e\u0301',
                       '\ud800', '$ref', 'N', 'schema'],
           'ordered': [['a', 'b'], ['b', 'a']],
           'floats': [1e20, 1e-7, -1.25],
           'absent-vs-null': {'present': None}, 'empty': [[], {}]}
SCOPE = ('Codec-only synthetic transport qualification, not scientific221 '
         'observations or proof admission; original221 subjects unchanged.')
COVERAGE_LIMITS = (
    'Object-only API: no raw-wire duplicate-key/EOF parser qualification.',
    'No forced hash collision or native-policy getter/setter/mutation hook.',
    'Finite public boundaries, not all cutoffs/private phases or cleanup cost.',
    'No worker seven-null/pool/first-rejected-size or resource-fit qualification.',
)
_ENCODE_CALLS = ('ENCODER_OPEN',) + ('ADD_BANK',) * 15 + ('ENCODER_FINISH', 'CLOSE')
CALL_ENDPOINTS = (
    _ENCODE_CALLS + ('READER_OPEN', 'READ_EXISTING', 'CLOSE'),
    ('READER_OPEN', 'READ_VALUE', 'CLOSE', 'READER_OPEN', 'READER_OPEN'),
    _ENCODE_CALLS + ('READER_OPEN',),
    ('READER_OPEN',) * 6 + ('ENCODER_OPEN', 'ADD_BANK', 'CLOSE'),
    ('ENCODER_OPEN',) + ('ADD_BANK',) * 15 +
    ('ENCODER_FINISH', 'ENCODER_FINISH', 'CLOSE', 'READER_OPEN', 'READ_VALUE',
     'READ_VALUE', 'CLOSE', 'READ_EXISTING', 'CLOSE', 'CLOSE', 'READ_EXISTING'),
    ('ENCODER_OPEN',) * 4 + ('READER_OPEN', 'READ_EXISTING', 'READ_VALUE', 'CLOSE',
     'READER_OPEN', 'ENCODER_OPEN', 'ADD_BANK', 'CLOSE', 'ENCODER_OPEN') +
    ('ADD_BANK',) * 15 + ('ENCODER_FINISH', 'CLOSE', 'READER_OPEN', 'READ_EXISTING',
     'CLOSE', 'READER_OPEN', 'READ_VALUE', 'CLOSE'),
    _ENCODE_CALLS + ('READER_OPEN', 'READ_EXISTING', 'READ_VALUE', 'CLOSE'),
    ('ENCODER_OPEN', 'ENCODER_OPEN', 'ENCODER_OPEN', 'ENCODER_FINISH', 'CLOSE',
     'READER_OPEN', 'READ_EXISTING', 'CLOSE', 'READER_OPEN', 'READ_VALUE', 'CLOSE') +
    _ENCODE_CALLS,
)
CALL_COUNTS = (21, 5, 19, 9, 27, 36, 22, 29)
RAISED_CALLS = ((), (3, 4), (18,), (0, 1, 2, 3, 4, 5, 7),
                (17, 23, 26), (0, 1, 2, 3, 5, 6, 8, 10, 28, 31, 34),
                (), (0, 1, 3, 6, 9))


class EvidenceControlError(ValueError):
    pass


class _Call:
    def __init__(self, check):
        self.check = check
        self.first = None
        self.callbacks = 0
        self.events = []
        self.group = 0

    def invoke(self, endpoint, action):
        if self.first is not None:
            raise self.first
        event = {'ordinal': len(self.events), 'control_index': self.group,
                 'endpoint': endpoint, 'outcome': 'ENTERED'}
        self.events.append(event)
        try:
            result = action()
        except BaseException:
            if self.first is not None:
                raise self.first
            event['outcome'] = 'RAISED'
            raise
        if self.first is not None:
            raise self.first
        event['outcome'] = 'RETURNED'
        return result

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise
        self.callbacks += 1

    def require(self, condition, message):
        if self.first is not None:
            raise self.first
        if not condition:
            raise EvidenceControlError(message)


def _copy(value, call):
    """Checked copy of finite authored/ordinary exported JSON, no conversions."""
    root = [None]
    todo = [(value, root, 0)]
    while todo:
        call.tick()
        item, parent, slot = todo.pop()
        kind = type(item)
        if kind is list or kind is tuple:
            out = [None] * len(item)
            parent[slot] = out
            for index in range(len(item) - 1, -1, -1):
                call.tick()
                todo.append((item[index], out, index))
        elif kind is dict:
            out = {}
            parent[slot] = out
            for key in item:
                call.tick()
                call.require(type(key) is str, 'copy key')
                todo.append((item[key], out, key))
        else:
            call.require(kind in (type(None), bool, int, float, str), 'copy scalar')
            parent[slot] = item
    return root[0]


def _quoted(value, call):
    chunks = ['"']
    for start in range(0, len(value), 256):
        call.tick()
        # Finite exact-str slices, no native container/semantic walk.
        chunks.append(json.dumps(value[start:start + 256], ensure_ascii=True)[1:-1])
    chunks.append('"')
    return ''.join(chunks)


def _canon(value, call):
    """Independent explicit-stack reference spelling for bounded test values."""
    out = []
    todo = [('value', value)]
    while todo:
        call.tick()
        action, item = todo.pop()
        if action == 'text':
            out.append(item)
            continue
        kind = type(item)
        if kind is str:
            out.append(_quoted(item, call))
        elif kind in (type(None), bool, int, float):
            if kind is int:
                call.require(item.bit_length() <= 128, 'oracle integer scope')
            if kind is float:
                call.require(math.isfinite(item), 'oracle finite float')
            out.append(json.dumps(item, ensure_ascii=True, allow_nan=False))
        elif kind in (list, tuple):
            out.append('[')
            todo.append(('text', ']'))
            for index in range(len(item) - 1, -1, -1):
                call.tick()
                todo.append(('value', item[index]))
                if index:
                    todo.append(('text', ','))
        elif kind is dict:
            keys = []
            for key in item:
                call.tick()
                call.require(type(key) is str and len(key) <= 256, 'oracle key')
                keys.append(key)
            call.require(len(keys) <= 32, 'oracle object scope')
            for position in range(1, len(keys)):
                key = keys[position]
                cursor = position
                while cursor:
                    call.tick()
                    if not key < keys[cursor - 1]:
                        break
                    keys[cursor] = keys[cursor - 1]
                    cursor -= 1
                keys[cursor] = key
            out.append('{')
            todo.append(('text', '}'))
            for index in range(len(keys) - 1, -1, -1):
                call.tick()
                key = keys[index]
                todo.append(('value', item[key]))
                todo.append(('text', ':'))
                todo.append(('text', _quoted(key, call)))
                if index:
                    todo.append(('text', ','))
        else:
            raise EvidenceControlError('oracle domain')
    out.append('\n')
    return ''.join(out).encode('ascii')


def _equal_bytes(left, right, call):
    call.require(type(left) is bytes and type(right) is bytes, 'exact bytes')
    if len(left) != len(right):
        return False
    for start in range(0, len(left), 4096):
        call.tick()
        if left[start:start + 4096] != right[start:start + 4096]:
            return False
    return True


def _digest(body, call):
    result = hashlib.sha256()
    for start in range(0, len(body), 4096):
        call.tick()
        result.update(body[start:start + 4096])
    return result.hexdigest()


def _same(left, right, call):
    return _equal_bytes(_canon(left, call), _canon(right, call), call)


def _forest(scopes, call, payload=None):
    """Complete221 structure; authored labels confer no scientific status."""
    values = {}
    for name in BANK_ORDER:
        call.tick()
        values[name] = {'codec_only_synthetic': True, 'scientific_claim': False}
    count = 0
    for scope in scopes:
        call.tick()
        name = scope['population']
        key = name
        if name in ('point-kernel13', 'point-kernel-safety3'):
            key = 'explicit16'
        call.require(key in values, 'scope population')
        rows = []
        for identifier in scope['control_ids']:
            call.tick()
            rows.append({'id': identifier, 'codec_only_synthetic': True,
                         'scientific_claim': False,
                         'payload': PAYLOAD if payload is None else payload})
            count += 1
        holder = values[key]
        if name == 'point-kernel13':
            holder['raw_population'] = {'codec_only_synthetic': True,
                                        'scientific_claim': False, 'controls': rows}
        elif name == 'point-kernel-safety3':
            holder['additional_population'] = {'codec_only_synthetic': True,
                                               'scientific_claim': False, 'controls': rows}
        else:
            holder['controls'] = rows
    call.require(count == 221 and len(scopes) == 16, 'full carrier structure')
    return values


def _path_value(value, path, call):
    current = value
    for part in path:
        call.tick()
        current = current[part]
    return current


def _node_value(nodes, target, call):
    """Independent bounded control-only inverse of public node records.

    Not a production reader or raw parser. Build only this small fixture's
    prefix, checking backward references; native scalar operations are bounded.
    """
    call.require(type(target) is int and 0 <= target < len(nodes) <= 4096,
                 'control node bounds')
    decoded = []
    for number in range(target + 1):
        call.tick()
        node = nodes[number]
        call.require(type(node) is list and node, 'control node carrier')
        tag = node[0]
        if tag == 'N':
            call.require(len(node) == 1, 'N arity')
            value = None
        elif tag == 'B':
            call.require(len(node) == 2 and type(node[1]) is bool, 'B payload')
            value = node[1]
        elif tag == 'I':
            call.require(len(node) == 2 and type(node[1]) is str and
                         len(node[1]) <= 40, 'control I bound')
            value = int(node[1])
            call.require(str(value) == node[1], 'canonical small integer')
        elif tag == 'F':
            call.require(len(node) == 3 and type(node[1]) is str and
                         len(node[1]) == 16 and type(node[2]) is str and
                         len(node[2]) <= 32, 'control F bound')
            value = struct.unpack('>d', bytes.fromhex(node[1]))[0]
            call.require(math.isfinite(value) and
                         json.dumps(value, allow_nan=False) == node[2] and
                         struct.pack('>d', value).hex() == node[1],
                         'bits and exact finite token')
        elif tag == 'S':
            call.require(len(node) == 2 and type(node[1]) is str and
                         len(node[1]) <= 8192, 'control S bound')
            value = node[1]
        elif tag == 'A':
            call.require(len(node) == 2 and type(node[1]) is list and
                         len(node[1]) <= 256, 'control A bound')
            value = []
            for child in node[1]:
                call.tick()
                call.require(type(child) is int and 0 <= child < number,
                             'backward child')
                value.append(decoded[child])
        elif tag == 'O':
            call.require(len(node) == 2 and type(node[1]) is list and
                         len(node[1]) <= 32, 'control O bound')
            value = {}
            last = None
            for pair in node[1]:
                call.tick()
                call.require(type(pair) is list and len(pair) == 2 and
                             type(pair[0]) is str and len(pair[0]) <= 256 and
                             type(pair[1]) is int and 0 <= pair[1] < number,
                             'O pair')
                call.require(last is None or last < pair[0], 'sorted object keys')
                last = pair[0]
                value[pair[0]] = decoded[pair[1]]
        else:
            raise EvidenceControlError('unknown control node tag')
        decoded.append(value)
    return decoded[target]


def _retire(handle, call):
    try:
        if call.first is not None:
            result = handle.close()
        else:
            result = call.invoke('CLOSE', handle.close)
    except BaseException:
        if call.first is not None:
            raise call.first
        raise
    if call.first is not None:
        raise call.first
    call.require(result is None, 'close returns None')


def _observation(label, endpoint, outcome, evidence):
    return {'label': label, 'endpoint': endpoint, 'outcome': outcome,
            'evidence': evidence}


def _keys(value, expected, call):
    if type(value) is not dict or len(value) != len(expected):
        return False
    actual = []
    for key in value:
        call.tick()
        if type(key) is not str or len(key) > 256:
            return False
        actual.append(key)
    return set(actual) == set(expected)


def _invalid(action, codec, call, reason, prefix, exact=False):
    """Observe diagnostics, never classify private ownership/recover a handle."""
    call.tick()
    try:
        action()
    except BaseException as error:
        if call.first is not None:
            raise call.first
        call.require(type(error) is codec.EvidenceFormatError, 'diagnostic class')
        seen_reason = error.reason
        path = error.path
        call.require(type(seen_reason) is str and seen_reason == reason, 'reason')
        call.require(type(path) is tuple, 'immutable diagnostic path')
        for item in path:
            call.tick()
            call.require(type(item) is str or (type(item) is int and item >= 0),
                         'diagnostic path component')
        call.require(path == prefix if exact else path[:len(prefix)] == prefix,
                     'diagnostic path/prefix')
        return error, {'reason': seen_reason, 'path': list(path),
                       'exception_type': 'EXACT_PUBLIC_EvidenceFormatError',
                       'path_container_type': 'EXACT_TUPLE',
                       'path_assertion': 'EXACT' if exact else 'TYPED_PREFIX'}
    raise EvidenceControlError('expected public refusal')


def _encoder(codec, scopes, limits, policy, call, check=None):
    return call.invoke('ENCODER_OPEN', lambda: codec.open_encoder(
                              scope_manifest=scopes, profile='EXISTING_JSON221_V1',
                              limits=limits, reference_integer_policy=policy,
                              check=call.tick if check is None else check))


def _reader(codec, envelope, limits, policy, call, check=None):
    return call.invoke('READER_OPEN', lambda: codec.open_reader(envelope, limits=limits,
                             reference_integer_policy=policy,
                             check=call.tick if check is None else check))


def _encode(codec, scopes, limits, policy, values, call):
    original_input = _canon([scopes, limits, values], call)
    handle = _encoder(codec, scopes, limits, policy, call)
    try:
        for name in BANK_ORDER:
            call.tick()
            ref = call.invoke('ADD_BANK', lambda: handle.add_bank(name, values[name]))
            call.require(type(ref) is int and ref >= 0, 'bank ref')
        envelope = call.invoke('ENCODER_FINISH', handle.finish)
        call.require(_keys(envelope, ENVELOPE_KEYS, call),
                     'complete envelope keys')
        call.require(envelope['blobs'] == [] and envelope['capture_root'] is None,
                     'JSON only profile')
        call.require(_equal_bytes(original_input, _canon([scopes, limits, values], call),
                                  call), 'encoder input stability')
        return envelope
    finally:
        _retire(handle, call)


def _read(reader, call, path=None):
    chunks = []
    sizes = []
    def write(chunk):
        call.tick()
        call.require(type(chunk) is bytes and len(chunk) <= 65536, 'output chunk')
        chunks.append(chunk)
        sizes.append(len(chunk))
    receipt = (call.invoke('READ_EXISTING', lambda: reader.write_existing_json(write))
               if path is None else
               call.invoke('READ_VALUE', lambda: reader.write_value_json(path, write)))
    body = b''.join(chunks)
    call.require(_keys(receipt, ('schema', 'complete', 'bytes', 'sha256'), call),
                 'readback keys')
    call.require(receipt['schema'] == 'FPC-lossless-evidence-readback-v1' and
                 receipt['complete'] is True and type(receipt['bytes']) is int and
                 receipt['bytes'] == len(body) and receipt['sha256'] == _digest(body, call),
                 'complete readback receipt')
    return body, receipt, sizes


def _foreign(action, probe, call):
    call.tick()
    try:
        action()
    except BaseException as error:
        if call.first is not None:
            raise call.first
        call.require(error is probe.error and probe.calls == 1, 'first E identity')
        return {'identical_first_object': True, 'callbacks_or_writes': probe.calls}
    raise EvidenceControlError('foreign E must escape')


class _Probe:
    def __init__(self, error, call):
        self.error = error
        self.call = call
        self.calls = 0
        self.enabled = True

    def arm(self):
        self.calls = 0
        self.enabled = True

    def __call__(self, *args):
        self.call.tick()
        if not self.enabled:
            return
        self.calls += 1
        if self.calls == 1:
            raise self.error
        raise RuntimeError('later F must not be called')


class _HostileDict(dict):
    def __iter__(self):
        raise RuntimeError('foreign iteration forbidden')

    def __getitem__(self, key):
        raise RuntimeError('foreign lookup forbidden')


def run_lossless_evidence_controls(codec, *, scope_manifest, limits,
                                   reference_integer_policy, check):
    call = _Call(check)
    call.tick()
    call.require(codec.VERSION == 'FPC-LOSSLESS-QUALIFICATION-EVIDENCE-CODEC-v1',
                 'codec VERSION')
    call.require(type(scope_manifest) is list and type(limits) is dict and
                 _same(limits, LIMITS, call), 'genuine scope/caps arguments')
    call.require(type(reference_integer_policy) is tuple and
                 len(reference_integer_policy) == 2 and
                 type(reference_integer_policy[0]) is str and
                 reference_integer_policy[0] == 'FPC-original-json-integer-policy-v1' and
                 type(reference_integer_policy[1]) is int and reference_integer_policy[1] >= 0,
                 'policy carrier')
    scopes = _copy(scope_manifest, call)
    caps = _copy(limits, call)
    before = _canon([scope_manifest, limits], call)
    policy = reference_integer_policy
    values = _forest(scopes, call)
    original = _canon(values, call)
    envelope = _encode(codec, scopes, caps, policy, values, call)
    rows = []
    def finish_group(index, observations, boundaries=()):
        call.tick()
        rows.append({'id': CONTROL_IDS[index], 'passed': True,
                     'observations': observations, 'coverage_limits': list(boundaries)})
        call.group = min(index + 1, 7)

    # Group1: genuine public inverse, not encoded-DAG hash alone.
    reader = _reader(codec, envelope, caps, policy, call)
    try:
        body, receipt, sizes = _read(reader, call)
    finally:
        _retire(reader, call)
    call.require(_equal_bytes(body, original, call), 'ORIGINAL full inverse')
    index = envelope['control_index']
    call.require(type(index) is list and len(index) == 221, 'all221 anchors')
    expected_anchors = []
    for scope in scopes:
        population = scope['population']
        key = population
        initial = []
        if population in ('point-kernel13', 'point-kernel-safety3'):
            key = 'explicit16'
            initial = ['raw_population' if population == 'point-kernel13'
                       else 'additional_population']
        for offset in range(len(scope['control_ids'])):
            call.tick()
            expected_anchors.append((population, scope['control_ids'][offset], key,
                                     [key] + initial + ['controls', offset]))
    joined = []
    for number in range(len(index)):
        call.tick()
        anchor = index[number]
        expected_anchor = expected_anchors[number]
        call.require(_keys(anchor, ('population', 'id', 'bank_key', 'path', 'row_ref'),
                           call), 'anchor keys')
        call.require(anchor['population'] == expected_anchor[0] and
                     anchor['id'] == expected_anchor[1] and
                     anchor['bank_key'] == expected_anchor[2] and
                     _same(anchor['path'], expected_anchor[3], call),
                     'complete ordered original anchor association')
        original_row = _path_value(values, anchor['path'], call)
        decoded_row = _node_value(envelope['nodes'], anchor['row_ref'], call)
        call.require(original_row['id'] == anchor['id'] and
                     _same(original_row, decoded_row, call), 'whole row-ref inverse')
        joined.append({'population': anchor['population'], 'id': anchor['id'],
                       'path': _copy(anchor['path'], call), 'row_ref': anchor['row_ref']})
    finish_group(0, [_observation('complete-original-inverse', 'READ_EXISTING',
                                'NORMAL_COMPLETE', {'original_Canon': original.decode('ascii'),
                                'observed_Canon': body.decode('ascii'), 'receipt': receipt,
                                'complete221anchors': joined})])

    # Group2: complete literal scalar/lexeme payload, no huge integer instance.
    path = ['baseline56', 'controls', 0, 'payload']
    reader = _reader(codec, envelope, caps, policy, call)
    try:
        small_body, small_receipt, _ = _read(reader, call, path)
    finally:
        _retire(reader, call)
    call.require(_equal_bytes(small_body, _canon(PAYLOAD, call), call), 'typed payload')
    scalar_observations = [_observation('literal-types-and-lexemes', 'READ_VALUE',
        'NORMAL_COMPLETE', {'original_payload': _copy(PAYLOAD, call),
                            'observed_Canon': small_body.decode('ascii'),
                            'receipt': small_receipt})]
    for label, tag, replacement in (
            ('bad-integer-token', 'I', ['I', '-0']),
            ('bad-float-bit-token', 'F', ['F', '0000000000000000', '-0.0'])):
        bad = _copy(envelope, call)
        found = None
        for pos in range(len(bad['nodes'])):
            call.tick()
            if bad['nodes'][pos][0] == tag:
                found = pos
                break
        call.require(found is not None, 'required scalar node')
        bad['nodes'][found] = replacement
        _, detail = _invalid(lambda: _reader(codec, bad, caps, policy, call),
                             codec, call, 'INVALID_EVIDENCE', ('envelope',))
        scalar_observations.append(_observation(label, 'READER_OPEN',
                                                'REFUSAL_DIAGNOSTIC', detail))
    finish_group(1, scalar_observations,
                 ('Large/unbounded integer-domain/native getter paths Source-only.',))

    # Group3: changing dict insertion order or caller acyclic alias is immaterial.
    reversed_values = {}
    for name in reversed(BANK_ORDER):
        call.tick()
        reversed_values[name] = dict(reversed(list(values[name].items())))
    second = _encode(codec, scopes, caps, policy, reversed_values, call)
    call.require(_same(envelope, second, call), 'deterministic canonical envelope')
    seen_descriptors = set()
    for node in envelope['nodes']:
        call.tick()
        descriptor = _canon(node, call)
        call.require(len(descriptor) <= 4096 and descriptor not in seen_descriptors,
                     'exact typed descriptor uniqueness')
        call.tick()
        seen_descriptors.add(descriptor)
    bad = _copy(envelope, call)
    bad['nodes'].append(_copy(bad['nodes'][-1], call))
    _, detail = _invalid(lambda: _reader(codec, bad, caps, policy, call),
                         codec, call, 'INVALID_EVIDENCE', ('envelope',))
    finish_group(2, [_observation('insertion-and-alias-normalization', 'ENCODER_FINISH',
        'NORMAL_COMPLETE', {'complete_envelopes_equal': True,
                            'node_count': len(envelope['nodes']),
                            'distinct_occurrence_anchors': len(index)}),
        _observation('duplicate-orphan-node', 'READER_OPEN', 'REFUSAL_DIAGNOSTIC', detail)],
        ('No forced collision or independent complete expected-node-table claim.',))

    # Group4: isolated closed-format and exact-carrier refusals.
    malformed = []
    for label in ('unknown-tag', 'bool-root', 'forward-child', 'blob-in-JSON-profile',
                  'wrong-anchor', 'hostile-envelope'):
        bad = _copy(envelope, call)
        if label == 'unknown-tag':
            bad['nodes'][0] = ['UNKNOWN']
        elif label == 'bool-root':
            bad['qualification_root'] = True
        elif label == 'forward-child':
            bad['nodes'][0] = ['A', [0]]
        elif label == 'blob-in-JSON-profile':
            bad['blobs'] = [{}]
        elif label == 'wrong-anchor':
            bad['control_index'][0]['id'] = 'not-the-declared-id'
        else:
            bad = _HostileDict(bad)
        _, detail = _invalid(lambda: _reader(codec, bad, caps, policy, call),
                             codec, call, 'INVALID_EVIDENCE', ('envelope',))
        malformed.append(_observation(label, 'READER_OPEN', 'REFUSAL_DIAGNOSTIC', detail))
    cyc = []
    cyc.append(cyc)
    cyclic_bank = _copy(values[BANK_ORDER[0]], call)
    cyclic_bank['controls'][0]['payload'] = cyc
    handle = _encoder(codec, scopes, caps, policy, call)
    try:
        _, detail = _invalid(lambda: call.invoke('ADD_BANK',
                             lambda: handle.add_bank(BANK_ORDER[0], cyclic_bank)), codec,
                             call, 'CYCLIC_INPUT', (BANK_ORDER[0],))
    finally:
        _retire(handle, call)
    malformed.append(_observation('actual-active-cycle', 'ADD_BANK',
                                  'REFUSAL_DIAGNOSTIC', detail))
    finish_group(3, malformed, ('Other hostile/multi-defect/canonical variants Source-only.',))

    # Group5: all mutations after corresponding successful intake only.
    local_scopes = _copy(scopes, call)
    local_caps = _copy(caps, call)
    handle = _encoder(codec, local_scopes, local_caps, policy, call)
    local_scopes.clear()
    local_caps.clear()
    try:
        for name in BANK_ORDER:
            bank = _copy(values[name], call)
            call.invoke('ADD_BANK', lambda: handle.add_bank(name, bank))
            bank.clear()
        detached = call.invoke('ENCODER_FINISH', handle.finish)
        call.require(_same(detached, envelope, call), 'owned encoder snapshots')
        _, detail = _invalid(lambda: call.invoke('ENCODER_FINISH', handle.finish),
                             codec, call, 'INVALID_SESSION_STATE',
                             ('state',), True)
    finally:
        _retire(handle, call)
    copy_envelope = _copy(envelope, call)
    reader = _reader(codec, copy_envelope, caps, policy, call)
    copy_envelope.clear()
    mutable_path = list(path)
    try:
        first, _, _ = _read(reader, call, mutable_path)
        mutable_path.clear()
        repeated, _, _ = _read(reader, call, path)
        call.require(_equal_bytes(first, repeated, call), 'reader/path snapshot')
    finally:
        _retire(reader, call)
    before_closed = call.callbacks
    closed_error, closed_detail = _invalid(lambda: call.invoke('READ_EXISTING',
        lambda: reader.write_existing_json(None)),
        codec, call, 'INVALID_SESSION_STATE', ('state',), True)
    # _invalid adds one pre-call and one singleton-path tick; codec none.
    call.require(call.callbacks == before_closed + 2, 'closed callback-free gate')
    _retire(reader, call)
    _retire(reader, call)
    try:
        call.invoke('READ_EXISTING', lambda: reader.write_existing_json(None))
    except BaseException as error:
        if call.first is not None:
            raise call.first
        call.require(error is closed_error, 'closed poison identity')
    else:
        raise EvidenceControlError('closed poison normal return')
    finish_group(4, [_observation('owned-postintake-mutation', 'ENCODER_FINISH',
        'NORMAL_COMPLETE', {'envelope_equal': True, 'repeat_finish': detail,
                            'reader_path_equal': True}),
        _observation('closed-poison-and-idempotent-close', 'READ_EXISTING',
                     'REFUSAL_DIAGNOSTIC', closed_detail)])

    # Group6: intentional faults are not genuine Root faults; every probe first
    # calls outer Root tick. Never examine diagnostics if genuine Root failed.
    fault_observations = []
    retained, _ = _invalid(lambda: call.invoke('ENCODER_OPEN',
        lambda: codec.open_encoder(scope_manifest=scopes,
        profile='EXISTING_JSON221_V1', limits=caps, reference_integer_policy=policy,
        check=None)), codec, call, 'INVALID_CODEC_CALL', ('check',), True)
    for label, error in (('first-StopIteration', StopIteration('intentional E')),
                         ('same-public-class', codec.EvidenceFormatError('intentional E')),
                         ('retained-public-refusal', retained)):
        probe = _Probe(error, call)
        if label == 'first-StopIteration':
            action = lambda: call.invoke('ENCODER_OPEN', lambda: codec.open_encoder(
                scope_manifest=[], profile='INVALID', limits=caps,
                reference_integer_policy=policy, check=probe))
        else:
            action = lambda: _encoder(codec, scopes, caps, policy, call, probe)
        detail = _foreign(action, probe, call)
        fault_observations.append(_observation(label, 'ENCODER_OPEN',
                                               'FOREIGN_IDENTITY', detail))
    reader = _reader(codec, envelope, caps, policy, call)
    probe = _Probe(RuntimeError('writer E'), call)
    try:
        detail = _foreign(lambda: call.invoke('READ_EXISTING',
                           lambda: reader.write_existing_json(probe)), probe, call)
        before_poison = call.callbacks
        try:
            call.invoke('READ_VALUE', lambda: reader.write_value_json(path, None))
        except BaseException as error:
            if call.first is not None:
                raise call.first
            call.require(error is probe.error and call.callbacks == before_poison,
                         'poison rethrows before callback')
        else:
            raise EvidenceControlError('poison normal return')
    finally:
        _retire(reader, call)
    fault_observations.append(_observation('writer-first-and-poisoned-method',
                                           'READ_EXISTING', 'FOREIGN_IDENTITY', detail))
    for endpoint in ('READER_OPEN', 'ADD_BANK', 'ENCODER_FINISH',
                     'READ_EXISTING', 'READ_VALUE'):
        probe = _Probe(RuntimeError('method-first E'), call)
        if endpoint == 'READER_OPEN':
            detail = _foreign(lambda: _reader(codec, envelope, caps, policy, call,
                                               probe), probe, call)
        else:
            probe.enabled = False
            if endpoint in ('ADD_BANK', 'ENCODER_FINISH'):
                handle = _encoder(codec, scopes, caps, policy, call, probe)
                try:
                    if endpoint == 'ENCODER_FINISH':
                        for name in BANK_ORDER:
                            call.tick()
                            call.invoke('ADD_BANK',
                                        lambda: handle.add_bank(name, values[name]))
                    probe.arm()
                    action = (lambda: call.invoke('ENCODER_FINISH', handle.finish)) \
                        if endpoint == 'ENCODER_FINISH' else \
                        (lambda: call.invoke('ADD_BANK', lambda: handle.add_bank(
                            BANK_ORDER[0], values[BANK_ORDER[0]])))
                    detail = _foreign(action, probe, call)
                finally:
                    _retire(handle, call)
            else:
                reader = _reader(codec, envelope, caps, policy, call, probe)
                probe.arm()
                try:
                    action = (lambda: call.invoke('READ_EXISTING',
                        lambda: reader.write_existing_json(None))) if endpoint == \
                        'READ_EXISTING' else (lambda: call.invoke('READ_VALUE',
                        lambda: reader.write_value_json(path, None)))
                    detail = _foreign(action, probe, call)
                finally:
                    _retire(reader, call)
        fault_observations.append(_observation('first-public-' + endpoint,
            endpoint, 'FOREIGN_IDENTITY', detail))
    finish_group(5, fault_observations, ('Only named public fault endpoints.',))

    # Group7: bounded finite expansion and chunked output; no astronomical DAG.
    stream_payload = {'repeated': ['x' * 4096, 'x' * 4096],
                      'nested': [[[[['leaf']]]]], 'empty': []}
    stream_values = _forest(scopes, call, stream_payload)
    stream_envelope = _encode(codec, scopes, caps, policy, stream_values, call)
    reader = _reader(codec, stream_envelope, caps, policy, call)
    try:
        all_body, all_receipt, chunk_sizes = _read(reader, call)
        part_body, part_receipt, _ = _read(reader, call, path)
    finally:
        _retire(reader, call)
    call.require(_equal_bytes(all_body, _canon(stream_values, call), call) and
                 _equal_bytes(part_body, _canon(stream_payload, call), call),
                 'stream ORIGINAL inverse')
    finish_group(6, [_observation('finite-repeated-whole-and-path', 'READ_EXISTING',
        'NORMAL_COMPLETE', {'original_payload': stream_payload,
                            'observed_payload_Canon': part_body.decode('ascii'),
                            'whole_receipt': all_receipt, 'path_receipt': part_receipt,
                            'complete_chunk_sizes': chunk_sizes})],
        ('Expanded full body is collected only for this finite codec-only control.',
         'No production eager expanded result, arbitrary expansion or fit claim.'))

    # Group8: closed public intake paths and fresh-session isolation.
    intake = []
    for label, action, reason, prefix, exact in (
        ('noncallable-check', lambda: call.invoke('ENCODER_OPEN',
            lambda: codec.open_encoder(scope_manifest=scopes,
            profile='EXISTING_JSON221_V1', limits=caps,
            reference_integer_policy=policy, check=0)), 'INVALID_CODEC_CALL', ('check',), True),
        ('bad-policy-bool', lambda: _encoder(codec, scopes, caps,
            (policy[0], True), call), 'INVALID_REFERENCE_INTEGER_POLICY_BINDING',
            ('reference_integer_policy',), True),
        ('missing-bank-finish', lambda: _encoder(codec, scopes, caps, policy, call),
            'INVALID_SESSION_STATE', ('state',), True),
        ):
        if label == 'missing-bank-finish':
            handle = action()
            try:
                _, detail = _invalid(lambda: call.invoke('ENCODER_FINISH', handle.finish),
                                     codec, call, reason, prefix, exact)
            finally:
                _retire(handle, call)
        else:
            _, detail = _invalid(action, codec, call, reason, prefix, exact)
        intake.append(_observation(label, 'ENCODER_FINISH' if label ==
                                   'missing-bank-finish' else 'ENCODER_OPEN',
                                   'REFUSAL_DIAGNOSTIC', detail))
    for label in ('noncallable-write', 'unknown-path'):
        reader = _reader(codec, envelope, caps, policy, call)
        try:
            action = (lambda: call.invoke('READ_EXISTING',
                lambda: reader.write_existing_json(None))) if label == \
                'noncallable-write' else (lambda: call.invoke('READ_VALUE',
                lambda: reader.write_value_json(['ABSENT'], lambda b: None)))
            _, detail = _invalid(action, codec, call, 'INVALID_CODEC_CALL',
                                 ('write',) if label == 'noncallable-write' else ('path',), True)
        finally:
            _retire(reader, call)
        intake.append(_observation(label, 'READ_EXISTING' if label ==
                                   'noncallable-write' else 'READ_VALUE',
                                   'REFUSAL_DIAGNOSTIC', detail))
    fresh = _encode(codec, scopes, caps, policy, _forest(scopes, call), call)
    call.require(_same(fresh, envelope, call), 'fresh session isolation')
    for group_number in range(8):
        actual_endpoints = []
        actual_outcomes = []
        for event in call.events:
            call.tick()
            if event['control_index'] == group_number:
                actual_endpoints.append(event['endpoint'])
                actual_outcomes.append(event['outcome'])
        call.require(tuple(actual_endpoints) == CALL_ENDPOINTS[group_number] and
                     len(actual_endpoints) == CALL_COUNTS[group_number],
                     'exact complete public call locator census')
        for offset in range(CALL_COUNTS[group_number]):
            call.tick()
            expected_outcome = 'RAISED' if offset in RAISED_CALLS[group_number] \
                else 'RETURNED'
            call.require(actual_outcomes[offset] == expected_outcome,
                         'exact public call outcome')
    intake.append(_observation('complete-public-call-census', 'BANK', 'NORMAL_COMPLETE',
        {'counts_per_group': list(CALL_COUNTS), 'complete_calls': _copy(call.events, call),
         'all_expected_sequences_equal': True}))
    finish_group(7, intake, ('Policy drift/native getter failure Source-only.',))
    call.require(_equal_bytes(before, _canon([scope_manifest, limits], call), call),
                 'caller scope/caps immutability')
    call.require(len(rows) == 8, 'complete8')
    return {'schema': RETURN_SCHEMA, 'version': VERSION, 'population': POPULATION,
            'complete': True, 'control_ids': list(CONTROL_IDS), 'controls': rows,
            'counts': {'groups': 8, 'passed': 8, 'failed': 0}, 'scope': SCOPE,
            'coverage_limits': list(COVERAGE_LIMITS), 'scientific_claim': False}
