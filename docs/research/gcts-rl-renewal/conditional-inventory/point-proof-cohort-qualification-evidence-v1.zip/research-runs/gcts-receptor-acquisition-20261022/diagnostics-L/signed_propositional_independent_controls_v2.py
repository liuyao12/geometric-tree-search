"""Prospective independent signed-calculus controls, authored without execution.

Only public contracts and pre-frozen expectations are inputs to this Source.
Tiny trees below are qualification inputs to the separate public compiler; no
tree or proof is supplied to production search or to any research target.
"""

import hashlib

VERSION = 'FPC-SIGNED-PROPOSITIONAL-INDEPENDENT-CONTROLS-v2'
RETURN_SCHEMA = 'FPC-signed-propositional-independent-controls-v1'
POPULATION = 'signed_propositional8_successor_v2'
PRODUCER_VERSION = 'FPC-H1-SIGNED-PROPOSITIONAL-PRODUCER-v2'
COMPILER_VERSION = 'FPC-H1-SIGNED-COMPILER-v2'
EMITTER_VERSION = 'FPC-H1-SIGNED-PRIMITIVE-EMITTERS-v1'
CONTROL_IDS = (
    'compiler-signed-rules-and-source-occurrences',
    'strict-invalid-tree-refusals',
    'search-closed-rule-counts-and-primitive-validation',
    'total-countermodels-and-second-split-branch',
    'malformed-unsupported-mode-and-EOF',
    'configuration-module-and-owned-refusals',
    'normal-FINAL-counts-and-owned-snapshot-isolation',
    'first-retained-fault-and-stale-diagnostic-identity',
)
SEMANTIC_KEYS = ('version', 'claim_mode', 'function_arities', 'predicate_arities',
                 'theory_profile', 'finite_axioms', 'Gamma', 'goal')
QUERY_KEYS = ('query_hex', 'bytes', 'sha256') + SEMANTIC_KEYS
COUNTERS = ('completed_atomic_steps', 'states_started', 'closed_branches',
            'split_nodes', 'active_stack_depth', 'active_entry_count',
            'pending_child_count', 'retained_closed_rule_nodes',
            'primitive_rows_emitted', 'compiler_emitter_instances')
DIAGNOSTICS = ('schema', 'snapshot_available', 'phase', 'phase_in_progress') + COUNTERS + (
    'observed_through_atomic_step',)
COMPILER_DIAGNOSTICS = (
    'schema', 'snapshot_available', 'phase', 'phase_in_progress',
    'active_control_index', 'active_fixture_index', 'compiler_invocation_index',
    'observed_through_callback', 'phase_enter_monotonic_ns',
    'construction_completed_ns', 'export_reachability_completed_ns',
    'export_encoding_completed_ns', 'formula_dag_nodes', 'ir_rows_created',
    'emitter_instances', 'reachable_rows', 'export_rows_committed',
    'expanded_headers_committed', 'wire_bytes_committed', 'active_encode_role',
)
CALL_LOCATORS = (
    ('F_IMP-alias', 'T_NOT', 'F_NOT', 'T_IMP-both-children', 'composite-CLOSE-first',
     'original-table-source', 'duplicate-Gamma-table-occurrences',
     'split-retains-unused-duplicate-Gamma'),
    ('extra-top-field', 'wrong-complete-query-hex', 'bool-node-id', 'missing-split-child',
     'shared-child-context', 'semantically-ordered-premises-but-wrong-DFS-postorder',
     'reversed-close-pair', 'wrong-origin-path', 'wrong-principal-occurrence',
     'nonclosing-leaf', 'extra-entry-field', 'unreachable-nodes-root-not-last',
     'nonfirst-but-complementary-close-pair'),
    ('F_IMP-alias', 'T_NOT', 'F_NOT', 'T_IMP-both-children', 'composite-CLOSE-first'),
    ('atomic-and-unused-false', 'F_NOT-open', 'first-child-closed-second-open'),
    ('physical-trailing-octet:search', 'physical-trailing-octet:compiler',
     'original-mode0-with-nonempty-Gamma:search', 'original-mode0-with-nonempty-Gamma:compiler',
     'function-before-constructor:search', 'function-before-constructor:compiler',
     'predicate-before-constructor:search', 'predicate-before-constructor:compiler',
     'equality-at-goal:search', 'equality-at-goal:compiler',
     'table-before-Gamma-and-goal:search', 'table-before-Gamma-and-goal:compiler',
     'original-AST-right-slot:search', 'original-AST-right-slot:compiler'),
    ('trace_limit-bool', 'configuration-extra-key', 'changed-principal-order',
     'producer-extra-module', 'compiler-extra-module'),
    ('compiler-before-caller-mutation', 'compiler-fresh-second-call', 'search-before-caller-mutation'),
    ('producer-retained-refusal', 'producer-first-StopIteration', 'producer-first-same-class',
     'producer-first-retained-owned', 'producer-first-MemoryError',
     'compiler-retained-refusal', 'compiler-first-StopIteration', 'compiler-first-same-class',
     'compiler-first-retained-owned', 'compiler-first-MemoryError'),
)
_OWNER = object()


class SignedControlError(ValueError):
    pass


class _Call:
    def __init__(self, check, compiler_diagnostics=None):
        self.check = check
        self.compiler_diagnostics = compiler_diagnostics
        self.control_index = None
        self.fixture_index = 0
        self.invocation_index = 0
        self.first = None
        self.token = object()
        self.callbacks = 0

    def begin_control(self, index):
        self.control_index = index
        self.fixture_index = 0

    def bind_compiler_sink(self):
        self.need(type(self.control_index) is int and 0 <= self.control_index < len(CALL_LOCATORS),
                  'direct invocation has a current declared control')
        self.need(self.fixture_index < len(CALL_LOCATORS[self.control_index]),
                  'direct invocation belongs to frozen locator enumeration')
        fixture = self.fixture_index
        invocation = self.invocation_index
        self.fixture_index += 1
        self.invocation_index += 1
        sink = self.compiler_diagnostics
        if sink is not None:
            # Exact typed shape was validated after the bank first callback.
            # Bounded caller publication: invalidate BEFORE changing locators.
            sink['snapshot_available'] = False
            sink['active_control_index'] = self.control_index
            sink['active_fixture_index'] = fixture
            sink['compiler_invocation_index'] = invocation
        return sink

    def tick(self):
        if self.first is not None:
            raise self.first
        if not callable(self.check):
            self.fail('check callback required')
        try:
            self.check()
            self.callbacks += 1
        except BaseException as error:
            if self.first is None:
                self.first = error
            raise self.first

    def fail(self, message):
        if self.first is not None:
            raise self.first
        error = SignedControlError(message)
        error._owner = _OWNER
        error._call = self.token
        raise error

    def need(self, condition, message):
        if not condition:
            self.fail(message)


def _validate_compiler_sink(sink, call):
    if sink is None:
        return
    call.need(type(sink) is dict and len(sink) == 20, 'optional exact20 compiler sink')
    for key in sink:
        call.tick()
        call.need(type(key) is str, 'exact-str compiler sink key')
    call.need(set(sink) == set(COMPILER_DIAGNOSTICS), 'compiler sink exact keys')
    call.need(type(sink['schema']) is str
              and sink['schema'] == 'FPC-H1-signed-compiler-diagnostics-v1', 'compiler sink schema')
    for key in ('snapshot_available', 'phase_in_progress'):
        call.need(type(sink[key]) is bool, 'compiler sink exact bool')
    for key in ('compiler_invocation_index', 'observed_through_callback',
                'export_rows_committed', 'expanded_headers_committed', 'wire_bytes_committed'):
        call.need(type(sink[key]) is int and sink[key] >= 0, 'compiler sink exact nonnegative int')
    for key in ('active_control_index', 'active_fixture_index', 'phase_enter_monotonic_ns',
                'construction_completed_ns', 'export_reachability_completed_ns',
                'export_encoding_completed_ns', 'formula_dag_nodes', 'ir_rows_created',
                'emitter_instances', 'reachable_rows'):
        value = sink[key]
        call.need(value is None or (type(value) is int and value >= 0), 'compiler sink optional int')
    for key, values in (('phase', ('INTAKE', 'CONSTRUCT', 'EXPORT_REACHABLE', 'EXPORT_ENCODE',
                                  'FINALIZE', 'FINAL')),
                        ('active_encode_role', ('CONCLUSION', 'LOGICAL_WITNESS', 'OTHER_WIRE'))):
        value = sink[key]
        call.need(value is None or (type(value) is str and value in values), 'compiler sink enum')


def _copy(value, call):
    call.tick()
    if type(value) in (str, int, bool, type(None)):
        return value
    if type(value) is float:
        call.need(value == value and value not in (float('inf'), -float('inf')),
                  'finite receipt evidence scalar')
        return value
    if type(value) in (list, tuple):
        out = []
        for item in value:
            call.tick()
            out.append(_copy(item, call))
        return out
    if type(value) is dict:
        out = {}
        for key, item in value.items():
            call.tick()
            call.need(type(key) is str, 'ordinary receipt key')
            out[key] = _copy(item, call)
        return out
    call.fail('ordinary discrete fixture or finite-float evidence carrier')


def _same(left, right, call):
    stack = [(left, right)]
    while stack:
        call.tick()
        a, b = stack.pop()
        if type(a) is not type(b):
            return False
        if type(a) is dict:
            if set(a) != set(b):
                return False
            for key in a:
                call.tick()
                stack.append((a[key], b[key]))
        elif type(a) in (list, tuple):
            if len(a) != len(b):
                return False
            for index in range(len(a)):
                call.tick()
                stack.append((a[index], b[index]))
        elif type(a) in (str, int, bool, type(None)):
            if a != b:
                return False
        else:
            call.fail('non-discrete formal comparison')
    return True


def _ids(value, call):
    seen = set()
    stack = [value]
    while stack:
        call.tick()
        item = stack.pop()
        if type(item) not in (list, tuple, dict) or id(item) in seen:
            continue
        seen.add(id(item))
        if type(item) is dict:
            for child in item.values():
                call.tick()
                stack.append(child)
        else:
            for child in item:
                call.tick()
                stack.append(child)
    return seen


def _configuration():
    return {'schema': 'FPC-H1-signed-propositional-configuration-v1',
            'principal_order': 'FIRST_DECOMPOSABLE_OCCURRENCE',
            'split_order': 'NEGATIVE_ANTECEDENT_FIRST',
            'memoization': 'NONE', 'trace_limit': 0}


def _sink():
    out = {'schema': 'FPC-H1-signed-propositional-diagnostics-v1',
           'snapshot_available': True, 'phase': 'FINAL', 'phase_in_progress': False,
           'observed_through_atomic_step': 17}
    for name in COUNTERS:
        out[name] = 17
    return out


def _query(goal, gamma=None, axioms=None, functions=None, predicates=None, mode=None):
    hypotheses = [] if gamma is None else gamma
    return {'version': 1, 'claim_mode': (1 if hypotheses else 0) if mode is None else mode,
            'function_arities': [] if functions is None else functions,
            'predicate_arities': [0, 0, 0] if predicates is None else predicates,
            'theory_profile': 0, 'finite_axioms': [] if axioms is None else axioms,
            'Gamma': hypotheses, 'goal': goal}


def _cases(call):
    call.tick()
    a, b, c = ['pred', 0, []], ['pred', 1, []], ['pred', 2, []]
    close = {'rule': 'CLOSE', 'children': []}
    return [
        {'id': 'F_IMP-alias', 'query': _query(['imp', a, a]),
         'shape': {'rule': 'F_IMP', 'children': [close]}, 'counts': [2, 1, 0]},
        {'id': 'T_NOT', 'query': _query(b, gamma=[['not', a], a]),
         'shape': {'rule': 'T_NOT', 'children': [close]}, 'counts': [2, 1, 0]},
        {'id': 'F_NOT', 'query': _query(['not', ['not', a]], gamma=[a]),
         'shape': {'rule': 'F_NOT', 'children': [
             {'rule': 'T_NOT', 'children': [close]}]}, 'counts': [3, 1, 0]},
        {'id': 'T_IMP-both-children', 'query': _query(b, gamma=[['imp', a, b], a]),
         'shape': {'rule': 'T_IMP', 'children': [close, close]}, 'counts': [3, 2, 1]},
        {'id': 'composite-CLOSE-first', 'query': _query(['imp', a, b], gamma=[['imp', a, b]]),
         'shape': close, 'counts': [1, 1, 0]},
        {'id': 'original-table-source', 'query': _query(a, axioms=[a]),
         'shape': close, 'counts': [1, 1, 0]},
        {'id': 'duplicate-Gamma-table-occurrences', 'query': _query(a, gamma=[a, a], axioms=[a]),
         'shape': close, 'counts': [1, 1, 0]},
        {'id': 'split-retains-unused-duplicate-Gamma',
         'query': _query(b, gamma=[['imp', a, b], a, a]),
         'shape': {'rule': 'T_IMP', 'children': [close, close]}, 'counts': [3, 2, 1]},
    ]


def _identity(query, raw, call):
    call.tick()
    out = {'query_hex': raw.hex(), 'bytes': len(raw),
           'sha256': hashlib.sha256(raw).hexdigest()}
    for key in SEMANTIC_KEYS:
        call.tick()
        out[key] = _copy(query[key], call)
    return out


def _encode(query, encoder, modules, call):
    before = _copy(query, call)
    wrapped = encoder.encode_tiny_declared_query(query, check=call.tick)
    call.need(type(wrapped) is dict and set(wrapped) == {'query_bytes', 'receipt'}, 'encoder wrapper')
    raw = wrapped['query_bytes']
    call.need(type(raw) is bytes, 'immutable encoded query')
    call.need(_same(wrapped['receipt']['semantic_query'], before, call), 'encoder semantic association')
    identity = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    call.need(_same(wrapped['receipt']['query_identity'], identity, call), 'encoder byte identity')
    parsed = modules['checker'].decode_query(raw, check=call.tick)
    for key in SEMANTIC_KEYS:
        call.tick()
        call.need(_same(parsed[key], before[key], call), 'same-byte original decode semantics')
    call.need(type(parsed['EOF']) is int and parsed['EOF'] == len(raw),
              'original full query EOF byte offset')
    call.need(_same(query, before, call), 'query fixture unchanged by encode/decode')
    return raw


def _entry(sign, source, index, path, formula, call):
    return {'sign': sign, 'origin': {'source': source, 'index': index, 'path': list(path)},
            'formula': _copy(formula, call)}


def _initial(query, call):
    entries = []
    for index, formula in enumerate(query['Gamma']):
        call.tick()
        entries.append(_entry('T', 'GAMMA', index, [], formula, call))
    for index, formula in enumerate(query['finite_axioms']):
        call.tick()
        entries.append(_entry('T', 'AXIOM', index, [], formula, call))
    entries.append(_entry('F', 'GOAL', 0, [], query['goal'], call))
    return entries


def _close_pair(entries, call):
    for left in range(len(entries)):
        for right in range(left + 1, len(entries)):
            call.tick()
            if entries[left]['sign'] != entries[right]['sign'] and _same(
                    entries[left]['formula'], entries[right]['formula'], call):
                return [left, right]
    return None


def _rule_children(entries, call):
    for principal, item in enumerate(entries):
        call.tick()
        formula = item['formula']
        if formula[0] == 'pred':
            continue
        origin = item['origin']

        def descendant(sign, child):
            return _entry(sign, origin['source'], origin['index'],
                          origin['path'] + [child], formula[child + 1], call)

        if formula[0] == 'not':
            sign = 'F' if item['sign'] == 'T' else 'T'
            additions = [[descendant(sign, 0)]]
            rule = item['sign'] + '_NOT'
        else:
            call.need(formula[0] == 'imp', 'qualification transition fragment')
            rule = item['sign'] + '_IMP'
            if item['sign'] == 'F':
                additions = [[descendant('T', 0), descendant('F', 1)]]
            else:
                additions = [[descendant('F', 0)], [descendant('T', 1)]]
        vectors = []
        for added in additions:
            call.tick()
            vectors.append(_copy(entries[:principal], call) + added
                           + _copy(entries[principal + 1:], call))
        return rule, principal, vectors
    call.fail('literal closed-tree shape reached open atomic leaf')


def _make_tree(query, raw, shape, call):
    nodes = []

    def visit(entries, expected):
        call.tick()
        pair = _close_pair(entries, call)
        premises = []
        principal = None
        if pair is not None:
            rule = 'CLOSE'
            call.need(expected['rule'] == rule and expected['children'] == [], 'literal CLOSE shape')
        else:
            rule, principal, vectors = _rule_children(entries, call)
            call.need(expected['rule'] == rule and len(expected['children']) == len(vectors),
                      'literal transition shape')
            for child_index in range(len(vectors)):
                call.tick()
                premises.append(visit(vectors[child_index], expected['children'][child_index]))
        number = len(nodes)
        nodes.append({'id': number, 'entries': _copy(entries, call), 'rule': rule,
                      'principal': principal, 'premises': premises, 'close_pair': pair})
        return number

    root = visit(_initial(query, call), shape)
    return {'schema': 'FPC-H1-closed-signed-tree-v1', 'query_hex': raw.hex(),
            'nodes': nodes, 'root': root}


def _dual(raw, candidate, query, modules, call):
    call.need(type(candidate) is bytes, 'complete immutable primitive candidate')
    subject = modules['checker'].check_certificate(raw, candidate, check=call.tick)
    reference = modules['reference'].reference_check_certificate(raw, candidate, check=call.tick)
    call.need(subject['status'] == 'VALID_DERIVATION' and subject['complete'] is True
              and subject['accepted'] is True and subject['syntax_complete'] is True
              and subject['derivation_complete'] is True and subject['final_goal_equal'] is True,
              'complete original subject gate')
    call.need(reference['status'] == 'VALID_DERIVATION' and reference['complete_check'] is True,
              'complete independent reference gate')
    certificate = subject['certificate']
    call.need(type(certificate['EOF']) is int and certificate['EOF'] == len(candidate)
              and type(certificate['row_count']) is int
              and certificate['row_count'] == len(certificate['rows'])
              and certificate['row_count'] > 0, 'complete nonempty primitive row census')
    for index, row in enumerate(certificate['rows']):
        call.tick()
        call.need(type(row['index']) is int and row['index'] == index
                  and row['validation']['status'] == 'VALID', 'every primitive row validated')
        call.need(type(row['rule_tag']) is int and 0 <= row['rule_tag'] <= 4,
                  'base primitive row only')
        for reference_index in row['validation']['references']:
            call.tick()
            call.need(type(reference_index) is int and 0 <= reference_index < index,
                      'strictly prior primitive references')
    call.need(_same(certificate['rows'][-1]['formula'], query['goal'], call), 'exact final core goal')
    return {'subject': _copy(subject, call), 'reference': _copy(reference, call),
            'candidate_identity': {'bytes': len(candidate), 'sha256': hashlib.sha256(candidate).hexdigest()},
            'rows': certificate['row_count']}


def _compiler_receipt(wrapped, raw, query, tree, modules, call):
    call.need(type(wrapped) is dict and set(wrapped) == {'candidate_certificate_bytes', 'receipt'},
              'compiler exact wrapper')
    receipt = wrapped['receipt']
    expected_keys = {'schema', 'accepted', 'query', 'primitive_rows', 'emitter_instances',
                     'emitter_version', 'tree_nodes', 'validation'}
    call.need(type(receipt) is dict and set(receipt) == expected_keys
              and receipt['schema'] == 'FPC-H1-signed-compiler-receipt-v2'
              and receipt['accepted'] is False, 'compiler exact v2 receipt')
    call.need(_same(receipt['query'], _identity(query, raw, call), call), 'compiler original query identity')
    for name in ('primitive_rows', 'emitter_instances', 'tree_nodes'):
        call.need(type(receipt[name]) is int and receipt[name] >= 0, 'compiler count scalar')
    call.need(receipt['tree_nodes'] == len(tree['nodes'])
              and receipt['emitter_version'] == EMITTER_VERSION
              and receipt['validation'] == 'NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED', 'compiler count/version scope')
    validated = _dual(raw, wrapped['candidate_certificate_bytes'], query, modules, call)
    call.need(receipt['primitive_rows'] == validated['rows'], 'public primitive count equals whole output')
    return {'receipt': _copy(receipt, call), 'validation': validated}


def _search_receipt(wrapped, raw, query, configuration, sink, expected_status,
                    expected_counts, modules, call):
    call.need(type(wrapped) is dict and set(wrapped) == {'status', 'candidate_certificate_bytes', 'receipt'},
              'search exact wrapper')
    call.need(wrapped['status'] == expected_status, 'literal search outcome')
    receipt = wrapped['receipt']
    call.need(type(receipt) is dict and set(receipt) ==
              {'schema', 'version', 'status', 'accepted', 'query', 'configuration',
               'scope', 'analytic', 'reconstruction', 'candidate_validation'}, 'search receipt keys')
    call.need(receipt['schema'] == 'FPC-H1-signed-propositional-receipt-v1'
              and type(receipt['version']) is int and receipt['version'] == 1
              and receipt['status'] == expected_status and receipt['accepted'] is False
              and receipt['candidate_validation'] == 'NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED',
              'search receipt fixed fields')
    call.need(_same(receipt['query'], _identity(query, raw, call), call)
              and _same(receipt['configuration'], configuration, call), 'full query/config association')
    analytic = receipt['analytic']
    reconstruction = receipt['reconstruction']
    call.need(type(analytic) is dict and set(analytic) == {'closed', 'open_leaf', 'counters'},
              'analytic keys')
    call.need(type(reconstruction) is dict and set(reconstruction) ==
              {'complete', 'reason', 'primitive_rows', 'emitter_version'}, 'reconstruction keys')
    counters = analytic['counters']
    call.need(type(counters) is dict and set(counters) == set(COUNTERS), 'counter keys')
    for name in COUNTERS:
        call.tick()
        call.need(type(counters[name]) is int and counters[name] >= 0, 'exact nonnegative counters')
        call.need(type(sink[name]) is int and counters[name] == sink[name], 'receipt equals postcleanup FINAL')
    for name in ('active_stack_depth', 'active_entry_count', 'pending_child_count', 'retained_closed_rule_nodes'):
        call.need(counters[name] == 0, 'postcleanup active count zero')
    call.need(type(sink) is dict and set(sink) == set(DIAGNOSTICS)
              and sink['schema'] == 'FPC-H1-signed-propositional-diagnostics-v1'
              and sink['snapshot_available'] is True and sink['phase'] == 'FINAL'
              and sink['phase_in_progress'] is False
              and type(sink['observed_through_atomic_step']) is int
              and sink['observed_through_atomic_step'] == counters['completed_atomic_steps'],
              'complete FINAL checkpoint')
    if expected_counts is not None:
        call.need([counters['states_started'], counters['closed_branches'], counters['split_nodes']]
                  == expected_counts, 'independent analytic activation/closure/split counts')
    if expected_status == 'CANDIDATE_FOUND':
        call.need(analytic['closed'] is True and analytic['open_leaf'] is None
                  and reconstruction['complete'] is True and reconstruction['reason'] is None
                  and reconstruction['emitter_version'] == EMITTER_VERSION, 'closed reconstruction carrier')
        call.need(_same(receipt['scope'], {'supported': True, 'reason': None, 'path': []}, call),
                  'supported scope carrier')
        validation = _dual(raw, wrapped['candidate_certificate_bytes'], query, modules, call)
        call.need(type(reconstruction['primitive_rows']) is int
                  and reconstruction['primitive_rows'] == validation['rows']
                  and counters['primitive_rows_emitted'] == validation['rows'], 'canonical row count join')
        return {'receipt': _copy(receipt, call), 'diagnostics': _copy(sink, call), 'validation': validation}
    call.need(wrapped['candidate_certificate_bytes'] is None and reconstruction['complete'] is False
              and reconstruction['primitive_rows'] is None and reconstruction['emitter_version'] is None,
              'no noncandidate proof bytes/counts')
    if expected_status == 'COUNTERMODEL_FOUND':
        call.need(analytic['closed'] is False and reconstruction['reason'] == 'OPEN_ANALYTIC_LEAF',
                  'open analytic status')
        leaf = analytic['open_leaf']
        call.need(type(leaf) is dict and set(leaf) == {'predicate_values', 'saturated', 'source_query_hex'}
                  and leaf['saturated'] is True and leaf['source_query_hex'] == raw.hex(), 'total open leaf carrier')
        values = leaf['predicate_values']
        call.need(type(values) is list and len(values) == len(query['predicate_arities']), 'total declared valuation')
        for value in values:
            call.tick()
            call.need(type(value) is bool, 'strict Boolean countermodel')
        for formula in query['finite_axioms'] + query['Gamma']:
            call.tick()
            call.need(_evaluate(formula, values, call) is True, 'countermodel full source truth')
        call.need(_evaluate(query['goal'], values, call) is False, 'countermodel exact original goal false')
        call.need(_same(receipt['scope'], {'supported': True, 'reason': None, 'path': []}, call),
                  'supported countermodel scope')
    else:
        call.need(expected_status == 'UNSUPPORTED_PROPOSITIONAL_SCOPE' and analytic['closed'] is None
                  and analytic['open_leaf'] is None and reconstruction['reason'] == 'UNSUPPORTED_SCOPE',
                  'unsupported nonproof carrier')
        for name in COUNTERS[1:]:
            call.need(counters[name] == 0, 'unsupported no analytic/compiler activity')
    return {'receipt': _copy(receipt, call), 'diagnostics': _copy(sink, call)}


def _evaluate(formula, values, call):
    call.tick()
    if formula[0] == 'pred':
        return values[formula[1]]
    if formula[0] == 'not':
        return not _evaluate(formula[1], values, call)
    call.need(formula[0] == 'imp', 'countermodel fragment')
    left = _evaluate(formula[1], values, call)
    right = _evaluate(formula[2], values, call)
    return (not left) or right


def _owned(component, invoke, code, call):
    caught = None
    try:
        invoke()
    except BaseException as error:
        if call.first is not None:
            raise call.first
        caught = error
    call.need(caught is not None and isinstance(caught, component.PropositionalInputError)
              and component.is_owned_error(caught) is True, 'normal per-call owned refusal')
    detail = getattr(caught, 'detail', None)
    call.need(type(detail) is dict and set(detail) == {'code', 'path', 'message'}
              and detail['code'] == code and type(detail['path']) is list
              and type(detail['message']) is str, 'exact refusal detail')
    for part in detail['path']:
        call.tick()
        call.need(type(part) is str or (type(part) is int and part >= 0), 'strict refusal path part')
    return caught


def _compiler_group(compiler, encoder, modules, call):
    evidence = []
    saved = []
    for case in _cases(call):
        call.tick()
        query = _copy(case['query'], call)
        raw = _encode(query, encoder, modules, call)
        tree = _make_tree(query, raw, case['shape'], call)
        before = _copy(tree, call)
        wrapped = compiler.compile_closed_signed_tree(raw, tree, modules={
            'checker': modules['checker'], 'builders': modules['builders']}, check=call.tick, diagnostics=call.bind_compiler_sink())
        checked = _compiler_receipt(wrapped, raw, query, tree, modules, call)
        call.need(_same(tree, before, call), 'compiler caller tree unchanged')
        call.need(not (_ids(tree, call) & _ids(wrapped['receipt'], call)), 'no caller tree containers in receipt')
        evidence.append({'fixture': case['id'], 'tree': before, 'compiler': checked})
        saved.append((case, query, raw, before))
    return saved, evidence


def _invalid_tree_group(compiler, saved, modules, call):
    split = _copy(saved[3][3], call)
    query, raw = saved[3][1], saved[3][2]
    examples = []

    def add(name, tree):
        examples.append((name, tree))

    tree = _copy(split, call); tree['extra'] = 0; add('extra-top-field', tree)
    tree = _copy(split, call); tree['query_hex'] = raw.hex() + '00'; add('wrong-complete-query-hex', tree)
    tree = _copy(split, call); tree['nodes'][0]['id'] = False; add('bool-node-id', tree)
    tree = _copy(split, call); tree['nodes'][-1]['premises'] = [0]; add('missing-split-child', tree)
    tree = _copy(split, call); tree['nodes'][-1]['premises'] = [0, 0]; add('shared-child-context', tree)
    tree = _copy(split, call)
    first, second = tree['nodes'][0], tree['nodes'][1]
    first['id'], second['id'] = 1, 0
    tree['nodes'][0], tree['nodes'][1] = second, first
    tree['nodes'][-1]['premises'] = [1, 0]
    add('semantically-ordered-premises-but-wrong-DFS-postorder', tree)
    tree = _copy(split, call); tree['nodes'][0]['close_pair'] = [1, 0]; add('reversed-close-pair', tree)
    tree = _copy(split, call); tree['nodes'][0]['entries'][0]['origin']['path'] = [1]; add('wrong-origin-path', tree)
    tree = _copy(split, call); tree['nodes'][-1]['principal'] = 1; add('wrong-principal-occurrence', tree)
    tree = _copy(split, call); tree['nodes'][0]['entries'][0]['sign'] = 'T'; add('nonclosing-leaf', tree)
    tree = _copy(split, call); tree['nodes'][0]['entries'][0]['extra'] = 0; add('extra-entry-field', tree)
    tree = _copy(split, call); tree['root'] = 0; add('unreachable-nodes-root-not-last', tree)
    records = []
    for name, tree in examples:
        call.tick()
        error = _owned(compiler, lambda t=tree: compiler.compile_closed_signed_tree(
            raw, t, modules={'checker': modules['checker'], 'builders': modules['builders']},
            check=call.tick, diagnostics=call.bind_compiler_sink()), 'INVALID_TREE', call)
        records.append({'case': name, 'detail': _copy(error.detail, call)})
    duplicate_raw = saved[6][2]
    duplicate_tree = _copy(saved[6][3], call)
    duplicate_tree['nodes'][0]['close_pair'] = [1, 3]
    error = _owned(compiler, lambda: compiler.compile_closed_signed_tree(
        duplicate_raw, duplicate_tree,
        modules={'checker': modules['checker'], 'builders': modules['builders']},
        check=call.tick, diagnostics=call.bind_compiler_sink()), 'INVALID_TREE', call)
    records.append({'case': 'nonfirst-but-complementary-close-pair',
                    'detail': _copy(error.detail, call)})
    return records


def _search_group(producer, compiler, saved, modules, call):
    records = []
    for case, query, raw, tree in saved[:5]:
        call.tick()
        config = _configuration()
        sink = _sink()
        wrapped = producer.search_propositional(raw, configuration=config,
            modules={'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
            diagnostics=sink, check=call.tick, compiler_diagnostics=call.bind_compiler_sink())
        checked = _search_receipt(wrapped, raw, query, config, sink, 'CANDIDATE_FOUND',
                                  case['counts'], modules, call)
        records.append({'fixture': case['id'], 'search': checked})
    return records


def _countermodel_group(producer, compiler, encoder, modules, call):
    a, b, c = ['pred', 0, []], ['pred', 1, []], ['pred', 2, []]
    cases = [
        ('atomic-and-unused-false', _query(a), [False, False, False], [1, 0, 0]),
        ('F_NOT-open', _query(['not', a]), [True, False, False], [2, 0, 0]),
        ('first-child-closed-second-open', _query(c, gamma=[['imp', a, b], a]),
         [True, True, False], [3, 1, 1]),
    ]
    records = []
    for name, query, values, counts in cases:
        call.tick()
        raw = _encode(query, encoder, modules, call)
        config, sink = _configuration(), _sink()
        wrapped = producer.search_propositional(raw, configuration=config,
            modules={'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
            diagnostics=sink, check=call.tick, compiler_diagnostics=call.bind_compiler_sink())
        checked = _search_receipt(wrapped, raw, query, config, sink, 'COUNTERMODEL_FOUND', counts,
                                  modules, call)
        call.need(_same(wrapped['receipt']['analytic']['open_leaf']['predicate_values'], values, call),
                  'literal total countermodel and unused-false policy')
        records.append({'fixture': name, 'expected_values': values, 'search': checked})
    return records


def _syntax_scope_group(producer, compiler, encoder, modules, saved, call):
    query, raw, tree = saved[1][1], saved[1][2], saved[1][3]
    # Original wire: magic4, canonical version1 octet at4, mode1 octet at5.
    call.need(raw[:4] == b'FPC1' and raw[4:6] == b'\x01\x01', 'literal mode-byte position')
    malformed = [('physical-trailing-octet', raw + b'\x00'),
                 ('original-mode0-with-nonempty-Gamma', raw[:5] + b'\x00' + raw[6:])]
    records = []
    for name, bad in malformed:
        call.tick()
        for component, entry in ((producer, 'search'), (compiler, 'compiler')):
            if entry == 'search':
                invoke = lambda value=bad: producer.search_propositional(value, configuration=_configuration(),
                    modules={'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
                    check=call.tick, compiler_diagnostics=call.bind_compiler_sink())
            else:
                invoke = lambda value=bad: compiler.compile_closed_signed_tree(value, _copy(tree, call),
                    modules={'checker': modules['checker'], 'builders': modules['builders']}, check=call.tick, diagnostics=call.bind_compiler_sink())
            error = _owned(component, invoke, 'MALFORMED_QUERY', call)
            records.append({'case': name, 'entry': entry, 'detail': _copy(error.detail, call)})
    a = ['pred', 0, []]
    all_a = ['all', 0, a]
    var = ['var', 0]
    unsupported = [
        ('function-before-constructor', _query(all_a, gamma=[all_a], functions=[0]),
         'NONEMPTY_FUNCTION_SIGNATURE', ['function_arities']),
        ('predicate-before-constructor', _query(['all', 0, ['pred', 0, [var]]],
             gamma=[['all', 0, ['pred', 0, [var]]]], predicates=[1]),
         'NONNULLARY_PREDICATE', ['predicate_arities', 0]),
        ('equality-at-goal', _query(['eq', var, var], gamma=[['eq', var, var]], predicates=[0]),
         'UNSUPPORTED_FORMULA_CONSTRUCTOR', ['Gamma', 0, 0]),
        ('table-before-Gamma-and-goal', _query(all_a, gamma=[all_a], axioms=[all_a]),
         'UNSUPPORTED_FORMULA_CONSTRUCTOR', ['finite_axioms', 0, 0]),
        ('original-AST-right-slot', _query(['imp', a, all_a], gamma=[['imp', a, all_a]]),
         'UNSUPPORTED_FORMULA_CONSTRUCTOR', ['Gamma', 0, 2, 0]),
    ]
    for name, declaration, reason, path in unsupported:
        call.tick()
        current_raw = _encode(declaration, encoder, modules, call)
        config, sink = _configuration(), _sink()
        wrapped = producer.search_propositional(current_raw, configuration=config,
            modules={'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
            diagnostics=sink, check=call.tick, compiler_diagnostics=call.bind_compiler_sink())
        checked = _search_receipt(wrapped, current_raw, declaration, config, sink,
                                  'UNSUPPORTED_PROPOSITIONAL_SCOPE', None, modules, call)
        call.need(_same(wrapped['receipt']['scope'],
                        {'supported': False, 'reason': reason, 'path': path}, call), 'first scope reason/path')
        # Every declaration here has its whole goal in Gamma, so its external
        # CLOSE tree is otherwise coherent.  No error-order tie with bad tree.
        unsupported_tree = _make_tree(declaration, current_raw,
                                      {'rule': 'CLOSE', 'children': []}, call)
        error = _owned(compiler, lambda: compiler.compile_closed_signed_tree(current_raw, unsupported_tree,
            modules={'checker': modules['checker'], 'builders': modules['builders']}, check=call.tick, diagnostics=call.bind_compiler_sink()),
            'UNSUPPORTED_COMPILER_SCOPE', call)
        records.append({'case': name, 'search': checked, 'compiler_detail': _copy(error.detail, call)})
    return records


def _argument_group(producer, compiler, saved, modules, call):
    raw, tree = saved[0][2], saved[0][3]
    records = []
    configs = [_configuration(), _configuration(), _configuration()]
    configs[0]['trace_limit'] = False
    configs[1]['extra'] = 0
    configs[2]['principal_order'] = 'CHANGED'
    for config in configs:
        call.tick()
        error = _owned(producer, lambda value=config: producer.search_propositional(raw,
            configuration=value, modules={'checker': modules['checker'], 'builders': modules['builders'],
                                         'compiler': compiler}, check=call.tick, compiler_diagnostics=call.bind_compiler_sink()), 'INVALID_CALL', call)
        records.append(_copy(error.detail, call))
    _owned(producer, lambda: producer.search_propositional(raw, configuration=_configuration(),
        modules={'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler,
                 'extra': compiler}, check=call.tick, compiler_diagnostics=call.bind_compiler_sink()), 'INVALID_CALL', call)
    _owned(compiler, lambda: compiler.compile_closed_signed_tree(raw, tree,
        modules={'checker': modules['checker'], 'builders': modules['builders'], 'extra': compiler},
        check=call.tick, diagnostics=call.bind_compiler_sink()), 'INVALID_CALL', call)
    for component in (producer, compiler):
        call.tick()
        error = component.PropositionalInputError('public message is not owned')
        call.need(component.is_owned_error(error) is False, 'public constructor unowned')
    return {'configuration_refusals': records, 'extra_module_refusals': 2,
            'public_constructors_unowned': 2}


def _isolation_group(producer, compiler, saved, modules, call):
    case, query, raw, original = saved[3]
    first_tree = _copy(original, call)
    before = _copy(first_tree, call)
    first = compiler.compile_closed_signed_tree(raw, first_tree,
        modules={'checker': modules['checker'], 'builders': modules['builders']}, check=call.tick, diagnostics=call.bind_compiler_sink())
    first_checked = _compiler_receipt(first, raw, query, before, modules, call)
    saved_receipt = _copy(first['receipt'], call)
    first_tree['nodes'].clear()
    call.need(_same(first['receipt'], saved_receipt, call), 'postcall caller-tree mutation affected receipt')
    second = compiler.compile_closed_signed_tree(raw, _copy(original, call),
        modules={'checker': modules['checker'], 'builders': modules['builders']}, check=call.tick, diagnostics=call.bind_compiler_sink())
    second_checked = _compiler_receipt(second, raw, query, original, modules, call)
    call.need(not (_ids(first['receipt'], call) & _ids(second['receipt'], call)), 'cross-call compiler containers')
    config, sink = _configuration(), _sink()
    pristine = _copy(config, call)
    result = producer.search_propositional(raw, configuration=config,
        modules={'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
        diagnostics=sink, check=call.tick, compiler_diagnostics=call.bind_compiler_sink())
    search_checked = _search_receipt(result, raw, query, pristine, sink, 'CANDIDATE_FOUND',
                                     case['counts'], modules, call)
    call.need(_same(config, pristine, call), 'caller configuration mutated')
    call.need(not (_ids(config, call) & _ids(result['receipt']['configuration'], call)),
              'caller configuration returned')
    config['memoization'] = 'postcall caller mutation'
    call.need(_same(result['receipt']['configuration'], pristine, call), 'immutable configuration snapshot')
    return {'first_compiler': first_checked, 'second_compiler': second_checked,
            'search': search_checked, 'caller_snapshots_isolated': True,
            'nested_emitter_count_independently_recomputed': False,
            'count_scope': 'Exact explicit receipt scalar and normal search FINAL transport; increment correctness needs Source review'}


def _fault_group(producer, compiler, saved, modules, call):
    query, raw, tree = saved[0][1], saved[0][2], saved[0][3]
    records = []
    for component, entry in ((producer, 'search'), (compiler, 'compiler')):
        call.tick()
        if entry == 'search':
            bad = _configuration(); bad['trace_limit'] = False
            retained = _owned(component, lambda: producer.search_propositional(raw, configuration=bad,
                modules={'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
                check=call.tick, compiler_diagnostics=call.bind_compiler_sink()), 'INVALID_CALL', call)
        else:
            retained = _owned(component, lambda: compiler.compile_closed_signed_tree(raw, {},
                modules={'checker': modules['checker'], 'builders': modules['builders']}, check=call.tick, diagnostics=call.bind_compiler_sink()),
                'INVALID_TREE', call)
        arguments, attributes = retained.args, dict(vars(retained))
        errors = [StopIteration('intentional signed callback'),
                  component.PropositionalInputError('unowned same-class callback'),
                  retained, MemoryError('intentional signed callback')]
        for fault_index, sentinel in enumerate(errors):
            call.tick()
            seen, later_calls = [0], [0]
            later = RuntimeError('forbidden later callback F')
            sink = _sink()

            def diagnostic_check():
                if seen[0]:
                    later_calls[0] += 1
                    raise later
                call.tick()
                seen[0] += 1
                raise sentinel

            caught = None
            try:
                if entry == 'search':
                    producer.search_propositional(raw, configuration=_configuration(),
                        modules={'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
                        diagnostics=sink, check=diagnostic_check, compiler_diagnostics=call.bind_compiler_sink())
                else:
                    compiler.compile_closed_signed_tree(raw, _copy(tree, call),
                        modules={'checker': modules['checker'], 'builders': modules['builders']}, check=diagnostic_check, diagnostics=call.bind_compiler_sink())
            except BaseException as error:
                if call.first is not None:
                    raise call.first
                caught = error
            call.need(caught is sentinel and seen[0] == 1 and later_calls[0] == 0,
                      'identical first callback with no later callback')
            if entry == 'search':
                call.need(sink['snapshot_available'] is False, 'stale true invalidated before first callback')
            if sentinel is retained:
                call.need(retained.args == arguments and vars(retained) == attributes,
                          'retained owned refusal data mutated')
            records.append({'entry': entry, 'fault_index': fault_index, 'identical': True,
                            'later_callbacks': 0, 'stale_sink_invalidated': entry == 'search'})
    return {'endpoints': records, 'fault_position': 'FIRST_PUBLIC_CALLBACK_ONLY',
            'retained_state_checked': 'args and shallow vars, not traceback/context',
            'cleanup_observed': False, 'late_all_cutoff_fault_coverage': False}


def run_signed_propositional_controls(producer, compiler, *, modules, encoder, check,
                                      compiler_diagnostics=None):
    call = _Call(check, compiler_diagnostics)
    try:
        call.tick()
        _validate_compiler_sink(compiler_diagnostics, call)
        call.need(type(modules) is dict and set(modules) == {'checker', 'builders', 'reference'},
                  'exact validator/builder roles')
        call.need(getattr(producer, 'VERSION', None) == PRODUCER_VERSION
                  and getattr(compiler, 'VERSION', None) == COMPILER_VERSION, 'frozen subject program versions')
        controls = []

        def add(index, evidence):
            call.tick()
            call.need(call.fixture_index == len(CALL_LOCATORS[index]),
                      'complete frozen direct invocation enumeration')
            controls.append({'population': POPULATION, 'id': CONTROL_IDS[index],
                             'status': 'PASSED', 'evidence': _copy(evidence, call)})

        call.begin_control(0)
        saved, compiler_evidence = _compiler_group(compiler, encoder, modules, call)
        add(0, compiler_evidence)
        call.begin_control(1)
        add(1, _invalid_tree_group(compiler, saved, modules, call))
        call.begin_control(2)
        add(2, _search_group(producer, compiler, saved, modules, call))
        call.begin_control(3)
        add(3, _countermodel_group(producer, compiler, encoder, modules, call))
        call.begin_control(4)
        add(4, _syntax_scope_group(producer, compiler, encoder, modules, saved, call))
        call.begin_control(5)
        add(5, _argument_group(producer, compiler, saved, modules, call))
        call.begin_control(6)
        add(6, _isolation_group(producer, compiler, saved, modules, call))
        call.begin_control(7)
        add(7, _fault_group(producer, compiler, saved, modules, call))
        out = {'schema': RETURN_SCHEMA, 'version': VERSION, 'population': POPULATION,
               'complete': True, 'control_ids': list(CONTROL_IDS), 'controls': controls,
               'counts': {'groups': 8, 'passed': 8, 'failed': 0},
               'scope': 'Generic authored signed/compiler qualification only, not discovered research proofs or admission',
               'limits': ['No direct public emitter hook; obligations exercised indirectly through closed-tree cases',
                          'No independent exact nested emitter invocation count without derivation/Source review',
                          'No unsupported profile1/2 encoding fixture through the restricted profile0 writer',
                          'No exhaustive deep tree/late fault/cleanup or every substitution instance claim',
                          'No runtime fit, GCTS, RL, fixed proof-verifier machine or theorem-discovery claim'],
               'callbacks': 0}
        result = _copy(out, call)
        result['callbacks'] = call.callbacks
        return result
    except BaseException:
        if call.first is not None:
            raise call.first
        raise
