"""Independent additional occurrence and compiler-diagnostic qualification Source.

Authored from frozen literal mathematical expectations and Root ABI-v3 only.
No B successor algorithm/derivation intake, private compiler hooks or execution.
All authored trees are generic control inputs, never research search hints.
"""

import hashlib

VERSION = 'FPC-OCCURRENCE-DIAGNOSTIC-INDEPENDENT-CONTROLS-v1'
RETURN_SCHEMA = 'FPC-occurrence-diagnostic-independent-controls-v1'
POPULATION = 'occurrence_diagnostics9'
COMPILER_VERSION = 'FPC-H1-SIGNED-COMPILER-v2'
PRODUCER_VERSION = 'FPC-H1-SIGNED-PROPOSITIONAL-PRODUCER-v2'
EMITTER_VERSION = 'FPC-H1-SIGNED-PRIMITIVE-EMITTERS-v1'
CONTROL_IDS = (
    'unused-LOCAL-root-and-both-split-branches',
    'equal-LOCAL-used-outer-unused-inner',
    'shared-original-source-boundary',
    'ordered-Gamma-and-finite-table-aliases',
    'LOCAL-equal-to-surviving-root-Gamma',
    'nested-composite-LOCAL-substitution',
    'exact-diagnostic-intake-refusals',
    'normal-FINAL-transport-and-no-compiler-paths',
    'first-callback-retained-and-malformed-sink-identity',
)
SEMANTIC_KEYS = ('version', 'claim_mode', 'function_arities', 'predicate_arities',
                 'theory_profile', 'finite_axioms', 'Gamma', 'goal')
QUERY_KEYS = ('query_hex', 'bytes', 'sha256') + SEMANTIC_KEYS
COUNTERS = ('completed_atomic_steps', 'states_started', 'closed_branches',
            'split_nodes', 'active_stack_depth', 'active_entry_count',
            'pending_child_count', 'retained_closed_rule_nodes',
            'primitive_rows_emitted', 'compiler_emitter_instances')
DIAGNOSTICS = ('schema', 'snapshot_available', 'phase', 'phase_in_progress') + COUNTERS + (
    'observed_through_atomic_step',)
COMPILER_DIAGNOSTICS = (
    'schema', 'snapshot_available', 'phase', 'phase_in_progress',
    'active_control_index', 'active_fixture_index', 'compiler_invocation_index',
    'observed_through_callback', 'phase_enter_monotonic_ns',
    'construction_completed_ns', 'export_reachability_completed_ns',
    'export_encoding_completed_ns', 'formula_dag_nodes', 'ir_rows_created',
    'emitter_instances', 'reachable_rows', 'export_rows_committed',
    'expanded_headers_committed', 'wire_bytes_committed', 'active_encode_role',
)
OPTIONAL_INTS = (
    'active_control_index', 'active_fixture_index', 'phase_enter_monotonic_ns',
    'construction_completed_ns', 'export_reachability_completed_ns',
    'export_encoding_completed_ns', 'formula_dag_nodes', 'ir_rows_created',
    'emitter_instances', 'reachable_rows',
)
REQUIRED_INTS = ('compiler_invocation_index', 'observed_through_callback',
                 'export_rows_committed', 'expanded_headers_committed', 'wire_bytes_committed')
PHASES = ('INTAKE', 'CONSTRUCT', 'EXPORT_REACHABLE', 'EXPORT_ENCODE', 'FINALIZE', 'FINAL')
ROLES = ('CONCLUSION', 'LOGICAL_WITNESS', 'OTHER_WIRE')
MALFORMED_NAMES = (
    'wrong-container', 'missing-key', 'extra-key', 'replacement-key', 'foreign-key',
) + tuple('wrong-type:' + name for name in COMPILER_DIAGNOSTICS) + (
    'wrong-schema-value', 'unknown-phase', 'unknown-encode-role', 'negative-wire-bytes',
)
CALL_LOCATORS = (
    ('unused-LOCAL-root-and-both-split-branches',),
    ('equal-LOCAL-used-outer-unused-inner',),
    ('shared-original-source-boundary',),
    ('Gamma-first-alias:valid', 'Gamma-first-alias:nonfirst',
     'table-first-alias:valid', 'table-first-alias:nonfirst'),
    ('LOCAL-equal-to-surviving-root-Gamma',),
    ('nested-composite-LOCAL-substitution',),
    tuple(name + ':' + entry for name in MALFORMED_NAMES for entry in ('compiler', 'producer')),
    ('direct-close-first', 'direct-close-fresh-labels', 'producer-close',
     'producer-countermodel', 'producer-unsupported'),
    tuple(name for entry in ('compiler', 'producer') for name in (
        (entry + ':retained-owned-refusal',) + tuple(
            entry + ':' + kind + ':' + carrier
            for kind in ('StopIteration', 'same-class', 'retained-owned', 'MemoryError')
            for carrier in ('valid-stale', 'foreign-key', 'bad-marker')))),
)
_OWNER = object()


class OccurrenceControlError(ValueError):
    pass


class _Call:
    def __init__(self, check, sink):
        self.check = check
        self.sink = sink
        self.first = None
        self.token = object()
        self.callbacks = 0
        self.control_index = None
        self.fixture_index = 0
        self.invocation_index = 0

    def tick(self):
        if self.first is not None:
            raise self.first
        if not callable(self.check):
            self.fail('check callback required')
        try:
            self.check()
            self.callbacks += 1
        except BaseException as error:
            if self.first is None:
                self.first = error
            raise self.first

    def fail(self, message):
        if self.first is not None:
            raise self.first
        error = OccurrenceControlError(message)
        error._owner = _OWNER
        error._call = self.token
        raise error

    def need(self, condition, message):
        if not condition:
            self.fail(message)

    def begin_control(self, index):
        self.control_index = index
        self.fixture_index = 0

    def locate(self):
        self.need(type(self.control_index) is int and 0 <= self.control_index < len(CALL_LOCATORS),
                  'declared current control')
        self.need(self.fixture_index < len(CALL_LOCATORS[self.control_index]),
                  'declared direct invocation ordinal')
        labels = (self.control_index, self.fixture_index, self.invocation_index)
        self.fixture_index += 1
        self.invocation_index += 1
        # Always retire the valid optional worker sink, even for a malformed
        # separate probe that is deliberately NOT repaired or forwarded here.
        self.sink['snapshot_available'] = False
        self.sink['active_control_index'] = labels[0]
        self.sink['active_fixture_index'] = labels[1]
        self.sink['compiler_invocation_index'] = labels[2]
        return labels


class _ForeignKey:
    """Authored hostile-key INPUT; never introspects subject internals."""
    def __init__(self):
        self.armed = False
        self.touches = 0

    def __hash__(self):
        if self.armed:
            self.touches += 1
            raise RuntimeError('foreign diagnostic-key hash must not run')
        return hash('snapshot_available')

    def __eq__(self, other):
        if self.armed:
            self.touches += 1
            raise RuntimeError('foreign diagnostic-key equality must not run')
        return self is other


MATH_FIXTURES = ({'group_id': 'unused-LOCAL-root-and-both-split-branches', 'facet': 'unused-LOCAL-root-and-both-split-branches', 'query': {'version': 1, 'claim_mode': 1, 'function_arities': [], 'predicate_arities': [0, 0, 0, 0], 'theory_profile': 0, 'finite_axioms': [], 'Gamma': [['imp', ['pred', 0, []], ['pred', 1, []]], ['not', ['not', ['pred', 2, []]]], ['not', ['pred', 2, []]]], 'goal': ['pred', 3, []]}, 'shape': {'rule': 'T_IMP', 'children': [{'rule': 'T_NOT', 'children': [{'rule': 'CLOSE'}]}, {'rule': 'T_NOT', 'children': [{'rule': 'CLOSE'}]}]}, 'nodes': 5, 'close_pair': None, 'factual_source': None}, {'group_id': 'equal-LOCAL-used-outer-unused-inner', 'facet': 'equal-LOCAL-used-outer-unused-inner', 'query': {'version': 1, 'claim_mode': 1, 'function_arities': [], 'predicate_arities': [0, 0, 0, 0], 'theory_profile': 0, 'finite_axioms': [], 'Gamma': [['imp', ['pred', 0, []], ['pred', 1, []]], ['imp', ['pred', 0, []], ['pred', 0, []]], ['not', ['not', ['pred', 0, []]]]], 'goal': ['pred', 1, []]}, 'shape': {'rule': 'T_IMP', 'children': [{'rule': 'T_IMP', 'children': [{'rule': 'T_NOT', 'children': [{'rule': 'F_NOT', 'children': [{'rule': 'CLOSE'}]}]}, {'rule': 'CLOSE'}]}, {'rule': 'CLOSE'}]}, 'nodes': 7, 'close_pair': None, 'factual_source': None}, {'group_id': 'shared-original-source-boundary', 'facet': 'shared-original-source-boundary', 'query': {'version': 1, 'claim_mode': 1, 'function_arities': [], 'predicate_arities': [0, 0, 0, 0], 'theory_profile': 0, 'finite_axioms': [], 'Gamma': [['imp', ['pred', 0, []], ['pred', 1, []]], ['imp', ['pred', 0, []], ['imp', ['pred', 1, []], ['pred', 2, []]]], ['pred', 0, []]], 'goal': ['pred', 2, []]}, 'shape': {'rule': 'T_IMP', 'children': [{'rule': 'CLOSE'}, {'rule': 'T_IMP', 'children': [{'rule': 'CLOSE'}, {'rule': 'T_IMP', 'children': [{'rule': 'CLOSE'}, {'rule': 'CLOSE'}]}]}]}, 'nodes': 7, 'close_pair': None, 'factual_source': None}, {'group_id': 'ordered-Gamma-and-finite-table-aliases', 'facet': 'Gamma-first-alias', 'query': {'version': 1, 'claim_mode': 1, 'function_arities': [], 'predicate_arities': [0, 0, 0, 0], 'theory_profile': 0, 'finite_axioms': [['pred', 0, []], ['pred', 0, []]], 'Gamma': [['pred', 0, []], ['pred', 0, []]], 'goal': ['pred', 0, []]}, 'shape': {'rule': 'CLOSE'}, 'nodes': 1, 'close_pair': [0, 4], 'factual_source': {'rule': 'HYP', 'index': 0}}, {'group_id': 'ordered-Gamma-and-finite-table-aliases', 'facet': 'table-first-alias', 'query': {'version': 1, 'claim_mode': 1, 'function_arities': [], 'predicate_arities': [0, 0, 0, 0], 'theory_profile': 0, 'finite_axioms': [['pred', 0, []], ['pred', 0, []]], 'Gamma': [['pred', 1, []], ['pred', 1, []]], 'goal': ['pred', 0, []]}, 'shape': {'rule': 'CLOSE'}, 'nodes': 1, 'close_pair': [2, 4], 'factual_source': {'rule': 'THEORY_AXIOM', 'profile': 0, 'index': 0}}, {'group_id': 'LOCAL-equal-to-surviving-root-Gamma', 'facet': 'LOCAL-equal-to-surviving-root-Gamma', 'query': {'version': 1, 'claim_mode': 1, 'function_arities': [], 'predicate_arities': [0, 0, 0, 0], 'theory_profile': 0, 'finite_axioms': [], 'Gamma': [['imp', ['pred', 0, []], ['pred', 1, []]], ['imp', ['pred', 1, []], ['pred', 2, []]], ['pred', 1, []]], 'goal': ['pred', 2, []]}, 'shape': {'rule': 'T_IMP', 'children': [{'rule': 'T_IMP', 'children': [{'rule': 'CLOSE'}, {'rule': 'CLOSE'}]}, {'rule': 'T_IMP', 'children': [{'rule': 'CLOSE'}, {'rule': 'CLOSE'}]}]}, 'nodes': 7, 'close_pair': None, 'factual_source': None}, {'group_id': 'nested-composite-LOCAL-substitution', 'facet': 'nested-composite-LOCAL-substitution', 'query': {'version': 1, 'claim_mode': 1, 'function_arities': [], 'predicate_arities': [0, 0, 0, 0], 'theory_profile': 0, 'finite_axioms': [], 'Gamma': [['imp', ['pred', 0, []], ['imp', ['pred', 1, []], ['pred', 2, []]]], ['pred', 0, []], ['pred', 1, []]], 'goal': ['pred', 2, []]}, 'shape': {'rule': 'T_IMP', 'children': [{'rule': 'CLOSE'}, {'rule': 'T_IMP', 'children': [{'rule': 'CLOSE'}, {'rule': 'CLOSE'}]}]}, 'nodes': 5, 'close_pair': None, 'factual_source': None})


def _copy(value, call):
    call.tick()
    if type(value) in (str, int, bool, type(None)):
        return value
    if type(value) is float:
        call.need(value == value and value not in (float('inf'), -float('inf')),
                  'finite receipt evidence scalar')
        return value
    if type(value) in (list, tuple):
        out = []
        for item in value:
            call.tick()
            out.append(_copy(item, call))
        return out
    if type(value) is dict:
        out = {}
        for key, item in value.items():
            call.tick()
            call.need(type(key) is str, 'ordinary receipt key')
            out[key] = _copy(item, call)
        return out
    call.fail('ordinary discrete fixture or finite-float evidence carrier')


def _same(left, right, call):
    stack = [(left, right)]
    while stack:
        call.tick()
        a, b = stack.pop()
        if type(a) is not type(b):
            return False
        if type(a) is dict:
            if set(a) != set(b):
                return False
            for key in a:
                call.tick()
                stack.append((a[key], b[key]))
        elif type(a) in (list, tuple):
            if len(a) != len(b):
                return False
            for index in range(len(a)):
                call.tick()
                stack.append((a[index], b[index]))
        elif type(a) in (str, int, bool, type(None)):
            if a != b:
                return False
        else:
            call.fail('non-discrete formal comparison')
    return True


def _ids(value, call):
    seen = set()
    stack = [value]
    while stack:
        call.tick()
        item = stack.pop()
        if type(item) not in (list, tuple, dict) or id(item) in seen:
            continue
        seen.add(id(item))
        if type(item) is dict:
            for child in item.values():
                call.tick()
                stack.append(child)
        else:
            for child in item:
                call.tick()
                stack.append(child)
    return seen


def _configuration():
    return {'schema': 'FPC-H1-signed-propositional-configuration-v1',
            'principal_order': 'FIRST_DECOMPOSABLE_OCCURRENCE',
            'split_order': 'NEGATIVE_ANTECEDENT_FIRST',
            'memoization': 'NONE', 'trace_limit': 0}


def _sink():
    out = {'schema': 'FPC-H1-signed-propositional-diagnostics-v1',
           'snapshot_available': True, 'phase': 'FINAL', 'phase_in_progress': False,
           'observed_through_atomic_step': 17}
    for name in COUNTERS:
        out[name] = 17
    return out


def _query(goal, gamma=None, axioms=None, functions=None, predicates=None, mode=None):
    hypotheses = [] if gamma is None else gamma
    return {'version': 1, 'claim_mode': (1 if hypotheses else 0) if mode is None else mode,
            'function_arities': [] if functions is None else functions,
            'predicate_arities': [0, 0, 0] if predicates is None else predicates,
            'theory_profile': 0, 'finite_axioms': [] if axioms is None else axioms,
            'Gamma': hypotheses, 'goal': goal}


def _identity(query, raw, call):
    call.tick()
    out = {'query_hex': raw.hex(), 'bytes': len(raw),
           'sha256': hashlib.sha256(raw).hexdigest()}
    for key in SEMANTIC_KEYS:
        call.tick()
        out[key] = _copy(query[key], call)
    return out


def _encode(query, encoder, modules, call):
    before = _copy(query, call)
    wrapped = encoder.encode_tiny_declared_query(query, check=call.tick)
    call.need(type(wrapped) is dict and set(wrapped) == {'query_bytes', 'receipt'}, 'encoder wrapper')
    raw = wrapped['query_bytes']
    call.need(type(raw) is bytes, 'immutable encoded query')
    call.need(_same(wrapped['receipt']['semantic_query'], before, call), 'encoder semantic association')
    identity = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    call.need(_same(wrapped['receipt']['query_identity'], identity, call), 'encoder byte identity')
    parsed = modules['checker'].decode_query(raw, check=call.tick)
    for key in SEMANTIC_KEYS:
        call.tick()
        call.need(_same(parsed[key], before[key], call), 'same-byte original decode semantics')
    call.need(type(parsed['EOF']) is int and parsed['EOF'] == len(raw),
              'original full query EOF byte offset')
    call.need(_same(query, before, call), 'query fixture unchanged by encode/decode')
    return raw


def _entry(sign, source, index, path, formula, call):
    return {'sign': sign, 'origin': {'source': source, 'index': index, 'path': list(path)},
            'formula': _copy(formula, call)}


def _initial(query, call):
    entries = []
    for index, formula in enumerate(query['Gamma']):
        call.tick()
        entries.append(_entry('T', 'GAMMA', index, [], formula, call))
    for index, formula in enumerate(query['finite_axioms']):
        call.tick()
        entries.append(_entry('T', 'AXIOM', index, [], formula, call))
    entries.append(_entry('F', 'GOAL', 0, [], query['goal'], call))
    return entries


def _close_pair(entries, call):
    for left in range(len(entries)):
        for right in range(left + 1, len(entries)):
            call.tick()
            if entries[left]['sign'] != entries[right]['sign'] and _same(
                    entries[left]['formula'], entries[right]['formula'], call):
                return [left, right]
    return None


def _rule_children(entries, call):
    for principal, item in enumerate(entries):
        call.tick()
        formula = item['formula']
        if formula[0] == 'pred':
            continue
        origin = item['origin']

        def descendant(sign, child):
            return _entry(sign, origin['source'], origin['index'],
                          origin['path'] + [child], formula[child + 1], call)

        if formula[0] == 'not':
            sign = 'F' if item['sign'] == 'T' else 'T'
            additions = [[descendant(sign, 0)]]
            rule = item['sign'] + '_NOT'
        else:
            call.need(formula[0] == 'imp', 'qualification transition fragment')
            rule = item['sign'] + '_IMP'
            if item['sign'] == 'F':
                additions = [[descendant('T', 0), descendant('F', 1)]]
            else:
                additions = [[descendant('F', 0)], [descendant('T', 1)]]
        vectors = []
        for added in additions:
            call.tick()
            vectors.append(_copy(entries[:principal], call) + added
                           + _copy(entries[principal + 1:], call))
        return rule, principal, vectors
    call.fail('literal closed-tree shape reached open atomic leaf')


def _make_tree(query, raw, shape, call):
    nodes = []

    def visit(entries, expected):
        call.tick()
        pair = _close_pair(entries, call)
        premises = []
        principal = None
        if pair is not None:
            rule = 'CLOSE'
            call.need(expected['rule'] == rule and expected.get('children', []) == [], 'literal CLOSE shape')
        else:
            rule, principal, vectors = _rule_children(entries, call)
            call.need(expected['rule'] == rule and len(expected['children']) == len(vectors),
                      'literal transition shape')
            for child_index in range(len(vectors)):
                call.tick()
                premises.append(visit(vectors[child_index], expected['children'][child_index]))
        number = len(nodes)
        nodes.append({'id': number, 'entries': _copy(entries, call), 'rule': rule,
                      'principal': principal, 'premises': premises, 'close_pair': pair})
        return number

    root = visit(_initial(query, call), shape)
    return {'schema': 'FPC-H1-closed-signed-tree-v1', 'query_hex': raw.hex(),
            'nodes': nodes, 'root': root}


def _dual(raw, candidate, query, modules, call):
    call.need(type(candidate) is bytes, 'complete immutable primitive candidate')
    subject = modules['checker'].check_certificate(raw, candidate, check=call.tick)
    reference = modules['reference'].reference_check_certificate(raw, candidate, check=call.tick)
    call.need(subject['status'] == 'VALID_DERIVATION' and subject['complete'] is True
              and subject['accepted'] is True and subject['syntax_complete'] is True
              and subject['derivation_complete'] is True and subject['final_goal_equal'] is True,
              'complete original subject gate')
    call.need(reference['status'] == 'VALID_DERIVATION' and reference['complete_check'] is True,
              'complete independent reference gate')
    certificate = subject['certificate']
    call.need(type(certificate['EOF']) is int and certificate['EOF'] == len(candidate)
              and type(certificate['row_count']) is int
              and certificate['row_count'] == len(certificate['rows'])
              and certificate['row_count'] > 0, 'complete nonempty primitive row census')
    for index, row in enumerate(certificate['rows']):
        call.tick()
        call.need(type(row['index']) is int and row['index'] == index
                  and row['validation']['status'] == 'VALID', 'every primitive row validated')
        call.need(type(row['rule_tag']) is int and 0 <= row['rule_tag'] <= 4,
                  'base primitive row only')
        for reference_index in row['validation']['references']:
            call.tick()
            call.need(type(reference_index) is int and 0 <= reference_index < index,
                      'strictly prior primitive references')
    call.need(_same(certificate['rows'][-1]['formula'], query['goal'], call), 'exact final core goal')
    return {'subject': _copy(subject, call), 'reference': _copy(reference, call),
            'candidate_identity': {'bytes': len(candidate), 'sha256': hashlib.sha256(candidate).hexdigest()},
            'rows': certificate['row_count']}


def _compiler_receipt(wrapped, raw, query, tree, modules, call):
    call.need(type(wrapped) is dict and set(wrapped) == {'candidate_certificate_bytes', 'receipt'},
              'compiler exact wrapper')
    receipt = wrapped['receipt']
    expected_keys = {'schema', 'accepted', 'query', 'primitive_rows', 'emitter_instances',
                     'emitter_version', 'tree_nodes', 'validation'}
    call.need(type(receipt) is dict and set(receipt) == expected_keys
              and receipt['schema'] == 'FPC-H1-signed-compiler-receipt-v2'
              and receipt['accepted'] is False, 'compiler exact v2 receipt')
    call.need(_same(receipt['query'], _identity(query, raw, call), call), 'compiler original query identity')
    for name in ('primitive_rows', 'emitter_instances', 'tree_nodes'):
        call.need(type(receipt[name]) is int and receipt[name] >= 0, 'compiler count scalar')
    call.need(receipt['tree_nodes'] == len(tree['nodes'])
              and receipt['emitter_version'] == EMITTER_VERSION
              and receipt['validation'] == 'NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED', 'compiler count/version scope')
    validated = _dual(raw, wrapped['candidate_certificate_bytes'], query, modules, call)
    call.need(receipt['primitive_rows'] == validated['rows'], 'public primitive count equals whole output')
    return {'receipt': _copy(receipt, call), 'validation': validated}


def _search_receipt(wrapped, raw, query, configuration, sink, expected_status,
                    expected_counts, modules, call):
    call.need(type(wrapped) is dict and set(wrapped) == {'status', 'candidate_certificate_bytes', 'receipt'},
              'search exact wrapper')
    call.need(wrapped['status'] == expected_status, 'literal search outcome')
    receipt = wrapped['receipt']
    call.need(type(receipt) is dict and set(receipt) ==
              {'schema', 'version', 'status', 'accepted', 'query', 'configuration',
               'scope', 'analytic', 'reconstruction', 'candidate_validation'}, 'search receipt keys')
    call.need(receipt['schema'] == 'FPC-H1-signed-propositional-receipt-v1'
              and type(receipt['version']) is int and receipt['version'] == 1
              and receipt['status'] == expected_status and receipt['accepted'] is False
              and receipt['candidate_validation'] == 'NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED',
              'search receipt fixed fields')
    call.need(_same(receipt['query'], _identity(query, raw, call), call)
              and _same(receipt['configuration'], configuration, call), 'full query/config association')
    analytic = receipt['analytic']
    reconstruction = receipt['reconstruction']
    call.need(type(analytic) is dict and set(analytic) == {'closed', 'open_leaf', 'counters'},
              'analytic keys')
    call.need(type(reconstruction) is dict and set(reconstruction) ==
              {'complete', 'reason', 'primitive_rows', 'emitter_version'}, 'reconstruction keys')
    counters = analytic['counters']
    call.need(type(counters) is dict and set(counters) == set(COUNTERS), 'counter keys')
    for name in COUNTERS:
        call.tick()
        call.need(type(counters[name]) is int and counters[name] >= 0, 'exact nonnegative counters')
        call.need(type(sink[name]) is int and counters[name] == sink[name], 'receipt equals postcleanup FINAL')
    for name in ('active_stack_depth', 'active_entry_count', 'pending_child_count', 'retained_closed_rule_nodes'):
        call.need(counters[name] == 0, 'postcleanup active count zero')
    call.need(type(sink) is dict and set(sink) == set(DIAGNOSTICS)
              and sink['schema'] == 'FPC-H1-signed-propositional-diagnostics-v1'
              and sink['snapshot_available'] is True and sink['phase'] == 'FINAL'
              and sink['phase_in_progress'] is False
              and type(sink['observed_through_atomic_step']) is int
              and sink['observed_through_atomic_step'] == counters['completed_atomic_steps'],
              'complete FINAL checkpoint')
    if expected_counts is not None:
        call.need([counters['states_started'], counters['closed_branches'], counters['split_nodes']]
                  == expected_counts, 'independent analytic activation/closure/split counts')
    if expected_status == 'CANDIDATE_FOUND':
        call.need(analytic['closed'] is True and analytic['open_leaf'] is None
                  and reconstruction['complete'] is True and reconstruction['reason'] is None
                  and reconstruction['emitter_version'] == EMITTER_VERSION, 'closed reconstruction carrier')
        call.need(_same(receipt['scope'], {'supported': True, 'reason': None, 'path': []}, call),
                  'supported scope carrier')
        validation = _dual(raw, wrapped['candidate_certificate_bytes'], query, modules, call)
        call.need(type(reconstruction['primitive_rows']) is int
                  and reconstruction['primitive_rows'] == validation['rows']
                  and counters['primitive_rows_emitted'] == validation['rows'], 'canonical row count join')
        return {'receipt': _copy(receipt, call), 'diagnostics': _copy(sink, call), 'validation': validation}
    call.need(wrapped['candidate_certificate_bytes'] is None and reconstruction['complete'] is False
              and reconstruction['primitive_rows'] is None and reconstruction['emitter_version'] is None,
              'no noncandidate proof bytes/counts')
    if expected_status == 'COUNTERMODEL_FOUND':
        call.need(analytic['closed'] is False and reconstruction['reason'] == 'OPEN_ANALYTIC_LEAF',
                  'open analytic status')
        leaf = analytic['open_leaf']
        call.need(type(leaf) is dict and set(leaf) == {'predicate_values', 'saturated', 'source_query_hex'}
                  and leaf['saturated'] is True and leaf['source_query_hex'] == raw.hex(), 'total open leaf carrier')
        values = leaf['predicate_values']
        call.need(type(values) is list and len(values) == len(query['predicate_arities']), 'total declared valuation')
        for value in values:
            call.tick()
            call.need(type(value) is bool, 'strict Boolean countermodel')
        for formula in query['finite_axioms'] + query['Gamma']:
            call.tick()
            call.need(_evaluate(formula, values, call) is True, 'countermodel full source truth')
        call.need(_evaluate(query['goal'], values, call) is False, 'countermodel exact original goal false')
        call.need(_same(receipt['scope'], {'supported': True, 'reason': None, 'path': []}, call),
                  'supported countermodel scope')
    else:
        call.need(expected_status == 'UNSUPPORTED_PROPOSITIONAL_SCOPE' and analytic['closed'] is None
                  and analytic['open_leaf'] is None and reconstruction['reason'] == 'UNSUPPORTED_SCOPE',
                  'unsupported nonproof carrier')
        for name in COUNTERS[1:]:
            call.need(counters[name] == 0, 'unsupported no analytic/compiler activity')
    return {'receipt': _copy(receipt, call), 'diagnostics': _copy(sink, call)}


def _evaluate(formula, values, call):
    call.tick()
    if formula[0] == 'pred':
        return values[formula[1]]
    if formula[0] == 'not':
        return not _evaluate(formula[1], values, call)
    call.need(formula[0] == 'imp', 'countermodel fragment')
    left = _evaluate(formula[1], values, call)
    right = _evaluate(formula[2], values, call)
    return (not left) or right


def _owned(component, invoke, code, call):
    caught = None
    try:
        invoke()
    except BaseException as error:
        if call.first is not None:
            raise call.first
        caught = error
    call.need(caught is not None and isinstance(caught, component.PropositionalInputError)
              and component.is_owned_error(caught) is True, 'normal per-call owned refusal')
    detail = getattr(caught, 'detail', None)
    call.need(type(detail) is dict and set(detail) == {'code', 'path', 'message'}
              and detail['code'] == code and type(detail['path']) is list
              and type(detail['message']) is str, 'exact refusal detail')
    for part in detail['path']:
        call.tick()
        call.need(type(part) is str or (type(part) is int and part >= 0), 'strict refusal path part')
    return caught


def _compiler_sink(stale=False):
    out = {'schema': 'FPC-H1-signed-compiler-diagnostics-v1',
           'snapshot_available': False, 'phase': None, 'phase_in_progress': False,
           'active_control_index': None, 'active_fixture_index': None,
           'compiler_invocation_index': 0, 'observed_through_callback': 0,
           'phase_enter_monotonic_ns': None, 'construction_completed_ns': None,
           'export_reachability_completed_ns': None, 'export_encoding_completed_ns': None,
           'formula_dag_nodes': None, 'ir_rows_created': None, 'emitter_instances': None,
           'reachable_rows': None, 'export_rows_committed': 0,
           'expanded_headers_committed': 0, 'wire_bytes_committed': 0, 'active_encode_role': None}
    if stale:
        out['snapshot_available'] = True
        out['phase'] = 'FINAL'
        # Deliberately inconsistent but correctly typed stale values. Freshness
        # relationships are NOT an intake constraint under the public ABI.
        for key in OPTIONAL_INTS + REQUIRED_INTS:
            out[key] = 17
        out['export_rows_committed'] = 0
    return out


def _typed_sink(sink, call):
    call.need(type(sink) is dict and len(sink) == 20, 'exact20 sink container')
    for key in sink:
        call.tick()
        call.need(type(key) is str, 'exact-str sink keys before lookup')
    call.need(set(sink) == set(COMPILER_DIAGNOSTICS), 'exact20 sink keys')
    call.need(type(sink['schema']) is str
              and sink['schema'] == 'FPC-H1-signed-compiler-diagnostics-v1', 'sink fixed schema')
    for key in ('snapshot_available', 'phase_in_progress'):
        call.need(type(sink[key]) is bool, 'sink exact bool')
    for key in REQUIRED_INTS:
        call.need(type(sink[key]) is int and sink[key] >= 0, 'sink required nonnegative int')
    for key in OPTIONAL_INTS:
        value = sink[key]
        call.need(value is None or (type(value) is int and value >= 0), 'sink optional nonnegative int')
    for key, allowed in (('phase', PHASES), ('active_encode_role', ROLES)):
        value = sink[key]
        call.need(value is None or (type(value) is str and value in allowed), 'sink closed enum')


def _foreign_sink():
    key = _ForeignKey()
    source = _compiler_sink(stale=True)
    del source['phase']
    # Insert the colliding foreign key before the genuine marker. All foreign
    # behavior is disarmed during authored input construction, then armed.
    sink = {key: None}
    for name, value in source.items():
        sink[name] = value
    key.touches = 0
    key.armed = True
    return sink, key


def _direct(entry, producer, compiler, raw, tree, modules, sink, call, check=None):
    labels = call.locate()
    callback = call.tick if check is None else check
    if entry == 'compiler':
        result = compiler.compile_closed_signed_tree(raw, tree, modules={
            'checker': modules['checker'], 'builders': modules['builders']},
            check=callback, diagnostics=sink)
    else:
        call.need(entry == 'producer', 'declared public entry')
        result = producer.search_propositional(raw, configuration=_configuration(), modules={
            'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
            check=callback, diagnostics=_sink(), compiler_diagnostics=sink)
    return result, labels


def _final_sink(sink, labels, receipt, candidate, producer_receipt, call):
    _typed_sink(sink, call)
    call.need(sink['snapshot_available'] is True and sink['phase'] == 'FINAL'
              and sink['phase_in_progress'] is False and sink['active_encode_role'] is None,
              'compiler normal postcleanup FINAL')
    call.need(tuple(sink[key] for key in ('active_control_index', 'active_fixture_index',
                                        'compiler_invocation_index')) == labels,
              'all caller-owned invocation locators preserved')
    for key in OPTIONAL_INTS + REQUIRED_INTS:
        call.need(type(sink[key]) is int and sink[key] >= 0, 'all normal final counters/times exist')
    if producer_receipt:
        rows = receipt['reconstruction']['primitive_rows']
        instances = receipt['analytic']['counters']['compiler_emitter_instances']
    else:
        rows = receipt['primitive_rows']
        instances = receipt['emitter_instances']
    call.need(sink['reachable_rows'] == sink['export_rows_committed'] == rows,
              'normal final reachable/export/receipt row census')
    call.need(sink['emitter_instances'] == instances
              and sink['wire_bytes_committed'] == len(candidate), 'normal count/byte transport')
    call.need(not (_ids(sink, call) & _ids(receipt, call)), 'no caller sink retained in receipt')
    return _copy(sink, call)


def _minimal(encoder, modules, call):
    a = ['pred', 0, []]
    query = _query(a, gamma=[a], predicates=[0, 0, 0, 0], mode=1)
    raw = _encode(query, encoder, modules, call)
    tree = _make_tree(query, raw, {'rule': 'CLOSE', 'children': []}, call)
    return query, raw, tree


def _mathematical_group(index, compiler, producer, encoder, modules, call):
    records = []
    for source in MATH_FIXTURES:
        call.tick()
        if source['group_id'] != CONTROL_IDS[index]:
            continue
        query = _copy(source['query'], call)
        raw = _encode(query, encoder, modules, call)
        tree = _make_tree(query, raw, source['shape'], call)
        call.need(len(tree['nodes']) == source['nodes'], 'manual tiny analytic node count')
        if source['close_pair'] is not None:
            call.need(_same(tree['nodes'][0]['close_pair'], source['close_pair'], call),
                      'manual original occurrence close pair')
        before = _copy(tree, call)
        result, labels = _direct('compiler', producer, compiler, raw, tree,
                                 modules, call.sink, call)
        final = _final_sink(call.sink, labels, result['receipt'],
                           result['candidate_certificate_bytes'], False, call)
        checked = _compiler_receipt(result, raw, query, before, modules, call)
        call.need(_same(tree, before, call), 'external control tree unchanged')
        call.need(not (_ids(tree, call) & _ids(result['receipt'], call)), 'no external tree retained')
        factual = source['factual_source']
        if factual is not None:
            rows = checked['validation']['subject']['certificate']['rows']
            found = []
            for row in rows:
                call.tick()
                if row['rule_tag'] in (0, 2):
                    found.append(row)
                    expected_tag = 0 if factual['rule'] == 'HYP' else 2
                    call.need(row['rule_tag'] == expected_tag and row['witness'] == [factual['index']],
                              'exact selected original factual source index')
                    if expected_tag == 2:
                        call.need(row['subtag'] == 0, 'profile0 finite table witness')
            call.need(bool(found), 'at least one selected original factual row')
        record = {'facet': source['facet'], 'tree': before, 'compiler': checked,
                  'compiler_diagnostics': final, 'locators': list(labels),
                  'internal_sharing_or_optimization_observed': False}
        if source['close_pair'] is not None:
            bad = _copy(before, call)
            # The second duplicate source is complementary but not lexicographic-first.
            bad['nodes'][0]['close_pair'] = [source['close_pair'][0] + 1,
                                            source['close_pair'][1]]
            error = _owned(compiler, lambda: _direct('compiler', producer, compiler,
                raw, bad, modules, call.sink, call), 'INVALID_TREE', call)
            record['nonfirst_pair_refusal'] = _copy(error.detail, call)
        records.append(record)
    call.need(len(records) == (2 if index == 3 else 1), 'all literal mathematical facets complete')
    return {'facets': records,
            'source_only': 'Token dependence, raw/transformed sharing and optimization choice remain Source properties; aggregate counts are not independently predicted.'}


def _bad_sinks():
    cases = []
    cases.append(('wrong-container', [], None, None))
    missing = _compiler_sink(); del missing['phase']
    cases.append(('missing-key', missing, None, None))
    extra = _compiler_sink(); extra['extra'] = 0
    cases.append(('extra-key', extra, None, None))
    replacement = _compiler_sink(stale=True); del replacement['phase']; replacement['replacement'] = None
    cases.append(('replacement-key', replacement, None, None))
    foreign, key = _foreign_sink()
    cases.append(('foreign-key', foreign, None, key))
    for field in COMPILER_DIAGNOSTICS:
        sink = _compiler_sink(stale=True)
        if field == 'schema':
            sink[field] = 0
        elif field in ('snapshot_available', 'phase_in_progress'):
            sink[field] = 1
        else:
            sink[field] = False
        cases.append(('wrong-type:' + field, sink, field, None))
    for name, field, value in (('wrong-schema-value', 'schema', 'WRONG'),
                               ('unknown-phase', 'phase', 'NO_SUCH_PHASE'),
                               ('unknown-encode-role', 'active_encode_role', 'NO_SUCH_ROLE'),
                               ('negative-wire-bytes', 'wire_bytes_committed', -1)):
        sink = _compiler_sink(stale=True); sink[field] = value
        cases.append((name, sink, field, None))
    return cases


def _intake_group(producer, compiler, encoder, modules, call):
    query, raw, tree = _minimal(encoder, modules, call)
    records = []
    cases = _bad_sinks()
    call.need(tuple(case[0] for case in cases) == MALFORMED_NAMES, 'fixed malformed input enumeration')
    for name, sink, field, key in cases:
        for entry, component in (('compiler', compiler), ('producer', producer)):
            call.tick()
            next_labels = [call.control_index, call.fixture_index, call.invocation_index]
            error = _owned(component, lambda: _direct(entry, producer, compiler,
                raw, tree, modules, sink, call), 'INVALID_CALL', call)
            prefix = 'diagnostics' if entry == 'compiler' else 'compiler_diagnostics'
            path = [prefix] if field is None else [prefix, field]
            call.need(_same(error.detail['path'], path, call), 'exact diagnostic refusal path before query decode')
            call.need(call.sink['snapshot_available'] is False,
                      'worker sink unavailable when separate malformed input forwarded')
            if key is not None:
                call.need(key.touches == 0, 'no foreign key hash/equality in public sink intake')
            if field == 'snapshot_available':
                call.need(type(sink[field]) is int and sink[field] == 1,
                          'bad marker not overwritten before validation')
            records.append({'fixture': name, 'entry': entry, 'locators': next_labels,
                            'detail': _copy(error.detail, call), 'foreign_operations': 0 if key else None})
    return {'refusals': records, 'scope': 'One wrong type per20fields, four shape carriers plus foreign-key, two unknown enums, wrong schema and one negative byte counter; no exhaustive hostile Python object model.'}


def _normal_group(producer, compiler, encoder, modules, call):
    query, raw, tree = _minimal(encoder, modules, call)
    records = []
    first_bytes = None
    first_receipt = None
    for repeat in range(2):
        call.tick()
        # Typed stale contradictions must reset, not become relationship errors.
        call.sink['snapshot_available'] = False
        stale = _compiler_sink(stale=True)
        for key in COMPILER_DIAGNOSTICS:
            if key != 'snapshot_available':
                call.sink[key] = stale[key]
        result, labels = _direct('compiler', producer, compiler, raw,
                                 _copy(tree, call), modules, call.sink, call)
        final = _final_sink(call.sink, labels, result['receipt'],
                           result['candidate_certificate_bytes'], False, call)
        checked = _compiler_receipt(result, raw, query, tree, modules, call)
        if repeat == 0:
            first_bytes, first_receipt = result['candidate_certificate_bytes'], result['receipt']
        else:
            call.need(result['candidate_certificate_bytes'] == first_bytes,
                      'diagnostic locator differences do not alter exact primitive bytes')
            call.need(not (_ids(first_receipt, call) & _ids(result['receipt'], call)),
                      'fresh compiler receipt containers across invocations')
        records.append({'entry': 'compiler', 'repeat': repeat, 'locators': list(labels),
                        'compiler': checked, 'compiler_diagnostics': final})
    # Use the genuine producer and compiler, without a forwarding proxy.
    labels = call.locate()
    search_sink = _sink()
    result = producer.search_propositional(raw, configuration=_configuration(), modules={
        'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
        check=call.tick, diagnostics=search_sink, compiler_diagnostics=call.sink)
    final = _final_sink(call.sink, labels, result['receipt'],
                       result['candidate_certificate_bytes'], True, call)
    checked = _search_receipt(result, raw, query, _configuration(), search_sink,
                              'CANDIDATE_FOUND', [1, 1, 0], modules, call)
    records.append({'entry': 'producer', 'locators': list(labels),
                    'search': checked, 'compiler_diagnostics': final})
    a = ['pred', 0, []]
    for name, declaration, expected_status, counts in (
            ('countermodel', _query(a, predicates=[0, 0, 0, 0]), 'COUNTERMODEL_FOUND', [1, 0, 0]),
            ('unsupported', _query(['all', 0, a], gamma=[['all', 0, a]],
                                   predicates=[0, 0, 0, 0], mode=1),
             'UNSUPPORTED_PROPOSITIONAL_SCOPE', None)):
        current_raw = _encode(declaration, encoder, modules, call)
        call.sink['snapshot_available'] = False
        stale = _compiler_sink(stale=True)
        for key in COMPILER_DIAGNOSTICS:
            if key != 'snapshot_available':
                call.sink[key] = stale[key]
        labels = call.locate()
        search_sink = _sink()
        result = producer.search_propositional(current_raw, configuration=_configuration(), modules={
            'checker': modules['checker'], 'builders': modules['builders'], 'compiler': compiler},
            check=call.tick, diagnostics=search_sink, compiler_diagnostics=call.sink)
        checked = _search_receipt(result, current_raw, declaration, _configuration(), search_sink,
                                  expected_status, counts, modules, call)
        call.need(call.sink['snapshot_available'] is False,
                  'no compiler availability on countermodel or unsupported path')
        records.append({'entry': 'producer', 'fixture': name, 'locators': list(labels),
                        'search': checked, 'compiler_diagnostics_available': False})
    return {'calls': records, 'private_count_or_shared-map_hook_used': False,
            'actual_nested_count_independently_computed': False,
            'all_PHASE_callbacks_observed': False, 'successful_cleanup_observed': False}


def _first_fault_group(producer, compiler, encoder, modules, call):
    query, raw, tree = _minimal(encoder, modules, call)
    records = []
    for entry, component in (('compiler', compiler), ('producer', producer)):
        bad = _compiler_sink(); bad['schema'] = 'WRONG'
        retained = _owned(component, lambda: _direct(entry, producer, compiler,
            raw, tree, modules, bad, call), 'INVALID_CALL', call)
        retained_args, retained_attributes = retained.args, dict(vars(retained))
        errors = (('StopIteration', StopIteration('intentional compiler diagnostic callback E')),
                  ('same-class', component.PropositionalInputError('unowned same-class E')),
                  ('retained-owned', retained),
                  ('MemoryError', MemoryError('intentional compiler diagnostic callback E')))
        for kind, sentinel in errors:
            for carrier in ('valid-stale', 'foreign-key', 'bad-marker'):
                key = None
                if carrier == 'valid-stale':
                    call.sink['snapshot_available'] = False
                    stale = _compiler_sink(stale=True)
                    for name in COMPILER_DIAGNOSTICS:
                        if name != 'snapshot_available':
                            call.sink[name] = stale[name]
                    sink = call.sink
                elif carrier == 'foreign-key':
                    sink, key = _foreign_sink()
                else:
                    sink = _compiler_sink(stale=True); sink['snapshot_available'] = 1
                seen, later_calls = [0], [0]
                later = RuntimeError('forbidden later callback F')

                def diagnostic_check():
                    if seen[0]:
                        later_calls[0] += 1
                        raise later
                    call.tick()
                    seen[0] += 1
                    raise sentinel

                caught = None
                labels = [call.control_index, call.fixture_index, call.invocation_index]
                try:
                    _direct(entry, producer, compiler, raw, tree, modules, sink, call,
                            check=diagnostic_check)
                except BaseException as error:
                    if call.first is not None:
                        raise call.first
                    caught = error
                call.need(caught is sentinel and seen[0] == 1 and later_calls[0] == 0,
                          'identical first E without later F or callback')
                call.need(call.sink['snapshot_available'] is False,
                          'worker sink stale availability retired before every probe')
                if carrier == 'valid-stale':
                    call.need(sink['snapshot_available'] is False, 'valid same-sink early invalidation')
                elif carrier == 'bad-marker':
                    call.need(type(sink['snapshot_available']) is int and sink['snapshot_available'] == 1,
                              'ineligible marker untouched when first callback faults')
                else:
                    call.need(key.touches == 0, 'no malformed foreign-key operation before first callback')
                if sentinel is retained:
                    call.need(retained.args == retained_args and vars(retained) == retained_attributes,
                              'retained owned exception args/shallow attributes unchanged')
                records.append({'entry': entry, 'fault': kind, 'carrier': carrier,
                                'locators': labels, 'identical': True, 'later_callbacks': 0,
                                'fault_endpoint': 'FIRST_PUBLIC_CALLBACK',
                                'foreign_key_operations': 0 if key else None})
    return {'probes': records, 'retained_scope': 'args and shallow vars only, not traceback/context',
            'all_cutoff_or_phase_callback_coverage': False, 'cleanup_observed': False,
            'postfault_getter_or_publication_requested': False}


def run_occurrence_diagnostic_controls(producer, compiler, *, modules, encoder, check,
                                      compiler_diagnostics=None):
    sink = _compiler_sink() if compiler_diagnostics is None else compiler_diagnostics
    call = _Call(check, sink)
    try:
        call.tick()
        _typed_sink(sink, call)
        call.need(type(modules) is dict and set(modules) == {'checker', 'builders', 'reference'},
                  'exact original checker/builders/reference roles')
        call.need(getattr(producer, 'VERSION', None) == PRODUCER_VERSION
                  and getattr(compiler, 'VERSION', None) == COMPILER_VERSION,
                  'explicit genuine successor subject versions')
        controls = []
        for index in range(6):
            call.begin_control(index)
            evidence = _mathematical_group(index, compiler, producer, encoder, modules, call)
            call.need(call.fixture_index == len(CALL_LOCATORS[index]), 'complete math call enumeration')
            controls.append({'population': POPULATION, 'id': CONTROL_IDS[index],
                             'status': 'PASSED', 'evidence': _copy(evidence, call)})
        for index, operation in ((6, _intake_group), (7, _normal_group), (8, _first_fault_group)):
            call.begin_control(index)
            evidence = operation(producer, compiler, encoder, modules, call)
            call.need(call.fixture_index == len(CALL_LOCATORS[index]), 'complete diagnostic call enumeration')
            controls.append({'population': POPULATION, 'id': CONTROL_IDS[index],
                             'status': 'PASSED', 'evidence': _copy(evidence, call)})
        out = {'schema': RETURN_SCHEMA, 'version': VERSION, 'population': POPULATION,
               'complete': True, 'control_ids': list(CONTROL_IDS), 'controls': controls,
               'counts': {'groups': 9, 'passed': 9, 'failed': 0},
               'scope': 'Generic authored occurrence/compiler diagnostic qualification only; no discovered research proof or admission',
               'limits': ['No private dependence/clone/sharing/optimization-path hook',
                          'No independently predicted primitive rows/bytes/nested-emitter count',
                          'First public callback and normal FINAL endpoints only; no every-phase/late-cutoff/cleanup witness',
                          'Normal reachable_rows is exact final primitive-row census; cumulative created counters are not live allocation',
                          'Malformed sinks have no telemetry authority; separate valid worker sink retired before each probe',
                          'No fit, speed, theorem, learned-family, fixed universal Wang or GCTS/RL advantage claim'],
               'callbacks': 0}
        result = _copy(out, call)
        result['callbacks'] = call.callbacks
        return result
    except BaseException:
        if call.first is not None:
            raise call.first
        raise
