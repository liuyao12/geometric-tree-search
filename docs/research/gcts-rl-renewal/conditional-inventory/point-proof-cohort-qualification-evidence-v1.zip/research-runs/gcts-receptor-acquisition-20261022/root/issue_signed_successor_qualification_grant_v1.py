"""Exact metadata-only one-use issuance after Root's fresh tools-idle check."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink()
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


prep_path = ROOT / 'signed-successor-qualification-study-preparation-v1.json'
accept_path = ROOT / 'signed-successor-qualification-Root-whole-prospective-acceptance-v1.json'
prep, accept = read(prep_path), read(accept_path)
assert accept['accepted_prospective_metadata'] is True and accept['preparation'] == pin(prep_path)
for key in ('preparation', 'whole_review', 'component_acceptance'):
    verify(accept[key])
assert read(accept['whole_review']['path'])['review_passed'] is True
components = read(accept['component_acceptance']['path'])
assert components['accepted_component_Source'] is True
for ref in components['component_reviews'].values():
    verify(ref)
    assert read(ref['path'])['review_passed'] is True
for key in ('plan', 'closure', 'proposal', 'protocol'):
    verify(prep[key])
plan, closure, proposal, protocol = [read(prep[key]['path']) for key in ('plan', 'closure', 'proposal', 'protocol')]
case_id = 'signed-propositional-successor-whole-qualification-v1-qualify-0'
assert plan['case_id'] == proposal['case_id'] == case_id
assert plan['stage'] == 'qualify' and plan['experiment'] == 'signed-propositional-successor-whole-qualification-v1'
assert all(key not in plan for key in ('donor_index', 'input_slot', 'arm', 'target_id', 'target_index', 'search_configuration'))
assert proposal['authorized'] is False and proposal['review_passed'] is False
assert type(proposal['uses']) is int and proposal['uses'] == 1
assert proposal['plan'] == closure['plan'] == prep['plan']
assert proposal['closure'] == prep['closure']
assert plan['protocol'] == closure['protocol'] == proposal['protocol'] == prep['protocol']
assert protocol['job_recipes'] == [prep['recipe']] == [dict(case_id=case_id, stage='qualify')]
assert closure['files'] == plan['files'] and len(plan['files']) == prep['shared_guards']
assert plan['module_pins'] == protocol['module_pins'] and len(plan['module_pins']) == 36
assert plan['control_populations'] == protocol['control_populations'] and len(plan['control_populations']) == 16
assert sum(item['groups'] for item in plan['control_populations'].values()) == 221
assert plan['limits'] == protocol['limits'] and len(plan['limits']) == 10
assert proposal['component_acceptance'] == accept['component_acceptance']
assert proposal['component_reviews'] == components['component_reviews']
for ref in plan['files']:
    verify(ref)
absent = [Path(plan['actual_dir']), Path(plan['actual_dir'] + '.observer'),
          Path(proposal['prospective_grant_path'])]
assert all(not path.exists() and not path.is_symlink() for path in absent)
now = datetime.now(timezone.utc).isoformat()
case = emit(ROOT / 'signed-successor-qualification-Root-case-prospective-acceptance-v1.json', dict(
    schema='Root-signed-successor-qualification-case-prospective-acceptance-v1', issued_utc=now, accepted=True,
    case_id=case_id, plan=prep['plan'], closure=prep['closure'], proposal=prep['proposal'],
    Root_whole_acceptance=pin(accept_path), whole_review=accept['whole_review'],
    metadata_issuer=pin(Path(__file__)), guards_current=len(plan['files']),
    namespaces=36, scoped_groups=221, absent_paths=[str(p) for p in absent], scientific_imports_calls=0))
barrier = emit(ROOT / 'signed-successor-qualification-all-tools-idle-barrier-v1.json', dict(
    schema='Root-signed-successor-qualification-tools-idle-barrier-v1', issued_utc=now, case_id=case_id,
    acceptance=case,
    observation='Root called collaboration.list_agents immediately before issuance; B/L/C completed/tools idle. Earlier Root command sessions terminal, no server/browser/network or scientific work running. During actual only the owned exec handle is polled.',
    scope='Current task tools, not exclusive operating-system ownership.',
    guards_rehashed=len(plan['files']), fresh_absence_checks=3))
grant = {key: proposal[key] for key in ('uses', 'case_id', 'plan_sha256', 'runner_sha256',
    'observer_sha256', 'plan', 'protocol', 'closure', 'component_acceptance', 'component_reviews')}
grant.update(schema='Root-signed-successor-qualification-once-grant-v1', authorized=True, review_passed=True,
    issued_utc=now, whole_review=accept['whole_review'], case_proposal=prep['proposal'],
    Root_prospective_acceptance=case, all_tools_idle_barrier=barrier,
    scope='One exact infrastructure qualification job. No research theorem, donor proof, consumed replay, prefix/library uptake or automatic admission.')
grant_pin = emit(Path(proposal['prospective_grant_path']), grant)
print(json.dumps(dict(grant=grant_pin, acceptance=case, barrier=barrier,
                      command=proposal['prospective_command'])))
