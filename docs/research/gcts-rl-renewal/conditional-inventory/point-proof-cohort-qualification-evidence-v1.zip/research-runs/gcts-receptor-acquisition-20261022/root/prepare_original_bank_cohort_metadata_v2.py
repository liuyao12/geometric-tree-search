"""Prospective metadata only; research modules are never imported or called."""
from pathlib import Path
import ast
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
EXPERIMENT = 'signed-propositional-original-bank-cohort-qualification-v1'
CASE = EXPERIMENT + '-qualify-0'
PREFIX = 'original-bank-cohort-'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 2
accept_path = Path(sys.argv[1]).resolve()
source_authority_path = ROOT / 'original-bank-cohort-Root-concrete-contract-and-Source-authorship-v2.json'
assert pin(source_authority_path)['sha256'] == 'd108b11dd228ddfbaf107cd6d812c78af4d8e448ac5abfd63559d30709946a1d'
accept = read(accept_path)
assert accept['accepted_component_Source'] is True
for ref in accept['component_reviews'].values():
    verify(ref)
    assert read(ref['path'])['review_passed'] is True
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff'):
    verify(accept[key])
worker = Path(accept['worker']['path'])
api, offer = read(accept['worker_API']['path']), read(accept['worker_offer']['path'])
body = worker.read_bytes()
base_api_path = ROOT.parent / 'implementation-B/lossless-evidence-qualification-worker-API-v3.json'
assert pin(base_api_path)['sha256'] == 'd670a38d78cc25755dd1e4af114a6680172302a2641ea39e76d0ee7cb41f8b9c'
base_api = read(base_api_path)
authority = read(source_authority_path)
contract_ref, requirements_ref = authority['contract'], authority['independent_preintake_requirements']
verify(contract_ref)
verify(requirements_ref)
contract = read(contract_ref['path'])
assert api['runtime_roles'] == base_api['runtime_roles']
assert api['scoped_populations'] == base_api['scoped_populations']
assert api['raw_inputs'] == base_api['raw_inputs']
assert api['cohort_id'] == contract['choice']['cohort_id']
assert api['evidence_profile'] == contract['choice']['evidence_profile']
assert api['output_limits'] == contract['bounds']['new_output_limits']
assert api['descriptor_fields'] == contract['binding']['descriptor_fields']
constants = {}
names = {'EXPERIMENT', 'PROTOCOL_SCHEMA', 'MODULE_ROLES', 'CONTROL_IDS', 'CAPS'}
for node in ast.parse(body).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in names:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
assert set(constants) == names
assert constants['EXPERIMENT'] == EXPERIMENT
assert constants['PROTOCOL_SCHEMA'] == 'Root-FPC-original-bank-cohort-qualification-protocol-v1'
old_path = ROOT / 'plans/signed-propositional-successor-whole-qualification-v1-qualify-0.json'
assert pin(old_path)['sha256'] == 'db348b552b040dafa3370d9db6e86d90c637a4cda09e6b15acbbd83dfcec2ab6'
old = read(old_path)
assert constants['CAPS'] == old['limits'] and len(constants['CAPS']) == 10
modules = {row['role']: row['rawpin'] for row in offer['runtime_roles']}
assert len(modules) == len(offer['runtime_roles']) == len(constants['MODULE_ROLES']) == 38
assert list(modules) == list(constants['MODULE_ROLES'])
assert list(modules)[:36] == list(old['module_pins'])
assert all(modules[role] == ref for role, ref in old['module_pins'].items())
assert set(modules) - set(old['module_pins']) == {'evidence_codec', 'evidence_codec_bank'}
assert modules['evidence_codec'] == accept['evidence_codec']
assert modules['evidence_codec_bank'] == accept['evidence_bank']
for ref in modules.values():
    verify(ref)
    assert ref['sha256'].encode() in body
assert {row['role']: row['rawpin'] for row in api['runtime_roles']} == modules
populations = {row['population']: {key: row[key] for key in
    ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')}
    for row in api['scoped_populations']}
assert len(populations) == len(api['scoped_populations']) == 17
assert list(populations)[:16] == list(old['control_populations'])
assert set(populations) == set(constants['CONTROL_IDS'])
assert all(populations[name] == item for name, item in old['control_populations'].items())
assert set(populations) - set(old['control_populations']) == {'lossless_evidence_codec8_v1'}
assert sum(item['groups'] for item in old['control_populations'].values()) == 221
assert sum(item['groups'] for item in populations.values()) == 229
extra = populations['lossless_evidence_codec8_v1']
assert extra['groups'] == 8 and extra['bank_role'] == 'evidence_codec_bank'
assert extra['subject_role'] == 'evidence_codec'
for name, item in populations.items():
    assert item['control_ids'] == list(constants['CONTROL_IDS'][name])
    assert type(item['groups']) is int and item['groups'] == len(item['control_ids'])
custody = {row['role']: row['rawpin'] for row in offer['custody_runtime']}
assert set(custody) == {'runner', 'observer', 'python'}
assert custody['python'] == old['python'] and custody['runner']['path'] == old['runner_path']
inputs = {}
for row in offer['raw_inputs']:
    key, ref = row['plan_key'], row['rawpin']
    assert key not in inputs and key in old and ref == old[key]
    inputs[key] = ref
    verify(ref)
guards = {}


def guard(ref):
    verify(ref)
    assert '/actual/' not in ref['path'] and not ref['path'].endswith('.bin')
    assert ref['path'] not in guards or guards[ref['path']] == ref
    guards[ref['path']] = ref


for ref in old['files'] + list(modules.values()) + list(custody.values()) + list(inputs.values()) + offer['semantic_guards']:
    guard(ref)
for ref in accept['component_reviews'].values():
    guard(ref)
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff'):
    guard(accept[key])
for path in (accept_path, Path(__file__), source_authority_path,
             ROOT / 'lossless-evidence-qualification-worker-Root-Source-authorship-v1.json',
             ROOT / 'lossless-worker-Root-postfault-and-last-use-clarification-v1.json',
             ROOT / 'lossless-lifecycle-accounting-successor-Root-Source-authorship-v1.json',
             ROOT / 'issue_original_bank_cohort_grant_v1.py',
             ROOT / 'census_original_bank_cohort_case_v1.py'):
    guard(pin(path))
for ref in accept.get('additional_current_guards', []):
    guard(ref)
for ref in (pin(base_api_path), contract_ref, requirements_ref):
    guard(ref)
# Nonrecursive subject/caller Source closure: descriptor and future protocol/plan
# are added to execution guards only after the descriptor has been frozen.
descriptor_value = dict(
    schema=contract['binding']['descriptor_schema'], cohort_id=api['cohort_id'],
    covered_runtime_roles=base_api['runtime_roles'],
    control_populations=base_api['scoped_populations'], raw_inputs=base_api['raw_inputs'],
    qualification_caller_pins=dict(worker=accept['worker'], API=accept['worker_API'],
        offer=accept['worker_offer'], handoff=accept['worker_handoff']),
    qualifier_contract_pins=[contract_ref, pin(source_authority_path), requirements_ref],
    custody_runtime=custody,
    source_closure=[guards[path] for path in sorted(guards)],
    environment=dict(platform='darwin', python_implementation='cpython',
        python_version='3.12.14', flags=['-I', '-S', '-B']),
    limits=constants['CAPS'], output_limits=api['output_limits'],
    policy_rule='BIND_EFFECTIVE_REFERENCE_AFTER_GENUINE_CHECK_AND_REQUIRE_STABLE_NORMAL_EXPORT_GATES')
assert list(descriptor_value) == api['descriptor_fields']
recipe = dict(case_id=CASE, stage='qualify')
actual = STUDY / 'actual' / CASE
grant_path = ROOT / 'grants' / (CASE + '.json')
plan_path = ROOT / 'plans' / (CASE + '.json')
fresh_paths = (actual, Path(str(actual) + '.observer'), grant_path, plan_path,
    ROOT / (PREFIX + 'descriptor-v1.json'), ROOT / (PREFIX + 'whole-protocol-v1.json'),
    ROOT / (PREFIX + 'Source-closure-v1.json'), ROOT / (PREFIX + 'grant-proposal-v1.json'),
    ROOT / (PREFIX + 'study-preparation-v1.json'))
for path in fresh_paths:
    assert not path.exists() and not path.is_symlink()
descriptor = emit(ROOT / (PREFIX + 'descriptor-v1.json'), descriptor_value)
guard(descriptor)
protocol = emit(ROOT / (PREFIX + 'whole-protocol-v1.json'), dict(
    schema=constants['PROTOCOL_SCHEMA'], experiment=EXPERIMENT, limits=constants['CAPS'],
    module_pins=modules, control_populations=populations, job_recipes=[recipe],
    metadata=dict(status='PROSPECTIVE_NO_EXECUTION', component_acceptance=pin(accept_path),
        Source_authority=pin(source_authority_path), cohort_descriptor=descriptor,
        evidence_profile=api['evidence_profile'], output_limits=api['output_limits'],
        population='Original221/16scopes/15wrappers/36roles retained exactly; separate codec8. Whole229/17scopes/16wrappers/38roles, not229 theorem targets.',
        codec_scope='Unchanged codec8 synthetic tests still cover their existing full profile. Production stores16 full originalJSON wrapper returns as exclusive provisional files; no production15-root DAG or combined Canon readback claim.',
        scope='Infrastructure qualification only, no research donor/holdout/proof/library/GCTS/RL result or automatic admission. Independent controls construct only frozen generic qualification inputs.',
        failure='Controlled caught/prewrite fault withholds all7 positive purposes and cohort authority. Earlier full bank files and late result may remain provisional; no deletion/rewrite/replay/prefix rescue. Preserve firstE and owned close/custody boundaries.',
        output_rejection='First same-decision BANK_JSON or FINAL_MANIFEST_JSON size refusal only, exact owned body length and committed-byte counters. No afterfault recompute or estimate.',
        cost='Single child: cold imports, codec8 then original221 calls, exact-type/policy validation, complete per-bank JSON serialization/write/fullbyte readback, shared guards/final manifest and custody charged. Numerical10 CAPS retained, but48MiB is per bank,4MiB entire result and119MiB inner evidence+result; all inner files/logs/header share runner119MiB and observer128MiB. Explicitly changed aggregate output unit, no fit guarantee.',
        success='Child manifest accepted=false is provisional; only full16 files/229 ordered pairs/17 scopes/source-policy-input/resource-custody C+Root admission creates cohort provenance. No theorem, learned inventory, fit or search benefit.',
        execution_authority=False)))
guard(protocol)
files = [guards[path] for path in sorted(guards)]
plan = dict(old, case_id=CASE, stage='qualify', experiment=EXPERIMENT,
            actual_dir=str(actual), worker_path=str(worker), protocol=protocol, files=files,
            cohort_descriptor=descriptor,
            module_pins=modules, control_populations=populations)
for stale in ('donor_index', 'input_slot', 'arm', 'target_index', 'target_id', 'search_configuration'):
    plan.pop(stale, None)
plan.update(inputs)
plan_pin = emit(plan_path, plan)
closure = emit(ROOT / (PREFIX + 'Source-closure-v1.json'), dict(
    schema='Root-original-bank-cohort-qualification-closed-Source-v1', status='PROSPECTIVE_NOT_AUTHORITY',
    plan=plan_pin, protocol=protocol, descriptor=descriptor, files=files, namespace_count=38, scoped_groups=229,
    original_guard_count_retained=len(old['files']), original221_complete_population_objects_retained=True,
    original_scientific_roles=36, original_scopes=16, original_wrappers=15, additional_codec_groups=8,
    scientific_imports_calls=0))
proposal = emit(ROOT / (PREFIX + 'grant-proposal-v1.json'), dict(
    schema='Root-original-bank-cohort-qualification-once-proposal-v1', authorized=False, review_passed=False,
    uses=1, case_id=CASE, plan_sha256=plan_pin['sha256'], runner_sha256=custody['runner']['sha256'],
    observer_sha256=custody['observer']['sha256'], plan=plan_pin, protocol=protocol, closure=closure,
    descriptor=descriptor,
    component_acceptance=pin(accept_path), component_reviews=accept['component_reviews'],
    prospective_grant_path=str(grant_path),
    prospective_command=[custody['python']['path'], '-I', '-S', '-B', custody['observer']['path'],
                         plan_pin['path'], str(grant_path)],
    required_before_grant=['Independent complete whole Source/plan/proposal review',
                           'Root current guards/acceptance/fresh tools-idle and storage observation',
                           'Separate exact one-use true grant'], execution_authority=False))
print(json.dumps(emit(ROOT / (PREFIX + 'study-preparation-v1.json'), dict(
    schema='Root-original-bank-cohort-qualification-preparation-v1', status='PROSPECTIVE_REQUIRES_WHOLE_REVIEW',
    metadata_builder=pin(Path(__file__)), component_acceptance=pin(accept_path), worker=pin(worker),
    protocol=protocol, descriptor=descriptor, recipe=recipe, plan=plan_pin, closure=closure, proposal=proposal,
    shared_guards=len(files), namespaces=38, scoped_populations=17, scoped_groups=229,
    original221_population_objects_preserved=True, additional_codec_groups=8,
    ten_caps_unchanged=True, false_proposal=True, scientific_imports_calls=0, goal_complete=False)), indent=2))
