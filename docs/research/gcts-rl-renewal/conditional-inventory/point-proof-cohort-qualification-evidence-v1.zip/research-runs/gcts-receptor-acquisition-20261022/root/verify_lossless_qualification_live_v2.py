"""Read-only normal-TLS verification of exact published payloads and retained history."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = 'https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/'
parser = argparse.ArgumentParser()
parser.add_argument('--commit', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
assert re.fullmatch('[0-9a-f]{40}', args.commit)
out = Path(args.output)
assert out.parent == ROOT and not out.exists()
out.mkdir()
staging = json.loads((ROOT / 'publication-lossless-qualification-v3/P2-staging.json').read_bytes())
refs = [dict(name=Path(x['path']).name, bytes=x['bytes'], sha256=x['sha256'], kind='CURRENT') for x in staging['files']]
refs.extend(dict(name=n, bytes=z, sha256=h, kind='UNCHANGED_HISTORY') for n,z,h in [
 ('point-proof-codec-source-manifest-v1.json',16011,'d90a7f5974ae3696ff39fd7854d3e1aca5d4eb39f8c34bd0117fe25a67f0de96'),
 ('point-proof-codec-source-evidence-v1.zip',233675,'f5b02331342e637b8be5b058d8dadc1b6e0b7f756c9d7f3dc7df8c2f72d17170'),
 ('point-proof-output-qualification-data-v1.json',1674,'e3d64511c564459d4d51335ed7e4a93cdf29a0b545a2e3a2b38f14a8b99f9fdb'),
 ('point-proof-output-qualification-evidence-v1.zip',1778378,'af5d5839c1b67ae07a3d3cca66c338e995b98e1ed9bc7497cdafcd3a96919d76')])
results=[]
for ref in refs:
    target=out/ref['name']
    url=BASE+ref['name']+'?v='+args.commit
    command=['curl','--fail','--show-error','--silent','--location','--proto','=https','--tlsv1.2',
             '--connect-timeout','15','--max-time','45','--output',str(target),url]
    proc=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    if proc.returncode:
        (out/'curl-failure.json').write_text(json.dumps(dict(url=url,returncode=proc.returncode,stderr=proc.stderr.decode(errors='replace')),indent=2)+'\n')
        raise RuntimeError('Read-only HTTPS verification failed; no insecure fallback')
    body=target.read_bytes();actual=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    assert actual=={k:ref[k] for k in ('bytes','sha256')},ref['name']
    results.append(dict(**ref,url=url,match=True))
    print(ref['name']+': MATCH',flush=True)
record=dict(schema='Root-lossless-qualification-live-TLS-verification-v1',commit=args.commit,
            all_eight_match=True,normal_TLS=True,certificate_bypass=False,files=results,scientific_calls=0)
with (out/'verification.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
