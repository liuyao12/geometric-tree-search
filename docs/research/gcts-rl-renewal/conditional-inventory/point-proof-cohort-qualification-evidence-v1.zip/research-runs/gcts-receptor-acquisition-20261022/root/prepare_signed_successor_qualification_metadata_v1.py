"""Prospective metadata only. Never import or invoke scientific components."""
from pathlib import Path
import ast
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 2
accept_path = Path(sys.argv[1]).resolve()
accept = read(accept_path)
assert accept['accepted_component_Source'] is True
for ref in accept['component_reviews'].values():
    verify(ref)
    assert read(ref['path'])['review_passed'] is True
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff'):
    verify(accept[key])
worker = Path(accept['worker']['path'])
api, offer = read(accept['worker_API']['path']), read(accept['worker_offer']['path'])
body = worker.read_bytes()
constants = {}
names = {'EXPERIMENT', 'PROTOCOL_SCHEMA', 'MODULE_ROLES', 'CONTROL_IDS', 'CAPS'}
for node in ast.parse(body).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in names:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
assert set(constants) == names
assert constants['EXPERIMENT'] == 'signed-propositional-successor-whole-qualification-v1'
assert constants['PROTOCOL_SCHEMA'] == 'Root-FPC-signed-propositional-successor-qualification-protocol-v1'
old = read(ROOT / 'plans/receptor-two-donor-acquisition-v1-donor-0.json')
assert constants['CAPS'] == old['limits'] and len(constants['CAPS']) == 10
modules = {row['role']: row['rawpin'] for row in offer['runtime_roles']}
assert len(modules) == len(offer['runtime_roles']) == len(constants['MODULE_ROLES']) == 36
assert set(modules) == set(constants['MODULE_ROLES'])
assert all(modules[role] == ref for role, ref in old['module_pins'].items())
assert set(modules) - set(old['module_pins']) == {
    'nonwrapper_selector', 'nonwrapper_selector_bank', 'signed_compiler', 'signed_producer', 'signed_bank', 'occurrence_bank'}
for ref in modules.values():
    verify(ref)
    assert ref['sha256'].encode() in body
assert {row['role']: row['rawpin'] for row in api['runtime_roles']} == modules
direction = read(ROOT / 'signed-successor-qualification-worker-Root-Source-direction-v1.json')
assert all(modules[role] == ref for role, ref in direction['current_roles'].items())
legacy_qualification = read(ROOT / 'signed-qualification-whole-protocol-v1.json')
assert all(modules[role] == legacy_qualification['module_pins'][role]
           for role in ('nonwrapper_selector', 'nonwrapper_selector_bank'))
populations = {row['population']: {key: row[key] for key in
    ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')}
    for row in api['scoped_populations']}
assert len(populations) == len(api['scoped_populations']) == 16
assert set(populations) == set(constants['CONTROL_IDS'])
assert all(populations[name] == item for name, item in old['control_populations'].items())
assert sum(item['groups'] for item in populations.values()) == 221
assert populations['nonwrapper_selector6'] == legacy_qualification['control_populations']['nonwrapper_selector6']
assert set(populations) - set(old['control_populations']) == {
    'nonwrapper_selector6', 'signed_propositional8_successor_v2', 'occurrence_diagnostics9'}
for name, item in populations.items():
    assert item['control_ids'] == list(constants['CONTROL_IDS'][name])
    assert type(item['groups']) is int and item['groups'] == len(item['control_ids'])
custody = {row['role']: row['rawpin'] for row in offer['custody_runtime']}
assert set(custody) == {'runner', 'observer', 'python'}
assert custody['python'] == old['python'] and custody['runner']['path'] == old['runner_path']
inputs = {}
for row in offer['raw_inputs']:
    key, ref = row['plan_key'], row['rawpin']
    assert key not in inputs
    inputs[key] = ref
    verify(ref)
    if key in old:
        assert ref == old[key]
guards = {}


def guard(ref):
    verify(ref)
    assert '/actual/' not in ref['path'] and not ref['path'].endswith('.bin')
    assert ref['path'] not in guards or guards[ref['path']] == ref
    guards[ref['path']] = ref


for ref in old['files'] + list(modules.values()) + list(custody.values()) + list(inputs.values()) + offer['semantic_guards']:
    guard(ref)
for ref in accept['component_reviews'].values():
    guard(ref)
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff'):
    guard(accept[key])
for path in (accept_path, Path(__file__), ROOT / 'signed-successor-qualification-worker-Root-Source-direction-v1.json',
             ROOT / 'issue_signed_successor_qualification_grant_v1.py', ROOT / 'census_signed_successor_qualification_case_v1.py'):
    guard(pin(path))
for ref in accept.get('additional_current_guards', []):
    guard(ref)
case_id = 'signed-propositional-successor-whole-qualification-v1-qualify-0'
recipe = dict(case_id=case_id, stage='qualify')
actual = STUDY / 'actual' / case_id
grant_path = ROOT / 'grants' / (case_id + '.json')
plan_path = ROOT / 'plans' / (case_id + '.json')
for path in (actual, Path(str(actual) + '.observer'), grant_path, plan_path):
    assert not path.exists() and not path.is_symlink()
protocol = emit(ROOT / 'signed-successor-qualification-whole-protocol-v1.json', dict(
    schema=constants['PROTOCOL_SCHEMA'], experiment=constants['EXPERIMENT'], limits=constants['CAPS'],
    module_pins=modules, control_populations=populations, job_recipes=[recipe],
    metadata=dict(status='PROSPECTIVE_NO_EXECUTION',
        direction=pin(ROOT / 'signed-successor-qualification-worker-Root-Source-direction-v1.json'),
        component_acceptance=pin(accept_path),
        population='Original198 complete scoped subjects/30base namespaces retained exactly; unchanged selector6, explicitly changed signed8 successor and additional occurrence9. 221groups/16scopes/15wrappers/36roles, not221 theorem targets.',
        scope='Infrastructure qualification only, no research donor/holdout search, proof export, GCTS/RL/library result or automatic admission. Controls construct only their independently frozen generic qualification inputs.',
        failure='Every controlled caught prewrite fault has seven null positive fields. Postwrite outer rejection may retain an unadmitted provisional artifact, never a qualified whole result/prefix. No replay or consumed retry; exact postwrite boundary is guarded.',
        success='Complete fresh controls, custody and whole costs followed by C/Root actual review; qualification is not a new research theorem or donor admission.',
        cost='All old/new cold imports, encoding, controls, same-byte dual validation, output and custody inside all original ten caps; tools idle during actual.',
        next='Research acquisition remains separate and still requires fresh inputs, complete cold controls and both donor whole admissions before extraction.',
        execution_authority=False)))
guard(protocol)
files = [guards[path] for path in sorted(guards)]
plan = dict(old, case_id=case_id, stage='qualify', experiment=constants['EXPERIMENT'],
            actual_dir=str(actual), worker_path=str(worker), protocol=protocol, files=files,
            module_pins=modules, control_populations=populations)
for stale in ('donor_index', 'input_slot', 'arm', 'target_index', 'target_id', 'search_configuration'):
    plan.pop(stale, None)
plan.update(inputs)
plan_pin = emit(plan_path, plan)
closure = emit(ROOT / 'signed-successor-qualification-Source-closure-v1.json', dict(
    schema='Root-signed-successor-qualification-closed-Source-v1', status='PROSPECTIVE_NOT_AUTHORITY',
    plan=plan_pin, protocol=protocol, files=files, namespace_count=36, scoped_groups=221,
    original_guard_count_retained=len(old['files']), original198_complete_population_objects_retained=True,
    scientific_imports_calls=0))
proposal = emit(ROOT / 'signed-successor-qualification-grant-proposal-v1.json', dict(
    schema='Root-signed-successor-qualification-once-proposal-v1', authorized=False, review_passed=False,
    uses=1, case_id=case_id, plan_sha256=plan_pin['sha256'], runner_sha256=custody['runner']['sha256'],
    observer_sha256=custody['observer']['sha256'], plan=plan_pin, protocol=protocol, closure=closure,
    component_acceptance=pin(accept_path), component_reviews=accept['component_reviews'],
    prospective_grant_path=str(grant_path),
    prospective_command=[custody['python']['path'], '-I', '-S', '-B', custody['observer']['path'],
                         plan_pin['path'], str(grant_path)],
    required_before_grant=['Independent complete whole Source/plan/proposal review',
                           'Root current guards/acceptance/fresh tools-idle observation',
                           'Separate exact one-use true grant'], execution_authority=False))
print(json.dumps(emit(ROOT / 'signed-successor-qualification-study-preparation-v1.json', dict(
    schema='Root-signed-successor-qualification-preparation-v1', status='PROSPECTIVE_REQUIRES_WHOLE_REVIEW',
    metadata_builder=pin(Path(__file__)), component_acceptance=pin(accept_path), worker=pin(worker),
    protocol=protocol, recipe=recipe, plan=plan_pin, closure=closure, proposal=proposal,
    shared_guards=len(files), namespaces=36, scoped_populations=16, scoped_groups=221,
    old198_population_objects_preserved=True, ten_caps_unchanged=True,
    false_proposal=True, scientific_imports_calls=0, goal_complete=False)), indent=2))
