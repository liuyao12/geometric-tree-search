"""Administrative original-bank cohort four-path publication from isolated P2 payloads."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import base64
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
P2 = ROOT.parents[1] / 'gcts-batch-20261020' / 'publisher-recovery-6338a77'
STAGING = ROOT / 'publication-original-bank-cohort-v1' / 'P2-staging.json'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
API = 'repos/liuyao12/geometric-tree-search/'
NAMES = ('point-proof-search-v1.html', 'point-proof-parallel-progress-v1.html',
         'point-proof-cohort-qualification-data-v1.json', 'point-proof-cohort-qualification-evidence-v1.zip')
BASES = {'point-proof-search-v1.html': ('198a0432374af5a35bbc5a16d7d91efd52e0b986', 60270),
         'point-proof-parallel-progress-v1.html': ('2cadc5364f32a61bcc660bb110ae94535cfd87b5', 9366)}
NEW_NAMES = ('point-proof-cohort-qualification-data-v1.json',
             'point-proof-cohort-qualification-evidence-v1.zip')


def pin(path):
    body = Path(path).read_bytes()
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def emit(path, value):
    with path.open('xb') as stream:
        stream.write(json_bytes(value))


def leaves(tree):
    assert tree['truncated'] is False
    result = {}
    for row in tree['tree']:
        if row['type'] == 'tree':
            continue
        assert row['type'] in ('blob', 'commit') and row['path'] not in result
        result[row['path']] = {key: row.get(key) for key in ('mode', 'type', 'sha', 'size')}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--acceptance', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    acceptance_path = Path(args.acceptance)
    acceptance = json.loads(acceptance_path.read_bytes())
    assert acceptance['approved_for_four_path_publication'] is True
    assert acceptance['publisher_source'] == dict(path=str(Path(__file__).resolve()), **pin(__file__))
    assert acceptance['staging'] == dict(path=str(STAGING), **pin(STAGING))
    for key in ('independent_review', 'visual_QA'):
        record = acceptance[key]
        assert pin(record['path']) == {k: record[k] for k in ('bytes', 'sha256')}
    staging = json.loads(STAGING.read_bytes())
    record = staging['catalog']
    assert pin(record['path']) == {k: record[k] for k in ('bytes', 'sha256')}
    files = staging['files']
    assert [row['path'] for row in files] == [PREFIX + name for name in NAMES]
    assert staging['scientific_execution'] is False
    bodies = {}
    for row in files:
        path = Path(row['publisher_source'])
        assert path == P2 / 'publication-payload-original-bank-cohort-v1' / Path(row['path']).name
        assert path.is_file() and not path.is_symlink()
        body = path.read_bytes()
        assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
        assert hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest() == row['git_blob_sha1']
        bodies[row['path']] = body
    output = Path(args.output)
    assert output.parent == ROOT and not output.exists()
    output.mkdir()
    sequence = 0

    def api(method, endpoint, value=None):
        nonlocal sequence
        sequence += 1
        command = ['gh', 'api', '--method', method, API + endpoint,
                   '-H', 'Accept: application/vnd.github+json',
                   '-H', 'X-GitHub-Api-Version: 2022-11-28']
        if value is not None:
            command.extend(['--input', '-'])
        process = subprocess.run(command, input=None if value is None else json_bytes(value),
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 cwd=P2, timeout=60, check=False)
        if process.returncode:
            emit(output / f'{sequence:02d}-api-error.json', dict(method=method, endpoint=endpoint,
                 returncode=process.returncode, stderr=process.stderr.decode(errors='replace')))
            raise RuntimeError('GitHub API failed; reconcile read-only before any retry')
        result = json.loads(process.stdout)
        emit(output / f'{sequence:02d}-response.json', result)
        return result

    parent = api('GET', 'git/ref/heads/main')['object']['sha']
    base_tree = api('GET', 'git/commits/' + parent)['tree']['sha']
    before = leaves(api('GET', 'git/trees/' + base_tree + '?recursive=1'))
    target_paths = {row['path'] for row in files}
    for name, (sha, size) in BASES.items():
        assert before[PREFIX + name] == dict(mode='100644', type='blob', sha=sha, size=size)
    assert len(BASES) == len(NEW_NAMES) == 2 and len(NAMES) == 4
    assert set(BASES) | set(NEW_NAMES) == set(NAMES)
    assert all(PREFIX + name not in before for name in NEW_NAMES)
    entries = []
    for row in files:
        result = api('POST', 'git/blobs', dict(content=base64.b64encode(bodies[row['path']]).decode('ascii'), encoding='base64'))
        assert result['sha'] == row['git_blob_sha1']
        entries.append(dict(path=row['path'], mode='100644', type='blob', sha=result['sha']))
    new_tree = api('POST', 'git/trees', dict(base_tree=base_tree, tree=entries))['sha']
    after = leaves(api('GET', 'git/trees/' + new_tree + '?recursive=1'))
    assert {k: v for k, v in before.items() if k not in target_paths} == {
        k: v for k, v in after.items() if k not in target_paths}
    assert set(after) == set(before) | target_paths
    for row in files:
        assert after[row['path']] == dict(mode='100644', type='blob', sha=row['git_blob_sha1'], size=row['bytes'])
    preservation = dict(parent=parent, base_tree=base_tree, new_tree=new_tree,
                        before_leaf_count=len(before), after_leaf_count=len(after),
                        non_target_leaves_identical=True, deletions=0, changed_paths=sorted(target_paths))
    emit(output / 'tree-preservation.json', preservation)
    commit = api('POST', 'git/commits', dict(message='Document original-bank cohort qualification outcome',
                                         tree=new_tree, parents=[parent]))['sha']
    assert api('GET', 'git/ref/heads/main')['object']['sha'] == parent, 'Main advanced; do not force or blindly retry'
    updated = api('PATCH', 'git/refs/heads/main', dict(sha=commit, force=False))
    assert updated['object']['sha'] == commit
    assert api('GET', 'git/ref/heads/main')['object']['sha'] == commit
    emit(output / 'publication-receipt.json', dict(schema='Root-four-path-original-bank-cohort-API-publication-v1',
        status='COMMITTED_AWAITING_PAGES_AND_LIVE_VERIFICATION',
        issued_utc=datetime.now(timezone.utc).isoformat(), commit=commit,
        parent=parent, tree=new_tree, force=False, files=files,
        acceptance=dict(path=str(acceptance_path), **pin(acceptance_path)),
        preservation=preservation, live_verified=False, scientific_execution=False))
    print(json.dumps(dict(commit=commit, receipt=str(output / 'publication-receipt.json'))))


if __name__ == '__main__':
    main()
