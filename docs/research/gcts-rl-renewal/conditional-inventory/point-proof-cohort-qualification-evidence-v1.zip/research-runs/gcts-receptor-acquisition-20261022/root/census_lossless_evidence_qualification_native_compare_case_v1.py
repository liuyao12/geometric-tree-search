"""Raw terminal census only; partial bodies are opaque bytes."""
from pathlib import Path
import hashlib
import json
import stat

ROOT = Path(__file__).resolve().parent
CASE = 'signed-propositional-lossless-evidence-whole-qualification-v3-qualify-0'
base = ROOT.parent / 'actual' / CASE
rows = []
for folder in (base, Path(str(base) + '.observer')):
    assert folder.is_dir() and not folder.is_symlink()
    for path in sorted(folder.rglob('*')):
        info = path.lstat()
        assert not stat.S_ISLNK(info.st_mode)
        if stat.S_ISREG(info.st_mode):
            body = path.read_bytes()
            rows.append(dict(path=str(path.resolve()), bytes=len(body),
                             sha256=hashlib.sha256(body).hexdigest(),
                             partial_opaque='.partial' in path.name))
out = ROOT / 'lossless-evidence-qualification-native-compare-terminal-raw-census-v1.json'
with out.open('xb') as stream:
    stream.write((json.dumps(dict(schema='Root-lossless-evidence-qualification-terminal-census-v1',
        case_id=CASE, files=rows, file_count=len(rows), physical_bytes=sum(row['bytes'] for row in rows),
        partial_count=sum(row['partial_opaque'] for row in rows),
        scope='Raw byte custody only. No scientific helper, replay, validator or prefix authority.'), indent=2) + '\n').encode())
body = out.read_bytes()
print(json.dumps(dict(path=str(out), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())))
