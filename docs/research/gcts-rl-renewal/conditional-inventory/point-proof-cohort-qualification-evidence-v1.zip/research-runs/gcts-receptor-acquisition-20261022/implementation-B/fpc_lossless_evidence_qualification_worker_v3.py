"""Fresh lossless-evidence infrastructure qualification once worker; Source-only authorship.

Every imported algorithm/control/codec operation belongs inside a separately
reviewed whole actual. All old controls keep their exact original subjects.
No prior output, target route, prefix, learned state or Native oracle is intake.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'FPC-lossless-evidence-qualification-worker-v3'
EXPERIMENT = 'signed-propositional-lossless-evidence-whole-qualification-v3'
PROTOCOL_SCHEMA = "Root-FPC-lossless-evidence-qualification-protocol-v3"
MODULE_ROLES = ('checker', 'builders', 'reference', 'baseline_search', 'codec', 'baseline_bank', 'producer', 'obligation_bank', 'point_adapter', 'point_bank', 'intro_bank', 'regression_bank', 'explicit_kernel', 'explicit_oracle', 'explicit_bank', 'provider', 'tiny_oracle', 'tiny_encoder', 'tiny_bank', 'controller', 'frame_oracle', 'controller_bank', 'conclusion_index_bank', 'legacy_provider', 'fixed_slot_bank', 'matched_point_controller', 'csp_controller', 'matched_controller_bank', 'selector', 'selector_bank', 'nonwrapper_selector', 'nonwrapper_selector_bank', 'signed_compiler', 'signed_producer', 'signed_bank', 'occurrence_bank', 'evidence_codec', 'evidence_codec_bank')
FIXED_PINS = {'checker': (31557, '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'), 'builders': (11348, 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'), 'reference': (24681, 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'), 'baseline_search': (54407, '53467e578ad7b512ae66e8e03cd85dadba1ded39b9ab0012c17e7e8f170a0902'), 'codec': (14061, '4c6366b1a3728608cedfd86f0c78ca38ffb9d65ffc1907b926fc5f5446ad0ab4'), 'baseline_bank': (35231, 'f0c2be3c99e866aea7a62dc012c6ec96be64c6a0f9b8619a82626d04603946af'), 'obligation_bank': (51653, '309fa0c9d5c068266faf96ff2f61f3ff15874cf24b0065bc83d216fa10152280'), 'point_adapter': (10972, '57eac1681fbb9e3a6494109a1b9ca43cbfa4d5bfc25ce87954537ae801acf32f'), 'point_bank': (18065, 'd49e554bc24fba8539224b7f4099e2f089639f36245a9ed4e47fc2753e7d387e'), 'intro_bank': (10141, '5390689c124393bed3ea8a19c84a1e43bb81d956945dbcebc5712b97892d90c2'), 'producer': (105517, 'fa135ec9e84cdb84b0be506d74a1f167e619b7ac82fcb6a1d8b8782c738523d1'), 'regression_bank': (13618, '2a20fd644b8370d1f6b8f07921075c72b227dc280d9502c9259ac6ed9eb41c7b'), 'explicit_kernel': (29002, '158174c8445997bedf5b17785840eb7a89dcd4d46098fcdfb35a84e2fef3849c'), 'explicit_oracle': (18338, 'ff34af27a491da3571fc02227333ca3ce048a8d7c6d49cb780d3b1c9ba14a995'), 'explicit_bank': (40853, 'eedf82a42ebae7f4133f2ee1781e33205980769f8164bd278641761e6d1a1029'), 'provider': (67637, '39da5195f815da0cceddd11b4d4b25671a50e926ca1885ccc3add6cd99a8d048'), 'tiny_oracle': (14647, 'bcf281fc7e19bf8c08a5b33456a6bb2eeebb33b2034f203f1540820e5e4eff9b'), 'tiny_encoder': (9018, '154615acacc813239d6cf005c82aa37fce96e631098f6408a8798a981a08455d'), 'tiny_bank': (30645, 'dadc7d7cad94fd80dbfe381e9d59f56c1af20d90149f292b9bd70ebe657442f7'), 'controller': (27604, 'e9198683dc830e0080fefde997e81adbcf5963c2671688b491c99bfde3ea9d61'), 'frame_oracle': (3981, 'e4d6f452cbda35b530fb469c10a2441bc694b523df8e46de74c96c4ab074de99'), 'legacy_provider': (58026, '7fc9ebe143513fa86e726c78832cdbb91589fbd9e8a5d2b21eb3183a5fbf5fd2'), 'fixed_slot_bank': (27942, '8a7b33c8729d6c9f40c9354058bbbef24568e885ec8bccf6d12fae04bdf8be03'), 'matched_point_controller': (37990, '16acece30e3420a1097989c8d580d0c9cf103488ac5b3a151d3ff2fc64285fac'), 'csp_controller': (39011, 'c9ec1b7a54d18b6d04056cb38039434bf287711cf6f430d38c14a0a97988d59a'), 'matched_controller_bank': (62115, '4de67bf9eb06235b39b6bcb43a5775e9e11897620775db41a558ca55f661b13d'), 'selector': (11525, 'a29b4ca1008b355006431584f05da9b391d22532602e7e54f14291477ef2e668'), 'selector_bank': (22672, '384aebcf362ff55da28e6bf4eec10360f50a354ad324f6423e7fdb0d3883bbf8'), 'nonwrapper_selector': (14767, '79e3faa7a63f908e94410b980c21c3e368d1672c4c318af4c822ad8462b25d83'), 'nonwrapper_selector_bank': (30254, 'a9f440295a9a9753d0983b62df056755df5adc1e88daf1c6895ce1d83a54fe2d'), 'signed_compiler': (45796, 'e904a88fc7896f4a941ab2d4f3f37ee2af005369be30b959263a4dd5f55eda0d'), 'signed_producer': (26771, '3996ab4f37243c4c2ef59e27f1a2b24539414a63795de2441d938553297ee251'), 'signed_bank': (47641, '1c6ec1eeea6e031cb8fd62c957f4f69f090b3b26c70c762e48c26ce3c4ce4693'), 'occurrence_bank': (51261, '372f069194c488ad0067f17593636f03db9f1f820059f471491fcd12a683e6a7'), 'evidence_codec': (50486, '4a06aad019c6a2215ba8802e798d350190168bbda62b19d50ee6e0ff573b8143'), 'evidence_codec_bank': (40507, '1aa84e604dc5d44d43f7fa65ba76d87c2b58ee6858f2ee45a93dbdf1f12136f4')}
CONTROL_IDS = {'baseline56': ('codec-hi-and-exists-literal', 'codec-pa-no-profile-payload', 'codec-metadata-query-invariance', 'codec-shadowed-binder-preserved', 'codec-bool-mode-refused', 'codec-open-theorem-refused', 'codec-signature-mismatch-refused', 'codec-binder-order-refused', 'codec-extra-proof-field-refused', 'codec-retained-fault-identity', 'product-two-by-three', 'product-three-binary-slots', 'product-closed-empty', 'product-zero-arity', 'product-open-request-not-eof', 'product-staggered-arrivals', 'product-known-empty-dominates-open', 'match-formula-meta', 'match-consistent-repeat', 'match-conflicting-repeat', 'match-rigid-binder', 'match-no-alpha-renaming', 'match-term-meta', 'match-sort-conflict', 'match-variable-meta', 'match-rigid-arity-conflict', 'builder-H1-literal', 'builder-H2-literal', 'builder-H3-literal', 'builder-Q1-literal', 'builder-Q2-literal', 'builder-Q3-literal', 'builder-E1-literal', 'builder-E2-literal', 'builder-Q1-capture-refused', 'builder-Q3-free-variable-refused', 'builder-E2-capture-refused', 'builder-induction-full-parameters-refused', 'search-antecedent-first-closure', 'search-implication-first-closure', 'search-duplicate-source-aliases', 'search-cyclic-demand-no-fact', 'search-long-source-witness-not-fact', 'search-shared-DAG-export', 'search-late-GEN', 'search-full-Gamma-GEN-refusal', 'search-source-variable-outside-grammar', 'search-source-depth-outside-grammar', 'search-priority-record-invariants', 'search-cutoff-live-prefix-no-exhaustion', 'fault-product-first-ValueError', 'fault-matcher-first-StopIteration', 'fault-search-retained-owned-codec', 'fault-search-later-RuntimeError', 'fault-final-validator-first-identity', 'fault-builder-public-class-identity'), 'obligation47': ('search-context-Gamma-present', 'search-context-Gamma-absent', 'search-context-theory-present', 'search-context-theory-absent', 'search-cycle-without-seed', 'search-premise-source-first', 'search-premise-implication-first', 'search-premise-duplicate-source', 'search-shared-context-diamond', 'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture', 'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable', 'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable', 'guard-induction-wrong-profile', 'guard-induction-wrong-parameters', 'guard-induction-parameter-closure', 'compile-intro-identity', 'compile-intro-root-hypothesis', 'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions', 'compile-intro-finite-table', 'compile-intro-logical-axiom', 'compile-intro-PA-table', 'compile-intro-incidence-table', 'compile-intro-induction', 'compile-full-FPC-deep-term', 'compile-full-FPC-large-formula', 'refuse-MP-premise-order', 'refuse-rigid-binder-HYP', 'refuse-GEN-unused-root', 'refuse-GEN-unused-local', 'refuse-context-opener', 'refuse-forward-premise', 'refuse-duplicate-arena-row', 'product-diagonal-2x2', 'product-open-WAIT-growth', 'product-closed-empty-open-other', 'product-zero-arity', 'fault-search-first-RuntimeError', 'fault-guard-StopIteration', 'fault-compile-same-public-class', 'fault-retained-owned-through-guard', 'fault-late-compile-first-before-second', 'fault-dual-validators'), 'intro_integration1': ('producer-INTRO-local-HYP-dual-export',), 'point20': ('point-HYP-MP-agreement', 'point-wrong-MP-mark-conflict', 'point-final-goal-boundary-conflict', 'point-GEN-agreement', 'point-GEN-source-mark-conflict', 'point-GEN-unused-Gamma-refusal', 'point-HYP-declared-conclusion-refusal', 'point-LOGICAL-declared-conclusion-refusal', 'point-THEORY-profile-refusal', 'point-MP-forward-reference-refusal', 'point-MP-coincident-port-refusal', 'point-repeated-remote-port-agreement', 'point-long-range-mark-only-agreement', 'point-LOGICAL-Q3-agreement', 'point-THEORY-finite-agreement', 'point-first-RuntimeError-identity', 'point-first-public-refusal-class-identity', 'point-first-StopIteration-identity', 'point-later-first-fault-and-immutability', 'point-retained-family-refusal-identity'), 'regression2': ('refuse-extra-INTRO-reused-owned-context', 'constructor-StopIteration-first-fault-and-owned-cleanup'), 'point-kernel13': ('global-dead-before-forced', 'global-forced-before-earlier-branch', 'generation-before-degree', 'remote-mark-only-zero-is-assigned', 'remote-conflict-dead-before-other-force', 'shared-fractional-placement-once', 'distinct-inventory-identical-point-functions', 'rollback-parent-exclusion', 'mark-reference-count-rollback', 'generation-minimum-rollback', 'outside-support-global-legality', 'lazy-prefix-not-singleton', 'frame-boundary-growth'), 'point-kernel-safety3': ('normal-refusal-and-input-ownership', 'checkpoint-path-and-cursor-ownership', 'first-fault-and-retained-owned-identity'), 'tiny-full-provider10': ('duplicate-HYP-table-full-domain', 'GEN-full-formula-valued-identities', 'MP-full-formula-valued-identities', 'E1-singleton-requires-full-EOF', 'full-Gamma-outside-envelope-blocks-GEN', 'full-Gamma-unblocked-GEN-counterpart', 'out-of-envelope-goal-stays-boundary', 'remote-ports-rebind-retained-parent', 'initial-inspection-not-tried-remainder', 'inventory-first-fault-no-prefix'), 'full-frame-controller10': ('protocol-dead-before-forced', 'protocol-no-forcing-unresolved', 'protocol-global-single-before-earlier-branch', 'protocol-parent-offer-remainder', 'protocol-fuel-not-child-failure', 'protocol-first-fault-no-normal-result', 'real-tiny-candidate-frame-agreement', 'real-tiny-empty-frame-agreement', 'dovetail-first-prefix-budget-restarts', 'public-strict-int-and-input-identity'), 'constructor-index14': ('shape-H1-ancestor-descendant', 'shape-H2-ancestor-descendant', 'shape-H3-ancestor-descendant', 'shape-Q1-ancestor-descendant', 'shape-Q2-ancestor-descendant', 'shape-Q3-ancestor-descendant', 'shape-E1-ancestor-descendant', 'shape-E2-ancestor-descendant', 'shape-induction-empty-prefix-core', 'shape-induction-nonempty-prefix-core', 'helper-first-fault-identities', 'public-cursor-first-fault-poison', 'public-tiny-identities-order-remainders', 'public-incompatible-shape-EOF'), 'fixed-free-slot8': ('rigid-visible-logical-equations', 'Q1-free-terms-public-order-EOF', 'E2-free-body-binder-forward-aliases', 'induction-prefix-singleton-forward', 'MP-fixed-B-reset-unfilled-reference-order', 'GEN-full-Gamma-unfilled-reference-domain', 'absent-output-typed-slots-source-aliases', 'restriction-first-fault-parent-remainder'), 'matched-controller8': ('protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions'), 'selector6': ('selector-tree-order', 'selector-atom-renaming', 'selector-Boolean-eligibility', 'selector-single-axiom-exclusion', 'selector-distinct-prefix-and-stop', 'selector-envelope-and-first-fault'), 'nonwrapper_selector6': ('literal-helper-facts', 'canonical-occurrence-and-copying', 'malformed-envelope-owned-refusals', 'complete-ordered-winning-prefixes', 'first-and-retained-callback-identity', 'fresh-call-and-slot-isolation'), 'signed_propositional8_successor_v2': ('compiler-signed-rules-and-source-occurrences', 'strict-invalid-tree-refusals', 'search-closed-rule-counts-and-primitive-validation', 'total-countermodels-and-second-split-branch', 'malformed-unsupported-mode-and-EOF', 'configuration-module-and-owned-refusals', 'normal-FINAL-counts-and-owned-snapshot-isolation', 'first-retained-fault-and-stale-diagnostic-identity'), 'occurrence_diagnostics9': ('unused-LOCAL-root-and-both-split-branches', 'equal-LOCAL-used-outer-unused-inner', 'shared-original-source-boundary', 'ordered-Gamma-and-finite-table-aliases', 'LOCAL-equal-to-surviving-root-Gamma', 'nested-composite-LOCAL-substitution', 'exact-diagnostic-intake-refusals', 'normal-FINAL-transport-and-no-compiler-paths', 'first-callback-retained-and-malformed-sink-identity'), 'lossless_evidence_codec8_v1': ('original-value-inverse-and221-paths', 'typed-scalars-and-integer-domain', 'canonical-sharing-order-and-occurrences', 'malformed-carriers-and-reference-refusals', 'owned-snapshot-and-public-lifecycle', 'first-callback-writer-and-retained-error', 'streamed-whole-and-path-readback', 'callable-intake-policy-and-session-isolation')}
CAPS = {'work_seconds': 160, 'positive_seconds': 180, 'custody_seconds': 210, 'observer_fallback_seconds': 225, 'memory_bytes': 1073741824, 'physical_bytes': 134217728, 'result_bytes': 50331648, 'log_bytes': 4194304, 'reserved_outer_bytes': 9437184, 'root_callbacks': 400000000}
DECLARATIONS_PIN = (8614, "c6ae5f616b61e85f4b5cbd2b1e7619c047f42d83afd725e277475292cd904b0a")
AUTHORITY_PIN = (7910, "2e7cc31d6e72107d3811cf6a980ec261e0122c8736d4520db9cea119317eb54d")
RAW13_PIN = (15516, "18851c3488152f3743a61eacafc12322c94c48f98038cccf01bd95482793225a")
TINY_INPUT_PIN = (16186, "bd3cefe3f86700f0909d605bcac480e4c0f941dafc529716f68b20350699d708")
CONTROLLER_BANK_PIN = (45831, "41d964fb0075cd034d64ccb98d078c6290e71d09d14ca2bc7ec004d343348f79")

CONCLUSION_BANK_PIN = (29220, '3afd0cbd5c43419f7f8d23e46ef015cfd2232b2325a354e984535ccd14ad1ac5')
CONCLUSION_FIXTURES_PIN = (13490, 'b23d97e5bce2c28e288742d9173787905e0b18ce804cde7a1dc39e3db20695e2')
FIXED_SLOT_FIXTURES_PIN = (36196, '9b2d64e844900e3a5741e0792690bbf58f36ba2a3667d96ef9159d5d9911661a')

WORKER_DIAGNOSTIC_FIELDS = ('schema', 'arm', 'complete', 'snapshot_available', 'publish_seq', 'phase_in_progress', 'active_frame_round', 'active_frame_pair_index', 'active_frame_ordinal', 'active_frame_rows', 'active_frame_syntax_nodes', 'active_frame_limit', 'active_phase', 'active_atomic_steps_committed', 'active_provider_calls_committed', 'active_provider_advances_committed', 'active_domain_completions', 'active_global_scans', 'active_forced_moves', 'active_branch_nodes', 'active_offers', 'active_backtracks', 'active_reject_offers', 'active_reuses', 'active_invalidations', 'active_outstanding_offers', 'active_live_cursors', 'active_highwater_live_cursors', 'active_trail_entries', 'active_highwater_trail_entries', 'frames_completed', 'frames_exhausted', 'frames_fuel_limited', 'completed_atomic_steps_committed', 'completed_provider_calls_committed', 'completed_provider_advances_committed', 'completed_domain_completions', 'completed_global_scans', 'completed_forced_moves', 'completed_branch_nodes', 'completed_offers', 'completed_backtracks', 'completed_reject_offers', 'completed_reuses', 'completed_invalidations', 'completed_highwater_live_cursors', 'completed_highwater_trail_entries', 'raw_member_work_supported', 'raw_member_work')
MATCHED_FIXTURES_PIN = (20281, '71078f5a170cda30c3f7b2d6a699e9c260793f6c8d591316076f6bb86c3ee898')

COMPILER_DIAGNOSTIC_FIELDS = ('schema', 'snapshot_available', 'phase', 'phase_in_progress', 'active_control_index', 'active_fixture_index', 'compiler_invocation_index', 'observed_through_callback', 'phase_enter_monotonic_ns', 'construction_completed_ns', 'export_reachability_completed_ns', 'export_encoding_completed_ns', 'formula_dag_nodes', 'ir_rows_created', 'emitter_instances', 'reachable_rows', 'export_rows_committed', 'expanded_headers_committed', 'wire_bytes_committed', 'active_encode_role')
COMPILER_DIAGNOSTIC_INITIAL = {'schema': 'FPC-H1-signed-compiler-diagnostics-v1', 'snapshot_available': False, 'phase': None, 'phase_in_progress': False, 'active_control_index': None, 'active_fixture_index': None, 'compiler_invocation_index': 0, 'observed_through_callback': 0, 'phase_enter_monotonic_ns': None, 'construction_completed_ns': None, 'export_reachability_completed_ns': None, 'export_encoding_completed_ns': None, 'formula_dag_nodes': None, 'ir_rows_created': None, 'emitter_instances': None, 'reachable_rows': None, 'export_rows_committed': 0, 'expanded_headers_committed': 0, 'wire_bytes_committed': 0, 'active_encode_role': None}

EVIDENCE_SCOPE_TEMPLATE = (('baseline56', ('codec-hi-and-exists-literal', 'codec-pa-no-profile-payload', 'codec-metadata-query-invariance', 'codec-shadowed-binder-preserved', 'codec-bool-mode-refused', 'codec-open-theorem-refused', 'codec-signature-mismatch-refused', 'codec-binder-order-refused', 'codec-extra-proof-field-refused', 'codec-retained-fault-identity', 'product-two-by-three', 'product-three-binary-slots', 'product-closed-empty', 'product-zero-arity', 'product-open-request-not-eof', 'product-staggered-arrivals', 'product-known-empty-dominates-open', 'match-formula-meta', 'match-consistent-repeat', 'match-conflicting-repeat', 'match-rigid-binder', 'match-no-alpha-renaming', 'match-term-meta', 'match-sort-conflict', 'match-variable-meta', 'match-rigid-arity-conflict', 'builder-H1-literal', 'builder-H2-literal', 'builder-H3-literal', 'builder-Q1-literal', 'builder-Q2-literal', 'builder-Q3-literal', 'builder-E1-literal', 'builder-E2-literal', 'builder-Q1-capture-refused', 'builder-Q3-free-variable-refused', 'builder-E2-capture-refused', 'builder-induction-full-parameters-refused', 'search-antecedent-first-closure', 'search-implication-first-closure', 'search-duplicate-source-aliases', 'search-cyclic-demand-no-fact', 'search-long-source-witness-not-fact', 'search-shared-DAG-export', 'search-late-GEN', 'search-full-Gamma-GEN-refusal', 'search-source-variable-outside-grammar', 'search-source-depth-outside-grammar', 'search-priority-record-invariants', 'search-cutoff-live-prefix-no-exhaustion', 'fault-product-first-ValueError', 'fault-matcher-first-StopIteration', 'fault-search-retained-owned-codec', 'fault-search-later-RuntimeError', 'fault-final-validator-first-identity', 'fault-builder-public-class-identity'), 56, 'baseline_bank', 'baseline_search', 'Unchanged original56 codec/builders/old search expectations only. Fresh controls, never claims about the new producer.'), ('obligation47', ('search-context-Gamma-present', 'search-context-Gamma-absent', 'search-context-theory-present', 'search-context-theory-absent', 'search-cycle-without-seed', 'search-premise-source-first', 'search-premise-implication-first', 'search-premise-duplicate-source', 'search-shared-context-diamond', 'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture', 'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable', 'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable', 'guard-induction-wrong-profile', 'guard-induction-wrong-parameters', 'guard-induction-parameter-closure', 'compile-intro-identity', 'compile-intro-root-hypothesis', 'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions', 'compile-intro-finite-table', 'compile-intro-logical-axiom', 'compile-intro-PA-table', 'compile-intro-incidence-table', 'compile-intro-induction', 'compile-full-FPC-deep-term', 'compile-full-FPC-large-formula', 'refuse-MP-premise-order', 'refuse-rigid-binder-HYP', 'refuse-GEN-unused-root', 'refuse-GEN-unused-local', 'refuse-context-opener', 'refuse-forward-premise', 'refuse-duplicate-arena-row', 'product-diagonal-2x2', 'product-open-WAIT-growth', 'product-closed-empty-open-other', 'product-zero-arity', 'fault-search-first-RuntimeError', 'fault-guard-StopIteration', 'fault-compile-same-public-class', 'fault-retained-owned-through-guard', 'fault-late-compile-first-before-second', 'fault-dual-validators'), 47, 'obligation_bank', 'producer', 'Additive new synthetic query/guard/compiler/product/fault coverage with full separate current receipts.'), ('intro_integration1', ('producer-INTRO-local-HYP-dual-export',), 1, 'intro_bank', 'producer', 'Synthetic search-only discovery of current-context INTRO/localHYP and primitive compiler/dual validation integration; not a six-goal theorem.'), ('point20', ('point-HYP-MP-agreement', 'point-wrong-MP-mark-conflict', 'point-final-goal-boundary-conflict', 'point-GEN-agreement', 'point-GEN-source-mark-conflict', 'point-GEN-unused-Gamma-refusal', 'point-HYP-declared-conclusion-refusal', 'point-LOGICAL-declared-conclusion-refusal', 'point-THEORY-profile-refusal', 'point-MP-forward-reference-refusal', 'point-MP-coincident-port-refusal', 'point-repeated-remote-port-agreement', 'point-long-range-mark-only-agreement', 'point-LOGICAL-Q3-agreement', 'point-THEORY-finite-agreement', 'point-first-RuntimeError-identity', 'point-first-public-refusal-class-identity', 'point-first-StopIteration-identity', 'point-later-first-fault-and-immutability', 'point-retained-family-refusal-identity'), 20, 'point_bank', 'point_adapter', 'Current parametric point-row representation only, no parser or search/graph qualification.'), ('regression2', ('refuse-extra-INTRO-reused-owned-context', 'constructor-StopIteration-first-fault-and-owned-cleanup'), 2, 'regression_bank', 'producer', 'Exact malformed ownership and public-phase first-StopIteration regressions only; cleanup remains Source/whole custody authority.'), ('point-kernel13', ('global-dead-before-forced', 'global-forced-before-earlier-branch', 'generation-before-degree', 'remote-mark-only-zero-is-assigned', 'remote-conflict-dead-before-other-force', 'shared-fractional-placement-once', 'distinct-inventory-identical-point-functions', 'rollback-parent-exclusion', 'mark-reference-count-rollback', 'generation-minimum-rollback', 'outside-support-global-legality', 'lazy-prefix-not-singleton', 'frame-boundary-growth'), 13, 'explicit_bank', 'explicit_kernel', 'Generic explicit graph13 or safety3 only; not full logical provider/controller proof validation.'), ('point-kernel-safety3', ('normal-refusal-and-input-ownership', 'checkpoint-path-and-cursor-ownership', 'first-fault-and-retained-owned-identity'), 3, 'explicit_bank', 'explicit_kernel', 'Generic explicit graph13 or safety3 only; not full logical provider/controller proof validation.'), ('tiny-full-provider10', ('duplicate-HYP-table-full-domain', 'GEN-full-formula-valued-identities', 'MP-full-formula-valued-identities', 'E1-singleton-requires-full-EOF', 'full-Gamma-outside-envelope-blocks-GEN', 'full-Gamma-unblocked-GEN-counterpart', 'out-of-envelope-goal-stays-boundary', 'remote-ports-rebind-retained-parent', 'initial-inspection-not-tried-remainder', 'inventory-first-fault-no-prefix'), 10, 'tiny_bank', 'provider', 'Restricted profile0,b<=3,n<=4 full-row membership; not all-FPC runtime qualification. Current provider subject is5; only the original explicitly scoped facets are tested.'), ('full-frame-controller10', ('protocol-dead-before-forced', 'protocol-no-forcing-unresolved', 'protocol-global-single-before-earlier-branch', 'protocol-parent-offer-remainder', 'protocol-fuel-not-child-failure', 'protocol-first-fault-no-normal-result', 'real-tiny-candidate-frame-agreement', 'real-tiny-empty-frame-agreement', 'dovetail-first-prefix-budget-restarts', 'public-strict-int-and-input-identity'), 10, 'controller_bank', 'controller', 'Protocol stubs/schedule/intake plus separately identified real tiny positive/empty/reuse facets; no theorem discovery authority. Current provider subject is5; only the original explicitly scoped facets are tested.'), ('constructor-index14', ('shape-H1-ancestor-descendant', 'shape-H2-ancestor-descendant', 'shape-H3-ancestor-descendant', 'shape-Q1-ancestor-descendant', 'shape-Q2-ancestor-descendant', 'shape-Q3-ancestor-descendant', 'shape-E1-ancestor-descendant', 'shape-E2-ancestor-descendant', 'shape-induction-empty-prefix-core', 'shape-induction-nonempty-prefix-core', 'helper-first-fault-identities', 'public-cursor-first-fault-poison', 'public-tiny-identities-order-remainders', 'public-incompatible-shape-EOF'), 14, 'conclusion_index_bank', 'legacy_provider', 'New separately scoped necessary-predicate54 literal cases across10 groups, helper faults, Source-bound public fault/poison, original tiny full-identity/order/remainder/SINGLE EOF and new generic empty single-row b5. Not a public full-profile inventory equivalence, scheduler, cleanup, practical benefit or proof-admission qualification. Original26 declarations remain distinct and unchanged. Subject is separately imported exact provider4, never current6.'), ('fixed-free-slot8', ('rigid-visible-logical-equations', 'Q1-free-terms-public-order-EOF', 'E2-free-body-binder-forward-aliases', 'induction-prefix-singleton-forward', 'MP-fixed-B-reset-unfilled-reference-order', 'GEN-full-Gamma-unfilled-reference-domain', 'absent-output-typed-slots-source-aliases', 'restriction-first-fault-parent-remainder'), 8, 'fixed_slot_bank', 'provider', 'Independent private rigid equation/typed-slot plus public tiny full identity/order/EOF/remainder/fault controls; legacy4 only common literal-set/order comparison. No all26 or full-profile/large-E2/cleanup/performance authority.'), ('matched-controller8', ('protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions'), 8, 'matched_controller_bank', 'csp_controller', 'Five independent protocol groups and three real provider6 facets for BOTH matched_point_controller and csp_controller; same49field observation and common14phase clock. Oracle complete tiny sets, driver first exports only. No all-profile equivalence or cleanup/fault-sweep proof.'), ('selector6', ('selector-tree-order', 'selector-atom-renaming', 'selector-Boolean-eligibility', 'selector-single-axiom-exclusion', 'selector-distinct-prefix-and-stop', 'selector-envelope-and-first-fault'), 6, 'selector_bank', 'selector', 'Fresh independent input-only prefix/Boolean/pattern/slot/fault qualification. No proof/query-byte/producer authority; STOP branch runtime coverage remains explicit. Original192 scope objects unchanged.'), ('nonwrapper_selector6', ('literal-helper-facts', 'canonical-occurrence-and-copying', 'malformed-envelope-owned-refusals', 'complete-ordered-winning-prefixes', 'first-and-retained-callback-identity', 'fresh-call-and-slot-isolation'), 6, 'nonwrapper_selector_bank', 'nonwrapper_selector', 'New selector public endpoint controls only; selected control slots are not research input authority.'), ('signed_propositional8_successor_v2', ('compiler-signed-rules-and-source-occurrences', 'strict-invalid-tree-refusals', 'search-closed-rule-counts-and-primitive-validation', 'total-countermodels-and-second-split-branch', 'malformed-unsupported-mode-and-EOF', 'configuration-module-and-owned-refusals', 'normal-FINAL-counts-and-owned-snapshot-isolation', 'first-retained-fault-and-stale-diagnostic-identity'), 8, 'signed_bank', 'signed_producer', 'Exact original8 semantic obligations/IDs on explicit compiler Source3 publicVERSION2, producer Source3 VERSION2 and signed-bank2. No retargeting/admission/retry of failed legacy1.'), ('occurrence_diagnostics9', ('unused-LOCAL-root-and-both-split-branches', 'equal-LOCAL-used-outer-unused-inner', 'shared-original-source-boundary', 'ordered-Gamma-and-finite-table-aliases', 'LOCAL-equal-to-surviving-root-Gamma', 'nested-composite-LOCAL-substitution', 'exact-diagnostic-intake-refusals', 'normal-FINAL-transport-and-no-compiler-paths', 'first-callback-retained-and-malformed-sink-identity'), 9, 'occurrence_bank', 'signed_producer/signed_compiler', 'Nine additional independently authored occurrence/mathematical/diagnostic groups; Source2 bank VERSION1/98 fixed direct call locators. Complete only after all facets, no research proof or legacy-prefix authority.'))
EVIDENCE_BANK_ORDER = ('baseline56', 'obligation47', 'intro_integration1', 'regression2', 'point20', 'explicit16', 'tiny-full-provider10', 'full-frame-controller10', 'constructor-index14', 'fixed-free-slot8', 'matched-controller8', 'selector6', 'nonwrapper_selector6', 'signed_propositional8_successor_v2', 'occurrence_diagnostics9')
EVIDENCE_ENVELOPE_KEYS = ('schema', 'profile', 'scope_manifest', 'bank_roots', 'control_index', 'nodes', 'blobs', 'qualification_root', 'capture_root', 'canonical_qualification')

class RootBudget(RuntimeError):
    """Only a genuine whole-worker limit may create this owned condition."""


def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module


def _compiler_snapshot(sink, population):
    # Callback-free fixed scalar copy only; never an algorithm/getter call.
    if (type(population) is not str or population not in
            ('signed_propositional8_successor_v2', 'occurrence_diagnostics9')
            or type(sink) is not dict or len(sink) != 20):
        return []
    for key in sink:
        if type(key) is not str:
            return []
    for key in COMPILER_DIAGNOSTIC_FIELDS:
        if key not in sink:
            return []
    if (type(sink['schema']) is not str or sink['schema'] != 'FPC-H1-signed-compiler-diagnostics-v1'
            or type(sink['snapshot_available']) is not bool or sink['snapshot_available'] is not True
            or type(sink['phase_in_progress']) is not bool):
        return []
    if not (sink['phase'] is None or (type(sink['phase']) is str and sink['phase'] in
            ('INTAKE', 'CONSTRUCT', 'EXPORT_REACHABLE', 'EXPORT_ENCODE', 'FINALIZE', 'FINAL'))):
        return []
    for key in ('active_control_index', 'active_fixture_index', 'phase_enter_monotonic_ns',
                'construction_completed_ns', 'export_reachability_completed_ns',
                'export_encoding_completed_ns', 'formula_dag_nodes', 'ir_rows_created',
                'emitter_instances', 'reachable_rows'):
        value = sink[key]
        if not (value is None or (type(value) is int and value >= 0)):
            return []
    for key in ('compiler_invocation_index', 'observed_through_callback', 'export_rows_committed',
                'expanded_headers_committed', 'wire_bytes_committed'):
        value = sink[key]
        if type(value) is not int or value < 0:
            return []
    if not (sink['active_encode_role'] is None or (type(sink['active_encode_role']) is str and
            sink['active_encode_role'] in ('CONCLUSION', 'LOGICAL_WITNESS', 'OTHER_WIRE'))):
        return []
    copied = {}
    for key in COMPILER_DIAGNOSTIC_FIELDS:
        copied[key] = sink[key]
    return [dict(schema='FPC-H1-signed-compiler-worker-snapshot-v1', population=population,
                 compiler_diagnostics=copied)]


def _evidence_scope_manifest(check):
    # Fresh ordinary caller metadata; no private codec table or old result intake.
    manifest = []
    for population, ids, groups, bank_role, subject_role, scope in EVIDENCE_SCOPE_TEMPLATE:
        check()
        copied_ids = []
        for control_id in ids:
            check()
            copied_ids.append(control_id)
        manifest.append(dict(population=population, control_ids=copied_ids,
            groups=groups, bank_role=bank_role, subject_role=subject_role, scope=scope))
    return manifest


def _validate_evidence_controls(value, check):
    check()
    expected = {'schema', 'version', 'population', 'complete', 'control_ids',
                'controls', 'counts', 'scope', 'coverage_limits', 'scientific_claim'}
    if (type(value) is not dict or len(value) != len(expected)
            or any(type(key) is not str for key in value) or set(value) != expected
            or value['version'] != 'FPC-LOSSLESS-EVIDENCE-INDEPENDENT-CONTROLS-v1'
            or value['scientific_claim'] is not False
            or type(value['scope']) is not str
            or value['scope'] != 'Codec-only synthetic transport qualification, not scientific221 observations or proof admission; original221 subjects unchanged.'
            or type(value['coverage_limits']) is not list):
        raise ValueError('complete separate non-scientific codec8 carrier required')
    for text in value['coverage_limits']:
        check()
        if type(text) is not str:
            raise ValueError('codec8 coverage strings required')
    for row in value['controls']:
        check()
        if (type(row) is not dict or len(row) != 4
                or any(type(key) is not str for key in row)
                or set(row) != {'id', 'passed', 'observations', 'coverage_limits'}
                or row['passed'] is not True or type(row['observations']) is not list
                or type(row['coverage_limits']) is not list):
            raise ValueError('complete codec8 row required')
        for text in row['coverage_limits']:
            check()
            if type(text) is not str:
                raise ValueError('codec8 row coverage strings required')
        for observation in row['observations']:
            check()
            if (type(observation) is not dict or len(observation) != 4
                    or any(type(key) is not str for key in observation)
                    or set(observation) != {'label', 'endpoint', 'outcome', 'evidence'}
                    or type(observation['label']) is not str
                    or type(observation['endpoint']) is not str
                    or type(observation['outcome']) is not str
                    or observation['outcome'] not in
                        ('NORMAL_COMPLETE', 'REFUSAL_DIAGNOSTIC', 'FOREIGN_IDENTITY')):
                raise ValueError('complete codec8 observation required')
    # Every evidence value is retained verbatim; the sole complete output encoder
    # enforces finite JSON. No hash/status/summary replaces these observations.


def _validate_evidence_envelope(value, packed_roots, manifest_frozen, canonical, check):
    check()
    if (type(value) is not dict or len(value) != len(EVIDENCE_ENVELOPE_KEYS)
            or any(type(key) is not str for key in value)
            or set(value) != set(EVIDENCE_ENVELOPE_KEYS)
            or value['schema'] != 'FPC-lossless-qualification-evidence-v1'
            or value['profile'] != 'EXISTING_JSON221_V1'
            or type(value['nodes']) is not list or not value['nodes']
            or type(value['blobs']) is not list or value['blobs']
            or value['capture_root'] is not None
            or type(value['qualification_root']) is not int
            or not 0 <= value['qualification_root'] < len(value['nodes'])
            or type(value['bank_roots']) is not list
            or len(value['bank_roots']) != len(EVIDENCE_BANK_ORDER)
            or type(value['control_index']) is not list
            or len(value['control_index']) != 221
            or canonical(value['scope_manifest']) != manifest_frozen):
        raise ValueError('complete original221-only evidence envelope required')
    for number, name in enumerate(EVIDENCE_BANK_ORDER):
        check()
        row = value['bank_roots'][number]
        if (type(row) is not dict or len(row) != 2
                or any(type(key) is not str for key in row)
                or set(row) != {'bank_key', 'root'}
                or type(row['bank_key']) is not str or row['bank_key'] != name
                or type(row['root']) is not int or row['root'] != packed_roots[name]
                or not 0 <= row['root'] < len(value['nodes'])):
            raise ValueError('ordered genuine encoded bank roots required')
    offset = 0
    for population, ids, groups, bank_role, subject_role, scope in EVIDENCE_SCOPE_TEMPLATE:
        check()
        bank_key = 'explicit16' if population in ('point-kernel13', 'point-kernel-safety3') else population
        prefix = ([bank_key, 'raw_population', 'controls'] if population == 'point-kernel13' else
                  [bank_key, 'additional_population', 'controls'] if population == 'point-kernel-safety3' else
                  [bank_key, 'controls'])
        for number, control_id in enumerate(ids):
            check()
            row = value['control_index'][offset]
            offset += 1
            if (type(row) is not dict or len(row) != 5
                    or any(type(key) is not str for key in row)
                    or set(row) != {'population', 'id', 'bank_key', 'path', 'row_ref'}
                    or type(row['population']) is not str or row['population'] != population
                    or type(row['id']) is not str or row['id'] != control_id
                    or type(row['bank_key']) is not str or row['bank_key'] != bank_key
                    or type(row['path']) is not list or len(row['path']) != len(prefix) + 1
                    or any(type(part) is not str for part in row['path'][:-1])
                    or type(row['path'][-1]) is not int
                    or row['path'] != prefix + [number]
                    or type(row['row_ref']) is not int
                    or not 0 <= row['row_ref'] < len(value['nodes'])):
                raise ValueError('complete original221 anchor identities required')
    measured = value['canonical_qualification']
    if (type(measured) is not dict or len(measured) != 2
            or any(type(key) is not str for key in measured)
            or set(measured) != {'bytes', 'sha256'}
            or type(measured['bytes']) is not int or measured['bytes'] < 1
            or type(measured['sha256']) is not str or len(measured['sha256']) != 64
            or any(c not in '0123456789abcdef' for c in measured['sha256'])):
        raise ValueError('complete charged canonical readback identity required')
    # Codec.finish already performs the charged canonical count/hash stream.
    # This checks metadata only, never decodes nodes or feeds them to science.


def main(plan_path, actual_dir, root_start):
    if not (sys.platform == 'darwin' and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode and os.getpid() == os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start)
            and 0 <= root_start <= time.monotonic()):
        raise ValueError('isolated owned Darwin child and genuine parent start required')
    began = root_start
    directory, plan_path = Path(actual_dir), Path(plan_path)
    study = Path(__file__).resolve().parents[1]
    plan_pin = raw_pin(plan_path)
    plan_bytes = plan_path.read_bytes()
    if byte_identity(plan_bytes) != {key: plan_pin[key] for key in ('bytes', 'sha256')}:
        raise ValueError('stable complete plan body required')
    plan = json.loads(plan_bytes)
    del plan_bytes
    if not (plan['schema'] == 'proof-search-case-once-plan-v1'
            and plan['experiment'] == EXPERIMENT and plan['stage'] == 'qualify'
            and plan['case_id'] == EXPERIMENT + '-qualify-0'
            and plan['required_upstream_ids'] == []
            and not any(key in plan for key in ('donor_index', 'input_slot', 'target_index',
                'target_id', 'arm', 'query', 'certificate', 'search_configuration'))
            and directory.is_absolute() and directory.resolve() == directory
            and not directory.is_symlink() and directory.is_dir()
            and directory == study / 'actual' / plan['case_id']
            and plan['actual_dir'] == str(directory)
            and plan_path.parent == study / 'root' / 'plans'
            and Path(plan['worker_path']) == Path(__file__).resolve()):
        raise ValueError('fresh exact qualification-only case and owned paths required')
    if not (type(plan['limits']) is dict and set(plan['limits']) == set(CAPS)
            and all(type(plan['limits'][key]) is int and plan['limits'][key] == value
                    for key, value in CAPS.items())):
        raise ValueError('all ten original exact whole caps required')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'], CAPS['physical_bytes']))
    consumed = json.loads((directory / 'CONSUMED.json').read_bytes())
    if not (consumed['schema'] == 'proof-search-case-consumed-v1'
            and consumed['plan_sha256'] == plan_pin['sha256']
            and consumed['case_id'] == plan['case_id']
            and type(consumed['uses']) is int and consumed['uses'] == 1):
        raise ValueError('fresh exact once consumption required')
    state = dict(stage='PIN_INTAKE', callbacks=0, first_fault=None, first_fault_monotonic_ns=None, stages=[], versions={})
    primary, guards, source_unchanged = None, [], False
    control_subject_bindings = None
    acquisition_producer_pin = selector_pin = None
    qualification = input_freeze = search_result = subject_receipt = reference_receipt = point_receipt = None
    frozen_query = candidate_bytes = scientific = None
    frozen_queries = None
    compiler_diagnostics = compiler_population = None
    work_snapshots = []
    evidence_encoder = evidence_controls = evidence_manifest = evidence_limits = None
    reference_integer_policy = None
    packed_bank_roots = {}
    selected_bank = nonwrapper_bank = signed_bank = occurrence_bank = explicit = None
    output_rejection = None

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        fault = None
        if state['callbacks'] > CAPS['root_callbacks']:
            fault = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic() - began >= CAPS['work_seconds']:
            fault = RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            fault = RootBudget('strict Python whole high-water ceiling')
        if fault is not None:
            state['first_fault_monotonic_ns'] = time.monotonic_ns()
            state['first_fault'] = fault
            raise fault

    def stage(name, operation):
        check()
        state['stage'] = name
        item = dict(name=name, began=time.monotonic() - began, status='STARTED')
        state['stages'].append(item)
        answer = operation()
        check()
        item.update(status='COMPLETED', seconds=time.monotonic() - began - item['began'])
        return answer

    def verify_files(cooperative):
        for row in guards:
            if cooperative:
                check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed closed Source/input: ' + row['path'])

    def canonical(value):
        check()
        answer = serialize(value, CAPS['result_bytes'])
        check()
        return answer

    def ordered_rows(value, name, counts, row_style):
        check()
        ids = list(CONTROL_IDS[name])
        if not (type(value) is dict and value.get('control_ids') == ids
                and type(value.get('controls')) is list
                and [row.get('id') if type(row) is dict else None for row in value['controls']] == ids
                and type(value.get('counts')) is dict
                and set(value['counts']) == set(counts)
                and all(type(value['counts'][key]) is int and value['counts'][key] == expected
                        for key, expected in counts.items())):
            raise ValueError('complete ordered population/counts required: ' + name)
        for row in value['controls']:
            check()
            if not ((row.get('passed') is True) if row_style == 'passed' else
                    (row.get('status') == 'PASSED')):
                raise ValueError('complete positive control row required: ' + name)

    def bank(name, operation, schema, counts, row_style='passed', population=None):
        result = stage('CONTROLS ' + name, operation)
        if not (type(result) is dict and result.get('schema') == schema
                and result.get('complete') is True
                and (population is None or result.get('population') == population)):
            raise ValueError('complete exact bank carrier required: ' + name)
        ordered_rows(result, name, counts, row_style)
        return result


    def pack_completed(name):
        # Called only after the genuine raw bank's last existing result use.
        check()
        value = qualification[name]
        ref = stage('EVIDENCE_PACK ' + name,
                    lambda: evidence_encoder.add_bank(name, value))
        if type(ref) is not int or ref < 0:
            raise ValueError('exact encoded bank reference required')
        packed_bank_roots[name] = ref
        del qualification[name]
        del value
        check()

    def retire_positive_references():
        # Callback-free retirement only, no codec close/getter/pool inspection.
        nonlocal qualification, scientific, evidence_encoder, evidence_controls
        nonlocal packed_bank_roots, selected_bank, nonwrapper_bank, signed_bank
        nonlocal occurrence_bank, explicit
        qualification = scientific = evidence_encoder = evidence_controls = None
        packed_bank_roots = None
        selected_bank = nonwrapper_bank = signed_bank = occurrence_bank = explicit = None

    def serialize_positive(value):
        # Exactly one complete positive-whole pass; no eager size remeasurement.
        nonlocal output_rejection
        body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                           separators=(',', ':')) + '\n').encode('ascii')
        if len(body) > CAPS['result_bytes']:
            if output_rejection is None:
                output_rejection = dict(schema='FPC-first-rejected-output-size-v1',
                    attempt_kind='COMPLETE_POSITIVE_WHOLE_RESULT', attempt_ordinal=1,
                    exact_attempt_bytes=len(body), cap_bytes=CAPS['result_bytes'])
            raise RootBudget('complete output ceiling; no truncation or prefix authority')
        return body

    try:
        check()
        if type(plan['files']) is not list or not plan['files']:
            raise ValueError('closed nonempty exact guards required')
        guards = [pin_fields(row) for row in plan['files']]
        if len({row['path'] for row in guards}) != len(guards):
            raise ValueError('unique guarded paths required')
        by_path = {row['path']: row for row in guards}
        if type(plan['module_pins']) is not dict or set(plan['module_pins']) != set(MODULE_ROLES):
            raise ValueError('exact thirty-eight namespace roles required')
        module_pins = {role: pin_fields(plan['module_pins'][role]) for role in MODULE_ROLES}
        fixed = dict(FIXED_PINS, controller_bank=CONTROLLER_BANK_PIN, conclusion_index_bank=CONCLUSION_BANK_PIN)
        acquisition_producer_pin, selector_pin = module_pins['producer'], module_pins['selector']
        for role, row in module_pins.items():
            check()
            if by_path.get(row['path']) != row or (row['bytes'], row['sha256']) != fixed[role]:
                raise ValueError('exact pinned current module in closed guards required: ' + role)
        control_subject_bindings = {
            'tiny-full-provider10': {'provider': module_pins['provider']},
            'full-frame-controller10': {'controller': module_pins['controller'], 'provider': module_pins['provider']},
            'constructor-index14': {'provider': module_pins['legacy_provider']},
            'fixed-free-slot8': {'provider': module_pins['provider'], 'baseline_provider': module_pins['legacy_provider']},
            'matched-controller8': {role: module_pins[role] for role in
                ('matched_point_controller', 'csp_controller', 'provider')},
            'selector6': {'selector': module_pins['selector']},
            'nonwrapper_selector6': {'selector': module_pins['nonwrapper_selector']},
            'signed_propositional8_successor_v2': {role: module_pins[key] for role, key in
                (('producer', 'signed_producer'), ('compiler', 'signed_compiler'),
                 ('checker', 'checker'), ('builders', 'builders'), ('reference', 'reference'),
                 ('encoder', 'tiny_encoder'))},
            'occurrence_diagnostics9': {role: module_pins[key] for role, key in
                (('producer', 'signed_producer'), ('compiler', 'signed_compiler'),
                 ('checker', 'checker'), ('builders', 'builders'), ('reference', 'reference'),
                 ('encoder', 'tiny_encoder'))}}
        control_subject_bindings['lossless_evidence_codec8_v1'] = {
            'codec': module_pins['evidence_codec'], 'bank': module_pins['evidence_codec_bank']}
        for key in ('protocol', 'python', 'declarations', 'target_authority',
                    'explicit_raw_models', 'tiny_provider_declarations', 'conclusion_index_fixtures',
                    'fixed_free_slot_fixtures', 'matched_controller_fixtures', 'nonwrapper_selector_fixtures'):
            row = pin_fields(plan[key])
            if by_path.get(row['path']) != row:
                raise ValueError('all runtime/phase pins must be guarded')
        for key, expected in (('declarations', DECLARATIONS_PIN), ('target_authority', AUTHORITY_PIN),
                              ('explicit_raw_models', RAW13_PIN), ('tiny_provider_declarations', TINY_INPUT_PIN),
                              ('conclusion_index_fixtures', CONCLUSION_FIXTURES_PIN),
                              ('fixed_free_slot_fixtures', FIXED_SLOT_FIXTURES_PIN),
                              ('matched_controller_fixtures', MATCHED_FIXTURES_PIN),
                              ('nonwrapper_selector_fixtures', (24228, '08770968af3ed99206e48c2b8d93be6471c5b730f96a091bf1ea688465c12082'))):
            if (plan[key]['bytes'], plan[key]['sha256']) != expected:
                raise ValueError('unchanged exact public literal input required: ' + key)
        if (by_path.get(str(Path(__file__).resolve())) != raw_pin(Path(__file__).resolve())
                or raw_pin(Path(sys.executable).resolve()) != pin_fields(plan['python'])):
            raise ValueError('exact current worker/isolated runtime required')
        populations = plan['control_populations']
        if type(populations) is not dict or set(populations) != set(CONTROL_IDS):
            raise ValueError('all complete scoped populations required')
        for name, ids in CONTROL_IDS.items():
            check()
            if type(populations[name]) is not dict or populations[name].get('control_ids') != list(ids):
                raise ValueError('exact unchanged ordered scoped ID vector required')
        protocol = json.loads(Path(plan['protocol']['path']).read_bytes())
        required = {'schema', 'experiment', 'limits', 'module_pins', 'control_populations', 'job_recipes'}
        if not (type(protocol) is dict and required <= set(protocol)
                and set(protocol) <= required | {'metadata'}
                and ('metadata' not in protocol or type(protocol['metadata']) is dict)
                and protocol['schema'] == PROTOCOL_SCHEMA and protocol['experiment'] == EXPERIMENT
                and canonical(protocol['limits']) == canonical(CAPS)
                and canonical(protocol['module_pins']) == canonical(plan['module_pins'])
                and canonical(protocol['control_populations']) == canonical(populations)):
            raise ValueError('exact current prospective protocol association required')
        declarations = json.loads(Path(plan['declarations']['path']).read_bytes())
        if not (declarations.get('schema') == 'FPC-H1-six-public-development-target-declarations-v1'
                and type(declarations.get('targets')) is list and len(declarations['targets']) == 6):
            raise ValueError('exact original six-declaration carrier required')
        # Original six statements remain guarded old-control provenance only.
        # No original target ID/statement chooses or supplies an acquisition input.
        expected_recipes = [dict(case_id=EXPERIMENT + '-qualify-0', stage='qualify')]
        if canonical(protocol['job_recipes']) != canonical(expected_recipes):
            raise ValueError('one exact qualification-only recipe required')
        verify_files(True)
        modules = {}
        for role in MODULE_ROLES:
            name = 'explicit_point_literal_oracle_v1' if role == 'explicit_oracle' else (
                'owned_point_frame_worker_' + role + '_v1')
            modules[role] = stage('IMPORT ' + role,
                lambda role=role, name=name: load_exact(module_pins[role], name, check))
            state['versions'][role] = modules[role].VERSION
        if not (modules['provider'].VERSION == 'FPC-POINT-FULL-FRAME-PROVIDER-v1'
                and modules['provider'].IMPLEMENTATION_REVISION == 'FPC-POINT-FULL-FRAME-PROVIDER-implementation-v6'
                and 'dependency-rebind-classification' in modules['provider'].FEATURES
                and 'conclusion-constructor-index' in modules['provider'].FEATURES
                and 'constrained-output-slots' in modules['provider'].FEATURES
                and modules['legacy_provider'].VERSION == 'FPC-POINT-FULL-FRAME-PROVIDER-v1'
                and modules['legacy_provider'].IMPLEMENTATION_REVISION == 'FPC-POINT-FULL-FRAME-PROVIDER-implementation-v4'
                and modules['controller_bank'].VERSION == 'L-full-frame-controller-controls-v2'
                and modules['conclusion_index_bank'].VERSION == 'L-conclusion-index-independent-controls-v2'
                and modules['fixed_slot_bank'].VERSION == 'L-fixed-free-slot-independent-controls-v2'
                and modules['matched_point_controller'].VERSION == 'FPC-POINT-FRAME-CONTROLLER-v3'
                and modules['csp_controller'].VERSION == 'FPC-ROW-CSP-CONTROLLER-v1'
                and modules['csp_controller'].IMPLEMENTATION_REVISION == 'FPC-ROW-CSP-CONTROLLER-implementation-v2'
                and modules['matched_controller_bank'].VERSION == 'L-matched-row-controller-controls-v2'
                and modules['matched_point_controller'].DIAGNOSTIC_FIELDS == WORKER_DIAGNOSTIC_FIELDS
                and modules['csp_controller'].DIAGNOSTIC_FIELDS == WORKER_DIAGNOSTIC_FIELDS
                and modules['producer'].VERSION == 'FPC-H1-OBLIGATION-PRODUCER-v2'
                and modules['tiny_encoder'].VERSION == 'L-tiny-FPC-query-encoder-v1'
                and modules['selector'].VERSION == 'FPC-TWO-DONOR-INPUT-SELECTOR-v1'
                and modules['selector_bank'].VERSION == 'L-two-donor-input-selector-controls-v1'
                and modules['nonwrapper_selector'].VERSION == 'FPC-NONWRAPPER-TWO-DONOR-INPUT-SELECTOR-v1'
                and modules['nonwrapper_selector_bank'].VERSION == 'FPC-NONWRAPPER-SELECTOR-INDEPENDENT-CONTROLS-v1'
                and modules['signed_compiler'].VERSION == 'FPC-H1-SIGNED-COMPILER-v2'
                and modules['signed_compiler'].EMITTER_VERSION == 'FPC-H1-SIGNED-PRIMITIVE-EMITTERS-v1'
                and modules['signed_producer'].VERSION == 'FPC-H1-SIGNED-PROPOSITIONAL-PRODUCER-v2'
                and modules['signed_bank'].VERSION == 'FPC-SIGNED-PROPOSITIONAL-INDEPENDENT-CONTROLS-v2'
                and modules['occurrence_bank'].VERSION == 'FPC-OCCURRENCE-DIAGNOSTIC-INDEPENDENT-CONTROLS-v1'
                and modules['evidence_codec'].VERSION == 'FPC-LOSSLESS-QUALIFICATION-EVIDENCE-CODEC-v1'
                and modules['evidence_codec_bank'].VERSION == 'FPC-LOSSLESS-EVIDENCE-INDEPENDENT-CONTROLS-v1'):
            raise ValueError('authenticated provider and current controller/index-bank revisions required')
        declaration_frozen = canonical(declarations)

        kernel_modules = {role: modules[role] for role in ('checker', 'builders', 'reference')}
        logical_modules = {role: modules[role] for role in ('checker', 'builders')}
        qualification = {}

        # The original codec role and all36 scientific namespaces stay exact.
        check()
        max_digits = sys.get_int_max_str_digits()
        if type(max_digits) is not int or max_digits < 0:
            raise ValueError('genuine effective integer reference policy required')
        reference_integer_policy = ('FPC-original-json-integer-policy-v1', max_digits)
        evidence_manifest = _evidence_scope_manifest(check)
        evidence_limits = dict(CAPS)
        evidence_manifest_frozen = canonical(evidence_manifest)
        evidence_limits_frozen = canonical(evidence_limits)
        evidence_controls = bank('lossless_evidence_codec8_v1', lambda:
            modules['evidence_codec_bank'].run_lossless_evidence_controls(
                modules['evidence_codec'], scope_manifest=evidence_manifest,
                limits=evidence_limits, reference_integer_policy=reference_integer_policy,
                check=check), 'FPC-lossless-evidence-independent-controls-v1',
            dict(groups=8, passed=8, failed=0), 'passed', 'lossless_evidence_codec8_v1')
        _validate_evidence_controls(evidence_controls, check)
        if (canonical(evidence_manifest) != evidence_manifest_frozen
                or canonical(evidence_limits) != evidence_limits_frozen):
            raise ValueError('codec controls mutated exact caller manifest or caps')
        evidence_encoder = stage('EVIDENCE_OPEN', lambda:
            modules['evidence_codec'].open_encoder(scope_manifest=evidence_manifest,
                profile='EXISTING_JSON221_V1', limits=evidence_limits, check=check,
                reference_integer_policy=reference_integer_policy))

        qualification['baseline56'] = bank('baseline56', lambda:
            modules['baseline_bank'].run_search_controls(search=modules['baseline_search'],
                codec=modules['codec'], modules=kernel_modules, check=check),
            'FPC-H1-independent-search-controls-v1', dict(total=56, passed=56, failed=0))
        pack_completed('baseline56')
        qualification['obligation47'] = bank('obligation47', lambda:
            modules['obligation_bank'].run_obligation_controls(modules['producer'], modules=kernel_modules, check=check),
            'FPC-H1-independent-obligation-controls-v1', dict(groups=47, passed=47, failed=0))
        pack_completed('obligation47')
        qualification['intro_integration1'] = bank('intro_integration1', lambda:
            modules['intro_bank'].run_intro_integration_control(modules['producer'], modules=kernel_modules, check=check),
            'FPC-H1-obligation-INTRO-integration-control-v1', dict(groups=1, passed=1, failed=0))
        pack_completed('intro_integration1')
        qualification['regression2'] = bank('regression2', lambda:
            modules['regression_bank'].run_obligation_regression_controls(modules['producer'], modules=kernel_modules, check=check),
            'FPC-H1-obligation-two-defect-regressions-v1', dict(groups=2, passed=2, failed=0))
        pack_completed('regression2')
        qualification['point20'] = bank('point20', lambda:
            modules['point_bank'].run_point_row_controls(modules['point_adapter'], builders=modules['builders'], check=check),
            'FPC-H1-point-row-independent-controls-v1', dict(groups=20, passed=20, failed=0))
        pack_completed('point20')
        raw_models = json.loads(Path(plan['explicit_raw_models']['path']).read_bytes())
        tiny_declarations = json.loads(Path(plan['tiny_provider_declarations']['path']).read_bytes())
        conclusion_fixtures = json.loads(Path(plan['conclusion_index_fixtures']['path']).read_bytes())
        raw_models_frozen, tiny_frozen = canonical(raw_models), canonical(tiny_declarations)
        conclusion_frozen = canonical(conclusion_fixtures)
        fixed_slot_fixtures = json.loads(Path(plan['fixed_free_slot_fixtures']['path']).read_bytes())
        fixed_slot_frozen = canonical(fixed_slot_fixtures)
        matched_fixtures = json.loads(Path(plan['matched_controller_fixtures']['path']).read_bytes())
        matched_frozen = canonical(matched_fixtures)
        explicit = stage('CONTROLS explicit-point16', lambda:
            modules['explicit_bank'].run_point_kernel_controls(modules['explicit_kernel'], raw_models=raw_models, check=check))
        if not (type(explicit) is dict and explicit.get('schema') == 'independent-explicit-point-controls-v1'
                and explicit.get('complete') is True and type(explicit.get('counts')) is dict
                and set(explicit['counts']) == {'raw_groups', 'additional_groups', 'groups', 'passed', 'failed'}
                and all(type(x) is int for x in explicit['counts'].values())
                and explicit['counts'] == dict(raw_groups=13, additional_groups=3, groups=16, passed=16, failed=0)):
            raise ValueError('complete independent explicit16 wrapper required')
        for field, name, count in (('raw_population', 'point-kernel13', 13),
                                   ('additional_population', 'point-kernel-safety3', 3)):
            if explicit[field].get('population') != name:
                raise ValueError('explicit population identity mismatch')
            ordered_rows(explicit[field], name, dict(groups=count, passed=count, failed=0), 'status')
        qualification['explicit16'] = explicit
        pack_completed('explicit16')
        explicit = None
        qualification['tiny-full-provider10'] = bank('tiny-full-provider10', lambda:
            modules['tiny_bank'].run_tiny_provider_controls(modules['provider'], declarations=tiny_declarations,
                oracle=modules['tiny_oracle'], encoder=modules['tiny_encoder'], modules=logical_modules, check=check),
            'independent-tiny-full-FPC-provider-controls-v1', dict(groups=10, passed=10, failed=0),
            'status', 'tiny-full-provider10')
        pack_completed('tiny-full-provider10')
        qualification['full-frame-controller10'] = bank('full-frame-controller10', lambda:
            modules['controller_bank'].run_frame_controller_controls(modules['controller'], provider=modules['provider'],
                declarations=tiny_declarations, row_oracle=modules['tiny_oracle'], frame_oracle=modules['frame_oracle'],
                encoder=modules['tiny_encoder'], modules=kernel_modules, check=check),
            'independent-full-frame-controller-controls-v1', dict(groups=10, passed=10, failed=0),
            'status', 'full-frame-controller10')
        if qualification['full-frame-controller10'].get('version') != 'L-full-frame-controller-controls-v2':
            raise ValueError('complete current controller-bank-v2 receipt required')
        pack_completed('full-frame-controller10')
        qualification['constructor-index14'] = bank('constructor-index14', lambda:
            modules['conclusion_index_bank'].run_conclusion_index_controls(modules['legacy_provider'],
                fixtures=conclusion_fixtures, declarations=tiny_declarations, oracle=modules['tiny_oracle'],
                encoder=modules['tiny_encoder'], modules=kernel_modules, check=check),
            'independent-conclusion-index-controls-v1', dict(groups=14, passed=14, failed=0),
            'status', 'constructor-index14')
        if qualification['constructor-index14'].get('version') != 'L-conclusion-index-independent-controls-v2':
            raise ValueError('complete current constructor-index14 receipt required')
        pack_completed('constructor-index14')
        qualification['fixed-free-slot8'] = bank('fixed-free-slot8', lambda:
            modules['fixed_slot_bank'].run_fixed_free_slot_controls(modules['provider'],
                baseline_provider=modules['legacy_provider'], fixtures=fixed_slot_fixtures,
                encoder=modules['tiny_encoder'], codec=modules['codec'], modules=kernel_modules, check=check),
            'independent-fixed-free-slot-controls-v1', dict(groups=8, passed=8, failed=0),
            'status', 'fixed-free-slot8')
        if qualification['fixed-free-slot8'].get('version') != 'L-fixed-free-slot-independent-controls-v2':
            raise ValueError('complete current fixed-free-slot8 receipt required')
        pack_completed('fixed-free-slot8')
        qualification['matched-controller8'] = bank('matched-controller8', lambda:
            modules['matched_controller_bank'].run_matched_controller_controls(
                modules['csp_controller'], modules['matched_point_controller'], provider=modules['provider'],
                fixtures=matched_fixtures, declarations=tiny_declarations, row_oracle=modules['tiny_oracle'],
                frame_oracle=modules['frame_oracle'], encoder=modules['tiny_encoder'], modules=kernel_modules, check=check),
            'independent-matched-row-controller-controls-v1', dict(groups=8, passed=8, failed=0),
            'status', 'matched-controller8')
        if qualification['matched-controller8'].get('version') != 'L-matched-row-controller-controls-v2':
            raise ValueError('complete matched-controller8 version required')
        pack_completed('matched-controller8')
        qualification['selector6'] = bank('selector6', lambda:
            modules['selector_bank'].run_selector_controls(modules['selector'], check=check),
            'independent-two-donor-input-selector-controls-v1', dict(groups=6, passed=6, failed=0),
            'status', 'selector6')
        selected_bank = qualification['selector6']
        if not (set(selected_bank) == {'schema', 'version', 'population', 'complete',
                    'control_ids', 'controls', 'counts', 'accepted', 'scope'}
                and selected_bank['version'] == 'L-two-donor-input-selector-controls-v1'
                and selected_bank['accepted'] is False
                and all(type(row) is dict and set(row) == {'id', 'status', 'scope', 'evidence'}
                        for row in selected_bank['controls'])):
            raise ValueError('exact nine-field nonadmitting selector6 carrier required')
        pack_completed('selector6')
        selected_bank = None
        nonwrapper_fixtures = json.loads(Path(plan['nonwrapper_selector_fixtures']['path']).read_bytes())
        nonwrapper_frozen = canonical(nonwrapper_fixtures)
        qualification['nonwrapper_selector6'] = bank('nonwrapper_selector6', lambda:
            modules['nonwrapper_selector_bank'].run_nonwrapper_selector_controls(
                modules['nonwrapper_selector'], fixtures=nonwrapper_fixtures, check=check),
            'FPC-nonwrapper-selector-independent-controls-v1', dict(groups=6, passed=6, failed=0),
            'status', 'nonwrapper_selector6')
        nonwrapper_bank = qualification['nonwrapper_selector6']
        if not (set(nonwrapper_bank) == {'schema', 'version', 'population', 'complete', 'control_ids',
                    'controls', 'counts', 'scope', 'limits', 'callbacks'}
                and nonwrapper_bank['version'] == 'FPC-NONWRAPPER-SELECTOR-INDEPENDENT-CONTROLS-v1'
                and type(nonwrapper_bank['limits']) is list
                and all(type(x) is str for x in nonwrapper_bank['limits'])
                and type(nonwrapper_bank['callbacks']) is int and nonwrapper_bank['callbacks'] >= 0
                and all(type(row) is dict and set(row) == {'population', 'id', 'status', 'evidence'}
                    and row['population'] == 'nonwrapper_selector6' for row in nonwrapper_bank['controls'])
                and canonical(nonwrapper_fixtures) == nonwrapper_frozen):
            raise ValueError('exact nonwrapper-selector6 carrier and immutable fixtures required')
        pack_completed('nonwrapper_selector6')
        nonwrapper_bank = None
        if (canonical(raw_models) != raw_models_frozen or canonical(tiny_declarations) != tiny_frozen
                or canonical(declarations) != declaration_frozen
                or canonical(conclusion_fixtures) != conclusion_frozen
                or canonical(fixed_slot_fixtures) != fixed_slot_frozen
                or canonical(matched_fixtures) != matched_frozen):
            raise ValueError('scientific control/codec mutated immutable public declaration input')
        signed_modules = {role: modules[role] for role in ('checker', 'builders', 'reference')}
        compiler_diagnostics = dict(COMPILER_DIAGNOSTIC_INITIAL)
        compiler_diagnostics['snapshot_available'] = False
        compiler_population = 'signed_propositional8_successor_v2'
        qualification['signed_propositional8_successor_v2'] = bank('signed_propositional8_successor_v2', lambda:
            modules['signed_bank'].run_signed_propositional_controls(
                modules['signed_producer'], modules['signed_compiler'], modules=signed_modules,
                encoder=modules['tiny_encoder'], check=check, compiler_diagnostics=compiler_diagnostics),
            'FPC-signed-propositional-independent-controls-v1', dict(groups=8, passed=8, failed=0),
            'status', 'signed_propositional8_successor_v2')
        if (set(signed_modules) != {'checker', 'builders', 'reference'}
                or any(signed_modules[role] is not modules[role] for role in signed_modules)):
            raise ValueError('signed bank mutated exact original module-role projection')
        signed_bank = qualification['signed_propositional8_successor_v2']
        if not (set(signed_bank) == {'schema', 'version', 'population', 'complete', 'control_ids',
                    'controls', 'counts', 'scope', 'limits', 'callbacks'}
                and signed_bank['version'] == 'FPC-SIGNED-PROPOSITIONAL-INDEPENDENT-CONTROLS-v2'
                and type(signed_bank['limits']) is list
                and all(type(x) is str for x in signed_bank['limits'])
                and type(signed_bank['callbacks']) is int and signed_bank['callbacks'] >= 0
                and all(type(row) is dict and set(row) == {'population', 'id', 'status', 'evidence'}
                    and row['population'] == 'signed_propositional8_successor_v2' for row in signed_bank['controls'])):
            raise ValueError('exact signed-propositional8 complete carrier required')
        pack_completed('signed_propositional8_successor_v2')
        signed_bank = None
        compiler_diagnostics['snapshot_available'] = False
        compiler_population = 'occurrence_diagnostics9'
        qualification['occurrence_diagnostics9'] = bank('occurrence_diagnostics9', lambda:
            modules['occurrence_bank'].run_occurrence_diagnostic_controls(
                modules['signed_producer'], modules['signed_compiler'], modules=signed_modules,
                encoder=modules['tiny_encoder'], check=check, compiler_diagnostics=compiler_diagnostics),
            'FPC-occurrence-diagnostic-independent-controls-v1', dict(groups=9, passed=9, failed=0),
            'status', 'occurrence_diagnostics9')
        if (set(signed_modules) != {'checker', 'builders', 'reference'}
                or any(signed_modules[role] is not modules[role] for role in signed_modules)):
            raise ValueError('occurrence bank mutated exact original module-role projection')
        occurrence_bank = qualification['occurrence_diagnostics9']
        if not (set(occurrence_bank) == {'schema', 'version', 'population', 'complete', 'control_ids',
                    'controls', 'counts', 'scope', 'limits', 'callbacks'}
                and occurrence_bank['version'] == 'FPC-OCCURRENCE-DIAGNOSTIC-INDEPENDENT-CONTROLS-v1'
                and type(occurrence_bank['limits']) is list
                and all(type(x) is str for x in occurrence_bank['limits'])
                and type(occurrence_bank['callbacks']) is int and occurrence_bank['callbacks'] >= 0
                and all(type(row) is dict and set(row) == {'population', 'id', 'status', 'evidence'}
                    and row['population'] == 'occurrence_diagnostics9' for row in occurrence_bank['controls'])):
            raise ValueError('exact occurrence-diagnostics9 complete carrier required')
        pack_completed('occurrence_diagnostics9')
        occurrence_bank = None
        if canonical(nonwrapper_fixtures) != nonwrapper_frozen:
            raise ValueError('added bank changed immutable independent selector fixtures')

        qualification = stage('EVIDENCE_FINISH', evidence_encoder.finish)
        _validate_evidence_envelope(qualification, packed_bank_roots,
                                    evidence_manifest_frozen, canonical, check)
        if (canonical(evidence_manifest) != evidence_manifest_frozen
                or canonical(evidence_limits) != evidence_limits_frozen):
            raise ValueError('production codec mutated exact original manifest or caps')
        check()
        evidence_encoder.close()
        evidence_encoder = None
        check()
        scientific = dict(status='COMPLETE_QUALIFICATION_PENDING_ROOT_WHOLE_REVIEW',
            qualification_only=True, accepted=False, proof_admitted=False,
            groups=221, scopes=16, bank_wrappers=15,
            original_scoped_groups=198, additive_nonwrapper_selector_groups=6,
            additive_signed_groups=8, additive_occurrence_groups=9,
            evidence_codec_qualification=evidence_controls, additive_codec_groups=8,
            proposed_whole_composition=dict(groups=229, scopes=17, bank_wrappers=16,
                original_scientific_roles=36, additive_transport_roles=2,
                status='SOURCE_PROPOSAL_PENDING_ROOT_WHOLE_ACCEPTANCE'),
            scope='Complete control qualification only; no research query, donor proof, selected '
                  'input authority, candidate export, library, transfer or GCTS/RL result. '
                  'Root/C whole resource and independent review gates remain mandatory.')
        check()
    except BaseException as error:
        if type(error) is RootBudget and state['first_fault'] is None:
            state['first_fault'] = error
        primary = state['first_fault'] if state['first_fault'] is not None else error
    finally:
        try:
            verify_files(primary is None)
            source_unchanged = bool(guards)
        except BaseException as error:
            source_unchanged = False
            if primary is None:
                primary = state['first_fault'] if state['first_fault'] is not None else error

    if primary is not None:
        retire_positive_references()

    # Freeze once, after algorithm/guard unwind and before first serialization.
    # Late receipt rebuilds reuse this owned copy and never inspect the live sink.
    try:
        work_snapshots = _compiler_snapshot(compiler_diagnostics, compiler_population)
    except BaseException as error:
        if primary is None:
            primary = state['first_fault'] if state['first_fault'] is not None else error

    if primary is not None:
        retire_positive_references()

    def receipt():
        return dict(schema='FPC-lossless-evidence-qualification-whole-worker-v1',
            case_id=plan['case_id'], stage='qualify', worker_version=VERSION,
            status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            stages=state['stages'], callbacks=state['callbacks'], elapsed_seconds=time.monotonic() - began,
            source_unchanged=source_unchanged, python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            native_peak_bytes=0, native_requests_started=0, native_queries=[],
            native_transport=dict(closed=True, all_reaped=True, native_exit_code=0,
                native_high_water_bytes=0, subprocesses_started=0, scope='VACUOUS_NO_NATIVE_SUBPROCESS'),
            guard_compilations=[], work_snapshots=work_snapshots, qualification_complete=primary is None,
            qualification_result=qualification if primary is None else None,
            input_freeze=None, search_result=None, subject_receipt=None, reference_receipt=None, point_receipt=None,
            scientific_result=scientific if primary is None else None,
            error=None if primary is None else dict(type=type(primary).__name__, message=str(primary),
                traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,
            first_fault_monotonic_ns=state['first_fault_monotonic_ns'],
            output_rejection=output_rejection, old_qualification_reused=False,
            component_versions=state['versions'], control_subject_bindings=control_subject_bindings,
            scope='Fresh complete infrastructure qualification only; no research target, donor search, '
                  'candidate certificate, proof admission, extractor/library/transfer/GCTS/RL authority. '
                  'Old consumed cohort remains STOP. Every positive payload is withheld on whole failure.')

    try:
        if primary is None:
            check()
        body = (serialize_positive(receipt()) if primary is None else
                serialize(receipt(), CAPS['result_bytes']))
        if primary is None:
            check()
    except BaseException as error:
        if primary is None:
            if type(error) is RootBudget and state['first_fault'] is None:
                state['first_fault'] = error
            primary = state['first_fault'] if state['first_fault'] is not None else error
        retire_positive_references()
        body = serialize(receipt(), CAPS['result_bytes'])
    result_path = directory / ('result.json' if primary is None else 'failure.json')
    write_body(result_path, body)
    del body
    result_pin = raw_pin(result_path)
    header = dict(schema='proof-search-case-worker-header-v1', case_id=plan['case_id'],
        status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'], seconds=time.monotonic() - began,
        python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0, source_unchanged=source_unchanged,
        native_closed_and_reaped=True, first_Root_fault=state['first_fault'] is not None,
        result=result_pin, native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory / 'worker-header.json', serialize(header, CAPS['log_bytes']))
    print(json.dumps(dict(case_id=plan['case_id'], status=header['status'], callbacks=state['callbacks'],
                          seconds=time.monotonic() - began)))
    return 0 if (primary is None and source_unchanged
        and time.monotonic() - began < CAPS['positive_seconds']
        and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < CAPS['memory_bytes']) else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: fpc_lossless_evidence_qualification_worker_v3.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1], sys.argv[2], float(sys.argv[3])))
