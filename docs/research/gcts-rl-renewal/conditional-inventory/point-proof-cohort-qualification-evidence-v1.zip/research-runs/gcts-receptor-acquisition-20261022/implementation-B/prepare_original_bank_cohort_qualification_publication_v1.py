"""Administrative original-bank cohort report packaging; no scientific imports.

Inert Source until separately authorized. Only four publication targets; no Git,
deployment, primary index/reader, protected active state, proof or control calls.
"""
from pathlib import Path
import argparse
import binascii
import hashlib
import html
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1] / 'root'
REPO = ROOT.parents[2]
BASE = ROOT / 'publication-lossless-qualification-v3'
P2 = ROOT.parents[1] / 'gcts-batch-20261020' / 'publisher-recovery-6338a77'
OUTPUT = ROOT / 'publication-original-bank-cohort-v1'
PAYLOAD = P2 / 'publication-payload-original-bank-cohort-v1'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-search-v1.html', 'point-proof-parallel-progress-v1.html',
         'point-proof-cohort-qualification-data-v1.json',
         'point-proof-cohort-qualification-evidence-v1.zip')
BASE_PINS = {
    NAMES[0]: (60270, '66166c112277b747e7ae234d9cbde1c212e5045a18c8f3093db00eabbf231cdb'),
    NAMES[1]: (9366, '28c57e2406af9a7e683bd8a00f5df1e2a365da56a24c3b32633b72ad8b8f0405')}
HISTORY_PINS = {
    'point-proof-lossless-qualification-data-v1.json':
        (153095, 'a51cf1451a7b28c3492d17bb2e078a63d24ce131bf8df5f1cdb7109901aa7e5e'),
    'point-proof-lossless-qualification-evidence-v1.zip':
        (2681920, '5c989b772429adac253a47843f5f220371458792193fa4a192ecad9c9910d701')}
NEGATIVE_CASES = tuple('signed-propositional-lossless-evidence-whole-qualification-v%d-qualify-0' % i
                       for i in (1, 2, 3))
CATALOG_FIELDS = ('schema', 'cohort_id', 'evidence_profile', 'status', 'reviewed',
    'actual_count', 'new_research_proofs', 'Root_gate', 'issued_utc',
    'current_plain_observation', 'next_scientific_step', 'prior_negative_cases',
    'archive_files', 'disposition_records')
HEADLINES = {
    'SOURCE_ONLY': 'Original-bank cohort: Source work only.',
    'PREPARED': 'Original-bank cohort: prepared, not executed.',
    'COMPLETE': 'Original-bank cohort: complete qualification admitted.',
    'NEGATIVE': 'Original-bank cohort: whole attempt not admitted.'}
FIXED_EXPLANATIONS = {
    'SOURCE_ONLY': 'No cohort actual or passing control result is claimed. The new caller and evidence layout are Source work only.',
    'PREPARED': 'The cohort is prepared for a separately authorized fresh once run. Preparation is not execution or qualification.',
    'COMPLETE': 'The Root-owned catalog records external admission of the complete finite infrastructure cohort. This is not a theorem, research proof or learned family result.',
    'NEGATIVE': 'The Root-owned catalog records a whole negative. Earlier stage labels or provisional bank files supply no admitted prefix, cohort or proof.'}


def rawpin(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def memberpin(body):
    return dict(**rawpin(body), crc32='%08x' % (binascii.crc32(body) & 0xffffffff))


def emit(path, body):
    assert not path.exists()
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as stream:
        assert stream.write(body) == len(body)
    temporary.replace(path)


def jsonbody(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode('ascii')


def esc(value):
    return html.escape(str(value), quote=True)


def checked_ref(ref):
    assert type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}
    assert type(ref['path']) is str and type(ref['bytes']) is int and ref['bytes'] >= 0
    assert type(ref['sha256']) is str and len(ref['sha256']) == 64
    assert all(c in '0123456789abcdef' for c in ref['sha256'])
    path = Path(ref['path'])
    assert path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink()
    assert path.is_relative_to(REPO) and not any('.partial' in part for part in path.parts)
    assert not any(p in ('.git', '.gcts-active') for p in path.parts)
    # Only the two explicitly pinned secondary reports are read separately.
    # An evidence allowlist cannot introduce any HTML reader/index or script.
    assert path.suffix.lower() not in ('.html', '.htm', '.js', '.css') and path.name.lower() != 'index.html'
    return path


def read_catalog(path):
    assert path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink()
    assert path.parent == ROOT and path.suffix == '.json' and '.partial' not in path.name
    body = path.read_bytes()
    cat = json.loads(body)
    assert type(cat) is dict and set(cat) == set(CATALOG_FIELDS)
    assert cat['schema'] == 'Root-original-bank-cohort-publication-catalog-v1'
    assert cat['cohort_id'] == 'signed-propositional-original-bank-cohort-v1'
    assert cat['evidence_profile'] == 'ORIGINAL_BANK_FILES229_V1'
    assert type(cat['status']) is str and cat['status'] in HEADLINES and cat['reviewed'] is True
    for field in ('issued_utc', 'current_plain_observation', 'next_scientific_step'):
        assert type(cat[field]) is str and cat[field]
    assert type(cat['actual_count']) is int and type(cat['new_research_proofs']) is int
    assert cat['new_research_proofs'] == 0
    assert cat['prior_negative_cases'] == list(NEGATIVE_CASES)
    if cat['status'] in ('SOURCE_ONLY', 'PREPARED'):
        assert cat['actual_count'] == 0 and cat['Root_gate'] == 'NONE'
    elif cat['status'] == 'COMPLETE':
        assert cat['actual_count'] == 1 and cat['Root_gate'] == 'ADMITTED_COHORT229'
    else:
        assert cat['actual_count'] == 1 and cat['Root_gate'] == 'FAILED_COHORT_NOT_ADMITTED'
    assert type(cat['archive_files']) is list and cat['archive_files']
    assert type(cat['disposition_records']) is list and cat['disposition_records']
    paths = []
    for ref in cat['archive_files']:
        item = checked_ref(ref)
        assert item != path and item not in paths
        paths.append(item)
    for ref in cat['disposition_records']:
        item = checked_ref(ref)
        assert ref in cat['archive_files'] and item.is_relative_to(ROOT.parent)
    assert any(checked_ref(ref).parent == ROOT for ref in cat['disposition_records'])
    if cat['status'] in ('COMPLETE', 'NEGATIVE'):
        assert any(checked_ref(ref).parent == ROOT.parent / 'review-C'
                   for ref in cat['disposition_records'])
    return body, cat


def summary_section(cat):
    status = cat['status']
    return ('<section class="panel" id="original-bank-cohort-current">'
        '<p class="status">' + esc(status.replace('_', ' ')) + '</p>'
        '<h2>Original-bank cohort: current disposition</h2><p><strong>'
        + esc(HEADLINES[status]) + '</strong> ' + esc(cat['current_plain_observation']) + '</p>'
        '<p>' + esc(FIXED_EXPLANATIONS[status]) + '</p>'
        '<div class="grid"><article class="card"><h3>Same finite obligations</h3>'
        '<p>All \\(221\\) original groups plus \\(8\\) separate transport groups remain: '
        '\\(229\\) groups, \\(17\\) populations, \\(16\\) original wrapper returns and '
        '\\(38\\) exact module roles. Scope labels and subjects remain distinct.</p></article>'
        '<article class="card"><h3>New evidence unit</h3><p>One fresh serial child keeps '
        'the original calls and guards. Complete ordinary JSON returns are saved separately; '
        'a small manifest links all of them. The former combined evidence envelope is not required '
        'for this new profile.</p></article>'
        '<article class="card"><h3>One whole gate</h3><p>Earlier files are provisional until '
        'every obligation, complete readback, resource and custody gate is accepted externally. '
        'Failure admits no prefix. The three earlier whole negatives stay negative.</p></article></div>'
        '<p class="caption">This changes evidence layout and budget accounting. Each bank '
        'body is bounded by \\(48\\,\\mathrm{MiB}\\), the entire positive result by '
        '\\(4\\,\\mathrm{MiB}\\), and bank files plus result by \\(119\\,\\mathrm{MiB}\\). '
        'The stronger runner bound counts all inner files against \\(119\\,\\mathrm{MiB}\\); '
        'the observer retains the \\(128\\,\\mathrm{MiB}\\) physical bound. Original work, '
        'memory, callback and custody caps remain. This is no guaranteed-fit partition.</p>'
        '<p>No new mathematical theorem, research proof, reusable receptor family, learned '
        'inventory or GCTS/RL benefit follows from infrastructure qualification.</p>'
        '<p><strong>Next scientific step.</strong> ' + esc(cat['next_scientific_step']) + '</p>'
        '<p><a href="point-proof-cohort-qualification-data-v1.json">Current catalog and member hashes</a> '
        '&middot; <a href="point-proof-cohort-qualification-evidence-v1.zip">Current complete evidence archive</a> '
        '&middot; <a href="point-proof-search-v1.html#original-bank-cohort-current">Research notebook</a></p>'
        '<p class="caption">Root-owned catalog: ' + esc(cat['issued_utc']) + '. '
        'Sources and observed files are read administratively; this packaging helper imports '
        'or reruns no scientific code. Source-only and prepared states contain no runtime result.</p></section>')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--catalog', required=True)
    args = parser.parse_args()
    catalog_path = Path(args.catalog)
    catalog_body, cat = read_catalog(catalog_path)
    bases = {}
    for name, expected in BASE_PINS.items():
        path = BASE / name
        assert path.is_file() and not path.is_symlink()
        body = path.read_bytes()
        assert rawpin(body) == dict(bytes=expected[0], sha256=expected[1])
        bases[name] = body
    history = []
    for name, expected in HISTORY_PINS.items():
        body = (BASE / name).read_bytes()
        assert rawpin(body) == dict(bytes=expected[0], sha256=expected[1])
        history.append(dict(path=PREFIX + name, **rawpin(body)))
    assert not OUTPUT.exists() and not PAYLOAD.exists() and P2.is_dir()
    assert all(not (P2 / (PREFIX + name)).exists() for name in NAMES[2:])
    OUTPUT.mkdir()
    PAYLOAD.mkdir()
    entries, member_names = [], set()
    archive_partial = OUTPUT / (NAMES[3] + '.partial')
    with zipfile.ZipFile(archive_partial, 'x', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6) as archive:
        for ref in cat['archive_files']:
            path = checked_ref(ref)
            body = path.read_bytes()
            assert rawpin(body) == {k: ref[k] for k in ('bytes', 'sha256')}
            name = path.relative_to(REPO).as_posix()
            assert name not in member_names and name != 'cohort-outcome-catalog.json'
            member_names.add(name)
            archive.writestr(name, body)
            entries.append(dict(name=name, **memberpin(body)))
        archive.writestr('cohort-outcome-catalog.json', catalog_body)
        entries.append(dict(name='cohort-outcome-catalog.json', **memberpin(catalog_body)))
    with zipfile.ZipFile(archive_partial) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [row['name'] for row in entries]
        for row in entries:
            body = archive.read(row['name'])
            info = archive.getinfo(row['name'])
            assert memberpin(body) == {k: row[k] for k in ('bytes', 'sha256', 'crc32')}
            assert info.file_size == row['bytes'] and '%08x' % info.CRC == row['crc32']
    archive_path = OUTPUT / NAMES[3]
    assert not archive_path.exists()
    archive_partial.replace(archive_path)
    data = {key: value for key, value in cat.items() if key != 'archive_files'}
    data.update(schema='Root-original-bank-cohort-publication-data-v1',
        catalog=dict(path=str(catalog_path), **rawpin(catalog_body)), members=entries,
        archive=rawpin(archive_path.read_bytes()), archive_member_count=len(entries),
        historical_artifacts_unchanged=history, packaging_scientific_execution=False,
        published=False)
    emit(OUTPUT / NAMES[2], jsonbody(data))
    section = summary_section(cat)
    notice = ('<p class="notice" id="original-bank-cohort-notice"><strong>'
        + esc(HEADLINES[cat['status']]) + '</strong> ' + esc(cat['current_plain_observation'])
        + ' Earlier panels are historical. <a href="point-proof-parallel-progress-v1.html'
        '#original-bank-cohort-current">Current cohort report and evidence</a>.</p>')
    main_before = bases[NAMES[0]].decode('utf-8')
    notice_anchor = '<p class="notice" id="native-compare-notice">'
    section_anchor = '<section class="panel" id="native-compare-current">'
    assert main_before.count(notice_anchor) == main_before.count(section_anchor) == 1
    assert 'id="original-bank-cohort-notice"' not in main_before
    assert 'id="original-bank-cohort-current"' not in main_before
    main_after = main_before.replace(notice_anchor, notice + notice_anchor, 1)
    main_after = main_after.replace(section_anchor, section + section_anchor, 1)
    assert main_after.replace(notice, '', 1).replace(section, '', 1).encode('utf-8') == bases[NAMES[0]]
    emit(OUTPUT / NAMES[0], main_after.encode('utf-8'))
    progress_before = bases[NAMES[1]].decode('utf-8')
    assert progress_before.count('<main>') == 1 and progress_before.count('<title>') == 1
    start, end = progress_before.index('<title>'), progress_before.index('</title>') + len('</title>')
    old_title = progress_before[start:end]
    new_title = '<title>Original-bank cohort qualification: current disposition</title>'
    historical = ('<p class="notice"><strong>Historical panels below.</strong> '
        'The following bounded-comparison report and its three negative cases are unchanged '
        'history. Its old current-status wording does not override the cohort disposition above.</p>')
    progress_after = progress_before[:start] + new_title + progress_before[end:]
    progress_after = progress_after.replace('<main>', '<main>' + section + historical, 1)
    assert progress_after.replace(section + historical, '', 1).replace(new_title, old_title, 1).encode('utf-8') == bases[NAMES[1]]
    emit(OUTPUT / NAMES[1], progress_after.encode('utf-8'))
    files = []
    for name in NAMES:
        body = (OUTPUT / name).read_bytes()
        emit(PAYLOAD / name, body)
        files.append(dict(path=PREFIX + name, publisher_source=str(PAYLOAD / name),
            **rawpin(body), git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode('ascii')
                + b'\0' + body).hexdigest()))
    emit(OUTPUT / 'P2-staging.json', jsonbody(dict(
        schema='Root-original-bank-cohort-publication-staging-v1',
        catalog=dict(path=str(catalog_path), **rawpin(catalog_body)), files=files,
        prior_base_pins=BASE_PINS, unchanged_historical_artifacts=history,
        archive_members_verified=len(entries), new_targets_must_be_absent=list(NAMES[2:]),
        exact_main_inverse_bytes=60270, scientific_execution=False, published=False,
        publisher_scope='Only sole P2 and four named existing-destination targets; '
            'Root publisher must verify tracked base blobs and new Git paths absent before commit.')))
    assert rawpin(catalog_path.read_bytes()) == rawpin(catalog_body)
    print(json.dumps(dict(files=files, archive_members=len(entries),
        staging=str(OUTPUT / 'P2-staging.json'), scientific_execution=False, published=False)))


if __name__ == '__main__':
    main()
