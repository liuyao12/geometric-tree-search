"""Ordinary signed-tree to primitive FPC compiler. Source authored, never run.

No target dispatch or proof input reaches search through this control-only entry.
The reviewed generic programs expand through H1/H2/H3/MP and exact deduction.
Returned candidates require the original two external validators and whole gate.
"""

import hashlib
from types import MappingProxyType
from time import monotonic_ns

VERSION = "FPC-H1-SIGNED-COMPILER-v2"
EMITTER_VERSION = "FPC-H1-SIGNED-PRIMITIVE-EMITTERS-v1"
_OWNER = object()
_QUERY_FIELDS = ("version", "claim_mode", "function_arities", "predicate_arities",
                 "theory_profile", "finite_axioms", "Gamma", "goal")


COMPILER_DIAGNOSTIC_FIELDS = (
    "schema", "snapshot_available", "phase", "phase_in_progress",
    "active_control_index", "active_fixture_index", "compiler_invocation_index",
    "observed_through_callback", "phase_enter_monotonic_ns",
    "construction_completed_ns", "export_reachability_completed_ns",
    "export_encoding_completed_ns", "formula_dag_nodes", "ir_rows_created",
    "emitter_instances", "reachable_rows", "export_rows_committed",
    "expanded_headers_committed", "wire_bytes_committed", "active_encode_role")
_COMPILER_DIAGNOSTIC_SCHEMA = "FPC-H1-signed-compiler-diagnostics-v1"
_COMPILER_PHASES = ("INTAKE", "CONSTRUCT", "EXPORT_REACHABLE", "EXPORT_ENCODE",
                    "FINALIZE", "FINAL")
_COMPILER_ROLES = ("CONCLUSION", "LOGICAL_WITNESS", "OTHER_WIRE")


def _invalidate_compiler_diagnostics(sink):
    # Exact twenty-key preflight, before any lookup or genuine callback.
    if type(sink) is not dict or len(sink) != 20:
        return
    for key in sink:
        if type(key) is not str:
            return
    if "snapshot_available" in sink and type(sink["snapshot_available"]) is bool:
        sink["snapshot_available"] = False


def _compiler_diagnostic_labels(sink, c, path):
    if sink is None:
        return (None, None, 0)
    c.need(type(sink) is dict, path, "plain compiler diagnostic dict", "INVALID_CALL")
    c.need(len(sink) == 20, path, "exact compiler diagnostic fields", "INVALID_CALL")
    for key in sink:
        c.need(type(key) is str, path, "exact string diagnostic keys", "INVALID_CALL")
    for key in COMPILER_DIAGNOSTIC_FIELDS:
        c.need(key in sink, path, "exact compiler diagnostic keys", "INVALID_CALL")
    c.need(type(sink["schema"]) is str and sink["schema"] == _COMPILER_DIAGNOSTIC_SCHEMA,
           path + ("schema",), "compiler diagnostic schema", "INVALID_CALL")
    for key in ("snapshot_available", "phase_in_progress"):
        c.need(type(sink[key]) is bool, path + (key,), "compiler diagnostic boolean", "INVALID_CALL")
    c.need(sink["phase"] is None or (type(sink["phase"]) is str and sink["phase"] in _COMPILER_PHASES),
           path + ("phase",), "compiler diagnostic phase", "INVALID_CALL")
    for key in ("active_control_index", "active_fixture_index", "phase_enter_monotonic_ns",
                "construction_completed_ns", "export_reachability_completed_ns",
                "export_encoding_completed_ns", "formula_dag_nodes", "ir_rows_created",
                "emitter_instances", "reachable_rows"):
        c.need(sink[key] is None or _nat(sink[key]), path + (key,),
               "compiler diagnostic optional natural", "INVALID_CALL")
    for key in ("compiler_invocation_index", "observed_through_callback", "export_rows_committed",
                "expanded_headers_committed", "wire_bytes_committed"):
        c.need(_nat(sink[key]), path + (key,), "compiler diagnostic natural", "INVALID_CALL")
    c.need(sink["active_encode_role"] is None or (type(sink["active_encode_role"]) is str and
           sink["active_encode_role"] in _COMPILER_ROLES), path + ("active_encode_role",),
           "compiler diagnostic role", "INVALID_CALL")
    return (sink["active_control_index"], sink["active_fixture_index"], sink["compiler_invocation_index"])


class _CompilerObservation:
    def __init__(self, sink, labels):
        self.sink = sink
        self.values = {
            "schema": _COMPILER_DIAGNOSTIC_SCHEMA, "snapshot_available": False,
            "phase": None, "phase_in_progress": False,
            "active_control_index": labels[0], "active_fixture_index": labels[1],
            "compiler_invocation_index": labels[2], "observed_through_callback": 0,
            "phase_enter_monotonic_ns": None, "construction_completed_ns": None,
            "export_reachability_completed_ns": None, "export_encoding_completed_ns": None,
            "formula_dag_nodes": None, "ir_rows_created": None, "emitter_instances": None,
            "reachable_rows": None, "export_rows_committed": 0,
            "expanded_headers_committed": 0, "wire_bytes_committed": 0,
            "active_encode_role": None}

    def publish(self, successful_callbacks):
        if self.sink is None or self.values["phase"] is None:
            return
        self.values["observed_through_callback"] = successful_callbacks
        self.sink["snapshot_available"] = False
        for key in COMPILER_DIAGNOSTIC_FIELDS:
            if key != "snapshot_available":
                self.sink[key] = self.values[key]
        self.sink["snapshot_available"] = True

    def enter(self, phase, c):
        c.tick()
        self.values["phase"] = phase
        self.values["phase_in_progress"] = True
        self.values["active_encode_role"] = None
        self.values["phase_enter_monotonic_ns"] = monotonic_ns()
        self.publish(c.successful_callbacks)

    def complete(self, c):
        c.tick()
        end = monotonic_ns()
        phase = self.values["phase"]
        field = {"CONSTRUCT": "construction_completed_ns",
                 "EXPORT_REACHABLE": "export_reachability_completed_ns",
                 "EXPORT_ENCODE": "export_encoding_completed_ns"}.get(phase)
        if field is not None:
            self.values[field] = end - self.values["phase_enter_monotonic_ns"]
        self.values["phase_in_progress"] = False
        self.values["active_encode_role"] = None
        self.publish(c.successful_callbacks)

    def final(self, successful_callbacks):
        # No callback or owned cleanup follows this checkpoint.
        self.values["phase"] = "FINAL"
        self.values["phase_in_progress"] = False
        self.values["active_encode_role"] = None
        self.values["phase_enter_monotonic_ns"] = monotonic_ns()
        self.publish(successful_callbacks)


def _ascending_ids(values, c):
    # Checked bottom-up merge; never scan unrelated retained IR rows or sort in C.
    ordered = []
    for value in values:
        c.tick()
        ordered.append(value)
    width = 1
    while width < len(ordered):
        merged = []
        start = 0
        while start < len(ordered):
            c.tick()
            middle, end = min(start + width, len(ordered)), min(start + 2 * width, len(ordered))
            left, right = start, middle
            while left < middle or right < end:
                c.tick()
                if right == end or (left < middle and ordered[left] < ordered[right]):
                    merged.append(ordered[left])
                    left += 1
                else:
                    merged.append(ordered[right])
                    right += 1
            start = end
        ordered = merged
        width *= 2
    return ordered


class PropositionalInputError(ValueError):
    """Public constructor is unowned; only this call's private mint is a refusal."""


def is_owned_error(error):
    return (type(error) is PropositionalInputError and
            getattr(error, "_module_owner", None) is _OWNER and
            getattr(error, "_call_owner", None) is not None)


class _Call:
    def __init__(self, check):
        self.check, self.owner, self.first = check, object(), None
        self.successful_callbacks, self.observer = 0, None

    def tick(self):
        if self.first is not None:
            raise self.first
        try:
            self.check()
        except BaseException as error:
            self.first = error
            raise
        self.successful_callbacks += 1
        if self.successful_callbacks % 65536 == 0 and self.observer is not None:
            self.observer.publish(self.successful_callbacks)

    def fault(self):
        if self.first is not None:
            raise self.first

    def fail(self, code, path, message):
        self.fault()
        error = PropositionalInputError(message)
        error._module_owner, error._call_owner = _OWNER, self.owner
        error.detail = {"code": code, "path": list(path), "message": message}
        raise error

    def need(self, condition, path, message, code="INVALID_TREE"):
        self.tick()
        if not condition:
            self.fail(code, path, message)


def _nat(x):
    return type(x) is int and x >= 0


def _keys(value, names, c, path, code="INVALID_TREE"):
    c.need(type(value) in (dict, MappingProxyType), path, "ordinary mapping required", code)
    c.need(len(value) == len(names), path, "exact keys required", code)
    for key in value:
        c.need(type(key) is str and key in names, path, "unknown key", code)


def _snapshot(value, c, path=()):
    """Fresh immutable JSON snapshot; aliases copy, ancestor cycles refuse."""
    pending, values, active = [("read", value, path)], [], set()
    while pending:
        c.tick()
        mode, node, at = pending.pop()
        if mode == "map":
            source_id, keys = node
            n = len(keys)
            kids = values[-n:] if n else []
            if n:
                del values[-n:]
            copied = {}
            for key, child in zip(keys, kids):
                c.tick()
                copied[key] = child
            values.append(MappingProxyType(copied))
            active.remove(source_id)
        elif mode == "list":
            source_id, n = node
            kids = values[-n:] if n else []
            if n:
                del values[-n:]
            values.append(tuple(kids))
            active.remove(source_id)
        elif type(node) is dict:
            c.need(id(node) not in active, at, "cyclic mapping")
            active.add(id(node))
            keys = []
            for key in node:
                c.need(type(key) is str, at, "string keys required")
                keys.append(key)
            pending.append(("map", (id(node), tuple(keys)), at))
            for key in reversed(keys):
                c.tick()
                pending.append(("read", node[key], at + (key,)))
        elif type(node) is list:
            c.need(id(node) not in active, at, "cyclic list")
            active.add(id(node))
            pending.append(("list", (id(node), len(node)), at))
            for j in range(len(node) - 1, -1, -1):
                c.tick()
                pending.append(("read", node[j], at + (j,)))
        elif node is None or type(node) in (str, int, bool):
            values.append(node)
        else:
            c.fail("INVALID_TREE", at, "JSON scalar/plain container required")
    return values[0]


def _plain(value, c):
    pending, values = [(False, value)], []
    while pending:
        c.tick()
        built, node = pending.pop()
        if built:
            kind, keys, n = node
            kids = values[-n:] if n else []
            if n:
                del values[-n:]
            if kind == "map":
                out = {}
                for key, child in zip(keys, kids):
                    c.tick()
                    out[key] = child
                values.append(out)
            else:
                values.append(list(kids))
        elif type(node) is MappingProxyType:
            keys = tuple(node)
            pending.append((True, ("map", keys, len(keys))))
            for key in reversed(keys):
                c.tick()
                pending.append((False, node[key]))
        elif type(node) is tuple:
            pending.append((True, ("list", (), len(node))))
            for child in reversed(node):
                c.tick()
                pending.append((False, child))
        else:
            values.append(node)
    return values[0]


def _scope(q, c):
    if q["theory_profile"] != 0:
        return "UNSUPPORTED_THEORY_PROFILE", ("theory_profile",)
    if q["function_arities"]:
        return "NONEMPTY_FUNCTION_SIGNATURE", ("function_arities",)
    for j, arity in enumerate(q["predicate_arities"]):
        c.tick()
        if arity != 0:
            return "NONNULLARY_PREDICATE", ("predicate_arities", j)
    sources = []
    for field in ("finite_axioms", "Gamma"):
        for j, f in enumerate(q[field]):
            c.tick()
            sources.append((f, (field, j)))
    sources.append((q["goal"], ("goal",)))
    for f, path in sources:
        pending = [(f, path)]
        while pending:
            c.tick()
            node, at = pending.pop()
            tag = node[0]
            if tag not in ("pred", "not", "imp"):
                return "UNSUPPORTED_FORMULA_CONSTRUCTOR", at + (0,)
            if tag == "not":
                pending.append((node[1], at + (1,)))
            elif tag == "imp":
                pending.append((node[2], at + (2,)))
                pending.append((node[1], at + (1,)))
    return None


def _query(raw, modules, c):
    c.need(type(raw) is bytes, (), "immutable query bytes required", "INVALID_CALL")
    c.need(type(modules) is dict, ("modules",), "plain module mapping required", "INVALID_CALL")
    _keys(modules, ("checker", "builders"), c, ("modules",), "INVALID_CALL")
    checker = modules["checker"]
    try:
        decoded = checker.decode_query(raw, check=c.tick)
    except BaseException as error:
        c.fault()
        if type(error) is checker.InvalidWitness and checker.is_owned_error(error):
            c.fail("MALFORMED_QUERY", (), "original query decoder refusal")
        raise
    c.fault()
    c.need(type(decoded) is dict and decoded.get("EOF") == len(raw), (), "decoder EOF", "INVALID_CALL")
    fields = {}
    for key in _QUERY_FIELDS:
        c.tick()
        fields[key] = decoded[key]
    frozen = _snapshot(fields, c)
    unsupported = _scope(frozen, c)
    if unsupported is not None:
        c.fail("UNSUPPORTED_COMPILER_SCOPE", unsupported[1], unsupported[0])
    digest = hashlib.sha256()
    for start in range(0, len(raw), 65536):
        c.tick()
        digest.update(raw[start:start + 65536])
    identity = _plain(frozen, c)
    identity.update(query_hex=raw.hex(), bytes=len(raw), sha256=digest.hexdigest())
    c.tick()
    return frozen, identity


class _Formulas:
    def __init__(self, predicates, c):
        self.predicates, self.c, self.rows, self.keys = predicates, c, [], {}
        c.observer.values["formula_dag_nodes"] = 0

    def add(self, tag, symbol, kids):
        self.c.tick()
        key = (tag, symbol, tuple(kids))
        if key not in self.keys:
            self.keys[key] = len(self.rows)
            self.rows.append(key)
            self.c.observer.values["formula_dag_nodes"] = len(self.rows)
        return self.keys[key]

    def neg(self, f):
        return self.add("not", None, (f,))

    def imp(self, a, b):
        return self.add("imp", None, (a, b))

    def load(self, ast, path=()):
        pending, values = [(False, ast, path)], []
        while pending:
            self.c.tick()
            built, node, at = pending.pop()
            if built:
                tag, n = node
                kids = values[-n:]
                del values[-n:]
                values.append(self.add(tag, None, kids))
                continue
            self.c.need(type(node) is tuple and bool(node), at, "formula list")
            tag = node[0]
            if tag == "pred":
                self.c.need(len(node) == 3 and _nat(node[1]) and node[1] < len(self.predicates)
                            and type(node[2]) is tuple and not node[2], at, "nullary atom")
                values.append(self.add(tag, node[1], ()))
            else:
                n = 1 if tag == "not" else 2
                self.c.need(tag in ("not", "imp") and len(node) == n + 1, at, "propositional core")
                pending.append((True, (tag, n), at))
                for j in range(n, 0, -1):
                    self.c.tick()
                    pending.append((False, node[j], at + (j,)))
        return values[0]

    def encode(self, root, out):
        pending = [root]
        while pending:
            self.c.tick()
            tag, symbol, kids = self.rows[pending.pop()]
            _uleb({"pred": 0, "not": 2, "imp": 3}[tag], out, self.c)
            if tag == "pred":
                _uleb(symbol, out, self.c)
                _uleb(0, out, self.c)
            for child in reversed(kids):
                self.c.tick()
                pending.append(child)
            self.c.observer.values["expanded_headers_committed"] += 1


def _uleb(value, out, c):
    c.need(_nat(value), (), "wire natural")
    while True:
        c.tick()
        byte = value & 127
        value >>= 7
        out.append(byte | (128 if value else 0))
        c.observer.values["wire_bytes_committed"] = len(out)
        if not value:
            return


def _same_entries(a, b, c):
    if len(a) != len(b):
        return False
    for left, right in zip(a, b):
        c.tick()
        if left[0] != right[0] or left[2] != right[2]:
            return False
        x, y = left[1], right[1]
        if x[0:2] != y[0:2] or len(x[2]) != len(y[2]):
            return False
        for u, v in zip(x[2], y[2]):
            c.tick()
            if u != v:
                return False
    return True


def _closure(entries, c):
    for i in range(len(entries)):
        for j in range(i + 1, len(entries)):
            c.tick()
            if entries[i][0] != entries[j][0] and entries[i][2] == entries[j][2]:
                return (i, j)
    return None


def _replacement(entries, principal, added, c):
    out = []
    for j, entry in enumerate(entries):
        c.tick()
        if j == principal:
            for child in added:
                c.tick()
                out.append(child)
        else:
            out.append(entry)
    return tuple(out)


def _children(entries, principal, a, c):
    sign, origin, formula = entries[principal]
    source, index, path = origin
    tag, _, kids = a.rows[formula]
    if tag == "not":
        child = ("F" if sign == "T" else "T", (source, index, path + (0,)), kids[0])
        return ("T_NOT" if sign == "T" else "F_NOT"), (_replacement(entries, principal, (child,), c),)
    left = ("F" if sign == "T" else "T", (source, index, path + (0,)), kids[0])
    right = ("T" if sign == "T" else "F", (source, index, path + (1,)), kids[1])
    if sign == "F":
        return "F_IMP", (_replacement(entries, principal, (left, right), c),)
    return "T_IMP", (_replacement(entries, principal, (left,), c),
                     _replacement(entries, principal, (right,), c))


def _validate_tree(raw, frozen, q, a, c):
    _keys(frozen, ("schema", "query_hex", "nodes", "root"), c, ())
    c.need(frozen["schema"] == "FPC-H1-closed-signed-tree-v1" and
           frozen["query_hex"] == raw.hex(), (), "tree/query identity")
    nodes = frozen["nodes"]
    c.need(type(nodes) is tuple and bool(nodes), ("nodes",), "nonempty nodes")
    c.need(_nat(frozen["root"]) and frozen["root"] == len(nodes) - 1, ("root",), "last root")
    parsed, parents = [], [0 for _ in nodes]
    for i, node in enumerate(nodes):
        c.tick()
        at = ("nodes", i)
        _keys(node, ("id", "entries", "rule", "principal", "premises", "close_pair"), c, at)
        c.need(_nat(node["id"]) and node["id"] == i, at + ("id",), "node ID")
        c.need(type(node["entries"]) is tuple and bool(node["entries"]), at, "entries")
        entries = []
        for j, entry in enumerate(node["entries"]):
            ep = at + ("entries", j)
            _keys(entry, ("sign", "origin", "formula"), c, ep)
            c.need(type(entry["sign"]) is str and entry["sign"] in ("T", "F"), ep, "sign")
            origin = entry["origin"]
            _keys(origin, ("source", "index", "path"), c, ep + ("origin",))
            c.need(origin["source"] in ("GAMMA", "AXIOM", "GOAL") and type(origin["source"]) is str
                   and _nat(origin["index"]) and type(origin["path"]) is tuple, ep, "origin")
            for step in origin["path"]:
                c.need(type(step) is int and step in (0, 1), ep, "origin step")
            formula = a.load(entry["formula"], ep + ("formula",))
            entries.append((entry["sign"], (origin["source"], origin["index"], origin["path"]), formula))
        entries = tuple(entries)
        pair = _closure(entries, c)
        refs = node["premises"]
        c.need(type(refs) is tuple, at, "premise list")
        for ref in refs:
            c.need(_nat(ref) and ref < i, at, "earlier premise")
            parents[ref] += 1
        if pair is not None:
            cp = node["close_pair"]
            c.need(node["rule"] == "CLOSE" and node["principal"] is None and not refs
                   and type(cp) is tuple and len(cp) == 2 and all(type(x) is int for x in cp)
                   and cp == pair, at, "exact first closure")
            principal, rule = None, "CLOSE"
        else:
            principal = None
            for j, entry in enumerate(entries):
                c.tick()
                if a.rows[entry[2]][0] != "pred":
                    principal = j
                    break
            c.need(principal is not None, at, "open analytic leaf")
            c.need(type(node["principal"]) is int and node["principal"] == principal
                   and node["close_pair"] is None, at, "exact principal")
            rule, children = _children(entries, principal, a, c)
            c.need(node["rule"] == rule and len(refs) == len(children), at, "rule/child count")
            for ref, child in zip(refs, children):
                c.need(_same_entries(parsed[ref][0], child, c), at, "exact child entries")
        parsed.append((entries, rule, principal, refs, pair))
    for i, count in enumerate(parents):
        c.need(count == (0 if i == len(nodes) - 1 else 1), ("nodes", i), "tree ownership")
    initial = []
    for field, source in (("Gamma", "GAMMA"), ("finite_axioms", "AXIOM")):
        for i, formula in enumerate(q[field]):
            c.tick()
            initial.append(("T", (source, i, ()), a.load(formula)))
    goal = a.load(q["goal"])
    initial.append(("F", ("GOAL", 0, ()), goal))
    c.need(_same_entries(parsed[-1][0], tuple(initial), c), ("root",), "initial query state")
    order, pending = [], [(len(nodes) - 1, False)]
    while pending:
        c.tick()
        node, ready = pending.pop()
        if ready:
            order.append(node)
        else:
            pending.append((node, True))
            for ref in reversed(parsed[node][3]):
                c.tick()
                pending.append((ref, False))
    c.need(len(order) == len(nodes), (), "all nodes reachable")
    for i, number in enumerate(order):
        c.need(number == i, ("nodes", i), "left-first postorder")
    return tuple(parsed), goal


class _IR:
    def __init__(self, q, a, c):
        self.q, self.a, self.c = q, a, c
        self.tokens, self.contexts, self.rows, self.origins = [], [], [], []
        self.origin, self.transform = ("ROOT",), None
        self.emitters = 0
        c.observer.values["ir_rows_created"] = 0
        c.observer.values["emitter_instances"] = 0
        for j, formula in enumerate(q["Gamma"]):
            c.tick()
            self.tokens.append(("ROOT", j, a.load(formula), ("GAMMA", j)))
        self.contexts.append(tuple(range(len(self.tokens))))

    def extend(self, context, formula):
        self.c.tick()
        token = len(self.tokens)
        self.tokens.append(("LOCAL", token, formula, self.origin))
        copied = []
        for old in self.contexts[context]:
            self.c.tick()
            copied.append(old)
        copied.append(token)
        number = len(self.contexts)
        self.contexts.append(tuple(copied))
        return number, token

    def add(self, context, formula, rule, payload, refs=()):
        self.c.tick()
        for ref in refs:
            self.c.need(_nat(ref) and ref < len(self.rows) and self.rows[ref][0] == context,
                        (), "primitive context/reference")
        number = len(self.rows)
        self.rows.append((context, formula, rule, payload, tuple(refs)))
        self.origins.append((self.origin, self.transform, number))
        self.c.observer.values["ir_rows_created"] = len(self.rows)
        return number

    def hyp(self, context, token):
        found = False
        for old in self.contexts[context]:
            self.c.tick()
            if old == token:
                found = True
        self.c.need(found, (), "occurrence outside context")
        return self.add(context, self.tokens[token][2], 0, token)

    def table(self, context, index):
        self.c.need(_nat(index) and index < len(self.q["finite_axioms"]), (), "table index")
        return self.add(context, self.a.load(self.q["finite_axioms"][index]), 2, index)

    def ax(self, context, tag, w):
        self.c.tick()
        I, N = self.a.imp, self.a.neg
        if tag == 0:
            A, B = w
            formula = I(A, I(B, A))
        elif tag == 1:
            A, B, C = w
            formula = I(I(A, I(B, C)), I(I(A, B), I(A, C)))
        else:
            self.c.need(tag == 2, (), "only H1/H2/H3")
            A, B = w
            formula = I(I(N(B), N(A)), I(A, B))
        return self.add(context, formula, 1, (tag, tuple(w)))

    def mp(self, context, antecedent, implication):
        self.c.tick()
        row = self.rows[implication]
        tag, _, kids = self.a.rows[row[1]]
        self.c.need(tag == "imp" and kids[0] == self.rows[antecedent][1], (), "MP operands")
        return self.add(context, kids[1], 3, None, (antecedent, implication))

    def reachable(self, roots):
        seen, pending, discovered = set(), [], []
        for root in roots:
            self.c.tick()
            pending.append(root)
        while pending:
            self.c.tick()
            number = pending.pop()
            if number in seen:
                continue
            seen.add(number)
            discovered.append(number)
            for child in self.rows[number][4]:
                self.c.tick()
                pending.append(child)
        return _ascending_ids(discovered, self.c)

    def substitute(self, roots, source, target, replacements):
        self.c.tick()
        self.c.need(len(replacements) == len(self.contexts[source]), (), "complete occurrence map")
        for token in self.contexts[source]:
            self.c.tick()
            self.c.need(token in replacements, (), "missing occurrence")
            row = self.rows[replacements[token]]
            self.c.need(row[0] == target and row[1] == self.tokens[token][2], (), "replacement scope/formula")
        mapping = {}
        old_transform = self.transform
        for number in self.reachable(roots):
            self.c.tick()
            self.transform = ("SUBSTITUTION", number, source, target)
            ctx, formula, rule, payload, refs = self.rows[number]
            self.c.need(ctx == source, (), "substitution source context")
            if rule == 0:
                result = replacements[payload]
            else:
                mapped = []
                for ref in refs:
                    self.c.tick()
                    mapped.append(mapping[ref])
                result = self.add(target, formula, rule, payload, mapped)
            mapping[number] = result
        self.transform = old_transform
        return [mapping[root] for root in roots]

    def weaken(self, roots, source, target):
        replacements = {}
        for token in self.contexts[source]:
            self.c.tick()
            replacements[token] = self.hyp(target, token)
        return self.substitute(roots, source, target, replacements)

    def deduce(self, root, occurrence, target):
        # Every map is local to this exact source/LOCAL-token/target discharge.
        ceiling = len(self.rows)
        self.c.need(_nat(root) and root < ceiling, (), "deduction source root")
        source = self.rows[root][0]
        self.c.need(_nat(occurrence) and occurrence < len(self.tokens) and
                    self.tokens[occurrence][0] == "LOCAL", (), "root Gamma cannot discharge")
        self.c.need(_nat(target) and target < len(self.contexts), (), "deduction target")
        remainder, found = [], False
        for token in self.contexts[source]:
            self.c.tick()
            if token == occurrence:
                self.c.need(not found, (), "one exact discharge occurrence")
                found = True
            else:
                remainder.append(token)
        self.c.need(found and len(remainder) == len(self.contexts[target]), (), "exact discharge context")
        for index, token in enumerate(remainder):
            self.c.need(token == self.contexts[target][index], (), "exact discharge context")
        dependency, raw, transformed = {}, {}, {}
        for number in self.reachable((root,)):
            self.c.tick()
            ctx, formula, rule, payload, refs = self.rows[number]
            self.c.need(number < ceiling and ctx == source, (), "deduction source context")
            if rule == 0:
                dependency[number] = payload == occurrence
            elif rule in (1, 2):
                dependency[number] = False
            else:
                self.c.need(rule == 3 and len(refs) == 2, (), "propositional deduction row")
                dependency[number] = dependency[refs[0]] or dependency[refs[1]]
        A = self.tokens[occurrence][2]
        old_transform = self.transform
        pending = [(root, False)]
        while pending:
            self.c.tick()
            number, ready = pending.pop()
            if number in transformed:
                continue
            ctx, P, rule, payload, refs = self.rows[number]
            self.transform = ("DEDUCTION", number, occurrence, target)
            if not dependency[number]:
                original = self.clone_independent(number, source, occurrence, target,
                                                  ceiling, dependency, raw)
                self.transform = ("DEDUCTION", number, occurrence, target)
                h1 = self.ax(target, 0, (P, A))
                result = self.mp(target, original, h1)
            elif rule == 0:
                self.c.need(payload == occurrence, (), "dependent exact HYP")
                result = self.emit("IDENTITY", (A,), target)
            elif not ready:
                self.c.need(rule == 3, (), "dependent MP")
                pending.append((number, True))
                pending.append((refs[1], False))
                pending.append((refs[0], False))
                continue
            else:
                left, right = refs
                X = self.rows[left][1]
                h2 = self.ax(target, 1, (A, X, P))
                middle = self.mp(target, transformed[right], h2)
                result = self.mp(target, transformed[left], middle)
            self.c.need(self.rows[result][0] == target and self.rows[result][1] == self.a.imp(A, P),
                        (), "transformed implication")
            transformed[number] = result
        self.transform = old_transform
        return transformed[root]

    def clone_independent(self, root, source, occurrence, target, ceiling, dependency, raw):
        # raw proves P; the separate transformed map proves A implies P.
        missing, seen, pending = [], set(), [root]
        while pending:
            self.c.tick()
            number = pending.pop()
            if number in raw or number in seen:
                continue
            self.c.need(number < ceiling and self.rows[number][0] == source and
                        dependency[number] is False, (), "independent source row")
            seen.add(number)
            missing.append(number)
            for child in self.rows[number][4]:
                self.c.tick()
                pending.append(child)
        for number in _ascending_ids(missing, self.c):
            self.c.tick()
            _, P, rule, payload, refs = self.rows[number]
            self.transform = ("RAW_CLONE", number, source, occurrence, target)
            if rule == 0:
                self.c.need(payload != occurrence, (), "discharged token in raw clone")
                result = self.hyp(target, payload)
            elif rule in (1, 2):
                result = self.add(target, P, rule, payload)
            else:
                self.c.need(rule == 3, (), "raw clone primitive kind")
                result = self.mp(target, raw[refs[0]], raw[refs[1]])
            self.c.need(self.rows[result][0] == target and self.rows[result][1] == P,
                        (), "raw clone formula/context")
            raw[number] = result
        return raw[root]

    def emit(self, name, parameters, base):
        self.c.tick()
        self.emitters += 1
        self.c.observer.values["emitter_instances"] = self.emitters
        old_origin = self.origin
        self.origin = ("SCHEMA", name, self.emitters)
        try:
            return self.program(name, parameters, base)
        finally:
            self.origin = old_origin

    def program(self, name, parameters, base):
        I, N = self.a.imp, self.a.neg
        if name == "IDENTITY":
            A, = parameters
            one = self.ax(base, 0, (A, I(A, A)))
            two = self.ax(base, 0, (A, A))
            three = self.ax(base, 1, (A, I(A, A), A))
            return self.mp(base, two, self.mp(base, one, three))
        if name == "EXPLOSION":
            A, C = parameters
            one, a = self.extend(base, A)
            two, n = self.extend(one, N(A))
            e0, e1 = self.hyp(two, a), self.hyp(two, n)
            e2 = self.ax(two, 0, (N(A), N(C)))
            e3 = self.mp(two, e1, e2)
            e4 = self.ax(two, 2, (A, C))
            e5 = self.mp(two, e3, e4)
            e6 = self.mp(two, e0, e5)
            return self.deduce(self.deduce(e6, n, one), a, base)
        if name == "CLASSICAL_ROOT_ELIMINATION":
            A, = parameters
            H = I(N(A), A)
            one, h = self.extend(base, H)
            two, u = self.extend(one, N(A))
            r0, r1 = self.hyp(two, h), self.hyp(two, u)
            r2 = self.mp(two, r1, r0)
            r3 = self.emit("EXPLOSION", (A, N(H)), two)
            r4 = self.mp(two, r2, r3)
            r5 = self.mp(two, r1, r4)
            r6 = self.deduce(r5, u, one)
            r7 = self.ax(one, 2, (H, A))
            r8 = self.mp(one, r6, r7)
            r9 = self.hyp(one, h)
            return self.deduce(self.mp(one, r9, r8), h, base)
        if name == "DOUBLE_NEGATION":
            A, = parameters
            one, d = self.extend(base, N(N(A)))
            two, u = self.extend(one, N(A))
            d0, d1 = self.hyp(two, u), self.hyp(two, d)
            d2 = self.emit("EXPLOSION", (N(A), A), two)
            d3 = self.mp(two, d0, d2)
            d4 = self.mp(two, d1, d3)
            d5 = self.deduce(d4, u, one)
            d6 = self.emit("CLASSICAL_ROOT_ELIMINATION", (A,), one)
            return self.deduce(self.mp(one, d5, d6), d, base)
        if name == "NEGATIVE_IMPLICATION_LEFT":
            A, B = parameters
            P = I(A, B)
            one, n = self.extend(base, N(P))
            two, u = self.extend(one, N(A))
            three, a = self.extend(two, A)
            l0, l1 = self.hyp(three, a), self.hyp(three, u)
            l2 = self.emit("EXPLOSION", (A, B), three)
            l3 = self.mp(three, l0, l2)
            l4 = self.mp(three, l1, l3)
            l5 = self.deduce(l4, a, two)
            l6 = self.hyp(two, n)
            l7 = self.emit("EXPLOSION", (P, A), two)
            l8 = self.mp(two, l5, l7)
            l9 = self.mp(two, l6, l8)
            l10 = self.deduce(l9, u, one)
            l11 = self.emit("CLASSICAL_ROOT_ELIMINATION", (A,), one)
            return self.deduce(self.mp(one, l10, l11), n, base)
        if name == "NEGATIVE_IMPLICATION_RIGHT":
            A, B = parameters
            P = I(A, B)
            one, n = self.extend(base, N(P))
            two, u = self.extend(one, N(N(B)))
            m0 = self.hyp(two, u)
            m1 = self.emit("DOUBLE_NEGATION", (B,), two)
            m2 = self.mp(two, m0, m1)
            m3 = self.ax(two, 0, (B, A))
            m4 = self.mp(two, m2, m3)
            m5 = self.hyp(two, n)
            m6 = self.emit("EXPLOSION", (P, N(B)), two)
            m7 = self.mp(two, m4, m6)
            m8 = self.mp(two, m5, m7)
            m9 = self.deduce(m8, u, one)
            m10 = self.emit("CLASSICAL_ROOT_ELIMINATION", (N(B),), one)
            return self.deduce(self.mp(one, m9, m10), n, base)
        self.c.need(name == "CLASSICAL_BRANCH_JOIN", (), "schema name")
        A, B, C = parameters
        one, p = self.extend(base, I(A, B))
        two, q = self.extend(one, I(N(A), C))
        three, r = self.extend(two, I(B, C))
        four, u = self.extend(three, N(C))
        five, v = self.extend(four, N(A))
        j0, j1 = self.hyp(five, v), self.hyp(five, q)
        j2 = self.mp(five, j0, j1)
        j3 = self.hyp(five, u)
        j4 = self.emit("EXPLOSION", (C, A), five)
        j5 = self.mp(five, j2, j4)
        j6 = self.mp(five, j3, j5)
        j7 = self.deduce(j6, v, four)
        j8 = self.emit("CLASSICAL_ROOT_ELIMINATION", (A,), four)
        j9 = self.mp(four, j7, j8)
        j10 = self.hyp(four, p)
        j11 = self.mp(four, j9, j10)
        j12 = self.hyp(four, r)
        j13 = self.mp(four, j11, j12)
        j14 = self.deduce(j13, u, three)
        j15 = self.emit("CLASSICAL_ROOT_ELIMINATION", (C,), three)
        j16 = self.mp(three, j14, j15)
        return self.deduce(self.deduce(self.deduce(j16, r, two), q, one), p, base)

    def export(self, root, goal):
        obs = self.c.observer
        obs.enter("EXPORT_REACHABLE", self.c)
        self.c.need(self.rows[root][0] == 0 and self.rows[root][1] == goal, (), "root context/goal")
        order = self.reachable((root,))
        obs.values["reachable_rows"] = len(order)
        obs.complete(self.c)
        obs.enter("EXPORT_ENCODE", self.c)
        remap = {}
        obs.values["active_encode_role"] = "OTHER_WIRE"
        out = bytearray(b"FPP1")
        obs.values["wire_bytes_committed"] = len(out)
        _uleb(len(order), out, self.c)
        for position, number in enumerate(order):
            self.c.tick()
            context, formula, rule, payload, refs = self.rows[number]
            self.c.need(context == 0, (), "local context leaked")
            obs.values["active_encode_role"] = "CONCLUSION"
            self.a.encode(formula, out)
            obs.values["active_encode_role"] = "OTHER_WIRE"
            _uleb(rule, out, self.c)
            if rule == 0:
                token = self.tokens[payload]
                self.c.need(token[0] == "ROOT", (), "local occurrence leaked")
                _uleb(token[1], out, self.c)
            elif rule == 1:
                tag, w = payload
                _uleb(tag, out, self.c)
                for formula_id in w:
                    self.c.tick()
                    obs.values["active_encode_role"] = "LOGICAL_WITNESS"
                    self.a.encode(formula_id, out)
                    obs.values["active_encode_role"] = "OTHER_WIRE"
            elif rule == 2:
                _uleb(0, out, self.c)
                _uleb(payload, out, self.c)
            else:
                self.c.need(rule == 3, (), "primitive rule")
                for ref in refs:
                    self.c.tick()
                    _uleb(remap[ref], out, self.c)
            remap[number] = position
            obs.values["export_rows_committed"] += 1
            obs.values["wire_bytes_committed"] = len(out)
            obs.publish(self.c.successful_callbacks)
        self.c.need(order[-1] == root, (), "root last")
        self.c.tick()
        candidate = bytes(out)
        self.c.tick()
        obs.complete(self.c)
        return candidate, len(order)


def _compile(nodes, goal, ir, c):
    root = len(nodes) - 1
    ir.origin = ("INITIAL_GOAL", root)
    root_context, negative_goal = ir.extend(0, ir.a.neg(goal))
    initial_proofs = []
    for _, origin, _ in nodes[root][0]:
        c.tick()
        source, index, _ = origin
        if source == "GAMMA":
            proof = ir.hyp(root_context, index)
        elif source == "AXIOM":
            proof = ir.table(root_context, index)
        else:
            proof = ir.hyp(root_context, negative_goal)
        initial_proofs.append(proof)
    stack = [{"node": root, "context": root_context, "proofs": initial_proofs, "next": 0, "results": [], "tokens": []}]
    result = None
    while stack:
        c.tick()
        frame = stack[-1]
        ir.origin = ("ANALYTIC", frame["node"])
        entries, rule, principal, refs, pair = nodes[frame["node"]]
        ctx, proofs = frame["context"], frame["proofs"]
        if rule == "CLOSE":
            i, j = pair
            positive, negative = (i, j) if entries[i][0] == "T" else (j, i)
            axiom = ir.emit("EXPLOSION", (entries[positive][2], goal), ctx)
            result = ir.mp(ctx, proofs[negative], ir.mp(ctx, proofs[positive], axiom))
        elif frame["next"] < len(refs):
            slot = frame["next"]
            frame["next"] += 1
            child = refs[slot]
            formula = entries[principal][2]
            _, _, kids = ir.a.rows[formula]
            source = proofs[principal]
            if rule == "T_IMP":
                local = ir.a.neg(kids[0]) if slot == 0 else kids[1]
                child_context, token = ir.extend(ctx, local)
                lifted = ir.weaken(proofs, ctx, child_context)
                new = ir.hyp(child_context, token)
                child_proofs = lifted[:principal] + [new] + lifted[principal + 1:]
                frame["tokens"].append(token)
            else:
                child_context = ctx
                if rule == "T_NOT":
                    added = [source]
                elif rule == "F_NOT":
                    axiom = ir.emit("DOUBLE_NEGATION", (kids[0],), ctx)
                    added = [ir.mp(ctx, source, axiom)]
                else:
                    left = ir.emit("NEGATIVE_IMPLICATION_LEFT", kids, ctx)
                    right = ir.emit("NEGATIVE_IMPLICATION_RIGHT", kids, ctx)
                    added = [ir.mp(ctx, source, left), ir.mp(ctx, source, right)]
                child_proofs = proofs[:principal] + added + proofs[principal + 1:]
            c.need(len(child_proofs) == len(nodes[child][0]), (), "entry mapping length")
            stack.append({"node": child, "context": child_context, "proofs": child_proofs,
                          "next": 0, "results": [], "tokens": []})
            continue
        elif rule == "T_IMP":
            formula = entries[principal][2]
            _, _, kids = ir.a.rows[formula]
            first = ir.deduce(frame["results"][0], frame["tokens"][0], ctx)
            second = ir.deduce(frame["results"][1], frame["tokens"][1], ctx)
            axiom = ir.emit("CLASSICAL_BRANCH_JOIN", (kids[0], kids[1], goal), ctx)
            current = ir.mp(ctx, proofs[principal], axiom)
            current = ir.mp(ctx, first, current)
            result = ir.mp(ctx, second, current)
        else:
            result = frame["results"][0]
        c.need(ir.rows[result][0] == ctx and ir.rows[result][1] == goal, (), "subtree continuation")
        stack.pop()
        if stack:
            stack[-1]["results"].append(result)
    discharged = ir.deduce(result, negative_goal, 0)
    classical = ir.emit("CLASSICAL_ROOT_ELIMINATION", (goal,), 0)
    return ir.mp(0, discharged, classical)


def compile_closed_signed_tree(query_bytes, tree, *, modules, check, diagnostics=None):
    _invalidate_compiler_diagnostics(diagnostics)
    c, ir, snapshot, nodes, arena = _Call(check), None, None, None, None
    q = result = None
    normal_cleanup_done = False
    try:
        if not callable(check):
            c.fail("INVALID_CALL", (), "check must be callable")
        c.tick()
        labels = _compiler_diagnostic_labels(diagnostics, c, ("diagnostics",))
        obs = _CompilerObservation(diagnostics, labels)
        c.observer = obs
        obs.enter("INTAKE", c)
        q, identity = _query(query_bytes, modules, c)
        snapshot = _snapshot(tree, c)
        arena = _Formulas(q["predicate_arities"], c)
        nodes, goal = _validate_tree(query_bytes, snapshot, q, arena, c)
        obs.complete(c)
        obs.enter("CONSTRUCT", c)
        ir = _IR(q, arena, c)
        root = _compile(nodes, goal, ir, c)
        obs.complete(c)
        candidate, count = ir.export(root, goal)
        obs.enter("FINALIZE", c)
        result = {"candidate_certificate_bytes": candidate, "receipt": {
            "schema": "FPC-H1-signed-compiler-receipt-v2", "accepted": False,
            "query": identity, "primitive_rows": count, "emitter_instances": ir.emitters,
            "emitter_version": EMITTER_VERSION, "tree_nodes": len(nodes),
            "validation": "NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED"}}
        ir = snapshot = nodes = arena = q = None
        normal_cleanup_done = True
        c.tick()
        obs.final(c.successful_callbacks)
        return result
    except BaseException:
        c.fault()
        raise
    finally:
        # Only owned containers; no postfault callback/getter/publication.
        if not normal_cleanup_done:
            ir = snapshot = nodes = arena = q = None
