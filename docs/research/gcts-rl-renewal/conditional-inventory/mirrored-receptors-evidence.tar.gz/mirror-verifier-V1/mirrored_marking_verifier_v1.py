"""UNEXECUTED independent mirrored finite unit-center gadget checks.

Derived from frozen independent finite_marking_verifier_v1.py; no old file is
changed. No compiler, codec, search, solver, simulator or fixture imports.
Each auxiliary read copies ALL original m rows to the literal base location,
including assigned0 and remote points. Original t is never mirrored.
"""
VERSION='independent-mirrored-marking-verifier-v1'
_OWNER=object()
CADENCE=1024
LIMIT_KEYS=('work','centers','tiles','marks','clauses','literals','candidates',
            'integer_abs','string_chars','data_depth')
BASE_KEYS=('schema','transformations','required_centers','admissible_origins',
           'tiles','fixed_background_marks','all_root_generations')
CERT_KEYS=('schema','placements')
COMP_KEYS=('schema','version','status','base','clauses','instance','mapping',
           'construction_counts','counts','problem_defining','redundancy_established',
           'mathematical_authority','executed_source_qualified')


class Invalid(ValueError):
    def __init__(self,reason,*,_owner=None):
        self.reason=reason;self._owner=_owner;super().__init__(reason)


class ResourceLimit(RuntimeError):
    def __init__(self,reason,work,*,_owner=None):
        self.reason=reason;self.work=work;self._owner=_owner;super().__init__(reason)


def is_own_invalid(error):
    return type(error)is Invalid and error._owner is _OWNER


def is_own_limit(error):
    return type(error)is ResourceLimit and error._owner is _OWNER


def _need(ok,reason):
    if not ok:raise Invalid(reason,_owner=_OWNER)


class _Budget:
    def __init__(self,check,limits):
        _need(callable(check),'explicit external check')
        _need(type(limits)is dict and all(type(k)is str for k in limits)and
              set(limits)==set(LIMIT_KEYS),'exact explicit private limits')
        _need(all(type(v)is int and v>0 for v in limits.values()),'positive exact-int limits')
        _need(limits['data_depth']<=128,'Source depth ceiling128')
        self.check=check;self.limits=dict(limits);self.work=0;self.stage='ENTRY'
        check()
    def tick(self):
        self.work+=1
        if self.work>self.limits['work']:
            raise ResourceLimit('work',self.work,_owner=_OWNER)
        if self.work%CADENCE==0:self.check()
    def bound(self,key,value):
        self.tick()
        if value>self.limits[key]:raise ResourceLimit(key,self.work,_owner=_OWNER)


def _failure(error,w,stage):
    # The caller protects this entire attachment-only diagnostic path.
    error.marking_verifier_prefix=dict(schema='mirrored-marking-failure-prefix-v1',
        stage=stage if w is None else w.stage,work=0 if w is None else w.work,
        cost_available=w is not None,cost_is_lower_bound=w is None,
        complete=False,authority=False)


def _object(value,keys,reason):
    _need(type(value)is dict and all(type(k)is str for k in value)and
          set(value)==set(keys),reason)


def _number(value,w,low=None):
    w.tick();_need(type(value)is int,'exact builtin integer')
    if low is not None:_need(value>=low,'integer lower bound')
    w.bound('integer_abs',abs(value));return value


def _string(value,w):
    w.tick();_need(type(value)is str,'literal string channel/key')
    w.bound('string_chars',len(value))
    for char in value:
        w.tick();_need(not 0xD800<=ord(char)<=0xDFFF,'Unicode scalar strings only')
    return value


def _point(value,w,even=False):
    w.tick();_need(type(value)is list and len(value)==2,'two-integer point')
    x=_number(value[0],w);y=_number(value[1],w)
    if even:_need(x%2==0 and y%2==0,'origins in translation lattice2Z2')
    return (x,y)


def _same(a,b,w):
    pending=[(a,b)]
    while pending:
        w.tick();left,right=pending.pop()
        if type(left)is not type(right):return False
        kind=type(left)
        if kind is list:
            if len(left)!=len(right):return False
            pending.extend(zip(left,right))
        elif kind is dict:
            if set(left)!=set(right)or any(type(k)is not str for k in left):return False
            for key in left:pending.append((left[key],right[key]))
        elif kind in(str,int,bool)or left is None:
            if left!=right:return False
        else:return False
    return True


def _copy(value,w,depth=0,active=None):
    w.tick();w.bound('data_depth',depth)
    kind=type(value)
    if value is None or kind is bool:return value
    if kind is int:return _number(value,w)
    if kind is str:return _string(value,w)
    _need(kind in(list,dict),'ordinary JSON values only')
    if active is None:active=set()
    identity=id(value);_need(identity not in active,'acyclic ordinary data')
    active.add(identity)
    try:
        if kind is list:return [_copy(v,w,depth+1,active)for v in value]
        result={}
        for key,item in value.items():
            _string(key,w);result[key]=_copy(item,w,depth+1,active)
        return result
    finally:active.remove(identity)


def _marks(rows,w):
    _need(type(rows)is list,'complete literal marking rows')
    section={};parsed=[]
    for row in rows:
        w.tick();_need(type(row)is list and len(row)==3,'point/channel/value marking')
        p=_point(row[0],w);channel=_string(row[1],w);value=_number(row[2],w,0)
        key=(p,channel);_need(key not in section,'no duplicate assigned point/channel')
        section[key]=value;parsed.append((p,channel,value))
    return section,parsed


def _model(instance,w):
    w.stage='INSTANCE';_object(instance,BASE_KEYS,'exact finite unit-center instance')
    _need(instance['schema']=='finite-unit-center-point-instance-v1'and
          instance['transformations']=='translations_only_2Z2'and
          type(instance['all_root_generations'])is int and instance['all_root_generations']==0,
          'fixed translation-only generation-zero profile')
    raw=instance['required_centers'];_need(type(raw)is list,'literal complete centers')
    w.bound('centers',len(raw));centers=[];seen=set()
    for row in raw:
        p=_point(row,w,True);_need(p not in seen,'distinct required centers')
        centers.append(p);seen.add(p)
    _need(bool(centers),'nonempty declared finite target')
    _need(_same(instance['admissible_origins'],raw,w),'exact same ordered admissible origins')
    tiles=instance['tiles'];_need(type(tiles)is list,'complete literal tile list')
    _need(bool(tiles),'nonempty declared finite palette')
    w.bound('tiles',len(tiles));w.bound('candidates',len(centers)*len(tiles))
    tile_map={};ordered=[];mark_count=0;channels=set()
    for tile in tiles:
        w.tick();_object(tile,('id','t','m'),'exact unit tile fields')
        identity=_number(tile['id'],w,0);_need(identity not in tile_map,'distinct literal tile IDs')
        _need(_same(tile['t'],[[[0,0],1]],w),'unit-center positive support exactly')
        section,rows=_marks(tile['m'],w);mark_count+=len(rows);w.bound('marks',mark_count)
        for unused,channel,value in rows:channels.add(channel)
        tile_map[identity]=rows;ordered.append(identity)
    pins,pin_rows=_marks(instance['fixed_background_marks'],w)
    mark_count+=len(pin_rows);w.bound('marks',mark_count)
    for unused,channel,value in pin_rows:channels.add(channel)
    return dict(raw=instance,centers=centers,center_set=seen,tiles=tile_map,
                tile_ids=ordered,pins=pins,pin_rows=pin_rows,channels=channels,
                mark_count=mark_count)


def _placements(model,certificate,w):
    w.stage='POINT_VERIFICATION';_object(certificate,CERT_KEYS,'exact placement certificate')
    _need(certificate['schema']=='finite-unit-center-placement-certificate-v1',
          'unit-center certificate schema')
    raw=certificate['placements'];_need(type(raw)is list,'literal placement rows')
    _need(len(raw)==len(model['centers']),'exactly one placement per required center')
    selected={};marks={key:[value,1,True]for key,value in model['pins'].items()}
    for row in raw:
        w.tick();_object(row,('tile_id','origin'),'exact placement fields')
        tid=_number(row['tile_id'],w,0);origin=_point(row['origin'],w,True)
        _need(tid in model['tiles']and origin in model['center_set'],'literal allowed tile/origin')
        _need(origin not in selected,'one unit tile per center, no duplicate placement')
        selected[origin]=tid
        for (dx,dy),channel,value in model['tiles'][tid]:
            w.tick();p=(origin[0]+dx,origin[1]+dy);key=(p,channel)
            w.bound('integer_abs',abs(p[0]));w.bound('integer_abs',abs(p[1]))
            if key in marks:
                _need(marks[key][0]==value,'all assigned marking values agree, including0')
                marks[key][1]+=1
            else:marks[key]=[value,1,False]
    _need(set(selected)==model['center_set'],'full required target without extras')
    normalized=dict(schema='finite-unit-center-placement-certificate-v1',placements=[
        dict(tile_id=selected[p],origin=list(p))for p in model['centers']])
    section=[[[p[0],p[1]],channel,value,refs,fixed]
             for (p,channel),(value,refs,fixed)in sorted(marks.items())]
    return selected,normalized,section


def verify_tiling(instance,certificate,*,check,limits):
    w=None
    try:
        w=_Budget(check,limits);owned=_copy(instance,w);proof=_copy(certificate,w)
        model=_model(owned,w);selected,normalized,section=_placements(model,proof,w)
        totals=[]
        for p in model['centers']:w.tick();totals.append([list(p),1,0])
        _finish([owned,proof],[instance,certificate],w)
        w.stage='RETURN';w.tick();check()
        return dict(schema='independent-mirrored-unit-center-verification-v1',version=VERSION,
            status='VALID_EXACT_FINITE_TILING',certificate=normalized,
            totals=totals,marks=section,
            work=w.work,authority=False,formal_kernel_certified=False,
            general_fractional_or_mixed_generation_qualified=False)
    except BaseException as error:
        try:_failure(error,w,'VERIFY_TILING')
        except BaseException:pass
        raise


def _clauses(rows,model,w):
    _need(type(rows)is list,'ordered finite clause list');w.bound('clauses',len(rows))
    total=0
    for clause in rows:
        w.tick();_need(type(clause)is list,'ordered finite literal word')
        total+=len(clause);w.bound('literals',total)
        for literal in clause:
            w.tick();_object(literal,('origin','tile_id'),'exact placement literal')
            p=_point(literal['origin'],w,True);tid=_number(literal['tile_id'],w,0)
            _need(p in model['center_set']and tid in model['tiles'],'literal original placement')
    return rows  # Order, duplicates and contradictory repeated centers survive.


def _translation(base,clauses,compilation,w):
    w.stage='TRANSLATION';model=_model(base,w)
    _need(model['centers']and model['tile_ids'],'nonempty compiler base domain')
    _clauses(clauses,model,w);_object(compilation,COMP_KEYS,'exact compilation packet')
    _need(compilation['schema']=='unit-center-mirrored-marking-compilation-v1'and
          compilation['version']=='unit-center-mirrored-marking-compiler-v1'and
          compilation['status']=='MARKING_GADGET_CANDIDATE'and
          compilation['problem_defining']is True and compilation['redundancy_established']is False and
          compilation['mathematical_authority']is False and compilation['executed_source_qualified']is False,
          'problem-defining candidate, no redundancy authority')
    _need(_same(compilation['base'],base,w)and _same(compilation['clauses'],clauses,w),
          'exact complete original input binding')
    mapping=compilation['mapping']
    _object(mapping,('channels','base_tiles','roles','clause_states','auxiliary_tiles'),'exact mapping fields')
    channels=mapping['channels'];_object(channels,('anchor','choice','state'),'three fresh channels')
    fresh=[_string(channels[k],w)for k in('anchor','choice','state')]
    _need(len(set(fresh))==3 and not(set(fresh)&model['channels']),
          'globally fresh distinct assigned channels')
    anchor,choice,state=fresh
    roles=mapping['roles'];chains=mapping['clause_states']
    _need(type(roles)is list and type(chains)is list and len(chains)==len(clauses),
          'complete ordered role/chain declarations')
    role_count=sum(len(c)if c else 1 for c in clauses)
    _need(len(roles)==role_count,'one role per literal or one impossible empty role')
    w.bound('centers',len(model['centers'])+role_count)
    new_centers=[];seen_centers=set(model['centers']);state_points=set();cursor=0;state_total=0
    for ci,clause in enumerate(clauses):
        w.tick();chain=chains[ci];_object(chain,('clause','states','roles'),'exact chain fields')
        _need(type(chain['clause'])is int and chain['clause']==ci,'ordered clause identity')
        _need(type(chain['states'])is list and len(chain['states'])==(len(clause)+1 if clause else 0),
              'all and only nonempty-chain state points')
        for raw in chain['states']:
            p=_point(raw,w);_need(p not in state_points,'independent state points across all chains')
            state_points.add(p);state_total+=1
        expected_role_ids=[]
        for li in range(len(clause)if clause else 1):
            w.tick();row=roles[cursor];cursor+=1
            _object(row,('role','clause','literal_index','center','kind'),'exact role fields')
            p=_point(row['center'],w,True)
            _need(p not in seen_centers,'distinct new auxiliary centers outside original target')
            seen_centers.add(p);new_centers.append(p);expected_role_ids.append(cursor)
            _need(type(row['role'])is int and row['role']==cursor and
                  type(row['clause'])is int and row['clause']==ci,'ordered unique positive anchor role')
            if clause:
                _need(type(row['literal_index'])is int and row['literal_index']==li and row['kind']=='step',
                      'literal step role')
            else:_need(row['literal_index']is None and row['kind']=='empty','empty clause has untyped role')
        _need(_same(chain['roles'],expected_role_ids,w),'complete exact ordered chain roles')
    expected_tiles=[];base_map=[];aux_map=[];lookup={};mark_total=0;mirror_total=0
    for index,original in enumerate(base['tiles']):
        w.tick();marks=_copy(original['m'],w)
        marks.extend([[[0,0],choice,original['id']],[[0,0],anchor,0]])
        expected_tiles.append(dict(id=index,t=[[[0,0],1]],m=marks))
        base_map.append([index,original['id']]);mark_total+=len(marks)
        w.bound('tiles',len(expected_tiles));w.bound('marks',mark_total)
    for role in roles:
        if role['kind']=='empty':continue
        ci=role['clause'];li=role['literal_index'];literal=clauses[ci][li]
        rx,ry=role['center'];before=chains[ci]['states'][li];after=chains[ci]['states'][li+1]
        for original_id in model['tile_ids']:
            for incoming in(0,1):
                w.tick();outgoing=int(incoming==1 and original_id==literal['tile_id'])
                tid=len(expected_tiles)
                marks=[[[0,0],anchor,role['role']],
                    [[literal['origin'][0]-rx,literal['origin'][1]-ry],choice,original_id],
                    [[before[0]-rx,before[1]-ry],state,incoming],
                    [[after[0]-rx,after[1]-ry],state,outgoing]]
                # Independent literal-position derivation, not compiler code:
                # at role center r this offset assigns the original value at
                # p+d. The original prototype row order is retained exactly.
                # These are m rows only; auxiliary t stays its own unit center.
                for (dx,dy),channel,value in model['tiles'][original_id]:
                    w.tick();mx=literal['origin'][0]+dx-rx;my=literal['origin'][1]+dy-ry
                    w.bound('integer_abs',abs(mx));w.bound('integer_abs',abs(my))
                    w.bound('marks',mark_total+len(marks)+1)
                    marks.append([[mx,my],channel,value]);mirror_total+=1
                expected_tiles.append(dict(id=tid,t=[[[0,0],1]],m=marks));mark_total+=len(marks)
                aux_map.append([tid,role['role'],original_id,incoming,outgoing])
                lookup[(role['role'],original_id,incoming)]=tid
        w.bound('tiles',len(expected_tiles));w.bound('marks',mark_total)
    pins=_copy(base['fixed_background_marks'],w)
    pins.extend([[list(p),anchor,0]for p in model['centers']])
    pins.extend([[list(p),anchor,role['role']]for p,role in zip(new_centers,roles)])
    for chain in chains:
        if chain['states']:
            pins.append([list(chain['states'][0]),state,1]);pins.append([list(chain['states'][-1]),state,0])
    centers=[list(p)for p in model['centers']+new_centers]
    expected=dict(schema='finite-unit-center-point-instance-v1',transformations='translations_only_2Z2',
        required_centers=centers,admissible_origins=_copy(centers,w),tiles=expected_tiles,
        fixed_background_marks=pins,all_root_generations=0)
    _need(_same(mapping['base_tiles'],base_map,w)and _same(mapping['auxiliary_tiles'],aux_map,w),
          'all literal IDs and every auxiliary transition prototype')
    _need(_same(compilation['instance'],expected,w),'every emitted point value, tile anchor, pin and origin')
    counts=dict(original_tiles=len(model['tile_ids']),lifted_tiles=len(base_map),auxiliary_tiles=len(aux_map),
        auxiliary_centers=role_count,state_points=state_total,total_required_centers=len(centers),
        total_tiles=len(expected_tiles),prototype_mark_rows=mark_total,fixed_mark_rows=len(pins),
        full_candidate_universe=len(expected_tiles)*len(centers))
    _need(_same(compilation['construction_counts'],counts,w),'complete independent construction counts')
    passive=compilation['counts'];_need(type(passive)is dict,'passive operational counts')
    for key,value in passive.items():_string(key,w);_number(value,w,0)
    _need(type(passive.get('mirrored_original_mark_rows'))is int and
          passive['mirrored_original_mark_rows']==mirror_total,
          'complete successful auxiliary mirror-row counter')
    expanded=_model(compilation['instance'],w)
    return dict(base=model,expanded=expanded,clauses=clauses,roles=roles,chains=chains,
                channels=channels,base_map=base_map,aux_map=aux_map,lookup=lookup,counts=counts)


def _analyze(context,base_certificate,w):
    w.stage='LINEAR_STATE_CHECK';model=context['base']
    selected,normalized,unused=_placements(model,base_certificate,w)
    lift={original:emitted for emitted,original in context['base_map']}
    emitted={p:lift[selected[p]]for p in model['centers']};traces=[];allowed=True
    by_role={row['role']:row for row in context['roles']}
    for ci,clause in enumerate(context['clauses']):
        w.tick();states=[1]if clause else [];values=[]
        if not clause:allowed=False
        for li,literal in enumerate(clause):
            w.tick();value=selected[tuple(literal['origin'])];incoming=states[-1]
            outgoing=int(incoming==1 and value==literal['tile_id']);states.append(outgoing);values.append(value)
            role_id=context['chains'][ci]['roles'][li];role=by_role[role_id]
            emitted[tuple(role['center'])]=context['lookup'][(role_id,value,incoming)]
        satisfied=bool(clause)and states[-1]==0
        if not satisfied:allowed=False
        traces.append(dict(clause=ci,read_tile_ids=values,prefix_states=states,allowed=satisfied))
    extension=None
    if allowed:
        extension=dict(schema='finite-unit-center-placement-certificate-v1',placements=[
            dict(tile_id=emitted[p],origin=list(p))for p in context['expanded']['centers']])
        _placements(context['expanded'],extension,w)  # Direct full literal t/m cross-check.
    return dict(base_certificate=normalized,extension_exists=allowed,
                unique_extension=extension,traces=traces)


def _finish(owned,original,w):
    w.stage='INPUT_RECHECK'
    _need(_same(owned,_copy(original,w),w),'whole caller input changed during verification')


def verify_translation(base,clauses,compilation,*,check,limits):
    w=None
    try:
        w=_Budget(check,limits);raw=[base,clauses,compilation];owned=_copy(raw,w)
        context=_translation(owned[0],owned[1],owned[2],w)
        base_map=_copy(context['base_map'],w);aux_map=_copy(context['aux_map'],w)
        _finish(owned,raw,w)
        w.stage='RETURN';w.tick();check()
        return dict(schema='independent-mirrored-marking-translation-check-v1',version=VERSION,
            status='VALID_MARKING_GADGET_TRANSLATION',construction_counts=dict(context['counts']),
            base_tiles=base_map,auxiliary_tiles=aux_map,
            layout_scope='Validated declared layout; coherent alternate layouts may be valid. Canonical compiler codec equality is a separate check.',
            problem_defining=True,redundancy_established=False,work=w.work,
            authority=False,formal_kernel_certified=False)
    except BaseException as error:
        try:_failure(error,w,'VERIFY_TRANSLATION')
        except BaseException:pass
        raise


def analyze_base_assignment(base,clauses,compilation,base_certificate,*,check,limits):
    w=None
    try:
        w=_Budget(check,limits);raw=[base,clauses,compilation,base_certificate];owned=_copy(raw,w)
        context=_translation(owned[0],owned[1],owned[2],w);analysis=_analyze(context,owned[3],w)
        _finish(owned,raw,w);w.stage='RETURN';w.tick();check()
        return dict(schema='independent-mirrored-marking-base-analysis-v1',version=VERSION,
            status='EXACT_LINEAR_STATE_ANALYSIS',analysis=analysis,work=w.work,
            qualification_only=True,problem_defining=True,redundancy_established=False,
            authority=False,formal_kernel_certified=False)
    except BaseException as error:
        try:_failure(error,w,'ANALYZE_BASE_ASSIGNMENT')
        except BaseException:pass
        raise


def verify_projection(base,clauses,compilation,extended_certificate,*,check,limits):
    w=None
    try:
        w=_Budget(check,limits);raw=[base,clauses,compilation,extended_certificate];owned=_copy(raw,w)
        context=_translation(owned[0],owned[1],owned[2],w)
        selected,normalized,section=_placements(context['expanded'],owned[3],w)
        literal={emitted:original for emitted,original in context['base_map']}
        projected=[]
        for p in context['base']['centers']:
            w.tick();_need(selected[p]in literal,'only lifted base tile at original center')
            projected.append(dict(tile_id=literal[selected[p]],origin=list(p)))
        base_certificate=dict(schema='finite-unit-center-placement-certificate-v1',placements=projected)
        analysis=_analyze(context,base_certificate,w)
        _need(analysis['extension_exists']and _same(analysis['unique_extension'],normalized,w),
              'full projection and unique prefix-state extension correspondence')
        _finish(owned,raw,w);w.stage='RETURN';w.tick();check()
        return dict(schema='independent-mirrored-marking-projection-check-v1',version=VERSION,
            status='VALID_EXACT_PROJECTION_EXTENSION',base_certificate=base_certificate,
            extended_certificate=normalized,marks=section,traces=analysis['traces'],
            work=w.work,problem_defining=True,redundancy_established=False,
            authority=False,formal_kernel_certified=False)
    except BaseException as error:
        try:_failure(error,w,'VERIFY_PROJECTION')
        except BaseException:pass
        raise


def verify_extension(base,clauses,compilation,base_certificate,extended_certificate,*,check,limits):
    """Check the complete finite correspondence for one valid base tiling.

    None is accepted only when the checked chain has no extension. This is an
    independent linear consequence of the fully checked marking construction,
    not a complete auxiliary-assignment enumeration or a search invocation.
    """
    w=None
    try:
        w=_Budget(check,limits)
        raw=[base,clauses,compilation,base_certificate,extended_certificate];owned=_copy(raw,w)
        context=_translation(owned[0],owned[1],owned[2],w);analysis=_analyze(context,owned[3],w)
        if analysis['extension_exists']:
            _need(owned[4]is not None,'required full extension certificate')
            selected,normalized,section=_placements(context['expanded'],owned[4],w)
            _need(_same(normalized,analysis['unique_extension'],w),
                  'entire unique extension including literal base projection')
        else:
            _need(owned[4]is None,'no certificate exists for this forbidden base assignment')
            normalized=None
        _finish(owned,raw,w);w.stage='RETURN';w.tick();check()
        return dict(schema='independent-mirrored-marking-extension-check-v1',version=VERSION,
            status='VALID_EXTENSION_PROJECTION_RELATION',extension_exists=analysis['extension_exists'],
            certificate=normalized,base_certificate=analysis['base_certificate'],
            traces=analysis['traces'],work=w.work,necessity_scope='Independent linear prefix consequence; not full assignment enumeration.',
            problem_defining=True,redundancy_established=False,authority=False,formal_kernel_certified=False)
    except BaseException as error:
        try:_failure(error,w,'VERIFY_EXTENSION')
        except BaseException:pass
        raise
