"""Raw Source authoring/AST only; inherited lifecycle and resource gates unchanged."""
from pathlib import Path
import ast,hashlib,json
D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1');old=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1')
s=(old/'run_certified_point_search_once_v1.py').read_text()
s=s.replace("VERSION='certified-general-point-search-once-runner-v1'","VERSION='mirrored-receptor-comparison-once-runner-v1'")
s=s.replace("SOURCE_ROLES=frozenset(('worker','compiler','verifier','search','census','runner','observer'))","SOURCE_ROLES=frozenset(('worker','compiler','verifier','search','census','mirror_compiler','mirror_verifier','dpll','runner','observer'))")
s=s.replace("q['schema']=='certified-finite-point-search-integration-candidate-v1'","q['schema']=='mirrored-receptor-comparison-candidate-v1'").replace("q['status']=='COMPLETE_CERTIFIED_POINT_SEARCH_INTEGRATION_CANDIDATE'","q['status']=='COMPLETE_MIRRORED_RECEPTOR_COMPARISON_CANDIDATE'")
s=s.replace("'primitive_certificates_checked','marked_lane_uses_only_point_agreement'))","'primitive_certificates_checked','marked_lane_uses_only_point_agreement','mirror_and_DPLL_all_solutions_preserved','mirror_lane_uses_only_point_agreement','same_literal_certified_advice'))")
s=s.replace("len(q['diagnostics'])==18","len(q['diagnostics'])==31")
insert="""    need(q['component_case_ids']==declaration['component_case_ids']and
         [r['id']for r in q['component_rows']]==q['component_case_ids']and len(q['component_rows'])==162,
         'all original component cases retained')
    need([r['assignments_checked']for r in q['component_rows']]==declaration['component_assignment_counts']and
         sum(r['assignments_checked']for r in q['component_rows'])==697 and
         q['component_base_assignments']==697 and q['component_full_palette_assignments']==4214,
         'complete component assignment products')
    for r,exhausted in zip(q['component_rows'],declaration['component_full_palette_flags']):
        need(r['status']=='VERIFIED_TRANSLATION_AND_ALL_BASE_ASSIGNMENTS'and
             all(r[k]is True for k in('all_primitive_checks_passed','all_projection_checks_passed','all_uniqueness_checks_passed'))and
             r['full_palette_exhausted']is exhausted,'complete mirror construction/codec/exhaustion gate')
    need(q['component_diagnostic_ids']==declaration['component_diagnostic_ids']and
         [r['id']for r in q['component_diagnostics']]==q['component_diagnostic_ids']and len(q['component_diagnostics'])==15,
         'all original component diagnostics')
    for r,d in zip(q['component_diagnostics'],declaration['component_diagnostics']):
        need(r['status']=='PASSED'and r['operation']==d['operation']and r['expectation_satisfied']is True,
             'component diagnostic expected disposition')
        if 'foreign'in r['operation']:need(r['exact_foreign_identity']is True and r['local_callbacks']==1,'component exact foreign callback object')
    for key in('mirror_compiler_calls','mirror_verifier_calls','DPLL_calls'):
        need(type(q[key])is int and q[key]>0,'new actual component call census')
"""
needle="    need(type(q['root_check_calls'])is int"
assert needle in s;s=s.replace(needle,insert+needle)
s=s.replace("profile='certified-general-point-search-integration'","profile='mirrored-receptor-same-advice-comparison'")
s=s.replace('One Root-owned complete finite Wang calibration; inherited bounded cleanup.','One Root-owned complete mirror/DPLL comparison; inherited bounded cleanup.')
p=D/'run_mirrored_receptor_once_v1.py';p.write_text(s)
s=(old/'observe_certified_point_search_once_v1.py').read_text().replace("VERSION='certified-general-point-search-terminal-observer-v1'","VERSION='mirrored-receptor-comparison-terminal-observer-v1'").replace('Finite certified unit-center point search integration only;','Finite mirror component and same-advice search comparison only;')
p=D/'observe_mirrored_receptor_once_v1.py';p.write_text(s)
rows=[]
for p in [D/'run_mirrored_receptor_once_v1.py',D/'observe_mirrored_receptor_once_v1.py']:
 raw=p.read_bytes();tree=ast.parse(raw);compile(tree,str(p),'exec');rows.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
print(json.dumps({'Sources':rows,'subject_calls':0},sort_keys=True))
