"""Source-only generic finite point-to-CNF/DPLL control; no imports.

Separate conventional scheduling, not the GCTS graph. Full original placement
universe, exactly-one centers, original pins/mark conflicts and supplied
forbidden conjunctions. No proof/reference/extension supplied to search.
"""
VERSION='finite-unit-center-CNF-DPLL-control-v1'
_OWNER=object()
LIMIT_KEYS=('work','centers','tiles','marks','variables','clauses','literals',
            'decisions','trace_rows','solutions','integer_abs','string_chars','data_depth')
BASE_KEYS=('schema','transformations','required_centers','admissible_origins','tiles',
           'fixed_background_marks','all_root_generations')
class Invalid(ValueError):
    def __init__(self,reason,*,owner=None):self.reason=reason;self.owner=owner;super().__init__(reason)
class Limit(RuntimeError):
    def __init__(self,reason,*,owner=None):self.reason=reason;self.owner=owner;super().__init__(reason)
def is_own_invalid(error):return type(error)is Invalid and error.owner is _OWNER
def is_own_limit(error):return type(error)is Limit and error.owner is _OWNER
def need(ok,message):
    if not ok:raise Invalid(message,owner=_OWNER)
class Budget:
    def __init__(self,check,limits):
        need(callable(check)and type(limits)is dict and set(limits)==set(LIMIT_KEYS),'exact limits and callback')
        need(all(type(k)is str and type(v)is int and v>0 for k,v in limits.items()),'literal positive limits')
        need(limits['data_depth']<=128,'depth ceiling')
        self.check=check;self.limits=dict(limits);self.work=0;self.check()
    def tick(self):
        self.work+=1
        if self.work>self.limits['work']:raise Limit('work',owner=_OWNER)
        if self.work%1024==0:self.check()
    def cap(self,key,value):
        self.tick()
        if value>self.limits[key]:raise Limit(key,owner=_OWNER)
    def integer(self,v,low=None):
        self.tick();need(type(v)is int and(low is None or v>=low),'exact integer')
        self.cap('integer_abs',abs(v));return v
    def string(self,v):
        self.tick();need(type(v)is str,'literal string');self.cap('string_chars',len(v))
        for c in v:self.tick();need(not 0xD800<=ord(c)<=0xDFFF,'Unicode scalar')
        return v
    def point(self,p,even=False):
        self.tick();need(type(p)is list and len(p)==2,'literal point')
        q=tuple(self.integer(x)for x in p)
        need(not even or all(x%2==0 for x in q),'even translation origin');return q
    def copy(self,v,depth=0,active=None):
        self.tick();self.cap('data_depth',depth);t=type(v)
        if v is None or t is bool:return v
        if t is int:return self.integer(v)
        if t is str:return self.string(v)
        need(t in(list,dict),'strict acyclic JSON data')
        if active is None:active=set()
        identity=id(v);need(identity not in active,'acyclic data');active.add(identity)
        try:
            if t is list:return [self.copy(x,depth+1,active)for x in v]
            return {self.string(k):self.copy(x,depth+1,active)for k,x in v.items()}
        finally:active.remove(identity)
def fields(value,keys):need(type(value)is dict and set(value)==set(keys),'exact object fields')
def parse_marks(rows,w):
    need(type(rows)is list,'literal marking list');result={}
    for row in rows:
        w.tick();need(type(row)is list and len(row)==3,'mark row')
        key=(w.point(row[0]),w.string(row[1]));value=w.integer(row[2],0)
        need(key not in result,'distinct assigned mark keys');result[key]=value
    return result

def solve(instance,forbidden,*,check,limits):
    w=None;assigned={};trail=[];frames=[];trace=[];solutions=[];cnf=[];provenance=[]
    statistics={'branch_decisions':0,'branch_attempts':0,'unit_assignments':0,'conflicts':0,'literal_visits':0}
    try:
        w=Budget(check,limits);base=w.copy(instance);clauses=w.copy(forbidden)
        fields(base,BASE_KEYS)
        need(base['schema']=='finite-unit-center-point-instance-v1'and base['transformations']=='translations_only_2Z2'and type(base['all_root_generations'])is int and base['all_root_generations']==0,'finite unit-center scope')
        need(type(base['required_centers'])is list and type(base['admissible_origins'])is list,'literal required/allowed origin arrays')
        centers=[w.point(p,True)for p in base['required_centers']];w.cap('centers',len(centers))
        admitted=[w.point(p,True)for p in base['admissible_origins']];w.cap('centers',len(admitted))
        need(centers==admitted,'same strictly parsed ordered required/allowed centers')
        need(bool(centers)and len(set(centers))==len(centers),'nonempty distinct centers')
        need(type(base['tiles'])is list and bool(base['tiles']),'nonempty full palette');w.cap('tiles',len(base['tiles']))
        tiles=[];ids=set();mark_count=0
        for tile in base['tiles']:
            w.tick();fields(tile,('id','t','m'));tid=w.integer(tile['id'],0)
            need(tid not in ids,'distinct tile IDs');ids.add(tid)
            need(type(tile['t'])is list and len(tile['t'])==1 and type(tile['t'][0])is list and len(tile['t'][0])==2 and w.point(tile['t'][0][0])==(0,0)and type(tile['t'][0][1])is int and tile['t'][0][1]==1,'exact single unit center')
            m=parse_marks(tile['m'],w);mark_count+=len(m);w.cap('marks',mark_count);tiles.append((tid,m))
        pins=parse_marks(base['fixed_background_marks'],w);mark_count+=len(pins);w.cap('marks',mark_count)
        variables=[];lookup={};sections=[];nc=len(centers);nt=len(tiles);w.cap('variables',nc*nt)
        for pi,p in enumerate(centers):
            for ti,(tid,m)in enumerate(tiles):
                w.tick();var=len(variables)+1;lookup[(p,tid)]=var;variables.append({'variable':var,'point':pi,'origin':list(p),'tile_id':tid});section={}
                for (offset,ch),value in m.items():
                    w.tick();absolute=(p[0]+offset[0],p[1]+offset[1]);w.integer(absolute[0]);w.integer(absolute[1]);section[(absolute,ch)]=value
                sections.append(section)
        literal_count=0
        def emit(row,reason):
            nonlocal literal_count
            w.tick();literal_count+=len(row);w.cap('clauses',len(cnf)+1);w.cap('literals',literal_count)
            cnf.append(row);provenance.append(reason)
        for pi in range(nc):
            group=list(range(pi*nt+1,(pi+1)*nt+1));emit(group,{'kind':'AT_LEAST_ONE','point':pi})
            for i in range(nt):
                for j in range(i+1,nt):w.tick();emit([-group[i],-group[j]],{'kind':'AT_MOST_ONE','point':pi})
        for i,section in enumerate(sections):
            for key,value in section.items():
                w.tick()
                if key in pins and pins[key]!=value:
                    emit([-i-1],{'kind':'ORIGINAL_PIN_CONFLICT','variable':i+1,'point':list(key[0]),'channel':key[1],'candidate_value':value,'pin_value':pins[key]});break
            for j in range(i+1,len(sections)):
                w.tick()
                if i//nt==j//nt:continue
                for key,value in section.items():
                    w.tick()
                    if key in sections[j]and sections[j][key]!=value:
                        emit([-i-1,-j-1],{'kind':'ORIGINAL_MARK_CONFLICT','left':i+1,'right':j+1,'point':list(key[0]),'channel':key[1],'left_value':value,'right_value':sections[j][key]});break
        need(type(clauses)is list,'literal forbidden conjunctions')
        for ci,clause in enumerate(clauses):
            w.tick();need(type(clause)is list,'literal conjunction');row=[]
            for literal in clause:
                w.tick();fields(literal,('origin','tile_id'));p=w.point(literal['origin'],True);tid=w.integer(literal['tile_id'],0);need((p,tid)in lookup,'original placement literal');row.append(-lookup[(p,tid)])
            # Preserve repeated and contradictory reads literally in the archived CNF.
            emit(row,{'kind':'SUPPLIED_LITERAL_FORBIDDEN_CONJUNCTION','clause_index':ci})
        def event(kind,**data):
            w.cap('trace_rows',len(trace)+1);trace.append(dict(kind=kind,**data))
        def assign(variable,value,kind):
            w.tick();need(variable not in assigned,'assign unbound variable');assigned[variable]=value;trail.append(variable);event(kind,variable=variable,value=value)
        def undo(checkpoint):
            w.tick()
            while len(trail)>checkpoint:w.tick();del assigned[trail.pop()]
            event('rollback',checkpoint=checkpoint)
        def propagate():
            while True:
                w.tick();unit=None;choice=None
                for ci,row in enumerate(cnf):
                    w.tick();open_values=[];seen=set();satisfied=False
                    for literal in row:
                        w.tick();statistics['literal_visits']+=1;variable=abs(literal);value=assigned.get(variable)
                        if value is not None:
                            if value is(literal>0):satisfied=True;break
                        elif literal not in seen:seen.add(literal);open_values.append(literal)
                    if satisfied:continue
                    if not open_values:return 'CONFLICT',ci
                    if len(open_values)==1 and unit is None:unit=open_values[0]
                    if choice is None or len(open_values)<len(choice):choice=open_values
                if unit is not None:
                    statistics['unit_assignments']+=1;assign(abs(unit),unit>0,'unit');continue
                if choice is None:return 'SOLUTION',None
                return 'BRANCH',abs(choice[0])
        while True:
            w.tick();kind,value=propagate()
            if kind=='BRANCH':
                statistics['branch_decisions']+=1;w.cap('decisions',statistics['branch_decisions']);frames.append([len(trail),value,1]);statistics['branch_attempts']+=1;assign(value,True,'branch');continue
            if kind=='SOLUTION':
                need(len(assigned)==len(variables),'exact-one clauses fully determine every variable')
                placement=[]
                for pi,p in enumerate(centers):
                    w.tick();selected=[]
                    for i in range(pi*nt,(pi+1)*nt):
                        w.tick()
                        if assigned[i+1]:selected.append(variables[i])
                    need(len(selected)==1,'unique point choice');placement.append({'origin':list(p),'tile_id':selected[0]['tile_id']})
                w.cap('solutions',len(solutions)+1);solutions.append({'schema':'finite-unit-center-placement-certificate-v1','placements':placement});event('solution',index=len(solutions)-1)
            else:statistics['conflicts']+=1;event('conflict',clause_index=value)
            resumed=False
            while frames:
                cp,var,next_value=frames[-1];undo(cp)
                if next_value==1:
                    frames[-1][2]=2;statistics['branch_attempts']+=1;assign(var,False,'branch');resumed=True;break
                frames.pop()
            if not resumed:break
        undo(0);w.check()
        return {'schema':'finite-point-DPLL-result-v1','version':VERSION,'status':'ALL_SOLUTIONS_EXHAUSTED','exhausted':True,'instance':base,'forbidden':clauses,'variables':variables,'CNF':cnf,'clause_provenance':provenance,'solutions':solutions,'trace':trace,'statistics':dict(statistics,work=w.work,variables=len(variables),clauses=len(cnf),literals=literal_count),'root_restored':not assigned and not trail and not frames,'authority':False,'scheduling':'Conventional CNF unit propagation, then shortest unsatisfied clause first literal, true/false complete binary DFS. Separate from GCTS scheduler.'}
    except BaseException as error:
        if not is_own_limit(error):raise
        return {'schema':'finite-point-DPLL-result-v1','version':VERSION,'status':'UNKNOWN','exhausted':False,'reason':error.reason,'work':None if w is None else w.work,'partial_solutions':solutions,'trace':trace,'authority':False}
    finally:
        # Owned local state only. No callbacks or exception translation during cleanup.
        assigned.clear();trail.clear();frames.clear()
