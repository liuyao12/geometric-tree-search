"""Passive saved-candidate HTML/data/archive projection; no subject/replay calls."""
from pathlib import Path
import json,hashlib,tarfile,gzip,io
D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1')
P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
O=D/'publication';O.mkdir(exist_ok=True)
packet=json.loads((D/'actual-comparison-v2/canonical-mirrored-receptor-comparison.json').read_bytes())
summary=json.loads((D/'ROOT-passive-unqualified-observations-v2.json').read_bytes())
assert summary['qualification_status']=='OUTER_GATE_REJECTED_UNQUALIFIED'and summary['mathematical_adoption']is False
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,value):
 (O/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def tex(f,variables):
 if f[0]=='var':return variables[f[1]]
 if f[0]=='not':return r'\neg '+tex(f[1],variables)
 op={'imp':r'\to','and':r'\land','or':r'\lor'}[f[0]]
 return r'\bigl('+tex(f[1],variables)+' '+op+' '+tex(f[2],variables)+r'\bigr)'
ordinals=['first','second','third','fourth','fifth','sixth','seventh','eighth']
def ordinal(i):return ordinals[i] if i<len(ordinals) else 'indexed '+str(i)
def assignment_reading(row,pi,original_id):
 meta=row['symbolic_metadata']
 if not meta:return 'Select this original point prototype.'
 base=row['model'];origin=base['required_centers'][pi];tile=next(t for t in base['tiles']if t['id']==original_id)
 values=[]
 for off,ch,v in tile['m']:
  target=[origin[0]+off[0],origin[1]+off[1]]
  if ch==meta['truth_channel']and target in meta['truth_points']:
   vi=meta['truth_points'].index(target);values.append('the '+ordinal(vi)+' variable is '+('true'if v else'false'))
 return ('Choose a variable value: 'if pi<len(meta['variable_roles'])else'Choose a satisfying local clause assignment: ')+', and '.join(values)+'.'
def translate_trace(row,lane):
 out=[];n=len(row['model']['required_centers']);mapping=row['compilation']['mapping'];basemap=dict(mapping['base_tiles']);auxmap={a[0]:a[1:]for a in mapping['auxiliary_tiles']}
 roles={a['role']:a for a in mapping['roles']}
 for i,e in enumerate(row[lane]['result']['trace']):
  k=e['kind'];reading=None
  if k in('branch','forced'):
   prefix='Try a branch. 'if k=='branch'else'The complete graph forces this placement. '
   if lane=='marked'and e['point']>=n:
    role,old,incoming,outgoing=auxmap[e['tile_id']];rr=roles[role]
    reading=prefix+'Place an auxiliary receptor for the '+ordinal(rr['clause'])+' failure certificate, reading the '+ordinal(rr['literal_index'])+' selected-support literal. Its exact type, choice and prefix values are in the saved event and prototype data.'
   else:
    old=basemap[e['tile_id']]if lane=='marked'else e['tile_id']
    reading=prefix+assignment_reading(row,e['point'],old)
  elif k=='census':
   decision=e.get('decision')
   reading={'DEAD':'The full point graph has an unfilled center with no compatible prototype.','COMPLETE':'All required centers are covered.','BRANCH':'No global dead or forced center remains; choose at the earliest generation.','FORCED':'At least one global forced center must be filled before branching.'}.get(decision,'Record the complete graph decision.')
  elif k=='rollback':reading='Undo placements and markings to this saved branch checkpoint.'
  elif k=='rollback_census':reading='Recheck the full graph after rollback.'
  elif k=='solution_candidate':reading='Return a complete finite placement candidate; the independent point checker checks it separately.'
  elif k=='enumeration_subtree_exhausted':reading='All recorded alternatives in this subtree have been traversed; return to its parent.'
  elif k=='raw_deadpoint_candidate':reading='Export an original-marking dead-point candidate for separate certification.'
  elif k=='raw_deadpoint_abstain':reading='No original-marking dead-point certificate is exported at this state.'
  elif k=='raw_deadpoint_acquisition_disabled':reading='Failure acquisition is disabled in this search lane.'
  elif k=='root_cleanup_complete':reading='Restore the original root graph and finish this search invocation.'
  assert reading is not None,('untranslated saved event',k)
  out.append({'index':i,'kind':k,'reading':reading})
 return out

# Display-only readout of complete saved data; never evaluate legality or a theorem.
rows=[]
for row in packet['rows']:
 lanes={}
 for lane in('plain','acquisition','marked','mirrored','dpll_plain','dpll_certified'):
  raw=row[lane];is_gadget=lane in('marked','mirrored');comp=row['mirror_compilation'if lane=='mirrored'else'compilation']if is_gadget else None;model=comp['instance']if is_gadget else row['model'];views=[]
  if raw['result']['solutions']:
   views.append({'label':'Saved complete candidate certificate','scope':'Unqualified saved candidate certificate and its worker-recorded independent point-check marking section. The original outer gate remains rejected.','section':{'placements':raw['result']['solutions'][0]['placements'],'marks':raw['solution_checks'][0]['marks']}})
  if lane.startswith('dpll'):
   s=row['plain']['retained_snapshots']['initial']
   if not views:views.append({'label':'Original boundary context','scope':'Boundary context copied from the separate original point-search initial snapshot, not a DPLL search state. The DPLL assignment trace is below.','section':{'placements':[],'marks':s['marks']}})
   english=[]
   for i,e in enumerate(raw['result']['trace']):
    kind=e['kind']
    if kind in('branch','unit'):
     var=raw['result']['variables'][e['variable']-1]
     reading=('Try a Boolean branch. 'if kind=='branch'else'Unit propagation fixes a Boolean selection variable. ')+('Include this original prototype at the required center. '+assignment_reading(row,var['point'],var['tile_id'])if e['value']else'Exclude this original prototype at its declared center. Its exact variable and placement are in the raw trace and variable table.')
    elif kind=='rollback':reading='Restore the Boolean assignment trail to this saved checkpoint.'
    elif kind=='conflict':reading='An encoded clause has no true or unassigned literal under this assignment. Backtrack.'
    else:
     assert kind=='solution';reading='Save a complete original-placement candidate for separate raw point checking.'
    english.append({'index':i,'kind':kind,'reading':reading})
   cnf={k:raw['result'][k]for k in('variables','CNF','clause_provenance')}
  else:
   for key,label in [('first_dead','First retained dead state'),('first_branch','First retained branch state'),('initial','Initial full graph'),('root_restored','Restored root')]:
    s=raw['retained_snapshots'].get(key)
    if s is not None:views.append({'label':label,'scope':'Unqualified saved '+s['reason']+' state: selected placements and its complete recorded marking section, not every historical graph.','section':{'placements':[{'tile_id':c[2],'origin':model['required_centers'][c[1]]}for c in s['chosen']],'marks':s['marks']}})
   display_row=row if lane!='mirrored'else dict(row,compilation=row['mirror_compilation'],marked=row['mirrored'])
   english=translate_trace(display_row,'marked'if lane=='mirrored'else lane);cnf=None
  lanes[lane]={'views':views,'trace':raw['result']['trace'],'english_events':english,'CNF':cnf}
 proofs=[]
 for i,p in enumerate(row['acquisition']['proofs']):
  c=p['candidate'];receipt=p['receipt'];proofs.append({'label':'Saved failure witness '+str(i+1),'reading':'Unqualified-run evidence: the worker recorded an independent same-instance primitive-certificate check. The original full-run outer gate failed; this display does not admit that run.','clause':receipt['clause'],'witnesses':receipt['witnesses'],'center':c['center']})
 domains=[]
 if row['compilation']['mapping']['roles']:
  for label,key,lane in [('Old first receptor','compilation','marked'),('Mirrored first receptor','mirror_compilation','mirrored')]:
   comp=row[key];role=comp['mapping']['roles'][0];center=comp['instance']['required_centers'].index(role['center']);cids=row[lane]['retained_snapshots']['initial']['forward'][center][1];np=len(comp['instance']['tiles']);aux={a[0]:a[2]for a in comp['mapping']['auxiliary_tiles']};choices=sorted(set(aux[comp['instance']['tiles'][cid%np]['id']]for cid in cids))
   domains.append({'label':label,'candidates':len(cids),'choices':choices})
  literal=row['certified_clauses'][0][0];pi=row['model']['required_centers'].index(literal['origin']);np=len(row['model']['tiles']);cids=row['plain']['retained_snapshots']['initial']['forward'][pi][1]
  domains.insert(0,{'label':'Referenced original base point','candidates':len(cids),'choices':sorted(set(row['model']['tiles'][cid%np]['id']for cid in cids))})
 formula=row['input'].get('formula');count=row['original_solution_count']
 display_formula=tex(formula,row['input']['variables'])if formula else None
 if not formula and row['input']['kind']=='propositional':
  parts=[]
  for clause in row['input']['clauses']:
   terms=[(''if positive else r'\neg ')+row['input']['variables'][v]for v,positive in clause]
   parts.append(r'\bigl('+r'\lor '.join(terms)+r'\bigr)'if terms else r'\bot')
  display_formula=r'\land '.join(parts)if parts else r'\top'
 formula_scope='Displayed: the named statement, whose encoded negation is searched.'if formula else 'Displayed: the original clause constraint; search enumerates its satisfying assignments.'if row['input']['kind']=='propositional'else'Literal finite point-domain control.'
 rows.append({'id':row['id'],'input':row['input'],'formula_tex':display_formula,'reading':'UNQUALIFIED saved worker candidate: '+str(count)+' original solutions reported; original outer gate rejected.','scope':formula_scope+' Input-specific palette; no serialized first-order kernel proof or current full-run qualification.','model':row['model'],'marked_instance':row['compilation']['instance'],'mapping':row['compilation']['mapping'],'mirror_instance':row['mirror_compilation']['instance'],'mirror_mapping':row['mirror_compilation']['mapping'],'lanes':lanes,'proofs':proofs,'initial_domains':domains})
write('mirrored-receptors-data.json',{'schema':'unqualified-saved-mirrored-reader-v1','qualification_status':'OUTER_GATE_REJECTED_UNQUALIFIED','display_only':True,'rows':rows})
write('mirrored-receptors-summary.json',summary)
M=lambda v:r'\('+str(v)+r'\)'
outcome='<div class="notice"><b>Unqualified run: the worker finished, but the outer gate rejected it.</b><p>The worker wrote all '+M(185)+' case rows and '+M(46)+' diagnostic rows. Its saved packet reports the complete '+M(162)+'-translation, '+M(697)+'-base-assignment and '+M(4214)+'-raw-assignment component bank, plus all '+M(23)+' search cases. The worker exited successfully; the runner exited with a failed gate.</p></div><p>The controller misclassified the malformed-input test <code>foreign_literal_id</code> as a foreign-callback test because it searched the operation name for a substring. That row correctly records a declaration refusal with no callback. The three actual component callback rows record the exact foreign object once. Root and the independent reviewer missed this controller defect before execution; it is preserved in the evidence.</p><p>No rerun or post-hoc validator replaces this outcome. The grant is retired. A separate future Source correction uses explicit operation classes and requires a new reviewed full qualification. The reader below exposes saved candidate observations, not an admitted complete result.</p>'
comparison='<p class="lead">The saved observations show no pruning benefit.</p><p>Plain, old-receptor and mirrored point search each record '+M(summary['mirror_base_branch_attempts'])+' base branch attempts. Both receptor arms record '+M(0)+' base-candidate removal events on auxiliary placements. DPLL with and without the same certified clauses each records '+M(summary['DPLL_plain_Boolean_branch_attempts'])+' Boolean branch attempts; Boolean and placement attempts are different units.</p><div class="wrap"><table><thead><tr><th>Saved phase observation</th><th>Summed seconds</th></tr></thead><tbody>'
for label,key in [('Old receptor cold arm','old_cold_seconds_sum'),('Mirrored receptor cold arm','mirror_cold_seconds_sum'),('DPLL without acquired clauses','DPLL_plain_seconds_sum'),('DPLL with acquired clauses, cold','DPLL_certified_cold_seconds_sum')]:comparison+='<tr><td>'+label+'</td><td>'+M(round(summary[key],6))+'</td></tr>'
comparison+='</tbody></table></div><p>Each cold advice arm includes its own fresh original acquisition and certification; the literal clause lists were required to agree. The DPLL phases include generic point-to-CNF translation and raw returned-solution checking. These are single instrumented, outer-rejected observations. DPLL is a simple homegrown control, not an optimized external solver or a state-of-art benchmark. Its lower recorded cost does not establish a general comparison.</p><p>The whole worker/runner observation ended in '+M(round(summary['terminal_seconds'],6))+' seconds. Worker high-water memory was '+M(summary['worker_peak_bytes'])+' bytes; the stored packet plus result was '+M(summary['stored_packet_and_result_bytes'])+' bytes. Cleanup and negative custody closed within the original window. The original positive terminal gate remains false. Full component derivation, guards and serialization are included in the whole elapsed observation; there is no separate component-bank timer.</p>'
fixed=r'''<section id="fixed-VM"><h2>A separate first-order encoding advance</h2><p>The earlier conditional full-checker palette-size calculation now has independent Source review: \(46\) checks with no mismatches. Under the unchanged compiler/lowering accepting the complete checker, the retained palette lower bound is \(2735636499\) tiles. Sparse enumeration removes rejected combinations but does not solve that output-size obstacle. This is a conditional Source deduction, not a materialized table or runtime result.</p><p>The new fixed-interpreter contract keeps the checker program and unbounded addresses in encoded tape data. It specifies \(13\) bytecode operations, exact registers, heap and call frames, immutable program/public problem bands and a free certificate band. The square-tile palette would implement one fixed interpreter rather than allocate states per program instruction.</p><p>This design remains unimplemented. It requires a fully expanded transition table, an independently reviewed size census, semantic correspondence for every scan macro and opcode, and an actual point-encoded initializer that binds the theory and target while varying only the certificate. Canonical byte-to-string decoding, including the host checker’s Unicode policy, is an explicit additional gate. No universal first-order palette, arithmetic or Hilbert proof discovery is claimed.</p><p>The Source audit and complete interpreter contract are included in the evidence archive.</p></section>'''
page=(D/'mirrored-receptors-template.html').read_text().replace('__OUTCOME__',outcome).replace('__COMPARISON__',comparison).replace('__FIXED_VM__',fixed)
page=page.replace('<b>Scope:</b> a finite propositional and point-domain control.','<b>Scope:</b> saved observations from an outer-rejected finite propositional and point-domain run.').replace('Inspect an acquired failure','Inspect a saved candidate failure').replace('The complete declared run','The full worker and rejected controller gate')
page=page.replace('<details><summary>Complete saved event trace</summary>', '<details><summary>Conventional CNF and provenance for this lane</summary><pre id="cnf"></pre></details><details><summary>Complete saved event trace</summary>')
page=page.replace("$('prototypes').textContent=JSON.stringify(key==='mirrored'?active.mirror_instance:key==='marked'?active.marked_instance:active.model,null,2);","$('cnf').textContent=l.CNF?JSON.stringify(l.CNF,null,2):'This lane uses the point graph; no CNF is passed to it.';$('prototypes').textContent=JSON.stringify(key==='mirrored'?active.mirror_instance:key==='marked'?active.marked_instance:active.model,null,2);")
page=page.replace('Read the saved search','Read the unqualified saved candidate').replace('The literal worker result remains a candidate; any Root adoption is limited to the declared finite experiment.','The literal worker result remains an unqualified candidate. Root has not admitted this run; the original outer gate and terminal flag remain false.')
(O/'mirrored-receptors.html').write_text(page)
pre=(P/'reader.html').read_bytes();(D/'reader-preimage.html').write_bytes(pre);assert pre.count(b'</main>')==1
append=r'''<section id="mirrored-receptor-comparison"><h2>Mirrored receptors: complete candidate packet, rejected outer gate</h2><p>The <a href="mirrored-receptors.html#reader">new saved reader</a> compares old and mirrored receptor markings with a conventional DPLL control. The worker wrote all \(185\) case rows and \(46\) diagnostics, but the controller mistook <code>foreign_literal_id</code> for a callback test. The original gate remains rejected; no current full-run qualification or rerun is admitted.</p><p>The unqualified observations show no base-branch reduction and no base removals from auxiliary placements. A separate <a href="mirrored-receptors.html#fixed-VM">independently reviewed conditional size audit and fixed-interpreter design</a> advances the first-order encoding plan; a concrete transition table and semantic correspondence remain open.</p></section>'''.encode()
(O/'reader.html').write_bytes(pre.replace(b'</main>',append+b'</main>'))
write('reader-append-custody.json',{'preimage':pin(D/'reader-preimage.html'),'postimage':pin(O/'reader.html'),'append_bytes':len(append),'append_sha256':hashlib.sha256(append).hexdigest(),'append_only':True})


# Exact raw evidence custody, with detached publication review excluded.
files=[]
def add(label,p):
 p=Path(p);assert p.is_file()and not p.is_symlink()and p.name!='index.html';files.append((label,p))
for p in sorted(D.iterdir()):
 if p.is_file()and p.suffix in('.py','.txt','.json','.md','.html'):add('Root/'+p.name,p)
for sub in ['actual-comparison-v2','plan-authorized-v2-terminal-observation','prospective-v1-negative']:
 for p in sorted((D/sub).iterdir()):
  if p.is_file():add('Root/'+sub+'/'+p.name,p)
roles=json.loads((D/'plan-authorized-v2.json').read_bytes())['sources']
for role,row in roles.items():add('executed-Sources/'+role+'/'+Path(row['path']).name,row['path'])
directories=[('mirror-library','/private/tmp/gcts-mirrored-receptor-library-20261019-v1'),('mirror-verifier-V1','/private/tmp/gcts-mirrored-receptor-verifier-20261019-v1'),('mirror-verifier-V2','/private/tmp/gcts-mirrored-receptor-verifier-20261019-v2'),('DPLL-independent-review','/private/tmp/gcts-point-CNF-control-review-20261019-v1'),('peer-reviews','/private/tmp/gcts-mirrored-receptor-peer-20261019-v1')]
for label,path in directories:
 for p in sorted(Path(path).iterdir()):
  if p.is_file()and p.suffix in('.py','.json','.html','.md'):add(label+'/'+p.name,p)
for label,path,names in [('fixed-checker-audit','/private/tmp/gcts-fixed-checker-feasibility-20261019-v1',['handoff-v1.json','source-metadata-v1.json','feasibility-note-v1.html','fixed-checker-combined-plaintext-v1.tree']),('fixed-VM-design','/private/tmp/gcts-fixed-VM-design-peer-20261019-v1',['typed-fixed-checker-feasibility-Source-review-v1.json','fixed-interpreter-encoding-contract-v1.json']),('input-search-ancestor','/private/tmp/gcts-certified-point-search-ROOT-20261019-v1',['cohort-inputs-v1.json','qualify_certified_point_search_worker_v1.py','ROOT-final-milestone-v1.json']),('input-component-ancestor','/private/tmp/gcts-marking-implementation-ROOT-20261019-v1',['cohort-inputs-v1.json','qualify_marking_worker_v1.py'])]:
 for name in names:add(label+'/'+name,Path(path)/name)
for key,row in json.loads(Path('/private/tmp/gcts-fixed-checker-feasibility-20261019-v1/source-metadata-v1.json').read_bytes())['pins'].items():
 p=Path(row['path']);assert str(p).startswith('/private/tmp/')and pin(p)['sha256']==row['sha256'];add('fixed-checker-Sources/'+key+'/'+p.name,p)
paths=[dict(archive_member=label,**pin(p))for label,p in files];pathmap=(json.dumps({'schema':'unqualified-mirrored-evidence-pathmap-v1','status':'OUTER_GATE_REJECTED_UNQUALIFIED','members':paths},sort_keys=True,indent=2)+'\n').encode()
archive=O/'mirrored-receptors-evidence.tar.gz'
with archive.open('wb')as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tf:
   for label,p in files+[('PATHMAP.json',None)]:
    b=pathmap if p is None else p.read_bytes();info=tarfile.TarInfo(label);info.size=len(b);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz')as tf:
 assert tf.getnames()==[label for label,p in files]+['PATHMAP.json']
 for row in paths:
  b=tf.extractfile(row['archive_member']).read();assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
write('mirrored-receptors-manifest.json',{'schema':'unqualified-mirrored-publication-manifest-v1','qualification_status':'OUTER_GATE_REJECTED_UNQUALIFIED','mathematical_adoption':False,'report':pin(O/'mirrored-receptors.html'),'data':pin(O/'mirrored-receptors-data.json'),'summary':pin(O/'mirrored-receptors-summary.json'),'notebook':pin(O/'reader.html'),'evidence_archive':pin(archive),'archive_member_count':len(paths)+1,'archive_all_member_hashes_verified':True,'archive_members':paths,'reader_append_custody':json.loads((O/'reader-append-custody.json').read_bytes()),'detached_publication_review_excluded_from_hash_cycle':True,'scope':'Raw copy/hash/archive and saved display formatting only; no mathematical replay, helper imports or gate repair. Original rejected outer result remains authoritative.'})
print(json.dumps({'output':str(O),'archive_members':len(paths)+1,'files':[pin(p)for p in sorted(O.iterdir())]},sort_keys=True))
