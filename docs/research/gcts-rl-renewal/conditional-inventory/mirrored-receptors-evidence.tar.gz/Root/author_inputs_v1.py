"""Ordinary frozen input copying and declared diagnostic metadata only."""
from pathlib import Path
import json,hashlib
D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1');old=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1/cohort-inputs-v1.json');component=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1/cohort-inputs-v1.json')
v=json.loads(old.read_bytes());v['schema']='ROOT-mirrored-receptor-comparison-inputs-v1';v['component_bank']=json.loads(component.read_bytes());v['ancestry_raw_inputs']=[{'path':str(p),'bytes':len(p.read_bytes()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in(old,component)]
ops=['mirror_missing_original_m','mirror_wrong_original_value','mirror_wrong_original_offset','mirror_wrong_original_channel','mirror_extra_t_support','mirror_extend_foreign','mirror_project_foreign','dpll_owned_work','dpll_foreign_check','dpll_foreign_same_class','dpll_invalid_boolmark','dpll_invalid_literal','dpll_invalid_admissible_bool']
v['additional_diagnostics']=[{'id':'M'+str(i+1).zfill(2),'operation':op}for i,op in enumerate(ops)]
v['whole_comparison']='Original23input problems and18diagnostics unchanged, plus ALL original162componentcases697baseassignments4214full-paletteassignments15componentdiagnostics and13newdiagnostics. New mirrored codec and6searchlanes(plain/acquisition/oldmarked/mirrored/DPLL plain/DPLL samecerts). No proof, failure clause or solution is supplied to search inputs.'
p=D/'cohort-inputs-v1.json';p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
