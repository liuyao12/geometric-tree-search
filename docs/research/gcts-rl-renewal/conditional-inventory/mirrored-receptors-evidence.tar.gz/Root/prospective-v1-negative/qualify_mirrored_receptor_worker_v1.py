"""UNEXECUTED worker Source for a complete mirrored-receptor and conventional comparison.

Only fresh reviewed once-run execution may load/call the seven components.
No Native/FOL/Model/Reader/inverse/solver imports or calls. No hostile sandbox
claim: input ownership, Source/callable custody and finite external gates apply.
"""
import time
NOW = time.monotonic_ns
ENTRY_NS = NOW()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'mirrored-receptor-comparison-worker-v1'
SOURCE_ROLES = ('worker','compiler','verifier','search','census','mirror_compiler','mirror_verifier','dpll','runner','observer')
SOURCE_PINS = {'compiler': ('9a07bd4afbfd7b4c95edd8d9e2a3ea489a025a53e1b18014ca5b429d09291eb9', 20653), 'verifier': ('eaee3b1681fcd8c5783d82c40f4225271a1a5ed350d6c8d7ac3baed8c7153b8f', 24281), 'search': ('198c0ae0300f01b507f0c17e6a573b58f9d986f105468a1756fa77106416b1c8', 29335), 'census': ('7b11424eaa6efa6619bfedf9f6af15f48683343f534c014470b6e6307fcfe399', 24791), 'mirror_compiler': ('9bfb4c09e17477a749cb959061fa08b942c9afdf30d03e955289b4e06956060e', 21212), 'mirror_verifier': ('bfac28318ae61e169d3dfc276ec7176b34ba0b25e4bd82485a62b20ed6b8f3b3', 25416), 'dpll': ('165157396c6ad3d05436cac9050dd3f7f87c770041abe2b0a6300f7b18fb56c5', 12038)}
INPUT_SHA = '98b479a008a2b57aaaa270e1ae3a0b32660909a972ae5bcf3a2d30148a879cca'
INPUT_BYTES = 280994

OUTER_LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
    stderr_bytes=4194304, worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608, observer_bytes=1048576)
POINT_LIMITS=dict(work=400000000,centers=1024,tiles=100000,marks=1000000,
    clauses=256,literals=1024,candidates=1000000,integer_abs=1000000,string_chars=1024,data_depth=64)
SEARCH_LIMITS=dict(work=400000000,centers=1024,tiles=100000,marks=1000000,candidates=1000000,dependencies=8000000,mark_points=1000000,integer_abs=1000000,string_chars=1024,data_depth=64,decisions=1000000,trace_rows=2000000,snapshot_items=40000000,trail_entries=2000000,solutions=10000,deadpoints=100000,witness_rows=1000000)
DPLL_LIMITS=dict(work=400000000,centers=1024,tiles=100000,marks=1000000,variables=1000000,clauses=1000000,literals=8000000,decisions=1000000,trace_rows=2000000,solutions=10000,integer_abs=1000000,string_chars=1024,data_depth=64)
COMPONENT_LIMITS={role:dict(DPLL_LIMITS if role=='dpll'else POINT_LIMITS if role in('compiler','verifier','mirror_compiler','mirror_verifier')else SEARCH_LIMITS)for role in('compiler','verifier','search','census','mirror_compiler','mirror_verifier','dpll')}

CHECKPOINT_LIMIT = 400000000
RESERVE_BYTES = 9437184
FORBIDDEN_EVENTS = ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','ctypes.dlopen')


class PolicyFailure(RuntimeError):
    pass


class PlannedForeign(BaseException):
    pass


def need(ok, message):
    if not ok:
        raise PolicyFailure(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def clone(value):
    return json.loads(canonical(value))


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and type(pin['path'])is str and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and
         len(pin['sha256'])==64,'strict finite raw descriptor')
    path=Path(pin['path'])
    need(path.is_absolute()and path==path.resolve()and path.is_file()and not path.is_symlink(),'canonical regular raw input')
    raw=path.read_bytes();need(descriptor(path,raw)==pin,'complete raw hash/size/path join');return raw


def information(error):
    try:return dict(type=type(error).__name__,message=str(error)[:512])
    except BaseException:return dict(type='UNAVAILABLE',message='error metadata unavailable')


def callable_seal(module):
    rows=[];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__)))
            elif type(value)is type and value.__module__==module.__name__ and id(value)not in seen:
                seen.add(id(value));rows.append((key,id(value)))
                owned={}
                for child,item in vars(value).items():
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    owned[child]=item
                pending.append((key+'.',owned))
    return tuple(sorted(rows))


class Session:
    def __init__(self,plan,plan_pin,consumed,actual):
        self.plan,self.plan_pin,self.actual=plan,plan_pin,actual
        self.began=consumed['began_ns'];self.work_deadline=consumed['work_deadline_ns']
        self.overall_deadline=consumed['overall_deadline_ns']
        self.root_calls=0;self.first_fault=None;self.stage='INTAKE';self.active=None
        self.started={};self.completed={};self.raised={};self.modules={};self.seals={};self.denied=[]
        self.oracle_work=0;self.oracle_work_unavailable=0;self.expanded_subtree_delta=0
        self.rows=[];self.diagnostics=[];self.component_rows=[];self.component_diagnostics=[];self.retained=[];self.output_pins=[]
        self.component_limits=clone(COMPONENT_LIMITS)

    def check(self):
        self.root_calls+=1
        try:
            need(self.root_calls<=CHECKPOINT_LIMIT,'invocation-total400m Root callback limit')
            need(NOW()<self.work_deadline,'original absolute180s work deadline')
            if self.first_fault is not None:raise self.first_fault
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def policy(self,action):
        try:return action()
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def guard(self):
        def action():
            self.check()
            for role,pin in self.plan['sources'].items():
                checked(pin)
            for role,module in self.modules.items():
                need(module.__file__==self.plan['sources'][role]['path'] and
                     callable_seal(module)==self.seals[role],'owned module origin/function/code/default binding')
            self.check()
        return self.policy(action)

    def fault_gate(self):
        if self.first_fault is not None:raise self.first_fault

    def call(self,role,name,data,action,expected_after=None):
        self.guard();before=canonical(data()if callable(data)else data)
        self.check();key=role+'.'+name;self.started[key]=self.started.get(key,0)+1
        try:
            value=action()
        except BaseException as error:
            self.raised[key]=self.raised.get(key,0)+1
            self.fault_gate()
            self.fault_gate()
            self.guard()
            expected=before if expected_after is None else canonical(expected_after)
            self.policy(lambda:need(canonical(data()if callable(data)else data)==expected,'full literal call arguments after refusal/fault'))
            raise
        self.fault_gate();self.guard()
        expected=before if expected_after is None else canonical(expected_after)
        self.policy(lambda:need(canonical(data()if callable(data)else data)==expected,'full literal call arguments unchanged'))
        self.completed[key]=self.completed.get(key,0)+1
        return value

    def load(self,role):
        self.check();pin=self.plan['sources'][role];checked(pin)
        name='certified_point_actual_'+role
        spec=importlib.util.spec_from_file_location(name,pin['path'])
        need(spec is not None and spec.loader is not None,'exact Python Source loader')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module
        spec.loader.exec_module(module)
        need(module.__file__==pin['path'],'exact loaded Source origin')
        self.modules[role]=module;self.seals[role]=callable_seal(module);self.guard()
        return module

    def calls(self,role):
        return sum(value for key,value in self.started.items()if key.startswith(role+'.'))

    def write_json(self,name,value,cap,closure=False):
        path=self.actual/name;temporary=self.actual/(name+'.partial')
        need(not path.exists()and not temporary.exists(),'never overwrite or retry a packet')
        digest=hashlib.sha256();size=0;parts=0
        fd=os.open(str(temporary),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as output:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).iterencode(value):
                raw=part.encode('utf8');size+=len(raw);need(size+1<=cap,'whole JSON packet cap')
                output.write(raw);digest.update(raw);parts+=1
                if parts%1024==0:
                    if closure:need(NOW()<self.overall_deadline,'failure metadata210 deadline')
                    else:self.check()
            output.write(b'\n');digest.update(b'\n');size+=1;output.flush();os.fsync(output.fileno())
        if closure:need(NOW()<self.overall_deadline,'failure metadata completed before210')
        else:self.check()
        os.rename(temporary,path)
        return dict(path=str(path),bytes=size,sha256=digest.hexdigest())


import itertools


def bounds(s,role,one=False):
    result=clone(s.component_limits[role])
    if one:result['work']=1
    return result


def predicate(s,role,name,error):
    s.fault_gate();s.guard();key=role+'.'+name
    s.started[key]=s.started.get(key,0)+1
    result=getattr(s.modules[role],name)(error)
    s.completed[key]=s.completed.get(key,0)+1;s.fault_gate();s.guard()
    need(type(result)is bool,'exact private owner predicate');return result


def invoke(s,role,name,args,one=False,check=None):
    limits=bounds(s,role,one);callback=s.check if check is None else check
    return s.call(role,name,dict(args=args,limits=limits),
        lambda:getattr(s.modules[role],name)(*args,check=callback,limits=limits))


def raw_tiling(s,instance,certificate):
    try:return invoke(s,'verifier','verify_tiling',[instance,certificate])
    except BaseException as error:
        s.fault_gate()
        if predicate(s,'verifier','is_own_invalid',error):return dict(status='INVALID_LITERAL_POINT_ASSIGNMENT',error=information(error))
        raise


def certificate(model,word):
    return dict(schema='finite-unit-center-placement-certificate-v1',placements=[
        dict(tile_id=tid,origin=p[:])for p,tid in zip(model['required_centers'],word)])


def eval_formula(s,formula,truth):
    s.check();tag=formula[0]
    if tag=='var':return truth[formula[1]]
    if tag=='not':return not eval_formula(s,formula[1],truth)
    left=eval_formula(s,formula[1],truth);right=eval_formula(s,formula[2],truth)
    if tag=='and':return left and right
    if tag=='or':return left or right
    need(tag=='imp','declared propositional syntax');return not left or right


def cnf_value(s,clauses,truth):
    for clause in clauses:
        s.check()
        if not any(truth[v]is sign for v,sign in clause):return False
    return True


def make_model(s,case):
    """Actual-only propositional factor encoding; no proof/solution supplied."""
    s.check()
    if case['kind']=='raw-point':return clone(case['base']),None
    n=len(case['variables']);clauses=case['clauses'];size=n+len(clauses)
    need(0<n<=3 and size<=7,'whole declared symbolic grammar bound')
    if case['coordinate_profile']=='positive-line':centers=[[2*i,0]for i in range(size)]
    else:
        need(case['coordinate_profile']=='negative-nonrectangular','literal coordinate profile')
        centers=[[-8,-4],[-2,-6],[0,-10],[4,-6],[10,-4],[14,-8],[18,-2]][:size]
    truth_points=[[1000+4*i,-1000]for i in range(n)];tiles=[];pins=[]
    def add(role,values):
        s.check();origin=centers[role]
        marks=[[[0,0],'logic-role',role+1]]
        for variable,bit in values:
            point=truth_points[variable];marks.append([[point[0]-origin[0],point[1]-origin[1]],'logic-truth',bit])
        tiles.append(dict(id=7+11*len(tiles),t=[[[0,0],1]],m=marks))
    for variable in range(n):
        for bit in(0,1):add(variable,[(variable,bit)])
    for ci,clause in enumerate(clauses):
        variables=[v for v,sign in clause]
        need(len(set(variables))==len(variables)and all(type(sign)is bool for v,sign in clause),'literal distinct-variable signed clause')
        for bits in itertools.product((0,1),repeat=len(variables)):
            s.check();assignment=dict(zip(variables,bits))
            if any(bool(assignment[v])is sign for v,sign in clause):add(n+ci,list(zip(variables,bits)))
    for role,p in enumerate(centers):pins.append([p[:],'logic-role',role+1])
    model=dict(schema='finite-unit-center-point-instance-v1',transformations='translations_only_2Z2',
        required_centers=centers,admissible_origins=clone(centers),tiles=tiles,fixed_background_marks=pins,all_root_generations=0)
    return model,dict(variables=case['variables'],truth_points=truth_points,variable_roles=list(range(n)),
        role_channel='logic-role',truth_channel='logic-truth',encoding='Instance-specific Boolean factor prototypes, not one fixed universal FOL palette.')


def reference_solutions(s,case,model,meta):
    """Independent truth enumeration + raw-role/point readout, never search output."""
    results=[];truth_rows=[]
    if meta is None:
        for word in itertools.product([t['id']for t in model['tiles']],repeat=len(model['required_centers'])):
            s.check();candidate=certificate(model,word);receipt=raw_tiling(s,model,candidate)
            truth_rows.append(dict(certificate=candidate,raw_check=receipt))
            if receipt['status']=='VALID_EXACT_FINITE_TILING':results.append(candidate)
        return dict(solutions=results,truth_rows=truth_rows,method='Entire original palette at every original center, raw point verifier.')
    n=len(case['variables'])
    for values in itertools.product((False,True),repeat=n):
        s.check();truth=list(values);allowed=cnf_value(s,case['clauses'],truth)
        formula_value=None if case['formula']is None else eval_formula(s,case['formula'],truth)
        if formula_value is not None:need(allowed is(not formula_value),'all truth rows independently bind CNF to negated symbolic statement')
        row=dict(truth=truth,CNF=allowed,formula=formula_value)
        if allowed:
            selected=[]
            for role,origin in enumerate(model['required_centers']):
                options=[]
                for tile in model['tiles']:
                    s.check();section={(tuple([origin[0]+xy[0],origin[1]+xy[1]]),channel):value for xy,channel,value in tile['m']}
                    if section.get((tuple(origin),'logic-role'))!=role+1:continue
                    consistent=True
                    for variable,point in enumerate(meta['truth_points']):
                        key=(tuple(point),'logic-truth')
                        if key in section and section[key]!=int(truth[variable]):consistent=False
                    if consistent:options.append(tile['id'])
                need(len(options)==1,'exact one factor prototype per truth assignment and role, no hidden tie')
                selected.append(options[0])
            cert=certificate(model,selected);receipt=raw_tiling(s,model,cert)
            need(receipt['status']=='VALID_EXACT_FINITE_TILING','independent raw point certificate for every reference truth solution')
            row.update(certificate=cert,raw_check=receipt);results.append(cert)
        truth_rows.append(row)
    return dict(solutions=results,truth_rows=truth_rows,method='Complete Boolean assignments from symbolic clauses; raw prototype-role readout and independent point verification.')


def sorted_certificates(s,certificates):
    result=[]
    for cert in certificates:s.check();result.append(canonical(cert).decode())
    need(len(result)==len(set(result)),'all enumeration solutions retain exact unique literal placement identity')
    return sorted(result)


def core(snapshot):
    return {key:value for key,value in snapshot.items()if key not in('reason','work')}


def run_search(s,model,label,acquire=False,check=None,observe_override=None,dead_override=None,one=False):
    limits=bounds(s,'search',one);records=[];kept={};proofs=[];latest=None;initial=None
    callback=s.check if check is None else check
    def observe(snapshot):
        nonlocal latest,initial
        s.check();before=canonical(snapshot);retained_keys=[]
        receipt=invoke(s,'census','audit_snapshot',[model,snapshot])
        need(receipt['status']=='EXACT_UNIT_CENTER_POINT_CENSUS_MATCH','complete independent live candidate graph census')
        need(canonical(snapshot)==before,'full detached snapshot preserved by independent checker')
        latest=clone(snapshot)
        if snapshot['reason']=='INITIAL':initial=clone(snapshot);kept['initial']=clone(snapshot);retained_keys.append('initial')
        if snapshot['reason']=='ROOT_RESTORED':
            need(initial is not None and canonical(core(initial))==canonical(core(snapshot)),'exact full initial/restored graph including domains/refcounts/dependencies/trail')
            kept['root_restored']=clone(snapshot);retained_keys.append('root_restored')
        if snapshot['scheduler']['kind']=='DEAD'and'first_dead'not in kept:kept['first_dead']=clone(snapshot);retained_keys.append('first_dead')
        if snapshot['scheduler']['kind']=='BRANCH'and'first_branch'not in kept:kept['first_branch']=clone(snapshot);retained_keys.append('first_branch')
        records.append(dict(index=len(records),reason=snapshot['reason'],scheduler=clone(snapshot['scheduler']),
            chosen=clone(snapshot['chosen']),trail_length=snapshot['trail_length'],
            receipt_summary={key:value for key,value in receipt.items()if value is None or type(value)in(str,int,bool)},
            full_snapshot_retained_in=retained_keys))
    def dead(candidate):
        s.check();need(acquire and latest is not None and latest['scheduler']['kind']=='DEAD','only actual acquisition raw DEAD can propose exclusion')
        need(candidate['point']==latest['scheduler']['point']and canonical(candidate['instance'])==canonical(model),'full original-instance and distinguished-point acquisition join')
        expected=[]
        for cid,pi,tid,generation in latest['chosen']:expected.append(dict(cid=cid,origin=model['required_centers'][pi],tile_id=tid))
        need(canonical(candidate['support'])==canonical(expected),'all selected support acquired from exact observed original failure')
        receipt=invoke(s,'census','certify_deadpoint',[model,candidate])
        need(receipt['status']=='VALID_SAME_INSTANCE_PRIMITIVE_DEADPOINT','every original tile has a separately checked original-m/pin blocker')
        proofs.append(dict(candidate=clone(candidate),receipt=receipt,acquisition_snapshot=clone(latest),snapshot_index=len(records)-1))
    actual_observe=observe if observe_override is None else observe_override
    actual_dead=(dead if acquire else None)if dead_override is None else dead_override
    began=NOW();result=s.call('search','search',dict(instance=model,mode='all',limits=limits),
        lambda:s.modules['search'].search(model,check=callback,limits=limits,observe=actual_observe,observe_deadpoint=actual_dead,mode='all'))
    end=NOW()
    if check is not None or observe_override is not None or dead_override is not None or one:
        return dict(result=result,records=records,retained_snapshots=kept,proofs=proofs,elapsed_seconds=(end-began)/1e9)
    need(result['status']=='ALL_SOLUTIONS_EXHAUSTED'and result['exhausted']is True and result['root_restored']is True and result['input_reconciled']is True,'complete whole declared search and root/input reconciliation; never UNKNOWN prefix')
    need('root_restored'in kept,'externally observed independent exact root restoration')
    need(len(result['deadpoint_candidates'])==len(proofs),'all acquired candidates separately certified before later activation')
    if not acquire:need(result['deadpoint_candidates']==[],'control/marked search did not acquire or relearn failures')
    checks=[]
    for cert in result['solutions']:
        receipt=raw_tiling(s,model,cert);need(receipt['status']=='VALID_EXACT_FINITE_TILING','complete returned point solution independent verification');checks.append(receipt)
    return dict(label=label,result=result,records=records,retained_snapshots=kept,proofs=proofs,solution_checks=checks,
        elapsed_seconds=(end-began)/1e9,clock_scope='Includes whole search and callbacks/guards; subsequent returned-solution checks separately charged inside whole actual.',
        snapshot_retention='Every live full snapshot independently checked; archive keeps all event traces/census receipts and selected initial/firstbranch/firstdead/root snapshots, not every full historical graph.')


def qualify_original_case(s,case):
    s.active=case['id'];s.stage='BUILD_ORIGINAL_POINT_MODEL';case_began=NOW()
    model,meta=make_model(s,case);reference=reference_solutions(s,case,model,meta)
    expected=sorted_certificates(s,reference['solutions'])
    reference_end=NOW();plain_began=NOW();s.stage='PLAIN_COMPLETE_SEARCH';plain=run_search(s,model,'plain')
    need(sorted_certificates(s,plain['result']['solutions'])==expected,'complete plain solutions equal independent truth/raw reference')
    plain_end=NOW();pipeline_began=NOW();s.stage='ACQUIRE_CERTIFIED_FAILURES';acquisition=run_search(s,model,'acquisition',acquire=True)
    need(sorted_certificates(s,acquisition['result']['solutions'])==expected,'acquisition itself retains every original solution')
    clauses=[]
    for proof in acquisition['proofs']:
        receipt=proof['receipt']
        need(canonical(receipt['instance'])==canonical(model),'certified clause full same-instance binding')
        clauses.append(clone(receipt['clause']))
    s.stage='COMPILE_FROZEN_ACTUAL_MARKINGS';compile_began=NOW()
    compilation=invoke(s,'compiler','compile_marking_gadget',[model,clauses])
    need(compilation['status']=='MARKING_GADGET_CANDIDATE','whole geometric gadget, no resource/partial result')
    translation=invoke(s,'verifier','verify_translation',[model,clauses,compilation])
    need(translation['status']=='VALID_MARKING_GADGET_TRANSLATION','full independent emitted prototype/pin/role/origin binding')
    compile_end=NOW();s.stage='MARKED_COMPLETE_POINT_SEARCH'
    marked=run_search(s,compilation['instance'],'marked',acquire=False)
    projected=[];projections=[]
    for cert in marked['result']['solutions']:
        record=invoke(s,'compiler','project',[compilation,cert])
        need(record['status']=='PROJECTION_CANDIDATE','whole literal base-ID projection')
        checked=raw_tiling(s,model,record['certificate']);need(checked['status']=='VALID_EXACT_FINITE_TILING','projected original exact t/m')
        projected.append(record['certificate']);projections.append(dict(record=record,raw_check=checked))
    need(sorted_certificates(s,projected)==expected,'all projected marked solutions exactly original reference population, unique extensions and no lost solution')
    end=NOW()
    return dict(id=case['id'],input=case,model=model,symbolic_metadata=meta,reference=reference,plain=plain,
        acquisition=acquisition,certified_clauses=clauses,compilation=compilation,translation=translation,
        marked=marked,projections=projections,projected_solutions=projected,original_solution_count=len(expected),
        acquisition_and_certification_seconds=(compile_began-pipeline_began)/1e9,old_reuse_seconds=(end-compile_began)/1e9,compile_and_translation_seconds=(compile_end-compile_began)/1e9,total_case_seconds=(end-case_began)/1e9,
        model_reference_seconds=(reference_end-case_began)/1e9,plain_complete_seconds=(plain_end-plain_began)/1e9,cold_certified_pipeline_seconds=(end-pipeline_began)/1e9,
        complete=True,all_original_solutions_preserved=True,primitive_certificates_checked=True,
        marked_lane_uses_only_point_agreement=True,full_FOL_fixed_palette=False,RL=False,
        performance_scope='Plain, acquisition and marked search phase observations have matching projected result semantics. Full cold acquisition+checking+compile+marked+projection costs remain in whole case; no speed advantage inferred from phase or branch counts.')


def diagnostics(s,inputs,rows):
    search=s.modules['search'];simple=rows[0];model=simple['model'];snapshot=simple['plain']['retained_snapshots']['initial']
    proof_row=next(row for row in rows if row['acquisition']['proofs'])
    proof=proof_row['acquisition']['proofs'][0]
    framed=next(p for row in rows for p in row['acquisition']['proofs']if p['acquisition_snapshot']['branch_stack'])
    for declared in inputs['diagnostics']:
        s.stage='DIAGNOSTIC';s.active=declared['id'];s.check();op=declared['operation']
        record=dict(id=declared['id'],operation=op,status='ENTERED');s.diagnostics.append(record)
        raised=None;returned=None;foreign=PlannedForeign('planned exact external callback object');hits=0
        actual_model=clone(model);actual_snapshot=clone(snapshot);actual_cert=clone(proof['candidate']);target=proof_row['model']
        role='census';expected='OWN_INVALID';started=s.root_calls
        def boom(*unused):
            nonlocal hits
            hits+=1;raise foreign
        try:
            if op=='search_owned_work':returned=run_search(s,actual_model,'diagnostic',one=True);expected='UNKNOWN'
            elif op=='census_owned_work':returned=invoke(s,'census','audit_snapshot',[actual_model,actual_snapshot],one=True);expected='OWN_LIMIT'
            elif op=='search_foreign_check':returned=run_search(s,actual_model,'diagnostic',check=boom);expected='FOREIGN'
            elif op=='search_foreign_observer':returned=run_search(s,actual_model,'diagnostic',observe_override=boom);expected='FOREIGN'
            elif op=='search_foreign_deadpoint':returned=run_search(s,proof_row['model'],'diagnostic',dead_override=boom);expected='FOREIGN'
            elif op=='census_foreign_check':returned=invoke(s,'census','audit_snapshot',[actual_model,actual_snapshot],check=boom);expected='FOREIGN'
            elif op=='deadpoint_foreign_check':returned=invoke(s,'census','certify_deadpoint',[target,actual_cert],check=boom);expected='FOREIGN'
            elif op.startswith('snapshot_'):
                if op=='snapshot_missing_remote_dependency':
                    index=next(i for i,row in enumerate(actual_snapshot['dependencies'])if row[0]=='m'and abs(row[1][0])>=900)
                    actual_snapshot['dependencies'].pop(index)
                elif op=='snapshot_missing_candidate':actual_snapshot['candidates'].pop()
                elif op=='snapshot_wrong_refcount':actual_snapshot['marks'][0][3]+=1
                elif op=='snapshot_wrong_scheduler':actual_snapshot['scheduler']['kind']='COMPLETE'
                elif op=='snapshot_wrong_parent_options':
                    actual_model=framed['candidate']['instance'];actual_snapshot=clone(framed['acquisition_snapshot'])
                    actual_snapshot['branch_stack'][-1]['options'].pop()
                else:raise PolicyFailure('declared snapshot diagnostic')
                record['offered_snapshot']=actual_snapshot
                returned=invoke(s,'census','audit_snapshot',[actual_model,actual_snapshot])
            elif op.startswith('deadpoint_'):
                if op=='deadpoint_missing_witness':actual_cert['witnesses'].pop()
                elif op=='deadpoint_wrong_instance':actual_cert['instance']['tiles'][0]['id']+=1
                elif op=='deadpoint_wrong_blocker':actual_cert['witnesses'][0]['blocker_value']+=1
                elif op=='deadpoint_exclusion_only_fake':
                    target=clone(model);actual_snapshot['mode']='first';actual_snapshot['reason']='STATE';point=actual_snapshot['scheduler']['point']
                    available=actual_snapshot['forward'][point][1][:]
                    actual_snapshot['exclusions']=[[cid,[]]for cid in available]
                    for cid in available:
                        actual_snapshot['candidates'][cid][3]=False;actual_snapshot['reverse'][cid][1]=[]
                    actual_snapshot['forward'][point][1]=[]
                    actual_snapshot['scheduler']=dict(kind='DEAD',point=point,options=[])
                    actual_snapshot['trail_length']+=2*len(available)
                    context_receipt=invoke(s,'census','audit_snapshot',[target,actual_snapshot])
                    need(context_receipt['status']=='EXACT_UNIT_CENTER_POINT_CENSUS_MATCH','a literal exclusion-only domain can be censused but carries no primitive proof')
                    witnesses=[]
                    for ti,tile in enumerate(target['tiles']):
                        xy,channel,value=tile['m'][0]
                        witnesses.append(dict(tile_id=tile['id'],cid=point*len(target['tiles'])+ti,
                            point=[target['required_centers'][point][0]+xy[0],target['required_centers'][point][1]+xy[1]],channel=channel,
                            candidate_value=value,blocker_kind='pin',blocker_cid=None,blocker_value=1))
                    actual_cert=dict(schema='unit-center-primitive-deadpoint-candidate-v1',scope='CURRENT_INVOCATION_INSTANCE',id=0,
                        instance=target,point=point,center=target['required_centers'][point],support=[],
                        fixed_background_marks=target['fixed_background_marks'],witnesses=witnesses,
                        branch_exclusions_ignored=True,mathematical_authority=False)
                    record.update(exclusion_only_snapshot=actual_snapshot,context_census=context_receipt,
                        context_scope='Synthetic context only; no genuine failed-child history is asserted. Census validity supplies no negative authority.')
                else:raise PolicyFailure('declared primitive diagnostic')
                record['offered_certificate']=actual_cert
                returned=invoke(s,'census','certify_deadpoint',[target,actual_cert])
            elif op in('invalid_boolean_mark_value','invalid_odd_origin'):
                role='search';expected='INPUT_ERROR'
                if op=='invalid_boolean_mark_value':actual_model['tiles'][0]['m'][0][2]=False
                else:actual_model['required_centers'][0][0]=1;actual_model['admissible_origins'][0][0]=1
                record['offered_instance']=actual_model
                returned=run_search(s,actual_model,'diagnostic')
            else:raise PolicyFailure('entire declared diagnostic operation')
        except BaseException as error:
            s.fault_gate();raised=error
        # Assign expectations by operation even if the planned call raised before its following assignment.
        if op=='search_owned_work':expected='UNKNOWN'
        elif op=='census_owned_work':expected='OWN_LIMIT'
        elif 'foreign'in op:expected='FOREIGN'
        elif op.startswith('invalid_'):expected='INPUT_ERROR'
        if expected=='UNKNOWN':passed=raised is None and returned['result']['status']=='UNKNOWN'and returned['result']['exhausted']is False
        elif expected=='FOREIGN':passed=raised is foreign and hits==1
        elif expected=='OWN_LIMIT':passed=raised is not None and predicate(s,role,'is_own_limit',raised)
        elif expected=='INPUT_ERROR':passed=type(raised)is search.InputError
        else:passed=raised is not None and predicate(s,role,'is_own_invalid',raised)
        need(passed,'exact declared diagnostic disposition, foreign identity or private owner')
        record.update(status='PASSED',expected=expected,error=None if raised is None else information(raised),
            returned=returned,local_callbacks=hits,exact_foreign_identity=raised is foreign,
            root_callbacks_before=started,root_callbacks_after=s.root_calls)


def cc_limits(s,role,work_one=False):
    result=clone(s.component_limits[role])
    if work_one:result['work']=1
    return result


def cc_predicate(s,name,error):
    s.fault_gate();s.guard();key='mirror_verifier.'+name
    s.started[key]=s.started.get(key,0)+1
    result=getattr(s.modules['mirror_verifier'],name)(error)
    s.completed[key]=s.completed.get(key,0)+1;s.fault_gate();s.guard()
    need(type(result)is bool,'literal private-owner predicate result');return result


def cc_compile_gadget(s,base,clauses,check=None,work_one=False):
    bounds=cc_limits(s,'mirror_compiler',work_one);module=s.modules['mirror_compiler']
    callback=s.check if check is None else check
    return s.call('mirror_compiler','compile_marking_gadget',dict(base=base,clauses=clauses,limits=bounds),
        lambda:module.compile_marking_gadget(base,clauses,check=callback,limits=bounds))


def cc_codec(s,name,compilation,certificate,check=None):
    bounds=cc_limits(s,'mirror_compiler');module=s.modules['mirror_compiler'];callback=s.check if check is None else check
    return s.call('mirror_compiler',name,dict(compilation=compilation,certificate=certificate,limits=bounds),
        lambda:getattr(module,name)(compilation,certificate,check=callback,limits=bounds))


def cc_verify(s,name,args,check=None,work_one=False):
    bounds=cc_limits(s,'mirror_verifier',work_one);module=s.modules['mirror_verifier'];callback=s.check if check is None else check
    data=dict(args=args,limits=bounds)
    return s.call('mirror_verifier',name,data,lambda:getattr(module,name)(*args,check=callback,limits=bounds))


def cc_raw_tiling(s,instance,certificate):
    try:return cc_verify(s,'verify_tiling',[instance,certificate])
    except BaseException as error:
        s.fault_gate()
        if cc_predicate(s,'is_own_invalid',error):return dict(status='INVALID_LITERAL_POINT_ASSIGNMENT',error=information(error))
        raise


def cc_certificate(model,word):
    return dict(schema='finite-unit-center-placement-certificate-v1',placements=[
        dict(tile_id=tile,origin=point[:])for point,tile in zip(model['required_centers'],word)])


def cc_forbidden(clauses,base_certificate):
    chosen={tuple(row['origin']):row['tile_id']for row in base_certificate['placements']}
    return any(all(chosen[tuple(literal['origin'])]==literal['tile_id']for literal in clause)for clause in clauses)


def cc_qualify_case(s,case):
    s.stage='COMPLETE_TRANSLATION';s.active=case['id'];s.check()
    base,clauses=case['base'],case['clauses'];module=s.modules['mirror_compiler']
    compilation=cc_compile_gadget(s,base,clauses)
    need(compilation['status']=='MARKING_GADGET_CANDIDATE','complete actual compiler result, never UNKNOWN')
    need(canonical(compilation['base'])==canonical(base)and canonical(compilation['clauses'])==canonical(clauses),
        'full original literal input binding')
    translation=cc_verify(s,'verify_translation',[base,clauses,compilation])
    need(translation['status']=='VALID_MARKING_GADGET_TRANSLATION','independent entire translated profile check')
    assignments=[];expected_preimages={};ids=[t['id']for t in base['tiles']]
    for word in itertools.product(ids,repeat=len(base['required_centers'])):
        s.check();base_certificate=cc_certificate(base,word);original=cc_raw_tiling(s,base,base_certificate)
        item=dict(base_certificate=base_certificate,original_check=original)
        key=canonical(base_certificate).decode()
        if original['status']!='VALID_EXACT_FINITE_TILING':
            error=None
            try:cc_codec(s,'extend',compilation,base_certificate)
            except BaseException as caught:s.fault_gate();error=caught
            need(type(error)is module.DeclarationError,'invalid ORIGINAL assignment refused distinctly from a forbidden conjunction')
            item.update(status='INVALID_ORIGINAL_ASSIGNMENT',extension=None,codec_refusal=information(error))
            expected_preimages[key]=0
        else:
            disallowed=cc_forbidden(clauses,base_certificate)
            if disallowed:
                error=None
                try:cc_codec(s,'extend',compilation,base_certificate)
                except BaseException as caught:s.fault_gate();error=caught
                need(type(error)is module.NoExtension,'actual supplied forbidden combination has no codec extension')
                relation=cc_verify(s,'verify_extension',[base,clauses,compilation,base_certificate,None])
                need(relation['status']=='VALID_EXTENSION_PROJECTION_RELATION'and relation['extension_exists']is False,
                    'independent necessary prefix trajectory forbids extension')
                item.update(status='FORBIDDEN_BY_DECLARED_CLAUSE',extension=None,relation=relation,codec_refusal=information(error))
                expected_preimages[key]=0
            else:
                extension=cc_codec(s,'extend',compilation,base_certificate)
                need(extension['status']=='EXTENSION_CANDIDATE','complete extension, never UNKNOWN')
                expanded_check=cc_verify(s,'verify_tiling',[compilation['instance'],extension['certificate']])
                need(expanded_check['status']=='VALID_EXACT_FINITE_TILING','independent complete raw t/m section')
                relation=cc_verify(s,'verify_extension',[base,clauses,compilation,base_certificate,extension['certificate']])
                need(relation['status']=='VALID_EXTENSION_PROJECTION_RELATION'and relation['extension_exists']is True and
                    canonical(relation['base_certificate'])==canonical(base_certificate),
                    'independent unique-prefix extension and literal projection')
                projection=cc_codec(s,'project',compilation,extension['certificate'])
                need(projection['status']=='PROJECTION_CANDIDATE'and
                    canonical(projection['certificate'])==canonical(base_certificate),'full literal base-ID round trip')
                projected_check=cc_verify(s,'verify_tiling',[base,projection['certificate']])
                need(projected_check['status']=='VALID_EXACT_FINITE_TILING','independent projected original point section')
                item.update(status='UNIQUE_ALLOWED_EXTENSION',extension=extension,expanded_check=expanded_check,
                    relation=relation,projection=projection,projected_check=projected_check)
                expected_preimages[key]=1
        assignments.append(item)
    need(len(assignments)==case['complete_base_assignment_count'],'whole declared base-assignment population')
    exhaustive=None
    if case['exhaustive_full_palette']:
        instance=compilation['instance'];tile_ids=[t['id']for t in instance['tiles']]
        total=len(tile_ids)**len(instance['required_centers'])
        need(total<=1000,'prospective complete full-palette population cap, no truncation')
        counts={key:0 for key in expected_preimages};offered=[]
        reverse={emitted:original_id for emitted,original_id in translation['base_tiles']}
        for word in itertools.product(tile_ids,repeat=len(instance['required_centers'])):
            s.check();candidate=cc_certificate(instance,word);checked_tiling=cc_raw_tiling(s,instance,candidate)
            record=dict(certificate=candidate,check=checked_tiling)
            if checked_tiling['status']=='VALID_EXACT_FINITE_TILING':
                by_origin={tuple(p['origin']):p['tile_id']for p in candidate['placements']}
                need(all(by_origin[tuple(p)]in reverse for p in base['required_centers']),'raw valid expanded tiling anchored base roles')
                projected=cc_certificate(base,[reverse[by_origin[tuple(p)]]for p in base['required_centers']])
                key=canonical(projected).decode();need(key in counts,'every raw valid tiling projects inside complete original universe')
                counts[key]+=1;record['projected_base_certificate']=projected
            offered.append(record)
        need(len(offered)==total and counts==expected_preimages,
            'exhaust ALL emitted tile assignments at ALL required centers; exact zero/one preimages')
        exhaustive=dict(method='ALL_EMITTED_PALETTE_AT_ALL_REQUIRED_CENTERS',assignments=offered,
            assignment_count=total,projection_preimage_counts=[[key,value]for key,value in sorted(counts.items())],
            exact_expected_preimages_matched=True)
    return dict(id=case['id'],family=case['family'],original_case=case,compilation=compilation,
        independent_translation=translation,assignments=assignments,exhaustive=exhaustive,
        status='VERIFIED_TRANSLATION_AND_ALL_BASE_ASSIGNMENTS',assignments_checked=len(assignments),
        all_primitive_checks_passed=True,all_projection_checks_passed=True,all_uniqueness_checks_passed=True,
        full_palette_exhausted=exhaustive is not None,
        uniqueness_method='Full raw-palette enumeration in declared subdomain; independently checked unique prefix states elsewhere.',
        redundancy_established=False,proof_search=False)


def cc_diagnostics(s,inputs,rows):
    compiler=s.modules['mirror_compiler'];simple=rows[0];aux=next(r for r in rows if r['compilation']['mapping']['auxiliary_tiles'])
    original_zero=next(r for r in rows if r['id']=='assigned-zero-versus-absent-none')
    for declared in inputs['diagnostics']:
        s.stage='DIAGNOSTIC';s.active=declared['id'];s.check();before=s.root_calls
        op=declared['operation'];record=dict(id=declared['id'],operation=op,status='UNFINISHED',check_calls_before=before)
        s.component_diagnostics.append(record);actual=None;returned=None;reached=False;hits=0;expected_kind='DECLARATION'
        model=clone(simple['original_case']['base']);clauses=clone(simple['original_case']['clauses'])
        changed=None
        if op=='duplicate_required':model['required_centers'].append(clone(model['required_centers'][0]))
        elif op=='extra_origin':model['admissible_origins'].append([50,50])
        elif op=='duplicate_tile_id':model['tiles'].append(clone(model['tiles'][0]))
        elif op=='boolean_mark_zero':model['tiles'][0]['m']=[[[100,0],'remote',False]]
        elif op=='odd_origin':model['required_centers'][0]=[1,0];model['admissible_origins'][0]=[1,0]
        elif op=='foreign_literal_id':clauses=[[dict(origin=model['required_centers'][0],tile_id=99)]]
        elif op=='rotation_field':model['tiles'][0]['rotation']=0
        elif op in('remove_anchor','flip_prefix_output','remove_original_zero'):
            chosen=original_zero if op=='remove_original_zero'else aux;changed=clone(chosen['compilation'])
            if op=='remove_anchor':
                anchor=changed['mapping']['channels']['anchor'];tile=changed['instance']['tiles'][0]
                index=next(i for i,m in enumerate(tile['m'])if m[0]==[0,0]and m[1]==anchor);tile['m'].pop(index)
            elif op=='flip_prefix_output':
                emitted=changed['mapping']['auxiliary_tiles'][0][0]
                mark=changed['instance']['tiles'][emitted]['m'][3];mark[2]=1-mark[2]
            else:changed['instance']['tiles'][0]['m'].pop(0)
            expected_kind='VERIFIER_INVALID'
        elif op in('compiler_owned_work','verifier_owned_work'):expected_kind=op
        elif op.startswith('compiler_foreign')or op=='verifier_foreign_base':expected_kind='FOREIGN'
        else:raise PolicyFailure('undeclared diagnostic operation')
        try:
            if expected_kind=='DECLARATION':reached=True;returned=cc_compile_gadget(s,model,clauses)
            elif expected_kind=='VERIFIER_INVALID':
                reached=True;returned=cc_verify(s,'verify_translation',[chosen['original_case']['base'],chosen['original_case']['clauses'],changed])
            elif expected_kind=='compiler_owned_work':reached=True;returned=cc_compile_gadget(s,model,clauses,work_one=True)
            elif expected_kind=='verifier_owned_work':
                reached=True;returned=cc_verify(s,'verify_tiling',[model,cc_certificate(model,[model['tiles'][0]['id']]*len(model['required_centers']))],work_one=True)
            else:
                sentinel=(s.call('mirror_compiler','GadgetLimit',{},lambda:compiler.GadgetLimit('planned_foreign'))
                    if op=='compiler_foreign_limit'else PlannedForeign('planned exact foreign callback object'))
                def fault():
                    nonlocal hits,reached
                    s.check();hits+=1;reached=True;raise sentinel
                if op.startswith('mirror_compiler'):returned=cc_compile_gadget(s,model,clauses,check=fault)
                else:returned=cc_verify(s,'verify_tiling',[model,cc_certificate(model,[model['tiles'][0]['id']]*len(model['required_centers']))],check=fault)
        except BaseException as error:s.fault_gate();actual=error
        s.fault_gate()
        if expected_kind=='DECLARATION':need(type(actual)is compiler.DeclarationError,'actual compiler malformed-data refusal')
        elif expected_kind=='VERIFIER_INVALID':need(actual is not None and cc_predicate(s,'is_own_invalid',actual),'actual independently owned profile refusal')
        elif expected_kind=='compiler_owned_work':need(type(returned)is dict and returned.get('status')=='UNKNOWN'and returned.get('reason')=='work','owned quota cannot return a candidate')
        elif expected_kind=='verifier_owned_work':need(actual is not None and cc_predicate(s,'is_own_limit',actual),'actual independently owned quota refusal')
        else:need(reached and actual is sentinel,'foreign callback object propagated exactly before any classification')
        record.update(status='PASSED',reached=reached,expectation_satisfied=True,expected_kind=expected_kind,
            error=None if actual is None else information(actual),returned=returned,check_calls_after=s.root_calls,
            exact_foreign_identity=True if expected_kind=='FOREIGN'else None,local_callbacks=hits,
            mutated_compilation=changed)


def cc_qualify(s,inputs):
    need(inputs['exact_case_count']==162 and inputs['exact_base_assignment_count']==697 and
        len(inputs['diagnostics'])==15,'whole prospectively declared new component domain')
    for case in inputs['cases']:s.component_rows.append(cc_qualify_case(s,case))
    need(sum(r['assignments_checked']for r in s.component_rows)==697,'all original base assignments covered')
    need(sum(r['exhaustive']['assignment_count']for r in s.component_rows if r['exhaustive']is not None)==4214,
        'entire declared full-palette product subdomain')
    statuses=[a['status']for row in s.component_rows for a in row['assignments']]
    for required in('UNIQUE_ALLOWED_EXTENSION','FORBIDDEN_BY_DECLARED_CLAUSE','INVALID_ORIGINAL_ASSIGNMENT'):
        need(required in statuses,'nonvacuous positive, forbidden and original-mark refusal coverage')
    cc_diagnostics(s,inputs,s.component_rows)
    need(len(s.component_rows)==162 and len(s.component_diagnostics)==15,'no missing case or diagnostic')
    return dict(schema='complete-finite-marking-qualification-packet-v1',inputs=inputs,rows=s.component_rows,
        diagnostics=s.component_diagnostics,full_base_assignments=697,full_palette_assignments=4214,
        representation='Actual finite point t/m assignments, no clause scanner used for raw tiling validity.',
        limits={k:COMPONENT_LIMITS[k]for k in('mirror_compiler','mirror_verifier')},redundancy_established=False,learned_markings=False,trained_RL=False,
        proof_search=False,full_pipeline_qualified=False,mathematical_proof_accepted=False)




def run_dpll(s,model,clauses,label):
    began=NOW();result=invoke(s,'dpll','solve',[model,clauses]);checks=[]
    need(result['status']=='ALL_SOLUTIONS_EXHAUSTED'and result['exhausted']is True and result['root_restored']is True,'complete conventional control, no unknown prefix')
    for cert in result['solutions']:
        checked_point=raw_tiling(s,model,cert);need(checked_point['status']=='VALID_EXACT_FINITE_TILING','conventional returned point certificate checked independently');checks.append(checked_point)
    return dict(label=label,result=result,solution_checks=checks,complete_seconds=(NOW()-began)/1e9,
        cost_scope='Whole generic original point-to-CNF compilation, conventional DPLL enumeration and independent returned point checks; no GCTS graph scheduler or graph-census equivalence claim.')


def qualify_comparison_case(s,case):
    began=NOW();row=qualify_original_case(s,case);model=row['model'];clauses=row['certified_clauses']
    expected=sorted_certificates(s,row['reference']['solutions'])
    # Each arm pays for its own fresh complete acquisition; every resulting literal list must match.
    mirror_cold=NOW();s.stage='MIRROR_COLD_ACQUISITION';mirror_acquisition=run_search(s,model,'mirror_acquisition',acquire=True)
    mirror_clauses=[clone(p['receipt']['clause'])for p in mirror_acquisition['proofs']]
    need(canonical(mirror_clauses)==canonical(clauses),'same actual independently checked failures in old and mirror arms')
    need(sorted_certificates(s,mirror_acquisition['result']['solutions'])==expected,'full mirror acquisition original population')
    mirror_reuse=NOW();s.stage='MIRROR_COMPILE_AND_TRANSLATION'
    compilation=invoke(s,'mirror_compiler','compile_marking_gadget',[model,mirror_clauses]);need(compilation['status']=='MARKING_GADGET_CANDIDATE','whole new mirror compiler')
    translation=invoke(s,'mirror_verifier','verify_translation',[model,mirror_clauses,compilation]);need(translation['status']=='VALID_MARKING_GADGET_TRANSLATION','independent complete mirror construction')
    compile_end=NOW();s.stage='MIRROR_COMPLETE_SEARCH';marked=run_search(s,compilation['instance'],'mirrored')
    projected=[];projections=[]
    for cert in marked['result']['solutions']:
        record=invoke(s,'mirror_compiler','project',[compilation,cert]);need(record['status']=='PROJECTION_CANDIDATE','complete mirror projection')
        checked_point=raw_tiling(s,model,record['certificate']);need(checked_point['status']=='VALID_EXACT_FINITE_TILING','mirror projection original raw point verification')
        projected.append(record['certificate']);projections.append(dict(record=record,raw_check=checked_point))
    need(sorted_certificates(s,projected)==expected,'all mirror projections exactly preserve every unique original solution')
    mirror_end=NOW();s.stage='DPLL_NO_ADVICE';dpll_plain=run_dpll(s,model,[],'dpll_plain')
    need(sorted_certificates(s,dpll_plain['result']['solutions'])==expected,'complete conventional original solution equality')
    dpll_cold=NOW();s.stage='DPLL_COLD_ACQUISITION';dpll_acquisition=run_search(s,model,'dpll_acquisition',acquire=True)
    dpll_clauses=[clone(p['receipt']['clause'])for p in dpll_acquisition['proofs']]
    need(canonical(dpll_clauses)==canonical(clauses),'same actual certified failures passed to DPLL')
    need(sorted_certificates(s,dpll_acquisition['result']['solutions'])==expected,'full conventional-advice acquisition original population')
    s.stage='DPLL_IDENTICAL_ADVICE';dpll=run_dpll(s,model,dpll_clauses,'dpll_certified')
    need(sorted_certificates(s,dpll['result']['solutions'])==expected,'all conventional same-advice original solutions preserved')
    dpll_end=NOW()
    row.update(mirror_acquisition=mirror_acquisition,mirror_compilation=compilation,mirror_translation=translation,
        mirrored=marked,mirror_projections=projections,mirror_projected_solutions=projected,
        dpll_plain=dpll_plain,dpll_acquisition=dpll_acquisition,dpll_certified=dpll,
        mirror_compile_translation_seconds=(compile_end-mirror_reuse)/1e9,mirror_reuse_seconds=(mirror_end-mirror_reuse)/1e9,
        mirror_cold_seconds=(mirror_end-mirror_cold)/1e9,dpll_certified_cold_seconds=(dpll_end-dpll_cold)/1e9,
        total_comparison_case_seconds=(dpll_end-began)/1e9,mirror_and_DPLL_all_solutions_preserved=True,
        mirror_lane_uses_only_point_agreement=True,same_literal_certified_advice=True,
        conventional_scope='Simple Root-authored generic point-CNF/DPLL implementation, not an external state-of-art solver; its variables/Boolean branches and GCTS placement branches have different units. Complete extensional finite populations checked, no formal universal kernel or GCTS graph-conformance claim for DPLL.')
    return row


def additional_diagnostics(s,inputs):
    aux=next(r for r in s.rows if r['mirror_compilation']['mapping']['auxiliary_tiles']and r['mirrored']['result']['solutions'])
    model=aux['model'];clauses=aux['certified_clauses'];comp=aux['mirror_compilation']
    for declared in inputs['additional_diagnostics']:
        s.stage='MIRROR_OR_CONTROL_DIAGNOSTIC';s.active=declared['id'];s.check();op=declared['operation'];error=None;returned=None;hits=0;foreign=PlannedForeign('exact new external callback object')
        record=dict(id=declared['id'],operation=op,status='ENTERED');s.diagnostics.append(record)
        offered=clone(comp);instance=clone(model);advice=clone(clauses)
        def boom():
            nonlocal hits
            hits+=1;raise foreign
        role='mirror_verifier';expected='OWN_INVALID'
        try:
            if op in('mirror_missing_original_m','mirror_wrong_original_value','mirror_wrong_original_offset','mirror_wrong_original_channel','mirror_extra_t_support'):
                emitted=offered['mapping']['auxiliary_tiles'][0][0];tile=next(t for t in offered['instance']['tiles']if t['id']==emitted)
                need(len(tile['m'])>4,'nonvacuous copied original marking mutation')
                if op=='mirror_missing_original_m':tile['m'].pop(4)
                elif op=='mirror_wrong_original_value':tile['m'][4][2]+=1
                elif op=='mirror_wrong_original_offset':tile['m'][4][0][0]+=2
                elif op=='mirror_wrong_original_channel':tile['m'][4][1]+='_wrong'
                else:tile['t'].append([[2,0],1])
                record['offered_compilation']=offered
                returned=invoke(s,'mirror_verifier','verify_translation',[model,clauses,offered])
            elif op in('mirror_extend_foreign','mirror_project_foreign'):
                role='mirror_compiler';expected='FOREIGN'
                certificate_value=aux['reference']['solutions'][0]if op=='mirror_extend_foreign'else aux['mirrored']['result']['solutions'][0]
                returned=invoke(s,role,'extend'if op=='mirror_extend_foreign'else'project',[comp,certificate_value],check=boom)
            else:
                role='dpll'
                if op=='dpll_owned_work':expected='UNKNOWN';returned=invoke(s,role,'solve',[instance,advice],one=True)
                elif op in('dpll_foreign_check','dpll_foreign_same_class'):
                    expected='FOREIGN'
                    if op=='dpll_foreign_same_class':foreign=s.call('dpll','Limit',{},lambda:s.modules['dpll'].Limit('foreign without private owner'))
                    returned=invoke(s,role,'solve',[instance,advice],check=boom)
                elif op=='dpll_invalid_boolmark':instance['tiles'][0]['m'][0][2]=False;record['offered_instance']=instance;returned=invoke(s,role,'solve',[instance,advice])
                elif op=='dpll_invalid_admissible_bool':instance['admissible_origins'][0][0]=False;record['offered_instance']=instance;returned=invoke(s,role,'solve',[instance,advice])
                elif op=='dpll_invalid_literal':advice=[[dict(origin=instance['required_centers'][0],tile_id=999999)]];record['offered_advice']=advice;returned=invoke(s,role,'solve',[instance,advice])
                else:raise PolicyFailure('every new declared diagnostic')
        except BaseException as caught:s.fault_gate();error=caught
        if expected=='FOREIGN':passed=error is foreign and hits==1
        elif expected=='UNKNOWN':passed=error is None and returned['status']=='UNKNOWN'and returned['exhausted']is False
        else:passed=error is not None and predicate(s,role,'is_own_invalid',error)
        need(passed,'exact new mirror/control diagnostic expected disposition')
        record.update(status='PASSED',expected=expected,error=None if error is None else information(error),returned=returned,local_callbacks=hits,exact_foreign_identity=error is foreign)


def qualify(s,inputs):
    need(inputs['schema']=='ROOT-mirrored-receptor-comparison-inputs-v1'and len(inputs['cases'])==23 and len(inputs['diagnostics'])==18 and len(inputs['additional_diagnostics'])==13,'whole extended bank, no omitted original case or diagnostic')
    component=cc_qualify(s,inputs['component_bank'])
    for case in inputs['cases']:s.rows.append(qualify_comparison_case(s,case))
    need(any(r['original_solution_count']>0 for r in s.rows)and any(r['original_solution_count']==0 for r in s.rows),'positive and exhausted-negative cases')
    need(any(r['certified_clauses']for r in s.rows),'actual original primitive certified failures, not supplied advice')
    diagnostics(s,inputs,s.rows);additional_diagnostics(s,inputs)
    return dict(schema='complete-mirrored-receptor-comparison-packet-v1',inputs=inputs,rows=s.rows,diagnostics=s.diagnostics,
        component_qualification=component,complete_case_count=23,complete_diagnostic_count=31,component_case_count=162,component_diagnostic_count=15,
        finite_scope='Exact finite unit-center complete mirror component bank and whole same-instance acquired-advice search comparison. Input-specific Boolean palettes, no fixed full-FOL palette, arithmetic/Hilbert integration or RL.',
        snapshot_scope='Every live GCTS graph independently reconstructed; selected full initial/firstbranch/firstdead/root and all traces/scalar census receipts retained. Conventional DPLL has its own complete CNF/provenance and assignment trace, not GCTS snapshots.',
        costs='Original whole180/210/1GiB/128MiB and cumulative400m callbacks. Includes entire162component cases, original23comparisoncases, all46diagnostics and allsourceguards, reference/certification/compile/check/search/cold acquisitions/output. Private DPLL CNF operations differ from point/graph work.',
        original_workloads_preserved=True,full_pipeline_qualified=False,mathematical_proof_accepted=False,RL=False)


def main(plan_path):
    plan_raw=Path(plan_path).read_bytes();need(len(plan_raw)<=16777216,'bounded complete plan')
    plan=json.loads(plan_raw);plan_pin=descriptor(plan_path,plan_raw)
    need(type(plan)is dict and set(plan)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'}and
        plan['schema']=='ROOT-wang-encoding-qualification-plan-v1','exact once-plan compatibility schema')
    need(plan['limits']==OUTER_LIMITS and set(plan['sources'])==set(SOURCE_ROLES),'original caps; all ten Sources')
    actual=Path(plan['actual_directory']);need(actual.is_absolute()and actual==actual.resolve()and actual.is_dir(),'owned once actual')
    consumed=json.loads((actual/'CONSUMED.json').read_bytes())
    need(consumed['plan']==plan_pin and consumed['invocation_id']==plan['invocation_id']and
        consumed['schema']=='wang-encoding-qualification-consumed-v1'and
        type(consumed['maximum_worker_launches'])is int and consumed['maximum_worker_launches']==1 and
        consumed['consumed_before_Popen']is True and type(consumed['began_ns'])is int and
        consumed['work_deadline_ns']==consumed['began_ns']+180000000000 and
        consumed['overall_deadline_ns']==consumed['began_ns']+210000000000,'inherited original Source-entry epoch')
    s=Session(plan,plan_pin,consumed,actual)
    try:
        s.check();need(descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['worker'],'complete worker Source pin')
        for role,(sha,size)in SOURCE_PINS.items():need((plan['sources'][role]['sha256'],plan['sources'][role]['bytes'])==(sha,size),'exact mathematical Source')
        for pin in plan['sources'].values():checked(pin)
        checked(plan['python'],67108864)
        declaration=json.loads(checked(plan['declaration']));closure=json.loads(checked(plan['runtime_closure']))
        need(declaration['schema']=='ROOT-wang-encoding-qualification-declaration-v1'and
            declaration['limits']==OUTER_LIMITS and declaration['component_limits']==COMPONENT_LIMITS and
            declaration['checkpoint_limit']==CHECKPOINT_LIMIT and declaration['experiment_kind']=='MIRRORED_RECEPTOR_SAME_ADVICE_COMPARISON',
            'new component question; original resource ceilings')
        need(closure['schema']=='ROOT-wang-encoding-runtime-closure-v1'and closure['python']==plan['python']and
            closure['sources']==plan['sources']and closure['declaration']==plan['declaration'],'complete current runtime closure')
        for pin in closure['stdlib_files']:checked(pin)
        need(plan['inputs']==declaration['inputs']and len(plan['inputs'])==1,'whole frozen input capsule')
        raw=checked(plan['inputs'][0]['pin'],134217728)
        need(len(raw)==INPUT_BYTES and hashlib.sha256(raw).hexdigest()==INPUT_SHA,'original complete new component bank')
        inputs=json.loads(raw);s.retained.append(inputs)
        need([r['id']for r in inputs['cases']]==declaration['case_ids']and
            [r['id']for r in inputs['diagnostics']+inputs['additional_diagnostics']]==declaration['diagnostic_ids']and [r['id']for r in inputs['component_bank']['cases']]==declaration['component_case_ids']and [r['id']for r in inputs['component_bank']['diagnostics']]==declaration['component_diagnostic_ids'],'full prospective domain and order')
        subject={k:v for k,v in plan.items()if k!='authorization'};auth=json.loads(checked(plan['authorization']))
        need(auth['actual_execution_authorized']is True and auth['author_identity']=='/root'and
            type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and
            auth['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest(),'max-one Root grant of exact new subject')
        s.write_json('WORKER_CONSUMED.json',dict(plan=plan_pin,pid=os.getpid(),ppid=os.getppid(),
            worker_entry_ns=ENTRY_NS,maximum_invocations=1),1048576)
        def audit(event,args):
            if event in FORBIDDEN_EVENTS:
                s.denied.append(event);s.policy(lambda:need(False,'forbidden process/network/dlopen event'))
        sys.addaudithook(audit)
        for role in('compiler','verifier','search','census','mirror_compiler','mirror_verifier','dpll'):s.load(role)
        packet=qualify(s,inputs);s.active=None;s.guard();s.stage='FULL_PACKET_WRITE'
        output=s.write_json('canonical-mirrored-receptor-comparison.json',packet,134217728-RESERVE_BYTES)
        s.output_pins.append(output)
        q=dict(schema='mirrored-receptor-comparison-candidate-v1',status='COMPLETE_MIRRORED_RECEPTOR_COMPARISON_CANDIDATE',
            outputs=s.output_pins,case_ids=declaration['case_ids'],diagnostic_ids=declaration['diagnostic_ids'],
            rows=[{key:r[key]for key in('id','complete','all_original_solutions_preserved','primitive_certificates_checked','marked_lane_uses_only_point_agreement','original_solution_count','mirror_and_DPLL_all_solutions_preserved','mirror_lane_uses_only_point_agreement','same_literal_certified_advice')}for r in s.rows],
            diagnostics=s.diagnostics,component_case_ids=declaration['component_case_ids'],component_diagnostic_ids=declaration['component_diagnostic_ids'],component_rows=[{k:r[k]for k in('id','status','assignments_checked','all_primitive_checks_passed','all_projection_checks_passed','all_uniqueness_checks_passed','full_palette_exhausted')}for r in s.component_rows],component_diagnostics=s.component_diagnostics,component_base_assignments=697,component_full_palette_assignments=4214,mirror_compiler_calls=s.calls('mirror_compiler'),mirror_verifier_calls=s.calls('mirror_verifier'),DPLL_calls=s.calls('dpll'),root_check_calls=s.root_calls,
            root_check_calls_scope='cutoff before metadata serialization; later callbacks still within original invocation ceiling',
            compiler_calls=s.calls('compiler'),verifier_calls=s.calls('verifier'),search_calls=s.calls('search'),oracle_calls=s.calls('census'),
            full_pipeline_qualified=False,mathematical_proof_accepted=False,fixed_FOL_palette_qualified=False,
            gcts_rl_advantage_established=False,learned_pair_markings=False,trained_RL=False,
            same_instance_primitive_redundancy_candidate=True,
            graph_census_calls=s.started.get('census.audit_snapshot',0),primitive_certificate_calls=s.started.get('census.certify_deadpoint',0),
            legacy_kernel_counter_scope='FOL_kernel_calls0; independent primitive certificates, point checks and actual Root truth/formula helpers are real work counted separately.',certified_clauses=sum(len(r['certified_clauses'])for r in s.rows))
        zeros=dict(Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,FOL_kernel_calls=0,opaque_program_decodes=0)
        payload=dict(schema='wang-encoding-qualification-result-v1',invocation_id=plan['invocation_id'],plan=plan_pin,
            declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],qualification=q,outputs=s.output_pins,
            denied_events=s.denied,canonical_logical_bytes=output['bytes'],expanded_canonical_packet_bytes=output['bytes'],
            compiler_calls=s.calls('compiler'),verifier_calls=s.calls('verifier'),search_calls=s.calls('search'),oracle_calls=s.calls('census'),
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,**zeros)
        s.stage='RESULT_WRITE';result=s.write_json('result.json',payload,134217728-RESERVE_BYTES-output['bytes'])
        s.guard()
        for pin in closure['stdlib_files']:checked(pin)
        checked(plan['inputs'][0]['pin'],134217728);s.check()
        logical=output['bytes']+result['bytes'];need(0<logical<=134217728,'full unshared stored/expanded output')
        header=dict(schema='wang-encoding-qualification-worker-receipt-v1',version=VERSION,
            invocation_id=plan['invocation_id'],plan=plan_pin,began_ns=s.began,work_deadline_ns=s.work_deadline,
            overall_deadline_ns=s.overall_deadline,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,
            result=result,outputs=s.output_pins,logical_result_bytes=logical,expanded_logical_result_bytes=logical,
            outer_metadata_reservation=RESERVE_BYTES,finite_encoding_candidate=True,
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,
            call_started=s.started,call_completed=s.completed,call_raised=s.raised,
            root_check_calls=s.root_calls,positive_worker_completed_ns=NOW(),
            snapshot_cutoff_scope='before header serialization/final callback/known exit',**zeros)
        s.stage='HEADER_WRITE';s.write_json('worker-receipt.json',header,4194304)
        need(sum(p.stat().st_size for p in actual.iterdir()if p.is_file())+RESERVE_BYTES<=134217728,
            'all actual files plus original outer9MiB reserve')
        s.check();return 0
    except BaseException as error:
        primary=s.first_fault if s.first_fault is not None else error
        failure=dict(schema='certified-point-search-worker-failure-v1',status='FAILED_OR_UNFINISHED',
            plan=plan_pin,invocation_id=plan['invocation_id'],stage=s.stage,active_row=s.active,
            completed_case_ids=[r['id']for r in s.rows],completed_component_case_ids=[r['id']for r in s.component_rows],component_diagnostic_prefix=[dict(id=r['id'],status=r['status'])for r in s.component_diagnostics],diagnostic_prefix=[dict(id=r['id'],status=r['status'])for r in s.diagnostics],
            call_started=s.started,call_completed=s.completed,call_raised=s.raised,root_check_calls=s.root_calls,
            first_available_fault=information(primary),outputs=s.output_pins,
            no_failed_prefix_admission=True,full_pipeline_qualified=False,mathematical_proof_accepted=False)
        try:s.write_json('worker-failure.json',failure,1048576,closure=True)
        except BaseException:pass
        return 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one exact once-plan path')
    raise SystemExit(main(sys.argv[1]))
