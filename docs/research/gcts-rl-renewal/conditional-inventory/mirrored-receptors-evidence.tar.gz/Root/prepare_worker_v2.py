"""Source authoring only: fixed raw ancestors, text/AST transformation; no subject calls."""
from pathlib import Path
import ast,hashlib,json,re
D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1');old=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1/qualify_certified_point_search_worker_v1.py');s=old.read_text()
component=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1/qualify_marking_worker_v1.py');legacy=component.read_text();legacy=legacy[legacy.index('def limits(s,'):legacy.index('def main(plan_path):')]
names=['limits','predicate','compile_gadget','codec','verify','raw_tiling','certificate','forbidden','qualify_case','diagnostics','qualify']
for name in names:legacy=re.sub(r'\b'+name+r'(?=\()','cc_'+name,legacy)
legacy=legacy.replace("'compiler'","'mirror_compiler'").replace("'verifier'","'mirror_verifier'").replace("'verifier.'","'mirror_verifier.'")
legacy=legacy.replace("op.startswith('mirror_compiler')","op.startswith('compiler')")
legacy=legacy.replace('s.rows','s.component_rows').replace('s.diagnostics','s.component_diagnostics')
legacy=legacy.replace("mark=changed['instance']['tiles'][emitted]['m'][-1]","mark=changed['instance']['tiles'][emitted]['m'][3]")
legacy=legacy.replace('limits=COMPONENT_LIMITS','limits={k:COMPONENT_LIMITS[k]for k in(\'mirror_compiler\',\'mirror_verifier\')}')
s=s.replace("VERSION = 'certified-finite-point-search-integration-worker-v1'","VERSION = 'mirrored-receptor-comparison-worker-v2'")
s=s.replace("SOURCE_ROLES = ('worker','compiler','verifier','search','census','runner','observer')","SOURCE_ROLES = ('worker','compiler','verifier','search','census','mirror_compiler','mirror_verifier','dpll','runner','observer')")
paths={'compiler':Path('/private/tmp/gcts-unit-center-receptor-library-20261019/unit_center_marking_compiler_v1.py'),'verifier':Path('/private/tmp/gcts-finite-marking-verifier-20261019-v1/finite_marking_verifier_v1.py'),'search':Path('/private/tmp/gcts-unit-center-point-search-20261019-v1/unit_center_point_search_v1.py'),'census':Path('/private/tmp/gcts-unit-center-search-verifier-20261019-v1/unit_center_search_verifier_v1.py'),'mirror_compiler':Path('/private/tmp/gcts-mirrored-receptor-library-20261019-v1/unit_center_mirrored_marking_compiler_v2.py'),'mirror_verifier':Path('/private/tmp/gcts-mirrored-receptor-verifier-20261019-v2/mirrored_marking_verifier_v2.py'),'dpll':D/'finite_point_dpll_control_v1.py'}
pins={k:(hashlib.sha256(p.read_bytes()).hexdigest(),len(p.read_bytes()))for k,p in paths.items()}
s=re.sub(r'^SOURCE_PINS = .*$',lambda m:'SOURCE_PINS = '+repr(pins),s,flags=re.M)
raw=(D/'cohort-inputs-v1.json').read_bytes();s=re.sub(r"^INPUT_SHA = .*$",lambda m:'INPUT_SHA = '+repr(hashlib.sha256(raw).hexdigest()),s,flags=re.M);s=re.sub(r'^INPUT_BYTES = .*$',lambda m:'INPUT_BYTES = '+str(len(raw)),s,flags=re.M)
oldlimits="COMPONENT_LIMITS={role:dict(POINT_LIMITS if role in('compiler','verifier')else SEARCH_LIMITS)for role in('compiler','verifier','search','census')}"
newlimits="DPLL_LIMITS=dict(work=400000000,centers=1024,tiles=100000,marks=1000000,variables=1000000,clauses=1000000,literals=8000000,decisions=1000000,trace_rows=2000000,solutions=10000,integer_abs=1000000,string_chars=1024,data_depth=64)\nCOMPONENT_LIMITS={role:dict(DPLL_LIMITS if role=='dpll'else POINT_LIMITS if role in('compiler','verifier','mirror_compiler','mirror_verifier')else SEARCH_LIMITS)for role in('compiler','verifier','search','census','mirror_compiler','mirror_verifier','dpll')}"
assert oldlimits in s;s=s.replace(oldlimits,newlimits)
s=s.replace('self.rows=[];self.diagnostics=[];self.retained=[];self.output_pins=[]','self.rows=[];self.diagnostics=[];self.component_rows=[];self.component_diagnostics=[];self.retained=[];self.output_pins=[]')
s=s.replace('def qualify_case(s,case):','def qualify_original_case(s,case):')
s=s.replace('compile_and_translation_seconds=(compile_end-compile_began)/1e9,total_case_seconds=', 'acquisition_and_certification_seconds=(compile_began-pipeline_began)/1e9,old_reuse_seconds=(end-compile_began)/1e9,compile_and_translation_seconds=(compile_end-compile_began)/1e9,total_case_seconds=')
start=s.index('def qualify(s,inputs):');end=s.index('def main(plan_path):',start)
s=s[:start]+legacy+'\n\n'+(D/'worker_extension_v1.py.txt').read_text()+'\n\n'+s[end:]
s=s.replace("'original caps; seven Sources'","'original caps; all ten Sources'")
s=s.replace("declaration['experiment_kind']=='CERTIFIED_GENERAL_POINT_SEARCH_INTEGRATION'","declaration['experiment_kind']=='MIRRORED_RECEPTOR_SAME_ADVICE_COMPARISON'")
s=s.replace("[r['id']for r in inputs['diagnostics']]==declaration['diagnostic_ids']","[r['id']for r in inputs['diagnostics']+inputs['additional_diagnostics']]==declaration['diagnostic_ids']and [r['id']for r in inputs['component_bank']['cases']]==declaration['component_case_ids']and [r['id']for r in inputs['component_bank']['diagnostics']]==declaration['component_diagnostic_ids']")
s=s.replace("for role in('compiler','verifier','search','census'):s.load(role)","for role in('compiler','verifier','search','census','mirror_compiler','mirror_verifier','dpll'):s.load(role)")
s=s.replace('canonical-certified-point-search-integration.json','canonical-mirrored-receptor-comparison.json')
s=s.replace("schema='certified-finite-point-search-integration-candidate-v1',status='COMPLETE_CERTIFIED_POINT_SEARCH_INTEGRATION_CANDIDATE'","schema='mirrored-receptor-comparison-candidate-v1',status='COMPLETE_MIRRORED_RECEPTOR_COMPARISON_CANDIDATE'")
s=s.replace("'marked_lane_uses_only_point_agreement','original_solution_count')","'marked_lane_uses_only_point_agreement','original_solution_count','mirror_and_DPLL_all_solutions_preserved','mirror_lane_uses_only_point_agreement','same_literal_certified_advice')")
s=s.replace('diagnostics=s.diagnostics,root_check_calls=s.root_calls,','diagnostics=s.diagnostics,component_case_ids=declaration[\'component_case_ids\'],component_diagnostic_ids=declaration[\'component_diagnostic_ids\'],component_rows=[{k:r[k]for k in(\'id\',\'status\',\'assignments_checked\',\'all_primitive_checks_passed\',\'all_projection_checks_passed\',\'all_uniqueness_checks_passed\',\'full_palette_exhausted\')}for r in s.component_rows],component_diagnostics=s.component_diagnostics,component_base_assignments=697,component_full_palette_assignments=4214,mirror_compiler_calls=s.calls(\'mirror_compiler\'),mirror_verifier_calls=s.calls(\'mirror_verifier\'),DPLL_calls=s.calls(\'dpll\'),root_check_calls=s.root_calls,')
s=s.replace("completed_case_ids=[r['id']for r in s.rows],diagnostic_prefix=","completed_case_ids=[r['id']for r in s.rows],completed_component_case_ids=[r['id']for r in s.component_rows],component_diagnostic_prefix=[dict(id=r['id'],status=r['status'])for r in s.component_diagnostics],diagnostic_prefix=")
s=s.replace('Only future reviewed once-run execution may load/call the four components.','Only fresh reviewed once-run execution may load/call the seven components.')
s=s.replace('UNEXECUTED worker Source for one complete declared finite Wang calibration.','UNEXECUTED worker Source for a complete mirrored-receptor and conventional comparison.')
p=D/'qualify_mirrored_receptor_worker_v2.py';p.write_text(s);tree=ast.parse(s);compile(tree,str(p),'exec')
(D/'worker-Source-ancestry-v2.json').write_text(json.dumps({'schema':'mirrored-worker-Source-ancestry-v1','ancestors':[{'path':str(p),'bytes':len(p.read_bytes()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in(old,component)],'component_section':'Exact old complete bank/codec checks renamed cc_ and roles remapped to independent mirror modules; diagnostic flip_prefix_output now fixes the actual old fourth prefix row rather than last appended original mirror.','calls':0,'AST_and_unusedcompile_only':True},sort_keys=True,indent=2)+'\n')
print(json.dumps({'worker':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'subject_calls':0},sort_keys=True))
