"""Raw Source authoring of display-only helpers; no helper execution here."""
from pathlib import Path
D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1');s=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1/build_saved_report_v1.py').read_text();helpers=s[s.index('def tex('):s.index('rows=[]\nfor row in packet')]
(D/'display_helpers_v1.py.txt').write_text(helpers)
