"""Root-only ordinary metadata grant after exact independent prospective review."""
from pathlib import Path
import hashlib,json,sys
D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1')
def pin(p):
 r=p.read_bytes();return dict(path=str(p),bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
def save(p,v):
 with p.open('xb')as f:f.write(json.dumps(v,sort_keys=True,indent=2).encode()+b'\n')
 return pin(p)
assert len(sys.argv)==2
review_path=Path(sys.argv[1]).resolve();review=json.loads(review_path.read_bytes());offer=json.loads((D/'Source-only-offer-v2.json').read_bytes());subject=offer['subject']
assert review['schema']=='wang-encoding-Source-prospective-review-v1'and review['reviewer_identity']=='/root/conventional_control_review'and review['review_passed']is True and review['source_only']is True and review['component_calls']==0 and review['actual_execution_authorized']is False
assert review['subject']==subject and review['subject_sha256']==offer['subject_sha256']
assert not Path(subject['actual_directory']).exists()
for row in list(subject['sources'].values())+[subject['python'],subject['declaration'],subject['runtime_closure']]+[x['pin']for x in subject['inputs']]:assert pin(Path(row['path']))==row
ap=save(D/'authorization-once-v2.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',actual_execution_authorized=True,maximum_actual_invocations=1,subject_sha256=offer['subject_sha256'],review=pin(review_path),scope='One fresh exact V2 mirrored-receptor complete185case46diagnostic comparison under unchanged original180/210/1GiB/128MiB/cumulative400m gates. All originalbanks retained. No oldgrant/retry/prefix/capraise. Scope/trust/cost gaps explicitly adopted; all peer tools stop and fresh Root idlebarrier before launch. Grant consumed even on failure; no repeat.'))
pp=save(D/'plan-authorized-v2.json',dict(subject,authorization=ap));print(json.dumps({'plan':pp,'authorization':ap,'review':pin(review_path)},sort_keys=True))
