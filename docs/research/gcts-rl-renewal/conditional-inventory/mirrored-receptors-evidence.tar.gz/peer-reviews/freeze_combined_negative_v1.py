"""Reviewer-owned ordinary bytes/JSON/AST audit; never load offered modules."""
import ast
import hashlib
import json
from pathlib import Path
import sys

D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1')
C=Path('/private/tmp/gcts-mirrored-receptor-peer-20261019-v1')
P=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1')
M=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
checks=[]
def check(name,condition,detail=None):
    checks.append(dict(name=name,passed=bool(condition),detail=detail))
def pin(path):
    path=Path(path);raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(path):return json.loads(Path(path).read_bytes())
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def dump(node):return ast.dump(node,include_attributes=False)
def definitions(path):
    tree=ast.parse(Path(path).read_text())
    return {node.name:node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
def text(node,path):return ast.get_source_segment(Path(path).read_text(),node)

offer=load(D/'Source-only-offer-v1.json');plan=load(D/'plan-false-v1.json')
subject={k:v for k,v in plan.items() if k!='authorization'}
sha=hashlib.sha256(canon(subject)).hexdigest()
check('exact offered subject',subject==offer['subject'] and sha==offer['subject_sha256']=='35684b8edbe1f51930e7fbea5f88e5f33c19bc0a993cdf71cc09ecfbf982c376')
check('nine-field subject ten-field plan',len(subject)==9 and len(plan)==10)
check('false offer no execution authority',offer['actual_execution_authorized'] is False and offer['component_calls']==0)
check('false plan raw descriptor',pin(D/'plan-false-v1.json')==offer['false_plan'])
check('exact ten Sources',offer['sources']==subject['sources'] and len(subject['sources'])==10)
trees={};defs={}
for role,descriptor in subject['sources'].items():
    path=Path(descriptor['path']);raw=path.read_bytes()
    check('full Source pin '+role,pin(path)==descriptor)
    trees[role]=ast.parse(raw,filename=str(path))
    # Compile is deliberately discarded; no exec/eval/import of the code object.
    compile(raw,str(path),'exec',dont_inherit=True)
    defs[role]=definitions(path)
check('pinned Python executable',pin(subject['python']['path'])==subject['python'])
check('pinned Python3.12 parser',sys.executable==subject['python']['path'] and sys.version_info[:2]==(3,12),sys.version)
declaration=load(subject['declaration']['path']);closure=load(subject['runtime_closure']['path'])
check('declaration raw pin',pin(subject['declaration']['path'])==subject['declaration'])
check('closure raw pin',pin(subject['runtime_closure']['path'])==subject['runtime_closure'])
check('full closure Source/Python/declaration join',closure['sources']==subject['sources'] and closure['python']==subject['python'] and closure['declaration']==subject['declaration'])
for descriptor in closure['stdlib_files']:check('whole declared stdlib '+Path(descriptor['path']).name,pin(descriptor['path'])==descriptor)
for row in closure['direct_import_census']:
    check('pinned parser AST '+row['role'],hashlib.sha256(dump(trees[row['role']]).encode()).hexdigest()==row['AST_sha256'])
    check('census raw Source '+row['role'],row['source']==subject['sources'][row['role']])
limits=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576)
check('unchanged original global caps',subject['limits']==declaration['limits']==limits)
check('cumulative callbacks400m',declaration['checkpoint_limit']==400000000)
auth=load(plan['authorization']['path'])
check('false authorization exact raw pin',pin(plan['authorization']['path'])==plan['authorization'])
check('false maximum0',auth['actual_execution_authorized'] is False and auth['maximum_actual_invocations']==0)
check('actual path absent',not Path(subject['actual_directory']).exists())
check('false observer path absent',not (D/'plan-false-v1-terminal-observation').exists())
check('future authorized observer path absent',not (D/'plan-authorized-v1-terminal-observation').exists())
inputs=load(subject['inputs'][0]['pin']['path'])
check('whole original input pin',pin(subject['inputs'][0]['pin']['path'])==subject['inputs'][0]['pin'])
check('whole input descriptor declaration',subject['inputs']==declaration['inputs'])
old=load(P/'cohort-inputs-v1.json');oldcomp=load(M/'cohort-inputs-v1.json')
check('original23 cases full values unchanged',inputs['cases']==old['cases'] and len(inputs['cases'])==23)
check('original18 diagnostics full values unchanged',inputs['diagnostics']==old['diagnostics'] and len(inputs['diagnostics'])==18)
check('component entire bank full values unchanged',inputs['component_bank']==oldcomp)
check('all162 component cases',len(inputs['component_bank']['cases'])==162)
check('all15 component diagnostics',len(inputs['component_bank']['diagnostics'])==15)
check('new13 diagnostics',len(inputs['additional_diagnostics'])==13)
check('185 cases46 diagnostics whole sums',len(inputs['cases'])+len(inputs['component_bank']['cases'])==185 and len(inputs['diagnostics'])+len(inputs['component_bank']['diagnostics'])+len(inputs['additional_diagnostics'])==46)
check('component697 complete assignments',sum(x['complete_base_assignment_count'] for x in inputs['component_bank']['cases'])==697)
check('case order declaration',[x['id'] for x in inputs['cases']]==declaration['case_ids'])
check('diagnostic order declaration',[x['id'] for x in inputs['diagnostics']+inputs['additional_diagnostics']]==declaration['diagnostic_ids'])
check('component case order declaration',[x['id'] for x in inputs['component_bank']['cases']]==declaration['component_case_ids'])
check('component diagnostic order declaration',inputs['component_bank']['diagnostics']==declaration['component_diagnostics'])
check('complete assignment count declaration',[x['complete_base_assignment_count'] for x in inputs['component_bank']['cases']]==declaration['component_assignment_counts'])
check('exhaustive flags declaration',[x['exhaustive_full_palette'] for x in inputs['component_bank']['cases']]==declaration['component_full_palette_flags'])
olddefs=definitions(subject['sources']['compiler']['path'])
for name,node in olddefs.items():
    if name!='_build':check('mirror compiler unchanged definition '+name,dump(node)==dump(defs['mirror_compiler'][name]))
oldb=definitions(subject['sources']['verifier']['path'])
for name,node in oldb.items():
    if name not in ('_Budget','_translation','verify_translation','verify_extension','verify_projection','verify_tiling','_failure','analyze_base_assignment'):
        # These retained routines carry literal versioned result schema names.
        if name in defs['mirror_verifier']:
            a=dump(node);b=dump(defs['mirror_verifier'][name])
            # Report, not a substitute for manual diff of the changed routines.
            check('mirror verifier retained definition '+name,a==b)
parentdefs=definitions(P/'qualify_certified_point_search_worker_v1.py')
for name in ('eval_formula','cnf_value','make_model','reference_solutions','sorted_certificates','core','run_search','diagnostics'):
    check('old search worker definition exact '+name,dump(parentdefs[name])==dump(defs['worker'][name]))
renamed=ast.parse(text(defs['worker']['qualify_original_case'],subject['sources']['worker']['path'])).body[0]
renamed.name='qualify_case'
renamed.body[-1].value.keywords=[kw for kw in renamed.body[-1].value.keywords if kw.arg not in ('acquisition_and_certification_seconds','old_reuse_seconds')]
check('old case procedure exact except name and two reported time intervals',dump(parentdefs['qualify_case'])==dump(renamed))
parentrunner=definitions(P/'run_certified_point_search_once_v1.py')
for name in ('error_information','need','canonical','descriptor','checked','save_new','contains','group_absent'):
    check('outer retained top helper '+name,dump(parentrunner[name])==dump(defs['runner'][name]))
main=defs['runner']['main'];oldmain=parentrunner['main']
def nested(f,name):return next(n for n in f.body if isinstance(n,ast.FunctionDef) and n.name==name)
for name in ('information','note','owned_group_absent','open_log','close_logs','reap','cleanup_child','positive'):
    check('outer retained lifecycle '+name,dump(nested(main,name))==dump(nested(oldmain,name)))
check('old full finalization exact',dump(next(n for n in main.body if isinstance(n,ast.Try))).split("finalbody=",1)[1]==dump(next(n for n in oldmain.body if isinstance(n,ast.Try))).split("finalbody=",1)[1])
obparent=P/'observe_certified_point_search_once_v1.py'
current=Path(subject['sources']['observer']['path']).read_text()
prior=obparent.read_text()
check('observer only version/scope changes',current.replace("VERSION='mirrored-receptor-comparison-terminal-observer-v1'","VERSION='certified-general-point-search-terminal-observer-v1'").replace('Finite mirror component and same-advice search comparison only; full FOL kernel and search advantage remain unqualified.','Finite certified unit-center point search integration only; full FOL kernel and search advantage remain unqualified.')==prior)
# Literal conditions establishing the two reported Source failures, not executed target examples.
srcL=Path(subject['sources']['mirror_compiler']['path']).read_text();srcB=Path(subject['sources']['mirror_verifier']['path']).read_text();srcW=Path(subject['sources']['worker']['path']).read_text()
check('zero mirror counter absent initialization',"self.counts = {'work': 0}" in srcL and "w.step('mirrored_original_mark_rows')" in srcL)
check('unconditional exact mirror counter check',"type(passive.get('mirrored_original_mark_rows'))is int" in srcB)
check('bank contains zero-clause case',inputs['component_bank']['cases'][0]['clauses']==[])
check('retained compiler foreign operations',[x['operation'] for x in inputs['component_bank']['diagnostics'] if x['operation'].startswith('compiler_foreign')]==['compiler_foreign_base','compiler_foreign_limit'])
check('incorrect foreign operation selector present',"if op.startswith('mirror_compiler'):returned=cc_compile_gadget" in srcW)
check('no auxiliary t copy',"t=[[[0, 0], 1]]" in srcL or "'t': [[[0, 0], 1]]" in srcL)

findings=[
dict(id='M1',severity='BLOCKER',kind='Source-predicted coupling failure; not observed runtime failure',source=subject['sources']['mirror_verifier'],function='_translation',detail='The mirror compiler initializes only counts.work and creates mirrored_original_mark_rows on its first loop step. The verifier unconditionally requires that key to hold an exact int. Successful zero-mirror compilations (including the first retained no-clause case) omit it, so independently derived mirror_total=0 does not make this tuple acceptable.',required_correction='Distinct preserved successor: explicitly initialize the compiler counter to0, or adopt an equally strict absent-only-when-independent-zero verifier rule; update full Source/version/worker/closure/subject bindings.'),
dict(id='M2',severity='BLOCKER',kind='False coverage attribution in unexecuted diagnostic Source',source=subject['sources']['worker'],function='cc_diagnostics',detail="The declared operations compiler_foreign_base and compiler_foreign_limit enter the FOREIGN branch, but dispatch tests op.startswith('mirror_compiler'). That is false for both operation names, so they invoke mirror_verifier.verify_tiling and may satisfy exact identity while missing the claimed compiler seam.",required_correction="Preserve mirror module role and cc_compile_gadget wrapper, but use the original operation selector op.startswith('compiler'); retain the unchanged full diagnostic bank.")]

limitations=[
'Source/prospective-only negative receipt. No offered module was loaded/imported, no function or fixture was called, and no actual/proof/search/checker/Native/Model/Reader/inverse/solver was run. Discarded compile/AST/ordinary JSON are static inspection only.',
'Mathematical mirror argument is conditional on accepted construction bounds and complete old placement semantics. Exact chosen base-ID agreement makes copied original m assignments redundant at complete solutions; no t is copied. That argument supplies neither partial-domain pruning nor speed/RAM evidence.',
'The original complete162/697/4214 component bank and23/18 search bank plus13new diagnostics are prospective obligations, not newly qualified outcomes. Prior old compiler/search qualification and all retired negative runs retain their own status.',
'Review reuses genuinely reviewed immutable old compiler/verifier/search/census, prior lifecycle and C DPLL Source receipt. C authored historical controls/helpers in the ancestry, not the current Root worker, new L mirror compiler or new B mirror verifier. Same L author of compiler/search and independent B implementations are disclosed; this is not formal kernel certification.',
'Exclusive caller input ownership and read-only callbacks, raw SourceFileLoader/interpreter/OS/pyc/builtin/transitive stdlib trust remain. Recursive callable/code/default identity plus full actual argument canonical before/after success/refusal are finite guards, not hostile-code/global/default-content/closure/compiled-object sealing or hard preemption.',
'Unit-center translation-only integer2Z2, finite palette at every declared origin, all roots0 and common numeric-domain intersection only. No fractional/shared positive supports, mixed generations, rotations, continuous/fair infinite tiling or full FOL palette/kernel/theorem/RL claim.',
'DPLL is a separately Root-authored conventional finite point-to-CNF control with new explicit private units. Root cumulative400m callbacks, private per-call ticks and branch counters are different units, not CPU work or directly comparable branches. Entire cold acquisitions are independently repeated; any timing observations would be single instrumented cohort scope only.',
'Only selected full GCTS snapshots plus all event/census/proof records are retained; not every historical full graph. Every normal returned population must be checked; no failed/UNKNOWN prefix can become accepted by this review.'
]
failures=[r for r in checks if not r['passed']]
receipt=dict(schema='wang-encoding-Source-prospective-review-v1',reviewer_identity='/root/conventional_control_review',review_passed=False,source_only=True,component_calls=0,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,subject=subject,subject_sha256=sha,sources=subject['sources'],offer=pin(D/'Source-only-offer-v1.json'),false_plan=pin(D/'plan-false-v1.json'),declaration=subject['declaration'],runtime_closure=subject['runtime_closure'],inputs=subject['inputs'],master=pin(D/'basic-tiling-algorithm-current.md'),review_method='Full changed Source/manual correspondence and ordinary metadata; AST/whole raw pins and unused compile; immutable ancestry reuse explicitly scoped.',findings=findings,blocking_finding_count=len(findings),checks=checks,check_count=len(checks),static_audit_check_failure_count=len(failures),static_audit_check_failures=failures,limitations=limitations,inherited_reviews=[pin(C/'typed-DPLL-component-Source-review-v1.json'),pin('/private/tmp/gcts-certified-point-search-peer-20261019-v1/typed-certified-point-search-Source-prospective-review-v1.json'),pin('/private/tmp/gcts-geometric-nogood-review-20261019/typed-marking-component-Source-prospective-review-v1.json')],stop_state='No launch authority; pending distinct corrected Source/prospective successor.')
receipt['reviewer_static_audit_correction']=dict(predecessor=pin(C/'typed-mirrored-comparison-Source-prospective-negative-v1.json'),detail='The first C audit writer recorded four failed comparison assumptions: two intentional verifier schema strings, two added passive time fields, and whitespace in a literal counter check. Raw diff inspection resolves these audit assumptions; the same two concrete Source blockers remain. No offered Source/subject changed and no target was evaluated.')
out=C/'typed-mirrored-comparison-Source-prospective-negative-v1b.json'
if out.exists():raise RuntimeError('immutable review output already exists')
out.write_bytes(json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks),failures=failures,blocking_findings=len(findings)),sort_keys=True))
