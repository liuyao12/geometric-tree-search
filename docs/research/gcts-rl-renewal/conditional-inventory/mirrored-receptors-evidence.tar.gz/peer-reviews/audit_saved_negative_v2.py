"""Passive ordinary saved JSON/raw-byte consistency audit. No target imports/calls."""
import collections
import hashlib
import json
from pathlib import Path

D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1')
C=Path('/private/tmp/gcts-mirrored-receptor-peer-20261019-v1')
A=D/'actual-comparison-v2';O=D/'plan-authorized-v2-terminal-observation'
groups=collections.Counter();failures=[];checks=0
def check(group,name,condition):
    global checks
    checks+=1;groups[group]+=1
    if not condition:failures.append(dict(group=group,name=name))
def pin(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(path):return json.loads(Path(path).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(a,b):return canonical(a)==canonical(b)
def population(values):return sorted(canonical(v).decode() for v in values)
def ns_seconds(n):return str(n//1000000000)+'.'+str(n%1000000000).zfill(9)
plan_path=D/'plan-authorized-v2.json';plan=load(plan_path);subject={k:v for k,v in plan.items() if k!='authorization'}
subject_sha=hashlib.sha256(canonical(subject)).hexdigest();plan_pin=pin(plan_path)
review_path=C/'typed-mirrored-comparison-Source-prospective-review-v2.json';review=load(review_path)
delta_path=C/'typed-final-grant-delta-review-v2.json';delta=load(delta_path)
grant=load(plan['authorization']['path']);decl=load(plan['declaration']['path']);closure=load(plan['runtime_closure']['path'])
inputs=load(plan['inputs'][0]['pin']['path'])
w=load(A/'worker-receipt.json');result=load(A/'result.json');q=result['qualification'];packet=load(A/'canonical-mirrored-receptor-comparison.json')
runner=load(A/'runner-receipt.json');terminal=load(O/'terminal.json');consumed=load(A/'CONSUMED.json');wc=load(A/'WORKER_CONSUMED.json');oc=load(O/'CONSUMED.json')
retirement=load(D/'ROOT-grant-retirement-v2.json');barrier=load(D/'ROOT-all-idle-fresh-barrier-v2.json')
check('custody','exact reviewed complete subject',subject==review['subject']==delta['subject'] and subject_sha==review['subject_sha256']==delta['subject_sha256']=='f5c1deff24deb6bf3b897edc5530e458c0de699920c81bc4318013fa2eabb82d')
check('custody','grant fullsubject reviewed once',grant['subject_sha256']==subject_sha and grant['maximum_actual_invocations']==1 and grant['actual_execution_authorized'] is True and grant['review']==pin(review_path))
for name,p in [('authorization',plan['authorization']),('python',plan['python']),('declaration',plan['declaration']),('closure',plan['runtime_closure'])]+list(plan['sources'].items())+[(i['id'],i['pin']) for i in plan['inputs']]:check('rawpins',name,pin(p['path'])==p)
for p in closure['stdlib_files']:check('rawpins',p['path'],pin(p['path'])==p)
check('custody','all10 reviewed Sources unchanged',plan['sources']==review['sources'] and len(plan['sources'])==10)
check('custody','closure full binding',closure['sources']==plan['sources'] and closure['python']==plan['python'] and closure['declaration']==plan['declaration'])
for name,data in [('worker',w),('result',result),('runner',runner),('terminal',terminal),('consumed',consumed),('workerconsumed',wc),('observerconsumed',oc)]:check('custody','plan '+name,data['plan']==plan_pin)
check('custody','one launch markers',consumed['maximum_worker_launches']==wc['maximum_invocations']==oc['maximum_runner_launches']==runner['worker_launch_attempts']==1 and consumed['consumed_before_Popen'] is True)
check('custody','epoch shared exact',all(data['began_ns']==consumed['began_ns'] and data['work_deadline_ns']==consumed['work_deadline_ns'] and data['overall_deadline_ns']==consumed['overall_deadline_ns'] for data in (w,runner)))
check('custody','original180/210 deltas',consumed['work_deadline_ns']-consumed['began_ns']==180000000000 and consumed['overall_deadline_ns']-consumed['began_ns']==210000000000)
check('custody','worker runner pid joins',w['pid']==wc['pid']==runner['worker_pid']==97513 and w['ppid']==wc['ppid']==terminal['runner_pid']==97512 and w['worker_entry_ns']==wc['worker_entry_ns'])
check('custody','outer observer command exact',terminal['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['runner']['path'],str(plan_path)])
check('custody','worker command exact',runner['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],str(plan_path)])
check('custody','worker/result packets bound raw',w['result']==pin(A/'result.json') and w['outputs']==result['outputs']==q['outputs']==[pin(A/'canonical-mirrored-receptor-comparison.json')])
check('custody','terminal runner raw bound',terminal['runner_receipt']==pin(A/'runner-receipt.json'))
for folder in (A,O):
    for f in folder.iterdir():
        check('files','regular retained file '+str(f),f.is_file() and not f.is_symlink())
check('files','no worker-failure/partial rescue',not (A/'worker-failure.json').exists() and not any(p.name.endswith('.partial') for p in A.iterdir()))
check('files','whole canonical ordinary JSON bytes', (A/'canonical-mirrored-receptor-comparison.json').read_bytes()==canonical(packet)+b'\n')
check('files','whole result ordinary JSON bytes',(A/'result.json').read_bytes()==canonical(result)+b'\n')
check('files','whole input packet equality',same(packet['inputs'],inputs) and same(packet['component_qualification']['inputs'],inputs['component_bank']))
check('population','whole185/46 declared structure',len(packet['rows'])==23 and len(packet['component_qualification']['rows'])==162 and len(packet['diagnostics'])==31 and len(packet['component_qualification']['diagnostics'])==15 and decl['exact_cases']==185 and decl['exact_diagnostics']==46)
check('population','whole23 ordered inputs',[r['id'] for r in packet['rows']]==[r['id'] for r in inputs['cases']]==decl['case_ids'])
check('population','whole162 ordered inputs',[r['id'] for r in packet['component_qualification']['rows']]==[r['id'] for r in inputs['component_bank']['cases']]==decl['component_case_ids'])
check('population','full31 diagnostics exact raw summary',same(packet['diagnostics'],q['diagnostics']) and [r['id'] for r in packet['diagnostics']]==decl['diagnostic_ids'])
check('population','full15 diagnostics exact raw summary',same(packet['component_qualification']['diagnostics'],q['component_diagnostics']) and [r['id'] for r in q['component_diagnostics']]==decl['component_diagnostic_ids'])
for r,d in zip(packet['diagnostics'],decl['diagnostics']):
    check('diagnostics',r['id']+' operation/status',r['id']==d['id'] and r['operation']==d['operation'] and r['status']=='PASSED')
    if r['expected']=='FOREIGN':check('diagnostics',r['id']+' recorded exact foreign',r['exact_foreign_identity'] is True and r['local_callbacks']==1)
for r,d in zip(q['component_diagnostics'],decl['component_diagnostics']):
    check('diagnostics','component '+r['id']+' operation/status',r['id']==d['id'] and r['operation']==d['operation'] and r['status']=='PASSED' and r['expectation_satisfied'] is True and r['reached'] is True)
    if r['expected_kind']=='FOREIGN':check('diagnostics','component '+r['id']+' recorded exact foreign',r['exact_foreign_identity'] is True and r['local_callbacks']==1)
    else:check('diagnostics','component '+r['id']+' noncallback literal flags',r['exact_foreign_identity'] is None and r['local_callbacks']==0)
component_statuses=collections.Counter();full_products=0;full_product_artifacts=0;component_rows=[]
for row,case,summary in zip(packet['component_qualification']['rows'],inputs['component_bank']['cases'],q['component_rows']):
    rid=row['id'];check('component',rid+' original full value',same(row['original_case'],case))
    check('component',rid+' completeassignment count',len(row['assignments'])==row['assignments_checked']==case['complete_base_assignment_count'])
    fields=('id','status','assignments_checked','all_primitive_checks_passed','all_projection_checks_passed','all_uniqueness_checks_passed','full_palette_exhausted')
    check('component',rid+' entire summary projection',same(summary,{k:row[k] for k in fields}))
    check('component',rid+' compilation original/clauses fullbind',same(row['compilation']['base'],case['base']) and same(row['compilation']['clauses'],case['clauses']) and row['compilation']['version']=='unit-center-mirrored-marking-compiler-v2')
    check('component',rid+' B translation candidate only',row['independent_translation']['status']=='VALID_MARKING_GADGET_TRANSLATION' and row['independent_translation']['authority'] is False)
    check('component',rid+' exact initialized counter retained',type(row['compilation']['counts']['mirrored_original_mark_rows']) is int and row['compilation']['counts']['mirrored_original_mark_rows']>=0)
    check('component',rid+' unique saved original words',len(population([x['base_certificate'] for x in row['assignments']]))==len(set(population([x['base_certificate'] for x in row['assignments']]))))
    for i,a in enumerate(row['assignments']):
        component_statuses[a['status']]+=1
        if a['status']=='UNIQUE_ALLOWED_EXTENSION':
            check('component_assignment',rid+str(i)+' complete saved codec/point joins',a['original_check']['status']=='VALID_EXACT_FINITE_TILING' and a['expanded_check']['status']=='VALID_EXACT_FINITE_TILING' and a['projected_check']['status']=='VALID_EXACT_FINITE_TILING' and a['relation']['extension_exists'] is True and same(a['projection']['certificate'],a['base_certificate']) and same(a['extension']['certificate'],a['relation']['certificate']))
        elif a['status']=='FORBIDDEN_BY_DECLARED_CLAUSE':check('component_assignment',rid+str(i)+' retained forbidden refusal',a['original_check']['status']=='VALID_EXACT_FINITE_TILING' and a['extension'] is None and a['relation']['extension_exists'] is False and a['codec_refusal']['type']=='NoExtension')
        else:check('component_assignment',rid+str(i)+' retained original-invalid refusal',a['status']=='INVALID_ORIGINAL_ASSIGNMENT' and a['original_check']['status']=='INVALID_LITERAL_POINT_ASSIGNMENT' and a['extension'] is None and a['codec_refusal']['type']=='DeclarationError')
    ex=row['exhaustive'];check('component',rid+' full product flag',row['full_palette_exhausted'] is (ex is not None) and row['full_palette_exhausted'] is case['exhaustive_full_palette'])
    if ex is not None:
        full_product_artifacts+=1;full_products+=len(ex['assignments'])
        check('component',rid+' entire saved full product size',len(ex['assignments'])==ex['assignment_count'] and ex['exact_expected_preimages_matched'] is True)
        check('component',rid+' distinct raw full products',len(set(population([a['certificate'] for a in ex['assignments']])))==len(ex['assignments']))
        raw_preimages=collections.Counter(canonical(a['projected_base_certificate']).decode() for a in ex['assignments'] if a['check']['status']=='VALID_EXACT_FINITE_TILING')
        check('component',rid+' saved zero/one tally join',all(raw_preimages[canonical(a['base_certificate']).decode()]==(1 if a['status']=='UNIQUE_ALLOWED_EXTENSION' else 0) for a in row['assignments']))
    component_rows.append(dict(id=rid,assignments=len(row['assignments']),mirror_row_counter=row['compilation']['counts']['mirrored_original_mark_rows'],full_product_assignments=0 if ex is None else len(ex['assignments'])))
check('population','entire697 assignment dispositions',sum(component_statuses.values())==697 and component_statuses=={'UNIQUE_ALLOWED_EXTENSION':394,'FORBIDDEN_BY_DECLARED_CLAUSE':291,'INVALID_ORIGINAL_ASSIGNMENT':12})
check('population','entire4214 products12 artifacts',full_products==4214 and full_product_artifacts==12)

normal_census_records=0;proof_count=0;positive=0;solutions=0;row_summaries=[]
for row,case,summary in zip(packet['rows'],inputs['cases'],q['rows']):
    rid=row['id'];expected=population(row['reference']['solutions']);nbase=len(row['model']['required_centers']);solutions+=len(expected);positive+=bool(expected)
    check('searchrow',rid+' original whole input',same(row['input'],case))
    check('searchrow',rid+' reference count and uniqueness',len(expected)==row['original_solution_count'] and len(expected)==len(set(expected)))
    check('searchrow',rid+' literal worker summary fulljoin',all(summary[k]==row[k] for k in summary))
    check('searchrow',rid+' all original projections/full populations agree',all(population(v)==expected for v in (row['plain']['result']['solutions'],row['acquisition']['result']['solutions'],row['mirror_acquisition']['result']['solutions'],row['dpll_acquisition']['result']['solutions'],row['projected_solutions'],row['mirror_projected_solutions'],row['dpll_plain']['result']['solutions'],row['dpll_certified']['result']['solutions'])))
    check('searchrow',rid+' old vs mirror entire extended word population',population(row['marked']['result']['solutions'])==population(row['mirrored']['result']['solutions']))
    check('searchrow',rid+' old and new exact layout mapping',same(row['compilation']['mapping'],row['mirror_compilation']['mapping']) and same(row['compilation']['instance']['required_centers'],row['mirror_compilation']['instance']['required_centers']))
    check('searchrow',rid+' compiler base/clauses binds same advice',all(same(comp['base'],row['model']) and same(comp['clauses'],row['certified_clauses']) for comp in (row['compilation'],row['mirror_compilation'])))
    check('searchrow',rid+' DPLL same instance/full forbiddenvalues',same(row['dpll_plain']['result']['instance'],row['model']) and same(row['dpll_certified']['result']['instance'],row['model']) and row['dpll_plain']['result']['forbidden']==[] and same(row['dpll_certified']['result']['forbidden'],row['certified_clauses']))
    lane_metrics={}
    for lane in ('plain','acquisition','marked','mirror_acquisition','mirrored','dpll_acquisition'):
        value=row[lane];res=value['result'];trace=res['trace'];records=value['records'];normal_census_records+=len(records)
        check('GCTS_lane',rid+lane+' complete literal fields',res['status']=='ALL_SOLUTIONS_EXHAUSTED' and res['mode']=='all' and res['exhausted'] is True and res['root_restored'] is True and res['input_reconciled'] is True)
        check('GCTS_lane',rid+lane+' complete saved trace/solutions lengths',res['statistics']['trace_rows']==len(trace) and res['statistics']['solutions']==len(res['solutions']) and res['statistics']['decision_attempts']==sum(e['kind']=='branch' for e in trace))
        check('GCTS_lane',rid+lane+' retained complete root pair',same({k:v for k,v in value['retained_snapshots']['initial'].items() if k not in ('reason','work')},{k:v for k,v in value['retained_snapshots']['root_restored'].items() if k not in ('reason','work')}))
        check('GCTS_lane',rid+lane+' every saved scalar census disposition',all(r['index']==i and r['receipt_summary']['status']=='EXACT_UNIT_CENTER_POINT_CENSUS_MATCH' and r['receipt_summary']['authority'] is False for i,r in enumerate(records)))
        check('GCTS_lane',rid+lane+' full saved solution receipts',len(value['solution_checks'])==len(res['solutions']) and all(r['status']=='VALID_EXACT_FINITE_TILING' for r in value['solution_checks']))
        if lane in ('acquisition','mirror_acquisition','dpll_acquisition'):
            check('proofjoin',rid+lane+' full candidate/receipt count',len(value['proofs'])==len(res['deadpoint_candidates'])==len(row['certified_clauses']))
            check('proofjoin',rid+lane+' entire advice order',same([p['receipt']['clause'] for p in value['proofs']],row['certified_clauses']))
            proof_count+=len(value['proofs'])
            for i,proof in enumerate(value['proofs']):
                cand=proof['candidate'];receipt=proof['receipt'];snap=proof['acquisition_snapshot'];record=records[proof['snapshot_index']]
                check('proofjoin',rid+lane+str(i)+' full cert/instance/pin/witness binding',same(cand,res['deadpoint_candidates'][i]) and same(cand,receipt['certificate']) and same(cand['instance'],row['model']) and same(receipt['instance'],row['model']) and same(cand['witnesses'],receipt['witnesses']) and same(cand['fixed_background_marks'],row['model']['fixed_background_marks']))
                check('proofjoin',rid+lane+str(i)+' saved original observed DEAD support',snap['scheduler']['kind']=='DEAD' and snap['scheduler']['point']==cand['point']==receipt['point'] and same(snap['scheduler'],record['scheduler']) and same(snap['chosen'],record['chosen']) and same(cand['support'],[dict(cid=x[0],origin=row['model']['required_centers'][x[1]],tile_id=x[2]) for x in snap['chosen']]))
                check('proofjoin',rid+lane+str(i)+' same-instance literalclause receipt scope',same(receipt['clause'],[dict(origin=x['origin'],tile_id=x['tile_id']) for x in cand['support']]) and receipt['status']=='VALID_SAME_INSTANCE_PRIMITIVE_DEADPOINT' and receipt['same_instance_clause_justified'] is True and receipt['branch_exclusions_used'] is False and receipt['authority'] is False)
        else:check('proofjoin',rid+lane+' no fresh failure advice',value['proofs']==[] and res['deadpoint_candidates']==[])
        tiles=len(row['model']['tiles']) if lane in ('plain','acquisition','mirror_acquisition','dpll_acquisition') else len(row['compilation' if lane=='marked' else 'mirror_compilation']['instance']['tiles'])
        removals=[dict(event=i,candidate=c) for i,e in enumerate(trace) if e['kind'] in ('branch','forced') and e['point']>=nbase for c in e.get('removed',[]) if c//tiles<nbase]
        lane_metrics[lane]=dict(base_branch_attempts=sum(e['kind']=='branch' and e['point']<nbase for e in trace),auxiliary_branch_attempts=sum(e['kind']=='branch' and e['point']>=nbase for e in trace),logged_base_removals_on_aux_placement=removals,full_census_records=len(records),statistics=res['statistics'])
    for lane in ('dpll_plain','dpll_certified'):
        v=row[lane];check('DPLL_lane',rid+lane+' literal complete/results',v['result']['status']=='ALL_SOLUTIONS_EXHAUSTED' and v['result']['exhausted'] is True and v['result']['root_restored'] is True and len(v['solution_checks'])==len(v['result']['solutions']) and all(r['status']=='VALID_EXACT_FINITE_TILING' for r in v['solution_checks']))
    for key in ('projections','mirror_projections'):
        projected=row['projected_solutions' if key=='projections' else 'mirror_projected_solutions']
        check('searchrow',rid+key+' full projection receipt equality',same([p['record']['certificate'] for p in row[key]],projected) and all(p['raw_check']['status']=='VALID_EXACT_FINITE_TILING' for p in row[key]))
    row_summaries.append(dict(id=rid,original_solutions=len(expected),certified_clauses_per_arm=len(row['certified_clauses']),lanes=lane_metrics,DPLL={k:row[k]['result']['statistics'] for k in ('dpll_plain','dpll_certified')},timings={k:row[k] for k in ('plain_complete_seconds','cold_certified_pipeline_seconds','mirror_cold_seconds','mirror_reuse_seconds','dpll_certified_cold_seconds')},DPLL_plain_complete_seconds=row['dpll_plain']['complete_seconds'],unqualified=True))
check('population','candidate37 solutions18positive5negative',solutions==37 and positive==18 and 23-positive==5)
check('population','candidate13 certified clauses39 repeated independently checked acquisitions',sum(r['certified_clauses_per_arm'] for r in row_summaries)==13 and proof_count==39)
for key,count in w['call_started'].items():check('counters',key+' started=returned+raised',count==w['call_completed'].get(key,0)+w['call_raised'].get(key,0))
for role,key in [('compiler','compiler_calls'),('verifier','verifier_calls'),('search','search_calls'),('census','oracle_calls'),('mirror_compiler','mirror_compiler_calls'),('mirror_verifier','mirror_verifier_calls'),('dpll','DPLL_calls')]:
    check('counters',role+' exact wrappedcall sum',q[key]==sum(n for k,n in w['call_started'].items() if k.startswith(role+'.')))
check('counters','recorded census/primitive starts exact',q['graph_census_calls']==w['call_started']['census.audit_snapshot']==1679 and q['primitive_certificate_calls']==w['call_started']['census.certify_deadpoint']==44)
check('counters','normal census records separate from diagnostics',normal_census_records<=w['call_completed']['census.audit_snapshot'])
check('counters','Root result/header cutoffs not totalCPU',q['root_check_calls']==27910276 and w['root_check_calls']==27910321 and 0<q['root_check_calls']<=w['root_check_calls']<=400000000)
for data in (w,result):check('authority','no broad API claims '+data['schema'],all(type(data[k]) is int and data[k]==0 for k in ('Native_calls','Model_calls','inverse_calls','Reader_calls','FOL_kernel_calls','opaque_program_decodes')) and data['full_pipeline_qualified'] is False and data['scientific_acceptance'] is False and data['mathematical_proof_accepted'] is False)
check('authority','literal worker candidate only',w['finite_encoding_candidate'] is True and q['status']=='COMPLETE_MIRRORED_RECEPTOR_COMPARISON_CANDIDATE')
check('closure','literal worker exit0 outerexit2',runner['worker_exit_code']==runner['worker_wait4_status']==0 and terminal['runner_exit_code']==2)
check('closure','reaped same group no reappearance',runner['worker_reaped'] is True and runner['owned_group_absent'] is True and runner['cleanup']['group_state']=='ABSENT' and runner['cleanup']['group_reappeared'] is False and runner['cleanup']['completed_before_deadline'] is True)
check('closure','bounded complete diagnostics no cleanup errors',runner['cleanup']['diagnostics_incomplete'] is False and runner['cleanup']['dropped_events']==0 and len(runner['cleanup']['events'])<=32 and runner['cleanup']['poll_cycles']<=2048 and runner['cleanup']['error_summaries']=={} and runner['finalization_errors']==[] and runner['signals']==[])
check('closure','genuine parentlogcloses stable whole logs',runner['regular_logs_closed'] is True and all(v['opened'] is True and v['closed'] is True and v['close_attempts']==1 for v in runner['log_close_observations'].values()) and runner['whole_log_custody']['stable'] is True and runner['whole_log_custody']['complete'] is True)
for key in ('stdout','stderr'):check('rawpins','stable worker '+key,runner[key]==pin(A/(key+'.bin')) and runner[key]['bytes']==0)
check('closure','negative raw custody210 complete',runner['post_child_raw_custody']['checked'] is True and runner['post_child_raw_custody']['completed_before_deadline'] is True and runner['post_child_raw_custody']['completed_ns']<runner['overall_deadline_ns'])
check('closure','literal flags allrejected',runner['resource_candidate_accepted'] is False and runner['finite_encoding_candidate'] is False and terminal['terminal_gate_passed'] is False and terminal['ROOT_resource_accepted'] is False)
check('closure','no positive full result read completion invented','positive_result_read_completed_ns' not in runner and 'worker_peak_bytes' not in runner)
check('clocks','worker selfcomplete and knownexit under180',runner['began_ns']<w['positive_worker_completed_ns']<runner['worker_terminal_observed_ns']<runner['work_deadline_ns'])
check('clocks','allclosure externalterminal210',all(runner['began_ns']<x<terminal['terminal_observed_ns']<runner['overall_deadline_ns'] for x in (runner['closed_ns'],runner['post_child_raw_custody']['completed_ns'],runner['whole_log_custody']['completed_ns'],runner['final_physical_ledger']['completed_ns'])))
check('clocks','exact observed durations',terminal['runner_clock_elapsed_seconds']==(terminal['terminal_observed_ns']-runner['began_ns'])/1e9 and terminal['observed_instrument_elapsed_seconds']==(terminal['terminal_observed_ns']-terminal['observer_started_ns'])/1e9)
check('resources','recorded HWM knownwithinlimit diagnostic only',runner['worker_wait4_usage']['ru_maxrss']==124928000<=1073741824)
check('resources','logical stored/expanded exact fullbyte joins',w['logical_result_bytes']==w['expanded_logical_result_bytes']==pin(A/'result.json')['bytes']+pin(A/'canonical-mirrored-receptor-comparison.json')['bytes']==result['canonical_logical_bytes']+pin(A/'result.json')['bytes']==15704028<=134217728)
before=sum(p.stat().st_size for p in A.iterdir() if p.is_file() and p.name!='runner-receipt.json')
check('resources','negative physical ledger current fullbyte sum',runner['final_physical_ledger']['before_receipt_bytes']==before==15707940 and runner['final_physical_ledger']['conservative_bytes']==before+9437184==25145124 and runner['final_physical_ledger']['within_original_cap'] is True and runner['final_physical_ledger']['enumeration_complete'] is True and runner['final_physical_ledger']['stable_writer_quiescence'] is True)
check('resources','metadata reservation and whole observer folder bounded',w['outer_metadata_reservation']==9437184 and sum(p.stat().st_size for p in O.iterdir() if p.is_file())<=1048576 and pin(A/'runner-receipt.json')['bytes']<=8388608)
offending=[r for r in q['component_diagnostics'] if 'foreign' in r['operation'] and (r['exact_foreign_identity'] is not True or r['local_callbacks']!=1)]
check('negative_diagnosis','one exact substring collision',len(offending)==1 and offending[0]['id']=='D06' and offending[0]['operation']=='foreign_literal_id' and offending[0]['expected_kind']=='DECLARATION' and offending[0]['exact_foreign_identity'] is None and offending[0]['local_callbacks']==0)
check('negative_diagnosis','exact actualcallback rows still recorded',all(r['expected_kind']=='FOREIGN' and r['exact_foreign_identity'] is True and r['local_callbacks']==1 for r in q['component_diagnostics'] if r['operation'] in ('compiler_foreign_base','compiler_foreign_limit','verifier_foreign_base')))
check('negative_diagnosis','literal exact saved firstfailure',runner['primary_failure']==dict(errno=None,message='component exact foreign callback object',type='ValueError') and runner['errors']==[runner['primary_failure']])
src=Path(plan['sources']['runner']['path']).read_text()
check('negative_diagnosis','raw current substringgate pinned',"if 'foreign'in r['operation']:need(r['exact_foreign_identity']is True and r['local_callbacks']==1,'component exact foreign callback object')" in src)
check('retirement','one consumed retired no retry',retirement['retired'] is True and retirement['actual_invocations']==1 and retirement['remaining_invocations']==0 and retirement['repeat_authorized'] is False and retirement['mathematical_adoption'] is False and retirement['no_failed_gate_rescue'] is True)
for key,path in [('consumed',A/'CONSUMED.json'),('worker_consumed',A/'WORKER_CONSUMED.json'),('runner',A/'runner-receipt.json'),('terminal',O/'terminal.json'),('worker_receipt',A/'worker-receipt.json')]:check('retirement','full pin '+key,retirement[key]==pin(path))
check('retirement','grant exactcurrent',retirement['grant']==plan['authorization'] and retirement['plan']==plan_pin and retirement['worker_exit']==0 and retirement['runner_exit']==2 and retirement['terminal_gate_passed'] is False)
check('custody','Root prelaunchbarrier precedesSourceentry',barrier['observed_monotonic_ns']<runner['began_ns'] and barrier['actual_path_fresh'] is True and barrier['observation_path_fresh'] is True)
root_summary=load(D/'ROOT-passive-unqualified-observations-v2.json')
metrics=dict(original_solutions=solutions,certified_clauses_per_arm=13,plain_base_branch_attempts=sum(r['lanes']['plain']['base_branch_attempts'] for r in row_summaries),old_base_branch_attempts=sum(r['lanes']['marked']['base_branch_attempts'] for r in row_summaries),mirror_base_branch_attempts=sum(r['lanes']['mirrored']['base_branch_attempts'] for r in row_summaries),old_aux_to_base_removal_occurrences=sum(len(r['lanes']['marked']['logged_base_removals_on_aux_placement']) for r in row_summaries),mirror_aux_to_base_removal_occurrences=sum(len(r['lanes']['mirrored']['logged_base_removals_on_aux_placement']) for r in row_summaries),DPLL_plain_Boolean_branch_attempts=sum(r['DPLL']['dpll_plain']['branch_attempts'] for r in row_summaries),DPLL_certified_Boolean_branch_attempts=sum(r['DPLL']['dpll_certified']['branch_attempts'] for r in row_summaries),old_cold_seconds_sum=sum(r['cold_certified_pipeline_seconds'] for r in packet['rows']),mirror_cold_seconds_sum=sum(r['mirror_cold_seconds'] for r in packet['rows']),DPLL_plain_seconds_sum=sum(r['dpll_plain']['complete_seconds'] for r in packet['rows']),DPLL_certified_cold_seconds_sum=sum(r['dpll_certified_cold_seconds'] for r in packet['rows']))
for key,value in metrics.items():
    other=root_summary['original_solutions_reported' if key=='original_solutions' else 'certified_clauses_per_arm_reported' if key=='certified_clauses_per_arm' else key]
    check('passive_metrics',key,abs(value-other)<1e-12 if type(value) is float else value==other)
for field in ('call_started','call_completed','call_raised'):check('passive_metrics','full '+field+' map',root_summary[field]==w[field])
check('passive_metrics','Root unqualified status',root_summary['qualification_status']=='OUTER_GATE_REJECTED_UNQUALIFIED' and root_summary['mathematical_adoption'] is False and root_summary['terminal_gate_passed'] is False)
if failures:
    print(json.dumps(dict(checks=checks,failures=failures[:40],failure_count=len(failures)),sort_keys=True));raise RuntimeError('saved consistency mismatch; no review frozen')
pins={str(p.relative_to(D)):pin(p) for folder in (A,O) for p in sorted(folder.iterdir()) if p.is_file()}
metrics.update(normal_saved_census_records=normal_census_records,normal_separately_saved_acquisition_proofs=proof_count,component_assignment_dispositions=dict(component_statuses),full_palette_assignment_count=full_products,full_palette_artifact_count=full_product_artifacts,positive_candidate_cases=positive,negative_candidate_cases=23-positive)
receipt=dict(schema='mirrored-receptor-saved-actual-negative-review-v2',reviewer_identity='/root/conventional_control_review',saved_review_passed=True,saved_data_only=True,component_calls=0,scientific_calls=0,subject_imports=0,replay_calls=0,actual_execution_authorized=False,scientific_acceptance=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,ROOT_fullqualification='REJECTED',qualification_admitted=False,worker_candidate_complete=True,outcome='OUTER_GATE_REJECTED_UNQUALIFIED',mismatch_count=0,check_count=checks,checks_by_group=dict(groups),findings=[dict(id='N1',kind='Observed controller validation failure; no resource or mathematical outcome adoption',source=plan['sources']['runner'],literal_primary=runner['primary_failure'],offending_saved_component_row={k:offending[0][k] for k in ('id','operation','status','expected_kind','local_callbacks','exact_foreign_identity')},diagnosis="Current outer substring `foreign` selects malformed-data foreign_literal_id D06, requiring callback identity where the declared expectation is a DeclarationError with0 callbacks. Actual callback D13/D14/D15 record FORElGN/1/true. This diagnosis is ordinary Source/data comparison, not execution of a corrected validator.",future_only_correction='A distinct reviewed Source successor should classify exact declared operation roles/expected kinds, preserving foreign1/true only for the three callback operations and None/0 for noncallbacks. No current result, grant or gate is repaired/admitted.'),dict(id='N2',kind='Independent review limitation/miss retained',detail='C prior Source/prospective PASS missed this broad substring selector, as did the authored controller. Prior review and all negative Sources remain immutable; this saved negative supersedes any runtime-readiness implication. No formal or complete bug-absence guarantee is claimed.')],subject=subject,subject_sha256=subject_sha,authorized_plan=plan_pin,authorization=plan['authorization'],source_review=pin(review_path),final_grant_delta=pin(delta_path),sources=plan['sources'],inputs=plan['inputs'],declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],actual_pins=pins,retirement=pin(D/'ROOT-grant-retirement-v2.json'),barrier=pin(D/'ROOT-all-idle-fresh-barrier-v2.json'),Root_passive_projection=pin(D/'ROOT-passive-unqualified-observations-v2.json'),diagnostics=dict(component15=q['component_diagnostics'],search_and_new31=[{k:r.get(k) for k in ('id','operation','status','expected','local_callbacks','exact_foreign_identity','error')} for r in packet['diagnostics']]),metrics=metrics,candidate_row_observations=row_summaries,component_row_observations=component_rows,resource_observations=dict(worker_exit=0,runner_exit=2,terminal_gate_passed=False,observer_ROOT_resource_accepted=False,runner_resource_candidate_accepted=False,worker_wait4_highwater_bytes=runner['worker_wait4_usage']['ru_maxrss'],worker_highwater_scope='Recorded standalone worker Darwin lifetime highwater; outer rejected before memory admission gate. Known value, not null or full-production RAM.',runner_epoch_to_terminal_ns=terminal['terminal_observed_ns']-runner['began_ns'],runner_epoch_to_terminal_seconds=ns_seconds(terminal['terminal_observed_ns']-runner['began_ns']),observer_elapsed_seconds=terminal['observed_instrument_elapsed_seconds'],worker_known_exit_ns=runner['worker_terminal_observed_ns'],positive_result_read_completed_ns=None,positive_result_read_scope='Absent in saved runner. Rejection occurred during qualification validation before full positive output-read/resource gates; later C raw hashes cannot rescue those gates.',stored_and_expanded_packet_plus_result_bytes=15704028,negative_physical_before_receipt_bytes=before,negative_conservative_physical_bytes=25145124,negative_custody_before210=True,all_original_limits=plan['limits']),counter_cutoffs=dict(worker_header=w['root_check_calls'],result=q['root_check_calls'],started=w['call_started'],completed=w['call_completed'],raised=w['call_raised'],scope='Explicit wrapped public/private classifier entries as actually instrumented; not every internal function, CPU operation or final callback total. Root callback header cutoff precedes header serialization/final callback; complete private aggregate costs are unavailable.'),limitations=[
'PASS means this saved-data audit consistently establishes the NEGATIVE outer result and retained unqualified candidate observations. It is not candidate/component/search/resource/proof/performance adoption and does not substitute a posthoc validator.',
'No offered target/helper/compiler/search/verifier/oracle/DPLL/checker/truth procedure/Reader/inverse/Native/Model was imported or called. Ordinary JSON projection, whole bytes/hashes, literal metadata comparisons and sums of saved event fields only; no new witness, truth assignment, point legality check, solver or simulation.',
'Saved worker reports185complete cases and46PASSED diagnostics; all retained packet, projection/population and receipt joins were checked as ordinary data. The original exact protocol still failed; no partial cases, whole bank, old162qualification or current candidate is newly admitted by this review.',
'Candidate observations54plain/54old/54mirror base branch attempts and0logged auxiliary-to-base removals provide no admitted pruning benefit. DPLL Boolean attempts have different units. Phase sums are one rejected, instrumented cohort with different cold work scopes and fixed execution order; no causal speed/RAM/GCTS/RL claim follows.',
'All original23/18 and162/697/4214/15 plus13new diagnostics were retained; V1prospective0actual negative and all older retired failures remain separate. V2actual grant is consumed/retiredremaining0; no retry, narrower input or failed-gate rescue authorized.',
'Full ordinary prototypes/certificates/populations and selected initial/firstbranch/firstdead/root snapshots plus all event/scalar census records are retained. Not every historical full graph; all point/checker assertions here are saved observations under prior Source/trust contracts, not independent mathematical replay or kernel verification.',
'Finite unit-center/allroots0/signed remote point instance and common numeric intersection only. Propositional instance-specific factor palettes and supplied-clause representation do not establish a fixed universal FOL palette, arithmetic/Hilbert theorem, mixed-generation/fractional/infinite GCTS conformance or trained RL.',
'Exclusive read-only input custody and raw pinned Source/interpreter/loader/pyc/OS/transitive stdlib trust plus scoped callable/default identity guards persist. No hostile semantic seal or formal compiled-object/default-content/global/closure guarantee. No new OS/process probe was taken; lifecycle claims use saved wait4/group/log/custody/terminal observations and Root authoritative owned-session release.'
],stop_state='Saved audit complete; no actual/reactivation authority. Separate tiny future-selector Source delta may be reviewed only as expressly requested; no current-data validator execution.')
out=C/'typed-saved-actual-negative-review-v2.json'
if out.exists():raise RuntimeError('immutable review exists')
out.write_bytes(json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
print(json.dumps(dict(receipt=pin(out),check_count=checks,mismatch_count=0,metrics=metrics,outcome=receipt['outcome']),sort_keys=True))
