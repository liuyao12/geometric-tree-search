"""Narrow C auth-only ordinary JSON/raw-pin/fresh-path review; no targets."""
import hashlib
import json
from pathlib import Path

D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1')
C=Path('/private/tmp/gcts-mirrored-receptor-peer-20261019-v1')
checks=[]
def check(name,condition):checks.append(dict(name=name,passed=bool(condition)))
def pin(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(path):return json.loads(Path(path).read_bytes())
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
false_path=D/'plan-false-v2.json';true_path=D/'plan-authorized-v2.json';auth_path=D/'authorization-once-v2.json'
review_path=C/'typed-mirrored-comparison-Source-prospective-review-v2.json'
false=load(false_path);true=load(true_path);auth=load(auth_path);review=load(review_path)
subject={k:v for k,v in true.items() if k!='authorization'}
sha=hashlib.sha256(canon(subject)).hexdigest()
check('exact authorized plan raw pin',pin(true_path)==dict(path=str(true_path),bytes=4144,sha256='26b53cc3ec1f69dd5d0bd81927530ec13040fd53a7e6a8738df1e86726f67349'))
check('exact Root auth raw pin',pin(auth_path)==dict(path=str(auth_path),bytes=860,sha256='924d29ae86d2f3a27fc7264e400bb7f5a06f56254e4756ae97682a6415111eab'))
check('preserved false plan exact reviewed pin',pin(false_path)==review['false_plan'])
check('ten plan fields same',set(true)==set(false) and len(true)==10)
check('only authorization descriptor changed',[k for k in true if true[k]!=false[k]]==['authorization'])
check('full nine-field subject literal unchanged',len(subject)==9 and subject=={k:v for k,v in false.items() if k!='authorization'}==review['subject'])
check('canonical subject digest unchanged',sha==review['subject_sha256']==auth['subject_sha256']=='f5c1deff24deb6bf3b897edc5530e458c0de699920c81bc4318013fa2eabb82d')
check('true plan current auth descriptor',true['authorization']==pin(auth_path))
check('exact seven-field Root authorization',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'})
check('Root authored true maxone',auth['schema']=='ROOT-wang-encoding-authorization-v1' and auth['author_identity']=='/root' and auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations']==1)
check('exact current C review descriptor',auth['review']==pin(review_path) and auth['review']['sha256']=='12c5f9f2e0a0fd43620e3fb904d9783e50569b16c03b26e0d676093eba4d4554')
check('exact current review ABI identity and no delegated launch',review['schema']=='wang-encoding-Source-prospective-review-v1' and review['reviewer_identity']=='/root/conventional_control_review' and review['review_passed'] is True and review['source_only'] is True and type(review['component_calls']) is int and review['component_calls']==0 and review['actual_execution_authorized'] is False)
check('all10 Source descriptors unchanged',true['sources']==review['sources'] and len(true['sources'])==10)
for role,p in true['sources'].items():check('full fresh Source pin '+role,pin(p['path'])==p)
for field in ('python','declaration','runtime_closure'):check('fresh '+field+' raw pin',pin(true[field]['path'])==true[field])
for row in true['inputs']:check('whole exact input '+row['id'],pin(row['pin']['path'])==row['pin'])
check('Source input profiles limits complete unchanged',all(true[k]==false[k]==review['subject'][k] for k in ('sources','inputs','limits','python','declaration','runtime_closure')))
decl=load(true['declaration']['path']);closure=load(true['runtime_closure']['path'])
check('complete current declaration input/limits',decl['inputs']==true['inputs'] and decl['limits']==true['limits'] and decl['checkpoint_limit']==400000000)
check('entire bank185/46 still mandatory',decl['exact_cases']==185 and decl['exact_diagnostics']==46 and decl['exact_component_cases']==162 and decl['exact_search_cases']==23 and decl['exact_component_diagnostics']==15 and decl['exact_search_diagnostics']==31)
check('closure current fullSource/Python/declaration',closure['sources']==true['sources'] and closure['python']==true['python'] and closure['declaration']==true['declaration'])
for p in closure['stdlib_files']:check('fresh declared stdlib '+Path(p['path']).name,pin(p['path'])==p)
falsauth=load(false['authorization']['path'])
check('false authorization preserved',pin(false['authorization']['path'])==false['authorization'] and falsauth['actual_execution_authorized'] is False and falsauth['maximum_actual_invocations']==0 and falsauth['subject_sha256']==sha)
actual=Path(true['actual_directory']);observation=D/'plan-authorized-v2-terminal-observation'
check('exact fresh V2 actual path',str(actual)==str(D/'actual-comparison-v2') and actual.is_absolute() and actual==actual.resolve() and actual.parent.is_dir() and not actual.exists())
check('current consumed marker absent',not (actual/'CONSUMED.json').exists() and not (actual/'WORKER_CONSUMED.json').exists())
check('fresh authorized observer folder absent',not observation.exists())
check('current authorized observer consumed absent',not (observation/'CONSUMED.json').exists() and not (observation/'terminal.json').exists())
retirement=load(D/'ROOT-prospective-v1-retirement.json')
check('V1 remains retired0actuals',retirement['retired'] is True and retirement['actual_invocations']==0 and retirement['subject_sha256']!=sha)
check('current Root once scope explicit',all(word in auth['scope'] for word in ('185case46diagnostic','180/210/1GiB/128MiB/cumulative400m','idlebarrier','consumed even on failure','no repeat')))
failures=[r for r in checks if not r['passed']]
if failures:
    print(json.dumps(dict(failures=failures),sort_keys=True));raise RuntimeError('narrow grant review failure')
out=C/'typed-final-grant-delta-review-v2.json'
receipt=dict(schema='wang-encoding-final-grant-delta-review-v1',reviewer_identity='/root/conventional_control_review',final_grant_delta_review_passed=True,review_passed=True,saved_data_only=True,metadata_only=True,scientific_calls=0,component_calls=0,subject_imports=0,actual_execution_authorized=False,review_scope='Auth-only delta, exact reviewed subject/raw descriptor freshness and currently absent owned paths. No repeated mathematical Source review, grant authorship or launch.',authorized_plan=pin(true_path),false_plan=pin(false_path),authorization=pin(auth_path),source_prospective_review=pin(review_path),subject=subject,subject_sha256=sha,sources=true['sources'],declaration=true['declaration'],runtime_closure=true['runtime_closure'],inputs=true['inputs'],checks=checks,check_count=len(checks),mismatch_count=0,findings=[],limits=true['limits'],limitations=[
'All119 current Source/prospective checks and explicitly reused145 predecessor static observations retain their exact conditional scope. Both earlier Source defects remain preserved and are not runtime failures; V1 had0 actuals. No current component/runtime qualification or benefit follows from this metadata review.',
'Current actual and authorized observer folders/consumed markers are absent at this raw filesystem snapshot. This does not assert a continuous OS/process absence proof. Root must separately freeze its all-peer-idle/fresh-path barrier immediately before the one authorized invocation.',
'Root alone grants one exact subject; the grant is consumed even on failure and is not retry authority. This C receipt neither creates a grant nor launches a worker or observer.',
'Original positive complete worker/header/output read and knownexit180, later custody/terminal210, standalone worker1GiB, stored/expanded/physical128MiB,4MiB logs/header and9MiB metadata reserve persist. Cumulative Root400m and private component units remain distinct. All185/46 plus697/4214 obligations remain mandatory.',
'Trusted exclusive-owner raw Source/interpreter/loader/pyc/OS and scoped callable/code/default identity/actual argument guards persist, with no hostile seal, formal kernel, general tiling/FOL/RL/speed claim.'
],stop_state='TOOLS STOPPED after this receipt; await authoritative postterminal saved-data release.')
if out.exists():raise RuntimeError('immutable review output exists')
out.write_bytes(json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks),mismatch_count=0,final_grant_delta_review_passed=True),sort_keys=True))
