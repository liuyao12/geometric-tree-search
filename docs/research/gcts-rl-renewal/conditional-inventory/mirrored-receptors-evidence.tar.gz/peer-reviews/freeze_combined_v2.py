"""C ordinary bytes/AST/JSON successor review; offered code never imported/run."""
import ast
import hashlib
import json
from pathlib import Path
import sys

D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1')
C=Path('/private/tmp/gcts-mirrored-receptor-peer-20261019-v1')
checks=[]
def check(name,condition,detail=None):checks.append(dict(name=name,passed=bool(condition),detail=detail))
def pin(path):
    path=Path(path);raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(path):return json.loads(Path(path).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def asthash(path):return hashlib.sha256(ast.dump(ast.parse(Path(path).read_bytes()),include_attributes=False).encode()).hexdigest()
def assignment(path,name):
    tree=ast.parse(Path(path).read_bytes())
    node=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict' and not node.args and all(kw.arg is not None for kw in node.keywords):
        return {kw.arg:ast.literal_eval(kw.value) for kw in node.keywords}
    return ast.literal_eval(node)
prior_path=C/'typed-mirrored-comparison-Source-prospective-negative-v1b.json'
prior=load(prior_path)
offer=load(D/'Source-only-offer-v2.json');plan=load(D/'plan-false-v2.json')
subject={k:v for k,v in plan.items() if k!='authorization'}
sha=hashlib.sha256(canonical(subject)).hexdigest()
check('exact V2 offer pin',pin(D/'Source-only-offer-v2.json')['sha256']=='d5e94d71d089c9a66537a2840a65dbaef711aa8d6f4fbfe7b6d79726bf4db2d5')
check('exact full nine-field subject',len(subject)==9 and subject==offer['subject'] and sha==offer['subject_sha256']=='f5c1deff24deb6bf3b897edc5530e458c0de699920c81bc4318013fa2eabb82d')
check('false plan descriptor',pin(D/'plan-false-v2.json')==offer['false_plan'])
check('offer Source map equals subject',offer['sources']==subject['sources'] and len(subject['sources'])==10)
check('offer zero calls no authority',offer['component_calls']==0 and offer['actual_execution_authorized'] is False)
check('prior bounded negative exact',pin(prior_path)['sha256']=='de068c26e04cc12841b621b636543a51c784337c3c041fbb575f5498c4f8b086' and prior['review_passed'] is False and prior['static_audit_check_failure_count']==0 and prior['check_count']==145)
check('same Source role set',set(subject['sources'])==set(prior['sources']))
changed={'worker','mirror_compiler','mirror_verifier'}
for role,descriptor in subject['sources'].items():
    check('whole current Source '+role,pin(descriptor['path'])==descriptor)
    if role not in changed:check('unchanged independently reviewed Source '+role,descriptor==prior['sources'][role])
    raw=Path(descriptor['path']).read_bytes();ast.parse(raw)
    compile(raw,descriptor['path'],'exec',dont_inherit=True)
check('input full descriptor unchanged',subject['inputs']==prior['subject']['inputs'])
check('global caps unchanged',subject['limits']==prior['subject']['limits'])
check('interpreter unchanged',subject['python']==prior['subject']['python'] and pin(subject['python']['path'])==subject['python'])
check('actual fresh successor distinct',subject['actual_directory']!=prior['subject']['actual_directory'] and not Path(subject['actual_directory']).exists())
check('invocation fresh successor distinct',subject['invocation_id']=='mirrored-receptor-185cases-46diags-v2' and subject['invocation_id']!=prior['subject']['invocation_id'])
check('no current false observer path',not (D/'plan-false-v2-terminal-observation').exists())
check('no future authorized observer path',not (D/'plan-authorized-v2-terminal-observation').exists())
check('no future authorized plan',not (D/'plan-authorized-v2.json').exists())
for role in changed:check('parent Source remains exact '+role,pin(prior['sources'][role]['path'])==prior['sources'][role])
oldL=Path(prior['sources']['mirror_compiler']['path']).read_text();newL=Path(subject['sources']['mirror_compiler']['path']).read_text()
restoredL=newL.replace("VERSION = 'unit-center-mirrored-marking-compiler-v2'","VERSION = 'unit-center-mirrored-marking-compiler-v1'").replace("self.counts = {'work': 0, 'mirrored_original_mark_rows': 0}","self.counts = {'work': 0}")
check('complete compiler inverse only version and explicitzero',restoredL==oldL)
check('M1 explicit exact intzero before initial callback',"self.counts = {'work': 0, 'mirrored_original_mark_rows': 0}\n        check()" in newL)
check('M1 same per-row operational step',newL.count("w.step('mirrored_original_mark_rows')")==oldL.count("w.step('mirrored_original_mark_rows')")==1)
oldB=Path(prior['sources']['mirror_verifier']['path']).read_text();newB=Path(subject['sources']['mirror_verifier']['path']).read_text()
restoredB=newB.replace("VERSION='independent-mirrored-marking-verifier-v2'","VERSION='independent-mirrored-marking-verifier-v1'").replace("compilation['version']=='unit-center-mirrored-marking-compiler-v2'","compilation['version']=='unit-center-mirrored-marking-compiler-v1'")
check('complete verifier inverse only version binding',restoredB==oldB)
check('M1 strict present/exactint/full independentlyderivedcounter retained',"type(passive.get('mirrored_original_mark_rows'))is int and\n          passive['mirrored_original_mark_rows']==mirror_total" in newB)
oldW=Path(prior['sources']['worker']['path']).read_text();newW=Path(subject['sources']['worker']['path']).read_text()
oldline=next(line for line in oldW.splitlines() if line.startswith('SOURCE_PINS = '));newline=next(line for line in newW.splitlines() if line.startswith('SOURCE_PINS = '))
restoredW=newW.replace("VERSION = 'mirrored-receptor-comparison-worker-v2'","VERSION = 'mirrored-receptor-comparison-worker-v1'").replace(newline,oldline).replace("if op.startswith('compiler'):returned=cc_compile_gadget","if op.startswith('mirror_compiler'):returned=cc_compile_gadget")
check('complete worker inverse only version/pins/selector',restoredW==oldW)
check('M2 original operation selector restored',"if op.startswith('compiler'):returned=cc_compile_gadget(s,model,clauses,check=fault)" in newW and "if op.startswith('mirror_compiler')" not in newW)
hardpins=assignment(subject['sources']['worker']['path'],'SOURCE_PINS')
for role,pair in hardpins.items():check('worker hardcoded component '+role,pair==(subject['sources'][role]['sha256'],subject['sources'][role]['bytes']))
check('exact seven loaded roles hardpins',set(hardpins)==set(subject['sources'])-{'worker','runner','observer'})
for key in ('declaration','runtime_closure'):check('full '+key+' pin',pin(subject[key]['path'])==subject[key])
decl=load(subject['declaration']['path']);olddecl=load(prior['subject']['declaration']['path'])
check('declaration delta ancestry text only',{k:v for k,v in decl.items() if k!='ancestry'}=={k:v for k,v in olddecl.items() if k!='ancestry'})
check('worker literal global profile matches declaration',assignment(subject['sources']['worker']['path'],'OUTER_LIMITS')==decl['limits']==subject['limits'])
check('literal cumulative400m unchanged',assignment(subject['sources']['worker']['path'],'CHECKPOINT_LIMIT')==decl['checkpoint_limit']==400000000)
check('new DPLL private caps explicit and unchanged',decl['component_limits']==olddecl['component_limits'])
closure=load(subject['runtime_closure']['path']);oldclosure=load(prior['subject']['runtime_closure']['path'])
check('closure complete Sources/Python/declaration join',closure['sources']==subject['sources'] and closure['python']==subject['python'] and closure['declaration']==subject['declaration'])
check('closure trust/stdlib policy unchanged',{k:v for k,v in closure.items() if k not in ('sources','declaration','direct_import_census')}=={k:v for k,v in oldclosure.items() if k not in ('sources','declaration','direct_import_census')})
check('exact pinned3.12 parser',sys.executable==subject['python']['path'] and sys.version_info[:2]==(3,12),sys.version)
for row in closure['direct_import_census']:
    check('current AST census '+row['role'],asthash(row['source']['path'])==row['AST_sha256'] and row['source']==subject['sources'][row['role']])
    if row['role'] not in changed:check('old retained AST census '+row['role'],row==next(r for r in oldclosure['direct_import_census'] if r['role']==row['role']))
for descriptor in closure['stdlib_files']:check('whole pinned stdlib '+Path(descriptor['path']).name,pin(descriptor['path'])==descriptor)
inputs=load(subject['inputs'][0]['pin']['path'])
check('whole input raw pin current',pin(subject['inputs'][0]['pin']['path'])==subject['inputs'][0]['pin'])
check('declaration full input join',decl['inputs']==subject['inputs'])
check('worker full input hash/size',assignment(subject['sources']['worker']['path'],'INPUT_SHA')==subject['inputs'][0]['pin']['sha256'] and assignment(subject['sources']['worker']['path'],'INPUT_BYTES')==subject['inputs'][0]['pin']['bytes'])
check('all185 cases all46 diagnostics',len(inputs['cases'])==23 and len(inputs['component_bank']['cases'])==162 and len(inputs['diagnostics'])==18 and len(inputs['component_bank']['diagnostics'])==15 and len(inputs['additional_diagnostics'])==13)
check('full ordered case/declaration join',[r['id'] for r in inputs['cases']]==decl['case_ids'] and [r['id'] for r in inputs['component_bank']['cases']]==decl['component_case_ids'])
check('full ordered diagnostic/declaration join',inputs['diagnostics']+inputs['additional_diagnostics']==decl['diagnostics'] and inputs['component_bank']['diagnostics']==decl['component_diagnostics'])
check('same697 complete base assignments',sum(r['complete_base_assignment_count'] for r in inputs['component_bank']['cases'])==697)
check('zero-clause and zero-m controls remain',any(r['clauses']==[] for r in inputs['component_bank']['cases']) and any(not any(t['m'] for t in r['base']['tiles']) for r in inputs['component_bank']['cases']))
check('compiler foreign controls unchanged',[r['operation'] for r in inputs['component_bank']['diagnostics'] if r['operation'].startswith('compiler_foreign')]==['compiler_foreign_base','compiler_foreign_limit'])
check('all native/FOL broad flags false',decl['full_pipeline_qualified'] is False and decl['forbidden_api']==olddecl['forbidden_api'])
check('false authorization exact pin',pin(plan['authorization']['path'])==plan['authorization'])
auth=load(plan['authorization']['path'])
check('false exact max0 subject grant',auth['actual_execution_authorized'] is False and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations']==0 and auth['review'] is None and auth['subject_sha256']==sha)
retirement=D/'ROOT-prospective-v1-retirement.json';ret=load(retirement)
check('V1 retired unexecuted negative',ret['retired'] is True and ret['actual_invocations']==0 and ret['subject_sha256']==prior['subject_sha256'] and not Path(prior['subject']['actual_directory']).exists())
master=pin(D/'basic-tiling-algorithm-current.md')
check('current master retained exact',master['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4' and master['bytes']==36240)
L=Path(subject['sources']['mirror_compiler']['path']).parent;B=Path(subject['sources']['mirror_verifier']['path']).parent
support=[]
for folder,handoff_name in ((L,'handoff-v2.json'),(B,'handoff-v2.json')):
    hpath=folder/handoff_name;h=load(hpath);support.append(pin(hpath))
    for v in h.values():
        if type(v) is dict and set(v)=={'path','bytes','sha256'}:check('handoff descriptor '+str(Path(v['path']).name),pin(v['path'])==v)
    if 'artifacts' in h:
        for name,v in h['artifacts'].items():check('handoff artifact '+name,pin(v['path'])==v)
support.extend([pin(L/'API-v2.json'),pin(L/'Source-contract-v2.json'),pin(L/'extension-projection-argument-v1.json'),pin(B/'API-v2.json'),pin(B/'proof-delta-v2.json')])
failures=[r for r in checks if not r['passed']]
if failures:
    print(json.dumps(dict(checks=len(checks),failures=failures),sort_keys=True));raise RuntimeError('C static audit must resolve failures before freeze')
limitations=list(prior['limitations'])
limitations[0]='Source/prospective-only PASS for the exact V2 bytes and conditional execution contract. No offered module was loaded/imported, no function/fixture was called, and no actual/proof/search/checker/Native/Model/Reader/inverse/solver was run. Discarded compile/AST/ordinary JSON are static inspection only; this review grants no launch authority.'
receipt=dict(schema='wang-encoding-Source-prospective-review-v1',reviewer_identity='/root/conventional_control_review',review_passed=True,source_only=True,component_calls=0,fixture_calls=0,subject_imports=0,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,subject=subject,subject_sha256=sha,sources=subject['sources'],offer=pin(D/'Source-only-offer-v2.json'),false_plan=pin(D/'plan-false-v2.json'),false_authorization=plan['authorization'],declaration=subject['declaration'],runtime_closure=subject['runtime_closure'],inputs=subject['inputs'],master=master,author_identities=['/root','/root/conventional_library','/root/benchmark_design'],ancestry_overlap='C genuinely reviewed current immutable ancestry and authored older control/helper ancestry; C did not author Root current worker/DPLL/outer, L mirror compiler or B mirror verifier. Reuse is explicit and conditional, not fresh independent formal kernel certification.',review_method='Prior full changed-source/manual/JSON review plus complete inert reverse of the three V2 changed Sources, all current full byte/parser/subject/raw metadata joins. No target evaluation.',predecessor_negative=pin(prior_path),predecessor_retirement=pin(retirement),inherited_static_review=dict(check_count=145,meaning='Prior145 checks established the V1 exact bytes/manual scope and identified two defects. Only unchanged conclusions are inherited; the three changed Sources and all current bindings are separately rechecked below. The prior zero-counter-absent and wrong-selector observations are superseded, not asserted on V2.',receipt=pin(prior_path)),checks=checks,check_count=len(checks),mismatch_count=0,findings=[],blocking_finding_count=0,resolved_findings=[dict(id='M1',resolution='L initializes exact builtin zero before initial callback. B retains strict key presence/exact-int/equality with independently reconstructed row total. Knownzero initialization does not claim any mirror loop execution.'),dict(id='M2',resolution='Compiler_foreign* operation selector restored to compiler; actual module role remains mirror_compiler and real Rootguard executes before planned sentinel. No fixture removed/relabelled.')],semantic_argument=[
'All auxiliary prototypes retain their one t at own center and four controls, then append every ORIGINAL referenced prototype m row in original order at literalOrigin+offset−auxCenter. Assigned0, channels, remote/signed coordinates and literal IDs remain exact; no original t, lifted controls or domain-derived truth is mirrored.',
'All-prototype anchors and exact allowed-origin closure force base/aux roles. Choice agreement identifies the same literal base prototype, so every appended m duplicates an already assigned base value in every complete old legal tiling. Removing mirror rows reverses the implication. Thus old/new complete extended placement-ID sets coincide on the accepted bounded encoding intersection; this is a manual conditional correspondence, not runtime or pruning proof.',
'Complete original model/reference is obtained before searches and never passed as a solution/proof to them. Plain, old-gadget, mirror and conventional populations are checked against the same independent finite truth/raw reference. Three fresh original acquisitions separately certify every raw DEAD witness for every original tile and full selected support, same-instance and observed-state bound, with identical literal advice lists required.',
'Only after the original acquisition root restores does each fresh compiled marked graph run; no runtime failure scanner in the marked lane. Every live GCTS snapshot is independently reconstructed and complete returned projections checked. Current main mode ALL; old FIRST code remains outside normal runtime qualification.',
'DPLL encodes the whole palette×origins with exactly-one, pin conflicts, all cross-center unequal raw m pairs and same separately certified conjunctions; its exhaustive Boolean DFS and raw point checks are a conventional control with different scheduler/branch/work units. No state-of-art benchmark, speed benefit or GCTS conformance is inferred for it.',
'The whole original162component/697base/4214raw product/15diagnostic bank is rerun prospectively for mirror semantics, followed by23original cases/18original plus13new diagnostics. All outputs/full returned populations mandatory; any incomplete/refusal/UNKNOWN prevents whole admission. No old680 prefix, historical result or retired grant is rescued.'
],limits=subject['limits'],cost_and_window_scope='Positive complete worker/header/output read and known exit before180 monotonic seconds from runner Source entry. Later whole raw Source/input/log/ledger/custody and external terminal must finish before210. Standalone worker Darwin peak <=1GiB, stored/expanded/physical <=128MiB with original9MiB metadata reserve, stdout/stderr/header<=4MiB. Per-call private work and Root400m callbacks remain distinct cooperative counters, not CPU or observer prelude.',supporting_metadata=support,limitations=limitations,stop_state='TOOLS STOPPED after handoff; fresh Root true/max1 grant, separate auth-only delta review and all-peer-idle barrier remain required before any actual.')
out=C/'typed-mirrored-comparison-Source-prospective-review-v2.json'
if out.exists():raise RuntimeError('immutable C review output exists')
out.write_bytes(json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
print(json.dumps(dict(receipt=pin(out),checks=len(checks),mismatch_count=0,review_passed=True),sort_keys=True))
