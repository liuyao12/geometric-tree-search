"""Future runner Source-only delta; never invokes validator on saved data."""
import ast
import hashlib
import json
from pathlib import Path
D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1');C=Path('/private/tmp/gcts-mirrored-receptor-peer-20261019-v1')
def pin(p):
    p=Path(p);r=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
checks=[]
def check(name,condition):checks.append(dict(name=name,passed=bool(condition)))
oldpath=D/'run_mirrored_receptor_once_v1.py';newpath=D/'run_mirrored_receptor_once_v2.py';delta=D/'future-outer-selector-delta-v1.json'
meta=load(delta);old=oldpath.read_text();new=newpath.read_text()
check('exact frozen future Source',pin(newpath)==meta['Source'] and pin(newpath)['sha256']=='af37af74b2d079a7ebe962bf16ecf074afd25e118a2aabc577446fa016ca5ae2')
check('exact actual parent Source preserved',pin(oldpath)==meta['parent'] and pin(oldpath)['sha256']=='d3f8d438c082c35cfd3a938f7598de01cb05f1f12211da1b6c40bf0ab481f5e8')
start=new.index('        callback_operations=');end=new.index("    for key in('mirror_compiler_calls'",start)
original="        if 'foreign'in r['operation']:need(r['exact_foreign_identity']is True and r['local_callbacks']==1,'component exact foreign callback object')\n"
restored=new[:start]+original+new[end:]
restored=restored.replace('"""UNEXECUTED future corrected outer diagnostic selector. NO grant or replay authority."""','"""One Root-owned complete mirror/DPLL comparison; inherited bounded cleanup."""').replace("VERSION='mirrored-receptor-comparison-once-runner-v2'","VERSION='mirrored-receptor-comparison-once-runner-v1'")
check('full inert reverse exact selector/version/docstring only',restored==old)
tree=ast.parse(new);compile(new,str(newpath),'exec',dont_inherit=True)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='validate_qualification')
values={}
for node in ast.walk(fn):
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('callback_operations','malformed_operations','mutation_operations'):
        values[node.targets[0].id]=ast.literal_eval(node.value)
check('three exact callback operations',values['callback_operations']==('compiler_foreign_base','compiler_foreign_limit','verifier_foreign_base'))
check('malformed literal foreign name properly belongs to declaration group',values['malformed_operations']==('duplicate_required','extra_origin','duplicate_tile_id','boolean_mark_zero','odd_origin','foreign_literal_id','rotation_field'))
check('three actual mutation operations',values['mutation_operations']==('remove_anchor','flip_prefix_output','remove_original_zero'))
allops=sum(values.values(),())+('compiler_owned_work','verifier_owned_work')
check('disjoint exhaustive15declared operation vocabulary',len(allops)==len(set(allops))==15 and set(allops)=={r['operation'] for r in load(D/'declaration-v2.json')['component_diagnostics']})
check('exact declaration role selector and expected_kind preserved',"operation=d['operation']" in new and "need(r['expected_kind']==expected,'explicit original component diagnostic classification')" in new)
check('foreign exact identitycount gate not weakened',"if operation in callback_operations:\n            need(r['exact_foreign_identity']is True and r['local_callbacks']==1,'component exact foreign callback object')" in new)
check('noncallbacks explicit absence/count gate',"need(r['exact_foreign_identity']is None and r['local_callbacks']==0,'non-callback component diagnostic has no foreign invocation')" in new)
current=load(D/'plan-authorized-v2.json')
check('current consumed plan still binds rejected parent',current['sources']['runner']==pin(oldpath) and current['sources']['runner']!=pin(newpath))
check('delta explicitly no retroactive authority',meta['actual_execution_authorized'] is False and meta['current_actual_gate_unchanged'] is True and meta['current_actual_original_gate_still_rejected'] is True and meta['subject_calls']==0)
failures=[r for r in checks if not r['passed']]
if failures:print(json.dumps(failures));raise RuntimeError('future Source delta mismatch')
out=C/'typed-future-outer-selector-Source-review-v1.json'
receipt=dict(schema='mirrored-receptor-future-outer-Source-delta-review-v1',reviewer_identity='/root/conventional_control_review',source_review_passed=True,source_only=True,component_calls=0,scientific_calls=0,subject_imports=0,validator_calls=0,actual_execution_authorized=False,scientific_acceptance=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,future_Source=pin(newpath),parent_actual_Source=pin(oldpath),author_delta=pin(delta),checks=checks,check_count=len(checks),mismatch_count=0,findings=[],current_saved_negative_review=pin(C/'typed-saved-actual-negative-review-v2.json'),scope='Full inert inverse and ordinary AST/read-only operation-vocabulary check only; no current packet/result was passed into this or any replacement validator.',limitations=['The exact current actual remains outer-gate rejected and grant retired. This Source-only PASS does not retroactively validate current data or inherit overall helper qualification. C missed the original substring defect and retains that review limitation.','The explicit operation vocabulary and expected-kind conditions resolve the identified lexical collision in Source. Other inherited worker/resource/raw/custody/cleanup gates are byte-identical through full inert inverse, not a new execution guarantee.','Any future use requires a complete fresh Source/prospective subject including this Source and bound observer, new independent review/Root maxone grant/authdelta/fresh-path idle barrier and measured complete bank. No new actual or current smaller rescue is authorized.','No validator/component/fixture/truth/helper/search/checker/solver/module was imported or executed; discarded compile only. No process probe or publisher change.'],stop_state='TOOLS STOPPED after this handoff.')
if out.exists():raise RuntimeError('immutable future review exists')
out.write_bytes(json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
print(json.dumps(dict(receipt=pin(out),check_count=len(checks),source_review_passed=True,mismatch_count=0),sort_keys=True))
