"""Source/raw/AST only; never import or call the offered DPLL control."""
from pathlib import Path
import ast,hashlib,json,sys
C=Path('/private/tmp/gcts-mirrored-receptor-peer-20261019-v1')
D=Path('/private/tmp/gcts-mirrored-receptor-ROOT-20261019-v1')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,v):
 p=C/name
 with p.open('x')as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
 return pin(p)
old=D/'finite_point_dpll_control_DRAFT_v1.py';new=D/'finite_point_dpll_control_v1.py'
a=old.read_text();b=new.read_text();checks=[]
def check(name,value):
 checks.append(dict(id=name,passed=bool(value)))
 if not value:raise AssertionError(name)
check('preserved offered draft exactraw',pin(old)['sha256']=='d4de135dd3af35c82c2bd7346e3d83f65b18806fded836635e0610f9bae1ebf6'and pin(old)['bytes']==11787)
check('corrected exact offered Source',pin(new)['sha256']=='165157396c6ad3d05436cac9050dd3f7f87c770041abe2b0a6300f7b18fb56c5'and pin(new)['bytes']==12038)
tree=ast.parse(b);unused=compile(tree,str(new),'exec');del unused
check('no target imports',not any(isinstance(n,(ast.Import,ast.ImportFrom))for n in ast.walk(tree)))
check('nongenerator callback control',not any(isinstance(n,(ast.Yield,ast.YieldFrom))for n in ast.walk(tree)))
reverse=b.replace("need(type(base['required_centers'])is list and type(base['admissible_origins'])is list,'literal required/allowed origin arrays')\n        centers=[w.point(p,True)for p in base['required_centers']];w.cap('centers',len(centers))\n        admitted=[w.point(p,True)for p in base['admissible_origins']];w.cap('centers',len(admitted))\n        need(centers==admitted,'same strictly parsed ordered required/allowed centers')", "need(type(base['required_centers'])is list and type(base['admissible_origins'])is list and base['required_centers']==base['admissible_origins'],'same ordered required/allowed centers')\n        centers=[w.point(p,True)for p in base['required_centers']];w.cap('centers',len(centers))")
reverse=reverse.replace("'SUPPLIED_LITERAL_FORBIDDEN_CONJUNCTION'","'SUPPLIED_CHECKED_FORBIDDEN_CONJUNCTION'")
reverse=reverse.replace("w.tick();selected=[]\n                    for i in range(pi*nt,(pi+1)*nt):\n                        w.tick()\n                        if assigned[i+1]:selected.append(variables[i])\n                    need(len(selected)==1,'unique point choice');placement.append({'origin':list(p),'tile_id':selected[0]['tile_id']})", "w.tick();selected=[variables[i]for i in range(pi*nt,(pi+1)*nt)if assigned[i+1]];need(len(selected)==1,'unique point choice');placement.append({'origin':list(p),'tile_id':selected[0]['tile_id']})")
check('whole inverse exact only three corrections',reverse==a)
for name,needle in{
 'required and admitted separately exact typed':'admitted=[w.point(p,True)for p in base[\'admissible_origins\']]',
 'every palette prototype at every origin':'for pi,p in enumerate(centers):\n            for ti,(tid,m)in enumerate(tiles):',
 'one ALO each point':"emit(group,{'kind':'AT_LEAST_ONE','point':pi})",
 'all unordered samepoint AMO pairs':"emit([-group[i],-group[j]],{'kind':'AT_MOST_ONE','point':pi})",
 'real pin raw unequal value':"if key in pins and pins[key]!=value:",
 'all crosscenter prototype pairs':"for j in range(i+1,len(sections)):",
 'actual remote point channel mismatch':"if key in sections[j]and sections[j][key]!=value:",
 'literal supplied conjunction no proofclaim':"'SUPPLIED_LITERAL_FORBIDDEN_CONJUNCTION'",
 'all support negated placements':'row.append(-lookup[(p,tid)])',
 'global unsatisfied empty clause conflict':"if not open_values:return 'CONFLICT',ci",
 'exact dedup for unit inference':'elif literal not in seen:seen.add(literal);open_values.append(literal)',
 'full clause unit before binary branch':"if unit is not None:",
 'literal full assignment positive gate':"need(len(assigned)==len(variables)",
 'per examined variable extraction charge':"for i in range(pi*nt,(pi+1)*nt):\n                        w.tick()",
 'branch both values complete':"frames[-1][2]=2;statistics['branch_attempts']+=1;assign(var,False,'branch')",
 'exact local reversible assigned trail':'while len(trail)>checkpoint:w.tick();del assigned[trail.pop()]',
 'limit only own class/token no exhaustion':'if not is_own_limit(error):raise',
 'quota unknown not proof':'\'status\':\'UNKNOWN\',\'exhausted\':False',
 'critical owned cleanup does not callback':'assigned.clear();trail.clear();frames.clear()',
}.items():check(name,needle in b)
negative=dict(schema='finite-point-conventional-DPLL-interim-Source-review-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',source_review_passed=False,review_passed=False,source_only=True,component_calls=0,scientific_calls=0,subject_imports=0,fixture_calls=0,actual_execution_authorized=False,
 source=pin(old),offered_path_at_initial_read=str(new),status='PRESERVED_UNEXECUTED_DRAFT_NEGATIVE',
 findings=[
  dict(id='D1',severity='BLOCKER',finding='Only required_centers were strictly parsed; admissible_origins were bound by Python list equality. A BooleanFalse in the admitted coordinate can compare equal to required integer0 without exact point validation. This contradicts the literal integer-origin domain. No target example was run.',correction='Strictly parse EVERY admitted origin and compare the resulting ordered exact-int tuples; corrected successor does this.'),
  dict(id='D2',severity='ACCOUNTING_GAP',finding='Positive extraction scanned candidate variables through a list comprehension without a per-inspected-variable tick; only one tick per center was present. This was independently caught by B/Root and confirmed in raw Source.',correction='Explicit extraction loop charges each inspected variable; no cap rise or data omission.'),
  dict(id='D3',severity='SCOPE_LABEL',finding='SUPPLIED_CHECKED_FORBIDDEN_CONJUNCTION suggested this control authenticated supplied advice. It only negates literal conjunctions; separate Root/B proof provenance is mandatory.',correction='Renamed SUPPLIED_LITERAL_FORBIDDEN_CONJUNCTION in the successor.'),
 ],limitations=['Source/manual reasoning only, not a failed runtime or a consumed actual. Old offered content preserved exactly; the original non-DRAFT pathname was replaced before any Source/prospective grant, and this receipt binds the preserved raw draft.', 'No claim of independent hostile-input reconciliation: caller read-only/exclusive ownership and Root real-argument guards remain necessary.'],tools_stopped_after_handoff=True)
np=save('typed-DPLL-draft-Source-negative-v1.json',negative)
review=dict(schema='finite-point-conventional-DPLL-interim-Source-review-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',source_review_passed=True,review_passed=True,component_only=True,source_only=True,
 component_calls=0,scientific_calls=0,subject_imports=0,fixture_calls=0,simulations=0,process_probes=0,actual_execution_authorized=False,prospective_review_passed=False,runtime_qualified=False,
 source=pin(new),preserved_negative=np,whole_inverse_exact=True,unused_compile_count=1,typed_checks=checks,check_count=len(checks),mismatch_count=0,
 conditional_argument=[
  'For the declared unit-center translation-only problem each complete placement solution selects exactly one literal prototype at each required origin. One Boolean variable is retained for EVERY original origin/prototype, independent of current domain legality. ALO and all pairwise AMO clauses exactly enforce that choice.',
  'A negative unit removes precisely a placement with an actual assigned marking conflicting with a permanent pin. Each unordered cross-center placement pair contributes a negative binary clause if some actual common point/channel values differ. Missing values never conflict, assigned0 remains assigned, and remote offsets are translated exactly. Same-center pair conflicts need no extra marking clause because AMO already prohibits co-selection. One mismatch clause per incompatible pair is sufficient even if several m-points differ.',
  'Each supplied literal support conjunction is negated into one clause, including repetitions, incompatible same-center reads and an empty conjunction. Repetition stays in archived CNF and is collapsed only for unit inference. This is a problem-defining input unless the new Root worker binds the same exact original-instance B proof; the control itself establishes no redundancy.',
  'Propagation scans all unsatisfied clauses, reports any empty clause before committing an accumulated unit, repeats after each unit, then branches on an unassigned variable from a shortest unsatisfied clause. True and false children are both enumerated via a saved cursor. Trail undo deletes every assignment after checkpoint; root undo leaves no assigned/trail/frame state before success. Critical finally cleanup is callback-free and touches only private builtins.',
  'When every clause is satisfied, each ALO has a selected true variable. Any other still-unassigned variable at that center would make an AMO clause a unit, so fixed-point propagation has assigned every variable. Thus the full-assignment extraction gate is coherent; complete assignments map one-to-one to exact literal placement populations under the supplied clauses. This is a manual Source argument, not an executed CNF or proof-kernel check.',
 ],
 required_coupling=[
  'The helper has no local second-read reconciliation. The new whole worker must guard the real instance/forbidden/limits objects before and after success/refusal with exact typed canonical values, Source/callable checks and exclusive/read-only callbacks. Root says its draft Session.call does this; full current worker/outer/subject not yet reviewed here.',
  'Root must gate its first real policy/deadline fault before interpreting control UNKNOWN/expected refusals. OwnLimit classifier is exact class plus private module token, not a per-invocation token. No same-class historical-owned-object callback coverage is inherited.',
  'Off/on controls receive the same full original model and exact fresh independently certified clause list as the mirror lane; off uses no advice. All CNF construction, checks, full enumeration/raw-point verification, failed attempts, output and new independent per-call units stay within the common real180/210/1GiB/128MiB protocol and explicit cumulative Root ceiling. Full current limits and profile need prospective review.',
  'This is a homegrown conventional shortest-clause binary DPLL control, not the GCTS generation scheduler, a point-domain graph or a state-of-art external prover. Boolean branch counters and point-prototype branches are different units; no branch-count speed claim. It is not a new engine conformance certificate or mathematical proof system.',
  'Source dimensions bound original and translated coordinates by integer_abs, a stricter intersection than some old L derived-offset allowance; declare the common actual domain honestly. Literal point/callback/strict-data/own-limit/rollback diagnostics plus full original solution population equality are still runtime obligations, not fulfilled by this Source pass.',
 ],
 limitations=['No target import, helper/fixture/callback/solver evaluation, compiled object execution or actual was performed. The sole compile object was discarded.', 'C independently reviews current Root control but authored earlier control/protocol ancestors; this is not formal independent kernel certification. L mirror compiler/B verifier and whole new worker/prospective cohort are not certified by this component-only receipt.', 'Previous185case/46diagnostic proposal and all historic failed/qualified actuals retain their own scope. No execution grant, reused consumed subject, case trimming or cap choice follows.'],
 interpreter=dict(executable=sys.executable,version=sys.version,flags='-I -S -B'),tools_stopped_after_handoff=True)
rp=save('typed-DPLL-component-Source-review-v1.json',review)
print(json.dumps(dict(negative=np,corrected_Source_review=rp,checks=len(checks),mismatch_count=0),sort_keys=True))
