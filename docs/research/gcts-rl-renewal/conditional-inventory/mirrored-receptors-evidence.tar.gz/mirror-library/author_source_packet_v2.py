"""Raw/AST/ordinary metadata repair only; no subject import or evaluation."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
D=Path('/private/tmp/gcts-mirrored-receptor-library-20261019-v1')
P=D/'unit_center_mirrored_marking_compiler_v1.py'
S=D/'unit_center_mirrored_marking_compiler_v2.py'
def pin(path):
 path=Path(path).resolve();raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def save(name,value):
 path=D/name
 with path.open('xb')as out:out.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False).encode()+b'\n')
 return pin(path)
old=P.read_text();assert pin(P)['sha256']=='9bfb4c09e17477a749cb959061fa08b942c9afdf30d03e955289b4e06956060e'
a="        self.counts = {'work': 0}\n";b="        self.counts = {'work': 0, 'mirrored_original_mark_rows': 0}\n"
assert old.count(a)==1
new=old.replace("VERSION = 'unit-center-mirrored-marking-compiler-v1'","VERSION = 'unit-center-mirrored-marking-compiler-v2'").replace(a,b)
with S.open('x')as out:out.write(new)
t=ast.parse(new,filename=str(S));compile(t,str(S),'exec')
reverse=new.replace("VERSION = 'unit-center-mirrored-marking-compiler-v2'","VERSION = 'unit-center-mirrored-marking-compiler-v1'").replace(b,a)
assert reverse==old
before=ast.parse(old);aa={n.name:ast.dump(n,include_attributes=False)for n in before.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};bb={n.name:ast.dump(n,include_attributes=False)for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert set(aa)==set(bb);retained=[n for n in aa if n!='_Budget'];assert all(aa[n]==bb[n]for n in retained)
old_budget=next(n for n in before.body if isinstance(n,ast.ClassDef)and n.name=='_Budget');new_budget=next(n for n in t.body if isinstance(n,ast.ClassDef)and n.name=='_Budget')
old_methods={n.name:ast.dump(n,include_attributes=False)for n in old_budget.body if isinstance(n,ast.FunctionDef)};new_methods={n.name:ast.dump(n,include_attributes=False)for n in new_budget.body if isinstance(n,ast.FunctionDef)}
assert all(old_methods[n]==new_methods[n]for n in old_methods if n!='__init__')
assert not any(isinstance(n,(ast.Import,ast.ImportFrom,ast.Yield,ast.YieldFrom))for n in ast.walk(t))
for name,left,right in [('mirrored-v1-to-v2.patch',old,new),('mirrored-v2-to-v1.patch',new,old)]:
 with(D/name).open('x')as out:out.write(''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='compiler.py',tofile='compiler.py')))
common=dict(author_identity='/root/conventional_library',source_only=True,subject_imports=0,component_calls=0,fixture_calls=0,scientific_acceptance=False,actual_execution_authorized=False)
api=save('API-v2.json',dict(schema='mirrored-unit-center-receptor-API-v2',**common,Source=pin(S),parent_API=pin(D/'API-v1.json'),
 version='unit-center-mirrored-marking-compiler-v2',compilation_schema='unit-center-mirrored-marking-compilation-v1',receptor_profile='MIRRORED_ORIGINAL_MARKS_V1',
 entries=['compile_marking_gadget(base,clauses,*,check,limits)','extend(compilation,base_certificate,*,check,limits)','project(compilation,extended_certificate,*,check,limits)'],
 delta="Only _Budget.__init__ initializes counts['mirrored_original_mark_rows']=0 before the initial check; every existing per-row step increments that actual zero normally. Known zero at initialization does not claim a row loop ran. VERSION v2; old result13fields/schema/layout/mapping/limits/status/public signatures unchanged.",
 inherited=pin(D/'API-v1.json'),notes='All successful zero-clause/zero-original-m compilations now expose exact-int zero; nonzero row increments unchanged. Full codec rebuild expects current v2 compilation version. No hidden normalization, test, actual or quota change. V1 preserved unexecuted negative ancestor.'))
contract=save('Source-contract-v2.json',dict(schema='mirrored-unit-center-receptor-Source-contract-v2',**common,Source=pin(S),API=api,
 parent_Source=pin(P),parent_contract=pin(D/'Source-contract-v1.json'),argument=pin(D/'extension-projection-argument-v1.json'),
 change='VERSION plus one initialized operational counter. Mathematical _build, full original/mirror rows, extension/projection, input reconciliation, private error handling and every cap unchanged.',
 historical='V1 Source/API/handoff retained byte-for-byte. Pre-execution independent coupling finding: missing mirror counter on actual-zero path. No previous actual/grant consumed; this is not a retry or cap increase.',
 qualification='All23 original inputs/18 controls and new diagnostics still require independent fresh review and bounded Root grant; no own functions/imports/fixtures evaluated here.'))
audit=save('author-static-audit-v2.json',dict(schema='mirrored-unit-center-receptor-author-static-audit-v2',**common,Source=pin(S),
 unused_compiles=1,raw_inverse_exact=True,AST_retained_definitions=retained,AST_retained_count=len(retained),
 only_changed_definition='_Budget.__init__',other_Budget_methods_AST_exact=True,
 patches=[pin(D/'mirrored-v1-to-v2.patch'),pin(D/'mirrored-v2-to-v1.patch')],
 scope='Raw/AST/unused compile only, no executed zero/nonzero fixture or mathematical/runtime qualification.'))
h=save('handoff-v2.json',dict(schema='mirrored-unit-center-receptor-handoff-v2',**common,Source=pin(S),API=api,Source_contract=contract,
 author_static_audit=audit,author_Source=pin(__file__),parent_handoff=pin(D/'handoff-v1.json'),
 argument=pin(D/'extension-projection-argument-v1.json'),status='FROZEN_SOURCE_ONLY_UNEXECUTED_NO_GRANT',tools_stopped_after_handoff=True))
print(json.dumps(dict(Source=pin(S),API=api,handoff=h,retained_definitions=len(retained)),sort_keys=True))
