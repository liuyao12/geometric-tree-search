"""Raw/AST/ordinary metadata only. Never imports or evaluates a subject."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
D=Path('/private/tmp/gcts-mirrored-receptor-library-20261019-v1')
P=Path('/private/tmp/gcts-unit-center-receptor-library-20261019/unit_center_marking_compiler_v1.py')
S=D/'unit_center_mirrored_marking_compiler_v1.py'

def pin(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    path=D/name
    with path.open('xb')as stream:stream.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    return pin(path)

old=P.read_text()
assert pin(P)['sha256']=='9a07bd4afbfd7b4c95edd8d9e2a3ea489a025a53e1b18014ca5b429d09291eb9'and pin(P)['bytes']==20653
mirror="""                # Mirror only the ORIGINAL prototype m at its referenced base origin.
                # Fresh role/choice/state channels are disjoint; no positive t copied.
                for offset, channel, value in original['m']:
                    w.step('mirrored_original_mark_rows')
                    translated = [literal['origin'][0] + offset[0] - r[0],
                                  literal['origin'][1] + offset[1] - r[1]]
                    marks.append([translated, channel, value])
"""
anchor="                aux_map.append([emit(marks), role['role'], v, a, b])\n"
assert old.count(anchor)==1
new=old.replace('UNEXECUTED finite unit-center forbidden-conjunction marking compiler.',
                'UNEXECUTED finite unit-center mirrored-original-mark receptor compiler.')
new=new.replace("VERSION = 'unit-center-nogood-marking-compiler-v1'", "VERSION = 'unit-center-mirrored-marking-compiler-v1'\nRECEPTOR_PROFILE = 'MIRRORED_ORIGINAL_MARKS_V1'")
new=new.replace("COMPILATION_SCHEMA = 'unit-center-nogood-marking-compilation-v1'", "COMPILATION_SCHEMA = 'unit-center-mirrored-marking-compilation-v1'")
new=new.replace(anchor,mirror+anchor)
with S.open('x')as stream:stream.write(new)
parent_tree=ast.parse(old,filename=str(P));tree=ast.parse(new,filename=str(S));compile(tree,str(S),'exec')
assert not any(isinstance(n,(ast.Import,ast.ImportFrom,ast.Yield,ast.YieldFrom,ast.AsyncFunctionDef,ast.Await))for n in ast.walk(tree))
a={n.name:ast.dump(n,include_attributes=False)for n in parent_tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
b={n.name:ast.dump(n,include_attributes=False)for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert set(a)==set(b)
retained=[name for name in a if name!='_build']
assert all(a[name]==b[name]for name in retained)
reverse=new.replace(mirror,'').replace('UNEXECUTED finite unit-center mirrored-original-mark receptor compiler.',
    'UNEXECUTED finite unit-center forbidden-conjunction marking compiler.')
reverse=reverse.replace("VERSION = 'unit-center-mirrored-marking-compiler-v1'\nRECEPTOR_PROFILE = 'MIRRORED_ORIGINAL_MARKS_V1'", "VERSION = 'unit-center-nogood-marking-compiler-v1'")
reverse=reverse.replace("COMPILATION_SCHEMA = 'unit-center-mirrored-marking-compilation-v1'", "COMPILATION_SCHEMA = 'unit-center-nogood-marking-compilation-v1'")
assert reverse==old
for name,left,right in [('old-to-mirrored.patch',old,new),('mirrored-to-old.patch',new,old)]:
    with(D/name).open('x')as stream:stream.write(''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='compiler.py',tofile='compiler.py')))
for name,value in [('inert-forward',old),('inert-reverse',new)]:
    directory=D/name;directory.mkdir()
    (directory/'compiler.py').write_text(value)
common=dict(author_identity='/root/conventional_library',source_only=True,subject_imports=0,component_calls=0,
    fixture_calls=0,actual_execution_authorized=False,scientific_acceptance=False)
literals={n.targets[0].id:ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
api=save('API-v1.json',dict(schema='mirrored-unit-center-receptor-API-v1',**common,Source=pin(S),parent=pin(P),
    version=literals['VERSION'],compilation_schema=literals['COMPILATION_SCHEMA'],receptor_profile=literals['RECEPTOR_PROFILE'],
    entries=['compile_marking_gadget(base,clauses,*,check,limits)','extend(compilation,base_certificate,*,check,limits)',
             'project(compilation,extended_certificate,*,check,limits)'],
    unchanged_contract=pin('/private/tmp/gcts-unit-center-receptor-library-20261019/API-v1.json'),
    unchanged='Same exact7-field point instance,13-field compilation result,statuses,mapping/layout,all literal IDs,prototype/order counts,full palette-times-origins,authorityfalse/problem-defining flags,old10-key limits,exception classes/callback identity/full caller reconciliation. New schema/version deliberately reject old compilation packets in new codecs.',
    result_keys=literals['RESULT_KEYS'],limits=literals['LIMIT_KEYS'],
    mirror='After each auxiliary prototype\'s original4 fresh anchor/choice/state rows, append every ORIGINAL referenced base prototype m row in original order. For role center r, literal center p, original row (offset d,channel h,value u), appended row offset=p+d-r, channel h, value u. Never copy t, lifted choice/anchor additions or another auxiliary variant. No sorting/dedup/filter.',
    math=r'\(m_{A_{i,v,a}}(p_i+d,h)=m_v(d,h)\). The added offsets are \(p_i+d-r_i\); the sole positive support remains \(t(0)=1\).',
    limits_and_errors='Final mirrored offsets/values are revalidated by unchanged emit->_marks->_xy/integer_abs, duplicate point/channel handling, Unicode/type/size and total marks/candidates/work caps. A previously fitting old compilation may reach honest new UNKNOWN without any cap increase. All exact callback exceptions remain foreign unless own exact-class/per-call-token GadgetLimit. Added counter mirrored_original_mark_rows counts each attempted row per aux variant; old work counts are not expected equal.',
    codecs='Raw bodies unchanged. Both rebuild complete NEW mirrored instance/mapping/construction_counts and compare full typed preimages; extend and project verify full literal point legality and exact input second read before candidate return.',
    scope='No runtime classifier, live nogood scan, search/engine/Native/Model changes, cap/grant reuse, fixed FOL/RL or performance claim. No test or invocation performed.'))
argument=save('extension-projection-argument-v1.json',dict(schema='mirrored-receptor-extension-projection-argument-v1',**common,Source=pin(S),
    premise='Same legal base and forbidden ordered conjunctions as old compiler. Old role anchors/choice/state construction is retained exactly. Clauses are problem-defining unless independently certified redundant for that exact base; mirror compilation does not supply this authority.',
    forward='Take any complete old-gadget literal-ID tiling. Base role pins force lifted originals at original centers; every auxiliary role reads v through fresh choice equality at p. The original lifted base tile with that literal ID already assigns every original m_v row at p+d. Therefore appended mirrored rows duplicate assignments already present and cannot create a conflict, including assigned0/remote/multiple/repeated channels. Same placement-ID word is valid in the mirrored instance.',
    reverse='Delete only appended mirror rows from any complete new-gadget tiling. All old t/m/pins/choice/state/anchors remain, so the SAME literal-ID placement word is an old-gadget tiling. Removing auxiliaries/fresh channels then yields the original base tiling as before.',
    correspondence='Thus complete extended placement-ID solution sets of old and mirrored gadgets are identical whenever both finish construction, not merely their base projections. Old unique extension and projection codecs remain valid with full new rebuild/raw legality. Partial domains and propagation may differ; this is the proposed effect, not a measured speed result.',
    repeated='Repeated literal/center reads still name the same actual base ID; contradictory conjunctions and multiple clauses need no simplification. Empty clauses still get unmatched-anchor centers and no prototype, so no extension. Literal IDs with equal original m remain distinct.',
    duplicate='Original m is a finite function with unique point/channel keys. Translation preserves uniqueness. Fresh channels were chosen disjoint from EVERY original prototype/pin channel, so original mirror rows cannot collide with the four fresh aux rows. Existing duplicate rejection still checks the emitted result; no silent overwrite/merge.',
    coordinates='Signed integer arithmetic exact. integer_abs cap applies to NEW FINAL offsets through unchanged parser. Intermediate sums are ordinary exact integers; there is no clipping/wrapping/tolerance. Missing m remains missing; explicit0 copied.',
    obligations='This is a manual Source argument by compiler author, not a formal kernel/independent certificate. Root/B must independently rederive all mirrored rows and full extension/projection, plus all original23 inputs/18 diagnostics and new mirror faults under a new bounded grant. No run authorized here.'))
contract=save('Source-contract-v1.json',dict(schema='mirrored-unit-center-receptor-Source-contract-v1',**common,Source=pin(S),parent=pin(P),API=api,
    argument=argument,parent_contract=pin('/private/tmp/gcts-unit-center-receptor-library-20261019/Source-contract-v1.json'),
    delta='Only module docstring/VERSION/compilation schema/new descriptive profile constant plus one appended mirror loop in _build. Every other function/class exact raw+AST. All old files/banks/results/retired grants untouched.',
    work='One charged mirrored_original_mark_rows unit before every appended original m row; unchanged emit validation charges/caps all extra rows. Counts/mark rows/output size can increase. No numeric cap/deadline/callback policy changed, no quota reset.',
    custody='Original t/m/pins/IDs and all roles/full prototype universe retained; mirror source is original base tile, not lifted tile or chosen search state. No semantic quotient. Full typed input snapshots/reconciliation/cycle/depth/Unicode and private-owner errors inherited unchanged.',
    profile='Separate Source/schema/profile, not success under old runtime/work count or blanket negative-path equivalence. Foreign direct callback identity and old public completion paths retained.',
    master='Current isolated publisher HEAD docs/basic-tiling-algorithm.md read; master raw ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4 /36240 (unchanged normative point/graph/rollback/learning distinction).',
    ancestry='Library authored parent compiler and point search; this is author static evidence, no independent own Source certification. Root+B/C own separate review/qualification; independent verifier not modified here.',
    future='Full same-instance/same-certified-clause old-vs-mirror comparison with all original23/18 and new diagnostics, full solution-ID projection and point checks, total conversion/census/output cost under unchanged Root180/210/1GiB/128MiB. No performance promise or old680 rescue.'))
audit=save('author-static-audit-v1.json',dict(schema='mirrored-unit-center-receptor-author-static-audit-v1',**common,Source=pin(S),
    AST_retained_definitions=retained,AST_retained_count=len(retained),only_changed_definition='_build',
    raw_inverse_exact=True,unused_compiles=1,
    patch_descriptors=[pin(D/'old-to-mirrored.patch'),pin(D/'mirrored-to-old.patch')],
    checks=['Parent raw9a07/20653 checked.','No import/yield/async subject path introduced.',
        'Mirror only original m rows, exact offset formula, old4-row prefix/order retained.',
        'No t/palette/origin/ID/anchor/state/empty/repeated-clause construction changed.',
        'Old full codec rebuild/point validation/input reconciliation/error-owner bodies unchanged.',
        'New rows pass old total marks/integer/duplicate/work caps.',
        'Manual identity extension/projection argument recorded; no mathematical test or code invoked.'],
    limitations='Static Source/AST and unused compile only. Inert patch rehearsal and genuine independent Source review separate; no executed subject/fixture/qualification result.'))
h=save('handoff-v1.json',dict(schema='mirrored-unit-center-receptor-handoff-v1',**common,Source=pin(S),API=api,
    argument=argument,Source_contract=contract,author_static_audit=audit,author_Source=pin(__file__),
    parent=pin(P),status='FROZEN_SOURCE_ONLY_UNEXECUTED_NO_GRANT',tools_stopped_after_handoff=True))
print(json.dumps(dict(Source=pin(S),API=api,argument=argument,handoff=h,retained_definitions=len(retained)),sort_keys=True))
