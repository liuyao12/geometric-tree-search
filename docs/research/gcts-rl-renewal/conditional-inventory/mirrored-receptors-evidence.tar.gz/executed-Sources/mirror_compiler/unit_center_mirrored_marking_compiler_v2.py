"""UNEXECUTED finite unit-center mirrored-original-mark receptor compiler.

Pure ordinary-data transforms; no imports, search, pair classifier or solver.
Clauses define the enlarged problem. Redundancy is NEVER certified here.
"""
VERSION = 'unit-center-mirrored-marking-compiler-v2'
RECEPTOR_PROFILE = 'MIRRORED_ORIGINAL_MARKS_V1'
INSTANCE_SCHEMA = 'finite-unit-center-point-instance-v1'
COMPILATION_SCHEMA = 'unit-center-mirrored-marking-compilation-v1'
CERTIFICATE_SCHEMA = 'finite-unit-center-placement-certificate-v1'
LIMIT_KEYS = ('work', 'centers', 'tiles', 'marks', 'clauses', 'literals',
              'candidates', 'integer_abs', 'string_chars', 'data_depth')
BASE_KEYS = ('schema', 'transformations', 'required_centers', 'admissible_origins',
             'tiles', 'fixed_background_marks', 'all_root_generations')
RESULT_KEYS = ('schema', 'version', 'status', 'base', 'clauses', 'instance', 'mapping',
               'construction_counts', 'counts', 'problem_defining',
               'redundancy_established', 'mathematical_authority', 'executed_source_qualified')


class DeclarationError(Exception):
    pass


class NoExtension(DeclarationError):
    pass


class GadgetLimit(Exception):
    def __init__(self, reason, *, owner=None):
        self.reason, self._owner = reason, owner
        super().__init__(reason)


class _Budget:
    def __init__(self, check, limits):
        if (not callable(check) or type(limits) is not dict or len(limits) != len(LIMIT_KEYS)
                or any(type(k) is not str for k in limits) or set(limits) != set(LIMIT_KEYS)):
            raise DeclarationError('exact finite limits and callback required')
        for key in LIMIT_KEYS:
            if type(limits[key]) is not int or limits[key] < 1:
                raise DeclarationError('positive exact-int limits required')
        if limits['data_depth'] > 128:
            raise DeclarationError('recursive ordinary-data depth at most128')
        self.check, self.limits = check, dict(limits)
        self.owner = object()
        self.counts = {'work': 0, 'mirrored_original_mark_rows': 0}
        check()

    def step(self, kind):
        self.counts['work'] += 1
        self.counts[kind] = self.counts.get(kind, 0) + 1
        if self.counts['work'] > self.limits['work']:
            raise GadgetLimit('work', owner=self.owner)
        self.check()

    def cap(self, name, value):
        self.step('capacity_checks')
        if value > self.limits[name]:
            raise GadgetLimit(name, owner=self.owner)

    def integer(self, value, nonnegative=False):
        self.step('integer_atoms')
        if type(value) is not int or (nonnegative and value < 0):
            raise DeclarationError('exact integer atom required')
        self.cap('integer_abs', abs(value))
        return value

    def string(self, value):
        if type(value) is not str:
            raise DeclarationError('literal string required')
        self.cap('string_chars', len(value))
        for c in value:
            self.step('string_characters')
            if 0xD800 <= ord(c) <= 0xDFFF:
                raise DeclarationError('Unicode scalar strings required')
        return value


def _obj(value, keys):
    if (type(value) is not dict or len(value) != len(keys)
            or any(type(k) is not str for k in value) or set(value) != set(keys)):
        raise DeclarationError('exact object fields required')


def _arr(value, size=None):
    if type(value) is not list or (size is not None and len(value) != size):
        raise DeclarationError('ordinary array required')
    return value


def _copy(value, w, depth=0, active=None):
    w.step('ordinary_copy_nodes')
    w.cap('data_depth', depth)
    t = type(value)
    if value is None or t in (bool, int):
        return value
    if t is str:
        return w.string(value)
    if t not in (list, dict):
        raise DeclarationError('strict finite JSON subset; no floats/subclasses/tuples')
    if active is None:
        active = set()
    identity = id(value)
    if identity in active:
        raise DeclarationError('cyclic caller data')
    active.add(identity)
    try:
        if t is list:
            return [_copy(x, w, depth + 1, active) for x in value]
        result = {}
        for key, item in value.items():
            result[w.string(key)] = _copy(item, w, depth + 1, active)
        return result
    finally:
        active.remove(identity)


def _same(left, right, w):
    w.step('full_value_comparisons')
    if type(left) is not type(right):
        return False
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if not _same(a, b, w):
                return False
        return True
    if type(left) is dict:
        if len(left) != len(right) or set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key], right[key], w):
                return False
        return True
    if type(left) is str:
        w.string(left); w.string(right)
    return left == right


def _xy(value, w, even=False):
    result = [w.integer(x) for x in _arr(value, 2)]
    if even and any(x % 2 for x in result):
        raise DeclarationError('origins must belong to2Z2')
    return result


def _marks(value, w):
    result, seen = [], set()
    for row in _arr(value):
        w.step('original_mark_rows')
        _arr(row, 3)
        xy, channel, code = _xy(row[0], w), w.string(row[1]), w.integer(row[2], True)
        key = (tuple(xy), channel)
        if key in seen:
            raise DeclarationError('duplicate assignment point/channel')
        seen.add(key)
        result.append([xy, channel, code])
        w.cap('marks', len(result))
    return result


def _base(value, w):
    _obj(value, BASE_KEYS)
    if (value['schema'] != INSTANCE_SCHEMA or value['transformations'] != 'translations_only_2Z2'
            or type(value['all_root_generations']) is not int or value['all_root_generations'] != 0):
        raise DeclarationError('finite exact unit-center translation-only scope required')
    centers, seen = [], set()
    for raw in _arr(value['required_centers']):
        w.step('base_required_centers')
        xy = _xy(raw, w, True)
        if tuple(xy) in seen:
            raise DeclarationError('duplicate required center')
        seen.add(tuple(xy)); centers.append(xy)
        w.cap('centers', len(centers))
    if not centers or not _same(value['admissible_origins'], centers, w):
        raise DeclarationError('nonempty required=allowed exact ordered origins required')
    tiles, ids, total_marks = [], set(), 0
    for raw in _arr(value['tiles']):
        w.step('base_tile_rows')
        _obj(raw, ('id', 't', 'm'))
        tile_id = w.integer(raw['id'], True)
        if tile_id in ids:
            raise DeclarationError('distinct literal tile identities required')
        ids.add(tile_id)
        if not _same(raw['t'], [[[0, 0], 1]], w):
            raise DeclarationError('exact singleton center t=1 required')
        marks = _marks(raw['m'], w); total_marks += len(marks)
        tiles.append(dict(id=tile_id, t=[[[0, 0], 1]], m=marks))
        w.cap('tiles', len(tiles)); w.cap('marks', total_marks)
    if not tiles:
        raise DeclarationError('nonempty finite base palette required')
    pins = _marks(value['fixed_background_marks'], w)
    w.cap('marks', total_marks + len(pins))
    w.cap('candidates', len(centers) * len(tiles))
    return dict(schema=INSTANCE_SCHEMA, transformations='translations_only_2Z2',
        required_centers=centers, admissible_origins=[xy[:] for xy in centers],
        tiles=tiles, fixed_background_marks=pins, all_root_generations=0)


def _clauses(value, base, w):
    result, total = [], 0
    origins = {tuple(x) for x in base['required_centers']}
    ids = {t['id'] for t in base['tiles']}
    for raw in _arr(value):
        w.step('clause_rows')
        row = []
        for literal in _arr(raw):
            w.step('clause_literals')
            _obj(literal, ('origin', 'tile_id'))
            xy, tile_id = _xy(literal['origin'], w, True), w.integer(literal['tile_id'], True)
            if tuple(xy) not in origins or tile_id not in ids:
                raise DeclarationError('every literal names an original placement')
            row.append(dict(origin=xy, tile_id=tile_id)); total += 1
            w.cap('literals', total)
        result.append(row); w.cap('clauses', len(result))
    return result


def _build(base, clauses, w):
    used = set()
    for tile in base['tiles']:
        for xy, channel, value in tile['m']:
            w.step('original_channels'); used.add(channel)
    for xy, channel, value in base['fixed_background_marks']:
        w.step('original_channels'); used.add(channel)
    channels = {}
    for kind in ('anchor', 'choice', 'state'):
        stem, suffix = '__receptor_' + kind + '__', 0
        name = stem
        while name in used:
            w.step('fresh_channel_trials'); name = stem + ':' + str(suffix); suffix += 1
        w.string(name); used.add(name); channels[kind] = name
    X = max(x for x, y in base['required_centers'])
    Y = max(y for x, y in base['required_centers'])
    roles, chains = [], []
    for ci, clause in enumerate(clauses):
        role_ids = []
        for li in range(len(clause) if clause else 1):
            w.step('auxiliary_roles')
            role = w.integer(len(roles) + 1, True)
            center = _xy([X + 2 * role, Y + 2], w, True)
            roles.append(dict(role=role, clause=ci, literal_index=li if clause else None,
                              center=center, kind='step' if clause else 'empty'))
            role_ids.append(role)
            w.cap('centers', len(base['required_centers']) + len(roles))
        chains.append(dict(clause=ci, states=[], roles=role_ids))
    R, state_count = len(roles), 0
    for chain, clause in zip(chains, clauses):
        if clause:
            for j in range(len(clause) + 1):
                w.step('fresh_state_points'); state_count += 1
                chain['states'].append(_xy([X + 2 * (R + state_count), Y + 4], w))
    tiles, base_map, aux_map, total_marks = [], [], [], 0

    def emit(marks):
        nonlocal total_marks
        w.step('emitted_tiles')
        tile_id = w.integer(len(tiles), True)
        marks = _marks(marks, w)
        total_marks += len(marks)
        w.cap('tiles', tile_id + 1); w.cap('marks', total_marks)
        tiles.append(dict(id=tile_id, t=[[[0, 0], 1]], m=marks))
        return tile_id

    for original in base['tiles']:
        marks = _copy(original['m'], w)
        marks += [[[0, 0], channels['choice'], original['id']], [[0, 0], channels['anchor'], 0]]
        base_map.append([emit(marks), original['id']])
    for role in roles:
        if role['kind'] == 'empty':
            continue  # No prototype carries this role's pinned anchor value.
        ci, li = role['clause'], role['literal_index']
        literal, r = clauses[ci][li], role['center']
        before, after = chains[ci]['states'][li:li + 2]
        for original in base['tiles']:
            for a in (0, 1):
                w.step('prefix_recurrence_rows')
                v = original['id']; b = int(a == 1 and v == literal['tile_id'])
                marks = [[[0, 0], channels['anchor'], role['role']],
                    [[literal['origin'][0] - r[0], literal['origin'][1] - r[1]], channels['choice'], v],
                    [[before[0] - r[0], before[1] - r[1]], channels['state'], a],
                    [[after[0] - r[0], after[1] - r[1]], channels['state'], b]]
                # Mirror only the ORIGINAL prototype m at its referenced base origin.
                # Fresh role/choice/state channels are disjoint; no positive t copied.
                for offset, channel, value in original['m']:
                    w.step('mirrored_original_mark_rows')
                    translated = [literal['origin'][0] + offset[0] - r[0],
                                  literal['origin'][1] + offset[1] - r[1]]
                    marks.append([translated, channel, value])
                aux_map.append([emit(marks), role['role'], v, a, b])
    centers = _copy(base['required_centers'], w) + [r['center'][:] for r in roles]
    pins = _copy(base['fixed_background_marks'], w)
    for center in base['required_centers']:
        w.step('base_anchor_pins'); pins.append([center[:], channels['anchor'], 0])
    for role in roles:
        w.step('role_anchor_pins'); pins.append([role['center'][:], channels['anchor'], role['role']])
    for chain in chains:
        if chain['states']:
            w.step('prefix_endpoint_pins')
            pins.append([chain['states'][0][:], channels['state'], 1])
            pins.append([chain['states'][-1][:], channels['state'], 0])
    pins = _marks(pins, w)
    w.cap('marks', total_marks + len(pins)); w.cap('candidates', len(tiles) * len(centers))
    instance = dict(schema=INSTANCE_SCHEMA, transformations='translations_only_2Z2',
        required_centers=centers, admissible_origins=[p[:] for p in centers],
        tiles=tiles, fixed_background_marks=pins, all_root_generations=0)
    # Every prototype has exactly one assigned center anchor, including base lifts.
    result = dict(instance=instance,
        mapping=dict(channels=channels, base_tiles=base_map, roles=roles, clause_states=chains, auxiliary_tiles=aux_map),
        construction_counts=dict(original_tiles=len(base['tiles']), lifted_tiles=len(base_map),
            auxiliary_tiles=len(aux_map), auxiliary_centers=len(roles), state_points=state_count,
            total_required_centers=len(centers), total_tiles=len(tiles), prototype_mark_rows=total_marks,
            fixed_mark_rows=len(pins), full_candidate_universe=len(tiles) * len(centers)))
    return result


def _board(instance, certificate, w):
    _obj(certificate, ('schema', 'placements'))
    if certificate['schema'] != CERTIFICATE_SCHEMA:
        raise DeclarationError('exact finite point certificate required')
    origins = {tuple(x) for x in instance['required_centers']}
    tiles = {t['id']: t for t in instance['tiles']}
    section = {(tuple(xy), channel): value for xy, channel, value in instance['fixed_background_marks']}
    chosen = {}
    for raw in _arr(certificate['placements'], len(origins)):
        w.step('whole_certificate_placements')
        _obj(raw, ('tile_id', 'origin'))
        tile_id, xy = w.integer(raw['tile_id'], True), _xy(raw['origin'], w, True)
        point = tuple(xy)
        if point not in origins or point in chosen or tile_id not in tiles:
            raise DeclarationError('exactly one allowed literal tile per required center')
        chosen[point] = tile_id
        for offset, channel, value in tiles[tile_id]['m']:
            w.step('whole_certificate_mark_assignments')
            key = ((xy[0] + offset[0], xy[1] + offset[1]), channel)
            if key in section and section[key] != value:
                raise DeclarationError('whole literal point/channel conflict')
            section[key] = value
    if set(chosen) != origins:
        raise DeclarationError('unfilled center')
    return chosen


def _validated_compilation(raw, w):
    packet = _copy(raw, w)
    _obj(packet, RESULT_KEYS)
    if (packet['schema'] != COMPILATION_SCHEMA or packet['version'] != VERSION
            or packet['status'] != 'MARKING_GADGET_CANDIDATE' or packet['problem_defining'] is not True
            or packet['redundancy_established'] is not False or packet['mathematical_authority'] is not False
            or packet['executed_source_qualified'] is not False):
        raise DeclarationError('compilation candidate is not a redundancy certificate')
    base = _base(packet['base'], w)
    clauses = _clauses(packet['clauses'], base, w)
    expected = _build(base, clauses, w)
    for key in ('instance', 'mapping', 'construction_counts'):
        if not _same(packet[key], expected[key], w):
            raise DeclarationError('full literal compiler reconstruction mismatch')
    if type(packet['counts']) is not dict or any(type(k) is not str or type(v) is not int or v < 0 for k, v in packet['counts'].items()):
        raise DeclarationError('passive operational counters malformed')
    return packet, base, clauses, expected


def _finish_input(before, original, w):
    after = _copy(original, w)
    if not _same(before, after, w):
        raise DeclarationError('caller input changed during transform')
    w.step('public_completion')


def compile_marking_gadget(base, clauses, *, check, limits):
    """Compile problem-defining clauses; no certification/activation authority."""
    w = _Budget(check, limits)
    try:
        original = _copy([base, clauses], w)
        owned_base = _base(original[0], w)
        owned_clauses = _clauses(original[1], owned_base, w)
        built = _build(owned_base, owned_clauses, w)
        _finish_input(original, [base, clauses], w)
        return dict(schema=COMPILATION_SCHEMA, version=VERSION, status='MARKING_GADGET_CANDIDATE',
            base=owned_base, clauses=owned_clauses, instance=built['instance'], mapping=built['mapping'],
            construction_counts=built['construction_counts'], counts=dict(w.counts),
            problem_defining=True, redundancy_established=False, mathematical_authority=False,
            executed_source_qualified=False)
    except GadgetLimit as error:
        if type(error) is not GadgetLimit or error._owner is not w.owner:
            raise
        return dict(status='UNKNOWN', reason=error.reason, counts=dict(w.counts), mathematical_authority=False)


def extend(compilation, base_certificate, *, check, limits):
    """Deterministic extension codec only; does not search or classify pairs."""
    w = _Budget(check, limits)
    try:
        original = _copy([compilation, base_certificate], w)
        packet, base, clauses, built = _validated_compilation(original[0], w)
        chosen = _board(base, original[1], w)
        base_ids = {original_id: emitted for emitted, original_id in built['mapping']['base_tiles']}
        selected = {}
        for xy, tile in chosen.items():
            w.step('base_lift_codec'); selected[xy] = base_ids[tile]
        aux = {(role, v, a): emitted for emitted, role, v, a, b in built['mapping']['auxiliary_tiles']}
        role_by_id = {r['role']: r for r in built['mapping']['roles']}
        for ci, clause in enumerate(clauses):
            if not clause:
                raise NoExtension('empty forbidden conjunction has no extension')
            state = 1
            for literal, role_id in zip(clause, built['mapping']['clause_states'][ci]['roles']):
                w.step('extension_prefix_states')
                value = chosen[tuple(literal['origin'])]
                role = role_by_id[role_id]
                selected[tuple(role['center'])] = aux[role_id, value, state]
                state = int(state == 1 and value == literal['tile_id'])
            if state != 0:
                raise NoExtension('base assignment contains a forbidden conjunction')
        certificate = dict(schema=CERTIFICATE_SCHEMA, placements=[dict(tile_id=selected[tuple(xy)], origin=xy[:])
            for xy in built['instance']['required_centers']])
        _board(built['instance'], certificate, w)
        _finish_input(original, [compilation, base_certificate], w)
        return dict(status='EXTENSION_CANDIDATE', certificate=certificate, counts=dict(w.counts),
                    mathematical_authority=False, compilation_rebuilt=True)
    except GadgetLimit as error:
        if type(error) is not GadgetLimit or error._owner is not w.owner:
            raise
        return dict(status='UNKNOWN', reason=error.reason, counts=dict(w.counts), mathematical_authority=False)


def project(compilation, extended_certificate, *, check, limits):
    """Full raw t/m legality then literal base-ID projection; no cached truth."""
    w = _Budget(check, limits)
    try:
        original = _copy([compilation, extended_certificate], w)
        packet, base, clauses, built = _validated_compilation(original[0], w)
        chosen = _board(built['instance'], original[1], w)
        mapping = {emitted: original_id for emitted, original_id in built['mapping']['base_tiles']}
        placements = []
        for xy in base['required_centers']:
            w.step('base_projection_codec')
            emitted = chosen[tuple(xy)]
            if emitted not in mapping:
                raise DeclarationError('auxiliary tile occupied base center')
            placements.append(dict(tile_id=mapping[emitted], origin=xy[:]))
        certificate = dict(schema=CERTIFICATE_SCHEMA, placements=placements)
        _board(base, certificate, w)
        _finish_input(original, [compilation, extended_certificate], w)
        return dict(status='PROJECTION_CANDIDATE', certificate=certificate, counts=dict(w.counts),
                    mathematical_authority=False, compilation_rebuilt=True)
    except GadgetLimit as error:
        if type(error) is not GadgetLimit or error._owner is not w.owner:
            raise
        return dict(status='UNKNOWN', reason=error.reason, counts=dict(w.counts), mathematical_authority=False)
