"""Metadata and AST/unused compile only; no scientific imports or calls."""
from pathlib import Path
import ast, hashlib, json, sys

B=Path(__file__).resolve().parent.parent
D8=B.parent/'gcts-word-point-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
RUNTIME=B/'runtime'
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12').resolve()
NATIVE=D5/'implementation-B/recovered/and-support'

def pin(path):
    p=Path(path).resolve(); assert '.partial' not in p.name
    body=p.read_bytes()
    return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())

def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,sort_keys=True,indent=2); stream.write('\n')

api_path=Path(sys.argv[1]).resolve()
handoff_path=Path(sys.argv[2]).resolve()
api=json.loads(api_path.read_bytes())
entry=Path(api['entry']['path']); assert pin(entry)==api['entry']
for field in ['model_source','verifier_source']:
    source=Path(api[field]['path']); assert pin(source)==api[field]
    assert (RUNTIME/source.name).read_bytes()==source.read_bytes()
baseline=json.loads((B/'root/baseline-copy-pins-v1.json').read_bytes())
for row in baseline['files']:
    assert pin(row['source'])['sha256']==row['sha256']
    assert pin(row['target'])['sha256']==row['sha256']
assert len(baseline['files'])==32
assert len(list(RUNTIME.glob('*.py')))==28
assert json.loads(handoff_path.read_bytes())
old_api=json.loads((D8/'implementation-B/API-v1.json').read_bytes())
assert api['roles']==dict(old_api['roles'],model='word_point_model_v1')
corpus=D5/'corpus-L/pilot-inputs-v2.json'
assert pin(corpus)['sha256']=='2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'
doc=json.loads(corpus.read_bytes()); assert [s['length'] for s in doc['tests']]==[14,13,14]
tree=ast.parse(entry.read_bytes(),filename=str(entry))
node=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets))
assert isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict'
scientific={k.arg:ast.literal_eval(k.value) for k in node.keywords}
assert scientific==json.loads((D8/'root/protocol-v1.json').read_bytes())['scientific_limits']
native=dict(template_path=str(NATIVE/'fixed-native-inputs/proof-boundary-001.json'),micro_path=str(NATIVE/'fixed-native-inputs/proof-boundary-microcode-001.json.gz'),executable_path=str(NATIVE/'Native-runtime/boundary-oracle-v2'))
sources=sorted(RUNTIME.glob('*.py'))+[entry]+[B/'root'/n for n in ['observe_case_once_v2.py','run_case_once_v3.py','case_worker_v1.py','independent_countermodel_v1.py']]
checks=[]
for p in sources:
    parsed=ast.parse(p.read_bytes(),filename=str(p)); compile(parsed,str(p),'exec')
    checks.append(dict(path=str(p),AST_and_unused_compile=True))
files=sources+[api_path,handoff_path,corpus,PYTHON,NATIVE/'Native-runtime/boundary_oracle.cpp']+[Path(p) for p in native.values()]
rows=[pin(p) for p in sorted(set(files))]
limits=dict(positive_seconds=180,custody_seconds=210,observer_fallback_seconds=225,work_seconds=160,memory_bytes=1073741824,physical_bytes=134217728,reserved_outer_bytes=9437184,log_bytes=4194304,root_callbacks=400000000,result_bytes=50331648)
protocol=dict(schema='readonly-parent-domain-search-protocol-v1',input=pin(corpus),limits=limits,scientific_limits=scientific,
    unchanged='All D8 corpus/theories/3fresh cold3-5-5donors/14-13-14primitive bounds; exact candidate identities, word carrier/reduction verifier, t roots, initial boundary, frontier/generations/global scheduler/rollback, six-arm order,2s clock, all quotas, Native ground gates and final proof gates.',
    change='Only eliminate one redundant candidate-domain copy per primitive placement in search_points. The former before={p:set(v) for p,v in cg.domains.items()} is now a read-only before=g.domains. Graph.copy already gives cg independent domain sets; child State.place does not mutate Graph, cg.update mutates only cg, and _aux_removals only reads before. VERSION/comment are the other text changes.',
    correspondence='In this pinned fixed-dependency runtime, pre-update cg.domains equals g.domains by value. Parent g remains unchanged through child updates and recursion; every auxiliary witness and subsequent search decision is preserved. Existing full Graph audits, exact root fingerprint restoration and all48 word-reference controls remain. No cost/fit prediction follows.',
    prerequisites='Unchanged D8 per-arm gate: Native unknown_step_budget/unknown_space_budget ground registry explicitly skips SC/P01/P11 only; S0/P00/P10 run. Rejected/foreign status and Root/transport faults are not skips. Clusters only reorder original primitive alternatives, with complete fallback.',
    proof_acceptance='Every candidate retains exact case Host, full finite point region and final primitive Native checks. Native UNKNOWN is candidate-only. Old memory-failed packets are not adopted; only fresh whole-accepted jobs enter qualified comparisons.',
    completion='Six explicit outcomes give job_record_complete. Any skipped arm prevents all_six_searched/scientific_complete. Whole resource/custody acceptance is separate, and bounded failure is unknown, never theorem falsity or a plane non-tiling claim.',
    execution='Three fresh sequential cold case jobs; all agents idle during timed actuals. Exact fully reviewed Source/plan and fresh one-use Root grants required. No old result/library/prefix/grant rescue.',
    costs='All donor acquisition, compilation/model/reference checks, wire encoding, markings, unknown ground query, real searches/final proof checks, serialization and custody remain charged once per case. Nested timers are not disjoint. S0 needs no unused learned inventory; no cluster method gets free acquisition.',
    search_time='Original cooperative2s includes Graph construction, snapshots, initial audits and active search. Cleanup/operations may overshoot checkpoints. No timer moved, audit omitted, attempt count increased or ordering tuned.',
    baseline_scope='Same matched symbolic control, not strongest ATP. Shared point setup is experimental correspondence/reporting overhead, not intrinsically necessary for symbolic proof search. D8 is an authored historical development comparator, not controlled statistical speedup evidence.',
    source='All28 runtime and4 custodian Sources are exact D8 copies. Only new entry statement/version/comment differ. Original D8 L handoff binds its unchanged verifier Source; D9 caller and whole-plan reviews separately bind the new entry. No traceback cleanup, new model, RL or admission-policy change.',
    observer='Unchanged fixed-dependency nonhostile custodian:160s work/180s positive/210s custody/225s independent fallback,1GiB memory/128MiB physical output including9MiB reserve and400m callbacks. Live file census is non-atomic; final census after known child exit. No adversarial or OSreal-time guarantee.',
    scope='Aligned complete-word Native/point adaptation; arbitrary shifted/partial byte assignments and physical nearest-neighbor Wang qualification remain outside scope. No fullPA/Hilbertgeometry, practical Turtle/Penrose plane coverage, trainedRL, broad proof-search superiority or wholeprogram completion.',
    partial_rule='Every.partial raw length/hash only, never parsed/projected/reconstructed/admitted.',old_grants_remaining=0,new_actuals=0,new_grants=0)
protocol_path=B/'root/protocol-v1.json'; save(protocol_path,protocol)
plans=[]
for spec in doc['tests']:
    case=spec['id']; actual=B/'actual'/case
    assert not actual.exists() and not Path(str(actual)+'.observer').exists()
    plan=dict(schema='proof-search-case-once-plan-v1',experiment='readonly-parent-domain-search-v1',case_id=case,actual_dir=str(actual),runtime_dir=str(RUNTIME),runner_path=str(B/'root/run_case_once_v3.py'),observer_path=str(B/'root/observe_case_once_v2.py'),worker_path=str(B/'root/case_worker_v1.py'),entry_path=str(entry),control_path=str(B/'root/independent_countermodel_v1.py'),input_path=str(corpus),modules=api['roles'],native=native,python=pin(PYTHON),files=rows,limits=limits,experiment_limits=scientific,protocol=pin(protocol_path),authority='No execution from plan. Exact reviewed fresh Root once grant required.',trusted_runtime='Pinned isolated CPython/fixed research Sources; nonhostile reproducible research, not wholeOS/adversarial security proof.',old_qualifications='No old grant/cohort/failed gate adopted or rescued.')
    path=B/'root'/('plan-'+case+'-v1.json'); save(path,plan); plans.append(pin(path))
offer=dict(schema='readonly-parent-domain-search-whole-offer-v1',plans=plans,files=rows,protocol=pin(protocol_path),python=pin(PYTHON),source_AST_checks=checks,expected_case_jobs=3,expected_explicit_arm_outcomes=18,scientific_calls=0,new_actuals=0,new_grants=0,old_grants_remaining=0,resource_fit='UNMEASURED. Complete actual admission required.',readiness='PENDING_EXACT_REDUCTION_SOURCE_COMPOSITION_AND_PLAN_REVIEWS_ROOT_ONCE_GRANTS')
save(B/'root/prospective-whole-offer-v1.json',offer)
print(json.dumps(dict(plans=plans,files=len(rows),Source_AST_checks=len(checks),new_actuals=0,new_grants=0)))
