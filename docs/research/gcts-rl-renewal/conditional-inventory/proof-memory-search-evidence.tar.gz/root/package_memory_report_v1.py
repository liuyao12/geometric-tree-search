"""Package complete task-owned bytes; no scientific calls or partial parsing."""
from pathlib import Path
import hashlib,io,json,tarfile
B=Path(__file__).resolve().parent.parent
D8=B.parent/'gcts-word-point-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
P=B.parent/'gcts-batch-20261020/publisher'
D=P/'docs/research/gcts-rl-renewal/conditional-inventory'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    raw=path.read_bytes();return dict(file=path.name,bytes=len(raw),sha256=sha(raw))
excluded={'archive-scan-v1.json','Root-final-milestone-v1.json','Root-next-stage-handoff-v1.json','cutoff-retention-next-assessment-v1.json'}
paths={p for p in B.rglob('*') if p.is_file() and 'publication' not in p.relative_to(B).parts and 'publication-C' not in p.relative_to(B).parts and p.name not in excluded}
offer=json.loads((B/'root/prospective-whole-offer-v1.json').read_bytes());omitted=[]
for row in offer['files']:
    path=Path(row['path'])
    if path==Path(offer['python']['path']):omitted.append(dict(pin=row,reason='Pinned trusted isolated CPython binary not redistributed; research Sources and fixed Native assets are included.'))
    else:paths.add(path)
paths.update([D8/'implementation-B/proof_search_pilot_v6.py',D8/'implementation-B/API-v1.json',D8/'implementation-B/word_point_model_v1.py',D8/'implementation-B/memory-retention-assessment-v1.json',D8/'verification-L/word_point_reference_verifier_v1.py',D8/'verification-L/API-v1.json',D8/'verification-L/manual-correspondence-v1.json',D8/'verification-L/declarative-diagnostic-bank-v1.json',D8/'root/protocol-v1.json',D8/'root/passive-actual-assessment-v1.json',P/'docs/basic-tiling-algorithm.md'])
records=[];bodies=[];partials=[]
for path in sorted(paths):
    assert not path.is_symlink()
    if path.is_relative_to(B):name=path.relative_to(B).as_posix()
    elif path.is_relative_to(D8):name='dependencies/D8/'+path.relative_to(D8).as_posix()
    elif path.is_relative_to(D5):name='dependencies/D5/'+path.relative_to(D5).as_posix()
    elif path==P/'docs/basic-tiling-algorithm.md':name='reference/basic-tiling-algorithm.md'
    else:raise ValueError('undeclared archive path '+str(path))
    raw=path.read_bytes();row=dict(file=name,bytes=len(raw),sha256=sha(raw))
    if '.partial' in path.name:partials.append(row)
    else:records.append(row);bodies.append((name,raw))
manifest=dict(schema='proof-memory-search-evidence-archive-v1',files=records,partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted,actual_case_attempts=3,resource_admitted_case_attempts=2,resource_rejected_case_attempts=1,complete_actual_and_observer_files=42,observed_searches=9,observed_cluster_skips=9,observed_point_placements=99,observed_point_audits=12,admitted_searches=6,admitted_cluster_skips=6,admitted_point_placements=65,admitted_point_audits=8,new_admitted_recipient_proofs=0,scientific_comparison_complete=False,scientific_calls_during_packaging=0,reproduction='Consumed grants are historical records, never reusable. New paths/plans/reviews/fresh once grants are required. This snapshot includes execution closure and all complete failed and admitted attempt bodies; the pinned CPython binary is omitted explicitly.',scope='The first positive memory-failed job is diagnostic only and never prefix-adopted. Equality and missing-premise jobs passed whole admission. Publication-only review and the unexecuted cutoff-retention next assessment are outside this scientific snapshot.')
mb=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=B/'publication/proof-memory-search-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as stream:
    for name,raw in bodies+[('MANIFEST.json',mb)]:
        item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0;stream.addfile(item,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as stream:
    assert len(stream.getmembers())==len(records)+1
    for row in records:
        raw=stream.extractfile(row['file']).read();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    assert stream.extractfile('MANIFEST.json').read()==mb
scan=dict(schema='proof-memory-archive-complete-byte-scan-v1',archive=pin(archive),members=len(records)+1,payload_bytes=sum(row['bytes'] for row in records),all_members_byte_checked=True,partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted)
(B/'root/archive-scan-v1.json').write_text(json.dumps(scan,sort_keys=True,indent=2)+'\n')
for path in sorted((B/'publication').glob('proof-memory-search*')):
    if path.name!='proof-memory-search-manifest.json':(D/path.name).write_bytes(path.read_bytes())
owned=sorted(p for p in D.glob('proof-memory-search*') if p.name!='proof-memory-search-manifest.json')+[D/'reader.html']
assert len(owned)==7
public=dict(schema='proof-memory-search-publication-manifest-v1',source_parent_commit='bb60f00fa250b01a7860f228cf7d801e7c07ff23',files=[pin(p) for p in owned],archive_scan=scan,conclusion='Three actuals: one rejected memory job, equality and negative admitted. Observed99placements/12audits; admitted65/8.0newadmittedrecipientproofs; no complete6armcomparison orGCTS/RLgain.',reader_delta=json.loads((B/'root/reader-publication-delta-v1.json').read_bytes()))
(D/'proof-memory-search-manifest.json').write_text(json.dumps(public,sort_keys=True,indent=2)+'\n')
print(json.dumps(scan))
