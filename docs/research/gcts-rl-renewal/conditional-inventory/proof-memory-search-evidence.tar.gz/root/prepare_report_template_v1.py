"""Author HTML from the established reader; no scientific imports or calls."""
from pathlib import Path
B=Path(__file__).resolve().parent.parent
P=B.parent/'gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
s=(P/'word-point-proof-search.html').read_text()
def replace(old,new):
    global s
    assert old in s,old[:120]
    s=s.replace(old,new)
replace('word-point-proof-search','proof-memory-search')
replace('reader.html#word-point-update','reader.html#proof-memory-update')
replace('href="recipient-proof-search.html#outcome">Previous byte-point search','href="word-point-proof-search.html#outcome">Previous word-port experiment')
replace('Word-valued point proof search — GCTS research','Proof-search memory experiment — GCTS research')
replace('Word-valued markings: can complete GCTS proof search become practical?','Removing a redundant copy from complete point proof search')
replace('A new, explicitly checked representation compresses each complete aligned formula or command into one exact point value. We retain the same statements, candidate identities, scheduler, proof gates and search budgets, and report what actually returns.','Three fresh cold cases test one implementation change: reuse the unchanged parent domains when measuring candidate removal, rather than copying those sets again. Statements, marking representation, candidate universe, scheduler, proof gates and budgets remain the same.')
replace('Implement the word-valued carrier and integrate it with the unchanged complete Graph search, markings and six arm protocol.','Remove one redundant domain copy and provide an exact source equivalence argument; preserve every search rule and proof gate.')
replace('Derive the original candidate specification independently; check dictionary words, ports, metadata, dependencies and negative controls.','Check parent/child ownership, the read-only consumer, source/API bindings and unchanged resource protocol independently.')
replace('What changed: one exact value per whole word','Underlying word-valued marking carrier (unchanged)')
replace('Independent reduction verifier','Independent verification')
replace('Ground-cluster admission is now a per-arm prerequisite.','Ground-cluster admission remains a per-arm prerequisite.')
section='''<section id="memory-copy"><h2>One isolated memory change</h2><div class="cards"><article class="card"><h3>Parent graph</h3><p>The current graph keeps its complete frontier domains and inverse incidence. Child exploration leaves it unchanged.</p></article><article class="card"><h3>Independent child graph</h3><p><code>Graph.copy()</code> already copies the domain and edge sets. Only the child receives the placement update.</p></article><article class="card"><h3>Read-only comparison view</h3><p>The removal observer can read <code>g.domains</code> directly. It previously made another full set copy before updating the child.</p></article></div><p>The source argument establishes equal candidate-removal observations for corresponding transitions. Existing exhaustive domain/inverse/scheduler audits, tiny controls and exact root restoration checks remain enabled. The wall-clock cutoff can occur after a different number of moves, so identical timed prefixes are not claimed.</p><p>This experiment makes no other implementation change: no new ordering, shortened proof, omitted audit, moved clock, changed Native admission policy or traceback cleanup. Actual whole-job memory and acceptance remain decisive.</p></section>\n'''
replace('<section id="carrier">',section+'<section id="carrier">')
comparison=r'''<section id="comparison"><h2>Historical case-by-case comparison</h2><div class="scroll"><table><thead><tr><th>Case</th><th>Previous whole job</th><th>Current whole job</th><th>Previous full peak (\(\mathrm{MiB}\))</th><th>Current full peak (\(\mathrm{MiB}\))</th><th>Recorded point placements, previous / current</th></tr></thead><tbody id="comparison-rows"></tbody></table></div><p>The previous experiment is preserved in the <a href="word-point-proof-search.html#outcome">word-port report</a>. An unavailable full peak is shown as a dash. These are single cold development runs: the same cooperative budget can end at different prefixes. Memory, attempt and admission differences are observations, without a causal phase attribution or statistical speedup claim.</p></section>
'''
replace('<section id="results">',comparison+'<section id="results">')
renderer="function showComparison(){el('comparison-rows').replaceChildren(...data.comparison.map(c=>{const tr=document.createElement('tr');[c.title,c.previous_admitted?'Admitted':'Rejected',c.current_admitted?'Admitted':'Rejected',c.previous_whole_peak_bytes===null?'—':num(c.previous_whole_peak_bytes/1048576),c.current_whole_peak_bytes===null?'—':num(c.current_whole_peak_bytes/1048576),c.previous_point_placements+' / '+c.current_point_placements].forEach(v=>tr.append(txt('td',v)));return tr}))}\n"
replace('function showPipeline(){',renderer+'function showPipeline(){')
replace('showPipeline();showCase();showProof();showTile()','showComparison();showPipeline();showCase();showProof();showTile()')
replace('except the first failed attempt, whose available worker-plus-Native lower bound is shown and labeled. Its whole peak is unavailable.','with an explicitly labeled worker-plus-Native lower bound if a failed attempt has no whole-peak authority.')
replace('The archive preserves complete outputs, including failures.','The archive preserves every complete output, including any failed attempts.')
(B/'publication/proof-memory-search.html').write_text(s)
print('Authored template; actual data and publication review still required.')
