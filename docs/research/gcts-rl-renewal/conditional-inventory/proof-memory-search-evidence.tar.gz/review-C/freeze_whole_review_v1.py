"""Bounded complete-pins/plan metadata and AST preflight; no scientific calls."""
import ast
import hashlib
import json
from pathlib import Path

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D=BASE/'research-runs/gcts-proof-memory-pilot-20261020'
OLD=BASE/'research-runs/gcts-word-point-proof-pilot-20261020'
OUT=D/'review-C'


def pin(path):
    p=Path(path);assert '.partial'not in p.name
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def read(path):
    p=Path(path);assert p.suffix=='.json'and '.partial'not in p.name
    return json.loads(p.read_bytes())


def verify(row):assert pin(row['path'])=={k:row[k]for k in ['path','bytes','sha256']}


offer_path=D/'root/prospective-whole-offer-v1.json';offer=read(offer_path)
assert len(offer['files']) == 41 and len({r['path']for r in offer['files']}) == 41
for row in offer['files']:verify(row)
assert len(offer['source_AST_checks'])==33
assert {r['path']for r in offer['source_AST_checks']}=={r['path']for r in offer['files']if r['path'].endswith('.py')}
for row in offer['source_AST_checks']:
    assert row['AST_and_unused_compile']is True
    t=ast.parse(Path(row['path']).read_bytes(),filename=row['path'])
    unused_code=compile(t,row['path'],'exec');del unused_code
assert offer['new_actuals']==offer['new_grants']==offer['old_grants_remaining']==0
assert offer['expected_case_jobs'] == 3 and offer['expected_explicit_arm_outcomes'] == 18
protocol=read(offer['protocol']['path']);verify(offer['protocol'])
old_protocol=read(OLD/'root/protocol-v1.json')
assert protocol['input']==old_protocol['input']
assert protocol['limits']==old_protocol['limits']
assert protocol['scientific_limits']==old_protocol['scientific_limits']
verify(protocol['input']);verify(offer['python'])
api_path=D/'implementation-B/API-v1.json';api=read(api_path)
assert api['limits']==protocol['scientific_limits']
assert len(list((D/'runtime').glob('*.py')))==len(list((OLD/'runtime').glob('*.py')))==28
for path in (OLD/'runtime').glob('*.py'):
    assert (D/'runtime'/path.name).read_bytes()==path.read_bytes()
outer_names=['case_worker_v1.py','run_case_once_v3.py','observe_case_once_v2.py','independent_countermodel_v1.py']
for name in outer_names:
    assert (D/'root'/name).read_bytes()==(OLD/'root'/name).read_bytes()
case_ids=[];actual_paths=[]
for row in offer['plans']:
    verify(row);plan=read(row['path']);case_ids.append(plan['case_id']);actual_paths.append(plan['actual_dir'])
    old_plan=read(OLD/'root'/('plan-'+plan['case_id']+'-v1.json'))
    assert plan['files']==offer['files']
    assert plan['protocol']==offer['protocol']and plan['python']==offer['python']
    assert plan['limits']==protocol['limits']and plan['experiment_limits']==protocol['scientific_limits']
    assert plan['input_path']==protocol['input']['path']
    assert plan['modules']==api['roles']==old_plan['modules']
    assert plan['native']==old_plan['native']
    assert plan['entry_path']==api['entry']['path']and plan['runtime_dir']==str(D/'runtime')
    for field,name in [('worker_path','case_worker_v1.py'),('control_path','independent_countermodel_v1.py'),('runner_path','run_case_once_v3.py'),('observer_path','observe_case_once_v2.py')]:
        assert plan[field]==str(D/'root'/name)
    assert plan['actual_dir']==str(D/'actual'/plan['case_id'])
    assert not Path(plan['actual_dir']).exists()and not Path(plan['actual_dir']+'.observer').exists()
assert set(case_ids)=={'pilot-fork-join-positive','pilot-quantifier-equality-positive','pilot-fork-join-missing-Pa'}
assert len(set(actual_paths))==3
assert not list((D/'root').glob('grant-*.json'))
science_path=OUT/'typed-scientific-delta-Source-review-v1.json'
assert pin(science_path)['sha256']=='27e25146437317d5397214a80b3926f8b247c0a32c584b904c39944829dcbe32'
assert read(science_path)['review_passed']is True
prior_L=OLD/'verification-L/typed-word-point-whole-plan-resource-ABI-Source-review-v1.json'
assert read(prior_L)['review_passed'] is True and read(prior_L)['scientific_self_admission'] is False
old_L_handoff=OLD/'verification-L/handoff-v1.json'
assert any(r==pin(old_L_handoff)for r in offer['files'])
assert pin(old_L_handoff)['sha256']=='5cfa4cc5ed78ff1f762040c6c394375a87165c11416bebded0ce2233a97386c2'
checks=[
 ('complete-41-file-closure','All41 complete offered file pins match;33 Sources independently AST parsed and unused compiled without imports or research execution. All28 runtime Sources and four custodian Sources match D8 byte for byte; only the separately reviewed v7 entry/API differ. No extra runtime/helper or semantic code is admitted by this preflight.'),
 ('independent-exact-single-delta','C separate27e25146… Source/manual review binds v7/oldv6, complete text inverse and Graph ownership/nonmutation proof. This is a fresh experiment; D8 two failed positive jobs remain rejected. Original D8 verifier handoff records unchanged verifier provenance only; it does not silently admit this new caller.'),
 ('exact-three-full-cold-case-plans','All three distinct new absent actual/observer paths bind the whole identical original corpus, same28runtime Native assets and exact entry/roles. Full14/13/14 targets and3/5/5 cold donors remain; all six explicit relative outcomes are required per job. No easier case, saved learned library, warm Native process or failed prefix is reused.'),
 ('all-limits-and-scientific-gates-unchanged','Every scientific and outer numeric limit matches D8.2s is cooperative and still begins before Graph construction/snapshots/two full domain audits;600attempts and400mRootcallbacks unchanged. Known ground Native UNKNOWN skips only SC/P01/P11; rejected/foreign/Root faults do not. Host, full point region and final primitive Native checks remain required.'),
 ('unchanged-custody-reuse-with-actual-obligations','Reuses prior exact D8/D6 fixed-dependency nonhostile custody review because all four Sources are byte-identical.160work/180positive/210custody/225independent fallback,1GiB,128MiB and9MiB reserve remain. Actual complete result/header/terminal/observer/tool exits, known Native reaping and stable post-exit output/memory gates must still pass; no fit or OS/adversarial guarantee is inferred.'),
 ('authority-and-independent-L-barrier','Zero actual/grant/old-use counts and absent paths verified at freeze. C issues no execution grant. Root must additionally hold the separately frozen independent D9 L plan/custody receipt, then issue fresh exact one-use grants after all tools are idle. This receipt neither predates nor assumes that L barrier passed; Root alone owns actual execution and subsequent outcome admission.'),
]
result=dict(schema='typed-parent-domain-view-whole-prospective-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_EXACT_PREFLIGHT_SEPARATE_L_AND_ROOT_ONCE_AUTHORITY_REQUIRED',source_only=True,scientific_calls=0,component_calls=0,actual_execution_authorized=False,actual_resource_accepted=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],whole_offer=pin(offer_path),protocol=offer['protocol'],plans=offer['plans'],file_pins=offer['files'],AST_unused_compile_count=33,runtime_Source_count=28,unchanged_custodian_Source_count=4,scientific_delta_review=pin(science_path),original_D8_L_verifier_handoff=pin(old_L_handoff),inherited_D8_L_plan_custody_review=pin(prior_L),separate_independent_D9_L_review_required=True,L_pass_not_assumed=True,fit='UNMEASURED',new_actuals=0,new_grants=0,old_grants_remaining=0,partial_policy='No partial content read or parsed; all old failed cohorts retained unchanged.',tools_stopped=True)
target=OUT/'typed-whole-prospective-Source-review-v1.json';assert not target.exists()
target.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(target),indent=2))
