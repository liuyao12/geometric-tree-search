"""Independent Source/AST and complete metadata review only; no research calls."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D=BASE/'research-runs/gcts-proof-memory-pilot-20261020'
D8=BASE/'research-runs/gcts-word-point-proof-pilot-20261020'
OUT=D/'review-C'


def pin(path):
    path=Path(path);assert '.partial'not in path.name
    b=path.read_bytes()
    return dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def read(path):
    path=Path(path);assert path.suffix=='.json'and '.partial'not in path.name
    return json.loads(path.read_bytes())


def rows(obj):
    if type(obj)is dict:
        if {'path','bytes','sha256'}<=obj.keys():yield obj
        else:
            for value in obj.values():yield from rows(value)
    elif type(obj)is list:
        for value in obj:yield from rows(value)


def tree(path):
    result=ast.parse(Path(path).read_bytes(),filename=str(path))
    unused_code=compile(result,str(path),'exec');del unused_code
    return result


handoff_path=D/'implementation-B/handoff-v1.json'
h=read(handoff_path)
assert h['entry']['sha256']=='1afee0ca5336cb29f25b4fb8602d4f2fd95ca7950dcfb5063b1c079d5e61b9bc'
artifacts={}
for relative in ['handoff-v1.json','manifest-v1.json','API-v1.json','manual-equivalence-v1.json','AST-diff-v1.json']:
    p=D/'implementation-B'/relative
    for row in rows(read(p)):
        actual=pin(row['path']);assert actual=={k:row[k]for k in ['path','bytes','sha256']}
        artifacts[actual['path']]=actual
    artifacts[str(p)]=pin(p)
old=D8/'implementation-B/proof_search_pilot_v6.py'
new=Path(h['entry']['path'])
before=old.read_text();after=new.read_text()
patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(old),tofile=str(new)))
assert patch==Path(h['patch']['path']).read_text()
old_literal="VERSION = 'native-point-matched-proof-search-pilot-v6-aligned-word-ports'"
new_literal="VERSION = 'native-point-matched-proof-search-pilot-v7-parent-domain-view'"
old_assign='            before = {p: set(v) for p, v in cg.domains.items()}'
new_assign='            # Parent domains remain unchanged; only the copied child graph is updated.\n            before = g.domains'
assert before.count(old_literal)==before.count(old_assign)==1
assert before.replace(old_literal,new_literal).replace(old_assign,new_assign)==after
ta=tree(old);tb=tree(new)
def members(t):return {n.name:ast.dump(n,include_attributes=False)for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
ma=members(ta);mb=members(tb)
assert ma.keys()==mb.keys()
changed=sorted(n for n in ma if ma[n]!=mb[n]);assert changed==['search_points']
assert len(set(ma)-set(changed))==28
graph=D8/'runtime/turtle.py';gt=tree(graph)
assert pin(graph)['sha256']=='9eefe9fd16671802e7b283ad414f02022eb591ebbf6ef1c877e3ad72dfc18c1a'
master=BASE/'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md'
assert pin(master)['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
prior=[D8/'review-C/typed-scientific-composition-Source-review-v1.json',D8/'review-C/typed-whole-prospective-Source-review-v1.json',D8/'review-C/typed-word-point-actual-scientific-review-v1.json']
assert all(read(p)['review_passed']is True for p in prior)

checks=[
 ('exact-single-delta','All frozen B artifacts/dependencies match their pins; exact unified patch and full raw Source inverse independently reproduce the predecessor. Only search_points function AST changes;28 other top-level functions/classes are identical. The only other Source text changes are VERSION and one comment. AST/unused compile only, zero research imports/calls/fixtures.'),
 ('deep-child-graph-ownership','Exact fixed Graph.copy creates separate domains and edges dictionaries and copies every nested candidate/point set. All shared keys/points are immutable tuple/scalar identities in this carrier. State.copy duplicates mutable state containers; child.place receives no graph reference and cannot mutate parent domains. Therefore g.domains and pre-update cg.domains are equal by value and disjoint as mutable owners.'),
 ('parent-graph-nonmutation-induction','Graph.update is invoked only on cg, whose dictionaries and sets are private copies. Decisions, audits, fingerprints, ordering and cluster hint validation read g. Recursive visit receives cg and builds further copied descendants before update. Inductively the input graph g of every visit remains unchanged through child exploration, failures and subsequent alternatives. Fixed nonhostile Root callbacks inspect resources/Source and do not mutate graph locals; arbitrary hostile callbacks are outside this experiment.'),
 ('read-only-removal-consumer-and-value-correspondence','Unchanged _aux_removals iterates sorted before.items and computes keys-after.get(point,set()) using nonmutating set subtraction. It never writes either map or any before set; placement/state inspection is read-only. Since old copied-before and new g.domains have the same values at this call, all scanned candidates, exact auxiliary point/value conflicts and saved removal witnesses agree for the same transition. Child updates cannot alter the new before view.'),
 ('unchanged-mathematics-and-acceptance','The change does not remove any legal domain/incidence, candidate, dependency or proof rule. Shared model metrics are not domain ownership. Full scalar/word/aux semantics, generation scheduling, primitive fallback, Host/full-region/Native gates, whole evidence payload, initial state/graph fingerprints and firsttwo full domain/inverse/scheduler audits remain exact. Existing D8 reduction/verification judgment is reused within its original aligned reachable-state scope.'),
 ('resource-and-bounded-prefix-scope','This removes one redundant allocation, not a measured peak diagnosis or a guaranteed fit. The same cooperative2s/600attempt budget includes graph construction and audits. Different allocation/GC/timing can change which finite prefix completes before a checkpoint; no equal timings/attempt counts, identical memory/error outcomes or old-result rescue is claimed. No traceback cleanup, new control, quota increase, clock relocation or cohort trimming is present.'),
]
result=dict(schema='typed-parent-domain-view-scientific-delta-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_CONDITIONAL_EXACT_SINGLE_SOURCE_DELTA_NO_ACTUAL_OR_FIT_ADMISSION',source_only=True,scientific_calls=0,component_calls=0,actual_execution_authorized=False,actual_resource_accepted=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],entry=pin(new),predecessor=pin(old),patch=pin(h['patch']['path']),implementation_handoff=pin(handoff_path),artifacts=list(artifacts.values()),fixed_Graph_State=pin(graph),master=pin(master),primary_master_also_read=pin(BASE/'docs/basic-tiling-algorithm.md'),changed_top_level_functions=changed,unchanged_top_level_functions_classes=28,inherited_reviews=[pin(p)for p in prior],manual_scope='Independent conditional manual Source argument, not a mechanized proof, runtime equivalence test, new whole-VM qualification or attribution of D8 peak memory.',remaining='Exact fresh Root whole-offer/plan review, one-use grants and idle barrier before any actual. All outcomes require complete saved evidence admission; previous failed jobs remain failed.',new_grants=0,new_actuals=0,tools_stopped_after_whole_preflight=True)
target=OUT/'typed-scientific-delta-Source-review-v1.json';assert not target.exists()
target.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(target),indent=2))
