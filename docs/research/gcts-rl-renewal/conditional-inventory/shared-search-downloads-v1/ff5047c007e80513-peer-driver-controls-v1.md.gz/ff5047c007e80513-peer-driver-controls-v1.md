# Independent Source-only driver/control integration review

Status: `PASS_STATIC_SOURCE_REVIEW`. Scientific execution and empirical qualification remain pending. No module, model builder, solver, native checker, oracle or previous witness was imported or executed in this review. Only direct Source/data reads and Python AST parsing were used. No subject Source was edited by this reviewer.

Reviewed final driver: `source/run_shared_search_v1.py`, 23,579 bytes, SHA256 `ae7e94a02c0cc04de4d484ad7c7451ed8a42e99ecd7b777644ea7735aad6179b`. Exact seven unit declarations: `plan/unit-fixtures-v1.json`, 1,683 bytes, SHA256 `4738703007e78594efc00b32b0ec66d62918e4c80ed286a2db521ddd79378d68`. The complete initial driver and all subsequent cleanup/admission/cost deltas were read; final AST parsing passed.

The final driver closes the identified pre-freeze issues:

- Observer errors and failed RSS observations stop the owned child, use bounded TERM/KILL cleanup and reap it. Races with an already exited process are handled. Terminal observer receipts retain actual native exit and guard/postcheck failure separately.
- Worker postcheck failures are persisted without suppressing the original exception or silently producing a complete invocation. Benchmark admission joins qualification started/observer/invocation phase, PID, protocol, native exit, guard and frozen postcheck.
- Tiny native and unit qualification requires completed control outcomes. UNKNOWN cannot pass a negative fixture merely because it is not SAT.
- Noncontiguous active-slot qualification requires an actual adjacent active-slot gap, rather than counting only leading PAD as a gap.
- Point observation persistence has its own pinned ref/write time; point, SAT and decoder functions retain outer pipeline totals. Those totals include expensive serialization not covered by the algorithm's internal solve timer.

The seven unit models cover global dead before forced, a forced remote marking that creates a dead point while another singleton remains, remote rollback, shared positive support, a seed-filled root, literal assigned zero versus missing, and a four-value agreement/AMO group. Their full tiny point and eligible selector-projection oracles are distinct from the subject searches. The driver joins complete point traces and separately checks exact CNF association/certificates. Positive native cases require agreement of adapter and independently reconstructed decoding plus unchanged native B; the forward control starts with no free facts and has the same declared line bound. Added strict-reference/PAD mutations exercise the new adapter boundary.

Actual limits are authoritative in the final driver: three-second solve ceilings, point 100-million work/10,000 nodes/1,000 retained events, forward 20-million work/200,000 states, reference DPLL 10-million work, native 5-million operations and phase guards of 180 seconds wall/150 seconds CPU/1 GiB sampled RSS. They supersede the earlier prose proposal. Counters have different units. A resource refusal or missing trace coverage must remain UNKNOWN; the observer's polled RSS is not a strict instantaneous memory certificate.

Reporting qualifications remain necessary. The driver uses fixed point/forward/SAT order, not rotated repeated cold trials. The shared combined `basis-model` assurance call does not separately time its logical-basis and point-model portions; report it as a combined study-assurance cost or disclose that limitation rather than assigning the whole amount as common logical cost to forward. Preparation/encoder/admission refusal can terminate a phase after retaining its raw artifact; that is not a negative search outcome. The simple reference DPLL is not a representative modern SAT solver. Neither Source review nor the prospective labels establish a solved target, practical speed advantage, full FOL/PA/Hilbert completeness or any RL result.

No blocking Source integration issue remains within this reviewed finite ground-pilot scope. Root must freeze this note together with the exact final file set/runtime/master/declarations before the first scientific import, then assess actual raw results and independent receipts.
