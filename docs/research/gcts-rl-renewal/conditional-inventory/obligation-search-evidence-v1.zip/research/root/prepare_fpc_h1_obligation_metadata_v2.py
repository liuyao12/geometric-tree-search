"""Raw metadata authoring only; never imports or calls research Sources.

Run only after the explicit current offers and component reviews exist.
This freezes protocol/closure/plan and a reject-only grant proposal. It
does not create an execution grant, actual directory, query or proof.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021')
ROOT = BASE / 'root'
CASE = 'obligation-fpc-h1-hi-point-not-line-0'


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path and not path.is_symlink()
    assert '.partial' not in path.name and path.is_file()
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       allow_nan=False, indent=2) + '\n').encode('ascii')
    with path.open('xb') as stream:
        stream.write(body)
    return pin(path)


def main(worker_api_path, producer_offer_path, regression_offer_path,
         producer_review_path, regression_review_path, worker_review_path):
    worker_api_path, producer_offer_path, regression_offer_path, producer_review_path, regression_review_path, worker_review_path = (Path(x).resolve() for x in (worker_api_path, producer_offer_path, regression_offer_path, producer_review_path, regression_review_path, worker_review_path))
    api = read(worker_api_path)
    offers = [Path(producer_offer_path), Path(regression_offer_path)]
    reviews = [Path(producer_review_path), Path(regression_review_path), Path(worker_review_path)]
    assert api['Source'] == pin(ROOT / 'fpc_h1_obligation_search_worker_v4.py')
    assert len(api['module_roles']) == 12
    modules = api['known_module_sources']
    assert set(modules) == set(api['module_roles'])
    assert sum(x['count'] for x in api['control_populations']) == 126
    for path in reviews:
        assert read(path)['review_passed'] is True
    guards = {}

    def guard(row, kind='RAW_SEMANTIC_GUARD', role=None):
        exact = {k: row[k] for k in ('path', 'bytes', 'sha256')}
        assert exact == pin(exact['path'])
        if exact['path'] in guards:
            assert {k: guards[exact['path']][k] for k in exact} == exact
            return
        guards[exact['path']] = dict(exact, kind=kind, role=role or Path(exact['path']).name)

    # Preserve the frozen baseline's contracts as raw context only. Replace its
    # worker with the current worker; old baseline controls remain on that API.
    old_protocol = read(ROOT / 'fpc-h1-search-protocol-v1.json')
    for row in old_protocol['nonprotocol_guards']:
        if row['role'] == 'worker' or 'worker' in Path(row['path']).name:
            continue
        guard(row, row['kind'], {'search': 'baseline_search', 'bank': 'baseline_bank'}.get(row['role'], row['role']))
    for role, row in modules.items():
        guard(row, 'IMPORTED_SOURCE', role)
    guard(api['Source'], 'EXECUTED_SOURCE', 'worker')
    for path in [Path(worker_api_path), ROOT / 'fpc-h1-obligation-worker-Source-successor-v4.json',
                 ROOT / 'fpc-h1-obligation-worker-v3-v4.patch', *offers, *reviews, Path(__file__).resolve()]:
        guard(pin(path))
    for path in offers:
        for row in read(path)['files']:
            guard(row)
    semantic_paths = [
        'implementation-B/fpc-h1-obligation-first-producer-design-v2.json',
        'implementation-B/fpc-h1-obligation-plan-context-ABI-v1.json',
        'implementation-B/typed-obligation-worker-v4-and-custody-Source-peer-review-v1.json',
        'diagnostics-L/fpc-h1-obligation-independent-controls-handoff-v2.json',
        'diagnostics-L/fpc-h1-obligation-independent-controls-API-v2.json',
        'diagnostics-L/fpc-h1-obligation-independent-controls-manual-v2.json',
        'diagnostics-L/obligation-first-independent-input-declarations-v1.json',
        'diagnostics-L/obligation-first-independent-control-requirements-v1.json',
        'diagnostics-L/fpc-h1-obligation-controls-old56-applicability-v1.json',
        'diagnostics-L/obligation-control-population-composition-judgment-v1.json',
        'diagnostics-L/obligation-control-population-additive-INTRO-supplement-v1.json',
        'diagnostics-L/typed-FPC-H1-obligation-producer-search-component-Source-review-v2.json',
        'diagnostics-L/fpc-h1-obligation-intro-integration-API-v1.json',
        'diagnostics-L/fpc-h1-obligation-intro-integration-manual-v1.json',
        'diagnostics-L/fpc-h1-point-row-independent-controls-API-v1.json',
        'diagnostics-L/fpc-h1-point-row-independent-controls-manual-v1.json',
        'root/fpc-h1-point-row-reduction-contract-v1.json',
        'root/fpc-h1-point-row-public-API-v1.json',
        'root/FPC-H1-obligation-producer-Source-reading-v1.json',
        'root/FPC-H1-obligation-producer-Source-reading-v2.json',
        'review-C/typed-FPC-H1-obligation-independent-controls-component-Source-review-v2.json',
        'review-C/typed-FPC-H1-obligation-INTRO-integration-control-component-Source-review-v1.json',
        'review-C/typed-FPC-H1-point-row-adapter-component-Source-review-v2.json',
        'review-C/typed-FPC-H1-point-row-independent-controls-and-API-Source-review-v1.json',
        'review-C/typed-obligation-two-defect-additive-regression-proposal-review-v1.json',
    ]
    for rel in semantic_paths:
        guard(pin(BASE / rel))
    old_plan = read(ROOT / 'plans/search-fpc-h1-hi-point-not-line-0-v1.json')
    populations = {}
    for record in api['control_populations']:
        name = record['name']
        if name == 'baseline56':
            ids = old_plan['control_ids']
        elif name == 'point20':
            ids = read(BASE / 'diagnostics-L/fpc-h1-point-row-independent-controls-API-v1.json')['return']['control_ids']
        else:
            ids = record['control_ids']
        assert len(ids) == record['count'] and len(set(ids)) == len(ids)
        populations[name] = dict(record, control_ids=ids)
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    protocol_path = ROOT / 'fpc-h1-obligation-protocol-v1.json'
    closure_path = ROOT / 'fpc-h1-obligation-closed-inputs-v1.json'
    plan_path = ROOT / 'plans' / (CASE + '-v1.json')
    grant_path = ROOT / 'grants' / (CASE + '-v1.json')
    actual = BASE / 'actual' / CASE
    for path in [actual, Path(str(actual) + '.observer'), grant_path]:
        assert not path.exists()
    acyclic = 'Protocol guards only already-frozen raw inputs, never itself/closure/plan/grant/actual. Closure adds protocol; plan binds closure and same guards. Current whole and grant-proposal reviews remain external, later bound by a separate grant. No self-review cycles or recursive input discovery.'
    protocol = dict(
        schema='Root-FPC-H1-obligation-protocol-v1', status='FROZEN_SOURCE_ONLY_NO_EXECUTION_AUTHORITY',
        created_utc=now, case_id=CASE, experiment=api['experiment'], stage='evaluate',
        limits=api['caps'], module_pins=modules, worker=api['Source'], configuration=api['production_configuration'],
        control_populations=populations, prospective_control_groups=126, controls_run=0,
        ordering='FOCUSED', population='All original six unchanged. One distinct ordinary symbolic feasibility producer on manifest slot3, HI-point-not-line. Other five not run by this job. Earlier forward-search memory failure stays consumed, no proof/control prefix adopted.',
        target_index=3, target_id='HI-point-not-line', declarations=old_plan['declarations'],
        target_authority=old_plan['target_authority'], python=old_plan['python'],
        runner=old_protocol['runner'], observer=old_protocol['observer'],
        canonical_paths=dict(protocol=str(protocol_path), closure=str(closure_path), plan=str(plan_path), grant=str(grant_path), actual=str(actual)),
        nonprotocol_guards=list(guards.values()),
        closed_input_contract=dict(acyclicity=acyclic, nonprotocol_guard_count=len(guards), total_guard_count=len(guards)+1,
            no_discovery='Explicit raw guards only, stdlib/Darwin trusted substrate. No old actual/proof/library/policy inputs, network/Native input, uncharged query/proof generation, supplied target proof or theorem-specific branch.'),
        input_order=api['ordered_stages'], input_freeze=api['input_freeze'],
        discovery_scope='V8, nullaries/variables depth0, Tdepth2. W_fallback generated9 or root-source subformulas; W_priority adds goal/current local subformulas512. U512 or exact whole root-source exception, no goal-only exemption. INTRO depth8; exact occurrence contexts and grounded AND/OR obligations. Compiler/receptor intermediates use full finite FPC syntax and guards, not discovery bounds.',
        control_scope='Five namespaces, identity(population,id). Old56 only old baseline, new47+INTRO1+regression2 on new producer, point20 on adapter. Every full bank mandatory; no combined theorem/universal completeness/fairness claim.',
        candidate_admission=api['candidate_admission'], point_scope=api['point_scope'], failure=api['failure'],
        science_scope='Ordinary symbolic FOL search/compiler. HI is the explicit incidence profile, not full Hilbert geometry. Parametric point-row encoding only; no complete GCTS graph/dead-forced-generation/rollback, learned markings, RL or fixed finite universal Wang palette.',
        coverage_limits=['No formal global correctness/completeness/fair-service proof.', 'Priority descriptors retired EOF are not revived for later priority values; no exhausted/nonprovability result.', 'Necessary catalogs/obligations/compiler/snapshots may exceed unchanged caps. No performance/fit/advantage prediction.'],
        statuses=api['candidate_statuses'], authority='Whole independent current C plan/Source/closure and reject-only grant-proposal review, fresh all-tools-idle barrier, then separate once Root grant required. Complete terminal actual/resource/C review and separate Root disposition before any positive admission.',
        no_replay='Failure consumes this case. No retry/resume, cap/bank/scope shrink, accepted-prefix rescue, or old proof/library/policy/control adoption.',
        operations=dict(scientific_imports_calls=0, query_proof_generation=0, grants_actuals=0))
    protocol_pin = write(protocol_path, protocol)
    files = list(guards.values()) + [dict(protocol_pin, kind='RAW_PROTOCOL', role='protocol')]
    closure_pin = write(closure_path, dict(schema='Root-FPC-H1-obligation-closed-inputs-v1', status='FROZEN_SOURCE_ONLY', protocol=protocol_pin,
        files=files, guard_count=len(files), module_pins=modules, acyclicity=acyclic,
        trusted_substrate='Pinned isolated Python executable plus installed stdlib/Darwin; no hermetic/adversarial claim.', scientific_imports_calls=0))
    plan = dict(schema='proof-search-case-once-plan-v1', case_id=CASE, stage='evaluate', experiment=api['experiment'],
        actual_dir=str(actual), worker_path=api['Source']['path'], runner_path=old_plan['runner_path'], observer_path=old_plan['observer_path'],
        python=old_plan['python'], limits=api['caps'], protocol=protocol_pin, closed_inputs=closure_pin, files=files,
        module_pins=modules, configuration=api['production_configuration'], control_populations=populations,
        target_index=3, target_id='HI-point-not-line', declarations=old_plan['declarations'], target_authority=old_plan['target_authority'],
        required_upstream_ids=[], scope='One distinct fresh obligation-first feasibility job with all126 separately scoped controls and original limits; no launch/admission authority from this plan.')
    plan_pin = write(plan_path, plan)
    fields = dict(schema='Root-FPC-H1-obligation-once-execution-grant-v1', authorized=True, review_passed=True, uses=1,
        case_id=CASE, plan=plan_pin, plan_sha256=plan_pin['sha256'], runner_sha256=old_protocol['runner']['sha256'],
        future_execution_grant_path=str(grant_path), status='AUTHORIZED_ONCE_AFTER_CURRENT_C_AND_FRESH_IDLE_BARRIER',
        scope='One exact observer invocation, agents/browser/network/preview idle through terminal. Failure consumed. No partial bank/proof authority; complete whole actual and separate Root disposition required.')
    proposal_pin = write(ROOT / 'fpc-h1-obligation-grant-proposal-v1.json', dict(schema='Root-FPC-H1-obligation-once-grant-proposal-v1',
        status='PROSPECTIVE_CONTENT_ONLY_REJECT_ONLY', authorized=False, review_passed=False, uses=1, created_utc=now,
        execution_grant_fields=fields, execution_grant_extensions=['created_utc','proposal','whole_Source_plan_review','grant_component_review','fresh_tools_idle_barrier'],
        exact_final_construction='Copy execution_grant_fields unchanged and add only five named extensions after current exact complete C whole/plan and grant-proposal PASS plus fresh all-tools-idle barrier. Proposal flags deliberately reject execution.', no_grant_or_actual_created=True))
    print(json.dumps(dict(protocol=protocol_pin, closure=closure_pin, plan=plan_pin, proposal=proposal_pin, guard_count=len(files))))


if __name__ == '__main__':
    if len(sys.argv) != 7:
        raise SystemExit('usage: prepare_metadata WORKER_API PRODUCER_OFFER REGRESSION_OFFER PRODUCER_REVIEW REGRESSION_REVIEW WORKER_REVIEW')
    main(*sys.argv[1:])
