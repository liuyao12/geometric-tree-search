"""Display/package complete saved records only; no scientific imports or calls."""
from pathlib import Path
import hashlib
import html
import json
import zipfile

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021')
ROOT = BASE / 'root'
CASE = 'obligation-fpc-h1-hi-point-not-line-0'
ACTUAL = BASE / 'actual' / CASE
OUT = ROOT / 'obligation-report-v1'
PUBLISHER = BASE.parent / 'gcts-batch-20261020/publisher-recovery-6338a77'
PARENT = PUBLISHER / 'docs/research/gcts-rl-renewal/conditional-inventory/reader.html'


def read(path):
    assert '.partial' not in path.name
    return json.loads(path.read_bytes())


def identity(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def output(name, body):
    with (OUT / name).open('xb') as stream:
        stream.write(body)


def main():
    admission_path = ROOT / 'admission' / (CASE + '-v1.json')
    admission = read(admission_path)
    assert admission['status'] == 'FAILED_MEMORY_NOT_ADMITTED'
    assert admission['proof_admitted'] is False and admission['qualification_admitted'] is False
    failure = read(ACTUAL / 'failure.json')
    terminal = read(ACTUAL / 'terminal.json')
    observer = read(Path(str(ACTUAL) + '.observer') / 'observer.json')
    plan = read(ROOT / 'plans' / (CASE + '-v1.json'))
    assert failure['first_Root_fault'] is True and failure['error']['type'] == 'RootBudget'
    assert failure['scientific_result'] is None and observer['resource_candidate_accepted'] is False
    assert observer['final_conservative_whole_peak_bytes'] is None
    assert all(failure[k] is None for k in ('qualification_result', 'input_freeze', 'search_result',
                                          'subject_receipt', 'reference_receipt', 'point_receipt'))
    OUT.mkdir(exist_ok=False)
    data = dict(schema='GCTS-obligation-search-report-v1', case_id=CASE,
        status='FAILED_MEMORY_NOT_ADMITTED', target_id='HI-point-not-line',
        target_latex=r'\forall p\,(\operatorname{Pt}(p)\to\neg\operatorname{Ln}(p))',
        proof_admitted=False, qualification_admitted=False,
        candidate_certificate_saved=(ACTUAL / 'candidate-certificate.bin').exists(),
        worker_seconds=failure['elapsed_seconds'], worker_callbacks=failure['callbacks'],
        worker_observed_peak_bytes=failure['python_peak_bytes'],
        worker_postoutput_peak_bytes=terminal['header']['python_peak_after_output_bytes'],
        reaped_child_observed_peak_bytes=terminal['child_usage']['ru_maxrss'],
        observer_seconds=observer['elapsed_seconds'], qualified_whole_peak_bytes=None,
        limits=plan['limits'], controls=[dict(population=k, groups=plan['control_populations'][k]['count'],
            diagnostic_stage='COMPLETED', admitted=False) for k in
            ('baseline56','obligation47','intro_integration1','regression2','point20')],
        other_five_targets='UNCHANGED_NOT_RUN_BY_THIS_CASE',
        actual_raw_files=12, actual_raw_bytes=18134, partial_files=0,
        scope='Ordinary symbolic feasibility failure. No proof, qualified prefix, GCTS/RL effect, speedup, finite-palette or nonprovability claim.',
        allocation_scope='No per-structure allocation census saved. Stack location is not an allocation profile.',
        parallel_outcome='Independent reviews identified and Source-fixed reciprocal INTRO ownership and constructor first-fault/partial cleanup; two additive regression groups preserved existing124.')
    output('obligation-search-data-v1.json', (json.dumps(data,indent=2)+'\n').encode())
    members = {}

    def add(path, member):
        assert '.partial' not in path.name and member not in members
        members[member] = path.read_bytes()

    # Exact task-owned Sources/contracts only. Never redistribute the runtime
    # binary, unrelated checkout changes, Git state or application/account data.
    for row in plan['files']:
        path = Path(row['path'])
        if row['kind'] == 'PINNED_RUNTIME':
            continue
        body = path.read_bytes()
        assert identity(body) == {k:row[k] for k in ('bytes','sha256')}
        if path.is_relative_to(BASE):
            member = 'research/' + str(path.relative_to(BASE))
        elif path.name in ('run_conditional_once_v1.py','observe_conditional_once_v1.py'):
            member = 'custody/' + path.name
        elif row['role'] == 'primary_master':
            member = 'contracts/primary-master.md'
        elif row['role'] == 'Publisher_master':
            member = 'contracts/published-master.md'
        else:
            raise ValueError('undeclared external publication member')
        assert member not in members
        members[member] = body
    extras = [ROOT / 'plans' / (CASE+'-v1.json'), ROOT / 'fpc-h1-obligation-closed-inputs-v1.json',
        ROOT / 'fpc-h1-obligation-tools-idle-barrier-v1.json', ROOT / 'grants' / (CASE+'-v1.json'),
        ROOT / 'fpc-h1-obligation-once-terminal-observation-v2.json', admission_path,
        BASE / 'review-C/typed-FPC-H1-obligation-whole-prospective-Source-plan-review-v1.json',
        BASE / 'review-C/typed-FPC-H1-obligation-grant-proposal-component-review-v1.json',
        Path(admission['independent_actual_review']['path']),
        ROOT / 'obligation-report-inputs-v1.json', Path(__file__).resolve()]
    extra_offer = read(ROOT / 'obligation-report-inputs-v1.json')
    extras.extend(Path(x['path']) for x in extra_offer['postmortems'])
    for path in extras:
        member = 'research/' + str(path.relative_to(BASE))
        if member not in members:
            add(path, member)
    for folder, label in [(ACTUAL,'actual'),(Path(str(ACTUAL)+'.observer'),'observer')]:
        for path in sorted(folder.iterdir()):
            assert path.is_file() and '.partial' not in path.name
            add(path, label+'/'+path.name)
    manifest = dict(schema='GCTS-obligation-search-evidence-manifest-v1',
        scope='Complete selected task Sources and negative actual; no new execution, proof or prefix authority.',
        runtime_binary_omitted=plan['python'],
        members=[dict(member=k,**identity(v)) for k,v in sorted(members.items())])
    manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
    output('obligation-search-manifest-v1.json',manifest_bytes)
    with zipfile.ZipFile(OUT/'obligation-search-evidence-v1.zip','x',zipfile.ZIP_DEFLATED) as archive:
        for name, body in sorted(members.items()):
            info=zipfile.ZipInfo(name,(2026,10,22,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,body)
        archive.writestr('MANIFEST.json',manifest_bytes)
        archive.writestr('README.txt','Negative bounded feasibility study. No proof or positive control prefix admitted. Runtime binary is not redistributed. Do not execute Sources merely to view this archive.\n')
    with zipfile.ZipFile(OUT/'obligation-search-evidence-v1.zip') as archive:
        assert archive.testzip() is None
        for row in manifest['members']:
            assert identity(archive.read(row['member'])) == {k:row[k] for k in ('bytes','sha256')}
    control_rows=''.join('<tr><td><code>'+html.escape(x['population'])+'</code></td><td>'+str(x['groups'])+'</td><td>Completed diagnostically</td><td>Withheld</td></tr>' for x in data['controls'])
    page=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Obligation proof search: memory limit · GCTS research</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','noscript','style','pre','code']}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>:root{--ink:#203039;--muted:#596b72;--paper:#f7f5ef;--line:#d4dedd;--teal:#14776f;--orange:#a65316;--red:#ad3443}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.65 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:34px 22px 60px}h1{font-size:clamp(2.3rem,5vw,3.7rem);line-height:1.1;letter-spacing:-.04em;max-width:900px;margin:12px 0 23px}h2{line-height:1.25;font-size:1.55rem;margin:0 0 16px}.eyebrow{font-size:.76rem;letter-spacing:.12em;text-transform:uppercase;font-weight:750;color:var(--muted)}header{padding-bottom:24px;border-bottom:2px solid var(--ink)}.lead{font-size:1.15rem;max-width:890px}.panel{background:white;border:1px solid var(--line);border-radius:9px;padding:25px;margin-top:24px;min-width:0}.notice{border-left:4px solid var(--red);background:#fff0ed;padding:15px 18px}.small{font-size:.87rem;color:var(--muted)}a{color:#215f83;text-underline-offset:3px}nav{display:flex;gap:12px 23px;flex-wrap:wrap}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}.card{border-top:4px solid var(--teal);background:#f0f5f4;padding:18px}.card:nth-child(2){border-top-color:var(--orange)}.card:nth-child(3){border-top-color:#755299}h3{font-size:1.05rem;margin:0 0 12px}p{margin:0 0 16px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:.9rem}th,td{text-align:left;vertical-align:top;border-bottom:1px solid var(--line);padding:12px 10px}.formula{overflow-x:auto}code{font: .84em ui-monospace,SFMono-Regular,monospace;overflow-wrap:anywhere}.flow{width:100%;max-height:260px;margin:8px 0 15px}.flow text{font:15px system-ui,sans-serif;fill:var(--ink)}.flow .tiny{font-size:12px;fill:var(--muted)}footer{margin-top:30px;border-top:1px solid var(--line);padding-top:18px;font-size:.85rem;color:var(--muted)}@media(max-width:720px){main{padding:22px 14px}.panel{padding:18px}.grid{grid-template-columns:1fr}h1{font-size:2.6rem}th,td{padding:9px 7px}}</style></head><body><main>
<header><p class="eyebrow">22 October 2026 · parallel research · bounded negative result</p><h1>Obligation search still exceeds the memory budget</h1><p class="lead">The new symbolic search completed all five test stages, then hit the strict memory limit while searching for the geometry target. The complete run is unqualified. No proof or passing control prefix is admitted.</p><p class="notice"><strong>No discovered theorem from this attempt.</strong> This result establishes an engineering limitation of the current producer. It does not establish that the statement is unprovable, and it supplies no GCTS or RL advantage.</p><nav><a href="#outcome">The result</a><a href="#parallel">Agent contributions</a><a href="#controls">Test scope</a><a href="#next">What changes next</a><a href="#evidence">Evidence</a></nav></header>
<section class="panel" id="outcome"><h2>The unchanged target</h2><div class="formula">\[\forall p\,(\operatorname{Pt}(p)\to\neg\operatorname{Ln}(p)).\]</div><p>Every object classified as a point is not a line. This is a purely symbolic statement in the declared incidence profile; no coordinates, drawing or geometric oracle enters the search. The profile is a fragment of geometry, not all of Hilbert geometry.</p><p>The search receives the axioms and target, without a supplied target proof or lemma. The other five arithmetic and geometry targets remain unchanged and were not run by this case.</p>
<div class="scroll"><table><thead><tr><th>Observation</th><th>Saved value</th><th>Meaning</th></tr></thead><tbody>
<tr><td>Worker elapsed time</td><td>\(21.53\,\mathrm{s}\)</td><td>Imports, input freeze, controls and target search together.</td></tr><tr><td>Root callbacks</td><td>\(27\,771\,277\)</td><td>Whole worker count, not just theorem search.</td></tr><tr><td>Worker observed peak</td><td>\(1\,085\,112\,320\) bytes</td><td>Exceeds the strict \(1\,073\,741\,824\)-byte ceiling.</td></tr><tr><td>Reaped child peak</td><td>\(1\,104\,003\,072\) bytes</td><td>Later OS high-water observation; not a qualified whole-run bound.</td></tr><tr><td>Observer elapsed time</td><td>\(23.02\,\mathrm{s}\)</td><td>Overlapping outer clock; do not add it to the worker clock.</td></tr><tr><td>Qualified whole peak</td><td><code>null</code></td><td>No valid whole-memory result was admitted.</td></tr><tr><td>Proof and validators</td><td>No candidate saved</td><td>Search, proof-check and point-result payloads are null.</td></tr></tbody></table></div><p class="small">The failure stack ends at a callback in obligation registration. This identifies where the ceiling was detected. It does not identify the allocating data structure. No detailed allocation census was saved.</p></section>
<section class="panel" id="parallel"><h2>What parallel agents contributed</h2><div class="grid"><article class="card"><h3>Implementation</h3><p>Built the obligation search and compiler for local assumptions. Corrected assumption-context ownership and cleanup of partially constructed search state.</p></article><article class="card"><h3>Independent tests</h3><p>Prepared checks from the public contract and added two regressions for the defects found. Existing test inputs and expectations were preserved.</p></article><article class="card"><h3>Critical review</h3><p>Read the code and contracts independently, challenged the two defects, and reviewed the exact bounded run and its negative outcome.</p></article></div>
<svg class="flow" viewBox="0 0 900 190" role="img" aria-label="Parallel implementation, test and review work converge on one isolated experiment, which stops at its memory ceiling."><g fill="#edf4f3" stroke="#8ca6a3"><rect x="25" y="12" width="245" height="48" rx="7"/><rect x="327" y="12" width="245" height="48" rx="7"/><rect x="630" y="12" width="245" height="48" rx="7"/></g><g text-anchor="middle"><text x="148" y="42">Implementation</text><text x="450" y="42">Independent tests</text><text x="752" y="42">Critical review</text></g><path d="M148 60V82H450V100M450 60V100M752 60V82H450" fill="none" stroke="#78938f" stroke-width="2"/><rect x="270" y="100" width="360" height="70" rx="8" fill="#fff0ed" stroke="#ad3443"/><text x="450" y="128" text-anchor="middle">One isolated experiment</text><text class="tiny" x="450" y="153" text-anchor="middle">Stopped at the memory ceiling; no proof admitted</text></svg><p>Root integrates the work, runs the experiment and publishes the checked record. Parallel development improves research throughput. Timed experiments remain isolated; agent concurrency is not a proof-search speedup.</p></section>
<section class="panel" id="controls"><h2>Five separate test populations</h2><div class="scroll"><table><thead><tr><th>Population</th><th>Groups</th><th>Saved stage observation</th><th>Whole-run qualification</th></tr></thead><tbody>__CONTROL_ROWS__</tbody></table></div><p>The saved record shows all five stages completed before target search. Their complete positive payloads were withheld after the whole memory failure. These observations are not an admitted claim that 126 checks passed.</p><p>The original baseline tests apply to the original baseline. New producer tests and point-representation tests retain their own scopes. No result transfers automatically to all search orders, all formulas or a full GCTS engine.</p></section>
<section class="panel" id="next"><h2>The next contribution to test</h2><p>The current program is ordinary symbolic proof search. Its point-row adapter supplies a representation with distant premise markings; it does not yet supply a complete GCTS frontier–candidate graph, global propagation, generation order, rollback, learned markings or trained RL.</p><p>A useful next direction is schematic receptor and lemma families that can be instantiated and expanded into independently checked primitive rows. This should be tested against explicit search baselines, including all construction and verification costs. The present result gives no evidence that such an inventory is already effective.</p><p>Before choosing the next implementation, collect a bounded, non-authoritative census of retained obligations, contexts, catalog entries and descriptors in a distinct declared study. Source inspection suggests several possible growth paths; without that census, naming one as the cause would be speculation.</p><p>This attempt remains consumed. No retry, larger budget, smaller target or accepted-prefix rescue is used. <a href="fpc-h1-point-markings-v1.html#marks">See the existing marking construction</a> and <a href="fpc-h1-search-v1.html#outcome">the separate earlier forward-search failure</a>. These are different producers, not a controlled speed comparison.</p></section>
<section class="panel" id="evidence"><h2>Inspect the complete record</h2><p><a href="obligation-search-evidence-v1.zip">Source, review and negative-run bundle</a> · <a href="obligation-search-manifest-v1.json">Raw manifest</a> · <a href="obligation-search-data-v1.json">Compact result data</a></p><p>The archive preserves the complete saved actual and observer files, the exact code and contracts, independent reviews and Root disposition. It contains no candidate proof. The runtime binary is omitted and identified by hash. No scientific code is executed by this page.</p><p class="small">A dataless iCloud-backed contract caused a preflight read timeout before any grant or experiment. Local access was restored and every pinned input rechecked before launch. This access recovery is separate from the later, observed search-memory failure. OS file-cache state was not controlled.</p><p><a href="reader.html#obligation-search-v1">Research progress notebook</a></p></section><footer>A corrected implementation, a completed diagnostic stage, a checked discovered proof and a demonstrated GCTS/RL advantage remain distinct claims.</footer></main></body></html>'''
    page=page.replace('__CONTROL_ROWS__',control_rows)
    output('obligation-search-v1.html',page.encode())
    parent=PARENT.read_bytes()
    assert identity(parent)==dict(bytes=138872,sha256='0cb4eb26bffcc4ef683b802729fb003f281a3b03edd63e463428ad1599122746')
    insertion=b'''\n<section id="obligation-search-v1" style="margin:28px auto;padding:24px;max-width:1080px;border:1px solid #d4dedd;background:#fff"><h2>Parallel proof-search experiment: memory limit</h2><p>The obligation-first producer completed five test stages diagnostically, then exceeded the unchanged memory ceiling on the incidence-geometry target. The whole run is unqualified; no proof or passing test prefix is admitted. Independent agents corrected two code defects and reviewed this negative result.</p><p><a href="obligation-search-v1.html#outcome">Read the result, agent contributions and complete evidence</a></p></section>\n'''
    at=parent.rfind(b'</body>');assert at>=0
    output('reader.html',parent[:at]+insertion+parent[at:])
    inventory=[dict(name=p.name,**identity(p.read_bytes())) for p in sorted(OUT.iterdir())]
    print(json.dumps(dict(output=str(OUT),files=inventory,archive_raw_members=len(members),archive_raw_bytes=sum(map(len,members.values())),parent_preimage=identity(parent))))


if __name__=='__main__':
    main()
