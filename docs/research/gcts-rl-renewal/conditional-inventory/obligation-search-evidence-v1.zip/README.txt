Negative bounded feasibility study. No proof or positive control prefix admitted. Runtime binary is not redistributed. Do not execute Sources merely to view this archive.
