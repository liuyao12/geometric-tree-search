"""Independent Root consumer delta review: raw/AST/compile/inert text only."""
import ast,copy,difflib,hashlib,json,subprocess
from pathlib import Path
O=Path('/private/tmp/gcts-schema-admission-peer-20261019');R=Path('/private/tmp/gcts-schema-admission-ROOT-source-20261019');checks=[];retained=[];patches=[]
def ck(k,v):
    checks.append(dict(check=k,passed=bool(v)))
    if not v:raise AssertionError(k)
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def write(name,v):
    p=O/name
    with p.open('xb')as f:f.write((json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    return pin(p)
def dump(n):return ast.dump(n,include_attributes=False)
def top(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def region(b,n):return b''.join(b.splitlines(True)[n.lineno-1:n.end_lineno])
def contains(v,s):
    if v==s:return True
    if type(v)is dict:return any(contains(x,s)for x in v.values())
    if type(v)is list:return any(contains(x,s)for x in v)
    return False
contract=pin(R/'consumer-gate-Source-contract-v1.json');c=json.loads(Path(contract['path']).read_bytes())
ck('Root Source-only immutable3gate contract',c['schema']=='ROOT-schema-admission-consumer-gate-Source-contract-v1'and c['author_identity']=='/root'and c['source_only']is True and c['scientific_calls']==c['module_evaluations']==0 and len(c['changes'])==3)
sources={};parents={};gate_regions={};summaries={}
expected_gate=ast.parse('''def _inventory_admission_ready(inventory):
    if inventory.get('status') == 'native_accepted':
        return True
    c = inventory.get('certification')
    return (inventory.get('status') == 'schema_admitted' and type(c) is dict
            and c.get('schema') == 'schema-then-native-inventory-certification-v1'
            and c.get('version') == 'inventory-schema-then-native-v1'
            and c.get('mode') == 'schema_then_native'
            and c.get('complete') is True and c.get('Model_permission') is True
            and c.get('native_accepted') is False
            and c.get('fresh_Native_target_proof_accepted') is False
            and c.get('final_whole_Native_required') is True)
''').body[0]
for change in c['changes']:
    role=change['role'];sources[role]=change['current'];parents[role]=change['origin'];new=Path(change['current']['path']).read_bytes();old=Path(change['origin']['path']).read_bytes();nt=ast.parse(new);ot=ast.parse(old);nd=top(nt);od=top(ot)
    ck(role+' current whole raw pin',pin(change['current']['path'])==change['current']);ck(role+' parent whole raw pin',pin(change['origin']['path'])==change['origin'])
    ck(role+' same complete import AST',[dump(n)for n in nt.body if isinstance(n,(ast.Import,ast.ImportFrom))]==[dump(n)for n in ot.body if isinstance(n,(ast.Import,ast.ImportFrom))])
    ck(role+' isolated gate exact strict AST',dump(nd['_inventory_admission_ready'])==dump(expected_gate));gate_regions[role]=region(new,nd['_inventory_admission_ready'])
    ck(role+' only declared new helper names',set(nd)-set(od)==({'_inventory_admission_ready','_inventory_admission_projection'}if role=='support'else{'_inventory_admission_ready'})and not(set(od)-set(nd)))
    compile(new,change['current']['path'],'exec',dont_inherit=True);ck(role+' compile without evaluation',True)
    changed=[]
    for name,n in od.items():
        if dump(n)==dump(nd[name]):ck(role+'.'+name+' raw/AST retained',region(old,n)==region(new,nd[name]));retained.append(role+'.'+name)
        else:changed.append(name)
    ck(role+' changed body inventory exact',changed==({'model':['Model'],'symbolic':['_intake'],'support':['build_support_graph']}[role]))
    inverse=copy.deepcopy(nt)
    inverse.body=[n for n in inverse.body if not(isinstance(n,ast.FunctionDef)and n.name in ('_inventory_admission_ready','_inventory_admission_projection'))and not(isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='SCHEMA_ADMISSION_GATE_VERSION'for x in n.targets))]
    idict=top(inverse)
    if role=='model':
        # The only original class-body deltas are one guard expression and a
        # schema-only provenance branch. Inverse via old AST never evaluates it.
        nm={n.name:n for n in idict['Model'].body if isinstance(n,ast.FunctionDef)};om={n.name:n for n in od['Model'].body if isinstance(n,ast.FunctionDef)}
        ck('Model exact original methods only',set(nm)==set(om)=={'__init__','record'})
        ni=nm['__init__'];oi=om['__init__'];ck('Model constructor only gate AST changed',len(ni.body)==len(oi.body)and sum(dump(a)!=dump(b)for a,b in zip(ni.body,oi.body))==1)
        for j,(a,b)in enumerate(zip(ni.body,oi.body)):
            if dump(a)!=dump(b):
                ck('Model constructor gate at original validation position',j==1 and isinstance(a,ast.If)and isinstance(b,ast.If)and dump(a.body)==dump(b.body)if False else j==1 and isinstance(a,ast.If)and isinstance(b,ast.If)and [dump(x)for x in a.body]==[dump(x)for x in b.body]);ni.body[j]=copy.deepcopy(b)
        nr=nm['record'];orr=om['record'];ck('Model record only one schema-only provenance branch',len(nr.body)==len(orr.body)+1 and isinstance(nr.body[-2],ast.If)and ast.unparse(nr.body[-2].test)=="self.inventory['status'] == 'schema_admitted'")
        provenance=nr.body[-2];ck('Model new metadata no Native-laundering and exact scope correction',len(provenance.body)==2 and "r['inventory_admission']"in ast.unparse(provenance.body[0])and 'native_accepted=False'in ast.unparse(provenance.body[0])and 'final_whole_Native_required=True'in ast.unparse(provenance.body[0])and 'Every actual block requires native checking.'in ast.unparse(provenance.body[1])and 'fresh whole Native checking.'in ast.unparse(provenance.body[1]))
        nr.body.pop(-2);ck('Model native record whole AST unchanged after removing schema branch',dump(nr)==dump(orr))
        # Only documentation has changed outside declared helpers/class deltas.
        ck('Model module docstring is sole other AST delta',isinstance(inverse.body[0],ast.Expr)and isinstance(inverse.body[0].value,ast.Constant));inverse.body[0]=copy.deepcopy(ot.body[0])
    elif role=='symbolic':
        nn=idict['_intake'];oo=od['_intake'];ck('symbolic intake same statement count',len(nn.body)==len(oo.body));changed_stmts=[j for j,(a,b)in enumerate(zip(nn.body,oo.body))if dump(a)!=dump(b)];ck('symbolic only one admission branch change',len(changed_stmts)==1)
        for j in changed_stmts:
            ck('symbolic unchanged False-return branch',isinstance(nn.body[j],ast.If)and [dump(x)for x in nn.body[j].body]==[dump(x)for x in oo.body[j].body]);nn.body[j]=copy.deepcopy(oo.body[j])
    else:
        projection=nd['_inventory_admission_projection'];txt=ast.unparse(projection)
        ck('support projection original full four fields retained',"('status', 'definitions', 'interfaces', 'native_blocks')"in txt)
        ck('support projection8scalar certificate fields exact',"('schema', 'version', 'mode', 'complete', 'Model_permission', 'native_accepted', 'fresh_Native_target_proof_accepted', 'final_whole_Native_required')"in txt)
        ck('support projection schema-only branch no wholecertcopy',"inventory.get('status') == 'schema_admitted'"in txt and 'type(c) is dict else None'in txt and len(projection.body)==3)
        nn=idict['build_support_graph'];oo=od['build_support_graph'];ck('support graph same original statement count',len(nn.body)==len(oo.body));changed_stmts=[j for j,(a,b)in enumerate(zip(nn.body,oo.body))if dump(a)!=dump(b)];ck('support only projection+gate2 statements changed',len(changed_stmts)==2)
        for j in changed_stmts:nn.body[j]=copy.deepcopy(oo.body[j])
    ck(role+' whole inverse AST equals parent',dump(inverse)==dump(ot))
    d=O/('gate-'+role+'-F0');d.mkdir();target=d/'subject.txt';target.write_bytes(old)
    for direction,a,b in [('forward',old,new),('inverse',new,old)]:
        p=d/(direction+'.patch');p.write_text(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='subject.txt',tofile='subject.txt')))
        result=subprocess.run(['/usr/bin/patch','--batch','--fuzz=0','subject.txt','-i',str(p)],cwd=d,capture_output=True,text=True,timeout=10)
        ck(role+' actual inert '+direction+'F0',result.returncode==0 and target.read_bytes()==b);patches.append(dict(role=role,direction=direction,patch=pin(p),stdout=result.stdout,stderr=result.stderr))
    summaries[role]=dict(retained_top_names=[n for n in od if n not in changed],changed_top_names=changed,whole_inverse_AST_equal=True)
ck('all3 gate function raw bodies identical',len(set(gate_regions.values()))==1)
genuine_order=pin('/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json');genuine_model=pin('/private/tmp/gcts-quantified-independent-peer-20261018/typed-adapter-Source-review-v2.json')
ov=json.loads(Path(genuine_order['path']).read_bytes());mv=json.loads(Path(genuine_model['path']).read_bytes())
for label,review in [('ordering',ov),('model',mv)]:ck(label+' genuine inherited distinct Sourcepeer',review['reviewer_identity']=='/root/receiver_driver_review'and review['source_review_passed']is True and review['source_only']is True and review['scientific_calls']==0)
for role in ('support','symbolic'):ck(role+' genuine inherited full raw subject',contains(ov,parents[role]))
ck('Model genuine inherited fullraw subject',contains(mv,parents['model']))
audit=write('consumer-gate-raw-audit-v1.json',dict(schema='schema-admission-consumer-gate-independent-raw-audit-v1',source_only=True,scientific_calls=0,checks=checks,current_sources=sources,parent_sources=parents,source_contract=contract,retained_raw_AST_regions=retained,per_source=summaries,inert_F0=patches,identical_gate_function_raw=True))
review=dict(schema='schema-admission-consumer-gate-typed-Source-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',source_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,project_imports=0,native_calls=0,model_calls=0,compiler_calls=0,solver_calls=0,search_calls=0,fixture_calls=0,codec_calls=0,renderer_calls=0,scope='Distinct review of Root-authored admission predicate, schema-only support projection and Model provenance deltas; not a fresh independent review of inherited reviewer-authored algorithms',sources=sources,parent_sources=parents,source_contract=contract,design_obligations=pin(O/'design-soundness-and-admission-obligations-v1.json'),gate_design_addendum=pin(O/'consumer-gate-design-addendum-v1.json'),inherited_genuine_ordering_peer=genuine_order,inherited_genuine_Model_peer=genuine_model,check_count=len(checks),mismatch_count=0,compile_without_evaluation=3,inert_F0_directions=6,retained_top_raw_AST_regions=len(retained),all3_whole_inverse_AST_parent_equal=True,audit=audit,review_Source=pin(Path(__file__)),findings=[dict(id='EXPLICIT_STRICT_ADMISSION',finding='All three identical new predicates retain native_accepted True historical path; otherwise require exact schema/version/mode and strict complete/Modelpermission true, Native/fresh-target flags false and final-Native-required true. They do not relabel status or claim to check mathematical certificates.'),dict(id='ALGORITHM_PRESERVATION',finding='Whole successor AST inverses equal exact parents after removing only explicit gate/projection/provenance changes and Model documentation. Every remaining top helper is raw/AST equal. Model constructor generation and derived arity, all symbolic skeleton/guard/enumeration/padding/search bodies and support relaxation/ranking bodies remain unchanged.'),dict(id='SCHEMA_PROJECTION_AND_MODEL_METADATA',finding='Support retains all four historical full inventory fields; only new schema status adds the eight scalar gate provenance fields, never full repeated certificates in graph metadata. Model adds admission provenance and corrects pre-search Native wording only for schema status; removing that branch restores the entire old record AST, preserving native record values.'),dict(id='CONSUMER_TRUST_BOUNDARY',finding='These shallow predicates consume a registry permission. New Library registry and Root driver must authenticate/rebuild complete original policy/ground coverage, theory/Source/certificates/current Native fallback and all-or-none permission. This review does not substitute for those separate Source reviews or future actual Native/point/resource admission.')],limitations=[
 'Only raw/AST Source reasoning, three compile-without-evaluation checks and six genuine inert text-patch directions occurred. No predicate, constructor, algorithm, fixture, Native/kernel/Model/compiler/solver/search/Reader/renderer/codec or scientific module was executed or imported. No runtime truth-table/test or performance result is claimed.',
 'Reviewer authored inherited support/symbolic algorithms and inherited outer/broker/earlier drivers, while Root authored this new minimal gate/projection/provenance delta. Retained own algorithm bodies rely on the genuine distinct Receiver84c Source peer and exact raw/AST equality; inherited Model relies on Receiver3d8b peer. This is not a fresh self-independent algorithm Source certificate.',
 'The predicates intentionally do not independently establish full registry identity, coverage, provenance, Source epoch or certificate soundness. Driver/registry authenticated custody and complete original coverage are necessary preconditions; a forged Boolean packet outside that protected boundary is not mathematically validated by these consumers.',
 'Logical implementation VERSION strings remain those of exact parent algorithms; the added SCHEMA_ADMISSION_GATE_VERSION and complete raw Source descriptors/epoch distinguish this delta. Runtime import aliases must resolve to these exact new files in both methods, including the unchanged compact Model wrapper importing the revised ordinary alias. Pending Root cold/driver/closure review must verify that coupling.',
 'The inherited support docstring still describes native-admitted inputs, but the explicit new gate and Source contract extend this consumer to completed schema admission. This is a disclosed new trust context, not Native acceptance. No full certificate duplication into heuristic metadata means the graph retains gate provenance only; full authority packets remain required in registry/driver evidence.',
 'Same full candidates/markings/Model scope conditional on valid completed schema inventory. Old native_accepted record behavior remains exact, while schema-only admission provenance necessarily changes metadata. Full current semantic/literal comparisons and final fresh Native/proof/point/resource gates remain Root actual obligations. No formal schema theorem, theorem discovery, speed/GCTS advantage, RL or activation is established.'
])
r=write('typed-consumer-gate-Source-review-v1.json',review)
h=write('consumer-gate-peer-handoff-v1.json',dict(schema='schema-admission-consumer-gate-peer-handoff-v1',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=r,audit=audit,sources=sources,source_contract=contract))
print(json.dumps(dict(review=r,audit=audit,handoff=h,checks=len(checks)),indent=2))
