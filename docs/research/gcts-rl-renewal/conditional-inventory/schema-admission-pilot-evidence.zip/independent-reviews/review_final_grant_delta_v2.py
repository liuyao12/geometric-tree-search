"""Narrow raw saved-metadata delta only; no scientific imports or execution."""
import hashlib
import json
import stat
from pathlib import Path

D=Path('/private/tmp/gcts-schema-admission-ROOT-20261019');OUT=Path('/private/tmp/gcts-schema-admission-peer-20261019')
checks=[];verified={};raws={}
def ck(k,v,detail=None):
    checks.append(dict(check=k,passed=bool(v),detail=detail))
    if not v:raise AssertionError(k)
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(d,label):
    ck(label+' complete descriptor',type(d)is dict and set(d)=={'path','sha256','bytes'}and type(d['path'])is str and type(d['bytes'])is int and d['bytes']>0 and type(d['sha256'])is str and len(d['sha256'])==64)
    p=Path(d['path']);s=p.lstat();ck(label+' canonical regular nonsymlink',p.is_absolute()and p==p.resolve()and stat.S_ISREG(s.st_mode)and not p.is_symlink())
    if d['path']not in verified:
        b=p.read_bytes();ck(label+' whole raw pin',dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==d);verified[d['path']]=d;raws[d['path']]=b
    else:ck(label+' unchanged reused literal pin',verified[d['path']]==d)
    return raws[d['path']]
def get(d,label):return json.loads(load(d,label))
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def contains(v,d):return v==d or(type(v)is dict and any(contains(x,d)for x in v.values()))or(type(v)is list and any(contains(x,d)for x in v))
def write(n,v):
    p=OUT/n
    with p.open('xb')as f:f.write((json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    return pin(p)

newd=dict(path=str(D/'plans-v2/authorized-index-v2.json'),sha256='48501b3c2db109b9da4ab592078d47d9e43ad5a5f7d738281c1da6615012cf01',bytes=10346)
oldd=dict(path=str(D/'plans-v2/prospective-index-v2.json'),sha256='551700c4ff8d0aeaa92ef4a7218c43f425ebd95a6f23e160152589b54c1c2824',bytes=7285)
adoptd=dict(path=str(D/'ROOT-final-grant-adoption-v2.json'),sha256='ca0b3800c2676268ecf54480a32114cddfec2041eb63a29ea0e088d8b93c2dba',bytes=2865)
peerd=dict(path=str(OUT/'typed-prospective-review-v2.json'),sha256='320667213fd85a532d965de8af930e57a32081822eb007a86127e5fccd538c28',bytes=30245)
new=get(newd,'authorized index');old=get(oldd,'reviewed false index');adopt=get(adoptd,'Root adoption');peer=get(peerd,'exact false prospective PASS')
ck('exact prospective PASS subject',peer['prospective_review_passed']is True and peer['prospective_index']==oldd and peer['scientific_calls']==0 and peer['scientific_acceptance']is False and peer['actual_execution_authorized']is False)
ck('index only authorized schema/flag/schedule plus role/scope/started metadata',set(new)-set(old)=={'current_review_roles','actuals_started','scope'}and not(set(old)-set(new))and {k for k in old if old[k]!=new[k]}=={'schema','actual_execution_authorized','schedule'})
ck('true index Root metadataonly two unstarted subjects',new['schema']=='ROOT-schema-admission-authorized-index-v1'and new['author_identity']=='/root'and new['actual_execution_authorized']is True and new['actuals_started']==0 and new['scientific_calls']==0 and new['source_only']is True and new['subject_count']==2)
ck('adoption current exact index/falseindex/no actuals',adopt['schema']=='ROOT-schema-admission-final-grant-adoption-v1'and adopt['author_identity']=='/root'and adopt['authorized_index']==newd and adopt['false_index']==oldd and adopt['actuals_started']==0 and adopt['source_only']is True and adopt['scientific_calls']==0 and adopt['scientific_acceptance']is False and adopt['maximum_actual_invocations_per_subject']==1)
roles=dict(old['current_Source_reviews'],prospective_plans=peerd)
ck('exact seven current review roles identical index/adoption',new['current_review_roles']==roles==adopt['current_review_roles']and len(roles)==7 and len({d['sha256']for d in roles.values()})==6 and roles['composition_Source']==roles['once_Source'])
contract=get(old['intake_Source_contract'],'unchanged role ABI contract')
reviewobjects={k:get(d,'exact scoped role '+k)for k,d in roles.items()}
for role,obj in reviewobjects.items():
    schema,passkey,reviewer=contract['current_review_roles'][role]
    ck('exact schema/pass/reviewer/Source-only flags '+role,obj['schema']==schema and obj[passkey]is True and obj['reviewer_identity']==reviewer and obj['author_identity']!=obj['reviewer_identity']and obj['source_only']is True and obj['scientific_calls']==0 and obj['scientific_acceptance']is False and obj['actual_execution_authorized']is False)
ck('two reviewer identities disclosed not seven',set(v['reviewer_identity']for v in reviewobjects.values())=={'/root/conventional_control_review','/root/receiver_driver_review'}and 'two reviewer identities'in adopt['disclosure'])
subjects=[];fresh=[];plans=[]
for pos,(o,n)in enumerate(zip(old['schedule'],new['schedule']),1):
    ck('schedule exact old fields plus new auth/runner '+str(pos),set(n)-set(o)=={'authorization','runner_plan'}and all(n[k]==v for k,v in o.items()))
    worker=get(n['worker_plan'],'unchanged worker '+str(pos));before=get(o['runner_plan_draft'],'false once '+str(pos));after=get(n['runner_plan'],'true once '+str(pos));af=get(o['authorization_draft'],'false authorization '+str(pos));at=get(n['authorization'],'true authorization '+str(pos))
    ck('worker whole pin and full body matches prospective review '+str(pos),n['worker_plan']==peer['full_schedule'][pos-1]['worker_plan']and contains(peer,n['worker_plan']))
    ck('runner only authorization descriptor changed '+str(pos),set(after)==set(before)and {k for k in before if before[k]!=after[k]}=={'authorization'}and after['authorization']==n['authorization'])
    subject_before={k:v for k,v in before.items()if k!='authorization'};subject_after={k:v for k,v in after.items()if k!='authorization'};sha=hashlib.sha256(canon(subject_after)).hexdigest()
    expectedsha=('8f2c3c65c65f7b64cda7418aacab11f6f8ec37112fc4070d514b28986ecbd55a'if pos==1 else'2ae64f5faa9b6e6e5a9bf59d85fc7be73af2fca76f34f7fb26916b1d275f8169')
    ck('literal full18subject preserved '+str(pos),len(subject_after)==18 and subject_before==subject_after and sha==o['subject_sha256']==n['subject_sha256']==af['subject_sha256']==at['subject_sha256']==expectedsha)
    ck('auth exact7fields and only permitted true/max1/roles/scope '+str(pos),set(at)==set(af)and {k for k in at if at[k]!=af[k]}=={'actual_execution_authorized','maximum_actual_invocations','review_roles','scope'}and af['actual_execution_authorized']is False and af['maximum_actual_invocations']==0 and af['review_roles']=={}and at['actual_execution_authorized']is True and type(at['maximum_actual_invocations'])is int and at['maximum_actual_invocations']==1 and at['author_identity']=='/root')
    ck('same fixedthen symbolic choices/caps/Source/fullinput '+str(pos),n['order']==pos and n['mode']==('fixed'if pos==1 else'symbolic')and n['inventory_certification_mode']=='schema_then_native'and n['search_ordering']=='and_support'and n['receiver_id']=='prospective-fol-20261018-002'and after['worker_plan']==n['worker_plan']and after['runtime_closure']==old['runtime_closure']and after['integration_declaration']==old['case_declaration'])
    a=worker['project_sources'];component=worker['components'];cert=old['schema_sources']['mp_schema_certificate']
    expected={
      'retained_ordering_Source':list(contract['retained_ordering_subjects'].values()),
      'consumer_gates_Source':[a[k]for k in ('quantified_family_points_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],
      'registry_Source':[a['semantic_inventory_oracle'],cert],
      'driver_Source':[component['receiver_driver'],a['semantic_inventory_oracle'],cert],
      'composition_Source':[old['cold'],component['receiver_driver'],cert],
      'once_Source':[old['runner'],old['observer']],
      'prospective_plans':[old['case_declaration'],old['runtime_closure'],n['worker_plan']]}
    ck('all seven authorization role names exact '+str(pos),set(at['review_roles'])==set(roles))
    for role,subjects_required in expected.items():
        v=at['review_roles'][role];obj=reviewobjects[role]
        ck('exact role packet receipt reviewer/fullsubjects '+str(pos)+' '+role,set(v)=={'receipt','reviewer_identity','required_subjects'}and v['receipt']==roles[role]and v['reviewer_identity']==obj['reviewer_identity']and v['required_subjects']==subjects_required)
        for d in subjects_required:
            load(d,'current required raw subject '+str(pos)+' '+role+' '+Path(d['path']).name)
            ck('literal complete subject in scoped receipt '+str(pos)+' '+role+' '+Path(d['path']).name,contains(obj,d))
    actual=Path(n['actual_directory']);paths=[actual,actual/'CONSUMED.json',actual/'result.json',actual/'worker-receipt.json',actual/'runner-receipt.json',Path(n['runner_plan']['path']).parent/(n['invocation_id']+'-terminal-observation'),Path(o['runner_plan_draft']['path']).parent/(n['invocation_id']+'-terminal-observation')]
    for p in paths:ck('still fresh absent '+str(p),not p.exists())
    fresh.extend(map(str,paths));subjects.append(sha);plans.append(dict(worker_plan=n['worker_plan'],runner_plan=n['runner_plan'],authorization=n['authorization'],full_authorization=at,full_subject_preimage=subject_after,subject_sha256=sha))
ck('adoption both independently derived exact subjects',adopt['subjects']==subjects and adopt['both_exact18field_subjects_unchanged']is True)
ck('prior V1 false candidate remains unlaunched',not(D/'actual-fixed-v1').exists()and not(D/'actual-symbolic-v1').exists()and not(D/'plans/authorized-index-v1.json').exists())
audit=write('final-grant-delta-raw-audit-v2.json',dict(schema='schema-admission-final-grant-delta-raw-audit-v1',source_only=True,scientific_calls=0,checks=checks,verified_raw_descriptors=list(verified.values()),all_plans=plans,fresh_paths=fresh))
review=write('typed-final-grant-delta-review-v2.json',dict(schema='schema-admission-final-grant-delta-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',final_grant_delta_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,authorized_index=newd,prospective_index=oldd,prospective_review=peerd,Root_adoption=adoptd,full_schedule=new['schedule'],subjects=subjects,subject_field_count=18,current_review_roles=roles,check_count=len(checks),mismatch_count=0,unique_raw_pin_count=len(verified),audit=audit,review_Source=pin(Path(__file__)),findings=[],conclusions=[
    'Both complete18-field canonical subjects are literally unchanged from the exact V2 false subjects. Every worker plan remains byte-pinned unchanged. Each runner plan differs only in its authorization descriptor.',
    'Both authorizations retain exact seven-field grammar and change only false0 to true1, the explicit Root scope and seven complete current review roles. Role schema/pass/reviewer/rawpin/fullsubject containment was checked externally, including registry+certifier, driver+registry+certifier, all three new consumer gates, retained ordering ancestry and the prospective declaration/closure/current worker.',
    'Seven roles use six distinct receipts and two reviewer identities; composition and once intentionally share the same intake receipt. This does not imply seven independent reviewers. The unchanged certifier authority and former Source ancestry remain separately scoped.',
    'Fixedfirst then symbolic, full case002/all38definitions, current25Sources and all common inputs/caps remain exact in the unchanged subjects. Both actual, consumed/result/receipt and observer directories are absent. Prior V1 false candidate remains unlaunched.'
],limitations=[
    'Narrow saved-metadata/raw-hash review only. No scientific/project module, Native, Model, compiler, solver, search, Reader, renderer, fixture or opaque codec evaluation; no execution/grant/launch was performed by reviewer. This receipt is not launch authorization or scientific acceptance.',
    'Reviewer authored inherited outer/broker and earlier driver/helper/symbolic/benchmark/checker components. Current Root/Library Source edits and exact genuine Receiver ordering ancestry are separately reviewed; this delta does not self-certify inherited own algorithms or kernel soundness.',
    'Source-only and prospective trust/cost/fairness limitations remain. Runtime custody, current all-ground complete schema permission, final fresh Native/point/wholeproof, once consumption and180/210/1GiB/128MiB/log/lifecycle gates require retained actual admission. No fit/success, theorem, speed/RL/GCTS superiority or goal completion is inferred.',
    'All tools stop after this frozen receipt. Reviewer remains idle during the two serial timed actuals until Root explicitly reports cohort closure.'
]))
handoff=write('final-grant-delta-handoff-v2.json',dict(schema='schema-admission-final-grant-delta-peer-handoff-v1',review=review,audit=audit,authorized_index=newd,subjects=subjects,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False))
print(json.dumps(dict(review=review,audit=audit,handoff=handoff,checks=len(checks),raw_pins=len(verified)),indent=2))
