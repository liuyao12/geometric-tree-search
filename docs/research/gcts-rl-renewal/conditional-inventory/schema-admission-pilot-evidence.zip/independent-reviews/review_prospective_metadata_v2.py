"""Raw metadata / AST audit only; never imports or evaluates scientific Sources."""
import ast
import collections
import hashlib
import json
import stat
import sys
from pathlib import Path

OUT=Path('/private/tmp/gcts-schema-admission-peer-20261019')
index_path=Path(sys.argv[1]);tag=sys.argv[2]
checks=[];verified={};raws={}
def check(label,value,detail=None):
    checks.append(dict(check=label,passed=bool(value),detail=detail))
    if not value:raise AssertionError(label)
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(d,label):
    check(label+' complete descriptor',type(d)is dict and set(d)=={'path','sha256','bytes'} and type(d['path'])is str and type(d['bytes'])is int and d['bytes']>0 and type(d['sha256'])is str and len(d['sha256'])==64 and all(c in '0123456789abcdef'for c in d['sha256']))
    p=Path(d['path']);s=p.lstat()
    check(label+' absolute canonical nonsymlink regular',p.is_absolute()and p==p.resolve()and stat.S_ISREG(s.st_mode)and not p.is_symlink())
    if d['path']not in verified:
        b=p.read_bytes();check(label+' whole raw hash/size',dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==d);verified[d['path']]=d;raws[d['path']]=b
    else:check(label+' literal reused descriptor',verified[d['path']]==d)
    return raws[d['path']]
def parsed(d,label):return json.loads(load(d,label))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def contains(v,d):return v==d or (type(v)is dict and any(contains(x,d)for x in v.values()))or(type(v)is list and any(contains(x,d)for x in v))
def write(n,v):
    p=OUT/n
    with p.open('xb')as f:f.write((json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    return pin(p)

idxd=pin(index_path);idx=parsed(idxd,'false prospective index');D=index_path.parent.parent
check('Root exact false two-subject index',idx['schema']=='ROOT-schema-admission-prospective-index-v1'and idx['author_identity']=='/root'and idx['source_only']is True and idx['scientific_calls']==0 and idx['actual_execution_authorized']is False and idx['subject_count']==2 and len(idx['schedule'])==2 and idx['goal_complete']is False)
design=parsed(idx['design'],'current design');decl=parsed(idx['case_declaration'],'current declaration');cl=parsed(idx['runtime_closure'],'whole runtime closure');census=parsed(idx['import_census'],'current raw import census');capsule=parsed(idx['input_capsule'],'complete original10 input capsule');contract=parsed(idx['intake_Source_contract'],'current intake contract')
for name,v in [('design',design),('declaration',decl),('closure',cl)]:check(name+' metadata only no authorization',v['author_identity']=='/root'and v['source_only']is True and v['scientific_calls']==0 and v['actual_execution_authorized']is False)
check('current declaration/design schemas',design['schema']=='ROOT-schema-admission-prospective-design-v1'and decl['schema']=='ROOT-schema-admission-comparison-declaration-v1')
check('whole design/declaration/closure references',decl['global_cohort_declaration']==idx['design']and design['runtime_closure']==decl['runtime_closure']==idx['runtime_closure']and decl['intake_Source_handoff']==design['intake_Source_contract']==idx['intake_Source_contract']==cl['current_composition_handoff'])
check('common current Source reviews and import census',idx['current_Source_reviews']==design['current_Source_reviews']and idx['import_census']==design['import_census']==cl['schema_import_census'])
check('full declared schedule common in design/declaration',design['schedule']==decl['schedule']and len(design['schedule'])==2)
check('new explicit structural trust and no RL/recursive changes',design['schema_admission_enabled']is True and design['new_RL_training']is False and design['recursive_proposer_enabled']is False and design['goal_complete']is False and decl['goal_complete']is False and decl['new_RL_training']is False)
check('design discloses all grounds, no historical Model and common point cost',design['complete_original_family_count']==4 and design['expected_original_ground_definition_count']==38 and 'did not reach Model'in design['matching']and 'common point Model'in design['matching']and 'not a statistical'in design['matching']and 'no ineligible ground'in design['unmeasured_gaps'][0]and 'No fit or success'in design['unmeasured_gaps'][2])

oldwd=dict(path='/private/tmp/gcts-adaptive-group-local-pilot-20261019/plans/worker-plans/adaptive-group-002-fixed-local-ROOT-20261019-v2.json',sha256='f123b75b1af2a4df74fd9d1a45384d9d30467e2a44a6de2cd7f4eaec5721edc7',bytes=18113)
oldw=parsed(oldwd,'prior local complete baseline worker')
oldcd=dict(path='/private/tmp/gcts-adaptive-group-local-pilot-20261019/runtime-closure-v2.json',sha256='48714576a9da54abe2c442cb3fbb5e883fa08f51cdd1c94297cc85ca1b41f42a',bytes=73808)
oldcl=parsed(oldcd,'prior local complete baseline closure')
instrument={'work_seconds':180,'overall_seconds':210,'aggregate_peak_bytes':1073741824,'stdout_bytes':4194304,'stderr_bytes':4194304,'result_bytes':134217728,'worker_receipt_bytes':4194304,'runner_plan_bytes':16777216,'failure_cleanup_seconds':5,'poll_milliseconds':20}
scientific={'work_seconds':180,'overall_seconds':210,'conservative_worker_plus_native_peak_bytes':1073741824,'result_bytes':134217728,'search_seconds':30,'search_max_nodes':5000,'compile_queries':512,'guard_steps':1000000000,'inventory_registration_aggregate_micro_steps':5000000000,'registry_steps':5000000000,'check_steps':2048,'proposal_steps':24,'seed':64000}
check('exact complete unchanged scientific limits',decl['limits']==scientific)
oncekeys={'schema','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory','runner','observer','python','cold','worker_plan','integration_declaration','runtime_closure','authorization','limits','environment'}
workerkeys={'schema','invocation_id','mode','actual_directory','cold','python','project_sources','components','native_inputs','policy','declaration','runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage','search_ordering','inventory_certification_mode'}
authkeys={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'}
allplans=[];fresh=[]
for pos,row in enumerate(idx['schedule'],1):
    w=parsed(row['worker_plan'],'worker'+str(pos));r=parsed(row['runner_plan_draft'],'once'+str(pos));a=parsed(row['authorization_draft'],'false auth'+str(pos));sched=design['schedule'][pos-1]
    check('worker exact19 fields/schema '+str(pos),set(w)==workerkeys and w['schema']=='ROOT-schema-admission-worker-plan-v1')
    check('once exact19 fields/schema '+str(pos),set(r)==oncekeys and r['schema']=='ROOT-schema-admission-once-plan-v1')
    check('auth exact7 false/max0/emptyroles '+str(pos),set(a)==authkeys and a['schema']=='ROOT-schema-admission-once-authorization-v1'and a['author_identity']=='/root'and a['actual_execution_authorized']is False and type(a['maximum_actual_invocations'])is int and a['maximum_actual_invocations']==0 and a['review_roles']=={})
    for k in ('invocation_id','actual_directory','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id'):check('complete schedule/worker/once '+str(pos)+' '+k,row[k]==sched[k]==w[k]==r[k])
    check('exact ordered two-arm case002 choices '+str(pos),row['order']==sched['order']==pos and row['mode']==('fixed'if pos==1 else'symbolic')and row['search_ordering']=='and_support'and row['inventory_certification_mode']=='schema_then_native'and row['model_storage']=='literal_interned'and row['result_reader']=='interned'and row['receiver_id']=='prospective-fol-20261018-002')
    subject={k:v for k,v in r.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
    check('exact18 full canonical subject '+str(pos),len(subject)==18 and sha==row['subject_sha256']==a['subject_sha256'])
    check('exact worker/auth/decl/closure links '+str(pos),r['worker_plan']==row['worker_plan']and r['authorization']==row['authorization_draft']and w['integration_declaration']==r['integration_declaration']==idx['case_declaration']and w['runtime_closure']==r['runtime_closure']==idx['runtime_closure'])
    check('exact instrument caps/environment '+str(pos),r['limits']==instrument and r['environment']=={'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','TZ':'UTC'})
    for k in ('cold','runner','observer'):check('current exact intake Source '+str(pos)+' '+k,r[k]==idx[k]==contract[k])
    check('worker same cold '+str(pos),w['cold']==idx['cold'])
    for k in ('native_inputs','policy','python','z3','declaration'):check('unchanged complete baseline '+str(pos)+' '+k,w[k]==oldw[k])
    actual=Path(row['actual_directory']);check('canonical local fresh actual parent '+str(pos),actual.is_absolute()and actual==actual.resolve()and actual.parent.is_dir()and str(actual).startswith('/private/tmp/'))
    local=[actual,actual/'CONSUMED.json',actual/'result.json',actual/'worker-receipt.json',actual/'runner-receipt.json',Path(row['runner_plan_draft']['path']).parent/(row['invocation_id']+'-terminal-observation'),index_path.parent/'runner-plans'/(row['invocation_id']+'.json'),index_path.parent/'runner-plans'/(row['invocation_id']+'-terminal-observation'),index_path.parent/'authorizations'/(row['invocation_id']+'.json')]
    for p in local:check('fresh absent '+str(p),not p.exists())
    fresh.extend(str(p)for p in local)
    allplans.append(dict(schedule=row,worker=w,once=r,authorization=a,subject_preimage=subject,subject_sha256=sha))
check('no existing true authorized index',not(index_path.parent/'authorized-index-v1.json').exists())
check('both worker common every non-slot Source/input field',{k:v for k,v in allplans[0]['worker'].items()if k not in ('invocation_id','mode','actual_directory')}=={k:v for k,v in allplans[1]['worker'].items()if k not in ('invocation_id','mode','actual_directory')})
w=allplans[0]['worker']
aliases=dict(w['project_sources'],semantic_receiver_driver=w['components']['receiver_driver'],bounded_request_oracle=w['components']['bounded_transport'])
allaliases=dict(aliases,**idx['schema_sources'])
check('complete common base24 plus separate1 current map',len(w['project_sources'])==22 and set(w['components'])=={'receiver_driver','bounded_transport'}and len(aliases)==24 and len(allaliases)==25 and set(idx['schema_sources']).isdisjoint(aliases)and aliases==cl['materialized_aliases']and w['project_sources']==cl['project_sources']and w['components']==cl['additional_nonseed_components']and idx['schema_sources']==cl['schema_sources'])
check('counts explicitly24base25current',cl['materialized_project_and_component_count']==24 and cl['current_scientific_alias_count']==25 and cl['schema_extra_component_count']==1)
oldaliases=dict(oldw['project_sources'],semantic_receiver_driver=oldw['components']['receiver_driver'],bounded_request_oracle=oldw['components']['bounded_transport'])
changed={k for k in aliases if aliases[k]!=oldaliases[k]}
check('exact five reviewed base replacements only',changed=={'semantic_inventory_oracle','semantic_receiver_driver','quantified_family_points_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1'}and set(oldaliases)==set(aliases),sorted(changed))
check('current schema cert/kernel exact Source contract links',cl['schema_sources']==idx['schema_sources']and cl['schema_kernel_source']==idx['schema_kernel_source'])
load(idx['schema_kernel_source'],'raw unchanged semantic kernel only')
for k in ('cold','runner','observer'):load(idx[k],'current '+k+' raw Source only')
for n,d in allaliases.items():load(d,'scientific raw Source only '+n)
check('same complete inputcapsule selected receiver literal',w['declaration']==decl['parent_structural_declaration']==idx['input_capsule']and len(capsule['receivers'])==10 and [r for r in capsule['receivers']if r['id']==decl['selected_receiver_id']]==[decl['selected_receiver']]and decl['selected_receiver']==design['assertion']and decl['selected_receiver_id']=='prospective-fol-20261018-002')
sel=decl['selected_receiver'];check('same12rows2rounds statement only',sel['length']==12 and sel['instantiation_rounds']==2 and sel['theory']['schemas']==[] and 'no open root assumptions'in sel['scope']and not(set(sel)&{'proof','commands','route','binding','hints'}))
policy=parsed(w['policy'],'whole original four-family policy');check('full4policy no filter',len(policy['library'])==4 and len({x['id']for x in policy['library']})==4)
load(w['python'],'whole original Python raw executable')
check('same interpreter and parent runtime',w['python']==cl['runtime']['Python_executable']==oldcl['runtime']['Python_executable']and cl['runtime']==oldcl['runtime'])
for n,d in w['native_inputs'].items():
    if type(d)is dict and set(d)=={'path','sha256','bytes'}:load(d,'Native raw/opaque hash only '+n)
for k in ('source','binary'):load(cl['native_CPP'][k],'Native CPP/binary raw only '+k)
check('unchanged full Native intake',cl['native_CPP']==oldcl['native_CPP']and cl['fixed_native_inputs']==oldcl['fixed_native_inputs'])
check('same complete41Z3 files/root',len(w['z3']['files'])==41 and w['z3']['files']==[{k:v[k]for k in ('path','sha256','bytes')}for v in cl['Z3']['files']]and w['z3']['root']==cl['Z3']['package_root']and cl['Z3']==oldcl['Z3'])
for d in w['z3']['files']:load(d,'Z3 raw bytes only '+Path(d['path']).name)
load(cl['parent_closure'],'private local parent closure raw metadata')
check('same local parent descriptor',cl['parent_closure']==oldcl['parent_closure'])
for n,v in cl['stdlib_entry_references'].items():
    if type(v)is dict and 'pin'in v:load(v['pin'],'trusted bundled stdlib direct entry '+n)

# Rebuild import declarations from raw AST, including nested imports. No import occurs.
check('census author/source-only/unlaunched',census['author_identity']=='/root/conventional_library'and census['source_only']is True and census['scientific_calls']==0 and census['actual_execution_authorized']is False)
check('census exact25 owned alias preimages',census['all_scientific_aliases']==allaliases and census['base_materialized_aliases']==aliases and census['extra_component_aliases']==idx['schema_sources']and census['all_alias_count']==25 and census['base_alias_count']==24 and census['extra_alias_count']==1)
check('complete current AST Source pins in both records',census['source_AST_pins']==cl['source_AST_pins']and set(census['source_AST_pins'])==set(allaliases))
derived_symbols=[];derived_statements=[];derived_dynamic=[];edges=set();stdlib=set();external=set()
for name,d in sorted(allaliases.items()):
    raw=raws[d['path']].decode();tree=ast.parse(raw)
    check('whole AST identity '+name,census['source_AST_pins'][name]['raw_source']==d and census['source_AST_pins'][name]['AST_sha256']==hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest())
    for node in ast.walk(tree):
        if isinstance(node,(ast.Import,ast.ImportFrom)):
            check('absolute import only '+name+':'+str(node.lineno),not isinstance(node,ast.ImportFrom)or node.level==0)
            dump=ast.dump(node,include_attributes=False);segment=ast.get_source_segment(raw,node)
            derived_statements.append((name,node.lineno,dump,segment))
            names=[a.name for a in node.names]if isinstance(node,ast.Import)else[node.module or'']
            for module in names:
                root=module.split('.')[0];derived_symbols.append((name,node.lineno,dump,module,segment))
                if root in allaliases:edges.add((name,root))
                elif root=='z3':external.add(root)
                else:stdlib.add(root)
        if isinstance(node,ast.Call)and isinstance(node.func,ast.Name)and node.func.id=='__import__':
            check('dynamic import literal known module '+name+':'+str(node.lineno),len(node.args)==1 and type(node.args[0])is ast.Constant and type(node.args[0].value)is str and not node.keywords)
            derived_dynamic.append((name,node.lineno,ast.dump(node,include_attributes=False),node.args[0].value,ast.get_source_segment(raw,node)));stdlib.add(node.args[0].value)
declared_symbols=[(s['source_module'],s['line'],s['statement_AST'],s['import_name'],s['statement_raw'])for s in census['import_sites']]
declared_statements=[(s['module'],s['line'],s['AST'],s['raw'])for s in census['import_statement_sites']]
declared_dynamic=[(s['module'],s['line'],s['call_AST'],s['import_name'],s['raw'])for s in census['literal_dynamic_import_sites']]
check('all129 raw AST import-symbol sites exact',collections.Counter(derived_symbols)==collections.Counter(declared_symbols)and len(derived_symbols)==census['import_site_count']==129)
check('all97 raw AST statement sites exact',collections.Counter(derived_statements)==collections.Counter(declared_statements)and len(derived_statements)==census['import_statement_count']==97)
check('both literal nested math calls exact',sorted(derived_dynamic)==sorted(declared_dynamic)and len(derived_dynamic)==2 and all(x[3]=='math'for x in derived_dynamic))
check('all36 current project edges exact',sorted(edges)==[(x['source'],x['target'])for x in census['project_import_edges']]and len(edges)==36)
check('current imports/census integrated literal closure',cl['import_sites']==census['import_sites']and cl['import_statement_sites']==census['import_statement_sites']and cl['project_import_edges']==census['project_import_edges']and cl['literal_dynamic_import_sites']==census['literal_dynamic_import_sites'])
check('all current stdlib/external roots exact',sorted(stdlib)==census['stdlib_import_roots']==cl['current_stdlib_import_roots']and sorted(external)==census['external_import_roots']==cl['current_external_import_roots']==['z3'])
check('census no unresolved/relative/loader sites',all(census[k]==[]for k in ('unresolved_dynamic_import_sites','unresolved_import_classifications','relative_import_sites','loader_calls_in_scientific_aliases','unreachable_owned_aliases'))and cl['unresolved_dynamic_import_sites']==cl['unresolved_project_imports']==[])
for s in census['import_sites']:check('raw Source descriptor for import '+s['source_module']+':'+str(s['line'])+':'+s['import_name'],s['source']==allaliases[s['source_module']])
reachable=set(census['explicit_seeds'])
while True:
    enlarged=reachable|{b for a,b in edges if a in reachable}
    if enlarged==reachable:break
    reachable=enlarged
check('complete25 reachable from explicit15seeds incl injectedcert',len(census['explicit_seeds'])==15 and reachable==set(allaliases)==set(census['reachable_aliases'])and census['raw_declared_alias_AST_closure_complete']is True)
missing=sorted(k for k in stdlib if census['inherited_stdlib_entry_references'].get(k)is None)
check('six inherited stdlib entry gaps explicit no new sealing claim',missing==['os','select','selectors','signal','stat','tempfile']==cl['inherited_closed_stdlib_roots_without_entry_pin']==census['inherited_closed_stdlib_roots_without_entry_pin'])
check('exact5replacement lineage and unchanged19 census',set(census['replaced_base_aliases'])==changed and set(census['unchanged_base_aliases'])==set(aliases)-changed)

# Historical ordinary JSON is comparison evidence only, never passed to a run.
prior=parsed(design['comparison_only_prior_result'],'historical bulkcase002 ordinary JSON comparison')
check('prior actual same statement/policy only with no Model/search',prior['declaration']==sel and prior['policy']==policy and prior['receiver_id']==sel['id']and prior['status']=='unknown_native_inventory'and all(k not in prior['outputs']for k in ('model','initial','search')))
sp=prior['outputs']['specialize'];reg=prior['outputs']['register']
check('all38 historical definitions/interfaces/Nativeblocks retained',len(sp['definitions'])==len(sp['interfaces'])==len(sp['native_blocks'])==38 and all(sp[k]==reg[k]for k in ('definitions','interfaces','native_blocks')))
body_kinds=collections.Counter(tuple(c['rule']for c in x['definition']['proof'])for x in sp['definitions'])
check('literal historical22singleMP16twohop only',body_kinds=={('assumption','assumption','mp'):22,('assumption','assumption','assumption','mp','mp'):16},str(body_kinds))
check('comparison raw never operational worker context',all(not contains(v,design['comparison_only_prior_result'])for item in allplans for v in (item['worker'],item['once'],item['authorization'])))

reviews={k:parsed(d,'exact scoped review '+k)for k,d in idx['current_Source_reviews'].items()}
for role,obj in reviews.items():
    schema,passed,reviewer=contract['current_review_roles'][role]
    check('current scoped review flags/identity '+role,obj['schema']==schema and obj[passed]is True and obj['reviewer_identity']==reviewer and obj['source_only']is True and obj['scientific_calls']==0 and obj['scientific_acceptance']is False and obj['actual_execution_authorized']is False and obj['author_identity']!=obj['reviewer_identity'])
required={'consumer_gates_Source':[aliases[k]for k in ('quantified_family_points_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],'registry_Source':[aliases['semantic_inventory_oracle'],idx['schema_sources']['mp_schema_certificate']],'driver_Source':[aliases[k]for k in ('semantic_receiver_driver','semantic_inventory_oracle')]+list(idx['schema_sources'].values()),'composition_Source':[idx['cold'],aliases['semantic_receiver_driver']]+list(idx['schema_sources'].values()),'once_Source':[idx['runner'],idx['observer']],'retained_ordering_Source':list(contract['retained_ordering_subjects'].values())}
for role,subjects in required.items():
    for d in subjects:check('full scoped subject '+role+' '+Path(d['path']).name,contains(reviews[role],d))
certreview=parsed(idx['certifier_Source_review'],'explicit unchanged certifier Source ancestry')
check('certifier exact unchangedSource review',certreview['source_review_passed']is True and certreview['source_only']is True and certreview['scientific_calls']==0 and contains(certreview,idx['schema_sources']['mp_schema_certificate']))
check('six existingroles fiveunique receipts twoidentities',len(idx['current_Source_reviews'])==6 and len({d['sha256']for d in idx['current_Source_reviews'].values()})==5 and len({v['reviewer_identity']for v in reviews.values()})==2 and idx['current_Source_reviews']['composition_Source']==idx['current_Source_reviews']['once_Source']and set(contract['current_review_roles'])==set(reviews)|{'prospective_plans'})
for d in (design['independent_design'],design['independent_consumer_addendum'],design['prior_shadow_finite_qualification']):load(d,'declared scope/finite ancestry raw metadata')
for d in [idxd,idx['design'],idx['case_declaration'],idx['runtime_closure'],idx['input_capsule'],cl['parent_closure'],*[item['schedule'][k]for item in allplans for k in ('worker_plan','runner_plan_draft','authorization_draft')]]:check('live operational metadata private tmp '+Path(d['path']).name,d['path'].startswith('/private/tmp/'))

# Narrow immutable V1-to-V2 metadata successor, with no scientific Source change.
prior_index_desc=dict(path=str(D/'plans/prospective-index-v1.json'),sha256='64c278d0b4ea9cf365408d44500a1b9675d6ee6a72a8434399405eadd732f715',bytes=7267)
prior_index=parsed(prior_index_desc,'preserved false index V1')
prior_cl=parsed(prior_index['runtime_closure'],'preserved closure V1')
prior_design=parsed(prior_index['design'],'preserved design V1')
prior_decl=parsed(prior_index['case_declaration'],'preserved declaration V1')
negative=parsed(cl['v1_negative_metadata_review'],'preserved independent negative metadata review V1')
check('negative preserved with one stale mode finding',negative['prospective_review_passed']is False and negative['metadata_finding_count']==1 and negative['findings'][0]['id']=='STALE_CURRENT_CERTIFICATION_MODE'and negative['prospective_index']==prior_index_desc)
check('V2 exact index expected whole raw',idxd['sha256']=='551700c4ff8d0aeaa92ef4a7218c43f425ebd95a6f23e160152589b54c1c2824'and idxd['bytes']==7285)
check('V2 exact three new operational descriptors',idx['case_declaration']['sha256']=='e1826931547adfe6b752dec3550a06d8a0e46dfedc9a9834497282873c8d76bd'and idx['runtime_closure']['sha256']=='a3d56909bd3445074de187b99914d6a4a073d2c4f6a701061880818c74360f7e'and idx['design']['sha256']=='8eacc173eaadb09a4a9bc49ec53cd1e4494e7a4e266cf3e98f99c8fcdc05d031')
check('V2 closure exact narrow added lineage fields',set(cl)-set(prior_cl)=={'preserved_false_metadata_v1','previous_Source_design','registry_Source_design','v1_negative_metadata_review'}and not(set(prior_cl)-set(cl)))
check('V2 closure exact narrow corrected current fields',{k for k in prior_cl if prior_cl[k]!=cl[k]}=={'Source_design','inventory_certification_modes','nested_and_dynamic_scope','reader_scope','status'})
check('V2 current mode corrected and prior design explicit',cl['inventory_certification_modes']==['schema_then_native']and cl['previous_Source_design']==prior_cl['Source_design']and cl['preserved_false_metadata_v1']=={'closure':prior_index['runtime_closure'],'declaration':prior_index['case_declaration'],'design':prior_index['design']})
check('V2 current contract map exact scope',set(cl['Source_design'])=={'cold','consumer_gates','driver','intake'}and cl['Source_design']['intake']==idx['intake_Source_contract']and cl['registry_Source_design']['sha256']=='a8d1f2fd405e7813874250ee12a80ec3db2a2440b716f8171aa5a0b6366b60b0')
for role,d in cl['Source_design'].items():load(d,'V2 current contract '+role)
load(cl['registry_Source_design'],'V2 current registry Source contract')
check('V2 design only new closure and fresh schedule',set(design)==set(prior_design)and {k for k in design if design[k]!=prior_design[k]}=={'runtime_closure','schedule'})
check('V2 declaration only referenced design/closure/fresh schedule',set(decl)==set(prior_decl)and {k for k in decl if decl[k]!=prior_decl[k]}=={'global_cohort_declaration','runtime_closure','schedule'})
check('V2 index only fresh referenced operational metadata',set(idx)==set(prior_index)and {k for k in idx if idx[k]!=prior_index[k]}=={'case_declaration','design','runtime_closure','schedule'})
for pos,(oldrow,item) in enumerate(zip(prior_index['schedule'],allplans),1):
    ow=parsed(oldrow['worker_plan'],'preserved worker V1 '+str(pos));orr=parsed(oldrow['runner_plan_draft'],'preserved once V1 '+str(pos));oa=parsed(oldrow['authorization_draft'],'preserved false auth V1 '+str(pos))
    nw=item['worker'];nr=item['once'];na=item['authorization'];newrow=item['schedule']
    check('V2 unchanged worker scientific body '+str(pos),set(ow)==set(nw)and {k for k in ow if ow[k]!=nw[k]}=={'invocation_id','actual_directory','integration_declaration','runtime_closure'})
    check('V2 once only fresh operational subject paths '+str(pos),set(orr)==set(nr)and {k for k in orr if orr[k]!=nr[k]}=={'invocation_id','actual_directory','worker_plan','integration_declaration','runtime_closure','authorization'})
    check('V2 false auth only new exact subject SHA '+str(pos),set(oa)==set(na)and {k for k in oa if oa[k]!=na[k]}=={'subject_sha256'})
    check('V2 schedule only operational descriptors and subject '+str(pos),set(oldrow)==set(newrow)and {k for k in oldrow if oldrow[k]!=newrow[k]}=={'invocation_id','actual_directory','worker_plan','runner_plan_draft','authorization_draft','subject_sha256'})
    check('V2 fresh iid and subject exact '+str(pos),newrow['invocation_id']==oldrow['invocation_id'][:-2]+'v2'and item['subject_sha256']==('8f2c3c65c65f7b64cda7418aacab11f6f8ec37112fc4070d514b28986ecbd55a'if pos==1 else'2ae64f5faa9b6e6e5a9bf59d85fc7be73af2fca76f34f7fb26916b1d275f8169'))
    check('V1 actual and terminal remain unlaunched '+str(pos),not Path(oldrow['actual_directory']).exists()and not(index_path.parent.parent/'plans/runner-plans'/(oldrow['invocation_id']+'-terminal-observation')).exists())
check('V1 no true authorized index',not(D/'plans/authorized-index-v1.json').exists())

findings=[]
if cl['inventory_certification_modes']!=['schema_then_native']:
    findings.append(dict(id='STALE_CURRENT_CERTIFICATION_MODE',severity='blocking_metadata',observed=cl['inventory_certification_modes'],required=['schema_then_native'],finding='The current closure names the inherited adaptive_groups lane despite both new subjects requiring schema_then_native. Preserve this candidate and issue a separately pinned metadata successor before a PASS or grants. No executable scientific Source defect is implied.'))
passed=not findings
audit=write('prospective-raw-metadata-audit-'+tag+'.json',dict(schema='schema-admission-prospective-independent-raw-audit-v1',source_only=True,scientific_calls=0,checks=checks,findings=findings,verified_raw_descriptors=list(verified.values()),full_subjects=allplans,all25Sources=allaliases,derived_import_symbols=derived_symbols,derived_import_statements=derived_statements,derived_dynamic_imports=derived_dynamic,derived_project_edges=sorted(edges),full_selected_receiver=sel,baseline_worker=oldwd,baseline_closure=oldcd,prior_comparison=design['comparison_only_prior_result'],fresh_paths=fresh))
review=dict(schema='schema-admission-prospective-plan-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',prospective_review_passed=passed,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,prospective_index=idxd,design=idx['design'],case_declaration=idx['case_declaration'],runtime_closure=idx['runtime_closure'],import_census=idx['import_census'],full_schedule=idx['schedule'],current_Source_reviews=idx['current_Source_reviews'],certifier_Source_review=idx['certifier_Source_review'],current_intake_sources={k:idx[k]for k in ('cold','runner','observer')},all25Sources=allaliases,schema_kernel_source=idx['schema_kernel_source'],Python=w['python'],Z3=w['z3'],native_inputs=w['native_inputs'],policy=w['policy'],input_capsule=idx['input_capsule'],subject_field_count=18,subject_count=2,preserved_negative_review=cl['v1_negative_metadata_review'],preserved_false_index_v1=prior_index_desc,metadata_successor_scope='V1 current-mode finding repaired; all executable Sources, scientific inputs and limits unchanged; fresh V2 paths/subjects only',check_count=len(checks),mismatch_count=0,metadata_finding_count=len(findings),findings=findings,unique_raw_pin_count=len(verified),audit=audit,review_Source=pin(Path(__file__)),conclusions=[
    'Both false/max0/emptyroles subjects share exactly the full current25 scientific Sources, Python,41 raw Z3 files, Native inputs, policy and complete original case002. Fixedfirst then symbolic, and_support, literal_interned Model and interned complete result reader; all original38 ground definitions remain prospective obligations, not assumed accepted.',
    'Only five base aliases change from the complete prior local24Source baseline, plus one explicitly injected certifier. Raw AST reconstruction matches129 import-symbol sites,97 import statements,36 project edges and two literal nested math imports. All25 aliases are reachable from15 explicit seeds, including the separately injected certifier.',
    'Current Source review scopes are explicit: retained ordering has distinct Receiver ancestry; new Root gate/driver/intake changes and Library registry are separately reviewed. Six existing role names use five unique receipts/two reviewer identities, with composition and once sharing a receipt; the prospective receipt becomes a sixth unique receipt across seven roles. This is not seven independent reviewers.',
    'New schema_admitted complete inventory permission is explicitly distinct from Native acceptance. The full current theory is freshly Native admitted. Eligible ground correspondence and any noneligible Native fallback cover the whole original registry before Model, fallback shares the original5e9 cap, and final target proof still requires fresh ordinary Native plus full point and used-original-closure gates.',
    'Both arms pay complete common Model acquisition and posthoc point projection costs; symbolic row extensions and point tile attempts are different units. The old bulkcase002 ordinary JSON has38 definitions (22singleMP/16twohop) and no Model/search. It is comparison-only, never passed as current Native/cache/context authority. No historical full Model equality is promised.'
],limitations=[
    'Saved metadata/raw byte/hash/stat/AST inspection only. No scientific target module/function, Native, Model, kernel, compiler, solver, search, Reader, renderer, fixture, scientific or opaque codec was imported or evaluated. Opaque Native gzip was raw-hashed only; no Native program decoding, proof replay, actual launch or grant was performed.',
    'Reviewer authored inherited outer/broker, earlier driver/control/helper Sources and prior benchmark/CASE/checker/diagnosis components, and the design obligation note. This independently checks Root prospective composition; it is not a fresh self-certificate of inherited algorithms or mathematical kernel soundness. Exact genuine Receiver ordering/certifier and scoped current Source reviews remain separate authority.',
    'The conditional structural uniform-substitution argument is unformalized. Certifier packets retain false authority; only the new explicit complete registry lane grants Model permission. Any later proof claim still depends on fresh unchanged Native semantics. New fallback may not execute on this case; generic nested calls were qualified only in the earlier shadow run, not assumed measured here.',
    'Bundled recursive stdlib/loader/OS is trusted. Six current stdlib roots have inherited missing entry pins (os/select/selectors/signal/stat/tempfile), explicitly disclosed; the raw import census is not formal continuous activation sealing. Actual custody/origins/callables and current theory/registry record joins remain cold/admission obligations.',
    'Original180positive/210terminal,1GiB sum of separate Darwin scientific worker+Native highwaters,128MiB full JSON,4MiB per log and search/compiler/Native limits remain. Observer/controller RAM and separately observed observer/interpreter prelude are excluded from the inherited Source-entry gate. Final outer raw rehash is conditional on aggregate profile pass; memory diagnostics cannot claim that skipped loop.',
    'No fit, successful inventory admission, theorem discovery, runtime prediction, RL training, statistical/general proof-search advantage or GCTS-specific superiority follows. No rule/template/term/interface/marking/candidate/grammar trim, budget increase, target route/binding, learned pruning or scheduler/fallback/rollback change is authorized. All actual UNKNOWN/failure must be retained without feedback into the second arm.',
    'This false/max0 receipt authorizes no execution. Root must separately bind seven role scopes/six unique receipts/two reviewer identities to full raw current subjects, create true/max1 grants without changing either18-field subject, and obtain a final exact delta/freshness check. Synchronous filesystem reads may still block; local private/tmp paths avoid the former dataless operational-metadata path but are not an I/O interruption proof.'
])
rd=write('typed-prospective-review-'+tag+'.json',review)
hd=write('prospective-peer-handoff-'+tag+'.json',dict(schema='schema-admission-prospective-independent-peer-handoff-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=rd,audit=audit,prospective_index=idxd,prospective_review_passed=passed))
print(json.dumps(dict(review=rd,audit=audit,handoff=hd,checks=len(checks),raw_pins=len(verified),metadata_findings=findings),indent=2))
