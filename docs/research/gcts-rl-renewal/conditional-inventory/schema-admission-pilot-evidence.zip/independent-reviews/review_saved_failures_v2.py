"""Retained ordinary JSON/raw byte failure audit. No scientific execution."""
import ast
import collections
import hashlib
import json
import stat
from pathlib import Path

D=Path('/private/tmp/gcts-schema-admission-ROOT-20261019');O=Path('/private/tmp/gcts-schema-admission-peer-20261019')
checks=[];pins={};raws={}
def ck(k,v,detail=None):
    checks.append(dict(check=k,passed=bool(v),detail=detail))
    if not v:raise AssertionError(k)
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(d,label):
    ck(label+' complete descriptor',type(d)is dict and set(d)=={'path','sha256','bytes'}and type(d['path'])is str and type(d['bytes'])is int and d['bytes']>=0)
    p=Path(d['path']);s=p.lstat();ck(label+' canonical regular nonsymlink',p.is_absolute()and p==p.resolve()and stat.S_ISREG(s.st_mode)and not p.is_symlink())
    if str(p)not in pins:
        b=p.read_bytes();ck(label+' whole raw SHA/bytes',dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==d);pins[str(p)]=d;raws[str(p)]=b
    else:ck(label+' identical reused pin',pins[str(p)]==d)
    return raws[str(p)]
def get(d,label):return json.loads(load(d,label))
def current(p,label):
    d=pin(p);return get(d,label),d
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def contains(v,d):return v==d or(type(v)is dict and any(contains(x,d)for x in v.values()))or(type(v)is list and any(contains(x,d)for x in v))
def write(n,v):
    p=O/n
    with p.open('xb')as f:f.write((json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    return pin(p)
idxd=dict(path=str(D/'plans-v2/authorized-index-v2.json'),sha256='48501b3c2db109b9da4ab592078d47d9e43ad5a5f7d738281c1da6615012cf01',bytes=10346)
reviewd=dict(path=str(O/'typed-final-grant-delta-review-v2.json'),sha256='72fe72b24bce247c167cbfd95f01def4f41b7f781f932d04cbaa0a4f7feb9043',bytes=9998)
idx=get(idxd,'exact authorized two-slot index');finalreview=get(reviewd,'exact prelaunch delta PASS')
ck('index subject unchanged from final peer',finalreview['final_grant_delta_review_passed']is True and finalreview['authorized_index']==idxd and finalreview['scientific_calls']==0 and finalreview['actual_execution_authorized']is False)
closure,closured=current(D/'ROOT-cohort-closure-v1.json','Root saved cohort process closure')
between,betweend=current(D/'ROOT-fixed-closure-before-symbolic-v1.json','saved fixed-before-symbolic process closure')
ck('cohort saved absent processes/no science',closure['schema']=='ROOT-schema-admission-cohort-closure-v1'and closure['all_workers_and_native_groups_closed']is True and closure['remaining_processes']==''and closure['scientific_calls']==0)
ck('sequential closure observation before next arm',between['logs_eof']is True and between['owned_group_absent']is True and between['remaining_processes']==[]and between['no_scientific_feedback']is True and between['scientific_calls']==0)
decl=get(idx['case_declaration'],'whole current declaration');cl=get(idx['runtime_closure'],'whole current25 Source closure');contract=get(idx['intake_Source_contract'],'exact review role ABI')
allrows=[];pids=[];groups=[];allstages=[]
for pos,row in enumerate(idx['schedule'],1):
    name=row['mode'];A=Path(row['actual_directory']);T=Path(row['runner_plan']['path']).parent/(row['invocation_id']+'-terminal-observation')
    worker=get(row['worker_plan'],name+' unchanged worker');plan=get(row['runner_plan'],name+' exact once plan');auth=get(row['authorization'],name+' exact maxone grant');false=get(row['runner_plan_draft'],name+' false once retained')
    c,cd=current(A/'CONSUMED.json',name+' prelaunch worker consumed');r,rd=current(A/'runner-receipt.json',name+' failed runner receipt');f,fd=current(A/'worker-failure.json',name+' worker failure');t,td=current(T/'terminal.json',name+' observer terminal');oc,ocd=current(T/'CONSUMED.json',name+' observer consumed')
    ck(name+' exact18subject/currentplan/auth linkage',len({k:v for k,v in plan.items()if k!='authorization'})==18 and {k:v for k,v in plan.items()if k!='authorization'}=={k:v for k,v in false.items()if k!='authorization'}and hashlib.sha256(canon({k:v for k,v in plan.items()if k!='authorization'})).hexdigest()==row['subject_sha256']==auth['subject_sha256']==r['subject_sha256']and r['plan']==c['plan']==oc['plan']==t['plan']==row['runner_plan']and plan['authorization']==r['authorization']==row['authorization'])
    ck(name+' true/maxone consumed exactlyonce metadata',auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1 and c['consumed_before_Popen']is True and c['maximum_worker_launches']==1 and r['consumed_once']is True and r['worker_launch_attempts']==1 and oc['maximum_runner_launches']==1)
    ck(name+' full captured consumed descriptor/terminal runnerpin',r['consumed_marker']==cd and t['runner_receipt']==rd)
    for k in ('invocation_id','mode','search_ordering','inventory_certification_mode','result_reader','model_storage'):
        ck(name+' literal slot/captured consumed/receipt '+k,row[k]==plan[k]==worker[k]==c[k]==r[k])
    ck(name+' exact case002/admission lane/order',row['order']==pos and row['mode']==('fixed'if pos==1 else'symbolic')and r['receiver_id']==row['receiver_id']=='prospective-fol-20261018-002'and r['inventory_certification_mode']=='schema_then_native'and r['runtime_closure']==plan['runtime_closure']==idx['runtime_closure']and r['integration_declaration']==plan['integration_declaration']==idx['case_declaration'])
    ck(name+' original instrument limits retained',r['limits']==plan['limits']and plan['limits']['work_seconds']==decl['limits']['work_seconds']==180 and plan['limits']['overall_seconds']==decl['limits']['overall_seconds']==210 and plan['limits']['aggregate_peak_bytes']==decl['limits']['conservative_worker_plus_native_peak_bytes']==1073741824 and plan['limits']['result_bytes']==decl['limits']['result_bytes']==134217728 and plan['limits']['stdout_bytes']==plan['limits']['stderr_bytes']==4194304)
    ck(name+' Source-entry absolute deadlines unchanged',c['began_ns']==r['began_ns']and c['work_deadline_ns']==r['work_deadline_ns']==r['began_ns']+180000000000 and c['overall_deadline_ns']==r['overall_deadline_ns']==r['began_ns']+210000000000)
    ck(name+' exact seven role packets recorded',r['review_roles']==auth['review_roles']and set(auth['review_roles'])==set(idx['current_review_roles'])and len(auth['review_roles'])==7)
    for role,p in auth['review_roles'].items():
        obj=get(p['receipt'],name+' scoped review '+role);schema,passkey,reviewer=contract['current_review_roles'][role]
        ck(name+' role exact receipt/identity/pass '+role,p['receipt']==idx['current_review_roles'][role]and p['reviewer_identity']==obj['reviewer_identity']==reviewer and obj['schema']==schema and obj[passkey]is True and obj['scientific_calls']==0 and obj['source_only']is True and obj['scientific_acceptance']is False and obj['actual_execution_authorized']is False)
        for d in p['required_subjects']:ck(name+' role complete subject containment '+role+' '+Path(d['path']).name,contains(obj,d))
    aliases=dict(worker['project_sources'],semantic_receiver_driver=worker['components']['receiver_driver'],bounded_request_oracle=worker['components']['bounded_transport'],**idx['schema_sources'])
    ck(name+' complete25 copy file names only',len(aliases)==25 and {p.name for p in(A/'modules').iterdir()}=={n+'.py'for n in aliases})
    copy_pins={}
    for n,d in aliases.items():
        original=load(d,name+' original raw Source '+n);owned=pin(A/'modules'/(n+'.py'));b=load(owned,name+' owned raw Source '+n)
        ck(name+' literal original/owned Source '+n,original==b and owned['sha256']==d['sha256']and owned['bytes']==d['bytes']);copy_pins[n]=owned
    absent=[A/'result.json',A/'worker-receipt.json',A/'schema-shadow-result.json']
    for p in absent:ck(name+' no complete result/worker receipt/sidecar '+p.name,not p.exists())
    ck(name+' no retained partial result',not list(A.glob('.*.partial'))and not list(A.glob('*.partial')))
    ck(name+' exact serialization output-cap failure no accepted proof',f['schema']=='ROOT-semantic-worker-failure-v1'and f['error_type']=='OutputCapExceeded'and f['message']=='full result exceeds128MiB; no truncated proof result published'and f['result_already_published']is None and f['logical_proof_accepted']is False and f['scientific_acceptance']is False and f['cleanup_errors']==[])
    ck(name+' all runner/observer admission flags false',all(r[k]is False for k in ('ROOT_resource_accepted','resource_candidate_accepted','mathematical_proof_accepted','logical_proof_transport_candidate','scientific_acceptance'))and all(t[k]is False for k in ('ROOT_resource_accepted','mathematical_proof_accepted','scientific_acceptance','terminal_gate_passed'))and r['worker_receipt']is None and r['native_transport']is None and r['conservative_parent_plus_native_peak_bytes']is None)
    ck(name+' distinct exact worker/runner exit failure',r['python_exit_code']==1 and r['python_wait4_status']==256 and r['python_reaped']is True and r['worker_pid_observed']is True and t['runner_exit_code']==2 and r['python_pid']!=t['runner_pid']and t['version']=='schema-admission-final-terminal-observer-v1')
    ck(name+' exit0 text is failed precondition not success',len(r['errors'])==1 and r['errors'][0]['type']=='OnceRunnerError'and r['errors'][0]['message']=='normal exact Python exit0')
    logs={}
    for channel in ('stdout','stderr'):
        b=load(r['outputs'][channel],name+' full worker '+channel);logs[channel]=r['outputs'][channel]
        ck(name+' complete bounded worker log '+channel,r[channel+'_bytes']==len(b)<=plan['limits'][channel+'_bytes']and r[channel+'_eof']is True)
    ck(name+' traceback exact copied driver output cap not Native failure',raws[str(A/'stdout.bin')]==b''and b'OutputCapExceeded'in raws[str(A/'stderr.bin')]and str(copy_pins['semantic_receiver_driver']['path']).encode()in raws[str(A/'stderr.bin')]and b'_atomic_output'in raws[str(A/'stderr.bin')])
    obsout=pin(T/'stdout.bin');obsbytes=load(obsout,name+' outer stdout');obserr=pin(T/'stderr.bin');ck(name+' no observer stderr',load(obserr,name+' outer stderr')==b'')
    outerline=json.loads(obsbytes);ck(name+' outer stdout failure/current runner receipt',outerline=={'completion_within_overall':True,'exit_code':2,'runner_receipt':rd})
    expectedcmd=[plan['python']['path'],'-I','-S','-B',idx['runner']['path'],row['runner_plan']['path']]
    ck(name+' exact observer command pinned isolated runner',t['command']==expectedcmd)
    ck(name+' known closed EOF/permanentgroup safety',r['owned_pgid']==r['python_pid']and r['owned_group_absent']is True and r['log_capture_complete']is True and r['signals']==[]and r['owned_group_reappearance_observed_ns']is None and r['owned_group_probe_count']>=1 and r['worker_terminal_observed_ns']<=r['owned_group_first_absent_ns']<=r['owned_group_last_probe_ns']<=r['postreap_group_and_pipe_closed_ns']<=r['checks_closed_ns']<=t['terminal_observed_ns'])
    elapsed=(t['terminal_observed_ns']-r['began_ns'])/1e9;instrument=(t['terminal_observed_ns']-t['observer_started_ns'])/1e9
    ck(name+' exact failure terminal clocks not proof times',elapsed==t['runner_clock_elapsed_seconds']and instrument==t['observed_instrument_elapsed_seconds']and oc['started_ns']==t['observer_started_ns']<r['began_ns']and elapsed<180<210 and t['terminal_observed_ns']<r['overall_deadline_ns'])
    python=r['python_custody'];ck(name+' conditional outer custody baseline only',python['python']==plan['python']==worker['python']and python['whole_baseline_authenticated']is True and python['trusted_OS_metadata_assumption']is True and python['formal_continuous_seal']is False and python['worker_callback_guard_claimed']is False and python['callback_policy']=='OUTER_POLL_METADATA_ONLY_NO_REBASELINE')
    n=f['native_transport'];ck(name+' Native closed exact child/parent wait4',n['schema']=='semantic-family-native-transport-receipt-v1'and n['constructor_completed']is True and n['closed']is True and n['all_reaped']is True and n['cleanup_errors']==[]and n['native_pid']not in (r['python_pid'],t['runner_pid'])and n['parent_pid']==r['python_pid']and n['native_pgid']==n['parent_pgid']==r['owned_pgid']and n['same_owned_process_group']is True and n['wait4_status']==0 and n['native_exit_code']==0)
    ck(name+' Native closed bounded pipes/no signals',n['stdout_eof']is True and n['stdout_pending_bytes']==0 and n['stderr_complete']is True and n['stderr_bytes']==0 and n['stderr_hex']==n['stderr_utf8']==''and n['termination_signals']==[]and n['stdout_bytes']<=n['limits']['stdout_total_bytes'])
    ck(name+' Native transport authority false',n['aggregate_resource_accepted']is False and n['logical_proof_accepted']is False and n['scientific_acceptance']is False and n['CPP_self_reported_peak_is_resource_authority']is False)
    ck(name+' Native deadlines literally same original clock',n['work_deadline']==r['work_deadline_ns']/1e9 and n['closure_deadline']==r['overall_deadline_ns']/1e9)
    stages=n['request_stages'];ck(name+'52 completed transport stages only',len(stages)==n['complete_records']==52 and collections.Counter(s['purpose']for s in stages)=={'first_order_theory_admission':1,'first_order_tautology':38,'first_order_scheme':12,'fresh_quantified_receiver_final':1})
    for j,s in enumerate(stages):
        ck(name+' exact metadata stage ordinal '+str(j),set(s)=={'input_sha256','limit','ordinal','output_sha256','purpose','record_id','request_sha256','stage'}and s['ordinal']==s['record_id']==j and s['stage']=='COMPLETED'and s['limit']==(1000000000 if j<51 else 5000000000))
        for field in ('input_sha256','output_sha256','request_sha256'):ck(name+' stage hash grammar '+str(j)+' '+field,type(s[field])is str and len(s[field])==64 and all(c in '0123456789abcdef'for c in s[field]))
    wire={p.name:pin(p)for p in(A/'native').iterdir()};ck(name+' exact retained Native filenames',set(wire)=={'code.bin','input.bin','output.bin'})
    for filename,d in wire.items():load(d,name+' opaque Native raw hash only '+filename)
    ck(name+' last opaque wire hashes join last stage only',wire['input.bin']['sha256']==stages[-1]['input_sha256']and wire['output.bin']['sha256']==stages[-1]['output_sha256'])
    rows=f['stage_intervals'];ck(name+'107 cold stages full reached-prefix only',len(rows)==107 and all(set(x)=={'stage','started_ns','returned_ns'}and type(x['started_ns'])is int and type(x['returned_ns'])is int and r['began_ns']<=x['started_ns']<=x['returned_ns']<r['worker_terminal_observed_ns']for x in rows)and all(a['returned_ns']<=b['started_ns']for a,b in zip(rows,rows[1:])))
    names=[x['stage']for x in rows]
    for alias in aliases:
        copystage=('copy schema:'if alias=='mp_schema_certificate'else'copy:')+alias;importstage=('import schema:'if alias=='mp_schema_certificate'else'import:')+alias
        ck(name+' Sourcecopy+import reached metadata '+alias,names.count(copystage)==names.count(importstage)==1 and names.index(copystage)<names.index(importstage))
    ck(name+' schema import follows full base24 and Z3',names.index('import schema:mp_schema_certificate')>names.index('import:Z3')and all(names.index('import:'+alias)<names.index('import schema:mp_schema_certificate')for alias in aliases if alias!='mp_schema_certificate'))
    ck(name+' failure journal not full driver stages',names[-1]=='encode fixed native table'and 'register'not in names and 'model'not in names and 'search'not in names)
    wp=r['python_wait4_usage']['ru_maxrss'];np=n['native_high_water_bytes'];total=wp+np
    ck(name+' Native exact wait4 peak bytes not CPP selfreport',np==n['wait4_usage']['ru_maxrss']and type(np)is int and np>0)
    ck(name+' worker alone necessarily violates original1GiB',type(wp)is int and wp>plan['limits']['aggregate_peak_bytes']and total>plan['limits']['aggregate_peak_bytes'])
    pids.extend([t['runner_pid'],r['python_pid'],n['native_pid']]);groups.append(r['owned_pgid']);allstages.append(stages)
    state=[x for x in closure['states']if x['mode']==name];ck(name+' Root saved closure agrees exact child/group/EOF evidence',len(state)==1 and state[0]['native_pid']==n['native_pid']and all(state[0][k]is True for k in ('native_closed','native_reaped','owned_group_absent','logs_eof'))and state[0]['worker_failure_keys']==sorted(f))
    allrows.append(dict(mode=name,invocation_id=row['invocation_id'],subject_sha256=row['subject_sha256'],actual_directory=str(A),worker_failure=fd,runner_receipt=rd,observer_terminal=td,consumed=cd,observer_consumed=ocd,worker_plan=row['worker_plan'],runner_plan=row['runner_plan'],authorization=row['authorization'],all25ownedSources=copy_pins,logs=logs,observer_stdout=obsout,observer_stderr=obserr,Native_wire_raw=wire,worker_exit_code=1,runner_exit_code=2,Native_exit_code=0,runner_clock_failure_terminal_seconds=elapsed,observed_instrument_failure_seconds=instrument,worker_wait4_peak_bytes=wp,Native_wait4_peak_bytes=np,posthoc_diagnostic_separate_peak_sum_bytes=total,posthoc_diagnostic_separate_peak_sum_MiB=total/1048576,admitted_resource_sum=r['conservative_parent_plus_native_peak_bytes'],complete_result_present=False,worker_receipt_present=False,resource_accepted=False,proof_accepted=False,schema_inventory_admission_established=False,Model_validation_established=False,Native_transport_stage_count=len(stages),Native_transport_stage_purposes=dict(collections.Counter(s['purpose']for s in stages)),cold_stage_prefix_count=len(rows),original128MiB_output_cap_failure=True))
ck('exact cohort all six PID/two groups saved absent',sorted(pids)==sorted(closure['exact_pids'])and sorted(groups)==sorted(closure['exact_groups']))
ck('fixed terminal fully precedes symbolic source entry',get(allrows[0]['observer_terminal'],'fixed terminal repeat')['terminal_observed_ns']<get(allrows[1]['runner_receipt'],'symbolic receipt repeat')['began_ns'])
ck('first51 current transport stage metadata literal equal only',allstages[0][:-1]==allstages[1][:-1])
ck('same opaque generated Native code rawhash both',allrows[0]['Native_wire_raw']['code.bin']['sha256']==allrows[1]['Native_wire_raw']['code.bin']['sha256'])

# Source-only representation hypothesis, without measuring or rebuilding packets.
source_evidence=[]
for alias,functions in [('semantic_receiver_driver',['_atomic_output','run_receiver']),('semantic_inventory_oracle',['_check_inventory_schema_then_native']),('mp_schema_certificate',['_run','check_ground_instance'])]:
    d=(idx['schema_sources']['mp_schema_certificate']if alias=='mp_schema_certificate'else (get(idx['schedule'][0]['worker_plan'],'worker for Source-only hypothesis')['components']['receiver_driver']if alias=='semantic_receiver_driver'else cl['materialized_aliases']['semantic_inventory_oracle']))
    text=load(d,'representation Source raw only '+alias).decode();tree=ast.parse(text)
    for fn in functions:
        nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==fn]
        if not nodes and fn=='_check_schema_inventory':nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='_check_inventory_schema']
        ck('raw hypothesis function exists '+alias+'.'+fn,len(nodes)==1)
        node=nodes[0];segment=ast.get_source_segment(text,node);source_evidence.append(dict(source=d,function=node.name,line=node.lineno,end_line=node.end_lineno,raw_segment_sha256=hashlib.sha256(segment.encode()).hexdigest()))
    if alias=='semantic_receiver_driver':ck('Source cap is whole atomic no truncate/partial remains',"OUTPUT_CAP_BYTES = 128 * 1024 * 1024"in text and "if size > OUTPUT_CAP_BYTES:"in text and "if not published:"in text and "Path(temporary).unlink(missing_ok=True)"in text)
    if alias=='mp_schema_certificate':ck('Source retains complete owned inputs and full original registry perground',"input_snapshot=owned"in text and "dependency_definitions=dependency_definitions"in text and "certificate=c,ground_correspondence=result"in text)
rootauditd=dict(path=str(D/'ROOT-negative-evidence-audit-v1.json'),sha256='e9e59f9281c9229338c1e3394ae2c15bc9577e9abc17a60ecd0fbcbe6769956f',bytes=22332)
rootaudit=get(rootauditd,'Root separate negative audit retained raw only')
audit=write('saved-failure-raw-audit-v2.json',dict(schema='schema-admission-saved-failure-independent-raw-audit-v1',source_only=True,saved_data_only=True,scientific_calls=0,checks=checks,verified_raw_descriptors=list(pins.values()),rows=allrows,Source_only_representation_evidence=source_evidence))
review=write('peer-saved-failure-evidence-review-v2.json',dict(schema='schema-admission-saved-failure-evidence-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',saved_failure_evidence_review_passed=True,data_review_passed=True,negative_bounded_experiment_outcome=True,source_only=True,saved_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,resource_accepted=False,proof_accepted=False,schema_inventory_admission_established=False,Model_validation_established=False,authorized_index=idxd,prelaunch_final_review=reviewd,Root_cohort_closure=closured,Root_fixed_before_symbolic_closure=betweend,Root_separate_negative_audit=rootauditd,current_declaration=idx['case_declaration'],current_runtime_closure=idx['runtime_closure'],rows=allrows,check_count=len(checks),mismatch_count=0,unique_raw_pin_count=len(pins),audit=audit,review_Source=pin(Path(__file__)),findings=[
    dict(id='TWO_CONSUMED_OUTPUT_FAILURES',finding='Both exact reviewed V2 subjects were consumed once. Both workers exited1 with OutputCapExceeded in full atomic JSON serialization, both runners exited2, both observer terminal gates failed. Neither complete result.json nor worker-receipt.json nor partial result remains. Both failures are retained; no retry or cap increase was made.'),
    dict(id='INDEPENDENT_RAM_FAILURE',finding='Darwin worker wait4 ru_maxrss alone exceeds the original1GiB in both arms. Fixed2076295168B plus Native13402112B gives diagnostic2089697280B; symbolic1239760896B plus Native12877824B gives diagnostic1252638720B. These are posthoc sums of separate measured peaks, not admitted runner aggregates or simultaneous live RAM. Runner aggregate is null and all resource-admission flags are false.'),
    dict(id='CLOSED_FAILED_LIFECYCLE',finding='Exact Python and Native were reaped; Native exits0, worker exits1, runner exits2 are distinct. Both retained logs have EOF, owned groups are absent, no signals or observed reappearance, and saved Root process closure agrees all six PIDs/two PGIDs. Failure terminal durations92.995525917s and92.620580833s are not proof timings.'),
    dict(id='SOURCE_COPIES_NOT_FULL_RESULT_AUTHORITY',finding='All25 owned Python Source files per arm match current original raw pins. Full current reviews/subjects/consumption and reached copy/import stage-prefix metadata join. No full returned Source epoch, compiler/inventory/Model/initial/search/point data, schema certificate census or final Native record was published, so complete semantic equality, schema admission, Model validation and proof acceptance are not established.'),
    dict(id='STAGE_HASH_METADATA_ONLY',finding='Each transport retains52 COMPLETED stage metadata entries: one theory,38tautology,12scheme and one final-purpose stage. Last opaque input/output raw hashes join ordinal51; full requests/results are absent. A stage purpose, completed hash or child exit0 is not a proof, certificate, coverage or Native acceptance receipt. No such proof was recovered or inferred.'),
    dict(id='SOURCE_ONLY_REPRESENTATION_HYPOTHESIS',finding='Frozen certifier Source returns each ground packet with complete input_snapshot (including full dependency_definitions and epochs), a reconstructed certificate and ground correspondence. Registry retains each returned packet in its ground census; those ground checks occur for every original definition. This is a concrete structural repetition site worth a separately reviewed representation design. No current packet-size attribution, avoidable-RAM measurement, fit or performance prediction is available from these failed outputs.')
],Source_only_representation_evidence=source_evidence,limitations=[
    'Retained ordinary JSON/raw hash/stat/AST only. No project/scientific module/function, Native, Model, compiler, logic, kernel, solver, search, Reader, renderer or fixture execution, replay or Native/opaque codec decoding. Native code.bin/input.bin/output.bin were only whole raw-hashed. No proof was reconstructed from wire or stage hashes.',
    'Reviewer authored inherited outer/broker and earlier driver/helper/symbolic/benchmark/CASE/checker/diagnosis components. Current Root/Library new Source edits were separately scoped reviews; this is an independent audit of Root execution artifacts, not a new self-certification of own inherited Source or formal kernel soundness.',
    'Negative evidence review PASS means the retained failure/custody interpretation is consistent. It does not mean either experiment passed its profile, schema admission or mathematical proof gates. Native child exit0 means transport process closure only. No bounded result exists for whole semantic Model/input/target/theory/registry/proof joins.',
    'Exact failed serialized candidate size and the fields that crossed128MiB were not retained. Source cap branch plus traceback establishes the original full cap failure, not a size estimate or a safely salvageable prefix. No truncation, hidden packet selection, packet recomputation, output recovery or old proof substitution is admitted.',
    'Worker-failure stage_intervals are107 cold intake/import/native-setup stages, ending at native table encoding; they are not full driver register/Model/search/output progress receipts.52 transport stage hashes prove only retained transport metadata. Current formula/registry/checker outcomes cannot be checked from those hashes.',
    'No positive worker receipt or full output/header/Reader inverse exists. Outer positive final raw loop and resource aggregation are skipped after failed worker exit; current raw Source copy equality does not retroactively prove those unreturned live checks. Interpreter baseline/stat and trusted OS/loader scopes remain conditional; observer/controller RAM and interpreter/observer prelude exclusions remain inherited.',
    'Saved Root process inspection and recorded reaping/EOF/group probes are retained observations, not a new live process query or formal all-descendant proof. Both terminal durations are failure costs only. Diagnostic separate highwater sums may double-count inherited pages and are not simultaneous memory measurements or enforced OS limits.',
    'The duplicate-input/certificate hypothesis is Source-only and unmeasured. Any future interning/reference-packet design must preserve complete literal preimages, independent reconstruction, exact ownership/error custody, full original registry and final Native/point authority under a new reviewed declaration; this audit authorizes no implementation, retry, budget raise or theorem/fit/speed/RL/GCTS advantage claim.'
]))
handoff=write('saved-failure-peer-handoff-v2.json',dict(schema='schema-admission-saved-failure-peer-handoff-v1',review=review,audit=audit,authorized_index=idxd,source_only=True,saved_data_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False))
print(json.dumps(dict(review=review,audit=audit,handoff=handoff,checks=len(checks),rawpins=len(pins),table=[{k:r[k]for k in ('mode','runner_clock_failure_terminal_seconds','worker_wait4_peak_bytes','Native_wait4_peak_bytes','posthoc_diagnostic_separate_peak_sum_bytes')}for r in allrows]),indent=2))
