Retained first explicit schema-admission matched pilot: two scientific actuals.
Both fail whole-output serialization at the original128MiB guard. Both workers
alone also exceed the original1GiB memory cap. No complete current result,
worker success receipt, schema/Model permission or target proof is admitted.
No successful proof is recovered from Native wire or stage hashes.

The archive preserves full surviving files, including raw Source copies and
last wire files, both consumed exact once plans, false draft history, original
inputs and negative audits. There are no result.json files to reconstruct.
Opaque Native microcode is copied raw; no posthoc inner decode/replay occurs.
The external Python/Z3/stdlib/loader/OS are identified but not bundled.
Reproduction needs fresh bounded declarations and authorizations; consumed
subjects cannot be rerun. This failure baseline remains immutable.

The next design is Source-only and unimplemented. Both encoded and expanded
canonical sizes must be reported; a compact byte limit cannot silently replace
the old expanded JSON guard while claiming the same serialization profile.
