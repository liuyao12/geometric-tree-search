"""Derive the explicit schema receiver driver from frozen raw Source."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).parent
parent=Path('/private/tmp/gcts-adaptive-groups-ROOT-source-20261019/inventory_certification_receiver_driver_v3.py')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert pin(parent)['sha256']=='16186e8a0c3906be90d716145cff3d52830ab0cd1f12a0fd366342abf6e55912'
registry=pin('/private/tmp/gcts-schema-admission-source-20261019/semantic_inventory_oracle_v4.py')
assert registry['sha256']=='a50579cb6ba326d32de3f203214963ec4bcf184613413a2abae2a2f6bb889eca'
gates=json.loads((D/'consumer-gate-Source-contract-v1.json').read_bytes())
gp={r['role']:r['current']for r in gates['changes']}
schema=pin('/private/tmp/gcts-mp-schema-source-20261019/mp_schema_certificate_v1.py')
assert schema['sha256']=='7351d5954763e8b671411a78a821e5cc560ac1af19477a9491da573a735d2ae4'
s=parent.read_text();tree=ast.parse(s)
node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='DEPENDENCY_PINS'for t in n.targets))
old=ast.get_source_segment(s,node);deps=ast.literal_eval(node.value)
for role,descriptor in [('family_registry',registry),('schema_certificate',schema),('family_model',gp['model']),('symbolic_control',gp['symbolic']),('support_ordering',gp['support'])]:
 deps[role]=(descriptor['sha256'],descriptor['bytes'])
s=s.replace(old,'DEPENDENCY_PINS = '+repr(deps),1)
s=s.replace("'ordinary': ('f65eb38269db74ff5db0d9eb2096a38d7f07bbd6a579aa564acc692f84e4437c', 6472)",
            "'ordinary': "+repr((gp['model']['sha256'],gp['model']['bytes'])),1)
s=s.replace("VERSION = 'semantic-family-inventory-certification-driver-v3'","VERSION = 'semantic-family-schema-admission-driver-v4'",1)
s=s.replace("SOURCE_EPOCH_SCHEMA = 'semantic-family-receiver-source-epoch-v5-adaptive-inventory-groups'",
            "SOURCE_EPOCH_SCHEMA = 'semantic-family-receiver-source-epoch-v6-explicit-schema-admission'",1)
old="inventory_certification_mode not in ('bulk','dependency_closures','adaptive_groups')"
assert s.count(old)==1;s=s.replace(old,"inventory_certification_mode not in ('bulk','dependency_closures','adaptive_groups','schema_then_native')")
helpers=(D/'schema_driver_helpers_v1.txt').read_text()
assert s.count('def run_receiver(')==1;s=s.replace('def run_receiver(',helpers+'\n\ndef run_receiver(',1)
old="""                inventory = stage('register', lambda: modules['family_registry'].check_inventory(spec, inventory, oracle, limit=5*10**9, mode=inventory_certification_mode))
                stage('inventory_record_join', lambda: _inventory_record_join(inventory, oracle.records, spec, boundary, inventory_certification_mode))
                if inventory['status'] != 'native_accepted':
"""
new="""                if inventory_certification_mode == 'schema_then_native':
                    original_inventory = _owned(inventory)
                    schema_context = _schema_context_for(spec, library, compiled, modules, module_pins, boundary)
                    before_registration = len(oracle.records)
                    inventory = stage('register', lambda: modules['family_registry'].check_inventory(
                        spec, inventory, oracle, limit=5*10**9, mode=inventory_certification_mode,
                        schema_context=schema_context))
                    stage('inventory_record_join', lambda: _schema_inventory_record_join(
                        inventory, original_inventory, oracle.records, before_registration,
                        spec, schema_context, boundary))
                    inventory_ready = (inventory['status'] == 'schema_admitted'
                        and inventory['certification']['complete'] is True
                        and inventory['certification']['Model_permission'] is True)
                else:
                    inventory = stage('register', lambda: modules['family_registry'].check_inventory(spec, inventory, oracle, limit=5*10**9, mode=inventory_certification_mode))
                    stage('inventory_record_join', lambda: _inventory_record_join(inventory, oracle.records, spec, boundary, inventory_certification_mode))
                    inventory_ready = inventory['status'] == 'native_accepted'
                if not inventory_ready:
"""
assert s.count(old)==1;s=s.replace(old,new,1)
old="                    status=result['status'], native_proof_accepted=result['native_proof_accepted'],"
new="""                    status=result['status'], native_proof_accepted=result['native_proof_accepted'],
                    schema_inventory_admitted=(inventory_certification_mode == 'schema_then_native'
                        and result['work_window_complete'] is True
                        and result['outputs'].get('register',{}).get('status') == 'schema_admitted'
                        and result['outputs']['register']['certification']['Model_permission'] is True),
"""
assert s.count(old)==1;s=s.replace(old,new,1)
p=D/'schema_admission_receiver_driver_v4.py';assert not p.exists();p.write_text(s)
ast.parse(s);compile(s,str(p),'exec')
out=dict(schema='ROOT-schema-admission-driver-Source-contract-v1',author_identity='/root',
 source_only=True,scientific_calls=0,module_evaluations=0,parse_compile_without_evaluation=1,
 parent=pin(parent),current=pin(p),registry=registry,certifier=schema,consumer_gates=pin(D/'consumer-gate-Source-contract-v1.json'),
 ABI='run_receiver original API with explicit mode schema_then_native and a ninth injected module role schema_certificate. Same old8 roles; current gate Source pins in dependency map. Fresh exact relevant Source/semantic capsules and syntax-only callback passed to registry.',
 changes=['New explicit epoch and dependency pins.','Schema context and independent complete literal/cost/custody joins before Model; no relabeling Native acceptance.','Original registry modes remain old branch; candidate creation/ranking/search/final Native/point/rollback paths retained.','Receipt explicitly reports complete schema Model admission; outer must require positive work/known worker exit by180 for this flag too.'],
 profile='Original180/210/1GiB/128MiB, same compiler/search/Native caps. No scientific evaluation or actual authorization.',
 limitations='Source only; genuine independent review pending. No formalized universal soundness or fit/performance/theorem result.')
f=D/'driver-Source-contract-v1.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
