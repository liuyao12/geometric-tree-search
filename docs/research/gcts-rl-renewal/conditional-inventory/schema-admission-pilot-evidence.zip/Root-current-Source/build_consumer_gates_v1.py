"""Raw Source transformations only; no scientific imports/evaluation."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).parent
GATE='''

# New explicit consumer gate. The driver separately authenticates every full
# registry packet. This predicate is not an independent mathematical checker.
SCHEMA_ADMISSION_GATE_VERSION = 'explicit-complete-schema-consumer-gate-v1'
def _inventory_admission_ready(inventory):
    if inventory.get('status') == 'native_accepted':
        return True  # historical path, unchanged
    c = inventory.get('certification')
    return (inventory.get('status') == 'schema_admitted' and type(c) is dict
            and c.get('schema') == 'schema-then-native-inventory-certification-v1'
            and c.get('version') == 'inventory-schema-then-native-v1'
            and c.get('mode') == 'schema_then_native'
            and c.get('complete') is True and c.get('Model_permission') is True
            and c.get('native_accepted') is False
            and c.get('fresh_Native_target_proof_accepted') is False
            and c.get('final_whole_Native_required') is True)
'''
PROJECTION='''

def _inventory_admission_projection(inventory):
    # Preserve the historical four-field graph projection in Native lanes.
    # In the explicit schema lane retain only gate provenance here, never
    # duplicate full certificate packets into the heuristic graph.
    out = {k: inventory[k] for k in
           ('status', 'definitions', 'interfaces', 'native_blocks')}
    if inventory.get('status') == 'schema_admitted':
        c = inventory.get('certification')
        out['certification'] = ({k: c.get(k) for k in
            ('schema', 'version', 'mode', 'complete', 'Model_permission',
             'native_accepted', 'fresh_Native_target_proof_accepted',
             'final_whole_Native_required')} if type(c) is dict else None)
    return out
'''
sources=[
 ('model','/private/tmp/gcts-quantified-adapter-source-20261018/quantified_family_points_v2.py','schema_admission_family_points_v3.py'),
 ('symbolic','/private/tmp/gcts-and-support-ordering-source-20261018/quantified_symbolic_control_v2.py','schema_admission_symbolic_control_v3.py'),
 ('support','/private/tmp/gcts-and-support-ordering-source-20261018/receptor_support_ordering_v1.py','schema_admission_support_ordering_v2.py')]
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
changes=[]
for role,origin,name in sources:
 raw=Path(origin).read_text();s=raw
 anchor=next(n.lineno for n in ast.parse(raw).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)))
 lines=s.splitlines(keepends=True);s=''.join(lines[:anchor-1])+GATE+(PROJECTION if role=='support'else'')+'\n'+''.join(lines[anchor-1:])
 if role=='model':
  old="if compiled['status']!='complete' or inventory['status']!='native_accepted':raise ValueError('unfinished admission is not authority')"
  assert s.count(old)==1;s=s.replace(old,"if compiled['status']!='complete' or not _inventory_admission_ready(inventory):raise ValueError('unfinished admission is not authority')")
  old='        return r\n';assert s.count(old)==1
  s=s.replace(old,"""        if self.inventory['status'] == 'schema_admitted':
            r['inventory_admission'] = dict(status='schema_admitted',
                consumer_gate=SCHEMA_ADMISSION_GATE_VERSION,
                native_accepted=False, final_whole_Native_required=True,
                authority='Complete schema registry permission; final proof authority remains Native.')
            r['scope'] = r['scope'].replace('Every actual block requires native checking.',
                'Every actual block requires complete declared schema-or-Native admission; the final proof and all used definitions still require fresh whole Native checking.')
        return r
""")
  s=s.replace('its actual ordered premises and needs whole native admission before use.',
              'its actual ordered premises. Native or explicit completed schema admission\\npermits candidate construction; the final proof always needs Native checking.')
 elif role=='symbolic':
  old="if compiled['status'] != 'complete' or inventory['status'] != 'native_accepted':"
  assert s.count(old)==1;s=s.replace(old,"if compiled['status'] != 'complete' or not _inventory_admission_ready(inventory):")
 else:
  old="""inventory={k: inventory[k] for k in
                                       ('status', 'definitions', 'interfaces', 'native_blocks')})"""
  assert s.count(old)==1;s=s.replace(old,'inventory=_inventory_admission_projection(inventory))')
  old="if c['status'] != 'complete' or inv['status'] != 'native_accepted':"
  assert s.count(old)==1;s=s.replace(old,"if c['status'] != 'complete' or not _inventory_admission_ready(inv):")
 dest=D/name;assert not dest.exists();dest.write_text(s)
 tree=ast.parse(s);compile(s,str(dest),'exec')
 # New predicate Source is literally shared, not independently tweaked.
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='_inventory_admission_ready')
 assert ast.get_source_segment(s,fn)==ast.get_source_segment(GATE,ast.parse(GATE).body[1])
 changes.append(dict(role=role,origin=pin(origin),current=pin(dest),new_gate_only=True))
out=dict(schema='ROOT-schema-admission-consumer-gate-Source-contract-v1',
 author_identity='/root',source_only=True,scientific_calls=0,module_evaluations=0,
 parse_compile_without_evaluation=3,changes=changes,
 preservation='All point construction, metadata, inventory multiplicity, ranking, search and rollback algorithms retained. Isolated admission gates/provenance only; Native historical record unchanged.',
 gaps='These booleans are consumer guards, not mathematical authority. Root driver must verify complete full registry and current Native theory custody. New gate Source review pending; no runtime qualification or launch.')
p=D/'consumer-gate-Source-contract-v1.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
