"""Raw Source derive the seven-scope once/observer adapters."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).parent
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
old_dir=Path('/private/tmp/gcts-mp-schema-shadow-intake-ROOT-source-20261019')
parent=old_dir/'mp_schema_shadow_once_runner_v3.py';s=parent.read_text();tree=ast.parse(s)
cold=pin(D/'schema_admission_cold_v1.py')
certifier=pin('/private/tmp/gcts-mp-schema-source-20261019/mp_schema_certificate_v1.py')
g=json.loads((D/'consumer-gate-Source-contract-v1.json').read_bytes());gp={r['role']:r['current']for r in g['changes']}
def one(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old));s=s.replace(old,new,1)
def span(begin,end,new):
 global s
 a=s.index(begin);b=s.index(end,a);s=s[:a]+new+s[b:]
roles={
 'retained_ordering_Source':('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
 'consumer_gates_Source':('schema-admission-consumer-gate-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'registry_Source':('schema-admission-registry-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'driver_Source':('schema-admission-driver-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'composition_Source':('schema-admission-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'once_Source':('schema-admission-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'prospective_plans':('schema-admission-prospective-plan-review-v1','prospective_review_passed','/root/conventional_control_review')}
updates={
 'VERSION':'schema-admission-external-once-runner-v1',
 'PLAN_SCHEMA':'ROOT-schema-admission-once-plan-v1',
 'AUTH_SCHEMA':'ROOT-schema-admission-once-authorization-v1',
 'WORKER_RECEIPT_SCHEMA':'schema-admission-worker-receipt-v1',
 'RECEIPT_SCHEMA':'schema-admission-external-once-receipt-v1',
 'KINDS':('fixed','symbolic'),'CERTIFICATIONS':('schema_then_native',),
 'COLD_PIN':cold,'SHADOW_SOURCES':{'mp_schema_certificate':certifier},'REVIEW_ROLES':roles}
for name,v in updates.items():
 n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets))
 one(ast.get_source_segment(parent.read_text(),n),('SCHEMA_SOURCES'if name=='SHADOW_SOURCES'else name)+' = '+repr(v))
retained={
 'family_search':pin('/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py'),
 'symbolic_control':pin('/private/tmp/gcts-and-support-ordering-source-20261018/quantified_symbolic_control_v2.py'),
 'support_ordering':pin('/private/tmp/gcts-and-support-ordering-source-20261018/receptor_support_ordering_v1.py')}
one('def intake_subject(plan, overall_end):','RETAINED_ORDERING_SOURCES = '+repr(retained)+'\n\n\ndef intake_subject(plan, overall_end):')
s=s.replace("'ROOT-mp-schema-shadow-worker-plan-v1'","'ROOT-schema-admission-worker-plan-v1'").replace("'ROOT-mp-schema-shadow-raw-runtime-closure-v1'","'ROOT-schema-admission-raw-runtime-closure-v1'").replace("'ROOT-mp-schema-shadow-qualification-declaration-v1'","'ROOT-schema-admission-comparison-declaration-v1'")
s=s.replace("closure['shadow_sources']==SHADOW_SOURCES","closure['schema_sources']==SCHEMA_SOURCES")
one("'whole two shadow Source descriptors'","'whole one separately sealed schema certifier Source'")
one("need(len(ids)==1 and len(set(ids))==1 and ids.count(plan['invocation_id'])==1 and",
    "need(len(ids)==2 and len(set(ids))==2 and ids.count(plan['invocation_id'])==1 and")
one("len({r['actual_directory'] for r in schedule})==1 and","len({r['actual_directory'] for r in schedule})==2 and")
one("'complete single fixed/bulk Native plus shadow declaration'","'complete matched fixed/symbolic explicit schema declaration'")
one("'exact five current scoped review roles'","'exact seven current scoped review roles with disclosed ancestry'")
span("    minimum={'ordering_Source':", "    checked={}", """    minimum={
        'retained_ordering_Source':list(RETAINED_ORDERING_SOURCES.values()),
        'consumer_gates_Source':[worker['project_sources'][k] for k in
            ('quantified_family_points_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],
        'registry_Source':[worker['project_sources']['semantic_inventory_oracle']]+list(SCHEMA_SOURCES.values()),
        'driver_Source':[worker['components']['receiver_driver'],worker['project_sources']['semantic_inventory_oracle']]+list(SCHEMA_SOURCES.values()),
        'composition_Source':[plan['cold'],worker['components']['receiver_driver']]+list(SCHEMA_SOURCES.values()),
        'once_Source':[plan['runner'],plan['observer']],
        'prospective_plans':[plan['integration_declaration'],plan['runtime_closure'],plan['worker_plan']]}
""")
one("['work_completed','logical_proof_accepted','primary_family_hint_accepted']",
    "['work_completed','logical_proof_accepted','primary_family_hint_accepted','schema_inventory_admitted']")
span("        shadow_meta=worker_receipt['schema_shadow']", "        search_role=", """        schema_meta=worker_receipt['schema_admission']
        register=result['outputs'].get('register',{})
        cert=register.get('certification',{}) if type(register)is dict else {}
        complete_schema=(result['work_window_complete']is True and
            register.get('status')=='schema_admitted' and cert.get('complete')is True and
            cert.get('Model_permission')is True)
        need(worker_receipt['schema_inventory_admitted']is complete_schema and
             schema_meta['complete_schema_inventory_admitted']is complete_schema and
             schema_meta['inventory_status']==register.get('status','NOT_REACHED') and
             schema_meta['registry_Model_permission']is cert.get('Model_permission',False) and
             schema_meta['mode']=='schema_then_native' and
             schema_meta['native_accepted_by_schema']is False and
             schema_meta['final_whole_Native_required']is True,
             'explicit schema registry permission separated from Native proof authority')
        need(schema_meta['sources']['original']==SCHEMA_SOURCES and
             all(schema_meta['sources'][k]==result['source_epoch']['schema_sources'][k]
                 for k in ('original','owned')) and
             schema_meta['kernel_source']==result['source_epoch']['schema_sources']['kernel_source'] and
             result['module_pins']['schema_certificate']==schema_meta['sources']['owned']['mp_schema_certificate'],
             'whole separately sealed current schema Source capsule')
        if complete_schema:
            need(worker_receipt['work_completed']is True and terminal_ns<work_end and
                 worker_receipt['result_reading']['completed_ns']<work_end,
                 'positive complete schema admission, reading and known worker exit before180')
""")
one("need(worker_receipt['logical_proof_accepted'] is False and worker_receipt['primary_family_hint_accepted'] is False,'after-work UNKNOWN has no proof flags')",
    "need(worker_receipt['logical_proof_accepted'] is False and worker_receipt['primary_family_hint_accepted'] is False and worker_receipt['schema_inventory_admitted'] is False,'after-work UNKNOWN has no positive proof/schema flags')")
assert all(w not in s for w in ['schema_shadow','schema-shadow-result','SHADOW_SOURCES','SHADOW_QUALIFICATION','shadow_sources'])
runner=D/'schema_admission_once_runner_v1.py';assert not runner.exists();runner.write_text(s);ast.parse(s);compile(s,str(runner),'exec')
# Observer only binds the new plan/runner/version, retains exact failure-only225
# fallback and all terminal210/resource/EOF/group requirements.
observer_parent=old_dir/'observe_mp_schema_shadow_runner_v3.py';o=observer_parent.read_text()
o=o.replace('mp-schema-shadow-final-terminal-observer-v3','schema-admission-final-terminal-observer-v1')
o=o.replace('ROOT-mp-schema-shadow-once-plan-v1','ROOT-schema-admission-once-plan-v1')
o=o.replace('d6abb164ef920f1fcab5f0efc6499762474f2e7a82d796a2ac4ea414ae6fedf8',pin(runner)['sha256'])
observer=D/'observe_schema_admission_runner_v1.py';assert not observer.exists();observer.write_text(o);ast.parse(o);compile(o,str(observer),'exec')
out=dict(schema='ROOT-schema-admission-intake-Source-contract-v1',author_identity='/root',
 source_only=True,scientific_calls=0,module_evaluations=0,parse_compile_without_evaluation=2,
 cold=pin(D/'schema_admission_cold_v1.py'),runner=pin(runner),observer=pin(observer),
 cold_contract=pin(D/'cold-Source-contract-v1.json'),runner_parent=pin(parent),observer_parent=pin(observer_parent),
 current_review_roles=roles,retained_ordering_subjects=retained,
 disclosure='Seven scopes, six unique review receipts expected, only two reviewer identities; composition+once share one intake review. Retained old algorithm ancestry is explicit; new consumer gates/registry/driver/intake are distinct exact scoped reviews.',
 profile='180scientific/210terminal, positive complete schema permission and all known worker exit/reading/headers before180 too;1GiB conservative separate worker+Native highwaters;128MiB whole result; originals unchanged.',
 scientific_scope='Two prospective complete case002 matched methods; no proof route, trimming, recursive proposer, learned policy or Native rule change. No actual or launch authorization. Outer still only transport/resource custody, Root admits saved full logical/point/schema evidence separately.')
f=D/'intake-Source-contract-v1.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
