"""Raw derive a new explicit-lane cold adapter; no scientific evaluation."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).parent
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
parent=Path('/private/tmp/gcts-mp-schema-shadow-intake-ROOT-source-20261019/mp_schema_shadow_cold_v3.py')
assert pin(parent)['sha256']=='5a9fae2f4747bc3049c408394a497b276ba15685b90469c44b02b4ecdf0282e0'
s=parent.read_text()
driver=pin(D/'schema_admission_receiver_driver_v4.py')
registry=pin('/private/tmp/gcts-schema-admission-source-20261019/semantic_inventory_oracle_v4.py')
certifier=pin('/private/tmp/gcts-mp-schema-source-20261019/mp_schema_certificate_v1.py')
gates=json.loads((D/'consumer-gate-Source-contract-v1.json').read_bytes());gp={r['role']:r['current']for r in gates['changes']}
def one(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old));s=s.replace(old,new,1)
def span(begin,end,new):
 global s
 a=s.index(begin);b=s.index(end,a);s=s[:a]+new+s[b:]
tree=ast.parse(s)
updates={
 'VERSION':'schema-admission-intake-cold-v1',
 'PLAN_SCHEMA':'ROOT-schema-admission-worker-plan-v1',
 'EPOCH_SCHEMA':'semantic-family-receiver-source-epoch-v6-explicit-schema-admission',
 'WORKER_SCHEMA':'schema-admission-worker-receipt-v1',
 'RECEIVER_DRIVER_SOURCE':driver,'REGISTRY_SOURCE':registry,
 'ORDERING_COMPONENT_SOURCES':dict(family_search=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='ORDERING_COMPONENT_SOURCES'for t in n.targets)))['family_search'],
    support_ordering=gp['support'],symbolic_control=gp['symbolic']),
 'SHADOW_SOURCES':{'mp_schema_certificate':certifier}}
for name,value in updates.items():
 n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets))
 old=ast.get_source_segment(parent.read_text(),n)
 one(old,(('SCHEMA_SOURCES'if name=='SHADOW_SOURCES'else name)+' = '+repr(value)))
one("MODEL_STORAGE_MODULES = {","ORDINARY_MODEL_SOURCE = "+repr(gp['model'])+"\n\nMODEL_STORAGE_MODULES = {")
s=s.replace('SHADOW_SOURCES','SCHEMA_SOURCES').replace('owned_shadow','owned_schema').replace('shadow_loaded','schema_loaded')
one("need(plan['mode']=='fixed','declared mechanism-control mode')",
    "need(plan['mode'] in ('fixed','symbolic'),'declared matched mechanism-control mode')")
one("need(plan['inventory_certification_mode']=='bulk', 'explicit inventory certification mode')",
    "need(plan['inventory_certification_mode']=='schema_then_native', 'explicit new inventory certification lane')")
one("'ROOT-mp-schema-shadow-qualification-declaration-v1'","'ROOT-schema-admission-comparison-declaration-v1'")
one("""        need(len(schedule)==1 and len({r['invocation_id'] for r in schedule})==1 and
             len({r['actual_directory'] for r in schedule})==1 and
             {(r['mode'],r['inventory_certification_mode']) for r in schedule}==
                 {('fixed','bulk')} and""",
"""        need(len(schedule)==2 and len({r['invocation_id'] for r in schedule})==2 and
             len({r['actual_directory'] for r in schedule})==2 and
             {(r['mode'],r['inventory_certification_mode']) for r in schedule}==
                 {('fixed','schema_then_native'),('symbolic','schema_then_native')} and""")
one("'one complete fixed/bulk Native control plus explicit shadow qualification'",
    "'two complete matched methods under the explicit schema admission lane'")
one("'ROOT-mp-schema-shadow-raw-runtime-closure-v1'","'ROOT-schema-admission-raw-runtime-closure-v1'")
one("        expected_project['semantic_inventory_oracle']=REGISTRY_SOURCE",
"""        expected_project['semantic_inventory_oracle']=REGISTRY_SOURCE
        expected_project['quantified_family_points_v2']=ORDINARY_MODEL_SOURCE
        expected_project['receptor_support_ordering_v1']=ORDERING_COMPONENT_SOURCES['support_ordering']
        expected_project['quantified_symbolic_control_v2']=ORDERING_COMPONENT_SOURCES['symbolic_control']""")
one("closure['shadow_sources']==SCHEMA_SOURCES","closure['schema_sources']==SCHEMA_SOURCES")
one("'whole separately reviewed shadow Sources and semantic kernel Source'",
    "'whole separately reviewed schema certifier and semantic kernel Source'")
s=s.replace('fresh separately scoped shadow module','fresh separately scoped schema module').replace("'copy shadow:'","'copy schema:'")
s=s.replace('shadow import','schema import').replace("'import shadow:'","'import schema:'").replace('exact shadow import origin','exact schema import origin')
one("need(len(loaded)==24 and len(schema_loaded)==2,'same full24 plus exactly2 schema imports')",
    "need(len(loaded)==24 and len(schema_loaded)==1,'full current base24 plus exactly1 schema import')")
one("shadow_sources=dict(original=SCHEMA_SOURCES,owned=owned_schema,kernel_source=SCHEMA_KERNEL_SOURCE)",
    "schema_sources=dict(original=SCHEMA_SOURCES,owned=owned_schema,kernel_source=SCHEMA_KERNEL_SOURCE)")
one("        roles['family_model']=loaded[MODEL_STORAGE_MODULES[plan['model_storage']]]",
"""        roles['family_model']=loaded[MODEL_STORAGE_MODULES[plan['model_storage']]]
        roles['schema_certificate']=schema_loaded['mp_schema_certificate']""")
one("reading_started=_NOW_NS();positive=receipt['native_proof_accepted'] or receipt['family_hint_success']",
    "reading_started=_NOW_NS();positive=receipt['native_proof_accepted'] or receipt['family_hint_success'] or receipt['schema_inventory_admitted']")
span("        # Base driver/result authority stays byte-for-byte separate.", "        source_guard()\n        positive=receipt['native_proof_accepted']", """        # New explicit registry permission never substitutes for final Native.
        need(canonical(result_data['records'])==canonical(oracle_box[0].records),
             'complete current Native ledger after driver closure')
        register=result_data['outputs'].get('register',{})
        cert=register.get('certification',{}) if type(register)is dict else {}
        complete_schema=(result_data['work_window_complete'] is True and
            register.get('status')=='schema_admitted' and cert.get('complete')is True and
            cert.get('Model_permission')is True)
        need(type(receipt['schema_inventory_admitted'])is bool and
             receipt['schema_inventory_admitted']is complete_schema,
             'current whole registry permission and driver work-window receipt')
        schema_observation=dict(mode='schema_then_native',
            inventory_status=register.get('status','NOT_REACHED'),
            complete_schema_inventory_admitted=complete_schema,
            registry_Model_permission=cert.get('Model_permission',False),
            native_accepted_by_schema=False,final_whole_Native_required=True,
            sources=dict(original=SCHEMA_SOURCES,owned=owned_schema),
            kernel_source=SCHEMA_KERNEL_SOURCE)
""")
one("        positive=receipt['native_proof_accepted'] or receipt['family_hint_success']",
    "        positive=receipt['native_proof_accepted'] or receipt['family_hint_success'] or receipt['schema_inventory_admitted']")
one("            logical_proof_accepted=receipt['native_proof_accepted'],",
"""            logical_proof_accepted=receipt['native_proof_accepted'],
            schema_inventory_admitted=receipt['schema_inventory_admitted'],""")
one("            schema_shadow=shadow_observation,","            schema_admission=schema_observation,")
# No legacy shadow execution or output remains.
assert all(w not in s for w in ['run_shadow(', 'schema-shadow-result.json', 'shadow_observation','SHADOW_QUALIFICATION','shadow_sources'])
p=D/'schema_admission_cold_v1.py';assert not p.exists();p.write_text(s);ast.parse(s);compile(s,str(p),'exec')
out=dict(schema='ROOT-schema-admission-cold-Source-contract-v1',author_identity='/root',
 source_only=True,scientific_calls=0,module_evaluations=0,parse_compile_without_evaluation=1,
 parent=pin(parent),current=pin(p),driver=driver,registry=registry,certifier=certifier,
 ordinary_model=gp['model'],symbolic_control=gp['symbolic'],support_ordering=gp['support'],
 current_alias_scope='Original24 aliases with explicit registry/driver/threeconsumer Source replacements, plus exactly1 separately copied/sealed certifier; actual current runtime25. Base24+Z3+cold sealed before certifier import, no rebaseline.',
 outcome_scope='Explicit new schema lane, same full original input and Native runtime; no shadow fixtures/sidecar. Complete positive registry permission joins and original final Native/point/result gates. All positive schema or proof reading/headers/knownexit before180 required; UNKNOWN closure210 only.',
 preserved_profile='Original180/210/1GiB/128MiB, no budget increase or candidate/point/mark/route change. Timed actuals not authorized.')
f=D/'cold-Source-contract-v1.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
