"""Validate the saved report and archive bytes, not scientific content by replay."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re,subprocess,urllib.parse,zipfile
D=Path(__file__).parent;OUT=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.scripts=[];self.inscript=False;self.buf=''
 def handle_starttag(self,t,a):
  a=dict(a)
  if 'id'in a:self.ids.append(a['id'])
  if t=='a':self.links.append(a.get('href',''))
  if t=='script':self.inscript=True;self.buf=''
 def handle_data(self,s):
  if self.inscript:self.buf+=s
 def handle_endtag(self,t):
  if t=='script'and self.inscript:self.scripts.append(self.buf);self.inscript=False
p=OUT/'schema-admission-pilot.html';raw=p.read_bytes();text=raw.decode();h=Parser();h.feed(text)
assert len(h.ids)==len(set(h.ids))and '@@'not in text and '\x00'not in text
for href in h.links:
 u=urllib.parse.urlsplit(href)
 if u.scheme:continue
 if u.path:assert(OUT/urllib.parse.unquote(u.path)).is_file(),href
 elif u.fragment:assert u.fragment in h.ids,href
assert len(h.scripts)==3 and not h.scripts[1]
node='/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
script=D/'report-inline-v1.js';script.write_text(h.scripts[-1]);subprocess.run([node,'--check',str(script)],check=True)
saved=json.loads(re.search(r'const saved=(.*);\nconst ms=',h.scripts[-1]).group(1))
a=load(D/'ROOT-negative-evidence-audit-v1.json');summary=load(OUT/'schema-admission-pilot-summary.json')
for mode in ['fixed','symbolic']:
 packet=load(OUT/('schema-admission-pilot-'+mode+'-failure.json'));assert packet==saved[mode]
 ad=D/('actual-'+mode+'-v2');assert packet['worker_failure']==load(ad/'worker-failure.json')and packet['runner_receipt']==load(ad/'runner-receipt.json')
 assert not packet['proof_accepted']and not packet['resource_accepted']and not packet['full_result_available']
for r in a['actuals']:
 for field in ['worker_peak_bytes','Native_peak_bytes','diagnostic_separate_peak_sum_bytes']:
  assert next(v for v in summary['actuals']if v['mode']==r['mode'])[field]==r[field]
 assert f"{r['worker_peak_bytes']/1048576:,.3f}".replace(',','\\,')in text
 assert f"{r['failure_terminal_seconds']:.3f}"in text
assert summary['current_whole_Model_equality_established']is False and summary['admitted_target_proofs']==0
manifest=load(OUT/'schema-admission-pilot-evidence-manifest.json')
for item in manifest['assets']:assert pin(item['path'])==item
assert pin(manifest['archive']['path'])==manifest['archive']
with zipfile.ZipFile(manifest['archive']['path'])as z:
 assert z.testzip()is None
 assert len(z.namelist())==len(manifest['members'])and len(z.namelist())==len(set(z.namelist()))
 for m in manifest['members']:
  b=z.read(m['member']);assert len(b)==m['bytes']and hashlib.sha256(b).hexdigest()==m['sha256']
 assert not any(n.endswith('/result.json')or n.endswith('/worker-receipt.json')for n in z.namelist())
 assert all(any(n.endswith('/'+v)for n in z.namelist())for v in ['next-storage-design-v1.json','typed-pilot-report-scope-review-v2.json'])
assert 'schema-admission-pilot' in(OUT/'reader.html').read_text()
expected={'docs/research/gcts-rl-renewal/conditional-inventory/'+Path(m['path']).name for m in manifest['assets']}
expected|={'docs/research/gcts-rl-renewal/conditional-inventory/'+n for n in ['schema-admission-pilot-evidence.zip','schema-admission-pilot-evidence-manifest.json']}
r=subprocess.run(['git','diff','--name-only'],cwd=OUT.parents[3],capture_output=True,text=True,check=True)
assert set(r.stdout.splitlines())<=expected
out=dict(schema='ROOT-schema-admission-publication-validation-v1',report=pin(p),whole_assets=[pin(OUT/Path(x).name)for x in sorted(expected)],HTML_ids=len(h.ids),local_links=len(h.links),inline_JS_syntax_passed=True,embedded_receipts_literal_equal=True,whole_archive_members=len(manifest['members']),whole_archive_hashes_verified=True,scientific_replays=0,Native_calls=0,opaque_Native_decodes=0,goal_complete=False)
p=D/'ROOT-publication-validation-v1.json';p.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(validation=pin(p),assets=len(expected),members=len(manifest['members']))))
