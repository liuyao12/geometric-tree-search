"""Publish saved failure diagnostics; no scientific imports or decoding."""
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).parent;P=D/'plans-v2';PUB=Path('/private/tmp/gcts-split-controls-publish-20261015');OUT=PUB/'docs/research/gcts-rl-renewal/conditional-inventory'
PEER=Path('/private/tmp/gcts-schema-admission-peer-20261019')
def load(p):return json.loads(Path(p).read_bytes())
def rawpin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def pin(p):
 p=Path(p).resolve();return dict(path=str(p),**rawpin(p.read_bytes()))
def save(p,v):
 p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
a=load(D/'ROOT-negative-evidence-audit-v1.json');idx=load(P/'authorized-index-v2.json');case=load(idx['case_declaration']['path'])
reviewpath=PEER/'peer-saved-failure-evidence-review-v2.json';review=load(reviewpath)
assert a['negative_evidence_audit_passed'] and a['scientific_actual_count']==2 and a['admitted_proof_count']==0
assert review['saved_failure_evidence_review_passed'] and review['negative_bounded_experiment_outcome'] and review['mismatch_count']==0 and review['scientific_calls']==0
assert review['resource_accepted']is False and review['proof_accepted']is False
nextpath=Path('/private/tmp/gcts-schema-admission-source-20261019/next-storage-design-v1.json')
nextdesign=load(nextpath);assert nextdesign['scientific_calls']==0
packets={}
for row in idx['schedule']:
 m=row['mode'];ad=Path(row['actual_directory']);op=P/'runner-plans'/(row['invocation_id']+'-terminal-observation')
 packet=dict(schema='schema-admission-pilot-retained-failure-packets-v1',mode=m,
  worker_failure=load(ad/'worker-failure.json'),runner_receipt=load(ad/'runner-receipt.json'),terminal=load(op/'terminal.json'),
  full_result_available=False,proof_accepted=False,resource_accepted=False)
 packets[m]=packet;save(OUT/('schema-admission-pilot-'+m+'-failure.json'),packet)
summary=dict(schema='schema-admission-pilot-public-summary-v1',date='2026-10-19',status='BOTH_FAILED_OUTPUT_AND_RAM_PROFILE',
 scientific_actuals=2,assertion=case['selected_receiver'],prior_complete_inventory_expected_definitions=38,
 current_inventory_count_established=False,current_whole_Model_equality_established=False,admitted_complete_results=0,admitted_target_proofs=0,
 schema_admission_Source_enabled=True,schema_admission_operationally_qualified=False,recursive_proposer_enabled=False,new_RL_training=False,
 new_theorems=0,GCTS_RL_advantage_established=False,goal_complete=False,actuals=a['actuals'],
 failure_only=True,full_uncompressed_output_size_above_cap_unretained=True,
 Root_negative_audit=pin(D/'ROOT-negative-evidence-audit-v1.json'),independent_review=pin(reviewpath),
 next_design=pin(nextpath),original_caps_unchanged=True,
 limitations=['Missing complete result means no proof, inventory or Model validation from this pair.',
 'Both workers alone exceed1GiB. Posthoc separate peak sums are diagnostic, not runner-admitted aggregates or simultaneous RAM.',
 'Failure terminal times are not search-performance comparisons.',
 'Transport stage hashes and last opaque raw wire are not substitutes for full original proof requests/results.',
 'Source-only duplication hypothesis is unmeasured; next representation is unimplemented and its byte-budget semantics require explicit declaration.'])
save(OUT/'schema-admission-pilot-summary.json',summary)
for src,dst in [(D/'ROOT-negative-evidence-audit-v1.json','schema-admission-pilot-audit.json'),(reviewpath,'schema-admission-pilot-peer-review.json'),(nextpath,'schema-admission-pilot-next-design.json')]:
 (OUT/dst).write_bytes(src.read_bytes())
f,s=a['actuals'];text=(D/'pilot-report-template-v2.html').read_text();scale=2200
sub=dict(CAP_PERCENT=f'{1024/scale*100:.5f}',FIXED_PERCENT=f"{f['worker_peak_bytes']/1048576/scale*100:.5f}",
 SYMBOLIC_PERCENT=f"{s['worker_peak_bytes']/1048576/scale*100:.5f}",FIXED_MIB=f"{f['worker_peak_bytes']/1048576:,.3f}".replace(',','\\,'),
 SYMBOLIC_MIB=f"{s['worker_peak_bytes']/1048576:,.3f}".replace(',','\\,'),FIXED_SUM=f"{f['diagnostic_separate_peak_sum_bytes']/1048576:,.3f}".replace(',','\\,'),
 SYMBOLIC_SUM=f"{s['diagnostic_separate_peak_sum_bytes']/1048576:,.3f}".replace(',','\\,'),FIXED_SECONDS=f"{f['failure_terminal_seconds']:.3f}",SYMBOLIC_SECONDS=f"{s['failure_terminal_seconds']:.3f}",
 PACKETS=json.dumps(packets,separators=(',',':'),ensure_ascii=True).replace('</','<\\/'))
for k,v in sub.items():text=text.replace('@@'+k+'@@',v)
assert '@@'not in text;(OUT/'schema-admission-pilot.html').write_text(text)
reader=OUT/'reader.html';r=reader.read_text();anchor='<section id="mp-schema-shadow">'
banner=r'''<section id="schema-admission-pilot"><p class="eyebrow">19 OCTOBER 2026 · LATEST MATCHED PILOT · NEGATIVE RESULT</p><h2>The explicit schema gate hits output and memory limits.</h2><p>Both fresh case002 methods fail the original full-output cap, and each worker alone exceeds the original RAM limit. No complete Model, schema permission or target proof is admitted. <a href="schema-admission-pilot.html?v=20261019-sa1#outcome"><b>Read the failures and next representation design</b></a> · <a href="schema-admission-pilot.html?v=20261019-sa1#reader">Inspect actual receipts</a>. The earlier successful shadow qualification remains separately available below.</p></section>'''
if 'id="schema-admission-pilot"'not in r:
 assert r.count(anchor)==1;r=r.replace(anchor,banner+anchor,1).replace('LATEST EXECUTED QUALIFICATION','EARLIER EXECUTED QUALIFICATION',1);reader.write_text(r)
for filename in ['mp-schema-shadow.html','parallel-research.html']:
 p=OUT/filename;t=p.read_text()
 if 'id="schema-admission-update"'not in t:
  banner=r'''<section id="schema-admission-update"><p class="warning"><strong>Later matched pilot:</strong> <a href="schema-admission-pilot.html?v=20261019-sa1#outcome">the explicit schema-admission case002 pair fails output and memory limits</a>. Neither method yields a qualified complete result. The report below preserves its earlier milestone.</p></section>'''
  assert '<section 'in t;t=t.replace('<section ',banner+'<section ',1);p.write_text(t)
# Raw evidence archive. Outer ZIP decompression never decodes the opaque inner Native payload.
members={};identities=[]
def add(name,p,expected=None):
 p=Path(p);b=p.read_bytes();d=pin(p)
 if expected is not None:assert d==expected
 assert name not in members;members[name]=b;identities.append(dict(member=name,source=d,**rawpin(b)))
for p in sorted(D.iterdir()):
 if p.is_file()and p.suffix in ['.py','.json','.html']:add('Root/'+p.name,p)
for folder in ['plans','plans-v2','actual-fixed-v2','actual-symbolic-v2']:
 for p in sorted((D/folder).rglob('*')):
  if p.is_file():add(folder+'/'+str(p.relative_to(D/folder)),p)
for folder,label in [('/private/tmp/gcts-schema-admission-ROOT-source-20261019','Root-current-Source'),('/private/tmp/gcts-schema-admission-source-20261019','Library-registry-Source'),('/private/tmp/gcts-mp-schema-source-20261019','qualified-certifier-Source'),('/private/tmp/gcts-schema-admission-peer-20261019','independent-reviews'),('/private/tmp/gcts-schema-admission-import-census-20261019','current-import-census')]:
 for p in sorted(Path(folder).glob('*')):
  if p.is_file()and p.suffix in ['.py','.json','.txt']:add(label+'/'+p.name,p)
worker=load(idx['schedule'][0]['worker_plan']['path']);auth=load(idx['schedule'][0]['authorization']['path'])
for k,d in worker['native_inputs'].items():add('Native-inputs/'+Path(d['path']).name,d['path'],d)
for role,d in [('policy',worker['policy']),('input-capsule',idx['input_capsule']),('raw-kernel',idx['schema_kernel_source'])]:add('inputs/'+role+Path(d['path']).suffix,d['path'],d)
for role,b in auth['review_roles'].items():add('scoped-review-receipts/'+role+'.json',b['receipt']['path'],b['receipt'])
readme=b'''Retained first explicit schema-admission matched pilot: two scientific actuals.
Both fail whole-output serialization at the original128MiB guard. Both workers
alone also exceed the original1GiB memory cap. No complete current result,
worker success receipt, schema/Model permission or target proof is admitted.
No successful proof is recovered from Native wire or stage hashes.

The archive preserves full surviving files, including raw Source copies and
last wire files, both consumed exact once plans, false draft history, original
inputs and negative audits. There are no result.json files to reconstruct.
Opaque Native microcode is copied raw; no posthoc inner decode/replay occurs.
The external Python/Z3/stdlib/loader/OS are identified but not bundled.
Reproduction needs fresh bounded declarations and authorizations; consumed
subjects cannot be rerun. This failure baseline remains immutable.

The next design is Source-only and unimplemented. Both encoded and expanded
canonical sizes must be reported; a compact byte limit cannot silently replace
the old expanded JSON guard while claiming the same serialization profile.
'''
members['README.txt']=readme;identities.append(dict(member='README.txt',**rawpin(readme)))
archive=OUT/'schema-admission-pilot-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,b in sorted(members.items()):
  info=zipfile.ZipInfo(name,(2026,10,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(members)
 for name,b in members.items():assert z.read(name)==b
names=['schema-admission-pilot.html','schema-admission-pilot-summary.json','schema-admission-pilot-audit.json','schema-admission-pilot-peer-review.json','schema-admission-pilot-fixed-failure.json','schema-admission-pilot-symbolic-failure.json','schema-admission-pilot-next-design.json','reader.html','mp-schema-shadow.html','parallel-research.html']
save(OUT/'schema-admission-pilot-evidence-manifest.json',dict(schema='schema-admission-pilot-public-manifest-v1',archive=pin(archive),members=identities,assets=[pin(OUT/n)for n in names],scientific_replays=0,posthoc_opaque_Native_decodes=0,goal_complete=False,Root_negative_audit=pin(D/'ROOT-negative-evidence-audit-v1.json'),independent_review=pin(reviewpath)))
print(json.dumps(dict(archive=pin(archive),member_count=len(members),report=pin(OUT/'schema-admission-pilot.html'))))
