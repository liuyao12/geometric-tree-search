"""Audit saved negative evidence only. No scientific imports, decode or replay."""
from pathlib import Path
import hashlib,json
D=Path(__file__).parent;P=D/'plans-v2'
def load(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(v):
 assert pin(v['path'])==v,v
 return load(v['path'])
checks=[]
def need(v,n):
 assert v,n
 checks.append(n)
idx=load(P/'authorized-index-v2.json');closure=checked(idx['runtime_closure']);case=checked(idx['case_declaration'])
closed=load(D/'ROOT-cohort-closure-v1.json')
need(closed['all_workers_and_native_groups_closed']is True and closed['remaining_processes']=='','exact cohort process closure')
need([r['mode']for r in idx['schedule']]==['fixed','symbolic'],'declared serial pair')
source_copies=[];rows=[]
for row in idx['schedule']:
 m=row['mode'];a=Path(row['actual_directory']);plan=checked(row['runner_plan']);worker=checked(row['worker_plan']);auth=checked(row['authorization'])
 q=load(a/'runner-receipt.json');w=load(a/'worker-failure.json');c=load(a/'CONSUMED.json')
 op=P/'runner-plans'/(row['invocation_id']+'-terminal-observation');t=load(op/'terminal.json');oc=load(op/'CONSUMED.json')
 subject={k:v for k,v in plan.items()if k!='authorization'}
 need(len(subject)==18 and hashlib.sha256(canonical(subject)).hexdigest()==row['subject_sha256']==auth['subject_sha256']==q['subject_sha256'],m+' full subject custody')
 need(auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1,m+' one-use grant')
 need(q['plan']==c['plan']==t['plan']==oc['plan']==pin(row['runner_plan']['path']),m+' all plan joins')
 need(q['authorization']==row['authorization']==pin(row['authorization']['path']),m+' authorization join')
 need(q['consumed_marker']==pin(a/'CONSUMED.json')and c['consumed_before_Popen']is True and c['maximum_worker_launches']==1 and oc['maximum_runner_launches']==1,m+' consumed before launch')
 need(q['consumed_once']is True and q['worker_launch_attempts']==1 and q['worker_pid_observed']is True,m+' single observed launch')
 need(q['review_roles']==auth['review_roles']and len(q['review_roles'])==7,m+' seven exact review scopes')
 for role,r in auth['review_roles'].items():checked(r['receipt'])
 need(t['runner_receipt']==pin(a/'runner-receipt.json'),m+' terminal full runner join')
 for k in ['invocation_id','receiver_id','mode','inventory_certification_mode','search_ordering','model_storage','result_reader']:
  need(q[k]==row[k]==worker[k]==plan[k],m+' identity '+k)
 need(q['python_exit_code']==1 and q['python_reaped']is True and t['runner_exit_code']==2,m+' retained worker failure exits')
 need(q['owned_group_absent']is True and q['owned_group_reappearance_observed_ns']is None and q['stdout_eof']and q['stderr_eof']and q['log_capture_complete'],m+' group and EOF closure')
 need(q['signals']==[]and len(q['errors'])==1 and q['errors'][0]['type']=='OnceRunnerError',m+' retained runner failure')
 need(q['work_deadline_ns']==c['work_deadline_ns']==q['began_ns']+180000000000 and q['overall_deadline_ns']==c['overall_deadline_ns']==q['began_ns']+210000000000,m+' unchanged time caps')
 need(q['limits']==plan['limits'] and all(q['limits'][k]==case['limits'][k]for k in ['work_seconds','overall_seconds','result_bytes']) and q['limits']['aggregate_peak_bytes']==case['limits']['conservative_worker_plus_native_peak_bytes'],m+' complete unchanged outer limits')
 need(q['worker_terminal_observed_ns']<q['work_deadline_ns']and t['terminal_observed_ns']<q['overall_deadline_ns'],m+' diagnostic early failure terminal')
 need(q['resource_candidate_accepted']is False and q['ROOT_resource_accepted']is False and t['terminal_gate_passed']is False,m+' no resource or terminal admission')
 need(q['logical_proof_transport_candidate']is False and q['mathematical_proof_accepted']is False and t['mathematical_proof_accepted']is False and q['scientific_acceptance']is False,m+' no logical or scientific admission')
 need(w['error_type']=='OutputCapExceeded'and w['message']=='full result exceeds128MiB; no truncated proof result published',m+' exact cap exception')
 need(w['logical_proof_accepted']is False and w['scientific_acceptance']is False and w['result_already_published']is None and w['cleanup_errors']==[],m+' exact negative worker header')
 need(not(a/'result.json').exists()and not(a/'worker-receipt.json').exists()and not list(a.glob('*.partial'))and not list(a.glob('.*.partial')),m+' absent whole result/header/partial')
 need(q['worker_receipt']is None and q['native_transport']is None and q['conservative_parent_plus_native_peak_bytes']is None,m+' no completed runner aggregation')
 for name in ['stdout','stderr']:
  need(pin(a/(name+'.bin'))==q['outputs'][name]and q['outputs'][name]['bytes']<=4194304,m+' bounded '+name)
 need('OutputCapExceeded' in(a/'stderr.bin').read_text(),m+' exception in closed stderr')
 n=w['native_transport'];need(n['closed']and n['all_reaped']and n['native_exit_code']==0 and n['wait4_status']==0 and n['termination_signals']==[]and n['cleanup_errors']==[],m+' exact Native cleanup')
 need(n['stderr_complete']and n['stdout_eof']and n['stdout_pending_bytes']==0 and n['stderr_bytes']==0,m+' Native pipes closed')
 need(n['parent_pid']==n['parent_pgid']==n['native_pgid']==q['python_pid']==q['owned_pgid'],m+' exact owned group join')
 stages=n['request_stages'];need(len(stages)==n['complete_records']==52,m+' complete transport stage census')
 for i,s in enumerate(stages):
  need(s['ordinal']==s['record_id']==i and s['stage']=='COMPLETED'and type(s['limit'])is int and 0<s['limit']<=5000000000,m+' stage '+str(i))
  need(set(s)=={'input_sha256','output_sha256','request_sha256','ordinal','record_id','stage','purpose','limit'},m+' stage has hashes, no full proof request/result '+str(i))
 for fn,k in [('input.bin','input_sha256'),('output.bin','output_sha256')]:need(pin(a/'native'/fn)['sha256']==stages[-1][k],m+' last raw wire '+fn)
 need(n['native_high_water_bytes']==n['wait4_usage']['ru_maxrss']and n['ru_maxrss_unit']=='bytes on declared Darwin runtime; Root must gate platform',m+' Native wait4 byte units')
 peak=q['python_wait4_usage']['ru_maxrss'];need(type(peak)is int and peak>1073741824,m+' worker alone exceeds RAM cap')
 originals=dict(closure['materialized_aliases'],**closure['schema_sources']);need(len(originals)==25,m+' original25sources')
 for alias,s in originals.items():
  owned=pin(a/'modules'/(alias+'.py'));need(owned['sha256']==s['sha256']and owned['bytes']==s['bytes']and pin(s['path'])==s,m+' original owned '+alias)
 source_copies.append({k:{x:v for x,v in pin(a/'modules'/(k+'.py')).items()if x!='path'}for k in originals})
 rows.append(dict(mode=m,invocation_id=row['invocation_id'],subject_sha256=row['subject_sha256'],
  status='FAILED_OUTPUT_CAP_AND_RAM_PROFILE',runner_receipt=pin(a/'runner-receipt.json'),worker_failure=pin(a/'worker-failure.json'),terminal=pin(op/'terminal.json'),
  consumed=pin(a/'CONSUMED.json'),worker_exit_code=1,runner_exit_code=2,
  failure_terminal_seconds=t['runner_clock_elapsed_seconds'],worker_known_failure_exit_seconds=(q['worker_terminal_observed_ns']-q['began_ns'])/1e9,
  worker_peak_bytes=peak,Native_peak_bytes=n['native_high_water_bytes'],diagnostic_separate_peak_sum_bytes=peak+n['native_high_water_bytes'],
  worker_alone_exceeds_1GiB=True,aggregate_is_posthoc_diagnostic_not_runner_admission=True,
  complete_transport_stage_entries=len(stages),last_stage_purpose=stages[-1]['purpose'],stage_metadata_establishes_no_logical_result=True,
  last_input_wire=pin(a/'native/input.bin'),last_output_wire=pin(a/'native/output.bin'),
  result_json_exists=False,worker_success_header_exists=False,partial_exists=False,
  whole_Model_equal_established=False,inventory_permission_established=False,fresh_target_proof_admitted=False,resource_admitted=False,logs_closed=True,owned_group_absent=True))
need(source_copies[0]==source_copies[1],'both actuals identical full25Source bytes')
need(next(r for r in load(idx['input_capsule']['path'])['receivers']if r['id']==case['selected_receiver_id'])==case['selected_receiver'],'original case002 literal')
out=dict(schema='ROOT-schema-admission-negative-evidence-audit-v1',author_identity='/root',saved_evidence_only=True,scientific_replays=0,Native_calls=0,opaque_Native_decodes=0,raw_wire_decodes=0,
 negative_evidence_audit_passed=True,checks_passed=len(checks),checks=checks,authorized_index=pin(P/'authorized-index-v2.json'),cohort_closure=pin(D/'ROOT-cohort-closure-v1.json'),
 actuals=rows,scientific_actual_count=2,admitted_proof_count=0,resource_admitted_count=0,whole_result_count=0,
 original_caps_unchanged=True,full_original_case_requested=True,both_actual_Source_bytes_equal=True,
 goal_complete=False,new_theorem=False,new_RL_training=False,GCTS_RL_advantage_established=False,schema_admission_operationally_qualified=False,
 disposition='Retain both failures. Full output cap exception and each worker alone exceeding RAM independently prevent admission. No successful prefix, proof reconstruction or search-performance claim.',
 scope='Transport stage metadata and raw last-wire identity are audited without decoding or replay; they do not recover missing original requests/results, complete Model, point region or schema packets. Exact uncompressed full output size above cap is unretained.',
 next_step='Design a bounded lossless object table with exact full reconstruction and structural sharing in memory, preserving complete original registry/Model/candidate graph and original caps; qualify it on small controls before any newly declared larger case. This is a proposal, not implemented or demonstrated here.')
p=D/'ROOT-negative-evidence-audit-v1.json';assert not p.exists();p.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(output=pin(p),checks=len(checks),actuals=rows)))
