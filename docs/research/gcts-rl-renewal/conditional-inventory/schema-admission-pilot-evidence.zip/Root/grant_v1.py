"""Exact reviewed saved subjects only; no scientific evaluation."""
from pathlib import Path
import copy,hashlib,json
D=Path(__file__).parent;P=D/'plans';PEER=Path('/private/tmp/gcts-schema-admission-peer-20261019')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(d):
 assert pin(d['path'])==d,d
 return load(d['path'])
def save(p,v):
 assert not p.exists(),p;p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def contains(v,w):
 if v==w:return True
 if type(v)is dict:return any(contains(x,w)for x in v.values())
 if type(v)is list:return any(contains(x,w)for x in v)
 return False
idx=load(P/'prospective-index-v1.json');current=idx['current_Source_reviews']
receipts=dict(current,prospective_plans=pin(PEER/'typed-prospective-review-v1.json'))
spec={
 'retained_ordering_Source':('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
 'consumer_gates_Source':('schema-admission-consumer-gate-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'registry_Source':('schema-admission-registry-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'driver_Source':('schema-admission-driver-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'composition_Source':('schema-admission-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'once_Source':('schema-admission-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'prospective_plans':('schema-admission-prospective-plan-review-v1','prospective_review_passed','/root/conventional_control_review')}
retained=[
 pin('/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py'),
 pin('/private/tmp/gcts-and-support-ordering-source-20261018/quantified_symbolic_control_v2.py'),
 pin('/private/tmp/gcts-and-support-ordering-source-20261018/receptor_support_ordering_v1.py')]
assert len(idx['schedule'])==2 and [r['mode']for r in idx['schedule']]==['fixed','symbolic']
prepared=[]
for row in idx['schedule']:
 once=checked(row['runner_plan_draft']);worker=checked(row['worker_plan']);old_auth=checked(row['authorization_draft'])
 subject={k:v for k,v in once.items()if k!='authorization'}
 assert len(subject)==18 and sha(subject)==row['subject_sha256']==old_auth['subject_sha256']
 assert old_auth['actual_execution_authorized']is False and old_auth['maximum_actual_invocations']==0 and old_auth['review_roles']=={}
 subjects={
  'retained_ordering_Source':retained,
  'consumer_gates_Source':[worker['project_sources'][k]for k in ('quantified_family_points_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],
  'registry_Source':[worker['project_sources']['semantic_inventory_oracle'],*idx['schema_sources'].values()],
  'driver_Source':[worker['components']['receiver_driver'],worker['project_sources']['semantic_inventory_oracle'],*idx['schema_sources'].values()],
  'composition_Source':[once['cold'],worker['components']['receiver_driver'],*idx['schema_sources'].values()],
  'once_Source':[once['runner'],once['observer']],
  'prospective_plans':[once['integration_declaration'],once['runtime_closure'],once['worker_plan']]}
 roles={}
 for role,(schema,passed,reviewer)in spec.items():
  r=checked(receipts[role])
  assert r['schema']==schema and r[passed]is True and r['reviewer_identity']==reviewer
  assert r['author_identity']!=reviewer and r['source_only']is True and r['scientific_calls']==0
  assert r['scientific_acceptance']is False and r['actual_execution_authorized']is False
  for s in subjects[role]:assert contains(r,s),(role,s)
  roles[role]=dict(receipt=receipts[role],reviewer_identity=reviewer,required_subjects=subjects[role])
 actual=Path(row['actual_directory']);iid=row['invocation_id']
 assert not actual.exists() and not(P/'runner-plans'/(iid+'-terminal-observation')).exists()
 prepared.append((row,once,old_auth,subject,roles))
assert not(P/'runner-plans').exists() and not(P/'authorizations').exists()
(P/'runner-plans').mkdir();(P/'authorizations').mkdir()
scheduled=[]
for row,once,old_auth,subject,roles in prepared:
 iid=row['invocation_id'];auth=copy.deepcopy(old_auth)
 auth.update(actual_execution_authorized=True,maximum_actual_invocations=1,review_roles=roles,
  scope='Exactly one fresh invocation of this unchanged prospective subject, in the declared serial two-arm cohort. Seven scopes/six unique receipts/two reviewer identities, composition+once intentionally shared. Complete case002 and original caps, no replay cache or consumed retry. No scientific evaluation in this grant helper.')
 ap=save(P/'authorizations'/(iid+'.json'),auth);once['authorization']=ap
 assert {k:v for k,v in once.items()if k!='authorization'}==subject
 op=save(P/'runner-plans'/(iid+'.json'),once)
 scheduled.append(dict(row,authorization=ap,runner_plan=op))
idx.update(schema='ROOT-schema-admission-authorized-index-v1',actual_execution_authorized=True,actuals_started=0,
 current_review_roles=receipts,schedule=scheduled,
 scope='Two unchanged reviewed false subjects become separate true/max1 grants only. No science evaluated; serial fixedthen symbolic, no feedback or retries.')
ip=save(P/'authorized-index-v1.json',idx)
adopt=save(D/'ROOT-final-grant-adoption-v1.json',dict(schema='ROOT-schema-admission-final-grant-adoption-v1',
 author_identity='/root',source_only=True,scientific_calls=0,scientific_acceptance=False,actuals_started=0,goal_complete=False,
 false_index=pin(P/'prospective-index-v1.json'),authorized_index=ip,
 subjects=[r['subject_sha256']for r in scheduled],both_exact18field_subjects_unchanged=True,
 current_review_roles=receipts,maximum_actual_invocations_per_subject=1,
 disclosure='Seven roles use six distinct review receipts and two reviewer identities; same intake receipt for composition and once. No additional independent reviewers implied.'))
print(json.dumps(dict(index=ip,adoption=adopt,runners=[r['runner_plan']for r in scheduled],scientific_calls=0)))
