"""Saved metadata only: two complete, false/max-zero prospective subjects."""
from pathlib import Path
import copy,hashlib,json
D=Path(__file__).parent;S=Path('/private/tmp/gcts-schema-admission-ROOT-source-20261019')
P=D/'plans';P.mkdir();(P/'worker-plans').mkdir();(P/'runner-plan-drafts').mkdir();(P/'authorization-drafts').mkdir()
OLD=Path('/private/tmp/gcts-adaptive-group-local-pilot-20261019')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
 assert not p.exists(),p;p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
h=load(S/'intake-Source-contract-v1.json');cold=load(S/'cold-Source-contract-v1.json')
oldidx=load(OLD/'plans/prospective-index-v2.json');oldrow=oldidx['schedule'][0]
oldw=load(oldrow['worker_plan']['path']);oldonce=load(oldrow['runner_plan_draft']['path']);oldcase=load(oldidx['case_declaration']['path'])
censuspath=Path('/private/tmp/gcts-schema-admission-import-census-20261019/newcensus-v1.json');census=load(censuspath)
assert pin(censuspath)['sha256']=='9f293e48a048cb085281c3c6bbff6d8f9c3424f36421af7b1da582d4d63e4eb4'
capsule=load('/private/tmp/gcts-local-operational-20261019/full-assertion-capsule.json')
rid='prospective-fol-20261018-002';spec=next(r for r in capsule['receivers']if r['id']==rid)
prior=D/'prior-case002-fixed-bulk-result.json';assert not prior.exists()
prior.write_bytes((OLD/'prior-case002-fixed-bulk-result.json').read_bytes())
assert load(prior)['declaration']==spec and load(prior)['status']=='unknown_native_inventory'
rows=[]
for order,mode in enumerate(('fixed','symbolic'),1):
 iid='schema-admission-002-'+mode+'-ROOT-20261019-v1'
 rows.append(dict(order=order,invocation_id=iid,receiver_id=rid,mode=mode,inventory_certification_mode='schema_then_native',
  search_ordering='and_support',model_storage='literal_interned',result_reader='interned',actual_directory=str(D/('actual-'+mode+'-v1'))))
closure=load(oldidx['runtime_closure']['path'])
base=census['base_materialized_aliases'];extra=census['extra_component_aliases']
project={k:v for k,v in base.items()if k not in ('semantic_receiver_driver','bounded_request_oracle')}
components=dict(receiver_driver=base['semantic_receiver_driver'],bounded_transport=base['bounded_request_oracle'])
assert len(base)==24 and len(project)==22 and len(extra)==1 and list(extra)==['mp_schema_certificate']
assert components['receiver_driver']==cold['driver'] and project['semantic_inventory_oracle']==cold['registry']
assert components['bounded_transport']==oldw['components']['bounded_transport']
closure.update(schema='ROOT-schema-admission-raw-runtime-closure-v1',
 project_sources=project,additional_nonseed_components=components,materialized_aliases=base,
 current_composition_handoff=pin(S/'intake-Source-contract-v1.json'),schema_sources=extra,
 schema_kernel_source=pin('/private/tmp/gcts-semantic-family-next-audit-20261018/fol_checker.tree'),
 schema_import_census=pin(censuspath),schema_extra_component_count=1,current_scientific_alias_count=25,
 import_sites=census['import_sites'],import_statement_sites=census['import_statement_sites'],
 project_import_edges=census['project_import_edges'],literal_dynamic_import_sites=census['literal_dynamic_import_sites'],
 unresolved_dynamic_import_sites=census['unresolved_dynamic_import_sites'],source_AST_pins=census['source_AST_pins'],
 current_stdlib_import_roots=census['stdlib_import_roots'],current_external_import_roots=census['external_import_roots'],
 inherited_closed_stdlib_roots_without_entry_pin=census['inherited_closed_stdlib_roots_without_entry_pin'],
 raw_project_import_closure_complete_for_declared_seeds=True,
 ordering_current_sources=dict(family_search=project['semantic_inventory_search_v2'],
  symbolic_control=project['quantified_symbolic_control_v2'],support_ordering=project['receptor_support_ordering_v1']),
 bridge_scope='Explicit new structural inventory admission: five base Source replacements (registry,driver,Model gate,symbolic gate,support gate), all remaining19 base aliases unchanged, plus one separately imported certifier. The import census is current AST metadata; host/runtime/loader trust remains conditional. Original full Native final proof/used closure, point model and complete original registry are retained.')
closure.pop('shadow_sources',None)
cp=save(D/'runtime-closure-v1.json',closure)
peer=Path('/private/tmp/gcts-schema-admission-peer-20261019')
reviews=dict(consumer_gates_Source=pin(peer/'typed-consumer-gate-Source-review-v1.json'),
 registry_Source=pin(peer/'typed-registry-Source-review-v2.json'),driver_Source=pin(peer/'typed-driver-Source-review-v1.json'),
 composition_Source=pin(peer/'typed-intake-Source-review-v1.json'),once_Source=pin(peer/'typed-intake-Source-review-v1.json'),
 retained_ordering_Source=pin('/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json'))
design=dict(schema='ROOT-schema-admission-prospective-design-v1',author_identity='/root',source_only=True,
 scientific_calls=0,actual_execution_authorized=False,goal_complete=False,schedule=rows,runtime_closure=cp,
 intake_Source_contract=pin(S/'intake-Source-contract-v1.json'),current_Source_reviews=reviews,
 certifier_Source_review=pin('/private/tmp/gcts-mp-schema-peer-20261019/typed-certificate-Source-review-v1.json'),
 prior_shadow_finite_qualification=pin('/private/tmp/gcts-mp-schema-shadow-ROOT-20261019/ROOT-actual-admission-v1.json'),
 independent_design=pin(peer/'design-soundness-and-admission-obligations-v1.json'),
 independent_consumer_addendum=pin(peer/'consumer-gate-design-addendum-v1.json'),
 import_census=pin(censuspath),assertion=spec,complete_original_family_count=4,expected_original_ground_definition_count=38,
 original_ground_class_scope='Prior saved result has22singleMP+16twohop definitions; no receiver nested ground call. Current ground membership must be independently reconstructed and literally compared. Generic nested qualification is inherited from the distinct prior shadow run, not newly tested here.',
 comparison_only_prior_result=pin(prior),schema_admission_enabled=True,recursive_proposer_enabled=False,new_RL_training=False,
 trust='A new explicitly trusted structural gate permits full Model construction after full certificate/correspondence coverage or exact Native fallback for every original definition. Certificate packet authority remains false; registry native_accepted staysfalse. Full current theory is freshly Native admitted by the compiler. Every claimed final proof still needs fresh original Native acceptance with every used original definition/dependency body.',
 unchanged='Full original case002 theory/target,12rows,2catalog rounds, four-family policy, all38definitions/interfaces/bodies/marks/candidates/base alternatives, full current scientific Sources in both methods, original compiler/search/Native/time/RAM/output caps. No targetproofroute, instance binding, grammar reduction, learned pruning or new logical primitive.',
 scientific_costs='Both current cold processes copy/import/seal all25 Sources and same Z3/Native runtime. Certificate/correspondence/guard/copy/projection/model/search/output/whole-reader work and known worker exit are charged. Native fallback shares original5e9 registration cap, not reallocated to search; schema work and Native microsteps remain distinct units.',
 invocation_policy='Exactly two fresh serial once-only subjects, fixedfirst then symbolic, every failure/UNKNOWN retained; no consumed retry and no feedback into the second arm. All other agents idle during each timed actual. No proof or old-acceptance cache. OS file cache is not flushed; cold means fresh isolated scientific process, not a universal machine-cache reset.',
 matching='Compare complete current non-timing compiler/inventory/Model/initial literals and all semantic metadata. Historical case002 did not reach Model, so no historical full Model equality is claimed. Current Source is common to both methods. Symbolic uses the common point Model for charged posthoc projection; it is a specialized logical control, not a no-point-model dedicated prover. Attempts are different units; this small study is not a statistical/general proof-search superiority result.',
 result_policy='One complete result.json per actual including all structural packets. No shadow diagnostics or sidecar. All positive complete schema inventory permission, target proof, reading/headers and known worker exit strictlybefore180; total externally observed closure<210.1GiB sum of separateDarwin scientificworker+Native highwaters;128MiB full result; original log caps. Observer/controller RAM is outside that inherited gate; no simultaneous-RAM/OS-enforcement claim.',
 conformance='Only explicit admission gates/provenance change. All old point domains/weights/marking words/transformations/frontier/candidate graph/generation/globaldeadforcedbranch/fallback/rollback logic is retained, with rawAST inverse Source evidence. Specialized finite proof-region adaptation, not a newly complete shared-engine conformance theorem.',
 unmeasured_gaps=['New fallback implementation is Source-reviewed; this case likely has no ineligible ground definitions and may not execute it.',
 'The conditional uniform-substitution argument is reviewed but unformalized, not a Source-to-Native formal equivalence theorem.',
 'No fit or success is assumed. Full Model/output may exceed original caps; do not trim, raise budgets, or narrow the target.',
 'No turtle/Penrose/plane construction, universal Wang palette, full PA/Hilbert geometry, RL training or GCTS-specific advantage follows from this engineering comparison.'])
dp=save(D/'prospective-design-v1.json',design)
case=dict(schema='ROOT-schema-admission-comparison-declaration-v1',author_identity='/root',source_only=True,
 scientific_calls=0,actual_execution_authorized=False,goal_complete=False,new_RL_training=False,
 parent_structural_declaration=oldidx['input_capsule'],global_cohort_declaration=dp,runtime_closure=cp,
 selected_receiver_id=rid,selected_receiver=spec,schedule=rows,result_reader='interned',model_storage='literal_interned',
 limits=copy.deepcopy(oldcase['limits']),intake_Source_handoff=pin(S/'intake-Source-contract-v1.json'),
 source_gate='Current independent Source and false-plan reviews plus separate Root freshmax1 grants are required. Seven scoped roles/six unique receipts/two reviewer identities, composition+once shared. False metadata grants no execution.',
 scope=design['trust'],conformance=design['conformance'])
dec=save(D/'case-declaration-v1.json',case)
scheduled=[]
for row in rows:
 iid=row['invocation_id'];w=copy.deepcopy(oldw);o=copy.deepcopy(oldonce)
 for k in ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory'):
  w[k]=o[k]=row[k]
 w.update(schema='ROOT-schema-admission-worker-plan-v1',cold=h['cold'],runtime_closure=cp,
  integration_declaration=dec,project_sources=project,components=components)
 wp=save(P/'worker-plans'/(iid+'.json'),w)
 o.update(schema='ROOT-schema-admission-once-plan-v1',cold=h['cold'],runner=h['runner'],observer=h['observer'],
  runtime_closure=cp,integration_declaration=dec,worker_plan=wp);o.pop('authorization')
 assert len(o)==18;subject=sha(o)
 ap=save(P/'authorization-drafts'/(iid+'.json'),dict(schema='ROOT-schema-admission-once-authorization-v1',
  author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=subject,
  review_roles={},scope='Prospective false/max0 only. Independent exact Source/plan reviews and fresh Root grant required; do not execute.'))
 o['authorization']=ap;op=save(P/'runner-plan-drafts'/(iid+'.json'),o)
 scheduled.append(dict(row,worker_plan=wp,runner_plan_draft=op,authorization_draft=ap,subject_sha256=subject))
 assert w['native_inputs']==oldw['native_inputs']and w['z3']==oldw['z3']and w['policy']==oldw['policy']
 assert not Path(row['actual_directory']).exists()
idx=dict(schema='ROOT-schema-admission-prospective-index-v1',author_identity='/root',source_only=True,
 scientific_calls=0,actual_execution_authorized=False,goal_complete=False,subject_count=2,schedule=scheduled,
 design=dp,case_declaration=dec,runtime_closure=cp,input_capsule=oldidx['input_capsule'],
 intake_Source_contract=pin(S/'intake-Source-contract-v1.json'),current_Source_reviews=reviews,
 certifier_Source_review=design['certifier_Source_review'],import_census=pin(censuspath),
 cold=h['cold'],runner=h['runner'],observer=h['observer'],schema_sources=extra,
 schema_kernel_source=closure['schema_kernel_source'])
ip=save(P/'prospective-index-v1.json',idx)
assert case['limits']==oldcase['limits']
print(json.dumps(dict(index=ip,declaration=dec,closure=cp,subjects=[r['subject_sha256']for r in scheduled],scientific_calls=0)))
