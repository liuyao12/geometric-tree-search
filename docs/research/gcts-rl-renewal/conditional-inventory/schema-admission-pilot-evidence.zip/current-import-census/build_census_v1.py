"""Read/hash/AST only; no scientific imports, calls or code object evaluation."""
from pathlib import Path
import ast,hashlib,json
D=Path('/private/tmp/gcts-schema-admission-import-census-20261019')
P=Path('/private/tmp/gcts-mp-schema-shadow-ROOT-20261019/runtime-closure-v1.json')

def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def exact(desc):
 actual=pin(desc['path'])
 if actual!=desc:raise AssertionError('raw Source descriptor differs: '+desc['path'])
 return actual

def main():
 parent=json.loads(P.read_text());base=dict(parent['materialized_aliases'])
 if len(base)!=24:raise AssertionError('complete parent base24')
 for desc in base.values():exact(desc)
 replacements={
  'semantic_inventory_oracle':'/private/tmp/gcts-schema-admission-source-20261019/semantic_inventory_oracle_v4.py',
  'semantic_receiver_driver':'/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_receiver_driver_v4.py',
  'quantified_family_points_v2':'/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_family_points_v3.py',
  'quantified_symbolic_control_v2':'/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_symbolic_control_v3.py',
  'receptor_support_ordering_v1':'/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_support_ordering_v2.py'}
 expected={
  'semantic_inventory_oracle':'a50579cb6ba326d32de3f203214963ec4bcf184613413a2abae2a2f6bb889eca',
  'semantic_receiver_driver':'df0b50a4c744f18fd3e8fd53ad63e9b42cf8adf9a270368bab59e5df605d2777',
  'quantified_family_points_v2':'7f95858af5af40d2f902d2aea6bc5d5a7944f7fe0b65b6b9a2ea66c0fb2ec4e3',
  'quantified_symbolic_control_v2':'8eda5d6fd91a137c9d22081bcba707631ab29733d2ae4ce413a2913a2b7d3bbe',
  'receptor_support_ordering_v1':'6e39f5cf5cd261c73515c29d3b315c43c27ae0bc64ef5fb509cea178b0251769'}
 for alias,path in replacements.items():
  desc=pin(path)
  if desc['sha256']!=expected[alias]:raise AssertionError('requested exact replacement '+alias)
  base[alias]=desc
 extra={'mp_schema_certificate':pin('/private/tmp/gcts-mp-schema-source-20261019/mp_schema_certificate_v1.py')}
 if extra['mp_schema_certificate']['sha256']!='7351d5954763e8b671411a78a821e5cc560ac1af19477a9491da573a735d2ae4':raise AssertionError('frozen certificate')
 aliases={**base,**extra};names=set(aliases)
 std=set(parent['stdlib_import_roots']);external=set(parent['external_imports'])
 imports=[];dynamics=[];loaders=[];relative=[];unknown=[];edges=set();trees={}
 def category(name,level=0):
  if level:return 'UNRESOLVED_RELATIVE'
  root=name.split('.')[0] if name else ''
  if root in names:
   return 'PROJECT_ALIAS' if name==root else 'UNRESOLVED_PROJECT_SUBMODULE'
  if root in std:return 'PARENT_CLOSED_STDLIB_ROOT'
  if root in external:return 'PARENT_CLOSED_EXTERNAL_ROOT'
  return 'UNCLASSIFIED_NOT_GUESSED'
 for alias,desc in sorted(aliases.items()):
  text=Path(desc['path']).read_text();tree=ast.parse(text,filename=desc['path']);trees[alias]=tree
  parents={child:node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
  dynamic_names={'__import__'};importlib_names={'importlib'}
  for node in ast.walk(tree):
   if isinstance(node,ast.ImportFrom) and node.module=='importlib':
    dynamic_names.update(a.asname or a.name for a in node.names if a.name=='import_module')
   if isinstance(node,ast.Import):
    importlib_names.update(a.asname or a.name for a in node.names if a.name=='importlib')
  def scope(node):
   path=[];node=parents.get(node)
   while node is not None:
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):path.append(node.name)
    node=parents.get(node)
   return '.'.join(reversed(path)) or '<module>'
  for node in sorted(ast.walk(tree),key=lambda n:(getattr(n,'lineno',0),getattr(n,'col_offset',0))):
   if isinstance(node,(ast.Import,ast.ImportFrom)):
    level=node.level if isinstance(node,ast.ImportFrom) else 0
    specs=([dict(module=node.module or '',imported=[dict(name=a.name,asname=a.asname) for a in node.names])]
           if isinstance(node,ast.ImportFrom) else
           [dict(module=a.name,asname=a.asname) for a in node.names])
    members=[]
    for spec in specs:
     c=category(spec['module'],level);members.append(dict(spec,classification=c))
     if c=='PROJECT_ALIAS':edges.add((alias,spec['module']))
     elif c.startswith('UNRESOLVED') or c=='UNCLASSIFIED_NOT_GUESSED':
      unknown.append(dict(module=alias,line=node.lineno,import_name=spec['module'],level=level,classification=c))
    record=dict(module=alias,source=desc,line=node.lineno,end_line=node.end_lineno,column=node.col_offset,
                kind=type(node).__name__,scope=scope(node),level=level,members=members,
                raw=ast.get_source_segment(text,node),AST=ast.dump(node,include_attributes=False))
    imports.append(record)
    if level:relative.append(record)
   if isinstance(node,ast.Call):
    direct=isinstance(node.func,ast.Name) and node.func.id in dynamic_names
    dotted=isinstance(node.func,ast.Attribute) and node.func.attr=='import_module'
    if direct or dotted:
     value=node.args[0].value if node.args and isinstance(node.args[0],ast.Constant) and type(node.args[0].value) is str else None
     c=category(value) if value is not None else 'UNRESOLVED_NONLITERAL_DYNAMIC'
     rec=dict(module=alias,source=desc,line=node.lineno,end_line=node.end_lineno,scope=scope(node),
              import_name=value,classification=c,raw=ast.get_source_segment(text,node),call_AST=ast.dump(node,include_attributes=False))
     dynamics.append(rec)
     if c=='PROJECT_ALIAS':edges.add((alias,value))
     elif c.startswith('UNRESOLVED') or c=='UNCLASSIFIED_NOT_GUESSED':unknown.append(rec)
    if isinstance(node.func,ast.Attribute) and node.func.attr in ('spec_from_file_location','module_from_spec','exec_module','load_module'):
     loaders.append(dict(module=alias,line=node.lineno,scope=scope(node),raw=ast.get_source_segment(text,node),call_AST=ast.dump(node,include_attributes=False)))
 roots_std=sorted({m['module'].split('.')[0] for r in imports for m in r['members'] if m['classification']=='PARENT_CLOSED_STDLIB_ROOT'}|{r['import_name'].split('.')[0] for r in dynamics if r['classification']=='PARENT_CLOSED_STDLIB_ROOT'})
 roots_external=sorted({m['module'].split('.')[0] for r in imports for m in r['members'] if m['classification']=='PARENT_CLOSED_EXTERNAL_ROOT'})
 seeds=list(parent['seeds'])+['mp_schema_certificate'];reached=set();todo=seeds[:]
 while todo:
  alias=todo.pop()
  if alias in reached:continue
  if alias not in aliases:raise AssertionError('missing declared seed '+alias)
  reached.add(alias);todo.extend(b for a,b in edges if a==alias and b not in reached)
 flat_imports=[]
 for record in imports:
  for member in record['members']:
   flat_imports.append(dict(source_module=record['module'],source=record['source'],form=record['kind'],line=record['line'],end_line=record['end_line'],scope=record['scope'],import_name=member['module'],root=member['module'].split('.')[0] if member['module'] else '',level=record['level'],classification=member['classification'],statement_raw=record['raw'],statement_AST=record['AST']))
 inherited={k:parent[k] for k in ('runtime','fixed_native_inputs','native_CPP','Z3','Z3_imports','external_imports')}
 census=dict(schema='schema-admission-raw-AST-import-census-v1',author_identity='/root/conventional_library',source_only=True,
  scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,status='RAW_AST_METADATA_ONLY_NOT_ACTIVATED',
  parent_closure=pin(P),helper=pin(Path(__file__)),
  base_materialized_aliases=base,base_alias_count=len(base),extra_component_aliases=extra,extra_alias_count=len(extra),
  all_scientific_aliases=aliases,all_alias_count=len(aliases),
  replaced_base_aliases={k:dict(parent=parent['materialized_aliases'][k],current=base[k]) for k in replacements},
  unchanged_base_aliases=[k for k in base if k not in replacements],
  source_AST_pins={k:dict(raw_source=aliases[k],AST_sha256=hashlib.sha256(ast.dump(v,include_attributes=False).encode()).hexdigest()) for k,v in trees.items()},
  import_sites=flat_imports,import_site_count=len(flat_imports),import_statement_sites=imports,import_statement_count=len(imports),project_import_edges=[dict(source=a,target=b) for a,b in sorted(edges)],project_import_edge_count=len(edges),
  stdlib_import_roots=roots_std,external_import_roots=roots_external,
  relative_import_sites=relative,literal_dynamic_import_sites=[r for r in dynamics if r['import_name'] is not None],
  unresolved_dynamic_import_sites=[r for r in dynamics if r['import_name'] is None],
  loader_calls_in_scientific_aliases=loaders,unresolved_import_classifications=unknown,
  parent_closed_stdlib_inventory=sorted(std),parent_closed_external_inventory=sorted(external),
  inherited_stdlib_entry_references={k:parent.get('stdlib_entry_references',{}).get(k) for k in roots_std},
  inherited_closed_stdlib_roots_without_entry_pin=[k for k in roots_std if k not in parent.get('stdlib_entry_references',{})],
  explicit_seeds=seeds,reachable_aliases=sorted(reached),unreachable_owned_aliases=sorted(names-reached),
  raw_declared_alias_AST_closure_complete=not unknown and not relative and not (names-reached),
  inherited_conditional_runtime_native_Z3=inherited,
  count_scope='Base24 remains separate from injected extra certificate1; all25 loaded/sealed by future Root Cold. Static edge reachability includes the explicitly injected certificate as its own seed, not a falsely claimed Python import from driver.',
  limitations=['No scientific Source/module/function/fixture/Native/compiler/Model/search/solver/codec/renderer was imported or evaluated. Only stdlib raw JSON/hash/AST metadata helper executed.',
   'This author wrote the registry/certifier and earlier Model/point components. This census is metadata authorship, not an independent semantic Source certificate of own or Root code.',
   'Classification uses exact parent closed project/stdlib/external inventories. Unknown roots are marked rather than guessed; no new OS/stdlib/Z3/Native closure proof is made.',
   'AST includes nested/conditional import statements and literal __import__/import_module sites. Arbitrarily aliased reflective loading, eval/exec-generated code and runtime package internals remain the parent conditional loader trust boundary.',
   'Root Cold/once loader Sources are outside these25scientific aliases and require separate Source/raw import/custody review. Their dynamic injection is not inferred from the scientific AST.',
   'Inherited stdlib entry metadata is conditional and not a full dependency/OS closure. New census recomputes actual current Source sites/lines; old exact entry descriptors are retained without package import or whole distribution evaluation.',
   'Raw Source pins describe this exact freeze. Future Source changes require a successor census; no current plans/grants/actuals are authorized by this metadata.'])
 out=D/'newcensus-v1.json';out.write_text(json.dumps(census,indent=2,sort_keys=True)+'\n')
 handoff=dict(schema='schema-admission-import-census-handoff-v1',author_identity='/root/conventional_library',source_only=True,
  scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,census=pin(out),helper=pin(Path(__file__)),
  parent_closure=pin(P),base_alias_count=24,extra_alias_count=1,all_alias_count=25,import_statements=len(imports),
  imported_module_clauses=len(flat_imports),project_edges=len(edges),literal_dynamic_import_sites=len(census['literal_dynamic_import_sites']),unresolved_imports=len(unknown),
  relative_import_sites=len(relative),complete_for_declared_AST_inventory=census['raw_declared_alias_AST_closure_complete'],
  scope='Metadata only; no independent own Source certification or runtime activation.')
 q=D/'handoff-v1.json';q.write_text(json.dumps(handoff,indent=2,sort_keys=True)+'\n')
 print(json.dumps(dict(census=pin(out),handoff=pin(q),counts={k:handoff[k] for k in ('base_alias_count','extra_alias_count','all_alias_count','import_statements','imported_module_clauses','project_edges','literal_dynamic_import_sites','unresolved_imports','relative_import_sites')}),indent=2))
if __name__=='__main__':main()
