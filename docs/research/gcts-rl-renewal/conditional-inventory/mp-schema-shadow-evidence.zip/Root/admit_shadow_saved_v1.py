"""Saved full literal evidence admission only; no Native or scientific replay."""
from pathlib import Path
import hashlib,json,gc,traceback
R=Path(__file__).resolve().parent
P=R/'plans'
def load(path):
    return json.loads(Path(path).read_bytes())

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def pin(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    with Path(path).open('x') as f:
        f.write(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')
    return pin(path)

def regions(data):
    model=data['outputs']['model'];initial=data['initial_state']
    def point(p):
        assert type(p)is list and len(p)==2 and all(type(v)is int for v in p)
        return tuple(p)
    required={point(p) for p in model['roots']}
    assert len(required)==len(model['roots']) and required=={point(p) for p in initial['allowed_points']}
    totals={point(p):v for p,v in initial['totals']};marks={point(p):v for p,v in initial['marks']}
    assert len(totals)==len(initial['totals']) and len(marks)==len(initial['marks'])
    assert set(totals)<=required and all(type(v)is int and 0<=v<=12 for v in totals.values())
    candidates={tuple(c['key']):c for c in model['placements']}
    assert len(candidates)==len(model['placements'])
    search=data['outputs']['search'];selected=[tuple(k) for k in search['placements']]
    assert len(set(selected))==len(selected)
    proof=search['proof'];slots={}
    for key in selected:
        assert key in candidates and len(key)==4 and all(type(v)is int for v in key)
        assert 0<=key[0]<len(proof) and 0<=key[1]<2+model['arity'] and key[:2] not in slots
        c=candidates[key];slots[key[:2]]=c
        assert c['occupancy']==[[[4*key[0],key[1]],12]]
        for p,v in c['occupancy']:
            p=point(p);assert p in required and type(v)is int and v>0
            totals[p]=totals.get(p,0)+v;assert totals[p]<=12
        for p,v in c['marks']:
            p=point(p);assert type(v)is int and (p not in marks or marks[p]==v)
            marks[p]=v
    assert set(totals)==required and all(v==12 for v in totals.values())
    assert len(slots)==len(proof)*(2+model['arity'])
    defs={d['name']:d['definition'] for d in data['outputs']['register']['definitions']}
    for j,line in enumerate(proof):
        row=[slots[j,n] for n in range(2+model['arity'])]
        command=dict(row[0]['command']);assert command==row[1]['command']
        if command['rule']=='block':
            n=len(defs[command['name']]['premises'])
            inputs=[row[2+i]['source'] for i in range(n)]
            assert all(type(i)is int and 0<=i<j for i in inputs)
            command['inputs']=inputs
        assert command==line
    assert data['outputs']['final_request']['proof']==proof
    return dict(status='VERIFIED_WHOLE_FINITE_POINT_REGION',required_points=len(required),
        selected_placements=len(selected),assigned_mark_points=len(marks),decoded_rows=len(proof),
        union_sha256=hashlib.sha256(canonical(dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected)))).hexdigest())

def semantic_parts(data):
    o=data['outputs']
    parts=dict(compiler={k:v for k,v in o['compile'].items() if k!='seconds'},
        inventory={k:o['register'][k] for k in ('definitions','interfaces','native_blocks')})
    if 'model' in o:
        parts['model']={k:v for k,v in o['model'].items() if k!='compile_seconds'}
        parts['initial']=data['initial_state']
    return parts

def block_custody(request, data):
    registered={b['name']:b for b in data['outputs']['register']['native_blocks']}
    supplied={b['name']:b for b in request['blocks']}
    assert len(supplied)==len(request['blocks'])
    assert all(name in registered and b==registered[name] for name,b in supplied.items())
    needed=set()
    def walk(word):
        for line in word:
            if line['rule']=='block':
                name=line['name']
                assert name in supplied
                if name not in needed:
                    needed.add(name);walk(supplied[name]['proof'])
    walk(request['proof'])
    assert needed==set(supplied)
    return dict(supplied_names=sorted(supplied),all_literal_registered=True,all_and_only_recursive_dependencies=True)


# This reads only saved literal JSON and bytes. It imports no scientific code.
def main():
 idx=load(P/'authorized-index-v1.json');row=idx['schedule'][0];a=Path(row['actual_directory'])
 closed=load(R/'ROOT-cohort-closure-v1.json')
 assert closed['all_workers_and_native_groups_closed'] and closed['remaining_processes']==''
 q=load(a/'runner-receipt.json');w=load(a/'worker-receipt.json');c=load(a/'CONSUMED.json')
 tp=P/'runner-plans'/(row['invocation_id']+'-terminal-observation')/'terminal.json';t=load(tp)
 runtime=load(idx['runtime_closure']['path']);plan=load(row['runner_plan']['path'])
 auth=load(row['authorization']['path'])
 assert auth['actual_execution_authorized'] is True and auth['maximum_actual_invocations']==1
 subject={k:v for k,v in plan.items()if k!='authorization'}
 assert len(subject)==18 and hashlib.sha256(canonical(subject)).hexdigest()==row['subject_sha256']==auth['subject_sha256']==q['subject_sha256']
 assert set(auth['review_roles'])=={'ordering_Source','registry_Source','composition_Source','once_Source','prospective_plans'}
 assert q['plan']==t['plan']==c['plan']==row['runner_plan']==pin(row['runner_plan']['path'])
 assert q['authorization']==row['authorization']==pin(row['authorization']['path'])
 assert pin(a/'runner-receipt.json')==t['runner_receipt']
 assert q['consumed_once'] is True and q['worker_launch_attempts']==1 and q['python_reaped'] and q['owned_group_absent']
 assert q['stdout_eof'] and q['stderr_eof'] and q['log_capture_complete'] and q['owned_group_reappearance_observed_ns'] is None
 assert q['python_exit_code']==t['runner_exit_code']==0 and not q['errors'] and not q['signals']
 assert q['resource_candidate_accepted'] and t['terminal_gate_passed']
 assert w['worker_plan']==row['worker_plan']==pin(row['worker_plan']['path'])
 assert pin(a/'worker-receipt.json')==q['outputs']['worker_receipt']
 assert q['began_ns']==w['began_ns']==c['began_ns']
 assert q['work_deadline_ns']==w['work_deadline_ns']==q['began_ns']+180000000000
 assert q['overall_deadline_ns']==w['overall_deadline_ns']==q['began_ns']+210000000000
 assert t['terminal_observed_ns']<q['overall_deadline_ns'] and q['worker_terminal_observed_ns']<q['work_deadline_ns']
 n=w['native_transport'];assert n==q['native_transport'] and n['closed'] and n['all_reaped']
 assert n['native_exit_code']==0 and n['stderr_complete'] and n['stdout_eof'] and n['stdout_pending_bytes']==0
 assert not n['cleanup_errors'] and not n['termination_signals']
 assert q['python_pid']==q['owned_pgid']==n['parent_pid']==n['parent_pgid']==n['native_pgid']
 peak=q['python_wait4_usage']['ru_maxrss']+n['native_high_water_bytes']
 assert peak==q['conservative_parent_plus_native_peak_bytes']<=1073741824
 for name in ['stdout','stderr']:
  assert pin(a/(name+'.bin'))==q['outputs'][name] and q['outputs'][name]['bytes']<=4194304
 raw=(a/'result.json').read_bytes();sr=(a/'schema-shadow-result.json').read_bytes()
 assert pin(a/'result.json')==w['result']==q['outputs']['result']
 sw=w['schema_shadow']
 assert pin(a/'schema-shadow-result.json')==sw['output']==q['outputs']['schema_shadow']
 assert len(raw)+len(sr)==sw['combined_result_bytes']<=134217728
 data=json.loads(raw);s=json.loads(sr)
 assert canonical(data)+b'\n'==raw and canonical(s)+b'\n'==sr
 reading=w['result_reading'];literal=reading['roundtrip']
 assert literal==sw['post_shadow_literal'] and literal['literal_bytes_equal'] is True
 assert literal['body_bytes']==len(raw)-1 and literal['body_sha256']==hashlib.sha256(raw[:-1]).hexdigest()
 assert sw['original_result_unchanged'] is True and reading['completed_ns']<q['work_deadline_ns']
 assert sw['completed_ns']<q['work_deadline_ns'] and sw['started_ns']<sw['completed_ns']
 for k in ['mode','inventory_certification_mode','search_ordering','receiver_id']:
  assert data[k]==w[k]==q[k]==row[k]
 assert data['inventory_certification_mode']=='bulk'
 case=load(idx['case_declaration']['path']);assert data['declaration']==case['selected_receiver']
 assert data['declaration']['length']==12 and data['declaration']['instantiation_rounds']==2
 assert w['integration_declaration']==idx['case_declaration']
 epoch=data['source_epoch']
 assert epoch['schema']=='semantic-family-receiver-source-epoch-v5-adaptive-inventory-groups'
 assert epoch['sources']['cold']==idx['cold'] and epoch['declaration']==idx['input_capsule']
 assert epoch['sources']['original']==runtime['materialized_aliases'] and len(epoch['sources']['original'])==24
 assert set(epoch['sources']['project'])==set(epoch['sources']['original'])
 checked_pins={}
 def verify_pin(d):
  assert pin(d['path'])==d
  checked_pins[d['path']]=d
 for alias,owned in epoch['sources']['project'].items():
  origin=epoch['sources']['original'][alias];verify_pin(owned);verify_pin(origin)
  assert owned['sha256']==origin['sha256'] and owned['bytes']==origin['bytes']
 shadow_epoch=epoch['shadow_sources']
 assert shadow_epoch['original']==idx['shadow_sources'] and len(shadow_epoch['original'])==2
 assert sw['sources']=={k:shadow_epoch[k]for k in ['original','owned']} and sw['kernel_source']==idx['schema_kernel_source']==shadow_epoch['kernel_source']
 for alias,owned in shadow_epoch['owned'].items():
  origin=shadow_epoch['original'][alias];verify_pin(owned);verify_pin(origin)
  assert owned['sha256']==origin['sha256'] and owned['bytes']==origin['bytes']
 verify_pin(shadow_epoch['kernel_source'])
 assert epoch['receiver_selection']['spec']==data['declaration']
 assert w['source_epoch_sha256']==hashlib.sha256(canonical(epoch)).hexdigest()
 records=data['records'];stages=[r for r in n['request_stages']if r['stage']=='COMPLETED']
 assert len(records)==len(stages)==17 and n['complete_records']==len(records)
 for i,(r,st)in enumerate(zip(records,stages)):
  assert r['id']==st['record_id']==st['ordinal']==i and r['purpose']==st['purpose']
  assert r['request_sha256']==hashlib.sha256(canonical(r['request'])).hexdigest()
  assert all(r[k]==st[k]for k in ['request_sha256','input_sha256','output_sha256'])
  assert type(st['limit'])is int and 0<st['limit']<=5000000000
  assert 0<=r['result']['micro_steps']<=st['limit']
 last=records[-1]
 for filename,key in [('input.bin','input_sha256'),('output.bin','output_sha256')]:
  assert pin(a/'native'/filename)['sha256']==last[key]
 inv=data['outputs']['register'];defs=inv['definitions'];names=[d['name']for d in defs]
 assert inv['status']=='native_accepted' and len(defs)==10 and len(set(names))==10
 assert inv['native_blocks']==[r['definition']for r in defs]
 assert set(inv['interfaces'])<=set(names) and len(inv['interfaces'])==len(set(inv['interfaces']))
 taut=['imp',['bot'],['bot']]
 wanted=dict(protocol='gcts-fol-1',theory=data['declaration']['theory'],blocks=inv['native_blocks'],proof=[dict(rule='tautology',formula=taut)],target=taut)
 nativebulk=records[inv['query']]
 assert nativebulk['purpose']=='check_generated_lemma_definitions' and nativebulk['request']==wanted
 assert nativebulk['result']['status']=='accepted' and stages[inv['query']]['limit']==5000000000
 assert data['native_proof_accepted'] is True and w['logical_proof_accepted'] is True
 assert data['status']==w['status']=='native_proof_discovered'
 final=data['outputs']['final_native'];request=data['outputs']['final_request']
 assert final==last and last['purpose']=='fresh_quantified_receiver_final' and last['request']==request and last['result']['status']=='accepted'
 assert request['target']==data['declaration']['target'] and request['theory']==data['declaration']['theory']
 custody=block_custody(request,data);point=regions(data)
 assert all(w['final_region_verification'][k]==v for k,v in point.items())
 assert s['schema']=='mp-schema-shadow-qualification-result-v1' and s['version']=='mp-schema-shadow-qualification-v3'
 assert s['status']==sw['status']=='SHADOW_QUALIFICATION_PASSED' and s['mode']==sw['mode']=='SHADOW_NO_ADMISSION_CHANGE'
 assert s['failures']==[] and s['prefix_stop'] is None
 assert s['coverage']==dict(families_returned=4,ground_packets_returned=10,generic_inline_completed=3,fixtures_returned=19)
 assert s['input_bytes_unchanged'] is True
 for obj in [s,sw]:
  assert all(obj[k] is False for k in ['native_accepted_by_schema','Model_permission','new_target_proof'])
 snap=s['full_input_snapshot'];policy=load(Path(plan['worker_plan']['path']).parent.parent.parent/'does-not-exist') if False else load(load(row['worker_plan']['path'])['policy']['path'])
 assert snap['library']==policy['library'] and len(snap['library'])==4
 assert snap['inventory']==inv and snap['records']==records and snap['theory']==data['declaration']['theory']
 assert s['fresh_Native_full_request']==wanted and s['fresh_Native_bulk_record_id']==inv['query']
 assert s['complete_original_definitions']==defs and s['complete_original_interfaces']==inv['interfaces']
 assert snap['source_epoch']['receiver_theory']==data['declaration']['theory']
 assert snap['source_epoch']['checker']==dict(original=idx['shadow_sources']['mp_schema_certificate'],owned=shadow_epoch['owned']['mp_schema_certificate'])
 assert snap['source_epoch']['harness']==dict(original=idx['shadow_sources']['mp_schema_shadow_qualification'],owned=shadow_epoch['owned']['mp_schema_shadow_qualification'])
 assert snap['semantic_epoch']['kernel_source']==idx['schema_kernel_source'] and snap['semantic_epoch']['kernel_protocol']=='gcts-fol-1'
 assert [f['family_id']for f in s['family_census']]==[f['id']for f in policy['library']]
 family_statuses=[]
 for f,r in zip(policy['library'],s['family_census']):
  expected='ELIGIBLE_CERTIFICATE' if all(c['rule']in ['assumption','mp','block']for c in f['template']['proof'])else'NOT_ELIGIBLE'
  assert r['result']['status']==expected
  if expected=='ELIGIBLE_CERTIFICATE':
   cert=r['result']['certificate'];assert cert['family']==f and r['revalidation']['certificate']==cert
   assert cert['source_epoch']==snap['source_epoch'] and cert['semantic_epoch']==snap['semantic_epoch']
   assert r['revalidation']['status']==expected
  family_statuses.append(dict(id=f['id'],status=expected,parameters=f['parameters'],dependencies=f['dependencies']))
 assert sum(f['status']=='ELIGIBLE_CERTIFICATE'for f in family_statuses)==3
 assert [g['name']for g in s['every_original_ground_definition']]==names
 for row,g in zip(defs,s['every_original_ground_definition']):
  r=g['result'];assert r['status']=='GROUND_CORRESPONDENCE' and r['input_custody_complete'] is True
  i=r['input_snapshot'];p=r['ground_correspondence'];primitive=p['primitive_expansion']
  assert i['ground_definition']==row and i['arguments']==row['arguments'] and i['dependency_definitions']==defs
  assert i['source_epoch']==snap['source_epoch'] and i['semantic_epoch']==snap['semantic_epoch']
  assert p['ground_definition']==row and p['root_name']==row['name'] and p['arguments']==row['arguments'] and p['full_registry_preserved'] is True
  assert p['original_ordered_closure']==[row] # all ten actual ground bodies have no nested calls
  assert all(primitive[k]==row['definition'][k]for k in ['premises','conclusion','proof'])
  assert primitive['proof'][-1]['formula']==primitive['conclusion'] and primitive['result_row']==len(primitive['proof'])-1
  assert g['literal_primitive_body_equals_fresh_Native_block'] is True
  assert g['independent_primitive_check']==dict(rows=len(primitive['proof']),last_formula=primitive['conclusion'],checked_from_entire_ordered_interface=True)
 generic=s['generic_inline_cases'];assert [g['name']for g in generic]==['ordered_repeated_ports','derived_child_assumption','last_alias_after_unrelated']
 for g in generic:
  assert g['certificate_result']['status']=='ELIGIBLE_CERTIFICATE' and g['correspondence']['status']=='GROUND_CORRESPONDENCE'
  assert g['correspondence']['input_snapshot']['dependency_definitions']==g['full_registry']
  p=g['correspondence']['ground_correspondence']['primitive_expansion']
  if g['name']=='ordered_repeated_ports':assert [f['input_sources']for f in p['frames']if f['name']!=g['ground_root']['name']]==[[0,0]]
  if g['name']=='derived_child_assumption':assert not any(c['rule']=='assumption'and c['formula']==['imp',['bot'],['bot']]for c in p['proof'])
  if g['name']=='last_alias_after_unrelated':assert p['tail_reification'] is not None and p['result_row']==len(p['proof'])-1
 fixtures=s['fixtures'];assert len(fixtures)==19 and len({f['name']for f in fixtures})==19 and all(f['passed'] is True for f in fixtures)
 for f in fixtures:
  if 'result'in f:assert f['result']['status']in f['expected_statuses']
  else:assert f['name'].startswith('exact_') and f['exact_exception_object_propagated'] is True
 assert next(f for f in fixtures if f['name']=='private_work_budget')['result']['status']=='UNKNOWN'
 returned=s['all_returned_component_packets']
 for r in returned:
  assert r['result']['status']in r['expected_statuses']
  authority=r['result']['authority'];assert all(authority[k]is False for k in ['native_accepted','Model_permission','candidate_pruning','new_axiom','logical_target_proof_accepted'])
 assert s['check_calls']<=s['maximum_check_calls']==2000000
 prior=load(R/'prior-case001-fixed-bulk-result.json');parts=semantic_parts(data);priorparts=semantic_parts(prior)
 assert parts==priorparts
 literalparts={}
 for k,v in parts.items():
  b=canonical(v);literalparts[k]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),full_current_prior_literal_equal=True)
 assert literalparts['model']['sha256']==data['model_identity_sha256']==data['model_after_identity_sha256']
 out=dict(schema='ROOT-mp-schema-shadow-retained-admission-v1',source_only=False,saved_evidence_only=True,scientific_replays=0,Native_calls=0,
  admission_checks_passed=True,ROOT_resource_admitted=True,finite_shadow_qualified=True,fresh_native_control_proof=True,new_theorem=False,
  recursive_proposer_enabled=False,new_RL_training=False,GCTS_RL_advantage_established=False,universal_soundness_formalized=False,schema_admission_lane_enabled=False,goal_complete=False,
  invocation_id=row['invocation_id'],subject_sha256=row['subject_sha256'],authorized_index=pin(P/'authorized-index-v1.json'),cohort_closure=pin(R/'ROOT-cohort-closure-v1.json'),
  result=pin(a/'result.json'),sidecar=pin(a/'schema-shadow-result.json'),worker_receipt=pin(a/'worker-receipt.json'),runner_receipt=pin(a/'runner-receipt.json'),terminal=pin(tp),
  status=data['status'],shadow_status=s['status'],coverage=s['coverage'],family_dispositions=family_statuses,fixtures=[dict(name=f['name'],passed=f['passed'],status=f.get('result',{}).get('status'))for f in fixtures],
  returned_packet_stage_entries=len(returned),packet_entries_are_not_unique_call_count=True,check_callbacks=s['check_calls'],native_queries=len(records),full_native_bulk_definitions=len(defs),all10_primitive_bodies_literal_equal_to_fresh_Native=True,
  worker_seconds=(q['worker_terminal_observed_ns']-q['began_ns'])/1e9,terminal_seconds=t['runner_clock_elapsed_seconds'],shadow_interval_seconds=(sw['completed_ns']-sw['started_ns'])/1e9,
  separate_peak_sum_bytes=peak,separate_peak_sum_MiB=peak/1048576,combined_result_bytes=len(raw)+len(sr),source_pins_checked=len(checked_pins),
  full_prior_semantic_literals=literalparts,whole_region=point,block_custody=custody,before_after_literal=literal,
  final_native_request_sha256=last['request_sha256'],final_native_input_sha256=last['input_sha256'],final_native_output_sha256=last['output_sha256'],
  limitations=['Finite familiar control qualification; no newly discovered theorem or search-performance comparison.','Original Native bulk ground admission and final proof checking remained mandatory. No schema bypass or Model permission.','Soundness is a reviewed unformalized conditional argument for the narrow fragment, not a Source-to-Native formal theorem.','Generic inline fixtures are author-supplied plumbing tests, never target proof routes. Cyclic-container fixture does not dynamically exercise every family-DAG guard.','Saved packet entries are retained stages, not unique module-call counts. Native microsteps and schema check callbacks are distinct units.','Only last Native wire files survive on disk; earlier input/output hashes are joined to broker records, not decoded or regenerated.','Memory gate is a conservative sum of separate Darwin worker/Native highwaters; observer/controller and posthoc inspection are outside the timed scientific-worker gate.'])
 print(json.dumps(dict(admission=save(R/'ROOT-actual-admission-v1.json',out),status=out['shadow_status'],native_queries=len(records),fixtures=len(fixtures),scientific_replays=0)))
if __name__=='__main__':main()
