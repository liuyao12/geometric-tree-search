"""Build the public report from complete saved evidence only."""
from pathlib import Path
import gzip,hashlib,json,zipfile
D=Path(__file__).parent
PUB=Path('/private/tmp/gcts-split-controls-publish-20261015')
OUT=PUB/'docs/research/gcts-rl-renewal/conditional-inventory'
PEER=Path('/private/tmp/gcts-mp-schema-peer-20261019')
def load(p):return json.loads(Path(p).read_bytes())
def rawpin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def pin(p):
 p=Path(p).resolve();return dict(path=str(p),**rawpin(p.read_bytes()))
def save(p,v):
 p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
a=load(D/'ROOT-actual-admission-v1.json')
assert a['admission_checks_passed'] and a['finite_shadow_qualified'] and a['ROOT_resource_admitted']
reviewpath=PEER/'peer-saved-evidence-review-v1.json';review=load(reviewpath)
assert review['reviewer_identity']=='/root/conventional_control_review'
assert review['saved_evidence_review_passed'] is True and review['resource_custody_review_passed'] is True and review['mismatch_count']==0
assert review['scientific_calls']==0
base=load(D/'actual-v1/result.json');shadow=load(D/'actual-v1/schema-shadow-result.json')
worker=load(D/'plans/worker-plans/mp-schema-shadow-001-fixed-bulk-ROOT-20261019-v1.json')
summary=dict(schema='mp-schema-shadow-public-summary-v1',date='2026-10-19',status=shadow['status'],
 target=base['declaration'],scientific_actuals=1,qualification_only=True,new_theorems=0,RL_training=False,
 schema_admission_lane_enabled=False,recursive_proposer_enabled=False,universal_soundness_formalized=False,
 GCTS_RL_advantage_established=False,goal_complete=False,coverage=shadow['coverage'],family_dispositions=a['family_dispositions'],
 full_native_bulk_ground_definitions=10,fresh_native_control_proof=True,native_queries=a['native_queries'],
 worker_seconds=a['worker_seconds'],terminal_seconds=a['terminal_seconds'],shadow_interval_seconds=a['shadow_interval_seconds'],
 conservative_separate_peak_sum_bytes=a['separate_peak_sum_bytes'],combined_result_bytes=a['combined_result_bytes'],
 check_callbacks=a['check_callbacks'],retained_component_stage_entries=a['returned_packet_stage_entries'],
 full_prior_semantic_literals=a['full_prior_semantic_literals'],whole_region=a['whole_region'],
 Root_admission=pin(D/'ROOT-actual-admission-v1.json'),independent_review=pin(reviewpath),
 trust='Original full Native ground inventory and final proof checking mandatory. Certificate/qualifier have no Model or Native permission.',
 limitations=a['limitations'])
save(OUT/'mp-schema-shadow-summary.json',summary)
(OUT/'mp-schema-shadow-admission.json').write_bytes((D/'ROOT-actual-admission-v1.json').read_bytes())
(OUT/'mp-schema-shadow-peer-review.json').write_bytes(reviewpath.read_bytes())
(OUT/'mp-schema-shadow-certificate-packets.json').write_bytes((D/'actual-v1/schema-shadow-result.json').read_bytes())
(OUT/'mp-schema-shadow-base-result.json.gz').write_bytes(gzip.compress((D/'actual-v1/result.json').read_bytes(),compresslevel=9,mtime=0))
display=dict(family_census=shadow['family_census'],full_input_snapshot=dict(library=shadow['full_input_snapshot']['library']),
 every_original_ground_definition=shadow['every_original_ground_definition'],
 fixtures=[dict(name=f['name'],passed=f['passed'],result=dict(status=f['result']['status'])if'result'in f else None)for f in shadow['fixtures']])
text=(D/'shadow-report-template.html').read_text()
sub=dict(WORKER=f"{a['worker_seconds']:.3f}",TERMINAL=f"{a['terminal_seconds']:.3f}",
 PEAK=f"{a['separate_peak_sum_MiB']:.3f}",SHADOW=f"{a['shadow_interval_seconds']:.3f}",
 TIME_PERCENT=f"{a['worker_seconds']/180*100:.3f}",MEM_PERCENT=f"{a['separate_peak_sum_bytes']/1073741824*100:.3f}",
 PACKETS=json.dumps(display,separators=(',',':'),ensure_ascii=True).replace('</','<\\/'),
 TARGET=json.dumps(base['outputs']['search']['proof'],separators=(',',':'),ensure_ascii=True).replace('</','<\\/'))
for k,v in sub.items():text=text.replace('@@'+k+'@@',v)
assert '@@'not in text
(OUT/'mp-schema-shadow.html').write_text(text)
# Task-owned navigation only. The research overview index is untouched.
reader=OUT/'reader.html';r=reader.read_text();anchor='<section id="adaptive-group-pilot">'
banner=r'''<section id="mp-schema-shadow"><p class="eyebrow">19 OCTOBER 2026 · LATEST EXECUTED QUALIFICATION</p><h2>Reusable lemma certificates pass their first shadow test.</h2><p>The complete familiar control retains original Native proof checking. Three original families qualify, all ten ground expansions match freshly accepted bodies, and nineteen diagnostic fixtures pass. This is finite qualification, with no new theorem, schema-admission bypass or search-speed claim. <a href="mp-schema-shadow.html?v=20261019-ms1#reader"><b>Inspect the actual family, ground and target proof rows</b></a> · <a href="mp-schema-shadow.html?v=20261019-ms1#parallel">Parallel contributions and evidence</a>.</p></section>'''
if 'id="mp-schema-shadow"'not in r:
 assert r.count(anchor)==1;r=r.replace(anchor,banner+anchor,1)
 r=r.replace('LATEST CERTIFICATION PILOT','EARLIER CERTIFICATION PILOT',1);reader.write_text(r)
for filename in ['parallel-research.html','adaptive-group-pilot.html']:
 p=OUT/filename;t=p.read_text()
 mark='<section id="mp-schema-update">'
 if mark not in t:
  b=r'''<section id="mp-schema-update"><p class="boundary"><strong>Later executed qualification:</strong> <a href="mp-schema-shadow.html?v=20261019-ms1#outcome">the first reusable-lemma shadow control passes</a>, retaining all original Native checks. All ten original ground expansions match their freshly accepted bodies. Schema admission remains disabled; no new theorem or search advantage follows. The report below preserves its earlier milestone.</p></section>'''
  assert '<section 'in t;t=t.replace('<section ',b+'<section ',1);p.write_text(t)
members={};identities=[]
def add(name,p,expected=None):
 p=Path(p);b=p.read_bytes();d=pin(p)
 if expected is not None:assert d==expected
 assert name not in members;members[name]=b;identities.append(dict(member=name,source=d,**rawpin(b)))
for p in sorted(D.glob('*')):
 if p.is_file()and p.suffix in ['.py','.json','.html'] and p.name!='prior-case001-fixed-bulk-result.json':
  add('Root/'+p.name,p)
for folder in ['plans','actual-v1']:
 for p in sorted((D/folder).rglob('*')):
  if p.is_file():add(folder+'/'+str(p.relative_to(D/folder)),p)
for folder,label in [
 ('/private/tmp/gcts-mp-schema-source-20261019','certifier-Source'),
 ('/private/tmp/gcts-mp-schema-shadow-intake-ROOT-source-20261019','Root-intake-and-qualifier-Source'),
 ('/private/tmp/gcts-mp-schema-peer-20261019','independent-reviews')]:
 for p in sorted(Path(folder).glob('*')):
  if p.is_file()and p.suffix in ['.py','.json']:add(label+'/'+p.name,p)
for k,d in worker['native_inputs'].items():add('Native-inputs/'+Path(d['path']).name,d['path'],d)
for role,d in [('policy',worker['policy']),('input-capsule',load(D/'plans/authorized-index-v1.json')['input_capsule']),('raw-kernel',load(D/'plans/authorized-index-v1.json')['schema_kernel_source'])]:
 add('inputs/'+role+Path(d['path']).suffix,d['path'],d)
auth=load(D/'plans/authorizations/mp-schema-shadow-001-fixed-bulk-ROOT-20261019-v1.json')
for role,b in auth['review_roles'].items():add('scoped-review-receipts/'+role+'.json',b['receipt']['path'],b['receipt'])
prior=OUT/'inventory-cert-001-fixed-bulk-result.json.gz';add('comparison-only/prior-case001-result.json.gz',prior)
readme=b"""Retained first MP-schema SHADOW qualification. One scientific actual.
Original complete Native inventory admission and final Native remain mandatory.
This archive includes full literal base and sidecar outputs, raw last Native
wire files, Sources, original inputs, predeclared caps and review/admission data.
It is not a reusable authorization, a universal soundness proof or a benchmark
speed result. Generic fixtures are author-supplied plumbing, not target routes.

The opaque Native microcode gzip is copied raw and never posthoc-decoded.
The comparison-only gzip is ordinary mathematical result JSON. Current raw
result bytes intentionally differ from historical epoch paths/timing; full
compiler/inventory/Model/initial projections are literally equal.
Pinned Python, Z3 distribution, stdlib, loader and OS are not bundled; complete
external file identities and the platform/trust limits remain in the closure.
Reproduction needs the pinned runtime and a fresh reviewed bounded subject,
paths and grant. Do not reuse consumed observations or prior acceptance.
"""
members['README.txt']=readme;identities.append(dict(member='README.txt',**rawpin(readme)))
archive=OUT/'mp-schema-shadow-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,b in sorted(members.items()):
  i=zipfile.ZipInfo(name,(2026,10,19,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16
  z.writestr(i,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(members)
 for name,b in members.items():assert z.read(name)==b
names=['mp-schema-shadow.html','mp-schema-shadow-summary.json','mp-schema-shadow-admission.json','mp-schema-shadow-peer-review.json','mp-schema-shadow-certificate-packets.json','mp-schema-shadow-base-result.json.gz','reader.html','parallel-research.html','adaptive-group-pilot.html']
save(OUT/'mp-schema-shadow-evidence-manifest.json',dict(schema='mp-schema-shadow-public-manifest-v1',archive=pin(archive),members=identities,assets=[pin(OUT/n)for n in names],
 scientific_replays=0,posthoc_opaque_Native_gzip_decodes=0,goal_complete=False,Root_admission=pin(D/'ROOT-actual-admission-v1.json'),independent_review=pin(reviewpath)))
print(json.dumps(dict(archive=pin(archive),members=len(members),report=pin(OUT/'mp-schema-shadow.html'))))
