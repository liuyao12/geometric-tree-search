"""Saved metadata only: exact reviewed subject, fresh max-one Root grant."""
from pathlib import Path
import copy, hashlib, json
D=Path(__file__).parent; P=D/'plans'
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve(); b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checked(d):
 assert pin(d['path'])==d,d
 return load(d['path'])
def save(p,v):
 assert not p.exists(),p
 p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n')
 return pin(p)
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def contains(v,w):
 if v==w:return True
 if type(v)is dict:return any(contains(x,w)for x in v.values())
 if type(v)is list:return any(contains(x,w)for x in v)
 return False
idx=load(P/'prospective-index-v1.json');row=idx['schedule'][0]
once=checked(row['runner_plan_draft']);worker=checked(row['worker_plan'])
old_auth=checked(row['authorization_draft'])
subject={k:v for k,v in once.items()if k!='authorization'}
assert len(subject)==18 and sha(subject)==row['subject_sha256']==old_auth['subject_sha256']
assert old_auth['actual_execution_authorized']is False and old_auth['maximum_actual_invocations']==0 and old_auth['review_roles']=={}
peer=Path('/private/tmp/gcts-mp-schema-peer-20261019')
receipts={
 'ordering_Source':idx['unchanged_ordering_review'],
 'registry_Source':pin('/private/tmp/gcts-adaptive-groups-independent-peer-20261019/typed-Source-review-v1.json'),
 'composition_Source':pin(peer/'typed-intake-Source-review-v3.json'),
 'once_Source':pin(peer/'typed-intake-Source-review-v3.json'),
 'prospective_plans':pin(peer/'typed-prospective-review-v1.json')}
spec={
 'ordering_Source':('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
 'registry_Source':('adaptive-group-registry-driver-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'composition_Source':('mp-schema-shadow-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'once_Source':('mp-schema-shadow-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'prospective_plans':('mp-schema-shadow-prospective-plan-review-v1','prospective_review_passed','/root/conventional_control_review')}
subjects={
 'ordering_Source':[worker['project_sources'][k]for k in ('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],
 'registry_Source':[worker['project_sources']['semantic_inventory_oracle'],worker['components']['receiver_driver']],
 'composition_Source':[once['cold'],worker['components']['receiver_driver'],*idx['shadow_sources'].values()],
 'once_Source':[once['runner'],once['observer']],
 'prospective_plans':[once['integration_declaration'],once['runtime_closure'],once['worker_plan']]}
roles={}
for role,(schema,passed,reviewer)in spec.items():
 r=checked(receipts[role])
 assert r['schema']==schema and r[passed]is True and r['reviewer_identity']==reviewer
 assert r['author_identity']!=reviewer and r['source_only']is True and r['scientific_calls']==0
 assert r['scientific_acceptance']is False and r['actual_execution_authorized']is False
 for s in subjects[role]:assert contains(r,s),(role,s)
 roles[role]=dict(receipt=receipts[role],reviewer_identity=reviewer,required_subjects=subjects[role])
actual=Path(row['actual_directory']);iid=row['invocation_id']
assert not actual.exists()
assert not(P/'runner-plans'/(iid+'-terminal-observation')).exists()
(P/'authorizations').mkdir();(P/'runner-plans').mkdir()
auth=copy.deepcopy(old_auth)
auth.update(actual_execution_authorized=True,maximum_actual_invocations=1,review_roles=roles,
 scope='Exactly one fresh case001 fixed/bulk SHADOW qualification. Full original Native10 admission retained. Same complete original scientific Sources and caps; schema bypass and recursive proposer disabled. Four unique receipts cover five roles, with composition and once scopes from one disclosed reviewer/receipt. No scientific evaluation in grant helper.')
ap=save(P/'authorizations'/(iid+'.json'),auth)
once['authorization']=ap
assert {k:v for k,v in once.items()if k!='authorization'}==subject
op=save(P/'runner-plans'/(iid+'.json'),once)
idx.update(schema='ROOT-mp-schema-shadow-authorized-index-v1',actual_execution_authorized=True,actuals_started=0,
 current_review_roles=receipts,scope='One unchanged local false subject, true/max1 grant only. No scientific evaluation.')
idx['schedule']=[dict(row,authorization=ap,runner_plan=op)]
ip=save(P/'authorized-index-v1.json',idx)
adopt=save(D/'ROOT-final-grant-adoption-v1.json',dict(schema='ROOT-mp-schema-shadow-final-grant-adoption-v1',author_identity='/root',
 source_only=True,scientific_calls=0,scientific_acceptance=False,actuals_started=0,goal_complete=False,
 false_index=pin(P/'prospective-index-v1.json'),authorized_index=ip,subject_sha256=sha(subject),
 exact18field_subject_unchanged=True,current_review_roles=receipts,
 disclosure='Composition and once use the same current independent review. Four unique receipts, not five reviewers.',
 prior_experiments_immutable=True,fresh_shadow_qualification=True,maximum_actual_invocations=1))
print(json.dumps(dict(index=ip,adoption=adopt,runner=op,authorization=ap,subject=sha(subject),scientific_calls=0)))
