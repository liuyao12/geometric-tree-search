"""Static report/archive checks; no scientific execution or opaque decoding."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import gzip,hashlib,json,re,subprocess,zipfile
D=Path(__file__).parent
O=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
class Page(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.scripts=[];self.active=False
 def handle_starttag(self,t,a):
  d=dict(a)
  if 'id'in d:self.ids.append(d['id'])
  if t=='a'and'href'in d:self.links.append(d['href'])
  if t=='script'and'src'not in d:self.active=True;self.scripts.append('')
 def handle_endtag(self,t):
  if t=='script':self.active=False
 def handle_data(self,d):
  if self.active:self.scripts[-1]+=d
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
m=load(O/'mp-schema-shadow-evidence-manifest.json')
for a in m['assets']:
 assert pin(a['path'])==a
assert pin(m['archive']['path'])==m['archive']
with zipfile.ZipFile(m['archive']['path'])as z:
 assert z.testzip()is None and len(z.namelist())==len(m['members'])
 for item in m['members']:
  b=z.read(item['member']);assert len(b)==item['bytes']and hashlib.sha256(b).hexdigest()==item['sha256']
assert gzip.decompress((O/'mp-schema-shadow-base-result.json.gz').read_bytes())==(D/'actual-v1/result.json').read_bytes()
assert (O/'mp-schema-shadow-certificate-packets.json').read_bytes()==(D/'actual-v1/schema-shadow-result.json').read_bytes()
s=(O/'mp-schema-shadow.html').read_text();p=Page();p.feed(s)
assert len(p.ids)==len(set(p.ids)) and '@@'not in s
assert not re.search(r'<(?:sup|sub)\b',s) and not any(c in s for c in '∀∃⇒⊢→ℤ')
for href in p.links:
 u=urlsplit(href)
 if u.scheme:continue
 path=O/unquote(u.path)if u.path else O/'mp-schema-shadow.html'
 assert path.is_file(),href
 if u.fragment and path.suffix=='.html':
  target=Page();target.feed(path.read_text());assert u.fragment in target.ids,href
for i,script in enumerate(p.scripts):
 f=D/('public-ui-static-'+str(i)+'.js');f.write_text(script)
 subprocess.run(['/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','--check',str(f)],check=True,capture_output=True)
# Verify display data against retained full packets, not an independently authored proof.
script=p.scripts[-1];j=script.split('const saved=',1)[1].split(';\nconst target=',1)
display=json.loads(j[0]);target=json.loads(j[1].split(';\nconst esc=',1)[0])
full=load(D/'actual-v1/schema-shadow-result.json');base=load(D/'actual-v1/result.json')
assert display['family_census']==full['family_census']
assert display['every_original_ground_definition']==full['every_original_ground_definition']
assert target==base['outputs']['search']['proof']
assert len(display['fixtures'])==19 and len(target)==12
out=dict(schema='ROOT-mp-schema-shadow-static-publication-validation-v1',passed=True,archive_members=len(m['members']),assets=len(m['assets']),local_links=len(p.links),inline_scripts_syntax_checked=len(p.scripts),display_full_packet_projection_equal=True,math_renderer='Established MathJax3; LaTeX delimiters',scientific_evaluations=0,opaque_Native_gzip_decodes=0,report=pin(O/'mp-schema-shadow.html'),manifest=pin(O/'mp-schema-shadow-evidence-manifest.json'))
f=D/'ROOT-publication-validation-v1.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
