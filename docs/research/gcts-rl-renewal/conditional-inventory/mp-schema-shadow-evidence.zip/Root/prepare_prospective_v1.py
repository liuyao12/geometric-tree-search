"""Raw saved-metadata authoring only; no scientific imports/evaluation."""
from pathlib import Path
import copy,hashlib,json
D=Path(__file__).parent;S=Path('/private/tmp/gcts-mp-schema-shadow-intake-ROOT-source-20261019');OLD=Path('/private/tmp/gcts-adaptive-group-local-pilot-20261019')
P=D/'plans';P.mkdir();(P/'worker-plans').mkdir();(P/'runner-plan-drafts').mkdir();(P/'authorization-drafts').mkdir()
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
 assert not p.exists(),p;p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
h=load(S/'Source-contract-v3.json');oldidx=load(OLD/'plans/prospective-index-v2.json');oldrow=oldidx['schedule'][0]
oldw=load(oldrow['worker_plan']['path']);oldonce=load(oldrow['runner_plan_draft']['path']);oldcase=load(oldidx['case_declaration']['path'])
capsule=load('/private/tmp/gcts-local-operational-20261019/full-assertion-capsule.json');rid='prospective-fol-20261018-001';spec=next(r for r in capsule['receivers']if r['id']==rid)
iid='mp-schema-shadow-001-fixed-bulk-ROOT-20261019-v1'
row=dict(order=1,invocation_id=iid,receiver_id=rid,mode='fixed',inventory_certification_mode='bulk',search_ordering='and_support',model_storage='literal_interned',result_reader='interned',actual_directory=str(D/'actual-v1'))
closure=load(oldidx['runtime_closure']['path']);closure.update(schema='ROOT-mp-schema-shadow-raw-runtime-closure-v1',current_composition_handoff=pin(S/'Source-contract-v3.json'),shadow_sources=h['shadow_sources'],schema_kernel_source=h['schema_kernel_source'],bridge_scope='Same complete24 scientific aliases and original Native/Model/search components; additionally two exact shadow modules sealed before Native after original base seal. No schema admission lane or base-result mutation.')
cp=save(D/'runtime-closure-v1.json',closure)
design=dict(schema='ROOT-mp-schema-shadow-prospective-design-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,goal_complete=False,
 schedule=[row],runtime_closure=cp,intake_Source_contract=pin(S/'Source-contract-v3.json'),
 schema_Source_contract=pin('/private/tmp/gcts-mp-schema-source-20261019/Source-contract-v1.json'),
 schema_Source_review=pin('/private/tmp/gcts-mp-schema-peer-20261019/typed-certificate-Source-review-v1.json'),
 independent_mathematical_obligations=pin('/private/tmp/gcts-mp-schema-peer-20261019/soundness-and-qualification-obligations-v1.json'),
 prior_saved_case001_result_comparison_only=pin(D/'prior-case001-fixed-bulk-result.json'),
 assertion=spec,full_original_family_count=4,known_control_definition_count=10,
 mode='SHADOW_NO_ADMISSION_CHANGE',
 changes='Full existing fixed/and_support/bulk pipeline including Model, search and fresh final Native; post-result schema qualification of all original families/definitions, three generic inline fixtures, eight fixed malformed variants, full epoch/returned-packet mutation, three exact callback exceptions and private work1 UNKNOWN.',
 unchanged='Original full theory, twelve rows, two catalog rounds, every candidate/mark/interface/body, same24 Source aliases, original Native runtime and full resource profile. Complete original Native ground-inventory admission remains mandatory; separate shadow flags never authorize Model or Native acceptance.',
 inputs_are_statements_not_routes=True,fixture_words_are_not_receiver_proof_routes=True,
 raw_result_policy='Keep original result.json completely byte-unchanged; independently reconstruct full literal inverse again after shadow. All inputs supplied to shadow are owned copies. Separate schema-shadow-result.json; combined whole JSON bytes<=128MiB. Entire qualification and all positive metadata+known worker exit before180; UNKNOWN closure before210.',
 invocation_policy='One fresh once-only qualification; no prior acceptance cache or consumed slot reuse. Retain all failures/UNKNOWN. New schema checker is never production admission in this actual.',
 scientific_costs='All26 copies/imports, raw semantic kernel, full Native setup/admission/search, complete result reading, all schema/negative fixtures, validation, serialization and worker exit charged. Native microsteps and schema work counters are separate units, never converted to an assumed speedup.',
 future='Only after finite shadow qualification and reviewed soundness/Source contract, separately predeclare explicit schema admission lane and fair controls. Recursive proposer disabled in this test.')
dp=save(D/'prospective-design-v1.json',design)
case=copy.deepcopy(oldcase);case.update(schema='ROOT-mp-schema-shadow-qualification-declaration-v1',global_cohort_declaration=dp,runtime_closure=cp,selected_receiver_id=rid,selected_receiver=spec,schedule=[row],intake_Source_handoff=pin(S/'Source-contract-v3.json'),
 scope='One familiar case001 qualification, not new theorem/benchmark. Complete original Native ground admission and fresh final check unchanged; shadow result is separate advice/structural correspondence only.',
 shadow_obligations=design['independent_mathematical_obligations'],shadow_fixed_limits=dict(maximum_check_calls=2000000,combined_result_bytes=134217728),
 conformance='No point/mark/Model/search/scheduler/rollback change. All original candidate domains and base alternatives retained. Positive base proof still requires whole finite point t/m verification plus fresh whole Native. This does not newly qualify all historical engine behavior.')
dec=save(D/'case-declaration-v1.json',case)
w=copy.deepcopy(oldw)
for k in ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory'):w[k]=row[k]
w.update(schema='ROOT-mp-schema-shadow-worker-plan-v1',cold=h['cold'],runtime_closure=cp,integration_declaration=dec)
wp=save(P/'worker-plans'/(iid+'.json'),w)
o=copy.deepcopy(oldonce)
for k in ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory'):o[k]=row[k]
o.update(schema='ROOT-mp-schema-shadow-once-plan-v1',cold=h['cold'],runner=h['runner'],observer=h['observer'],runtime_closure=cp,integration_declaration=dec,worker_plan=wp);o.pop('authorization')
assert len(o)==18;subject=sha(o)
ap=save(P/'authorization-drafts'/(iid+'.json'),dict(schema='ROOT-mp-schema-shadow-once-authorization-v1',author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=subject,review_roles={},scope='Prospective shadow qualification only, false/max0. Exact current Source+full plan reviews and fresh Root grant required.'))
o['authorization']=ap;op=save(P/'runner-plan-drafts'/(iid+'.json'),o)
idx=dict(schema='ROOT-mp-schema-shadow-prospective-index-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,goal_complete=False,subject_count=1,
 schedule=[dict(row,worker_plan=wp,runner_plan_draft=op,authorization_draft=ap,subject_sha256=subject)],
 design=dp,case_declaration=dec,runtime_closure=cp,input_capsule=oldidx['input_capsule'],intake_Source_contract=pin(S/'Source-contract-v3.json'),
 source_contract=design['schema_Source_contract'],schema_Source_review=design['schema_Source_review'],unchanged_ordering_review=oldidx['unchanged_ordering_review'],
 cold=h['cold'],runner=h['runner'],observer=h['observer'],shadow_sources=h['shadow_sources'],schema_kernel_source=h['schema_kernel_source'])
ip=save(P/'prospective-index-v1.json',idx)
assert w['project_sources']==oldw['project_sources']and w['components']==oldw['components']and w['native_inputs']==oldw['native_inputs']and w['z3']==oldw['z3']and w['policy']==oldw['policy']
assert case['limits']==oldcase['limits']and not Path(row['actual_directory']).exists()
print(json.dumps(dict(index=ip,case=dec,worker=wp,subject=subject,scientific_calls=0)))
