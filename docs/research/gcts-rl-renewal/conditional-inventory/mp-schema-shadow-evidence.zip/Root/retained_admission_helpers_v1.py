from pathlib import Path
import hashlib,json

def load(path):
    return json.loads(Path(path).read_bytes())


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def pin(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    with Path(path).open('x') as f:
        f.write(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')
    return pin(path)


def regions(data):
    model=data['outputs']['model'];initial=data['initial_state']
    def point(p):
        assert type(p)is list and len(p)==2 and all(type(v)is int for v in p)
        return tuple(p)
    required={point(p) for p in model['roots']}
    assert len(required)==len(model['roots']) and required=={point(p) for p in initial['allowed_points']}
    totals={point(p):v for p,v in initial['totals']};marks={point(p):v for p,v in initial['marks']}
    assert len(totals)==len(initial['totals']) and len(marks)==len(initial['marks'])
    assert set(totals)<=required and all(type(v)is int and 0<=v<=12 for v in totals.values())
    candidates={tuple(c['key']):c for c in model['placements']}
    assert len(candidates)==len(model['placements'])
    search=data['outputs']['search'];selected=[tuple(k) for k in search['placements']]
    assert len(set(selected))==len(selected)
    proof=search['proof'];slots={}
    for key in selected:
        assert key in candidates and len(key)==4 and all(type(v)is int for v in key)
        assert 0<=key[0]<len(proof) and 0<=key[1]<2+model['arity'] and key[:2] not in slots
        c=candidates[key];slots[key[:2]]=c
        assert c['occupancy']==[[[4*key[0],key[1]],12]]
        for p,v in c['occupancy']:
            p=point(p);assert p in required and type(v)is int and v>0
            totals[p]=totals.get(p,0)+v;assert totals[p]<=12
        for p,v in c['marks']:
            p=point(p);assert type(v)is int and (p not in marks or marks[p]==v)
            marks[p]=v
    assert set(totals)==required and all(v==12 for v in totals.values())
    assert len(slots)==len(proof)*(2+model['arity'])
    defs={d['name']:d['definition'] for d in data['outputs']['register']['definitions']}
    for j,line in enumerate(proof):
        row=[slots[j,n] for n in range(2+model['arity'])]
        command=dict(row[0]['command']);assert command==row[1]['command']
        if command['rule']=='block':
            n=len(defs[command['name']]['premises'])
            inputs=[row[2+i]['source'] for i in range(n)]
            assert all(type(i)is int and 0<=i<j for i in inputs)
            command['inputs']=inputs
        assert command==line
    assert data['outputs']['final_request']['proof']==proof
    return dict(status='VERIFIED_WHOLE_FINITE_POINT_REGION',required_points=len(required),
        selected_placements=len(selected),assigned_mark_points=len(marks),decoded_rows=len(proof),
        union_sha256=hashlib.sha256(canonical(dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected)))).hexdigest())


def semantic_parts(data):
    o=data['outputs']
    parts=dict(compiler={k:v for k,v in o['compile'].items() if k!='seconds'},
        inventory={k:o['register'][k] for k in ('definitions','interfaces','native_blocks')})
    if 'model' in o:
        parts['model']={k:v for k,v in o['model'].items() if k!='compile_seconds'}
        parts['initial']=data['initial_state']
    return parts


def block_custody(request, data):
    registered={b['name']:b for b in data['outputs']['register']['native_blocks']}
    supplied={b['name']:b for b in request['blocks']}
    assert len(supplied)==len(request['blocks'])
    assert all(name in registered and b==registered[name] for name,b in supplied.items())
    needed=set()
    def walk(word):
        for line in word:
            if line['rule']=='block':
                name=line['name']
                assert name in supplied
                if name not in needed:
                    needed.add(name);walk(supplied[name]['proof'])
    walk(request['proof'])
    assert needed==set(supplied)
    return dict(supplied_names=sorted(supplied),all_literal_registered=True,all_and_only_recursive_dependencies=True)
