Retained first MP-schema SHADOW qualification. One scientific actual.
Original complete Native inventory admission and final Native remain mandatory.
This archive includes full literal base and sidecar outputs, raw last Native
wire files, Sources, original inputs, predeclared caps and review/admission data.
It is not a reusable authorization, a universal soundness proof or a benchmark
speed result. Generic fixtures are author-supplied plumbing, not target routes.

The opaque Native microcode gzip is copied raw and never posthoc-decoded.
The comparison-only gzip is ordinary mathematical result JSON. Current raw
result bytes intentionally differ from historical epoch paths/timing; full
compiler/inventory/Model/initial projections are literally equal.
Pinned Python, Z3 distribution, stdlib, loader and OS are not bundled; complete
external file identities and the platform/trust limits remain in the closure.
Reproduction needs the pinned runtime and a fresh reviewed bounded subject,
paths and grant. Do not reuse consumed observations or prior acceptance.
