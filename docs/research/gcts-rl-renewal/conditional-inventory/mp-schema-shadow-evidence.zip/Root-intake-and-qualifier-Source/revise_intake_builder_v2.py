"""Raw authoring repair: preserve failed builder/cold V1, never execute intake."""
from pathlib import Path
D=Path(__file__).parent;s=(D/'build_intake_Source_v1.py').read_text()
def sub(a,b,n=1):
 global s
 assert s.count(a)==n,(a,s.count(a));s=s.replace(a,b)
for a,b in [
 ('mp_schema_shadow_qualification_v1.py','mp_schema_shadow_qualification_v2.py'),
 ('mp-schema-shadow-intake-cold-v1','mp-schema-shadow-intake-cold-v2'),
 ('mp_schema_shadow_cold_v1.py','mp_schema_shadow_cold_v2.py'),
 ('mp-schema-shadow-external-once-runner-v1','mp-schema-shadow-external-once-runner-v2'),
 ('mp_schema_shadow_once_runner_v1.py','mp_schema_shadow_once_runner_v2.py'),
 ('mp-schema-shadow-final-terminal-observer-v1','mp-schema-shadow-final-terminal-observer-v2'),
 ('observe_mp_schema_shadow_runner_v1.py','observe_mp_schema_shadow_runner_v2.py'),
 ("D/'Source-contract-v1.json'","D/'Source-contract-v2.json'")]:sub(a,b)
sub('r=sub(r,"             \'complete22project+2component worker intake\')", "             \'complete22project+2component worker intake\')\\n    need',
    'r=sub(r,"\'complete22project+2component worker intake\')", "\'complete22project+2component worker intake\')\\n    need')
sub("        shadow_tick();shadow_started=_NOW_NS()", "        overall_tick();shadow_started=_NOW_NS()")
start=s.index("        theory=own(result_data['declaration']['theory'])")
end=s.index("        shadow_tick();source_guard()",start)
block=s[start:end]
replacement="""        register=result_data['outputs'].get('register')
        if type(register)is dict and register.get('status')=='native_accepted' and _NOW_NS()<work_ns:
"""+''.join('    '+line if line.strip()else line for line in block.splitlines(keepends=True))+"""        else:
            shadow=dict(schema='mp-schema-shadow-qualification-result-v1',version='mp-schema-shadow-qualification-v2',
                status='SHADOW_QUALIFICATION_UNKNOWN',mode='SHADOW_NO_ADMISSION_CHANGE',
                original_inventory_status=register.get('status')if type(register)is dict else'NOT_REACHED',
                fresh_Native_bulk_record_id=register.get('query')if type(register)is dict else None,
                native_accepted_by_schema=False,Model_permission=False,new_target_proof=False,
                reason='No fresh complete Native inventory available inside original work window; no schema qualification executed.',
                retained_base_result=result_pin,all_schema_tests_unexecuted=True)
        def shadow_finish_tick():
            overall_tick()
            if positive or shadow['status']=='SHADOW_QUALIFICATION_PASSED':
                need(_NOW_NS()<work_ns,'all positive shadow/base work within original180')
"""
s=s[:start]+replacement+s[end:]
sub("        shadow_tick();source_guard()\n        need(raw_file(result_pin)","        shadow_finish_tick();source_guard()\n        need(raw_file(result_pin)")
sub("post_shadow_literal=verify_literal_result(result_data,result_raw,shadow_tick)","post_shadow_literal=verify_literal_result(result_data,result_raw,shadow_finish_tick)")
sub("        shadow_tick();source_guard();need(raw_file(result_pin)","        shadow_finish_tick();source_guard();need(raw_file(result_pin)")
sub("             shadow['original_inventory_status']==result['outputs']['register']['status'] and\n             shadow['fresh_Native_bulk_record_id']==result['outputs']['register']['query'] and", "             shadow['original_inventory_status']==result['outputs'].get('register',{}).get('status','NOT_REACHED') and\n             shadow['fresh_Native_bulk_record_id']==result['outputs'].get('register',{}).get('query') and")
sub("             shadow_meta['completed_ns']<work_end,", "             shadow_meta['completed_ns']<overall_end,")
sub("'separate shadow qualification without Native/Model authority; all work before180'", "'separate shadow qualification without Native/Model authority; unknown closure before210'")
sub("            need(terminal_ns<work_end,'positive shadow and known worker exit before180')", "            need(shadow_meta['completed_ns']<work_end and terminal_ns<work_end,'positive shadow and known worker exit before180')")
p=D/'build_intake_Source_v2.py';assert not p.exists();p.write_text(s)
print(str(p))
