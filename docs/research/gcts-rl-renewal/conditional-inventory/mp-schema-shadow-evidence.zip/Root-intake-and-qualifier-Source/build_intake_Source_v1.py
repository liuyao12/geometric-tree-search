"""Derive new, unexecuted SHADOW intake from raw reviewed parent Sources."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).parent;OLD=Path('/private/tmp/gcts-adaptive-group-local-intake-ROOT-source-20261019')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,b):
 assert not p.exists(),p;p.write_bytes(b);return pin(p)
def sub(s,a,b,count=1):
 assert s.count(a)==count,(a,s.count(a));return s.replace(a,b)
SHADOW=dict(mp_schema_certificate=pin('/private/tmp/gcts-mp-schema-source-20261019/mp_schema_certificate_v1.py'),mp_schema_shadow_qualification=pin(D/'mp_schema_shadow_qualification_v1.py'))
KERNEL=pin('/private/tmp/gcts-semantic-family-next-audit-20261018/fol_checker.tree')
s=(OLD/'adaptive_group_local_cold_v2.py').read_text()
for a,b in [
 ('adaptive-group-local-intake-cold-v2','mp-schema-shadow-intake-cold-v1'),
 ('ROOT-adaptive-group-worker-plan-v1','ROOT-mp-schema-shadow-worker-plan-v1'),
 ('adaptive-group-worker-receipt-v1','mp-schema-shadow-worker-receipt-v1'),
 ("plan['inventory_certification_mode']=='adaptive_groups'","plan['inventory_certification_mode']=='bulk'"),
 ('ROOT-adaptive-group-experiment-declaration-v1','ROOT-mp-schema-shadow-qualification-declaration-v1'),
 ("{('fixed','adaptive_groups')}","{('fixed','bulk')}"),
 ('one complete fixed/adaptive-group pilot subject with common assertion/storage/reader','one complete fixed/bulk Native control plus explicit shadow qualification'),
 ('ROOT-adaptive-group-raw-runtime-closure-v1','ROOT-mp-schema-shadow-raw-runtime-closure-v1')]:s=sub(s,a,b)
s=sub(s,'MODEL_STORAGE_MODULES = {','SHADOW_SOURCES = '+repr(SHADOW)+'\nSCHEMA_KERNEL_SOURCE = '+repr(KERNEL)+'\n\nMODEL_STORAGE_MODULES = {')
s=sub(s,"        expected_z3=[", "        need(closure['shadow_sources']==SHADOW_SOURCES and closure['schema_kernel_source']==SCHEMA_KERNEL_SOURCE,\n             'whole separately reviewed shadow Sources and semantic kernel Source')\n        expected_z3=[")
s=sub(s,"        need(Path(plan['z3']['root']).is_absolute(),'owned Z3 package root')", """        owned_shadow={}
        for name,pin in SHADOW_SOURCES.items():
            need(name.isidentifier() and name not in names and name not in sys.modules,'fresh separately scoped shadow module')
            raw=stage('copy shadow:'+name,lambda pin=pin:raw_file(pin,16777216))
            dest=modules_dir/(name+'.py');dest.write_bytes(raw)
            owned_shadow[name]=descriptor(dest,raw);source_pins.extend([pin,owned_shadow[name]])
        stage('kernel semantic raw Source',lambda:raw_file(SCHEMA_KERNEL_SOURCE))
        source_pins.append(SCHEMA_KERNEL_SOURCE)
        need(Path(plan['z3']['root']).is_absolute(),'owned Z3 package root')""")
s=sub(s,"        module_guards.append(seal_callables(list(loaded.values())+z3_modules+[sys.modules[__name__]]))\n        source_guard()", """        # Seal protected base24/Z3/cold callables BEFORE either shadow import.
        # Keep this original guard; never rebaseline the protected objects.
        module_guards.append(seal_callables(list(loaded.values())+z3_modules+[sys.modules[__name__]]))
        source_guard()
        shadow_loaded={}
        for name in SHADOW_SOURCES:
            module=stage('import shadow:'+name,lambda name=name:importlib.import_module(name))
            need(Path(module.__file__).resolve()==Path(owned_shadow[name]['path']),'exact shadow import origin')
            source_guard()
            module_guards.append(seal_callables([module]))
            shadow_loaded[name]=module;source_guard()
        need(len(loaded)==24 and len(shadow_loaded)==2,'same full24 plus exactly2 shadow imports')""")
s=sub(s,"                   sources=dict(project=owned,original=names,cold=plan['cold']),", "                   sources=dict(project=owned,original=names,cold=plan['cold']),\n                   shadow_sources=dict(original=SHADOW_SOURCES,owned=owned_shadow,kernel_source=SCHEMA_KERNEL_SOURCE),")
s=sub(s,"        region_check=(verify_raw_region(result_data,work_ns) if receipt['native_proof_accepted']\n                      else dict(status='NOT_CHECKED_NO_NATIVE_PROOF'))\n        source_guard()", """        region_check=(verify_raw_region(result_data,work_ns) if receipt['native_proof_accepted']
                      else dict(status='NOT_CHECKED_NO_NATIVE_PROOF'))
        source_guard()
        # Base driver/result authority stays byte-for-byte separate. All
        # Shadow work and both complete outputs share the original profile.
        def shadow_tick():
            overall_tick();need(_NOW_NS()<work_ns,'shadow scientific work within original180')
        shadow_tick();shadow_started=_NOW_NS()
        own=lambda v:json.loads(canonical(v))
        theory=own(result_data['declaration']['theory'])
        kernel=loaded['logic'].Kernel(theory['functions'],theory['predicates'],
            {k:loaded['quantified_receptors_v1'].frozen(v) for k,v in theory['axioms'].items()})
        def formula_validator(formula):
            shadow_tick();kernel.formula(loaded['quantified_receptors_v1'].frozen(formula));shadow_tick();return True
        shadow_source_epoch=dict(schema='mp-schema-shadow-authenticated-Source-epoch-v1',
            checker=dict(original=SHADOW_SOURCES['mp_schema_certificate'],owned=owned_shadow['mp_schema_certificate']),
            harness=dict(original=SHADOW_SOURCES['mp_schema_shadow_qualification'],owned=owned_shadow['mp_schema_shadow_qualification']),
            syntax_validator=dict(original=names['logic'],owned=owned['logic']),
            syntax_AST=dict(original=names['quantified_receptors_v1'],owned=owned['quantified_receptors_v1']),
            cold=plan['cold'],policy=plan['policy'],receiver_theory=theory,
            scope='Complete relevant Source/theory capsule, not mathematical authority. Full unchanged base24 runtime is separately bound by original source_epoch and closure.')
        semantic_epoch=dict(kernel_protocol='gcts-fol-1',kernel_source=SCHEMA_KERNEL_SOURCE,
            native_program_sha256=PROGRAM_SHA,fragment='IMPLICATION_META_ASSUMPTION_MP_CERTIFIED_DAG_V1',
            rule_semantics='Exact original kernel assumption/MP/prior-block rules; no object binder around metas.')
        need(canonical(result_data['records'])==canonical(oracle_box[0].records),'complete fresh base Native records before shadow')
        shadow=shadow_loaded['mp_schema_shadow_qualification'].run_shadow(
            schema_module=shadow_loaded['mp_schema_certificate'],
            library=own(json.loads(raw_file(plan['policy']))['library']),
            inventory=own(result_data['outputs']['register']),records=own(result_data['records']),
            theory=theory,source_epoch=shadow_source_epoch,semantic_epoch=semantic_epoch,
            source_guard=source_guard,formula_validator=formula_validator,check=shadow_tick)
        shadow_tick();source_guard()
        need(raw_file(result_pin)==result_raw,'whole original result bytes unchanged after shadow')
        post_shadow_literal=verify_literal_result(result_data,result_raw,shadow_tick)
        need(post_shadow_literal==literal,'whole original in-memory result unchanged after shadow')
        shadow_raw=canonical(shadow)+b'\\n'
        need(len(shadow_raw)+len(result_raw)<=134217728,'combined complete base+shadow128MiB output cap')
        shadow_pin=write_new(actual/'schema-shadow-result.json',shadow)
        shadow_reloaded=raw_file(shadow_pin)
        need(shadow_reloaded==shadow_raw and canonical(json.loads(shadow_reloaded))+b'\\n'==shadow_reloaded,
             'whole shadow raw bytes and literal JSON inverse')
        shadow_tick();source_guard();need(raw_file(result_pin)==result_raw,'final whole original result bytes still unchanged')
        shadow_observation=dict(output=shadow_pin,status=shadow['status'],mode=shadow['mode'],
            started_ns=shadow_started,completed_ns=_NOW_NS(),sources=dict(original=SHADOW_SOURCES,owned=owned_shadow),
            kernel_source=SCHEMA_KERNEL_SOURCE,combined_result_bytes=len(result_raw)+len(shadow_raw),
            original_result_unchanged=True,post_shadow_literal=post_shadow_literal,
            native_accepted_by_schema=False,Model_permission=False,new_target_proof=False)
        source_guard()""")
s=sub(s,"            source_epoch_sha256=hashlib.sha256(canonical(epoch)).hexdigest(),", "            schema_shadow=shadow_observation,\n            source_epoch_sha256=hashlib.sha256(canonical(epoch)).hexdigest(),")
cold=save(D/'mp_schema_shadow_cold_v1.py',s.encode())
r=(OLD/'adaptive_group_local_once_runner_v2.py').read_text()
for a,b in [
 ('adaptive-group-local-external-once-runner-v2','mp-schema-shadow-external-once-runner-v1'),
 ('ROOT-adaptive-group-once-plan-v1','ROOT-mp-schema-shadow-once-plan-v1'),
 ('ROOT-adaptive-group-once-authorization-v1','ROOT-mp-schema-shadow-once-authorization-v1'),
 ('adaptive-group-worker-receipt-v1','mp-schema-shadow-worker-receipt-v1'),
 ('adaptive-group-external-once-receipt-v1','mp-schema-shadow-external-once-receipt-v1'),
 ("CERTIFICATIONS = ('adaptive_groups',)","CERTIFICATIONS = ('bulk',)"),
 ('ROOT-adaptive-group-worker-plan-v1','ROOT-mp-schema-shadow-worker-plan-v1'),
 ('ROOT-adaptive-group-experiment-declaration-v1','ROOT-mp-schema-shadow-qualification-declaration-v1'),
 ('ROOT-adaptive-group-raw-runtime-closure-v1','ROOT-mp-schema-shadow-raw-runtime-closure-v1'),
 ('adaptive-group-intake-typed-Source-review-v1','mp-schema-shadow-intake-typed-Source-review-v1'),
 ('adaptive-group-prospective-plan-review-v1','mp-schema-shadow-prospective-plan-review-v1'),
 ('complete single fixed/adaptive-group pilot declaration','complete single fixed/bulk Native plus shadow declaration')]:r=sub(r,a,b,2 if a=='adaptive-group-intake-typed-Source-review-v1'else 1)
tree=ast.parse(r)
n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='COLD_PIN'for t in n.targets))
lines=r.splitlines(keepends=True);lines[n.lineno-1:n.end_lineno]=['COLD_PIN = '+repr(cold)+'\n'];r=''.join(lines)
r=sub(r,"             'complete22project+2component worker intake')", "             'complete22project+2component worker intake')\n    need(closure['shadow_sources']==SHADOW_SOURCES,'whole two shadow Source descriptors')")
r=sub(r,'REVIEW_ROLES = {','SHADOW_SOURCES = '+repr(SHADOW)+'\n\nREVIEW_ROLES = {')
r=sub(r,"'registry_Source':[worker['project_sources']['semantic_inventory_oracle']],", "'registry_Source':[worker['project_sources']['semantic_inventory_oracle'],worker['components']['receiver_driver']],")
r=sub(r,"'composition_Source':[plan['cold'],worker['components']['receiver_driver']],", "'composition_Source':[plan['cold'],worker['components']['receiver_driver']]+list(SHADOW_SOURCES.values()),")
needle="        search_role='family_search' if plan['mode']=='fixed' else 'symbolic_control'"
insert="""        shadow_meta=worker_receipt['schema_shadow']
        shadow_path=actual/'schema-shadow-result.json'
        shadow_raw=read_raw(shadow_path,LIMITS['result_bytes'],overall_end)
        pins['schema_shadow']=pin_raw(shadow_path,shadow_raw);shadow=parse(shadow_raw)
        need(pins['schema_shadow']==shadow_meta['output'] and len(result_raw)+len(shadow_raw)==shadow_meta['combined_result_bytes']<=LIMITS['result_bytes'],
             'whole two-file output custody and unchanged combined128MiB cap')
        need(shadow_meta['original_result_unchanged']is True and shadow_meta['post_shadow_literal']==worker_receipt['result_reading']['roundtrip'] and
             shadow_meta['sources']['original']==SHADOW_SOURCES and
             shadow_meta['sources']==result['source_epoch']['shadow_sources']|{'kernel_source':shadow_meta['kernel_source']} if False else True,'placeholder')
"""
# Deliberately build the Source plainly; no metadata expression is evaluated.
insert=insert[:insert.index("        need(shadow_meta['original_result_unchanged']")]+"""        need(shadow_meta['original_result_unchanged']is True and
             shadow_meta['post_shadow_literal']==worker_receipt['result_reading']['roundtrip'] and
             shadow_meta['sources']['original']==SHADOW_SOURCES and
             all(shadow_meta['sources'][k]==result['source_epoch']['shadow_sources'][k]for k in ('original','owned')) and
             shadow_meta['kernel_source']==result['source_epoch']['shadow_sources']['kernel_source'],
             'whole current shadow Source maps and unchanged base literal inverse')
        need(shadow['mode']==shadow_meta['mode']=='SHADOW_NO_ADMISSION_CHANGE' and
             shadow['status']==shadow_meta['status'] and shadow['status']in
             ('SHADOW_QUALIFICATION_PASSED','SHADOW_QUALIFICATION_FAILED','SHADOW_QUALIFICATION_UNKNOWN') and
             shadow['original_inventory_status']==result['outputs']['register']['status'] and
             shadow['fresh_Native_bulk_record_id']==result['outputs']['register']['query'] and
             shadow['native_accepted_by_schema']is False and shadow['Model_permission']is False and shadow['new_target_proof']is False and
             shadow_meta['completed_ns']<work_end,
             'separate shadow qualification without Native/Model authority; all work before180')
        if shadow['status']=='SHADOW_QUALIFICATION_PASSED':
            need(terminal_ns<work_end,'positive shadow and known worker exit before180')
"""
r=sub(r,needle,insert+needle)
runner=save(D/'mp_schema_shadow_once_runner_v1.py',r.encode())
o=(OLD/'observe_adaptive_group_local_runner_v2.py').read_text()
o=sub(o,'adaptive-group-local-final-terminal-observer-v2','mp-schema-shadow-final-terminal-observer-v1')
o=sub(o,'ROOT-adaptive-group-once-plan-v1','ROOT-mp-schema-shadow-once-plan-v1')
o=sub(o,'0ff157a8edbd8e26ebb3eec4388728e7f80dde523be57789743663e243f6c787',runner['sha256'])
observer=save(D/'observe_mp_schema_shadow_runner_v1.py',o.encode())
retained={}
for label,old,new in [('cold',OLD/'adaptive_group_local_cold_v2.py',Path(cold['path'])),('runner',OLD/'adaptive_group_local_once_runner_v2.py',Path(runner['path'])),('observer',OLD/'observe_adaptive_group_local_runner_v2.py',Path(observer['path']))]:
 a=ast.parse(old.read_bytes());b=ast.parse(new.read_bytes());compile(b,str(new),'exec',dont_inherit=True)
 da={n.name:ast.dump(n,include_attributes=False)for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 db={n.name:ast.dump(n,include_attributes=False)for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 retained[label]=dict(unchanged=[k for k in da if da[k]==db.get(k)],changed=[k for k in da if da[k]!=db.get(k)],added=[k for k in db if k not in da])
contract=dict(schema='ROOT-mp-schema-shadow-intake-Source-contract-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,scientific_acceptance=False,
 cold=cold,runner=runner,observer=observer,shadow_sources=SHADOW,schema_kernel_source=KERNEL,
 parent_cold=pin(OLD/'adaptive_group_local_cold_v2.py'),parent_runner=pin(OLD/'adaptive_group_local_once_runner_v2.py'),parent_observer=pin(OLD/'observe_adaptive_group_local_runner_v2.py'),
 base_registry=pin('/private/tmp/gcts-adaptive-groups-ROOT-source-20261019/semantic_inventory_oracle_v3.py'),base_driver=pin('/private/tmp/gcts-adaptive-groups-ROOT-source-20261019/inventory_certification_receiver_driver_v3.py'),
 retained_callable_AST=retained,compile_without_evaluation=True,
 scope='Fresh fixed/bulk case001 shadow qualification. Same original24 Native/search components, both extra modules sealed before Native after original base seal, full Native10 remains mandatory, original result bytes unchanged, separate shadow file combined128MiB and original180/210/1GiB profile. No schema lane activation or new theorem/performance claim.',goal_complete=False)
cp=save(D/'Source-contract-v1.json',(json.dumps(contract,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps(dict(contract=cp,cold=cold,runner=runner,observer=observer,retained=retained),sort_keys=True))
