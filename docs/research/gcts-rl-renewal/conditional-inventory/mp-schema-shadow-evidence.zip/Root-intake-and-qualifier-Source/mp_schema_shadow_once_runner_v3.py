"""Prospective single-profile external runner; raw transport/resource only.

Root alone freezes this Source, its plan/authorization and runs an actual.
No project, solver, proof, compiler or native-library imports are performed.
"""
import time
_NOW = time.monotonic_ns
ENTRY_BEGAN_NS = _NOW()
import hashlib
import json
import math
import os
from pathlib import Path
import selectors
import signal
import stat
import subprocess
import sys

VERSION = 'mp-schema-shadow-external-once-runner-v3'
PLAN_SCHEMA = 'ROOT-mp-schema-shadow-once-plan-v1'
AUTH_SCHEMA = 'ROOT-mp-schema-shadow-once-authorization-v1'
WORKER_RECEIPT_SCHEMA = 'mp-schema-shadow-worker-receipt-v1'
RECEIPT_SCHEMA = 'mp-schema-shadow-external-once-receipt-v1'
LIMITS = {'work_seconds':180,'overall_seconds':210,'aggregate_peak_bytes':1073741824,
          'stdout_bytes':4194304,'stderr_bytes':4194304,'result_bytes':134217728,
          'worker_receipt_bytes':4194304,'runner_plan_bytes':16777216,
          'failure_cleanup_seconds':5,'poll_milliseconds':20}
KINDS = ('fixed',)
STORAGES = ('literal_interned',)
ORDERINGS = ('and_support',)
CERTIFICATIONS = ('bulk',)
COLD_PIN = {'path': '/private/tmp/gcts-mp-schema-shadow-intake-ROOT-source-20261019/mp_schema_shadow_cold_v3.py', 'sha256': '5a9fae2f4747bc3049c408394a497b276ba15685b90469c44b02b4ecdf0282e0', 'bytes': 42669}
SHADOW_SOURCES = {'mp_schema_certificate': {'path': '/private/tmp/gcts-mp-schema-source-20261019/mp_schema_certificate_v1.py', 'sha256': '7351d5954763e8b671411a78a821e5cc560ac1af19477a9491da573a735d2ae4', 'bytes': 26687}, 'mp_schema_shadow_qualification': {'path': '/private/tmp/gcts-mp-schema-shadow-intake-ROOT-source-20261019/mp_schema_shadow_qualification_v3.py', 'sha256': '5e3b715242b40941dc918e623746ba90a946d12fc3f3158b99ff3a4115e38694', 'bytes': 19493}}

REVIEW_ROLES = {'ordering_Source': ('and-support-ordering-components-typed-Source-review-v1', 'source_review_passed', '/root/receiver_driver_review'), 'registry_Source': ('adaptive-group-registry-driver-typed-Source-review-v1', 'source_review_passed', '/root/conventional_control_review'), 'composition_Source': ('mp-schema-shadow-intake-typed-Source-review-v1', 'source_review_passed', '/root/conventional_control_review'), 'once_Source': ('mp-schema-shadow-intake-typed-Source-review-v1', 'source_review_passed', '/root/conventional_control_review'), 'prospective_plans': ('mp-schema-shadow-prospective-plan-review-v1', 'prospective_review_passed', '/root/conventional_control_review')}


class OnceRunnerError(ValueError):
    pass


def need(ok,message):
    if not ok:raise OnceRunnerError(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def exact_path(value):
    need(type(value) is str,'literal absolute path')
    p=Path(value);need(p.is_absolute() and p==p.resolve(),'canonical absolute path')
    return p


def read_raw(path,cap,end=None):
    fd=os.open(str(path),os.O_RDONLY|os.O_NOFOLLOW)
    try:
        info=os.fstat(fd);need(stat.S_ISREG(info.st_mode) and info.st_size<=cap,'whole finite regular file')
        blocks=[];total=0
        while True:
            if end is not None:need(_NOW()<end,'postterminal file read under original overall deadline')
            block=os.read(fd,65536)
            if not block:break
            total+=len(block);need(total<=cap,'whole file grows beyond finite cap')
            blocks.append(block)
        need(total==info.st_size,'whole raw file EOF/size stable')
        return b''.join(blocks)
    finally:os.close(fd)


def pin_raw(path,raw):
    return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}


def read_pinned(desc,cap,end=None):
    need(type(desc) is dict and set(desc)=={'path','sha256','bytes'},'exact raw descriptor')
    path=exact_path(desc['path']);raw=read_raw(path,cap,end)
    need(pin_raw(path,raw)==desc,'whole raw SHA/size identity')
    return raw


def reject_pairs(pairs):
    answer={}
    for k,v in pairs:
        need(k not in answer,'duplicate JSON key');answer[k]=v
    return answer


def reject_constant(value):
    raise OnceRunnerError('nonfinite JSON constant')


def finite_float(value):
    result=float(value);need(math.isfinite(result),'finite JSON diagnostic float');return result


def parse(raw):
    return json.loads(raw,object_pairs_hook=reject_pairs,parse_constant=reject_constant,parse_float=finite_float)


def write_new(path,raw):
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        at=0
        while at<len(raw):
            n=os.write(fd,raw[at:at+65536]);need(n>0,'whole exclusive owned output');at+=n
    finally:os.close(fd)
    return pin_raw(path,raw)


def contains_literal(value, subject):
    # Custody lookup of complete literal descriptors only, not scope semantics.
    if value==subject:return True
    if type(value) is dict:return any(contains_literal(v,subject) for v in value.values())
    if type(value) is list:return any(contains_literal(v,subject) for v in value)
    return False


def python_custody(pin, end):
    executable=sys.executable
    bindings=((os,'open',os.open),(os,'read',os.read),(os,'fstat',os.fstat),
              (os,'stat',os.stat),(os,'close',os.close),(os,'wait4',os.wait4),
              (os,'killpg',os.killpg),(os,'getpgrp',os.getpgrp),
              (hashlib,'sha256',hashlib.sha256),(time,'monotonic_ns',time.monotonic_ns))
    opened,read_bytes,fstat,nofollow,close_fd=(b[2] for b in bindings[:5])
    path=exact_path(pin['path']);need(Path(executable).resolve()==path,'exact outer Python executable')
    def signature(info):
        need(stat.S_ISREG(info.st_mode),'nofollow regular Python runtime')
        return (info.st_dev,info.st_ino,info.st_mode,info.st_size,info.st_mtime_ns,info.st_ctime_ns)
    fd=opened(str(path),os.O_RDONLY|os.O_NOFOLLOW)
    try:
        before=signature(fstat(fd))
        need(signature(nofollow(str(path),follow_symlinks=False))==before,'baseline Python path/fd identity')
        digest=hashlib.sha256();size=0
        while True:
            need(_NOW()<end,'baseline Python bytes under original work clock')
            chunk=read_bytes(fd,65536)
            if not chunk:break
            size+=len(chunk);digest.update(chunk)
        need(signature(fstat(fd))==before and signature(nofollow(str(path),follow_symlinks=False))==before,
             'stable before/hash/after Python baseline')
        need({'path':str(path),'bytes':size,'sha256':digest.hexdigest()}==pin,'whole Python baseline pin')
    finally:close_fd(fd)
    def guard():
        need(sys.executable is executable and _NOW is bindings[-1][2],'captured outer interpreter/clock identities')
        need(all(getattr(owner,name) is function for owner,name,function in bindings),'captured outer native runtime callables')
        need(signature(nofollow(str(path),follow_symlinks=False))==before,'unchanged nofollow Python signature')
    guard()
    return guard,{'python':pin,'signature_fields':['dev','ino','mode','size','mtime_ns','ctime_ns'],
        'baseline_signature':list(before),'whole_baseline_authenticated':True,
        'callback_policy':'OUTER_POLL_METADATA_ONLY_NO_REBASELINE','trusted_OS_metadata_assumption':True,
        'worker_callback_guard_claimed':False,'formal_continuous_seal':False}


def intake_subject(plan, overall_end):
    worker=parse(read_pinned(plan['worker_plan'],16777216,overall_end))
    declaration=parse(read_pinned(plan['integration_declaration'],1048576,overall_end))
    closure=parse(read_pinned(plan['runtime_closure'],1048576,overall_end))
    need(plan['cold']==COLD_PIN,'exact frozen current cold bridge')
    for key in ('invocation_id','mode','search_ordering','inventory_certification_mode','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure'):
        need(worker[key]==plan[key],'complete worker/once binding '+key)
    need(worker['schema']=='ROOT-mp-schema-shadow-worker-plan-v1' and
         len(worker['project_sources'])==22 and set(worker['components'])=={'receiver_driver','bounded_transport'},
         'complete22project+2component worker intake')
    need(closure['shadow_sources']==SHADOW_SOURCES,'whole two shadow Source descriptors')
    names=dict(worker['project_sources'],semantic_receiver_driver=worker['components']['receiver_driver'],
               bounded_request_oracle=worker['components']['bounded_transport'])
    need(len(names)==24 and closure['schema']=='ROOT-mp-schema-shadow-raw-runtime-closure-v1' and
         closure['project_sources']==worker['project_sources'] and closure['additional_nonseed_components']==worker['components'] and
         closure['materialized_aliases']==names and closure['runtime']['Python_executable']==plan['python'],
         'same full24 alias closure/native runtime intake')
    need(declaration['schema']=='ROOT-mp-schema-shadow-qualification-declaration-v1' and
         declaration['runtime_closure']==plan['runtime_closure'] and declaration['parent_structural_declaration']==worker['declaration'] and
         declaration['selected_receiver_id']==plan['receiver_id'] and declaration['result_reader']==plan['result_reader'],
         'full current integration declaration binding')
    schedule=declaration['schedule'];ids=[r['invocation_id'] for r in schedule]
    need(len(ids)==1 and len(set(ids))==1 and ids.count(plan['invocation_id'])==1 and
         len({r['actual_directory'] for r in schedule})==1 and
         {(r['mode'],r['inventory_certification_mode']) for r in schedule}==
             {(m,c) for m in KINDS for c in CERTIFICATIONS} and
         all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and
             r['result_reader']=='interned' and r['search_ordering']=='and_support' for r in schedule),'complete single fixed/bulk Native plus shadow declaration')
    row=schedule[ids.index(plan['invocation_id'])]
    need(all(row[k]==plan[k] for k in ('mode','search_ordering','inventory_certification_mode','result_reader','receiver_id','actual_directory','model_storage')),
         'declared literal current arm, no route')
    limits=declaration['limits']
    need(all(limits[k]==v for k,v in {'work_seconds':180,'overall_seconds':210,
         'conservative_worker_plus_native_peak_bytes':1073741824,'result_bytes':134217728,
         'search_seconds':30,'search_max_nodes':5000,'compile_queries':512,'inventory_registration_aggregate_micro_steps':5000000000}.items()),'unchanged scientific profile')
    return worker,declaration,closure


def authenticate_reviews(auth, plan, worker, overall_end):
    roles=auth['review_roles'];need(type(roles)is dict and set(roles)==set(REVIEW_ROLES),'exact five current scoped review roles')
    minimum={'ordering_Source':[worker['project_sources'][k] for k in
                 ('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],
             'registry_Source':[worker['project_sources']['semantic_inventory_oracle'],worker['components']['receiver_driver']],
             'composition_Source':[plan['cold'],worker['components']['receiver_driver']]+list(SHADOW_SOURCES.values()),
             'once_Source':[plan['runner'],plan['observer']],
             'prospective_plans':[plan['integration_declaration'],plan['runtime_closure'],plan['worker_plan']]}
    checked={}
    for role,(schema,passed,reviewer) in REVIEW_ROLES.items():
        binding=roles[role]
        need(type(binding)is dict and set(binding)=={'receipt','reviewer_identity','required_subjects'} and
             binding['reviewer_identity']==reviewer,'literal expected review identity '+role)
        review=parse(read_pinned(binding['receipt'],2097152,overall_end))
        need(review['schema']==schema and review[passed] is True and review['reviewer_identity']==reviewer and
             review['author_identity']!=reviewer and review['source_only'] is True and
             review['scientific_acceptance'] is False and review['actual_execution_authorized'] is False and
             type(review['scientific_calls'])is int and review['scientific_calls']==0,'current raw scoped review '+role)
        subjects=binding['required_subjects']
        need(type(subjects)is list and len(subjects)>=len(minimum[role]) and all(x in subjects for x in minimum[role]),
             'current complete required subject descriptors '+role)
        for subject in subjects:
            need(type(subject)is dict and set(subject)=={'path','sha256','bytes'},'whole descriptor review subject')
            need(contains_literal(review,subject),'full literal subject occurs in current review '+role)
        checked[role]=binding
    return checked


def run_once(*, runner_plan_path):
    began=ENTRY_BEGAN_NS
    work_end=began+LIMITS['work_seconds']*1000000000
    overall_end=began+LIMITS['overall_seconds']*1000000000
    path=exact_path(runner_plan_path)
    plan_raw=read_raw(path,LIMITS['runner_plan_bytes'],overall_end);plan=parse(plan_raw)
    fields={'schema','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory',
            'runner','observer','python','cold','worker_plan','integration_declaration','runtime_closure','authorization','limits','environment'}
    need(type(plan)is dict and set(plan)==fields and plan['schema']==PLAN_SCHEMA,'exact compact-model cold once plan')
    need(plan['inventory_certification_mode'] in CERTIFICATIONS and
         plan['mode'] in KINDS and type(plan['search_ordering'])is str and plan['search_ordering'] in ORDERINGS and type(plan['invocation_id'])is str and bool(plan['invocation_id']) and
         type(plan['model_storage'])is str and plan['model_storage'] in STORAGES and
         plan['result_reader']=='interned' and type(plan['receiver_id'])is str and bool(plan['receiver_id']),
         'explicit matched method/storage/complete shared reader/receiver')
    need(plan['limits']==LIMITS,'original180/210/1GiB/128MiB/log profile')
    need(type(plan['environment'])is dict and all(type(k)is str and type(v)is str for k,v in plan['environment'].items()),'literal child environment')
    need(not(set(plan['environment'])&{'PATH','PYTHONPATH','PYTHONHOME','Z3_LIBRARY_PATH','DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH'}),'no implicit runtime loader overrides')
    worker,declaration,closure=intake_subject(plan,overall_end)
    auth=parse(read_pinned(plan['authorization'],1048576,overall_end))
    auth_fields={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'}
    need(type(auth)is dict and set(auth)==auth_fields and auth['schema']==AUTH_SCHEMA and auth['author_identity']=='/root' and
         auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations'])is int and
         auth['maximum_actual_invocations']==1,'fresh Root true maximum-one authorization')
    subject={k:v for k,v in plan.items() if k!='authorization'}
    need(auth['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest(),'whole exact current once subject')
    review_roles=authenticate_reviews(auth,plan,worker,overall_end)
    actual=exact_path(plan['actual_directory'])
    need(actual.parent.is_dir() and not actual.exists(),'fresh owned actual directory')
    os.mkdir(actual,0o700)
    marker={'schema':'semantic-family-once-consumed-v1','invocation_id':plan['invocation_id'],
        'mode':plan['mode'],'search_ordering':plan['search_ordering'],'inventory_certification_mode':plan['inventory_certification_mode'],'model_storage':plan['model_storage'],'result_reader':plan['result_reader'],
        'plan':pin_raw(path,plan_raw),'began_ns':began,'work_deadline_ns':work_end,
        'overall_deadline_ns':overall_end,'consumed_before_Popen':True,'maximum_worker_launches':1}
    marker_pin=write_new(actual/'CONSUMED.json',canonical(marker)+b'\n')
    process=None;pid=None;pgid=None;wait_status=None;wait_usage=None;reaped=False
    stdout_count=stderr_count=0;capture_complete=True;signals=[];errors=[];terminal_ns=None
    streams={};selector=None;fds={};pins={};worker_receipt=None;group_absent=None
    group_probe_count=0;group_last_probe_ns=None;group_absence_observed_ns=None;group_absence_latched=False;group_reappearance_observed_ns=None
    eof={'stdout':False,'stderr':False};drain_closed_ns=None;runtime_guard=None;runtime_evidence=None
    resource_candidate=False;proof_transport_candidate=False;worker_exit=None;launch_attempts=0
    def reap():
        nonlocal reaped,wait_status,wait_usage,worker_exit,terminal_ns
        if pid is None or reaped:return reaped
        got,status,usage=os.wait4(pid,os.WNOHANG)
        if got:
            need(got==pid,'exact owned Python wait4 PID')
            reaped=True;wait_status=status;worker_exit=os.waitstatus_to_exitcode(status)
            process.returncode=worker_exit;terminal_ns=_NOW()
            wait_usage={'ru_maxrss':usage.ru_maxrss,'ru_utime':usage.ru_utime,'ru_stime':usage.ru_stime,
                'ru_minflt':usage.ru_minflt,'ru_majflt':usage.ru_majflt}
        return reaped
    def probe_group():
        nonlocal group_absent,group_probe_count,group_last_probe_ns,group_absence_observed_ns,group_absence_latched,group_reappearance_observed_ns
        if pgid is None:return None
        need(group_reappearance_observed_ns is None,'owned PGID reappearance is permanently unaccepted')
        need(pgid==pid and pgid!=os.getpgrp(),'probe exact newly owned group')
        group_probe_count+=1;group_last_probe_ns=_NOW()
        try:
            os.killpg(pgid,0);group_absent=False
            if group_absence_latched:
                group_reappearance_observed_ns=group_last_probe_ns
                raise OnceRunnerError('present PGID after observed absence; never signal or reaccept')
        except ProcessLookupError:
            group_absent=True;group_absence_latched=True
            if group_absence_observed_ns is None:group_absence_observed_ns=group_last_probe_ns
        return group_absent
    def signal_group(signum):
        if pgid is None:return
        need(pgid==pid and pgid!=os.getpgrp() and not group_absence_latched,
             'signal only continuously owned group, never a reused absent PGID')
        try:os.killpg(pgid,signum)
        except ProcessLookupError:pass
        signals.append({'signal':signum,'stamp_ns':_NOW(),'pgid':pgid})
    def drain(key, failure=False):
        nonlocal stdout_count,stderr_count,capture_complete
        try:raw=os.read(key.fileobj.fileno(),65536)
        except BlockingIOError:return
        label=key.data
        if not raw:
            eof[label]=True;selector.unregister(key.fileobj);return
        before=stdout_count if label=='stdout' else stderr_count
        if label=='stdout':stdout_count+=len(raw)
        else:stderr_count+=len(raw)
        remaining=max(0,LIMITS[label+'_bytes']-before);keep=raw[:remaining];at=0
        while at<len(keep):
            n=os.write(fds[label],keep[at:]);need(n>0,'whole bounded captured log');at+=n
        if len(raw)>remaining:
            capture_complete=False
            if not failure:raise OnceRunnerError('owned '+label+' exceeds finite cap; no truncated positive')
    def wait_cleanup():
        # Reaping the leader alone is not closure: keep probing its owned group
        # and draining all inherited pipes, even after wait4 already succeeded.
        nonlocal drain_closed_ns
        if pid is None:return
        if probe_group() is not True:signal_group(signal.SIGKILL)
        failure_end=_NOW()+LIMITS['failure_cleanup_seconds']*1000000000
        while _NOW()<failure_end:
            reap();probe_group()
            if selector is not None:
                for key,mask in selector.select(.01):drain(key,failure=True)
            if reaped and group_absent is True and (selector is None or not selector.get_map()):
                drain_closed_ns=_NOW();return
            time.sleep(.01)
        reap();probe_group()
    try:
        need(sys.platform=='darwin' and sys.byteorder=='little','Darwin/little-endian resource units')
        need(_NOW()<work_end,'startup/intake under original work')
        need(pin_raw(Path(__file__).resolve(),read_raw(Path(__file__).resolve(),1048576,work_end))==plan['runner'],'exact current runner Source')
        for key,cap in [('observer',1048576),('cold',16777216),('worker_plan',16777216),('integration_declaration',1048576),('runtime_closure',1048576)]:read_pinned(plan[key],cap,work_end)
        runtime_guard,runtime_evidence=python_custody(plan['python'],work_end)
        for label in ('stdout','stderr'):fds[label]=os.open(str(actual/(label+'.bin')),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        argv=[plan['python']['path'],'-I','-S','-B',plan['cold']['path'],plan['worker_plan']['path'],str(began),str(work_end),str(overall_end)]
        launch_attempts=1
        process=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            cwd=str(actual),env=dict(plan['environment']),close_fds=True,start_new_session=True,bufsize=0)
        pid=process.pid;pgid=pid
        try:need(os.getpgid(pid)==pgid,'Python owns exact isolated process group')
        except ProcessLookupError:pass
        selector=selectors.DefaultSelector()
        for label in ('stdout','stderr'):
            stream=getattr(process,label);streams[label]=stream;os.set_blocking(stream.fileno(),False);selector.register(stream,selectors.EVENT_READ,label)
        while True:
            runtime_guard()
            if _NOW()>=overall_end:
                signal_group(signal.SIGKILL);raise OnceRunnerError('original210 overall deadline; no admitted output')
            reap()
            if reaped:
                probe_group()
                if group_absent is True and not selector.get_map():drain_closed_ns=_NOW();break
            timeout=min(LIMITS['poll_milliseconds']/1000,max(0,(overall_end-_NOW())/1e9))
            for key,mask in selector.select(timeout):drain(key)
        need(worker_exit==0 and reaped,'normal exact Python exit0')
        need(capture_complete and all(eof.values()),'both bounded logs fully drained to EOF')
        need(group_absent is True and _NOW()<overall_end,'authoritative postreap group absence and pipe closure before210')
        receipt_path=actual/'worker-receipt.json';result_path=actual/'result.json'
        receipt_raw=read_raw(receipt_path,LIMITS['worker_receipt_bytes'],overall_end);worker_receipt=parse(receipt_raw);pins['worker_receipt']=pin_raw(receipt_path,receipt_raw)
        need(worker_receipt['schema']==WORKER_RECEIPT_SCHEMA and all(worker_receipt[k]==plan[k] for k in
             ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','receiver_id','integration_declaration')),'whole current worker receipt/storage subject')
        need(worker_receipt['worker_plan']==plan['worker_plan'] and worker_receipt['cold']==plan['cold'] and worker_receipt['python']==plan['python'] and
             worker_receipt['began_ns']==began and worker_receipt['work_deadline_ns']==work_end and worker_receipt['overall_deadline_ns']==overall_end,
             'whole worker raw plan/runtime/original endpoint joins')
        need(type(worker_receipt['status'])is str and all(type(worker_receipt[k])is bool for k in ['work_completed','logical_proof_accepted','primary_family_hint_accepted']),'literal worker status flags')
        need(worker_receipt['result_reading']['reader']==plan['result_reader'] and worker_receipt['result_reading']['roundtrip']['literal_bytes_equal'] is True,'complete current shared-reader inverse receipt')
        selected=worker_receipt['selected_family_model'];expected_alias={'ordinary':'quantified_family_points_v2','literal_interned':'interned_quantified_family_points_v1'}[plan['model_storage']]
        need(selected['module']==expected_alias and selected['original']==worker['project_sources'][expected_alias],'whole selected storage alias preimage')
        result_raw=read_raw(result_path,LIMITS['result_bytes'],overall_end);pins['result']=pin_raw(result_path,result_raw)
        need(pins['result']==worker_receipt['result'],'whole result EOF/size/hash join')
        result=parse(result_raw)
        need(type(result)is dict and result['source_epoch']['model_storage']==plan['model_storage'] and result['module_pins']['family_model']==selected['owned'] and
             result['search_ordering']==plan['search_ordering'] and result['source_epoch']['search_ordering']==plan['search_ordering'] and
             result['inventory_certification_mode']==plan['inventory_certification_mode'] and
             result['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode'],'complete result/storage selected Source join; no mathematics interpreted')
        shadow_meta=worker_receipt['schema_shadow']
        shadow_path=actual/'schema-shadow-result.json'
        shadow_raw=read_raw(shadow_path,LIMITS['result_bytes'],overall_end)
        pins['schema_shadow']=pin_raw(shadow_path,shadow_raw);shadow=parse(shadow_raw)
        need(pins['schema_shadow']==shadow_meta['output'] and len(result_raw)+len(shadow_raw)==shadow_meta['combined_result_bytes']<=LIMITS['result_bytes'],
             'whole two-file output custody and unchanged combined128MiB cap')
        need(shadow_meta['original_result_unchanged']is True and
             shadow_meta['post_shadow_literal']==worker_receipt['result_reading']['roundtrip'] and
             shadow_meta['sources']['original']==SHADOW_SOURCES and
             all(shadow_meta['sources'][k]==result['source_epoch']['shadow_sources'][k]for k in ('original','owned')) and
             shadow_meta['kernel_source']==result['source_epoch']['shadow_sources']['kernel_source'],
             'whole current shadow Source maps and unchanged base literal inverse')
        need(shadow['mode']==shadow_meta['mode']=='SHADOW_NO_ADMISSION_CHANGE' and
             shadow['status']==shadow_meta['status'] and shadow['status']in
             ('SHADOW_QUALIFICATION_PASSED','SHADOW_QUALIFICATION_FAILED','SHADOW_QUALIFICATION_UNKNOWN') and
             shadow['original_inventory_status']==result['outputs'].get('register',{}).get('status','NOT_REACHED') and
             shadow['fresh_Native_bulk_record_id']==result['outputs'].get('register',{}).get('query') and
             shadow['native_accepted_by_schema']is False and shadow['Model_permission']is False and shadow['new_target_proof']is False and
             shadow_meta['completed_ns']<overall_end,
             'separate shadow qualification without Native/Model authority; unknown closure before210')
        if shadow['status']=='SHADOW_QUALIFICATION_PASSED':
            need(shadow_meta['completed_ns']<work_end and terminal_ns<work_end,'positive shadow and known worker exit before180')
        search_role='family_search' if plan['mode']=='fixed' else 'symbolic_control'
        search_alias='semantic_inventory_search_v2' if plan['mode']=='fixed' else 'quantified_symbolic_control_v2'
        search_subject=worker_receipt['selected_search_module'];support_subject=worker_receipt['support_ordering_module']
        need(search_subject['role']==search_role and search_subject['module']==search_alias and
             search_subject['original']==worker['project_sources'][search_alias] and
             search_subject['owned']==result['module_pins'][search_role] and
             support_subject['module']=='receptor_support_ordering_v1' and
             support_subject['original']==worker['project_sources']['receptor_support_ordering_v1'] and
             support_subject['owned']==result['module_pins']['support_ordering'],
             'current method/helper original and owned Source preimage joins')
        native=worker_receipt['native_transport']
        need(type(native)is dict and native['schema']=='semantic-family-native-transport-receipt-v1' and native['version']=='semantic-family-bounded-request-oracle-transport-v1','exact native transport receipt')
        need(native['parent_pid']==pid and native['parent_pgid']==pgid and native['native_pgid']==pgid and type(native['native_pid'])is int and native['native_pid']>0 and native['native_pid']!=pid,'exact parent/native ownership')
        need(native['constructor_completed'] is True and native['closed'] is True and native['all_reaped'] is True and native['same_owned_process_group'] is True and type(native['native_exit_code'])is int and native['native_exit_code']==0 and type(native['wait4_status'])is int and native['wait4_status']==0,'exact native successful wait4 reaping')
        need(native['stderr_complete'] is True and native['stdout_eof'] is True and native['stdout_pending_bytes']==0,'native streams closed at reaping')
        need(native['wait4_usage']['ru_maxrss']==native['native_high_water_bytes'] and type(native['native_high_water_bytes'])is int and native['native_high_water_bytes']>=0,'separate native highwater bytes')
        need(abs(native['work_deadline']-work_end/1e9)<.000001 and native['closure_deadline']<=overall_end/1e9+.000001,'original native endpoints')
        aggregate=wait_usage['ru_maxrss']+native['native_high_water_bytes']
        need(aggregate<=LIMITS['aggregate_peak_bytes'],'conservative separate Python+CPP highwater sum within1GiB')
        need(probe_group() is True,'final authoritative postreap group absence')
        has_proof=worker_receipt['logical_proof_accepted'] or worker_receipt['primary_family_hint_accepted']
        need(not worker_receipt['primary_family_hint_accepted'] or worker_receipt['logical_proof_accepted'],'hint success bounded by whole native proof')
        if has_proof:
            need(worker_receipt['work_completed'] is True and terminal_ns<work_end,'positive output+known worker exit strictly before original180')
            need(worker_receipt['final_region_verification']['status']=='VERIFIED_WHOLE_FINITE_POINT_REGION','fresh whole point-region receipt')
            proof_transport_candidate=True
        elif not worker_receipt['work_completed']:
            need(worker_receipt['logical_proof_accepted'] is False and worker_receipt['primary_family_hint_accepted'] is False,'after-work UNKNOWN has no proof flags')
        runtime_guard()
        for key,cap in [('runner',1048576),('observer',1048576),('python',67108864),('cold',16777216),('worker_plan',16777216),('integration_declaration',1048576),('runtime_closure',1048576)]:read_pinned(plan[key],cap,overall_end)
        runtime_guard();need(_NOW()<overall_end,'all complete terminal/custody/resource checks before210')
        resource_candidate=True
    except BaseException as error:
        errors.append({'type':type(error).__name__,'message':str(error)[:4096],'stamp_ns':_NOW()})
        resource_candidate=False;proof_transport_candidate=False
        if pid is not None and not group_absence_latched:
            try:signal_group(signal.SIGTERM)
            except BaseException as cleanup_error:errors.append({'type':type(cleanup_error).__name__,'message':str(cleanup_error)[:1024]})
        try:wait_cleanup()
        except BaseException as cleanup_error:errors.append({'type':type(cleanup_error).__name__,'message':str(cleanup_error)[:1024]})
    finally:
        capture_complete=capture_complete and all(eof.values())
        if selector is not None:selector.close()
        for stream in streams.values():stream.close()
        for fd in fds.values():os.close(fd)
    for label in ('stdout','stderr'):
        log=actual/(label+'.bin')
        if log.exists():
            try:
                raw=read_raw(log,LIMITS[label+'_bytes'],overall_end if resource_candidate else None);pins[label]=pin_raw(log,raw)
            except BaseException as error:
                resource_candidate=False;proof_transport_candidate=False;capture_complete=False
                errors.append({'type':type(error).__name__,'message':str(error)[:4096],'stamp_ns':_NOW()})
    if resource_candidate:
        try:
            runtime_guard();need(probe_group() is True and all(eof.values()) and _NOW()<overall_end,'final postlog group/EOF/runtime closure')
        except BaseException as error:
            resource_candidate=False;proof_transport_candidate=False
            errors.append({'type':type(error).__name__,'message':str(error)[:4096],'stamp_ns':_NOW()})
    closed_ns=_NOW()
    if closed_ns>=overall_end:resource_candidate=False;proof_transport_candidate=False
    native=worker_receipt.get('native_transport') if type(worker_receipt)is dict else None
    aggregate=(wait_usage['ru_maxrss']+native['native_high_water_bytes'] if wait_usage is not None and type(native)is dict and type(native.get('native_high_water_bytes'))is int else None)
    receipt={'schema':RECEIPT_SCHEMA,'version':VERSION,'invocation_id':plan['invocation_id'],'mode':plan['mode'],'search_ordering':plan['search_ordering'],
        'inventory_certification_mode':plan['inventory_certification_mode'],
        'model_storage':plan['model_storage'],'result_reader':plan['result_reader'],'receiver_id':plan['receiver_id'],
        'plan':pin_raw(path,plan_raw),'subject_sha256':auth['subject_sha256'],'authorization':plan['authorization'],'review_roles':review_roles,
        'integration_declaration':plan['integration_declaration'],'runtime_closure':plan['runtime_closure'],
        'consumed_marker':marker_pin,'consumed_once':True,'worker_launch_attempts':launch_attempts,'worker_pid_observed':pid is not None,
        'CLOCK_DOMAIN':'time.monotonic_ns on same declared Darwin host','began_ns':began,'work_deadline_ns':work_end,'overall_deadline_ns':overall_end,
        'worker_terminal_observed_ns':terminal_ns,'checks_closed_ns':closed_ns,'python_pid':pid,'owned_pgid':pgid,
        'python_reaped':reaped,'python_exit_code':worker_exit,'python_wait4_status':wait_status,'python_wait4_usage':wait_usage,
        'native_transport':native,'owned_group_absent':group_absent,'owned_group_probe_count':group_probe_count,
        'owned_group_last_probe_ns':group_last_probe_ns,'owned_group_first_absent_ns':group_absence_observed_ns,
        'owned_group_reappearance_observed_ns':group_reappearance_observed_ns,
        'postreap_group_and_pipe_closed_ns':drain_closed_ns,'stdout_eof':eof['stdout'],'stderr_eof':eof['stderr'],
        'conservative_parent_plus_native_peak_bytes':aggregate,'perprocess_peaks_may_doublecount_conservatively':True,'live_group_memory_limit_claimed':False,
        'observer_scope':'Outer/observer memory excluded from worker+CPP sum; parent Source-entry walltime charged, interpreter prelude separately observed.',
        'python_custody':runtime_evidence,'python_custody_scope':'Outer-only baseline/stat polling/final whole bytes, no injected worker callback guard or formal continuous seal.',
        'stdout_bytes':stdout_count,'stderr_bytes':stderr_count,'log_capture_complete':capture_complete,'signals':signals,'errors':errors,
        'outputs':pins,'worker_receipt':worker_receipt,'resource_candidate_accepted':resource_candidate,'logical_proof_transport_candidate':proof_transport_candidate,
        'ROOT_resource_accepted':False,'mathematical_proof_accepted':False,'scientific_acceptance':False,
        'success_requires_runner_exit0_and_external_terminal_within210':True,'failed_cleanup_after210_is_never_admitted':True,'limits':dict(LIMITS)}
    final_pin=write_new(actual/'runner-receipt.json',canonical(receipt)+b'\n');postwrite=_NOW()
    if postwrite>=overall_end:
        write_new(actual/'POST_RECEIPT_DEADLINE_FAILURE.json',canonical({'schema':'semantic-family-final-deadline-failure-v1','stamp_ns':postwrite,'overall_deadline_ns':overall_end,'runner_receipt':final_pin,'resource_accepted':False})+b'\n')
        return {'runner_receipt':final_pin,'exit_code':2,'completion_within_overall':False}
    return {'runner_receipt':final_pin,'exit_code':0 if resource_candidate else 2,'completion_within_overall':True}


if __name__=='__main__':
    need(len(sys.argv)==2,'exact once-plan argument')
    outcome=run_once(runner_plan_path=sys.argv[1])
    sys.stdout.buffer.write(canonical(outcome)+b'\n');sys.stdout.buffer.flush()
    raise SystemExit(outcome['exit_code'])
