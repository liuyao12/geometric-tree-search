"""Raw repair for retained normal callback-fixture returns; no evaluation."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).parent;s=(D/'mp_schema_shadow_qualification_v2.py').read_text()
def sub(a,b,n=1):
 global s
 assert s.count(a)==n,(a,s.count(a));s=s.replace(a,b)
sub("VERSION='mp-schema-shadow-qualification-v2'","VERSION='mp-schema-shadow-qualification-v3'")
sub('            caught=None\n            try:', '            caught=None;callback_return=None\n            try:')
sub('                    schema_module.check_ground_instance(certificate=', '                    callback_return=schema_module.check_ground_instance(certificate=')
sub('else:certify_args=dict(family=_owned(mp),certified_dependencies=[],**dict(common,**{callback:fail}));schema_module.certify_family(**certify_args)', 'else:certify_args=dict(family=_owned(mp),certified_dependencies=[],**dict(common,**{callback:fail}));callback_return=schema_module.certify_family(**certify_args)')
sub("            good=caught is exact;fixtures.append", "            if caught is None:\n                if type(callback_return)is dict and 'status'in callback_return:\n                    observe('normal_return_before_exact_'+name,callback_return,['EXACT_CALLBACK_EXCEPTION'])\n                else:\n                    fixtures.append(dict(name='invalid_return_before_exact_'+name,passed=False,returned_packet=callback_return))\n                    failures.append('exact_'+name+'_callback_protocol')\n                    raise _PrefixStop(prefix_owner,'SHADOW_QUALIFICATION_FAILED','invalid_callback_fixture_return')\n            good=caught is exact;fixtures.append")
p=D/'mp_schema_shadow_qualification_v3.py';assert not p.exists();p.write_text(s);compile(ast.parse(s),str(p),'exec',dont_inherit=True);b=p.read_bytes()
print(json.dumps(dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),source_only=True,scientific_calls=0)))
t=(D/'build_intake_Source_v2.py').read_text()
for a,b in [('mp_schema_shadow_qualification_v2.py','mp_schema_shadow_qualification_v3.py'),('mp-schema-shadow-qualification-v2','mp-schema-shadow-qualification-v3'),('mp-schema-shadow-intake-cold-v2','mp-schema-shadow-intake-cold-v3'),('mp_schema_shadow_cold_v2.py','mp_schema_shadow_cold_v3.py'),('mp-schema-shadow-external-once-runner-v2','mp-schema-shadow-external-once-runner-v3'),('mp_schema_shadow_once_runner_v2.py','mp_schema_shadow_once_runner_v3.py'),('mp-schema-shadow-final-terminal-observer-v2','mp-schema-shadow-final-terminal-observer-v3'),('observe_mp_schema_shadow_runner_v2.py','observe_mp_schema_shadow_runner_v3.py'),("D/'Source-contract-v2.json'","D/'Source-contract-v3.json'")]:
 assert t.count(a)==1,(a,t.count(a));t=t.replace(a,b)
p=D/'build_intake_Source_v3.py';assert not p.exists();p.write_text(t)
