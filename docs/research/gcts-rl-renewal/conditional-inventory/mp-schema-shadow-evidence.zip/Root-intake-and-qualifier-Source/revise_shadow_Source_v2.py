"""Raw Source repair only; preserve unexecuted V1 and its negative review."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).parent;s=(D/'mp_schema_shadow_qualification_v1.py').read_text()
def sub(a,b,n=1):
 global s
 assert s.count(a)==n,(a,s.count(a));s=s.replace(a,b)
sub("VERSION='mp-schema-shadow-qualification-v1'","VERSION='mp-schema-shadow-qualification-v2'")
sub('class _OwnStop(Exception):pass','class _OwnStop(Exception):pass\nclass _PrefixStop(Exception):\n    def __init__(self,owner,status,stage):self.owner,self.status,self.stage=owner,status,stage')
sub('families=[];ground=[];fixtures=[];failures=[];certificates={};total_checks=0;own_stop=_OwnStop()',
    'families=[];ground=[];fixtures=[];inline=[];component_returns=[];failures=[];certificates={};total_checks=0;own_stop=_OwnStop();prefix_owner=object();prefix_stop=None')
sub('    def observe(name,r,expected):','''    def require(name,r,expected):
        component_returns.append(dict(stage=name,expected_statuses=list(expected),result=r))
        if r['status']=='UNKNOWN' and 'UNKNOWN'not in expected:
            raise _PrefixStop(prefix_owner,'SHADOW_QUALIFICATION_UNKNOWN',name)
        if r['status']not in expected:
            failures.append(name)
            raise _PrefixStop(prefix_owner,'SHADOW_QUALIFICATION_FAILED',name)
    def observe(name,r,expected):''')
sub("        if not good:failures.append(name)\n        return good", "        require(name,r,expected)\n        return good")
sub("            if r['status']!=expected:failures.append('original_family_fragment_disposition:'+f['id'])", "            require('original_family_fragment_disposition:'+f['id'],r,[expected])")
sub("                rebuilt=rv(r['certificate'])\n                if rebuilt['status']!='ELIGIBLE_CERTIFICATE'or rebuilt['certificate']!=r['certificate']:failures.append('family_full_revalidation:'+f['id'])", """                rebuilt=rv(r['certificate']);families[-1]['revalidation']=rebuilt
                require('family_full_revalidation:'+f['id'],rebuilt,['ELIGIBLE_CERTIFICATE'])
                if rebuilt['certificate']!=r['certificate']:
                    failures.append('family_full_revalidation_literal:'+f['id'])
                    raise _PrefixStop(prefix_owner,'SHADOW_QUALIFICATION_FAILED','family_full_revalidation_literal')""")
sub("            if r['status']=='GROUND_CORRESPONDENCE':", "            ground.append(entry);require('ground_correspondence:'+row['name'],r,['GROUND_CORRESPONDENCE'])\n            if r['status']=='GROUND_CORRESPONDENCE':")
sub('            ground.append(entry)\n        # Three generic', '        # Three generic')
sub("        rp=certify(repeated);ip=certify(identity)\n        if rp['status']!='ELIGIBLE_CERTIFICATE'or ip['status']!='ELIGIBLE_CERTIFICATE':raise ShadowDataError('generic child certificate failed')", "        rp=certify(repeated);require('generic_repeated_child_certificate',rp,['ELIGIBLE_CERTIFICATE'])\n        ip=certify(identity);require('generic_identity_child_certificate',ip,['ELIGIBLE_CERTIFICATE'])")
sub('        inline=[]\n        for name,parent', '        for name,parent')
sub("            r=certify(parent,[cc]);row,registry=_fixture_registry(parent,[child,parent],args,tick)\n            if r['status']!='ELIGIBLE_CERTIFICATE':raise ShadowDataError('generic parent certificate failed')", "            r=certify(parent,[cc]);require('generic_parent_certificate:'+name,r,['ELIGIBLE_CERTIFICATE'])\n            row,registry=_fixture_registry(parent,[child,parent],args,tick)")
sub("            g=gi(r['certificate'],args,row,registry);good=g['status']=='GROUND_CORRESPONDENCE'", "            g=gi(r['certificate'],args,row,registry);require('generic_ground:'+name,g,['GROUND_CORRESPONDENCE']);good=g['status']=='GROUND_CORRESPONDENCE'")
sub("                if name=='last_alias_after_unrelated':", "                if name=='ordered_repeated_ports':\n                    children=[frame for frame in p['frames']if frame['name']!=row['name']]\n                    good=len(children)==1 and children[0]['input_sources']==[0,0]\n                if name=='last_alias_after_unrelated':")
sub("        fresh=certify(_owned(mp))\n        returned=fresh['certificate'];", "        fresh=certify(_owned(mp));require('fresh_before_direct_returned_mutation',fresh,['ELIGIBLE_CERTIFICATE'])\n        returned=fresh['certificate'];")
sub("    except _OwnStop as e:", "    except _PrefixStop as e:\n        if e.owner is not prefix_owner:raise\n        status=e.status;prefix_stop=dict(stage=e.stage,status=e.status)\n    except _OwnStop as e:")
sub("        inline=locals().get('inline',[])", "        prefix_stop=dict(stage='wrapper_private_check_quota',status=status)")
sub("        every_original_ground_definition=ground,generic_inline_cases=inline,fixtures=fixtures,failures=failures,", "        every_original_ground_definition=ground,generic_inline_cases=inline,fixtures=fixtures,failures=failures,\n        all_returned_component_packets=component_returns,prefix_stop=prefix_stop,\n        coverage=dict(families_returned=len(families),ground_packets_returned=len(ground),generic_inline_completed=len(inline),fixtures_returned=len(fixtures)),")
p=D/'mp_schema_shadow_qualification_v2.py';assert not p.exists();p.write_text(s)
t=ast.parse(s);compile(t,str(p),'exec',dont_inherit=True);b=p.read_bytes()
print(json.dumps(dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),source_only=True,scientific_calls=0)))
