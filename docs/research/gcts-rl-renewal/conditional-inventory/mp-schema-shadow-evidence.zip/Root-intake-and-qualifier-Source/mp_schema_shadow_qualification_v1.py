"""Prospective SHADOW qualification; no imports of scientific modules.

The caller supplies fresh full Native-admitted inventory/records, unchanged
library, captured schema module, charged callbacks and syntax-only validator.
This never changes the production registry, Model, proof or Native authority.
Generic fixtures are plumbing tests, never receiver routes or Native proofs.
"""
import hashlib
import json

VERSION='mp-schema-shadow-qualification-v1'
SCHEMA='mp-schema-shadow-qualification-result-v1'
EXPECTED_MODULE_VERSION='mp-schema-certificates-v1'
MAX_CHECKS=2000000
NEGATIVE_NAMES=('bool_meta','out_of_range_meta','forward_MP','changed_MP_implication',
 'changed_ordered_ground_premise','missing_dependency','cyclic_certificate','changed_ground_identity')

class ShadowDataError(ValueError):pass
class _OwnStop(Exception):pass

def _bytes(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def _owned(v):return json.loads(_bytes(v))
def _digest(v):return hashlib.sha256(_bytes(v)).hexdigest()

def _primitive(packet,validator,check):
    """Separate direct assumption/MP row check, not the new module's helper."""
    premises=packet['premises'];proof=packet['proof'];formulas=[]
    if type(premises)is not list or type(proof)is not list or not proof:raise ShadowDataError('full nonempty primitive packet')
    def index(i,n):
        if type(i)is not int or not 0<=i<n:raise ShadowDataError('strict primitive prior/premise')
        return i
    for f in premises:
        check()
        if validator(f)is not True:raise ShadowDataError('primitive premise syntax')
    for position,c in enumerate(proof):
        check();f=c['formula']
        if validator(f)is not True:raise ShadowDataError('primitive row syntax')
        if c['rule']=='assumption':
            if set(c)!={'rule','formula','index'}or f!=premises[index(c['index'],len(premises))]:raise ShadowDataError('primitive exact assumption')
        elif c['rule']=='mp':
            if set(c)!={'rule','formula','antecedent','implication'}:raise ShadowDataError('primitive exact MP fields')
            a=index(c['antecedent'],position);b=index(c['implication'],position)
            if formulas[b]!=['imp',formulas[a],f]:raise ShadowDataError('primitive MP formula equality')
        else:raise ShadowDataError('primitive unsupported rule')
        formulas.append(f)
    if formulas[-1]!=packet['conclusion']:raise ShadowDataError('primitive last target')
    return dict(rows=len(proof),last_formula=formulas[-1],checked_from_entire_ordered_interface=True)

def _family(parameters,premises,conclusion,proof,dependencies=()):
    template=dict(premises=premises,conclusion=conclusion,proof=proof)
    return dict(id=_digest(dict(parameters=parameters,template=template)),parameters=parameters,
        template=template,dependencies=sorted(dependencies),donor_atoms=['fixture'+str(i)for i in range(parameters)],
        provenance=dict(kind='GENERIC_SHADOW_PLUMBING_NOT_RECEIVER_ROUTE'),scope='Generic qualification fixture only; no Native authority.')

def _fixture_registry(root,library,arguments,check):
    """Independent tiny fixture authoring, never receiver specialization."""
    by_id={f['id']:f for f in library};rows=[];known={};active=set()
    def replace(v,args):
        check()
        if type(v)is list:
            if len(v)==2 and v[0]=='meta':return _owned(args[v[1]])
            return [replace(x,args)for x in v]
        if type(v)is dict:return {k:replace(x,args)for k,x in v.items()}
        return v
    def build(fid,args):
        check();f=by_id[fid];name='lemma'+_digest(dict(family=fid,arguments=args))
        if name in known:return name
        if name in active:raise ShadowDataError('fixture dependency cycle')
        active.add(name);g=replace(f['template'],args);body=[];level=1
        for c in g['proof']:
            c=dict(c)
            if c['rule']=='block':
                call=c.pop('call');dep=build(call['family'],call['arguments']);c['name']=dep;level=max(level,known[dep]['level']+1)
            body.append(c)
        row=dict(name=name,family=fid,arguments=_owned(args),level=level,
            definition=dict(name=name,premises=g['premises'],conclusion=g['conclusion'],proof=body))
        active.remove(name);known[name]=row;rows.append(row);return name
    name=build(root['id'],arguments);return known[name],rows

def run_shadow(*,schema_module,library,inventory,records,theory,source_epoch,semantic_epoch,source_guard,formula_validator,check):
    if schema_module.VERSION!=EXPECTED_MODULE_VERSION:raise ShadowDataError('exact schema module')
    if not all(callable(f)for f in (source_guard,formula_validator,check)):raise ShadowDataError('required charged callbacks')
    check();source_guard();supplied=dict(library=library,inventory=inventory,records=records,theory=theory,source_epoch=source_epoch,semantic_epoch=semantic_epoch);before=_bytes(supplied);inputs=_owned(supplied)
    if len(library)!=4 or inventory['status']!='native_accepted':raise ShadowDataError('unchanged four-family/current Native inventory')
    definitions=inventory['definitions'];names=[r['name']for r in definitions]
    if len(names)!=len(set(names))or inventory['native_blocks']!=[r['definition']for r in definitions]:raise ShadowDataError('whole ordered original registry')
    # Full actual bulk admission packet. This is retained execution evidence,
    # not a caller's success flag or a new mathematical checker.
    qid=inventory['query'];q=records[qid];taut=['imp',['bot'],['bot']]
    wanted=dict(protocol='gcts-fol-1',theory=theory,blocks=inventory['native_blocks'],proof=[dict(rule='tautology',formula=taut)],target=taut)
    if q['id']!=qid or q['request']!=wanted or q['request_sha256']!=_digest(wanted)or q['result']['status']!='accepted':raise ShadowDataError('full fresh bulk Native join')
    families=[];ground=[];fixtures=[];failures=[];certificates={};total_checks=0;own_stop=_OwnStop()
    def tick():
        nonlocal total_checks
        check()
        if total_checks>=MAX_CHECKS:raise own_stop
        total_checks+=1
    common=dict(source_epoch=_owned(source_epoch),semantic_epoch=_owned(semantic_epoch),source_guard=source_guard,check=tick)
    def observe(name,r,expected):
        good=r['status']in expected
        fixtures.append(dict(name=name,expected_statuses=list(expected),passed=good,result=r))
        if not good:failures.append(name)
        return good
    def certify(f,deps=()):return schema_module.certify_family(family=f,certified_dependencies=list(deps),**common)
    def rv(c,**kw):return schema_module.revalidate_certificate(certificate=c,**dict(common,**kw))
    def gi(c,args,row,registry,**kw):return schema_module.check_ground_instance(certificate=c,arguments=args,ground_definition=row,
        dependency_definitions=registry,formula_validator=formula_validator,**dict(common,**kw))
    def rehash(f):f['id']=_digest(dict(parameters=f['parameters'],template=f['template']));return f
    try:
        for f in library:
            tick();deps=[certificates[d]for d in sorted(f['dependencies'])if d in certificates]
            r=certify(_owned(f),deps);families.append(dict(family_id=f['id'],result=r))
            expected='ELIGIBLE_CERTIFICATE'if all(c['rule']in ('assumption','mp','block')for c in f['template']['proof'])else'NOT_ELIGIBLE'
            if r['status']!=expected:failures.append('original_family_fragment_disposition:'+f['id'])
            if r['status']=='ELIGIBLE_CERTIFICATE':
                certificates[f['id']]=r['certificate']
                rebuilt=rv(r['certificate'])
                if rebuilt['status']!='ELIGIBLE_CERTIFICATE'or rebuilt['certificate']!=r['certificate']:failures.append('family_full_revalidation:'+f['id'])
            elif r['status']!='NOT_ELIGIBLE':failures.append('family_classification:'+f['id'])
        for row in definitions:
            tick();fid=row['family']
            if fid not in certificates:
                ground.append(dict(name=row['name'],status='RETAINS_ORDINARY_NATIVE_ONLY',definition=_owned(row)))
                continue
            r=gi(certificates[fid],_owned(row['arguments']),_owned(row),_owned(definitions));entry=dict(name=row['name'],result=r)
            if r['status']=='GROUND_CORRESPONDENCE':
                p=r['ground_correspondence']['primitive_expansion'];entry['independent_primitive_check']=_primitive(p,formula_validator,tick)
                entry['literal_primitive_body_equals_fresh_Native_block']=(p['premises']==row['definition']['premises']and p['conclusion']==row['definition']['conclusion']and p['proof']==row['definition']['proof'])
                if all(c['rule']!='block'for c in row['definition']['proof'])and not entry['literal_primitive_body_equals_fresh_Native_block']:failures.append('literal_primitive_correspondence:'+row['name'])
            else:failures.append('ground_correspondence:'+row['name'])
            ground.append(entry)
        # Three generic inlining edges, disconnected from receiver search.
        m=lambda i:['meta',i]
        identity=_family(1,[m(0)],m(0),[dict(rule='assumption',formula=m(0),index=0)])
        repeated=_family(1,[m(0),m(0)],m(0),[dict(rule='assumption',formula=m(0),index=1)])
        rp=certify(repeated);ip=certify(identity)
        if rp['status']!='ELIGIBLE_CERTIFICATE'or ip['status']!='ELIGIBLE_CERTIFICATE':raise ShadowDataError('generic child certificate failed')
        p0=_family(1,[m(0)],m(0),[dict(rule='assumption',formula=m(0),index=0),dict(rule='block',formula=m(0),call=dict(family=repeated['id'],arguments=[m(0)]),inputs=[0,0])],[repeated['id']])
        pref=[dict(rule='assumption',formula=['imp',m(0),m(1)],index=0),dict(rule='assumption',formula=m(0),index=1),dict(rule='mp',formula=m(1),antecedent=1,implication=0)]
        p1=_family(2,[['imp',m(0),m(1)],m(0)],m(1),pref+[dict(rule='block',formula=m(1),call=dict(family=identity['id'],arguments=[m(1)]),inputs=[2])],[identity['id']])
        p2=_family(3,[['imp',m(0),m(1)],m(0),m(2)],m(1),pref+[dict(rule='assumption',formula=m(2),index=2),dict(rule='block',formula=m(1),call=dict(family=identity['id'],arguments=[m(1)]),inputs=[2])],[identity['id']])
        A=['bot'];B=['imp',['bot'],['bot']];C=['imp',B,['bot']]
        inline=[]
        for name,parent,child,cc,args in [('ordered_repeated_ports',p0,repeated,rp['certificate'],[A]),('derived_child_assumption',p1,identity,ip['certificate'],[A,B]),('last_alias_after_unrelated',p2,identity,ip['certificate'],[A,B,C])]:
            r=certify(parent,[cc]);row,registry=_fixture_registry(parent,[child,parent],args,tick)
            if r['status']!='ELIGIBLE_CERTIFICATE':raise ShadowDataError('generic parent certificate failed')
            g=gi(r['certificate'],args,row,registry);good=g['status']=='GROUND_CORRESPONDENCE'
            if good:
                p=g['ground_correspondence']['primitive_expansion'];_primitive(p,formula_validator,tick)
                if name=='last_alias_after_unrelated':good=p['tail_reification']is not None and p['result_row']==len(p['proof'])-1
                if name=='derived_child_assumption':good=all(c['rule']!='assumption'or c['formula']!=B for c in p['proof'])
            observe(name,g,['GROUND_CORRESPONDENCE'])
            if not good:failures.append(name+':inline_mapping')
            inline.append(dict(name=name,family=parent,certificate_result=r,ground_root=row,full_registry=registry,correspondence=g))
        # Fixed malformed matrix. Identity hashes are recomputed for changes
        # intended to reach rule checks rather than failing only a stale hash.
        mp=next(f for f in library if not f['dependencies']and any(c['rule']=='mp'for c in f['template']['proof']))
        for name,mutation in [('bool_meta',lambda f:f['template']['conclusion'].__setitem__(1,True)),('out_of_range_meta',lambda f:f['template']['conclusion'].__setitem__(1,f['parameters'])),('forward_MP',lambda f:next(c for c in f['template']['proof']if c['rule']=='mp').__setitem__('antecedent',len(f['template']['proof']))),('changed_MP_implication',lambda f:next(c for c in f['template']['proof']if c['rule']=='mp').__setitem__('implication',next(c for c in f['template']['proof']if c['rule']=='mp')['antecedent']))]:
            f=_owned(mp);mutation(f);observe(name,certify(rehash(f)),['REJECTED'])
        chosen=next(row for row in definitions if row['family']in certificates and len(row['definition']['premises'])>=2 and row['definition']['premises'][0]!=row['definition']['premises'][1])
        altered=_owned(chosen);altered['definition']['premises'][0],altered['definition']['premises'][1]=altered['definition']['premises'][1],altered['definition']['premises'][0]
        registry=[altered if r['name']==chosen['name']else _owned(r)for r in definitions]
        observe('changed_ordered_ground_premise',gi(certificates[chosen['family']],chosen['arguments'],altered,registry),['REJECTED'])
        dep=next(f for f in library if f['dependencies']and f['id']in certificates)
        observe('missing_dependency',certify(_owned(dep),[]),['NOT_ELIGIBLE'])
        cyclic=_owned(certificates[dep['id']]);cyclic['dependency_certificates'].append(cyclic)
        observe('cyclic_certificate',rv(cyclic),['REJECTED'])
        altered=_owned(chosen);altered['arguments'][0]=['imp',altered['arguments'][0],['bot']]
        altered['name']='lemma'+_digest(dict(family=altered['family'],arguments=altered['arguments']));altered['definition']['name']=altered['name']
        registry=[altered if r['name']==chosen['name']else _owned(r)for r in definitions]
        observe('changed_ground_identity',gi(certificates[chosen['family']],altered['arguments'],altered,registry),['REJECTED'])
        # Complete epochs and actual returned-packet ownership, not hash flags.
        c=certificates[mp['id']];changed=_owned(source_epoch);changed['fixture_epoch_change']=True
        observe('changed_Source_epoch',rv(c,source_epoch=changed),['REJECTED'])
        changed=_owned(semantic_epoch);changed['fixture_epoch_change']=True
        observe('changed_semantic_epoch',rv(c,semantic_epoch=changed),['REJECTED'])
        fresh=certify(_owned(mp))
        returned=fresh['certificate'];returned['derived_rows'][0]['formula']=['meta',mp['parameters']]
        observe('direct_returned_packet_mutation',rv(returned),['REJECTED'])
        restored=certify(_owned(mp));observe('fresh_after_mutation',restored,['ELIGIBLE_CERTIFICATE'])
        # Only exact sentinel errors are caught by this test harness.
        for name,callback in [('source_guard','source_guard'),('check','check'),('formula_validator','formula_validator')]:
            exact=ValueError('shadow exact '+name+' sentinel')
            def fail():raise exact
            def fail_formula(formula):raise exact
            caught=None
            try:
                if callback=='formula_validator':
                    schema_module.check_ground_instance(certificate=certificates[chosen['family']],arguments=_owned(chosen['arguments']),ground_definition=_owned(chosen),dependency_definitions=_owned(definitions),formula_validator=fail_formula,**common)
                else:certify_args=dict(family=_owned(mp),certified_dependencies=[],**dict(common,**{callback:fail}));schema_module.certify_family(**certify_args)
            except BaseException as e:
                if e is not exact:raise
                caught=e
            good=caught is exact;fixtures.append(dict(name='exact_'+name+'_error',passed=good,exact_exception_object_propagated=good))
            if not good:failures.append('exact_'+name+'_error')
        observe('private_work_budget',schema_module.certify_family(family=_owned(mp),certified_dependencies=[],limits=dict(work=1),**common),['UNKNOWN'])
        if _bytes(supplied)!=before:raise ShadowDataError('qualification full supplied inputs changed')
        tick();source_guard()
        status='SHADOW_QUALIFICATION_PASSED'if not failures else'SHADOW_QUALIFICATION_FAILED'
    except _OwnStop as e:
        if e is not own_stop:raise
        status='SHADOW_QUALIFICATION_UNKNOWN'
        inline=locals().get('inline',[])
    check();source_guard()
    if _bytes(supplied)!=before:raise ShadowDataError('qualification final full supplied inputs changed')
    return dict(schema=SCHEMA,version=VERSION,status=status,mode='SHADOW_NO_ADMISSION_CHANGE',
        original_inventory_status=inventory['status'],full_input_snapshot=inputs,family_census=families,
        every_original_ground_definition=ground,generic_inline_cases=inline,fixtures=fixtures,failures=failures,
        fixed_malformed_matrix=list(NEGATIVE_NAMES),check_calls=total_checks,maximum_check_calls=MAX_CHECKS,
        fresh_Native_bulk_record_id=qid,fresh_Native_full_request= wanted,
        complete_original_interfaces=_owned(inventory['interfaces']),complete_original_definitions=_owned(definitions),
        input_bytes_unchanged=True,native_accepted_by_schema=False,Model_permission=False,new_target_proof=False,
        scope='Finite shadow plumbing/correspondence only. Original Native admission and complete base search are unchanged. No universal formal soundness theorem, schema admission lane, or GCTS/RL performance claim.')
