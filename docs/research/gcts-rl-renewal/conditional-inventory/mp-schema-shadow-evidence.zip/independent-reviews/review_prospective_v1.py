"""Independent frozen ordinary metadata/raw Source audit; no target evaluation."""
import ast
import hashlib
import json
import stat
from pathlib import Path

OUT=Path('/private/tmp/gcts-mp-schema-peer-20261019')
ROOT=Path('/private/tmp/gcts-mp-schema-shadow-ROOT-20261019')
checks=[];verified={};raws={}
def check(label,value,detail=None):
    checks.append(dict(check=label,passed=bool(value),detail=detail))
    if not value:raise AssertionError(label)
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(d,label):
    check(label+' complete descriptor',type(d)is dict and set(d)=={'path','sha256','bytes'} and type(d['path'])is str and type(d['bytes'])is int and d['bytes']>0 and type(d['sha256'])is str and len(d['sha256'])==64 and all(c in '0123456789abcdef'for c in d['sha256']))
    p=Path(d['path']);s=p.lstat()
    check(label+' canonical absolute nonsymlink regular',p.is_absolute()and p==p.resolve()and stat.S_ISREG(s.st_mode)and not p.is_symlink())
    if d['path']not in verified:
        b=p.read_bytes();check(label+' whole raw SHA/size',dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==d);verified[d['path']]=d;raws[d['path']]=b
    else:check(label+' literal reused descriptor',verified[d['path']]==d)
    return raws[d['path']]
def parsed(d,label):return json.loads(load(d,label))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def write(p,v):
    with p.open('xb')as f:f.write((json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    return pin(p)
def contains(v,subject):
    if v==subject:return True
    if type(v)is dict:return any(contains(x,subject)for x in v.values())
    if type(v)is list:return any(contains(x,subject)for x in v)
    return False

index_desc=dict(path=str(ROOT/'plans/prospective-index-v1.json'),sha256='064319aff45ab168a59904af66a047430dfcd8111b1ceca55d54f5f60775fba8',bytes=4888)
index=parsed(index_desc,'current FALSE index')
check('one Root Source-only unlaunched subject',index['schema']=='ROOT-mp-schema-shadow-prospective-index-v1'and index['author_identity']=='/root'and index['source_only']is True and index['scientific_calls']==0 and index['actual_execution_authorized']is False and index['subject_count']==1 and len(index['schedule'])==1)
row=index['schedule'][0]
design=parsed(index['design'],'Root design');decl=parsed(index['case_declaration'],'Root current declaration');closure=parsed(index['runtime_closure'],'full current closure')
worker=parsed(row['worker_plan'],'full worker plan');once=parsed(row['runner_plan_draft'],'full once draft');auth=parsed(row['authorization_draft'],'false authorization draft')
capsule=parsed(index['input_capsule'],'complete original10-input capsule');contract=parsed(index['intake_Source_contract'],'current intake Source contract')
for name,v in [('design',design),('declaration',decl),('closure',closure)]:check(name+' Root author/Source-only/no launch',v['author_identity']=='/root'and v['source_only']is True and v['scientific_calls']==0 and v['actual_execution_authorized']is False)
check('exact new design and declaration schemas',design['schema']=='ROOT-mp-schema-shadow-prospective-design-v1'and decl['schema']=='ROOT-mp-schema-shadow-qualification-declaration-v1')
check('same whole current closure in all operational subjects',index['runtime_closure']==design['runtime_closure']==decl['runtime_closure']==worker['runtime_closure']==once['runtime_closure'])
check('whole integration descriptors agree',decl['global_cohort_declaration']==index['design']and worker['integration_declaration']==once['integration_declaration']==index['case_declaration']and decl['intake_Source_handoff']==index['intake_Source_contract']==design['intake_Source_contract']==closure['current_composition_handoff'])
check('exact one full schedule in design and declaration',design['schedule']==decl['schedule']and len(decl['schedule'])==1)
schedule=decl['schedule'][0]
for key in ('invocation_id','mode','search_ordering','inventory_certification_mode','receiver_id','result_reader','model_storage','actual_directory'):
    check('all full schedule/once/worker bindings '+key,row[key]==schedule[key]==once[key]==worker[key])
check('exact prospective fixed/bulk/case001 choices',(row['mode'],row['search_ordering'],row['inventory_certification_mode'],row['model_storage'],row['result_reader'],row['receiver_id'])==('fixed','and_support','bulk','literal_interned','interned','prospective-fol-20261018-001'))
check('one new once iid/order',row['invocation_id']=='mp-schema-shadow-001-fixed-bulk-ROOT-20261019-v1'and row['order']==schedule['order']==1)
once_keys={'schema','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory','runner','observer','python','cold','worker_plan','integration_declaration','runtime_closure','authorization','limits','environment'}
worker_keys={'schema','invocation_id','mode','actual_directory','cold','python','project_sources','components','native_inputs','policy','declaration','runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage','search_ordering','inventory_certification_mode'}
auth_keys={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'}
check('exact19-field current worker protocol',set(worker)==worker_keys and worker['schema']=='ROOT-mp-schema-shadow-worker-plan-v1')
check('exact19-field once protocol',set(once)==once_keys and once['schema']=='ROOT-mp-schema-shadow-once-plan-v1')
check('exact7-field false/max0/emptyroles authorization',set(auth)==auth_keys and auth['schema']=='ROOT-mp-schema-shadow-once-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review_roles']=={})
subject={k:v for k,v in once.items()if k!='authorization'};subject_sha=hashlib.sha256(canonical(subject)).hexdigest()
check('full18-field subject excludes onlyauthorization',len(subject)==18 and subject_sha==row['subject_sha256']==auth['subject_sha256']=='4c8b18798415d7952a945c26b58b94b82d0102aa37e5c1b7406f5b4dd0680047')
check('once exact full worker/auth descriptors',once['worker_plan']==row['worker_plan']and once['authorization']==row['authorization_draft'])
for role in ('cold','runner','observer'):
    load(index[role],'current '+role+' Source');check(role+' current exact contract/once/index binding',index[role]==contract[role]==once[role])
check('worker selects current cold exact',worker['cold']==index['cold'])

old_worker_desc=dict(path='/private/tmp/gcts-adaptive-group-local-pilot-20261019/plans/worker-plans/adaptive-group-002-fixed-local-ROOT-20261019-v2.json',sha256='f123b75b1af2a4df74fd9d1a45384d9d30467e2a44a6de2cd7f4eaec5721edc7',bytes=18113)
old_worker=parsed(old_worker_desc,'prior local scientific baseline worker')
old_closure_desc=dict(path='/private/tmp/gcts-adaptive-group-local-pilot-20261019/runtime-closure-v2.json',sha256='48714576a9da54abe2c442cb3fbb5e883fa08f51cdd1c94297cc85ca1b41f42a',bytes=73808)
old_closure=parsed(old_closure_desc,'prior complete local closure')
changes={k for k in worker if worker[k]!=old_worker[k]}
check('worker only intended case/mode/current operational changes',changes=={'actual_directory','cold','integration_declaration','inventory_certification_mode','invocation_id','receiver_id','runtime_closure','schema'},sorted(changes))
check('base24 project/component Sources literal unchanged',worker['project_sources']==old_worker['project_sources']==closure['project_sources']and worker['components']==old_worker['components']==closure['additional_nonseed_components']and len(worker['project_sources'])==22 and set(worker['components'])=={'receiver_driver','bounded_transport'})
aliases=dict(worker['project_sources'],semantic_receiver_driver=worker['components']['receiver_driver'],bounded_request_oracle=worker['components']['bounded_transport'])
check('same complete24 materialized alias map',len(aliases)==24 and aliases==closure['materialized_aliases']==old_closure['materialized_aliases']and closure['materialized_project_and_component_count']==24)
check('closure exact narrow schema+shadow additions',set(closure)-set(old_closure)=={'schema_kernel_source','shadow_sources'}and not(set(old_closure)-set(closure))and {k for k in closure if k in old_closure and closure[k]!=old_closure[k]}=={'schema','bridge_scope','current_composition_handoff'})
check('complete26 imports are base24 plus distinct2 Shadow',len(index['shadow_sources'])==2 and set(index['shadow_sources']).isdisjoint(aliases)and closure['shadow_sources']==index['shadow_sources']==contract['shadow_sources'])
check('same exact raw kernel descriptor',closure['schema_kernel_source']==index['schema_kernel_source']==contract['schema_kernel_source'])
load(index['schema_kernel_source'],'historical semantic kernel raw only')
for name,d in aliases.items():load(d,'base scientific Source raw only '+name)
for name,d in index['shadow_sources'].items():
    t=ast.parse(load(d,'extra Shadow raw Source '+name));roots=[]
    for n in ast.walk(t):
        if isinstance(n,ast.Import):roots.extend(a.name.split('.')[0]for a in n.names)
        elif isinstance(n,ast.ImportFrom):roots.append((n.module or'').split('.')[0])
    check('Shadow '+name+' has only explicit stdlib imports',set(roots)<= {'hashlib','json','math'}and not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id in ('__import__','eval','exec')for n in ast.walk(t)),roots)
check('no recursive proposer alias added',not any('recursive'in name for name in aliases))
check('closure exact unchanged complete126 importsites2literal imports',len(closure['import_sites'])==126 and closure['import_sites']==old_closure['import_sites']and len(closure['literal_dynamic_import_sites'])==2 and closure['literal_dynamic_import_sites']==old_closure['literal_dynamic_import_sites']and closure['unresolved_dynamic_import_sites']==closure['unresolved_project_imports']==[])
for key in ('native_inputs','policy','python','z3','declaration'):check('unchanged full baseline worker '+key,worker[key]==old_worker[key])
policy=parsed(worker['policy'],'complete original four-family policy')
check('full4 policy and no filtering',len(policy['library'])==design['full_original_family_count']==4 and len({f['id']for f in policy['library']})==4)
check('all original inputcapsule and full selected receiver agree',worker['declaration']==decl['parent_structural_declaration']==index['input_capsule']and len(capsule['receivers'])==10)
selected=[x for x in capsule['receivers']if x['id']==row['receiver_id']]
check('exact unchanged full case001 statement',len(selected)==1 and selected[0]==decl['selected_receiver']==design['assertion']and selected[0]['length']==12 and selected[0]['instantiation_rounds']==2 and not(set(selected[0])&{'proof','commands','route','binding','hints'}))
check('closed root policy explicit no new open assumptions/schemas',selected[0]['theory']['schemas']==[] and 'no open root assumptions'in selected[0]['scope'])
load(worker['python'],'unchanged whole Python raw executable')
check('Python intake exact original runtime',worker['python']==once['python']==closure['runtime']['Python_executable']==old_closure['runtime']['Python_executable'])
for name,d in worker['native_inputs'].items():
    if type(d)is dict and set(d)=={'path','sha256','bytes'}:load(d,'Native input opaque/raw bytes only '+name)
for key in ('source','binary'):load(closure['native_CPP'][key],'Native CPP '+key+' raw only')
check('same complete Native closure and canonical inputs',closure['native_CPP']==old_closure['native_CPP']and closure['fixed_native_inputs']==old_closure['fixed_native_inputs'])
check('all41 Z3 files exact complete projection',len(worker['z3']['files'])==41 and worker['z3']['files']==[{k:v[k]for k in ('path','sha256','bytes')}for v in closure['Z3']['files']]and worker['z3']['root']==closure['Z3']['package_root'])
for d in worker['z3']['files']:load(d,'Z3 raw bytes only '+d['path'].rsplit('/',1)[-1])
for name,v in closure['stdlib_entry_references'].items():
    if 'pin'in v:load(v['pin'],'trusted bundled stdlib entry raw only '+name)
load(closure['parent_closure'],'materialized local historical parent closure')
check('unchanged hard parent clone literal equality',closure['parent_closure']==old_closure['parent_closure'])
instrument_limits={'work_seconds':180,'overall_seconds':210,'aggregate_peak_bytes':1073741824,'stdout_bytes':4194304,'stderr_bytes':4194304,'result_bytes':134217728,'worker_receipt_bytes':4194304,'runner_plan_bytes':16777216,'failure_cleanup_seconds':5,'poll_milliseconds':20}
scientific_limits={'work_seconds':180,'overall_seconds':210,'conservative_worker_plus_native_peak_bytes':1073741824,'result_bytes':134217728,'search_seconds':30,'search_max_nodes':5000,'compile_queries':512,'guard_steps':1000000000,'inventory_registration_aggregate_micro_steps':5000000000,'registry_steps':5000000000,'check_steps':2048,'proposal_steps':24,'seed':64000}
check('exact full original instrument caps',once['limits']==instrument_limits)
check('exact full original scientific caps',decl['limits']==scientific_limits)
check('same original environment only',once['environment']=={'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','TZ':'UTC'})
check('Shadow explicit fixed own cap2M and combined128MiB',decl['shadow_fixed_limits']=={'combined_result_bytes':134217728,'maximum_check_calls':2000000})
check('known familiar qualification/full10 not a new theorem trial',design['mode']=='SHADOW_NO_ADMISSION_CHANGE'and design['known_control_definition_count']==10 and design['fixture_words_are_not_receiver_proof_routes']is True and design['inputs_are_statements_not_routes']is True and design['goal_complete']is False and decl['new_RL_training']is False)
obligations=design['independent_mathematical_obligations'];load(obligations,'prospective independent obligations')
check('same frozen nine obligation map',obligations==decl['shadow_obligations']and obligations['sha256']=='c1603d97d1bc45397196a231d1ed1d89204d8ae527e8a1715e01f1706afa6315')
load(design['prior_saved_case001_result_comparison_only'],'whole saved historical case001 comparison raw only')
check('prospective schema contract/review joins',design['schema_Source_contract']==index['source_contract']and design['schema_Source_review']==index['schema_Source_review'])
load(index['source_contract'],'exact Library component Source contract')
reviews={
 'ordering':index['unchanged_ordering_review'],
 'registry_driver':dict(path='/private/tmp/gcts-adaptive-groups-independent-peer-20261019/typed-Source-review-v1.json',sha256='ff2d6a15e9625f6873554d7b682abe601c3865ec4af0297c20f59e4111e9c65c',bytes=11934),
 'certifier':index['schema_Source_review'],
 'shadow_wrapper':dict(path=str(OUT/'typed-shadow-Source-review-v3.json'),sha256='04fb46c12e80d68a770c261c44918eee8372f3ffdcfad9af9acc7dd4b56ed089',bytes=5823),
 'intake':dict(path=str(OUT/'typed-intake-Source-review-v3.json'),sha256='0eaa91c27f3aeff9669e9b40b075c37681c4c5dd287fabf8f3607ccb3a0b0a22',bytes=10049)}
review_objects={k:parsed(d,k+' exact scoped Source receipt')for k,d in reviews.items()}
for name,v in review_objects.items():check(name+' PASS/no science/no launch/distinct author',v['source_review_passed']is True and v['source_only']is True and type(v['scientific_calls'])is int and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False and v['author_identity']!=v['reviewer_identity'])
check('certifier current raw Source exact coverage',contains(review_objects['certifier'],index['shadow_sources']['mp_schema_certificate']))
check('wrapper V3 current raw exact coverage',contains(review_objects['shadow_wrapper'],index['shadow_sources']['mp_schema_shadow_qualification']))
for d in [index['cold'],index['runner'],index['observer'],*index['shadow_sources'].values(),worker['components']['receiver_driver']]:check('intake full current subject coverage '+Path(d['path']).name,contains(review_objects['intake'],d))
for d in [aliases['semantic_inventory_oracle'],aliases['semantic_receiver_driver']]:check('registry peer BOTH original scientific subjects '+Path(d['path']).name,contains(review_objects['registry_driver'],d))
check('Source reviewers ancestry explicitly not5distinct people',review_objects['ordering']['reviewer_identity']=='/root/receiver_driver_review'and all(review_objects[k]['reviewer_identity']=='/root/conventional_control_review'for k in ('registry_driver','certifier','shadow_wrapper','intake')))
operational=[index_desc,index['design'],index['case_declaration'],index['runtime_closure'],index['input_capsule'],closure['parent_closure'],row['worker_plan'],row['runner_plan_draft'],row['authorization_draft']]
for d in operational:check('operational descriptor already private/tmp '+Path(d['path']).name,d['path'].startswith('/private/tmp/'))
actual=Path(row['actual_directory'])
check('actual parent exists/local canonical',actual.parent.is_dir()and actual.is_absolute()and actual==actual.resolve()and str(actual).startswith('/private/tmp/'))
fresh=[actual,actual/'CONSUMED.json',actual/'result.json',actual/'schema-shadow-result.json',actual/'runner-receipt.json',Path(row['runner_plan_draft']['path']).parent/(row['invocation_id']+'-terminal-observation'),ROOT/'plans/runner-plans'/(row['invocation_id']+'.json'),ROOT/'plans/runner-plans'/(row['invocation_id']+'-terminal-observation'),ROOT/'plans/authorizations'/(row['invocation_id']+'.json'),ROOT/'plans/authorized-index-v1.json']
for p in fresh:check('fresh absence '+str(p),not p.exists())
audit=write(OUT/'prospective-raw-metadata-audit-v1.json',dict(schema='mp-schema-shadow-prospective-independent-raw-audit-v1',source_only=True,scientific_calls=0,checks=checks,verified_raw_descriptors=list(verified.values()),full_worker_plan=worker,full_once_draft=once,full_false_authorization=auth,subject_preimage=subject,subject_sha256=subject_sha,full_selected_receiver=selected[0],complete24base_aliases=aliases,separate2shadow_sources=index['shadow_sources'],baseline_worker=old_worker_desc,baseline_closure=old_closure_desc,intended_worker_changed_fields=sorted(changes),fresh_paths=[str(p)for p in fresh]))
review=dict(schema='mp-schema-shadow-prospective-plan-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',prospective_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,project_imports=0,native_calls=0,model_calls=0,compiler_calls=0,solver_calls=0,search_calls=0,reader_calls=0,renderer_calls=0,fixture_calls=0,codec_calls=0,scope='One exact false prospective SHADOW qualification subject only; Root metadata composition, not launch or own inherited scientific Source certification',prospective_index=index_desc,design=index['design'],case_declaration=index['case_declaration'],runtime_closure=index['runtime_closure'],worker_plan=row['worker_plan'],runner_plan_draft=row['runner_plan_draft'],authorization_draft=row['authorization_draft'],subject_sha256=subject_sha,subject_field_count=18,source_contract=index['intake_Source_contract'],scientific_Source_contract=index['source_contract'],current_intake_sources={k:index[k]for k in ('cold','runner','observer')},shadow_sources=index['shadow_sources'],schema_kernel_source=index['schema_kernel_source'],all24base_sources=aliases,Python=worker['python'],Z3=worker['z3'],native_inputs=worker['native_inputs'],policy=worker['policy'],input_capsule=index['input_capsule'],full_schedule=[schedule],independent_obligations=obligations,current_Source_reviews=reviews,check_count=len(checks),mismatch_count=0,unique_raw_pin_count=len(verified),audit=audit,review_Source=pin(Path(__file__)),findings=[
 dict(id='EXACT_FALSE_SUBJECT',finding='One fixed/and_support/bulk familiar case001 slot with interned Model/result reader. Complete18-field subject4c8b preserves the exact full worker/runtime/declaration input. Authorization is false/max0/emptyroles, and final grant, observer and actual paths are absent.'),
 dict(id='BASE24_AND_SEPARATE2',finding='All original24 aliases, full policy, Native inputs, Python,41 Z3 files and complete case capsule are unchanged from the prior local scientific baseline. Current26-module runtime adds exactly the two separately pinned Shadow modules and raw semantic-kernel context. Historical descriptors remain history; live operational metadata is private/tmp.'),
 dict(id='QUALIFICATION_NO_PERMISSION',finding='Original full Native bulk inventory admission and normal search/final proof gates remain. Shadow has separate output, original-result before/after preservation and combined128MiB cap. The case is a familiar finite qualification of all4 policy families, all expected10 Native ground definitions and fixed obligations, not a new theorem or schema bypass.'),
 dict(id='COST_AND_ROLE_SCOPE',finding='Original180positive/210terminal, conservative separate worker+Native peak sum1GiB, original search/compiler/Native limits and log caps remain. The added two imports, syntax calls, all finite fixtures, complete result rereading and both serializations are charged. Five runtime role names use the same intake review for composition+once and only two reviewer identities overall; full Source scope and ancestry remain externally checked.')],limitations=[
 'Only raw Source/ordinary saved JSON/hash/stat/AST metadata inspection was performed. No target scientific function/module, Native, kernel, Model, compiler, solver, search, Reader, renderer, fixture, program or opaque codec was imported or evaluated. Native gzip was raw-hashed only. Historical case001 result was whole-hashed only; no proof replay.',
 'Reviewer authored inherited outer/broker, earlier drivers and current helper/symbolic control, some benchmark and previous CASE/checker/diagnosis components, and the independent obligation note. Root authored the prospective composition/current intake and wrapper; Library authored the certifier. This review independently checks Root metadata, not a fresh self-certificate of inherited own Source or Native kernel soundness. Separate exact certifier, wrapper, intake, scientific and genuine Receiver ordering reviews are bound.',
 'This false/max0 packet authorizes no execution. Future Root must create a fresh true/max1 grant without changing the subject, bind all five expected role scopes to complete raw subjects, include BOTH registry and driver, and preserve the additional separate certifier+wrapper reviews and obligation map. Same composition/once receipt and shared reviewer identity are intentional and not presented as distinct independent reviewers. A final exact delta/freshness review is still required.',
 'The runtime closure explicitly inventories the unchanged24 base aliases; the complete current runtime is26 with its separate two-module Shadow map. Importsites126 and two literal math imports describe the base map; the added two were independently AST-read and contain only hashlib/json/math imports. Bundled stdlib/loader/OS custody is conditional, not a fully sealed formal activation guarantee.',
 'No future qualification count is assumed from old success. Root retained admission must verify fresh full10 original ground registry membership/order and Native-record authority, all4 family dispositions, all returned ground/revalidation/generic/negative/callback/quota packets, unchanged base result and exact before/after inverse. A PASSED string alone is insufficient. GEN remains outside the eligible meta/imp grammar and retains its ordinary Native path.',
 'Normal base registry/compile UNKNOWN or unavailable work window skips all schema qualification and preserves a separate normal UNKNOWN sidecar. Unexpected component UNKNOWN remains explicit prefix UNKNOWN; the expected private-quota UNKNOWN is only a fixture result. Returned packet lists are retained stage evidence and may duplicate a generic packet, not unique module-call counts. Thrown resource/callback failure has no promised unreturned snapshots.',
 'Positive base or passed Shadow plus known worker exit must satisfy the original180 deadline; metadata-only UNKNOWN may close by210. Source entry scope excludes separately observed observer/interpreter prelude.1GiB is the sum of separately measured Darwin worker+Native highwaters, not simultaneous RAM or OS enforcement. Observer/controller RAM is outside this qualification gate. Final outer whole-Python/raw loop is conditional on aggregate-profile pass, so failed-memory diagnostics cannot claim that skipped loop.',
 'Synchronous filesystem resolve/open/read remains potentially blocking. Private/tmp operational metadata avoids the previous reported dataless-file hydration path but provides no formal I/O interruption guarantee. Fresh subject/paths cannot reuse previous consumed observations. Earlier failed launch and original actuals remain historical and immutable.',
 'No schema-only Native admission, new mathematical axiom/rule, interface trim, primitive/marking/point/scheduler/fallback/rollback change, target route/binding, theorem discovery, performance/RL/GCTS-specific superiority or goal-completion claim follows. Future schema bypass or resource/performance comparison requires a separately declared reviewed lane and actual admission.'
])
r=write(OUT/'typed-prospective-review-v1.json',review)
h=write(OUT/'prospective-peer-handoff-v1.json',dict(schema='mp-schema-shadow-prospective-independent-peer-handoff-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=r,audit=audit,prospective_index=index_desc,subject_sha256=subject_sha))
print(json.dumps(dict(review=r,audit=audit,handoff=h,checks=len(checks),raw_pins=len(verified)),indent=2))
