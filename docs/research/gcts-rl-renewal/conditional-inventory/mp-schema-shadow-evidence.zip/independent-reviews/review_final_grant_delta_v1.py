"""Saved metadata delta/freshness only. No scientific function or launch."""
import hashlib,json,stat
from pathlib import Path
OUT=Path('/private/tmp/gcts-mp-schema-peer-20261019');ROOT=Path('/private/tmp/gcts-mp-schema-shadow-ROOT-20261019')
checks=[];verified={}
def check(label,v):
    checks.append(dict(check=label,passed=bool(v)))
    if not v:raise AssertionError(label)
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def raw(d,label):
    check(label+' complete raw descriptor',type(d)is dict and set(d)=={'path','sha256','bytes'}and type(d['bytes'])is int and d['bytes']>0)
    p=Path(d['path']);check(label+' canonical regular nonsymlink',p.is_absolute()and p==p.resolve()and stat.S_ISREG(p.lstat().st_mode)and not p.is_symlink())
    b=p.read_bytes();check(label+' whole SHA/size',dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==d);verified[d['path']]=d;return b
def load(d,label):return json.loads(raw(d,label))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def contains(v,s):
    if v==s:return True
    if type(v)is dict:return any(contains(x,s)for x in v.values())
    if type(v)is list:return any(contains(x,s)for x in v)
    return False
def write(p,v):
    with p.open('xb')as f:f.write((json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
    return pin(p)
ix_desc=dict(path=str(ROOT/'plans/authorized-index-v1.json'),sha256='3aec0042c73374883b0564445c5d24e729a294db23505b798466d5a81ce14eb5',bytes=6805)
old_desc=dict(path=str(ROOT/'plans/prospective-index-v1.json'),sha256='064319aff45ab168a59904af66a047430dfcd8111b1ceca55d54f5f60775fba8',bytes=4888)
adopt_desc=dict(path=str(ROOT/'ROOT-final-grant-adoption-v1.json'),sha256='2c2f88d81dd2e3f7aea0f05112c256e037cd95c9ea32e531fb5290061782924b',bytes=2267)
ix=load(ix_desc,'current authorized index');old=load(old_desc,'preserved false index');adopt=load(adopt_desc,'Root adoption')
check('Root sole current grant/no launches metadata',ix['schema']=='ROOT-mp-schema-shadow-authorized-index-v1'and ix['author_identity']=='/root'and ix['actual_execution_authorized']is True and ix['actuals_started']==0 and ix['scientific_calls']==0 and ix['source_only']is True and len(ix['schedule'])==ix['subject_count']==1)
check('only declared index authorization additions',set(ix)-set(old)=={'actuals_started','current_review_roles','scope'}and not(set(old)-set(ix))and {k for k in old if ix[k]!=old[k]}=={'actual_execution_authorized','schema','schedule'})
r=ix['schedule'][0];o=old['schedule'][0]
check('only current runner/auth descriptors added to row',set(r)-set(o)=={'authorization','runner_plan'}and all(r[k]==v for k,v in o.items()))
once=load(r['runner_plan'],'new whole once plan');draft=load(o['runner_plan_draft'],'preserved once draft');auth=load(r['authorization'],'new Root true grant');false=load(o['authorization_draft'],'preserved false grant');worker=load(r['worker_plan'],'unchanged whole worker')
check('worker descriptor unchanged',r['worker_plan']==o['worker_plan'])
check('once only authorization descriptor changed',set(once)==set(draft)and len(once)==19 and {k for k in once if once[k]!=draft[k]}=={'authorization'}and once['authorization']==r['authorization'])
subject={k:v for k,v in once.items()if k!='authorization'};digest=hashlib.sha256(canonical(subject)).hexdigest()
check('full exact18 subject unchanged',len(subject)==18 and subject=={k:v for k,v in draft.items()if k!='authorization'}and digest==r['subject_sha256']==false['subject_sha256']==auth['subject_sha256']=='4c8b18798415d7952a945c26b58b94b82d0102aa37e5c1b7406f5b4dd0680047')
check('false max0 and true strictmax1 only intended authorization delta',set(auth)==set(false)and {k for k in auth if auth[k]!=false[k]}=={'actual_execution_authorized','maximum_actual_invocations','review_roles','scope'}and false['actual_execution_authorized']is False and type(false['maximum_actual_invocations'])is int and false['maximum_actual_invocations']==0 and false['review_roles']=={}and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['author_identity']=='/root')
check('same exact invocation/worker paths/factors',all(once[k]==worker[k]==r[k]for k in ('actual_directory','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id'))and once['mode']=='fixed'and once['inventory_certification_mode']=='bulk')
for k in ('cold','runner','observer','runtime_closure','case_declaration','design','intake_Source_contract','source_contract','schema_Source_review','schema_kernel_source','input_capsule'):
    check('unchanged full index binding '+k,ix[k]==old[k]);raw(ix[k],'current unchanged '+k)
for k in ('integration_declaration','runtime_closure'):check('exact operational once-worker '+k,once[k]==worker[k])
intake_desc=dict(path=str(OUT/'typed-intake-Source-review-v3.json'),sha256='0eaa91c27f3aeff9669e9b40b075c37681c4c5dd287fabf8f3607ccb3a0b0a22',bytes=10049)
prospective_desc=dict(path=str(OUT/'typed-prospective-review-v1.json'),sha256='59212f304b4214aded14a594a139bfec05c7ca4077590688cec2e78024def454',bytes=29589)
expected_receipts={
 'ordering_Source':old['unchanged_ordering_review'],
 'registry_Source':dict(path='/private/tmp/gcts-adaptive-groups-independent-peer-20261019/typed-Source-review-v1.json',sha256='ff2d6a15e9625f6873554d7b682abe601c3865ec4af0297c20f59e4111e9c65c',bytes=11934),
 'composition_Source':intake_desc,'once_Source':intake_desc,'prospective_plans':prospective_desc}
expected_subjects={
 'ordering_Source':[worker['project_sources'][k]for k in ('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],
 'registry_Source':[worker['project_sources']['semantic_inventory_oracle'],worker['components']['receiver_driver']],
 'composition_Source':[once['cold'],worker['components']['receiver_driver'],*ix['shadow_sources'].values()],
 'once_Source':[once['runner'],once['observer']],
 'prospective_plans':[once['integration_declaration'],once['runtime_closure'],once['worker_plan']]}
specs={
 'ordering_Source':('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
 'registry_Source':('adaptive-group-registry-driver-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'composition_Source':('mp-schema-shadow-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'once_Source':('mp-schema-shadow-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'prospective_plans':('mp-schema-shadow-prospective-plan-review-v1','prospective_review_passed','/root/conventional_control_review')}
check('all5 current scopes and exact raw receipt map',set(auth['review_roles'])==set(specs)and ix['current_review_roles']==adopt['current_review_roles']==expected_receipts)
objects={}
for role,(schema,passed,reviewer)in specs.items():
    binding=auth['review_roles'][role]
    check(role+' exact full scoped binding',set(binding)=={'receipt','reviewer_identity','required_subjects'}and binding['receipt']==expected_receipts[role]and binding['reviewer_identity']==reviewer and binding['required_subjects']==expected_subjects[role])
    v=load(binding['receipt'],role+' genuine current raw receipt');objects[role]=v
    check(role+' correct schema/pass/author/reviewer/no science',v['schema']==schema and v[passed]is True and v['author_identity']!=v['reviewer_identity']==reviewer and v['source_only']is True and type(v['scientific_calls'])is int and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False)
    for d in expected_subjects[role]:check(role+' full literal descriptor covered '+Path(d['path']).name,contains(v,d));raw(d,role+' current subject raw '+Path(d['path']).name)
check('five scopes are4receipts2reviewer identities',len({d['path']for d in expected_receipts.values()})==4 and len({v['reviewer_identity']for v in objects.values()})==2 and auth['review_roles']['composition_Source']['receipt']==auth['review_roles']['once_Source']['receipt'])
check('prospective receipt exact current subject/case/closure/worker',objects['prospective_plans']['prospective_index']==old_desc and objects['prospective_plans']['subject_sha256']==digest and objects['prospective_plans']['worker_plan']==r['worker_plan']and objects['prospective_plans']['case_declaration']==ix['case_declaration']and objects['prospective_plans']['runtime_closure']==ix['runtime_closure'])
cert=load(ix['schema_Source_review'],'separate certifier Source scope');wrapper_desc=dict(path=str(OUT/'typed-shadow-Source-review-v3.json'),sha256='04fb46c12e80d68a770c261c44918eee8372f3ffdcfad9af9acc7dd4b56ed089',bytes=5823);wrapper=load(wrapper_desc,'separate current wrapper Source scope')
for name,v,d in [('certifier',cert,ix['shadow_sources']['mp_schema_certificate']),('wrapper',wrapper,ix['shadow_sources']['mp_schema_shadow_qualification'])]:
    check(name+' exact separate SourcePASS and owned subject',v['source_review_passed']is True and v['source_only']is True and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False and v['author_identity']!=v['reviewer_identity']and contains(v,d))
check('intake binds both current separate certificate+wrapper reviews',objects['composition_Source']['current_component_Source_reviews']['certifier']==ix['schema_Source_review']and objects['composition_Source']['current_component_Source_reviews']['shadow_wrapper']==wrapper_desc)
check('adoption exact old/new/subject/maxone/zeroactuals',adopt['author_identity']=='/root'and adopt['false_index']==old_desc and adopt['authorized_index']==ix_desc and adopt['subject_sha256']==digest and adopt['exact18field_subject_unchanged']is True and adopt['actuals_started']==0 and adopt['maximum_actual_invocations']==1 and adopt['scientific_calls']==0 and adopt['source_only']is True and adopt['scientific_acceptance']is False)
helper=pin(ROOT/'grant_v1.py')
actual=Path(r['actual_directory']);fresh=[actual,actual/'CONSUMED.json',actual/'worker-receipt.json',actual/'runner-receipt.json',actual/'result.json',actual/'schema-shadow-result.json',Path(r['runner_plan']['path']).parent/(r['invocation_id']+'-terminal-observation')]
for p in fresh:check('fresh absence before any measured window '+str(p),not p.exists())
check('local fresh parent exists and uniquegrant/runner only',actual.parent.is_dir()and actual==actual.resolve()and str(actual).startswith('/private/tmp/')and list((ROOT/'plans/authorizations').glob('*.json'))==[Path(r['authorization']['path'])]and list((ROOT/'plans/runner-plans').glob('*.json'))==[Path(r['runner_plan']['path'])])
audit=write(OUT/'final-grant-delta-audit-v1.json',dict(schema='mp-schema-shadow-final-grant-delta-raw-audit-v1',source_only=True,scientific_calls=0,checks=checks,verified_raw_descriptors=list(verified.values()),original_subject_preimage=subject,subject_sha256=digest,full_false_authorization=false,full_current_authorization=auth,full_current_once_plan=once,Root_metadata_grant_helper=helper,fresh_paths=[str(p)for p in fresh]))
review=dict(schema='mp-schema-shadow-final-grant-delta-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',grant_delta_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,scientific_replays=0,module_evaluations=0,project_imports=0,native_calls=0,fixture_calls=0,codec_calls=0,scope='Narrow saved-metadata false-to-true delta and pre-launch freshness only; no new Source or scientific review, no launch authorization',authorized_index=ix_desc,prospective_index=old_desc,Root_adoption=adopt_desc,prospective_review=prospective_desc,once_plan=r['runner_plan'],once_draft=r['runner_plan_draft'],authorization=r['authorization'],authorization_draft=r['authorization_draft'],worker_plan=r['worker_plan'],subject_sha256=digest,subject_field_count=18,case_declaration=ix['case_declaration'],runtime_closure=ix['runtime_closure'],current_roles=auth['review_roles'],schema_Source_review=ix['schema_Source_review'],wrapper_Source_review=wrapper_desc,check_count=len(checks),mismatch_count=0,unique_raw_pin_count=len(verified),audit=audit,review_Source=pin(Path(__file__)),findings=[dict(id='AUTHORIZATION_ONLY',finding='Full19-field once plan changes only authorization descriptor. Complete18-field subject4c8b, original worker bytes, all runtime/case/profile/input/Source descriptors and exact fixed/bulk choices are unchanged. False/max0/emptyroles becomes true/max1 with explicit scoped metadata.'),dict(id='EXACT_SCOPED_CUSTODY',finding='Five exact role scopes bind four unique receipts and two reviewer identities; composition and once intentionally share intake0eaa. Registry scope includes BOTH registry and driver, composition includes BOTH Shadow Sources. The separate certifier078f and wrapper04fb Source reviews remain explicitly joined through intake and prospective design.'),dict(id='FRESHNESS',finding='Exactly one current grant and once file; fresh local iid/output path and terminal-observation path absent, no CONSUMED/worker/result/sidecar receipts. This is a saved-path observation before launch, not ongoing process supervision or authority to execute.')],limitations=[
 'Reviewer authored inherited outer/broker/earlier drivers/current helper+symbolic and other prior benchmark/checker material; Root authored this grant and intake delta, Library authored certifier. This review is Root metadata delta/freshness only, not a new independent own-Source or mathematical kernel soundness certificate. Same reviewer across distinct scoped receipts is disclosed, not presented as five reviewers.',
 'Only raw ordinary JSON/Source hashes and path freshness were inspected. No scientific module, fixture, Native, Model, compiler, solver, search, Reader, renderer or codec was imported/evaluated; no launcher, observer, once, worker or grant helper executed by reviewer.',
 'Root reports its first helper invocation raised KeyError before any grants, then corrected shadow_sources lookup and performed metadata-only creation. This review authenticates current helper bytes and exact terminal metadata state; it does not independently establish the unretained prior exception chronology. Fresh actual/observer paths and no markers are directly checked.',
 'Root alone may launch after its own adoption and all-agent idle condition. This receipt has actual_execution_authorized:false and does not create or modify any grant. Original180positive/210terminal/1GiB separate Darwin highwater sum/128MiB combined output and all work units remain in the unchanged subject; actual fit/qualification/Native acceptance require later retained admission.',
 'Synchronous filesystem and OS/loader/callable custody trust limitations, conditional final outer raw loop, observer/interpreter prelude and separate controller/observer RAM exclusions remain as declared by the exact prior Source/prospective reviews. No all-state seal, new schema Native authority, scientific advantage, new theorem, RL, publication or goal-completion claim follows.'
])
rp=write(OUT/'typed-final-grant-delta-review-v1.json',review)
hp=write(OUT/'final-grant-delta-handoff-v1.json',dict(schema='mp-schema-shadow-final-grant-delta-peer-handoff-v1',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=rp,audit=audit,authorized_index=ix_desc,subject_sha256=digest,tools_stopped_after_receipt=True))
print(json.dumps(dict(review=rp,audit=audit,handoff=hp,checks=len(checks),raw_pins=len(verified)),indent=2))
