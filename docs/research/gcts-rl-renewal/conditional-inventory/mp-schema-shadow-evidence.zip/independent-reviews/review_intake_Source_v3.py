"""Root intake delta raw/AST/static review only; no target imports or launch."""
import ast,difflib,hashlib,json,subprocess
from pathlib import Path
OUT=Path('/private/tmp/gcts-mp-schema-peer-20261019');BASE=Path('/private/tmp/gcts-mp-schema-shadow-intake-ROOT-source-20261019');checks=[]
def check(k,v):
    checks.append(dict(check=k,passed=bool(v)))
    if not v:raise AssertionError(k)
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def write(p,v):
    with p.open('xb')as f:f.write((json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
    return pin(p)
contract_desc=dict(path=str(BASE/'Source-contract-v3.json'),sha256='ecb5d40b8230deeb565241537c4a96f55ab08236476f9efd362629e61b022393',bytes=4334)
check('exact current contract raw pin',pin(Path(contract_desc['path']))==contract_desc);c=json.loads(Path(contract_desc['path']).read_bytes())
check('Root current inactive Source contract',c['author_identity']=='/root' and c['source_only']is True and c['scientific_calls']==0 and c['scientific_acceptance']is False and c['actual_execution_authorized']is False)
paths={k:Path(c[k]['path'])for k in ('cold','runner','observer')};parents={k:Path(c['parent_'+k]['path'])for k in paths}
raws={};texts={};trees={};olds={};oldtrees={};constants={};oldconstants={};retained=[];patches=[]
def constants_of(t):
    result={}
    for n in t.body:
        if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)and isinstance(n.value,(ast.Constant,ast.Dict,ast.Tuple,ast.List,ast.Set)):
            result[n.targets[0].id]=ast.literal_eval(n.value)
    return result
def top(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def region(b,n):return b''.join(b.splitlines(True)[n.lineno-1:n.end_lineno])
for role,p in paths.items():
    raw=p.read_bytes();before=parents[role].read_bytes();t=ast.parse(raw);ot=ast.parse(before)
    raws[role]=raw;texts[role]=raw.decode();trees[role]=t;olds[role]=before;oldtrees[role]=ot;constants[role]=constants_of(t);oldconstants[role]=constants_of(ot)
    check(role+' exact new raw pin',pin(p)==c[role]);check(role+' exact parent raw pin',pin(parents[role])==c['parent_'+role])
    check(role+' same stdlib import AST',[ast.dump(n,include_attributes=False)for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom))]==[ast.dump(n,include_attributes=False)for n in ot.body if isinstance(n,(ast.Import,ast.ImportFrom))])
    td=top(t);od=top(ot);declared=c['retained_callable_AST'][role]
    check(role+' no added/removed top callable',set(td)==set(od) and declared['added']==[])
    actual_unchanged=[];actual_changed=[]
    for name in od:
        if ast.dump(td[name],include_attributes=False)==ast.dump(od[name],include_attributes=False):
            actual_unchanged.append(name);check(role+'.'+name+' raw retained',region(raw,td[name])==region(before,od[name]));retained.append(role+'.'+name)
        else:actual_changed.append(name)
    check(role+' retained/changed contract inventory exact',set(actual_unchanged)==set(declared['unchanged']) and set(actual_changed)==set(declared['changed']))
    compile(raw,str(p),'exec',dont_inherit=True);check(role+' compile-only',True)
    d=OUT/('intake-'+role+'-inert-review2');d.mkdir();target=d/'subject.txt';target.write_bytes(before)
    for direction,a,b in [('forward',before,raw),('inverse',raw,before)]:
        patch=d/(direction+'.patch');patch.write_text(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='subject.txt',tofile='subject.txt')))
        r=subprocess.run(['/usr/bin/patch','--batch','--fuzz=0','subject.txt','-i',str(patch)],cwd=d,capture_output=True,text=True,timeout=10)
        check(role+' '+direction+' actual zero-fuzz inert text patch',r.returncode==0 and target.read_bytes()==b);patches.append(dict(role=role,direction=direction,patch=pin(patch),stdout=r.stdout,stderr=r.stderr))
check('27 retained top helpers raw/AST',len(retained)==27)
for role,parent_fn,names in [('cold','main',['overall_tick','now','stage','full_artifacts','source_guard','oracle_factory','reader_tick']),('runner','run_once',['reap','signal_group','probe_group','drain','wait_cleanup'])]:
    def nested(t):return {n.name:n for n in ast.walk(top(t)[parent_fn]) if isinstance(n,ast.FunctionDef) and n.name!=parent_fn}
    a=nested(trees[role]);b=nested(oldtrees[role])
    for name in names:check(role+' lifecycle/context nested '+name+' raw/AST retained',region(raws[role],a[name])==region(olds[role],b[name]) and ast.dump(a[name],include_attributes=False)==ast.dump(b[name],include_attributes=False))
check('original LIMITS exact unchanged',constants['runner']['LIMITS']==oldconstants['runner']['LIMITS'])
check('exact bulk/fixed/and_support/compact intake factors',constants['runner']['KINDS']==('fixed',) and constants['runner']['CERTIFICATIONS']==('bulk',) and constants['runner']['ORDERINGS']==('and_support',) and constants['runner']['STORAGES']==('literal_interned',))
check('cold/runner whole shadow Source constants agree',constants['cold']['SHADOW_SOURCES']==constants['runner']['SHADOW_SOURCES']==c['shadow_sources'])
check('new runner hard cold pin exact',constants['runner']['COLD_PIN']==c['cold'])
check('worker schema matches cold/runner',constants['cold']['WORKER_SCHEMA']==constants['runner']['WORKER_RECEIPT_SCHEMA']=='mp-schema-shadow-worker-receipt-v1')
check('same Native program/microcode/roles/parent closure/registry driver constants',all(constants['cold'][k]==oldconstants['cold'][k]for k in ('PROGRAM_SHA','MICRO_SHA','ROLE_MODULES','PARENT_RUNTIME_CLOSURE','COMPACT_MODEL_SOURCE','RECEIVER_DRIVER_SOURCE','REGISTRY_SOURCE','ORDERING_COMPONENT_SOURCES','MODEL_STORAGE_MODULES')))
check('exact raw kernel descriptor bound',constants['cold']['SCHEMA_KERNEL_SOURCE']==c['schema_kernel_source'] and pin(Path(c['schema_kernel_source']['path']))==c['schema_kernel_source'])
for name,d in c['shadow_sources'].items():check('current shadow raw Source '+name,pin(Path(d['path']))==d)
check('base driver/registry literal same Sources',c['base_driver']==constants['cold']['RECEIVER_DRIVER_SOURCE'] and c['base_registry']==constants['cold']['REGISTRY_SOURCE'])
check('retained base role map still8logical roles',len(constants['cold']['ROLE_MODULES'])==8)
cold=texts['cold'];runner=texts['runner'];observer=texts['observer']
facts=[
 ('base24 same and2 separate shadow imports','cold',['expected_project=dict(parent_closure[\'project_sources\'])',"len(loaded)==24 and len(shadow_loaded)==2","closure['shadow_sources']==SHADOW_SOURCES"]),
 ('full original owned shadows copied and guarded','cold',["name not in names and name not in sys.modules",'owned_shadow[name]=descriptor(dest,raw);source_pins.extend([pin,owned_shadow[name]])','source_pins.append(SCHEMA_KERNEL_SOURCE)']),
 ('base guard before imports no rebaseline','cold',["module_guards.append(seal_callables(list(loaded.values())+z3_modules+[sys.modules[__name__]]))",'for name in SHADOW_SOURCES:',"module_guards.append(seal_callables([module]))"]),
 ('full import origin check per shadow','cold',["Path(module.__file__).resolve()==Path(owned_shadow[name]['path'])","shadow_loaded[name]=module;source_guard()"]),
 ('separate shadow maps in base epoch','cold',['shadow_sources=dict(original=SHADOW_SOURCES,owned=owned_shadow,kernel_source=SCHEMA_KERNEL_SOURCE)']),
 ('base driver call exact full original context','cold',["roles['family_model']=loaded[MODEL_STORAGE_MODULES[plan['model_storage']]]","inventory_certification_mode=plan['inventory_certification_mode']","source_epoch=epoch,source_guard=source_guard,tick=overall_tick,now=now"]),
 ('base Native cleanup/whole region happens before shadow','cold',["transport['closed'] is True and transport['all_reaped'] is True",'region_check=(verify_raw_region(result_data,work_ns)',"register=result_data['outputs'].get('register')"]),
 ('only complete fresh Native inside work can run Shadow','cold',["register.get('status')=='native_accepted' and _NOW_NS()<work_ns","canonical(result_data['records'])==canonical(oracle_box[0].records)"]),
 ('syntax only validator uses current theory/signature','cold',["kernel=loaded['logic'].Kernel(theory['functions'],theory['predicates']",'kernel.formula(loaded[\'quantified_receptors_v1\'].frozen(formula))','kernel_protocol=\'gcts-fol-1\'']),
 ('owned library registry records input copies','cold',["library=own(json.loads(raw_file(plan['policy']))['library'])","inventory=own(result_data['outputs']['register']),records=own(result_data['records'])"]),
 ('complete relevant checker harness syntax capsules','cold',['checker=dict(original=SHADOW_SOURCES[\'mp_schema_certificate\']','harness=dict(original=SHADOW_SOURCES[\'mp_schema_shadow_qualification\']','syntax_validator=dict(original=names[\'logic\']','receiver_theory=theory']),
 ('normal base UNKNOWN/late window skips qualification honestly','cold',["status='SHADOW_QUALIFICATION_UNKNOWN'","all_schema_tests_unexecuted=True","original_inventory_status=register.get('status')if type(register)is dict else'NOT_REACHED'"]),
 ('same original work check during all Shadow semantic callbacks','cold',["def shadow_tick():","need(_NOW_NS()<work_ns,'shadow scientific work within original180')"]),
 ('all positive base or Shadow finish checks under180','cold',["if positive or shadow['status']=='SHADOW_QUALIFICATION_PASSED':","all positive shadow/base work within original180"]),
 ('base raw and decoded literal unchanged after Shadow','cold',["raw_file(result_pin)==result_raw","post_shadow_literal=verify_literal_result(result_data,result_raw,shadow_finish_tick)","post_shadow_literal==literal"]),
 ('two full output combined128MiB and independent inverse','cold',["len(shadow_raw)+len(result_raw)<=134217728","shadow_pin=write_new(actual/'schema-shadow-result.json',shadow)","canonical(json.loads(shadow_reloaded))+b'\\n'==shadow_reloaded"]),
 ('worker binds full sidecar observations','cold',['schema_shadow=shadow_observation','combined_result_bytes=len(result_raw)+len(shadow_raw)','original_result_unchanged=True']),
 ('no Shadow Native/Model target permission','cold',['native_accepted_by_schema=False,Model_permission=False,new_target_proof=False']),
 ('new5review schemas keep scientific Both registry driver','runner',["'registry_Source':[worker['project_sources']['semantic_inventory_oracle'],worker['components']['receiver_driver']]","+list(SHADOW_SOURCES.values())"]),
 ('whole sidecar raw pin/combined cap joined','runner',["shadow_raw=read_raw(shadow_path,LIMITS['result_bytes'],overall_end)","pins['schema_shadow']==shadow_meta['output']","shadow_meta['combined_result_bytes']<=LIMITS['result_bytes']"]),
 ('sidecar current Source maps/literal inverse joined','runner',["shadow_meta['post_shadow_literal']==worker_receipt['result_reading']['roundtrip']","shadow_meta['sources']['original']==SHADOW_SOURCES","result['source_epoch']['shadow_sources'][k]"]),
 ('three distinct Shadow dispositions nativefalse preserved','runner',["('SHADOW_QUALIFICATION_PASSED','SHADOW_QUALIFICATION_FAILED','SHADOW_QUALIFICATION_UNKNOWN')","shadow['native_accepted_by_schema']is False","shadow['Model_permission']is False","shadow['new_target_proof']is False"]),
 ('passed Shadow output and known exit before180','runner',["if shadow['status']=='SHADOW_QUALIFICATION_PASSED':","shadow_meta['completed_ns']<work_end and terminal_ns<work_end"]),
 ('owned Python/Native sum and strict resource end retained','runner',["aggregate=wait_usage['ru_maxrss']+native['native_high_water_bytes']","aggregate<=LIMITS['aggregate_peak_bytes']","all complete terminal/custody/resource checks before210"]),
 ('observer currentrunner schema pin','observer',["plan['schema']=='ROOT-mp-schema-shadow-once-plan-v1'",c['runner']['sha256']])
]
for label,role,parts in facts:check(label,all(x in texts[role]for x in parts))
base_seal=cold.index('module_guards.append(seal_callables(list(loaded.values())+z3_modules+[sys.modules[__name__]]))')
shadow_import=cold.index("module=stage('import shadow:")
native_start=cold.index("receipt=loaded['semantic_receiver_driver'].run_receiver")
check('base seal <shadow import <Native/driver startup',base_seal<shadow_import<native_start)
check('no post-shadow base guard rebaseline',cold.count('module_guards.append(seal_callables(list(loaded.values())+z3_modules+[sys.modules[__name__]]))')==1)
check('four cold args same original direct process invocation',"plan['worker_plan']['path'],str(began),str(work_end),str(overall_end)" in runner and 'start_new_session=True' in runner)
check('same strict plan19/auth7/subject excludes onlyauthorization',"subject={k:v for k,v in plan.items() if k!='authorization'}" in runner and "auth_fields={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'}" in runner)
check('all runner top role schema keys5 retained',set(constants['runner']['REVIEW_ROLES'])==set(oldconstants['runner']['REVIEW_ROLES']) and len(constants['runner']['REVIEW_ROLES'])==5)
current_reviews={'certifier':pin(OUT/'typed-certificate-Source-review-v1.json'),'shadow_wrapper':pin(OUT/'typed-shadow-Source-review-v3.json'),'parent_intake':pin(Path('/private/tmp/gcts-adaptive-group-local-peer-20261019/typed-Source-review-v2.json'))}
for name,d in current_reviews.items():
    v=json.loads(Path(d['path']).read_bytes());check(name+' current Source PASS correctly no launch',v['source_review_passed']is True and v['source_only']is True and v['scientific_acceptance']is False and v['actual_execution_authorized']is False)
audit=write(OUT/'intake-raw-Source-audit-v3.json',dict(schema='mp-schema-shadow-intake-independent-raw-audit-v3',source_only=True,scientific_calls=0,checks=checks,retained_top_helpers=retained,retained_nested_cold7_runner5=True,inert_patches=patches,contract=contract_desc))
sources={'cold':c['cold'],'once_runner':c['runner'],'terminal_observer':c['observer'],**c['shadow_sources'],'base_driver':c['base_driver']}
review=dict(schema='mp-schema-shadow-intake-typed-Source-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',source=c['cold'],sources=sources,source_contract=contract_desc,source_only=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,project_imports=0,fixture_calls=0,native_calls=0,model_calls=0,compiler_calls=0,solver_calls=0,search_calls=0,codec_calls=0,renderer_calls=0,check_count=len(checks),mismatch_count=0,compile_without_evaluation_count=3,inert_F0_patch_directions=6,retained_top_raw_AST_helpers=27,retained_nested_cold_helpers=7,retained_nested_runner_lifecycle_helpers=5,current_component_Source_reviews=current_reviews,base_registry=c['base_registry'],kernel_Source=c['schema_kernel_source'],inherited_genuine_outer_peer={'path':'/private/tmp/gcts-compact-model-cold-once-independent-peer-20261018/typed-Source-review-v2.json','sha256':'d1fed0448738dbe07efbd2482a6259dc58ecf21473a3cbf46bf09e61a242d4a2','bytes':7732},audit=audit,review_Source=pin(Path(__file__)),scope='Root V3 cold/once/observer Source coupling delta only; exact Library/helper semantics and old inherited lifecycle rely on separately scoped reviews',findings=[dict(id='BASE24_PLUS_SEPARATE2',finding='Base24 originals/owned/roles and same compiler/registry/Native/Model/search remain. Two exact stdlib-only Shadow modules are copied/imported/sealed separately before Native startup. The original base guard is captured first and never rebased afterward; the actual Source epoch adds a distinct two-module map.'),dict(id='BASE_AUTHORITY_AND_OUTPUT_PRESERVED',finding='Only a freshly complete Native-admitted registry in remaining work time enters SHADOW. Owned copies and full Native-record equality to the persistent broker are used. Base result bytes and its decoded literal inverse are rechecked after Shadow. Normal base UNKNOWN skips all schema tests and retains separate UNKNOWN metadata.'),dict(id='WHOLE_PROFILE_AND_SIDEFILE',finding='Both full JSON outputs share the original128MiB cap; sidecar exact raw/inverse/source-map/status joins occur in the outer. Passed Shadow and known worker exit must be before180, and all externally observed terminal/resource/hash/EOF/group checks remain before210. No cap, parser, native microstep limit or lifecycle policy is changed.'),dict(id='EXACT_REVIEW_COVERAGE',finding='Runtime5-role custody now requires BOTH scientific registry and driver, and the composition role includes cold/baseDriver/BOTHShadow Sources. This one intake receipt may cover composition and once but does not create a second reviewer. Distinct certifier and Root-wrapper Source review receipts are explicitly bound.')],limitations=[
 'Source/static/AST reasoning only; three compile-without-evaluation and six actual inert text patch directions, no target/module/fixture/Native/Model/compiler/solver/search/Reader/renderer/codec execution or activation. No runtime fit, qualification, proof or performance result follows.',
 'Reviewer authored inherited original outer/broker/earlier driver and current helper/symbolic and obligations, but Root authored this current intake delta. Exact inherited27top helpers and12nested helpers rely on prior scoped intake/genuine Receiver outer ancestry, not a new independent self-Source certificate. Library certifier and Root wrapper have separate genuine exact reviews; prior negative wrappers remain preserved.',
 'The logical EPOCH schema remains the v5 base protocol but includes additional shadow_sources; the complete runtime therefore imports26 owned modules. Base24 role maps are unchanged. Base result byte preservation means before versus after Shadow within this new run, not byte identity to an older run with different Source epoch/time/metadata.',
 'Cold syntax validation uses the owned historical logic.Kernel.formula and compiler frozen conversion against the exact current theory. That is syntax checking, not a Native or proof-acceptance callback. The shadow Source capsule contains complete relevant checker/harness/syntax/theory inputs; the full base runtime remains separately bound in the base epoch and Source guard.',
 'Source entry still accepts a declaration-selected receiver; prospective plans must bind exact complete case001/four-policy/ten-ground-definition coverage and explicit count/status acceptance. The standalone wrapper does not independently establish original inventory membership. A future retained audit must check all returns/fixture coverage rather than only a PASSED string.',
 'One same intake receipt intentionally serves composition and once. Five role labels are not five reviewers. Root must externally validate exact raw receipt schema/scope/ancestry and bind the separate certifier078f and wrapper04fb scopes; generic full-descriptor containment is custody only. No circular current-grant review or launch permission is created here.',
 'Original Source-entry180positive work/output/known worker exit and210terminal, conservative separate Darwin worker+Native highwater sum1GiB,128MiB combined JSON and4MiB logs remain. Shadow passed with base UNKNOWN is still forced through the outer known-exit-before180 check. Late metadata UNKNOWN is not late positive qualification. Outer/observer/controller RAM and interpreter/observer prelude scopes remain separate.',
 'Blocking resolve/open/stat/read is still not formally interruptible and no new pre-marker journal exists. All operational metadata must be prospectively materialized locally under fresh max-one subject after the prior hydration failure; do not reuse old consumed attempts. Group absence/reappearance/EOF/kill ownership and trusted OS/loader/Python metadata/callable limits remain conditional.',
 'The final outer whole-Python/Source raw loop remains conditional on aggregate profile acceptance; earlier/memory-failed diagnostics cannot claim that skipped loop. Normal returned Shadow UNKNOWN/FAILED are retained distinctly from a valid Native base proof; combined resource admission and independent mathematical tiers remain Root-only obligations.',
 'No schema-only admission lane, new Native rule/axiom, Model-interface trimming, changed fallback/scheduler/rollback, theorem route/binding, RL or GCTS-specific advantage is introduced. A future schema bypass would require a separately declared/reviewed trusted gate.'
])
r=write(OUT/'typed-intake-Source-review-v3.json',review)
h=write(OUT/'intake-peer-handoff-v3.json',dict(schema='mp-schema-shadow-intake-independent-peer-handoff-v3',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=r,audit=audit,sources=sources,source_contract=contract_desc))
print(json.dumps(dict(review=r,audit=audit,handoff=h,checks=len(checks)),indent=2))
