"""Independent raw/AST/inert-patch audit only; never imports the certifier."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path('/private/tmp/gcts-mp-schema-peer-20261019')
BASE=Path('/private/tmp/gcts-mp-schema-source-20261019')
checks=[]
def check(label,value,lines=None):
    checks.append(dict(check=label,passed=bool(value),Source_lines=lines))
    if not value:raise AssertionError(label)
def pin(p):
    raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def write(p,v):
    with p.open('xb')as s:s.write((json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
    return pin(p)
def load(d,label):
    check(label+' raw pin',pin(Path(d['path']))==d)
    return json.loads(Path(d['path']).read_bytes())
handoff_desc=dict(path=str(BASE/'handoff-v1.json'),sha256='21279a23bf897dd8a3dd5f30cf8a22023ce60e9ff387c98c3fe48c9c6c5f5b89',bytes=2047)
h=load(handoff_desc,'author frozen handoff');contract=load(h['source_contract'],'contract');api=load(h['API'],'API')
source=h['source'];p=Path(source['path']);raw=p.read_bytes();text=raw.decode();tree=ast.parse(raw,filename=str(p))
check('exact Source7351 independent raw pin',pin(p)==source and source['sha256']=='7351d5954763e8b671411a78a821e5cc560ac1af19477a9491da573a735d2ae4' and source['bytes']==26687)
check('Root-designated distinct implementation author',h['author_identity']==contract['author_identity']=='/root/conventional_library')
check('contract/handoff/API Source descriptors exact',contract['source']==api['source']==source and contract['sources']==h['sources']=={'mp_schema':source})
check('all metadata Source-only/nonactivated',all(v['source_only']is True and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False for v in (h,contract,api)))
argument_desc=pin(OUT/'soundness-and-qualification-obligations-v1.json')
check('pre-frozen independent obligations exactc160',argument_desc['sha256']=='c1603d97d1bc45397196a231d1ed1d89204d8ae527e8a1715e01f1706afa6315' and h['independent_soundness_obligations']==argument_desc and contract['references']['independent_soundness_obligations']==argument_desc)
for name in ('original_kernel_raw_Source','original_family_Source','original_four_template_policy','master'):
    check('raw existing reference pin '+name,pin(Path(contract['references'][name]['path']))==contract['references'][name])
check('policy copy retains whole original bytes',pin(Path(contract['original_policy_copy']['path']))['sha256']==contract['references']['original_four_template_policy']['sha256'])
imports=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]
check('only3stdlib imports; no project/evaluator',len(imports)==3 and all(isinstance(n,ast.Import)for n in imports) and [n.names[0].name for n in imports]==['hashlib','json','math'])
defs={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
expected_functions=['_bytes','_digest','_copy','_fields','_index','_hash','_epochs','_formula','_replace','_family_header','_rebuild','_revalidate','_syntax','_ground_records','_registry','_flatten','_run','certify_family','revalidate_certificate','check_ground_instance']
check('all expected bounded functional stages exist',set(defs)==set(expected_functions)|{'SchemaCustodyError','SchemaCallbackProtocolError','_Refusal','_Stop','_Work'})
def body(name):
    n=defs[name];return '\n'.join(text.splitlines()[n.lineno-1:n.end_lineno])
expected_kwargs={
 'certify_family':['family','certified_dependencies','source_epoch','semantic_epoch','source_guard','check','limits'],
 'revalidate_certificate':['certificate','source_epoch','semantic_epoch','source_guard','check','limits'],
 'check_ground_instance':['certificate','arguments','ground_definition','dependency_definitions','source_epoch','semantic_epoch','source_guard','formula_validator','check','limits']}
for name,args in expected_kwargs.items():
    n=defs[name]
    check(name+' exact keyword-only public ABI',not n.args.args and [a.arg for a in n.args.kwonlyargs]==args)
    check(name+' uses single owned/custody wrapper',any(isinstance(x,ast.Call)and isinstance(x.func,ast.Name)and x.func.id=='_run'for x in ast.walk(n)))
handlers=[x for x in ast.walk(tree)if isinstance(x,ast.ExceptHandler)]
check('only owner-tagged private exceptions caught',len(handlers)==3 and {x.type.id for x in handlers if isinstance(x.type,ast.Name)}=={'_Refusal','_Stop'})
check('no dynamic eval/exec/import or target invocation',not any(isinstance(x,ast.Call)and isinstance(x.func,ast.Name)and x.func.id in ('eval','exec','__import__','compile','open')for x in ast.walk(tree)))
facts=[
 ('copy rejects cycles and nonbuiltin/stringkey/finite protocol','_copy',[78,97],['identity in active','type(value) in (dict,list)','type(k) is not str','math.isfinite','ordinary finite JSON literal']),
 ('exact key sets','_fields',[100,102],['type(value) is not dict','set(value)!=set(fields)']),
 ('bool/negative/future indices rejected','_index',[105,108],['type(value) is not int','0<=value<size']),
 ('raw kernel protocol/Source scope pinned but caller authenticates context','_epochs',[118,130],["semantic.get('kernel_protocol')!='gcts-fol-1'",'KERNEL_SOURCE_SHA256','KERNEL_SOURCE_BYTES']),
 ('only meta/imp constructors in eligible schematic formulas','_formula',[133,146],["formula[0]=='meta'","formula[0]=='imp'",'len(formula)!=2','len(formula)!=3',"w.ineligible('formula outside implication/meta fragment')"]),
 ('replacement copies inserted whole formula without recursive substitution inside it','_replace',[149,157],['return _copy(arguments[_index','return [_replace(v,arguments,w) for v in value]']),
 ('complete exact original family header and full identity preimage','_family_header',[160,181],["('id','parameters','template','dependencies','donor_atoms','provenance','scope')",'type(parameters) is not int','sorted(set','_digest(dict(parameters=parameters,template=t))','not t[\'proof\']']),
 ('active family-ID DAG guard','_rebuild',[184,187],["if fid in active:w.reject('cyclic certified family DAG')",'active=active|{fid}']),
 ('all child certificates independently rebuilt and declaration exact','_rebuild',[188,200],['_revalidate(c,source,semantic,w,active)','duplicate dependency certificate identity','undeclared extra dependency certificates','declared dependency has no eligible certificate']),
 ('exact assumption equation against ordered premise port','_rebuild',[206,210],["('rule','formula','index')","formula!=t['premises'][i]",'ordered assumption port']),
 ('literal MP equation from strict earlier rows','_rebuild',[211,216],["('rule','formula','antecedent','implication')","command['antecedent'],position","command['implication'],position","proved[b]!=['imp',proved[a],formula]"]),
 ('call argument arity and complete ordered repeated input validation','_rebuild',[217,240],['exact dependency formula argument arity','complete ordered dependency ports','enumerate(zip(inputs,interface[\'premises\']))','proved[source_row]!=wanted','dependency conclusion correspondence']),
 ('all-and-only dependency calls and final schema conclusion','_rebuild',[241,244],["called!=set(family['dependencies'])","proved[-1]!=t['conclusion']"]),
 ('incoming certificate full rebuild and whole literal equality','_revalidate',[253,261],["certificate['source_epoch']!=source","certificate['semantic_epoch']!=semantic",'_rebuild(',"_bytes(rebuilt)!=_bytes(certificate)"]),
 ('syntax callback exact exceptions/strict bool/mutation check','_syntax',[264,271],['valid=validator(formula)','type(valid) is not bool','SchemaCallbackProtocolError','SchemaCustodyError']),
 ('independent old ground specialization and full name preimage','_ground_records',[274,300],["name='lemma'+_digest(dict(family=f['id'],arguments=args))",'_replace(',"command['name']=dep",'full ground identity collision']),
 ('all formulas and signature callback checked','_ground_records',[278,295],['for a in args:_syntax(a,validator,w)',"_syntax(command['formula'],validator,w)","for p in ground['premises']:_syntax(p,validator,w)","_syntax(ground['conclusion'],validator,w)"]),
 ('full caller registry shape/root/required closure and prior order','_registry',[303,325],['full original ground definition registry','ground root must remain in complete original registry','independent ground specialization differs from original',"positions[cmd['name']]>=positions[name]"]),
 ('every child ordered source checked before frame','_flatten',[328,339],['len(input_sources)!=len(definition[\'premises\'])','enumerate(zip(input_sources,definition[\'premises\']))',"primitive[source]['formula']!=wanted"]),
 ('child assumptions alias caller source rather than new parent premise','_flatten',[342,349],['if input_sources is None:',"actual=_index(input_sources[port]","primitive[actual]['formula']!=formula",'alias=True']),
 ('actual flattened MP equation and ordered recursive call mapping','_flatten',[350,359],["mapping[_index(command['antecedent'],line", "primitive[b]['formula']!=['imp',primitive[a]['formula'],formula]", "for i in command['inputs']",'actual=frame(command[\'name\'],ports,path+[line])']),
 ('every frame retains source-to-primitive result map','_flatten',[361,367],['mapping.append(actual)','row_mapping=events','result_row=result']),
 ('generic final-result exact primitive duplicate with prior refs','_flatten',[368,372],['if result!=len(primitive)-1:', 'emit(dict(primitive[prior]))','source_row=prior,appended_row=result']),
 ('full independent flattened assumption MP recheck and last target','_flatten',[373,390],['flat root assumption mismatch',"proved[b]!=['imp',proved[a],formula]",'flat proof must end at claimed conclusion']),
 ('all public data is owned before action and checked after guard','_run',[394,419],['owned=_copy(inputs,w);before=_bytes(owned)','result=action(owned,w)',"w.step('final_custody');source_guard();w.step()",'_bytes(_copy(inputs,w))!=before']),
 ('only private owner-tagged refusal/stop yields normal statuses','_run',[403,420],['if refusal.owner is not w.owner:raise','if stop.owner is not w.owner:raise',"status='UNKNOWN'",'certificate=None,ground_correspondence=None']),
 ('per-call counters/output cap/no clock renewal','_run',[408,420],["result['counts']=dict(w.counts)",'encoded=_bytes(result);check()',"len(encoded)>w.limits['output_bytes']"]),
 ('ground root registry and expansion all rebuilt before success','check_ground_instance',[423,438],['_revalidate(','_ground_records(','_registry(','_flatten(',"status='GROUND_CORRESPONDENCE'"])
]
for label,name,lines,strings in facts:check(label,all(s in body(name)for s in strings),lines)
check('module all success authority flags remain false',all(x in text for x in ('native_accepted=False','Model_permission=False','new_axiom=False','candidate_pruning=False','logical_target_proof_accepted=False')),[19,23])
check('no operative cache or grant/Native/Model call',not any(isinstance(x,ast.ImportFrom)for x in tree.body) and not any(isinstance(x,ast.Call)and isinstance(x.func,ast.Name)and x.func.id in ('Popen','run_receiver','Model','open_fallback','check_inventory')for x in ast.walk(tree)))
compile(raw,str(p),'exec',dont_inherit=True);check('compile only; no code object evaluated',True)
inert=OUT/'certificate-inert-v1';inert.mkdir();subject=inert/'subject.txt';subject.write_bytes(b'')
patch_records=[]
for direction,before,after in [('forward',b'',raw),('inverse',raw,b'')]:
    patch=inert/(direction+'.patch');patch.write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='subject.txt',tofile='subject.txt')))
    proc=subprocess.run(['/usr/bin/patch','--batch','--fuzz=0','subject.txt','-i',str(patch)],cwd=str(inert),capture_output=True,text=True,timeout=10)
    check(direction+' actual inert full-file zero-fuzz direction',proc.returncode==0 and subject.read_bytes()==after)
    patch_records.append(dict(direction=direction,patch=pin(patch),stdout=proc.stdout,stderr=proc.stderr,returncode=proc.returncode,result_sha256=hashlib.sha256(subject.read_bytes()).hexdigest()))
audit=write(OUT/'certificate-raw-Source-audit-v1.json',dict(schema='mp-schema-certificate-independent-raw-Source-audit-v1',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,checks=checks,inert_patches=patch_records,author_handoff=handoff_desc,source=source,Source_contract=h['source_contract'],API=h['API'],independent_obligations=argument_desc))
review=dict(schema='mp-schema-certificate-typed-Source-review-v1',author_identity='/root/conventional_library',reviewer_identity='/root/conventional_control_review',scope='Independent narrow certificate Source review against pre-frozen unformalized c1603 obligations; no production admission or runtime qualification',source=source,sources={'mp_schema':source},source_contract=h['source_contract'],API=h['API'],author_handoff=handoff_desc,source_only=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,project_imports=0,fixture_calls=0,native_calls=0,model_calls=0,compiler_calls=0,solver_calls=0,search_calls=0,codec_calls=0,renderer_calls=0,formalized_proof=False,check_count=len(checks),mismatch_count=0,compile_without_evaluation_count=1,inert_F0_patch_directions=2,audit=audit,review_Source=pin(Path(__file__)),independent_soundness_obligations=argument_desc,findings=[dict(id='RULE_AND_SUBSTITUTION_CORRESPONDENCE',severity='evidence',finding='Exact meta/imp grammar, full ordered assumption equations, strict-prior literal MP, recursively rebuilt acyclic child certificates and every ordered repeated input port implement the stated row/DAG induction. No object-binder operation or Native rule is added.'),dict(id='FULL_GROUND_AND_PRIMITIVE_MAP',severity='evidence',finding='Ground name/definition/dependency construction is independent of the original specializer and matches full required records against the caller supplied complete original registry. Child assumptions alias caller sources, not parent assumptions. The final alias repair copies an already valid assumption/MP command and the whole flat proof is directly rechecked to end at its conclusion.'),dict(id='CUSTODY_AND_ERROR_ORIGIN',severity='evidence',finding='Owned builtins/finite active-copy checks, full literal certificate reconstruction and complete Source/semantic preimages retained. Only owner-tagged private refusal/stop classes are caught. Source guard, charged check and syntax-validator ValueError identity is preserved by the visible call/catch structure; no callback fixture was executed.'),dict(id='QUALIFICATION_SEPARATE',severity='scope',finding='Implementation Source PASS is independent of the Root SHADOW wrapper, whose exact V1 ad37 has a preserved negative receipt for normal UNKNOWN/prefix retention. Future corrected wrapper/intake/plan/Native qualification are required before any runtime claim.')],limitations=[
 'This is human raw Source reasoning plus AST/static confirmations, one compile-without-evaluation and two inert text patch directions, not executed schema/fixture/Native evidence. No universal machine-checked soundness theorem or formal historical Source-to-Native compiler/lowering proof is provided.',
 'The full current Source/semantic capsule and syntax-only validator remain caller-authenticated/read-only/exclusively owned preconditions. The module validates protocol and raw-kernel descriptor values and compares full epochs but cannot itself establish authenticity of arbitrary caller metadata or original complete inventory membership. Root SHADOW must supply the exact full original Native-admitted registry and policy. Unrelated records are retained, not newly certified.',
 'Capture begins after the check/Source prelude as documented. The design is not a sandbox against hostile concurrent callbacks or arbitrary protected-module/default/cell mutation. Full Root callable/raw Source custody remains external. No per-callback formal continuous OS seal is claimed.',
 'Private per-call work/depth/rows/output caps may return UNKNOWN with no operative certificate/correspondence. Canonical copies/JSON serialization costs are still charged to the outer absolute deadline but operation counts are not byte-time or Native microsteps. Native all-or-none admission remains required in SHADOW; no fit or speed guarantee follows.',
 'Returned nested objects are owned by the caller and no persistent cache is held. Shared subobjects within a returned packet do not create cross-call authority; revalidation reconstructs a mutated packet. Direct returned-packet mutation and callback-origin runtime tests remain future finite qualification obligations.',
 'The existing GEN/reflexivity template remains NOT_ELIGIBLE and all original four templates/ground interfaces must be preserved by the caller. A schema-only admission bypass or changed trusted kernel would be a new lane requiring separate declaration and review. None of the result statuses grants native_accepted, Model permission, pruning, receiver proof or GCTS/RL benefit.',
 'Reviewer authored the prior soundness note, inherited outer/broker/earlier driver and current helper/symbolic Sources, but did not author this Library module. Shared ABI discussion and the child-alias/final-row issue were disclosed before freeze. This is a genuine distinct implementation Source review, not a self-certificate of other inherited components.'
])
r=write(OUT/'typed-certificate-Source-review-v1.json',review)
handoff=write(OUT/'certificate-peer-handoff-v1.json',dict(schema='mp-schema-certificate-independent-peer-handoff-v1',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=r,audit=audit,source=source,source_contract=h['source_contract']))
print(json.dumps(dict(review=r,audit=audit,handoff=handoff,checks=len(checks)),indent=2))
