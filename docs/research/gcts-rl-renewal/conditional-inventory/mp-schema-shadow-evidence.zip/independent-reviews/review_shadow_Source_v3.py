"""Root wrapper successor: static/AST/inert-patch review, never imported."""
import ast,difflib,hashlib,json,subprocess
from pathlib import Path
OUT=Path('/private/tmp/gcts-mp-schema-peer-20261019');BASE=Path('/private/tmp/gcts-mp-schema-shadow-intake-ROOT-source-20261019');checks=[]
def check(k,v):
    checks.append(dict(check=k,passed=bool(v)))
    if not v:raise AssertionError(k)
def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def write(p,v):
    with p.open('xb')as f:f.write((json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    return pin(p)
p=BASE/'mp_schema_shadow_qualification_v3.py';old=BASE/'mp_schema_shadow_qualification_v2.py';raw=p.read_bytes();before=old.read_bytes();text=raw.decode();tree=ast.parse(raw);prior=ast.parse(before)
source=dict(path=str(p),sha256='5e3b715242b40941dc918e623746ba90a946d12fc3f3158b99ff3a4115e38694',bytes=19493)
check('exact V3 raw Source',pin(p)==source)
check('exact V2 parent preserved',pin(old)['sha256']=='32efab7fd0e6df9c55b315880f81399f050a9be1f66c9b775845bca0f3204936' and pin(old)['bytes']==18881)
check('only stdlib imports',[(n.names[0].name)for n in tree.body if isinstance(n,ast.Import)]==['hashlib','json'] and not any(isinstance(n,ast.ImportFrom)for n in tree.body))
def top(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def region(b,n):return b''.join(b.splitlines(True)[n.lineno-1:n.end_lineno])
newdefs=top(tree);olddefs=top(prior)
check('same full callable inventory V2/V3',set(newdefs)==set(olddefs))
retained=[]
for name in olddefs:
    if name!='run_shadow':
        check(name+' raw retained',region(raw,newdefs[name])==region(before,olddefs[name]));check(name+' AST retained',ast.dump(newdefs[name],include_attributes=False)==ast.dump(olddefs[name],include_attributes=False));retained.append(name)
for label,parts in [
 ('all records full Native request join',['inventory[\'status\']!=\'native_accepted\'','q[\'request\']!=wanted',"q['request_sha256']!=_digest(wanted)"]),
 ('all returned census/revalidation records before stop',['families.append(dict(family_id=',"families[-1]['revalidation']=rebuilt","require('family_full_revalidation:"]),
 ('all returned ground records before stop',["ground.append(entry);require('ground_correspondence:"]),
 ('generic child and parent returns retained',['generic_repeated_child_certificate','generic_identity_child_certificate','generic_parent_certificate:','generic_ground:']),
 ('fresh actual returned certificate retained before mutation',['fresh_before_direct_returned_mutation',"returned=fresh['certificate'];returned['derived_rows'][0]['formula']"]),
 ('owner scoped prefix UNKNOWN and failed channels',["component_returns.append(dict(stage=name","r['status']=='UNKNOWN' and 'UNKNOWN'not in expected","raise _PrefixStop(prefix_owner,'SHADOW_QUALIFICATION_UNKNOWN'","if e.owner is not prefix_owner:raise"]),
 ('unexpected normal callback return captured',['caught=None;callback_return=None','callback_return=schema_module.check_ground_instance','callback_return=schema_module.certify_family','if caught is None:']),
 ('normal callback UNKNOWN enters same retained prefix policy',["observe('normal_return_before_exact_'+name,callback_return,['EXACT_CALLBACK_EXCEPTION'])"]),
 ('invalid normal callback packet retained FAILED',["returned_packet=callback_return","'invalid_callback_fixture_return'"]),
 ('thrown sentinel identity exact',['except BaseException as e:','if e is not exact:raise','caught=e','good=caught is exact']),
 ('expected private quota UNKNOWN remains fixture success',["observe('private_work_budget'",'limits=dict(work=1)',"['UNKNOWN'])"]),
 ('complete repeated port tuple explicitly tested',["children[0]['input_sources']==[0,0]"]),
 ('derived assumptions not promoted',["if name=='derived_child_assumption':good=all(c['rule']!='assumption'or c['formula']!=B"]),
 ('final alias repair independently inspected',["p['tail_reification']is not None and p['result_row']==len(p['proof'])-1"]),
 ('independent primitive kernel-shape checks',["formulas[b]!=['imp',formulas[a],f]","f!=premises[index(c['index'],len(premises))]","formulas[-1]!=packet['conclusion']"]),
 ('both whole input snapshots unchanged',["if _bytes(supplied)!=before:raise ShadowDataError('qualification full supplied inputs changed')","if _bytes(supplied)!=before:raise ShadowDataError('qualification final full supplied inputs changed')"]),
 ('full partial arrays/coverage returned',['all_returned_component_packets=component_returns,prefix_stop=prefix_stop','families_returned=len(families)','ground_packets_returned=len(ground)','generic_inline_completed=len(inline)']),
 ('no schema Native Model permission',["native_accepted_by_schema=False,Model_permission=False,new_target_proof=False"]),
 ('complete malformed matrix and epoch/ownership fixtures',['bool_meta','out_of_range_meta','forward_MP','changed_MP_implication','changed_ordered_ground_premise','missing_dependency','cyclic_certificate','changed_ground_identity','changed_Source_epoch','changed_semantic_epoch','direct_returned_packet_mutation','fresh_after_mutation'])
]:check(label,all(s in text for s in parts))
check('full no clock/native/Model/search imports/calls',not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id in ('eval','exec','__import__','Model','Popen','run_receiver')for n in ast.walk(tree)))
check('exact public keyword ABI',[a.arg for a in newdefs['run_shadow'].args.kwonlyargs]==['schema_module','library','inventory','records','theory','source_epoch','semantic_epoch','source_guard','formula_validator','check'])
compile(raw,str(p),'exec',dont_inherit=True);check('compile only not evaluation',True)
folder=OUT/'shadow-V2-V3-inert';folder.mkdir();target=folder/'subject.txt';target.write_bytes(before);patches=[]
for direction,a,b in [('forward',before,raw),('inverse',raw,before)]:
    patch=folder/(direction+'.patch');patch.write_text(''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='subject.txt',tofile='subject.txt')))
    q=subprocess.run(['/usr/bin/patch','--batch','--fuzz=0','subject.txt','-i',str(patch)],cwd=folder,capture_output=True,text=True,timeout=10)
    check(direction+' actual inert zero-fuzz patch',q.returncode==0 and target.read_bytes()==b);patches.append(dict(direction=direction,patch=pin(patch),stdout=q.stdout,stderr=q.stderr))
audit=write(OUT/'shadow-raw-Source-audit-v3.json',dict(schema='mp-schema-shadow-independent-raw-audit-v3',source_only=True,scientific_calls=0,checks=checks,retained_helpers=retained,inert_patches=patches))
review=dict(schema='mp-schema-shadow-typed-Source-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',source=source,sources={'mp_schema_shadow':source},source_only=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,project_imports=0,fixture_calls=0,native_calls=0,model_calls=0,compiler_calls=0,solver_calls=0,search_calls=0,codec_calls=0,scope='Root wrapper V3 Source only against pre-frozen obligations; finite fixtures unexecuted and intake/plan review separate',independent_obligations=pin(OUT/'soundness-and-qualification-obligations-v1.json'),certificate_Source_review=pin(OUT/'typed-certificate-Source-review-v1.json'),preserved_negative_reviews=[pin(OUT/'typed-shadow-Source-review-v1-negative.json'),pin(OUT/'typed-shadow-Source-review-v2-negative.json')],check_count=len(checks),mismatch_count=0,compile_without_evaluation_count=1,inert_F0_patch_directions=2,audit=audit,review_Source=pin(Path(__file__)),findings=[dict(id='RETENTION_AND_UNKNOWN_REPAIRED',finding='Census/revalidation/generic/ground/fresh-mutation and every normal callback-fixture return are retained before status branching. Unexpected component UNKNOWN gets owner-scoped qualification UNKNOWN; other missing required result becomes a retained FAILED prefix. Exact thrown callback sentinel identity remains, and the separately expected private-quota UNKNOWN remains a successful fixture.'),dict(id='FINITE_CORRESPONDENCE_AND_NEGATIVES',finding='The wrapper joins the complete supplied current Native bulk request, retains the full library/registry, independently checks assumption/MP primitive expansions and explicitly checks repeated-port [0,0], derived-child assumption mapping and final-row reification. Fixed malformed/epoch/ownership/callback/quota fixture definitions are inspectable Source, not executed results.')],limitations=[
 'No wrapper/certifier/fixture or scientific module was imported/evaluated; one compile-only and two inert Source patch directions only. Source PASS is not runtime qualification, Native acceptance or kernel soundness.',
 'The caller must supply the full current original four-template policy and ten case001 definitions/interfaces/records from the freshly executed untouched base pipeline. The wrapper joins supplied Native records but is not a cryptographic independent Native attestation. Its standalone entry point does not establish original library/inventory completeness or hardcode the ten-count; final intake/plan/retained review must bind and check those facts.',
 'The cyclic_certificate fixture uses an actual cyclic Python container and tests literal-copy cycle rejection. It does not runtime-exercise the distinct family-ID dependency active-set guard; that guard is covered only by the separate certifier Source review.',
 'The fixed exact-callback fixtures cover the first authentic invoked callback and require exact exception-object identity, not arbitrary late interruptions/all interleavings. No fixture outcomes are claimed here. Thrown callbacks that never return cannot provide a returned packet snapshot.',
 'all_returned_component_packets is a stage evidence list: the same generic correspondence result is observed more than once and entries are not a unique module-call count. check_calls is a distinct charged callback counter, not Native microsteps or a proof complexity measure.',
 'Full input canonical copying/serialization and returned evidence remain charged to Root original absolute window and combined output cap. Private per-call or wrapper quota UNKNOWN grants no certificate/Model/Native permission. Unexpected normal statuses stop a retained prefix without pretending complete fixture coverage.',
 'Reviewer authored the obligations and inherited outer/earlier driver/current helper-symbolic components but did not author this Root wrapper or the Library certifier. This is distinct presentation/protocol Source review and relies on the separate genuine Library implementation review; no own inherited Source certification or new theorem/GCTS/RL claim.'
])
r=write(OUT/'typed-shadow-Source-review-v3.json',review)
print(json.dumps(dict(review=r,audit=audit,checks=len(checks)),indent=2))
