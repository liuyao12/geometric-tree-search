"""Retained ordinary JSON/raw-byte audit only; no scientific modules or replay."""
import collections,hashlib,json,math,stat
from pathlib import Path
OUT=Path('/private/tmp/gcts-mp-schema-peer-20261019');ROOT=Path('/private/tmp/gcts-mp-schema-shadow-ROOT-20261019');A=ROOT/'actual-v1'
checks=[];pins={};digests={};observations={}
def ck(name,v):
    checks.append(dict(check=name,passed=bool(v)))
    if not v:raise AssertionError(name)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(v):return hashlib.sha256(canonical(v)).hexdigest()
def rawpin(p):
    b=p.read_bytes();d=dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));pins[str(p)]=d;return d
def raw(d,label):
    ck(label+' exact raw descriptor',type(d)is dict and set(d)=={'path','sha256','bytes'}and type(d['bytes'])is int and d['bytes']>=0)
    p=Path(d['path']);ck(label+' nofollow canonical regular',p.is_absolute()and p==p.resolve()and stat.S_ISREG(p.lstat().st_mode)and not p.is_symlink());b=p.read_bytes();ck(label+' whole SHA/size',dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==d);pins[str(p)]=d;return b
def doc(p):return json.loads(p.read_bytes())
def checked(d,label):return json.loads(raw(d,label))
def write(p,v):
    with p.open('xb')as f:f.write((json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
    return rawpin(p)
def preimage(label,v):
    b=canonical(v);digests[label]=dict(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));return digests[label]
def contains(v,s):
    if v==s:return True
    if type(v)is dict:return any(contains(x,s)for x in v.values())
    if type(v)is list:return any(contains(x,s)for x in v)
    return False
ixd=dict(path=str(ROOT/'plans/authorized-index-v1.json'),sha256='3aec0042c73374883b0564445c5d24e729a294db23505b798466d5a81ce14eb5',bytes=6805)
ix=checked(ixd,'exact executed authorized index');slot=ix['schedule'][0];iid=slot['invocation_id']
plan=checked(slot['runner_plan'],'whole executed once plan');worker=checked(slot['worker_plan'],'whole worker plan');auth=checked(slot['authorization'],'whole true maxone grant')
closure=checked(ix['runtime_closure'],'whole runtime closure');decl=checked(ix['case_declaration'],'whole current declaration');policy=checked(worker['policy'],'original whole policy')
q=doc(A/'runner-receipt.json');w=doc(A/'worker-receipt.json');consumed=doc(A/'CONSUMED.json')
terminal_path=Path(slot['runner_plan']['path']).parent/(iid+'-terminal-observation')/'terminal.json';t=doc(terminal_path)
for p in (A/'runner-receipt.json',A/'worker-receipt.json',A/'CONSUMED.json',terminal_path,ROOT/'ROOT-cohort-closure-v1.json'):rawpin(p)
ck('one new exact iid and subject',ix['subject_count']==len(ix['schedule'])==1 and iid=='mp-schema-shadow-001-fixed-bulk-ROOT-20261019-v1'and slot['actual_directory']==str(A))
subject={k:v for k,v in plan.items()if k!='authorization'}
ck('full18 subject join grant/index/runner',len(subject)==18 and sha(subject)==slot['subject_sha256']==auth['subject_sha256']==q['subject_sha256']=='4c8b18798415d7952a945c26b58b94b82d0102aa37e5c1b7406f5b4dd0680047')
ck('strict true max1 original grant',auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['author_identity']=='/root')
ck('exact full runner/worker/consumed/observer descriptors',q['plan']==t['plan']==consumed['plan']==slot['runner_plan']and q['authorization']==slot['authorization']and w['worker_plan']==slot['worker_plan'])
ck('whole terminal-runner and runner-worker receipt raw joins',rawpin(A/'runner-receipt.json')==t['runner_receipt']and rawpin(A/'worker-receipt.json')==q['outputs']['worker_receipt']and q['worker_receipt']==w)
ck('exact five roles4receipts2reviewers retained',q['review_roles']==auth['review_roles']and set(q['review_roles'])=={'ordering_Source','registry_Source','composition_Source','once_Source','prospective_plans'}and len({v['receipt']['path']for v in q['review_roles'].values()})==4 and len({v['reviewer_identity']for v in q['review_roles'].values()})==2)
for role,b in auth['review_roles'].items():
    v=checked(b['receipt'],'actual exact scoped '+role)
    ck(role+' literal PASS/identity/no grant',v.get('source_review_passed',v.get('prospective_review_passed'))is True and v['reviewer_identity']==b['reviewer_identity']and v['author_identity']!=v['reviewer_identity']and v['scientific_calls']==0 and v['source_only']is True and v['actual_execution_authorized']is False)
    for d in b['required_subjects']:ck(role+' complete subject '+Path(d['path']).name,contains(v,d));raw(d,'current actual subject '+Path(d['path']).name)
ck('actual registry scope BOTH original Sources',auth['review_roles']['registry_Source']['required_subjects']==[worker['project_sources']['semantic_inventory_oracle'],worker['components']['receiver_driver']])
ck('composition current Source includes BOTH shadows',all(d in auth['review_roles']['composition_Source']['required_subjects']for d in ix['shadow_sources'].values()))
ck('exclusive once consumption and one launch metadata',consumed['consumed_before_Popen']is True and consumed['maximum_worker_launches']==1 and q['consumed_once']is True and q['worker_launch_attempts']==1 and rawpin(A/'CONSUMED.json')==q['consumed_marker'])
began=q['began_ns'];work=q['work_deadline_ns'];end=q['overall_deadline_ns']
ck('one exact Source-entry180/210 clock',began==w['began_ns']==consumed['began_ns']and work==w['work_deadline_ns']==consumed['work_deadline_ns']==began+180000000000 and end==w['overall_deadline_ns']==consumed['overall_deadline_ns']==began+210000000000)
ck('known worker exit and all checks/observer terminal in caps',began<w['driver_returned_ns']<=w['custody_checked_ns']<q['worker_terminal_observed_ns']<work and q['worker_terminal_observed_ns']<=q['postreap_group_and_pipe_closed_ns']<=q['checks_closed_ns']<=t['terminal_observed_ns']<end)
ck('all three authority tiers still Root-only',q['ROOT_resource_accepted']is False and q['mathematical_proof_accepted']is False and q['scientific_acceptance']is False and t['ROOT_resource_accepted']is False and t['mathematical_proof_accepted']is False)
ck('separate exact worker/runner exit0 and observer positive',q['python_exit_code']==0 and q['python_wait4_status']==0 and q['python_reaped']is True and t['runner_exit_code']==0 and t['terminal_gate_passed']is True and q['resource_candidate_accepted']is True and q['errors']==[])
ck('exact worker/native/runner IDs distinct',q['python_pid']==52072 and t['runner_pid']==52071 and q['native_transport']['native_pid']==52073 and len({q['python_pid'],t['runner_pid'],q['native_transport']['native_pid']})==3)
ck('original full instrument limits retained',q['limits']==plan['limits']and q['limits']['work_seconds']==180 and q['limits']['overall_seconds']==210 and q['limits']['aggregate_peak_bytes']==1073741824 and q['limits']['result_bytes']==134217728 and q['limits']['stdout_bytes']==q['limits']['stderr_bytes']==4194304)
ck('postreap group/EOF/permanent-veto positive',q['owned_pgid']==q['python_pid']and q['owned_group_absent']is True and q['owned_group_reappearance_observed_ns']is None and q['owned_group_probe_count']>=2 and q['owned_group_first_absent_ns']<=q['owned_group_last_probe_ns']<=q['checks_closed_ns']and q['stdout_eof']is True and q['stderr_eof']is True and q['log_capture_complete']is True and q['signals']==[])
for name in ('stdout','stderr'):
    d=q['outputs'][name];raw(d,name+' full raw logs');ck(name+' zero complete logs',d['bytes']==q[name+'_bytes']==0)
closed=doc(ROOT/'ROOT-cohort-closure-v1.json')
ck('Root separately observed final absent IDs retained',closed['all_workers_and_native_groups_closed']is True and closed['inspected_exact_pids']==[52072,52073,52071]and closed['remaining_processes']==''and closed['ps_return_code']==1)
raw_result=raw(q['outputs']['result'],'entire current base result');raw_shadow=raw(q['outputs']['schema_shadow'],'entire current sidecar')
r=json.loads(raw_result);s=json.loads(raw_shadow);out=r['outputs'];epoch=r['source_epoch'];native=r['transport_receipt'];sm=w['schema_shadow']
ck('whole two JSON bytes canonical without omission',canonical(r)+b'\n'==raw_result and canonical(s)+b'\n'==raw_shadow)
ck('full base result/sidecar worker descriptor joins',q['outputs']['result']==w['result'])
ck('driver whole base output pin joins',all(w['driver_output_receipt']['output'][k]==w['result'][k]for k in ('path','sha256','bytes'))and w['driver_output_receipt']['output']['complete']is True)
ck('whole combined cap and sidecar output pin',sm['output']==q['outputs']['schema_shadow']and sm['combined_result_bytes']==len(raw_result)+len(raw_shadow)==38029149 and sm['combined_result_bytes']<=134217728)
ck('before/after literal inverse raw body exact',w['result_reading']['roundtrip']==sm['post_shadow_literal']and sm['original_result_unchanged']is True and sm['post_shadow_literal']['literal_bytes_equal']is True and sm['post_shadow_literal']['body_bytes']==len(raw_result)-1 and sm['post_shadow_literal']['body_sha256']==hashlib.sha256(raw_result[:-1]).hexdigest())
ck('all charged result reading/Shadow/output and known exit under180',w['driver_returned_ns']<=w['result_reading']['started_ns']<=w['result_reading']['decoded_ns']<=w['result_reading']['completed_ns']<=sm['started_ns']<sm['completed_ns']<q['worker_terminal_observed_ns']<work)
ck('schema passed separate no Native Model target permission',sm['status']==s['status']=='SHADOW_QUALIFICATION_PASSED'and s['mode']==sm['mode']=='SHADOW_NO_ADMISSION_CHANGE'and all(s[k]is False and sm[k]is False for k in ('Model_permission','native_accepted_by_schema','new_target_proof'))and s['failures']==[]and s['prefix_stop']is None)
ck('native receipt exact through all4 output layers',native==w['native_transport']==w['driver_output_receipt']['transport_receipt']==q['native_transport'])
ck('exact Native child reaped normal with no buffered residue',native['closed']is True and native['all_reaped']is True and native['constructor_completed']is True and native['native_exit_code']==native['wait4_status']==0 and native['cleanup_errors']==native['termination_signals']==[]and native['stdout_eof']is True and native['stdout_pending_bytes']==0 and native['stderr_complete']is True and native['stderr_bytes']==0)
ck('Native exact owned worker processgroup',native['parent_pid']==native['parent_pgid']==native['native_pgid']==q['owned_pgid']and native['same_owned_process_group']is True and native['native_pid']!=native['parent_pid'])
ck('Native absolute deadlines same whole arm',math.isclose(native['work_deadline']*1e9,work,abs_tol=1)and math.isclose(native['closure_deadline']*1e9,end,abs_tol=1))
peak=q['python_wait4_usage']['ru_maxrss']+native['wait4_usage']['ru_maxrss']
ck('exact conservative separate Darwin highwater sum',native['native_high_water_bytes']==native['wait4_usage']['ru_maxrss']==13631488 and q['python_wait4_usage']['ru_maxrss']==737329152 and peak==q['conservative_parent_plus_native_peak_bytes']==750960640 and peak<=1073741824)
ck('peak units/policy honest',native['CPP_self_reported_peak_is_resource_authority']is False and q['live_group_memory_limit_claimed']is False and q['perprocess_peaks_may_doublecount_conservatively']is True)
ck('observer full exact command/runner pin',t['command']==[worker['python']['path'],'-I','-S','-B',ix['runner']['path'],slot['runner_plan']['path']]and t['plan']==slot['runner_plan'])
ck('computed terminal elapsed values match',math.isclose(t['runner_clock_elapsed_seconds'],(t['terminal_observed_ns']-began)/1e9,abs_tol=1e-9)and math.isclose(t['observed_instrument_elapsed_seconds'],(t['terminal_observed_ns']-t['observer_started_ns'])/1e9,abs_tol=1e-9))
ck('full base status no schema-tier relabel',r['status']==w['status']=='native_proof_discovered'and r['native_proof_accepted']is True and w['logical_proof_accepted']is True and r['ROOT_resource_accepted']is False and r['quantified_reasoning_success']is False and r['family_hint_success']is False)
for k in ('mode','inventory_certification_mode','search_ordering','receiver_id'):ck('actual arm literal '+k,r[k]==w[k]==q[k]==slot[k])
ck('full exact statement/closedness/current receiver selection',r['declaration']==decl['selected_receiver']==r['receiver_selection']['spec']and r['receiver_selection']==epoch['receiver_selection']and r['declaration']['length']==12 and r['declaration']['instantiation_rounds']==2 and r['declaration']['theory']['schemas']==[])
ck('exact Sourceepoch hash and original selected statement hash',sha(epoch)==w['source_epoch_sha256']and sha(r['receiver_selection'])==w['receiver_selection_sha256'])
base_aliases=dict(worker['project_sources'],semantic_receiver_driver=worker['components']['receiver_driver'],bounded_request_oracle=worker['components']['bounded_transport'])
ck('full base24 maps original exact closure',len(base_aliases)==24 and epoch['sources']['original']==closure['materialized_aliases']==base_aliases and set(epoch['sources']['project'])==set(base_aliases)and epoch['sources']['cold']==ix['cold'])
origins={v['module']:v['path']for v in w['import_origins']}
for name,d in base_aliases.items():
    owned=epoch['sources']['project'][name];raw(d,'original base Source '+name);raw(owned,'owned base Source '+name)
    ck(name+' owned bytes preserve original fullpreimage',owned['sha256']==d['sha256']and owned['bytes']==d['bytes']and owned['path']==str(A/'modules'/(name+'.py'))and origins[name]==owned['path'])
ck('shadow maps separate original/owned/kernel literal joined',epoch['shadow_sources']['original']==ix['shadow_sources']==sm['sources']['original']and epoch['shadow_sources']['owned']==sm['sources']['owned']and epoch['shadow_sources']['kernel_source']==sm['kernel_source']==ix['schema_kernel_source'])
for name,d in ix['shadow_sources'].items():
    od=sm['sources']['owned'][name];raw(d,'original shadow Source '+name);raw(od,'owned shadow Source '+name);ck(name+' exact owned origin',d['sha256']==od['sha256']and d['bytes']==od['bytes']and origins[name]==od['path'])
raw(ix['schema_kernel_source'],'historical semantic kernel raw only')
for d in worker['z3']['files']:raw(d,'full Z3raw '+Path(d['path']).name)
ck('all41 Z3 full runtime same original plan',epoch['z3']==worker['z3']and len(epoch['z3']['files'])==41)
ck('Python whole runtime and original declaration/policy exact',epoch['python']==w['python']==q['python_custody']['python']==worker['python']and epoch['policy']==worker['policy']and epoch['declaration']==worker['declaration'])
raw(worker['python'],'whole current Python executable');raw(ix['cold'],'whole current cold');raw(ix['runner'],'whole current outer');raw(ix['observer'],'whole current observer')
ck('outer stable nofollow metadata custody conditional flags',q['python_custody']['whole_baseline_authenticated']is True and q['python_custody']['trusted_OS_metadata_assumption']is True and q['python_custody']['formal_continuous_seal']is False and q['python_custody']['worker_callback_guard_claimed']is False)
for name,d in epoch['native_inputs'].items():raw(d,'Native raw only '+name)
ck('code fixed canonical bytes same prior known compiler input',epoch['native_inputs']['code_bin']['sha256']=='97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed')
role_names={'base_compiler':'quantified_receptors_v1','family_miner':'semantic_lemma_inventory','family_model':'interned_quantified_family_points_v1','family_registry':'semantic_inventory_oracle','family_search':'semantic_inventory_search_v2','point_smt':'semantic_point_smt','support_ordering':'receptor_support_ordering_v1','symbolic_control':'quantified_symbolic_control_v2'}
ck('all8 selected logicalroles exact owned map',r['module_pins']=={k:epoch['sources']['project'][v]for k,v in role_names.items()})
for receipt,role in [('selected_family_model','family_model'),('selected_search_module','family_search'),('support_ordering_module','support_ordering')]:
    name=role_names[role];ck('selected receipt exact original+owned '+receipt,w[receipt]['module']==name and w[receipt]['original']==base_aliases[name]and w[receipt]['owned']==r['module_pins'][role])
intervals=w['cold_stages'];ck('all109 returned cold stages charged',len(intervals)==109 and all(began<=v['started_ns']<=v['returned_ns']<work for v in intervals))
names=[v['stage']for v in intervals]
ck('26 exact copies/imports with Shadow before Native',sum(n.startswith('copy:')for n in names)==24 and sum(n.startswith('copy shadow:')for n in names)==2 and sum(n.startswith('import:')and n!='import:Z3'for n in names)==24 and sum(n.startswith('import shadow:')for n in names)==2 and names.index('import shadow:mp_schema_shadow_qualification')<names.index('native intake:boundary-oracle-v2'))

# Literal Native request/transport joins only, never native-machine evaluation.
records=r['records'];stages=native['request_stages'];ck('exact17 complete Native query records/stages',len(records)==len(stages)==native['complete_records']==17)
native_samples=[]
for j,(rec,st)in enumerate(zip(records,stages)):
    ck('Native '+str(j)+' full record index/hash/stage',rec['id']==st['record_id']==st['ordinal']==j and st['stage']=='COMPLETED'and rec['request_sha256']==st['request_sha256']==sha(rec['request'])and rec['input_sha256']==st['input_sha256']and rec['output_sha256']==st['output_sha256']and rec['purpose']==st['purpose'])
    ck('Native '+str(j)+' original full theory/protocol and finite machine metadata',rec['request']['theory']==r['declaration']['theory']and rec['request']['protocol']=='gcts-fol-1'and type(rec['result']['micro_steps'])is int and 0<=rec['result']['micro_steps']<=st['limit']and rec['result']['status']in ('accepted','rejected')and rec['result']['micro_fnv64'].isdigit())
    ck('Native '+str(j)+' original cap',st['limit']==(1000000000 if j<15 else 5000000000))
    native_samples.append(dict(id=j,purpose=rec['purpose'],request_sha256=rec['request_sha256'],input_sha256=rec['input_sha256'],output_sha256=rec['output_sha256'],status=rec['result']['status'],micro_steps=rec['result']['micro_steps'],limit=st['limit']))
ck('Native17 stage classes explicit no Shadow fixture queries',collections.Counter(x['purpose']for x in records)=={'first_order_theory_admission':1,'first_order_tautology':11,'first_order_scheme':3,'check_generated_lemma_definitions':1,'fresh_quantified_receiver_final':1})
compile_packet=out['compile'];taut=['imp',['bot'],['bot']]
ck('complete native-backed compile catalog not recreated',compile_packet['status']=='complete'and len(compile_packet['basis'])==11 and compile_packet['queries']==list(range(15))and compile_packet['theory_query']==0)
ck('native fulltheory admission literal request',records[0]['request']==dict(protocol='gcts-fol-1',theory=r['declaration']['theory'],blocks=[],proof=[dict(rule='tautology',formula=taut)],target=taut)and records[0]['result']['status']=='accepted')
for j,f in enumerate(compile_packet['basis'],1):ck('basis literal tautology request '+str(j),records[j]['request']==dict(protocol='gcts-fol-1',theory=r['declaration']['theory'],blocks=[],proof=[dict(rule='tautology',formula=f)],target=f))
for j,c in enumerate(compile_packet['catalog']['schemes'],12):ck('scheme literal Native request '+str(j),records[j]['request']==dict(protocol='gcts-fol-1',theory=r['declaration']['theory'],blocks=[],proof=[c],target=c['formula'])and records[j]['result']['status']=='accepted')
ck('compile exact15 stored join descriptors',all(v['literal_request_matched']is True and v['record_id']==i and v['request_sha256']==records[i]['request_sha256']and v['result_status']==records[i]['result']['status']for i,v in enumerate(out['compile_record_joins']['queries']))and len(out['compile_record_joins']['queries'])==15)
reg=out['register'];definitions=reg['definitions'];byname={d['name']:d for d in definitions}
ck('fresh full original10 definition/interface/native blocks preserved',reg['status']=='native_accepted'and len(definitions)==len(byname)==len(reg['interfaces'])==len(reg['native_blocks'])==10 and reg['native_blocks']==[v['definition']for v in definitions]and reg['interfaces']==[v['name']for v in definitions]and all(reg[k]==out['specialize'][k]for k in ('definitions','interfaces','native_blocks')))
bulk=records[15];bulk_expected=dict(protocol='gcts-fol-1',theory=r['declaration']['theory'],blocks=reg['native_blocks'],proof=[dict(rule='tautology',formula=taut)],target=taut)
ck('full fresh bulk actual request all10 not subset',reg['query']==15 and bulk['request']==bulk_expected and bulk['result']['status']=='accepted'and out['inventory_record_join']==dict(literal_request_matched=True,record_id=15,request_sha256=bulk['request_sha256'],result_status='accepted'))
for d in definitions:ck('original ground name/full binding ID '+d['name'],d['name']=='lemma'+sha(dict(family=d['family'],arguments=d['arguments']))and d['definition']['name']==d['name'])
final=out['final_request'];ck('fresh final17 literal full request/record join',out['final_native']==records[16]and records[16]['request']==final and records[16]['result']['status']=='accepted'and records[16]['purpose']=='fresh_quantified_receiver_final'and final['proof']==out['search']['proof']and final['target']==r['declaration']['target']and final['proof'][-1]['formula']==final['target'])
supplied={d['name']:d for d in final['blocks']};used={c['name']for c in final['proof']if c['rule']=='block'}
ck('final all-and-only actual2 called blocks original registry exact',len(supplied)==2 and used==set(supplied)and all(v==byname[n]['definition']for n,v in supplied.items())and not any(c['rule']=='block'for d in supplied.values()for c in d['proof']))
ck('root no openassumption commands/native originaltheory',not any(c['rule']=='assumption'for c in final['proof'])and final['theory']==r['declaration']['theory'])
for name,key in [('input.bin','input_sha256'),('output.bin','output_sha256')]:ck('last Native whole wire raw '+name,rawpin(A/'native'/name)['sha256']==records[16][key])

# Complete literal semantic preimages against the immutable prior control.
prior_path=ROOT/'prior-case001-fixed-bulk-result.json';prior_desc=dict(path=str(prior_path),sha256='4e02917b4dffec237fbb13f5cc6949c8da1cbed5976e41914cef466baf053184',bytes=36482958);prior=checked(prior_desc,'full prior case001 ordinary JSON')
parts={'compiler':{k:v for k,v in compile_packet.items()if k!='seconds'},'inventory':{k:reg[k]for k in ('definitions','interfaces','native_blocks')},'model':{k:v for k,v in out['model'].items()if k!='compile_seconds'},'initial_state':r['initial_state']}
old_parts={'compiler':{k:v for k,v in prior['outputs']['compile'].items()if k!='seconds'},'inventory':{k:prior['outputs']['register'][k]for k in ('definitions','interfaces','native_blocks')},'model':{k:v for k,v in prior['outputs']['model'].items()if k!='compile_seconds'},'initial_state':prior['initial_state']}
for name,v in parts.items():ck('entire current/prior literal semantic preimage '+name,v==old_parts[name]);preimage('complete_semantic_'+name,v)
ck('recorded semantic hashes independently match completepreimages',sha(parts['compiler'])==r['compiled_semantics_sha256']and sha(parts['inventory'])==r['inventory_semantics_sha256']and sha(parts['model'])==r['model_identity_sha256']==r['model_after_identity_sha256'])
ck('full prior exact proof/selected keys',out['search']['proof']==prior['outputs']['search']['proof']and out['search']['placements']==prior['outputs']['search']['placements'])

# Saved literal point union arithmetic, never calling Model/Graph/Reader/kernel.
model=out['model'];initial=r['initial_state'];search=out['search'];candidates={tuple(v['key']):v for v in model['placements']};selected=[tuple(v)for v in search['placements']]
ck('full candidate identity and60 distinct selected keys',len(candidates)==len(model['placements'])==10078 and len(selected)==len(set(selected))==60 and all(k in candidates for k in selected))
required={tuple(v)for v in model['roots']};totals={tuple(p):v for p,v in initial['totals']};marks={tuple(p):v for p,v in initial['marks']};slots={}
ck('required exact60 full roots/all initial allowed points',len(required)==len(model['roots'])==60 and required=={tuple(v)for v in initial['allowed_points']})
for key in selected:
    c=candidates[key];ck('selected exactsingle root occupancy '+str(key),c['occupancy']==[[[4*key[0],key[1]],12]]and key[:2]not in slots);slots[key[:2]]=c
    for p,v in c['occupancy']:
        k=tuple(p);totals[k]=totals.get(k,0)+v;ck('selected raw t-capacity '+str(key),k in required and type(v)is int and 0<v and totals[k]<=12)
    ck('selected complete assignedmark agreement '+str(key),all(tuple(p)not in marks or marks[tuple(p)]==v for p,v in c['marks']))
    for p,v in c['marks']:marks[tuple(p)]=v
ck('whole required target exact t-coverage',set(totals)==required and all(v==12 for v in totals.values())and len(slots)==12*(2+model['arity']))
for j,c in enumerate(search['proof']):
    row=[slots[j,k]for k in range(2+model['arity'])];command=dict(row[0]['command'])
    ck('actual full C/G row literal '+str(j),command==row[1]['command'])
    if command['rule']=='block':
        refs=[row[k+2]['source']for k in range(len(byname[command['name']]['definition']['premises']))];ck('actual ordered strict prior block refs '+str(j),all(type(v)is int and 0<=v<j for v in refs));command['inputs']=refs
    ck('exact selected row decoded Native command '+str(j),command==c)
union=dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected));union_sha=sha(union)
ck('independent raw union vs worker receipt',union_sha==w['final_region_verification']['union_sha256']and len(marks)==w['final_region_verification']['assigned_mark_points']==2192 and w['final_region_verification']['required_points']==60 and w['final_region_verification']['decoded_rows']==12 and w['final_region_verification']['selected_placements']==60)
preimage('whole_saved_point_union',union)
initial_sha=sha(initial);ck('initial full snapshot hash/root restoration receipt',search['root_restored']is True and r['root_restoration']['root_restored']is True and initial_sha==search['root_state_sha256']==r['root_restoration']['engine_root_sha256']==search['tree']['state_sha256'])
ck('current finite search retained counts',search['metrics']['attempts']==60 and search['metrics']['nodes']==61 and search['metrics']['forced']==48 and search['metrics']['branch']==12 and search['status']=='finite_marked_proof_region')

# Whole SHADOW input, certificates, ground packets and finite stage evidence.
snap=s['full_input_snapshot'];ck('entire Shadow originals full snapshots',snap['library']==policy['library']==r['policy']['library']and snap['inventory']==reg and snap['records']==records and snap['theory']==r['declaration']['theory']and s['complete_original_definitions']==definitions and s['complete_original_interfaces']==reg['interfaces'])
ck('fresh full Native bulk Shadow exact request',s['fresh_Native_bulk_record_id']==15 and s['fresh_Native_full_request']==bulk['request'])
ck('exact bounded coverage4/10/3/19 and42stage entries',s['coverage']==dict(families_returned=4,ground_packets_returned=10,generic_inline_completed=3,fixtures_returned=19)and len(s['family_census'])==4 and len(s['every_original_ground_definition'])==10 and len(s['generic_inline_cases'])==3 and len(s['fixtures'])==19 and len(s['all_returned_component_packets'])==42)
ck('whole input preserved/152950checks within2M',s['input_bytes_unchanged']is True and s['check_calls']==152950<s['maximum_check_calls']==decl['shadow_fixed_limits']['maximum_check_calls']==2000000)
source=snap['source_epoch'];semantic=snap['semantic_epoch']
ck('exact current Source/theory capsule',source['receiver_theory']==r['declaration']['theory']and source['cold']==ix['cold']and source['policy']==worker['policy']and source['checker']==dict(original=ix['shadow_sources']['mp_schema_certificate'],owned=sm['sources']['owned']['mp_schema_certificate'])and source['harness']==dict(original=ix['shadow_sources']['mp_schema_shadow_qualification'],owned=sm['sources']['owned']['mp_schema_shadow_qualification']))
ck('syntax Source capsule exact current owned/original logic+compiler',source['syntax_validator']==dict(original=base_aliases['logic'],owned=epoch['sources']['project']['logic'])and source['syntax_AST']==dict(original=base_aliases['quantified_receptors_v1'],owned=epoch['sources']['project']['quantified_receptors_v1']))
ck('semantic full raw kernel/program context',semantic['kernel_protocol']=='gcts-fol-1'and semantic['kernel_source']==ix['schema_kernel_source']and semantic['native_program_sha256']=='877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673')
familymap={f['id']:f for f in policy['library']};certs={};expected_stage={}
for f,row in zip(policy['library'],s['family_census']):
    fid=f['id'];p=row['result'];ck('full census exact policy family '+fid,row['family_id']==fid and p['input_snapshot']['family']==f and p['input_snapshot']['source_epoch']==source and p['input_snapshot']['semantic_epoch']==semantic)
    eligible=fid!='8a035116a4e2ca64655bef36a63030f6267acd58a97630881b6255b1e3a460d5';ck('exact narrow census disposition '+fid,p['status']==('ELIGIBLE_CERTIFICATE'if eligible else'NOT_ELIGIBLE'))
    expected_stage['original_family_fragment_disposition:'+fid]=p
    if eligible:
        c=p['certificate'];certs[fid]=c
        ck('complete certificate literal family/epochs/interface '+fid,c['family']==f and c['source_epoch']==source and c['semantic_epoch']==semantic and c['interface']==dict(premises=f['template']['premises'],conclusion=f['template']['conclusion'],ordered_ports=list(range(len(f['template']['premises'])))))
        ck('full dependency certificate membership/order '+fid,[d['family']['id']for d in c['dependency_certificates']]==f['dependencies']and all(d==certs[d['family']['id']]for d in c['dependency_certificates']))
        ck('all original schematic rows returned '+fid,len(c['derived_rows'])==len(f['template']['proof'])and all(d['row']==i and d['rule']==line['rule']and d['formula']==line['formula']for i,(d,line)in enumerate(zip(c['derived_rows'],f['template']['proof']))))
        for d,line in zip(c['derived_rows'],f['template']['proof']):
            if line['rule']=='assumption':ck('retained exact premise port '+fid+str(d['row']),d['evidence']==dict(premise_port=line['index']))
            elif line['rule']=='mp':ck('retained exact ordered MP refs '+fid+str(d['row']),d['evidence']==dict(antecedent_row=line['antecedent'],implication_row=line['implication']))
            elif line['rule']=='block':ck('retained exact ordered child references '+fid+str(d['row']),d['evidence']['family']==line['call']['family']and d['evidence']['arguments']==line['call']['arguments']and [v['source_row']for v in d['evidence']['ordered_ports']]==line['inputs'])
        rv=row['revalidation'];ck('full fresh literal certificate revalidation '+fid,rv['status']=='ELIGIBLE_CERTIFICATE'and rv['certificate']==c and rv['input_snapshot']['certificate']==c);expected_stage['family_full_revalidation:'+fid]=rv
    else:ck('GEN excluded from schema never removed from originalpolicy',p['certificate']is None and 'revalidation'not in row and any(line['rule']=='generalize'for line in f['template']['proof']))
ck('all3 eligible and1GEN census',len(certs)==3)
for item,d in zip(s['every_original_ground_definition'],definitions):
    name=d['name'];p=item['result'];g=p['ground_correspondence'];flat=g['primitive_expansion'];inp=p['input_snapshot']
    ck('exact10 returned ground name/full registry '+name,item['name']==name and p['status']=='GROUND_CORRESPONDENCE'and inp['ground_definition']==g['ground_definition']==d and inp['dependency_definitions']==definitions and inp['arguments']==g['arguments']==d['arguments'])
    ck('exact full current eligible ground cert '+name,p['certificate']==certs[d['family']]==inp['certificate']and g['root_name']==name and g['full_registry_preserved']is True)
    ck('all10 original singleton dependencyclosures '+name,g['original_ordered_closure']==[d])
    ck('full original Native primitive body exact '+name,flat['proof']==d['definition']['proof']and flat['premises']==d['definition']['premises']and flat['conclusion']==d['definition']['conclusion']and flat['result_row']==len(flat['proof'])-1 and flat['tail_reification']is None and flat['primitive_commands']==len(flat['proof'])and item['literal_primitive_body_equals_fresh_Native_block']is True)
    ck('finite independent primitive receipt exact literals '+name,item['independent_primitive_check']==dict(checked_from_entire_ordered_interface=True,last_formula=flat['proof'][-1]['formula'],rows=len(flat['proof'])))
    ck('all10 original frame remapping identity '+name,len(flat['frames'])==1 and flat['frames'][0]['name']==name and all(m['source_row']==m['primitive_row']==i and m['alias']is False for i,m in enumerate(flat['frames'][0]['row_mapping'])))
    expected_stage['ground_correspondence:'+name]=p
ck('ground body sizes six3/four5 all38rows',collections.Counter(len(x['result']['ground_correspondence']['primitive_expansion']['proof'])for x in s['every_original_ground_definition'])=={3:6,5:4})
generic={v['name']:v for v in s['generic_inline_cases']};ck('exact prospectively fixed3 generic cases',set(generic)=={'ordered_repeated_ports','derived_child_assumption','last_alias_after_unrelated'})
for name,v in generic.items():
    p=v['correspondence'];g=p['ground_correspondence'];flat=g['primitive_expansion']
    ck(name+' whole generic certificate/ground inputs retained',v['certificate_result']['status']=='ELIGIBLE_CERTIFICATE'and v['certificate_result']['certificate']['family']==v['family']and p['status']=='GROUND_CORRESPONDENCE'and p['input_snapshot']['ground_definition']==v['ground_root']and p['input_snapshot']['dependency_definitions']==v['full_registry']and g['ground_definition']==v['ground_root'])
    ck(name+' primitive final output and row count retained',flat['primitive_commands']==len(flat['proof'])and flat['result_row']==len(flat['proof'])-1 and flat['proof'][-1]['formula']==flat['conclusion'])
f=generic['ordered_repeated_ports']['correspondence']['ground_correspondence']['primitive_expansion'];ck('actual repeated child aliases exact ordered [0,0]',f['frames'][0]['input_sources']==[0,0]and f['frames'][0]['row_mapping']==[dict(alias=True,primitive_row=0,rule='assumption',source_row=0)]and len(f['proof'])==1)
f=generic['derived_child_assumption']['correspondence']['ground_correspondence']['primitive_expansion'];ck('actual child assumption aliases derived caller MP',f['frames'][0]['input_sources']==[2]and f['frames'][0]['row_mapping'][0]['primitive_row']==2 and f['frames'][0]['row_mapping'][0]['alias']is True and f['proof'][2]['rule']=='mp'and len(f['proof'])==3)
f=generic['last_alias_after_unrelated']['correspondence']['ground_correspondence']['primitive_expansion'];ck('actual generic finalalias reified exact justified command',f['tail_reification']==dict(appended_row=4,reason='kernel requires final literal formula to be target',source_row=2)and f['proof'][4]==f['proof'][2]and f['proof'][3]['formula']!=f['conclusion']and len(f['proof'])==5)
fixtures={f['name']:f for f in s['fixtures']};negative_names=['bool_meta','out_of_range_meta','forward_MP','changed_MP_implication','changed_ordered_ground_premise','missing_dependency','cyclic_certificate','changed_ground_identity']
ck('whole declared malformed8matrix no substitutedtests',s['fixed_malformed_matrix']==negative_names)
for name,v in fixtures.items():
    ck('finite fixture returned passed '+name,v['passed']is True)
    if 'result'in v:ck('finite fixture exact returned expectedstatus '+name,v['result']['status']in v['expected_statuses']);expected_stage[name]=v['result']
    else:ck('finite exact callback identity observation '+name,name in ('exact_source_guard_error','exact_check_error','exact_formula_validator_error')and v['exact_exception_object_propagated']is True)
for name in negative_names:ck('malformed exact negative status '+name,fixtures[name]['result']['status']==('NOT_ELIGIBLE'if name=='missing_dependency'else'REJECTED')and fixtures[name]['result']['certificate']is None and fixtures[name]['result']['ground_correspondence']is None)
for name in ('changed_Source_epoch','changed_semantic_epoch','direct_returned_packet_mutation'):ck('custody/actual returned-mutation rejection '+name,fixtures[name]['result']['status']=='REJECTED')
ck('fresh after directmutation matches pristine wholecertificate',fixtures['fresh_after_mutation']['result']['status']=='ELIGIBLE_CERTIFICATE'and fixtures['fresh_after_mutation']['result']['certificate']==s['family_census'][0]['result']['certificate'])
quota=fixtures['private_work_budget']['result'];ck('expected private quota1 UNKNOWN no partial authority',quota['status']=='UNKNOWN'and quota['reason']=='schema_work_budget'and quota['limits']['work']==1 and quota['counts']=={'work':1}and quota['certificate']is None and quota['ground_correspondence']is None and quota['input_snapshot']is None and quota['input_custody_complete']is False)
ck('cyclic fixture reports container not familyDAG cycle',fixtures['cyclic_certificate']['result']['reason']=='cyclic non-JSON input')
stagemap={v['stage']:v for v in s['all_returned_component_packets']};ck('all42 stage names unique though values mayrepeat',len(stagemap)==42)
for stage,p in expected_stage.items():ck('full returnedpacket preserved bystage '+stage,stage in stagemap and stagemap[stage]['result']==p)
for name,v in generic.items():
    ck('full generic cert+ground stage packets retained '+name,stagemap['generic_parent_certificate:'+name]['result']==v['certificate_result']and stagemap['generic_ground:'+name]['result']==v['correspondence'])
for stage,v in stagemap.items():
    p=v['result'];ck('stage status expected '+stage,p['status']in v['expected_statuses'])
    ck('stage all5 authority flagsfalse '+stage,all(p['authority'][k]is False for k in ('Model_permission','candidate_pruning','logical_target_proof_accepted','native_accepted','new_axiom')))
    if p['certificate']is not None:ck('stage certificate noNativepermission '+stage,all(p['certificate']['authority'][k]is False for k in ('Model_permission','candidate_pruning','logical_target_proof_accepted','native_accepted','new_axiom')))
ck('no discarded unexpected UNKNOWN in actual fullPASS',[(k,v['result']['status'])for k,v in stagemap.items()if v['result']['status']=='UNKNOWN']==[('private_work_budget','UNKNOWN')])
for name,v in [('family_census',s['family_census']),('ground_packets',s['every_original_ground_definition']),('generic_inline',s['generic_inline_cases']),('finite_fixtures',s['fixtures']),('all_component_stage_packets',s['all_returned_component_packets'])]:preimage('whole_'+name,v)
observations.update(status=r['status'],Shadow_status=s['status'],families=4,eligible_certificates=3,ineligible_GEN=1,original_ground_definitions=10,generic_inline_cases=3,fixtures=19,retained_stage_packets=42,Native_queries=17,Native_query_purposes=dict(collections.Counter(x['purpose']for x in records)),check_callbacks=s['check_calls'],model_candidates=len(candidates),selected_point_tiles=60,proof_rows=12,union_assigned_marks=len(marks),search_attempts=60,search_nodes=61,worker_elapsed_seconds=(q['worker_terminal_observed_ns']-began)/1e9,terminal_elapsed_seconds=t['runner_clock_elapsed_seconds'],observer_instrument_elapsed_seconds=t['observed_instrument_elapsed_seconds'],Shadow_elapsed_seconds=(sm['completed_ns']-sm['started_ns'])/1e9,worker_highwater_bytes=q['python_wait4_usage']['ru_maxrss'],native_highwater_bytes=native['native_high_water_bytes'],conservative_sum_bytes=peak,conservative_sum_MiB=peak/1048576,result_bytes=len(raw_result),sidecar_bytes=len(raw_shadow),combined_bytes=len(raw_result)+len(raw_shadow))
admission_desc=dict(path=str(ROOT/'ROOT-actual-admission-v1.json'),sha256='5f9a35737e2a4f13fd5196ecf8fbb2316f4664d922d0a924d6934bc37b8b9543',bytes=8712)
root_admission=checked(admission_desc,'Root separate saved-admission conclusion')
audit=write(OUT/'saved-evidence-audit-v1.json',dict(schema='mp-schema-shadow-independent-saved-evidence-audit-v1',saved_data_only=True,scientific_calls=0,checks=checks,verified_raw_descriptors=list(pins.values()),complete_preimage_hashes=digests,observations=observations,Native_record_stage_join_samples=native_samples,scoped_current_artifacts=dict(authorized_index=ixd,whole_result=q['outputs']['result'],whole_sidecar=q['outputs']['schema_shadow'],worker_receipt=q['outputs']['worker_receipt'],runner_receipt=t['runner_receipt'],terminal_observation=rawpin(terminal_path),Root_admission=admission_desc)))
review=dict(schema='mp-schema-shadow-saved-evidence-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',saved_evidence_review_passed=True,data_review_passed=True,resource_custody_review_passed=True,saved_data_only=True,source_only=False,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,project_imports=0,native_calls=0,model_calls=0,compiler_calls=0,kernel_calls=0,solver_calls=0,search_calls=0,Reader_calls=0,renderer_calls=0,fixture_calls=0,codec_calls=0,scope='Exact saved bytes, original/owned Source/runtime/once/resource custody and literal Native/point/SHADOW correspondence; no Native replay or independent kernel soundness theorem',authorized_index=ixd,worker_plan=slot['worker_plan'],once_plan=slot['runner_plan'],authorization=slot['authorization'],case_declaration=ix['case_declaration'],runtime_closure=ix['runtime_closure'],whole_result=q['outputs']['result'],whole_schema_shadow=q['outputs']['schema_shadow'],worker_receipt=q['outputs']['worker_receipt'],runner_receipt=t['runner_receipt'],terminal_observation=rawpin(terminal_path),cohort_closure=rawpin(ROOT/'ROOT-cohort-closure-v1.json'),Root_admission=admission_desc,prior_whole_case001_result=prior_desc,current_Source_subjects=dict(cold=ix['cold'],once=ix['runner'],observer=ix['observer'],base_driver=worker['components']['receiver_driver'],registry=worker['project_sources']['semantic_inventory_oracle'],**ix['shadow_sources']),independent_obligations=decl['shadow_obligations'],check_count=len(checks),mismatch_count=0,raw_pin_count=len(pins),observations=observations,complete_preimage_hashes=digests,audit=audit,review_Source=rawpin(Path(__file__)),findings=[
 dict(id='FULL_ORIGINAL_NATIVE_CONTROL',finding='All original4 policy families and10 exact ground definitions/interfaces/native blocks remain; current Native query15 contains the whole registry and full current theory. All17 Native request/preimage/input/output metadata join exact completed transport stages. Query16 is a distinct fresh final whole request, with the actual12-row selected word and all-and-only2 used original block definitions.'),
 dict(id='PRIOR_SEMANTIC_PREIMAGE_EQUALITY',finding='Complete compiler fields except explicit seconds, complete original registry definitions/interfaces/native blocks, every model field except compile_seconds and all initial-state fields are literal-equal to the immutable prior control. Full selected keys and proof word are also equal. This is direct full JSON comparison with retained preimage hashes, not digest-only equality or performance equivalence.'),
 dict(id='FINITE_SHADOW_SUCCESS',finding='Exact finite coverage4families/10ground/3generic/19fixtures,42 retained stage packets and152950 charged check callbacks. Three MP/call certificates revalidate; the GEN family is explicitly NOT_ELIGIBLE and kept in the original policy. All10 ground primitive words/interfaces are exactly the fresh full-Native registry bodies. Generic child aliases preserve repeated ordered [0,0], derived-MP source2, and exact final-result reification.'),
 dict(id='NEGATIVE_AND_OWNERSHIP_SCOPE',finding='Eight fixed malformed results, changed Source/semantic epochs, direct returned-packet mutation rejection/fresh recovery, three exact callback identity observations and private-work1 UNKNOWN are present. Only expected quota UNKNOWN occurs in the completed stage list. Cyclic fixture is specifically cyclic-container rejection and does not demonstrate family-ID DAG guard coverage. Error identity flags rely on exact reviewed fixture Source plus saved observation; they are not serialized exception objects.'),
 dict(id='POINT_AND_RESTORATION',finding='Literal saved union of60 original point tiles covers all60 required roots at exact encoded unit12 with all2192 assigned marks consistent; C/G/ordered source packets decode to the fresh Native word. Full initial snapshot hash matches recorded engine/root-restored fingerprints. Full literal post-rollback graph is not exported; no stronger all-state rollback or all-input oracle claim is made.'),
 dict(id='WHOLE_PROFILE_AND_CUSTODY',finding='Exact once subject/grant/max1/consumed/one launch/current24base+2Shadow originals/owned paths/import origins and all41Z3 raw pins join. Normal worker/Native/runner exit0, explicit wait4 receipts, EOF/log/group absence and no signals/reappearance are retained. Known worker exit49.411324958s, terminal50.890808958s; separate Darwin peaks737329152+13631488=750960640B,716.171875MiB. Both full outputs total38029149B; literal canonical bytes and before/after base-body checksum match.'),
 dict(id='NO_SCHEMA_PERMISSION',finding='Schema sidecar and all returned/certificate authority flags remain false. Original full Native admission, Model/search and final fresh Native gates precede Shadow. Shadow structural evidence has no Model permission, pruning, new axiom or target-proof authority; no schema bypass is activated.')],limitations=[
 'This is a retained ordinary JSON/raw-byte/stat/hash audit after the authoritative terminal window. No scientific project/Native/logic/kernel/Model/compiler/solver/search/Reader/renderer/fixture or codec function was imported or evaluated, and no proof or scientific experiment was replayed. Opaque native gzip/code/input/output were raw-hashed only. Literal saved point arithmetic and command/reference/preimage comparisons do not execute a mathematical kernel or Native program.',
 'Reviewer authored inherited outer/broker/earlier driver/current support helper+symbolic and prior benchmark/CASE/checker/diagnoses, and the predeclared schema obligation note; current Root intake/wrapper and Library certifier were separately Source-reviewed. This is independent of Root execution/admission and current component authors but is not a fresh independent Source certificate of inherited own components. Same reviewer covers several disclosed Source scopes; role labels are not distinct people.',
 'The conditional soundness argument remains human/unformalized and narrowly meta/imp assumption/MP/certified calls. Finite actual correspondence and three generic edge cases do not establish universal kernel correctness, all substitutions, all dependency DAGs, every malicious input, arbitrary callback interleaving or Source-to-historical-microcode compiler correctness. GEN/eigenvariable/binder templates remain noneligible and independently Native controlled.',
 'Callback identity is observed by the exact reviewed fixture at its reached authentic callback; JSON stores an identity assertion, not the live exception object. Cyclic-container fixture never reaches an active family-ID DAG cycle. Private quota UNKNOWN has no input-custody completion or partial certificate; normal UNKNOWN-prefix and thrown-stop retention behavior follows Source review but was not exercised by this all-positive cohort beyond the declared quota fixture.',
 'Original result unchanged means its complete bytes and literal preimage were unchanged before/after Shadow in this new run. Its Source epoch and timing metadata differ from old results; only the explicit complete semantic projections and literal proof/selected keys are directly equal to the old control. Stage packets can repeat one returned generic result and are not unique module-call counts.',
 'Native input/output hash joins establish exact saved request/transport custody, not independent decoding of binary tape or fresh mathematical rechecking. The final input/output files retain only the last query; earlier hashes survive in exact matching per-record/per-stage metadata. No earlier raw wire image is invented. Final proof uses2 of10 definitions but full10 were freshly admitted before Model.',
 'Resource gate is the original Source-entry180positive work/output/known worker exit and210external terminal, conservative sum of separate Darwin worker+Native highwaters1GiB, combined128MiB result and original log/native/search caps. This is not simultaneous live RAM or OS enforcement. Observer/controller RAM and pre-Source-entry observer/interpreter prelude are separate. Full initial/Python/Source custody uses trusted OS metadata/captured-callable/loader assumptions, not formal continuous sealing or arbitrary mutable-data defense.',
 'Current normal aggregate-profile pass follows the reviewed final outer whole-Python/Source raw loop; older/memory-failed diagnostics that skip that loop are not upgraded. Final process absence is retained Root ps metadata and once group probes, not a new live process probe by this reviewer. Synchronous filesystem blocking and loader/OS trust limits remain.',
 'This is a familiar case001 qualification, not a new theorem, broad benchmark, automatic schema extraction proof, speed advantage, statistical result, GCTS-specific superiority or RL. All original actuals remain immutable; no new grant/launch/retry or schema-only admission is authorized. Root scientific/publication/goal classification remains separate.'
])
rp=write(OUT/'peer-saved-evidence-review-v1.json',review)
hp=write(OUT/'saved-evidence-peer-handoff-v1.json',dict(schema='mp-schema-shadow-saved-evidence-peer-handoff-v1',reviewer_identity='/root/conventional_control_review',saved_data_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=rp,audit=audit,whole_result=q['outputs']['result'],whole_sidecar=q['outputs']['schema_shadow']))
print(json.dumps(dict(review=rp,audit=audit,handoff=hp,checks=len(checks),raw_pins=len(pins),observations=observations),indent=2))
