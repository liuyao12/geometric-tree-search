**Fresh native proof-fixture API, version 1**

Status: **Source only, unexecuted**. The factory module is inert on import; scientific modules, compilation, kernel checks and classification run only when Root invokes `prepare()` after reviewing the Source. Static AST parsing is the only validation performed by its author before handoff.

The fixtures are anchored symbolic point-proof trees, not literal Wang-grid tilings. They exercise a finite first-order fragment, not unrestricted first-order completeness or an RL advantage. No expected derivation or selected output proof is supplied to the solver.

**Declared theory and targets**

`declarations()` returns six declarative records, one for each target/bound pair. Each record has fresh deterministic alphanumeric names derived from the fixture namespace and case ID. It uses one constant, four unary predicate symbols, and one variable used only by a vacuous universal goal. There is no geometric interpretation.

Writing the freshly renamed symbols schematically as \(c,P,Q,U,G,x\), the hypotheses are

\[
P(c),\quad P(c),\quad P(c)\to Q(c),\quad Q(c)\to G(c),\quad
U(c)\to G(c),\quad U(c)\to U(c),\quad Q(c)\to Q(c).
\]

The duplicated initial fact has two distinct axiom names and therefore two distinct native `ZERO` producer IDs. It supports a disconnected point-consistency mutation without planting a target proof. Targets are \(G(c)\), \(U(c)\), and \(\forall x\,P(c)\), each at maximum native address depth \(2\) and \(3\). The universal goal adds a genuine unary `GEN` producer, while its body and all hypotheses remain ground. The chain, unsupported cycle, alternate premise and padding are declared syntax, not cached proofs.

The pinned finite-basis compiler uses no instantiation rounds, no original equality templates and one original term. Its only intended `ZERO` lines are the seven named hypotheses and equality reflexivity for the constant. The module independently reconstructs and checks that entire intended zero set, all structural `MP`/`GEN` indices and all definition descriptors.

**Public functions**

| Function | Return and use |
| --- | --- |
| `declarations()` | Detached syntax-only declarations; no outcomes or proof IDs |
| `prepare()` | `{status:'PREPARED',cases:[...],acquisition:{...}}`; eighteen cases across `BASE`, `MARKS`, `FILTER` |
| `make_provider(case)` | Fresh `(model,provider,factory)` per solver run; must equal the prepared model. `FILTER` has explicit inventory and `provider=None` |
| `check_solution(case,result)` | Only actual solver-selected IDs. For `SAT`, join point consistency, rooted decoding, independent tree verification, the pinned symbolic FOL kernel, and a separately authored direct fragment kernel. For `UNSAT`/`UNKNOWN`, return `NOT_APPLICABLE` rather than calling a missing proof invalid |
| `exhaustive_proof_sets(case)` | Separate post-search reference enumeration of **every** rooted bounded producer tree, then complete root point/mark checking; returns canonical sorted CID arrays and a complete-set digest. No first witness is selected or supplied to the solver |
| `disconnected_mutant(case,actual_selected)` | Given an actual complete solver witness, add two distinct same-output zero producers at an unused nonroot site. Return the selected mutation, `point_consistency` receipt and `native_rejection` receipt; require point consistency and rooted native rejection |
| `ground_kernel(theory,proof,target)` | Independently authored direct AST checker for axiom, reflexivity, `MP` and vacuous `GEN` in this fixture fragment |
| `theory_reader(declaration)` / `proof_reader(declaration,proof)` | Readable hypotheses/conclusion or actual native proof lines; no search or expected-proof construction |
| `source_pins()` | Validate and return the eight exact copied dependency pins |

Each prepared case contains `id`, `base_id`, `goal_label` (`G`, `U`, `forall-P`), `mode`, `declaration`, `compiled`, `generation`, `depth`, `model`, `provider`, `factory`, `factory_model`, `factory_check`, `definitions`, `universe`, `universe_sha256`, `failure_certificate`, `acquisition_id` and `reader`.

`provider` is the only non-JSON case field. Persist `{k:v for k,v in case.items() if k!='provider'}` and the complete acquisition object before solver execution. The driver must persist raw model, full universe, observations and solver result before fallible graph/native assurance. A later assurance failure must not cause an earlier search to be silently repeated.

**Independent joins and universe**

The original `indexed_proof_provider_v1.py` is copied unchanged. Its catalogue version remains `Z-ANCHORED-PROOF-PRODUCER-v1`; `IP-CURRENT-TM-INCIDENT-v1` is its incident-query ABI, not a conflicting factory version. `prepare()` requires the actual result of the unchanged `growing_proof_verifier_v2.verify_factory` to be `VERIFIED`. It does not edit receipt counts or version strings to obtain a pass.

Every native zero line is separately checked as a one-line proof by the pinned `independent_fol_checker_v1.check`. The new direct fragment kernel uses separately written literal AST checks and strict prior references for the actual decoded proof. No separate unavailable C1 checker is claimed.

The full finite universe is authored independently from definition descriptors, literal formula colors and binary address depth, without a provider call or provider placement helper. For every admitted address and definition, it builds the own point and required child points, exact unit contributions, literal formula marks and CID. Nonleaf producers at the maximum depth are excluded. All rows are sorted by CID and the factory refuses a universe of \(2000\) or more rows. This includes nonroot rows that can participate in disconnected point-consistent nonproofs; native validity additionally requires a rooted proof tree.

Factory verification binds `factory_model`, the original unmarked model. `MARKS` and `FILTER` are subsequent separately identified adaptations; the original factory receipt is not misrepresented as verifying their changed models.

**Three controls and preservation**

- `BASE`: unchanged indexed provider and original full universe.
- `MARKS`: unchanged failure-marking adapter with every original CID retained and its extra literal premise-port assignments. Requested certified absences alone seed string `"0"`; premise ports assign string `"1"`. The independent marked checker validates the exact marked model and **every** reconstructed decorated row. Missing is unconstrained; zero is assigned.
- `FILTER`: fresh explicit, statically reduced inventory containing precisely original rows whose premise/remaining-height pairs are not in the checked negative requests. It uses `provider=None`, so no original-potential-count packet is relabeled as a filtered one. This is a proved-redundant restricted-inventory control, not pure marking agreement in the original inventory and not the old wrapper's `FILTER` packet convention.

Classification requests come from all distinct native premise IDs and remaining heights below the root bound. They are frozen from syntax before labeling. There is no top-level goal/height request and no imported failure table. The unchanged bounded classifier runs during preparation; its full classifications, work/cost, absence DAG, independent absence receipt and native-zero checks are retained as acquisition evidence. Positive preprocessing witnesses are evidence only and are not target solver inputs or a chosen target derivation. All this preprocessing cost must be reported.

`exhaustive_proof_sets` enumerates all producer alternatives and Cartesian products of child proof sets independently of the solver and provider. Complete point/mark testing happens **only after the whole root tree is assembled**, not on isolated subtrees with an unfilled global root. Root compares the complete rooted CID sets across all three modes at the same theory and bound. Equality of those sets is a result to be checked at runtime, not a supplied outcome. Enumeration exceeding the explicit work/output cap returns `UNKNOWN` with no truncated preservation claim.

**Human reader**

`check_solution(...)["proof_reader"]` contains rows

```json
{
  "line": "one-based integer",
  "formula": "actual decoded native AST",
  "formula_latex": "LaTeX source without display delimiters",
  "english": "direct reading of that formula",
  "rule": "actual native rule",
  "dependencies": "one-based prior-line numbers",
  "reason": "human explanation of that actual inference"
}
```

The web renderer must typeset `formula_latex` with its established math renderer. English predicate descriptions are a legend for uninterpreted symbols, not extra logical premises. Generalization is explained using the absence of the variable from the closed ground hypotheses. Reader lines are generated from the solver's actual decoded and checked proof, not a hand-authored proof outline.

**Copied dependencies and exact pins**

All copies reside in `reference/upstream/` and come from the unchanged sibling `gcts-failure-markings-20261103-v1`. No old run was edited. The old `proof_core_v1` module is used only for path-independent catalogue/meter functions; its archived path-based loader and I/O functions are not called. Temporary dependency import aliases are restored after lazy loading.

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `finite_basis_v1.py` | 14044 | `97225dcffd98dd5386aeb560a2fc5634dfcc4606ff475a46536207768932a0dc` |
| `proof_core_v1.py` | 5508 | `d363b72e6f4355225d3dbbdc66c64f746d27bf96de5c4d8a17471cc95b70091c` |
| `failure_markings_v1.py` | 7268 | `4b0f735c6a1114925fd1032c2a5cba37bffa61f447a0b71e1aaea8bf8e09a529` |
| `failure_certificate_checker_v1.py` | 12386 | `2436cc872737f9400c7bbb78949a366919a64804ca3088be1577fcdc7c7e88db` |
| `marked_point_checker_v1.py` | 15781 | `513ac4c616a2db3154c79156f40807228c9a667f601230a35330673d3105aa26` |
| `indexed_proof_provider_v1.py` | 26917 | `5261bf552924105f3c9ac3a4e9ddce0490869105b1812a8d897610267623b26e` |
| `growing_proof_verifier_v2.py` | 69970 | `6286d6b151d460e6ee0b97983fd9f081168a6d76256a33c3e0f9ead0ffae3aa1` |
| `independent_fol_checker_v1.py` | 21560 | `099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1` |
