"""Independent finite producer-absence certificates; inert stdlib-only Source.

No search, classifier, marking adapter or logical kernel is imported. Native
ZERO lines require separate current kernel audits. Internal negative DAG nodes
are evidence lemmas; only certificate.requests are classified query samples.
"""
import hashlib
import json

VERSION = 'FM-INDEPENDENT-ABSENCE-CHECKER-v1'
DEPTH_SEMANTICS = 'FM-rooted-tree-height-v1'
CAPS = {'formulas':16000, 'definitions':200000, 'nodes':200000,
        'requests':200000, 'remaining':32, 'AST_depth':64,
        'json_nodes':5000000, 'string_units':67108864}
ZERO_RULES = frozenset(('axiom','instantiate','refl','tautology','eq_subst','distribute'))


class InputError(ValueError):
    pass


class ResourceLimit(InputError):
    pass


def _need(condition, reason):
    if not condition:
        raise InputError(reason)


def _limit(condition, reason):
    if not condition:
        raise ResourceLimit(reason)


def _fields(value, names, reason):
    _need(type(value) is dict and all(type(key) is str for key in value)
          and set(value) == set(names), reason)


def _text(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)


def _sha(value):
    return hashlib.sha256((_text(value)+'\n').encode('ascii')).hexdigest()


def _guard(value):
    stack, active, nodes, units = [(value,0,False)], set(), 0, 0
    while stack:
        item, depth, leaving = stack.pop()
        if leaving:
            active.remove(id(item)); continue
        nodes += 1
        _limit(nodes+len(stack)<=CAPS['json_nodes'] and depth<=192,'JSON_RESOURCE_BOUND')
        kind = type(item)
        if kind is str:
            units += len(item); _limit(units<=CAPS['string_units'],'STRING_RESOURCE_BOUND')
        elif kind is int:
            _limit(item.bit_length()<=256,'INTEGER_RESOURCE_BOUND')
        elif item is None:
            pass
        else:
            _need(kind in (list,dict) and id(item) not in active,'NATIVE_JSON_TYPE_OR_CYCLE')
            _limit(nodes+len(stack)+1+len(item)*(2 if kind is dict else 1)<=CAPS['json_nodes'],'JSON_RESOURCE_BOUND')
            active.add(id(item));stack.append((item,depth,True))
            if kind is dict:
                _need(all(type(key) is str for key in item),'NATIVE_JSON_KEYS')
                for key, child in item.items():
                    stack.append((key,depth+1,False));stack.append((child,depth+1,False))
            else:
                stack.extend((child,depth+1,False) for child in item)


def _name(value):
    _need(type(value) is str and 1<=len(value)<=64
          and all(32<=ord(char)<=126 for char in value),'SYMBOL_NAME')
    return value


def _term(value, functions, depth):
    _limit(depth<=CAPS['AST_depth'],'AST_RESOURCE_BOUND')
    _need(type(value) is list and bool(value) and type(value[0]) is str,'TERM')
    if value[0]=='var' and len(value)==2:
        return {_name(value[1])}
    _need(value[0]=='fun' and len(value)==3,'TERM_SHAPE')
    name, args = _name(value[1]), value[2]
    _need(type(args) is list and name in functions and len(args)==functions[name],'FUNCTION_ARITY')
    return set().union(*(_term(child,functions,depth+1) for child in args))


def _formula(value, functions, predicates, depth=0):
    _limit(depth<=CAPS['AST_depth'],'AST_RESOURCE_BOUND')
    _need(type(value) is list and bool(value) and type(value[0]) is str,'FORMULA')
    tag=value[0]
    if tag=='bot' and len(value)==1:
        return set()
    if tag=='eq' and len(value)==3:
        return _term(value[1],functions,depth+1)|_term(value[2],functions,depth+1)
    if tag=='pred' and len(value)==3:
        name,args=_name(value[1]),value[2]
        _need(type(args) is list and name in predicates and len(args)==predicates[name],'PREDICATE_ARITY')
        return set().union(*(_term(child,functions,depth+1) for child in args))
    if tag=='all' and len(value)==3:
        return _formula(value[2],functions,predicates,depth+1)-{_name(value[1])}
    if tag=='not' and len(value)==2:
        return _formula(value[1],functions,predicates,depth+1)
    _need(tag in ('imp','and','or') and len(value)==3,'FORMULA_SHAPE')
    return _formula(value[1],functions,predicates,depth+1)|_formula(value[2],functions,predicates,depth+1)


def _catalogue(compiled):
    _fields(compiled,('schema','version','theory','goal','goal_id','profile','logical_basis',
                     'zero_instances','mp_index','gen_index','costs','scope'),'COMPILED_FIELDS')
    _need(compiled['schema']=='V-interned-Hilbert8-basis-v1'
          and compiled['version']=='V-INTERNED-FINITE-HILBERT8-v1','COMPILED_IDENTITY')
    basis=compiled['logical_basis']
    _fields(basis,('instantiation_terms','terms','variables','formulas','colors','templates','hole','stages'),'BASIS_FIELDS')
    payload={'schema':'FM-native-producer-scope-v1','depth_semantics':DEPTH_SEMANTICS,
             'compiled_schema':compiled['schema'],'compiled_version':compiled['version'],
             'theory':compiled['theory'],'registry':{'formulas':basis['formulas'],'colors':basis['colors']},
             'zero_instances':compiled['zero_instances'],'mp_index':compiled['mp_index'],'gen_index':compiled['gen_index']}
    _guard(payload)
    theory=compiled['theory'];_fields(theory,('functions','predicates','axioms'),'THEORY_FIELDS')
    for signature in (theory['functions'],theory['predicates']):
        _need(type(signature) is dict,'SIGNATURE')
        for name, arity in signature.items():
            _name(name);_need(type(arity) is int and arity>=0,'SIGNATURE_ARITY')
    _need(type(theory['axioms']) is dict,'AXIOMS')
    for name, formula in theory['axioms'].items():
        _name(name);_need(not _formula(formula,theory['functions'],theory['predicates']),'OPEN_GAMMA')
    forms, colors=basis['formulas'],basis['colors']
    _need(type(forms) is list and type(colors) is list and len(forms)==len(colors),'FORMULAS_COLORS')
    _limit(len(forms)<=CAPS['formulas'],'FORMULA_RESOURCE_BOUND')
    for formula in forms:
        _formula(formula,theory['functions'],theory['predicates'])
    _need(all(type(color) is str and color==_text(formula) for color,formula in zip(colors,forms)),'LITERAL_FORMULA_COLORS')
    _need(colors==sorted(colors) and len(set(colors))==len(colors),'FORMULA_REGISTRY_ORDER')
    _guard(compiled['goal'])
    goal=compiled['goal_id']
    _need(type(goal) is int and 0<=goal<len(forms) and _text(compiled['goal'])==colors[goal],'GOAL_BINDING')
    by_color={color:i for i,color in enumerate(colors)}
    mp,gen=[],[]
    for i,formula in enumerate(forms):
        if formula[0]=='imp':
            a,b=by_color.get(_text(formula[1])),by_color.get(_text(formula[2]))
            if a is not None and b is not None:
                mp.append([i,a,b])
        if formula[0]=='all':
            body=by_color.get(_text(formula[2]))
            if body is not None:
                gen.append([i,body,formula[1]])
    _need(type(compiled['mp_index']) is list and type(compiled['gen_index']) is list
          and _text(mp)==_text(compiled['mp_index']) and _text(gen)==_text(compiled['gen_index']),'COMPLETE_TYPED_MP_GEN_INDICES')
    zeros=compiled['zero_instances'];_need(type(zeros) is list,'ZERO_INSTANCES')
    _limit(len(zeros)+len(mp)+len(gen)<=CAPS['definitions'],'DEFINITION_RESOURCE_BOUND')
    producers=[{} for _ in forms]
    for i,zero in enumerate(zeros):
        _fields(zero,('id','rule','formula_id','line'),'ZERO_FIELDS')
        fid,rule,line=zero['formula_id'],zero['rule'],zero['line']
        _need(type(zero['id']) is str and zero['id']=='i'+str(i) and type(rule) is str
              and rule in ZERO_RULES and type(fid) is int and 0<=fid<len(forms) and type(line) is dict,'ZERO_BINDING')
        _need(line.get('rule')==rule and _text(line.get('formula'))==colors[fid],'ZERO_LINE_BINDING')
        producers[fid][_text(['zero',zero['id']])]=()
    for head,a,out in mp:
        producers[out][_text(['mp',head,a,out])]=(a,head)
    for head,body,variable in gen:
        producers[head][_text(['gen',head,body,variable])]=(body,)
    return payload,producers


def scope_payload(compiled):
    """Validated exact scope; returns a detached native-JSON payload."""
    payload,_=_catalogue(compiled)
    return json.loads(_text(payload))


def scope_sha256(compiled):
    """Canonical sorted-key ASCII JSON plus one LF, SHA256."""
    payload,_=_catalogue(compiled)
    return _sha(payload)


def _key(value, count):
    _need(type(value) is list and len(value)==2,'REQUEST_PAIR')
    fid,remaining=value
    _need(type(fid) is int and 0<=fid<count,'FID')
    _need(type(remaining) is int and remaining>=0,'REMAINING_TYPE_OR_RANGE')
    _limit(remaining<=CAPS['remaining'],'REMAINING_RESOURCE_BOUND')
    return fid,remaining


def verify(compiled, certificate):
    """Certify only the declared negative requests in a finite producer model."""
    try:
        _fields(certificate,('version','scope_sha256','requests','nodes'),'CERTIFICATE_FIELDS')
        _need(type(certificate['version']) is str and certificate['version']=='FM-bounded-absence-v1','CERTIFICATE_VERSION')
        _need(type(certificate['requests']) is list and type(certificate['nodes']) is list,'CERTIFICATE_ARRAYS')
        _limit(len(certificate['requests'])<=CAPS['requests'] and len(certificate['nodes'])<=CAPS['nodes'],'CERTIFICATE_RESOURCE_BOUND')
        payload,producers=_catalogue(compiled);scope=_sha(payload)
        _need(type(certificate['scope_sha256']) is str and certificate['scope_sha256']==scope,'SCOPE_HASH_MISMATCH')
        _guard(certificate)
        requests=[_key(pair,len(producers)) for pair in certificate['requests']]
        _need(len(set(requests))==len(requests),'DUPLICATE_REQUEST')
        table={}
        for node in certificate['nodes']:
            _fields(node,('fid','remaining','blockers'),'NEGATIVE_NODE_FIELDS')
            key=_key([node['fid'],node['remaining']],len(producers))
            _need(key not in table,'DUPLICATE_NEGATIVE_NODE')
            _need(type(node['blockers']) is list,'BLOCKER_LIST')
            table[key]=node['blockers']
        _need(all(key in table for key in requests),'MISSING_NEGATIVE_REQUEST_NODE')
        blockers_checked=0
        for (fid,remaining),blockers in table.items():
            domain=producers[fid];seen=set()
            _need(len(blockers)==len(domain),'COMPLETE_PRODUCER_COVERAGE_COUNT')
            for row in blockers:
                _need(type(row) is list and len(row)==2 and type(row[0]) is str,'BLOCKER_ROW')
                identity,index=row
                _need(identity in domain and identity not in seen,'COMPLETE_PRODUCER_IDENTITIES')
                seen.add(identity);premises=domain[identity]
                _need(bool(premises),'ZERO_WITNESS_EXISTS')
                if remaining==0:
                    _need(index is None,'DEPTH_ZERO_BLOCKER_MUST_BE_NULL')
                else:
                    _need(type(index) is int and 0<=index<len(premises),'PREMISE_INDEX')
                    _need((premises[index],remaining-1) in table,'MISSING_STRICTLY_LOWER_NEGATIVE_DEPENDENCY')
                blockers_checked+=1
            _need(seen==set(domain),'COMPLETE_PRODUCER_COVERAGE')
        keys=sorted(table)
        return {'status':'VERIFIED','reason':'COMPLETE_BOUNDED_PRODUCER_ABSENCE_DAG','version':VERSION,
                'scope_sha256':scope,'certificate_sha256':_sha(certificate),
                'negative_requests':[[fid,r] for fid,r in requests],
                'checked_nodes':[[fid,r] for fid,r in keys],
                'request_count':len(requests),'checked_node_count':len(table),'blockers_checked':blockers_checked,
                'formula_count':len(producers),'definition_count':sum(len(domain) for domain in producers),
                'depth_semantics':DEPTH_SEMANTICS,
                'scope':'No producer proof of height at most remaining for each requested FID, conditional on separately native-kernel-audited ZERO lines. Internal DAG nodes are evidence lemmas, not extra classification samples. No unbounded non-theorem or decorated m-value transformation is checked.'}
    except ResourceLimit as error:
        return {'status':'UNKNOWN','reason':str(error),'version':VERSION}
    except InputError as error:
        return {'status':'REJECTED','reason':str(error),'version':VERSION}
