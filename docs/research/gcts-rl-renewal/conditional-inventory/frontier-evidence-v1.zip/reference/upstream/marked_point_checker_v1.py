"""Independent MARKS adapter checks; inert Source, no search or adapter import.

The public scope function belongs to the separate independent absence checker.
It validates/binds the original catalogue, not the truth of requested negatives.
Negative certificates and native ZERO truth are separate required assurances.
This module rebuilds its own producers, placements, incident packets and replay.
"""
import hashlib
import json
from failure_certificate_checker_v1 import scope_sha256 as _validated_scope

VERSION = 'FM-INDEPENDENT-MARKED-POINT-CHECKER-v1'
DEFAULT_WORK = 100000000


class _Limit(ValueError):
    pass


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def _text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _same(a, b):
    """Typed native JSON equality: neither True==1 nor 1.0==1 is exact."""
    return _text(a) == _text(b)


def _sha(value):
    return hashlib.sha256((_text(value)+'\n').encode('ascii')).hexdigest()


def _fields(value, names, reason):
    _need(type(value) is dict and all(type(k) is str for k in value)
          and set(value) == set(names), reason)


class _Meter:
    def __init__(self, maximum):
        _need(type(maximum) is int and maximum >= 0, 'WORK_LIMIT')
        self.maximum, self.work = maximum, 0
    def tick(self, count=1):
        self.work += count
        if self.work > self.maximum:
            raise _Limit('WORK_LIMIT')


def _guard(value, meter):
    """Bound native JSON traversal/serialization; do not normalize types."""
    stack, active = [(value, 0, False)], set()
    while stack:
        item, depth, leaving = stack.pop()
        if leaving:
            active.remove(id(item))
            continue
        meter.tick()
        if depth > 192:
            raise _Limit('JSON_DEPTH')
        kind = type(item)
        if kind is str:
            meter.tick(12*len(item))
        elif kind is int:
            if item.bit_length() > 256:
                raise _Limit('INTEGER_SIZE')
        elif kind is bool or item is None:
            pass
        else:
            _need(kind in (list, dict) and id(item) not in active, 'NATIVE_JSON_TYPE_OR_CYCLE')
            meter.tick(len(item))
            active.add(id(item)); stack.append((item, depth, True))
            if kind is dict:
                _need(all(type(k) is str for k in item), 'JSON_KEYS')
                for k, v in item.items():
                    stack.append((k, depth+1, False)); stack.append((v, depth+1, False))
            else:
                stack.extend((v, depth+1, False) for v in item)


class Checker:
    def __init__(self, compiled, H, scope_sha256, negative_requests):
        _need(type(H) is int and 0 <= H <= 256, 'DEPTH')
        _need(type(scope_sha256) is str and len(scope_sha256) == 64
              and all(c in '0123456789abcdef' for c in scope_sha256), 'SCOPE_HASH')
        _need(_validated_scope(compiled) == scope_sha256, 'SCOPE_BINDING')
        self.H, self.scope = H, scope_sha256
        self.colors = tuple(compiled['logical_basis']['colors'])
        self.goal = compiled['goal_id']
        # Independent derivation from the complete current formula registry.
        forms = compiled['logical_basis']['formulas']
        by_color = {value: i for i, value in enumerate(self.colors)}
        self.defs = {}
        for zero in compiled['zero_instances']:
            self.defs[_text(['zero', zero['id']])] = (zero['formula_id'], ())
        for fid, form in enumerate(forms):
            if form[0] == 'imp':
                a, b = by_color.get(_text(form[1])), by_color.get(_text(form[2]))
                if a is not None and b is not None:
                    self.defs[_text(['mp', fid, a, b])] = (b, (a, fid))
            elif form[0] == 'all':
                body = by_color.get(_text(form[2]))
                if body is not None:
                    self.defs[_text(['gen', fid, body, form[1]])] = (fid, (body,))
        self.ordered = tuple(sorted(self.defs))
        _need(type(negative_requests) is list, 'NEGATIVE_REQUESTS')
        if len(negative_requests) > 200000:
            raise ValueError('REQUEST_RESOURCE_BOUND')
        requests = []
        for pair in negative_requests:
            _need(type(pair) is list and len(pair) == 2, 'NEGATIVE_REQUEST_PAIR')
            fid, remaining = pair
            _need(type(fid) is int and 0 <= fid < len(self.colors), 'NEGATIVE_FID')
            _need(type(remaining) is int and 0 <= remaining <= 256, 'NEGATIVE_REMAINING')
            requests.append((fid, remaining))
        _need(len(set(requests)) == len(requests), 'DUPLICATE_NEGATIVE_REQUEST')
        self.requests = tuple(sorted(requests))
        self.seed_marks = dict([['', self.colors[self.goal]]] +
                               [[self.port(fid, r), '0'] for fid, r in self.requests])
        self.identity = self.model_version = None

    def port(self, fid, remaining):
        return _text(['FM-port-v1', self.scope, fid, remaining])

    def _site(self, site):
        _need(type(site) is str and len(site) <= self.H
              and all(c in '01' for c in site), 'SITE')
        return site

    def _decode(self, cid, meter):
        _need(type(cid) is str, 'CID_TYPE'); meter.tick(12*len(cid)+1)
        pair = json.loads(cid)
        _need(type(pair) is list and len(pair) == 2, 'CID_SHAPE')
        site, did = pair
        self._site(site)
        _need(type(did) is str and did in self.defs and _text(pair) == cid, 'CID_BINDING')
        _, premises = self.defs[did]
        _need(not premises or len(site) < self.H, 'PRODUCER_DEPTH')
        return site, did

    def _row(self, site, did, meter):
        meter.tick(8+len(site)+len(did))
        output, premises = self.defs[did]
        points = [site] + [site+str(i) for i in range(len(premises))]
        marks = dict(zip(points, [self.colors[f] for f in (output,)+premises]))
        for fid in premises:
            marks[self.port(fid, self.H-len(site)-1)] = '1'
        return {'id': _text([site, did]), 't': [[p, 1] for p in points],
                'm': [[p, v] for p, v in sorted(marks.items())]}

    def placement(self, cid):
        """Return a detached exact decorated row; malformed input raises ValueError."""
        meter = _Meter(DEFAULT_WORK)
        site, did = self._decode(cid, meter)
        return self._row(site, did, meter)

    def _model(self, model, meter):
        _guard(model, meter)
        _fields(model, ('schema', 'version', 'capacity', 'roots', 'seed', 'inventory'), 'MODEL_FIELDS')
        _need(type(model['version']) is str, 'MODEL_VERSION')
        inventory = model['inventory']
        _fields(inventory, ('kind', 'identity'), 'INVENTORY_FIELDS')
        _need(type(inventory['identity']) is str, 'INVENTORY_IDENTITY_TYPE')
        expected = {'schema': 'Z-growing-point-model-v1', 'version': model['version'],
                    'capacity': 2, 'roots': [''],
                    'seed': {'t': [['', 1]], 'm': [[p, v] for p, v in sorted(self.seed_marks.items())]},
                    'inventory': {'kind': 'CERTIFIED_INCIDENT', 'identity': inventory['identity']}}
        _need(_same(model, expected), 'EXACT_MARKED_MODEL')
        if self.identity is not None:
            _need(inventory['identity'] == self.identity and model['version'] == self.model_version,
                  'MODEL_IDENTITY_CHANGED')
        self.identity, self.model_version = inventory['identity'], model['version']
        return {'seed_mark_points': len(self.seed_marks), 'negative_requests': len(self.requests),
                'definitions': len(self.defs), 'model_sha256': _sha(model)}

    def _run(self, operation, maximum):
        meter = None
        try:
            meter = _Meter(maximum)
            value = operation(meter)
            return dict(status='VERIFIED', reason='EXACT_MARKED_POINT_CHECK', version=VERSION,
                        work=meter.work, scope_sha256=self.scope, **value)
        except _Limit as error:
            return dict(status='UNKNOWN', reason=str(error), version=VERSION,
                        work=meter.work if meter else 0)
        except (ValueError, TypeError, KeyError, IndexError, RecursionError) as error:
            return dict(status='REJECTED', reason=str(error), version=VERSION,
                        work=meter.work if meter else 0)

    def check_model(self, model, *, max_work=DEFAULT_WORK):
        """Bind the opaque inventory identity; its derivation is checked externally."""
        return self._run(lambda m: self._model(model, m), max_work)

    def _query(self, query, reply, meter):
        _need(self.identity is not None, 'CHECK_MODEL_FIRST')
        _guard(query, meter); _guard(reply, meter)
        _fields(query, ('schema', 'inventory_identity', 'point', 'capacity', 'totals', 'marks'), 'QUERY_FIELDS')
        _need(query['schema'] == 'IP-current-tm-incident-query-v1'
              and type(query['schema']) is str and type(query['capacity']) is int
              and query['capacity'] == 2 and type(query['inventory_identity']) is str
              and query['inventory_identity'] == self.identity, 'QUERY_BINDING')
        point = self._site(query['point']); tables = []
        for field in ('totals', 'marks'):
            rows = query[field]; _need(type(rows) is list, 'CONTEXT_ROWS')
            table, previous = {}, None
            for row in rows:
                meter.tick()
                _need(type(row) is list and len(row) == 2 and type(row[0]) is str, 'CONTEXT_ROW')
                key, value = row
                _need(previous is None or previous < key, 'CONTEXT_ORDER_OR_DUPLICATE')
                if field == 'totals':
                    _need(type(value) is int and 0 <= value <= 2, 'CONTEXT_TOTAL')
                else:
                    _need(type(value) is str, 'CONTEXT_MARK')
                table[key] = value; previous = key
            tables.append(table)
        totals, marks = tables
        result, potential = [], 0
        # Enumerate every own and every parent-role alignment. No failure mask.
        anchors = [(point, None)] + ([(point[:-1], int(point[-1]))] if point else [])
        for site, role in anchors:
            for did in self.ordered:
                meter.tick(); _, premises = self.defs[did]
                if premises and len(site) >= self.H:
                    continue
                if role is not None and role >= len(premises):
                    continue
                potential += 1
                row = self._row(site, did, meter)
                if any(totals.get(p, 0)+n > 2 for p, n in row['t']):
                    continue
                if any(p in marks and marks[p] != value for p, value in row['m']):
                    continue
                result.append(row)
        result.sort(key=lambda row: row['id'])
        expected = {'point': point, 'context_sha256': _sha(query), 'complete': True,
                    'placements': result,
                    'certificate': {'scope': 'COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',
                                    'potential_count': potential, 'compatible_count': len(result)}}
        # Charge expected row serialization, including long formula/port strings.
        _guard(expected, meter)
        _need(_same(reply, expected), 'EXACT_COMPLETE_INCIDENT_PACKET')
        return {'potential_count': potential, 'compatible_count': len(result),
                'returned_count': len(reply['placements']), 'context_sha256': expected['context_sha256']}

    def verify_query(self, query, reply, *, max_work=DEFAULT_WORK):
        """Exhaustive packet check; selected/excluded state is outside this ABI."""
        return self._run(lambda m: self._query(query, reply, m), max_work)

    def _partial(self, model, selected, new_rows, meter):
        counts = self._model(model, meter)
        _guard(selected, meter); _guard(new_rows, meter)
        _need(type(selected) is list and type(new_rows) is list, 'PARTIAL_ARRAYS')
        totals, marks, seen = {'': 1}, dict(self.seed_marks), set()
        for is_new, items in ((False, selected), (True, new_rows)):
            for item in items:
                if is_new:
                    _fields(item, ('id', 't', 'm'), 'PARTIAL_PLACEMENT_FIELDS')
                    cid = item['id']
                else:
                    cid = item
                site, did = self._decode(cid, meter)
                _need(cid not in seen, 'PARTIAL_DUPLICATE_PLACEMENT'); seen.add(cid)
                row = self._row(site, did, meter)
                if is_new:
                    _need(_same(item, row), 'EXACT_PARTIAL_PLACEMENT')
                for p, n in row['t']:
                    meter.tick(); totals[p] = totals.get(p, 0)+n
                    _need(totals[p] <= 2, 'T_CAPACITY_OVERFLOW')
                for p, value in row['m']:
                    meter.tick(1+len(p)+len(value))
                    _need(p not in marks or marks[p] == value, 'MARK_DISAGREEMENT')
                    marks[p] = value
        counts.update(selected_count=len(selected), new_placements=len(new_rows),
                      positive_support_points=len(totals), assigned_mark_points=len(marks),
                      totals_sha256=_sha(sorted(totals.items())), marks_sha256=_sha(sorted(marks.items())))
        return counts

    def verify_partial(self, model, selected, new_rows, *, max_work=DEFAULT_WORK):
        """Exact rows and joint partial t/m only; no attachment/completion claim."""
        return self._run(lambda m: self._partial(model, selected, new_rows, m), max_work)

    def _solution(self, model, selected, meter):
        counts = self._model(model, meter)
        _guard(selected, meter); _need(type(selected) is list, 'SELECTED_LIST')
        _need(all(type(cid) is str for cid in selected) and len(set(selected)) == len(selected),
              'SELECTED_DUPLICATE_OR_TYPE')
        totals, marks, refs, nodes = {'': 1}, dict(self.seed_marks), {p: 1 for p in self.seed_marks}, {}
        for cid in selected:
            site, did = self._decode(cid, meter)
            _need(site not in nodes, 'MULTIPLE_PRODUCERS_AT_SITE'); nodes[site] = did
            row = self._row(site, did, meter)
            for p, n in row['t']:
                meter.tick(); totals[p] = totals.get(p, 0)+n
                _need(totals[p] <= 2, 'T_CAPACITY_OVERFLOW')
            for p, value in row['m']:
                meter.tick(1+len(p)+len(value))
                _need(p not in marks or marks[p] == value, 'MARK_DISAGREEMENT')
                marks[p] = value; refs[p] = refs.get(p, 0)+1
        _need(bool(nodes) and '' in nodes, 'ROOT_PRODUCER_MISSING')
        _need(all(value == 2 for value in totals.values()), 'INCOMPLETE_POSITIVE_SUPPORT')
        reached, stack = set(), ['']
        while stack:
            site = stack.pop(); meter.tick()
            _need(site in nodes and site not in reached, 'MISSING_OR_REPEATED_SUBTREE')
            reached.add(site)
            stack.extend(site+str(i) for i in range(len(self.defs[nodes[site]][1])))
        _need(reached == set(nodes), 'DISCONNECTED_SELECTED_COMPONENT')
        counts.update(selected_count=len(selected), positive_support_points=len(totals),
                      assigned_mark_points=len(marks), maximum_mark_references=max(refs.values()),
                      totals_sha256=_sha(sorted(totals.items())), marks_sha256=_sha(sorted(marks.items())))
        return counts

    def verify_solution(self, model, selected, *, max_work=DEFAULT_WORK):
        """Exact rooted point replay; separate native checking proves logic truth."""
        return self._run(lambda m: self._solution(model, selected, m), max_work)
