"""Generic RF-v1 finite native-FOL basis, in the unchanged V/Y carriers.

No search, proof path, learned-family admission or external module execution.
Term/context universes are frozen from original problem syntax. Resource refusal
raises BasisLimit with status UNKNOWN; it never returns a truncated catalogue.
"""
import copy
import hashlib
import json
import time

VERSION = 'RF-original-context-finite-basis-v1'


def text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256((text(value) + '\n').encode('ascii')).hexdigest()


class BasisLimit(RuntimeError):
    status = 'UNKNOWN'

    def __init__(self, reason, counts):
        self.reason, self.counts = reason, dict(counts)
        super().__init__(reason)

    def receipt(self):
        return dict(status=self.status, reason=self.reason, counts=self.counts,
                    scope='Resource refusal; no partial basis or nonprovability claim.')


class Capture(ValueError):
    pass


def _need(condition, message):
    if not condition:
        raise ValueError(message)


def free_term(term):
    return {term[1]} if term[0] == 'var' else set().union(*(free_term(a) for a in term[2]))


def free(form):
    tag = form[0]
    if tag == 'all':
        return free(form[2]) - {form[1]}
    if tag in ('imp', 'and', 'or'):
        return free(form[1]) | free(form[2])
    if tag == 'not':
        return free(form[1])
    if tag == 'eq':
        return free_term(form[1]) | free_term(form[2])
    return set().union(*(free_term(t) for t in form[2])) if tag == 'pred' else set()


def substitute(form, variable, term):
    """Literal free-for substitution; capture is omitted, never alpha-renamed."""
    def st(t):
        if t[0] == 'var':
            return copy.deepcopy(term) if t[1] == variable else list(t)
        return ['fun', t[1], [st(a) for a in t[2]]]
    tag = form[0]
    if tag == 'all':
        if form[1] == variable:
            return copy.deepcopy(form)
        if variable in free(form[2]) and form[1] in free_term(term):
            raise Capture('Term not free for this variable at encountered binder.')
        return ['all', form[1], substitute(form[2], variable, term)]
    if tag in ('imp', 'and', 'or'):
        return [tag, substitute(form[1], variable, term), substitute(form[2], variable, term)]
    if tag == 'not':
        return ['not', substitute(form[1], variable, term)]
    if tag == 'eq':
        return ['eq', st(form[1]), st(form[2])]
    if tag == 'pred':
        return ['pred', form[1], [st(t) for t in form[2]]]
    _need(tag == 'bot', 'Unsupported formula tag')
    return ['bot']


def collect_terms(value, found):
    tag = value[0]
    if tag in ('var', 'fun'):
        found[text(value)] = copy.deepcopy(value)
        if tag == 'fun':
            for child in value[2]:
                collect_terms(child, found)
    elif tag in ('eq', 'imp', 'and', 'or'):
        collect_terms(value[1], found)
        collect_terms(value[2], found)
    elif tag == 'all':
        collect_terms(value[2], found)
    elif tag == 'not':
        collect_terms(value[1], found)
    elif tag == 'pred':
        for term in value[2]:
            collect_terms(term, found)
    else:
        _need(tag == 'bot', 'Unsupported syntax while collecting terms')


def variables(value):
    tag = value[0]
    if tag == 'var':
        return {value[1]}
    if tag in ('fun', 'pred'):
        return set().union(*(variables(c) for c in value[2]))
    if tag == 'all':
        return {value[1]} | variables(value[2])
    if tag in ('eq', 'imp', 'and', 'or'):
        return variables(value[1]) | variables(value[2])
    return variables(value[1]) if tag == 'not' else set()


def _equations(form):
    if form[0] == 'eq':
        yield form
    elif form[0] in ('imp', 'and', 'or'):
        yield from _equations(form[1])
        yield from _equations(form[2])
    elif form[0] == 'all':
        yield from _equations(form[2])
    elif form[0] == 'not':
        yield from _equations(form[1])


def _term_paths(term, path):
    yield path
    if term[0] == 'fun':
        for i, child in enumerate(term[2]):
            yield from _term_paths(child, path + (2, i))


def _contexts(sources, hole):
    templates, equations, raw = {}, {}, 0
    for source in sources:
        for equation in _equations(source):
            equations[text(equation)] = equation
            for side in (1, 2):
                for path in _term_paths(equation[side], (side,)):
                    raw += 1
                    template = copy.deepcopy(equation)
                    cursor = template
                    for index in path[:-1]:
                        cursor = cursor[index]
                    cursor[path[-1]] = ['var', hole]
                    templates[text(template)] = template
    return [templates[k] for k in sorted(templates)], raw, [equations[k] for k in sorted(equations)]


def compile_case(case):
    """Return (compiled,generation), complete for this frozen finite profile.

    case.problem={theory:{functions,predicates,axioms},goal}; case.terms extends
    the original subterm pool. Optional case.instantiation_terms restricts only
    UI's frozen substitution pool, not equality/reflexivity's original pool.
    """
    started = time.perf_counter()
    theory = copy.deepcopy(case['problem']['theory'])
    goal = copy.deepcopy(case['problem']['goal'])
    _need(set(theory) == {'functions', 'predicates', 'axioms'}, 'Exact native theory fields required')
    _need(all(not free(f) for f in theory['axioms'].values()), 'Closed Gamma required for GEN')
    requested = copy.deepcopy(case.get('profile', {}))
    rounds = requested.get('ui_rounds', case.get('ui_rounds', 1))
    _need(type(rounds) is int and rounds >= 0, 'Nonnegative native UI rounds required')
    limit = requested.get('max_definitions', 8000)
    _need(type(limit) is int and 1 <= limit <= 8000, 'Definition resource cap must be at most8000')
    term_limit, template_limit = requested.get('max_terms', 20), requested.get('max_templates', 24)
    _need(type(term_limit) is int and term_limit >= 1 and type(template_limit) is int and template_limit >= 0,
          'Native term/template resource caps required')
    sources = [theory['axioms'][n] for n in sorted(theory['axioms'])] + [goal]
    fixed = {}
    for form in sources:
        collect_terms(form, fixed)
    for term in case.get('terms', []):
        _need(term[0] in ('var', 'fun'), 'Declared case.terms must contain terms')
        collect_terms(term, fixed)
    terms = [fixed[k] for k in sorted(fixed)]
    if len(terms) > term_limit:
        raise BasisLimit('MAX_FIXED_TERMS', dict(terms=len(terms), limit=term_limit))
    if 'instantiation_terms' in case:
        ui = {text(t): copy.deepcopy(t) for t in case['instantiation_terms']}
        _need(all(k in fixed for k in ui), 'Explicit UI terms must belong to original fixed pool')
        ui_terms = [ui[k] for k in sorted(ui)]
    else:
        ui_terms = copy.deepcopy(terms)
    names = set().union(*(variables(f) for f in sources + terms))
    hole = '__rf_hole'
    while hole in names:
        hole += '_'
    templates, raw_templates, source_equations = _contexts(sources, hole)
    if len(templates) > template_limit:
        raise BasisLimit('MAX_ORIGINAL_EQ_TEMPLATES', dict(raw=raw_templates,
                         deduplicated=len(templates), limit=template_limit))
    pool, zeros = {}, {}
    counters = dict(mp=0, gen=0, capture_omissions=0, ui_attempts=0,
                    equality_term_instances=0, equality_retained_pairs=0)

    def resource(stage):
        count = len(zeros) + counters['mp'] + counters['gen']
        if count > limit:
            raise BasisLimit('MAX_DEFINITIONS', dict(stage=stage, definitions=count,
                zeros=len(zeros), mp=counters['mp'], gen=counters['gen'], limit=limit,
                elapsed_seconds=time.perf_counter() - started))

    def add(form):
        key = text(form)
        if key in pool:
            return
        pool[key] = copy.deepcopy(form)
        tag = form[0]
        if tag in ('imp', 'and', 'or'):
            counters['mp'] += int(tag == 'imp')
            add(form[1]); add(form[2])
        elif tag == 'all':
            counters['gen'] += 1
            add(form[2])
        elif tag == 'not':
            add(form[1])
        resource('formula_closure')

    def zero(line):
        key = text(line)
        if key not in zeros:
            add(line['formula'])
            zeros[key] = copy.deepcopy(line)
            resource('zero_instance')

    add(goal)
    for name in sorted(theory['axioms']):
        zero(dict(rule='axiom', name=name, formula=theory['axioms'][name]))
    for term in terms:
        zero(dict(rule='refl', formula=['eq', term, term]))
    stages = [dict(stage='frozen_original_inputs', fixed_terms=len(terms), ui_terms=len(ui_terms),
                   raw_eq_templates=raw_templates, eq_templates=len(templates),
                   source_equations=source_equations)]
    for round_index in range(rounds):
        universals = [pool[k] for k in sorted(pool) if pool[k][0] == 'all']
        before = len(zeros)
        omitted_before = counters['capture_omissions']
        for universal in universals:
            for term in ui_terms:
                counters['ui_attempts'] += 1
                try:
                    instance = substitute(universal[2], universal[1], term)
                except Capture:
                    counters['capture_omissions'] += 1
                    continue
                zero(dict(rule='instantiate', universal=universal, term=term,
                          formula=['imp', universal, instance]))
        stages.append(dict(stage='ui', round=round_index + 1, universals=len(universals),
                           new_zero_instances=len(zeros) - before,
                           capture_omissions=counters['capture_omissions'] - omitted_before))
        if len(zeros) == before:
            break  # Exact fixed point: further identical rounds add nothing.
    for template in templates:
        retained = []
        for term in terms:
            result = substitute(template, hole, term)
            result_terms = {}
            collect_terms(result, result_terms)
            if set(result_terms).issubset(fixed):
                retained.append((term, result))
        counters['equality_term_instances'] += len(retained)
        # Output-term retention factorizes into two independent term tests.
        # This product is exactly all ordered pairs passing the stated filter.
        for left, antecedent in retained:
            for right, consequent in retained:
                counters['equality_retained_pairs'] += 1
                zero(dict(rule='eq_subst', variable=hole, template=template,
                          left=left, right=right,
                          formula=['imp', ['eq', left, right],
                                   ['imp', antecedent, consequent]]))
    colors = sorted(pool)
    forms, ids = [pool[k] for k in colors], {k: i for i, k in enumerate(colors)}
    native_zeros = [zeros[k] for k in sorted(zeros)]
    mp, gen = [], []
    for i, form in enumerate(forms):
        if form[0] == 'imp':
            mp.append([i, ids[text(form[1])], ids[text(form[2])]])
        elif form[0] == 'all':
            gen.append([i, ids[text(form[2])], form[1]])
    resource('complete_basis')
    profile = dict(requested, ui_rounds=rounds, bridge_arity=0, max_tautology_atoms=0,
        max_definitions=limit, max_terms=term_limit, max_templates=template_limit,
        fixed_term_count=len(terms), ui_term_count=len(ui_terms),
        ui_pool='explicit-case-instantiation-terms' if 'instantiation_terms' in case else 'original-fixed-terms',
        eq_context_scope='Every EQ occurrence in original theory/goal only; each individual term occurrence replaced by one fresh hole.',
        raw_eq_template_count=raw_templates, eq_template_count=len(templates),
        unique_source_equations=len(source_equations),
        eq_pairs_before_output_filter=len(templates) * len(terms) ** 2,
        eq_retained_pairs=counters['equality_retained_pairs'],
        term_scope='All original theory/goal/declared-term subterms, frozen before UI. UI output terms do not enlarge this pool.',
        definition_count=len(native_zeros) + len(mp) + len(gen))
    stages.append(dict(stage='native_equality', reflexivity_instances=len(terms),
                       retained_ordered_pairs=counters['equality_retained_pairs']))
    scope = 'RF-frozen-original-term/UI/original-EQ-context basis; complete native ZERO/MP/GEN within this explicit basis, not unbounded FOL completeness.'
    compiled = dict(schema='V-interned-Hilbert8-basis-v1', version='V-INTERNED-FINITE-HILBERT8-v1',
        theory=theory, goal=goal, goal_id=ids[text(goal)], profile=profile,
        logical_basis=dict(instantiation_terms=ui_terms, terms=terms,
            variables=sorted(names | {hole}), formulas=forms, colors=colors,
            templates=templates, hole=hole, stages=stages),
        zero_instances=[dict(id='i' + str(i), rule=z['rule'], formula_id=ids[text(z['formula'])], line=z)
                        for i, z in enumerate(native_zeros)],
        mp_index=mp, gen_index=gen,
        costs=dict(seconds=time.perf_counter() - started, formulas=len(forms),
                   instances=len(native_zeros), definitions=len(native_zeros) + len(mp) + len(gen),
                   fixed_terms=len(terms), raw_eq_templates=raw_templates,
                   eq_templates=len(templates), **counters), scope=scope)
    generation = dict(schema='Y-goal-receptor-universe-v1', version='Y-GOAL-RECEPTOR-FAMILY-v1',
        profile=copy.deepcopy(profile),
        compiled_core_sha256=digest({k: v for k, v in compiled.items() if k not in ('costs', 'scope')}),
        core_stages=[], core_assertions=[], goal_receptors=[], bridge_premises=[], scope=scope)
    return compiled, generation
