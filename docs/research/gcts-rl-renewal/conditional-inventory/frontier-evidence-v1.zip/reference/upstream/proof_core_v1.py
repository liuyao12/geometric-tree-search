"""Pinned finite point-proof dependencies and catalogue utilities; no driver."""
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import time

ROOT=Path(__file__).resolve().parents[1]
CHECK=dict(max_depth=256,max_operations=10000000,max_proof_lines=4096)
FACTORY=dict(max_work=1000000000,max_depth=256,max_definitions=20000,max_proof_lines=4096,wall_seconds=15)
AUDIT=dict(max_depth=256,max_items=20000000,max_work=1000000000,wall_seconds=15)
PINS={'growing_point_search_v2.py':'6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb',
      'indexed_proof_provider_v1.py':'5261bf552924105f3c9ac3a4e9ddce0490869105b1812a8d897610267623b26e',
      'growing_proof_verifier_v2.py':'6286d6b151d460e6ee0b97983fd9f081168a6d76256a33c3e0f9ead0ffae3aa1',
      'independent_fol_checker_v1.py':'099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1'}


def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def text(x):return wire(x).decode().rstrip('\n')
def sha(x):return hashlib.sha256(wire(x)).hexdigest()


def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);raw=wire(value)
    if path.name.endswith('.gz'):raw=gzip.compress(raw,mtime=0)
    with path.open('xb') as f:f.write(raw)
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def load_modules():
    modules={}
    for filename,pin in PINS.items():
        path=ROOT/'upstream'/filename;assert hashlib.sha256(path.read_bytes()).hexdigest()==pin
        spec=importlib.util.spec_from_file_location(filename[:-3],path);module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module);modules[filename[:-3]]=module
    return modules


class Stop(Exception):pass


class Meter:
    def __init__(self,seconds):self.start=time.perf_counter();self.seconds=max(0,seconds);self.work=0
    def tick(self,n=1):
        self.work+=n
        if self.work>1000000000 or time.perf_counter()-self.start>=self.seconds:raise Stop('WALL_OR_WORK')


class Catalogue:
    def __init__(self,compiled,definitions,depth):
        self.c=compiled;self.depth=depth;self.defs={d['id']:d for d in definitions};self.by_out={}
        for d in definitions:self.by_out.setdefault(d['output'],[]).append(d)
        self.colors=compiled['logical_basis']['colors'];self.forms=compiled['logical_basis']['formulas']
        self.fid={value:i for i,value in enumerate(self.colors)}
        self.zero_out={d['output'] for d in definitions if d['kind']=='ZERO'}
        self.axiom_out={d['output'] for d in definitions if d['kind']=='ZERO' and d['native_rule']=='axiom'}
    def placement(self,site,d):
        points=[site]+[site+str(i) for i in range(len(d['premises']))]
        return dict(id=text([site,d['id']]),t=[[p,1] for p in points],m=[[p,self.colors[f]] for p,f in zip(points,[d['output']]+d['premises'])])
    def decode_id(self,cid):
        site,did=json.loads(cid);return site,self.defs[did]
    def values(self,selected,charge):
        totals={'':1};marks={'':self.colors[self.c['goal_id']]}
        for cid in selected:
            charge(5+len(cid));site,d=self.decode_id(cid);row=self.placement(site,d)
            for p,n in row['t']:
                totals[p]=totals.get(p,0)+n;assert totals[p]<=2
            for p,v in row['m']:
                assert p not in marks or marks[p]==v;marks[p]=v
        return totals,marks
    def valid(self,rows,selected,excluded,charge):
        totals,marks=self.values(selected,charge);seen=set(selected)
        for row in rows:
            charge(20+len(row['id']))
            if row['id'] in seen or row['id'] in excluded:return False
            seen.add(row['id']);site,d=self.decode_id(row['id'])
            if row!=self.placement(site,d) or len(site)>self.depth or d['premises'] and len(site)>=self.depth:return False
            for p,n in row['t']:
                totals[p]=totals.get(p,0)+n
                if totals[p]>2:return False
            for p,v in row['m']:
                if p in marks and marks[p]!=v:return False
                marks[p]=v
        return True


def native(d):return 'ZERO:'+d['native_rule'] if d['kind']=='ZERO' else d['kind']
def pattern_size(p):return 0 if p is None else 1+sum(pattern_size(x) for x in p[1:])


def probabilities(vectors,weights):
    logits=[sum(a*b for a,b in zip(v,weights)) for v in vectors];top=max(logits)
    exps=[math.exp(max(-60,x-top)) for x in logits];denom=sum(exps)
    return [x/denom for x in exps]


def make_catalogue(modules,compiled,generation,depth):
    model,provider,factory=modules['indexed_proof_provider_v1'].make_provider(compiled,generation,depth,FACTORY)
    assert factory['status']=='COMPLETE',factory
    return model,provider,factory,Catalogue(compiled,factory['value']['definitions'],depth)


def check_positive(modules,compiled,depth,selected):
    decoded=modules['indexed_proof_provider_v1'].decode(compiled,depth,selected,FACTORY)
    assert decoded['status']=='UNVERIFIED_CERTIFICATE',decoded
    checked=modules['growing_proof_verifier_v2'].verify_tree(compiled,depth,selected,decoded,limits=AUDIT)
    assert checked['status']=='VERIFIED',checked
    host=modules['independent_fol_checker_v1'].check(compiled['theory'],decoded['proof'],compiled['goal'],CHECK)
    assert host['status']=='VERIFIED',host
    return dict(proof=decoded['proof'],tree=decoded['tree'],tree_check=checked,host_check=host)
