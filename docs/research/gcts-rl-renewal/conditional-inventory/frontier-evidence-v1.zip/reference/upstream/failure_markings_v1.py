"""Bounded failure certificates compiled to literal point marking conflicts.

The table producer is not trusted: an independent checker certifies its DAG.
The marked provider uses only t/m comparisons after the marking is frozen.
Direct table filtering is a separately labeled conventional control.
"""
import collections
import copy
import json
import time
from proof_core_v1 import Catalogue,Meter,Stop,sha,text


def scope_payload(c):
    return dict(schema='FM-native-producer-scope-v1',depth_semantics='FM-rooted-tree-height-v1',
        compiled_schema=c['schema'],compiled_version=c['version'],theory=c['theory'],
        registry=dict(formulas=c['logical_basis']['formulas'],colors=c['logical_basis']['colors']),
        zero_instances=c['zero_instances'],mp_index=c['mp_index'],gen_index=c['gen_index'])


def port(scope,fid,remaining):return text(['FM-port-v1',scope,fid,remaining])


def requests(cat,limit=24,local_depth=3):
    """Freeze requests from syntax alone, before classification, without labels."""
    seen=set();pending=[cat.c['goal_id']];frequency=collections.Counter()
    while pending:
        fid=pending.pop()
        if fid in seen:continue
        seen.add(fid)
        for d in cat.by_out.get(fid,[]):
            for child in d['premises']:frequency[child]+=1;pending.append(child)
    chosen=sorted(seen,key=lambda f:(-frequency[f],f))[:limit]
    return [[f,r] for f in chosen for r in range(local_depth+1)]


def learn(cat,query_pairs,seconds=1.):
    """Complete bounded producer search; interrupted requests stay UNKNOWN."""
    start=time.perf_counter();meter=Meter(seconds);memo={};records=[]
    def visit(fid,r):
        meter.tick();key=(fid,r)
        if key in memo:return memo[key]
        blockers=[]
        for d in cat.by_out.get(fid,[]):
            meter.tick(5+len(d['id']))
            if not d['premises']:
                answer=dict(status='PROVED',tree=[d['id'],[]]);memo[key]=answer;return answer
            if r==0:blockers.append([d['id'],None]);continue
            children=[];failed=None
            for i,p in enumerate(d['premises']):
                child=visit(p,r-1)
                if child['status']=='ABSENT':failed=i;break
                children.append(child['tree'])
            if failed is None:
                answer=dict(status='PROVED',tree=[d['id'],children]);memo[key]=answer;return answer
            blockers.append([d['id'],failed])
        answer=dict(status='ABSENT',node=dict(fid=fid,remaining=r,blockers=blockers));memo[key]=answer;return answer
    stopped=False
    for fid,r in query_pairs:
        if (fid,r) in memo:answer=memo[fid,r]
        elif stopped:answer=dict(status='UNKNOWN',reason='CLASSIFICATION_BUDGET_EXHAUSTED')
        else:
            try:answer=visit(fid,r)
            except Stop as error:answer=dict(status='UNKNOWN',reason=str(error));stopped=True
        records.append(dict(fid=fid,remaining=r,**answer))
    negatives=[[q['fid'],q['remaining']] for q in records if q['status']=='ABSENT']
    cert=dict(version='FM-bounded-absence-v1',scope_sha256=sha(scope_payload(cat.c)),requests=negatives,
              nodes=[a['node'] for key,a in sorted(memo.items()) if a['status']=='ABSENT'])
    return dict(requests=query_pairs,classifications=records,certificate=cert,seconds=time.perf_counter()-start,
                work=meter.work,internal_cached_states=len(memo),
                scope='Requested failures only become seed marks. Internal negative nodes are certificate evidence; no result from an interrupted search is called absent.')


def expand(cat,tree,site=''):
    d=cat.defs[tree[0]];rows=[cat.placement(site,d)['id']]
    for i,child in enumerate(tree[1]):rows+=expand(cat,child,site+str(i))
    return rows


class MarkedCatalogue(Catalogue):
    def __init__(self,compiled,definitions,depth,certificate):
        super().__init__(compiled,definitions,depth)
        self.scope=certificate['scope_sha256']
        self.negative_requests=certificate['requests']
        self.seed_marks={port(self.scope,f,r):'0' for f,r in self.negative_requests}
    def placement(self,site,d):
        base=super().placement(site,d);marks=dict(base['m'])
        for f in d['premises']:marks[port(self.scope,f,self.depth-len(site)-1)]='1'
        base['m']=[[p,v] for p,v in sorted(marks.items())];return base
    def values(self,selected,charge):
        totals={'':1};marks=dict(self.seed_marks);marks['']=self.colors[self.c['goal_id']]
        for cid in selected:
            charge(5+len(cid));site,d=self.decode_id(cid);row=self.placement(site,d)
            for p,n in row['t']:totals[p]=totals.get(p,0)+n;assert totals[p]<=2
            for p,v in row['m']:assert p not in marks or marks[p]==v;marks[p]=v
        return totals,marks
    def project(self,proposal):
        return dict(root_site=proposal['root_site'],pattern=proposal['pattern'],placements=[
            Catalogue.placement(self,*self.decode_id(p['id'])) for p in proposal['placements']])


class Provider:
    incident_query_abi='IP-CURRENT-TM-INCIDENT-v1'
    def __init__(self,base,model,cat,mode):
        assert mode in ('MARKS','FILTER')
        self.base=base;self.cat=cat;self.mode=mode;self.identity=text(['FM-provider-v1',base.identity,mode,sha(cat.negative_requests),cat.scope])
        self.model=copy.deepcopy(model);self.model['inventory']['identity']=self.identity
        if mode=='MARKS':self.model['seed']['m']=[[p,v] for p,v in sorted(dict(model['seed']['m']+list(cat.seed_marks.items())).items())]
        self.calls=0;self.returned=0;self.removed=0;self.work=0
        self.negative={tuple(x) for x in cat.negative_requests}
    def __call__(self,query,charge):
        assert query['inventory_identity']==self.identity
        def reserve(n=1):self.work+=n;charge(n)
        translated=copy.deepcopy(query);translated['inventory_identity']=self.base.identity
        packet=self.base(translated,reserve);marks=dict(query['marks']);out=[]
        for row in packet['placements']:
            reserve(5+len(row['id']));site,d=self.cat.decode_id(row['id'])
            if self.mode=='MARKS':
                candidate=self.cat.placement(site,d);reserve(2*len(candidate['m']))
                keep=all(p not in marks or marks[p]==v for p,v in candidate['m'])
            else:
                # Conventional lookup control: intentionally not called GCTS marking.
                candidate=row;r=self.cat.depth-len(site)-1;reserve(2*len(d['premises']))
                keep=not any((f,r) in self.negative for f in d['premises'])
            if keep:out.append(candidate)
            else:self.removed+=1
        self.calls+=1;self.returned+=len(out)
        return dict(point=query['point'],context_sha256=sha(query),complete=True,placements=out,
                    certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',
                       potential_count=packet['certificate']['potential_count'],compatible_count=len(out)))
    def snapshot(self):
        return dict(mode=self.mode,calls=self.calls,returned=self.returned,removed_by_mark_agreement=self.removed if self.mode=='MARKS' else 0,
                    removed_by_table_lookup=self.removed if self.mode=='FILTER' else 0,charged_adapter_work=self.work,base=self.base.snapshot())
