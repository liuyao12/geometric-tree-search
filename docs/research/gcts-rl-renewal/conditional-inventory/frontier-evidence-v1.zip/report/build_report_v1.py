"""Passive HTML/trace materializer. No engine, provider or checker import.

Reads only saved summary/reference bytes, verifies raw reference pins, and
copies exact raw archives alongside decoded JSON for a browser proof reader.
"""
import gzip
import hashlib
import html
import json
from pathlib import Path
import re
import sys


STYLE = r'''
:root{color-scheme:light;--ink:#172334;--muted:#526477;--line:#d9e1e8;--blue:#176ca4;--purple:#774caf;--paper:#f5f7fa}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}a{color:#145f96}header,main,footer{max-width:1260px;margin:auto;padding:25px}header{padding-top:52px}h1{font:600 clamp(2rem,4vw,3rem)/1.12 Georgia,serif;max-width:950px;letter-spacing:-.025em;margin:12px 0 20px}h2{font:600 1.6rem/1.2 Georgia,serif;margin:0 0 15px}h3{font-size:1.03rem}.eyebrow{letter-spacing:.13em;text-transform:uppercase;color:var(--blue);font-size:.75rem;font-weight:750}.lede{font-size:1.12rem;max-width:950px}.muted,.note{color:var(--muted)}.note{font-size:.88rem}.card{background:white;border:1px solid var(--line);border-radius:14px;padding:23px;margin-bottom:22px}.scope{border-left:5px solid var(--purple)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}.stat{font-size:1.35rem;font-weight:750}.badge{display:inline-block;font:650 .74rem/1.5 ui-monospace,monospace;border:1px solid var(--line);border-radius:5px;padding:2px 7px;background:#eff3f7;white-space:nowrap}.good{background:#e7f4ed;color:#205c3b}.bad{background:#f8eded;color:#963e3e}.unknown{background:#fff3d9;color:#785819}.toolbar{display:flex;gap:12px;flex-wrap:wrap;align-items:end;margin:18px 0}label{display:flex;flex-direction:column;gap:6px;font-size:.85rem;font-weight:650}select,button{font:inherit;padding:9px 11px;border:1px solid #b8c7d4;border-radius:7px;background:white;color:var(--ink);max-width:100%}select{min-width:200px}button{cursor:pointer}button:hover{background:#edf5fa}.scroll{overflow:auto;max-width:100%}.bounded{max-height:480px}table{border-collapse:collapse;width:100%;font-size:.86rem}th,td{padding:10px 11px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{background:#f4f7fa;position:sticky;top:0;z-index:1;font-size:.77rem}code,pre{font:12px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace}code{overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f8;border-radius:8px;padding:13px;max-height:420px;overflow:auto}.graph{overflow:auto;max-height:660px;border:1px solid var(--line);border-radius:9px;background:linear-gradient(90deg,#f5faff,#fff)}.graph svg{display:block;min-width:1050px;width:100%}.graph .edge{stroke:#96adc1;opacity:.55;fill:none;stroke-width:1.2}.graph .edge-label{font:10px ui-monospace,monospace;fill:#526477}.graph .point circle{fill:#eaf5fc;stroke:#207daf;stroke-width:2}.graph .candidate rect{fill:#f5f7fa;stroke:#8393a2;stroke-width:1.3}.graph text{fill:var(--ink);font:12px ui-monospace,monospace}.graph .small{font-size:10px;fill:#526477}.graph .dim{opacity:.12}.graph g.candidate{cursor:pointer}.graph g.candidate:hover rect,.graph g.candidate:focus rect{stroke:var(--purple);stroke-width:3}.chip{display:inline-flex;gap:7px;align-items:center;border:1px solid var(--line);padding:5px 9px;border-radius:7px;margin:4px;font-size:.8rem}.swatch{width:12px;height:12px;border-radius:3px;display:inline-block;flex-shrink:0}.formula{min-width:250px}.proof tr:hover{background:#f4f9fd}.links{display:flex;flex-wrap:wrap;gap:15px}.split{display:grid;grid-template-columns:1fr 1fr;gap:18px}.error{border-left:5px solid #b14545;background:#fff4f4;padding:14px}.math-legend{margin:12px 0}details{margin:14px 0}summary{cursor:pointer;font-weight:650}.empty{padding:22px;color:var(--muted)}footer{font-size:.85rem;color:var(--muted);padding-bottom:45px}@media(max-width:760px){header,main,footer{padding:18px}.card{padding:16px}.split{grid-template-columns:1fr}header{padding-top:30px}select{min-width:0;width:100%}label{width:100%}th,td{padding:8px}h1{font-size:2.1rem}}
'''


SCRIPT = r'''
const $=id=>document.getElementById(id), esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const absent=x=>x===null||x===undefined, show=x=>absent(x)?'Unavailable':typeof x==='object'?JSON.stringify(x):String(x);
const badge=x=>{let s=show(x),c=/^(VERIFIED|PASS|SAT|COMPLETE)/.test(s)?'good':/^(REJECTED|FAIL|UNSAT)/.test(s)?'bad':/UNKNOWN|INCOMPLETE|UNAVAILABLE/i.test(s)?'unknown':'';return `<span class="badge ${c}">${esc(s)}</span>`};
let data,rows=[],current,trace,state,checkpoints=[],loadToken=0;
function typeset(node=document){if(window.MathJax?.typesetPromise)window.MathJax.typesetPromise([node]).catch(()=>{});}
function color(value){let h=2166136261;for(let c of String(value))h=Math.imul(h^c.charCodeAt(0),16777619);return `hsl(${(h>>>0)%360} 57% 43%)`;}
function table(headers,body){return `<div class="scroll"><table><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${body.join('')}</tbody></table></div>`;}
function pairs(value){if(absent(value))return '<p class="note">Unavailable.</p>';if(typeof value!=='object')return `<p>${esc(show(value))}</p>`;return table(['Recorded field','Recorded value'],Object.entries(value).map(([k,v])=>`<tr><td><code>${esc(k)}</code></td><td>${typeof v==='object'?`<pre>${esc(JSON.stringify(v,null,2))}</pre>`:esc(show(v))}</td></tr>`));}
function astLatex(n){if(!Array.isArray(n))return null;const tag=n[0],tx=x=>String(x).replace(/([_{}%&#$])/g,'\\$1'),r=x=>astLatex(x);if(tag==='var')return tx(n[1]);if(tag==='fun'){let a=(n[2]||[]).map(r);return a.some(x=>x===null)?null:`\\operatorname{${tx(n[1])}}${a.length?'('+a.join(',')+')':''}`;}if(tag==='pred'){let a=(n[2]||[]).map(r);return a.some(x=>x===null)?null:`\\operatorname{${tx(n[1])}}${a.length?'('+a.join(',')+')':''}`;}if(tag==='eq'){let a=r(n[1]),b=r(n[2]);return a===null||b===null?null:a+'='+b;}if(tag==='imp'){let a=r(n[1]),b=r(n[2]);return a===null||b===null?null:'('+a+'\\to '+b+')';}if(tag==='all'){let b=r(n[2]);return b===null?null:'\\forall '+tx(n[1])+'.\\,'+b;}if(tag==='not'){let b=r(n[1]);return b===null?null:'\\neg '+b;}if(tag==='bot')return '\\bot';return null;}
function markMath(value){try{return astLatex(JSON.parse(value));}catch{return null;}}
function short(x,n=42){x=String(x);return x.length>n?x.slice(0,n-1)+'…':x;}
function pointLabel(p){return p===''?'root (empty ID)':String(p);}
function cidLabel(id){try{let a=JSON.parse(id);if(Array.isArray(a)&&typeof a[0]==='string'){let d=a[1];if(typeof d==='string')d=JSON.parse(d);let role=Array.isArray(d)?String(d[0]).toUpperCase():'CID';return {label:(a[0]===''?'root':a[0])+' · '+role,role};}}catch{}return {label:short(id),role:'CID'};}
function renderOverview(){
 $('status').innerHTML=badge(data.status);$('coverage').innerHTML=pairs(data.coverage);$('costs').innerHTML=pairs(data.costs);
 $('limitations').innerHTML=Array.isArray(data.limitations)?'<ul>'+data.limitations.map(x=>`<li>${esc(show(x))}</li>`).join('')+'</ul>':pairs(data.limitations);
 $('outcomes').innerHTML=table(['Profile / case','Search result','Graph assurance','Native logic','Routes / subsets'],rows.map((r,i)=>`<tr><td><button data-case="${i}">${esc(r.group+' · '+r.id+(r.mode?' · '+r.mode:''))}</button></td><td>${badge(r.display?.result_status)}</td><td>${badge(r.display?.graph_status)}</td><td>${r.group==='native'?badge(r.display?.native_status):'<span class="note">Abstract point fixture</span>'}</td><td>${badge(r.display?.route_status)} ${badge(r.display?.subset_status)}</td></tr>`));
 document.querySelectorAll('[data-case]').forEach(b=>b.addEventListener('click',()=>{$('case').value=b.dataset.case;loadCase(Number(b.dataset.case));$('reader').scrollIntoView({behavior:'smooth'});}));
 $('mutations').innerHTML=table(['Mutation','Case','Observed checker status','Expected','Reason'],(data.mutations||[]).map(m=>`<tr><td><code>${esc(m.id)}</code></td><td>${esc(m.case_id)}</td><td>${badge(m.status)}</td><td>${esc(show(m.expected))}</td><td>${esc(show(m.reason))}</td></tr>`));
}
async function loadCase(index){let token=++loadToken;current=rows[index];trace=null;state=null;checkpoints=[];$('event').innerHTML='';for(let id of ['graph','incidence','points','marks','legend','event-data','candidate','state-extra','proof'])$(id).textContent='Loading saved data…';$('reader-status').innerHTML='<p class="note">Loading the selected saved trace…</p>';try{let response=await fetch(current.reader_trace);if(!response.ok)throw Error('Trace HTTP '+response.status);let payload=await response.json();if(token!==loadToken)return;trace=payload;
 $('case-meta').innerHTML=`<div class="grid"><div><strong>${esc(current.group+' · '+current.id)}</strong><p>${badge(current.display?.result_status)} ${badge(current.display?.graph_status)}</p></div><div><strong>Scope</strong><p class="note">${current.group==='native'?'Anchored finite symbolic proof-address model. Native proof validity is checked separately.':'Abstract finite point data. This fixture is not a mathematical theorem.'}</p></div></div>`;
 $('downloads').innerHTML=`<a href="${esc(current.reader_trace)}" download>Full decoded trace JSON</a><a href="${esc(current.raw_download)}" download>Exact saved raw archive</a><a href="frontier-audit-results-v1.json" download>Results summary</a>`;
 $('raw-pin').textContent=JSON.stringify({original:current.raw,public_copy:current.public_raw_pin,trace:current.reader_trace_pin},null,2);
 checkpoints=(trace.observations||[]).map((o,i)=>({state:o.state,event:o.event,label:`${i} · ${o.event?.kind||'recorded event'}${o.event?.point!==null&&o.event?.point!==undefined?' · '+pointLabel(o.event.point):''}`}));
 for(let [key,label] of [['entry_state','Saved entry checkpoint'],['final_state','Saved final checkpoint'],['restored_state','Saved restored checkpoint']]){if(trace.result?.[key])checkpoints.push({state:trace.result[key],event:null,label,source:key});}
 $('event').innerHTML=checkpoints.map((o,i)=>`<option value="${i}">${esc(o.label)}</option>`).join('');
 $('reader-status').innerHTML=checkpoints.length?`<p class="note">${checkpoints.length} retained event/checkpoint views. Event stream retention and independent coverage are reported separately below.</p>`:'<p class="note">No state checkpoint was retained. A refusal before initialization can leave no complete entry graph.</p>';
 $('stream').innerHTML=pairs({event_extent:trace.result?.event_extent,rollback_extent:trace.result?.rollback_extent,provider_evidence:trace.result?.provider_evidence?{mode:trace.result.provider_evidence.mode,total:trace.result.provider_evidence.total,retained:trace.result.provider_evidence.retained,sha256:trace.result.provider_evidence.sha256,scope:trace.result.provider_evidence.scope}:null});
 renderProof();if(checkpoints.length)renderCheckpoint(0);else{$('graph').innerHTML='<div class="empty">No complete saved graph available.</div>';$('incidence').innerHTML='';$('points').innerHTML='';$('marks').innerHTML='';$('legend').innerHTML='';$('event-data').textContent='Unavailable';$('candidate').textContent='Unavailable';$('state-extra').textContent='Unavailable: no complete saved checkpoint.';}typeset($('reader'));
 }catch(e){$('reader-status').innerHTML=`<div class="error">${esc(e.message)}. No replacement data have been generated.</div>`;}}
function renderProof(){let proof=current.proof_reader,theory=current.theory_reader,head='';if(theory){head='<details><summary>Declared hypotheses and conclusion</summary>'+table(['Hypothesis','Formula','English'],(theory.hypotheses||[]).map(h=>`<tr><td><code>${esc(h.name)}</code></td><td>\\(${esc(h.latex)}\\)</td><td>${esc(h.english)}</td></tr>`))+`<p>Conclusion: \\(${esc(theory.conclusion.latex)}\\). ${esc(theory.conclusion.english)}</p></details>`;}if(!Array.isArray(proof)||!proof.length){$('proof').innerHTML=head+'<p class="note">No line-by-line native proof is supplied for this result.</p>';typeset($('proof'));return;}$('proof').innerHTML=head+table(['Line','Formula','English reading','Native rule / dependencies'],proof.map(p=>`<tr><td>${esc(show(p.line))}</td><td class="formula">\\(${esc(p.formula_latex??'\\text{Unavailable}')}\\)</td><td>${esc(show(p.english))}</td><td><code>${esc(show(p.rule))}</code><br><span class="note">${esc(show(p.dependencies))}</span></td></tr>`));typeset($('proof'));}
function renderCheckpoint(index){let cp=checkpoints[index];if(!cp)return;state=cp.state;if(!state){$('graph').innerHTML='<p class="empty">This observation has no retained state.</p>';return;}$('event-data').textContent=JSON.stringify(cp.event??{source:cp.source},null,2);
 const totals=new Map(state.totals||[]),gens=new Map(state.Q||[]),marks=new Map((state.marks||[]).map(r=>[r[0],r])),cap=trace.model?.capacity??trace.result?.certificate?.capacity;
 const allValues=[...new Set((state.marks||[]).map(r=>r[1]))].sort();$('legend').innerHTML=allValues.length?allValues.map(v=>{let m=markMath(v);return `<span class="chip"><span class="swatch" style="background:${color(v)}"></span><code title="${esc(v)}">${esc(short(v,55))}</code>${m?`<span>\\(${esc(m)}\\)</span>`:''}</span>`;}).join(''):'<span class="note">No assigned markings in this checkpoint. Missing remains unconstrained.</span>';
 $('points').innerHTML=table(['Required point ID','Generation','Recorded total units','Capacity','Frontier / assigned mark'],(state.Q||[]).map(([p,g])=>`<tr><td><code>${esc(pointLabel(p))}</code></td><td>${esc(g)}</td><td>${totals.has(p)?esc(totals.get(p)):'Unavailable'}</td><td>${esc(show(cap))}</td><td>${(state.domains||[]).some(r=>r[0]===p)?'Frontier':'Full / inactive frontier'}${marks.has(p)?'<br><code>'+esc(marks.get(p)[1])+'</code>':'<br><span class="note">No assigned mark</span>'}</td></tr>`));
 $('marks').innerHTML=table(['Mark point ID','Literal assigned value','Reference count','Domain'],(state.marks||[]).map(([p,v,n])=>`<tr><td><code>${esc(p===''?'root (empty ID)':p)}</code></td><td><span class="swatch" style="background:${color(v)}"></span> <code>${esc(v)}</code></td><td>${esc(n)}</td><td>${gens.has(p)?'Required point':'Mark-only point'}</td></tr>`));
 $('incidence').innerHTML=table(['Frontier point','Shared candidate ID','Exact contribution units'],(state.forward||[]).map(([p,c,u])=>`<tr><td><code>${esc(pointLabel(p))}</code></td><td><code>${esc(c)}</code></td><td>${esc(u)}</td></tr>`));
 $('state-extra').textContent=JSON.stringify({selected:state.selected,excluded:state.excluded,eligible:state.eligible,loaded:state.loaded,dependencies:state.dependencies,reverse:state.reverse,edge_count:state.edge_count},null,2);
 drawGraph(state,totals,gens,marks,cap);typeset($('legend'));}
function drawGraph(s,totals,gens,marks,cap){let domains=s.domains||[],ids=[...new Set(domains.flatMap(r=>r[1]))].sort(),pindex=new Map(domains.map((r,i)=>[r[0],i])),cindex=new Map(ids.map((c,i)=>[c,i])),rowHeight=43,height=65+Math.max(domains.length,ids.length,1)*rowHeight;
 if(!domains.length){$('graph').innerHTML='<div class="empty">The saved frontier is empty. The result and independent assurance determine what this checkpoint certifies.</div>';$('candidate').textContent='No candidate node in this frontier.';return;}
 let parts=[`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1120 ${height}" role="img" aria-label="Recorded whole frontier point and shared candidate graph"><text x="28" y="24">FRONTIER POINTS</text><text x="660" y="24">SHARED CANDIDATE IDENTITIES</text>`];
 for(let [p,c,u] of s.forward||[]){if(!pindex.has(p)||!cindex.has(c))continue;let i=pindex.get(p),j=cindex.get(c),y=55+i*rowHeight,z=55+j*rowHeight;parts.push(`<path class="edge" data-p="${i}" data-c="${j}" d="M 294 ${y} C 455 ${y},505 ${z},650 ${z}"/><text class="edge-label" data-p="${i}" data-c="${j}" x="${440+(i%3)*37}" y="${(y+z)/2-3}">${esc(u)}</text>`);}
 domains.forEach(([p,domain],i)=>{let y=55+i*rowHeight,m=marks.get(p);parts.push(`<g class="point" data-p="${i}"><title>${esc(JSON.stringify({point:p,generation:gens.get(p),total:totals.get(p),capacity:cap,domain,mark:m}))}</title><circle cx="284" cy="${y}" r="9"${m?` style="stroke:${color(m[1])}"`:''}/><text x="16" y="${y-3}">${esc(short(pointLabel(p),36))}</text><text class="small" x="16" y="${y+12}">units:${esc(show(totals.get(p)))} capacity:${esc(show(cap))} gen:${esc(show(gens.get(p)))} degree:${domain.length}</text></g>`);});
 ids.forEach((c,j)=>{let y=55+j*rowHeight,label=cidLabel(c);parts.push(`<g class="candidate" data-c="${j}" tabindex="0" role="button" aria-label="Inspect candidate ${esc(c)}"><title>${esc(c)}</title><rect x="650" y="${y-17}" width="452" height="34" rx="6"/><text x="662" y="${y-2}">${esc(short(label.label,58))}</text><text class="small" x="662" y="${y+11}">${esc(short(c,68))}</text></g>`);});parts.push('</svg>');$('graph').innerHTML=parts.join('');
 let highlight=(type,index)=>{$('graph').querySelectorAll('.edge,.edge-label,.point,.candidate').forEach(n=>{let hit=type==='p'?n.dataset.p===index:n.dataset.c===index;if(n.classList.contains('point')&&type==='c')hit=(s.forward||[]).some(([p,c])=>cindex.get(c)===Number(index)&&pindex.get(p)===Number(n.dataset.p));if(n.classList.contains('candidate')&&type==='p')hit=(domains[Number(index)]?.[1]||[]).includes(ids[Number(n.dataset.c)]);n.classList.toggle('dim',!hit);});};
 $('graph').querySelectorAll('g.point,g.candidate').forEach(n=>{let type=n.classList.contains('point')?'p':'c',idx=n.dataset[type];n.addEventListener('mouseenter',()=>highlight(type,idx));n.addEventListener('mouseleave',()=>{$('graph').querySelectorAll('.dim').forEach(k=>k.classList.remove('dim'));});if(type==='c'){let inspect=()=>{$('candidate').textContent=JSON.stringify((s.placements||[]).find(r=>r.id===ids[Number(idx)])??{id:ids[Number(idx)],record:'No registered row retained'},null,2);};n.addEventListener('click',inspect);n.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')inspect();});}});$('candidate').textContent='Select a candidate card to inspect its exact positive support and literal markings.';
}
async function init(){try{let response=await fetch('frontier-audit-results-v1.json');if(!response.ok)throw Error('Summary HTTP '+response.status);data=await response.json();rows=[...(data.abstract||[]).map(r=>({...r,group:'abstract'})),...(data.native||[]).map(r=>({...r,group:'native'}))];renderOverview();$('case').innerHTML=rows.map((r,i)=>`<option value="${i}">${esc(r.group+' · '+r.id+(r.mode?' · '+r.mode:''))}</option>`).join('');$('case').addEventListener('change',()=>loadCase(Number($('case').value)));$('event').addEventListener('change',()=>renderCheckpoint(Number($('event').value)));$('previous').addEventListener('click',()=>{let i=Math.max(0,Number($('event').value)-1);$('event').value=i;renderCheckpoint(i);});$('next').addEventListener('click',()=>{let i=Math.min(checkpoints.length-1,Number($('event').value)+1);$('event').value=i;renderCheckpoint(i);});if(rows.length)await loadCase(0);else $('reader-status').innerHTML='<p>No recorded runs are supplied.</p>';typeset();}catch(e){$('status').innerHTML=`<div class="error">${esc(e.message)}. No demonstration data have been substituted.</div>`;}}
init();
'''


def page(title, body, script=''):
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<title>'+html.escape(title)+'</title><style>'+STYLE+'</style>'
        r'<script>window.MathJax={tex:{inlineMath:[["\\(","\\)"]],displayMath:[["\\[","\\]"]]},options:{skipHtmlTags:["script","noscript","style","textarea","pre","code"]}};</script>'
        '<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>'
        '</head><body>'+body+('<script>'+script+'</script>' if script else '')+'</body></html>')


MAIN = r'''
<header><div class="eyebrow">GCTS · Independent frontier evidence</div><h1>Inspect the whole proof frontier</h1><p class="lede">A saved-data reader for exact point obligations, shared candidate identities, literal markings and independently checked search traces.</p><div id="status">Loading recorded status…</div><p class="note">This is a specialized anchored symbolic point profile. It is not a literal Wang square-grid palette. Abstract fixtures test the graph contract; native logical proofs have a separate validity check.</p><div class="links"><a href="frontier-evidence-v1.html">Evidence and raw downloads</a><a href="failure-markings-v1.html">Previous failure-marking notebook</a><a href="#reader">Inspect a trace</a><a href="#proof-reader">Read the native proof</a></div><p><!-- FRONTIER_ARCHIVE_LINK --></p></header>
<main><section class="card scope"><h2>What this reader can establish</h2><p>The displayed states and formulas come from retained records. Search outcome, whole-graph assurance, native proof validity and mutation rejection are separate columns. A missing or resource-limited check remains explicit. The earlier legacy checker refusal has not been relabeled as a pass.</p><p class="note">No newly trained RL, standard-ATP speedup, universal first-order encoding or plane-tiling result is claimed here. Missing marks are unconstrained; the literal assigned value <code>"0"</code> remains assigned.</p></section>
<section class="card"><h2>Recorded outcomes</h2><div id="outcomes"></div></section>
<section id="reader" class="card"><h2>Point and candidate reader</h2><div class="toolbar"><label>Recorded run<select id="case"></select></label><label>Actual event / saved checkpoint<select id="event"></select></label><button id="previous">Previous</button><button id="next">Next</button></div><div id="case-meta"></div><div id="reader-status"></div><div id="downloads" class="links"></div><p class="note">Circles are frontier points. Cards are distinct candidate IDs, shared across every incident point. Edge labels are integer contribution units. This layout is a graph diagram, not tile geometry. Hover to inspect incidence; select a candidate to see its exact data.</p><div id="graph" class="graph"></div><div class="split"><div><h3>Actual event</h3><pre id="event-data"></pre></div><div><h3>Selected candidate data</h3><pre id="candidate"></pre></div></div><h3>Assigned-value color legend</h3><div id="legend" class="math-legend"></div><p class="note">A color identifies a literal marking value. If the saved value itself contains a recognized formula AST, its LaTeX reading appears beside it. Other exact values remain literal code.</p><details open><summary>All weighted incidences</summary><div id="incidence" class="bounded scroll"></div></details><details><summary>All required points, including untouched zeros</summary><div id="points" class="bounded scroll"></div></details><details><summary>All assignments and mark-only ports</summary><div id="marks" class="bounded scroll"></div></details><details><summary>Inventory, exclusions and dependency indexes</summary><pre id="state-extra"></pre></details><details><summary>Stream retention and hashes</summary><div id="stream"></div><pre id="raw-pin"></pre></details><h3 id="proof-reader">Native proof, line by line</h3><p class="note">These supplied lines translate the searched native proof. They are separate from graph events and do not turn an arbitrary capacity-consistent patch into a logical derivation.</p><div id="proof" class="proof"></div></section>
<section class="card"><h2>Mutation checks</h2><div id="mutations"></div><p class="note">A declared expected outcome is not an observed rejection. The status column contains only the recorded checker result.</p></section>
<section class="card"><h2>Coverage and retained evidence</h2><div id="coverage"></div></section><section class="card"><h2>Measured costs</h2><div id="costs"></div><p class="note">Search, preparation and assurance have different scopes. Missing timers are unavailable; reused observations are not a measured cold run.</p></section><section class="card"><h2>Limits of this result</h2><div id="limitations"></div></section></main><footer>Passive browser rendering. The reader does not invoke a search engine or a proof checker. Exact saved archives and decoded trace downloads are provided for examination.</footer>
'''


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def file_pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read_reference(root, reference):
    if not isinstance(reference, dict) or not {'path', 'bytes', 'sha256'} <= set(reference):
        raise ValueError('Expected pinned reference {path,bytes,sha256}.')
    path = (root / reference['path']).resolve()
    if root != path and root not in path.parents:
        raise ValueError('Reference leaves the declared run root.')
    raw = path.read_bytes()
    if file_pin(raw) != {key: reference[key] for key in ('bytes', 'sha256')}:
        raise ValueError('Reference byte/hash differs: '+reference['path'])
    decoded = json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)
    return path, raw, decoded


def status(root, value):
    if isinstance(value, dict):
        if 'status' in value:
            return value['status']
        if {'path', 'bytes', 'sha256'} <= set(value):
            return status(root, read_reference(root, value)[2])
    if isinstance(value, str):
        return value
    return None


def build(root):
    root = root.resolve()
    source = root / 'data/report-summary-v1.json'
    raw_summary = source.read_bytes()
    summary = json.loads(raw_summary)
    out = root / 'report'
    traces = out / 'frontier-traces-v1'
    traces.mkdir(parents=True, exist_ok=True)
    evidence_rows = []
    for group in ('abstract', 'native'):
        for index, row in enumerate(summary.get(group, [])):
            path, raw, payload = read_reference(root, row['raw'])
            if not isinstance(payload, dict) or not {'model', 'universe', 'observations', 'result'} <= set(payload):
                raise ValueError('Raw trace does not have the declared reader schema: '+row['id'])
            key = group+'-%03d-' % index + re.sub('[^a-zA-Z0-9_-]', '-', str(row['id']))[:70]
            decoded = canonical(payload)
            decoded_name = key+'.trace.json'
            raw_name = key+('.raw.json.gz' if path.suffix == '.gz' else '.raw.json')
            (traces / decoded_name).write_bytes(decoded)
            (traces / raw_name).write_bytes(raw)
            row['reader_trace'] = 'frontier-traces-v1/'+decoded_name
            row['reader_trace_pin'] = file_pin(decoded)
            row['raw_download'] = 'frontier-traces-v1/'+raw_name
            row['public_raw_pin'] = file_pin(raw)
            row['display'] = dict(result_status=payload['result'].get('status'),
                graph_status=status(root, row.get('graph_check')),
                native_status=status(root, row.get('native_check')),
                route_status=status(root, row.get('route_checks')),
                subset_status=status(root, row.get('subset_check')))
            if isinstance(row.get('proof_reader'), dict) and {'path', 'bytes', 'sha256'} <= set(row['proof_reader']):
                row['proof_reader'] = read_reference(root, row['proof_reader'])[2]
            evidence_rows.append((group, row))
    summary['reader_materialization'] = dict(schema='Passive-frontier-reader-v1',
        input_summary=file_pin(raw_summary), traces=len(evidence_rows),
        scope='No scientific Source imported or executed; exact raw copies plus canonical decoded saved JSON.')
    (out / 'frontier-audit-results-v1.json').write_bytes(canonical(summary))
    headline=('<section class="card"><h2>The qualification result</h2><p>All '+
        str(summary['coverage']['full_graph_verified_completed_searches'])+' completed searches passed the full point-graph audit. The two deliberately interrupted searches remained unknown. The native lane produced '+
        str(summary['coverage']['native_positive_proofs'])+' checked proof outputs across three controls; these are repeated outputs for two schematic positive targets, not twelve different theorems.</p>'+
        r'<p>One target derives \(G(c)\) from \(P(c)\), \(P(c)\to Q(c)\), and \(Q(c)\to G(c)\). The other derives \(\forall x\,P(c)\) from the closed hypothesis \(P(c)\). Extra unsupported and padding alternatives remain in the declared grammar. No selected derivation is supplied to the solver.</p>'+
        '<p>Every complete bounded proof set was preserved by literal failure markings and by the explicit filtering control. Four capacity-consistent disconnected additions were rejected as native proofs. This establishes a checked interface on the qualification cases; it does not establish a search-performance advantage.</p></section>')
    main_body=MAIN.replace('<main>','<main>'+headline,1)
    preferred_script=SCRIPT.replace("if(rows.length)await loadCase(0);", "if(rows.length){let first=rows.findIndex(r=>r.group==='native'&&r.mode==='MARKS'&&r.goal_label==='G'&&r.depth===3);if(first<0)first=0;$('case').value=String(first);await loadCase(first);}")
    (out / 'frontier-audit-v1.html').write_text(page('GCTS proof-frontier audit', main_body, preferred_script))
    rows = []
    for group, row in evidence_rows:
        rows.append('<tr><td>'+html.escape(group+' · '+str(row['id']))+'</td><td><a href="'+
            html.escape(row['raw_download'], quote=True)+'" download>Exact raw archive</a><br><a href="'+
            html.escape(row['reader_trace'], quote=True)+'" download>Decoded full trace</a></td><td><code>'+
            html.escape(str(row['public_raw_pin']['bytes']))+'</code></td><td><code>'+
            html.escape(row['public_raw_pin']['sha256'])+'</code></td></tr>')
    body = ('<header><div class="eyebrow">GCTS · Saved evidence</div><h1>Trace archive and provenance</h1>'
        '<p class="lede">Every download below is copied from a saved raw reference after checking its exact byte length and SHA256. Decoded JSON contains the same saved data.</p>'
        '<div class="links"><a href="frontier-audit-v1.html">Open the graph and proof reader</a><a href="frontier-audit-results-v1.json" download>Results summary</a></div>'
        '<p><!-- FRONTIER_ARCHIVE_LINK --></p></header><main><section class="card scope"><h2>Verification boundaries</h2>'
        '<p>Raw records contain the point model, finite universe, retained event/state observations and native search result. Full-stream claims depend on retained evidence and independent receipts; a checksum alone does not verify unseen suffixes. Abstract fixtures are not native logical proofs.</p>'
        '<p>No previous legacy checker refusal is converted into a pass. No newly trained RL, ATP superiority or universal Wang palette is claimed.</p></section>'
        '<section class="card"><h2>Per-run downloads</h2><div class="scroll"><table><thead><tr><th>Run</th><th>Files</th><th>Raw bytes</th><th>Raw SHA256</th></tr></thead><tbody>'+
        ''.join(rows)+'</tbody></table></div></section><section class="card"><h2>Input summary pin</h2><pre>'+
        html.escape(json.dumps(file_pin(raw_summary), indent=2))+'</pre></section></main><footer>Generated passively from retained data. The evidence page runs no solver or logical kernel.</footer>')
    (out / 'frontier-evidence-v1.html').write_text(page('GCTS frontier evidence', body))
    return dict(status='PASSIVE_REPORT_BUILT', runs=len(evidence_rows),
                summary_pin=file_pin((out / 'frontier-audit-results-v1.json').read_bytes()))


if __name__ == '__main__':
    if len(sys.argv) > 2:
        raise SystemExit('Usage: python3 report/build_report_v1.py [RUN]')
    run_root = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parents[1]
    print(json.dumps(build(run_root)), flush=True)
