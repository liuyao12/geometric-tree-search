"""Saved-byte joins and passive report summary; no scientific imports/replay."""
import collections
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def pin(path):
    raw=path.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(name):
    p=ROOT/name;raw=p.read_bytes()
    return json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw)
def ref(value):
    p=ROOT/value['path'];assert pin(p)=={k:value[k] for k in ('bytes','sha256')}
    return read(value['path'])
def save(name,value):
    p=ROOT/name;p.parent.mkdir(exist_ok=True,parents=True)
    with p.open('xb') as f:f.write(wire(value))

def main():
    phases={name:read('data/'+name+'-results-v1.json') for name in ('abstract','native','mutations')}
    for phase in phases:
        assert phases[phase]['status']=='COMPLETE' and phases[phase]['sources_unchanged']
        protocol=read('data/'+phase+'-protocol-v1.json')
        for name,expected in protocol['pins'].items():assert pin(ROOT/name)==expected,name
        assert read('review/'+phase+'-invocation-v1.json')['status']=='COMPLETE'
    counts=collections.Counter();native_logic=collections.Counter();checker_counts=collections.Counter()
    event_counts=collections.Counter();search_seconds=collections.Counter();checks=[]
    for group in ('abstract','native'):
        for row in phases[group]['records']:
            raw=ref(row['raw']);graph=ref(row['graph_check']);result=raw['result'];observations=raw['observations']
            assert row['id']==raw['id'] and row['result']==result['status'] and row['assurance']==graph['status']
            assert [o['event'] for o in observations]==result['events']
            assert result['event_extent']['total']==result['event_extent']['retained']==len(observations)
            assert graph['counts'].get('observations_checked',0)==len(observations)
            counts[group+'/result/'+result['status']]+=1;counts[group+'/assurance/'+graph['status']]+=1
            checker_counts.update(graph['counts']);event_counts.update(o['event']['kind'] for o in observations)
            search_seconds[group]+=raw['search_seconds']
            if result['entry_state'] is not None:assert result['entry_state']==result['restored_state']
            if group=='abstract':
                brute=ref(row['subset_check'])
                if result['status']!='UNKNOWN':assert brute['status']==result['status'] and graph['status']=='VERIFIED'
                row['route_checks']=dict(status='PASS' if row['route_checks'] else 'NOT_APPLICABLE',checks=row['route_checks'])
            else:
                native=ref(row['native_check']);exact=ref(row['all_proof_sets'])
                assert exact['status']=='COMPLETE' and graph['status']=='VERIFIED'
                assert bool(exact['proof_sets'])==(result['status']=='SAT')
                native_logic[native['status']]+=1
                if result['status']=='SAT':
                    assert native['status']=='VERIFIED' and result['selected'] in exact['proof_sets']
                    assert len(row['proof_reader'])==len(native['decoded']['proof'])
                    for proof_row,original,line in zip(row['proof_reader'],native['proof_reader'],native['decoded']['proof']):
                        assert proof_row['rule']==line['rule'] and original['formula']==line['formula']
                        assert proof_row['formula_latex']==original['formula_latex']
                        dependencies=([line['antecedent']+1,line['implication']+1] if line['rule']=='mp' else
                            [line['source']+1] if line['rule']=='generalize' else [])
                        assert proof_row['dependencies']==dependencies
                    for key in ('tree','native_fol_kernel','direct_fragment_kernel'):assert native[key]['status']=='VERIFIED'
            checks.append(dict(id=row['id'],raw_sha256=row['raw']['sha256'],status=result['status'],graph=graph['status'],events=len(observations)))
    assert len(phases['abstract']['records'])==24 and len(phases['native']['records'])==18
    assert counts['abstract/assurance/VERIFIED']==22 and counts['abstract/result/UNKNOWN']==2
    assert counts['abstract/assurance/UNKNOWN']==2
    assert counts['native/assurance/VERIFIED']==18 and native_logic['VERIFIED']==12
    mutants=[]
    for row in phases['mutations']['records']:
        evidence=ref(row['evidence']);checked=ref(row['check'])
        assert row['status']==checked['status'] and row['status']!='VERIFIED'
        assert evidence['id']==row['case_id']
        mutants.append(row)
    assert len(mutants)==12
    for row in phases['native']['disconnected_mutants']:
        assert row['point_complete'] is True and row['point_consistency']['status']=='VERIFIED'
        assert row['native_rejection']['status']=='REJECTED'
    assert len(phases['native']['disconnected_mutants'])==4
    acquisition=read('data/native-acquisition-v1.json')
    for row in acquisition['acquisition']['records']:
        assert row['factory_check']['status']==row['absence_check']['status']==row['marked_model_check']['status']=='VERIFIED'
        assert all(z['status']=='VERIFIED' for z in row['native_zero_checks'])
    preservation=phases['native']['preservation'];assert len(preservation)==6
    audit=dict(status='PASS',method='Saved evidence/ref/pin/census joins only; no engine, classifier, logical kernel or graph checker replay.',counts=dict(counts),native_logic=dict(native_logic),checker_counts=dict(checker_counts),event_counts=dict(event_counts),runs=checks,mutations=collections.Counter(x['status'] for x in mutants),disconnected_nonproofs=4,preservation=preservation)
    save('review/saved-data-audit-v1.json',audit)
    costs={name:read('review/'+name+'-invocation-v1.json') for name in phases}
    costs.update(native_preparation_seconds=phases['native']['preparation_seconds'],nested_search_seconds=dict(search_seconds),
        scope='Separate fresh main-invocation timers include inline verification and prior writes. Preparation and search subtotals are nested, not additive. Qualification is not a cold benchmark against an ATP.')
    summary=dict(schema='Proof-frontier-report-summary-v1',status='COMPLETE_QUALIFICATION',
        abstract=phases['abstract']['records'],native=phases['native']['records'],mutations=mutants,
        coverage=dict(searches=42,full_graph_verified_completed_searches=40,deliberate_unknown_searches=2,
            abstract_cases=24,native_cases=18,native_positive_proofs=12,bounded_native_exhaustions=6,
            event_snapshots=sum(event_counts.values()),indexed_queries_checked=checker_counts['queries_checked'],
            weighted_graph_checks=checker_counts['graphs_checked'],semantic_mutations_rejected=sum(x['status']=='REJECTED' for x in mutants),
            honest_truncation_unknown=sum(x['status']=='UNKNOWN' for x in mutants),disconnected_point_consistent_nonproofs_rejected=4,
            exact_native_proof_set_preservation=preservation),costs=costs,
        limitations=[
            'This gate qualifies these complete tiny traces under the unchanged indexed point engine; the earlier legacy graph-checker rejection is retained and historical sampled runs are not retroactively verified.',
            'The checker assumes an externally qualified complete immutable universe. Here the abstract inventories are explicit and exhaustively subset-checked; native factory, full row construction, failure certificates and logical proof checks are separately joined.',
            'This is an anchored symbolic proof-tree point profile with literal formula colors and global mark-only ports, not a fixed translation-only Wang square-grid palette or a universal first-order proof encoding.',
            'Native targets are fresh synthetic ground Horn and vacuous-generalization examples. No new Peano-arithmetic or Hilbert-geometry benchmark, RL training, ATP advantage, Turtle substitution, Penrose or plane-tiling result is established.',
            'Rollback logical states are independently reconstructed; internal trail indices are checked arithmetically, not instruction-by-instruction. Ordering traces must be complete permutations, but arbitrary future learned policies and macro expansions require their own admission audit.',
            'UNSAT here means exhaustion of the declared finite inventory and address bound. Neither bounded absence nor an interrupted search proves unrestricted logical nonprovability.'])
    save('data/report-summary-v1.json',summary)
    print(json.dumps(dict(status='PASS',coverage=summary['coverage']),sort_keys=True))

if __name__=='__main__':main()
