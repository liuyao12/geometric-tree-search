"""Prospective tiny abstract point fixtures, not mathematical proof claims.

Data construction and an exhaustive finite-universe incident provider only.
No engine, logical kernel or independent checker is imported or executed here.
Expected routes are qualification specifications, not recorded observations.
"""
import hashlib
import json


VERSION = 'Abstract-proof-frontier-fixtures-v1'
INDEXED_ABI = 'IP-CURRENT-TM-INCIDENT-v1'
RECOMMENDED_LIMITS = dict(wall_seconds=5.0, max_work=100000000, max_nodes=500,
    max_events=1024, max_rollback_records=1024, max_candidates=64, max_points=64)


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()


def _copy(value):
    return json.loads(wire(value))


def _universe(rows):
    _need(type(rows) is list and len(rows) <= 16, 'Abstract universe is a list of at most16 rows.')
    result, ids = [], set()
    for row in rows:
        _need(type(row) is dict and set(row) == {'id', 't', 'm'}, 'Exact placement fields required.')
        cid = row['id']
        _need(type(cid) is str and cid and cid not in ids, 'Unique nonempty literal CID required.')
        ids.add(cid)
        fields = {}
        for key in ('t', 'm'):
            _need(type(row[key]) is list, 'Point support must be a list.')
            seen, values = set(), []
            for pair in row[key]:
                _need(type(pair) is list and len(pair) == 2, 'Exact point/value pair required.')
                point, value = pair
                _need(type(point) is str and point not in seen, 'Distinct literal point IDs required.')
                seen.add(point)
                if key == 't':
                    _need(type(value) is int and value > 0, 'Positive native integer t units required.')
                else:
                    _need(type(value) is str, 'This engine ABI uses literal string marks.')
                values.append([point, value])
            fields[key] = sorted(values)
        _need(fields['t'], 'Nonempty positive support required.')
        result.append(dict(id=cid, **fields))
    return sorted(result, key=lambda row: row['id'])


def inventory_identity(universe):
    return 'ABSTRACT-FINITE-POINT-UNIVERSE-v1:' + digest(_universe(universe))


class Provider:
    """Complete pure t/m incident packets; selection/exclusion stay in engine.

    INDEXED_REFUSE consumes a bounded initial prefix then requests a charge
    larger than the fixture's declared work budget. The engine's owned refusal
    propagates; no partial packet or complete flag is ever returned on that path.
    """
    incident_query_abi = INDEXED_ABI

    def __init__(self, universe, mode='INDEXED'):
        _need(mode in ('INDEXED', 'INDEXED_REFUSE'), 'Unsupported provider mode.')
        self.universe = _universe(universe)
        self.identity = inventory_identity(self.universe)
        self.mode, self.calls = mode, 0
        self.attempts = []
        self.by_point = {}
        for row in self.universe:
            for point, units in row['t']:
                self.by_point.setdefault(point, []).append(row)

    def __call__(self, query, charge):
        _need(type(query) is dict and set(query) == {'schema', 'inventory_identity', 'point',
              'capacity', 'totals', 'marks'}, 'Exact indexed query fields required.')
        _need(query['schema'] == 'IP-current-tm-incident-query-v1'
              and query['inventory_identity'] == self.identity, 'Query ABI/inventory binding differs.')
        point, capacity = query['point'], query['capacity']
        _need(type(point) is str and type(capacity) is int and capacity > 0, 'Exact query point/capacity required.')
        context = {}
        for key in ('totals', 'marks'):
            _need(type(query[key]) is list, 'Context rows must be lists.')
            values = {}
            for pair in query[key]:
                _need(type(pair) is list and len(pair) == 2, 'Context point/value pairs required.')
                p, value = pair
                _need(type(p) is str and p not in values, 'Context point duplicated or malformed.')
                _need((type(value) is int and 0 <= value <= capacity) if key == 'totals'
                      else type(value) is str, 'Context value type/range differs.')
                values[p] = value
            context[key] = values
        self.calls += 1
        attempt = dict(call=self.calls, point=point, complete=False, examined=0, compatible=0)
        self.attempts.append(attempt)
        potential = self.by_point.get(point, [])
        compatible = []
        charge(1 + len(query['totals']) + len(query['marks']))
        for row in potential:
            charge(1 + len(row['t']) + len(row['m']))
            attempt['examined'] += 1
            _need(all(units <= capacity for p, units in row['t']), 'Universe units exceed query capacity.')
            legal = (all(context['totals'].get(p, 0) + units <= capacity for p, units in row['t'])
                     and all(p not in context['marks'] or context['marks'][p] == value
                             for p, value in row['m']))
            if legal:
                compatible.append(_copy(row))
                attempt['compatible'] += 1
            if self.mode == 'INDEXED_REFUSE':
                attempt['refusal'] = 'OWNED_MAX_WORK_REQUEST_AFTER_FIRST_EXAMINED_ROW'
                charge(1 << 128)
                raise RuntimeError('Fixture refusal requires its declared finite work limit.')
        if self.mode == 'INDEXED_REFUSE':
            attempt['refusal'] = 'OWNED_MAX_WORK_REQUEST_WITH_EMPTY_PACKET'
            charge(1 << 128)
            raise RuntimeError('Fixture refusal requires its declared finite work limit.')
        attempt['complete'] = True
        return dict(point=point, context_sha256=digest(query), complete=True,
            placements=compatible, certificate=dict(scope='COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET',
                potential_count=len(potential), compatible_count=len(compatible)))

    def snapshot(self):
        return dict(schema='Abstract-finite-provider-telemetry-v1', identity=self.identity,
                    mode=self.mode, calls=self.calls, attempts=_copy(self.attempts))


def provider_for(case):
    return None if case['provider_mode'] == 'EXPLICIT' else Provider(case['universe'], case['provider_mode'])


def _row(cid, t, m=()):
    return dict(id=cid, t=[list(pair) for pair in t], m=[list(pair) for pair in m])


def _case(cid, capacity, roots, seed_t, universe, status, checks, notes, seed_m=()):
    universe = _universe(universe)
    return dict(id=cid, capacity=capacity, roots=roots, seed_t=seed_t, seed_m=seed_m,
                universe=universe, expectation=dict(status=status, checks=checks), notes=notes)


def cases():
    """Twenty complete tiny cases plus one deliberate interrupted enumeration.

    Every base fixture is supplied in both EXPLICIT and honest INDEXED modes.
    An independent oracle may exhaust all subsets of the declared universe;
    generic exact active-point consistency is distinct from native proof truth.
    """
    base = []
    base.append(_case('untouched-zero', 2, ['a-full', 'z-empty'], [['a-full', 2]], [], 'UNSAT',
        [dict(route='READY->DEAD->EXHAUSTED', point='z-empty', generation=0),
         dict(assertion='Untouched zero root remains an obligation; no selected placement exists.')],
        'One root is full, the other has no positive alignment in the entire empty inventory.'))
    base.append(_case('late-global-dead', 2, ['a-trigger', 'b-early'],
        [['a-trigger', 1], ['b-early', 1]], [
            _row('a-trigger', [('a-trigger', 1), ('zz-remote-1000000', 1)]),
            _row('b-early-fill', [('b-early', 1)])], 'UNSAT',
        [dict(route='FORCED->PLACED->DEAD', candidate='a-trigger', dead_point='zz-remote-1000000'),
         dict(assertion='After trigger, generation1 dead point defeats generation0 singleton b-early.')],
        'Generations emerge from a real forced placement; remote is an opaque point ID, not a viewport.'))
    base.append(_case('global-forced-before-branch', 2, ['a-early', 'b-trigger'],
        [['a-early', 1], ['b-trigger', 1]], [
            *[_row('early-%d' % i, [('a-early', 1)]) for i in range(4)],
            _row('trigger', [('b-trigger', 1), ('z-late', 1)]),
            _row('late-fill', [('z-late', 1)])], 'SAT',
        [dict(assertion='FORCED trigger at generation0 precedes a-early degree4.'),
         dict(assertion='FORCED late-fill at generation1 precedes remaining a-early generation0 branch.')],
        'Exercises global forced precedence twice without injected generation metadata.'))
    base.append(_case('generation-before-degree', 2, ['a-early', 'b-trigger'],
        [['a-early', 1], ['b-trigger', 1]], [
            *[_row('early-%d' % i, [('a-early', 1)]) for i in range(4)],
            _row('trigger', [('b-trigger', 1), ('z-late', 1)]),
            *[_row('late-%d' % i, [('z-late', 1)]) for i in range(2)]], 'SAT',
        [dict(after_selected=['trigger'], decision='BRANCH', point='a-early', generation=0, degree=4,
              alternative=dict(point='z-late', generation=1, degree=2))],
        'A genuine growing point at generation1 has fewer candidates than the earlier root.'))
    base.append(_case('shared-weighted', 4, ['p', 'q'], [['p', 1], ['q', 2]], [
        _row('a-shared', [('p', 2), ('q', 1)]),
        _row('b-fill-p', [('p', 1)]), _row('c-fill-q', [('q', 1)])], 'SAT',
        [dict(at='READY', candidate='a-shared', incidences=[['p', 2], ['q', 1]], copies_of_this_candidate_node=1),
         dict(assertion='Shared candidate selected once, then remaining unit fillers are forced.')],
        'One CID has two differently weighted edges; edge counts and candidate counts differ.'))
    base.append(_case('selected-once-residual', 4, ['p'], [['p', 1]], [
        _row('only-fraction', [('p', 1)])], 'UNSAT',
        [dict(route='FORCED->PLACED->DEAD->EXHAUSTED', candidate='only-fraction'),
         dict(assertion='Residual total2 could fit the same units again, but selected inventory forbids CID reuse.')],
        'The sole fractional tile leaves an impossible residual; a forced move need not fill capacity.'))
    base.append(_case('remote-zero-global-removal', 2, ['a-choice', 'b-one', 'c-two'],
        [['a-choice', 1], ['b-one', 1], ['c-two', 1]], [
            _row('a-set-zero', [('a-choice', 1)], [('remote-port', '0')]),
            _row('b-set-one', [('a-choice', 1)], [('remote-port', '1')]),
            _row('c-shared-zero', [('b-one', 1), ('c-two', 1)], [('remote-port', '0')]),
            _row('d-shared-one', [('b-one', 1), ('c-two', 1)], [('remote-port', '1')])], 'SAT',
        [dict(after_selected=['a-set-zero'], removed_at_all_incident_points='d-shared-one'),
         dict(assertion='Mark-only remote-port is not required; explicit string0 stays assigned with referencecount2.')],
        'A mark-only assignment invalidates one shared candidate at both distant frontier points.'))
    base.append(_case('assigned-zero-versus-missing', 2, ['p'], [['p', 1]], [
        _row('a-absent', [('p', 1)]),
        _row('b-zero', [('p', 1)], [('far', '0')]),
        _row('c-one', [('p', 1)], [('far', '1')])], 'SAT',
        [dict(at='READY', legal=['a-absent', 'b-zero'], illegal=['c-one']),
         dict(assertion='Seed literal0 conflicts with1; a missing assignment is unconstrained.')],
        'This ABI uses exact literal strings: string0 is an assigned mark, not an absent sentinel.',
        seed_m=[['far', '0']]))
    base.append(_case('rollback-revival', 2, ['r'], [['r', 1]], [
        _row('a-bad', [('r', 1), ('p', 1)], [('remote', '1')]),
        _row('b-good', [('r', 1), ('p', 1)], [('remote', '0')]),
        _row('c-filler', [('p', 1)], [('remote', '0')])], 'SAT',
        [dict(route='BRANCH a-bad->DEAD p->EXCLUDE a-bad->FORCED b-good->FORCED c-filler'),
         dict(assertion='Remote mark, domains, discovery/exhaustion and dependencies restore before sibling.'),
         dict(assertion='Indexed p packet is empty in bad child and contains c-filler in good sibling.')],
        'A previously incompatible omitted row must be rediscovered after rollback; no global negative cache.'))
    base.append(_case('nested-exclusion-scope', 2, ['r'], [['r', 1]], [
        _row('a-outer-bad', [('r', 1), ('p', 1)], [('remote', '1')]),
        _row('b-outer-good', [('r', 1), ('p', 1)], [('remote', '0')]),
        _row('c-inner', [('p', 1), ('q', 1)]),
        _row('d-inner', [('p', 1), ('w', 1)]),
        _row('e-fill-q', [('q', 1)], [('remote', '0')]),
        _row('f-fill-w', [('w', 1)], [('remote', '0')])], 'SAT',
        [dict(assertion='Bad outer branch: inner c fails, is excluded, then forced d fails.'),
         dict(assertion='Undo outer branch removes inner exclusion; c-inner is legal again under b-outer-good.'),
         dict(assertion='A forced move after an inner branch is rolled back with the outer frame.')],
        'Nested failures make a sibling-context exclusion leak observable in a bounded six-row universe.'))
    result = []
    for specification in base:
        for mode in ('EXPLICIT', 'INDEXED'):
            universe = _copy(specification['universe'])
            inventory = (dict(kind='EXPLICIT', placements=universe) if mode == 'EXPLICIT' else
                         dict(kind='CERTIFIED_INCIDENT', identity=inventory_identity(universe)))
            model = dict(schema='Z-growing-point-model-v1', version=VERSION,
                capacity=specification['capacity'], roots=sorted(specification['roots']),
                seed=dict(t=sorted(_copy(specification['seed_t'])), m=sorted(_copy(specification['seed_m']))),
                inventory=inventory)
            result.append(dict(id=specification['id']+'-'+mode.lower(), model=model,
                universe=universe, provider_mode=mode,
                expectation=_copy(specification['expectation']), notes=specification['notes']))
    universe = _universe([_row('a', [('p', 2)]), _row('b', [('p', 2)])])
    result.append(dict(id='partial-provider-refusal', provider_mode='INDEXED_REFUSE', universe=universe,
        model=dict(schema='Z-growing-point-model-v1', version=VERSION, capacity=2, roots=['p'],
            seed=dict(t=[], m=[]), inventory=dict(kind='CERTIFIED_INCIDENT', identity=inventory_identity(universe))),
        expectation=dict(status='UNKNOWN', reason='MAX_WORK', limit_overrides=dict(max_work=100000000),
            checks=[dict(assertion='No partial packet is returned or certified exhausted.'),
                    dict(assertion='No DEAD/FORCED/EXHAUSTED decision can use the unfinished enumeration.')]),
        notes='Provider examines its first row then propagates the engine-owned work refusal; no checker or solver is called by this fixture.'))
    return result


def mutation_specs():
    """Declarative attack routes for the new independent graph/evidence checker.

    These do not mutate a run or imply that a rejection has been observed. The
    harness selects a genuine retained context, applies the specified edit and
    recomputes ordinary container digests when requested, so acceptance cannot
    depend merely on noticing a stale checksum. Keep pristine evidence intact.
    """
    return [
        dict(id='missing-shared-edge', case_id='shared-weighted-indexed', target='READY checkpoint',
            operation='Remove q/a-shared incidence coherently from domains, forward, reverse and edge_count.',
            keep='Universe, CID rows and exact seed remain unchanged.',
            expected='REJECTED_EVIDENCE', obligation='Complete independently reconstructed shared incidence.'),
        dict(id='wrong-edge-weight', case_id='shared-weighted-explicit', target='READY checkpoint',
            operation='Change p/a-shared contribution2 to1 in forward and reverse, preserving counts.',
            expected='REJECTED_EVIDENCE', obligation='Edge weight must equal immutable CID positive support.'),
        dict(id='mark-dependency-omission', case_id='remote-zero-global-removal-explicit', target='READY checkpoint',
            operation='Remove d-shared-one from dependencies.m at remote-port; preserve current domains.',
            expected='REJECTED_EVIDENCE', obligation='Complete marking dependencies, including outside Q.'),
        dict(id='missing-indexed-row-adjusted-count', case_id='generation-before-degree-indexed',
            target='First completed packet for a-early, which has four compatible rows.',
            operation='Remove one returned early CID and decrement compatible_count; retain completeTrue and original potential_count.',
            recompute_container_hashes=True, expected='REJECTED_EVIDENCE',
            obligation='Exhaustive finite universe oracle, not self-consistent packet counts.'),
        dict(id='wrong-emergent-generation', case_id='generation-before-degree-explicit',
            target='Checkpoint after PLACED trigger',
            operation='Change z-late point generation1 to0 while preserving all cardinalities.',
            expected='REJECTED_EVIDENCE', obligation='Chronological recurrence and explicit-root provenance.'),
        dict(id='changed-cid-content', case_id='shared-weighted-indexed', target='A later packet containing a-shared',
            operation='Change a-shared positive units under its existing CID; update packet counts/digests coherently.',
            recompute_container_hashes=True, expected='REJECTED_EVIDENCE',
            obligation='Immutable universe identity and exact describe(CID) content.'),
        dict(id='forged-exclude-without-failure', case_id='rollback-revival-explicit', target='READY checkpoint/trace',
            operation='Inject EXCLUDE a-bad and coherently remove its eligibility/edges before any failed child.',
            expected='REJECTED_EVIDENCE', obligation='Acyclic checked failure in the identical parent context.'),
        dict(id='exclusion-from-unknown', case_id='partial-provider-refusal', target='Unresolved enumeration outcome',
            operation='Forge exhausted failure/EXCLUDE justification from this UNKNOWN refusal.',
            expected='REJECTED_EVIDENCE', obligation='Budget or incomplete inventory cannot justify pruning.'),
        dict(id='sibling-exclusion-leak', case_id='nested-exclusion-scope-indexed',
            target='Parent restored after a-outer-bad fails',
            operation='Retain inner exclusion c-inner into b-outer-good context, coherently removing its graph incidences.',
            expected='REJECTED_EVIDENCE', obligation='Exclusion lifetime is its branch frame, not a global CID ban.'),
        dict(id='honest-truncated-retention', case_id='nested-exclusion-scope-indexed',
            target='All-event evidence stream',
            operation='Retain a strict prefix, keep accurate original total/retained distinction and stream hash.',
            expected='UNKNOWN_OR_REJECTED_EVIDENCE',
            obligation='No conformance PASS from unseen event/checkpoint suffixes.'),
        dict(id='forged-complete-truncation', case_id='nested-exclusion-scope-indexed',
            target='All-event evidence stream',
            operation='Remove an intermediate actual checkpoint/transition and falsely declare complete retention.',
            recompute_container_hashes=True, expected='REJECTED_EVIDENCE',
            obligation='Replay continuity, child/EXCLUDE provenance and final endpoint must all join.'),
    ]
