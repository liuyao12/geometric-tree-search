"""Prospective tiny full-stream audit. Persist native data before assurance.

No policy learning or performance benchmark is claimed. Scientific searches
are never repeated merely because their independent assurance is refused.
"""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
ENGINE_SHA='6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb'
DEFAULT_LIMITS=dict(wall_seconds=10,max_work=500000000,max_nodes=5000,
    max_events=50000,max_rollback_records=50000,max_candidates=10000,max_points=4096)

def wire(v):
    return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')

def pin(p):
    raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def save(name,value):
    path=ROOT/name;path.parent.mkdir(parents=True,exist_ok=True)
    raw=wire(value)
    if name.endswith('.gz'):raw=gzip.compress(raw,mtime=0)
    with path.open('xb') as f:f.write(raw)
    return dict(path=name,**pin(path))

def load(name):
    raw=(ROOT/name).read_bytes()
    if name.endswith('.gz'):raw=gzip.decompress(raw)
    return json.loads(raw)

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value

def freeze(phase):
    names=sorted(p.relative_to(ROOT).as_posix() for directory in ('source','reference','upstream')
        for p in (ROOT/directory).rglob('*') if p.is_file() and p.suffix in ('.py','.md'))
    protocol=dict(schema='Proof-frontier-prospective-protocol-v1',phase=phase,
        pins={name:pin(ROOT/name) for name in names},python=dict(path=sys.executable,version=sys.version,**pin(Path(sys.executable))),
        limits=DEFAULT_LIMITS,scope='Qualification of full tiny traces; finite declared inventories only. No RL training, ATP speedup or universal Wang grid claim.')
    save('data/'+phase+'-protocol-v1.json',protocol)
    return protocol

def unchanged(protocol):
    for name,expected in protocol['pins'].items():assert pin(ROOT/name)==expected,name

def exhaust_subsets(model,universe):
    """Independent brute-force point subsets; no frontier scheduler or provider."""
    started=time.perf_counter();assert len(universe)<=16
    cap=model['capacity'];accepted=[];examined=0
    for bits in range(1<<len(universe)):
        examined+=1;totals=dict(model['seed']['t']);marks=dict(model['seed']['m'])
        required=set(model['roots'])|{p for p,n in model['seed']['t'] if n}
        chosen=[];valid=True
        for i,row in enumerate(universe):
            if not bits>>i&1:continue
            chosen.append(row['id'])
            for p,n in row['t']:
                totals[p]=totals.get(p,0)+n;required.add(p)
                if totals[p]>cap:valid=False;break
            if not valid:break
            for p,v in row['m']:
                if p in marks and marks[p]!=v:valid=False;break
                marks[p]=v
            if not valid:break
        if valid and all(totals.get(p,0)==cap for p in required):accepted.append(sorted(chosen))
    return dict(status='SAT' if accepted else 'UNSAT',examined_subsets=examined,
        exact_point_solution_sets=accepted,seconds=time.perf_counter()-started,
        scope='Every placement subset of the declared finite point inventory. Disconnected components are allowed by generic point semantics; this is not native rooted proof validity.')

def run_case(engine,checker,case,provider,phase):
    limits=dict(DEFAULT_LIMITS);limits.update(case.get('expectation',{}).get('limit_overrides',{}))
    observations=[]
    def audit(event,state,charge):
        # Engine gives detached event/snapshot values; retain every callback.
        observations.append(dict(event=event,state=state))
    order_calls=[]
    def order(request,charge):
        charge();kind=case.get('order_mode')
        preferred=[] if kind=='EMPTY' else list(reversed(request['legal']))[:1]
        order_calls.append(dict(request=copy.deepcopy(request),preferred=list(preferred)))
        return preferred
    kwargs=dict(audit=audit)
    if model_kind(case)=='CERTIFIED_INCIDENT':kwargs['enumerate_incident']=provider
    if case.get('order_mode'):kwargs['order']=order
    started=time.perf_counter();result=engine.solve(case['model'],limits,**kwargs)
    search_seconds=time.perf_counter()-started
    raw=dict(id=case['id'],phase=phase,model=case['model'],universe=case['universe'],
        provider_mode=case.get('provider_mode'),expectation=case.get('expectation'),notes=case.get('notes'),
        limits=limits,observations=observations,result=result,order_calls=order_calls,search_seconds=search_seconds)
    ref=save('data/'+phase+'/'+case['id']+'-raw.json.gz',raw)
    checked=checker.verify(case['model'],case['universe'],observations,result,max_items=20000000,wall_seconds=30)
    checked_ref=save('data/'+phase+'/'+case['id']+'-graph-check.json',checked)
    print(json.dumps(dict(id=case['id'],result=result['status'],assurance=checked['status'],events=len(observations))),flush=True)
    return raw,dict(id=case['id'],raw=ref,graph_check=checked_ref,result=result['status'],assurance=checked['status'])

def model_kind(case):return case['model']['inventory']['kind']

def qualified_abstract_cases(fixtures):
    cases=fixtures.cases();by_id={c['id']:c for c in cases}
    for mode in ('EMPTY','PARTIAL_REVERSE'):
        c=copy.deepcopy(by_id['shared-weighted-indexed'])
        c['id']='fallback-'+mode.lower();c['order_mode']=mode
        c['notes']+=' Ordering callback supplies '+mode+' preferences; complete primitive fallback is mandatory.'
        cases.append(c)
    c=copy.deepcopy(by_id['rollback-revival-indexed']);c['id']='unknown-in-child'
    c['expectation']=dict(status='UNKNOWN',reason='MAX_NODES',limit_overrides=dict(max_nodes=1))
    c['notes']='Stop after the first branch placement, before checking the child. It must not become a failed-child exclusion.'
    cases.append(c)
    return cases

def route_checks(raw):
    events=[x['event'] for x in raw['observations']];states=[x['state'] for x in raw['observations']]
    base=raw['id'];checks=[]
    def need(ok,label):
        assert ok,(base,label);checks.append(label)
    if base.startswith('late-global-dead'):
        i=next(i for i,e in enumerate(events) if e['kind']=='PLACED')
        need(events[i+1]['kind']=='DEAD' and events[i+1]['point']=='zz-remote-1000000','remote dead before earlier singleton')
    if base.startswith('global-forced-before-branch'):
        need([e['candidate'] for e in events if e['kind']=='FORCED'][:2]==['trigger','late-fill'],'later forced before earlier branch')
    if base.startswith('generation-before-degree'):
        e=next(e for e in events if e['kind']=='BRANCH')
        need(e['point']=='a-early' and len(e['data']['legal'])==4,'generation before smaller degree')
    if base.startswith('rollback-revival'):
        need(any(e['kind']=='EXCLUDE' and e['candidate']=='a-bad' for e in events),'actual failed-child exclusion')
        need(raw['result']['selected']==['b-good','c-filler'],'sibling revival solves')
    if base.startswith('nested-exclusion-scope'):
        need(any(e['kind']=='EXCLUDE' and e['candidate']=='c-inner' for e in events),'inner exclusion occurred')
        need('c-inner' in raw['result']['selected'],'inner candidate revived after outer undo')
    if base.startswith('selected-once-residual'):
        need(sum(e['kind']=='PLACED' for e in events)==1,'selected fractional CID used once')
    if base.startswith('remote-zero-global-removal'):
        s=next(s for e,s in zip(events,states) if e['kind']=='PLACED' and e['candidate']=='a-set-zero')
        need(all('d-shared-one' not in ids for p,ids in s['domains']),'mark-only change removes every shared incidence')
    if base=='unknown-in-child':
        need(not any(e['kind'] in ('EXCLUDE','EXHAUSTED') for e in events),'unknown child never used as failure')
        need(raw['result']['entry_state']==raw['result']['restored_state'],'unknown child restores complete entry')
    if base=='partial-provider-refusal':
        need(not events and raw['result']['entry_state'] is None,'partial enumeration emits no certified decision')
    if base.startswith('fallback-'):
        need(bool(raw['order_calls']),'ordering hook actually called')
        for e in events:
            if e['kind']=='BRANCH':need(set(e['data']['order'])==set(e['data']['legal']),'full primitive fallback retained')
    return checks

def abstract_main():
    fixtures=module('abstract_fixtures_v1','source/abstract_fixtures_v1.py')
    engine=module('pinned_point_engine','reference/growing_point_search_v2.py')
    assert pin(ROOT/'reference/growing_point_search_v2.py')['sha256']==ENGINE_SHA
    checker=module('frontier_trace_checker_v1','reference/frontier_trace_checker_v1.py')
    protocol=freeze('abstract');cases=qualified_abstract_cases(fixtures)
    save('data/abstract-cases-v1.json',cases);records=[]
    for case in cases:
        raw,record=run_case(engine,checker,case,fixtures.provider_for(case),'abstract')
        brute=exhaust_subsets(case['model'],case['universe'])
        record['subset_check']=save('data/abstract/'+case['id']+'-subsets.json',brute)
        expected=case['expectation']['status']
        assert raw['result']['status']==expected,(case['id'],raw['result']['status'],expected)
        if 'reason' in case['expectation']:assert raw['result']['reason']==case['expectation']['reason']
        if expected in ('SAT','UNSAT'):
            assert brute['status']==expected,(case['id'],brute['status'],expected)
            assert record['assurance']=='VERIFIED',(case['id'],load(record['graph_check']['path']))
        else:assert record['assurance']=='UNKNOWN',(case['id'],record)
        record['route_checks']=route_checks(raw);records.append(record)
    unchanged(protocol)
    save('data/abstract-results-v1.json',dict(status='COMPLETE',records=records,sources_unchanged=True))

def native_main():
    engine=module('pinned_point_engine','reference/growing_point_search_v2.py')
    assert pin(ROOT/'reference/growing_point_search_v2.py')['sha256']==ENGINE_SHA
    checker=module('frontier_trace_checker_v1','reference/frontier_trace_checker_v1.py')
    fixtures=module('native_fixtures_v1','source/native_fixtures_v1.py')
    protocol=freeze('native');started=time.perf_counter();prepared=fixtures.prepare()
    preparation_seconds=time.perf_counter()-started
    save('data/native-acquisition-v1.json',dict(status=prepared['status'],acquisition=prepared['acquisition'],seconds=preparation_seconds))
    cases=prepared['cases'];records=[];sets={};disconnected=[]
    save('data/native-cases-v1.json',[{k:v for k,v in c.items() if k!='provider'} for c in cases])
    for case in cases:
        setup_start=time.perf_counter();model,provider,factory=fixtures.make_provider(case)
        setup_seconds=time.perf_counter()-setup_start
        assert wire(model)==wire(case['model'])
        case=dict(case,model=model)
        raw,record=run_case(engine,checker,case,provider,'native')
        exact=fixtures.exhaustive_proof_sets(case)
        exact_ref=save('data/native/'+case['id']+'-all-proof-sets.json',exact)
        native=fixtures.check_solution(case,raw['result'])
        native_ref=save('data/native/'+case['id']+'-native-check.json',native)
        reader=native.get('proof_reader',native.get('reader',[]))
        reader=[dict(line=r['line'],formula_latex=r.get('formula_latex',r.get('latex')),
            english=r['english']+' '+r.get('reason',''),rule=r['rule'],
            dependencies=r.get('dependencies',r.get('references',[]))) for r in reader]
        record.update(mode=case['mode'],goal_label=case.get('goal_label',case['id']),depth=case['depth'],
            native_check=native_ref,all_proof_sets=exact_ref,setup_seconds=setup_seconds,
            proof_reader=reader,theory_reader=case.get('reader'))
        save('data/native/'+case['id']+'-joined-record.json',record)
        assert record['assurance']=='VERIFIED',(case['id'],load(record['graph_check']['path']))
        assert exact['status']=='COMPLETE'
        expected='SAT' if exact['proof_sets'] else 'UNSAT'
        assert raw['result']['status']==expected,(case['id'],raw['result']['status'],expected)
        if expected=='SAT':
            assert native['status']=='VERIFIED',(case['id'],native)
            assert sorted(raw['result']['selected']) in exact['proof_sets']
            if case['mode']=='BASE' and case.get('goal_label') in ('G','forall-P'):
                bad=fixtures.disconnected_mutant(case,raw['result']['selected'])
                assert bad['point_complete'] is True and bad['native_rejection']['status']=='REJECTED'
                disconnected.append(dict(case_id=case['id'],**bad))
                save('data/native/'+case['id']+'-disconnected-mutant.json',bad)
        key=(json.dumps(case['compiled']['goal'],sort_keys=True),case['depth'])
        sets.setdefault(key,{})[case['mode']]=exact['proof_sets']
        records.append(record)
    preservation=[]
    for (goal,depth),lanes in sorted(sets.items()):
        assert set(lanes)=={'BASE','MARKS','FILTER'}
        assert wire(lanes['BASE'])==wire(lanes['MARKS'])==wire(lanes['FILTER'])
        preservation.append(dict(goal=json.loads(goal),depth=depth,complete_proof_sets=len(lanes['BASE']),identical_modes=['BASE','MARKS','FILTER']))
    unchanged(protocol)
    save('data/native-results-v1.json',dict(status='COMPLETE',records=records,preservation=preservation,
        disconnected_mutants=disconnected,preparation_seconds=preparation_seconds,sources_unchanged=True))

def mutations_main():
    checker=module('frontier_trace_checker_v1','reference/frontier_trace_checker_v1.py')
    mutations=module('evidence_mutations_v1','source/evidence_mutations_v1.py')
    protocol=freeze('mutations');result=load('data/abstract-results-v1.json')
    by_id={r['id']:load(r['raw']['path']) for r in result['records']};records=[]
    for attack in mutations.attacks(by_id):
        raw=attack.pop('raw');ref=save('data/mutations/'+attack['id']+'-evidence.json.gz',raw)
        receipt=checker.verify(raw['model'],raw['universe'],raw['observations'],raw['result'],max_items=20000000,wall_seconds=30)
        check_ref=save('data/mutations/'+attack['id']+'-check.json',receipt)
        entry=dict(**attack,evidence=ref,check=check_ref,status=receipt['status'],reason=receipt.get('reason'))
        records.append(entry);print(json.dumps(entry),flush=True)
        allowed=('REJECTED','UNKNOWN') if attack['expected']=='UNKNOWN_OR_REJECTED' else ('REJECTED',)
        assert receipt['status'] in allowed,entry
    unchanged(protocol)
    save('data/mutations-results-v1.json',dict(status='COMPLETE',records=records,sources_unchanged=True))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=('abstract','native','mutations'));args=parser.parse_args()
    started=time.perf_counter()
    try:
        if args.phase=='abstract':abstract_main()
        elif args.phase=='native':native_main()
        else:mutations_main()
    finally:
        cost=dict(status='FAILED' if sys.exc_info()[0] else 'COMPLETE',phase=args.phase,
            main_invocation_seconds=time.perf_counter()-started,ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            platform=sys.platform,scope='This one fresh process main invocation, including preparation, search, all inline checking and prior writes; interpreter startup and this final cost receipt excluded. ru_maxrss is process lifetime high-water RSS (bytes on Darwin).')
        save('review/'+args.phase+'-invocation-v1.json',cost)

if __name__=='__main__':main()
