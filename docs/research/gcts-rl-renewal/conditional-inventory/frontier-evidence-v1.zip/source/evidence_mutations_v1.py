"""Semantic mutations of saved tiny evidence; never re-executes search."""
import copy
import hashlib
import json

def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def stream(rows):return hashlib.sha256(b''.join(wire(x) for x in rows)).hexdigest()

def rehash(raw):
    """Keep checksums/cardinalities coherent, so semantic checks do the work."""
    result=raw['result'];observations=raw['observations']
    for i,x in enumerate(observations):x['event']['seq']=i
    result['events']=[copy.deepcopy(x['event']) for x in observations]
    result['event_extent'].update(total=len(observations),retained=len(observations),sha256=stream(result['events']))
    result['stats']['events_total']=len(observations);result['stats']['audit_calls']=len(observations)
    if observations and observations[0]['event']['kind']=='READY':
        result['entry_state']=copy.deepcopy(observations[0]['state'])
        result['restored_state']=copy.deepcopy(result['entry_state'])
    if result['final_state'] is not None and observations:result['final_state']=copy.deepcopy(observations[-1]['state'])
    for field,key in (('entry_state','entry'),('final_state','final'),('restored_state','restored')):
        result['state_hashes'][key]=None if result[field] is None else sha(result[field])
    evidence=result['provider_evidence'];rows=evidence['records']
    evidence.update(total=len(rows),retained=len(rows),sha256=stream(rows))

def remove_edges(state,cid,point=None):
    for p,ids in state['domains']:
        if point is None or p==point:
            if cid in ids:ids.remove(cid)
    state['forward']=[x for x in state['forward'] if not (x[1]==cid and (point is None or x[0]==point))]
    new=[]
    for c,rows in state['reverse']:
        if c==cid:rows=[x for x in rows if point is not None and x[0]!=point]
        if rows:new.append([c,rows])
    state['reverse']=new;state['edge_count']=len(state['forward'])

def attacks(by_id):
    """Yield immutable pristine case plus a coordinated corrupted evidence copy."""
    def base(cid):return copy.deepcopy(by_id[cid])
    def out(name,cid,raw,expected='REJECTED'):
        rehash(raw);return dict(id=name,case_id=cid,expected=expected,raw=raw)
    cid='shared-weighted-indexed';raw=base(cid)
    remove_edges(raw['observations'][0]['state'],'a-shared','q')
    yield out('missing-shared-incidence',cid,raw)
    cid='shared-weighted-explicit';raw=base(cid);s=raw['observations'][0]['state']
    for row in s['forward']:
        if row[:2]==['p','a-shared']:row[2]=1
    for c,rows in s['reverse']:
        if c=='a-shared':
            for row in rows:
                if row[0]=='p':row[1]=1
    yield out('wrong-weight-coherent-both-directions',cid,raw)
    cid='remote-zero-global-removal-explicit';raw=base(cid)
    bucket=next(ids for p,ids in raw['observations'][0]['state']['dependencies']['m'] if p=='remote-port')
    bucket.remove('d-shared-one')
    yield out('omitted-remote-mark-dependency',cid,raw)
    cid='generation-before-degree-indexed';raw=base(cid)
    record=next(x for x in raw['result']['provider_evidence']['records'] if x['query']['point']=='a-early')
    assert len(record['reply']['placements'])==4
    record['reply']['placements'].pop();record['reply']['certificate']['compatible_count']-=1
    yield out('omitted-packet-row-adjusted-count',cid,raw)
    cid='generation-before-degree-explicit';raw=base(cid)
    s=next(x['state'] for x in raw['observations'] if x['event']['kind']=='PLACED' and x['event']['candidate']=='trigger')
    next(x for x in s['Q'] if x[0]=='z-late')[1]=0
    yield out('wrong-emergent-generation',cid,raw)
    cid='shared-weighted-indexed';raw=base(cid)
    packet=next(x for x in raw['result']['provider_evidence']['records'] if any(r['id']=='a-shared' for r in x['reply']['placements']))
    row=next(r for r in packet['reply']['placements'] if r['id']=='a-shared')
    next(x for x in row['t'] if x[0]=='p')[1]=1
    yield out('changed-placement-under-same-cid',cid,raw)
    cid='rollback-revival-explicit';raw=base(cid)
    s=copy.deepcopy(raw['observations'][0]['state']);s['excluded'].append('a-bad');s['eligible'].remove('a-bad');remove_edges(s,'a-bad')
    raw['observations'].insert(1,dict(event=dict(seq=1,kind='EXCLUDE',point=None,candidate='a-bad',data={}),state=s))
    yield out('exclusion-without-failed-child',cid,raw)
    cid='nested-exclusion-scope-indexed';raw=base(cid)
    s=next(x['state'] for x in raw['observations'] if x['event']['kind']=='PLACED' and x['event']['candidate']=='b-outer-good')
    assert 'c-inner' in s['eligible'];s['excluded'].append('c-inner');s['excluded'].sort();s['eligible'].remove('c-inner');remove_edges(s,'c-inner')
    yield out('inner-exclusion-leaks-into-sibling',cid,raw)
    cid='nested-exclusion-scope-indexed';raw=base(cid)
    # Accurate stream metadata remains original: omitted callbacks cannot pass.
    raw['observations']=raw['observations'][:-1]
    yield dict(id='honest-truncated-callback-stream',case_id=cid,expected='UNKNOWN_OR_REJECTED',raw=raw)
    raw=base(cid)
    i=next(i for i,x in enumerate(raw['observations']) if x['event']['kind']=='EXCLUDE')
    del raw['observations'][i]
    yield out('forged-complete-missing-exclude-transition',cid,raw)
    cid='unknown-in-child';raw=base(cid)
    parent=copy.deepcopy(raw['observations'][0]['state']);parent['excluded'].append('a-bad')
    parent['eligible'].remove('a-bad');remove_edges(parent,'a-bad')
    raw['observations'].append(dict(event=dict(seq=3,kind='EXCLUDE',point=None,candidate='a-bad',data={}),state=parent))
    raw['result']['status']='UNSAT';raw['result']['reason']='EXHAUSTED_DECLARED_FINITE_INVENTORY'
    yield out('unknown-prefix-cannot-justify-exclusion',cid,raw)
    cid='partial-provider-refusal';raw=base(cid)
    raw['result']['status']='UNSAT';raw['result']['reason']='EXHAUSTED_DECLARED_FINITE_INVENTORY'
    yield out('partial-enumeration-cannot-prove-exhaustion',cid,raw)
