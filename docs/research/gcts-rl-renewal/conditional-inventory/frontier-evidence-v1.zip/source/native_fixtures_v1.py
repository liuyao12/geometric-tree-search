"""Fresh declarative native first-order fixtures; inert until prepare() is called.

No expected proof or chosen derivation is supplied to a solver. The reference
enumerator is a separate post-search API that returns ALL rooted bounded proof
sets. All imported scientific dependencies are exact pinned, unchanged copies.
"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import itertools
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'PFA-fresh-native-fixtures-v1'
PINS = {
    'finite_basis_v1.py': '97225dcffd98dd5386aeb560a2fc5634dfcc4606ff475a46536207768932a0dc',
    'proof_core_v1.py': 'd363b72e6f4355225d3dbbdc66c64f746d27bf96de5c4d8a17471cc95b70091c',
    'failure_markings_v1.py': '4b0f735c6a1114925fd1032c2a5cba37bffa61f447a0b71e1aaea8bf8e09a529',
    'failure_certificate_checker_v1.py': '2436cc872737f9400c7bbb78949a366919a64804ca3088be1577fcdc7c7e88db',
    'marked_point_checker_v1.py': '513ac4c616a2db3154c79156f40807228c9a667f601230a35330673d3105aa26',
    'indexed_proof_provider_v1.py': '5261bf552924105f3c9ac3a4e9ddce0490869105b1812a8d897610267623b26e',
    'growing_proof_verifier_v2.py': '6286d6b151d460e6ee0b97983fd9f081168a6d76256a33c3e0f9ead0ffae3aa1',
    'independent_fol_checker_v1.py': '099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1',
}
FACTORY_LIMITS = dict(max_work=1000000000, max_depth=256, max_definitions=20000,
                      max_proof_lines=4096, wall_seconds=15)
VERIFY_LIMITS = dict(max_depth=256, max_items=20000000, max_work=1000000000, wall_seconds=15)
KERNEL_LIMITS = dict(max_depth=256, max_operations=10000000, max_proof_lines=4096)
_MODULES = None


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def sha(value):
    return hashlib.sha256((text(value)+'\n').encode('ascii')).hexdigest()


def source_pins():
    records = {}
    for name, expected in PINS.items():
        path = ROOT/'reference/upstream'/name
        data = path.read_bytes()
        _need(hashlib.sha256(data).hexdigest() == expected, 'PINNED_SOURCE:'+name)
        records['reference/upstream/'+name] = dict(bytes=len(data), sha256=expected)
    return records


def _modules():
    global _MODULES
    source_pins()
    if _MODULES is not None:
        return _MODULES
    modules, absent = {}, object()
    saved = {name: sys.modules.get(name, absent)
             for name in ('proof_core_v1', 'failure_certificate_checker_v1')}
    try:
        for name in ('proof_core_v1', 'finite_basis_v1', 'failure_certificate_checker_v1',
                     'failure_markings_v1', 'marked_point_checker_v1',
                     'indexed_proof_provider_v1', 'growing_proof_verifier_v2',
                     'independent_fol_checker_v1'):
            path = ROOT/'reference/upstream'/(name+'.py')
            spec = importlib.util.spec_from_file_location('pfa_pinned_'+name, path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            modules[name] = module
            if name in saved:
                sys.modules[name] = module
    finally:
        for name, value in saved.items():
            if value is absent:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value
    _MODULES = modules
    return modules


def declarations():
    """Only syntax, names, goals and bounds. No expected outcomes or proof IDs."""
    records = []
    for goal_kind in ('G', 'U', 'forallP'):
        for depth in (2, 3):
            label = 'pfa-native-%s-depth%d-v1' % (goal_kind, depth)
            stem = 'pf'+hashlib.sha256(('fresh-PFA-20261103:'+label).encode()).hexdigest()[:8]
            names = {key: stem+key for key in ('c', 'x', 'P', 'Q', 'U', 'G')}
            constant = ['fun', names['c'], []]
            atoms = {key: ['pred', names[key], [constant]] for key in ('P', 'Q', 'U', 'G')}
            p, q, u, g = (atoms[k] for k in ('P', 'Q', 'U', 'G'))
            axioms = {stem+'fact': p, stem+'duplicateFact': p,
                      stem+'step': ['imp', p, q], stem+'finish': ['imp', q, g],
                      stem+'deadAlternative': ['imp', u, g],
                      stem+'ungroundedCycle': ['imp', u, u], stem+'padding': ['imp', q, q]}
            goal = ['all', names['x'], p] if goal_kind == 'forallP' else atoms[goal_kind]
            theory = dict(functions={names['c']: 0}, predicates={names[k]: 1 for k in ('P', 'Q', 'U', 'G')},
                          axioms=axioms)
            records.append(dict(id=label, depth=depth, goal_kind=goal_kind, names=names,
                problem=dict(theory=theory, goal=goal), terms=[constant],
                profile=dict(ui_rounds=0, max_terms=2, max_templates=0, max_definitions=100),
                scope='Fresh renamed closed ground Horn hypotheses, duplicated initial fact and vacuous universal goal. No target derivation or output proof supplied.'))
    return copy.deepcopy(records)


def _definitions(compiled, declaration):
    """Independent intended ZERO set, syntax indices and native descriptors."""
    colors = compiled['logical_basis']['colors']
    forms = compiled['logical_basis']['formulas']
    _need(colors == sorted(set(colors)) and colors == [text(f) for f in forms], 'LITERAL_FORMULA_REGISTRY')
    ids = {color: i for i, color in enumerate(colors)}
    theory = declaration['problem']['theory']
    c = declaration['terms'][0]
    intended = [dict(rule='axiom', name=name, formula=formula) for name, formula in theory['axioms'].items()]
    intended += [dict(rule='refl', formula=['eq', c, c])]
    intended.sort(key=text)
    actual = compiled['zero_instances']
    _need(len(actual) == len(intended) and [text(z['line']) for z in actual] == [text(z) for z in intended],
          'COMPLETE_INTENDED_GROUND_ZERO_SCHEMAS')
    definitions, mp, gen = [], [], []
    for index, zero in enumerate(actual):
        _need(zero['id'] == 'i'+str(index) and zero['rule'] == zero['line']['rule'] and
              colors[zero['formula_id']] == text(zero['line']['formula']), 'EXACT_ZERO_DESCRIPTOR')
        definitions.append(dict(id=text(['zero', zero['id']]), kind='ZERO', output=zero['formula_id'],
            premises=[], zero_id=zero['id'], variable=None, native_rule=zero['rule']))
    for head, formula in enumerate(forms):
        if formula[0] == 'imp':
            a, b = ids[text(formula[1])], ids[text(formula[2])]
            mp.append([head, a, b])
            definitions.append(dict(id=text(['mp', head, a, b]), kind='MP', output=b,
                premises=[a, head], zero_id=None, variable=None, native_rule='mp'))
        elif formula[0] == 'all':
            body, variable = ids[text(formula[2])], formula[1]
            gen.append([head, body, variable])
            definitions.append(dict(id=text(['gen', head, body, variable]), kind='GEN', output=head,
                premises=[body], zero_id=None, variable=variable, native_rule='generalize'))
    _need(text(mp) == text(compiled['mp_index']) and text(gen) == text(compiled['gen_index']),
          'INDEPENDENT_COMPLETE_MP_GEN_INDICES')
    return sorted(definitions, key=lambda d: d['id'])


def _sites(depth):
    return [''.join(bits) for length in range(depth+1) for bits in itertools.product('01', repeat=length)]


def _universe(compiled, definitions, depth, certificate=None):
    """All rows authored independently; no provider or placement helper calls."""
    colors, rows = compiled['logical_basis']['colors'], []
    for site in _sites(depth):
        for definition in definitions:
            premises = definition['premises']
            if premises and len(site) >= depth:
                continue
            points = [site]+[site+str(i) for i in range(len(premises))]
            marks = dict(zip(points, [colors[fid] for fid in [definition['output']]+premises]))
            if certificate is not None:
                for fid in premises:
                    port = text(['FM-port-v1', certificate['scope_sha256'], fid, depth-len(site)-1])
                    marks[port] = '1'
            rows.append(dict(id=text([site, definition['id']]), t=[[p, 1] for p in points],
                             m=[[p, value] for p, value in sorted(marks.items())]))
    _need(len(rows) < 2000 and len({r['id'] for r in rows}) == len(rows), 'UNIVERSE_RESOURCE_OR_DUPLICATE')
    return sorted(rows, key=lambda row: row['id'])


def _marked_model(base_model, certificate, base_identity):
    model = copy.deepcopy(base_model)
    identity = text(['FM-provider-v1', base_identity, 'MARKS', sha(certificate['requests']), certificate['scope_sha256']])
    model['inventory']['identity'] = identity
    marks = dict(model['seed']['m'])
    for fid, remaining in certificate['requests']:
        marks[text(['FM-port-v1', certificate['scope_sha256'], fid, remaining])] = '0'
    model['seed']['m'] = [[p, value] for p, value in sorted(marks.items())]
    return model


def prepare():
    """Run preparation only after review; never selects a target proof.

    Returns {status,cases,acquisition}. Each provider is the sole non-JSON case
    field; persist all other fields before solving. Positive classification
    witnesses are preprocessing evidence, never passed to the target solver.
    """
    started, modules, cases, acquisitions = time.perf_counter(), _modules(), [], []
    for declaration in declarations():
        c, generation = modules['finite_basis_v1'].compile_case(declaration)
        depth = declaration['depth']
        definitions = _definitions(c, declaration)
        base_model, base_provider, factory = modules['indexed_proof_provider_v1'].make_provider(c, generation, depth, FACTORY_LIMITS)
        _need(factory['status'] == 'COMPLETE' and text(factory['value']['definitions']) == text(definitions), 'FULL_FACTORY_DESCRIPTOR')
        factory_check = modules['growing_proof_verifier_v2'].verify_factory(c, generation, depth, base_model, factory, limits=VERIFY_LIMITS)
        _need(factory_check['status'] == 'VERIFIED', 'INDEPENDENT_FACTORY_JOIN:'+text(factory_check))
        zero_checks = [modules['independent_fol_checker_v1'].check(c['theory'], [z['line']], z['line']['formula'], KERNEL_LIMITS)
                       for z in c['zero_instances']]
        _need(all(r['status'] == 'VERIFIED' for r in zero_checks), 'EVERY_ZERO_NATIVE_KERNEL')
        base_rows = _universe(c, definitions, depth)
        cat = modules['proof_core_v1'].Catalogue(c, definitions, depth)
        # Only potential premise-port queries, frozen from syntax. No top-level
        # goal/height query and no imported table or expected derivation.
        premise_ids = sorted({fid for d in definitions for fid in d['premises']})
        requests = [[fid, remaining] for fid in premise_ids for remaining in range(depth)]
        learned = modules['failure_markings_v1'].learn(cat, requests, seconds=15)
        _need(all(r['status'] in ('PROVED', 'ABSENT') for r in learned['classifications']), 'UNRESOLVED_FIXTURE_CLASSIFICATION')
        certificate = learned['certificate']
        absence = modules['failure_certificate_checker_v1'].verify(c, certificate)
        _need(absence['status'] == 'VERIFIED', 'INDEPENDENT_ABSENCE_DAG')
        marked_rows = _universe(c, definitions, depth, certificate)
        expected_marked_model = _marked_model(base_model, certificate, base_provider.identity)
        marked_cat = modules['failure_markings_v1'].MarkedCatalogue(c, definitions, depth, certificate)
        marked_provider = modules['failure_markings_v1'].Provider(base_provider, base_model, marked_cat, 'MARKS')
        _need(text(marked_provider.model) == text(expected_marked_model), 'EXACT_MARKED_ADAPTER_MODEL')
        checker = modules['marked_point_checker_v1'].Checker(c, depth, certificate['scope_sha256'], certificate['requests'])
        marked_model_check = checker.check_model(marked_provider.model)
        _need(marked_model_check['status'] == 'VERIFIED' and
              all(text(checker.placement(row['id'])) == text(row) for row in marked_rows), 'INDEPENDENT_EVERY_MARKED_ROW')
        negative = {tuple(pair) for pair in certificate['requests']}
        by_id = {d['id']: d for d in definitions}
        filtered = []
        for row in base_rows:
            site, did = json.loads(row['id'])
            if not any((fid, depth-len(site)-1) in negative for fid in by_id[did]['premises']):
                filtered.append(copy.deepcopy(row))
        filter_model = copy.deepcopy(base_model)
        filter_model['version'] = 'PFA-certified-filter-explicit-inventory-v1'
        filter_model['inventory'] = dict(kind='EXPLICIT', placements=copy.deepcopy(filtered))
        acquisition = dict(id=declaration['id'], depth=depth, factory_check=factory_check,
            native_zero_checks=zero_checks, classifications=learned, absence_check=absence,
            marked_model_check=marked_model_check, definitions_sha256=sha(definitions),
            base_universe_sha256=sha(base_rows), marked_universe_sha256=sha(marked_rows),
            filtered_universe_sha256=sha(filtered), original_rows=len(base_rows), filtered_rows=len(filtered),
            filter_scope='Explicit certified-redundant restricted inventory control; not the old FILTER potential-count packet ABI.')
        acquisitions.append(acquisition)
        for mode, model, provider, universe in [('BASE',base_model,base_provider,base_rows),
                ('MARKS',marked_provider.model,marked_provider,marked_rows), ('FILTER',filter_model,None,filtered)]:
            cases.append(dict(id=declaration['id']+'--'+mode, base_id=declaration['id'], mode=mode,
                goal_label='forall-P' if declaration['goal_kind']=='forallP' else declaration['goal_kind'],
                declaration=copy.deepcopy(declaration), compiled=copy.deepcopy(c), generation=copy.deepcopy(generation),
                depth=depth, model=copy.deepcopy(model), provider=provider, factory=copy.deepcopy(factory),
                factory_model=copy.deepcopy(base_model), factory_check=copy.deepcopy(factory_check),
                definitions=copy.deepcopy(definitions), universe=copy.deepcopy(universe),
                universe_sha256=sha(universe), failure_certificate=copy.deepcopy(certificate),
                acquisition_id=declaration['id'], reader=theory_reader(declaration)))
    _need(len(cases) == 18, 'NATIVE_CASE_CENSUS')
    return dict(status='PREPARED', cases=cases, acquisition=dict(version=VERSION, source_pins=source_pins(),
        records=acquisitions, seconds=time.perf_counter()-started,
        scope='Finite preprocessing/factory/zero/absence evidence, not target proof supervision, a Wang grid or universal FOL completeness.'))


def make_provider(case):
    """Fresh per-run instance; returns (model,provider,factory). FILTER is explicit."""
    modules = _modules()
    model, provider, factory = modules['indexed_proof_provider_v1'].make_provider(
        case['compiled'], case['generation'], case['depth'], FACTORY_LIMITS)
    _need(factory['status'] == 'COMPLETE' and model == case['factory_model'], 'FRESH_FACTORY_BINDING')
    if case['mode'] == 'MARKS':
        cat = modules['failure_markings_v1'].MarkedCatalogue(case['compiled'],case['definitions'],case['depth'],case['failure_certificate'])
        provider = modules['failure_markings_v1'].Provider(provider,model,cat,'MARKS')
        model = provider.model
    elif case['mode'] == 'FILTER':
        model, provider = copy.deepcopy(case['model']), None
    _need(model == case['model'], 'FRESH_MODE_MODEL_BINDING')
    return model, provider, factory


def _point_complete(case, selected):
    table = {row['id']:row for row in case['universe']}
    totals, marks, active = dict(case['model']['seed']['t']), dict(case['model']['seed']['m']), set(case['model']['roots'])
    if len(selected) != len(set(selected)):
        return False
    for cid in selected:
        if cid not in table:
            return False
        for point, units in table[cid]['t']:
            totals[point] = totals.get(point,0)+units
            active.add(point)
            if totals[point] > case['model']['capacity']:
                return False
        for point, value in table[cid]['m']:
            if point in marks and marks[point] != value:
                return False
            marks[point] = value
    return all(totals.get(point,0) == case['model']['capacity'] for point in active)


def exhaustive_proof_sets(case):
    """Independent ALL rooted bounded producer trees, only after solver runs."""
    by_out, allowed, work = {}, {r['id'] for r in case['universe']}, [0]
    for definition in case['definitions']:
        by_out.setdefault(definition['output'], []).append(definition)
    def enumerate_at(fid, remaining, site):
        work[0] += 1
        _need(work[0] <= 1000000, 'EXHAUSTIVE_REFERENCE_WORK_BOUND')
        result = []
        for definition in by_out.get(fid, []):
            cid = text([site,definition['id']])
            if cid not in allowed or (definition['premises'] and remaining == 0):
                continue
            children = [enumerate_at(child,remaining-1,site+str(i)) for i,child in enumerate(definition['premises'])]
            for product in itertools.product(*children):
                selected = [cid]+[row for subtree in product for row in subtree]
                result.append(tuple(sorted(selected)))
                _need(len(result) <= 10000, 'EXHAUSTIVE_REFERENCE_OUTPUT_BOUND')
        return result
    try:
        all_rooted = enumerate_at(case['compiled']['goal_id'],case['depth'],'')
        result = sorted({rows for rows in all_rooted if _point_complete(case,rows)})
        return dict(status='COMPLETE', proof_sets=[list(rows) for rows in result], count=len(result),
                    work=work[0], sha256=sha(result), scope='All rooted native producer trees in this exact finite universe and bound; no disconnected point-solution claim.')
    except ValueError as error:
        return dict(status='UNKNOWN', reason=str(error), proof_sets=None, count=None, work=work[0])


def ground_kernel(theory, proof, target):
    """Independent axiom/refl/MP/vacuous-GEN kernel for this declared fragment."""
    try:
        _need(type(proof) is list and proof, 'EMPTY_NATIVE_PROOF')
        _need(all(_ground(formula,theory) for formula in theory['axioms'].values()), 'NON_GROUND_GAMMA')
        previous = []
        for line in proof:
            _need(type(line) is dict and _ground(line['formula'],theory), 'NATIVE_FORMULA')
            rule, formula = line['rule'], line['formula']
            if rule == 'axiom':
                _need(set(line) == {'rule','name','formula'} and line['name'] in theory['axioms'] and
                      text(formula) == text(theory['axioms'][line['name']]), 'NATIVE_AXIOM')
            elif rule == 'refl':
                _need(set(line) == {'rule','formula'} and formula[0] == 'eq' and
                      text(formula[1]) == text(formula[2]), 'NATIVE_REFLEXIVITY')
            elif rule == 'mp':
                _need(set(line) == {'rule','formula','antecedent','implication'}, 'NATIVE_MP_FIELDS')
                for key in ('antecedent','implication'):
                    _need(type(line[key]) is int and 0 <= line[key] < len(previous), 'STRICT_PRIOR_REFERENCE')
                a, implication = previous[line['antecedent']], previous[line['implication']]
                _need(text(implication) == text(['imp',a,formula]), 'NATIVE_MP')
            elif rule == 'generalize':
                _need(set(line) == {'rule','formula','source','variable'} and type(line['source']) is int and
                      0 <= line['source'] < len(previous) and type(line['variable']) is str and
                      text(formula) == text(['all',line['variable'],previous[line['source']]]), 'NATIVE_VACUOUS_GEN')
            else:
                raise ValueError('RULE_OUTSIDE_TINY_NATIVE_FRAGMENT')
            previous.append(formula)
        _need(text(previous[-1]) == text(target), 'NATIVE_TARGET')
        return dict(status='VERIFIED', reason='INDEPENDENT_GROUND_HORN_AND_VACUOUS_GEN', lines=len(previous),
                    scope='Given closed ground hypotheses; direct AST checks, strict prior references. Not a full FOL kernel.')
    except (ValueError,KeyError,IndexError,TypeError) as error:
        return dict(status='REJECTED', reason=str(error))


def _ground(formula,theory):
    def term(value):
        return type(value) is list and len(value) == 3 and value[0] == 'fun' and value[1] in theory['functions'] and \
            type(value[2]) is list and len(value[2]) == theory['functions'][value[1]] and all(term(c) for c in value[2])
    if type(formula) is not list or not formula:
        return False
    if formula[0] == 'pred':
        return len(formula) == 3 and formula[1] in theory['predicates'] and \
            type(formula[2]) is list and len(formula[2]) == theory['predicates'][formula[1]] and all(term(t) for t in formula[2])
    if formula[0] == 'eq':
        return len(formula) == 3 and term(formula[1]) and term(formula[2])
    if formula[0] == 'imp':
        return len(formula) == 3 and _ground(formula[1],theory) and _ground(formula[2],theory)
    return formula[0] == 'all' and len(formula) == 3 and type(formula[1]) is str and _ground(formula[2],theory)


def check_solution(case, result):
    """Actual solver-selected IDs only; no expected proof or target derivation."""
    if result.get('status') not in ('SAT', None):
        return dict(status='NOT_APPLICABLE',reason='NO_POSITIVE_SOLVER_CERTIFICATE',proof_reader=[])
    modules, selected = _modules(), result['selected']
    try:
        decoded = modules['indexed_proof_provider_v1'].decode(case['compiled'],case['depth'],selected,FACTORY_LIMITS)
    except modules['indexed_proof_provider_v1'].InputError as error:
        return dict(status='REJECTED',reason='NATIVE_DECODER_REJECTED:'+str(error),proof_reader=[])
    if decoded['status'] != 'UNVERIFIED_CERTIFICATE':
        return dict(status='REJECTED' if decoded['status'] != 'UNKNOWN' else 'UNKNOWN', decoder=decoded)
    tree = modules['growing_proof_verifier_v2'].verify_tree(case['compiled'],case['depth'],selected,decoded,limits=VERIFY_LIMITS)
    host = modules['independent_fol_checker_v1'].check(case['compiled']['theory'],decoded['proof'],case['compiled']['goal'],KERNEL_LIMITS)
    direct = ground_kernel(case['compiled']['theory'],decoded['proof'],case['compiled']['goal'])
    status = 'VERIFIED' if _point_complete(case,selected) and all(r['status']=='VERIFIED' for r in (tree,host,direct)) else 'REJECTED'
    if any(r['status']=='UNKNOWN' for r in (tree,host,direct)):
        status = 'UNKNOWN'
    return dict(status=status, decoded=decoded, tree=tree, native_fol_kernel=host, direct_fragment_kernel=direct,
                proof_reader=proof_reader(case['declaration'],decoded['proof']))


def disconnected_mutant(case, actual_selected):
    """Only mutate an actual solver witness, never seed a proof into search."""
    _need(_point_complete(case,actual_selected), 'ACTUAL_POINT_WITNESS_REQUIRED')
    table, active = {r['id']:r for r in case['universe']}, set(case['model']['roots'])
    for cid in actual_selected:
        active.update(p for p,u in table[cid]['t'])
    p_formula = ['pred',case['declaration']['names']['P'],[case['declaration']['terms'][0]]]
    fid = case['compiled']['logical_basis']['colors'].index(text(p_formula))
    zeros = [d for d in case['definitions'] if d['kind']=='ZERO' and d['output']==fid]
    _need(len(zeros)>=2, 'DISTINCT_SAME_OUTPUT_ZEROS_REQUIRED')
    for site in _sites(case['depth']):
        pair = [text([site,d['id']]) for d in zeros[:2]]
        if site and site not in active and all(cid in table for cid in pair):
            selected = list(actual_selected)+pair
            _need(_point_complete(case,selected), 'DISCONNECTED_MUTANT_NOT_POINT_COMPLETE')
            rejected = check_solution(case,dict(status='SAT',selected=selected))
            _need(rejected['status']=='REJECTED', 'DISCONNECTED_NONPROOF_NOT_REJECTED')
            return dict(selected=selected, added=pair, unused_site=site, point_complete=True,
                        point_consistency=dict(status='VERIFIED',reason='EXACT_POINT_CAPACITY_AND_MARK_AGREEMENT'),
                        native_rejection=rejected,
                        scope='Disconnected two-producer point-consistent nonproof, constructed only from an actual solver output; native rooted decoding must reject.')
    raise ValueError('NO_UNUSED_SITE_FOR_DISCONNECTED_MUTANT')


def _latex(ast):
    tag = ast[0]
    if tag == 'fun':
        return r'\mathrm{'+ast[1]+'}'+('('+','.join(_latex(a) for a in ast[2])+')' if ast[2] else '')
    if tag == 'pred':
        return r'\mathrm{'+ast[1]+'}('+','.join(_latex(a) for a in ast[2])+')'
    if tag == 'eq':
        return _latex(ast[1])+'='+_latex(ast[2])
    if tag == 'imp':
        return '('+_latex(ast[1])+r'\to '+_latex(ast[2])+')'
    if tag == 'all':
        return r'\forall\mathrm{'+ast[1]+'}\, '+_latex(ast[2])
    raise ValueError('READER_FORMULA_OUTSIDE_FIXTURE')


def _english(ast, names):
    labels = {names['P']:'the initial property', names['Q']:'the intermediate property',
              names['U']:'the unsupported property', names['G']:'the target property'}
    if ast[0] == 'pred':
        return 'the distinguished object has '+labels[ast[1]]
    if ast[0] == 'eq':
        return 'the distinguished object equals itself'
    if ast[0] == 'imp':
        return 'if '+_english(ast[1],names)+', then '+_english(ast[2],names)
    if ast[0] == 'all':
        return 'regardless of the value of '+ast[1]+', '+_english(ast[2],names)
    raise ValueError('READER_FORMULA_OUTSIDE_FIXTURE')


def theory_reader(declaration):
    return dict(symbols=declaration['names'], hypotheses=[dict(name=name, formula=formula,
        latex=_latex(formula), english=_english(formula,declaration['names'])+'.')
        for name,formula in sorted(declaration['problem']['theory']['axioms'].items())],
        conclusion=dict(formula=declaration['problem']['goal'],latex=_latex(declaration['problem']['goal']),
                        english=_english(declaration['problem']['goal'],declaration['names'])+'.'),
        scope='Names denote uninterpreted unary predicates and one constant; no geometry or intended mathematical model is checked.')


def proof_reader(declaration, proof):
    result=[]
    for i,line in enumerate(proof):
        rule, refs = line['rule'], []
        if rule=='axiom':
            reason='Use the declared hypothesis '+line['name']+'.'
        elif rule=='mp':
            refs=[line['antecedent']+1,line['implication']+1]
            reason='Apply the implication on line %d to the antecedent on line %d.'%(refs[1],refs[0])
        elif rule=='generalize':
            refs=[line['source']+1]
            reason='Generalize line %d; the variable is absent from every closed ground hypothesis.'%refs[0]
        else:
            reason='Use equality reflexivity.'
        result.append(dict(line=i+1,formula=line['formula'],formula_latex=_latex(line['formula']),
            english=_english(line['formula'],declaration['names'])+'.',rule=rule,dependencies=refs,reason=reason))
    return result
