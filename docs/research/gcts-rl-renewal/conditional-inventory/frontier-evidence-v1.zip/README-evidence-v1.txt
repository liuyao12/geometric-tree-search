Proof-frontier whole-graph qualification, 2026-11-03.

This archive physically stores every task file at the archive cut, except
package/ and publication/ to avoid recursion. No alias/deduplication is used.
ARCHIVE-file-manifest-v1.json lists every original path, bytes and SHA256.
The external manifest additionally gives the completed ZIP byte/hash identity.
The full task-owned archive including local paths is explicitly approved for
the existing public GitHub Pages destination; unrelated work is excluded.

The report covers fresh tiny full traces under the unchanged indexed growing
point engine, complete provider/context joins, global scheduling and restored
branch exclusions. Native logical checks and bounded proof-set preservation
are separate evidence. UNKNOWN remains unresolved. Passing this gate does not
retroactively verify old sampled runs, prove unrestricted nonprovability, or
establish a universal Wang palette, ATP advantage, RL gain or plane tiling.

Use report/frontier-audit-v1.html and its saved trace downloads. Serving this
directory with python3 -m http.server enables the passive reader's local fetch
links. The overall research program remains ACTIVE. Do not execute old drivers
in place or overwrite these immutable scientific records for reproduction.
