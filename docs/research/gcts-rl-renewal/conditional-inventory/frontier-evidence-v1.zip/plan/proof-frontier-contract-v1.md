**Proof-frontier adapter contract, proposed version 1**

Status: **read-only Source assessment and unimplemented contract**. No engine, classifier, logical checker or scientific driver was executed for this assessment. No prior run was modified. This document proposes the next qualification gate; it does not establish conformance.

The immediate contribution should be a complete, independently replayable point-frontier interface for the existing finite proof grammar. The failure-marking lane already has useful bounded absence certificates and literal marking conflicts. Its report also records that the attempted whole-graph verifier refused the indexed result format. Closing that verification boundary is a concrete next step before enlarging the proof language or claiming a geometric proof-search advantage.

**What the inspected implementation establishes and what it does not**

The inspected run is `gcts-failure-markings-20261103-v1`, in the same visualization workspace as this document. Its `failure_markings_v1.learn` recursively explores the finite native producer catalogue, memoizing a formula ID together with remaining proof height. Every absence node lists a blocker for every producer; dependencies decrease remaining height strictly. `failure_certificate_checker_v1.verify` independently reconstructs all structural `MP` and `GEN` producers in the declared registry and checks complete blocker coverage. Native `ZERO` line truth is an additional kernel-audit obligation, explicitly outside that checker.

`MarkedCatalogue` gives each requested certified absence a global mark-only port with the literal string value `"0"`. Every candidate requests `"1"` at every premise's scoped remaining-height port. `Provider(mode='MARKS')` obtains the base incident packet, constructs the decorated rows, and retains candidates by ordinary assigned-mark agreement. `mode='FILTER'` is the separately labeled direct-table control using the same negative requests. Internal certificate DAG nodes are supporting lemmas, not additional requested classifications or seed marks. Interrupted requests remain `UNKNOWN`.

This is certified unary bounded-subgoal tabling represented by literal point markings. It is not a new memoization algorithm, a learned dynamic relation between arbitrary subgoals, or an unrestricted logical nonprovability oracle. The saved review reports 1,256 requested classifications, including 812 scoped absences and 444 witnessed positives, with no unresolved requested labels. These are retained study results, not new computations in this assessment.

| Contract aspect | Inspected evidence | Remaining boundary |
| --- | --- | --- |
| Exact point semantics | Capacity `2`, root seed unit `1`; each producer contributes unit `1` at its own address and premise-child addresses; literal formula colors and disjoint failure-port marks | Preserve the explicit anchored proof-tree profile; a point certificate alone must not silently become a native logical proof |
| Complete incident enumeration | Indexed provider enumerates every own role and possible parent-child role, applies full-support capacity/formula constraints; independent marked checker exhaustively rebuilds a supplied packet | `complete:true` and counts are not independent proofs; main-run assurance retained first/last packet samples rather than every intermediate graph |
| Shared graph and weighted edges | Engine keeps shared candidate identities, forward/reverse incidence, dependencies, and contribution weights in snapshots | Independent main-run reconstruction of every frontier, candidate set, dependency change and scheduler checkpoint remains open |
| Scheduling | Source scans the whole frontier for dead points, then forced points, then branches by generation before degree; ordering hook receives the current legal domain and appends complete lexical fallback | This is a Source observation. The legacy full-result checker returned `REJECTED`, reason `record cardinality`, rather than verifying the indexed trace |
| Rollback | Trailed maps/sets/edge counts and mandatory final entry/restored equality are present | Final equality and sampled packets do not replace complete independent intermediate-state replay, especially across branch exclusions and lazy exhaustion |
| Positive logic | Selected point solutions, decoded proof trees, and native logical proofs have separate checkers | These assurances must stay separate from negative finite-grammar exhaustion and from an arbitrary geometric tiling interpretation |
| RL/cluster contribution | Frozen semantic-family inventory and shape policy supply leader/continuation preferences; base fallback is retained | This lane did not newly train its policy; it does not establish superiority over conventional tabling or standard automated theorem provers |

The marked checker's `verify_query` deliberately says that selected/excluded state is outside its ABI. It checks a complete **current point-value-compatible incident packet**, not the engine's complete **current legal frontier graph**. That is a legitimate boundary, but the missing join must be checked. Treating the two sets as identical would lose the inventory rule and context-local exclusions.

**Finite proof reduction and its scope**

Let \(H\) be the declared maximum binary proof-address depth. A native definition has an output formula and zero, one or two premises. A placement at address \(s\) uses the canonical existing CID for the pair `site,definitionID`, assigns literal formula colors to its own and child points, and contributes one integer unit at each of those points. The capacity is \(C=2\), so dividing units by \(C\) gives the master reference's normalized point values. The root seed supplies one unit and the goal color.

For a premise of a producer placed at \(s\), the remaining height is

\[
r=H-|s|-1.
\]

This is proof-address depth, **not frontier generation**. The current ports contain the native scope digest, formula ID and remaining height. The scope digest binds the theory, literal formula/color registry, native producer indices, and depth-semantics version; the port's height component and the inventory's search-height binding must also be checked. A certificate from another theory, registry or remaining-height interpretation cannot justify the same port merely because its formula text looks similar.

The preservation argument is conditional: a complete rooted proof containing a premise at that height would supply a producer subtree contradicting a checked bounded absence DAG. Thus its containing candidate cannot occur in a complete rooted proof of the same finite grammar and bound. This justifies a redundant constraint for that declared proof set. It does not justify unrestricted first-order nonprovability, arbitrary stronger profiles, or use of unresolved classifications as failures.

The profile is an anchored symbolic tree point system. Its addresses and global mark-only keys are not a square grid, and its inventory depends on a finite formula registry and proof bound. There are no north/east/south/west cell colors or a fixed translation-only Wang palette in these Sources. The separate fixed-palette circuit work is an encoding backend elsewhere in the program; this assessment has not audited or joined it. A universal first-order proof encoding would additionally need a specified sound and complete logical calculus, a uniform finite encoding/decoder, and a fair treatment of unbounded syntax and proof size. Increasing this finite registry alone has not established those results.

`finite_basis_v1.py` explicitly freezes original terms, finite instantiation rounds and original equality contexts. Its own scope says that it is complete within that explicit native basis, not complete for unbounded first-order logic. Failed search inside that basis is therefore a finite grammar result.

**Proposed shared point-frontier ABI**

Use a fresh versioned adapter and fresh evidence; do not rewrite the old study or relabel its rejected verifier receipt. The ABI accepts opaque exact point IDs, so both proof addresses and an \(A_2\) point adapter can use it. A domain profile declares namespaces, permitted placement actions, activation and solution semantics. For this proof profile, binary address strings and canonical `FM-port-v1` JSON strings are disjoint; mark-only keys are never made required points implicitly. No plane-translation invariance is promised.

All semantic integers are native integers, excluding booleans and floats. Mark values use declared exact typed JSON equality; missing means unconstrained and an assigned zero remains assigned. Serialization, order and digest conventions are versioned. Hashes bind content; an independent reconstruction is what checks its meaning.

The immutable binding record must include:

```json
{
  "schema": "GCTS-proof-point-binding-v1",
  "profile": "ANCHORED_FINITE_PRODUCER_TREE",
  "capacity": 2,
  "grammar_scope_sha256": "theory/registry/producer/depth-semantics digest",
  "height_bound": "native integer",
  "factory_certificate_sha256": "complete declared producer catalogue",
  "cid_schema": "canonical site/definition identity version",
  "seed_model_sha256": "roots plus exact seed t/m",
  "marking_version_sha256": "exact frozen requests and their checked certificate",
  "inventory_identity_sha256": "derived from all relevant bindings",
  "solution_semantics": "all activated positive proof addresses exact plus rooted native decoding"
}
```

The existing marked checker only binds an opaque model inventory identity after checking its shape. The new binding verifier must also recompute the identity derivation and bind the model, factory, depth and exact decorated rows. Goal-independent reuse of an absence certificate may be valid, but a goal-bearing search model must still bind its own seed and inventory.

The Source contract should expose these operations, with explicit resource refusals:

| Proposed operation | Required meaning |
| --- | --- |
| `describe(cid, binding)` | Return the unique immutable exact base row `{id,t,m}`; reject changed content for a reused ID |
| `enumerate_incident(point, context, binding)` | Exhaust every permitted positive-support role alignment and return the complete current legal incident set, with independently checkable catalogue coverage |
| `checkpoint(context)` | Emit the entire logical frontier/candidate graph, weighted incidence and provenance described below |
| `verify_checkpoint(binding, checkpoint, inventory_evidence)` | Independently reconstruct the state and every frontier domain, without importing the engine/provider |
| `verify_transition(before, event, after)` | Check placement, exclusion, root activation, rule-version change or undo against the reference semantics |
| `verify_result(binding, trace, result)` | Separate a found native proof, exhausted finite grammar, incomplete evidence and resource-limited unknown |

The legacy bridge may obtain the old complete capacity-and-mark-compatible packet and then remove selected and justified excluded IDs. It must retain that raw packet and the exact join evidence. The public adapter must not silently label that packet a complete legal domain. Counts should separately report potential alignments, capacity-and-mark-compatible rows, inventory/exclusion removals, unique candidate nodes and graph incidences.

For selected placements \(S\), context-local certified exclusions \(E\), active required points \(Q\), totals \(U\), and current marks \(M\), the independent checker reconstructs

\[
U(p)=U_{\mathrm{seed}}(p)+\sum_{c\in S}u_c(p),
\qquad
F=\{p\in Q:U(p)<C\},
\]

and, for every \(p\in F\),

\[
D(p)=\{c\in I:\ u_c(p)>0,\ c\notin S\cup E,
\ U+u_c\leq C\ \text{at every support point},\ m_c\sim M\}.
\]

Each CID is one candidate node shared by every incident frontier point. Every incidence includes its exact contribution; degree is the number of candidate identities, not the number of support rows or a capacity-fill estimate. Full positive and marking support is checked outside the active frontier too. Mark-only failure ports affect legality and dependencies without becoming frontier obligations.

**Checkpoint and certificate requirements**

The checkpoint carries the following logical data, either explicitly or through a complete independently verified reconstruction witness:

1. Binding/model/marking versions; explicit roots and seed; every active required point with its generation; exact totals including explicitly active zeros.
2. Selected CIDs with placement sequence and generation. A chronologically ordered placement/activation trace is required to validate generation recurrence; a CID-sorted final selected list alone does not provide placement history.
3. Every assigned mark value and reference count, including seed and remote mark-only contacts. Removing the last assignment restores absence rather than inventing a zero value.
4. Every frontier domain; one shared candidate node per legal CID; complete forward and reverse weighted incidence; no omitted untouched required point or disconnected pocket.
5. Registered immutable rows and all positive/mark dependency links used by incremental updates. Any context-sensitive loaded/exhausted cache state has its version/context binding and rollback treatment declared. An optional implementation cache is not trusted to prove completeness.
6. Branch frames and exclusions with parent-context identity and a checked failed-child justification. A budget-limited or otherwise unresolved child cannot become an exclusion certificate.
7. The proposed scheduler decision and its full current domain, followed by raw transition evidence and complete restoration records.

Initialization activates the proof root and positive seed support at generation zero. Placing a candidate gives it one plus the minimum existing generation on its positive support, and updates point generations by the minimum incident contribution and explicit root obligation. A new required root is generation zero only through an explicit activation event. Proof-height ports retain their own address-depth interpretation.

The decision verifier first checks the **whole** frontier for degree zero; if any exists, the state is dead. It then handles global forced moves before branches. A branch chooses the earliest point generation, with minimum degree permitted only within that generation and a declared deterministic final key. The old proof profile succeeds when its entire active frontier is empty; any future finite-core pause must declare that different stopping criterion and rule out global dead points before pausing.

The ordering callback may propose a validated lemma/cluster leader or continuation only after the base decision. Preferences are a subset of the selected full legal domain; the engine appends every remaining base CID. Absence of a proposal is not pruning. Multiple cluster members are not executed as an atomic macro without a separate scheduler-equivalence argument.

Undo must restore totals, selected inventory, mark values/reference counts, point generations, roots/activation, exclusions, eligibility, domains, weighted incidence, dependencies and context-sensitive exhaustion state. Exact byte/digest equality supplements independent reconstruction; it does not replace it. Monotone statistics and explicitly immutable row caches may be excluded from logical equality only when they cannot change future legality or decisions.

The current engine learns context-local failed alternatives by undoing a child, excluding its CID and re-entering global propagation. A new certificate must replay that branch-frame discipline or compile it to a fully justified search certificate. An arbitrary exclusion list is not acceptable input. Every exclusion must point to an already checked failure in the same parent context, with an acyclic certificate dependency. It cannot leak into a sibling, survive an incompatible marking version, or follow an `UNKNOWN` child.

Changing a frozen marking, weakening a constraint or changing a formula registry invalidates loaded/completeness contexts and affected trails. Initially implement only frozen-marking runs; rule-change support remains a separately qualified feature. Previously omitted candidates must be rediscovered after any permitted weakening or rollback.

Evidence streams must distinguish all-event coverage from bounded-prefix or endpoint samples. Store total/retained counts and full stream hashes, but do not call a hash of unseen records an independent semantic verification. A completeness certificate must be checkable from retained evidence, or all relevant checkpoints must be streamed to a separately logged independent checker. Refused/incomplete checking is `UNKNOWN` or `REJECTED_EVIDENCE`, never an independent conformance pass.

**Next qualification gate, before a new proof benchmark**

Start with abstract point fixtures for the shared engine and then native proof-grammar fixtures. Abstract fixtures are not advertised as mathematical proofs. Exhaust every tiny placement subset or bounded tree independently, with no policy shortlist supplying the candidate universe.

| Fixture | Required independent observation or mutation rejection |
| --- | --- |
| Explicit untouched zero target | A required zero-valued point with no candidate is globally dead even when another point is already full |
| Remote dead versus forced | A late-generation dead point defeats an earlier singleton; moving the dead point outside the display must change nothing |
| Global forced versus earlier branch | A later singleton propagates before an earlier non-singleton branch |
| Generation versus degree | An earlier-generation point with four candidates precedes a later-generation point with two; tie rules remain deterministic |
| Shared candidate and residual units | One CID touching two frontier points appears once as a node, twice as weighted edges and is selected once; a singleton that leaves an impossible residual is followed by a dead check |
| Inventory identity | A selected fractional tile cannot be selected twice merely because the capacity would allow it; altered point values under an existing CID are rejected |
| Complete own/parent roles | For tiny `ZERO`, unary `GEN` and binary `MP` catalogues, independently enumerate own and parent-role contacts, root/leaf depth boundaries and second-child role; omission with adjusted counts still fails |
| Literal remote markings | Assigned `"0"` conflicts with `"1"`; missing remains unconstrained. A mark-only contact removes a candidate at every incident point, including distant ones |
| Scope and height binding | Wrong theory/registry scope, wrong remaining height, wrong port, false ZERO absence, omitted producer and nondecreasing negative dependency are rejected |
| Rollback and revival | A failed branch restores the complete graph and all mark references; a candidate omitted in its child is available again in its parent when legal |
| Exclusion provenance | A finite failed-child certificate permits only its own parent-context exclusion; budget unknown, sibling reuse and circular failure justifications are rejected |
| Budget/incomplete inventory | Stop during enumeration, dependency update or proof checking yields unknown; neither partial domain nor swallowed refusal can create dead/forced evidence |
| Proof interpretation | An otherwise capacity-consistent selected set with an extra disconnected pair of zero producers at a nonroot site is rejected as a rooted proof; generic point consistency is kept distinct from native proof validity |
| Cluster preference fallback | Empty/partial preferences leave the full primitive domain available; a legal cluster cannot skip dead/forced checks or execute several members without separate evidence |

For a native integration fixture, reuse the *schema* of the prior independently generated ground Horn qualification in a fresh renamed theory: one reachable chain, one ungrounded self-cycle, a dead alternate premise, and a padding cycle that creates more than one complete bounded proof. Generate the tiny proof sets without supplying a target derivation. Check exact unmarked/marked preservation at the same grammar and bound, all indexed packets and every checkpoint, then apply the scope/height/omission mutations above. Keep direct filtering and a conventional memoized search as explicit controls.

The first gate should produce one tiny full trace in the new ABI, accepted by an independent whole-graph verifier, plus rejected mutants. Only then freeze a fresh cohort and compare base, literal-marked and direct-table lanes under the same grammar, scheduler, budgets and full accounting. Add RL after this gate so that policy behavior cannot obscure a graph-contract discrepancy.

**Unresolved claims and admission conditions**

- Complete incident packets have a clear independent oracle, but the new adapter, graph verifier, exclusion certificates and full result-format join are unimplemented.
- Native ZERO truth, first-order side conditions, equality schemas, closed assumptions and proof decoding remain separate obligations. Point capacity alone is not a logical kernel.
- Root-only activation and prefix-connected proof growth support a rooted-tree interpretation. Introducing arbitrary zero-valued proof-site roots, general lemma sharing or DAG compression needs a new reduction invariant or added point constraints; proof tree height and DAG/line bounds are not interchangeable.
- The existing finite basis omits unbounded terms and schema instances. No finite negative outcome becomes unrestricted nonprovability; any fair bound-expansion or universal encoding claim requires its own proof.
- Unary failure ports do not encode relational receptor constraints or learned correlations between open subgoals. A later relational marking needs a new soundness argument or an explicit learned-restriction label.
- Existing positive native proofs are not invalidated by a rejected legacy graph receipt. Equally, that receipt must not be cited as successful complete conformance.
- No new speedup, ATP superiority, literal Wang-grid search, single universal mathematical tile set or plane-tiling result follows from this contract.

**Inspected Sources and saved evidence**

The master reference was read from `/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md`: 21,657 bytes, SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.

The paths below are relative to `gcts-failure-markings-20261103-v1`; these pins identify the read-only assessment's inputs. Report numbers above are attributed to those saved records, without replaying their scientific computations.

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `source/failure_markings_v1.py` | 7268 | `4b0f735c6a1114925fd1032c2a5cba37bffa61f447a0b71e1aaea8bf8e09a529` |
| `reference/failure_certificate_checker_v1.py` | 12386 | `2436cc872737f9400c7bbb78949a366919a64804ca3088be1577fcdc7c7e88db` |
| `reference/failure-certificate-checker-API-v1.json` | 3745 | `95eb1b4ee4267029c48b49ec502ccc14a75f78aa208e99e9967a34b075643f9b` |
| `reference/marked_point_checker_v1.py` | 15781 | `513ac4c616a2db3154c79156f40807228c9a667f601230a35330673d3105aa26` |
| `source/proof_core_v1.py` | 5508 | `d363b72e6f4355225d3dbbdc66c64f746d27bf96de5c4d8a17471cc95b70091c` |
| `source/family_policy_v1.py` | 8909 | `3fb4946dadfae736a319e41eefe9bc124a6ef8159cd0f19658963ae53e738680` |
| `source/finite_basis_v1.py` | 14044 | `97225dcffd98dd5386aeb560a2fc5634dfcc4606ff475a46536207768932a0dc` |
| `source/experiment_v1.py` | 14072 | `6f91ca5cb9f8ce492836977cce6fe67e4d5b13fdc8005fbff476b936b7ba7911` |
| `upstream/growing_point_search_v2.py` | 39556 | `6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb` |
| `upstream/indexed_proof_provider_v1.py` | 26917 | `5261bf552924105f3c9ac3a4e9ddce0490869105b1812a8d897610267623b26e` |
| `review/conformance-v1.json` | 3067 | `eab7ef8054f38e27496a20f3b7c2fcb47c155d68a2aa3598814694dace514113` |
| `review/results-independent-review-v1.json` | 20261 | `9f3d55dca6075e1e6217d94ae6f1327ced42fcf7020de3da4e3fb98697bb1b21` |
| `review/tiny-exhaustive-graph-audit-v1.json` | 1130 | `7adccc3cc093917331519aeded36ec7f99f48a78a1443abf504fd68f05247666` |
| `report/failure-markings-v1.html` | 765173 | `5249e1883cc8cd2cdcdc6dd840ccced85fb374c18765cdc67d319459cd2d1429` |
| `report/results-summary-v1.json` | 747369 | `613e26b0d5d85236c7ff26614c896af88f3efa9df1fd759caf5ee9e8c4720f97` |
