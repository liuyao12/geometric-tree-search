"""Passive complete saved-JSON/data joins only; no research import or replay."""
import collections
import hashlib
import json
from pathlib import Path

D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-cutoff-proof-pilot-20261020')
OLD=D.parent/'gcts-proof-memory-pilot-20261020'
D8=D.parent/'gcts-word-point-proof-pilot-20261020'


def pin(path):
    p=Path(path);assert '.partial' not in p.name
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def read(path):
    p=Path(path);assert p.suffix=='.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def verify(row):assert pin(row['path'])=={k:row[k] for k in ('path','bytes','sha256')}


offer=read(D/'root/prospective-whole-offer-v1.json')
for row in offer['files']:verify(row)
assert len(offer['files'])==41
corpus=read(next(r['path'] for r in offer['files'] if r['sha256']=='2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'))
bank=read(D8/'verification-L/declarative-diagnostic-bank-v1.json')
control_ids=[r['id'] for r in bank['controls']]
external=read(D/'root/external-tool-observer-v1.json')
assert external['all_handles_terminal'] is True and len(external['cases'])==3
cases=['pilot-fork-join-positive','pilot-quantifier-equality-positive','pilot-fork-join-missing-Pa']
expected_packets=[('22a36c42ee0e4c08e2dd605b8bad34080f29b74fbff1fa5b2f19ae719c74e158',31536770),('1493ec353c0ec6316afde6468bbb141782012b891bb16522d741b468283c33a6',30981329),('f6bc5558131175a3b13fc853ef972ca4b77eaede712bfbda79e310649dcaa4cd',31357262)]
expected_attempts=[dict(S0=14,P00=19,P10=15),dict(S0=600,P00=13,P10=20),dict(S0=600,P00=22,P10=23)]
status_total=collections.Counter();observations=[];actual_pins=[]
raw_point=raw_audits=0;admitted_point=admitted_audits=0
for index,cid in enumerate(cases):
    path=D/'actual'/cid;op=D/'actual'/(cid+'.observer')/'observer.json'
    result_path=path/'result.json';rp=pin(result_path)
    assert (rp['sha256'],rp['bytes'])==expected_packets[index]
    record=read(result_path);s=record['scientific_result'];t=s['tests'][0]
    header=read(path/'worker-header.json');terminal=read(path/'terminal.json');observer=read(op)
    plan_path=D/'root'/('plan-'+cid+'-v1.json');plan=read(plan_path)
    gp=D/'root'/('grant-'+cid+'-v1.json');grant=read(gp);consumed=read(path/'CONSUMED.json')
    tool=next(r for r in external['cases'] if r['case_id']==cid)
    assert record['case_id']==s['selected_case_id']==header['case_id']==terminal['case_id']==observer['case_id']==cid
    assert consumed['case_id']==grant['case_id']==cid and consumed['uses']==grant['uses']==1
    assert consumed['plan_sha256']==grant['plan_sha256']==pin(plan_path)['sha256']
    assert consumed['grant_sha256']==pin(gp)['sha256'] and grant['authorized'] is grant['no_retry'] is True
    assert grant['old_grants_reused'] is False
    for row in grant['reviews']:verify(row)
    assert s['inputs']==corpus and s['limits']==plan['experiment_limits']
    assert s['job_record_complete'] is True
    assert s['all_six_searched'] is s['scientific_complete'] is s['complete'] is s['resource_accepted'] is False
    assert record['status']==header['status']=='COMPLETE' and record['error'] is None
    assert terminal['header_valid'] is True and terminal['process_exit_code']==0
    assert header['result']==terminal['result']==rp and terminal['header']==header
    assert record['source_unchanged'] is terminal['sources_unchanged'] is True
    assert record['old_qualification_reused'] is record['full_physical_Wang_claim'] is False
    transport=record['native_transport'];queries=record['native_queries']
    assert s['native_records']==queries and transport['complete_records']==len(queries)
    assert transport['all_reaped'] is transport['closed'] is True and transport['native_exit_code']==0
    assert [q['id'] for q in queries]==list(range(len(queries)))
    assert len(transport['request_stages'])==len(queries)
    for q,stage in zip(queries,transport['request_stages']):
        assert hashlib.sha256(canonical(q['request'])).hexdigest()==q['request_sha256']
        assert stage['record_id']==stage['ordinal']==q['id'] and stage['stage']=='COMPLETED'
        assert stage['purpose']==q['purpose'] and stage['limit']==plan['experiment_limits']['native_steps']
        for k in ('input_sha256','output_sha256','request_sha256'):assert stage[k]==q[k]
    assert pin(path/'native/input.bin')['sha256']==queries[-1]['input_sha256']
    assert pin(path/'native/output.bin')['sha256']==queries[-1]['output_sha256']
    qs=collections.Counter(q['result']['status'] for q in queries);status_total.update(qs)
    ground=t['clusters'];gq=queries[ground['admission_query']]
    assert gq['purpose']=='pilot_ground_cluster_admission' and gq['request']['theory']==t['spec']['theory']
    assert gq['request']['blocks']==[r['definition'] for r in ground['instances']]
    assert gq['result']['status']==ground['native_status']=='unknown_step_budget'
    assert gq['result']['micro_steps']==1000000000 and ground['usable']==[] and ground['binding_work']==20003
    wr=s['word_reference_diagnostics'];assert wr['complete'] is True
    assert [r['id'] for r in wr['controls']]==control_ids and all(r['status']=='PASSED' for r in wr['controls'])
    assert wr['tiny_full_byte_pair_comparisons']==49
    assert s['diagnostics']['status']=='complete' and s['diagnostics']['base_solutions']==s['diagnostics']['marked_solutions']
    assert s['diagnostics']['global_dead_forced_generation_controls'] is s['diagnostics']['callback_identity_propagated'] is True
    assert t['reference_check']['complete'] is t['word_model_check']['complete'] is t['marked_extension_check']['complete'] is t['marking_certificate_check']['complete'] is True
    m=t['model'];bykey={tuple(x['key']):x for x in m['placements']}
    assert len(bykey)==len(m['placements'])==t['reference_check']['accepted_placements']
    assert len(m['word_dictionary'])==t['reference_check']['distinct_complete_words']
    assert len(m['conflicts'])==t['reference_check']['internal_conflicts']
    assert m['word_terminator']==256 and m['initial']['marks']==[[[4*(t['spec']['length']-1),100],0]]
    assert bytes.fromhex(m['word_dictionary'][0])==canonical(t['spec']['target'])
    assert sum(len(r['keys']) for r in m['dependencies'])==t['reference_check']['dependency_memberships']
    roots={tuple(r['point']):r['keys'] for r in m['alignments']};certs=t['markings']['certificates']
    assert len(certs)==t['marking_certificate_check']['certificates']==t['marked_extension_check']['auxiliary_points']==12
    for i,c in enumerate(certs):
        assert c['id']==i and c['trial']==[c['auxiliary']['placement']]
        assert c['trial'][0][:2]==[0,0] and c['exhausted_root']==[0,1]
        assert c['auxiliary']['point']==[-100,i] and c['auxiliary']['placement_value']==0 and c['auxiliary']['initial_value']==1
        assert [r['key'] for r in c['all_candidates']]==roots[(0,1)]
    donors=[];assert len(s['training'])==len(s['library'])==3 and s['library_frozen_before_tests'] is True
    for tr,length in zip(s['training'],[3,5,5]):
        assert len(tr['search']['proof'])==len(tr['essential_proof'])==length
        assert tr['host_check']['accepted'] is tr['essential_host_check']['accepted'] is tr['region']['complete'] is tr['reference_check']['complete'] is True
        for field,proof in [('native_query',tr['search']['proof']),('essential_native_query',tr['essential_proof'])]:
            q=queries[tr[field]];assert q['result']['status']=='accepted'
            assert q['request']['proof']==proof and q['request']['theory']==tr['spec']['theory'] and q['request']['target']==tr['spec']['target'] and q['request']['blocks']==[]
        donors.append(dict(id=tr['spec']['id'],rows=length,whole_query=tr['native_query'],essential_query=tr['essential_native_query']))
    assert [a['id'] for a in t['arms']]==corpus['protocol']['arm_order'][cid]
    assert len(t['arms'])==6;arms={a['id']:a for a in t['arms']};arm_rows=[]
    for a in t['arms']:
        aid=a['id'];search=a['search']
        if aid in ['SC','P01','P11']:
            assert a['execution_status']=='SKIPPED_UNKNOWN_PREREQUISITE' and search is None
            assert a['host_check'] is a['region'] is a['native_query'] is a['native_proof_accepted'] is None
            assert all(a['timings'][k] is None for k in ('full_arm_seconds','search_seconds','host_region_native_seconds'))
            arm_rows.append(dict(id=aid,status=a['execution_status'],search=None));continue
        assert a['execution_status']=='SEARCH_RETURNED' and search['root_restored'] is True
        assert search['metrics']['attempts']==expected_attempts[index][aid]
        events=collections.Counter(x['event'] for x in search['trace'])
        row=dict(id=aid,status=search['status'],metrics=search['metrics'],trace_event_counts=dict(events),seconds=search['seconds'],full_arm_seconds=a['timings']['full_arm_seconds'],root_restored=search['root_restored'],proof_verification_status=a['proof_verification_status'])
        if aid.startswith('P'):
            assert search['status']=='unknown_search_budget' and search['proof'] is None and search['placements']==[]
            assert len(search['domain_audits'])==2 and all(r['complete'] is True for r in search['domain_audits'])
            assert events['place']==search['metrics']['attempts'] and events['decision']==search['metrics']['nodes']
            assert events['return']==search['metrics'].get('backtracks',0)
            assert search['trace'][-1]==dict(event='cutoff',attempts=search['metrics']['attempts'])
            kinds=collections.Counter(e['kind'] for e in search['trace'] if e['event']=='decision')
            for kind in ['branch','forced','dead']:assert kinds[kind]==search['metrics'].get(kind,0)
            for ordinal,e in enumerate(search['trace']):
                if e['event']=='decision':assert e['ordinal']==ordinal
                elif e['event']=='order':
                    dec=search['trace'][e['decision']]
                    assert dec['kind'] in ['forced','branch'] and sorted(e['alternatives'])==sorted(dec['original_alternatives'])
                elif e['event'] in ['place','return']:
                    assert e['key'] in search['trace'][e['decision']+1]['alternatives']
            assert len(search['initial_auxiliary_removals'])==(12 if aid=='P10' else 0)
            assert search['metrics']['auxiliary_removed_incidences']==0
            if aid=='P10':assert [w['candidate'] for w in search['initial_auxiliary_removals']]==[c['auxiliary']['placement'] for c in certs]
            row['initial_auxiliary_witnesses']=len(search['initial_auxiliary_removals'])
            row['completed_audits']=[dict(frontier_points=r['frontier_points'],incidences=r['incidences'],decision_kind=r['decision'][0],decision_point=r['decision'][1],decision_candidate_count=len(r['decision'][2])) for r in search['domain_audits']]
            raw_point+=search['metrics']['attempts'];raw_audits+=2
            admitted_point+=search['metrics']['attempts'];admitted_audits+=2
        elif index==0:
            assert a['native_proof_accepted'] is a['host_check']['accepted'] is a['region']['complete'] is True
            assert len(search['proof'])==14 and len(search['placements'])==28
            q=queries[a['native_query']];assert q['result']['status']=='accepted' and q['purpose']=='pilot_test_'+cid+'_S0'
            assert q['request']['proof']==search['proof'] and q['request']['theory']==t['spec']['theory'] and q['request']['target']==t['spec']['target'] and q['request']['blocks']==[]
            for key in search['placements']:
                item=bykey[tuple(key)];slot,k=item['command_reference'];assert m['domains'][slot][k]==search['proof'][slot]
            row['admitted_conventional_proof_observation']=dict(rows=14,selected_placements=28,Host=a['host_check'],region=a['region'],Native_query=q['id'],Native_status=q['result']['status'],rule_counts=dict(collections.Counter(c['rule'] for c in search['proof'])),admitted_proof=True,novel_mathematical_theorem=False,GCTS_point_search_proof=False)
        else:assert search['proof'] is None and search['status']=='unknown_search_budget'
        arm_rows.append(row)
    p00=arms['P00']['search'];p10=arms['P10']['search']
    assert p00['domain_audits'][0]['incidences']-p10['domain_audits'][0]['incidences']==12
    assert p00['domain_audits'][0]['decision']==p10['domain_audits'][0]['decision']
    assert p00['domain_audits'][1]==p10['domain_audits'][1]
    admitted=True;assert observer['resource_candidate_accepted'] is admitted
    assert tool['terminal']['exit_code']==observer['parent_exit_code']==0
    assert (observer['conservative_whole_peak_bytes']<plan['limits']['memory_bytes']) is admitted
    control=record['independent_external_controls']
    assert control['supplied_to_proof_search'] is False and all(control['base']['premise_truths']) and control['base']['goal_truth'] is False
    files=sorted(p for folder in [path,op.parent] for p in folder.rglob('*') if p.is_file())
    assert not any('.partial' in p.name for p in files)
    actual_pins.extend(pin(p) for p in files)
    observations.append(dict(case_id=cid,resource_admitted=admitted,packet=rp,worker_status=record['status'],worker_exit=terminal['process_exit_code'],observer_tool_exit=tool['terminal']['exit_code'],whole_peak_bytes=observer['conservative_whole_peak_bytes'],observer_gate_seconds=observer['final_observer_gate_seconds'],plan=pin(plan_path),grant=pin(gp),consumed=pin(path/'CONSUMED.json'),Native_queries=len(queries),Native_status_counts=dict(qs),Native_request_stage_joins=len(queries),donors=donors,library_family_ids=[x['id'] for x in s['library']],job_record_complete=True,scientific_complete=False,recipient_proofs_admitted=(1 if index==0 else 0),word_reference_controls_returned=48,word_reference_controls_qualified=admitted,reference_check=t['reference_check'],marking_certificates=12,marking_scope='All12 are first-row command/guard support exhaustion, shallow local failures rather than learned high-level lemmas.',initial_audited_incidence_difference=12,second_audits_identical=True,compile_and_model_seconds=t['compile_and_model_seconds'],full_shared_setup_seconds=t['full_shared_setup_seconds'],word_evidence_seconds=t['word_model_seconds'],ground_Native_status=ground['native_status'],ground_binding_work=ground['binding_work'],arms=arm_rows))

assert raw_point==112 and raw_audits==12 and admitted_point==112 and admitted_audits==12
assert len(actual_pins)==42 and dict(status_total)==dict(accepted=75,rejected=209,unknown_step_budget=3)
old_review=OLD/'review-C/typed-parent-domain-actual-scientific-review-v1.json'
old=read(old_review);assert old['review_passed'] is True
for row in old['actual_file_pins']:verify(row)
old_first=read(OLD/'actual/pilot-fork-join-positive/result.json')
old_proof=next(a for a in old_first['scientific_result']['tests'][0]['arms'] if a['id']=='S0')['search']['proof']
current_first=read(D/'actual/pilot-fork-join-positive/result.json')
assert old_proof==next(a for a in current_first['scientific_result']['tests'][0]['arms'] if a['id']=='S0')['search']['proof']
history=[]
for row in observations:
    prior=next(c for c in old['cases'] if c['case_id']==row['case_id'])
    history.append(dict(case_id=row['case_id'],D9_resource_admitted=prior['resource_admitted'],D10_resource_admitted=row['resource_admitted'],D9_whole_peak_bytes=prior['whole_peak_bytes'],D10_whole_peak_bytes=row['whole_peak_bytes'],D9_point_attempts={a['id']:a['metrics']['attempts'] for a in prior['arms'] if a['id'] in ['P00','P10']},D10_point_attempts={a['id']:a['metrics']['attempts'] for a in row['arms'] if a['id'] in ['P00','P10']},interpretation='Historical single cold development observations only; no identical timed-prefix, phase-memory attribution, statistical inference or causal speedup claim.'))
checks=[
 ('complete-pins-and-fresh-attempts','All41 offered Source/runtime/input pins remain exact.42 complete actual/observer files and three unique consumed once grants join exact plans and prior independent reviews. No partials observed/parsed. This audit invokes no research code, Native/Host checker, model constructor, generator, fixture, sizing or semantic replay.'),
 ('whole-resource-classification','All three worker packets COMPLETE/child0 and parent/observer/tool0 reconcile; conservative whole peaks839,303,168/812,433,408/852,721,664B are below unchanged1GiB. All three whole jobs now qualify. Resource completion remains distinct from proof acceptance and scientific comparison completion; prior failed jobs are not rescued or relabeled.'),
 ('full-arm-population-and-query-joins','Nine searches/nine explicit Native-UNKNOWN prerequisite skips are all within qualified jobs. All287 Native request digests, complete stages and terminal input/output hashes join; statuses75accepted/209rejected/3unknown. Ground batches each exhaust1e9 microsteps and expose no usable inventory. Eighteen donor whole/essential requests accepted3/5/5 inside fresh cold qualified jobs; no cluster recipient arm executes.'),
 ('actual-reduction-and-existing-controls','All48 unchanged independent word-reference controls returned per case,144 qualified control rows total. Full target reduction, literal evidence, overlay and existing Tiny scheduler/rollback diagnostics returned. These are saved observations linked to the prior Source argument, not a fresh checker replay, universal correctness proof or arbitrary partial-byte-state claim.'),
 ('recipient-point-progress-and-rollback','All six point calls completed two full independent domain/inverse/scheduler audits,112 placement events total. Counts P00/P10 are19/15,13/20,22/23. Every saved order preserves the complete decision alternatives; placement/return keys, counters, cutoffs and restored root fingerprints reconcile. Equality P10 reaches one dead/backtrack; negative P00 three and P10 four. Only the initial two states per call are independently audited; Source ownership supports parent preservation beyond them, not an exhaustive runtime audit at every later node.'),
 ('real-marking-effect-with-local-scope','All12 certificates per case exhaust the full recorded first-row guard support for a trial first-row command. Actual P10 initial Graph audit has12 fewer incidences than P00 at the same frontier/first decision; second audited state agrees. This is observed ordinary marking-based initial pruning, with no additional during-placement auxiliary removals. It is shallow local plumbing and does not establish high-level lemma discovery or faster solving.'),
 ('qualified-conventional-proof-not-GCTS-or-novel-theorem','First S0 returns14 primitive rows/28 exact command+guard placements and exact Host/full-region/Native acceptance request89 inside a now-qualified whole job. The complete saved proof equals the prior D9 conventional S0 proof, and its theorem was already separately admitted in D7. Thus D10 has one qualified conventional baseline certificate, no new mathematical theorem or GCTS point proof. Both remaining S0 runs and all six point runs remain bounded UNKNOWN; the authored external negative model was not supplied to search.'),
 ('owned-cutoff-Source-inference-and-historical-scope','Exact v8 Source plus returned owned-cutoff events and post-handler fingerprints support passage through the guarded traceback clear in point searches. No direct traceback snapshot, live-object census or phase-memory instrumentation was saved. All runtime/custodian Sources, clocks and gates remain unchanged apart from the reviewed point-only cleanup/VERSION. D9 actual raw pins revalidate unchanged. All three D10 cases fit where D9 first failed, but clearing cannot reverse an earlier HWM and single timed runs cannot prove causal/statistical memory or speed benefit. Shared setup remains roughly79–90s. Nine cluster skips prevent a full six-arm comparison; trainedRL/GCTS advantage/fullWang/general proof-search progress remain open.'),
]
assessment=D/'root/passive-actual-assessment-v1.json'
assert pin(assessment)['sha256']=='c62c71afd9c9896f03c3421b0ccba5c23f67392a44a9ab943d0cf9f55ebc54ad'
review=dict(schema='typed-owned-cutoff-actual-scientific-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_PASSIVE_COMPLETE_SAVED_OUTCOME_SCOPE_ALL_THREE_RESOURCE_JOBS_QUALIFIED',passive_complete_saved_data_only=True,scientific_calls=0,logical_replays=0,actual_execution_authorized=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f) for i,f in checks],resource_admitted_case_ids=cases,resource_rejected_case_ids=[],recipient_proofs_admitted=1,recipient_proof_engine='unchanged conventional symbolic S0 baseline',GCTS_point_proofs_admitted=0,novel_mathematical_theorem=False,complete_pilot_comparison=False,GCTS_or_RL_advantage_established=False,raw_and_admitted_totals=dict(searches=9,skips=9,point_placements=112,point_domain_audits=12,Native_queries=287,Native_status_counts=dict(status_total),donor_whole_essential_acceptances=18,word_control_returns=144,conventional_recipient_proofs=1),cases=observations,actual_file_pins=actual_pins,whole_offer=pin(D/'root/prospective-whole-offer-v1.json'),scientific_Source_delta_review=pin(D/'review-C/typed-scientific-delta-Source-review-v1.json'),whole_Source_preflight=pin(D/'review-C/typed-whole-prospective-Source-review-v1.json'),external_tool_observer=pin(D/'root/external-tool-observer-v1.json'),Root_passive_assessment=pin(assessment),D9_historical_review=pin(old_review),historical_comparison=history,partial_policy='No partial contents read/projected/adopted. Earlier rejected jobs remain rejected; no prefix rescue or grant reuse.',remaining='One repeated conventional certificate qualifies; full six-arm comparison, GCTS point/cluster/RL benefit and all broader mathematical/tiling goals remain open. No further experiment authorized by this review.',tools_stopped=True)
resource=D/'verification-L/typed-owned-cutoff-resource-custody-review-v1.json'
if resource.exists():
    rr=read(resource);assert rr['review_passed'] is True
    review['independent_resource_review']=pin(resource)
target=D/'review-C/typed-owned-cutoff-actual-scientific-review-v1.json';assert not target.exists()
target.write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(target),indent=2))
