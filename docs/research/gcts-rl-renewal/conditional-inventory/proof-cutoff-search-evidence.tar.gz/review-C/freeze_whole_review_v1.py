"""Metadata/AST preflight only. No offered scientific module is imported/called."""
import ast
import hashlib
import json
from pathlib import Path

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D=BASE/'research-runs/gcts-cutoff-proof-pilot-20261020'
OLD=BASE/'research-runs/gcts-proof-memory-pilot-20261020'
D8=BASE/'research-runs/gcts-word-point-proof-pilot-20261020'


def pin(path):
    p=Path(path);assert '.partial' not in p.name
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def read(path):
    p=Path(path);assert p.suffix=='.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())


def verify(r):assert pin(r['path'])=={k:r[k] for k in ('path','bytes','sha256')}


op=D/'root/prospective-whole-offer-v1.json';offer=read(op)
assert len(offer['files'])==len({r['path'] for r in offer['files']})==41
for r in offer['files']:verify(r)
asts=offer['source_AST_checks'];assert len(asts)==33
assert {r['path'] for r in asts}=={r['path'] for r in offer['files'] if r['path'].endswith('.py')}
for r in asts:
    assert r['AST_and_unused_compile'] is True
    t=ast.parse(Path(r['path']).read_bytes(),filename=r['path'])
    unused_code=compile(t,r['path'],'exec');del unused_code
assert offer['expected_case_jobs']==3 and offer['expected_explicit_arm_outcomes']==18
assert offer['new_actuals']==offer['new_grants']==offer['old_grants_remaining']==0
protocol=read(offer['protocol']['path']);verify(offer['protocol']);verify(offer['python'])
prior_protocol=read(OLD/'root/protocol-v1.json')
for field in ['input','limits','scientific_limits']:assert protocol[field]==prior_protocol[field]
verify(protocol['input'])
api=read(D/'implementation-B/API-v1.json')
assert api['limits']==protocol['scientific_limits']
assert len(list((D/'runtime').glob('*.py')))==len(list((OLD/'runtime').glob('*.py')))==28
for path in (OLD/'runtime').glob('*.py'):assert path.read_bytes()==(D/'runtime'/path.name).read_bytes()
for name in ['case_worker_v1.py','run_case_once_v3.py','observe_case_once_v2.py','independent_countermodel_v1.py']:
    assert (D/'root'/name).read_bytes()==(OLD/'root'/name).read_bytes()
case_ids=[]
for r in offer['plans']:
    verify(r);plan=read(r['path']);case_ids.append(plan['case_id'])
    old_plan=read(OLD/'root'/('plan-'+plan['case_id']+'-v1.json'))
    assert plan['files']==offer['files']
    assert plan['protocol']==offer['protocol'] and plan['python']==offer['python']
    assert plan['limits']==protocol['limits'] and plan['experiment_limits']==protocol['scientific_limits']
    assert plan['modules']==api['roles']==old_plan['modules'] and plan['native']==old_plan['native']
    assert plan['input_path']==protocol['input']['path']
    assert plan['entry_path']==api['entry']['path'] and plan['runtime_dir']==str(D/'runtime')
    for field,name in [('worker_path','case_worker_v1.py'),('runner_path','run_case_once_v3.py'),('observer_path','observe_case_once_v2.py'),('control_path','independent_countermodel_v1.py')]:
        assert plan[field]==str(D/'root'/name)
    assert plan['actual_dir']==str(D/'actual'/plan['case_id'])
    assert not Path(plan['actual_dir']).exists() and not Path(plan['actual_dir']+'.observer').exists()
assert len(set(case_ids))==3 and set(case_ids)=={'pilot-fork-join-positive','pilot-quantifier-equality-positive','pilot-fork-join-missing-Pa'}
assert not list((D/'root').glob('grant-*.json'))
science=D/'review-C/typed-scientific-delta-Source-review-v1.json'
assert pin(science)['sha256']=='2a6d903c9212d696192cb25b0fb2cee22ce38c9b8f7c92f33c3b0fa160e24efc'
assert read(science)['review_passed'] is True
prior_C=OLD/'review-C/typed-whole-prospective-Source-review-v1.json'
prior_L=OLD/'verification-L/typed-parent-domain-Source-ABI-whole-plan-review-v1.json'
assert read(prior_C)['review_passed'] is read(prior_L)['review_passed'] is True
original_handoff=D8/'verification-L/handoff-v1.json'
assert pin(original_handoff)['sha256']=='5cfa4cc5ed78ff1f762040c6c394375a87165c11416bebded0ce2233a97386c2'
current_handoff=D/'implementation-B/handoff-v1.json'
assert any(r==pin(current_handoff) for r in offer['files'])
assert read(current_handoff)['verifier_source']==read(original_handoff)['source']
checks=[
 ('exact-closure-and-unchanged-runtime','All41 file pins independently revalidated;33 Sources AST/unused compiled without execution/import. All28 runtime Sources and all four custodians are byte-identical D9. New v8 entry/API/handoff are exact separately reviewed frozen bodies. The current B handoff replaces the original L handoff metadata row in the closure and binds the same verifier Source; original L provenance remains an explicit inherited pin. No new checker, model, callback, dependency or semantic helper enters the closure.'),
 ('exact-point-only-cleanup-review','C2a6d903c… delta review binds complete v7/v8 raw inverse, unchanged28 other function/class ASTs and exact owned identityguard→cutoffevent→tracebackclear handler. Existing Graph/state/word-carrier/parent-view judgments remain within scope. No measured collection, HWM reversal, active-recursion saving or fit prediction is inferred.'),
 ('three-full-fresh-cold-case-plans','Three exact plans bind distinct absent actual/observer paths, entire original corpus, same roles/Native assets and full Source closure. Full14/13/14 targets, three3/5/5 donor searches and six relative arm schedules unchanged. No old result, prefix, learned library or grant reused; all18 outcomes and proof gates remain required for complete comparison.'),
 ('unchanged-clocks-limits-and-proof-policy','All outer/scientific limits exactly match D9, including2s cooperative clock before Graph/snapshots/audits,600attempts, firsttwo independent full audits,400m callbacks and Native1e9steps. Known ground UNKNOWN skips only dependent arms; foreign/rejected/Root faults remain faults. Host/full finite region/final primitive Native proof gates unchanged.'),
 ('custody-source-reuse-and-runtime-admission','Exact unchanged custodian Source permits scoped reuse of prior C/L judgments under fixed nonhostile assumptions.160work/180positive/210custody/225independent fallback,1GiB/128MiB/9MiBreserve and output/log gates remain. Actual complete outputs, waited Native reaping, post-output memory, stable final census, terminal/observer/tool exits and fresh consumed grant joins still determine admission; Source review cannot adopt failed D9 cases.'),
 ('no-authority-and-independent-barrier','No actual/grant/remaining old grant and absent per-case directories verified at freeze. This receipt grants no execution authority and assumes no fresh L PASS. Root must separately collect independent D10 L preflight, issue fresh one-use grants and observe all tools idle before its three sequential actuals. Every new result remains subject to complete evidence and scientific interpretation.'),
]
result=dict(schema='typed-owned-point-cutoff-whole-prospective-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_EXACT_SOURCE_PLAN_PREFLIGHT_SEPARATE_L_AND_ROOT_GRANT_REQUIRED',source_only=True,scientific_calls=0,component_calls=0,actual_execution_authorized=False,actual_resource_accepted=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f) for i,f in checks],whole_offer=pin(op),protocol=offer['protocol'],plans=offer['plans'],file_pins=offer['files'],AST_unused_compile_count=33,unchanged_runtime_Source_count=28,unchanged_custodian_Source_count=4,scientific_delta_review=pin(science),original_D8_L_verifier_handoff=pin(original_handoff),inherited_D9_C_preflight=pin(prior_C),inherited_D9_L_preflight=pin(prior_L),separate_D10_L_review_required=True,L_PASS_not_assumed=True,fit='UNMEASURED',new_actuals=0,new_grants=0,old_grants_remaining=0,partial_policy='No partial parsing/projection/admission; previous failed attempts stay failed.',tools_stopped=True)
result['current_B_implementation_handoff_in_closure']=pin(current_handoff)
result['review_author_correction']=dict(preimage=pin(D/'review-C/review-author-handoff-join-preimage-v1.py'),finding='Initial reviewer metadata author assumed the old L handoff remained an offered closure member. The assertion refused before any receipt was written. The exact frozen offer instead includes current B handoff, whose verifier pin exactly equals original L Source pin. This correction changes only reviewer metadata expectations and documentation; no offered Source, plan, gate or artifact was edited, and no earlier PASS existed.')
target=D/'review-C/typed-whole-prospective-Source-review-v1.json';assert not target.exists()
target.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(target),indent=2))
