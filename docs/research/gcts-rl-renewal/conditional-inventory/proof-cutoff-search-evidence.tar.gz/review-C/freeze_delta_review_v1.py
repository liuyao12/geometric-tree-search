"""Independent Source/AST/raw metadata only; never imports offered research code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D=BASE/'research-runs/gcts-cutoff-proof-pilot-20261020'
OLD=BASE/'research-runs/gcts-proof-memory-pilot-20261020'


def pin(path):
    p=Path(path);assert '.partial' not in p.name
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def read(path):
    p=Path(path);assert p.suffix=='.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())


def rows(obj):
    if type(obj)is dict:
        if {'path','bytes','sha256'}<=obj.keys():yield obj
        else:
            for child in obj.values():yield from rows(child)
    elif type(obj)is list:
        for child in obj:yield from rows(child)


def tree(path):
    t=ast.parse(Path(path).read_bytes(),filename=str(path))
    unused_code=compile(t,str(path),'exec');del unused_code
    return t


hpath=D/'implementation-B/handoff-v1.json';h=read(hpath);artifacts={}
for filename in ['handoff-v1.json','manifest-v1.json','API-v1.json','AST-diff-v1.json','manual-lifecycle-scope-v1.json']:
    p=D/'implementation-B'/filename
    for r in rows(read(p)):
        actual=pin(r['path']);assert actual=={k:r[k] for k in ('path','bytes','sha256')}
        artifacts[actual['path']]=actual
    artifacts[str(p)]=pin(p)
new=Path(h['entry']['path']);old=OLD/'implementation-B/proof_search_pilot_v7.py'
assert pin(new)['sha256']=='11ce58bc403677331b69db2dc01d9a11adcae165b017c997034ebe1a7123aa46'
before=old.read_text();after=new.read_text()
version_old="VERSION = 'native-point-matched-proof-search-pilot-v7-parent-domain-view'"
version_new="VERSION = 'native-point-matched-proof-search-pilot-v8-owned-point-cutoff'"
cutoff="        trace.append(dict(event='cutoff', attempts=budget.attempts))"
assert before.count(version_old)==1 and before.count(cutoff)==2
assert before.replace(version_old,version_new).replace(cutoff,cutoff+'\n        budget.stop.__traceback__ = None',1)==after
patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(old),tofile=str(new)))
assert patch==Path(h['patch']['path']).read_text()
ta=tree(old);tb=tree(new)
def members(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
ma=members(ta);mb=members(tb);assert ma.keys()==mb.keys()
changed=[n for n in ma if ast.dump(ma[n],include_attributes=False)!=ast.dump(mb[n],include_attributes=False)]
assert changed==['search_points'] and len(ma)-1==28
handlers=[n for n in ast.walk(mb['search_points']) if isinstance(n,ast.ExceptHandler)]
assert len(handlers)==1
handler=handlers[0]
assert ast.dump(handler.type)=='Name(id=\'_Cutoff\', ctx=Load())' and handler.name=='error'
expected=ast.parse("try:\n pass\nexcept _Cutoff as error:\n if error is not budget.stop:\n  raise\n trace.append(dict(event='cutoff', attempts=budget.attempts))\n budget.stop.__traceback__ = None\n").body[0].handlers[0]
assert ast.dump(handler,include_attributes=False)==ast.dump(expected,include_attributes=False)
assert ast.dump(ma['_Budget'],include_attributes=False)==ast.dump(mb['_Budget'],include_attributes=False)
assert ast.dump(ma['search_symbolic'],include_attributes=False)==ast.dump(mb['search_symbolic'],include_attributes=False)
master=BASE/'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md'
assert pin(master)['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
inherited=[OLD/'review-C/typed-scientific-delta-Source-review-v1.json',OLD/'review-C/typed-whole-prospective-Source-review-v1.json',OLD/'review-C/typed-parent-domain-actual-scientific-review-v1.json']
assert all(read(p)['review_passed'] is True for p in inherited)
checks=[
 ('exact-executable-delta','All frozen B handoff/API/manual/manifest/dependency pins match; full raw inverse and unified patch reproduce v7 exactly. Only search_points function AST changes;28 other function/class ASTs, including _Budget and search_symbolic, are identical. VERSION is the only other text delta. AST/unused compile only; no offered function executed or imported.'),
 ('identity-and-trace-dominance','The exact _Cutoff handler has unchanged `if error is not budget.stop: raise`, followed by unchanged cutoff-event append, then the sole new assignment `budget.stop.__traceback__ = None`. Both successful identity classification and trace recording dominate cleanup. The exact stop object created in the unchanged _Budget is retained; no exception replacement, type-only ownership inference or broad/finally suppression occurs.'),
 ('foreign-and-Root-fault-safety','Different _Cutoff instances re-raise before cleanup. RootBudget, transport, callback and all other exception types remain outside the handler. If trace append itself faults, cleanup is not reached and that fault escapes. No Root callback/check is removed or added; no external exception traceback, context, cause or first-fault record is rewritten. Scope is pinned fixed nonhostile callbacks/runtime, not arbitrary frame-introspecting mutation.'),
 ('limited-lifecycle-effect','A retained owned exception traceback can own recursive visit frames, whose locals include child/parent Graphs and states; the outer budget owns that exception. Assigning None removes that particular exception-to-traceback edge after recursive unwinding. This is a manual Source ownership argument, not a measurement of collection or RSS. It cannot remove still-active recursion graphs, erase an earlier HWM, force GC or page return, clear all other owners/context chains or guarantee numeric fit.'),
 ('search-evidence-and-remaining-goals-unchanged','Cutoff remains UNKNOWN with the same event/attempt count, complete alternatives, initial/final root fingerprints, full domain/inverse/scheduler audits, certificate/overlay/reduction checks and Host/full-region/final Native gates. All field names/data remain; private owned traceback was not serialized scientific evidence. Existing word-carrier and parent-view judgments are reused in original scope. No new proof, GCTS/RL gain, speedup, phase attribution or old failed-case admission follows; exact new plans and actual gates remain mandatory.'),
]
review=dict(schema='typed-owned-point-cutoff-scientific-delta-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_EXACT_POINT_OWNED_CUTOFF_SOURCE_DELTA_ONLY_NO_FIT_OR_ACTUAL_ADMISSION',source_only=True,scientific_calls=0,component_calls=0,actual_execution_authorized=False,actual_resource_accepted=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f) for i,f in checks],entry=pin(new),predecessor=pin(old),patch=pin(h['patch']['path']),implementation_handoff=pin(hpath),artifacts=list(artifacts.values()),master=pin(master),changed_top_level_functions=changed,unchanged_function_class_AST_count=28,inherited_scoped_reviews=[pin(p) for p in inherited],manual_scope='Conditional Source ownership/fault argument, not a mechanized theorem, runtime conformance experiment or numerical memory/cost bound.',remaining='Root exact whole-offer plans, independent L review, fresh once grants and idle barrier before any actual. All actual outcomes and earlier failed cohorts remain subject to complete saved evidence admission.',new_actuals=0,new_grants=0,tools_stopped_after_whole_preflight=True)
target=D/'review-C/typed-scientific-delta-Source-review-v1.json';assert not target.exists()
target.write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(target),indent=2))
