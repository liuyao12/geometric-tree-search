"""Administrative report packaging from reviewed observations; no research imports."""
from pathlib import Path
import argparse
import hashlib
import html
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OLD = ROOT / 'publication-lossless-qualification-v2'
P2 = ROOT.parents[1] / 'gcts-batch-20261020' / 'publisher-recovery-6338a77'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-search-v1.html', 'point-proof-parallel-progress-v1.html',
         'point-proof-lossless-qualification-data-v1.json', 'point-proof-lossless-qualification-evidence-v1.zip')


def rawpin(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def emit(path, body):
    with path.open('xb') as stream:
        stream.write(body)


def jsonbody(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def esc(value):
    return html.escape(str(value), quote=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--catalog', required=True)
    args = parser.parse_args()
    catpath = Path(args.catalog)
    cat = json.loads(catpath.read_bytes())
    assert cat['scientific_actuals_this_turn'] == 1 and cat['new_research_proofs'] == 0
    assert cat['current_disposition_reviewed'] is True
    output = ROOT / 'publication-lossless-qualification-v3'
    staging = P2 / 'publication-payload-lossless-qualification-v3'
    assert not output.exists() and not staging.exists()
    output.mkdir()
    staging.mkdir()
    entries = []
    names = set()
    with zipfile.ZipFile(output / NAMES[3], 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for ref in cat['archive_files']:
            path = Path(ref['path'])
            assert path.is_relative_to(ROOT.parents[2]) and path.is_file() and not path.is_symlink()
            body = path.read_bytes()
            assert rawpin(body) == {k: ref[k] for k in ('bytes', 'sha256')}
            name = path.relative_to(ROOT.parents[2]).as_posix()
            assert name not in names
            names.add(name)
            archive.writestr(name, body)
            entries.append(dict(name=name, **rawpin(body)))
        archive.writestr('milestone-catalog.json', catpath.read_bytes())
        entries.append(dict(name='milestone-catalog.json', **rawpin(catpath.read_bytes())))
    with zipfile.ZipFile(output / NAMES[3]) as archive:
        assert archive.testzip() is None and archive.namelist() == [row['name'] for row in entries]
        for row in entries:
            assert rawpin(archive.read(row['name'])) == {k: row[k] for k in ('bytes', 'sha256')}
    data = {k: v for k, v in cat.items() if k != 'archive_files'}
    data.update(schema='Root-lossless-native-compare-publication-data-v1', members=entries,
                archive=rawpin((output / NAMES[3]).read_bytes()), archive_member_count=len(entries))
    emit(output / NAMES[2], jsonbody(data))
    old = (OLD / NAMES[1]).read_text()
    assert rawpin(old.encode())['sha256'] == '08b2fd6fac5fd26ce8eba624655776133ac722407521c18e72f485af17cb57fc'
    head = old.split('</head>', 1)[0]
    title_start, title_end = head.index('<title>'), head.index('</title>') + len('</title>')
    head = head[:title_start] + '<title>Parallel proof-search research: bounded comparison experiment</title>' + head[title_end:]
    rows = ''.join('<tr><td>' + esc(row['label']) + '</td><td>' + esc(row['observer_time_display'])
                   + '</td><td>' + esc(row['event']) + '</td><td>' + esc(row['disposition']) + '</td></tr>'
                   for row in cat['case_summaries'])
    assert len(cat['case_summaries']) == 3
    page = head + '''</head><body><main>
<p class="eyebrow">GCTS + RL research · 23 October 2026 UTC</p>
<h1>Parallel work, one measured experiment</h1>
<p>Implementation, independent expectations and critical review produced a narrowly scoped string-comparison optimization. A new complete experiment used the existing obligations and limits.</p>
<p class="notice"><strong>''' + esc(cat['current_headline']) + '''</strong> ''' + esc(cat['current_plain_observation']) + '''</p>
<p>The research program remains active. This is an infrastructure experiment: no new mathematical theorem, learned inventory or GCTS/RL advantage is claimed. <a href="point-proof-search-v1.html#native-compare-current">Main research notebook</a>.</p>
<section class="panel"><h2>What changed</h2>
<div class="pipe" role="img" aria-label="Same checkpoint, bounded native comparison, same exact ordering, unchanged evidence requirements">
<div class="step"><b>Same check</b>The existing genuine budget and policy check runs before each comparison block.</div>
<div class="step"><b>Bounded native work</b>Compare ordinary string slices of at most \\(4096\\) codepoints instead of a Python character loop.</div>
<div class="step"><b>Same semantics</b>Exact Unicode codepoint order, equality and prefix resolution remain required.</div>
<div class="step"><b>Whole evidence</b>All original evidence and mandatory complete canonical readback remain required.</div>
</div><p class="caption">The old implementation already checked once per block. No callback batching, cache or new compression profile was introduced. Native slicing and comparisons allocate memory and are not preemptible.</p></section>
<section class="panel"><h2>Three distinct experiments</h2><table><thead><tr><th>Case</th><th>Saved observer time</th><th>Terminating event</th><th>Disposition</th></tr></thead><tbody>''' + rows + '''</tbody></table>
<p class="caption">These are different whole attempts. Failed-stage labels do not qualify a prefix. Saved worker, observer and custody clocks are separate; timings alone do not establish a speedup or cost profile.</p></section>
<section class="panel"><h2>Why several agents help</h2><div class="grid">
<article class="card"><h3>Implementation</h3><p>Changed one comparator. Every other codec definition and all proof-worker function bodies were preserved exactly.</p></article>
<article class="card"><h3>Independent expectations</h3><p>Specified ordering, prefixes, block boundaries, genuine checks and first-error requirements before reading the new implementation.</p></article>
<article class="card"><h3>Critical review</h3><p>Checked the complete source delta, the run declaration and the resulting whole packet. Source approval remained separate from execution evidence.</p></article>
</div><p>Root integrated the work and owned the measured run, with other task agents and tools idle. Parallelism supports implementation and independent scrutiny; timed comparisons stay serial.</p></section>
<section class="panel"><h2>What stayed fixed</h2><p>The original 221 obligations, 36 original module roles and 15 original wrappers were retained. Eight separate transport-control groups give 229 groups across 17 populations and 38 roles. These are infrastructure checks, not theorem targets.</p><p>Work, memory, output and custody limits stayed fixed. Both earlier negative cases remain negative. A failed run cannot supply an admitted inventory, proof or qualified prefix.</p></section>
<section class="panel"><h2>The scientific work ahead</h2><p>''' + esc(cat['next_scientific_step']) + '''</p>
<p>The broader parallel lanes should deliver a sound symbolic proof core, acquired receptor families and hierarchical clusters, and matched conventional-search benchmarks. Practical regional tiling remains a separate validation lane. Arithmetic and symbolic Hilbert geometry share the intended logic; a fixed finite universal Wang palette is still unbuilt.</p>
<p>Independent line-by-line proof checking and complete primitive fallback remain essential. Success means automatically acquired reusable structure helping new checked proofs, with construction and validation costs included.</p></section>
<section class="panel" id="downloads"><h2>Inspect the evidence</h2><p><a href="point-proof-lossless-qualification-data-v1.json">Run dispositions, clocks and archive manifest</a> · <a href="point-proof-lossless-qualification-evidence-v1.zip">Complete sources, reviews and observed packets</a></p>
<details><summary>Earlier milestones</summary><p><a href="point-proof-codec-source-manifest-v1.json">Historical source milestone</a> · <a href="point-proof-codec-source-evidence-v1.zip">Historical source archive</a> · <a href="point-proof-output-qualification-data-v1.json">Earlier output-ceiling negative</a> · <a href="point-proof-output-qualification-evidence-v1.zip">Its unchanged archive</a></p></details>
<p class="caption">Every archived member was freshly read and hash-checked. Publication imports or reruns no scientific code. The runtime binary is identified and freshly hashed but not redistributed.</p></section>
<footer>One new whole experiment. ''' + esc(cat['current_headline']) + ''' No new theorem or learned proof-search advantage.</footer>
</main></body></html>'''
    emit(output / NAMES[1], page.encode())
    main_report = (OLD / NAMES[0]).read_text()
    assert rawpin(main_report.encode())['sha256'] == 'd36d357bebfb89a48722240e6c3bcadaefce0eb2ede624dfe4a795798becdf65'
    notice = '<p class="notice" id="native-compare-notice"><strong>Current bounded comparison experiment · 23 October 2026 UTC.</strong> ' + esc(cat['current_headline']) + ' ' + esc(cat['current_plain_observation']) + ' Earlier status panels below are historical. <a href="point-proof-parallel-progress-v1.html">Current visual report and evidence</a>.</p>'
    anchor = '<p class="notice" id="lossless-qualification-notice">'
    assert main_report.count(anchor) == 1
    main_report = main_report.replace(anchor, notice + anchor, 1)
    section = '<section class="panel" id="native-compare-current"><h2>Bounded native comparison: current whole result</h2><p>' + esc(cat['current_headline']) + ' ' + esc(cat['current_plain_observation']) + '</p><p>No new theorem, learned inventory or GCTS/RL advantage follows. ' + esc(cat['next_scientific_step']) + '</p><p><a href="point-proof-parallel-progress-v1.html">Visual report</a> · <a href="point-proof-lossless-qualification-data-v1.json">Data</a> · <a href="point-proof-lossless-qualification-evidence-v1.zip">Evidence</a></p></section>'
    anchor2 = '<section class="panel" id="lossless-qualification-current">'
    assert main_report.count(anchor2) == 1
    main_report = main_report.replace(anchor2, section + anchor2, 1)
    assert main_report.replace(notice, '', 1).replace(section, '', 1) == (OLD / NAMES[0]).read_text()
    emit(output / NAMES[0], main_report.encode())
    files = []
    for name in NAMES:
        body = (output / name).read_bytes()
        emit(staging / name, body)
        files.append(dict(path=PREFIX + name, publisher_source=str(staging / name), **rawpin(body),
                          git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()))
    emit(output / 'P2-staging.json', jsonbody(dict(schema='Root-lossless-qualification-publication-staging-v1',
        catalog=dict(path=str(catpath), **rawpin(catpath.read_bytes())), files=files,
        archive_members_verified=len(entries), scientific_execution=False, published=False)))
    print(json.dumps(dict(files=files, archive_members=len(entries), staging=str(output / 'P2-staging.json'))))


if __name__ == '__main__':
    main()
