"""Administrative complete-negative report packaging; no research module imports."""
from pathlib import Path
import argparse
import hashlib
import html
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OLD = ROOT / 'publication-codec-source-v1'
P2 = ROOT.parents[1] / 'gcts-batch-20261020' / 'publisher-recovery-6338a77'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-search-v1.html', 'point-proof-parallel-progress-v1.html',
         'point-proof-lossless-qualification-data-v1.json', 'point-proof-lossless-qualification-evidence-v1.zip')


def rawpin(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def emit(path, body):
    with path.open('xb') as stream:
        stream.write(body)


def jsonbody(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--catalog', required=True)
    args = parser.parse_args()
    catpath = Path(args.catalog)
    cat = json.loads(catpath.read_bytes())
    assert cat['new_qualified_suites'] == 0 and cat['new_research_proofs'] == 0
    assert cat['scientific_actuals_this_turn'] == 2
    output = ROOT / 'publication-lossless-qualification-v1'
    staging = P2 / 'publication-payload-lossless-qualification-v1'
    assert not output.exists() and not staging.exists()
    output.mkdir()
    staging.mkdir()
    entries = []
    with zipfile.ZipFile(output / NAMES[3], 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for ref in cat['archive_files']:
            path = Path(ref['path'])
            assert path.is_relative_to(ROOT.parents[2]) and path.is_file() and not path.is_symlink()
            body = path.read_bytes()
            assert rawpin(body) == {k: ref[k] for k in ('bytes', 'sha256')}
            name = path.relative_to(ROOT.parents[2]).as_posix()
            assert name not in {row['name'] for row in entries}
            archive.writestr(name, body)
            entries.append(dict(name=name, **rawpin(body)))
        archive.writestr('milestone-catalog.json', catpath.read_bytes())
        entries.append(dict(name='milestone-catalog.json', **rawpin(catpath.read_bytes())))
    with zipfile.ZipFile(output / NAMES[3]) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [row['name'] for row in entries]
        for row in entries:
            assert rawpin(archive.read(row['name'])) == {k: row[k] for k in ('bytes', 'sha256')}
    data = {k: v for k, v in cat.items() if k != 'archive_files'}
    data.update(schema='Root-lossless-qualification-publication-data-v1', members=entries,
                archive=rawpin((output / NAMES[3]).read_bytes()), archive_member_count=len(entries))
    emit(output / NAMES[2], jsonbody(data))
    old = (OLD / NAMES[1]).read_text()
    assert rawpin(old.encode())['sha256'] == '0729741ed9d98bc8dae95ac36fa87009c4643d0b3c699189c0415d83fad942a6'
    style = old.split('<style>', 1)[1].split('</style>', 1)[0]
    mathhead = old.split('<script>', 1)[1].split('</style>', 1)[0].split('<style>', 1)[0]
    page = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Parallel proof-search research: two bounded negative experiments</title><script>''' + mathhead + '<style>' + style + '''
.stop{background:#fff0eb;border-color:#d9b4a7}.stop b{color:#974526}.path{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.path article{border:1px solid var(--rule);padding:18px;border-radius:9px;background:#f1f5f2}.path strong{display:block;color:var(--purple);font-size:20px}summary{cursor:pointer;color:var(--teal)}@media(max-width:760px){.path{grid-template-columns:1fr}} 
</style></head><body><main>
<p class="eyebrow">GCTS + RL research · 23 October 2026 UTC</p>
<h1>Execution found a test error, then a deadline</h1>
<p>Parallel implementation, independent controls and critical review produced two new bounded experiments. The first exposed a callback-count error in the test. After a narrow correction, the second reached final evidence readback and hit the original 160-second work limit. <strong>Neither whole qualification was admitted.</strong></p>
<p class="notice"><strong>The research remains active and incomplete.</strong> There is no new theorem, reusable learned inventory or measured GCTS/RL advantage. The evidence transport still needs a successful whole run. <a href="point-proof-search-v1.html#lossless-qualification-current">Main research notebook</a>.</p>
<section class="panel"><h2>Where the second experiment stopped</h2><div class="pipe" role="img" aria-label="Control stages and packing completed; final canonical readback reached the work deadline; whole qualification was withheld">
<div class="step"><b>Codec controls</b>One complete control-bank stage returned normally.</div>
<div class="step"><b>Original obligations</b>All 15 original control stages and their 15 packing stages have completed labels.</div>
<div class="step stop"><b>Final readback</b>Started at 142.80 seconds. The Root work-deadline check interrupted the canonical stream.</div>
<div class="step stop"><b>Whole qualification</b>Withheld. All seven positive fields are null; both evidence pools are absent.</div>
</div><p class="caption">These are saved diagnostic stage labels, not qualified subsets. No codec-control prefix, original-obligation prefix or resource fit is admitted. The output-size decision was never reached.</p></section>
<section class="panel"><h2>Two experiments, separately preserved</h2><table><thead><tr><th>Case</th><th>Saved observer time</th><th>Terminating event</th><th>Whole disposition</th></tr></thead><tbody>
<tr><td>First lossless case · bank Source1</td><td>1.747761 s</td><td>The independent bank expected one callback in an interval containing two of its own callbacks. Original controls were not reached.</td><td>Consumed, wholly negative.</td></tr>
<tr><td>Second lossless case · bank Source2</td><td>160.634785 s</td><td>Absolute work deadline during mandatory final canonical readback, after all control and packing stages.</td><td>Consumed, wholly negative.</td></tr>
</tbody></table><p class="caption">The cases stop at different stages; these times are not a speed comparison. Saved worker, observer and custody clocks remain distinct in the downloadable data. Whole qualified memory remains null in both cases.</p></section>
<section class="panel"><h2>Why the first test expectation was wrong</h2><div class="path" role="img" aria-label="Static callback accounting: one harness pre-call check, zero permitted closed-reader callbacks, one harness error-path validation check">
<article><strong>Before the call</strong>The test makes one outer check.</article>
<article><strong>Closed reader</strong>The contract permits no callback from this endpoint.</article>
<article><strong>After refusal</strong>The test makes one check while validating the singleton error path.</article>
</div><p>The expected combined counter increment is \\(1+0+1=2\\). The correction changes that expectation and its comment. A callback from the closed reader would still fail the test. Both implementation and independent-test authors derived this accounting separately from the source; critical review confirmed it.</p><p class="caption">The failed run did not save the local before/after counter values. Two is the static expected count, not a reconstructed observation. The original negative case was preserved; the corrected source was used in a separately reviewed new case.</p></section>
<section class="panel"><h2>What parallel work contributed</h2><div class="grid">
<article class="card"><h3>Implementation</h3><p>Integrated the transport while retaining every original control call, raw validation and final-use boundary. The second caller changes only source binding and study identity.</p></article>
<article class="card"><h3>Independent controls</h3><p>Kept expectations separate from the codec implementation. Examining the failed test exposed its own accounting defect; the correction retains the zero-callback rule.</p></article>
<article class="card"><h3>Critical review</h3><p>Checked the source changes, exact run inputs and complete negative records. Source approval did not substitute for execution or admit a partially completed run.</p></article>
</div><p>Root integrated the work and ran each measured job with the other task agents and tools idle. Parallel work helped find and isolate mistakes. This is engineering evidence; it does not establish a mathematical or proof-search advantage.</p></section>
<section class="panel"><h2>What stays fixed</h2><p>The original 221 obligations, 36 original module roles and 15 original wrappers are unchanged. Eight synthetic transport groups are separate, giving 229 prospective groups across 17 populations and 38 module roles. These are infrastructure checks, not 229 theorem targets.</p><p>The work, memory, output and custody limits were retained. All complete observations are required; failed stages cannot supply a usable inventory or a qualified prefix. The second run saves 241,510,879 Root callbacks and a check-origin fault timestamp, but no complete positive envelope or rejected-output length.</p></section>
<section class="panel"><h2>Return to the scientific question</h2><p>The next engineering decision should be the smallest change that can complete the qualification bridge. Bounded token reuse and batching are candidates for source analysis; no optimization or alternative representation has been executed. The existing format still requires complete readback and first-error preservation.</p><p>The useful research comparison remains mechanically acquired receptor families against an ordinary prover with the same primitive fallback and budgets. Fresh distinct checked donors must supply the inventory, followed by a structural holdout requiring real family use in a complete checked proof. Learned markings and RL remain separate later factors.</p><p>Arithmetic, symbolic Hilbert geometry and practical regional tiling remain goals. A fixed finite universal Wang tile palette is still unbuilt; current symbolic rows can have unbounded formula-valued markings.</p></section>
<section class="panel" id="downloads"><h2>Inspect the evidence</h2><p><a href="point-proof-lossless-qualification-data-v1.json">Both run dispositions, clocks and archive manifest</a> · <a href="point-proof-lossless-qualification-evidence-v1.zip">Sources, independent controls, reviews and complete negative packets</a></p><details><summary>Earlier milestones</summary><p><a href="point-proof-codec-source-manifest-v1.json">Historical unexecuted-source milestone</a> · <a href="point-proof-codec-source-evidence-v1.zip">Historical source archive</a></p><p><a href="point-proof-output-qualification-data-v1.json">Earlier 221-obligation output-ceiling negative</a> · <a href="point-proof-output-qualification-evidence-v1.zip">Its unchanged evidence archive</a></p></details><p class="caption">All archived members were freshly read and hash-checked during packaging. Old negatives remain negative. No scientific module was imported, decoded or rerun for publication.</p></section>
<footer>Two new scientific actuals; no new whole qualification or research proof. Progress here is a corrected independent test and a precisely located whole-run deadline, with complete evidence retained.</footer>
</main></body></html>'''
    emit(output / NAMES[1], page.encode())
    main_report = (OLD / NAMES[0]).read_text()
    assert rawpin(main_report.encode())['sha256'] == 'ff195bf4b4ef12deeeddbf7f52b950f56b2a06cf5e5ea792741f833e3c6b0c3c'
    notice = '<p class="notice" id="lossless-qualification-notice"><strong>Current execution evidence · 23 October 2026 UTC.</strong> Two distinct lossless-qualification cases are wholly negative: first a test-accounting error, then the original work deadline during final readback after a narrow correction. No whole qualification, new theorem or GCTS/RL benefit is admitted. Earlier status labels below are historical. <a href="point-proof-parallel-progress-v1.html">Current visual report and evidence</a>.</p>'
    anchor = '<p class="notice" id="codec-source-current">'
    assert main_report.count(anchor) == 1
    main_report = main_report.replace(anchor, notice + anchor, 1)
    section = '<section class="panel" id="lossless-qualification-current"><h2>Lossless qualification: two complete negative records</h2><p>The first distinct case stopped at an independent test accounting error. Its narrow correction preserves the required zero callbacks from a closed reader. The second case returned from all control and packing stages, then hit the 160-second work deadline during final canonical readback. All seven positive fields are null and both evidence pools are withheld; no prefix is admitted.</p><p>Both complete records, frozen sources and independent reviews are available. No output-fit, new theorem, learned inventory or GCTS/RL advantage follows. The next step remains the minimum qualification bridge, then fresh donors and a matched receptor-family proof-search comparison.</p><p><a href="point-proof-parallel-progress-v1.html">Visual report</a> · <a href="point-proof-lossless-qualification-data-v1.json">Data and manifest</a> · <a href="point-proof-lossless-qualification-evidence-v1.zip">Complete evidence</a></p></section>'
    anchor2 = '<section class="panel" id="signed-qualification">'
    assert main_report.count(anchor2) == 1
    main_report = main_report.replace(anchor2, section + anchor2, 1)
    assert main_report.replace(notice, '', 1).replace(section, '', 1) == (OLD / NAMES[0]).read_text()
    emit(output / NAMES[0], main_report.encode())
    files = []
    for name in NAMES:
        body = (output / name).read_bytes()
        emit(staging / name, body)
        assert (staging / name).read_bytes() == body
        files.append(dict(path=PREFIX + name, publisher_source=str(staging / name), **rawpin(body),
                          git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()))
    emit(output / 'P2-staging.json', jsonbody(dict(schema='Root-lossless-qualification-publication-staging-v1',
        catalog=dict(path=str(catpath), **rawpin(catpath.read_bytes())), files=files,
        archive_members_verified=len(entries), scientific_execution=False, published=False)))
    print(json.dumps(dict(files=files, archive_members=len(entries), staging=str(output / 'P2-staging.json'))))


if __name__ == '__main__':
    main()
