"""Text/AST-only derivation of cold/once Sources; never imports/evaluates them."""
from pathlib import Path
import ast,hashlib,json
P=Path(__file__).resolve().parent
OLD=Path('/private/tmp/gcts-first-order-suite-intake-source-20261018')
REG=Path('/private/tmp/gcts-inventory-batching-ROOT-source-20261018/semantic_inventory_oracle_v2.py')
DRIVER=REG.with_name('inventory_certification_receiver_driver_v2.py')
CLOSURE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/first-order-suite-progress-20261018/runtime-closure-v1.json')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def replace(s,a,b,n=1):
 if s.count(a)!=n:raise ValueError(('replacement count',a,s.count(a),n))
 return s.replace(a,b)
def save(name,s):
 ast.parse(s);compile(s,name,'exec')
 p=P/name
 with p.open('x') as f:f.write(s)
 return pin(p)
def main():
 s=(OLD/'frozen_fol_suite_cold_v1.py').read_text()
 s=replace(s,"VERSION = 'frozen-fol-suite-intake-cold-v1'","VERSION = 'inventory-certification-intake-cold-v1'")
 s=s.replace('ROOT-and-support-ordering-worker-plan-v1','ROOT-inventory-certification-worker-plan-v1').replace('semantic-family-receiver-source-epoch-v3-and-support-ordering','semantic-family-receiver-source-epoch-v4-inventory-certification').replace('and-support-ordering-worker-receipt-v1','inventory-certification-worker-receipt-v1')
 start=s.index('PARENT_RUNTIME_CLOSURE = ');end=s.index('\nCOMPACT_MODEL_SOURCE',start)
 s=s[:start]+'PARENT_RUNTIME_CLOSURE = '+repr(pin(CLOSURE))+s[end:]
 start=s.index('RECEIVER_DRIVER_SOURCE = ');end=s.index('\nORDERING_COMPONENT_SOURCES',start)
 s=s[:start]+'RECEIVER_DRIVER_SOURCE = '+repr(pin(DRIVER))+"\nREGISTRY_SOURCE = "+repr(pin(REG))+s[end:]
 s=replace(s,"'integration_declaration','model_storage','search_ordering'}","'integration_declaration','model_storage','search_ordering','inventory_certification_mode'}")
 s=replace(s,"    need(plan['result_reader']=='interned','fixed complete interned result reader')","    need(plan['inventory_certification_mode'] in ('bulk','dependency_closures'), 'explicit inventory certification mode')\n    need(plan['search_ordering']=='and_support','fixed shared support ordering in certification comparison')\n    need(plan['result_reader']=='interned','fixed complete interned result reader')")
 s=replace(s,"marker['search_ordering']==plan['search_ordering'] and","marker['search_ordering']==plan['search_ordering'] and\n         marker['inventory_certification_mode']==plan['inventory_certification_mode'] and")
 s=s.replace('ROOT-and-support-ordering-experiment-declaration-v1','ROOT-inventory-certification-experiment-declaration-v1')
 s=replace(s,"('mode','search_ordering','result_reader','receiver_id','actual_directory','model_storage')","('mode','search_ordering','inventory_certification_mode','result_reader','receiver_id','actual_directory','model_storage')")
 s=replace(s,"{(r['mode'],r['search_ordering']) for r in schedule}==\n                 {(m,o) for m in ('fixed','symbolic') for o in ('legacy','and_support')} and\n             all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and\n                 r['result_reader']=='interned' for r in schedule)","{(r['mode'],r['inventory_certification_mode']) for r in schedule}==\n                 {(m,c) for m in ('fixed','symbolic') for c in ('bulk','dependency_closures')} and\n             all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and\n                 r['result_reader']=='interned' and r['search_ordering']=='and_support' for r in schedule)")
 s=s.replace('four unique complete method-by-ordering subjects','four unique complete method-by-certification subjects')
 s=s.replace('ROOT-and-support-ordering-raw-runtime-closure-v1','ROOT-inventory-certification-raw-runtime-closure-v1')
 a="        expected_project=dict(parent_closure['project_sources'])\n        del expected_project['semantic_inventory_search']\n        expected_project['semantic_inventory_search_v2']=ORDERING_COMPONENT_SOURCES['family_search']\n        del expected_project['quantified_symbolic_control_v1']\n        expected_project['quantified_symbolic_control_v2']=ORDERING_COMPONENT_SOURCES['symbolic_control']\n        expected_project['receptor_support_ordering_v1']=ORDERING_COMPONENT_SOURCES['support_ordering']"
 b="        expected_project=dict(parent_closure['project_sources'])\n        expected_project['semantic_inventory_oracle']=REGISTRY_SOURCE"
 s=replace(s,a,b)
 s=replace(s,"'new full closure with explicit unchanged parent lineage'","'new full closure with explicit previous-suite lineage'")
 s=replace(s,"epoch=dict(schema=EPOCH_SCHEMA,model_storage=plan['model_storage'],search_ordering=plan['search_ordering'],","epoch=dict(schema=EPOCH_SCHEMA,model_storage=plan['model_storage'],search_ordering=plan['search_ordering'],\n                   inventory_certification_mode=plan['inventory_certification_mode'],")
 s=replace(s,"receiver_spec=receiver_selection['spec'],mode=plan['mode'],search_ordering=plan['search_ordering'],","receiver_spec=receiver_selection['spec'],mode=plan['mode'],search_ordering=plan['search_ordering'],\n            inventory_certification_mode=plan['inventory_certification_mode'],")
 s=replace(s,"result_data['source_epoch']['search_ordering']==plan['search_ordering'] and","result_data['source_epoch']['search_ordering']==plan['search_ordering'] and\n             result_data['inventory_certification_mode']==plan['inventory_certification_mode'] and\n             result_data['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode'] and")
 s=replace(s,"header=dict(schema=WORKER_SCHEMA,invocation_id=plan['invocation_id'],mode=plan['mode'],search_ordering=plan['search_ordering'],","header=dict(schema=WORKER_SCHEMA,invocation_id=plan['invocation_id'],mode=plan['mode'],search_ordering=plan['search_ordering'],\n            inventory_certification_mode=plan['inventory_certification_mode'],")
 cold=save('inventory_certification_cold_v1.py',s)
 s=(OLD/'frozen_fol_suite_once_runner_v1.py').read_text()
 for a,b in [('frozen-fol-suite-intake-external-once-runner-v1','inventory-certification-external-once-runner-v1'),('ROOT-and-support-ordering-once-plan-v1','ROOT-inventory-certification-once-plan-v1'),('ROOT-and-support-ordering-once-authorization-v1','ROOT-inventory-certification-once-authorization-v1'),('and-support-ordering-worker-receipt-v1','inventory-certification-worker-receipt-v1'),('and-support-ordering-external-once-receipt-v1','inventory-certification-external-once-receipt-v1'),('ROOT-and-support-ordering-worker-plan-v1','ROOT-inventory-certification-worker-plan-v1'),('ROOT-and-support-ordering-raw-runtime-closure-v1','ROOT-inventory-certification-raw-runtime-closure-v1'),('ROOT-and-support-ordering-experiment-declaration-v1','ROOT-inventory-certification-experiment-declaration-v1')]:s=s.replace(a,b)
 s=replace(s,"ORDERINGS = ('legacy','and_support')","ORDERINGS = ('and_support',)\nCERTIFICATIONS = ('bulk','dependency_closures')")
 start=s.index('COLD_PIN = ');end=s.index('\n\n\nclass OnceRunnerError',start)
 reviews={
  'ordering_Source':('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
  'registry_Source':('inventory-closure-registry-typed-Source-review-v1','source_review_passed','/root/conventional_library'),
  'composition_Source':('inventory-certification-driver-cold-typed-Source-review-v1','source_review_passed','/root/conventional_library'),
  'once_Source':('inventory-certification-once-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
  'prospective_plans':('inventory-certification-prospective-plan-review-v1','prospective_review_passed','/root/conventional_library')}
 s=s[:start]+'COLD_PIN = '+repr(cold)+'\nREVIEW_ROLES = '+repr(reviews)+s[end:]
 s=replace(s,"('invocation_id','mode','search_ordering','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure')","('invocation_id','mode','search_ordering','inventory_certification_mode','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure')")
 s=replace(s,"{(r['mode'],r['search_ordering']) for r in schedule}==\n             {(m,o) for m in KINDS for o in ORDERINGS} and\n         all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and\n             r['result_reader']=='interned' for r in schedule)","{(r['mode'],r['inventory_certification_mode']) for r in schedule}==\n             {(m,c) for m in KINDS for c in CERTIFICATIONS} and\n         all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and\n             r['result_reader']=='interned' and r['search_ordering']=='and_support' for r in schedule)")
 s=replace(s,"('mode','search_ordering','result_reader','receiver_id','actual_directory','model_storage')","('mode','search_ordering','inventory_certification_mode','result_reader','receiver_id','actual_directory','model_storage')")
 s=replace(s,"'compile_queries':512}.items()","'compile_queries':512,'inventory_registration_aggregate_micro_steps':5000000000}.items()")
 s=replace(s,"'exact four current review roles'","'exact five current scoped review roles'")
 s=replace(s,"'composition_Source':[plan['cold'],worker['components']['receiver_driver']],","'registry_Source':[worker['project_sources']['semantic_inventory_oracle']],\n             'composition_Source':[plan['cold'],worker['components']['receiver_driver']],")
 s=replace(s,"fields={'schema','invocation_id','mode','search_ordering','model_storage'","fields={'schema','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage'")
 s=replace(s,"need(plan['mode'] in KINDS and type(plan['search_ordering'])is str","need(plan['inventory_certification_mode'] in CERTIFICATIONS and\n         plan['mode'] in KINDS and type(plan['search_ordering'])is str")
 s=replace(s,"'mode':plan['mode'],'search_ordering':plan['search_ordering'],'model_storage':plan['model_storage']","'mode':plan['mode'],'search_ordering':plan['search_ordering'],'inventory_certification_mode':plan['inventory_certification_mode'],'model_storage':plan['model_storage']")
 s=replace(s,"('invocation_id','mode','search_ordering','model_storage','receiver_id','integration_declaration')","('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','receiver_id','integration_declaration')")
 s=replace(s,"result['search_ordering']==plan['search_ordering'] and result['source_epoch']['search_ordering']==plan['search_ordering']","result['search_ordering']==plan['search_ordering'] and result['source_epoch']['search_ordering']==plan['search_ordering'] and\n             result['inventory_certification_mode']==plan['inventory_certification_mode'] and\n             result['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode']")
 s=replace(s,"'model_storage':plan['model_storage'],'result_reader':plan['result_reader'],'receiver_id':plan['receiver_id'],","'inventory_certification_mode':plan['inventory_certification_mode'],\n        'model_storage':plan['model_storage'],'result_reader':plan['result_reader'],'receiver_id':plan['receiver_id'],")
 runner=save('inventory_certification_once_runner_v1.py',s)
 s=(OLD/'observe_frozen_fol_suite_runner_v1.py').read_text()
 s=s.replace('frozen-fol-suite-intake-final-terminal-observer-v1','inventory-certification-final-terminal-observer-v1').replace('ROOT-and-support-ordering-once-plan-v1','ROOT-inventory-certification-once-plan-v1').replace('and-support-ordering-final-terminal-observation-v1','inventory-certification-final-terminal-observation-v1')
 s=replace(s,"7849621343d3dd150cecd3616eeed9667b82c6b68008601c4649aa9117d98df7",runner['sha256'])
 s=replace(s,"receipt['search_ordering']==plan['search_ordering'] and","receipt['search_ordering']==plan['search_ordering'] and\n            receipt['inventory_certification_mode']==plan['inventory_certification_mode'] and")
 observer=save('observe_inventory_certification_runner_v1.py',s)
 q=P/'intake-Source-handoff-v1.json'
 value=dict(schema='ROOT-inventory-certification-intake-Source-handoff-v1',author_identity='/root',source_only=True,scientific_calls=0,Native_calls=0,module_evaluations=0,actual_execution_authorized=False,
  cold=cold,runner=runner,observer=observer,registry=pin(REG),driver=pin(DRIVER),parent_closure=pin(CLOSURE),
  source_contract=pin(REG.with_name('Source-contract-v1.json')),
  parent_sources={p.name:pin(p) for p in [OLD/'frozen_fol_suite_cold_v1.py',OLD/'frozen_fol_suite_once_runner_v1.py',OLD/'observe_frozen_fol_suite_runner_v1.py']},
  scope='New explicit certification factor, unchanged full profile and exact original assertion capsule,24 aliases; five scoped reviews required. Raw derivation/syntax only, no runtime qualification.')
 with q.open('x')as f:f.write(json.dumps(value,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(handoff=pin(q),cold=cold,runner=runner,observer=observer),indent=2))
if __name__=='__main__':main()
