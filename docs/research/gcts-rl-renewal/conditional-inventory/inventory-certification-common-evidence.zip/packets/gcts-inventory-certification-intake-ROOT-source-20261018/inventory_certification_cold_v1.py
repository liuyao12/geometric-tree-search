"""Root cold adapter for the declared semantic-family receiver.

This module is authored and compiled without evaluation. Only Root's separately
granted, exclusive external runner may invoke it. All project imports, native
table preparation, checking, search and result work occur inside that window.
"""
import time
_NOW_NS = time.monotonic_ns
import builtins
import ctypes
import gzip
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import platform
import stat
import sys
import types

VERSION = 'inventory-certification-intake-cold-v1'
PLAN_SCHEMA = 'ROOT-inventory-certification-worker-plan-v1'
EPOCH_SCHEMA = 'semantic-family-receiver-source-epoch-v4-inventory-certification'
WORKER_SCHEMA = 'inventory-certification-worker-receipt-v1'
PROGRAM_SHA = '877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673'
MICRO_SHA = '2f9e430b0b7034ed615d81c3e9b3978dc47ba4136686227a9b86df5779b203ac'
ROLE_MODULES = {'base_compiler': 'quantified_receptors_v1', 'family_miner': 'semantic_lemma_inventory', 'family_model': 'quantified_family_points_v2', 'family_search': 'semantic_inventory_search_v2', 'family_registry': 'semantic_inventory_oracle', 'point_smt': 'semantic_point_smt', 'symbolic_control': 'quantified_symbolic_control_v2', 'support_ordering': 'receptor_support_ordering_v1'}

PARENT_RUNTIME_CLOSURE = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/first-order-suite-progress-20261018/runtime-closure-v1.json', 'sha256': 'e3ed95935216bdbae1cfea900050718a7b21f81a11dc9d50a608585101e8d1cf', 'bytes': 73258}
COMPACT_MODEL_SOURCE = {'path': '/private/tmp/gcts-compact-point-representation-source-20261018/interned_quantified_family_points_v1.py', 'sha256': 'fb37663b4c0c3de4e9f3c28564678af833857f7ebe761cd83275d62f123b9a8e', 'bytes': 4311}
RECEIVER_DRIVER_SOURCE = {'path': '/private/tmp/gcts-inventory-batching-ROOT-source-20261018/inventory_certification_receiver_driver_v2.py', 'sha256': '2ba4a2de010da425e0f74f2c09b553d2051d7fc1a79fbe438845ec0a53c34466', 'bytes': 62044}
REGISTRY_SOURCE = {'path': '/private/tmp/gcts-inventory-batching-ROOT-source-20261018/semantic_inventory_oracle_v2.py', 'sha256': '2010ca7cb6f3da0734efe03e5be0f7e166b7e4d5939078dea0451361cf5890f3', 'bytes': 12626}
ORDERING_COMPONENT_SOURCES = {'family_search': {'bytes': 15936, 'path': '/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py', 'sha256': '35443c958f2115efa18cc923fb4a4f1070e6e03ccf1d1adf2bb56ce1f7bab28b'}, 'support_ordering': {'bytes': 16868, 'path': '/private/tmp/gcts-and-support-ordering-source-20261018/receptor_support_ordering_v1.py', 'sha256': '18cf90ebd75d746db3eb251eaffa92cd6a25432b70f34653b57f3d58ef5d8adc'}, 'symbolic_control': {'bytes': 26238, 'path': '/private/tmp/gcts-and-support-ordering-source-20261018/quantified_symbolic_control_v2.py', 'sha256': '740319d243cc2fd2eefe1d7ef1611d8bcfe6f0ff70a2ce2ed72771e78f64a391'}}

MODEL_STORAGE_MODULES = {
    'ordinary': 'quantified_family_points_v2',
    'literal_interned': 'interned_quantified_family_points_v1',
}


class ColdError(ValueError):
    pass


def need(ok, message):
    if not ok:
        raise ColdError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def descriptor(path, raw=None):
    p=Path(path).resolve()
    if raw is None:
        raw=p.read_bytes()
    return dict(path=str(p), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def raw_file(pin, cap=134217728):
    need(type(pin) is dict and set(pin)=={'path','sha256','bytes'}, 'exact raw descriptor')
    p=Path(pin['path'])
    need(p.is_absolute() and p==p.resolve(), 'canonical absolute raw path')
    fd=os.open(str(p),os.O_RDONLY|os.O_NOFOLLOW)
    try:
        info=os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_size<=cap, 'bounded regular raw file')
        chunks=[];total=0
        while True:
            b=os.read(fd,65536)
            if not b:
                break
            total+=len(b);need(total<=cap,'raw file growth beyond cap');chunks.append(b)
        raw=b''.join(chunks)
        need(total==info.st_size and descriptor(p,raw)==pin,'whole raw size/hash/EOF')
        return raw
    finally:
        os.close(fd)


def write_new(path, value):
    raw=canonical(value)+b'\n'
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        at=0
        while at<len(raw):
            n=os.write(fd,raw[at:at+65536]);need(n>0,'whole new metadata output');at+=n
        os.fsync(fd)
    finally:
        os.close(fd)
    return descriptor(path,raw)


def seal_callables(modules, classes=()):
    """Retain identities and code objects; mutable search data is not frozen."""
    bindings=[];codes=[];seen_classes=set()
    def function(f):
        if isinstance(f,types.FunctionType):
            codes.append((f,f.__code__,f.__globals__,f.__defaults__,f.__kwdefaults__))
    def klass(c):
        if c in seen_classes:
            return
        seen_classes.add(c)
        for name,value in list(vars(c).items()):
            if isinstance(value,(staticmethod,classmethod)):
                bindings.append((c,name,value));function(value.__func__)
            elif isinstance(value,types.FunctionType):
                bindings.append((c,name,value));function(value)
            elif isinstance(value,property):
                bindings.append((c,name,value))
                for f in (value.fget,value.fset,value.fdel):
                    function(f)
    for module in modules:
        for name,value in list(vars(module).items()):
            if isinstance(value,(types.FunctionType,types.ModuleType,type,types.BuiltinFunctionType)):
                bindings.append((module,name,value));function(value)
                if isinstance(value,type) and value.__module__==module.__name__:
                    klass(value)
    for c in classes:
        klass(c)
    def guard():
        for owner,name,value in bindings:
            need(vars(owner).get(name) is value,'sealed callable/module binding: '+name)
        for f,code,namespace,defaults,kwdefaults in codes:
            need(f.__code__ is code and f.__globals__ is namespace and
                 f.__defaults__ is defaults and f.__kwdefaults__ is kwdefaults,
                 'sealed function code/globals/defaults')
    return guard


def verify_raw_region(data, work_ns):
    """Whole literal t/m union and row decoding, without engine/solver calls."""
    def check():
        need(_NOW_NS()<work_ns,'whole-region verification inside original work')
    def point(p):
        need(type(p) in (list,tuple) and len(p)==2 and all(type(v) is int for v in p),'exact integer point')
        return tuple(p)
    check();model=data['outputs']['model'];initial=data['initial_state']
    required={point(p) for p in model['roots']}
    need(len(required)==len(model['roots']) and required=={point(p) for p in initial['allowed_points']},'whole required target')
    totals={point(p):v for p,v in initial['totals']};marks={point(p):v for p,v in initial['marks']}
    need(len(totals)==len(initial['totals']) and len(marks)==len(initial['marks']),'unambiguous initial assignments')
    need(set(totals)<=required and all(type(v) is int and 0<=v<=12 for v in totals.values()),'initial exact unit capacity')
    candidates={tuple(p['key']):p for p in model['placements']}
    need(len(candidates)==len(model['placements']),'unique complete placement identity')
    selected=[tuple(k) for k in data['outputs']['search']['placements']]
    need(len(set(selected))==len(selected),'no duplicate selected placement')
    proof=data['outputs']['search']['proof'];slots={}
    for key in selected:
        check();need(key in candidates,'selected original candidate')
        c=candidates[key]
        need(len(key)==4 and all(type(v) is int for v in key) and 0<=key[0]<len(proof) and 0<=key[1]<2+model['arity'],'positional proof tile')
        need(c['occupancy']==[[[4*key[0],key[1]],12]],'declared single-root unit tile')
        need(key[:2] not in slots,'one tile for each row role');slots[key[:2]]=c
        for p,v in c['occupancy']:
            p=point(p);need(p in required and type(v) is int and v>0,'exact required t-support')
            totals[p]=totals.get(p,0)+v;need(totals[p]<=12,'whole-region capacity')
        for p,v in c['marks']:
            p=point(p);need(type(v) is int,'declared exact integer m-value')
            need(p not in marks or marks[p]==v,'whole-region assigned m-values agree')
            marks[p]=v
    need(set(totals)==required and all(v==12 for v in totals.values()),'every required point reaches exact capacity')
    need(len(slots)==len(proof)*(2+model['arity']),'complete row-role rectangle')
    definitions={d['name']:d['definition'] for d in data['outputs']['register']['definitions']}
    for j,line in enumerate(proof):
        check();row=[slots[j,r] for r in range(2+model['arity'])]
        command=dict(row[0]['command']);need(command==row[1]['command'],'C/G literal command agreement')
        if command['rule']=='block':
            n=len(definitions[command['name']]['premises'])
            ports=[row[2+r]['source'] for r in range(n)]
            need(all(type(i) is int and 0<=i<j for i in ports),'strict-earlier ordered receptor inputs')
            command['inputs']=ports
        need(command==line,'whole native proof is the decoded selected row')
    need(data['outputs']['final_request']['proof']==proof,'selected proof/final request literal join')
    check()
    return dict(status='VERIFIED_WHOLE_FINITE_POINT_REGION',selected_placements=len(selected),
        required_points=len(required),assigned_mark_points=len(marks),decoded_rows=len(proof),
        union_sha256=hashlib.sha256(canonical(dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected)))).hexdigest(),
        completed_ns=_NOW_NS(),scope='Separate raw whole-target occupancy, initial/selected marking agreement and literal C/G/input row decoding; no engine, solver or logical kernel call.')


def verify_literal_result(data, raw, checkpoint):
    """Full streaming canonical inverse on the pinned writer domain."""
    checkpoint()
    body = raw[:-1] if raw.endswith(b'\n') else raw
    encoder = json.JSONEncoder(sort_keys=True, separators=(',', ':'),
                               ensure_ascii=False, allow_nan=False)
    offset = 0; chunks = 0
    for text in encoder.iterencode(data):
        value = text.encode('utf8')
        need(raw[offset:offset+len(value)] == value, 'whole canonical literal byte comparison')
        offset += len(value); chunks += 1
        if chunks % 65536 == 0:
            checkpoint()
    need(offset == len(body), 'whole canonical writer EOF')
    checkpoint()
    return dict(literal_bytes_equal=True, body_bytes=offset,
                body_sha256=hashlib.sha256(body).hexdigest(), chunks=chunks)


def select_receiver(declaration, receiver_id):
    """Select exact ordinary assertion data, never a route or proof."""
    need(type(declaration) is dict and
         declaration.get('schema')=='ROOT-closed-quantified-benchmark-declaration-v1',
         'frozen structural cohort declaration')
    need(type(receiver_id) is str and bool(receiver_id), 'explicit nonempty receiver selector')
    receivers=declaration.get('receivers')
    need(type(receivers) is list and bool(receivers), 'complete nonempty receiver list')
    ids=[]
    for spec in receivers:
        need(type(spec) is dict and type(spec.get('id')) is str and bool(spec['id']),
             'ordinary receiver with exact ID')
        ids.append(spec['id'])
    need(len(ids)==len(set(ids)), 'unique receiver IDs in whole declaration')
    need(receiver_id in ids, 'selected receiver must occur exactly once')
    spec=receivers[ids.index(receiver_id)]
    need(type(spec.get('length')) is int and spec['length']==12 and
         type(spec.get('instantiation_rounds')) is int and spec['instantiation_rounds']==2,
         'unchanged twelve-row/two-round receiver profile')
    return dict(schema='closed-quantified-receiver-selection-v1',
                receiver_id=receiver_id,spec=json.loads(canonical(spec)))


def main(argv):
    need(len(argv)==4,'worker_plan,began_ns,work_deadline_ns,overall_deadline_ns')
    plan_path=Path(argv[0]).resolve()
    began,work_ns,overall_ns=[int(x) for x in argv[1:]]
    need(work_ns==began+180000000000 and overall_ns==began+210000000000,
         'one absolute180/210 clock from external entry')
    need(began<=_NOW_NS()<work_ns,'fresh original cold work window')
    need(sys.platform=='darwin' and platform.machine()=='arm64' and sys.byteorder=='little',
         'declared Darwin arm64/little-endian runtime')
    need(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
         'isolated -I -S -B Python')
    need(os.getpid()==os.getpgrp(),'worker must lead the owned group')
    plan_raw=plan_path.read_bytes();need(len(plan_raw)<=16777216,'finite worker plan')
    plan=json.loads(plan_raw)
    fields={'schema','invocation_id','mode','actual_directory','cold','python',
            'project_sources','components','native_inputs','policy','declaration',
            'runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage','search_ordering','inventory_certification_mode'}
    need(type(plan) is dict and set(plan)==fields and plan['schema']==PLAN_SCHEMA,
         'exact worker plan')
    need(plan['mode'] in ('fixed','symbolic'),'declared mechanism-control mode')
    need(type(plan['search_ordering']) is str and plan['search_ordering'] in ('legacy','and_support'),
         'mandatory explicit search ordering')
    need(plan['inventory_certification_mode'] in ('bulk','dependency_closures'), 'explicit inventory certification mode')
    need(plan['search_ordering']=='and_support','fixed shared support ordering in certification comparison')
    need(plan['result_reader']=='interned','fixed complete interned result reader')
    need(type(plan['model_storage']) is str and plan['model_storage']=='literal_interned',
         'explicit ordinary/literal_interned Model storage; no fallback')
    actual=Path(plan['actual_directory'])
    need(actual.is_absolute() and actual==actual.resolve() and actual==Path.cwd(),
         'exact existing private actual directory')
    marker=json.loads((actual/'CONSUMED.json').read_bytes())
    need(marker['invocation_id']==plan['invocation_id'] and marker['mode']==plan['mode'] and
         marker['search_ordering']==plan['search_ordering'] and
         marker['inventory_certification_mode']==plan['inventory_certification_mode'] and
         marker['began_ns']==began and marker['work_deadline_ns']==work_ns and
         marker['overall_deadline_ns']==overall_ns and marker['consumed_before_Popen'] is True,
         'exclusive external consumption and shared deadlines')
    need(Path(plan['cold']['path']).resolve()==Path(__file__).resolve(), 'exact cold entry')
    need(Path(sys.executable).resolve()==Path(plan['python']['path']), 'exact Python entry')

    stages=[];oracle_box=[];module_guards=[];source_pins=[];artifact_pins=[]
    z3_core=None;z3_native_library=None
    def overall_tick():
        need(_NOW_NS()<overall_ns,'original total closure deadline')
    def now():
        return _NOW_NS()/1000000000
    def stage(label, action):
        overall_tick();start=_NOW_NS();value=action();end=_NOW_NS()
        stages.append(dict(stage=label,started_ns=start,returned_ns=end))
        need(end<work_ns,'Root cold setup returned after original work deadline: '+label)
        return value
    def full_artifacts():
        for pin in artifact_pins:
            overall_tick();raw_file(pin)
    def source_guard():
        # This guard remains usable after the scientific deadline for cleanup.
        for pin in source_pins:
            raw_file(pin,16777216)
        for guard in module_guards:
            guard()
        if z3_core is not None:
            need(z3_native_library is not None and
                 Path(z3_native_library._name).resolve()==Path(plan['z3']['library']['path']) and
                 z3_core.Z3_mk_config.__defaults__[0].f is z3_native_library.Z3_mk_config,
                 'exact supported Z3 native-library origin')

    result_pin=None
    try:
        for pin in [plan['cold'],plan['python'],plan['policy'],plan['declaration'],plan['runtime_closure'],plan['integration_declaration']]:
            stage('intake:'+Path(pin['path']).name,lambda pin=pin:raw_file(pin))
        source_pins.append(plan['cold']);artifact_pins.extend([plan['python'],plan['policy'],
            plan['declaration'],plan['runtime_closure'],plan['integration_declaration']])
        need(hashlib.sha256(raw_file(plan['declaration'])).hexdigest()==
             '1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0',
             'exact prospectively declared receiver/profile')
        integration=json.loads(raw_file(plan['integration_declaration']))
        need(integration['schema']=='ROOT-inventory-certification-experiment-declaration-v1' and
             integration['parent_structural_declaration']==plan['declaration'] and
             integration['selected_receiver_id']==plan['receiver_id'], 'unchanged selected assertion/cohort')
        binding=next((r for r in integration['schedule'] if r['invocation_id']==plan['invocation_id']),None)
        need(binding is not None and all(binding[k]==plan[k] for k in
             ('mode','search_ordering','inventory_certification_mode','result_reader','receiver_id','actual_directory','model_storage')), 'complete declared method/ordering subject binding')
        schedule=integration['schedule']
        need(len(schedule)==4 and len({r['invocation_id'] for r in schedule})==4 and
             len({r['actual_directory'] for r in schedule})==4 and
             {(r['mode'],r['inventory_certification_mode']) for r in schedule}==
                 {(m,c) for m in ('fixed','symbolic') for c in ('bulk','dependency_closures')} and
             all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and
                 r['result_reader']=='interned' and r['search_ordering']=='and_support' for r in schedule),
             'four unique complete method-by-certification subjects with common assertion/storage/reader')
        declaration=json.loads(raw_file(plan['declaration']))
        receiver_selection=stage('select frozen receiver',lambda:select_receiver(declaration,plan['receiver_id']))
        parent_closure=stage('intake:parent runtime closure',
            lambda:json.loads(raw_file(PARENT_RUNTIME_CLOSURE)))
        artifact_pins.append(PARENT_RUNTIME_CLOSURE)
        closure=json.loads(raw_file(plan['runtime_closure']))
        need(closure['schema']=='ROOT-inventory-certification-raw-runtime-closure-v1' and
             closure['parent_closure']==PARENT_RUNTIME_CLOSURE,
             'new full closure with explicit previous-suite lineage')
        expected_project=dict(parent_closure['project_sources'])
        expected_project['semantic_inventory_oracle']=REGISTRY_SOURCE
        need(expected_project['interned_quantified_family_points_v1']==COMPACT_MODEL_SOURCE,
             'unchanged compact Model full Source')
        need(plan['project_sources']==closure['project_sources']==expected_project and
             all(closure[key]==parent_closure[key] for key in
                 ('Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime',
                  'stdlib_entry_references','authoring_python')) and
             plan['python']==closure['runtime']['Python_executable'],
             'literal complete fixed project/native/Z3/runtime maps')
        need(plan['components']==closure['additional_nonseed_components'] and
             plan['components']['receiver_driver']==RECEIVER_DRIVER_SOURCE and
             plan['components']['bounded_transport']==parent_closure['additional_nonseed_components']['bounded_transport'],
             'exact new driver and unchanged bounded transport pins')
        expected_z3=[{k:p[k] for k in ('path','sha256','bytes')} for p in closure['Z3']['files']]
        need(plan['z3']['files']==expected_z3 and plan['z3']['root']==closure['Z3']['package_root'],
             'complete41-file Z3 raw map and package root')
        need(plan['z3']['library']['path']==str(Path(plan['z3']['root'])/'z3/lib/libz3.dylib'),
             'fixed supported owned Z3 library')
        modules_dir=actual/'modules';modules_dir.mkdir(mode=0o700)
        need(set(plan['components'])=={'receiver_driver','bounded_transport'},'two exact components')
        names={**plan['project_sources'],
               'semantic_receiver_driver':plan['components']['receiver_driver'],
               'bounded_request_oracle':plan['components']['bounded_transport']}
        need(len(plan['project_sources'])==22 and len(names)==24 and
             closure['materialized_aliases']==names, 'complete same24 project/component aliases in all four arms')
        owned={}
        for name,pin in names.items():
            need(name.isidentifier() and name not in sys.modules,'fresh explicit project module')
            raw=stage('copy:'+name,lambda pin=pin:raw_file(pin,16777216))
            dest=modules_dir/(name+'.py');dest.write_bytes(raw)
            owned[name]=descriptor(dest,raw);source_pins.extend([pin,owned[name]])
        need(Path(plan['z3']['root']).is_absolute(),'owned Z3 package root')
        for pin in plan['z3']['files']:
            stage('Z3 intake:'+Path(pin['path']).name,lambda pin=pin:raw_file(pin))
            artifact_pins.append(pin)
        need(plan['z3']['library'] in plan['z3']['files'],'loaded Z3 library in complete package pins')
        builtins.Z3_LIB_DIRS=[str(Path(plan['z3']['library']['path']).parent)]
        sys.path[:0]=[str(modules_dir),plan['z3']['root']]
        loaded={name:stage('import:'+name,lambda name=name:importlib.import_module(name)) for name in names}
        for name,module in loaded.items():
            need(Path(module.__file__).resolve()==Path(owned[name]['path']),'exact project import origin')
        # The same pinned Z3 runtime is loaded and charged in every arm.
        # The pinned z3core Source deletes its temporary _lib global at EOF.
        # Capture the actual loader result during import, then restore stdlib.
        original_cdll=ctypes.CDLL;loaded_libraries=[]
        def observed_cdll(name,*args,**kwargs):
            library=original_cdll(name,*args,**kwargs)
            loaded_libraries.append(library)
            return library
        ctypes.CDLL=observed_cdll
        try:
            z3=stage('import:Z3',lambda:importlib.import_module('z3'))
        finally:
            ctypes.CDLL=original_cdll
        need(ctypes.CDLL is original_cdll and len(loaded_libraries)==1,
             'exact one observed Z3 native-library load and restored loader')
        z3_core=sys.modules['z3.z3core']
        z3_native_library=loaded_libraries[0]
        z3_modules=[]
        for name,module in list(sys.modules.items()):
            if name=='z3' or name.startswith('z3.'):
                file=Path(module.__file__).resolve()
                match=next((p for p in plan['z3']['files'] if Path(p['path'])==file),None)
                need(match is not None,'exact Z3 Python import origin');source_pins.append(match)
                z3_modules.append(module)
        need(Path(z3_native_library._name).resolve()==Path(plan['z3']['library']['path']) and
             z3_core.Z3_mk_config.__defaults__[0].f is z3_native_library.Z3_mk_config,
             'owned exact Z3 dynamic library')
        module_guards.append(seal_callables(list(loaded.values())+z3_modules+[sys.modules[__name__]]))
        source_guard()
        native=plan['native_inputs']
        need(set(native)=={'program_and_template','opaque_microcode_gzip','native_cpp'},'fixed native inputs')
        need(native['program_and_template']==closure['fixed_native_inputs']['program_and_template'] and
             native['opaque_microcode_gzip']==closure['fixed_native_inputs']['opaque_microcode_gzip'] and
             native['native_cpp']==closure['native_CPP']['binary'],'literal native raw input maps')
        for pin in native.values():
            stage('native intake:'+Path(pin['path']).name,lambda pin=pin:raw_file(pin))
            artifact_pins.append(pin)
        old=stage('decode native template',lambda:json.loads(raw_file(native['program_and_template'])))
        micro=stage('decode fixed microcode',lambda:json.loads(gzip.decompress(raw_file(native['opaque_microcode_gzip']))))
        need(hashlib.sha256(canonical(micro)).hexdigest()==MICRO_SHA and
             hashlib.sha256(canonical(old['program'])).hexdigest()==PROGRAM_SHA and
             old['program_sha256']==PROGRAM_SHA and micro['program_sha256']==PROGRAM_SHA and
             old['machine']['micro_sha256']==MICRO_SHA and len(micro['rows'])==old['machine']['micro_states'],
             'unchanged canonical microcode/program/row identities')
        native_dir=actual/'native';native_dir.mkdir(mode=0o700);code=native_dir/'code.bin'
        stage('encode fixed native table',lambda:loaded['tape_binary'].write_micro(micro,code))
        code_pin=descriptor(code);artifact_pins.append(code_pin)
        source_pins.append(native['native_cpp'])
        epoch=dict(schema=EPOCH_SCHEMA,model_storage=plan['model_storage'],search_ordering=plan['search_ordering'],
                   inventory_certification_mode=plan['inventory_certification_mode'],
                   sources=dict(project=owned,original=names,cold=plan['cold']),
                   native_inputs=dict(**native,code_bin=code_pin),
                   python=plan['python'],z3=plan['z3'],declaration=plan['declaration'],policy=plan['policy'],
                   receiver_selection=receiver_selection,
                   result_representation=dict(reader=plan['result_reader'],integration_declaration=plan['integration_declaration']),
                   custody='Exact raw project/component origins and captured callable identities; pinned Python/bundled stdlib and platform loader are trusted runtime. Z3 native origin/raw bytes gated separately. No whole OS formal validation claimed.')
        factory_module=loaded['bounded_request_oracle'];registry=loaded['semantic_inventory_oracle']
        def oracle_factory(*,work_deadline,tick,source_guard,now):
            need(work_deadline==work_ns/1000000000,'factory original work deadline')
            cls=factory_module.make_request_oracle_factory(request_oracle_module=registry,
                deadline=work_deadline,tick=tick,source_guard=source_guard,now=now)
            # Seal all dynamic methods before the constructor or later queries.
            module_guards.append(seal_callables([],classes=[cls]))
            oracle=cls(micro,old['cases'][0]['initial'],native['native_cpp']['path'],code,native_dir)
            oracle_box.append(oracle)
            return oracle
        roles={role:loaded[name] for role,name in ROLE_MODULES.items()}
        roles['family_model']=loaded[MODEL_STORAGE_MODULES[plan['model_storage']]]
        overall_tick();need(_NOW_NS()<work_ns,'receiver starts in original work window')
        receipt=loaded['semantic_receiver_driver'].run_receiver(receiver_spec=receiver_selection['spec'],mode=plan['mode'],search_ordering=plan['search_ordering'],
            inventory_certification_mode=plan['inventory_certification_mode'],
            policy_bytes=raw_file(plan['policy']),modules=roles,oracle_factory=oracle_factory,
            source_epoch=epoch,source_guard=source_guard,tick=overall_tick,now=now,
            work_deadline=work_ns/1000000000,closure_deadline=overall_ns/1000000000,
            closure_tick=overall_tick,output_path=actual/'result.json')
        returned=_NOW_NS();source_guard();full_artifacts();checked=_NOW_NS()
        need(receipt['receiver_id']==plan['receiver_id'] and receipt['search_ordering']==plan['search_ordering'],
             'returned exact receiver and ordering identity')
        need(len(oracle_box)==1,'one persistent native instance')
        transport=oracle_box[0].transport_receipt()
        need(transport['closed'] is True and transport['all_reaped'] is True and
             transport['native_exit_code']==0,'native exactly closed and reaped')
        result_pin={k:receipt['output'][k] for k in ('path','sha256','bytes')}
        result_raw=raw_file(result_pin)
        reading_started=_NOW_NS();positive=receipt['native_proof_accepted'] or receipt['family_hint_success']
        def reader_tick():
            overall_tick()
            if positive:
                need(_NOW_NS()<work_ns,'positive full result reading within original work')
        reader_tick();sharing=None
        if plan['result_reader']=='builtin':
            result_data=json.loads(result_raw)
        else:
            result_data,sharing=loaded['interned_result_reader_v2'].decode_result(result_raw,checkpoint=reader_tick)
        decoded_ns=_NOW_NS()
        literal=verify_literal_result(result_data,result_raw,reader_tick)
        reading_completed=_NOW_NS();source_guard()
        result_reading=dict(reader=plan['result_reader'],source=owned['interned_result_reader_v2'],
            started_ns=reading_started,decoded_ns=decoded_ns,completed_ns=reading_completed,
            decode_seconds=(decoded_ns-reading_started)/1e9,roundtrip=literal,sharing=sharing,
            scope='Complete result reading and literal reconstruction in original scientific worker with all old native/template/model lifetimes unchanged. Parent parser unchanged.')
        need(result_data['receiver_id']==plan['receiver_id'] and
             canonical(result_data['declaration'])==canonical(receiver_selection['spec']) and
             canonical(result_data['source_epoch']['receiver_selection'])==canonical(receiver_selection) and
             result_data['source_epoch']['schema']==EPOCH_SCHEMA and
             result_data['search_ordering']==plan['search_ordering'] and
             result_data['source_epoch']['search_ordering']==plan['search_ordering'] and
             result_data['inventory_certification_mode']==plan['inventory_certification_mode'] and
             result_data['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode'] and
             result_data['module_pins']['support_ordering']==owned[ROLE_MODULES['support_ordering']] and
             result_data['module_pins']['family_search' if plan['mode']=='fixed' else 'symbolic_control']==
                 owned[ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control']] and
             result_data['source_epoch']['model_storage']==plan['model_storage'] and
             result_data['module_pins']['family_model']==owned[MODEL_STORAGE_MODULES[plan['model_storage']]],
             'whole output/current receiver and selected Model storage preimages')
        region_check=(verify_raw_region(result_data,work_ns) if receipt['native_proof_accepted']
                      else dict(status='NOT_CHECKED_NO_NATIVE_PROOF'))
        source_guard()
        positive=receipt['native_proof_accepted'] or receipt['family_hint_success']
        if positive:
            need(checked<work_ns and _NOW_NS()<work_ns,'positive result and full Root checks within work')
        else:
            overall_tick()
        origins=[]
        for name,module in sorted(sys.modules.items()):
            file=getattr(module,'__file__',None)
            if file:
                origins.append(dict(module=name,path=str(Path(file).resolve())))
        header=dict(schema=WORKER_SCHEMA,invocation_id=plan['invocation_id'],mode=plan['mode'],search_ordering=plan['search_ordering'],
            inventory_certification_mode=plan['inventory_certification_mode'],
            receiver_id=plan['receiver_id'],receiver_input_qualified=receipt['receiver_input_qualified'],
            receiver_selection_sha256=hashlib.sha256(canonical(receiver_selection)).hexdigest(),
            status=receipt['status'],result=result_pin,
            work_completed=checked<work_ns and receipt['status']!='unknown_receiver_work_deadline',
            logical_proof_accepted=receipt['native_proof_accepted'],
            primary_family_hint_accepted=receipt['family_hint_success'],
            quantified_reasoning_success=receipt['quantified_reasoning_success'],native_transport=transport,
            worker_plan=descriptor(plan_path,plan_raw),cold=plan['cold'],python=plan['python'],
            began_ns=began,work_deadline_ns=work_ns,overall_deadline_ns=overall_ns,
            driver_returned_ns=returned,custody_checked_ns=checked,cold_stages=stages,
            source_epoch_sha256=hashlib.sha256(canonical(epoch)).hexdigest(),
            final_region_verification=region_check,result_reading=result_reading,
            integration_declaration=plan['integration_declaration'],
            model_storage=plan['model_storage'],
            selected_search_module=dict(role=('family_search' if plan['mode']=='fixed' else 'symbolic_control'),
                module=ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control'],
                original=ORDERING_COMPONENT_SOURCES['family_search' if plan['mode']=='fixed' else 'symbolic_control'],
                owned=owned[ROLE_MODULES['family_search' if plan['mode']=='fixed' else 'symbolic_control']]),
            support_ordering_module=dict(module=ROLE_MODULES['support_ordering'],
                original=ORDERING_COMPONENT_SOURCES['support_ordering'],owned=owned[ROLE_MODULES['support_ordering']]),
            selected_family_model=dict(module=MODEL_STORAGE_MODULES[plan['model_storage']],
                original=plan['project_sources'][MODEL_STORAGE_MODULES[plan['model_storage']]],
                owned=owned[MODEL_STORAGE_MODULES[plan['model_storage']]]),
            import_origins=origins,driver_output_receipt=receipt,
            scope='Root adapter headers are not resource or mathematical admission; outer exact terminal/resource gates remain required.')
        write_new(actual/'worker-receipt.json',header)
        overall_tick()
        if positive:
            need(_NOW_NS()<work_ns,'worker positive header serialization within work')
    except BaseException as error:
        transport=getattr(error,'native_transport_receipt',None)
        if transport is None:
            transport=getattr(error,'transport_receipt',None)
        cleanup_errors=[]
        for oracle in oracle_box:
            try:
                oracle.close();transport=oracle.transport_receipt()
            except BaseException as cleanup:
                cleanup_errors.append(dict(type=type(cleanup).__name__,message=str(cleanup)))
                transport=getattr(cleanup,'transport_receipt',transport)
        # Failure diagnostics cannot create an accepted partial proof result.
        write_new(actual/'worker-failure.json',dict(schema='ROOT-semantic-worker-failure-v1',
            error_type=type(error).__name__,message=str(error),cleanup_errors=cleanup_errors,
            native_transport=transport,result_already_published=result_pin,
            stage_intervals=stages,scientific_acceptance=False,logical_proof_accepted=False))
        raise


if __name__=='__main__':
    main(sys.argv[1:])
