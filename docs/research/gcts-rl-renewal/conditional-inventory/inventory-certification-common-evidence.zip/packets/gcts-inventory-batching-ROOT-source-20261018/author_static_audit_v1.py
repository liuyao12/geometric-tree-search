"""Raw AST/byte preservation audit only. Does not import scientific Sources."""
from pathlib import Path
import ast,hashlib,json
P=Path(__file__).resolve().parent
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def nodes(s):
 return {n.name:n for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def same(a,b):return ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
def main():
 checks=[]
 def need(ok,label):
  checks.append(dict(check=label,passed=bool(ok)))
  if not ok:raise ValueError(label)
 reg=P/'semantic_inventory_oracle_v2.py';old=P/'unchanged-parent-Source.py'
 r=reg.read_text();o=old.read_text();rn=nodes(r);on=nodes(o)
 need(r[:r.index('INVENTORY_CERTIFICATION_VERSION')] == o[:o.index('def check_inventory(')]+'\n','exact old imports/RequestOracle prefix')
 parent=ast.parse(ast.unparse(on['check_inventory'])).body[0]
 parent.name='_check_inventory_bulk_parent'
 need(same(parent,rn['_check_inventory_bulk_parent']),'bulk checker complete raw AST inverse after name only')
 driver=P/'inventory_certification_receiver_driver_v2.py'
 olddriver=Path('/private/tmp/gcts-and-support-cold-source-20261018/and_support_receiver_driver_v1.py')
 d=driver.read_text();od=olddriver.read_text();dn=nodes(d);odn=nodes(od)
 for name,node in odn.items():
  if name in ['run_receiver','_inventory_record_join']:continue
  need(name in dn and same(node,dn[name]),'whole unchanged driver callable '+name)
 bulk=ast.parse(ast.unparse(odn['_inventory_record_join'])).body[0]
 bulk.name='_inventory_bulk_record_join_parent'
 need(same(bulk,dn['_inventory_bulk_record_join_parent']),'bulk exact full Native request/record join inverse')
 need("'family_registry': ('2010ca7cb6f3da0734efe03e5be0f7e166b7e4d5939078dea0451361cf5890f3', 12626)"in d,'new exact registry raw pin')
 need("inventory_certification_mode" in [a.arg for a in dn['run_receiver'].args.kwonlyargs],'mandatory explicit inventory mode argument')
 # Three definitions are compiled to code objects but never evaluated/imported.
 for p in [reg,driver,P/'new_driver_join_fragment.py']:
  source=p.read_text();ast.parse(source);compile(source,str(p),'exec')
  need(True,'parse/compile without evaluation '+p.name)
 static=dict(schema='ROOT-inventory-certification-author-static-audit-v1',author_identity='/root',checks=checks,checks_passed=len(checks),mismatches=0,scientific_calls=0,Native_calls=0,module_evaluations=0,fixture_executions=0,Source_only=True,actual_execution_authorized=False,scope='Structural Source preservation and syntax only; no runtime, fit, compositional soundness, proof or resource acceptance claimed.')
 q=P/'author-static-audit-v1.json'
 with q.open('x') as f:f.write(json.dumps(static,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(audit=pin(q),checks=len(checks))))
if __name__=='__main__':main()
