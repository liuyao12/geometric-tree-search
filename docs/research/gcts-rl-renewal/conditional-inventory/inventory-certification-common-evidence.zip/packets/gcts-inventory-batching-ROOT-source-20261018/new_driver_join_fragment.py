def _inventory_record_join(inventory, records, spec, boundary, certification_mode):
    if certification_mode == 'bulk':
        return _inventory_bulk_record_join_parent(inventory, records, spec, boundary)
    if certification_mode != 'dependency_closures':
        raise DriverDataError('explicit inventory certification mode')
    boundary.check(full=True)
    fields = {'status', 'query', 'queries', 'certification', 'seconds'}
    original = {k:v for k,v in inventory.items() if k not in fields}
    cert = inventory.get('certification')
    if (type(cert) is not dict or cert.get('schema') != 'native-inventory-dependency-closure-certification-v1'
            or cert.get('version') != 'native-inventory-exact-dependency-closures-v2'
            or cert.get('mode') != certification_mode
            or cert.get('inventory_sha256') != _sha(original)
            or cert.get('theory_sha256') != _sha(spec['theory'])
            or type(cert.get('aggregate_micro_step_limit')) is not int
            or cert['aggregate_micro_step_limit'] != 5*10**9):
        raise DriverDataError('complete original inventory/theory/cap certificate')
    definitions = inventory['definitions']
    blocks = inventory['native_blocks']
    if type(definitions) is not list or type(blocks) is not list:
        raise DriverDataError('literal complete inventory lists')
    if blocks != [d['definition'] for d in definitions]:
        raise DriverDataError('complete ordered definition bodies')
    names = []
    seen = set()
    by_name = {}
    for d in definitions:
        boundary.check()
        name = d['name']
        if type(name) is not str or name in seen or d['definition']['name'] != name:
            raise DriverDataError('unique current definition identity')
        for line in d['definition']['proof']:
            if line['rule'] == 'block' and line['name'] not in seen:
                raise DriverDataError('strict prior Native dependency')
        names.append(name);seen.add(name);by_name[name] = d['definition']
    if (cert.get('all_original_definition_names') != names
            or cert.get('all_original_interfaces') != inventory['interfaces']
            or any(n not in seen for n in inventory['interfaces'])
            or len(set(inventory['interfaces'])) != len(inventory['interfaces'])):
        raise DriverDataError('whole original definition/interface coverage')
    plans = []
    # Deliberately independent DFS over the literal bodies, rather than calling
    # the registry planner being checked.
    for name in names:
        wanted = set();pending = [name]
        while pending:
            boundary.check()
            n = pending.pop()
            if n in wanted:
                continue
            wanted.add(n)
            pending.extend(line['name'] for line in by_name[n]['proof']
                           if line['rule'] == 'block')
        plans.append(dict(definition=name,names=[n for n in names if n in wanted]))
    if not plans:
        plans = [dict(definition=None,names=[])]
    if cert.get('planned_requests') != plans:
        raise DriverDataError('every exact transitive dependency closure')
    receipts = cert.get('receipts')
    if type(receipts) is not list or not receipts or len(receipts)>len(plans):
        raise DriverDataError('nonempty serial receipt prefix')
    ids = [r['query'] for r in receipts]
    if (any(type(i) is not int for i in ids)
            or ids != list(range(len(records)-len(ids),len(records)))
            or inventory.get('query') is not None
            or inventory.get('queries') != ids):
        raise DriverDataError('fresh complete serial registration query suffix')
    used = 0;accepted = set();joined = [];last_status = None
    taut = ['imp', ['bot'], ['bot']]
    for ordinal,(r,plan) in enumerate(zip(receipts,plans)):
        boundary.check()
        remaining = 5*10**9-used
        if remaining <= 0:
            raise DriverDataError('no request after aggregate budget exhaustion')
        if (r.get('ordinal') != ordinal or type(r['ordinal']) is not int
                or r.get('definition') != plan['definition']
                or r.get('closure_names') != plan['names']
                or r.get('assigned_micro_step_limit') != remaining
                or type(r['assigned_micro_step_limit']) is not int
                or r.get('aggregate_consumed_before') != used
                or type(r['aggregate_consumed_before']) is not int):
            raise DriverDataError('exact ordered plan and shared step allowance')
        request = dict(protocol='gcts-fol-1',theory=spec['theory'],
                       blocks=[by_name[n] for n in plan['names']],
                       proof=[dict(rule='tautology',formula=taut)],target=taut)
        q = records[r['query']]
        if q['purpose'] != 'check_generated_lemma_definition_closure':
            raise DriverDataError('current closure request purpose')
        current = _record_join(records,r['query'],request,boundary)
        steps = q['result'].get('micro_steps');status = q['result']['status']
        if (type(steps) is not int or not 0<=steps<=remaining
                or status not in ['accepted','rejected','unknown_space_budget','unknown_step_budget']
                or r.get('consumed_micro_steps') != steps
                or type(r['consumed_micro_steps']) is not int
                or r.get('aggregate_consumed_after') != used+steps
                or type(r['aggregate_consumed_after']) is not int
                or r.get('request_sha256') != _sha(request)
                or r.get('result_status') != status):
            raise DriverDataError('current Native outcome and exact step accounting')
        used += steps
        joined.append(current);last_status=status
        if status == 'accepted':
            accepted.update(plan['names'])
        elif ordinal+1 != len(receipts):
            raise DriverDataError('no continuation after rejected/unknown query')
    complete = (len(receipts)==len(plans) and last_status=='accepted'
                and accepted==set(names))
    if complete:
        expected_status='native_accepted';stop=None
    elif last_status=='rejected':
        expected_status='native_rejected';stop='rejected'
    elif last_status in ['unknown_space_budget','unknown_step_budget']:
        expected_status='unknown_native_inventory';stop=last_status
    elif last_status=='accepted' and used==5*10**9 and len(receipts)<len(plans):
        expected_status='unknown_native_inventory';stop='aggregate_registration_micro_step_budget'
    else:
        raise DriverDataError('incomplete acceptance is not inventory authority')
    if (inventory['status'] != expected_status or cert.get('complete') is not complete
            or cert.get('stop_reason') != stop
            or type(cert.get('aggregate_consumed_micro_steps')) is not int
            or cert['aggregate_consumed_micro_steps'] != used
            or cert.get('accepted_definition_names') != [n for n in names if n in accepted]):
        raise DriverDataError('all-or-none full inventory authority and provenance')
    return dict(mode=certification_mode,queries=joined,complete=complete,
                full_original_inventory=complete,aggregate_consumed_micro_steps=used,
                aggregate_micro_step_limit=5*10**9,status=expected_status,
                scope='Independent exact per-closure Native transcript joins and '
                      'whole original inventory coverage. Partial accepted bodies '
                      'never authorize a reduced search inventory; final whole '
                      'proof Native acceptance remains separate.')
