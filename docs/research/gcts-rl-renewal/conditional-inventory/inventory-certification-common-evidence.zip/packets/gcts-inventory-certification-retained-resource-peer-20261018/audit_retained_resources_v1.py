"""Retained JSON/bytes only: no scientific imports, codecs or process probes."""
from pathlib import Path
import gc
import hashlib
import json
import math

D = Path('/private/tmp/gcts-inventory-certification-retained-resource-peer-20261018')
ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
PROGRESS = ROOT / '.gcts-active/inventory-certification-progress-20261018'
INDEX = Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1/authorized-index-v1.json')
D.mkdir(exist_ok=True)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf8')

def pin(path):
    p = Path(path).resolve()
    h = hashlib.sha256()
    size = 0
    with p.open('rb') as stream:
        for chunk in iter(lambda: stream.read(65536), b''):
            size += len(chunk)
            h.update(chunk)
    return dict(path=str(p), bytes=size, sha256=h.hexdigest())

def load(path):
    return json.loads(Path(path).read_bytes())

def write(name, value):
    p = D / name
    p.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    return pin(p)

checks = []
pins_checked = {}
def ck(label, value, evidence=None):
    checks.append(dict(check=label, passed=bool(value), evidence=evidence))
    if not value:
        raise AssertionError(label)

def rawpin(descriptor, label):
    path = descriptor['path']
    if path not in pins_checked:
        pins_checked[path] = pin(path)
    ck(label, descriptor == pins_checked[path], descriptor)
    return descriptor

def pinned_load(descriptor, label):
    rawpin(descriptor, label)
    return load(descriptor['path'])

def contains(value, wanted):
    if value == wanted:
        return True
    if type(value) is dict:
        return any(contains(v, wanted) for v in value.values())
    if type(value) is list:
        return any(contains(v, wanted) for v in value)
    return False

def ns_between(value, start, end):
    return type(value) is int and start <= value < end

index = load(INDEX)
ck('exact authorized index pin', pin(INDEX) == dict(path=str(INDEX), bytes=48702,
   sha256='419adfa495ea3f1a90be681deb3de25c0d4cf309b1d99437c01bdc2b343fb512'))
closure_path = PROGRESS / 'ROOT-cohort-closure-v1.json'
cohort = load(closure_path)
ck('exact retained cohort closure pin', pin(closure_path) == dict(path=str(closure_path), bytes=26909,
   sha256='78917aa47a3aaeb74de9b6687ae1b353cf39d394003f6487372dfc55e0ef193d'))
runtime = pinned_load(index['runtime_closure'], 'whole current runtime closure')
parent_runtime=pinned_load(runtime['parent_closure'],'whole immutable previous-suite Source/runtime closure')
ck('only intended registry project replacement with same22 aliases',set(parent_runtime['project_sources'])==set(runtime['project_sources']) and [k for k in runtime['project_sources'] if runtime['project_sources'][k]!=parent_runtime['project_sources'][k]]==['semantic_inventory_oracle'])
ck('only receiver driver component changes, broker identical',set(runtime['additional_nonseed_components'])==set(parent_runtime['additional_nonseed_components']) and [k for k in runtime['additional_nonseed_components'] if runtime['additional_nonseed_components'][k]!=parent_runtime['additional_nonseed_components'][k]]==['receiver_driver'])
ck('unchanged Python/Z3/fixed Native dependency custody',runtime['runtime']==parent_runtime['runtime'] and runtime['Z3']==parent_runtime['Z3'] and runtime['fixed_native_inputs']==parent_runtime['fixed_native_inputs'])

declaration = pinned_load(index['design'], 'whole current prospective design')
adoption_path = PROGRESS / 'ROOT-final-grant-adoption-v1.json'
adoption = load(adoption_path)
delta_path=PROGRESS/'ROOT-final-metadata-delta-v1.json'
delta=load(delta_path)
rawpin(dict(path=str(delta_path),bytes=16836,sha256='cb91c931d94db4ee5fda080f4181470e36a93b3224d6dc4d9a6e6449f92d68aa'),'Root final delta raw metadata')
rawpin(dict(path=str(adoption_path),bytes=2370,sha256='b8aca39ac2ad241184d7c639dd00bba90f013bca925a1bd88da5261ca901ea33'),'Root grant adoption raw metadata')
prospective=pinned_load(delta['prospective_index'],'whole original false prospective index')
ck('Root metadata binds exact current index/design, not independently adopted as evidence',adoption['authorized_index']==delta['authorized_index']==pin(INDEX) and adoption['metadata_adoption_passed'] is True and adoption['maximum_actuals']==20 and adoption['design']==index['design'])
ck('full schedule unchanged except added true grant/runner references',len(prospective['schedule'])==20 and all(all(row[k]==v for k,v in old.items()) for old,row in zip(prospective['schedule'],index['schedule'])))
delta_rows={r['invocation_id']:r for r in delta['subjects']}
ck('all20 delta records present and distinct',len(delta_rows)==len(delta['subjects'])==20)
launcher_marker_path=PROGRESS/'COHORT-LAUNCHER-CONSUMED-v1.json'
launcher_marker=load(launcher_marker_path)
rawpin(adoption['launcher'],'whole exact sequential controller Source')
rawpin(pin(launcher_marker_path),'whole exclusive cohort marker')
ck('exclusive20slot controller joins exact Source/index',launcher_marker['authorized_index']==pin(INDEX) and launcher_marker['launcher']==adoption['launcher'] and launcher_marker['maximum_subjects']==20 and cohort['launcher_marker']==pin(launcher_marker_path))
input_capsule = pinned_load(index['input_capsule'], 'whole frozen ten input capsule')
case_declarations = {key:pinned_load(value, 'whole case declaration '+key) for key,value in index['case_declarations'].items()}
ck('complete unique20 slots and closed order', len(index['schedule']) == len(cohort['actuals']) == 20 and
   len({r['invocation_id'] for r in index['schedule']}) == 20 and
   [r['invocation_id'] for r in index['schedule']] == [r['invocation_id'] for r in cohort['actuals']])
case_ids = list(dict.fromkeys(r['receiver_id'] for r in index['schedule']))
ck('five prospectively selected complete cases and unchanged full10 input capsule',len(case_ids)==5 and len(case_declarations)==5 and len(input_capsule['receivers'])==10 and set(case_ids)=={'prospective-fol-20261018-'+x for x in ('001','002','003','005','010')})
ck('all20 exact rows preserve whole design order',len(declaration['schedule'])==20 and all(all(row[k]==v for k,v in declared.items()) for declared,row in zip(declaration['schedule'],index['schedule'])))
for case_id in case_ids:
    selected = [r for r in index['schedule'] if r['receiver_id']==case_id]
    ck('complete percase factorial '+case_id, len(selected)==4 and {(r['mode'],r['inventory_certification_mode']) for r in selected} ==
       {(m,c) for m in ('fixed','symbolic') for c in ('bulk','dependency_closures')})
    declared_rows = case_declarations[case_id]['schedule']
    ck('complete percase four declaration '+case_id,
       case_declarations[case_id]['selected_receiver_id']==case_id and len(declared_rows)==4 and
       all(d=={k:r[k] for k in d} for d,r in zip(declared_rows,selected)))
ck('all current compact/shared reader fixed', all(r['model_storage'] == 'literal_interned' and
   r['result_reader'] == 'interned' and r['search_ordering']=='and_support' for r in index['schedule']))
ck('same full current Source inventory24', len(runtime['project_sources']) == 22 and
   len(runtime['materialized_aliases']) == runtime['materialized_project_and_component_count'] == 24)
ck('unchanged Z3 full41 raw file map', len(runtime['Z3']['files']) == 41)
for alias, source in runtime['materialized_aliases'].items():
    rawpin(source, 'current raw original alias ' + alias)
for source in runtime['Z3']['files']:
    rawpin({k: source[k] for k in ('path','sha256','bytes')}, 'current raw Z3 file ' + source['path'])
rawpin(runtime['runtime']['Python_executable'], 'whole Python executable raw bytes (no import)')
for name in ('runner', 'observer', 'cold'):
    rawpin(index[name], 'current instrument Source ' + name)

role_schemas = {
 'ordering_Source':dict(schema='and-support-ordering-components-typed-Source-review-v1', **{'pass':'source_review_passed'},reviewer='/root/receiver_driver_review'),
 'registry_Source':dict(schema='inventory-closure-registry-typed-Source-review-v1', **{'pass':'source_review_passed'},reviewer='/root/conventional_library'),
 'composition_Source':dict(schema='inventory-certification-driver-cold-typed-Source-review-v1', **{'pass':'source_review_passed'},reviewer='/root/conventional_library'),
 'once_Source':dict(schema='inventory-certification-once-typed-Source-review-v1', **{'pass':'source_review_passed'},reviewer='/root/conventional_control_review'),
 'prospective_plans':dict(schema='inventory-certification-prospective-plan-review-v1', **{'pass':'prospective_review_passed'},reviewer='/root/conventional_library')}
ck('exact five current review roles',set(index['current_review_roles'])==set(role_schemas))
reviews = {}
for role, descriptor in index['current_review_roles'].items():
    review = pinned_load(descriptor, 'raw current distinct scoped review ' + role)
    a = role_schemas[role]
    ck('review identity/schema/pass/no-execution ' + role,
       review['schema'] == a['schema'] and review['reviewer_identity'] == a['reviewer'] and
       review[a['pass']] is True and review['author_identity'] != review['reviewer_identity'] and
       review['source_only'] is True and review['scientific_calls'] == 0 and
       review['scientific_acceptance'] is False and review['actual_execution_authorized'] is False)
    reviews[role] = review

role_modules = dict(base_compiler='quantified_receptors_v1', family_miner='semantic_lemma_inventory',
                    family_model='interned_quantified_family_points_v1', family_search='semantic_inventory_search_v2',
                    family_registry='semantic_inventory_oracle', point_smt='semantic_point_smt',
                    symbolic_control='quantified_symbolic_control_v2', support_ordering='receptor_support_ordering_v1')
cohort_rows = {r['invocation_id']:r for r in cohort['actuals']}
rows = []
epoch_semantic_context = []
for planrow in index['schedule']:
    iid = planrow['invocation_id']
    tag = iid + ': '
    actual = Path(planrow['actual_directory'])
    meta = dict(cohort_rows[iid], consumed=pin(actual/'CONSUMED.json'))
    case_pin = index['case_declarations'][planrow['receiver_id']]
    runner_plan = pinned_load(planrow['runner_plan'], tag+'whole runner plan')
    worker_plan = pinned_load(planrow['worker_plan'], tag+'whole worker plan')
    auth = pinned_load(planrow['authorization'], tag+'whole true grant')
    draft = pinned_load(planrow['runner_plan_draft'], tag+'historical false runner plan')
    draft_auth = pinned_load(planrow['authorization_draft'], tag+'historical false grant')
    ck(tag+'exact19 runner/19 worker fields and seven auth fields', len(runner_plan) == len(worker_plan) == 19 and len(auth) == 7)
    ck(tag+'historical false maxone and current true maxone', draft_auth['actual_execution_authorized'] is False and
       auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations']) is int and
       auth['maximum_actual_invocations'] == 1 and type(draft_auth['maximum_actual_invocations'])is int and draft_auth['maximum_actual_invocations']==0 and auth['author_identity'] == '/root')
    ck(tag+'runner changed only authorization descriptor',
       {k:v for k,v in runner_plan.items() if k!='authorization'} == {k:v for k,v in draft.items() if k!='authorization'})
    ck(tag+'18-field whole scientific subject',len({k:v for k,v in runner_plan.items() if k!='authorization'})==18)
    subject = hashlib.sha256(canonical({k:v for k,v in runner_plan.items() if k!='authorization'})).hexdigest()
    ck(tag+'full exact subject hash joins grant/index', subject == auth['subject_sha256'] == planrow['subject_sha256'])
    ck(tag+'only allowed false-to-true authorization changes',{k:v for k,v in auth.items() if k not in ('actual_execution_authorized','maximum_actual_invocations','review_roles','scope')}=={k:v for k,v in draft_auth.items() if k not in ('actual_execution_authorized','maximum_actual_invocations','review_roles','scope')} and draft_auth['review_roles']=={})
    ck(tag+'exact current new protocol schemas',runner_plan['schema']=='ROOT-inventory-certification-once-plan-v1' and worker_plan['schema']=='ROOT-inventory-certification-worker-plan-v1' and auth['schema']==draft_auth['schema']=='ROOT-inventory-certification-once-authorization-v1')
    dd=delta_rows[iid]
    ck(tag+'Root final delta independently recomputed joins',dd['whole_plan']==planrow['runner_plan'] and dd['whole_authorization']==planrow['authorization'] and dd['former_draft_maximum']==0 and dd['authorized_maximum']==1 and dd['subject_unchanged'] is True)
    for key in ('mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory','invocation_id'):
        ck(tag+'literal subject '+key, runner_plan[key] == worker_plan[key] == planrow[key])
    ck(tag+'Source/declaration/closure exact plan bindings', runner_plan['runner'] == index['runner'] and
       runner_plan['observer'] == index['observer'] and runner_plan['cold'] == worker_plan['cold'] == index['cold'] and
       runner_plan['integration_declaration'] == worker_plan['integration_declaration'] == case_pin and
       runner_plan['runtime_closure'] == worker_plan['runtime_closure'] == index['runtime_closure'])
    ck(tag+'full original24 maps equal current closure', worker_plan['project_sources'] == runtime['project_sources'] and
       worker_plan['components'] == runtime['additional_nonseed_components'] and
       worker_plan['python'] == runner_plan['python'] == runtime['runtime']['Python_executable'])
    ck(tag+'review roles exact current five receipts', set(auth['review_roles']) == set(index['current_review_roles']) and
       all(auth['review_roles'][role]['receipt'] == desc for role,desc in index['current_review_roles'].items()))
    minimum = {'ordering_Source':[runtime['project_sources'][a] for a in
                  ('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],
               'registry_Source':[runtime['project_sources']['semantic_inventory_oracle']],
               'composition_Source':[index['cold'],worker_plan['components']['receiver_driver']],
               'once_Source':[index['runner'],index['observer']],
               'prospective_plans':[case_pin,index['runtime_closure'],planrow['worker_plan']]}
    for role, binding in auth['review_roles'].items():
        ck(tag+'full current minimum subjects '+role, all(s in binding['required_subjects'] for s in minimum[role]) and
           binding['reviewer_identity'] == role_schemas[role]['reviewer'])
        for j, descriptor in enumerate(binding['required_subjects']):
            ck(tag+'raw scoped receipt subject '+role+'/'+str(j), contains(reviews[role], descriptor))
    consumed = pinned_load(meta['consumed'], tag+'exclusive consumed marker')
    worker = pinned_load(meta['worker_receipt'], tag+'whole worker receipt')
    runner = pinned_load(meta['runner_receipt'], tag+'whole outer receipt')
    terminal = pinned_load(meta['terminal'], tag+'whole final terminal observation')
    slot=PROGRESS/'launcher-slots'/iid
    slot_closed=load(slot/'CLOSED.json');slot_start=load(slot/'START.json')
    rawpin(pin(slot/'CLOSED.json'),tag+'full closed launcher slot')
    rawpin(pin(slot/'START.json'),tag+'full started launcher slot')
    ck(tag+'exact controller closed slot equals cohort record',slot_closed==cohort_rows[iid])
    ck(tag+'one explicit current observer command in launcher slot',slot_start['order']==planrow['order'] and slot_start['subject']==subject and slot_start['command']==[runner_plan['python']['path'],'-I','-S','-B',index['observer']['path'],planrow['runner_plan']['path']])
    ck(tag+'exact three new retained receipt schemas',worker['schema']=='inventory-certification-worker-receipt-v1' and runner['schema']=='inventory-certification-external-once-receipt-v1' and terminal['schema']=='inventory-certification-final-terminal-observation-v1')
    ck(tag+'observer exact single current runner command',terminal['command']==[runner_plan['python']['path'],'-I','-S','-B',index['runner']['path'],planrow['runner_plan']['path']])
    terminal_folder = Path(meta['terminal']['path']).parent
    for filename in ['stdout.bin','stderr.bin']:
        rawpin(pin(terminal_folder/filename),tag+'whole observer log '+filename)
        rawpin(pin(slot/('observer-'+filename)),tag+'whole controller-captured observer log '+filename)
    observed_return=load(terminal_folder/'stdout.bin');controller_return=load(slot/'observer-stdout.bin')
    ck(tag+'outer stdout terminal outcome joins exact final receipt',observed_return['completion_within_overall'] is True and observed_return['exit_code']==0 and observed_return['runner_receipt']==meta['runner_receipt'])
    ck(tag+'controller captured observer terminal output',controller_return['exit_code']==0 and controller_return['terminal_gate_passed'] is True and controller_return['terminal']==meta['terminal']['path'])

    terminal_marker_path = terminal_folder / 'CONSUMED.json'
    terminal_marker = load(terminal_marker_path)
    rawpin(pin(terminal_marker_path), tag+'observer exclusive consumed marker bytes')
    ck(tag+'observer launched once under exact plan', terminal_marker['maximum_runner_launches'] == 1 and
       terminal_marker['plan'] == terminal['plan'] == runner['plan'] == consumed['plan'] == planrow['runner_plan'])
    ck(tag+'once consumed before single observed worker Popen', consumed['consumed_before_Popen'] is True and
       consumed['maximum_worker_launches'] == runner['worker_launch_attempts'] == 1 and
       runner['consumed_once'] is True and runner['worker_pid_observed'] is True and
       runner['consumed_marker'] == meta['consumed'])
    for key in ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader'):
        ck(tag+'consumed/outer literal '+key, consumed[key] == runner[key] == planrow[key])
    ck(tag+'outer receiver joined through full consumed plan descriptor', runner['receiver_id'] == planrow['receiver_id'])
    for key in ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','receiver_id'):
        ck(tag+'worker literal '+key, worker[key] == planrow[key])
    ck(tag+'grant and review receipts actually recorded', runner['authorization'] == planrow['authorization'] and
       runner['subject_sha256'] == subject and runner['review_roles'] == auth['review_roles'])
    limits = runner['limits']
    ck(tag+'whole original limits copied from declared runner plan', limits == runner_plan['limits'])
    ck(tag+'strict180/210/1GiB/128MiB plus4MiB logs', limits['work_seconds'] == 180 and limits['overall_seconds'] == 210 and
       limits['aggregate_peak_bytes'] == 1073741824 and limits['result_bytes'] == 134217728 and
       limits['stdout_bytes'] == limits['stderr_bytes'] == 4194304)
    began, work_end, overall = runner['began_ns'], runner['work_deadline_ns'], runner['overall_deadline_ns']
    ck(tag+'original endpoint arithmetic and shared epochs', work_end-began == 180000000000 and overall-began == 210000000000 and
       all(obj['began_ns'] == began and obj['work_deadline_ns'] == work_end and obj['overall_deadline_ns'] == overall
           for obj in (consumed, worker)))
    ck(tag+'exact isolated Python PID and known wait4', type(runner['python_pid']) is int and runner['python_pid'] > 0 and
       runner['python_pid'] == runner['owned_pgid'] and runner['python_reaped'] is True and
       runner['python_exit_code'] == runner['python_wait4_status'] == 0)
    ck(tag+'full EOF/group/log and permanent no-reappearance flags', runner['owned_group_absent'] is True and
       runner['stdout_eof'] is runner['stderr_eof'] is runner['log_capture_complete'] is True and
       runner['owned_group_reappearance_observed_ns'] is None and runner['owned_group_probe_count'] >= 1 and
       runner['signals'] == [] and runner['errors'] == [])
    ck(tag+'authoritative absence only after known worker reap', began <= runner['worker_terminal_observed_ns'] <=
       runner['owned_group_first_absent_ns'] <= runner['postreap_group_and_pipe_closed_ns'] <= runner['checks_closed_ns'] < overall and
       runner['owned_group_first_absent_ns'] <= runner['owned_group_last_probe_ns'] <= runner['checks_closed_ns'])
    ck(tag+'strict final external terminal before210 and normal runner exit', terminal['runner_exit_code'] == 0 and
       terminal['terminal_gate_passed'] is True and runner['resource_candidate_accepted'] is True and
       terminal['runner_receipt'] == meta['runner_receipt'] and runner['checks_closed_ns'] <= terminal['terminal_observed_ns'] < overall)
    ck(tag+'three DISTINCT observer/runner/worker exit observations', meta['observer_exit_code']==0 and
       terminal['runner_exit_code']==0 and runner['python_exit_code']==0 and meta['terminal_gate'] is True and
       meta['closed_without_ownership_ambiguity'] is True)
    ck(tag+'no late postreceipt failure marker', not (actual/'POST_RECEIPT_DEADLINE_FAILURE.json').exists())
    ck(tag+'resource flags not own mathematical admission', runner['scientific_acceptance'] is False and
       runner['mathematical_proof_accepted'] is False and terminal['mathematical_proof_accepted'] is False)
    native = worker['native_transport']
    ck(tag+'all retained native transport copies equal', native == runner['native_transport'] == worker['driver_output_receipt']['transport_receipt'])
    ck(tag+'exact native child belongs to current worker group', native['parent_pid'] == native['parent_pgid'] == native['native_pgid'] == runner['python_pid'] and
       type(native['native_pid']) is int and native['native_pid'] > 0 and native['native_pid'] != runner['python_pid'])
    ck(tag+'native constructor close exact wait4 terminal', native['constructor_completed'] is native['closed'] is native['all_reaped'] is native['same_owned_process_group'] is True and
       native['native_exit_code'] == native['wait4_status'] == 0 and native['cleanup_errors'] == [])
    ck(tag+'native EOF and no native termination signals', native['stdout_eof'] is native['stderr_complete'] is True and
       native['stdout_pending_bytes'] == 0 and native['termination_signals'] == [])
    ck(tag+'native original absolute deadlines', abs(native['work_deadline']-work_end/1e9) < .000001 and
       abs(native['closure_deadline']-overall/1e9) < .000001)
    python_peak = runner['python_wait4_usage']['ru_maxrss']
    native_peak = native['native_high_water_bytes']
    ck(tag+'exact separately observed Darwin highwater integers', type(python_peak) is type(native_peak) is int and
       python_peak >= 0 and native_peak == native['wait4_usage']['ru_maxrss'] and native_peak >= 0 and
       'bytes on declared Darwin' in native['ru_maxrss_unit'])
    peak = python_peak + native_peak
    ck(tag+'conservative sum within1GiB (not simultaneous peak)', peak == runner['conservative_parent_plus_native_peak_bytes'] and
       peak <= 1073741824 and runner['live_group_memory_limit_claimed'] is False and
       runner['perprocess_peaks_may_doublecount_conservatively'] is True)
    for name, output in runner['outputs'].items():
        rawpin(output, tag+'whole retained output/log '+name)
    ck(tag+'outer output worker joins exact cohort pin', runner['outputs']['worker_receipt'] == meta['worker_receipt'])
    ck(tag+'bounded whole stdout/stderr captured to EOF', runner['stdout_bytes'] == runner['outputs']['stdout']['bytes'] <= limits['stdout_bytes'] and
       runner['stderr_bytes'] == runner['outputs']['stderr']['bytes'] <= limits['stderr_bytes'])
    result_pin = worker['result']
    ck(tag+'one whole raw result Source receipt join', result_pin == runner['outputs']['result'] and result_pin['bytes'] <= 134217728)
    rawpin(result_pin, tag+'whole raw result hash')
    raw_result = Path(result_pin['path']).read_bytes()
    result = json.loads(raw_result)  # Standard JSON data only; no research decoder.
    reading = worker['result_reading']
    ck(tag+'recorded full Reader inverse raw body checksum matches saved bytes', raw_result[-1:] == b'\n' and
       reading['roundtrip']['literal_bytes_equal'] is True and reading['roundtrip']['body_bytes'] == len(raw_result)-1 and
       reading['roundtrip']['body_sha256'] == hashlib.sha256(raw_result[:-1]).hexdigest())
    # Standard JSON's C-backed whole re-encoding is data-only, not the
    # scientific Reader/codec. One result at a time; release before next arm.
    canonical_body = canonical(result)
    canonical_bytes = len(canonical_body)
    canonical_digest = hashlib.sha256(canonical_body).hexdigest()
    del canonical_body
    ck(tag+'independent stdlib literal JSON re-encoding checksum', canonical_bytes == reading['roundtrip']['body_bytes'] and
       canonical_digest == reading['roundtrip']['body_sha256'])
    ck(tag+'reader temporal interval fully charged', began <= reading['started_ns'] <= reading['decoded_ns'] <= reading['completed_ns'] < work_end and
       abs(reading['decode_seconds']-(reading['decoded_ns']-reading['started_ns'])/1e9) < 1e-9)
    ck(tag+'current fixed shared Reader role', reading['reader'] == 'interned' and reading['source']['sha256'] ==
       worker_plan['project_sources']['interned_result_reader_v2']['sha256'])
    epoch = result['source_epoch']
    original_map = runtime['materialized_aliases']
    owned_map = epoch['sources']['project']
    ck(tag+'complete original and owned24 Source epochs', epoch['sources']['original'] == original_map and
       set(owned_map) == set(original_map) and len(owned_map) == 24 and epoch['sources']['cold'] == index['cold'])
    ck(tag+'exact current epoch schema and factor',epoch['schema']=='semantic-family-receiver-source-epoch-v4-inventory-certification' and epoch['inventory_certification_mode']==result['inventory_certification_mode']==planrow['inventory_certification_mode'])
    ck(tag+'whole exact epoch checksum', worker['source_epoch_sha256'] == hashlib.sha256(canonical(epoch)).hexdigest())
    origins = {entry['module']:entry['path'] for entry in worker['import_origins']}
    for alias, original in original_map.items():
        owned = owned_map[alias]
        expected = dict(path=str(actual/'modules'/(alias+'.py')), sha256=original['sha256'], bytes=original['bytes'])
        ck(tag+'whole alias original/owned descriptor '+alias, owned == expected)
        rawpin(owned, tag+'actual owned alias raw '+alias)
        ck(tag+'actual recorded module origin '+alias, origins[alias] == owned['path'])
    ck(tag+'all imported Z3 module paths among exact frozen41 files',all(entry['path'] in {z['path']for z in worker_plan['z3']['files']} for entry in worker['import_origins']if entry['module'].split('.')[0]=='z3'))
    for role, alias in role_modules.items():
        ck(tag+'full driver module Source role '+role, result['module_pins'][role] == owned_map[alias])
    search_role = 'family_search' if planrow['mode'] == 'fixed' else 'symbolic_control'
    search_alias = role_modules[search_role]
    ck(tag+'selected search original and owned literal module', worker['selected_search_module'] ==
       dict(role=search_role,module=search_alias,original=original_map[search_alias],owned=owned_map[search_alias]))
    ck(tag+'helper original and owned literal module', worker['support_ordering_module'] ==
       dict(module='receptor_support_ordering_v1', original=original_map['receptor_support_ordering_v1'], owned=owned_map['receptor_support_ordering_v1']))
    ck(tag+'selected compact Model whole original and owned', worker['selected_family_model'] ==
       dict(module=role_modules['family_model'], original=original_map[role_modules['family_model']], owned=owned_map[role_modules['family_model']]))
    ck(tag+'all result/epoch/worker/driver ordering and mode joins', result['mode'] == worker['driver_output_receipt']['mode'] == planrow['mode'] and
       result['search_ordering'] == epoch['search_ordering'] == worker['driver_output_receipt']['search_ordering'] == planrow['search_ordering'] and
       epoch['model_storage'] == planrow['model_storage'] and result['receiver_id'] == planrow['receiver_id'])
    ck(tag+'epoch full current Python/Z3 and Reader declaration custody', epoch['python'] == worker_plan['python'] and
       epoch['z3'] == worker_plan['z3'] and epoch['result_representation']['integration_declaration'] == case_pin)
    ck(tag+'whole original policy and current result policy checksum',epoch['policy']==worker_plan['policy'] and result['policy_pin']=={k:worker_plan['policy'][k]for k in ('sha256','bytes')})
    rawpin(worker_plan['policy'],tag+'complete unchanged four-template policy raw Source')
    ck(tag+'complete Native input map unchanged apart from charged perarm codebin',{k:v for k,v in epoch['native_inputs'].items() if k!='code_bin'}==worker_plan['native_inputs'] and set(epoch['native_inputs'])==set(worker_plan['native_inputs'])|{'code_bin'})
    ck(tag+'perarm encoded fixedNative table path exactly owned',epoch['native_inputs']['code_bin']['path']==str(actual/'native'/'code.bin'))
    for name, descriptor in epoch['native_inputs'].items():
        rawpin(descriptor, tag+'current native raw input (NO decode) '+name)
    ck(tag+'Python whole baseline and explicit metadata trust', runner['python_custody']['python'] == worker_plan['python'] and
       runner['python_custody']['whole_baseline_authenticated'] is True and
       runner['python_custody']['trusted_OS_metadata_assumption'] is True and
       runner['python_custody']['formal_continuous_seal'] is False and
       runner['python_custody']['worker_callback_guard_claimed'] is False)
    ck(tag+'all resource candidates reached positive-profile final outer raw loop', runner['resource_candidate_accepted'] is True and runner['errors'] == [])
    for j, stage in enumerate(worker['cold_stages']):
        ck(tag+'charged returned cold stage '+str(j), ns_between(stage['started_ns'],began,work_end) and
           stage['started_ns'] <= stage['returned_ns'] < work_end)
    for j, stage in enumerate(result['stage_intervals']):
        ck(tag+'charged returned scientific stage endpoint '+str(j), began/1e9 <= stage['started_monotonic'] <= stage['returned_monotonic'] < work_end/1e9)
    output_receipt = worker['driver_output_receipt']['output']
    ck(tag+'complete atomic output raw pin and within128MiB', output_receipt['complete'] is output_receipt['atomic'] is True and
       {k:output_receipt[k] for k in ('path','sha256','bytes')} == result_pin and output_receipt['cap_bytes'] == 134217728)
    ck(tag+'serialization and preflight charged strictly before180', began/1e9 <= output_receipt['serialization_started_monotonic'] <=
       output_receipt['payload_serialized_monotonic'] <= output_receipt['publication_preflight_monotonic'] < work_end/1e9 and
       worker['driver_returned_ns'] <= worker['custody_checked_ns'] < work_end)
    observed_positive = worker['logical_proof_accepted']
    ck(tag+'stored proof transport flags consistent (not own math admission)', type(observed_positive) is bool and
       observed_positive == result['native_proof_accepted'] == worker['driver_output_receipt']['native_proof_accepted'] == runner['logical_proof_transport_candidate'])
    if observed_positive:
        ck(tag+'positive whole output and known worker exit strictly before180', worker['work_completed'] is True and
           runner['worker_terminal_observed_ns'] < work_end and reading['completed_ns'] < work_end and
           worker['final_region_verification']['status'] == 'VERIFIED_WHOLE_FINITE_POINT_REGION')
    else:
        ck(tag+'UNKNOWN has no positive proof flags', result['status'] in ('unknown_search_budget','unknown_native_inventory') and
           worker['primary_family_hint_accepted'] is False and result['family_hint_success'] is False and
           worker['final_region_verification']['status'] == 'NOT_CHECKED_NO_NATIVE_PROOF')
    ck(tag+'same current scientific caps/attempt unit metadata', result['limits']['attempts'] == 5000 and
       result['limits']['search_seconds'] == 30 and result['limits']['compile_queries'] == 512 and
       result['limits']['compile_micro_steps'] == 1000000000 and result['limits']['native_micro_steps'] == 5000000000 and
       result['limits']['output_bytes'] == 134217728)
    ck(tag+'result transport full bytes equal worker header', result['transport_receipt'] == native)
    records = result['records']
    ck(tag+'native completed request stages and records count', len(records) == native['complete_records'] == len(native['request_stages']))
    for j, (record, stage) in enumerate(zip(records,native['request_stages'])):
        ck(tag+'native raw request/transport ordinal '+str(j), record['id'] == stage['record_id'] == stage['ordinal'] == j and
           stage['stage'] == 'COMPLETED' and all(stage[key] == record[key] for key in
               ('purpose','request_sha256','input_sha256','output_sha256')) and
           hashlib.sha256(canonical(record['request'])).hexdigest() == record['request_sha256'])
        expected_limit=1000000000 if record['purpose'].startswith('first_order_') else 5000000000
        if record['purpose']=='check_generated_lemma_definition_closure':
            expected_limit=5000000000-sum(r['result']['micro_steps'] for r in records[:j] if r['purpose']=='check_generated_lemma_definition_closure')
        ck(tag+'exact assigned original/remaining microstep cap '+str(j),type(stage['limit'])is int and stage['limit']==expected_limit and 0<stage['limit']<=5000000000)
        ck(tag+'reported microsteps within actually assigned cap '+str(j),type(record['result']['micro_steps'])is int and 0<=record['result']['micro_steps']<=stage['limit'])
    registry_records=[r for r in records if r['purpose'] in ('check_generated_lemma_definitions','check_generated_lemma_definition_closure')]
    ck(tag+'entire registration aggregate within unchanged5e9',sum(r['result']['micro_steps']for r in registry_records)<=5000000000)
    last=records[-1]
    for native_name,key in [('input.bin','input_sha256'),('output.bin','output_sha256')]:
        native_artifact=pin(actual/'native'/native_name);rawpin(native_artifact,tag+'last saved Native wire raw bytes only '+native_name)
        ck(tag+'last raw Native wire hash join '+native_name,native_artifact['sha256']==last[key])
        ck(tag+'current compilation request count within512', sum(r['purpose'].startswith('first_order_') for r in records) <= 512)
    epoch_semantic_context.append(dict(invocation_id=iid, receiver_id=planrow['receiver_id'], original_source_map=original_map,
                                       native_inputs=worker_plan['native_inputs'], policy=worker_plan['policy'],
                                       selected_receiver=epoch['receiver_selection']))
    search = result['outputs'].get('search')
    if type(search) is not dict:
        search = {}
    table = dict(invocation_id=iid, order=planrow['order'], mode=planrow['mode'], search_ordering=planrow['search_ordering'], inventory_certification_mode=planrow['inventory_certification_mode'], receiver_id=planrow['receiver_id'],
                 stored_status=result['status'], stored_native_proof_flag=observed_positive,
                 resource_profile_pass=True, search_status=search.get('status','NOT_REACHED'), search_seconds=search.get('seconds'),
                 search_work_count=search.get('metrics',{}).get('prefix_extensions', search.get('metrics',{}).get('attempts')),
                 search_work_unit=result['limits']['attempt_unit'],
                 worker_seconds=(runner['worker_terminal_observed_ns']-began)/1e9,
                 external_terminal_seconds=(terminal['terminal_observed_ns']-began)/1e9,
                 separately_observed_instrument_seconds=terminal['observed_instrument_elapsed_seconds'],
                 result_bytes=result_pin['bytes'], python_high_water_bytes=python_peak, native_high_water_bytes=native_peak,
                 conservative_peak_sum_bytes=peak, conservative_peak_sum_MiB=peak/1048576,
                 native_queries=len(records), registration_queries=len(registry_records), registration_micro_steps=sum(r['result']['micro_steps']for r in registry_records), registration_last_status=registry_records[-1]['result']['status'], reader_decode_seconds=reading['decode_seconds'],
                 observer_exit_code=meta['observer_exit_code'], runner_exit_code=terminal['runner_exit_code'],
                 worker_exit_code=runner['python_exit_code'], native_exit_code=native['native_exit_code'],
                 reader_total_seconds=(reading['completed_ns']-reading['started_ns'])/1e9,
                 serialization_to_preflight_seconds=output_receipt['serialization_to_preflight_seconds'],
                 stage_seconds={s['stage']:s['returned_monotonic']-s['started_monotonic'] for s in result['stage_intervals']},
                 retained_pins=dict(result=result_pin, worker=meta['worker_receipt'], runner=meta['runner_receipt'],
                                    terminal=meta['terminal'], consumed=meta['consumed']),
                 group_absent=True, stdout_eof=True, stderr_eof=True, group_reappearance_observed=None,
                 scientific_acceptance_by_this_review=False)
    ck(tag+'Root controller recorded outcome metadata join',meta['status']==result['status'] and
       meta['resource_candidate'] is True and meta['native_proof_candidate']==observed_positive)
    rows.append(table)
    print('retained metadata checked', len(rows), iid, flush=True)
    del result, raw_result, records, epoch
    gc.collect()

ck('sequential measured worker epochs in fixed declared order', all(
   rows[i]['retained_pins']['runner'] != rows[i+1]['retained_pins']['runner'] for i in range(19)))
previous_terminal = None
for row in rows:
    rr = load(row['retained_pins']['runner']['path'])
    term = load(row['retained_pins']['terminal']['path'])
    if previous_terminal is not None:
        ck('no overlapping next measured Source-entry epoch '+row['invocation_id'], rr['began_ns'] > previous_terminal)
    previous_terminal = term['terminal_observed_ns']
for case_id in case_ids:
    contexts=[c for c in epoch_semantic_context if c['receiver_id']==case_id]
    ck('same full Source/native/policy/receiver context percase '+case_id, len(contexts)==4 and all(
       {k:v for k,v in c.items() if k!='invocation_id'} == {k:v for k,v in contexts[0].items() if k!='invocation_id'} for c in contexts))
ck('fixed full original Source/native/policy all20; assertions vary only bycase', all(
   {k:v for k,v in c.items() if k not in ('invocation_id','receiver_id','selected_receiver')} ==
   {k:v for k,v in epoch_semantic_context[0].items() if k not in ('invocation_id','receiver_id','selected_receiver')}
   for c in epoch_semantic_context))
ck('all20 outcomes retained with four positive flags and16 inventoryUNKNOWN',len(rows)==20 and sum(r['stored_native_proof_flag']for r in rows)==4 and sum(r['stored_status']=='unknown_native_inventory'for r in rows)==16 and all(r['receiver_id']=='prospective-fol-20261018-001' for r in rows if r['stored_native_proof_flag']))

phase_ranges={}
for row in rows:
    for phase,value in row['stage_seconds'].items():phase_ranges.setdefault(phase,[]).append(value)
summary=dict(retained_actuals=20,resource_profile_pass_count=20,stored_positive_candidates=4,stored_native_inventory_UNKNOWN=16,peak_sum_MiB_range=[min(r['conservative_peak_sum_MiB']for r in rows),max(r['conservative_peak_sum_MiB']for r in rows)],external_terminal_seconds_range=[min(r['external_terminal_seconds']for r in rows),max(r['external_terminal_seconds']for r in rows)],max_full_result_bytes=max(r['result_bytes']for r in rows),total_native_completed_requests=sum(r['native_queries']for r in rows),phase_ranges={k:dict(count=len(v),minimum=min(v),maximum=max(v))for k,v in phase_ranges.items()})
table_pin=write('twenty-result-resource-table-v1.json',dict(schema='inventory-certification-twenty-retained-resource-table-v1',rows=rows,summary=summary,saved_data_only=True,scientific_acceptance=False,cost_scope='Outer Source-entry through positive worker/output/Reader/known exit and final externally observed terminal; observer/interpreter prelude separately observed. Separate Darwin worker and Native highwaters are summed conservatively; outer/observer/controller RAM excluded.'))
audit_pin=write('raw-retained-resource-audit-v1.json',dict(schema='inventory-certification-retained-resource-audit-v1',source_only=True,saved_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,author_identity='/root',reviewer_identity='/root/conventional_control_review',index=pin(INDEX),cohort_closure=pin(closure_path),runtime_closure=index['runtime_closure'],design=index['design'],input_capsule=index['input_capsule'],case_declarations=index['case_declarations'],Root_final_grant_adoption=pin(adoption_path),Root_final_metadata_delta=pin(delta_path),current_reviews=index['current_review_roles'],check_count=len(checks),mismatch_count=0,checks=checks,unique_current_raw_pins_checked=list(pins_checked.values()),full_same_contexts=epoch_semantic_context,table=table_pin,scientific_or_native_decoding_performed=False))
print(json.dumps(dict(audit=audit_pin,table=table_pin,check_count=len(checks),mismatch_count=0,summary=summary),sort_keys=True,indent=2))
