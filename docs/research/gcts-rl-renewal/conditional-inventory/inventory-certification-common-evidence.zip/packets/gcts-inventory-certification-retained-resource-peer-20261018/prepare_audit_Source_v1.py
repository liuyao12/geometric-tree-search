"""Create a retained-data audit successor; no reviewed runtime is imported."""
from pathlib import Path
P=Path('/private/tmp/gcts-first-order-suite-retained-resource-peer-20261018/audit_suite_resources_v1.py')
s=P.read_text()
s=s[:s.index("table_pin = write(")]
s=s.replace('/private/tmp/gcts-first-order-suite-retained-resource-peer-20261018','/private/tmp/gcts-inventory-certification-retained-resource-peer-20261018')
s=s.replace(".gcts-active/first-order-suite-progress-20261018'",".gcts-active/inventory-certification-progress-20261018'")
s=s.replace('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1','/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1')
s=s.replace("bytes=90732,\n   sha256='8892cb887508d87f0b6d7cf0091975f9654a70ecf60872437688ae76207544d0'","bytes=48702,\n   sha256='419adfa495ea3f1a90be681deb3de25c0d4cf309b1d99437c01bdc2b343fb512'")
s=s.replace("bytes=52310,\n   sha256='326c2f81cd9380651679d91ae741740e33eb522a8c5bfd9575952b304906a21f'","bytes=26909,\n   sha256='78917aa47a3aaeb74de9b6687ae1b353cf39d394003f6487372dfc55e0ef193d'")
s=s.replace("declaration = pinned_load(index['declaration'], 'whole current experiment declaration')","declaration = pinned_load(index['design'], 'whole current prospective design')")
start=s.index("final_peer = pinned_load(")
end=s.index("input_capsule = pinned_load",start)
s=s[:start]+'''delta_path=PROGRESS/'ROOT-final-metadata-delta-v1.json'
delta=load(delta_path)
rawpin(dict(path=str(delta_path),bytes=16836,sha256='cb91c931d94db4ee5fda080f4181470e36a93b3224d6dc4d9a6e6449f92d68aa'),'Root final delta raw metadata')
rawpin(dict(path=str(adoption_path),bytes=2370,sha256='b8aca39ac2ad241184d7c639dd00bba90f013bca925a1bd88da5261ca901ea33'),'Root grant adoption raw metadata')
prospective=pinned_load(delta['prospective_index'],'whole original false prospective index')
ck('Root metadata binds exact current index/design, not independently adopted as evidence',adoption['authorized_index']==delta['authorized_index']==pin(INDEX) and adoption['metadata_adoption_passed'] is True and adoption['maximum_actuals']==20 and adoption['design']==index['design'])
ck('full schedule unchanged except added true grant/runner references',len(prospective['schedule'])==20 and all(all(row[k]==v for k,v in old.items()) for old,row in zip(prospective['schedule'],index['schedule'])))
delta_rows={r['invocation_id']:r for r in delta['subjects']}
ck('all20 delta records present and distinct',len(delta_rows)==len(delta['subjects'])==20)
launcher_marker_path=PROGRESS/'COHORT-LAUNCHER-CONSUMED-v1.json'
launcher_marker=load(launcher_marker_path)
rawpin(adoption['launcher'],'whole exact sequential controller Source')
rawpin(pin(launcher_marker_path),'whole exclusive cohort marker')
ck('exclusive20slot controller joins exact Source/index',launcher_marker['authorized_index']==pin(INDEX) and launcher_marker['launcher']==adoption['launcher'] and launcher_marker['maximum_subjects']==20 and cohort['launcher_marker']==pin(launcher_marker_path))
''' +s[end:]
s=s.replace("== len(cohort['actuals']) == 40","== len(cohort['actuals']) == 20").replace("}) == 40","}) == 20")
start=s.index("ck('complete fixed ten inputs/eight groups")
end=s.index('for case_id in case_ids:',start)
s=s[:start]+'''ck('five prospectively selected complete cases and unchanged full10 input capsule',len(case_ids)==5 and len(case_declarations)==5 and len(input_capsule['receivers'])==10 and set(case_ids)=={'prospective-fol-20261018-'+x for x in ('001','002','003','005','010')})
ck('all20 exact rows preserve whole design order',len(declaration['schedule'])==20 and all(all(row[k]==v for k,v in declared.items()) for declared,row in zip(declaration['schedule'],index['schedule'])))
''' +s[end:]
s=s.replace("{(r['mode'],r['search_ordering']) for r in selected}","{(r['mode'],r['inventory_certification_mode']) for r in selected}")
s=s.replace("{(m,o) for m in ('fixed','symbolic') for o in ('legacy','and_support')}","{(m,c) for m in ('fixed','symbolic') for c in ('bulk','dependency_closures')}")
s=s.replace("r['result_reader'] == 'interned' for r in index['schedule']","r['result_reader'] == 'interned' and r['search_ordering']=='and_support' for r in index['schedule']")
s=s.replace("role_schemas = index['review_role_schemas']",'''role_schemas = {
 'ordering_Source':dict(schema='and-support-ordering-components-typed-Source-review-v1', **{'pass':'source_review_passed'},reviewer='/root/receiver_driver_review'),
 'registry_Source':dict(schema='inventory-closure-registry-typed-Source-review-v1', **{'pass':'source_review_passed'},reviewer='/root/conventional_library'),
 'composition_Source':dict(schema='inventory-certification-driver-cold-typed-Source-review-v1', **{'pass':'source_review_passed'},reviewer='/root/conventional_library'),
 'once_Source':dict(schema='inventory-certification-once-typed-Source-review-v1', **{'pass':'source_review_passed'},reviewer='/root/conventional_control_review'),
 'prospective_plans':dict(schema='inventory-certification-prospective-plan-review-v1', **{'pass':'prospective_review_passed'},reviewer='/root/conventional_library')}
ck('exact five current review roles',set(index['current_review_roles'])==set(role_schemas))''')
s=s.replace("len(runner_plan) == len(worker_plan) == 18", "len(runner_plan) == len(worker_plan) == 19")
s=s.replace("auth['maximum_actual_invocations'] == draft_auth['maximum_actual_invocations'] == 1", "auth['maximum_actual_invocations'] == 1 and type(draft_auth['maximum_actual_invocations'])is int and draft_auth['maximum_actual_invocations']==0")
s=s.replace("for key in ('mode','search_ordering','model_storage'", "for key in ('mode','search_ordering','inventory_certification_mode','model_storage'")
s=s.replace("for key in ('invocation_id','mode','search_ordering','model_storage'", "for key in ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage'")
s=s.replace("'current four receipts'", "'current five receipts'")
s=s.replace("'composition_Source':[index['cold'],worker_plan['components']['receiver_driver']],", "'registry_Source':[runtime['project_sources']['semantic_inventory_oracle']],\n               'composition_Source':[index['cold'],worker_plan['components']['receiver_driver']],")
s=s.replace("subject = hashlib.sha256", "ck(tag+'18-field whole scientific subject',len({k:v for k,v in runner_plan.items() if k!='authorization'})==18)\n    subject = hashlib.sha256")
needle="    for key in ('mode','search_ordering','inventory_certification_mode','model_storage'"
pos=s.index(needle)
s=s[:pos]+'''    ck(tag+'only allowed false-to-true authorization changes',{k:v for k,v in auth.items() if k not in ('actual_execution_authorized','maximum_actual_invocations','review_roles','scope')}=={k:v for k,v in draft_auth.items() if k not in ('actual_execution_authorized','maximum_actual_invocations','review_roles','scope')} and draft_auth['review_roles']=={})
    ck(tag+'exact current new protocol schemas',runner_plan['schema']=='ROOT-inventory-certification-once-plan-v1' and worker_plan['schema']=='ROOT-inventory-certification-worker-plan-v1' and auth['schema']==draft_auth['schema']=='ROOT-inventory-certification-once-authorization-v1')
    dd=delta_rows[iid]
    ck(tag+'Root final delta independently recomputed joins',dd['whole_plan']==planrow['runner_plan'] and dd['whole_authorization']==planrow['authorization'] and dd['former_draft_maximum']==0 and dd['authorized_maximum']==1 and dd['subject_unchanged'] is True)
''' +s[pos:]
needle="    terminal_folder = Path(meta['terminal']['path']).parent"
s=s.replace(needle,'''    slot=PROGRESS/'launcher-slots'/iid
    slot_closed=load(slot/'CLOSED.json');slot_start=load(slot/'START.json')
    rawpin(pin(slot/'CLOSED.json'),tag+'full closed launcher slot')
    rawpin(pin(slot/'START.json'),tag+'full started launcher slot')
    ck(tag+'exact controller closed slot equals cohort record',slot_closed==cohort_rows[iid])
    ck(tag+'one explicit current observer command in launcher slot',slot_start['order']==planrow['order'] and slot_start['subject']==subject and slot_start['command']==[runner_plan['python']['path'],'-I','-S','-B',index['observer']['path'],planrow['runner_plan']['path']])
    '''+needle.strip())
needle="    ck(tag+'whole exact epoch checksum'"
s=s.replace(needle,"    ck(tag+'exact current epoch schema and factor',epoch['schema']=='semantic-family-receiver-source-epoch-v4-inventory-certification' and epoch['inventory_certification_mode']==result['inventory_certification_mode']==planrow['inventory_certification_mode'])\n"+needle)
needle="    for role, alias in role_modules.items():"
s=s.replace(needle,"    ck(tag+'all imported Z3 module paths among exact frozen41 files',all(entry['path'] in {z['path']for z in worker_plan['z3']['files']} for entry in worker['import_origins']if entry['module'].split('.')[0]=='z3'))\n"+needle)
needle="    ck(tag+'current compilation request count within512'"
start=s.index("        ck(tag+'native declared microstep cap '")
end=s.index(needle,start)
s=s[:start]+'''        expected_limit=1000000000 if record['purpose'].startswith('first_order_') else 5000000000
        if record['purpose']=='check_generated_lemma_definition_closure':
            expected_limit=5000000000-sum(r['result']['micro_steps'] for r in records[:j] if r['purpose']=='check_generated_lemma_definition_closure')
        ck(tag+'exact assigned original/remaining microstep cap '+str(j),type(stage['limit'])is int and stage['limit']==expected_limit and 0<stage['limit']<=5000000000)
        ck(tag+'reported microsteps within actually assigned cap '+str(j),type(record['result']['micro_steps'])is int and 0<=record['result']['micro_steps']<=stage['limit'])
    registry_records=[r for r in records if r['purpose'] in ('check_generated_lemma_definitions','check_generated_lemma_definition_closure')]
    ck(tag+'entire registration aggregate within unchanged5e9',sum(r['result']['micro_steps']for r in registry_records)<=5000000000)
    last=records[-1]
    for native_name,key in [('input.bin','input_sha256'),('output.bin','output_sha256')]:
        native_artifact=pin(actual/'native'/native_name);rawpin(native_artifact,tag+'last saved Native wire raw bytes only '+native_name)
        ck(tag+'last raw Native wire hash join '+native_name,native_artifact['sha256']==last[key])
    '''+s[end:]
s=s.replace("table = dict(invocation_id=iid, order=planrow['order'], mode=planrow['mode'], search_ordering=planrow['search_ordering'],", "table = dict(invocation_id=iid, order=planrow['order'], mode=planrow['mode'], search_ordering=planrow['search_ordering'], inventory_certification_mode=planrow['inventory_certification_mode'], receiver_id=planrow['receiver_id'],")
s=s.replace("native_queries=len(records), reader_decode_seconds", "native_queries=len(records), registration_queries=len(registry_records), registration_micro_steps=sum(r['result']['micro_steps']for r in registry_records), registration_last_status=registry_records[-1]['result']['status'], reader_decode_seconds")
s=s.replace("range(39)","range(19)")
start=s.index("ck('all40 outcomes retained")
s=s[:start]+'''ck('all20 outcomes retained with four positive flags and16 inventoryUNKNOWN',len(rows)==20 and sum(r['stored_native_proof_flag']for r in rows)==4 and sum(r['stored_status']=='unknown_native_inventory'for r in rows)==16 and all(r['receiver_id']=='prospective-fol-20261018-001' for r in rows if r['stored_native_proof_flag']))

phase_ranges={}
for row in rows:
    for phase,value in row['stage_seconds'].items():phase_ranges.setdefault(phase,[]).append(value)
summary=dict(retained_actuals=20,resource_profile_pass_count=20,stored_positive_candidates=4,stored_native_inventory_UNKNOWN=16,peak_sum_MiB_range=[min(r['conservative_peak_sum_MiB']for r in rows),max(r['conservative_peak_sum_MiB']for r in rows)],external_terminal_seconds_range=[min(r['external_terminal_seconds']for r in rows),max(r['external_terminal_seconds']for r in rows)],max_full_result_bytes=max(r['result_bytes']for r in rows),total_native_completed_requests=sum(r['native_queries']for r in rows),phase_ranges={k:dict(count=len(v),minimum=min(v),maximum=max(v))for k,v in phase_ranges.items()})
table_pin=write('twenty-result-resource-table-v1.json',dict(schema='inventory-certification-twenty-retained-resource-table-v1',rows=rows,summary=summary,saved_data_only=True,scientific_acceptance=False,cost_scope='Outer Source-entry through positive worker/output/Reader/known exit and final externally observed terminal; observer/interpreter prelude separately observed. Separate Darwin worker and Native highwaters are summed conservatively; outer/observer/controller RAM excluded.'))
audit_pin=write('raw-retained-resource-audit-v1.json',dict(schema='inventory-certification-retained-resource-audit-v1',source_only=True,saved_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,author_identity='/root',reviewer_identity='/root/conventional_control_review',index=pin(INDEX),cohort_closure=pin(closure_path),runtime_closure=index['runtime_closure'],design=index['design'],input_capsule=index['input_capsule'],case_declarations=index['case_declarations'],Root_final_grant_adoption=pin(adoption_path),Root_final_metadata_delta=pin(delta_path),current_reviews=index['current_review_roles'],check_count=len(checks),mismatch_count=0,checks=checks,unique_current_raw_pins_checked=list(pins_checked.values()),full_same_contexts=epoch_semantic_context,table=table_pin,scientific_or_native_decoding_performed=False))
print(json.dumps(dict(audit=audit_pin,table=table_pin,check_count=len(checks),mismatch_count=0,summary=summary),sort_keys=True,indent=2))
'''
out=Path('/private/tmp/gcts-inventory-certification-retained-resource-peer-20261018/audit_retained_resources_v1.py')
s=s.replace('all40','all20').replace('unique40','unique20').replace('exact18 runner/18 worker fields','exact19 runner/19 worker fields').replace('review roles exact current four receipts','review roles exact current five receipts')
s=s.replace("runtime = pinned_load(index['runtime_closure'], 'whole current runtime closure')", """runtime = pinned_load(index['runtime_closure'], 'whole current runtime closure')
parent_runtime=pinned_load(runtime['parent_closure'],'whole immutable previous-suite Source/runtime closure')
ck('only intended registry project replacement with same22 aliases',set(parent_runtime['project_sources'])==set(runtime['project_sources']) and [k for k in runtime['project_sources'] if runtime['project_sources'][k]!=parent_runtime['project_sources'][k]]==['semantic_inventory_oracle'])
ck('only receiver driver component changes, broker identical',set(runtime['additional_nonseed_components'])==set(parent_runtime['additional_nonseed_components']) and [k for k in runtime['additional_nonseed_components'] if runtime['additional_nonseed_components'][k]!=parent_runtime['additional_nonseed_components'][k]]==['receiver_driver'])
ck('unchanged Python/Z3/fixed Native dependency custody',runtime['runtime']==parent_runtime['runtime'] and runtime['Z3']==parent_runtime['Z3'] and runtime['fixed_native_inputs']==parent_runtime['fixed_native_inputs'])
""")
s=s.replace("    terminal_folder = Path(meta['terminal']['path']).parent", """    ck(tag+'exact three new retained receipt schemas',worker['schema']=='inventory-certification-worker-receipt-v1' and runner['schema']=='inventory-certification-external-once-receipt-v1' and terminal['schema']=='inventory-certification-final-terminal-observation-v1')
    ck(tag+'observer exact single current runner command',terminal['command']==[runner_plan['python']['path'],'-I','-S','-B',index['runner']['path'],planrow['runner_plan']['path']])
    terminal_folder = Path(meta['terminal']['path']).parent
    for filename in ['stdout.bin','stderr.bin']:
        rawpin(pin(terminal_folder/filename),tag+'whole observer log '+filename)
        rawpin(pin(slot/('observer-'+filename)),tag+'whole controller-captured observer log '+filename)
    observed_return=load(terminal_folder/'stdout.bin');controller_return=load(slot/'observer-stdout.bin')
    ck(tag+'outer stdout terminal outcome joins exact final receipt',observed_return['completion_within_overall'] is True and observed_return['exit_code']==0 and observed_return['runner_receipt']==meta['runner_receipt'])
    ck(tag+'controller captured observer terminal output',controller_return['exit_code']==0 and controller_return['terminal_gate_passed'] is True and controller_return['terminal']==meta['terminal']['path'])
""")
s=s.replace("    for name, descriptor in epoch['native_inputs'].items():", """    ck(tag+'whole original policy and current result policy checksum',epoch['policy']==worker_plan['policy'] and result['policy_pin']=={k:worker_plan['policy'][k]for k in ('sha256','bytes')})
    rawpin(worker_plan['policy'],tag+'complete unchanged four-template policy raw Source')
    ck(tag+'complete Native input map unchanged apart from charged perarm codebin',{k:v for k,v in epoch['native_inputs'].items() if k!='code_bin'}==worker_plan['native_inputs'] and set(epoch['native_inputs'])==set(worker_plan['native_inputs'])|{'code_bin'})
    ck(tag+'perarm encoded fixedNative table path exactly owned',epoch['native_inputs']['code_bin']['path']==str(actual/'native'/'code.bin'))
    for name, descriptor in epoch['native_inputs'].items():""")
out.write_text(s)
compile(s,str(out),'exec')
print(out)
