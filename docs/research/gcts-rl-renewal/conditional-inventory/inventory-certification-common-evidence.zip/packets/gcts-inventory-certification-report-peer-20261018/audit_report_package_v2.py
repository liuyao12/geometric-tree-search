from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import collections,gc,gzip,hashlib,json,re

D=Path('/private/tmp/gcts-inventory-certification-report-peer-20261018')
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/inventory-certification-progress-20261018')
PUB=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
CP=Path('/private/tmp/gcts-and-support-comparison-peer-20261018/retained-comparison-data-v1.json')
checks=[];counts=collections.Counter()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def ck(n,x,detail=None):
 checks.append(dict(check=n,passed=bool(x),detail=detail))
 if not x:raise AssertionError(n)
def emit(n,v):
 p=D/n;p.write_text(json.dumps(v,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n');return desc(p)
class Node:
 def __init__(self,t='root',a=None):self.tag=t;self.attrs=dict(a or []);self.children=[]
 def text(self):return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
 def nodes(self):
  yield self
  for c in self.children:
   if isinstance(c,Node):yield from c.nodes()
 def find(self,tag=None,cls=None):return [n for n in self.nodes() if (tag is None or n.tag==tag) and (cls is None or cls in n.attrs.get('class','').split())]
 def direct(self,tag):return [c for c in self.children if isinstance(c,Node) and c.tag==tag]
class DOM(HTMLParser):
 void={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
 def __init__(self,text):
  super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(text);self.close()
 def handle_starttag(self,t,a):
  n=Node(t,a);self.stack[-1].children.append(n)
  if t not in self.void:self.stack.append(n)
 def handle_startendtag(self,t,a):self.stack[-1].children.append(Node(t,a))
 def handle_endtag(self,t):
  for j in range(len(self.stack)-1,0,-1):
   if self.stack[j].tag==t:self.stack=self.stack[:j];return
 def handle_data(self,data):self.stack[-1].children.append(data)
def mathword(n):
 s=n.text().strip();ck('MathJax inline delimiters',s.startswith('\\(') and s.endswith('\\)'));return s[2:-2]
# A restricted reader of displayed TeX, not a formula generator or proof checker.
# It only parses the actual forall/imp/predicate/variable notation in these saved pages.
def parse_formula(tex):
 tex=tex.replace('\\left','').replace('\\right','').replace('\\;','')
 toks=re.findall(r'\\forall|\\Rightarrow|\\rightarrow|[A-Za-z]+|[(),]',tex)
 if ''.join(toks)!=re.sub(r'\s+','',tex):raise ValueError('unexpected displayed formula token: '+tex)
 at=0
 def get():
  nonlocal at
  x=toks[at];at+=1;return x
 def atom():
  x=get()
  if x=='\\forall':
   variable=get();return ['all',variable,atom()]
  if x=='(':
   f=expr()
   if get()!=')':raise ValueError('display formula parenthesis')
   return f
  if x not in ('P','Q','R') or get()!='(':raise ValueError('display predicate syntax')
  args=[]
  if toks[at]!=')':
   while True:
    args.append(['var',get()])
    if toks[at]!=',':break
    get()
  if get()!=')':raise ValueError('display term parenthesis')
  return ['pred',x,args]
 def expr():
  f=atom()
  if at<len(toks) and toks[at] in ('\\Rightarrow','\\rightarrow'):
   get();f=['imp',f,expr()]
  return f
 f=expr()
 if at!=len(toks):raise ValueError('trailing display formula')
 return f

def labeled_pre(node,label):
 result=[]
 for d in node.find('details'):
  s=d.direct('summary')
  if s and s[0].text()==label:
   p=d.direct('pre');ck('one literal pre for '+label,len(p)==1);result.append(json.loads(p[0].text()))
 ck('exact one '+label,len(result)==1);return result[0]
def leading_nodes(cell):
 out=[]
 for x in cell.children:
  if isinstance(x,Node) and x.tag=='details':break
  out.append(x)
 return out
def lead_text(cell):return ''.join(x if isinstance(x,str) else x.text() for x in leading_nodes(cell))
def lead_find(cell,tag):return [n for x in leading_nodes(cell) if isinstance(x,Node) for n in x.nodes() if n.tag==tag]
def tbody_rows(table):return table.direct('tbody')[0].direct('tr')
def formula_spans(node):return node.find('span','sr-math')
def check_table(table,lines,premises,definitions,labels,ess,scope,label):
 rows=tbody_rows(table);ck(label+' full row count',len(rows)==len(lines))
 for j,(tr,cmd) in enumerate(zip(rows,lines)):
  counts['displayed_proof_rows']+=1
  cells=tr.direct('td');ck(label+str(j)+' three cells',len(cells)==3)
  ck(label+str(j)+' exact row ID',tr.attrs['id']==scope+'-line-'+str(j))
  ck(label+str(j)+' one-based display',cells[0].children[0]==str(j+1))
  ck(label+str(j)+' retained essential highlight',('sr-essential' in tr.attrs.get('class','').split())==(j in ess))
  ff=formula_spans(cells[1]);ck(label+str(j)+' one formula',len(ff)==1)
  ck(label+str(j)+' literal formula LaTex AST',canon(parse_formula(mathword(ff[0])))==canon(cmd['formula']))
  ck(label+str(j)+' full literal command',canon(labeled_pre(tr,'Literal command'))==canon(cmd))
  english=lead_text(cells[2]);links=lead_find(cells[2],'a');rule=cmd['rule']
  if rule=='axiom':ck(label+str(j)+' English AX name',english=='Use the given theory premise '+cmd['name']+'.')
  elif rule=='instantiate':
   ck(label+str(j)+' English UI licence',english.startswith('Introduce the universal-instantiation license for ') and english.endswith('.') and ' at term ' in english)
   m=[x for x in lead_find(cells[2],'span') if 'sr-math' in x.attrs.get('class','').split()]
   ck(label+str(j)+' English actual UI universal/term',len(m)==2 and canon(parse_formula(mathword(m[0])))==canon(cmd['universal']) and canon(parse_term(mathword(m[1])))==canon(cmd['term']))
   ck(label+str(j)+' no fabricated UI prior read',links==[])
  elif rule=='generalize':
   ck(label+str(j)+' English actual GEN source',[x.attrs['href'] for x in links]==['#'+scope+'-line-'+str(cmd['source'])] and english.startswith('Universally generalize line '+str(cmd['source']+1)+' in ') and 'native checker supplies the scope side condition.' in english)
   m=[x for x in lead_find(cells[2],'span') if 'sr-math'in x.attrs.get('class','').split()];ck(label+str(j)+' exact GEN variable',len(m)==1 and mathword(m[0])==cmd['variable'])
  elif rule=='mp':ck(label+str(j)+' English ordered MP reads',[x.attrs['href'] for x in links]==['#'+scope+'-line-'+str(cmd['implication']),'#'+scope+'-line-'+str(cmd['antecedent'])] and english=='Apply the implication on line '+str(cmd['implication']+1)+' to line '+str(cmd['antecedent']+1)+'.')
  elif rule=='assumption':
   ck(label+str(j)+' English exact assumption port',english.startswith('Use local input '+str(cmd['index']+1)+', whose declared formula is '))
   m=[x for x in lead_find(cells[2],'span') if 'sr-math'in x.attrs.get('class','').split()];ck(label+str(j)+' exact assumption formula',len(m)==1 and canon(parse_formula(mathword(m[0])))==canon(premises[cmd['index']]))
  elif rule=='block':
   target=labels[cmd['name']]
   ck(label+str(j)+' English exact block/ordered sources',[x.attrs['href'] for x in links]==['#'+target]+['#'+scope+'-line-'+str(i) for i in cmd['inputs']] and english.endswith(', in the recorded port order.'))
   details=[n for n in tr.find('details') if n.direct('summary') and n.direct('summary')[0].text()=='Ordered lemma input ports'];ck(label+str(j)+' ordered port table present',len(details)==1)
   portrows=tbody_rows(details[0].find('table')[0]);ps=definitions[cmd['name']]['premises'];ck(label+str(j)+' exact complete port count',len(portrows)==len(cmd['inputs'])==len(ps))
   for port,(pr,source,premise) in enumerate(zip(portrows,cmd['inputs'],ps)):
    cc=pr.direct('td');ck(label+str(j)+' port'+str(port)+' exact ordinal/index',cc[0].text()==str(port+1) and cc[1].find('a')[0].attrs['href']=='#'+scope+'-line-'+str(source))
    ck(label+str(j)+' port'+str(port)+' declared and actual formula',canon(parse_formula(mathword(formula_spans(cc[2])[0])))==canon(premise) and canon(parse_formula(mathword(formula_spans(cc[3])[0])))==canon(lines[source]['formula']))
    counts['ordered_port_rows']+=1
  elif rule=='tautology':ck(label+str(j)+' exact English tautology',english=='Use a propositional tautology, as named by this recorded rule.' and links==[])
  elif rule=='refl':ck(label+str(j)+' exact English reflexivity',english=='Introduce equality of a term with itself.' and links==[])
  elif rule=='eq_subst':
   ck(label+str(j)+' English equality licence',english.startswith('Introduce the equality-substitution license with placeholder ') and ' and formula context ' in english and links==[])
   m=[x for x in lead_find(cells[2],'span') if 'sr-math' in x.attrs.get('class','').split()]
   ck(label+str(j)+' exact equality placeholder/context',len(m)==2 and parse_name(mathword(m[0]))==cmd['variable'] and canon(parse_formula(mathword(m[1])))==canon(cmd['template']))
  else:raise ValueError('unexpected recorded rendered rule '+rule)

# Independent limited displayed-TeX reader, using literal declaration signatures.
FUNS={};PREDS={}
def tokens(tex):
 text=tex.replace('\\left','').replace('\\right','').replace('\\;','').replace('\\,','')
 text=re.sub(r'\\operatorname\{([A-Za-z][A-Za-z0-9]*)\}',lambda m:m.group(1),text)
 ts=re.findall(r'\\forall|\\Rightarrow|\\rightarrow|\\neg|\\land|\\lor|\\bot|[A-Za-z][A-Za-z0-9]*|[(),=]',text)
 if ''.join(ts)!=re.sub(r'\s+','',text):raise ValueError('unhandled literal display token '+text)
 return ts
class FormulaReader:
 def __init__(self,ts):self.ts=ts;self.i=0
 def peek(self):return self.ts[self.i]if self.i<len(self.ts)else None
 def get(self):x=self.peek();self.i+=1;return x
 def expect(self,x):
  if self.get()!=x:raise ValueError('display expected '+x)
 def term_after_name(self,name):
  args=[]
  if self.peek()=='(':
   self.get()
   if self.peek()!=')':
    while True:
     args.append(self.term())
     if self.peek()!=',':break
     self.get()
   self.expect(')')
  if name in FUNS:return ['fun',name,args]
  if args:raise ValueError('undeclared displayed function '+name)
  return ['var',name]
 def term(self):return self.term_after_name(self.get())
 def atom(self):
  x=self.get()
  if x=='\\forall':return ['all',self.get(),self.atom()]
  if x=='\\neg':return ['not',self.atom()]
  if x=='\\bot':return ['bot']
  if x=='(':
   f=self.expr();self.expect(')');return f
  if x in PREDS:
   args=[]
   if self.peek()=='(':
    self.get()
    if self.peek()!=')':
     while True:
      args.append(self.term())
      if self.peek()!=',':break
      self.get()
    self.expect(')')
   return ['pred',x,args]
  lhs=self.term_after_name(x);self.expect('=');return ['eq',lhs,self.term()]
 def expr(self):
  f=self.atom()
  if self.peek()in('\\Rightarrow','\\rightarrow','\\land','\\lor'):
   op=self.get();f=[{'\\Rightarrow':'imp','\\rightarrow':'imp','\\land':'and','\\lor':'or'}[op],f,self.expr()]
  return f
 def finish(self,kind):
  v=self.expr()if kind=='formula'else self.term()
  if self.i!=len(self.ts):raise ValueError('trailing display tokens')
  return v
def parse_formula(tex):return FormulaReader(tokens(tex)).finish('formula')
def parse_term(tex):return FormulaReader(tokens(tex)).finish('term')
def parse_name(tex):
 ts=tokens(tex)
 if len(ts)!=1:raise ValueError('displayed name must be singular')
 return ts[0]
def statement(tex):
 left,right=tex.split('\\vdash');left=left.strip().replace('\\;','').strip()
 if not left.startswith('\\{')or not left.endswith('\\}'):raise ValueError('statement premise braces')
 left=left[2:-2];parts=[];depth=0;start=0
 for i,c in enumerate(left):
  if c=='(':depth+=1
  elif c==')':depth-=1
  elif c==','and depth==0:parts.append(left[start:i]);start=i+1
 parts.append(left[start:]);return [parse_formula(p)for p in parts if p.strip()],parse_formula(right)

import zipfile
M=json.loads((ROOT/'ROOT-report-draft-assets-v1.json').read_bytes());refine=json.loads((ROOT/'ROOT-report-text-refinement-v1.json').read_bytes())
ck('current report heading successor',desc(PUB/'inventory-certification.html')==refine['after'] and refine['before']==M['report'])
assetpins=[]
for p in M['assets']:
 actual=desc(p['path']);assetpins.append(actual)
 if Path(p['path']).name not in ['inventory-certification.html','reader.html']:ck('whole frozen asset '+Path(p['path']).name,actual==p)
records={r['invocation_id']:{**r,'raw_result':r['result']}for r in json.loads(Path('/private/tmp/gcts-inventory-certification-retained-data-peer-20261018/raw-data-audit-v1.json').read_bytes())['current']}
main=(PUB/'inventory-certification.html').read_text();md=DOM(main).root;summary=json.loads((PUB/'inventory-certification-summary.json').read_bytes());admission=json.loads((PUB/'inventory-certification-admission.json').read_bytes());capsule=json.loads((PUB/'inventory-certification-inputs.json').read_bytes());specs={s['id']:s for s in capsule['receivers']};ar={r['invocation_id']:r for r in admission['actuals']}
ck('full public20 admission literalcopy',canon(summary['actuals'])==canon(admission['actuals']) and len(ar)==20)
ck('exact20 outcome summary',summary['total_actuals']==20 and summary['proof_instances']==4 and summary['bulk_space_stops']==summary['closure_work_stops']==8 and summary['newly_solved_inputs']==0 and summary['all_within_profile']is True and summary['new_RL_training']is False)
for pub,original in [('inventory-certification-admission.json',ROOT/'ROOT-actual-admission-v1.json'),('inventory-certification-design.json',ROOT/'prospective-design-v1.json'),('inventory-certification-runtime-closure.json',ROOT/'runtime-closure-v1.json'),('inventory-certification-inputs.json',Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/first-order-suite-progress-20261018/input-capsule-v1.json'))]:ck('whole literal publiccopy '+pub,(PUB/pub).read_bytes()==original.read_bytes())
# All20 cost rows from independent data and admitted external resource records.
costs=next(n for n in md.nodes()if n.attrs.get('id')=='costs');tables=costs.find('table');ck('exact2 cost tables',len(tables)==2);trs=tbody_rows(tables[1]);ck('all20 measured rows',len(trs)==20)
ordered=[records[x['invocation_id']]for x in admission['actuals']]
for tr,r in zip(trs,ordered):
 rr=ar[r['invocation_id']];cs=[c for c in tr.children if isinstance(c,Node)and c.tag in('th','td')];ss=[x.text()for x in cs];arm=('GCTS'if r['mode']=='fixed'else'Symbolic')+' · '+('bulk'if r['inventory_certification_mode']=='bulk'else'closures');status='Proof'if r['positive']else'Space cap'if r['last_result_status']=='unknown_space_budget'else'Work cap'
 ck(r['invocation_id']+' exact rowidentity/outcome',ss[0]=='\('+str(rr['order'])+'\)'and ss[1]==r['receiver_id'][-3:]+' '+arm and ss[2]==status)
 n=str(r['registration_micro_steps']);formatted='\('+('\,'.join([n[max(0,len(n)-3*k-3):len(n)-3*k]for k in range((len(n)+2)//3)][::-1]))+'\)';ck(r['invocation_id']+' exact registration steps',ss[3]==formatted)
 stage=next(x for x in r['stage_intervals']if x['stage']=='register');seconds=stage['returned_monotonic']-stage['started_monotonic'];ck(r['invocation_id']+' full registration interval',ss[4]=='\('+format(seconds,'.3f')+'\)')
 ck(r['invocation_id']+' admitted terminal/memory figures',ss[5]=='\('+format(rr['outer_terminal_seconds'],'.3f')+'\)'and ss[6]=='\('+format(rr['peak_sum_MiB'],'.1f')+'\)')
 ck(r['invocation_id']+' exact rawdownload',cs[7].find('a')[0].attrs['href']==M['raw_downloads'][r['invocation_id']])
 display=summary['certificate_display'][r['invocation_id']];ck(r['invocation_id']+' actual issued vs planned closure',display['actual_max_closure_definitions']==r['queried_closure_max'] and display['planned_max_closure_definitions']==(r['planned_closure_max']if r['inventory_certification_mode']=='dependency_closures'else r['definitions']))
# Every inventory-size row checks actual request bytes and accepted-prefix counts.
size_rows=tbody_rows(tables[0]);ck('five inventory rows',len(size_rows)==5)
for tr in size_rows:
 cells=[c for c in tr.children if isinstance(c,Node)and c.tag in('th','td')];rid='prospective-fol-20261018-'+cells[0].text();batch=next(x for x in ordered if x['receiver_id']==rid and x['inventory_certification_mode']=='dependency_closures');bulk=next(x for x in ordered if x['receiver_id']==rid and x['inventory_certification_mode']=='bulk');b=json.loads(Path(batch['result']['path']).read_bytes());q=json.loads(Path(bulk['result']['path']).read_bytes());requests=[b['records'][x['query']]['request']for x in b['outputs']['register']['certification']['receipts']];largest=max(len(canon(x))for x in requests);bulkbytes=len(canon(q['records'][q['outputs']['register']['query']]['request']))
 def num(x):return '\('+format(x,',').replace(',','\,')+'\)'
 ck(rid+' exact size/prefix/formatted table',[x.text()for x in cells[1:]]==[num(batch['definitions']),num(bulkbytes),num(largest),num(batch['accepted_definitions'])+' of '+num(batch['definitions']),num(batch['registration_queries'])+' of '+num(batch['definitions']),num(batch['queried_closure_max'])+' actual / '+num(batch['planned_closure_max'])+' planned']);del b,q
# Five statements and20 matrix entries.
mt=md.find('table','matrix')[0];mrs=tbody_rows(mt);ck('five matrix cases',len(mrs)==5)
for tr in mrs:
 cells=[c for c in tr.children if isinstance(c,Node)and c.tag in('th','td')];case=cells[0].find('a')[0].attrs['href'][1:];rid='prospective-fol-20261018-'+case[-3:];node=next(n for n in md.nodes()if n.attrs.get('id')==case);spec=specs[rid];FUNS=spec['theory']['functions'];PREDS=spec['theory']['predicates'];tex=re.search(r'\\\[(.*?)\\\]',node.text(),re.S).group(1);ps,target=statement(tex);ck(case+' complete literal assertion',canon(ps)==canon(list(spec['theory']['axioms'].values()))and canon(target)==canon(spec['target']))
 for cell,(mode,cert)in zip(cells[1:],[('fixed','bulk'),('fixed','dependency_closures'),('symbolic','bulk'),('symbolic','dependency_closures')]):
  r=next(x for x in ordered if x['receiver_id']==rid and x['mode']==mode and x['inventory_certification_mode']==cert);expected='Proof'if r['positive']else'Space cap'if cert=='bulk'else'Work cap';ck(case+mode+cert+' exact matrix outcome',cell.text()==expected)
# All20 gzip inverses (ordinary report data only; no Native gzip decoding).
gzipdetails=[]
for iid,name in M['raw_downloads'].items():
 raw=Path(records[iid]['raw_result']['path']).read_bytes();packed=(PUB/name).read_bytes();unpacked=gzip.decompress(packed);ck(iid+' gzip preserves entire ordinary result bytes',unpacked==raw);gzipdetails.append(dict(invocation_id=iid,gzip=desc(PUB/name),raw=records[iid]['raw_result'],uncompressed_bytes=len(raw)))
proof_details=[]
for iid,name in M['proof_readers'].items():
 pr={'invocation_id':iid,'file':name}
 r=records[pr['invocation_id']];name=pr['file'];html=(PUB/name).read_text();dom=DOM(html).root;data=json.loads(Path(r['raw_result']['path']).read_bytes());spec=data['declaration'];FUNS=spec['theory']['functions'];PREDS=spec['theory']['predicates'];proof=data['outputs']['search']['proof'];inventory=data['outputs']['register'];ob=data['outputs']['essential_ancestry'];model=data['outputs']['model'];search=data['outputs']['search'];defs={d['name']:d for d in inventory['native_blocks']};metas={d['name']:d for d in inventory['definitions']};sections=dom.find('details','sr-definition');labels={};by_definition={}
 ck(name+' allcompletebodies',len(sections)==len(defs))
 for sec in sections:
  packet=labeled_pre(sec,'Literal registered definition and metadata');dn=packet['definition']['name'];labels[dn]=sec.attrs['id'];by_definition[dn]=sec
  ck(name+dn+' fullbodymetadata',canon(packet['definition'])==canon(defs[dn])and canon(packet['metadata'])==canon(metas[dn]))
  ck(name+dn+' summaryconclusion',canon(parse_formula(mathword(formula_spans(sec.direct('summary')[0])[0])))==canon(defs[dn]['conclusion']))
 ck(name+' allnamesdistinct',set(labels)==set(defs))
 rt=dom.find('table','sr-proof')[0];scope=tbody_rows(rt)[0].attrs['id'].rsplit('-line-',1)[0]
 check_table(rt,proof,[],defs,labels,set(ob['root']['essential_rows']),scope,name+' root ')
 for dn,sec in by_definition.items():
  ts=sec.find('table','sr-proof');ck(name+dn+' fulltablepresent',len(ts)==1)
  check_table(ts[0],defs[dn]['proof'],defs[dn]['premises'],defs,labels,set(ob['ground_definition_summaries'][dn]['essential_rows']),sec.attrs['id'],name+' '+dn+' ');counts['registered_bodies']+=1
 tiles=dom.find('details','sr-tile');rs=dom.find('div','sr-tile-row');expected_points=len(proof)*(2+model['arity']);ck(name+' actualderivedtilesrows',len(tiles)==expected_points and len(rs)==len(proof)==12)
 indexed={tuple(p['key']):p for p in model['placements']};selected={tuple(k)for k in search['placements']};seen=set();numeric=0
 for tile in tiles:
  packet=labeled_pre(tile,'Full selected placement packet');key=tuple(packet['key']);candidate=indexed[key];seen.add(key);ck(name+str(key)+' fullactualpacket',key in selected and canon(packet)==canon(candidate));title='C'if key[1]==0 else'G'if key[1]==1 else'I'+str(key[1]-1);ck(name+str(key)+' glyphrole',tile.direct('summary')[0].find('strong')[0].text()==title and tile.find('svg')[0].attrs['aria-label']=='Schematic point placement '+title);color='#2865a5'if key[1]==0 else'#8b52a5'if key[1]==1 else'#b5771a';ck(name+str(key)+' glyphcolor',tile.find('svg')[0].find('rect')[0].attrs['stroke']==color)
  trs=tbody_rows(tile.direct('table')[0]);wanted=[('base occupancy',p,v,'')for p,v in candidate['occupancy']]
  for p,v in candidate['marks']:
   x,y=p;layer,color=('formula','#25845b')if x%4==0 and y>=100 else('command','#2865a5')if x%4==1 and y>=100 else('mode','#8b52a5')if x%4==2 and y==90 else('source','#b5771a')if x%4==2 and y>=100 else('other','#60717e');wanted.append((layer+' marking',p,v,color))
  glyph=tile.find('svg')[0];circles=glyph.find('circle');layercounts=collections.Counter(layer.replace(' marking','') for layer,p,v,color in wanted if layer!='base occupancy');colored={layer.replace(' marking',''):color for layer,p,v,color in wanted if layer!='base occupancy'}
  ck(name+str(key)+' center glyph color',circles[0].attrs['fill']==('#2865a5'if key[1]==0 else'#8b52a5'if key[1]==1 else'#b5771a'))
  ck(name+str(key)+' complete layer summary dots',len(circles)==1+len(layercounts))
  for circle,(layer,num) in zip(circles[1:],sorted(layercounts.items())):ck(name+str(key)+' SVG exact summary '+layer,circle.attrs['fill']==colored[layer] and circle.find('title')[0].text()==layer+': '+str(num)+' point assignments')
  ck(name+str(key)+' entiret_mrowcount',len(trs)==len(wanted))
  for tr,(layer,p,v,color)in zip(trs,wanted):
   cc=tr.direct('td');point='('+','.join(map(str,p))+')';value=str(v)+'/12'if layer=='base occupancy'else str(v);ck(name+str(key)+str(p)+' exactpointvalue',cc[0].text()==layer and mathword(formula_spans(cc[1])[0])==point and mathword(formula_spans(cc[2])[0])==value)
   if color:ck(name+str(key)+str(p)+' markinglayercolor',cc[0].find('span')[0].attrs['style']=='background:'+color)
   numeric+=1
  if candidate['kind']=='lemma_input':ck(name+str(key)+' exactsourceEnglish','Reads root line '+str(candidate['source']+1)+'.'in tile.text())
  if candidate['kind']=='unused_input':ck(name+str(key)+' literalunusedsentinel','Unused input filler; its source sentinel is 'in tile.text())
  counts['selected_tiles']+=1
 ck(name+' noneomittedduplicated',seen==selected and len(seen)==len(tiles));counts['point_value_rows']+=numeric
 ck(name+' pointglyphlimits','square is a display glyph'in html and'No rotation'in html and'12/12=1'in html)
 ck(name+' exactrawdownload',name.replace('-proof.html','-result.json.gz')in html)
 proof_details.append({'file':name,'invocation_id':r['invocation_id'],'root_rows':len(proof),'registered_bodies':len(defs),'lemma_rows':sum(len(x['proof'])for x in defs.values()),'tiles':len(tiles),'point_value_rows':numeric,'arity':model['arity']})
 print('DISPLAY CHECKED',name,flush=True);del data,model,dom;gc.collect()

# Five case archives, every raw member, no opaque Native interpretation.
archiveindex=ROOT/'ROOT-case-archive-assets-v1.json';ai=json.loads(archiveindex.read_bytes());archivedetails=[]
for item in ai['archives']:
 ck(item['receiver_id']+' whole archivepin',desc(item['archive']['path'])==item['archive']);members=item['members'];ck(item['receiver_id']+' complete164rawmembers',len(members)==item['raw_member_count']==164)
 with zipfile.ZipFile(item['archive']['path'])as z:
  ck(item['receiver_id']+' exact archive members no duplicates',len(z.namelist())==len(set(z.namelist()))==165 and set(z.namelist())=={m['member']for m in members}|{'MANIFEST.json'})
  manifest=json.loads(z.read('MANIFEST.json'));ck(item['receiver_id']+' complete internal manifest',manifest['members']==members and manifest['complete_raw_results']is True and manifest['all_four_actuals']is True and manifest['opaque_Native_decodes']==0)
  total=0
  for m in members:
   original=Path(m['path']).read_bytes();inside=z.read(m['member']);ck('archive complete raw member '+m['member'],inside==original and len(inside)==m['bytes'] and hashlib.sha256(inside).hexdigest()==m['sha256']);total+=len(inside);counts['archive_raw_members']+=1
  ck(item['receiver_id']+' complete raw archive bytecount',total==item['raw_bytes'])
 archivedetails.append(dict(archive=item['archive'],receiver_id=item['receiver_id'],raw_members=len(members),raw_bytes=total))
# Local anchors; pending common archive/manifest/review copies are explicit.
page_names=['inventory-certification.html','reader.html','first-order-suite.html']+list(M['proof_readers'].values());doms={n:DOM((PUB/n).read_text()).root for n in page_names};ids={n:{x.attrs['id']for x in dom.nodes()if'id'in x.attrs}for n,dom in doms.items()};pending={'inventory-certification-common-evidence.zip','inventory-certification-evidence-manifest.json'}|{'inventory-certification-'+x+'-review.json'for x in ['data','resource','report']};links=[]
for name,dom in doms.items():
 values=[x.attrs['id']for x in dom.nodes()if'id'in x.attrs];ck(name+' unique HTMLIDs',len(values)==len(set(values)));ck(name+' MathJaxloaded',any(x.tag=='script'and x.attrs.get('src')=='https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js'for x in dom.nodes()))
 ck(name+' noUnicode mathsubstitution',not any(c in(PUB/name).read_text()for c in ['∀','⇒','⊢','∧','∈']))
 for a in dom.find('a'):
  u=urlsplit(a.attrs.get('href',''))
  if u.scheme or u.netloc:continue
  target=u.path or name
  if target in pending:links.append(dict(page=name,href=a.attrs['href'],status='PENDING_FINALIZATION'));continue
  if target in ids and u.fragment:ck(name+' exact anchor '+a.attrs['href'],u.fragment in ids[target])
  if target.startswith('inventory-cert')or(name!='reader.html'and target in page_names):ck(name+' localfile '+a.attrs['href'],(PUB/target).is_file())
for name in M['proof_readers'].values():ck(name+' correct experiment navigation',[x.attrs['href']for x in doms[name].find('nav')[0].find('a')]==['reader.html#inventory-certification','inventory-certification.html#outcomes','inventory-certification.html#costs','inventory-certification.html#proofs','inventory-certification.html#evidence'])
# Additive dated historical changes; old statistics remain exact literal bytes.
old40=(ROOT/'publication-baselines/first-order-suite.html').read_text();now40=(PUB/'first-order-suite.html').read_text();banner=re.search(r'<p class="band">Later inventory-certification experiment:.*?</p>',now40).group(0);ck('old40 exact after only new dated banner',now40.replace(banner,'',1)==old40)
oldreader=(ROOT/'publication-baselines/reader.html').read_text();newreader=(PUB/'reader.html').read_text();card=re.search(r'<section id="inventory-certification">.*?</section>',newreader,re.S).group(0);withoutcard=newreader.replace(card,'',1);label_changed=False
if withoutcard!=oldreader:
 oldlabel=re.search(r'<section id="first-order-suite"><p class="eyebrow">(.*?)</p>',oldreader).group(1);newlabel=re.search(r'<section id="first-order-suite"><p class="eyebrow">(.*?)</p>',withoutcard).group(1);withoutcard=withoutcard.replace(newlabel,oldlabel,1);label_changed=True
ck('reader older bodies/stats rawexact after currentcard and optional historicaleyebrow only',withoutcard==oldreader)
readerstatus=next(n for n in doms['reader.html'].nodes()if n.attrs.get('id')=='first-order-suite').find('p','eyebrow')[0].text();reader_label_finding='LATEST MEASURED COHORT'in readerstatus
ck('current card truthful summary',all(s in card for s in ['LATEST CHECKER','twenty','four admitted','No new theorem']))
ck('main exactscope caveats',all(s in main for s in ['Every actual closure request','three definitions','before those recursive requests','no completed bulk check','rather than a general cost law','known-outcome engineering cohort','correlated','Twenty once-only sequential runs','no new RL','not a simultaneous live peak','12','30','5\,000','no implementation','No new theorem']))
ck('immutable pure renderer Source pin only',desc(M['pure_renderer']['path'])==M['pure_renderer'])
result=dict(schema='inventory-certification-human-package-raw-audit-v1',saved_data_only=True,scientific_replays=0,scientific_calls=0,Native_gzip_decodes=0,renderer_executions=0,draft_assets=desc(ROOT/'ROOT-report-draft-assets-v1.json'),heading_refinement=desc(ROOT/'ROOT-report-text-refinement-v1.json'),current_assets=assetpins,checks=checks,counts=dict(counts),proof_details=proof_details,gzipdetails=gzipdetails,archives=archivedetails,archive_index=desc(archiveindex),pending_links=links,reader_label_finding=reader_label_finding,reader_label_changed=label_changed,summary=dict(checks=len(checks),mismatches=sum(not x['passed']for x in checks)))
p=D/'raw-report-package-audit-v2.json';p.write_text(json.dumps(result,indent=2,ensure_ascii=False)+chr(10));print('DONE',json.dumps(dict(audit=desc(p),counts=dict(counts),reader_label_finding=reader_label_finding,checks=len(checks))),flush=True)
