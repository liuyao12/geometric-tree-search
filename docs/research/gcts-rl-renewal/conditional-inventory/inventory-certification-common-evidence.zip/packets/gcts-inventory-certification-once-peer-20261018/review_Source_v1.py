"""Independent raw/AST review only. Never import or evaluate a reviewed Source."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

OUT=Path('/private/tmp/gcts-inventory-certification-once-peer-20261018')
NEW=Path('/private/tmp/gcts-inventory-certification-intake-ROOT-source-20261018')
OLD=Path('/private/tmp/gcts-first-order-suite-intake-source-20261018')
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
OUT.mkdir(exist_ok=True)
checks=[]
def check(name, ok, evidence=None):
    checks.append(dict(id=name,passed=bool(ok),evidence=evidence))
def pin(path):
    path=Path(path).resolve(); raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def load(path): return json.loads(Path(path).read_bytes())
def dump(tree): return ast.dump(tree,include_attributes=False)
def region(text,node): return ''.join(text.splitlines(True)[node.lineno-1:node.end_lineno])
def functions(tree): return {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def constants(tree):
    result={}
    for n in tree.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            try: result[n.targets[0].id]=ast.literal_eval(n.value)
            except (ValueError,TypeError): pass
    return result
def contains(text, needle): return needle in text
def check_pin(desc,label): check('pin:'+label,pin(desc['path'])==desc,desc)
def replace(text,old,new,count=1):
    check('normalization-count:'+str(len(checks)),text.count(old)==count,dict(old=old,count=text.count(old),expected=count))
    return text.replace(old,new)

hpath=NEW/'intake-Source-handoff-v1.json'; h=load(hpath)
check('handoff-fixed-pin',pin(hpath)==dict(path=str(hpath),sha256='4485aa9d52e5e591cb607c39257d35652ce66e6ffac25ce7d0b6343239b9c0a9',bytes=2965))
for key in ('runner','observer','cold','driver','registry','source_contract','parent_closure'): check_pin(h[key],key)
for key,desc in h['parent_sources'].items(): check_pin(desc,'parent:'+key)
check('handoff-Source-only',h['source_only'] is True and h['scientific_calls']==0 and h['module_evaluations']==0 and h['actual_execution_authorized'] is False)
master=ROOT/'docs/basic-tiling-algorithm.md'
check('master-current',pin(master)['sha256']=='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9')

peer_paths=[
 Path('/private/tmp/gcts-first-order-suite-once-peer-20261018/typed-Source-review-v1.json'),
 Path('/private/tmp/gcts-and-support-once-peer-20261018/typed-Source-review-v1.json'),
 Path('/private/tmp/gcts-compact-model-cold-once-independent-peer-20261018/typed-Source-review-v2.json')]
peer_shas=['9639f8aebdced55d55e549e89582da15bc942c5fe1e96ccdfe99f07649a76d9c','4f05d69a2c09cb1594355ba96748f1fef0db0d39914c9b351f0a072cf3fb63e6','d1fed0448738dbe07efbd2482a6259dc58ecf21473a3cbf46bf09e61a242d4a2']
for path,sha in zip(peer_paths,peer_shas):
    p=load(path);check('genuine-ancestry:'+path.parent.name,pin(path)['sha256']==sha and p['source_review_passed'] is True and p['scientific_calls']==0)
check('genuine-grandparent-distinct',load(peer_paths[-1])['reviewer_identity']=='/root/receiver_driver_review' and load(peer_paths[-1])['author_identity']=='/root/conventional_control_review')

old_runner=(OLD/'frozen_fol_suite_once_runner_v1.py').read_text();runner=Path(h['runner']['path']).read_text()
old_observer=(OLD/'observe_frozen_fol_suite_runner_v1.py').read_text();observer=Path(h['observer']['path']).read_text()
trees={}
for label,text in [('runner',runner),('observer',observer)]:
    tree=ast.parse(text,filename=h[label]['path']);trees[label]=tree
    compile(tree,h[label]['path'],'exec')
    roots=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Import):roots.extend(a.name.split('.')[0] for a in n.names)
        elif isinstance(n,ast.ImportFrom):roots.append(n.module.split('.')[0])
    check(label+'-stdlib-imports-only',set(roots)<=set('time hashlib json math os pathlib selectors signal stat subprocess sys'.split()),sorted(set(roots)))
    check(label+'-compile-without-evaluation',True)
old_tree=ast.parse(old_runner);old_fn=functions(old_tree);new_fn=functions(trees['runner'])
retained=[]
for name in old_fn.keys()-{'intake_subject','authenticate_reviews','run_once'}:
    equal=region(old_runner,old_fn[name])==region(runner,new_fn[name]) and dump(old_fn[name])==dump(new_fn[name])
    check('retained-top-level:'+name,equal);retained.append(name)
old_nested={n.name:n for n in old_fn['run_once'].body if isinstance(n,ast.FunctionDef)}
new_nested={n.name:n for n in new_fn['run_once'].body if isinstance(n,ast.FunctionDef)}
check('nested-lifecycle-same-set',set(old_nested)==set(new_nested))
for name,n in old_nested.items():check('retained-nested:'+name,region(old_runner,n)==region(runner,new_nested[name]) and dump(n)==dump(new_nested[name]))
rc=constants(trees['runner']); oc=constants(ast.parse(old_runner)); obs=constants(trees['observer'])
check('LIMITS-entirely-unchanged',rc['LIMITS']==oc['LIMITS'],rc['LIMITS'])
check('typed-current-factor',rc['KINDS']==('fixed','symbolic') and rc['ORDERINGS']==('and_support',) and rc['CERTIFICATIONS']==('bulk','dependency_closures') and rc['STORAGES']==('literal_interned',))
check('new-schemas',all(rc[k]==v for k,v in {'PLAN_SCHEMA':'ROOT-inventory-certification-once-plan-v1','AUTH_SCHEMA':'ROOT-inventory-certification-once-authorization-v1','WORKER_RECEIPT_SCHEMA':'inventory-certification-worker-receipt-v1','RECEIPT_SCHEMA':'inventory-certification-external-once-receipt-v1'}.items()))
check('exact-cold-pin',rc['COLD_PIN']==h['cold'])
expected_roles={
 'ordering_Source':('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
 'registry_Source':('inventory-closure-registry-typed-Source-review-v1','source_review_passed','/root/conventional_library'),
 'composition_Source':('inventory-certification-driver-cold-typed-Source-review-v1','source_review_passed','/root/conventional_library'),
 'once_Source':('inventory-certification-once-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'prospective_plans':('inventory-certification-prospective-plan-review-v1','prospective_review_passed','/root/conventional_library')}
check('exact-five-role-schema-identity-map',rc['REVIEW_ROLES']==expected_roles,rc['REVIEW_ROLES'])

required={
 'complete-worker-factor':"('invocation_id','mode','search_ordering','inventory_certification_mode','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure')",
 'full22-plus2':"len(worker['project_sources'])==22 and set(worker['components'])=={'receiver_driver','bounded_transport'}",
 'closure-whole24':"closure['materialized_aliases']==names and closure['runtime']['Python_executable']==plan['python']",
 'factorial-allfour':"{(m,c) for m in KINDS for c in CERTIFICATIONS}",
 'no-ordering-factor':"r['result_reader']=='interned' and r['search_ordering']=='and_support' for r in schedule)",
 'per-row-factor':"('mode','search_ordering','inventory_certification_mode','result_reader','receiver_id','actual_directory','model_storage')",
 'aggregate-microstep-declaration':"'inventory_registration_aggregate_micro_steps':5000000000",
 'registry-role-subject':"'registry_Source':[worker['project_sources']['semantic_inventory_oracle']]",
 'three-ordering-subjects':"('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')",
 'composition-subjects':"'composition_Source':[plan['cold'],worker['components']['receiver_driver']]",
 'once-subjects':"'once_Source':[plan['runner'],plan['observer']]",
 'prospective-subjects':"'prospective_plans':[plan['integration_declaration'],plan['runtime_closure'],plan['worker_plan']]",
 'exact-plan-factor-field':"fields={'schema','invocation_id','mode','search_ordering','inventory_certification_mode'",
 'full-subject-auth':"subject={k:v for k,v in plan.items() if k!='authorization'}",
 'maxone':"auth['maximum_actual_invocations']==1",
 'auth-no-selfcert':"review['author_identity']!=reviewer and review['source_only'] is True",
 'role-scope-is-containment':"need(contains_literal(review,subject),'full literal subject occurs in current review '+role)",
 'whole-result-factor':"result['inventory_certification_mode']==plan['inventory_certification_mode']",
 'epoch-factor':"result['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode']",
 'selected-search':"search_subject['original']==worker['project_sources'][search_alias]",
 'selected-helper':"support_subject['original']==worker['project_sources']['receptor_support_ordering_v1']",
 'native-exact-parent':"native['parent_pid']==pid and native['parent_pgid']==pgid and native['native_pgid']==pgid",
 'native-success-reap':"native['closed'] is True and native['all_reaped'] is True",
 'native-peaks-separate':"aggregate=wait_usage['ru_maxrss']+native['native_high_water_bytes']",
 'positive-exit180':"worker_receipt['work_completed'] is True and terminal_ns<work_end",
 'permanent-veto':"need(group_reappearance_observed_ns is None,'owned PGID reappearance is permanently unaccepted')",
 'sourceentry-clock':"began=ENTRY_BEGAN_NS",
 'raw-loop-conditional':"need(aggregate<=LIMITS['aggregate_peak_bytes']",
 'no-proof-acceptance':"'ROOT_resource_accepted':False,'mathematical_proof_accepted':False,'scientific_acceptance':False",
}
for name,s in required.items():check(name,s in runner,s)
check('marker-precedes-only-Popen',runner.index("marker_pin=write_new(actual/'CONSUMED.json'")<runner.index('process=subprocess.Popen(') and runner.count('subprocess.Popen(')==1)
check('exact-four-cold-args',"plan['cold']['path'],plan['worker_plan']['path'],str(began),str(work_end),str(overall_end)]" in runner)
check('factor-at-marker-and-finalreceipt',runner.count("'inventory_certification_mode':plan['inventory_certification_mode']")==2)
check('worker-factor-check',"('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','receiver_id','integration_declaration')" in runner)
check('raw-loop-after-memory-check',runner.index("need(aggregate<=LIMITS['aggregate_peak_bytes']")<runner.index("for key,cap in [('runner',1048576),('observer',1048576),('python',67108864)"))

# Whole-observer inverse is intentionally small and independent of target execution.
norm=observer
for a,b in [('inventory-certification-final-terminal-observer-v1','frozen-fol-suite-intake-final-terminal-observer-v1'),('ROOT-inventory-certification-once-plan-v1','ROOT-and-support-ordering-once-plan-v1'),(h['runner']['sha256'],h['parent_sources']['frozen_fol_suite_once_runner_v1.py']['sha256']),('inventory-certification-final-terminal-observation-v1','and-support-ordering-final-terminal-observation-v1')]:norm=replace(norm,a,b)
norm=replace(norm,"            receipt['inventory_certification_mode']==plan['inventory_certification_mode'] and\n",'')
check('observer-whole-inverse-raw-and-AST',norm==old_observer and dump(ast.parse(norm))==dump(ast.parse(old_observer)))
check('observer-exact-currentrunner-hardpin',h['runner']['sha256'] in observer)
check('observer-terminal-factor',"receipt['inventory_certification_mode']==plan['inventory_certification_mode']" in observer)
check('observer-no-science-admission',"scientific_acceptance=False,mathematical_proof_accepted=False" in observer)
check('observer-sourceentry-scope',"Parent Source-entry epoch excludes observer/Python prelude" in observer)

# Coupling only: scientific cold/driver/registry algorithms are not reviewed here.
cold=Path(h['cold']['path']).read_text();cc=constants(ast.parse(cold))
check('cold-mandatory-matching-schema',cc['PLAN_SCHEMA']=='ROOT-inventory-certification-worker-plan-v1' and cc['WORKER_SCHEMA']==rc['WORKER_RECEIPT_SCHEMA'])
check('cold-new-driver-registry-full-pins',cc['RECEIVER_DRIVER_SOURCE']==h['driver'] and cc['REGISTRY_SOURCE']==h['registry'])
check('cold-same-24-parentmap-onlyregistry-change',"expected_project=dict(parent_closure['project_sources'])\n        expected_project['semantic_inventory_oracle']=REGISTRY_SOURCE" in cold)
check('cold-certified-factor-marker-epoch-call-return',all(s in cold for s in ["marker['inventory_certification_mode']==plan['inventory_certification_mode']", "inventory_certification_mode=plan['inventory_certification_mode']", "result_data['inventory_certification_mode']==plan['inventory_certification_mode']", "result_data['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode']"]))
check('cold-unchanged-inputcapsule-pin','1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0' in cold)

# Exact changed-statement census records all delta bodies, without evaluating them.
statement_census={}
for name in ['intake_subject','authenticate_reviews','run_once']:
    a=old_fn[name];b=new_fn[name]
    sa=[dump(x) for x in a.body];sb=[dump(x) for x in b.body]
    opcodes=difflib.SequenceMatcher(a=sa,b=sb,autojunk=False).get_opcodes()
    statement_census[name]=[dict(operation=tag,parent_lines=[a.body[i].lineno for i in range(i1,i2)],current_lines=[b.body[j].lineno for j in range(j1,j2)],parent_source=[region(old_runner,a.body[i]) for i in range(i1,i2)],current_source=[region(runner,b.body[j]) for j in range(j1,j2)]) for tag,i1,i2,j1,j2 in opcodes if tag!='equal']
old_try=next(n for n in old_fn['run_once'].body if isinstance(n,ast.Try))
new_try=next(n for n in new_fn['run_once'].body if isinstance(n,ast.Try))
check('run-once-exception-handlers-raw-AST-retained',len(old_try.handlers)==len(new_try.handlers) and all(region(old_runner,a)==region(runner,b) and dump(a)==dump(b) for a,b in zip(old_try.handlers,new_try.handlers)))
check('run-once-finally-raw-AST-retained',len(old_try.finalbody)==len(new_try.finalbody) and all(region(old_runner,a)==region(runner,b) and dump(a)==dump(b) for a,b in zip(old_try.finalbody,new_try.finalbody)))
inner_changes=[]
for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(a=[dump(x) for x in old_try.body],b=[dump(x) for x in new_try.body],autojunk=False).get_opcodes():
    if tag!='equal':inner_changes.append(dict(operation=tag,parent_source=[region(old_runner,x) for x in old_try.body[i1:i2]],current_source=[region(runner,x) for x in new_try.body[j1:j2]]))
check('run-once-main-try-only-two-factor-joins-changed',len(inner_changes)==2 and all(x['operation']=='replace' and len(x['parent_source'])==len(x['current_source'])==1 for x in inner_changes) and all('inventory_certification_mode' in x['current_source'][0] for x in inner_changes),inner_changes)
statement_census['run_once.main_try']=inner_changes

controller=ROOT/'.gcts-active/inventory-certification-progress-20261018/run_twenty_once_v1.py'
parent_controller=ROOT/'.gcts-active/first-order-suite-progress-20261018/run_forty_once_v2.py'
ct=controller.read_text();pt=parent_controller.read_text();compile(ast.parse(ct),str(controller),'exec')
check('controller-current-pin',pin(controller)['sha256']=='42622bd44ac7bfc2ded2edc07d84be4e2cc8a24cd33ef459ef0a15e641835663' and pin(controller)['bytes']==9127)
check('controller-parent-pin',pin(parent_controller)['sha256']=='428e6a62e3c9aa0c95cea9d8e816fecd498ec34f198d6c4cc8d64d9ab0b53571')
expected=pt.replace('forty','twenty').replace('40','20')
for a,b in [('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1','/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1'),('ROOT-first-order-suite-authorized-plan-index-v1','ROOT-inventory-certification-authorized-index-v1'),("'search_ordering','model_storage'","'search_ordering','inventory_certification_mode','model_storage'"),('len(subject)==17','len(subject)==18'),('ROOT-first-order-suite-launcher-consumed-v1','ROOT-inventory-certification-launcher-consumed-v1'),('ROOT-first-order-twenty-actuals-closed-v1','ROOT-inventory-certification-twenty-actuals-closed-v1')]:expected=replace(expected,a,b,2 if a=="'search_ordering','model_storage'" else 1)
check('controller-full-delta-exact-raw-AST',expected==ct and dump(ast.parse(expected))==dump(ast.parse(ct)))
check('controller-marker-before-single-observer-Popen',ct.index("marker=save(R/'COHORT-LAUNCHER-CONSUMED-v1.json'")<ct.index('process=subprocess.Popen(') and ct.count('subprocess.Popen(')==1)
check('controller-closure-before-nextslot',all(s in ct for s in ["q['python_reaped'] is True and q['owned_group_absent'] is True", "q['stdout_eof'] is True and q['stderr_eof'] is True and q['log_capture_complete'] is True", "q['owned_group_reappearance_observed_ns'] is None", "native['closed'] is True and native['all_reaped'] is True"]))
check('controller-no-outcome-filter',"resource_candidate=q['resource_candidate_accepted']" in ct and "terminal_gate=t['terminal_gate_passed']" in ct and "closed.append(record)" in ct)
check('controller-preflight-exact-all20-before-marker',ct.index('for expected,row in zip(design')<ct.index("marker=save(R/'COHORT-LAUNCHER-CONSUMED-v1.json'"))
check('controller-compile-without-evaluation',True)

patch_records=[]
for name,a,b in [('runner',old_runner,runner),('observer',old_observer,observer),('controller',pt,ct)]:
    folder=OUT/(name+'-inert-F0');folder.mkdir(exist_ok=True)
    forward=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='payload.txt',tofile='payload.txt'))
    inverse=''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='payload.txt',tofile='payload.txt'))
    (folder/'forward.patch').write_text(forward);(folder/'inverse.patch').write_text(inverse)
    (folder/'payload.txt').write_text(a)
    for direction,expected_text in [('forward',b),('inverse',a)]:
        result=subprocess.run(['patch','--batch','--fuzz=0','-p0','-i',str(folder/(direction+'.patch'))],cwd=folder,capture_output=True,text=True)
        ok=result.returncode==0 and (folder/'payload.txt').read_text()==expected_text
        check('inert-F0:'+name+':'+direction,ok,dict(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
        patch_records.append(dict(subject=name,direction=direction,patch=pin(folder/(direction+'.patch')),whole_output_equal=ok))
    (OUT/(name+'-Source.diff')).write_text(forward)

audit=dict(schema='inventory-certification-once-raw-Source-audit-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=sum(not c['passed'] for c in checks),retained_top_level_functions=sorted(retained),retained_nested_lifecycle_functions=sorted(old_nested),changed_statement_census=statement_census,actual_inert_F0_directions=patch_records,compiled_without_evaluation_count=3,reviewed_sources=dict(once_runner=h['runner'],terminal_observer=h['observer'],sequential_controller=pin(controller)),parents=dict(once_runner=h['parent_sources']['frozen_fol_suite_once_runner_v1.py'],terminal_observer=h['parent_sources']['observe_frozen_fol_suite_runner_v1.py'],sequential_controller=pin(parent_controller)))
(OUT/'raw-Source-audit-v1.json').write_text(json.dumps(audit,sort_keys=True,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(check_count=len(checks),mismatches=[c for c in checks if not c['passed']],audit=pin(OUT/'raw-Source-audit-v1.json')),indent=2))
