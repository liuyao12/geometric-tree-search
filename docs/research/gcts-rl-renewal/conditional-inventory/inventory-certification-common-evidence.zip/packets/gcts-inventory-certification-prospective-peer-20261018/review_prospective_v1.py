"""Source/raw metadata review only; no target/scientific imports or calls."""
from pathlib import Path
import ast,collections,hashlib,json
P=Path('/private/tmp/gcts-inventory-certification-prospective-peer-20261018')
I=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1/prospective-index-v1.json')
checks=[];pins={}
def pin(q):
 q=Path(q);b=q.read_bytes();return dict(path=str(q),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def need(ok,label):
 checks.append(dict(check=label,passed=bool(ok)))
 if not ok:raise ValueError(label)
def read(desc,label,decode=True):
 need(type(desc)is dict and set(desc)=={'path','sha256','bytes'},'whole descriptor '+label)
 q=Path(desc['path']);need(q.is_absolute() and str(q.resolve())==str(q),'canonical path '+label)
 if str(q) not in pins:
  pins[str(q)]=pin(q)
 need(pins[str(q)]==desc,'raw pin '+label)
 return json.loads(q.read_text()) if decode else None
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(x):return hashlib.sha256(canon(x)).hexdigest()
need(pin(I)['sha256']=='440f05ef66b1fbfe6e751d9b693cd73e823ccd74428326dcc4c4f8ba386f6ff3' and pin(I)['bytes']==35467,'exact assigned index')
i=json.loads(I.read_text());d=read(i['design'],'design');cl=read(i['runtime_closure'],'current closure');caps=read(i['input_capsule'],'original whole input capsule');h=read(i['intake_Source_handoff'],'intake handoff');ct=read(i['source_contract'],'Source contract')
need(i['schema']=='ROOT-inventory-certification-prospective-index-v1' and i['source_only'] is True and i['actual_execution_authorized'] is False and i['scientific_calls']==0,'inert index schema/flags')
need(d['schema']=='ROOT-inventory-certification-prospective-design-v1' and d['source_only'] is True and d['actual_execution_authorized'] is False,'inert design schema/flags')
need(i['subject_count']==20 and len(i['schedule'])==len(d['schedule'])==20,'complete20 subjects')
need(i['runtime_closure']==d['runtime_closure'] and i['input_capsule']==d['original_input_capsule'] and i['intake_Source_handoff']==d['intake_Source_handoff'],'index/design whole common descriptors')
need(i['cold']==h['cold'] and i['runner']==h['runner'] and i['observer']==h['observer'],'intake exact current3 Source pins')
for k in ['cold','runner','observer']:read(i[k],k,False)
read(i['source_contract'],'current Source contract',False)
need(ct['sources']['family_registry']==h['registry'] and ct['sources']['receiver_driver']==h['driver'],'contract current driver/registry')
need(cl['schema']=='ROOT-inventory-certification-raw-runtime-closure-v1' and cl['source_only'] is True and cl['actual_execution_authorized'] is False,'inert current closure')
parent=read(cl['parent_closure'],'full prior suite closure')
need(cl['parent_closure']==h['parent_closure'],'current runtime closure parent matches reviewed cold')
project=dict(parent['project_sources']);project['semantic_inventory_oracle']=h['registry']
components=dict(parent['additional_nonseed_components']);components['receiver_driver']=h['driver']
need(cl['project_sources']==project and cl['additional_nonseed_components']==components,'only current registry+driver executable Source maps change')
need(len(project)==22 and len(components)==2,'unchanged22project+2component domain')
for k in ['Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python']:
 need(cl[k]==parent[k],'whole unchanged fixed closure '+k)
aliases={**project,'semantic_receiver_driver':components['receiver_driver'],'bounded_request_oracle':components['bounded_transport']}
need(cl['materialized_aliases']==aliases and len(aliases)==24,'complete24 same aliases every arm')
need(cl['unresolved_project_imports']==[] and cl.get('unresolved_dynamic_import_sites')==[],'no declared unresolved scientific closure imports')
for alias,desc in aliases.items():read(desc,'alias '+alias,False)
for n,desc in cl['fixed_native_inputs'].items():
 if type(desc)is dict and set(desc)=={'path','sha256','bytes'}:read(desc,'opaque fixed Native '+n,False)
for n in ['source','binary']:read(cl['native_CPP'][n],'Native CPP '+n,False)
read(cl['runtime']['Python_executable'],'Python runtime',False)
for z in cl['Z3']['files']:
 read({k:z[k] for k in ('path','sha256','bytes')},'Z3 '+z.get('relative_path',z['path']),False)
for n in ['family_registry','receiver_driver']:read(ct['sources'][n],n,False)
for x in [h['registry'],h['driver'],i['cold']]:ast.parse(Path(x['path']).read_text());need(True,'AST-only exact current Source '+Path(x['path']).name)
# Original logical input remains literal and complete, no supplied routes.
receivers=caps['receivers'];byid={r['id']:r for r in receivers}
need(len(receivers)==len(byid)==10,'unchanged complete original10 input capsule')
need(set(i['case_declarations'])=={'prospective-fol-20261018-'+n for n in ['001','002','003','005','010']},'exact all4 previous failure inputs+positive control')
need(d['selection']['ordered_cases']==[2,3,5,10,1] and d['selection']['known_previous_outcomes'] is True and d['selection']['not_blind'] is True,'known development-case selection explicitly scoped')
need(d['selection']['correlated_renaming_pair']==[5,10],'correlated rename disclosed')
need(d['factors']=={'inventory_certification_mode':['bulk','dependency_closures'],'method':['fixed','symbolic'],'search_ordering':['and_support']},'exact intended2x2 factor')
limits={'check_steps':2048,'compile_queries':512,'conservative_worker_plus_native_peak_bytes':1073741824,'guard_steps':1000000000,'inventory_registration_aggregate_micro_steps':5000000000,'overall_seconds':210,'proposal_steps':24,'registry_steps':5000000000,'result_bytes':134217728,'search_max_nodes':5000,'search_seconds':30,'seed':64000,'work_seconds':180}
need(d['limits']==limits,'unchanged full design profile')
source=ast.parse(Path(i['runner']['path']).read_text());constants={n.targets[0].id:ast.literal_eval(n.value) for n in source.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='LIMITS'}
expectedlimits={'aggregate_peak_bytes':1073741824,'failure_cleanup_seconds':5,'overall_seconds':210,'poll_milliseconds':20,'result_bytes':134217728,'runner_plan_bytes':16777216,'stderr_bytes':4194304,'stdout_bytes':4194304,'work_seconds':180,'worker_receipt_bytes':4194304}
need(constants['LIMITS']==expectedlimits,'declared limits equal exact once literal limits')
casefiles={k:read(v,'case declaration '+k) for k,v in i['case_declarations'].items()}
for rid,c in casefiles.items():
 need(c['schema']=='ROOT-inventory-certification-experiment-declaration-v1' and c['source_only'] is True and c['actual_execution_authorized'] is False,'inert percase '+rid)
 need(c['selected_receiver_id']==rid and c['selected_receiver']==byid[rid],'whole original selected receiver literal '+rid)
 need(set(c['selected_receiver'])=={'id','title','theory','target','length','instantiation_rounds','scope'},'input only, no proof/commands/bindings '+rid)
 need(c['selected_receiver']['length']==12 and c['selected_receiver']['instantiation_rounds']==2,'unchanged12/2 input '+rid)
 need(c['parent_structural_declaration']==i['input_capsule'] and c['global_cohort_declaration']==i['design'] and c['runtime_closure']==i['runtime_closure'],'full percase common pins '+rid)
 need(c['limits']==limits and c['model_storage']=='literal_interned' and c['result_reader']=='interned' and c['new_RL_training'] is False,'percase profile/storage/training '+rid)
 expected=[r for r in d['schedule'] if r['receiver_id']==rid]
 need(c['schedule']==expected and len(expected)==4,'exact all4 percase schedule '+rid)
 need({(r['mode'],r['inventory_certification_mode']) for r in expected}=={(m,k) for m in ['fixed','symbolic'] for k in ['bulk','dependency_closures']},'all2x2 combinations '+rid)
worker_fields={'schema','invocation_id','mode','actual_directory','cold','python','project_sources','components','native_inputs','policy','declaration','runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage','search_ordering','inventory_certification_mode'}
once_fields={'schema','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory','runner','observer','python','cold','worker_plan','integration_declaration','runtime_closure','authorization','limits','environment'}
auth_fields={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'}
rows=[];paths=[];ids=[]
basearm=[('fixed','bulk'),('symbolic','dependency_closures'),('symbolic','bulk'),('fixed','dependency_closures')]
for j,r in enumerate(i['schedule']):
 label=r['invocation_id'];rid=r['receiver_id'];spec=byid[rid];worker=read(r['worker_plan'],'worker '+label);once=read(r['runner_plan_draft'],'once '+label);auth=read(r['authorization_draft'],'false auth '+label)
 actual=Path(r['actual_directory']);obs=I.parent/'runner-plans'/(label+'-terminal-observation');terminal=I.parent/'runner-plans'/(label+'-terminal.json')
 need(not actual.exists() and not obs.exists() and not terminal.exists(),'fresh absent actual/observer/terminal '+label)
 need(set(worker)==worker_fields and worker['schema']=='ROOT-inventory-certification-worker-plan-v1','exact19-field worker envelope '+label)
 need(set(once)==once_fields and once['schema']=='ROOT-inventory-certification-once-plan-v1','exact19-field once envelope '+label)
 need(set(auth)==auth_fields and auth['schema']=='ROOT-inventory-certification-once-authorization-v1','exact7-field inert authorization '+label)
 need(auth['actual_execution_authorized'] is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review_roles']=={} and auth['author_identity']=='/root','deliberately unlaunchable false/zero/empty auth '+label)
 subject={k:v for k,v in once.items() if k!='authorization'}
 need(len(subject)==18 and sha(subject)==auth['subject_sha256']==r['subject_sha256'],'whole18-field authorization-omitted subject SHA '+label)
 need(once['authorization']==r['authorization_draft'] and once['worker_plan']==r['worker_plan'],'exact once raw draft/worker pins '+label)
 for key in ['invocation_id','mode','inventory_certification_mode','model_storage','result_reader','receiver_id','search_ordering','actual_directory']:
  need(worker[key]==once[key]==r[key],'whole factor/path/identity '+key+' '+label)
 need(worker['cold']==once['cold']==i['cold'] and once['runner']==i['runner'] and once['observer']==i['observer'],'whole current intake Sources '+label)
 need(worker['runtime_closure']==once['runtime_closure']==i['runtime_closure'] and worker['components']==components and worker['project_sources']==project,'whole current executable/runtime maps '+label)
 need(worker['integration_declaration']==once['integration_declaration']==i['case_declarations'][rid] and worker['declaration']==i['input_capsule'],'exact percase declaration not global substitution '+label)
 need(worker['python']==once['python']==cl['runtime']['Python_executable'],'exact runtime '+label)
 need(worker['native_inputs']=={'program_and_template':cl['fixed_native_inputs']['program_and_template'],'opaque_microcode_gzip':cl['fixed_native_inputs']['opaque_microcode_gzip'],'native_cpp':cl['native_CPP']['binary']},'whole unchanged Native inputs '+label)
 need(worker['policy']['sha256']=='f5f0c22121f4c503db319fe6e01c4c3a146ac9db9deb7e2ccec0aab1a2f32161' and worker['policy']['bytes']==4502,'whole full4-template policy pin '+label);read(worker['policy'],'policy '+label,False)
 z3files=[{k:z[k] for k in ['path','sha256','bytes']} for z in cl['Z3']['files']]
 need(worker['z3']['root']==cl['Z3']['package_root'] and worker['z3']['files']==z3files and worker['z3']['library'] in z3files,'whole unchanged Z3 map '+label)
 need(once['limits']==expectedlimits and once['environment']=={'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','TZ':'UTC'},'original limits/environment '+label)
 need(r['order']==j+1 and r['case_order']==j//4+1 and r['within_case_order']==j%4+1,'whole serial order '+label)
 need((r['mode'],r['inventory_certification_mode'])==basearm[(j%4+j//4)%4],'fixed predeclared Latin rotation '+label)
 need({k:r[k] for k in d['schedule'][j]}==d['schedule'][j],'index/design whole schedule row '+label)
 paths.append(str(actual));ids.append(label)
 rows.append(dict(invocation_id=label,receiver_id=rid,mode=r['mode'],inventory_certification_mode=r['inventory_certification_mode'],worker_plan=r['worker_plan'],runner_plan_draft=r['runner_plan_draft'],authorization_draft=r['authorization_draft'],subject_sha256=sha(subject),subject=subject,integration_declaration=i['case_declarations'][rid],actual_directory=str(actual),actual_path_absent=True,terminal_observation_directory=str(obs),terminal_observation_path_absent=True))
need(len(set(ids))==len(set(paths))==20,'20 unique invocations and absent actual directories')
need(collections.Counter(r['receiver_id'] for r in rows)=={rid:4 for rid in casefiles},'every case retained in all4 arms')
need(collections.Counter((r['mode'],r['inventory_certification_mode']) for r in rows)=={pair:5 for pair in basearm},'five independent slots per factor, no omitted subject')
# End-of-audit freshness and immutable current object checks.
for r in rows:need(not Path(r['actual_directory']).exists() and not Path(r['terminal_observation_directory']).exists(),'end-of-review no launch '+r['invocation_id'])
need(pin(I)['sha256']=='440f05ef66b1fbfe6e751d9b693cd73e823ccd74428326dcc4c4f8ba386f6ff3','index unchanged after audit')
audit=dict(schema='inventory-certification-prospective-independent-raw-audit-v1',author_identity='/root',reviewer_identity='/root/conventional_library',prospective_index=pin(I),design=i['design'],runtime_closure=i['runtime_closure'],input_capsule=i['input_capsule'],case_declarations=i['case_declarations'],all20subjects=rows,raw_descriptors_checked=list(pins.values()),checks=checks,checks_passed=len(checks),mismatches=0,source_only=True,scientific_calls=0,scientific_replays=0,module_evaluations=0,Native_calls=0,fixture_executions=0,actual_execution_authorized=False)
q=P/'raw-prospective-audit-v1.json';q.write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(audit=pin(q),checks=len(checks),raw_files=len(pins),subjects=len(rows))))
