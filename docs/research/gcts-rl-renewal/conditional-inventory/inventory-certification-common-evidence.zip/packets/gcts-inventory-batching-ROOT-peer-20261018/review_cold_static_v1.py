"""Stdlib inert raw/AST cold composition inspection; no target imports/calls."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
P=Path('/private/tmp/gcts-inventory-batching-ROOT-peer-20261018')
S=Path('/private/tmp/gcts-inventory-certification-intake-ROOT-source-20261018/inventory_certification_cold_v1.py')
O=Path('/private/tmp/gcts-first-order-suite-intake-source-20261018/frozen_fol_suite_cold_v1.py')
H=S.with_name('intake-Source-handoff-v1.json')
def pin(q):
 b=q.read_bytes();return dict(path=str(q),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def nm(t):return {n.name:n for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
def raw(s,n):return ast.get_source_segment(s,n)
def same(a,b):return ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
checks=[]
def need(ok,label):
 checks.append(dict(check=label,passed=bool(ok)))
 if not ok:raise ValueError(label)
s=S.read_text();o=O.read_text();st=ast.parse(s);ot=ast.parse(o);sn=nm(st);on=nm(ot)
need(pin(S)['sha256']=='f8cd51bc5a96191a7b8e0cb8a3eeeea62814d3d7951cb92225c4449031a13f62' and pin(S)['bytes']==35479,'exact assigned cold Source')
h=json.loads(H.read_text());need(h['cold']==pin(S) and h['parent_sources'][O.name]==pin(O),'handoff exact cold and parent')
D=Path('/private/tmp/gcts-inventory-batching-ROOT-source-20261018/inventory_certification_receiver_driver_v2.py');R=D.with_name('semantic_inventory_oracle_v2.py');C=D.with_name('Source-contract-v1.json')
need(h['driver']==pin(D) and h['registry']==pin(R) and h['source_contract']==pin(C),'handoff exact reviewed driver/registry/contract')
for q,a in [(S,s),(O,o)]:ast.parse(a);compile(a,str(q),'exec');need(True,'parse and unused compile '+q.name)
retained=[]
for name,node in on.items():
 if name=='main':continue
 need(name in sn and raw(o,node)==raw(s,sn[name]) and same(node,sn[name]),'inherited callable raw+AST exact '+name);retained.append(name)
need([ast.dump(n,include_attributes=False) for n in st.body if isinstance(n,(ast.Import,ast.ImportFrom))]==[ast.dump(n,include_attributes=False) for n in ot.body if isinstance(n,(ast.Import,ast.ImportFrom))],'all cold imports exact parent')
# Literal raw inversion of all disclosed main-body coupling changes.
x=raw(s,sn['main']);old=raw(o,on['main'])
def replace_once(a,b,label):
 global x
 need(x.count(a)==1,'unique inverse seam '+label);x=x.replace(a,b,1)
replace_once(",'search_ordering','inventory_certification_mode'}",",'search_ordering'}",'worker required fields')
replace_once("    need(plan['inventory_certification_mode'] in ('bulk','dependency_closures'), 'explicit inventory certification mode')\n    need(plan['search_ordering']=='and_support','fixed shared support ordering in certification comparison')\n",'', 'new mode/fixedordering guards')
replace_once("         marker['inventory_certification_mode']==plan['inventory_certification_mode'] and\n",'', 'consumption marker certification field')
replace_once("'ROOT-inventory-certification-experiment-declaration-v1'","'ROOT-and-support-ordering-experiment-declaration-v1'",'percase declaration schema')
replace_once("('mode','search_ordering','inventory_certification_mode','result_reader','receiver_id','actual_directory','model_storage')","('mode','search_ordering','result_reader','receiver_id','actual_directory','model_storage')",'percase subject fields')
def block(txt,start,end):return txt[txt.index(start):txt.index(end,txt.index(start))]
start="        need(len(schedule)==4";end="        declaration=json.loads"
replace_once(block(x,start,end),block(old,start,end),'four-arm factor validation')
replace_once("'ROOT-inventory-certification-raw-runtime-closure-v1'","'ROOT-and-support-ordering-raw-runtime-closure-v1'",'closure schema')
replace_once("'new full closure with explicit previous-suite lineage'","'new full closure with explicit unchanged parent lineage'",'closure lineage wording')
start="        expected_project=dict(parent_closure['project_sources'])";end="        need(expected_project['interned_quantified_family_points_v1']"
replace_once(block(x,start,end),block(old,start,end),'current full parent project map with registry-only replacement')
replace_once("                   inventory_certification_mode=plan['inventory_certification_mode'],\n",'', 'epoch mode')
replace_once("            inventory_certification_mode=plan['inventory_certification_mode'],\n",'', 'driver mode')
replace_once("             result_data['inventory_certification_mode']==plan['inventory_certification_mode'] and\n             result_data['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode'] and\n",'', 'whole result mode joins')
replace_once("            inventory_certification_mode=plan['inventory_certification_mode'],\n",'', 'worker mode')
need(x==old,'entire main raw equals parent after exact disclosed coupling inverse')
need(same(ast.parse(x).body[0],on['main']),'entire main AST equals parent after declared coupling inverse')
# Full residual AST inversion for version/source descriptor only.
sa={n.targets[0].id:n for n in st.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
oa={n.targets[0].id:n for n in ot.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
changed={'VERSION','PLAN_SCHEMA','EPOCH_SCHEMA','WORKER_SCHEMA','PARENT_RUNTIME_CLOSURE','RECEIVER_DRIVER_SOURCE'}
for key in oa:
 if key not in changed:need(raw(s,sa[key])==raw(o,oa[key]) and same(sa[key],oa[key]),'constant raw+AST unchanged '+key)
newbody=[]
for n in st.body:
 if isinstance(n,ast.FunctionDef) and n.name=='main':n=ast.parse(x).body[0]
 if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name):
  name=n.targets[0].id
  if name=='REGISTRY_SOURCE':continue
  if name in changed:n=oa[name]
 newbody.append(n)
need(same(ast.Module(body=newbody,type_ignores=[]),ot),'whole residual cold AST equals parent after only declared changes')
parent=ast.literal_eval(sa['PARENT_RUNTIME_CLOSURE'].value);need(parent==h['parent_closure'] and parent==pin(Path(parent['path'])),'new parent closure descriptor is exact full40 immutable closure')
need(ast.literal_eval(sa['RECEIVER_DRIVER_SOURCE'].value)==pin(D) and ast.literal_eval(sa['REGISTRY_SOURCE'].value)==pin(R),'cold fixed raw driver and registry exact')
pd=json.loads(Path(parent['path']).read_text());need(len(pd['project_sources'])==22 and len(pd['materialized_aliases'])==24,'parent closure complete22 project+2 aliases')
for alias,desc in pd['project_sources'].items():need(desc==pin(Path(desc['path'])),'raw inherited project descriptor '+alias)
need("expected_project['semantic_inventory_oracle']=REGISTRY_SOURCE" in s,'only project registry replacement from current parent')
need("plan['components']['bounded_transport']==parent_closure['additional_nonseed_components']['bounded_transport']" in s,'bounded factory unchanged exact parent')
need("plan['components']['receiver_driver']==RECEIVER_DRIVER_SOURCE" in s,'new driver fixed in actual imported component map')
need("plan['project_sources']==closure['project_sources']==expected_project" in s,'whole exact project map authenticated')
need("closure['materialized_aliases']==names" in s and 'len(names)==24' in s,'all24 exact aliases copied/imported/sealed in every arm')
need("result_data['inventory_certification_mode']==plan['inventory_certification_mode']" in s and "result_data['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode']" in s,'full output and epoch certification-mode joins')
for field in ['work_ns==began+180000000000','overall_ns==began+210000000000',"region_check=(verify_raw_region(result_data,work_ns)","loaded['interned_result_reader_v2'].decode_result",'verify_literal_result(result_data,result_raw,reader_tick)']:
 need(field in s,'preserved profile/whole validation seam '+field)
f=P/'cold-parent-to-v1.patch';r=P/'cold-v1-to-parent.patch'
f.write_text(''.join(difflib.unified_diff(o.splitlines(True),s.splitlines(True),fromfile='cold.txt',tofile='cold.txt')));r.write_text(''.join(difflib.unified_diff(s.splitlines(True),o.splitlines(True),fromfile='cold.txt',tofile='cold.txt')))
w=P/'cold-patch-rehearsal';w.mkdir(exist_ok=True);q=w/'cold.txt';q.write_text(o)
for name,pat,wanted in [('forward',f,s),('inverse',r,o)]:
 z=subprocess.run(['patch','-F','0','-i',str(pat)],cwd=w,capture_output=True,text=True);need(z.returncode==0 and q.read_text()==wanted,'actual inert F0 cold '+name+' exact');(P/('cold-patch-'+name+'-receipt.txt')).write_text(z.stdout+z.stderr)
need(S.read_text()==s and O.read_text()==o,'parent/current cold Source untouched')
audit=dict(schema='inventory-certification-driver-cold-independent-static-audit-v1',author_identity='/root',reviewer_identity='/root/conventional_library',cold=pin(S),parent_cold=pin(O),handoff=pin(H),driver=pin(D),registry=pin(R),source_contract=pin(C),checks=checks,checks_passed=len(checks),mismatches=0,retained_callables=retained,whole_main_raw_inverse_exact=True,whole_residual_AST_exact=True,patches=dict(forward=pin(f),inverse=pin(r)),source_only=True,scientific_calls=0,module_evaluations=0,Native_calls=0,fixture_executions=0,actual_execution_authorized=False)
q=P/'cold-raw-Source-audit-v1.json';q.write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(audit=pin(q),checks=len(checks),retained_callables=len(retained))))
