"""Stdlib inert Source inspection only; target code is never imported/evaluated."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,subprocess
P=Path('/private/tmp/gcts-inventory-batching-ROOT-peer-20261018')
D=Path('/private/tmp/gcts-inventory-batching-ROOT-source-20261018/inventory_certification_receiver_driver_v2.py')
O=Path('/private/tmp/gcts-and-support-cold-source-20261018/and_support_receiver_driver_v1.py')
C=D.with_name('Source-contract-v1.json');R=D.with_name('semantic_inventory_oracle_v2.py')
def pin(q):
 raw=q.read_bytes();return dict(path=str(q),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def raw(src,node):return ast.get_source_segment(src,node)
def same(a,b):return ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
def nodes(t):return {x.name:x for x in t.body if isinstance(x,(ast.ClassDef,ast.FunctionDef))}
def assigns(t):return {x.targets[0].id:x for x in t.body if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name)}
checks=[]
def need(ok,label):
 checks.append(dict(check=label,passed=bool(ok)))
 if not ok:raise ValueError(label)
s=D.read_text();o=O.read_text();dt=ast.parse(s);ot=ast.parse(o);dn=nodes(dt);on=nodes(ot);da=assigns(dt);oa=assigns(ot)
need(pin(D)['sha256']=='2ba4a2de010da425e0f74f2c09b553d2051d7fc1a79fbe438845ec0a53c34466' and pin(D)['bytes']==62044,'exact assigned driver')
need(pin(C)['sha256']=='fa820289e6c75435b7f5f37d5e92a18f2d047a52548ce6308243cb1cac666ffe' and pin(C)['bytes']==3496,'exact assigned contract')
need(pin(R)['sha256']=='2010ca7cb6f3da0734efe03e5be0f7e166b7e4d5939078dea0451361cf5890f3','exact previously reviewed registry')
need(pin(O)['sha256']=='5f73835dfc9219f06f01206ebf6bbac5744eea582cbfb03deed42105f2ccacd0' and pin(O)['bytes']==53725,'exact historical driver parent')
contract=json.loads(C.read_text())
for role,q in [('receiver_driver',D),('family_registry',R)]:need(contract['sources'][role]==pin(q),'contract full source descriptor '+role)
need(contract['schema']=='ROOT-inventory-certification-Source-contract-v1' and contract['author_identity']=='/root' and contract['source_only'] is True and contract['actual_execution_authorized'] is False,'contract Source-only identity and no activation')
for q,src in [(D,s),(O,o),(R,R.read_text())]:ast.parse(src);compile(src,str(q),'exec');need(True,'parse and unused compilation '+q.name)
retained=[]
for name,node in on.items():
 if name in ('run_receiver','_inventory_record_join'):continue
 need(name in dn and raw(o,node)==raw(s,dn[name]) and same(node,dn[name]),'raw and AST exact inherited callable '+name)
 retained.append(name)
need(raw(s,dn['_inventory_bulk_record_join_parent']).replace('def _inventory_bulk_record_join_parent(', 'def _inventory_record_join(',1)==raw(o,on['_inventory_record_join']),'old bulk transcript checker raw exact after sole name inverse')
newpins=ast.literal_eval(da['DEPENDENCY_PINS'].value);oldpins=ast.literal_eval(oa['DEPENDENCY_PINS'].value)
need(set(newpins)==set(oldpins),'same complete injected scientific role set')
need({k:v for k,v in newpins.items() if k!='family_registry'}=={k:v for k,v in oldpins.items() if k!='family_registry'},'all compiler/model/search/helper/miner/SMT/control pins unchanged')
need(newpins['family_registry']==(pin(R)['sha256'],pin(R)['bytes']),'registry pin joins exact reviewed successor')
for name in oa:
 if name in ('VERSION','SOURCE_EPOCH_SCHEMA','DEPENDENCY_PINS'):continue
 need(raw(o,oa[name])==raw(s,da[name]) and same(oa[name],da[name]),'raw and AST exact inherited constant '+name)
need([ast.dump(x,include_attributes=False) for x in ot.body if isinstance(x,(ast.Import,ast.ImportFrom))]==[ast.dump(x,include_attributes=False) for x in dt.body if isinstance(x,(ast.Import,ast.ImportFrom))],'all driver imports remain stdlib and exact parent')
need('inventory_certification_mode' in [a.arg for a in dn['run_receiver'].args.kwonlyargs],'new certification mode mandatory keyword')
need("source_epoch.get('inventory_certification_mode') != inventory_certification_mode" in s,'mandatory caller/epoch certification mode equality')
need("SOURCE_EPOCH_SCHEMA = 'semantic-family-receiver-source-epoch-v4-inventory-certification'" in s,'explicit new epoch schema')
# Exact AST inversion of every disclosed run_receiver delta; no target execution.
class InvertCalls(ast.NodeTransformer):
 def visit_Call(self,node):
  self.generic_visit(node)
  if isinstance(node.func,ast.Name) and node.func.id=='dict':node.keywords=[k for k in node.keywords if k.arg not in ('inventory_certification_mode','inventory_registration_aggregate_micro_steps')]
  if isinstance(node.func,ast.Attribute) and node.func.attr=='check_inventory':node.keywords=[k for k in node.keywords if k.arg!='mode']
  if isinstance(node.func,ast.Name) and node.func.id=='_inventory_record_join' and node.args and isinstance(node.args[-1],ast.Name) and node.args[-1].id=='inventory_certification_mode':node.args.pop()
  return node
newmain=copy.deepcopy(dn['run_receiver'])
i=next(i for i,a in enumerate(newmain.args.kwonlyargs) if a.arg=='inventory_certification_mode');newmain.args.kwonlyargs.pop(i);newmain.args.kw_defaults.pop(i)
removed=[]
for n in list(newmain.body):
 if isinstance(n,ast.If) and any(isinstance(x,ast.Constant) and x.value=='explicit current caller/Source-epoch inventory mode' for x in ast.walk(n)):
  newmain.body.remove(n);removed.append(n)
need(len(removed)==1,'exact one new mandatory certification-mode guard')
newmain=InvertCalls().visit(newmain)
need(same(newmain,on['run_receiver']),'entire run_receiver AST exactly parent after only disclosed mode/result/limit/call inverses')
residual=copy.deepcopy(dt)
residual.body=[n for n in residual.body if not isinstance(n,ast.FunctionDef) or n.name!='_inventory_record_join']
for j,n in enumerate(residual.body):
 if isinstance(n,ast.FunctionDef) and n.name=='_inventory_bulk_record_join_parent':n.name='_inventory_record_join'
 if isinstance(n,ast.FunctionDef) and n.name=='run_receiver':residual.body[j]=newmain
 if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('VERSION','SOURCE_EPOCH_SCHEMA','DEPENDENCY_PINS'):residual.body[j]=copy.deepcopy(oa[n.targets[0].id])
need(same(residual,ot),'whole residual driver AST equals parent after declared deltas only')
join=dn['_inventory_record_join']
need(not any(isinstance(x,ast.ExceptHandler) for x in ast.walk(join)),'new join has no exception normalization')
need(not any(isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='plan_dependency_closures' for x in ast.walk(join)),'new join does not call registry closure planner')
checks_text=[
 ("if cert.get('planned_requests') != plans:",'fresh independent exact DFS plans compared'),
 ("ids != list(range(len(records)-len(ids),len(records)))",'exact full serial registration suffix'),
 ("inventory.get('query') is not None",'new batch scalar authority forbidden'),
 ("type(receipts) is not list or not receipts or len(receipts)>len(plans)",'nonempty bounded receipt prefix includes zero-definition theory query'),
 ("remaining = 5*10**9-used",'same aggregate5e9 reconstructed from actual Native consumption'),
 ("type(steps) is not int or not 0<=steps<=remaining",'strict integer residual consumption'),
 ("elif ordinal+1 != len(receipts):",'no receipt after unknown/rejected query'),
 ("len(receipts)==len(plans) and last_status=='accepted'",'all planned requests required for authority'),
 ("cert.get('complete') is not complete",'complete flag exact bool identity'),
 ("elif last_status=='accepted' and used==5*10**9 and len(receipts)<len(plans):",'honest accepted-prefix aggregate exhaustion UNKNOWN'),
 ("stage('inventory_record_join'",'independent join before Model activation'),
 ("if inventory['status'] != 'native_accepted':",'all-or-none inventory activation'),
 ("mode=inventory_certification_mode",'current mode dispatched to exact registry'),
 ("original = {k:v for k,v in inventory.items() if k not in fields}",'full original inventory semantic payload reconstructed'),
 ("cert.get('inventory_sha256') != _sha(original)",'current full inventory hash joined'),
 ("cert.get('theory_sha256') != _sha(spec['theory'])",'current full theory hash joined'),
 ("q['purpose'] != 'check_generated_lemma_definition_closure'",'every fresh closure purpose joined'),
 ("current = _record_join(records,r['query'],request,boundary)",'each entire literal Native request independently reconstructed and joined')]
for literal,label in checks_text:need(literal in s,label)
# Two actual inert F0 directions, no execution of the patched text.
fwd=P/'driver-parent-to-v2.patch';rev=P/'driver-v2-to-parent.patch'
fwd.write_text(''.join(difflib.unified_diff(o.splitlines(True),s.splitlines(True),fromfile='driver.txt',tofile='driver.txt')))
rev.write_text(''.join(difflib.unified_diff(s.splitlines(True),o.splitlines(True),fromfile='driver.txt',tofile='driver.txt')))
work=P/'driver-patch-rehearsal';work.mkdir(exist_ok=True);q=work/'driver.txt';q.write_text(o)
for label,patch,wanted in [('forward',fwd,s),('inverse',rev,o)]:
 r=subprocess.run(['patch','-F','0','-i',str(patch)],cwd=work,capture_output=True,text=True)
 need(r.returncode==0 and q.read_text()==wanted,'actual inert F0 driver '+label+' exact whole text')
 (P/('driver-patch-'+label+'-receipt.txt')).write_text(r.stdout+r.stderr)
need(D.read_text()==s and O.read_text()==o,'current and parent Sources remain exact and untouched')
report=dict(schema='inventory-certification-driver-independent-static-audit-v1',author_identity='/root',reviewer_identity='/root/conventional_library',source=pin(D),source_contract=pin(C),registry=pin(R),parent=pin(O),checks=checks,checks_passed=len(checks),mismatches=0,retained_raw_AST_callables=retained,whole_residual_AST_exact=True,patches=dict(forward=pin(fwd),inverse=pin(rev)),source_only=True,scientific_calls=0,scientific_replays=0,module_evaluations=0,fixture_executions=0,Native_calls=0,actual_execution_authorized=False,method='stdlib AST/raw/hash plus unused compile and inert text patches; no scientific functions or modules executed')
z=P/'driver-raw-Source-audit-v1.json';z.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(audit=pin(z),checks=len(checks),retained_callables=len(retained))))
