"""Saved JSON and raw Source descriptors only; no scientific module evaluation."""
import collections,hashlib,json,pathlib
O=pathlib.Path('/private/tmp/gcts-recursive-cluster-design-20261018');R=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');D=json.loads(pathlib.Path('/private/tmp/gcts-first-order-suite-comparison-peer-20261018/retained-comparison-data-v2.json').read_bytes());rows=[];checks=[]
def can(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def desc(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
for r in D['rows']:
 if r['receiver_id'][-3:]not in['006','007','008']:continue
 raw=pathlib.Path(r['raw_result']['path']).read_bytes();x=json.loads(raw);o=x['outputs'];m=o['model'];s=o['search'];target=x['declaration']['target'];basis=o['compile']['basis'];end=x['declaration']['length']-1;guardcounts=collections.Counter(p['command']['rule']for p in m['placements']if p['key'][0]==end and p['key'][1]==1 and p['command']['formula']==target);lastcommandcounts=collections.Counter(c['rule']for c in m['domains'][-1]if c['formula']==target)
 checks.append({'check':r['invocation_id']+' fullrawpin','passed':hashlib.sha256(raw).hexdigest()==r['raw_result']['sha256']and len(raw)==r['raw_result']['bytes']})
 semantic=collections.Counter();sampled=collections.Counter();semantic_max=0
 for e in s.get('events',[]):
  for item in e.get('items',[]):
   if item is None:continue
   n=len({k[0]for k in item['members']})
   if item['kind']=='sampled':sampled[n]+=1
   else:semantic[(item['kind'],n)]+=1;semantic_max=max(semantic_max,n)
 sup=s.get('support_ordering_metadata')if r['mode']=='fixed'else s.get('support_ordering');g=sup.get('graph')if isinstance(sup,dict)else None;edgeinfo=None
 if g:
  tid=g['target_formula_id'];edgecounts=collections.Counter((e['rule'],e['active_in_root_formula_grammar'])for e in g['graph_preimage']['edges']if e['conclusion']==tid)
  edgeinfo={'status':g['status'],'target_formula_id':tid,'target_is_formula_record':any(a['formula_id']==tid and a['formula']==target for a in g['graph_preimage']['formulas']),'target_incoming_edge_counts':[{'rule':k[0],'active_in_root_formula_grammar':k[1],'count':v}for k,v in edgecounts.items()],'admissible_lower_bound':g['admissible_lower_bound'],'candidate_pruning':g['candidate_pruning'],'logical_authority':g['logical_authority'],'graph_sha256':g['graph_sha256']}
 rows.append({'invocation_id':r['invocation_id'],'receiver_id':r['receiver_id'],'mode':r['mode'],'search_ordering':r['search_ordering'],'raw_result':r['raw_result'],'compile':r['compile'],'inventory_status':r['inventory']['status'],'model':r['model'],'search':r['search'],'target_in_saved_basis':any(f==target for f in basis),'target_formula_count_in_final_command_domain':sum(lastcommandcounts.values()),'final_command_rule_counts':dict(lastcommandcounts),'target_guard_rule_counts':dict(guardcounts),'semantic_proposal_row_span_histogram':[{'kind':k[0],'distinct_rows':k[1],'items':v}for k,v in semantic.items()],'semantic_proposal_max_rows':semantic_max if semantic else None,'sampled_proposal_row_span_histogram':dict(sampled),'support_graph_target_observation':edgeinfo})
 print(r['receiver_id'][-3:],r['mode'],r['search_ordering'],'target_guards',dict(guardcounts),flush=True)
sourcepaths={'master':R/'docs/basic-tiling-algorithm.md','current_closure':R/'.gcts-active/first-order-suite-progress-20261018/runtime-closure-v1.json','Source_comparison':'/private/tmp/gcts-first-order-suite-comparison-peer-20261018/typed-comparison-analysis-v1.json','Root_admission':R/'.gcts-active/first-order-suite-progress-20261018/ROOT-actual-admission-v1.json','data_peer':'/private/tmp/gcts-first-order-suite-retained-data-peer-20261018/typed-data-review-v1.json','semantic_Join':'/private/tmp/gcts-semantic-family-next-audit-20261018/semantic_inventory_guidance.py','family_inventory':'/private/tmp/gcts-semantic-family-next-audit-20261018/semantic_lemma_inventory.py','older_cluster_module':'/private/tmp/gcts-semantic-family-next-audit-20261018/native_inference_inventory.py','point_search':'/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py','helper':'/private/tmp/gcts-and-support-ordering-source-20261018/receptor_support_ordering_v1.py','compiler':'/private/tmp/gcts-quantified-adapter-source-20261018/quantified_receptors_v1.py','symbolic':'/private/tmp/gcts-and-support-ordering-source-20261018/quantified_symbolic_control_v2.py'}
payload={'schema':'recursive-cluster-failed-case-retained-evidence-v1','source_and_retained_data_only':True,'scientific_calls':0,'scientific_replays':0,'checks':checks,'rows':rows,'sources':{k:desc(v)for k,v in sourcepaths.items()},'summary':{'raw_results':len(rows),'checks':len(checks),'mismatches':sum(not a['passed']for a in checks)}}
(O/'failure-evidence-v1.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({'evidence':desc(O/'failure-evidence-v1.json'),'summary':payload['summary']}),flush=True)
