"""Independent retained literal JSON checks only, with no scientific imports/calls."""
from pathlib import Path
import collections,hashlib,json
P=Path('/private/tmp/gcts-inventory-certification-retained-data-peer-20261018')
I=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1/authorized-index-v1.json')
OLDI=Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1/authorized-index-v1.json')
LEDGER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/inventory-certification-progress-20261018')
checks=[];allpins={};coverage=collections.Counter()
def pin(q):
 q=Path(q);b=q.read_bytes();return dict(path=str(q),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def need(ok,label):
 checks.append(dict(check=label,passed=bool(ok)))
 if not ok:raise ValueError(label)
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(x):return hashlib.sha256(canonical(x)).hexdigest()
def get(desc,label):
 q=Path(desc['path']);raw=q.read_bytes();need(pin(q)==desc,'raw complete pin '+label);allpins[str(q)]=desc
 return json.loads(raw)
def point(v):
 if not(type(v)is list and len(v)==2 and all(type(x)is int for x in v)):raise ValueError('literal integer point')
 return tuple(v)
def key(v):
 if not(type(v)is list and len(v)==4 and all(type(x)is int for x in v)):raise ValueError('literal integer key')
 return tuple(v)
def semantic_inventory(inv):return {k:inv[k] for k in ('definitions','interfaces','native_blocks')}
def compiler(c):return {k:v for k,v in c.items() if k!='seconds'}
def model(m):return {k:v for k,v in m.items() if k!='compile_seconds'}
def deps(inv):
 names=[r['name'] for r in inv['definitions']];by={r['name']:r['definition'] for r in inv['definitions']}
 if len(names)!=len(by):raise ValueError('duplicate definition')
 seen=set()
 for n in names:
  if by[n]['name']!=n:raise ValueError('name join')
  if any(c['name'] not in seen for c in by[n]['proof'] if c['rule']=='block'):raise ValueError('not prior dependency')
  seen.add(n)
 if inv['native_blocks']!=[by[n] for n in names]:raise ValueError('ordered complete blocks')
 plans=[]
 for n in names:
  wanted=set();pending=[n]
  while pending:
   x=pending.pop()
   if x in wanted:continue
   wanted.add(x);pending.extend(c['name'] for c in by[x]['proof'] if c['rule']=='block')
  plans.append(dict(definition=n,names=[x for x in names if x in wanted]))
 return names,by,plans or [dict(definition=None,names=[])]
def check_region(d,w,label):
 m=d['outputs']['model'];ini=d['initial_state'];search=d['outputs']['search'];proof=search['proof'];inv=d['outputs']['register'];defs={x['name']:x['definition'] for x in inv['definitions']}
 required={point(x) for x in m['roots']};allowed={point(x) for x in ini['allowed_points']}
 need(len(required)==len(m['roots']) and required==allowed,'complete roots/allowed '+label)
 need(required=={(4*j,r) for j in range(d['declaration']['length']) for r in range(2+m['arity'])},'derived full row-role roots '+label)
 totals={point(p):v for p,v in ini['totals']};marks={point(p):v for p,v in ini['marks']}
 need(len(totals)==len(ini['totals']) and len(marks)==len(ini['marks']),'unambiguous initial full t/m '+label)
 candidates={key(x['key']):x for x in m['placements']};need(len(candidates)==len(m['placements']),'all original candidate identities unique '+label)
 selected=[key(x) for x in search['placements']];need(len(set(selected))==len(selected),'selected keys unique '+label)
 slots={};markpairs=0
 for k in selected:
  need(k in candidates,'selected key from full Model '+label+repr(k));c=candidates[k]
  need(c['occupancy']==[[[4*k[0],k[1]],12]] and k[:2] not in slots,'exact unique positional occupancy '+label+repr(k));slots[k[:2]]=c
  for p,v in c['occupancy']:
   p=point(p)
   if p not in allowed or type(v)is not int or v<=0 or totals.get(p,0)+v>12:raise ValueError('capacity '+label)
   totals[p]=totals.get(p,0)+v
  for p,v in c['marks']:
   p=point(p);markpairs+=1
   if type(v)is not int or (p in marks and marks[p]!=v):raise ValueError('full m agreement '+label)
   marks[p]=v
 need(set(totals)==required and all(v==12 for v in totals.values()),'all t exactly normalized12/12 '+label)
 need(set(slots)=={(j,r) for j in range(len(proof)) for r in range(2+m['arity'])},'all C/G/I rows exactly occupied '+label)
 for j,line in enumerate(proof):
  c=slots[j,0];g=slots[j,1];cmd=dict(c['command'])
  need(cmd==g['command'] and cmd in m['domains'][j],'C/G command and full domain join '+label+str(j))
  for role,tile in [(0,c),(1,g)]:
   md={point(p):v for p,v in tile['marks']}
   for kind,value,x in [('formula',cmd['formula'],4*j),('command',cmd,4*j+1)]:
    word=list(canonical(value))+[256]
    need(all(md.get((x,100+z))==v for z,v in enumerate(word)),'complete literal word+terminator '+label+str((j,role,kind)))
  if cmd['rule']=='block':
   definition=defs[cmd['name']];refs=[]
   for port,f in enumerate(definition['premises']):
    tile=slots[j,2+port];ref=tile['source'];refs.append(ref)
    need(tile['kind']=='lemma_input' and type(ref)is int and 0<=ref<j and proof[ref]['formula']==f,'ordered actual premise receptor '+label+str((j,port)))
   cmd['inputs']=refs
  need(cmd==line,'literal whole row decode '+label+str(j))
  for ref in ([line['antecedent'],line['implication']] if line['rule']=='mp' else [line['source']] if line['rule']=='generalize' else line.get('inputs',[]) if line['rule']=='block' else []):
   need(type(ref)is int and 0<=ref<j,'all strict prior row refs '+label+str(j))
 need(len(proof)==d['declaration']['length'] and proof[-1]['formula']==d['declaration']['target'],'exact final declared row/target '+label)
 union=dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected))
 rh=w['final_region_verification'];need(rh['status']=='VERIFIED_WHOLE_FINITE_POINT_REGION' and rh['union_sha256']==sha(union) and rh['required_points']==len(required) and rh['selected_placements']==len(selected) and rh['assigned_mark_points']==len(marks) and rh['decoded_rows']==len(proof),'whole independent region fingerprint/summary '+label)
 coverage['selected_mark_pairs']+=markpairs;coverage['root_rows']+=len(proof);coverage['selected_tiles']+=len(selected)
 return dict(rows=len(proof),tiles=len(selected),assigned_mark_points=len(marks),mark_pairs_compared=markpairs,union_sha256=sha(union))
need(pin(I)['sha256']=='419adfa495ea3f1a90be681deb3de25c0d4cf309b1d99437c01bdc2b343fb512' and pin(I)['bytes']==48702,'exact20 authorized index')
i=json.loads(I.read_text());oldi=json.loads(OLDI.read_text());closurep=LEDGER/'ROOT-cohort-closure-v1.json';co=json.loads(closurep.read_text());allpins[str(I)]=pin(I);allpins[str(OLDI)]=pin(OLDI);allpins[str(closurep)]=pin(closurep)
need(co['authorized_index']==pin(I) and co['retained_actuals']==20 and len(co['actuals'])==20,'all20 cohort closure identities')
cr={x['invocation_id']:x for x in co['actuals']};caps=get(i['input_capsule'],'frozen full capsule');byid={x['id']:x for x in caps['receivers']};current=[];bases={};modelbase=None;initialbase=None;taut=['imp',['bot'],['bot']]
for row in i['schedule']:
 label=row['invocation_id'];rid=row['receiver_id'];a=Path(row['actual_directory']);w=get(cr[label]['worker_receipt'],label+' worker');run=get(cr[label]['runner_receipt'],label+' runner');d=get(w['result'],label+' full result');wp=get(row['worker_plan'],label+' worker plan');spec=byid[rid];out=d['outputs'];reg=out['register'];records=d['records'];stages=d['transport_receipt']['request_stages'];compiled=out['compile'];inventory=out['specialize'];
 raw=Path(w['result']['path']).read_bytes();need(canonical(d)+b'\n'==raw,'entire full canonical result raw inverse '+label);coverage['full_raw_bytes']+=len(raw)
 need(d['receiver_id']==rid and d['declaration']==spec and d['source_epoch']['receiver_selection']['spec']==spec,'full original assertion/theory/target '+label)
 need(d['inventory_certification_mode']==row['inventory_certification_mode']==wp['inventory_certification_mode'] and d['mode']==row['mode'] and d['search_ordering']=='and_support','full current factor binding '+label)
 need(d['transport_receipt']==w['native_transport']==run['native_transport'],'whole retained broker transcript custody '+label)
 owned=d['source_epoch']['sources']['project'];original={**wp['project_sources'],'semantic_receiver_driver':wp['components']['receiver_driver'],'bounded_request_oracle':wp['components']['bounded_transport']}
 need(d['source_epoch']['sources']['original']==original and len(owned)==len(original)==24,'complete original/owned24Source maps '+label)
 for alias,desc in owned.items():
  rawsource=Path(desc['path']).read_bytes();need(pin(Path(desc['path']))==desc and hashlib.sha256(rawsource).hexdigest()==original[alias]['sha256'] and len(rawsource)==original[alias]['bytes'],'exact owned executable raw Source '+label+':'+alias)
 need(d['policy_pin']=={'sha256':wp['policy']['sha256'],'bytes':wp['policy']['bytes']} and d['policy']==json.loads(Path(wp['policy']['path']).read_text()),'complete4family library literal '+label)
 need(semantic_inventory(reg)==semantic_inventory(inventory),'entire original inventory retained '+label)
 names,by,plans=deps(inventory);need(set(reg['interfaces'])<=set(names) and len(set(reg['interfaces']))==len(reg['interfaces']),'all complete registered interfaces '+label)
 raw_original={k:v for k,v in reg.items() if k not in ['status','query','queries','certification','seconds']};need(raw_original==inventory,'all original inventory fields retained '+label)
 semantic=dict(compiler=compiler(compiled),inventory=semantic_inventory(inventory),specialize=inventory)
 if rid not in bases:bases[rid]={k:canonical(v) for k,v in semantic.items()}
 for k,v in semantic.items():need(canonical(v)==bases[rid][k],'samecase full literal '+k+' '+label)
 need(compiled['status']=='complete','compiler whole complete before registration '+label)
 expected=[(dict(rule='tautology',formula=taut),'first_order_theory_admission')]+[(dict(rule='tautology',formula=f),'first_order_tautology') for f in compiled['catalog']['basis']]+[(c,'first_order_scheme') for c in compiled['catalog']['schemes']]
 need(compiled['queries']==list(range(len(expected))) and len(expected)<=512,'complete compiler schedule prefix '+label)
 need(len(stages)==len(records) and d['transport_receipt']['complete_records']==len(records),'all actual broker requests retained '+label)
 for n,(q,t) in enumerate(zip(records,stages)):
  need(type(q['id'])is int and q['id']==n and t['record_id']==n and t['ordinal']==n and t['stage']=='COMPLETED','serial actual Native/broker '+label+':'+str(n))
  need(q['request_sha256']==sha(q['request'])==t['request_sha256'] and q['purpose']==t['purpose'] and q['input_sha256']==t['input_sha256'] and q['output_sha256']==t['output_sha256'],'whole Native/broker literal hashes '+label+':'+str(n))
  need(q['request']['protocol']=='gcts-fol-1' and q['request']['theory']==spec['theory'],'every exact full Native theory '+label+':'+str(n))
  need(type(q['result']['micro_steps'])is int and 0<=q['result']['micro_steps']<=t['limit'],'every actual passed allowance/step bound '+label+':'+str(n))
 coverage['Native_records']+=len(records)
 tauts=[];schemes=[]
 for n,(command,purpose) in enumerate(expected):
  q=records[n];need(q['request']==dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=[],proof=[command],target=command['formula']) and q['purpose']==purpose and stages[n]['limit']==10**9,'every full original compiler Native request '+label+':'+str(n))
  if n==0:need(q['result']['status']=='accepted','fresh theory admission accepted '+label)
  else:
   need(q['result']['status'] in ['accepted','rejected'],'compiler Native noUNKNOWN admitted '+label+':'+str(n))
   if q['result']['status']=='accepted':(tauts if purpose=='first_order_tautology' else schemes).append(command['formula'] if purpose=='first_order_tautology' else command)
 need(tauts==compiled['tautologies'] and schemes==compiled['admitted_schemes'],'actual full guard admissions literal '+label)
 if row['inventory_certification_mode']=='bulk':
  ids=[reg['query']];need(ids==[len(expected)],'fresh sole bulk registration index '+label);q=records[ids[0]];need(q['request']==dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=inventory['native_blocks'],proof=[dict(rule='tautology',formula=taut)],target=taut) and q['purpose']=='check_generated_lemma_definitions' and stages[ids[0]]['limit']==5*10**9,'entire bulk Native request and actual cap '+label)
  status='native_accepted' if q['result']['status']=='accepted' else 'native_rejected' if q['result']['status']=='rejected' else 'unknown_native_inventory';used=q['result']['micro_steps'];complete=status=='native_accepted';accepted=names if complete else [];laststatus=q['result']['status'];stop=None if complete else laststatus;queriedsizes=[len(names)];nativequeries=[q]
  need(reg['status']==status,'bulk disposition honest '+label)
 else:
  cert=reg['certification'];need(cert['schema']=='native-inventory-dependency-closure-certification-v1' and cert['version']=='native-inventory-exact-dependency-closures-v2' and cert['mode']=='dependency_closures','current exact certification wire '+label)
  need(cert['inventory_sha256']==sha(inventory) and cert['theory_sha256']==sha(spec['theory']) and cert['all_original_definition_names']==names and cert['all_original_interfaces']==inventory['interfaces'] and cert['planned_requests']==plans,'full independent closure provenance '+label)
  rr=cert['receipts'];ids=[x['query'] for x in rr];need(ids==list(range(len(expected),len(expected)+len(rr))) and reg['queries']==ids and reg['query'] is None,'all actual closure prefix serial IDs '+label)
  used=0;aset=set();queriedsizes=[];nativequeries=[]
  for n,(r,plan) in enumerate(zip(rr,plans)):
   q=records[r['query']];allowance=5*10**9-used;wanted=dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=[by[x] for x in plan['names']],proof=[dict(rule='tautology',formula=taut)],target=taut)
   need(r['ordinal']==n and r['definition']==plan['definition'] and r['closure_names']==plan['names'] and q['request']==wanted and q['request_sha256']==sha(wanted),'fresh complete exact recursive closure request '+label+':'+str(n))
   need(q['purpose']=='check_generated_lemma_definition_closure' and stages[r['query']]['limit']==r['assigned_micro_step_limit']==allowance and type(allowance)is int and allowance>0,'ACTUAL broker residual limit '+label+':'+str(n))
   steps=q['result']['micro_steps'];need(r['consumed_micro_steps']==steps and r['aggregate_consumed_before']==used and r['aggregate_consumed_after']==used+steps and r['result_status']==q['result']['status'],'actual closure accounting '+label+':'+str(n));used+=steps
   if q['result']['status']=='accepted':aset.update(plan['names'])
   else:need(n==len(rr)-1,'first Native UNKNOWN/rejection stops whole inventory '+label)
   queriedsizes.append(len(plan['names']));nativequeries.append(q)
  accepted=[x for x in names if x in aset];laststatus=nativequeries[-1]['result']['status'];complete=len(rr)==len(plans) and laststatus=='accepted' and set(accepted)==set(names)
  status='native_accepted' if complete else 'native_rejected' if laststatus=='rejected' else 'unknown_native_inventory';stop=None if complete else laststatus if laststatus!='accepted' else 'aggregate_registration_micro_step_budget'
  need(cert['complete'] is complete and cert['aggregate_micro_step_limit']==5*10**9 and cert['aggregate_consumed_micro_steps']==used and cert['accepted_definition_names']==accepted and cert['stop_reason']==stop and reg['status']==status,'all-or-none whole coverage and exact stop '+label)
  need(out['inventory_record_join']['complete'] is complete and out['inventory_record_join']['aggregate_consumed_micro_steps']==used,'independent saved driver join consistency '+label)
 coverage['registration_queries']+=len(ids)
 positive=bool(d['native_proof_accepted']);region=None;proofinfo=None
 if not complete:
  need(not positive and 'model' not in out and 'search' not in out and 'initial_state' not in d and d['status']==status,'partial inventory never activated Model/search '+label)
  need(len(records)==len(expected)+len(ids),'no post-stop Native/search calls '+label)
 else:
  need('model' in out and 'search' in out,'full inventory Model activation only '+label)
  mbytes=canonical(model(out['model']));ibytes=canonical(d['initial_state'])
  if modelbase is None:modelbase=mbytes;initialbase=ibytes
  need(mbytes==modelbase and ibytes==initialbase,'complete current Model and all initial literals equal '+label)
  need(d['model_identity_sha256']==d['model_after_identity_sha256']==sha(model(out['model'])),'full Model before/after identity '+label)
  need(positive and d['status']=='native_proof_discovered','recorded positive current status '+label)
  proof=out['search']['proof'];needed=set();pending=[x['name'] for x in proof if x['rule']=='block']
  while pending:
   x=pending.pop()
   if x in needed:continue
   needed.add(x);pending.extend(c['name'] for c in by[x]['proof'] if c['rule']=='block')
  actualblocks=[by[x] for x in names if x in needed];expectedfinal=dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=actualblocks,proof=proof,target=spec['target'])
  need(out['final_request']==expectedfinal,'exact all-and-only used recursive blocks/finalproof '+label)
  final=out['final_native'];need(final==records[-1] and final['id']==len(expected)+len(ids) and len(records)==len(expected)+len(ids)+1 and final['purpose']=='fresh_quantified_receiver_final' and final['request']==expectedfinal and final['result']['status']=='accepted' and stages[-1]['limit']==5*10**9,'fresh whole final Native target/proof accepted literal '+label)
  for name in names:
   definition=by[name]
   for j,c in enumerate(definition['proof']):
    refs=[c['antecedent'],c['implication']] if c['rule']=='mp' else [c['source']] if c['rule']=='generalize' else c.get('inputs',[]) if c['rule']=='block' else []
    need(all(type(x)is int and 0<=x<j for x in refs),'strict earlier full block-body port/ref '+label+':'+name+':'+str(j))
    if c['rule']=='assumption':need(type(c['index'])is int and 0<=c['index']<len(definition['premises']) and c['formula']==definition['premises'][c['index']],'body assumption literal receptor '+label+':'+name+':'+str(j))
   need(definition['proof'][-1]['formula']==definition['conclusion'],'every registered full body final conclusion '+label+':'+name)
  region=check_region(d,w,label)
  need(out['search'].get('root_restored') is True if row['mode']=='fixed' else out['search']['root_path_restored'] is True,'method-specific exact root/prefix restore flag '+label)
  proofinfo=dict(proof_sha256=sha(proof),final_request_sha256=sha(expectedfinal),used_definitions=[x for x in names if x in needed],root_rules=dict(collections.Counter(c['rule'] for c in proof)),essential_calls=out['essential_ancestry']['essential_calls'],essential_quantifier_counts={x:out['essential_ancestry'][x] for x in ['essential_instantiate_count','essential_generalize_count']})
 # Retained last wire files are checked as bytes only; no native decoding.
 need(pin(a/'native/input.bin')['sha256']==records[-1]['input_sha256'] and pin(a/'native/output.bin')['sha256']==records[-1]['output_sha256'],'last complete raw Native input/output hashes only '+label)
 current.append(dict(invocation_id=label,receiver_id=rid,mode=row['mode'],inventory_certification_mode=row['inventory_certification_mode'],result=w['result'],worker_receipt=cr[label]['worker_receipt'],runner_receipt=cr[label]['runner_receipt'],status=d['status'],compiler_queries=len(expected),basis_count=len(compiled['basis']),definitions=len(names),interfaces=len(reg['interfaces']),registration_queries=len(ids),accepted_definitions=len(accepted),last_result_status=laststatus,stop_reason=stop,registration_micro_steps=used,registration_seconds=reg['seconds'],registration_request_seconds=sum(x['seconds'] for x in nativequeries),registration_CPP_seconds=sum(x['result']['seconds'] for x in nativequeries),planned_closure_max=max(len(x['names']) for x in plans),queried_closure_sizes=queriedsizes,queried_closure_max=max(queriedsizes),last_queried_definition=None if row['inventory_certification_mode']=='bulk' else plans[len(ids)-1]['definition'],next_unqueried_definition=None if row['inventory_certification_mode']=='bulk' or len(ids)==len(plans) else plans[len(ids)]['definition'],complete_inventory=complete,Native_records=len(records),Native_total_micro_steps=sum(x['result']['micro_steps'] for x in records),model_present='model'in out,search_present='search'in out,positive=positive,region=region,proof=proofinfo,stage_intervals=d['stage_intervals']))
 del d
# Compare every available prior samecase literal, not merely hashes; no historical native execution.
prior=[]
for r in oldi['schedule']:
 rid=r['receiver_id']
 if rid not in bases:continue
 a=Path(r['actual_directory']);w=json.loads((a/'worker-receipt.json').read_text());d=get(w['result'],'prior full original '+r['invocation_id']);out=d['outputs'];semantic=dict(compiler=compiler(out['compile']),inventory=semantic_inventory(out['register']),specialize=out['specialize'])
 for k,v in semantic.items():need(canonical(v)==bases[rid][k],'PRIOR full ordinary literal '+k+' '+r['invocation_id'])
 if 'model'in out:need(canonical(model(out['model']))==modelbase and canonical(d['initial_state'])==initialbase,'PRIOR full Model/initial unchanged '+r['invocation_id'])
 prior.append(dict(invocation_id=r['invocation_id'],result=w['result'],model_available='model'in out,full_literals_compared=list(semantic)+(['model_except_compile_seconds','all_initial_fields'] if 'model'in out else [])))
 del d
need(len(prior)==20 and len(current)==20,'all20 current and20 relevant prior full results covered')
need(pin(I)['sha256']=='419adfa495ea3f1a90be681deb3de25c0d4cf309b1d99437c01bdc2b343fb512','authorized index unchanged')
audit=dict(schema='inventory-certification-retained-independent-data-audit-v1',reviewer_identity='/root/conventional_library',author_identity='/root',authorized_index=pin(I),cohort_closure=pin(closurep),prior_index=pin(OLDI),current=current,prior=prior,checks=checks,checks_passed=len(checks),mismatches=0,coverage=dict(coverage),rawpins=list(allpins.values()),source_only=False,saved_data_only=True,scientific_calls=0,scientific_replays=0,module_evaluations=0,Native_calls=0,fixture_executions=0,scientific_acceptance=False,actual_execution_authorized=False)
q=P/'raw-data-audit-v1.json';q.write_text(json.dumps(audit,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(audit=pin(q),checks=len(checks),coverage=dict(coverage),rows=[{k:r[k] for k in ['invocation_id','definitions','registration_queries','accepted_definitions','last_result_status','registration_micro_steps','planned_closure_max','queried_closure_max','positive']} for r in current])))
