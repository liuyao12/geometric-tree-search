"""Read-only complete public-byte verification. No scientific evaluation."""
from pathlib import Path
import concurrent.futures,hashlib,json,urllib.request,time,sys,re
R=Path(__file__).resolve().parent
BASE='https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/'
def verify(d,commit):
 url=BASE+Path(d['path']).name+'?v=20261018-ic-'+commit[:8]
 began=time.monotonic();h=hashlib.sha256();size=0
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'GCTS-research-publication-verification','Cache-Control':'no-cache'})
  with urllib.request.urlopen(req,timeout=45) as response:
   status=response.status
   while True:
    chunk=response.read(min(1048576,d['bytes']+1-size))
    if not chunk:break
    size+=len(chunk);h.update(chunk)
    if size>d['bytes']:break
  return dict(url=url,status=status,bytes=size,sha256=h.hexdigest(),seconds=time.monotonic()-began,
   verified=status==200 and size==d['bytes'] and h.hexdigest()==d['sha256'],local=d)
 except Exception as ex:
  return dict(url=url,verified=False,error=type(ex).__name__+': '+str(ex),bytes=size,seconds=time.monotonic()-began,local=d)
def main():
 assert len(sys.argv)in [3,4]
 commit=sys.argv[1];assert re.fullmatch('[0-9a-f]{40}',commit)
 assets=json.loads((R/'ROOT-publication-assets-v1.json').read_bytes())['assets'];assert len(assets)==43
 previous=None
 if len(sys.argv)==4:
  previous=json.loads((R/sys.argv[3]).read_bytes());assert previous['commit']==commit
  keep={r['local']['path']:r for r in previous['assets'] if r['verified']}
  todo=[d for d in assets if d['path']not in keep]
 else:keep={};todo=assets
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  fresh=list(pool.map(lambda d:verify(d,commit),todo))
 by={r['local']['path']:r for r in fresh};by.update(keep)
 rows=[by[d['path']] for d in assets]
 out=dict(schema='ROOT-inventory-certification-live-HTTP-verification-v1',commit=commit,assets=rows,total_assets=len(rows),
  all_exact_public_bytes=all(r['verified']for r in rows),verified_bytes=sum(r.get('bytes',0)for r in rows if r['verified']),
  fresh_verifications=len(fresh),previous_record=sys.argv[3]if previous else None,scientific_calls=0,goal_complete=False)
 p=R/sys.argv[2]
 with p.open('x') as f:f.write(json.dumps(out,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(record=str(p),verified=sum(r['verified']for r in rows),total=len(rows),bytes=out['verified_bytes'],failed=[dict(url=r['url'],error=r.get('error'),status=r.get('status'),bytes=r.get('bytes'))for r in rows if not r['verified']])))
 if not out['all_exact_public_bytes']:raise SystemExit(2)
if __name__=='__main__':main()
