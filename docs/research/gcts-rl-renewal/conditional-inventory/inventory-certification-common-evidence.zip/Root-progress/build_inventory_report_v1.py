"""Saved-data HTML projection only. No Native, Model, prover, compiler or search calls."""
from pathlib import Path
import json,hashlib,gzip,html,importlib.util,gc
R=Path(__file__).resolve().parent
SITE=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
P=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def e(x):return html.escape(str(x),quote=True)
def m(x):return '\\('+e(x)+'\\)'
def num(x):return m(f'{x:,}'.replace(',','\\,'))
def js(x):return json.dumps(x,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n'
def write(n,x):
 p=SITE/n
 if isinstance(x,str):x=x.encode()
 with p.open('xb')as f:f.write(x)
 return pin(p)
def main():
 a=load(R/'ROOT-actual-admission-v1.json');assert not a['findings']and a['retained_actuals']==20 and a['within_resource_profile']==20 and a['fresh_native_proofs']==4
 idx=load(P/'authorized-index-v1.json');rows=a['actuals']
 rp=Path('/private/tmp/gcts-semantic-proof-renderer-source-20261018/semantic_proof_renderer_v2.py')
 assert pin(rp)['sha256']=='bd929c531205dfd9fcfd6732c9de554d71e2abdd492a80aac1dd094965b77e77'
 s=importlib.util.spec_from_file_location('pure_saved_proof_display',rp);renderer=importlib.util.module_from_spec(s);s.loader.exec_module(renderer)
 parent=SITE/'first-order-suite.html';head=parent.read_text().split('<p class="eyebrow">',1)[0]
 head=head.replace('Forty first-order proof-search runs — GCTS research','Inventory certification: twenty measured runs — GCTS research')
 at=head.index('<nav>');end=head.index('</nav>',at)+6
 nav='<nav><a href="reader.html#inventory-certification">Notebook</a><a href="inventory-certification.html#outcomes">Twenty outcomes</a><a href="inventory-certification.html#costs">Budgets and costs</a><a href="inventory-certification.html#proofs">Proof rows and markings</a><a href="inventory-certification.html#evidence">Evidence</a></nav>'
 head=head[:at]+nav+head[end:]
 head=head.replace('</style>','.pipeline{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:24px 0}.pipeline article{padding:18px;border:1px solid #bcced4;border-top:5px solid #8150a5;background:#f5f3f9}.pipeline article:last-child{border-top-color:#278477}.step-stop{background:#eee7f7;color:#573879}.space-stop{background:#f8e5cc;color:#714d1c}.proof-pass{background:#dcefe7;color:#195e4a}.matrix a{color:inherit}.band{font-size:14px;padding:16px;background:#eef5f7}.inventory-table{font-size:14px}.inventory-table code{word-break:normal}.micro{font-size:12px;word-break:break-all}@media(max-width:760px){.pipeline{grid-template-columns:1fr}}</style>')
 names={('fixed','bulk'):'GCTS · bulk',('fixed','dependency_closures'):'GCTS · closures',('symbolic','bulk'):'Symbolic · bulk',('symbolic','dependency_closures'):'Symbolic · closures'}
 arms=list(names);assets=[];downloads={};proofs={};extra={}
 for r in rows:
  raw=Path(r['result']['path']).read_bytes();assert pin(r['result']['path'])==r['result'];d=json.loads(raw)
  stem='inventory-cert-'+r['receiver_id'][-3:]+'-'+r['mode']+'-'+('bulk'if r['inventory_certification_mode']=='bulk'else 'closures')
  href=stem+'-result.json.gz';assets.append(write(href,gzip.compress(raw,compresslevel=6,mtime=0)));downloads[r['invocation_id']]=href
  inv=d['outputs']['register'];c=inv.get('certification')
  extra[r['invocation_id']]=dict(accepted_definition_count=len(c['accepted_definition_names'])if c else(len(inv['definitions'])if inv['status']=='native_accepted'else None),planned_max_closure_definitions=max((len(x['names'])for x in c['planned_requests']),default=0)if c else len(inv['definitions']),actual_max_closure_definitions=max((len(x['closure_names'])for x in c['receipts']),default=0)if c else len(inv['definitions']),space_unknown_queries=sum(x['result']['status']=='unknown_space_budget'for x in d['records']if x['purpose'].startswith('check_generated_lemma')),step_unknown_queries=sum(x['result']['status']=='unknown_step_budget'for x in d['records']if x['purpose'].startswith('check_generated_lemma')))
  if r['fresh_native_proof']:
   file=stem+'-proof.html';proofs[r['invocation_id']]=file
   label=names[r['mode'],r['inventory_certification_mode']]
   fragment=renderer.render_result(d,label,raw_href=href)
   intro=r'<p class="eyebrow">NEW MEASURED POSITIVE CONTROL · 18 OCTOBER 2026</p><h1>An automatically discovered proof, row by row.</h1><p class="lead">From '+m('a=b')+' and '+m('P(a)')+', the search derives '+m('P(b)')+r'. Read the selected point-tile rows as formulas and English, expand their colored markings, and inspect every reusable lemma body.</p>'
   intro+='<p class="status">Root admitted the complete finite point region and the fresh final Native proof request within the original resource profile. This is a new once-only run of a previously solved control; it adds no newly solved theorem family.</p>'
   intro+='<p><a href="inventory-certification.html#case-001">All four controls and certification costs</a> · <a href="#proof-reader">Proof rows and colored markings</a>.</p><p class="scope">The same twelve-row finite grammar, generic lemma templates and complete candidate Model are used. The target row sequence was chosen by search. Square glyphs depict translation-only point tiles with nonlocal markings; a single universal nearest-neighbor Wang palette remains open. All retained rows, including padding, are shown.</p>'
   assets.append(write(file,head+intro+'<div id="proof-reader">'+fragment+'</div></main></body></html>'))
  del d,raw;gc.collect()
 bycase={rid:[r for r in rows if r['receiver_id']==rid]for rid in idx['case_declarations']}
 def status(r):
  if r['fresh_native_proof']:return 'proof-pass','Proof'
  if r['registration']['native_status']=='unknown_step_budget':return 'step-stop','Work cap'
  return 'space-stop','Space cap'
 matrix=[];cases=[];full=[];requests=[]
 titles={'001':'Known positive: equality predicate transport','002':'Function congruence','003':'Equality chain','005':'Binary relation permutation','010':'Renaming of case 005'}
 for rid,rr in bycase.items():
  n=rid[-3:];by={(r['mode'],r['inventory_certification_mode']):r for r in rr};cells=[]
  for arm in arms:
   r=by[arm];cls,label=status(r);href=proofs.get(r['invocation_id'],'#case-'+n)
   cells.append('<td class="'+cls+'"><a href="'+href+'">'+label+'</a></td>')
  matrix.append('<tr><th><a href="#case-'+n+'"><code>'+n+'</code> '+titles[n]+'</a></th>'+''.join(cells)+'</tr>')
  c=load(idx['case_declarations'][rid]['path'])['selected_receiver']
  formula='\\{'+',\\;'.join(renderer._formula(x)for x in c['theory']['axioms'].values())+'\\}\\;\\vdash\\;'+renderer._formula(c['target'])
  links=[]
  for r in rr:
   label=names[r['mode'],r['inventory_certification_mode']];cls,out=status(r);i=r['registration'];x=extra[r['invocation_id']]
   links.append('<li>'+e(label)+': '+('<a href="'+proofs[r['invocation_id']]+'#proof-reader">formula, English and actual colored point rows</a>'if r['fresh_native_proof']else out+' before Model and search')+'. <a href="'+downloads[r['invocation_id']]+'">Full raw result (gzip)</a>.</li>')
  cases.append('<article class="case" id="case-'+n+'"><h3><code>'+n+'</code> '+titles[n]+'</h3><p class="note">'+('Correlated renaming control; paired with case <code>005</code>.'if n=='010'else 'Previously solved control; same complete Model tested in all four arms.'if n=='001'else 'Previously observed inventory-space failure; outcome known when this engineering cohort was selected.')+'</p>\\['+e(formula)+'\\]<ul>'+''.join(links)+'</ul></article>')
  b=by['fixed','bulk']['registration'];cl=by['fixed','dependency_closures']['registration'];x=extra[by['fixed','dependency_closures']['invocation_id']]
  requests.append('<tr><th><code>'+n+'</code></th><td>'+num(b['definitions'])+'</td><td>'+num(b['maximum_request_bytes'])+'</td><td>'+num(cl['maximum_request_bytes'])+'</td><td>'+num(x['accepted_definition_count'])+' of '+num(b['definitions'])+'</td><td>'+num(cl['requests'])+' of '+num(cl['planned_requests'])+'</td><td>'+num(x['actual_max_closure_definitions'])+' actual / '+num(x['planned_max_closure_definitions'])+' planned</td></tr>')
 for r in rows:
  i=r['registration'];cls,out=status(r);x=extra[r['invocation_id']]
  reg=next(t['returned_monotonic']-t['started_monotonic']for t in r['stage_intervals']if t['stage']=='register')
  full.append('<tr><td>'+num(r['order'])+'</td><th><code>'+r['receiver_id'][-3:]+'</code> '+e(names[r['mode'],r['inventory_certification_mode']])+'</th><td class="'+cls+'">'+out+'</td><td>'+num(i['consumed_micro_steps'])+'</td><td>'+m(f'{reg:.3f}')+'</td><td>'+m(f'{r["outer_terminal_seconds"]:.3f}')+'</td><td>'+m(f'{r["peak_sum_MiB"]:.1f}')+'</td><td><a href="'+downloads[r['invocation_id']]+'">Full raw</a></td></tr>')
 summary=dict(schema='inventory-certification-public-summary-v1',actuals=rows,certificate_display=extra,raw_downloads=downloads,proof_readers=proofs,total_actuals=20,proof_instances=4,newly_solved_inputs=0,bulk_space_stops=8,closure_work_stops=8,all_within_profile=True,all_original_inventory_and_available_Model_preimages_equal=True,Root_admission=pin(R/'ROOT-actual-admission-v1.json'),new_RL_training=False,goal_complete=False,scope='Known five-input engineering comparison, four primary patterns with005/010correlated; all four previously failed inputs plus one known successful control. One deterministic run per arm. Native certification factor only; no new theorem family, generic speed claim, GCTS/RL search advantage or universal Wang completion.')
 assets.append(write('inventory-certification-summary.json',js(summary)))
 for n,f in [('admission','ROOT-actual-admission-v1.json'),('design','prospective-design-v1.json'),('runtime-closure','runtime-closure-v1.json'),('heap-evidence','ROOT-saved-inventory-heap-evidence-v1.json')]:assets.append(write('inventory-certification-'+n+'.json',(R/f).read_bytes()))
 assets.append(write('inventory-certification-inputs.json',Path(idx['input_capsule']['path']).read_bytes()))
 report=head+r'''<p class="eyebrow">INVENTORY CERTIFICATION EXPERIMENT · 18 OCTOBER 2026</p>
<h1>Small checks fit. The full inventory still hits its work cap.</h1>
<p class="lead">Checking each generated lemma with its dependencies avoids the observed space failures, but the larger inventories exhaust the same total checking allowance before search can start. A known positive control passes in all four variants with identical candidate Models and initial point data.</p>
<p class="status">Twenty once-only sequential runs. Four admitted proof instances of the known control; eight bulk space stops; eight closure work-budget stops. All twenty pass the original full resource profile. No new theorem family is solved.</p>
<section id="outcomes"><h2>All twenty outcomes</h2><div class="stage-flow"><article><div class="counter">\(4\)</div><h3>Control proofs</h3><p>Both search methods and both certification modes prove the known equality-transport statement.</p></article><article><div class="counter">\(8\)</div><h3>Bulk space stops</h3><p>The complete request again exceeds the Native machine’s fixed simulated space.</p></article><article><div class="counter">\(8\)</div><h3>Closure work stops</h3><p>Smaller requests consume the shared \(5\times10^9\) microsteps before all definitions pass.</p></article></div>
<div class="table-wrap"><table class="matrix"><thead><tr><th>Input</th>'''+''.join('<th>'+e(names[x])+'</th>'for x in arms)+r'''</tr></thead><tbody>'''+''.join(matrix)+r'''</tbody></table></div>
<p class="caption">This known-outcome engineering cohort includes all four formerly space-limited inputs and one previously successful control. Case <code>010</code> renames <code>005</code>; they are correlated. The older <a href="first-order-suite.html#outcomes">forty-run benchmark</a> remains unchanged. These twenty runs do not measure new theorem coverage or a search-method advantage.</p></section>
<section id="mechanism"><h2>What changed in certification</h2><div class="pipeline"><article><h3>Complete inventory</h3><p>Keep every original definition, interface and literal proof body in registry order. No accepted prefix becomes a smaller search library.</p></article><article><h3>Fresh dependency checks</h3><p>Send the full theory and each definition’s exact dependency closure to the unchanged Native checker. All requests share one work allowance.</p></article><article><h3>All-or-none admission</h3><p>Only complete acceptance permits Model construction and search. A discovered proof still needs its fresh whole-proof check and complete point-region verification.</p></article></div>
<p>The new driver independently reconstructs each dependency closure and joins its full literal request, Native result and actual broker allowance. A checked lemma is never imported as a new axiom. In the successful control all ten original definitions pass; all four complete Models and initial states equal each other and the prior cohort, excluding only declared timing diagnostics.</p>
<p>On larger inputs, the final closure query reports <code>unknown_step_budget</code>, and the exact sum of consumed registration microsteps is \(5\times10^9\). The complete original inventory remains in the result; Model construction and search are blocked. A prefix of individually accepted definitions supplies no partial search authority.</p></section>
<section id="costs"><h2>Smaller requests, incomplete certification</h2>
<p>The following sizes are canonical request JSON bytes, rather than Native tape size. Values agree across the two methods. Queried counts include the final budget-UNKNOWN request. Every actual closure request in this cohort contains one definition; case <code>003</code> plans closures of up to three definitions, but reaches its work cap before those recursive requests are issued.</p>
<div class="table-wrap"><table class="inventory-table"><thead><tr><th>Input</th><th>All definitions</th><th>Bulk bytes</th><th>Largest issued closure bytes</th><th>Accepted definitions</th><th>Issued / planned queries</th><th>Largest closure</th></tr></thead><tbody>'''+''.join(requests)+r'''</tbody></table></div>
<p>The control requires \(1\,876\,601\,674\) bulk microsteps or \(1\,690\,782\,155\) across its ten closure checks. The smaller mode is not intrinsically more expensive in this sample. On the larger inputs we have no completed bulk check to compare with a completed closure check. The data establish incomplete certification under the fixed allowance, rather than a general cost law.</p>
<h3>Complete costs in declared order</h3><p>Registration seconds use the full driver stage interval. Terminal time includes cold preparation, checking, serialization, whole-result reading and external closure. Memory is the conservative sum of separate Darwin Python-worker and Native high-water peaks; it is not a simultaneous live peak. Controller, outer-runner and observer memory are excluded.</p>
<div class="table-wrap"><table class="inventory-table"><thead><tr><th>Order</th><th>Input and arm</th><th>Outcome</th><th>Registration microsteps</th><th>Registration s</th><th>Full terminal s</th><th>Peak sum MiB</th><th>Retained data</th></tr></thead><tbody>'''+''.join(full)+r'''</tbody></table></div>
<p>All runs retain \(180\) seconds for work, \(210\) for the externally observed terminal, a \(1\) GiB conservative peak sum, \(128\) MiB full result and \(4\) MiB per log. Positive proof output, full positive checks and known worker exit must precede the work endpoint. Search retains \(12\) rows, two catalog rounds, \(30\) seconds and \(5\,000\) method-specific work units. The shared support ordering and all search Sources are unchanged.</p></section>
<section id="proofs"><h2>Statements, proof rows and markings</h2><p>The four successful readers show every retained root line as a formula and English, actual selected C/G/input tiles with colored nonlocal markings, exact ordered ports and all reusable lemma bodies. These are fresh runs of the previously solved control; no target proof sequence was supplied. Inventory UNKNOWN inputs have no invented proof rows.</p>'''+''.join(cases)+r'''</section>
<section id="assessment"><h2>Assessment and next experiment</h2><p>This is useful checker and inventory engineering evidence. It establishes neither a new GCTS search advantage nor an RL gain: the larger inputs never reach either search method, and no new RL training occurs. The two methods retain their existing semantics: complete point-candidate GCTS scheduling versus a specialized chronological symbolic control.</p>
<p>The next certification experiment should group several definitions into dependency-closed batches, retaining every definition and the same aggregate allowance. Batch planning or adaptive splits must charge all setup and failed probes, keep all-or-none admission, and retain a fresh final whole-proof Native gate. Its capacity and cost remain unmeasured. Single-definition checking is an explicit tested control.</p>
<p>The separate recursive-cluster design proposes a bounded missing-premise DAG with typed open receptors, shared row identities and scheduler-validated continuations. It remains a design, with no implementation or new RL/proof-search result. Once full inventories can be certified practically, it should be tested as a separate factor against the same conventional support heuristic.</p>
<p>Source reviews and saved-data audits have distinct scopes and disclosed inherited authorship. Parallel agents review registry/driver composition, plans, mathematical data and resources; Root freezes the experiments, performs separate admission and publishes. All timed runs were sequential with other agents idle. Native checker correctness remains an inherited premise, rather than a newly proved kernel theorem.</p>
<p>The research program remains active: a growing learned lemma hierarchy, a fixed universal proof-tile palette, Peano induction, Hilbert geometry, unmarked Turtle/Penrose experiments and infinite-plane or substitution certificates are not established by this experiment.</p></section>
<section id="evidence"><h2>Full evidence and reproducibility</h2><p><a href="inventory-certification-summary.json">Results and display facts</a> · <a href="inventory-certification-admission.json">Root retained-data admission</a> · <a href="inventory-certification-design.json">Frozen twenty-run design</a> · <a href="inventory-certification-inputs.json">Original input capsule</a> · <a href="inventory-certification-runtime-closure.json">Complete runtime identities</a> · <a href="inventory-certification-heap-evidence.json">Prior space diagnosis</a> · <a href="inventory-certification-evidence-manifest.json">Published member hashes</a>.</p>
<p><a href="inventory-certification-data-review.json">Independent data review</a> · <a href="inventory-certification-resource-review.json">Independent resource review</a> · <a href="inventory-certification-report-review.json">Independent report/package review</a>.</p>
<p><a href="inventory-certification-common-evidence.zip">Common Sources, all plans, grants and scoped reviews</a>. Each case archive retains all four complete raw results, receipts, logs, owned Sources, Native artifacts and terminal observations: '''+' · '.join('<a href="inventory-certification-case-'+rid[-3:]+'-evidence.zip"><code>'+rid[-3:]+'</code></a>'for rid in bycase)+r'''. External interpreter and solver distributions remain pinned prerequisites on the declared Darwin platform.</p><p>Individual ordinary result gzip files preserve all raw bytes. Packaging and display evaluate no Native code, compiler, Model or search; opaque Native inputs are copied and hashed without decoding. These readers add no hidden derivations.</p></section><footer><a href="reader.html#inventory-certification">Research notebook</a> · <a href="first-order-suite.html#outcomes">Earlier forty-run comparison</a>. The full research goal remains open.</footer></main></body></html>'''
 assets.append(write('inventory-certification.html',report))
 # Preserve exact pre-edit baselines for targeted diff/link audit.
 baseline=R/'publication-baselines';baseline.mkdir()
 for n in ['reader.html','first-order-suite.html']:(baseline/n).write_bytes((SITE/n).read_bytes())
 reader=SITE/'reader.html';s=reader.read_text();marker='<section id="first-order-suite">';assert s.count(marker)==1
 section=r'<section id="inventory-certification"><p class="eyebrow">LATEST CHECKER EXPERIMENT · TWENTY ONCE-ONLY RUNS</p><h2>Smaller checks expose the work limit.</h2><p>Dependency-closure certification avoids the observed space stops but exhausts the same aggregate allowance on larger inventories. All twenty runs pass the original full profile; the known positive control yields four admitted proofs with identical Models. No new theorem family or GCTS/RL search gain follows.</p><p><a href="inventory-certification.html#outcomes"><b>All outcomes, exact budget use and next experiment</b></a> · <a href="inventory-certification.html#proofs">Proof rows, English and actual colored markings</a>.</p></section>'
 reader.write_text(s.replace(marker,section+marker,1));assets.append(pin(reader))
 s=parent.read_text();marker='<section id="outcomes">';assert s.count(marker)==1
 banner='<p class="band">Later inventory-certification experiment: twenty new once-only runs isolate the checker bottleneck. Smaller requests avoid the observed space stops but exhaust the fixed work allowance on larger inventories. <a href="inventory-certification.html#outcomes">Read the complete new comparison</a>. The forty-run cohort below is retained unchanged.</p>'
 parent.write_text(s.replace(marker,banner+marker,1));assets.append(pin(parent))
 out=dict(schema='ROOT-inventory-certification-report-draft-assets-v1',assets=assets,proof_readers=proofs,raw_downloads=downloads,pure_renderer=pin(rp),summary=pin(SITE/'inventory-certification-summary.json'),report=pin(SITE/'inventory-certification.html'),scientific_replays=0,peer_reviews_pending=True,goal_complete=False)
 with (R/'ROOT-report-draft-assets-v1.json').open('x')as f:f.write(js(out))
 print(js(dict(assets=len(assets),report=out['report'],proof_readers=proofs,display=extra)))
if __name__=='__main__':main()
