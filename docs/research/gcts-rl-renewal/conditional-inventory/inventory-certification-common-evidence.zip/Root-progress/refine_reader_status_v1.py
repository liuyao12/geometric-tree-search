"""Resolve the report review's dated-status label finding; no result data change."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
p=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory/reader.html')
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
before=pin(p);raw=p.read_bytes();(R/'publication-reader-superseded-v1.html').write_bytes(raw)
s=raw.decode();old='LATEST MEASURED COHORT · FORTY FROZEN RUNS';assert s.count(old)==1;p.write_text(s.replace(old,'EARLIER FORTY-RUN COHORT'))
v=dict(schema='ROOT-inventory-certification-report-status-finding-v1',reviewer='/root/conventional_library',finding='The older40run card below the new20run card still used the unqualified latest-measured-cohort label.',before=before,preserved_before=pin(R/'publication-reader-superseded-v1.html'),after=pin(p),resolution='Relabel only the older eyebrow as EARLIER FORTY-RUN COHORT; all old scientific statistics/body text unchanged.',scientific_changes=0,scientific_calls=0)
with(R/'ROOT-report-status-finding-v1.json').open('x')as f:f.write(json.dumps(v,sort_keys=True,indent=2)+'\n')
print(json.dumps(v))
