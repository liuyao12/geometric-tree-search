"""Root sequential observer launcher V2, complete subject preflight. No scientific imports or result replay.

All twenty original subjects must be granted and adopted before entry. Every
scientific window is owned by its unchanged once runner/worker. This launcher
reads small transport receipts only between windows and stops on ambiguous
process closure. A failed resource/proof outcome never removes a later slot.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

R=Path(__file__).resolve().parent
P=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1')

def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(ok,message):
    if not ok:raise ValueError(message)
def save(p,value):
    with Path(p).open('x') as f:
        f.write(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
    return pin(p)

def main():
    adopted=load(R/'ROOT-final-grant-adoption-v1.json');idx=load(P/'authorized-index-v1.json')
    need(adopted['metadata_adoption_passed'] is True and adopted['actual_execution_authorized'] is True,'Root complete current grant adoption')
    need(adopted['authorized_index']==pin(P/'authorized-index-v1.json'),'whole adopted twenty-index')
    need(adopted['launcher']==pin(__file__),'reviewed exact current launcher')
    need(idx['schema']=='ROOT-inventory-certification-authorized-index-v1' and idx['actual_execution_authorized'] is True,'true index')
    need(adopted['design']==pin(R/'prospective-design-v1.json'),'whole adopted prospective design')
    design=load(R/'prospective-design-v1.json');rows=idx['schedule']
    need(len(design['schedule'])==20,'whole design has twenty subjects')
    need(len({r['actual_directory']for r in rows})==20,'twenty unique actual directories')
    need(len(rows)==20 and len({r['invocation_id']for r in rows})==20,'all twenty once-only subjects')
    for expected,row in zip(design['schedule'],rows):
        need(all(row[k]==v for k,v in expected.items()),'unchanged full prescribed order')
        need(pin(row['runner_plan']['path'])==row['runner_plan'],'whole current runner plan')
        need(pin(row['authorization']['path'])==row['authorization'],'whole current true grant')
        plan=load(row['runner_plan']['path']);auth=load(row['authorization']['path'])
        need(plan['authorization']==row['authorization'],'plan binds same whole grant')
        need(all(plan[k]==row[k] for k in ['invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory']),'all twenty plan/row identities')
        need(plan['worker_plan']==row['worker_plan'] and pin(row['worker_plan']['path'])==row['worker_plan'],'all twenty exact worker paths and bytes')
        need(plan['integration_declaration']==idx['case_declarations'][row['receiver_id']] and plan['runtime_closure']==idx['runtime_closure'],'all twenty case/closure subjects')
        subject={k:v for k,v in plan.items() if k!='authorization'}
        raw=json.dumps(subject,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
        need(len(subject)==18 and hashlib.sha256(raw).hexdigest()==row['subject_sha256']==auth['subject_sha256'],'all twenty whole original subjects')
        need(auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations']==1,'all twenty true max-one grants')
        need(set(auth['review_roles'])==set(idx['current_review_roles']),'all twenty complete current roles')
        for role,binding in auth['review_roles'].items():
            need(binding['receipt']==idx['current_review_roles'][role] and pin(binding['receipt']['path'])==binding['receipt'],'whole current role receipt')
        worker=load(row['worker_plan']['path'])
        need(all(worker[k]==plan[k]for k in ['invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory','cold','python','integration_declaration','runtime_closure']),'all twenty worker/plan paths and identity bindings')
        need(worker['declaration']==idx['input_capsule'],'all twenty frozen full input capsule')
        for key in ['cold','runner','observer']:
            need(plan[key]==idx[key] and pin(plan[key]['path'])==plan[key],'all twenty current entry Source '+key)
        need(not Path(row['actual_directory']).exists(),'all actual paths fresh before any launch')
        plan_path=Path(row['runner_plan']['path'])
        need(not plan_path.with_name(plan_path.stem+'-terminal-observation').exists(),'all observer paths fresh before any launch')
    marker=save(R/'COHORT-LAUNCHER-CONSUMED-v1.json',dict(schema='ROOT-inventory-certification-launcher-consumed-v1',
        pid=os.getpid(),started_ns=time.monotonic_ns(),authorized_index=pin(P/'authorized-index-v1.json'),
        launcher=pin(__file__),maximum_subjects=20,scientific_admission=False))
    slots=R/'launcher-slots';slots.mkdir();closed=[]
    for order,row in enumerate(rows,1):
        # Optional Root stop between already authorized windows. A stopped
        # controller never resumes/restarts itself or retries a consumed slot.
        if (R/'STOP-BEFORE-NEXT-SLOT').exists():
            save(R/'ROOT-launcher-stopped-v1.json',dict(completed=len(closed),closed=closed,next_invocation_id=row['invocation_id'],scientific_admission=False))
            return 3
        plan=load(row['runner_plan']['path'])
        need(plan['invocation_id']==row['invocation_id'],'exact selected current plan')
        for key in ['python','observer','runner','cold']:
            need(pin(plan[key]['path'])==plan[key],'current raw '+key)
        command=[plan['python']['path'],'-I','-S','-B',plan['observer']['path'],row['runner_plan']['path']]
        slot=slots/row['invocation_id'];slot.mkdir()
        save(slot/'START.json',dict(order=order,subject=row['subject_sha256'],command=command,started_ns=time.monotonic_ns()))
        print(json.dumps(dict(event='START',order=order,total=20,invocation_id=row['invocation_id'])),flush=True)
        # Exactly one observer launch. No timeout-driven or outcome-driven retry.
        process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        stdout,stderr=process.communicate()
        (slot/'observer-stdout.bin').write_bytes(stdout);(slot/'observer-stderr.bin').write_bytes(stderr)
        actual=Path(row['actual_directory']);plan_path=Path(row['runner_plan']['path'])
        tp=plan_path.with_name(plan_path.stem+'-terminal-observation')/'terminal.json'
        t=load(tp);q=load(actual/'runner-receipt.json')
        need(t['runner_receipt']==pin(actual/'runner-receipt.json'),'whole closed outer receipt')
        need(t['plan']==row['runner_plan']==q['plan'],'same exact closed subject')
        need(not t.get('residual_worker_cleanup_requires_inspection',False),'no unresolved observer fallback ownership')
        need(q['python_reaped'] is True and q['owned_group_absent'] is True,'known worker reaping and full group absence')
        need(q['stdout_eof'] is True and q['stderr_eof'] is True and q['log_capture_complete'] is True,'complete closed worker pipes')
        need(q['owned_group_reappearance_observed_ns'] is None,'no ambiguous group reappearance')
        native=q.get('native_transport')
        if native is not None:
            need(native['closed'] is True and native['all_reaped'] is True,'all created Native children reaped')
        wp=actual/'worker-receipt.json';w=load(wp) if wp.is_file() else {}
        record=dict(invocation_id=row['invocation_id'],order=order,observer_exit_code=process.returncode,
            terminal=pin(tp),runner_receipt=pin(actual/'runner-receipt.json'),
            worker_receipt=pin(wp) if wp.is_file() else None,
            status=w.get('status','WORKER_FAILURE_RETAINED'),resource_candidate=q['resource_candidate_accepted'],
            terminal_gate=t['terminal_gate_passed'],closed_without_ownership_ambiguity=True,
            native_proof_candidate=w.get('logical_proof_accepted',False),scientific_admission=False)
        save(slot/'CLOSED.json',record);closed.append(record)
        print(json.dumps(dict(event='CLOSED',done=order,total=20,invocation_id=row['invocation_id'],status=record['status'],
            resource_candidate=record['resource_candidate'],terminal_gate=record['terminal_gate'],
            native_proof_candidate=record['native_proof_candidate'])),flush=True)
    save(R/'ROOT-cohort-closure-v1.json',dict(schema='ROOT-inventory-certification-twenty-actuals-closed-v1',actuals=closed,
        retained_actuals=20,all_workers_and_native_groups_closed=True,launcher_marker=marker,
        authorized_index=pin(P/'authorized-index-v1.json'),scientific_replays=0,ROOT_mathematical_admission=False,goal_complete=False))
    return 0

if __name__=='__main__':raise SystemExit(main())
