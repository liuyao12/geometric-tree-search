"""Saved-result diagnosis only. No project/Native imports, replay, or opaque decoding."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
OLD=R.parent/'first-order-suite-progress-20261018'
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def raw(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def main():
 admitted=load(OLD/'ROOT-actual-admission-v1.json');rows=[]
 for r in admitted['actuals']:
  if r['status']!='unknown_native_inventory':continue
  a=Path(r['actual_directory']);d=load(a/'result.json');inv=d['outputs']['register'];q=d['records'][inv['query']]
  assert d['outputs']['compile']['status']=='complete' and 'model' not in d['outputs']and 'search'not in d['outputs']
  assert q['result']['status']=='unknown_space_budget' and q['result']['micro_steps']<5000000000 and q['result']['state']==2 and q['result']['physical_head']==74896
  names=[x['name']for x in inv['definitions']];deps={}
  for row in inv['definitions']:
   direct={x['name']for x in row['definition']['proof']if x['rule']=='block'}
   assert direct<=set(deps);deps[row['name']]={row['name']}.union(*(deps[n]for n in direct))
  w=load(a/'worker-receipt.json');s=[s for s in w['native_transport']['request_stages']if s['stage']=='COMPLETED'and s.get('record_id')==q['id']]
  assert len(s)==1 and s[0]['limit']==5000000000 and s[0]['request_sha256']==q['request_sha256']
  rows.append(dict(invocation_id=r['invocation_id'],receiver_id=r['receiver_id'],mode=r['mode'],search_ordering=r['search_ordering'],result=r['result'],request_sha256=q['request_sha256'],canonical_request_bytes=len(raw(q['request'])),definitions=len(names),interfaces=len(inv['interfaces']),maximum_dependency_closure=max(map(len,deps.values()),default=0),native_result=q['result'],compiler_complete=True,Model_constructed=False,search_started=False,peak_sum_MiB=r['peak_sum_MiB']))
 assert len(rows)==16
 out=dict(schema='ROOT-saved-inventory-heap-evidence-v1',scientific_calls=0,Native_calls=0,opaque_gzip_decodes=0,prior_admission=pin(OLD/'ROOT-actual-admission-v1.json'),records=rows,
  conclusions=['All16 inventory failures are unchanged Native simulated-space UNKNOWN with physical_head74896/state2, below the declared5e9 microstep cap.','Host high-water profiles passed; this does not identify the precise internal parser/checker phase.','No Model or search was constructed for these16 original runs.','Exact dependency closures are much smaller sets of bodies; fit and end-to-end cost remain unmeasured. No input/definition/interface filtering is justified by these records.'],goal_complete=False)
 p=R/'ROOT-saved-inventory-heap-evidence-v1.json'
 with p.open('x')as f:f.write(json.dumps(out,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(evidence=pin(p),records=len(rows),cases=sorted({r['receiver_id']for r in rows}))))
if __name__=='__main__':main()
