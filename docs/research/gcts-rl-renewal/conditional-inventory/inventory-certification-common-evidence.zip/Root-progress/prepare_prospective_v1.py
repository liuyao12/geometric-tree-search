"""Raw Source/input metadata only; no scientific imports or actual launches."""
from pathlib import Path
import ast,copy,hashlib,json
R=Path(__file__).resolve().parent
BASE=R.parent.parent
P=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1')
I=Path('/private/tmp/gcts-inventory-certification-intake-ROOT-source-20261018')
S=Path('/private/tmp/gcts-inventory-batching-ROOT-source-20261018')
OLD=R.parent/'first-order-suite-progress-20261018'
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):
 p=Path(p)
 with p.open('x')as f:f.write(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n')
 return pin(p)
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def main():
 P.mkdir();(P/'worker-plans').mkdir();(P/'runner-plan-drafts').mkdir();(P/'authorization-drafts').mkdir();(R/'case-declarations').mkdir()
 h=load(I/'intake-Source-handoff-v1.json');oldindex=load('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1/authorized-index-v1.json')
 oldworker=load(oldindex['schedule'][0]['worker_plan']['path']);oldonce=load(oldindex['schedule'][0]['runner_plan']['path'])
 parent=OLD/'runtime-closure-v1.json';closure=load(parent)
 closure.update(schema='ROOT-inventory-certification-raw-runtime-closure-v1',parent_closure=pin(parent),
  previous_suite_closure=pin(parent),Source_design=pin(S/'Source-contract-v1.json'),current_composition_handoff=pin(I/'intake-Source-handoff-v1.json'),
  bridge_scope='Same complete24 aliases with only registry and receiver driver replaced by explicit certification-mode Sources; compiler, Model, search, helper, broker and Native/runtime unchanged. Parent metadata is historical, not fresh execution authority.',
  nested_and_dynamic_scope='All AST descendants in all24 current raw aliased Sources; no evaluation.',
  inventory_certification_modes=['bulk','dependency_closures'])
 closure['project_sources']['semantic_inventory_oracle']=h['registry'];closure['additional_nonseed_components']['receiver_driver']=h['driver']
 names=dict(closure['project_sources'],semantic_receiver_driver=h['driver'],bounded_request_oracle=closure['additional_nonseed_components']['bounded_transport'])
 closure['materialized_aliases']=names
 sites=[];edges={};roots=set();dynamic=[];unknown=[]
 for name,d in sorted(names.items()):
  if pin(d['path'])!=d:raise ValueError('changed raw Source '+name)
  tree=ast.parse(Path(d['path']).read_text());compile(tree,d['path'],'exec');links=set()
  for n in ast.walk(tree):
   if isinstance(n,(ast.Import,ast.ImportFrom)):
    imports=[a.name for a in n.names]if isinstance(n,ast.Import)else[n.module]
    for imp in imports:
     root=imp.split('.')[0];kind='project'if root in names else 'external'if root=='z3'else 'stdlib'
     sites.append(dict(source_module=name,line=n.lineno,form=type(n).__name__,import_name=imp,root=root,kind=kind))
     if kind=='project':links.add(root)
     elif kind=='stdlib':roots.add(root)
   elif isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='__import__':
    if len(n.args)==1 and isinstance(n.args[0],ast.Constant)and type(n.args[0].value)is str:
     imp=n.args[0].value;dynamic.append(dict(module=name,line=n.lineno,import_name=imp,call_AST=ast.dump(n,include_attributes=False)));roots.add(imp.split('.')[0])
    else:unknown.append(dict(module=name,line=n.lineno))
  edges[name]=sorted(links)
 closure.update(import_sites=sites,project_import_edges=edges,stdlib_import_roots=sorted(roots),literal_dynamic_import_sites=dynamic,unresolved_dynamic_import_sites=unknown)
 if unknown or len(names)!=24:raise ValueError('raw closure')
 cp=save(R/'runtime-closure-v1.json',closure)
 # Exact selected cases: every old inventory heap failure plus first known successful input as a same-Model control.
 cases=[2,3,5,10,1];arms=[('fixed','bulk'),('symbolic','dependency_closures'),('symbolic','bulk'),('fixed','dependency_closures')]
 schedule=[]
 for ci,c in enumerate(cases):
  rotation=ci%4;ordered=arms[rotation:]+arms[:rotation]
  for ai,(mode,cert)in enumerate(ordered):
   rid='prospective-fol-20261018-'+str(c).zfill(3);iid='inventory-cert-'+str(c).zfill(3)+'-'+mode+'-'+('bulk'if cert=='bulk'else 'closures')+'-ROOT-20261018-v1'
   schedule.append(dict(order=len(schedule)+1,case_order=ci+1,within_case_order=ai+1,invocation_id=iid,receiver_id=rid,mode=mode,inventory_certification_mode=cert,search_ordering='and_support',model_storage='literal_interned',result_reader='interned',actual_directory=str(R.parent/iid)))
 limits=copy.deepcopy(load(oldindex['case_declarations'][schedule[0]['receiver_id']]['path'])['limits']);limits['inventory_registration_aggregate_micro_steps']=5000000000
 design=dict(schema='ROOT-inventory-certification-prospective-design-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,goal_complete=False,
  purpose='Full-inventory certification feasibility and end-to-end cost; no changed mathematical proof search, no general benchmark or speedup claim.',
  original_input_capsule=oldworker['declaration'],prior_cohort_admission=pin(OLD/'ROOT-actual-admission-v1.json'),
  selection=dict(previous_inventory_unknown_cases=[2,3,5,10],positive_same_Model_control=1,correlated_renaming_pair=[5,10],ordered_cases=cases,not_blind=True,known_previous_outcomes=True,omitted_cases_reason='Other former successes/search-budget failures do not isolate the inventory heap bottleneck; not counted as a solve-rate benchmark.'),
  factors=dict(method=['fixed','symbolic'],inventory_certification_mode=['bulk','dependency_closures'],search_ordering=['and_support']),
  schedule=schedule,limits=limits,runtime_closure=cp,intake_Source_handoff=pin(I/'intake-Source-handoff-v1.json'),
  stop_semantics='Each slot once, no outcome-dependent removal/retry. Stop controller only for ambiguous ownership/Source drift or explicit Root stop; retain all failures. Source changes require separate immutable successors and new experiment, never rescue a consumed slot.',
  preregistered_comparisons=['All original compiler/inventory bodies unchanged for each case, including definitions not exported or used.', 'Complete original Model and initial t/m/generations identical wherever both certify, excluding the Model compile_seconds diagnostic only.', 'Every closure receipt joins exact Native request, full original theory, dependency-ordered block bodies, actual broker allowance, status and aggregate microsteps.', 'Final proof and whole t/m region checks unchanged; full worker/Native/terminal/whole output cost and all failures retained.'],
  scientific_scope='No new RL, learned pruning, new recursive cluster proposer, PA induction, Hilbert geometry, universal fixed tile palette, or infinite tiling result. Specialized symbolic control retains its existing semantics.')
 dp=save(R/'prospective-design-v1.json',design)
 declarations={};rows=[]
 for c in cases:
  rid='prospective-fol-20261018-'+str(c).zfill(3)
  original=load(oldindex['case_declarations'][rid]['path'])
  d=dict(schema='ROOT-inventory-certification-experiment-declaration-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,goal_complete=False,
   global_cohort_declaration=dp,parent_structural_declaration=oldworker['declaration'],runtime_closure=cp,
   selected_receiver_id=rid,selected_receiver=original['selected_receiver'],limits=limits,model_storage='literal_interned',result_reader='interned',schedule=[r for r in schedule if r['receiver_id']==rid],
   intake_Source_handoff=pin(I/'intake-Source-handoff-v1.json'),new_RL_training=False,source_gate='Current Source/plans reviews and separate Root max-one grants required; no execution authorized here.')
  declarations[rid]=save(R/'case-declarations'/(rid+'.json'),d)
 for row in schedule:
  iid=row['invocation_id'];worker=copy.deepcopy(oldworker)
  for k in ['invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory']:worker[k]=row[k]
  worker.update(schema='ROOT-inventory-certification-worker-plan-v1',cold=h['cold'],project_sources=closure['project_sources'],components=closure['additional_nonseed_components'],runtime_closure=cp,integration_declaration=declarations[row['receiver_id']])
  wp=save(P/'worker-plans'/(iid+'.json'),worker)
  once=copy.deepcopy(oldonce)
  for k in ['invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory']:once[k]=row[k]
  once.update(schema='ROOT-inventory-certification-once-plan-v1',cold=h['cold'],runner=h['runner'],observer=h['observer'],runtime_closure=cp,worker_plan=wp,integration_declaration=declarations[row['receiver_id']]);once.pop('authorization')
  subject=sha(once)
  draft=dict(schema='ROOT-inventory-certification-once-authorization-v1',author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=subject,review_roles={},scope='Inert Source/prospective subject only; never launch. Root true successor requires current scoped reviews and allagentsidle.')
  ap=save(P/'authorization-drafts'/(iid+'.json'),draft);once['authorization']=ap
  op=save(P/'runner-plan-drafts'/(iid+'.json'),once)
  rows.append(dict(**row,worker_plan=wp,runner_plan_draft=op,authorization_draft=ap,subject_sha256=subject))
 idx=dict(schema='ROOT-inventory-certification-prospective-index-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,subject_count=len(rows),schedule=rows,design=dp,runtime_closure=cp,input_capsule=oldworker['declaration'],case_declarations=declarations,cold=h['cold'],runner=h['runner'],observer=h['observer'],source_contract=pin(S/'Source-contract-v1.json'),intake_Source_handoff=pin(I/'intake-Source-handoff-v1.json'),unchanged_ordering_review=oldindex['current_review_roles']['ordering_Source'],goal_complete=False)
 ip=save(P/'prospective-index-v1.json',idx)
 print(json.dumps(dict(index=ip,design=dp,closure=cp,subjects=len(rows)),indent=2))
if __name__=='__main__':main()
