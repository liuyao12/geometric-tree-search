"""Full raw case packaging; never decodes the opaque Native inputs."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent
P=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1')
SITE=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def js(v):return json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n'
def main():
 a=load(R/'ROOT-actual-admission-v1.json');assert a['retained_actuals']==20 and not a['findings'];archives=[]
 for rid in sorted({r['receiver_id']for r in a['actuals']}):
  members=[];paths=[]
  for r in a['actuals']:
   if r['receiver_id']!=rid:continue
   actual=Path(r['actual_directory']);iid=r['invocation_id'];op=P/'runner-plans'/(iid+'-terminal-observation');slot=R/'launcher-slots'/iid
   for prefix,folder in [('actuals/'+iid,actual),('terminal-observations/'+iid,op),('launcher-slots/'+iid,slot)]:
    for p in sorted(folder.rglob('*')):
     if p.is_symlink():raise ValueError('no symlink case artifact')
     if p.is_file():
      member=prefix+'/'+str(p.relative_to(folder));d=pin(p);paths.append((member,p,d));members.append(dict(member=member,**d))
  assert len(set(m['member']for m in members))==len(members)
  manifest=dict(schema='inventory-certification-case-raw-members-v1',receiver_id=rid,all_four_actuals=True,complete_raw_results=True,members=members,scientific_replays=0,opaque_Native_decodes=0)
  q=SITE/('inventory-certification-case-'+rid[-3:]+'-evidence.zip')
  with zipfile.ZipFile(q,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
   z.writestr('MANIFEST.json',js(manifest))
   for member,p,d in paths:
    assert pin(p)==d;z.write(p,member)
  # Complete byte-for-byte container inverse, not scientific execution.
  with zipfile.ZipFile(q)as z:
   assert z.testzip()is None and set(z.namelist())=={'MANIFEST.json'}|{m for m,_,_ in paths}
   for member,p,d in paths:
    b=z.read(member);assert len(b)==d['bytes']and hashlib.sha256(b).hexdigest()==d['sha256']and b==p.read_bytes()
  archives.append(dict(archive=pin(q),receiver_id=rid,members=members,raw_member_count=len(members),raw_bytes=sum(m['bytes']for m in members),byte_inverse_passed=True))
 out=dict(schema='ROOT-inventory-certification-case-archive-assets-v1',archives=archives,scientific_replays=0,Native_calls=0,opaque_Native_gzip_decodes=0,whole_raw_member_inverse=True)
 with(R/'ROOT-case-archive-assets-v1.json').open('x')as f:f.write(js(out))
 print(js(dict(archives=[dict(file=x['archive'],members=x['raw_member_count'])for x in archives])))
if __name__=='__main__':main()
