"""Derive retained-data admission Source only; it is not invoked here."""
from pathlib import Path
import ast
R=Path(__file__).resolve().parent
old=R.parent/'first-order-suite-progress-20261018/admit_v1.py'
s=old.read_text();tree=ast.parse(s)
functions='\n\n'.join(ast.get_source_segment(s,n)for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ['load','canonical','pin','save','regions','semantic_parts','block_custody'])
p=R/'admit_inventory_cert_v1.py'
with p.open('x')as f:f.write('"""Saved full literal evidence admission only; no Native or scientific replay."""\nfrom pathlib import Path\nimport hashlib,json,gc,traceback\nR=Path(__file__).resolve().parent\nP=Path("/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1")\n'+functions+'\n\n')
