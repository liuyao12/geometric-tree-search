"""Tighten the observed-space claim; display text only."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
p=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory/inventory-certification.html')
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
before=pin(p);s=p.read_text();old='Small checks fit. The full inventory still hits its work cap.';assert s.count(old)==1
p.write_text(s.replace(old,'Smaller checks reach the work limit.'))
q=R/'ROOT-report-text-refinement-v1.json'
with q.open('x')as f:f.write(json.dumps(dict(schema='ROOT-inventory-certification-display-refinement-v1',before=before,after=pin(p),reason='A work-UNKNOWN request may not have completed; headline states observed work stop rather than implying proved space fit.',scientific_changes=0,scientific_calls=0),sort_keys=True,indent=2)+'\n')
print(json.dumps(pin(p)))
