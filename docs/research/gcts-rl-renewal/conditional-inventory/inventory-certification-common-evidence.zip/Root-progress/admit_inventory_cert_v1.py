"""Saved full literal evidence admission only; no Native or scientific replay."""
from pathlib import Path
import hashlib,json,gc,traceback
R=Path(__file__).resolve().parent
P=Path("/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1")
def load(path):
    return json.loads(Path(path).read_bytes())

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def pin(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    with Path(path).open('x') as f:
        f.write(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')
    return pin(path)

def regions(data):
    model=data['outputs']['model'];initial=data['initial_state']
    def point(p):
        assert type(p)is list and len(p)==2 and all(type(v)is int for v in p)
        return tuple(p)
    required={point(p) for p in model['roots']}
    assert len(required)==len(model['roots']) and required=={point(p) for p in initial['allowed_points']}
    totals={point(p):v for p,v in initial['totals']};marks={point(p):v for p,v in initial['marks']}
    assert len(totals)==len(initial['totals']) and len(marks)==len(initial['marks'])
    assert set(totals)<=required and all(type(v)is int and 0<=v<=12 for v in totals.values())
    candidates={tuple(c['key']):c for c in model['placements']}
    assert len(candidates)==len(model['placements'])
    search=data['outputs']['search'];selected=[tuple(k) for k in search['placements']]
    assert len(set(selected))==len(selected)
    proof=search['proof'];slots={}
    for key in selected:
        assert key in candidates and len(key)==4 and all(type(v)is int for v in key)
        assert 0<=key[0]<len(proof) and 0<=key[1]<2+model['arity'] and key[:2] not in slots
        c=candidates[key];slots[key[:2]]=c
        assert c['occupancy']==[[[4*key[0],key[1]],12]]
        for p,v in c['occupancy']:
            p=point(p);assert p in required and type(v)is int and v>0
            totals[p]=totals.get(p,0)+v;assert totals[p]<=12
        for p,v in c['marks']:
            p=point(p);assert type(v)is int and (p not in marks or marks[p]==v)
            marks[p]=v
    assert set(totals)==required and all(v==12 for v in totals.values())
    assert len(slots)==len(proof)*(2+model['arity'])
    defs={d['name']:d['definition'] for d in data['outputs']['register']['definitions']}
    for j,line in enumerate(proof):
        row=[slots[j,n] for n in range(2+model['arity'])]
        command=dict(row[0]['command']);assert command==row[1]['command']
        if command['rule']=='block':
            n=len(defs[command['name']]['premises'])
            inputs=[row[2+i]['source'] for i in range(n)]
            assert all(type(i)is int and 0<=i<j for i in inputs)
            command['inputs']=inputs
        assert command==line
    assert data['outputs']['final_request']['proof']==proof
    return dict(status='VERIFIED_WHOLE_FINITE_POINT_REGION',required_points=len(required),
        selected_placements=len(selected),assigned_mark_points=len(marks),decoded_rows=len(proof),
        union_sha256=hashlib.sha256(canonical(dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected)))).hexdigest())

def semantic_parts(data):
    o=data['outputs']
    parts=dict(compiler={k:v for k,v in o['compile'].items() if k!='seconds'},
        inventory={k:o['register'][k] for k in ('definitions','interfaces','native_blocks')})
    if 'model' in o:
        parts['model']={k:v for k,v in o['model'].items() if k!='compile_seconds'}
        parts['initial']=data['initial_state']
    return parts

def block_custody(request, data):
    registered={b['name']:b for b in data['outputs']['register']['native_blocks']}
    supplied={b['name']:b for b in request['blocks']}
    assert len(supplied)==len(request['blocks'])
    assert all(name in registered and b==registered[name] for name,b in supplied.items())
    needed=set()
    def walk(word):
        for line in word:
            if line['rule']=='block':
                name=line['name']
                assert name in supplied
                if name not in needed:
                    needed.add(name);walk(supplied[name]['proof'])
    walk(request['proof'])
    assert needed==set(supplied)
    return dict(supplied_names=sorted(supplied),all_literal_registered=True,all_and_only_recursive_dependencies=True)

def inventory_join(data,transport):
 inv=data['outputs']['register'];records=data['records'];theory=data['declaration']['theory']
 original={k:v for k,v in inv.items()if k not in ['status','query','queries','certification','seconds']}
 names=[d['name']for d in inv['definitions']];blocks={d['name']:d['definition']for d in inv['definitions']}
 assert len(blocks)==len(names)and inv['native_blocks']==[blocks[n]for n in names]
 assert len(set(inv['interfaces']))==len(inv['interfaces'])and set(inv['interfaces'])<=set(names)
 taut=['imp',['bot'],['bot']]
 stages={s['record_id']:s for s in transport['request_stages']if s['stage']=='COMPLETED'}
 assert len(stages)==len(records)and set(stages)==set(range(len(records)))
 for i,q in enumerate(records):
  s=stages[i];assert q['id']==i and s['ordinal']==i and s['purpose']==q['purpose']
  assert all(s[k]==q[k]for k in ['request_sha256','input_sha256','output_sha256'])
  assert q['request_sha256']==hashlib.sha256(canonical(q['request'])).hexdigest()
  assert type(s['limit'])is int and 0<s['limit']<=5000000000
  assert type(q['result']['micro_steps'])is int and 0<=q['result']['micro_steps']<=s['limit']
 if data['inventory_certification_mode']=='bulk':
  q=records[inv['query']];assert q['purpose']=='check_generated_lemma_definitions'
  request=dict(protocol='gcts-fol-1',theory=theory,blocks=inv['native_blocks'],proof=[dict(rule='tautology',formula=taut)],target=taut)
  assert q['request']==request and stages[q['id']]['limit']==5000000000
  assert (inv['status']=='native_accepted')==(q['result']['status']=='accepted')
  return dict(mode='bulk',complete=inv['status']=='native_accepted',requests=1,definitions=len(names),interfaces=len(inv['interfaces']),consumed_micro_steps=q['result']['micro_steps'],native_status=q['result']['status'],maximum_request_bytes=len(canonical(request)),maximum_closure_definitions=len(names))
 cert=inv['certification'];assert cert['schema']=='native-inventory-dependency-closure-certification-v1'
 assert cert['version']=='native-inventory-exact-dependency-closures-v2'and cert['mode']=='dependency_closures'
 assert cert['inventory_sha256']==hashlib.sha256(canonical(original)).hexdigest()and cert['theory_sha256']==hashlib.sha256(canonical(theory)).hexdigest()
 assert cert['aggregate_micro_step_limit']==5000000000 and cert['all_original_definition_names']==names and cert['all_original_interfaces']==inv['interfaces']
 prior=set();plans=[]
 for name in names:
  assert all(x['name']in prior for x in blocks[name]['proof']if x['rule']=='block')
  prior.add(name);wanted=set();pending=[name]
  while pending:
   x=pending.pop()
   if x in wanted:continue
   wanted.add(x);pending.extend(l['name']for l in blocks[x]['proof']if l['rule']=='block')
  plans.append(dict(definition=name,names=[n for n in names if n in wanted]))
 if not plans:plans=[dict(definition=None,names=[])]
 assert cert['planned_requests']==plans
 rs=cert['receipts'];assert rs and len(rs)<=len(plans)
 ids=[r['query']for r in rs];assert inv['query']is None and inv['queries']==ids and ids==list(range(ids[0],ids[0]+len(ids)))
 assert ids[0]==data['outputs']['compile_record_joins']['queries'][-1]['record_id']+1
 used=0;accepted=set();sizes=[]
 for ordinal,(r,plan)in enumerate(zip(rs,plans)):
  assert r['ordinal']==ordinal and r['definition']==plan['definition']and r['closure_names']==plan['names']
  q=records[r['query']];s=stages[q['id']]
  request=dict(protocol='gcts-fol-1',theory=theory,blocks=[blocks[n]for n in plan['names']],proof=[dict(rule='tautology',formula=taut)],target=taut)
  assert q['purpose']=='check_generated_lemma_definition_closure'and q['request']==request
  assert s['limit']==r['assigned_micro_step_limit']==5000000000-used and r['aggregate_consumed_before']==used
  steps=q['result']['micro_steps'];assert steps==r['consumed_micro_steps']and r['result_status']==q['result']['status']and r['request_sha256']==q['request_sha256']
  used+=steps;assert r['aggregate_consumed_after']==used
  sizes.append(len(canonical(request)))
  if q['result']['status']=='accepted':accepted.update(plan['names'])
  else:assert ordinal==len(rs)-1
 complete=len(rs)==len(plans)and rs[-1]['result_status']=='accepted'and accepted==set(names)
 assert cert['complete']is complete and cert['aggregate_consumed_micro_steps']==used<=5000000000
 assert cert['accepted_definition_names']==[n for n in names if n in accepted]
 if complete:assert inv['status']=='native_accepted'and cert['stop_reason']is None
 else:
  assert inv['status']in ['unknown_native_inventory','native_rejected']
  assert 'model'not in data['outputs']and 'search'not in data['outputs']
  stop=rs[-1]['result_status']
  assert cert['stop_reason']==(stop if stop!='accepted'else 'aggregate_registration_micro_step_budget')
  if stop=='accepted':assert used==5000000000 and len(rs)<len(plans)
 return dict(mode='dependency_closures',complete=complete,requests=len(rs),planned_requests=len(plans),definitions=len(names),interfaces=len(inv['interfaces']),consumed_micro_steps=used,stop_reason=cert['stop_reason'],native_status=rs[-1]['result_status'],maximum_request_bytes=max(sizes),maximum_closure_definitions=max(len(p['names'])for p in plans))

def main():
 idx=load(P/'authorized-index-v1.json');closed=load(R/'ROOT-cohort-closure-v1.json');runtime=load(idx['runtime_closure']['path'])
 assert len(idx['schedule'])==20 and closed['all_workers_and_native_groups_closed']and closed['retained_actuals']==20
 refs={};findings=[];rows=[];directory=R/'semantic-preimages';directory.mkdir()
 for row in idx['schedule']:
  a=Path(row['actual_directory']);r=dict(row,admission_checks_passed=False,ROOT_resource_admitted=False,fresh_native_proof=False)
  try:
   q=load(a/'runner-receipt.json');tp=P/'runner-plans'/(row['invocation_id']+'-terminal-observation')/'terminal.json';t=load(tp);c=load(a/'CONSUMED.json')
   assert q['plan']==t['plan']==c['plan']==row['runner_plan']==pin(row['runner_plan']['path'])
   assert q['authorization']==row['authorization']==pin(row['authorization']['path'])and q['subject_sha256']==row['subject_sha256']
   assert q['consumed_once']is True and q['worker_launch_attempts']==1 and q['python_reaped']and q['owned_group_absent']
   assert q['stdout_eof']and q['stderr_eof']and q['log_capture_complete']and q['owned_group_reappearance_observed_ns']is None
   assert pin(a/'runner-receipt.json')==t['runner_receipt']
   r.update(status=q.get('worker_receipt',{}).get('status')if type(q.get('worker_receipt'))is dict else 'WORKER_FAILURE_RETAINED',runner_receipt=pin(a/'runner-receipt.json'),terminal=pin(tp),errors=q['errors'],signals=q['signals'],outer_terminal_seconds=t.get('runner_clock_elapsed_seconds'),peak_sum_bytes=q.get('conservative_parent_plus_native_peak_bytes'))
   if not(q['resource_candidate_accepted']and t['terminal_gate_passed']):
    r.update(outcome_class='PROFILE_FAILURE_RETAINED',available_outputs={n:pin(a/n)for n in ['result.json','worker-receipt.json','worker-failure.json','stdout.bin','stderr.bin']if(a/n).is_file()})
    rows.append(r);continue
   w=load(a/'worker-receipt.json');assert q['python_exit_code']==0 and t['runner_exit_code']==0 and not q['errors']and not q['signals']
   assert w['worker_plan']==row['worker_plan']==pin(row['worker_plan']['path'])and pin(a/'worker-receipt.json')==q['outputs']['worker_receipt']
   assert q['began_ns']==w['began_ns']==c['began_ns']and q['work_deadline_ns']==w['work_deadline_ns']==q['began_ns']+180000000000
   assert q['overall_deadline_ns']==w['overall_deadline_ns']==q['began_ns']+210000000000 and t['terminal_observed_ns']<q['overall_deadline_ns']
   n=w['native_transport'];assert n==q['native_transport']and n['closed']and n['all_reaped']and n['native_exit_code']==0 and n['stderr_complete']and n['stdout_eof']and n['stdout_pending_bytes']==0
   assert q['python_pid']==q['owned_pgid']==n['parent_pid']==n['parent_pgid']==n['native_pgid']
   peak=q['python_wait4_usage']['ru_maxrss']+n['native_high_water_bytes'];assert peak==q['conservative_parent_plus_native_peak_bytes']and peak<=1073741824
   raw=(a/'result.json').read_bytes();rp=pin(a/'result.json');assert len(raw)<=134217728 and rp==q['outputs']['result']==w['result']
   body=memoryview(raw)[:-1]if raw.endswith(b'\n')else memoryview(raw);reading=w['result_reading'];literal=reading['roundtrip']
   assert reading['reader']=='interned'and literal['literal_bytes_equal']and literal['body_bytes']==len(body)and literal['body_sha256']==hashlib.sha256(body).hexdigest()
   data=json.loads(raw);assert canonical(data)+b'\n'==raw;del raw,body
   for k in ['mode','inventory_certification_mode','search_ordering','receiver_id']:assert data[k]==w[k]==q[k]==row[k]
   case=load(idx['case_declarations'][row['receiver_id']]['path']);assert data['declaration']==case['selected_receiver']and w['integration_declaration']==idx['case_declarations'][row['receiver_id']]
   epoch=data['source_epoch'];assert epoch['schema']=='semantic-family-receiver-source-epoch-v4-inventory-certification'
   assert epoch['inventory_certification_mode']==row['inventory_certification_mode']and epoch['search_ordering']==row['search_ordering']=='and_support'
   assert epoch['model_storage']==w['model_storage']==row['model_storage']=='literal_interned'and epoch['declaration']==idx['input_capsule']and epoch['receiver_selection']['spec']==data['declaration']
   assert epoch['result_representation']==dict(reader='interned',integration_declaration=idx['case_declarations'][row['receiver_id']])and epoch['sources']['cold']==idx['cold']
   assert epoch['sources']['original']==runtime['materialized_aliases']and set(epoch['sources']['project'])==set(runtime['materialized_aliases'])and len(epoch['sources']['project'])==24
   for alias,owned in epoch['sources']['project'].items():
    assert pin(owned['path'])==owned;origin=epoch['sources']['original'][alias];assert pin(origin['path'])==origin and owned['sha256']==origin['sha256']and owned['bytes']==origin['bytes']
   assert data['module_pins']['family_registry']==epoch['sources']['project']['semantic_inventory_oracle']
   proof=data['native_proof_accepted']is True;assert proof==w['logical_proof_accepted']
   point=None
   if proof:
    assert data['status']==w['status']=='native_proof_discovered'and q['worker_terminal_observed_ns']<q['work_deadline_ns']and reading['completed_ns']<q['work_deadline_ns']
    final=data['outputs']['final_native'];request=data['outputs']['final_request'];assert data['records'][final['id']]==final and final['request']==request and final['result']['status']=='accepted'
    assert final['request_sha256']==hashlib.sha256(canonical(request)).hexdigest()and request['target']==data['declaration']['target']and request['theory']==data['declaration']['theory']
    r['block_custody']=block_custody(request,data);point=regions(data);assert all(w['final_region_verification'][k]==v for k,v in point.items())
   else:assert data['status']==w['status']and data['status']in ['unknown_native_inventory','unknown_search_budget','unknown_receiver_work_deadline','native_rejected']
   registration=inventory_join(data,n)if'register'in data['outputs']else None
   if 'model'in data['outputs']:assert registration['complete']
   parts=semantic_parts(data)if'register'in data['outputs']else dict(compiler={k:v for k,v in data['outputs'].get('compile',{}).items()if k!='seconds'})
   same={}
   for key,value in parts.items():
    b=canonical(value);g=refs.setdefault(row['receiver_id'],{})
    if key in g:assert b==Path(g[key]['path']).read_bytes(),'complete same-case '+key
    else:
     p=directory/(row['receiver_id']+'-'+key+'.json');p.write_bytes(b);g[key]=pin(p)
    prior=R.parent/'first-order-suite-progress-20261018/semantic-preimages'/(row['receiver_id']+'-'+key+'.json')
    if prior.is_file():assert b==prior.read_bytes(),'complete prior-cohort '+key
    same[key]=dict(current=g[key],prior=pin(prior)if prior.is_file()else None,all_available_literals_equal=True)
    if key=='model':assert hashlib.sha256(b).hexdigest()==data['model_identity_sha256']==data['model_after_identity_sha256']
   search=data['outputs'].get('search',{})
   r.update(admission_checks_passed=True,ROOT_resource_admitted=True,fresh_native_proof=proof,outcome_class='ADMITTED_BOUNDED_PROOF'if proof else 'IN_PROFILE_UNKNOWN',status=data['status'],result=rp,worker_receipt=pin(a/'worker-receipt.json'),whole_region=point,registration=registration,semantic_preimages=same,peak_sum_bytes=peak,peak_sum_MiB=peak/1048576,worker_seconds=(q['worker_terminal_observed_ns']-q['began_ns'])/1e9,reading=reading,native_queries=len(data['records']),proof=search.get('proof'),search_seconds=search.get('seconds'),search_counters=search.get('metrics'),stage_intervals=data['stage_intervals'],stage_seconds={k:v.get('seconds')for k,v in data['outputs'].items()if type(v)is dict and'seconds'in v},model_placements=len(data['outputs'].get('model',{}).get('placements',[])),required_points=len(data['outputs'].get('model',{}).get('roots',[])))
   del data,parts;gc.collect()
  except Exception as e:
   finding=dict(invocation_id=row['invocation_id'],type=type(e).__name__,message=str(e),traceback=traceback.format_exc());findings.append(finding);r.update(outcome_class='ADMISSION_FAILURE_RETAINED',finding=finding)
  rows.append(r)
 out=dict(schema='ROOT-inventory-certification-retained-admission-v1',actuals=rows,retained_actuals=len(rows),findings=findings,authorized_index=pin(P/'authorized-index-v1.json'),cohort_closure=pin(R/'ROOT-cohort-closure-v1.json'),fresh_native_proofs=sum(r['fresh_native_proof']for r in rows),within_resource_profile=sum(r['ROOT_resource_admitted']for r in rows),scientific_replays=0,Native_calls=0,new_RL_training=False,goal_complete=False,scope='Known failure-engineering cohort: all four former inventory-space inputs plus one known positive control; correlated005/010. No blind/general benchmark or GCTS/RL advantage claim. Full same-case/prior semantic literals, broker actual residual allowances, fresh final Native/whole-region and full profiles inspected from saved evidence without Native replay.')
 print(json.dumps(dict(admission=save(R/'ROOT-actual-admission-v1.json',out),proofs=out['fresh_native_proofs'],within_profile=out['within_resource_profile'],findings=findings)))
if __name__=='__main__':main()
