"""Full task-owned raw Source/evidence packaging and link preflight, no science."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import hashlib,json,zipfile,gzip
R=Path(__file__).resolve().parent
P=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1')
PUB=Path('/private/tmp/gcts-split-controls-publish-20261015')
SITE=PUB/'docs/research/gcts-rl-renewal/conditional-inventory'
PREFIX='docs/research/gcts-rl-renewal/conditional-inventory/'
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def js(x):return json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n'
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=set()
 def handle_starttag(self,t,a):
  d=dict(a)
  if'id'in d:self.ids.add(d['id'])
  if t in ['a','link']and'href'in d:self.links.append(d['href'])
  if t in ['script','img']and'src'in d:self.links.append(d['src'])
def main():
 idx=load(P/'authorized-index-v1.json');a=load(R/'ROOT-actual-admission-v1.json');assert len(a['actuals'])==20 and not a['findings']
 # Package must wait until distinct data/resource/report scopes are adopted.
 adoption=load(R/'ROOT-retained-review-adoption-v1.json');assert adoption['all_current_reviews_adopted']is True
 for n,d in adoption['reviews'].items():
  assert pin(d['path'])==d
  dest=SITE/('inventory-certification-'+n+'-review.json')
  with dest.open('xb')as f:f.write(Path(d['path']).read_bytes())
 files={}
 def add(member,p):
  p=Path(p).resolve();assert p.is_file()and not p.is_symlink()
  if member in files:assert files[member]==p
  files[member]=p
 def tree(prefix,folder,skip=()):
  folder=Path(folder).resolve()
  for p in sorted(folder.rglob('*')):
   rel=p.relative_to(folder)
   if any(x in rel.parts for x in skip):continue
   if p.is_file():add(prefix+'/'+str(rel),p)
 # All current raw aliases and Native inputs; external distributions are pinned prerequisites.
 closure=load(idx['runtime_closure']['path'])
 for alias,d in closure['materialized_aliases'].items():assert pin(d['path'])==d;add('runtime-aliases/'+alias+'.py',d['path'])
 for key in ['program_and_template','opaque_microcode_gzip']:d=closure['fixed_native_inputs'][key];assert pin(d['path'])==d;add('Native-fixed-inputs/'+Path(d['path']).name,d['path'])
 for key in ['source','binary','build_receipt','preserved_failed_build_receipt']:
  d=closure['native_CPP'][key];assert pin(d['path'])==d;add('Native-CPP/'+Path(d['path']).name,d['path'])
 tree('Root-progress',R,skip=('semantic-preimages','launcher-slots'))
 tree('plans',P,skip=tuple(p.name for p in P.joinpath('runner-plans').glob('*-terminal-observation')))
 directories=[
  '/private/tmp/gcts-inventory-batching-ROOT-source-20261018',
  '/private/tmp/gcts-inventory-certification-intake-ROOT-source-20261018',
  '/private/tmp/gcts-inventory-batching-ROOT-peer-20261018',
  '/private/tmp/gcts-inventory-certification-once-peer-20261018',
  '/private/tmp/gcts-inventory-certification-prospective-peer-20261018',
  '/private/tmp/gcts-inventory-certification-retained-data-peer-20261018',
  '/private/tmp/gcts-inventory-certification-retained-resource-peer-20261018',
  '/private/tmp/gcts-inventory-certification-report-peer-20261018',
  '/private/tmp/gcts-recursive-cluster-design-20261018']
 for folder in directories:tree('packets/'+Path(folder).name,folder,skip=('__pycache__',))
 # Complete input and authoritative prior Source/preimage provenance, not prior actuals.
 add('prior/input-capsule-v1.json',idx['input_capsule']['path'])
 parent=closure['parent_closure'];add('prior/first-order-suite-runtime-closure-v1.json',parent['path'])
 parentcl=load(parent['path'])
 for role,d in parentcl['materialized_aliases'].items():
  if d!=closure['materialized_aliases'][role]:add('prior/parent-aliases/'+role+'.py',d['path'])
 for name in ['ROOT-actual-admission-v1.json','ROOT-live-final-v1.json']:
  add('prior/'+name,R.parent/'first-order-suite-progress-20261018'/name)
 for d in idx['current_review_roles'].values():
  if not str(Path(d['path']).parent)in directories:add('inherited-reviews/'+Path(d['path']).parent.name+'/'+Path(d['path']).name,d['path'])
 # Sources/receipts explicitly needed by inherited Source custody (no recursive directory hydration).
 extra=[
 '/private/tmp/gcts-compact-model-cold-once-independent-peer-20261018/typed-Source-review-v2.json',
 '/private/tmp/gcts-first-order-suite-once-peer-20261018/typed-Source-review-v1.json',
 '/private/tmp/gcts-and-support-once-peer-20261018/typed-Source-review-v1.json',
 '/private/tmp/gcts-first-order-suite-intake-source-20261018/frozen_fol_suite_cold_v1.py',
 '/private/tmp/gcts-first-order-suite-intake-source-20261018/frozen_fol_suite_once_runner_v1.py',
 '/private/tmp/gcts-first-order-suite-intake-source-20261018/observe_frozen_fol_suite_runner_v1.py',
 '/private/tmp/gcts-semantic-proof-renderer-source-20261018/semantic_proof_renderer_v2.py']
 for p in extra:add('inherited-explicit/'+Path(p).parent.name+'/'+Path(p).name,p)
 add('contract/basic-tiling-algorithm.md',R.parent.parent/'docs/basic-tiling-algorithm.md')
 members=[dict(member=n,**pin(p))for n,p in sorted(files.items())]
 manifest=dict(schema='inventory-certification-common-raw-members-v1',members=members,scientific_replays=0,Native_calls=0,opaque_Native_gzip_decodes=0,external_runtime_prerequisites=dict(Python=closure['runtime']['Python_executable'],Z3=closure['Z3']),scope='All current24rawaliases/Nativeinputs/currentSources/plans/grants/reviews and scoped provenance. Per-casearchives hold actuals. Standard external interpreter/solver distributions remain exact pinned prerequisites. Archive extraction is transport, not authority; original absolute provenance paths retained.')
 q=SITE/'inventory-certification-common-evidence.zip'
 with zipfile.ZipFile(q,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  z.writestr('MANIFEST.json',js(manifest))
  for n,p in sorted(files.items()):z.write(p,n)
 with zipfile.ZipFile(q)as z:
  assert z.testzip()is None and set(z.namelist())=={'MANIFEST.json'}|set(files)
  for x in members:
   b=z.read(x['member']);assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256']and b==files[x['member']].read_bytes()
 # Explicit task assets, avoiding unrelated dirty/untracked files.
 names=[p.name for p in SITE.iterdir()if p.is_file()and(p.name.startswith('inventory-certification-')or p.name.startswith('inventory-cert-001-')or p.name.startswith('inventory-cert-002-')or p.name.startswith('inventory-cert-003-')or p.name.startswith('inventory-cert-005-')or p.name.startswith('inventory-cert-010-'))]
 names+=['inventory-certification.html','reader.html','first-order-suite.html']
 names=sorted(set(names));assert 'inventory-certification-evidence-manifest.json'not in names
 case=load(R/'ROOT-case-archive-assets-v1.json')
 public=dict(schema='inventory-certification-public-evidence-manifest-v1',assets=[dict(relative_path=PREFIX+n,**pin(SITE/n))for n in names],common_archive=pin(q),common_raw_members=members,case_archives=case['archives'],Root_admission=pin(R/'ROOT-actual-admission-v1.json'),reviews=adoption['reviews'],scientific_replays=0,opaque_Native_gzip_decodes=0,goal_complete=False)
 mp=SITE/'inventory-certification-evidence-manifest.json';mp.write_text(js(public));names.append(mp.name)
 # Check every new-document link and only added old-document links against exact baselines.
 cache={}
 def parsed(p):
  p=p.resolve()
  if p not in cache:
   l=Links();l.feed(p.read_text());cache[p]=l
  return cache[p]
 checked=[];outside=[]
 for n in names:
  if not n.endswith('.html'):continue
  p=SITE/n;links=parsed(p).links
  if n in ['reader.html','first-order-suite.html']:
   base=R/'publication-baselines'/n;l=Links();l.feed(base.read_text());links=[x for x in links if x not in l.links]
  for href in links:
   u=urlsplit(href)
   if u.scheme or u.netloc:outside.append(href);continue
   target=(p.parent/unquote(u.path)).resolve()if u.path else p.resolve()
   assert target.is_file(),(n,href)
   if u.fragment and target.suffix=='.html':assert unquote(u.fragment)in parsed(target).ids,(n,href,'anchor')
   checked.append(dict(document=n,link=href))
 protected=R.parent.parent/'docs/research/gcts-rl-renewal/index.html';assert pin(protected)['sha256']=='d04878220b6c43b16bbc1ff6cd17d24d824e2c3049a2b47600f0e26eec0cd770'
 assets=[dict(relative_path=PREFIX+n,**pin(SITE/n))for n in sorted(names)]
 out=dict(schema='ROOT-inventory-certification-publication-assets-v1',assets=assets,total_assets=len(assets),total_bytes=sum(x['bytes']for x in assets),common_archive=pin(q),common_raw_member_count=len(members),full_common_member_inverse=True,all_current_links_checked=checked,unchanged_historical_links_not_reopened=True,external_links=sorted(set(outside)),protected_overview=pin(protected),scientific_calls=0,Native_calls=0,opaque_Native_gzip_decodes=0,goal_complete=False)
 with(R/'ROOT-publication-assets-v1.json').open('x')as f:f.write(js(out))
 print(js(dict(assets=len(assets),bytes=out['total_bytes'],archive=pin(q),common_members=len(members),links=len(checked))))
if __name__=='__main__':main()
