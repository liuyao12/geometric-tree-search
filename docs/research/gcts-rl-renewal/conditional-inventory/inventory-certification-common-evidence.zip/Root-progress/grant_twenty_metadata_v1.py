"""Root metadata-only max-one grants, after distinct exact Source/plan reviews. No launches."""
from pathlib import Path
import hashlib,json,os
R=Path(__file__).resolve().parent
P=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1')

def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):
 with Path(p).open('x')as f:f.write(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
 return pin(p)
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def contains(v,s):return v==s or (type(v)is dict and any(contains(x,s)for x in v.values()))or(type(v)is list and any(contains(x,s)for x in v))
def main():
 idx=load(P/'prospective-index-v1.json');assert idx['actual_execution_authorized']is False and len(idx['schedule'])==20
 roles={
  'ordering_Source':(idx['unchanged_ordering_review'],'and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
  'registry_Source':(pin('/private/tmp/gcts-inventory-batching-ROOT-peer-20261018/typed-registry-Source-review-v1.json'),'inventory-closure-registry-typed-Source-review-v1','source_review_passed','/root/conventional_library'),
  'composition_Source':(pin('/private/tmp/gcts-inventory-batching-ROOT-peer-20261018/typed-driver-cold-Source-review-v1.json'),'inventory-certification-driver-cold-typed-Source-review-v1','source_review_passed','/root/conventional_library'),
  'once_Source':(pin('/private/tmp/gcts-inventory-certification-once-peer-20261018/typed-once-Source-review-v1.json'),'inventory-certification-once-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
  'prospective_plans':(pin('/private/tmp/gcts-inventory-certification-prospective-peer-20261018/typed-prospective-plan-review-v1.json'),'inventory-certification-prospective-plan-review-v1','prospective_review_passed','/root/conventional_library')}
 reviews={}
 for role,(d,schema,passed,reviewer)in roles.items():
  assert pin(d['path'])==d;r=load(d['path']);assert r['schema']==schema and r[passed]is True and r['reviewer_identity']==reviewer and r['author_identity']!=reviewer and r['source_only']is True and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False
  reviews[role]=r
 assert contains(reviews['once_Source'],pin(R/'run_twenty_once_v1.py'))
 (P/'authorizations').mkdir();(P/'runner-plans').mkdir();rows=[]
 for row in idx['schedule']:
  assert not Path(row['actual_directory']).exists()
  for key in ['worker_plan','runner_plan_draft','authorization_draft']:assert pin(row[key]['path'])==row[key]
  once=load(row['runner_plan_draft']['path']);worker=load(row['worker_plan']['path']);subject={k:v for k,v in once.items()if k!='authorization'}
  assert len(subject)==18 and digest(subject)==row['subject_sha256']
  assert all(once[k]==worker[k]==row[k]for k in ['invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory'])
  required={'ordering_Source':[worker['project_sources'][k]for k in ['semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1']],
   'registry_Source':[worker['project_sources']['semantic_inventory_oracle']],
   'composition_Source':[once['cold'],worker['components']['receiver_driver']],
   'once_Source':[once['runner'],once['observer'],pin(R/'run_twenty_once_v1.py')],
   'prospective_plans':[once['integration_declaration'],once['runtime_closure'],once['worker_plan']]}
  binding={}
  for role,subjects in required.items():
   assert all(contains(reviews[role],s)for s in subjects),role
   binding[role]=dict(receipt=roles[role][0],reviewer_identity=roles[role][3],required_subjects=subjects)
  auth=dict(schema='ROOT-inventory-certification-once-authorization-v1',author_identity='/root',actual_execution_authorized=True,maximum_actual_invocations=1,subject_sha256=row['subject_sha256'],review_roles=binding,scope='Root exact unchanged prospective subject, once only, full unchanged profile. All agents idle and sequential dedicated controller. No consumed retries or outcome-dependent deletions. Root separately admits full saved evidence; no mathematical acceptance granted by metadata.')
  ap=save(P/'authorizations'/(row['invocation_id']+'.json'),auth);once['authorization']=ap
  op=save(P/'runner-plans'/(row['invocation_id']+'.json'),once)
  assert digest({k:v for k,v in once.items()if k!='authorization'})==row['subject_sha256']
  rows.append(dict(**row,authorization=ap,runner_plan=op))
 authorized=dict(idx,schema='ROOT-inventory-certification-authorized-index-v1',actual_execution_authorized=True,schedule=rows,actuals_started=0,current_review_roles={k:v[0]for k,v in roles.items()},scope='All20 original false subjects unchanged; true maxone grants only, no science/launch performed by metadata helper.')
 ip=save(P/'authorized-index-v1.json',authorized)
 adopted=dict(schema='ROOT-inventory-certification-final-grant-adoption-v1',author_identity='/root',metadata_adoption_passed=True,actual_execution_authorized=True,authorized_index=ip,design=idx['design'],launcher=pin(R/'run_twenty_once_v1.py'),review_roles={k:v[0]for k,v in roles.items()},maximum_actuals=20,scientific_calls=0,all_subjects_unchanged=True,goal_complete=False)
 print(json.dumps(dict(index=ip,adoption=save(R/'ROOT-final-grant-adoption-v1.json',adopted),actuals=20)))
if __name__=='__main__':main()
