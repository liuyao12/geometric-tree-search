"""Root retained/display/byte review adoption only; no proof evaluation."""
from pathlib import Path
import json,hashlib,sys,re
R=Path(__file__).resolve().parent
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def contains(v,x):
 if v==x:return True
 if type(v)is dict:return any(contains(w,x)for w in v.values())
 if type(v)is list:return any(contains(w,x)for w in v)
 return False
def main():
 assert len(sys.argv)==2 and re.fullmatch('[0-9a-f]{64}',sys.argv[1])
 old=load(R/'ROOT-retained-data-review-adoption-v1.json');assert old['adoption_passed'] is True
 reviews=dict(old['reviews'])
 cfg=[
 ('report','/private/tmp/gcts-first-order-suite-report-peer-20261018/typed-report-review-v1.json',sys.argv[1],'first-order-suite-human-report-review-v1','report_review_passed','/root/conventional_library'),
 ('case-package','/private/tmp/gcts-first-order-suite-package-peer-20261018/typed-case-package-review-v1.json','b2117bd64f57a16f1d31fe5af1483f72fd8e55fd111f1f0ff77517f103ecd3be','first-order-suite-case-package-review-v1','package_review_passed','/root/conventional_control_review')]
 draft=pin(R/'report-draft-assets-v3.json');assert draft['sha256']=='c1ac5ed8f43b1084087bf352cc5e9e041cc400b62238fa1bcb5e675526d50156'
 for desc in load(draft['path'])['assets']:assert pin(desc['path'])==desc
 for role,path,sha,schema,passed,who in cfg:
  p=pin(path);d=load(path);assert p['sha256']==sha
  assert d['schema']==schema and d[passed] is True and d['reviewer_identity']==who
  assert d['author_identity']=='/root' and d['scientific_calls']==0 and d['actual_execution_authorized'] is False
  assert contains(d,draft)
  for key in ['audit']:
   if key in d:assert pin(d[key]['path'])==d[key]
  reviews[role]=p
 for desc in reviews.values():assert pin(desc['path'])==desc
 admission=load(R/'ROOT-actual-admission-v1.json')
 assert not admission['findings'] and admission['fresh_native_proofs']==12 and admission['within_resource_profile']==40
 d=dict(schema='ROOT-first-order-suite-retained-review-adoption-v1',adoption_passed=True,reviews=reviews,
  Root_independent_admission=pin(R/'ROOT-actual-admission-v1.json'),retained_data_adoption=pin(R/'ROOT-retained-data-review-adoption-v1.json'),
  exact_report_draft=draft,case_archives=pin(R/'ROOT-case-archive-assets-v1.json'),Root_conformance=pin(R/'ROOT-conformance-v1.json'),
  admitted_proofs=12,retained_actuals=40,solved_primary_groups=2,primary_groups=8,
  scientific_replays=0,actual_execution_authorized=False,goal_complete=False,
  scope='Root adopts distinct data,resource,comparison,display and case-byte audits over immutable retained evidence, with inherited authorship and separate Source roles preserved. Common archive/final links/live publication remain independently checked by Root; this metadata adoption adds no proof search or mathematical rule.')
 p=R/'ROOT-retained-review-adoption-v1.json'
 with p.open('x') as f:f.write(json.dumps(d,sort_keys=True,indent=2)+'\n')
 print(json.dumps(pin(p)))
if __name__=='__main__':main()
