"""Final common evidence and link/hash manifest; no scientific evaluation."""
from pathlib import Path
import json,hashlib,zipfile,subprocess
from collections import Counter
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
R=Path(__file__).resolve().parent
S=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
P=Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def js(v):return json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n'
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=set()
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if 'id'in d:
   assert d['id'] not in self.ids,('duplicateHTMLid',d['id']);self.ids.add(d['id'])
  if tag=='a' and 'href'in d:self.links.append(d['href'])
def main():
 adopted=load(R/'ROOT-retained-review-adoption-v1.json')
 assert adopted['adoption_passed'] is True
 draft=load(R/'report-draft-assets-v3.json')
 assets=[Path(d['path']) for d in draft['assets']]
 assert all(pin(d['path'])==d for d in draft['assets'])
 for role,desc in adopted['reviews'].items():
  assert pin(desc['path'])==desc
  out=S/('first-order-suite-'+role+'-review.json')
  out.write_bytes(Path(desc['path']).read_bytes());assets.append(out)
 out=S/'first-order-suite-conformance.json';out.write_bytes((R/'ROOT-conformance-v1.json').read_bytes());assets.append(out)
 cases=load(R/'ROOT-case-archive-assets-v1.json')
 assert len(cases['assets'])==10 and all(pin(d['path'])==d for d in cases['assets'])
 assets.extend(Path(d['path']) for d in cases['assets'])
 members={}
 def add(p,name):
  p=Path(p);assert p.is_file() and not p.is_symlink() and name not in members,(str(p),name)
  members[name]=p
 def folder(p,arc):
  p=Path(p);assert p.is_dir()
  for c in sorted(p.iterdir()):
   if c.is_file() and c.suffix in ['.json','.py','.html','.txt','.md','.cpp']:add(c,arc+'/'+c.name)
 # Exact already-cached parent HTML establishes which links are unchanged
 # historical references. This read does not hydrate unrelated source trees.
 baselines=R/'historical-link-baselines';baselines.mkdir()
 baseline_data={}
 for name in ['reader.html','and-support-ordering.html']:
  relative='docs/research/gcts-rl-renewal/conditional-inventory/'+name
  b=subprocess.run(['git','show','72e180da11960a5994d074457924e936050b3163:'+relative],cwd=S.parents[3],capture_output=True,check=True).stdout
  (baselines/name).write_bytes(b);baseline_data[name]=b.decode()
 folder(R,'Root-progress')
 folder(baselines,'Root-progress/historical-link-baselines')
 for n in ['report-draft-v1-before-clarification','report-draft-v2-before-proof-quality-addendum','case-declarations','semantic-preimages']:
  folder(R/n,'Root-progress/'+n)
 dirs=[
 '/private/tmp/gcts-first-order-suite-intake-source-20261018',
 '/private/tmp/gcts-first-order-next-benchmark-source-20261018',
 '/private/tmp/gcts-first-order-suite-input-peer-20261018',
 '/private/tmp/gcts-first-order-suite-composition-peer-20261018',
 '/private/tmp/gcts-first-order-suite-once-peer-20261018',
 '/private/tmp/gcts-first-order-suite-prospective-peer-20261018',
 '/private/tmp/gcts-first-order-suite-final-grant-peer-20261018',
 '/private/tmp/gcts-first-order-suite-launcher-peer-20261018',
 '/private/tmp/gcts-and-support-ordering-source-20261018',
 '/private/tmp/gcts-and-support-point-source-20261018',
 '/private/tmp/gcts-and-support-cold-source-20261018',
 '/private/tmp/gcts-and-support-ordering-independent-peer-20261018',
 '/private/tmp/gcts-first-order-suite-retained-data-peer-20261018',
 '/private/tmp/gcts-first-order-suite-retained-resource-peer-20261018',
 '/private/tmp/gcts-first-order-suite-comparison-peer-20261018',
 '/private/tmp/gcts-first-order-suite-report-peer-20261018',
 '/private/tmp/gcts-first-order-suite-package-peer-20261018']
 for p in dirs:folder(p,'Sources-and-scoped-reviews/'+Path(p).name)
 suite=load('/private/tmp/gcts-first-order-next-benchmark-source-20261018/suite-input-index-v1.json')
 for case in suite['receivers']:
  desc=case['input'];assert pin(desc['path'])==desc
  add(desc['path'],'original-frozen-inputs/'+Path(desc['path']).name)
 folder(P,'plans')
 for n in ['worker-plans','runner-plans','runner-plan-drafts','authorizations','authorization-drafts']:folder(P/n,'plans/'+n)
 closure=load(R/'runtime-closure-v1.json')
 for name,desc in closure['materialized_aliases'].items():
  assert pin(desc['path'])==desc;add(desc['path'],'complete-runtime-Source/'+name+'.py')
 for name in ['opaque_microcode_gzip','program_and_template']:
  desc=closure['fixed_native_inputs'][name];assert pin(desc['path'])==desc
  add(desc['path'],'fixed-native-inputs/'+Path(desc['path']).name)
 for name in ['binary','source','build_receipt','preserved_failed_build_receipt']:
  desc=closure['native_CPP'][name];assert pin(desc['path'])==desc
  add(desc['path'],'Native-runtime/'+Path(desc['path']).name)
 add('/private/tmp/gcts-semantic-proof-renderer-source-20261018/semantic_proof_renderer_v2.py','pure-display/semantic_proof_renderer_v2.py')
 for p in assets:
  if p.suffix in ['.html','.json']:add(p,'published-reader/'+p.name)
 add(S/'reader.css','published-reader/reader.css')
 archive=S/'first-order-suite-common-evidence.zip';assert not archive.exists()
 mapping={k:pin(v) for k,v in members.items()}
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in members.items():z.write(p,name)
  z.writestr('archive-manifest.json',js(dict(schema='first-order-suite-common-archive-manifest-v1',members=mapping,all_ten_case_archives=cases['assets'],scope='Common Sources/inputs/contracts/plans/max-one grants/full scoped review audits/same-case preimages/proof displays/fixed Native inputs/build receipts. Ten separate archives retain all40 complete actuals. External interpreter/stdlib/Z3 are exact pinned prerequisites, not repackaged distributions. No scientific replay or opaque Native gzip decoding.')))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for name,desc in mapping.items():
   b=z.read(name);assert len(b)==desc['bytes'] and hashlib.sha256(b).hexdigest()==desc['sha256']
 assets.append(archive)
 checked=[];cache={};unchanged_historical=[]
 for p in assets:
  if p.suffix!='.html':continue
  parser=Links();parser.feed(p.read_text());cache[p.resolve()]=parser
 for p,parser in list(cache.items()):
  links=parser.links
  if p.name in baseline_data:
   before=Links();before.feed(baseline_data[p.name]);prior=Counter(before.links)
   added=[]
   for href in links:
    if prior[href]>0:
     prior[href]-=1;unchanged_historical.append(dict(source=p.name,href=href))
    else:added.append(href)
   links=added
  for href in links:
   u=urlsplit(href)
   if u.scheme or u.netloc:continue
   target=(p.parent/unquote(u.path)).resolve() if u.path else p
   manifest=S/'first-order-suite-evidence-manifest.json'
   assert target.is_file() or (target==manifest and not u.fragment),('missing',str(p),href)
   if u.fragment:
    if target not in cache:
     q=Links();q.feed(target.read_text());cache[target]=q
    assert unquote(u.fragment) in cache[target].ids,('anchor',str(p),href)
   checked.append(dict(source=p.name,href=href))
 assets=list(dict.fromkeys(assets))
 published={p.name:pin(p) for p in assets}
 manifest=S/'first-order-suite-evidence-manifest.json'
 out=dict(schema='first-order-suite-public-evidence-manifest-v1',published=published,common_archive=pin(archive),common_archive_members=len(mapping),case_archives=cases['assets'],case_archive_raw_members=sum(len(c['members']) for c in cases['cases']),all_archive_raw_hashes_verified=True,local_links_checked=len(checked),local_links=checked,unchanged_historical_links_not_rechecked=unchanged_historical,link_scope='Every link and anchor in all13newdocuments; every newlyaddedlink in twoexistingpages compared with exact parent72e180. Unchanged historical references remain outside this release scope.',Root_review_adoption=pin(R/'ROOT-retained-review-adoption-v1.json'),retained_actuals=40,admitted_instances=12,solved_primary_groups=2,primary_groups=8,correlated_renamings=2,new_RL_training=False,goal_complete=False,scope='Manifest excludes own rawidentity. Archives contain internal rawmember manifests. Source/retained/display/packaging reviews have separate scopes and inherited authorship. All40 complete scientific outcomes remain public.')
 manifest.write_text(js(out))
 for item in checked:
  p=S/item['source'];u=urlsplit(item['href']);target=(p.parent/unquote(u.path)).resolve() if u.path else p
  assert target.is_file(),str(target)
 assets.append(manifest)
 out=R/'ROOT-publication-assets-v1.json'
 with out.open('x') as f:f.write(js(dict(schema='ROOT-first-order-suite-publication-assets-v1',assets=[pin(p) for p in assets],common_members=mapping,protected_overview_unchanged=True,scientific_replays=0,goal_complete=False)))
 print(js(dict(publication=pin(out),assets=len(assets),common_archive=pin(archive),members=len(mapping),links=len(checked))))
if __name__=='__main__':main()
