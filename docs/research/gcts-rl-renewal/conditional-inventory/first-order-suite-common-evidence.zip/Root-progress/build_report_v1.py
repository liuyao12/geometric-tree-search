"""Pure retained-data display/compression, no scientific inference or search."""
from pathlib import Path
import json,hashlib,gzip,html,ast,importlib.util,gc

R=Path(__file__).resolve().parent
SITE=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
P=Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def js(v):return json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n'
def e(v):return html.escape(str(v),quote=True)
def math(v):return '\\('+e(v)+'\\)'
def write(n,b):
 if type(b)is str:b=b.encode()
 p=SITE/n;p.write_bytes(b);return pin(p)
def main():
 a=load(R/'ROOT-actual-admission-v1.json');assert not a['findings'] and a['retained_actuals']==40 and a['fresh_native_proofs']==12
 rows=a['actuals'];assert all(r['ROOT_resource_admitted'] for r in rows)
 specs=load(R/'input-capsule-v1.json')['receivers']
 meta=load('/private/tmp/gcts-first-order-next-benchmark-source-20261018/suite-input-index-v1.json')['receivers']
 lookup={m['case_id']:m for m in meta}
 renderer_path=Path('/private/tmp/gcts-semantic-proof-renderer-source-20261018/semantic_proof_renderer_v2.py')
 assert pin(renderer_path)['sha256']=='bd929c531205dfd9fcfd6732c9de554d71e2abdd492a80aac1dd094965b77e77'
 spec=importlib.util.spec_from_file_location('pure_retained_display',renderer_path)
 renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
 old=ast.parse((R.parent/'and-support-ordering-progress-20261018/build_report_v1.py').read_text())
 head=next(ast.literal_eval(n.value) for n in old.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='HEAD' for t in n.targets))
 head=head.replace('Joint-premise guidance finds the curried proof — GCTS research','Forty first-order proof-search runs — GCTS research')
 ns=head.index('<nav>');ne=head.index('</nav>',ns)+6
 nav='<nav><a href="reader.html#first-order-suite">Research notebook</a><a href="first-order-suite.html#outcomes">All results</a><a href="first-order-suite.html#proofs">Concrete theorems</a><a href="first-order-suite.html#assessment">Assessment</a><a href="first-order-suite.html#evidence">Evidence</a></nav>'
 head=head[:ns]+nav+head[ne:]
 head=head.replace('</style>','.matrix td{text-align:center}.inventory{background:#f9e3c3;color:#6a4513}.search-stop{background:#e9e6f4;color:#513c78}.proof{background:#daf0e7;color:#185d49}.case{border-top:2px solid #c6d8dd;margin-top:32px;padding-top:20px}.case h3{margin-bottom:8px}.legend{display:flex;gap:16px;flex-wrap:wrap}.legend span{padding:8px 12px}.mono{font-variant-numeric:tabular-nums}.stage-flow{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.stage-flow article{padding:18px;border:1px solid #c5d8dc}.counter{font-size:34px;font-weight:750}.note{font-size:14px;color:#476270}@media(max-width:720px){.stage-flow{grid-template-columns:1fr}}</style>')
 names={('fixed','legacy'):'GCTS · legacy',('fixed','and_support'):'GCTS · shared support',('symbolic','legacy'):'Symbolic · legacy',('symbolic','and_support'):'Symbolic · shared support'}
 columns=[('fixed','legacy'),('fixed','and_support'),('symbolic','legacy'),('symbolic','and_support')]
 labels={'native_proof_discovered':('proof','Proof'),'unknown_native_inventory':('inventory','Inventory stop'),'unknown_search_budget':('search-stop','Search budget')}
 assets=[];proofs=[];downloads={}
 for row in rows:
  n=row['receiver_id'][-3:];stem='fol-'+n+'-'+row['mode']+'-'+row['search_ordering'].replace('_','-')
  raw=Path(row['result']['path']).read_bytes();assert pin(row['result']['path'])==row['result']
  href=stem+'-result.json.gz';assets.append(write(href,gzip.compress(raw,compresslevel=6,mtime=0)))
  downloads[row['invocation_id']]=href
  if row['fresh_native_proof']:
   data=json.loads(raw);fragment=renderer.render_result(data,names[row['mode'],row['search_ordering']],raw_href=href)
   formula='\\{'+',\\;'.join(renderer._formula(v) for v in data['declaration']['theory']['axioms'].values())+'\\}\\;\\vdash\\;'+renderer._formula(data['declaration']['target'])
   note=r'<p class="eyebrow">AUTOMATICALLY FOUND · FIRST-ORDER SUITE</p><h1>A discovered proof, row by row.</h1><p class="lead">The search selected the target proof sequence from programmed inference rules and generic lemma templates. Every retained command row, formula, explanation, colored point tile and reusable lemma body is available below.</p>'
   note+='<p>\\['+e(formula)+'\\]</p><p><a href="first-order-suite.html#case-'+n+'">Return to this case and all four methods</a> · <a href="#proof-reader">Inspect the proof rows</a>.</p>'
   note+=r'<p class="scope">Root admitted this complete finite region and its exact Native proof request within the frozen resource profile. The square glyphs display actual translation-only point tiles with nonlocal markings. This implementation has a finite case-specific catalog; a single universal nearest-neighbor Wang palette remains future work. All twelve rows are retained, including padding; green rows identify the recorded target ancestry.</p>'
   file=stem+'-proof.html';assets.append(write(file,head+note+'<div id="proof-reader">'+fragment+'</div></main></body></html>'))
   proofs.append(dict(invocation_id=row['invocation_id'],file=file))
   del data,fragment
  del raw;gc.collect()
 prooflinks={p['invocation_id']:p['file'] for p in proofs}
 matrix=[];cases=[]
 for c in specs:
  n=c['id'][-3:];group=lookup[c['id']];rr=[r for r in rows if r['receiver_id']==c['id']]
  by={(r['mode'],r['search_ordering']):r for r in rr}
  title=group['group'].replace('-',' ').capitalize()
  annotation=' · renamed '+group['renaming_control_of'][-3:] if not group['structural_primary'] else ''
  cells=[]
  for arm in columns:
   r=by[arm];cls,label=labels[r['status']]
   href=prooflinks.get(r['invocation_id'],'#case-'+n)
   cells.append('<td class="'+cls+'"><a href="'+href+'">'+label+'</a></td>')
  matrix.append('<tr><th><a href="#case-'+n+'"><code>'+n+'</code> '+e(title)+e(annotation)+'</a></th>'+''.join(cells)+'</tr>')
  formula='\\{'+',\\;'.join(renderer._formula(v) for v in c['theory']['axioms'].values())+'\\}\\;\\vdash\\;'+renderer._formula(c['target'])
  links=[]
  for r in rr:
   name=e(names[r['mode'],r['search_ordering']])
   href=prooflinks.get(r['invocation_id'])
   links.append('<li>'+name+': '+('<a href="'+href+'#proof-reader">read discovered proof and colored markings</a>' if href else labels[r['status']][1])+'. <a href="'+downloads[r['invocation_id']]+'">Complete raw output (gzip)</a>.</li>')
  cases.append('<article class="case" id="case-'+n+'"><h3><code>'+n+'</code> '+e(title)+'</h3><p class="note">'+('Primary structural group.' if group['structural_primary'] else 'Correlated renaming of case <code>'+e(group['renaming_control_of'][-3:])+'</code>; excluded from the primary group denominator.')+'</p>\\['+e(formula)+'\\]<ul>'+''.join(links)+'</ul></article>')
 full=[]
 for r in rows:
  s=r['search_seconds'];metrics=r['search_counters'];count=None if metrics is None else metrics.get('attempts',metrics.get('prefix_extensions'))
  work='Not reached' if count is None else math(str(count))+' '+('placements' if r['mode']=='fixed' else 'row extensions')
  cls,label=labels[r['status']];href=prooflinks.get(r['invocation_id'])
  outcome=('<a href="'+href+'#proof-reader">'+label+'</a>') if href else label
  full.append('<tr><td>'+math(str(r['order']))+'</td><th><code>'+r['receiver_id'][-3:]+'</code> '+e(names[r['mode'],r['search_ordering']])+'</th><td class="'+cls+'">'+outcome+'</td><td>'+work+'</td><td>'+('Not reached' if s is None else math(f'{s:.3f}'))+'</td><td>'+math(f'{r["outer_terminal_seconds"]:.3f}')+'</td><td>'+math(f'{r["peak_sum_MiB"]:.1f}')+'</td><td><a href="'+downloads[r['invocation_id']]+'">'+math(f'{r["result"]["bytes"]/1048576:.2f}')+'</a></td></tr>')
 summary=dict(schema='first-order-suite-public-summary-v1',actuals=rows,total_actuals=40,primary_groups=8,correlated_renamings=2,admitted_proof_instances=12,solved_primary_groups=2,solved_inputs_including_renamings=3,inventory_stops=16,search_budget_stops=12,all_within_profile=True,all_available_same_case_preimages_equal=True,proof_readers=proofs,raw_downloads=downloads,Root_admission=pin(R/'ROOT-actual-admission-v1.json'),goal_complete=False,new_RL_training=False,scope='Authored synthetic first-order corpus, not official TPTP or blind data. One run per arm. Two related renamings are not independent theorem families. No solve-rate advantage for point search or shared support on this corpus; no new mathematical theorem or general benchmark supremacy.')
 assets.append(write('first-order-suite-summary.json',js(summary)))
 for name,file in [('admission','ROOT-actual-admission-v1.json'),('declaration','experiment-declaration-v1.json'),('design','prospective-design-v1.json'),('runtime-closure','runtime-closure-v1.json'),('inputs','input-capsule-v1.json')]:
  assets.append(write('first-order-suite-'+name+'.json',(R/file).read_bytes()))
 report=head+r'''<p class="eyebrow">PROSPECTIVE FROZEN COHORT · 18 OCTOBER 2026</p>
<h1>A broader test shows the current limits.</h1>
<p class="lead">All four variants solve the same two primary first-order cases. Across the eight primary groups, three stop while certifying the lemma inventory and three exhaust search budgets. The shared support heuristic that helped the earlier curried development case produces no solve-rate gain in this cohort.</p>
<p class="status">Forty sequential runs; twelve admitted proof instances including one correlated renaming; every run within the frozen resource profile. Independent agents review mathematical data, resource custody and comparative interpretation. No target proof sequence was supplied to search.</p>
<section id="outcomes"><h2>All declared outcomes</h2>
<div class="stage-flow"><article><div class="counter">\(12\)</div><h3>Admitted proofs</h3><p>Cases <code>001</code>, <code>004</code> and renamed <code>009</code>, in every variant. This is \(2/8\) primary groups.</p></article><article><div class="counter">\(16\)</div><h3>Inventory space stops</h3><p>Cases <code>002</code>, <code>003</code>, <code>005</code>, renamed <code>010</code>. The Native checker reaches its space limit before Model or search.</p></article><article><div class="counter">\(12\)</div><h3>Search budget stops</h3><p>Cases <code>006</code>, <code>007</code>, <code>008</code>. The inventory is admitted, but search returns UNKNOWN within its frozen limits.</p></article></div>
<p>The matrix shows the whole corpus, including failures and the two renaming controls. Each cell links to an actual proof reader or the corresponding concrete statement. Color is also named in every cell.</p>
<div class="table-wrap"><table class="matrix"><thead><tr><th>Case</th>'''+''.join('<th>'+e(names[arm])+'</th>' for arm in columns)+r'''</tr></thead><tbody>'''+''.join(matrix)+r'''</tbody></table></div>
<p class="caption">Each variant solves \(3/10\) input assertions, or \(2/8\) primary structural groups. The last two inputs rename earlier cases; they are not independent successes or failures. These are authored synthetic inputs inspired by familiar first-order forms, not an official TPTP evaluation or blind holdout.</p></section>
<section id="assessment"><h2>What GCTS contributes here</h2>
<p>The system does discover checkable target proofs without a human supplying their row sequence. Its rules and generic lemma templates are programmed, and automatic specialization supplies a case-specific inventory. Root independently checks the retained complete point region and exact final Native request, including theory, target, proof word and used lemma bodies.</p>
<p>This cohort establishes no solve-rate advantage for GCTS or the shared heuristic. Conventional symbolic search solves exactly the same cases. On the three primary search failures, the shared helper adds cost without finding a proof. The earlier curried success remains useful development evidence, but its benefit does not transfer to these harder cases under the current grammar and budgets.</p>
<p>The geometric method maintains the full candidate/frontier graph with global dead-end and forced-move propagation, earliest-generation branching and exact rollback. The symbolic control uses chronological prefix search and is a specialized conventional control. It is not a state-of-the-art external prover. Matching this control is a useful diagnostic milestone; comparison with existing proof-search systems remains open.</p>
<p>There is no new RL training in this cohort. Reusable level-one lemma families are present, but recursive learning of a growing hierarchy of new lemmas remains unestablished. These are first-order statements, with no new Peano arithmetic or Hilbert geometry result. A fixed universal Wang palette, Turtle/Penrose tiling results and plane-tiling proofs remain separate open goals.</p></section>
<section id="costs"><h2>Full pipeline costs</h2>
<p>The table follows the frozen launch order. Search counts have method-specific units; compare outcomes and full measured costs across methods. Full seconds include Source-entry setup, Native checks, complete model construction, search, output, full result reading and shutdown. Interpreter and observer preparation are separately recorded.</p>
<div class="table-wrap"><table class="mono"><thead><tr><th>Run</th><th>Case and variant</th><th>Outcome</th><th>Search work</th><th>Search seconds</th><th>Full seconds</th><th>Memory MiB</th><th>Full raw MiB</th></tr></thead><tbody>'''+''.join(full)+r'''</tbody></table></div>
<p class="caption">Every run passes the same \(180\)-second work window, \(210\)-second externally observed termination limit, \(1\) GiB conservative sum of separate Python-worker and Native-process high-water values, \(128\) MiB complete raw output cap and \(4\) MiB per-log cap. The memory measure is a conservative sum, not a simultaneous live peak; controller and observer memory are excluded. No truncation, retries or omitted failed arms are used.</p>
<p>The independent resource audit reports compiler times of \(9.166\)–\(89.159\) seconds, registration of \(4.561\)–\(20.120\) seconds, model construction of \(1.308\)–\(2.666\) seconds where reached, final Native checks of \(5.608\)–\(11.135\) seconds for positive results, complete output serialization up to \(36.430\) seconds, and full result reading up to \(47.167\) seconds. These stages have different denominators; the full records preserve every interval.</p>
<p>Preparation and audit output dominate many runs. The current resource profile measures this complete experimental pipeline. Improving proof search alone will not remove inventory-space failures or the cost of retaining and checking the full audit object.</p></section>
<section id="proofs"><h2>Concrete statements and discovered proofs</h2>
<p>The statements below come from the frozen ordinary symbolic inputs. Successful readers show every retained row as a formula and English explanation, actual colored point tiles, nonlocal marking values, ordered input ports and full reusable lemma expansions. The twelve-row word can contain padding; its length is not the length of the target-essential argument.</p>'''+''.join(cases)+r'''</section>
<section id="design"><h2>What stayed fixed</h2>
<p>The original ten inputs were frozen before this cohort, with no proofs, routes, supplied instances or expected runtime results. All four variants use the same \(24\) scientific modules, full theory and target, compiler, inventory, complete candidate Model where reached, Native checker, compact literal storage and lossless result reader. Root compares full same-case literal preimages; inventory stops permit only a compiler/inventory comparison because no Model or search exists.</p>
<p>Only the input-custody entry constants and declarations changed for intake; the scientific Sources are byte-identical to the previous shared-heuristic implementation. Each input receives all four variants in the original prospective order. Rotation gives first-position frequencies \(3,3,2,2\). There is one deterministic run per variant and input, with no repetitions or significance claims.</p>
<p>GCTS uses the original row-Join setting \(24\), plus arbitrary sampled proposals and defer; that setting is not a cap on the total proposal pool. Symbolic search ranks stable windows of \(64\) legal row candidates. The common support potential reorders choices and supplies no proof authority or proved pruning. Both methods retain their complete original alternatives within the frozen finite grammar.</p>
<p>Proof validity follows the common Native checker plus retained finite-region agreement, not the learned or heuristic markings alone. Integer occupancy uses capacity \(12\), equivalent to normalized tile values summing to \(1\). Missing mark assignments remain distinct from assigned zero.</p></section>
<section id="parallel"><h2>Parallel work, independent checks</h2>
<p>The user’s parallel-agent suggestion is now concrete: one agent audits the saved proof words, whole point regions and lemma provenance; a second audits exact launch subjects, resources and process closure; a third analyzes paired comparisons and reviews the human report. Root freezes the experiment, independently repeats admission, integrates the results and publishes them.</p>
<p>These roles have disclosed authorship overlap with inherited code. Distinct Source reviews and saved-data reviews have separate scopes. Parallel research improves throughput and scrutiny; all timed runs were sequential with the other agents idle.</p></section>
<section id="next"><h2>Next decisions</h2>
<p>First address the inventory checker’s space bottleneck while preserving the full declared inventory and proof authority. Then diagnose the three admitted-inventory search failures and test a genuinely recursive missing-premise cluster proposer as a separate change. Learned markings, learned cluster proposals and inventory reuse should be separately ablated against the same shared heuristic, with all construction and training costs recorded.</p>
<p>Broader comparisons should use documented external prover baselines and appropriately licensed standard corpora after the encoding and checker support their fragment. An elementary synthetic success should remain evidence of working automation, rather than a claim of surpassing existing theorem provers.</p></section>
<section id="evidence"><h2>Complete retained evidence</h2>
<p><a href="first-order-suite-summary.json">Results and scope</a> · <a href="first-order-suite-admission.json">Root admission</a> · <a href="first-order-suite-design.json">Prospective design</a> · <a href="first-order-suite-declaration.json">Forty-run declaration</a> · <a href="first-order-suite-inputs.json">All ordinary input specifications</a> · <a href="first-order-suite-runtime-closure.json">Runtime identities</a> · <a href="first-order-suite-evidence-manifest.json">Published hashes and archive members</a>.</p>
<p><a href="first-order-suite-data-review.json">Distinct retained-data review</a> · <a href="first-order-suite-resource-review.json">Distinct resource review</a> · <a href="first-order-suite-comparison-review.json">Comparison analysis</a> · <a href="first-order-suite-report-review.json">Human report review</a>.</p>
<p>The per-case archives retain all four complete raw outputs, receipts, logs, owned modules and Native wire artifacts. The common archive holds Sources, original inputs, declarations, plans, grants, scoped reviews and runtime prerequisites by raw identity. External interpreter and solver distributions remain pinned prerequisites.</p><ul><li><a href="first-order-suite-common-evidence.zip">Common Sources, all plans and reviews</a></li>'''+''.join('<li><a href="first-order-suite-case-'+c['id'][-3:]+'-evidence.zip">Case <code>'+c['id'][-3:]+'</code>: all four complete actuals</a></li>' for c in specs)+r'''</ul>
<p>Individual gzip downloads above preserve complete raw result bytes with no omitted fields. No Native opaque input was decoded for publication, and no proof search or Native evaluation was replayed for these readers.</p></section>
<footer>The research program remains active. <a href="and-support-ordering.html#outcomes">Earlier curried development experiment</a> · <a href="reader.html#first-order-suite">Research notebook</a>.</footer></main></body></html>'''
 assets.append(write('first-order-suite.html',report))
 reader=SITE/'reader.html';s=reader.read_text()
 old='<section id="and-support-ordering">';assert old in s
 block=r'<section id="first-order-suite"><p class="eyebrow">LATEST MEASURED COHORT · FORTY FROZEN RUNS</p><h2>The broader test shows matching solve outcomes.</h2><p>All four variants solve \(2/8\) primary first-order groups. Twelve proof instances including a renaming are admitted; sixteen runs stop at inventory space limits and twelve exhaust search budgets. All forty pass the original full resource profile. This cohort establishes no solve-rate gain for GCTS or the shared support heuristic.</p><p><a href="first-order-suite.html#outcomes"><b>All forty outcomes and complete pipeline costs</b></a> · <a href="first-order-suite.html#proofs">Concrete statements, formulas, English and colored markings</a> · <a href="first-order-suite.html#parallel">Independent agent roles</a>.</p></section>'
 s=s.replace(old,block+old,1).replace('LATEST MEASURED SEARCH RESULT · PARALLEL RESEARCH','EARLIER DEVELOPMENT RESULT · PARALLEL RESEARCH',1)
 start=s.index('<p class="lead">');end=s.index('</p>',start)+4
 s=s[:start]+r'<p class="lead">The original forty-run first-order cohort is complete. All four variants solve the same two primary groups; inventory-space limits and search budgets block the others. Twelve proofs are admitted with readable tile rows, while no GCTS-specific or RL advantage is established.</p>'+s[end:]
 reader.write_text(s);assets.append(pin(reader))
 previous=SITE/'and-support-ordering.html';s=previous.read_text();marker='<section id="statement">';assert marker in s
 s=s.replace(marker,r'<p class="status">Subsequent frozen benchmark: all four variants solve the same \(2/8\) primary groups, with no solve-rate gain from the shared heuristic in that cohort. <a href="first-order-suite.html#outcomes">Read all forty results and discovered proofs</a>. The curried development result below is retained as earlier evidence.</p>'+marker,1)
 previous.write_text(s);assets.append(pin(previous))
 out=R/'report-draft-assets-v1.json'
 out.write_text(js(dict(schema='ROOT-first-order-suite-report-draft-assets-v1',assets=assets,proof_readers=proofs,pure_renderer=pin(renderer_path),scientific_replays=0,peer_reviews_pending=True,goal_complete=False)))
 print(js(dict(draft=pin(out),assets=len(assets),proof_readers=len(proofs))))
if __name__=='__main__':main()
