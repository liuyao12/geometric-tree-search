"""Issue metadata-only true grants over independently reviewed unchanged subjects."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
P=Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1')
def load(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):
 with Path(p).open('x') as f:f.write(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n')
 return pin(p)
def contains(v,s):
 if v==s:return True
 if type(v)is dict:return any(contains(x,s) for x in v.values())
 if type(v)is list:return any(contains(x,s) for x in v)
 return False
def nested(v,path):
 for part in path.split('.'):v=v[part]
 return v
def main():
 idx=load(P/'prospective-index-v1.json');assert idx['actual_execution_authorized'] is False
 adoption=load(R/'ROOT-Source-and-plan-adoption-v1.json')
 assert adoption['accepted_for_exact_prospective_subjects'] is True and adoption['scientific_calls']==0 and adoption['actuals_started']==0
 assert adoption['prospective_index']==pin(P/'prospective-index-v1.json')
 references=adoption['review_roles'];specs=idx['review_role_schemas']
 assert set(references)==set(specs)=={'ordering_Source','composition_Source','once_Source','prospective_plans'}
 reviews={}
 for role,ref in references.items():
  assert pin(ref['path'])==ref
  d=load(ref['path']);s=specs[role]
  assert d['schema']==s['schema'] and d[s['pass']] is True and d['reviewer_identity']==s['reviewer'] and d['author_identity']!=s['reviewer']
  assert d['source_only'] is True and d['scientific_calls']==0 and d['scientific_acceptance'] is False and d['actual_execution_authorized'] is False
  reviews[role]=d
 assert contains(reviews['prospective_plans'],pin(P/'prospective-index-v1.json'))
 assert len(idx['schedule'])==40
 for row in idx['schedule']:
  assert not Path(row['actual_directory']).exists()
  for k in ('worker_plan','authorization_draft','runner_plan_draft'):assert pin(row[k]['path'])==row[k]
  assert not (P/'runner-plans'/(row['invocation_id']+'-terminal-observation')).exists()
 for k in ('authorizations','runner-plans'):(P/k).mkdir()
 rows=[]
 for row in idx['schedule']:
  draft=load(row['runner_plan_draft']['path']);subject={k:v for k,v in draft.items() if k!='authorization'}
  sha=hashlib.sha256(canonical(subject)).hexdigest();assert sha==row['subject_sha256']
  old=load(row['authorization_draft']['path']);assert old['actual_execution_authorized'] is False and old['review_roles']=={} and old['subject_sha256']==sha
  worker=load(row['worker_plan']['path']);context=dict(worker,worker_plan=row['worker_plan'],runner=idx['runner'],observer=idx['observer'])
  roles={}
  for role,s in specs.items():
   subjects=[nested(context,k) for k in s['minimum_subjects']]
   assert all(contains(reviews[role],d) for d in subjects)
   for d in subjects:assert pin(d['path'])==d
   roles[role]=dict(receipt=references[role],reviewer_identity=s['reviewer'],required_subjects=subjects)
  auth=dict(old,actual_execution_authorized=True,review_roles=roles,scope='Root fresh max-one actual only over exact reviewed immutable40subjects/current4roles. Separate distinct finalgrantdelta and Root adoption/allagentsidle still required before launch. Full original scientific/runtime/native/wholepoint/completeoutput/resourceprofile. No retries or salvage.')
  assert {k:v for k,v in auth.items() if k not in ('actual_execution_authorized','review_roles','scope')}=={k:v for k,v in old.items() if k not in ('actual_execution_authorized','review_roles','scope')}
  iid=row['invocation_id'];aref=save(P/'authorizations'/(iid+'.json'),auth)
  final=dict(subject,authorization=aref);assert {k:v for k,v in final.items() if k!='authorization'}==subject
  qref=save(P/'runner-plans'/(iid+'.json'),final)
  rows.append(dict(row,authorization=aref,runner_plan=qref))
 out=dict(idx,schema='ROOT-first-order-suite-authorized-plan-index-v1',actual_execution_authorized=True,subject_count=40,schedule=rows,current_review_roles=references,prospective_index=pin(P/'prospective-index-v1.json'),Source_and_plan_adoption=pin(R/'ROOT-Source-and-plan-adoption-v1.json'),final_delta_still_required=True,scientific_calls=0,actuals_started=0,scope='True max-one grants over forty unchanged false subjects. No launch by this metadata helper; distinct finaldelta+reviewedRootlauncher+Rootadoption/allagentsidle required.')
 ref=save(P/'authorized-index-v1.json',out)
 print(json.dumps(dict(index=ref,subjects=40,actuals_started=0)))
if __name__=='__main__':main()
