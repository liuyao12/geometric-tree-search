"""Lossless closed-actual case archives; no scientific evaluation."""
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parent
S=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
P=Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def js(v):return json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n'
def main():
 a=load(R/'ROOT-actual-admission-v1.json');idx=load(P/'authorized-index-v1.json')
 assert len(a['actuals'])==len(idx['schedule'])==40 and not a['findings']
 by={r['invocation_id']:r for r in a['actuals']};assets=[];cases=[]
 for cid in idx['case_declarations']:
  rows=[r for r in idx['schedule'] if r['receiver_id']==cid];assert len(rows)==4
  members={}
  def add(p,name):
   p=Path(p);assert p.is_file() and not p.is_symlink() and name not in members
   members[name]=p
  for row in rows:
   act=Path(row['actual_directory']);arc='actuals/'+act.name
   assert pin(act/'result.json')==by[row['invocation_id']]['result']
   assert pin(act/'worker-receipt.json')==by[row['invocation_id']]['worker_receipt']
   assert pin(act/'runner-receipt.json')==by[row['invocation_id']]['runner_receipt']
   for c in sorted(act.iterdir()):
    if c.is_file():add(c,arc+'/'+c.name)
    else:
     assert c.name in ['native','modules'] and c.is_dir() and not c.is_symlink()
     for f in sorted(c.iterdir()):add(f,arc+'/'+c.name+'/'+f.name)
   obs=P/'runner-plans'/(row['invocation_id']+'-terminal-observation')
   for f in sorted(obs.iterdir()):add(f,'observations/'+row['invocation_id']+'/'+f.name)
   slot=R/'launcher-slots'/row['invocation_id']
   for f in sorted(slot.iterdir()):add(f,'launcher-slots/'+row['invocation_id']+'/'+f.name)
  manifest={k:pin(p) for k,p in members.items()}
  p=S/('first-order-suite-case-'+cid[-3:]+'-evidence.zip')
  assert not p.exists()
  with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for name,path in members.items():z.write(path,name)
   z.writestr('archive-manifest.json',js(dict(schema='first-order-suite-case-archive-manifest-v1',receiver_id=cid,all_four_actuals=True,members=manifest,scope='All complete raw result fields, receipts, logs, all owned modules/Native artifacts and externally observed terminal/launcher records. Failed cases retained. No scientific replay or opaque Native gzip decoding.')))
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   for name,desc in manifest.items():
    raw=z.read(name);assert len(raw)==desc['bytes'] and hashlib.sha256(raw).hexdigest()==desc['sha256']
  q=pin(p);assets.append(q);cases.append(dict(receiver_id=cid,archive=q,members=manifest,all_raw_hashes_verified=True))
  print(json.dumps(dict(case=cid,archive_bytes=q['bytes'],members=len(manifest))),flush=True)
 out=R/'ROOT-case-archive-assets-v1.json'
 with out.open('x') as f:f.write(js(dict(schema='ROOT-first-order-suite-case-archives-v1',assets=assets,cases=cases,scientific_replays=0,goal_complete=False)))
 print(json.dumps(pin(out)))
if __name__=='__main__':main()
