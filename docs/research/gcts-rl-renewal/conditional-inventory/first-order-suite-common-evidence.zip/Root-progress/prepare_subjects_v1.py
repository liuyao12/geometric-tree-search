"""Raw metadata/AST only. Prepare all forty false subjects before any launch."""
from pathlib import Path
import ast
import hashlib
import json
import sys

R=Path(__file__).resolve().parent
S=Path('/private/tmp/gcts-first-order-suite-intake-source-20261018')
P=Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1')

def load(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=Path(p).resolve();b=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def verify(d):
    assert pin(d['path'])==d
    return Path(d['path']).read_bytes()
def save(p,v):
    with Path(p).open('x') as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

def main():
    hand=load(S/'handoff-v1.json');api=load(S/'API-v1.json')
    assert hand['scientific_calls']==0 and hand['actual_execution_authorized'] is False
    assert hand['sources']==api['sources']
    for d in hand['sources'].values():verify(d)
    design=load(R/'prospective-design-v1.json');capsule=load(R/'input-capsule-v1.json');capsule_ref=pin(R/'input-capsule-v1.json')
    assert design['input_capsule']==capsule_ref
    oldref=design['frozen_scientific_runtime_closure'];verify(oldref);old=load(oldref['path'])
    assert oldref['sha256']=='8246d2d2afdd3045067af2ae12b45f9fe6619451bbd33fd47e6b09d0ae5f06b8'
    assert hand['sources']['receiver_driver']==old['additional_nonseed_components']['receiver_driver']
    # Every operative scientific descriptor, import graph and Native/runtime
    # prerequisite remains exactly the prior cohort. Only intake lineage changes.
    for d in old['materialized_aliases'].values():
        ast.parse(verify(d),filename=d['path'])
    assert len(old['project_sources'])==22 and len(old['materialized_aliases'])==24
    closure=dict(old)
    closure.update(Source_design=hand['composition_contract'],current_composition_handoff=pin(S/'handoff-v1.json'),
        benchmark_intake_parent_closure=oldref,benchmark_input_capsule=capsule_ref,
        bridge_scope='All40 runs retain exact previous24scientificaliases and their full import/native/runtime maps. Only new Source-entry intake hash/version and outer/observer entrypins adapt to10 frozen assertion inputs, each with4arms. No scientific operation evaluated here.',
        limitations=[str(x).replace('all23','all24') for x in old['limitations']])
    for k,v in old.items():
        if k not in ['Source_design','current_composition_handoff','bridge_scope','limitations']:assert closure[k]==v
    assert closure['parent_closure']==old['parent_closure']
    cref=save(R/'runtime-closure-v1.json',closure)
    sources=hand['sources'];projects=closure['project_sources'];components=closure['additional_nonseed_components']
    global_decl=dict(design,schema='ROOT-frozen-first-order-40-arm-experiment-declaration-v1',runtime_closure=cref,
        input_capsule=capsule_ref,intake_Source_handoff=pin(S/'handoff-v1.json'),
        source_state='FROZEN_SCIENTIFIC_CODE_MINIMAL_INPUT_INTAKE_SUBJECT_TO_DISTINCT_REVIEWS',
        source_gate='Source/input/full40subject reviews, separate maxonegrants/delta/Rootadoption/allagentsidle required. This full40declaration grants no execution.')
    global_ref=save(R/'experiment-declaration-v1.json',global_decl)
    D=R/'case-declarations';D.mkdir()
    case_refs={}
    for receiver in capsule['receivers']:
        schedule=[r for r in design['schedule'] if r['receiver_id']==receiver['id']]
        assert len(schedule)==4 and {(r['mode'],r['search_ordering']) for r in schedule}=={(m,o)for m in ['fixed','symbolic']for o in ['legacy','and_support']}
        declaration=dict(schema=api['declaration_schema'],author_identity='/root',parent_structural_declaration=capsule_ref,
            selected_receiver=receiver,selected_receiver_id=receiver['id'],result_reader='interned',model_storage='literal_interned',
            runtime_closure=cref,limits=design['limits'],schedule=schedule,global_cohort_declaration=global_ref,
            new_RL_training=False,scientific_calls=0,actual_execution_authorized=False,goal_complete=False,
            source_gate=global_decl['source_gate'],intake_Source_handoff=pin(S/'handoff-v1.json'))
        case_refs[receiver['id']]=save(D/(receiver['id']+'.json'),declaration)
    tree=ast.parse(verify(sources['once_runner']))
    limits=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name)and t.id=='LIMITS'for t in n.targets))
    assert limits==dict(work_seconds=180,overall_seconds=210,aggregate_peak_bytes=1073741824,stdout_bytes=4194304,
        stderr_bytes=4194304,result_bytes=134217728,worker_receipt_bytes=4194304,runner_plan_bytes=16777216,failure_cleanup_seconds=5,poll_milliseconds=20)
    zfiles=[{k:d[k]for k in ['path','sha256','bytes']}for d in closure['Z3']['files']]
    library=next(d for d in zfiles if d['path']==str(Path(closure['Z3']['package_root'])/'z3/lib/libz3.dylib'))
    python=closure['runtime']['Python_executable']
    native=dict(program_and_template=closure['fixed_native_inputs']['program_and_template'],
        opaque_microcode_gzip=closure['fixed_native_inputs']['opaque_microcode_gzip'],native_cpp=closure['native_CPP']['binary'])
    policy=pin('/private/tmp/gcts-semantic-family-next-audit-20261018/semantic-inventory-policy-001.json')
    for d in [python,policy]+zfiles+list(native.values()):verify(d)
    rows=design['schedule'];assert len(rows)==40
    assert len({r['invocation_id']for r in rows})==len({r['actual_directory']for r in rows})==40
    P.mkdir()
    for name in ['worker-plans','authorization-drafts','runner-plan-drafts']:(P/name).mkdir()
    subjects=[]
    for row in rows:
        assert not Path(row['actual_directory']).exists()
        base={k:row[k]for k in ['invocation_id','mode','search_ordering','model_storage','result_reader','receiver_id','actual_directory']}
        dref=case_refs[row['receiver_id']]
        worker=dict(base,schema=api['worker_schema'],cold=sources['cold'],python=python,project_sources=projects,components=components,
            native_inputs=native,policy=policy,declaration=capsule_ref,integration_declaration=dref,runtime_closure=cref,
            z3=dict(root=closure['Z3']['package_root'],files=zfiles,library=library))
        assert set(worker)==set(api['worker_fields'])
        iid=row['invocation_id'];wref=save(P/'worker-plans'/(iid+'.json'),worker)
        subject=dict(base,schema=api['once_schema'],runner=sources['once_runner'],observer=sources['terminal_observer'],
            python=python,cold=sources['cold'],worker_plan=wref,integration_declaration=dref,runtime_closure=cref,
            limits=limits,environment=dict(LANG='en_US.UTF-8',LC_ALL='en_US.UTF-8',TZ='UTC'))
        sha=hashlib.sha256(canonical(subject)).hexdigest()
        auth=dict(schema=api['authorization_schema'],author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=1,
            subject_sha256=sha,review_roles={},scope='FALSE prospective subject. Original full40cohort immutable; no execution before exact Source/input/plan reviews, truegrantdelta/Rootadoption/allagentsidle.')
        assert set(auth)==set(api['authorization_fields'])
        aref=save(P/'authorization-drafts'/(iid+'.json'),auth)
        final=dict(subject,authorization=aref);assert set(final)==set(api['once_fields'])
        qref=save(P/'runner-plan-drafts'/(iid+'.json'),final)
        subjects.append(dict(row,worker_plan=wref,authorization_draft=aref,runner_plan_draft=qref,subject_sha256=sha))
    idx=dict(schema='ROOT-first-order-suite-prospective-plan-index-v1',author_identity='/root',source_only=True,
        scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,actuals_started=0,goal_complete=False,
        declaration=global_ref,case_declarations=case_refs,input_capsule=capsule_ref,runtime_closure=cref,
        frozen_scientific_parent=oldref,cold=sources['cold'],runner=sources['once_runner'],observer=sources['terminal_observer'],
        composition_handoff=pin(S/'handoff-v1.json'),API=pin(S/'API-v1.json'),review_role_schemas=api['review_roles'],schedule=subjects,
        scope='All40 once-only subjects prepared before execution:10frozen inputs/eightgroups,4arms percase with original fullprofile and identical24scientificaliases. False grants only; no newRL/Native/solver/search/renderer evaluation.')
    print(json.dumps(dict(index=save(P/'prospective-index-v1.json',idx),closure=cref,declaration=global_ref,subjects=40,actuals_started=0)))

if __name__=='__main__':main()
