"""Root raw-metadata grant adoption only. Never imports or launches search."""
from pathlib import Path
import hashlib
import json
import sys

R = Path(__file__).resolve().parent
I = Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1/authorized-index-v1.json')

def load(p):
    return json.loads(Path(p).read_bytes())

def pin(p):
    p=Path(p).resolve(); b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def main(peer_path):
    idx=load(I)
    assert pin(I)['sha256']=='8892cb887508d87f0b6d7cf0091975f9654a70ecf60872437688ae76207544d0'
    assert pin(peer_path)['sha256']=='d66f4415d544414186674562ce22d8ddd54ddb2e28d3e733c2ba969d5fb32d5f'
    peer=load(peer_path)
    assert peer['schema']=='and-support-final-grant-delta-review-v1'
    assert peer['final_grant_delta_review_passed'] is True
    assert peer['reviewer_identity']=='/root/conventional_library'
    assert peer['author_identity']=='/root'
    assert peer['source_only'] is True and peer['scientific_calls']==0
    assert peer['actual_execution_authorized'] is False
    # The independent reviewer must bind the complete exact authorized index.
    def contains(v, target):
        if v==target:return True
        if type(v)is dict:return any(contains(q,target) for q in v.values())
        if type(v)is list:return any(contains(q,target) for q in v)
        return False
    assert contains(peer,pin(I))
    seen={}
    def verify(v):
        if type(v)is dict:
            if set(v)=={'path','sha256','bytes'}:
                if v['path'] not in seen:
                    assert pin(v['path'])==v, v['path'];seen[v['path']]=v
            else:
                for q in v.values():verify(q)
        elif type(v)is list:
            for q in v:verify(q)
    verify(idx)
    design=pin(R/'prospective-design-v1.json')
    assert design['sha256']=='3b324a86de79a408a4d1317d94c6e03a807e4367afaf15f24cf0ec5e2288139f'
    expected=load(design['path'])['schedule']
    assert len(expected)==len(idx['schedule'])==40
    assert all(all(row[k]==v for k,v in exp.items()) for exp,row in zip(expected,idx['schedule']))
    launcher=pin(R/'run_forty_once_v2.py')
    assert launcher['sha256']=='428e6a62e3c9aa0c95cea9d8e816fecd498ec34f198d6c4cc8d64d9ab0b53571'
    lp=Path('/private/tmp/gcts-first-order-suite-launcher-peer-20261018/typed-Source-review-v2.json')
    assert pin(lp)['sha256']=='0a6586ab561cb045c8fce6dd5ee7fda5cf71fc78e7e290c6493a222efc800626'
    l=load(lp)
    assert l['schema']=='first-order-suite-launcher-Source-review-v1'
    assert l['launcher_review_passed'] is l['source_review_passed'] is True
    assert l['reviewer_identity']=='/root/receiver_driver_review'
    assert l['author_identity']=='/root' and l['source']==launcher
    assert l['source_only'] is True and l['scientific_calls']==0 and l['actual_execution_authorized'] is False
    ip=Path('/private/tmp/gcts-first-order-suite-input-peer-20261018/typed-input-design-review-v1.json')
    assert pin(ip)['sha256']=='769b4e57594093a7335b41962766ca6151c21517068a02676592837f789c617c'
    ir=load(ip)
    assert ir['input_design_review_passed'] is True and contains(ir,design)
    new=load(idx['runtime_closure']['path']);old=load(idx['frozen_scientific_parent']['path'])
    for key in ['project_sources','materialized_aliases','additional_nonseed_components','parent_closure']:
        assert new[key]==old[key], key
    subjects=[]
    for row in idx['schedule']:
        true=load(row['runner_plan']['path']);false=load(row['runner_plan_draft']['path'])
        subject={k:v for k,v in true.items() if k!='authorization'}
        assert len(subject)==17
        assert subject=={k:v for k,v in false.items() if k!='authorization'}
        raw=json.dumps(subject,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
        assert hashlib.sha256(raw).hexdigest()==row['subject_sha256']
        grant=load(row['authorization']['path']);draft=load(row['authorization_draft']['path'])
        delta={'actual_execution_authorized','review_roles','scope'}
        assert {k:v for k,v in grant.items() if k not in delta}=={k:v for k,v in draft.items() if k not in delta}
        assert grant['maximum_actual_invocations']==1 and grant['actual_execution_authorized'] is True
        assert grant['subject_sha256']==row['subject_sha256']
        assert set(grant['review_roles'])==set(idx['review_role_schemas'])
        for role,binding in grant['review_roles'].items():
            spec=idx['review_role_schemas'][role];receipt=load(binding['receipt']['path'])
            assert receipt['schema']==spec['schema'] and receipt[spec['pass']] is True
            assert binding['receipt']==idx['current_review_roles'][role]
            assert receipt['reviewer_identity']==binding['reviewer_identity']==spec['reviewer']
            assert receipt['source_only'] is True and receipt['scientific_calls']==0
            assert receipt['actual_execution_authorized'] is False
            for desc in binding['required_subjects']:assert contains(receipt,desc)
        verify(true);verify(grant);verify(load(row['worker_plan']['path']))
        actual=Path(row['actual_directory'])
        observer=Path(row['runner_plan']['path']).with_name(Path(row['runner_plan']['path']).stem+'-terminal-observation')
        assert not actual.exists() and not observer.exists()
        subjects.append(dict(invocation_id=row['invocation_id'],subject_sha256=row['subject_sha256'],actual_directory=str(actual),terminal_observation=str(observer)))
    assert len(subjects)==40
    out=dict(schema='ROOT-first-order-suite-final-grant-adoption-v1',authorized_index=pin(I),final_grant_peer=pin(peer_path),launcher=launcher,design=design,launcher_peer=pin(lp),input_design_peer=pin(ip),
        raw_descriptors_verified=len(seen),unchanged_full_subjects=subjects,actuals_started=0,scientific_calls=0,
        metadata_adoption_passed=True,actual_execution_authorized=True,goal_complete=False,
        scope='Root adopts independently reviewed exact forty max-one grants. All actual/observer directories absent at adoption. All-agent idle snapshot still required before first launch. No scientific code evaluated or mathematical admission by this script; exact Source scopes and inherited authorship caveats retained.')
    p=R/'ROOT-final-grant-adoption-v1.json'
    with p.open('x') as f:f.write(json.dumps(out,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(json.dumps(pin(p)))

if __name__=='__main__':
    assert len(sys.argv)==2
    main(sys.argv[1])
