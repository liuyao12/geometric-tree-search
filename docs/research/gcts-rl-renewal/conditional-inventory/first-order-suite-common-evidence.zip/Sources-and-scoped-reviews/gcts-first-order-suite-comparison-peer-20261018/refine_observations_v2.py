"""Narrow saved-data reporting corrections; no scientific calls."""
import json,pathlib,hashlib,collections
O=pathlib.Path('/private/tmp/gcts-first-order-suite-comparison-peer-20261018');D=json.loads((O/'retained-comparison-data-v1.json').read_bytes());checks=[];graphs={};graph_comparisons=[]
def can(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def ck(n,v):checks.append({'name':n,'passed':bool(v)})
for row in D['rows']:
 s=row['search'];enabled=bool(s and s.get('support')and s['support'].get('enabled'))
 if not s or(row['mode']!='symbolic'and not enabled):continue
 raw=pathlib.Path(row['raw_result']['path']).read_bytes();x=json.loads(raw);o=x['outputs'];saved=o['search'];ck(row['invocation_id']+'.raw_unchanged',hashlib.sha256(raw).hexdigest()==row['raw_result']['sha256'])
 if row['mode']=='symbolic':
  status=x['root_restoration'];ok=saved['root_path_restored']is True and o['symbolic_point_projection']['root_path_restored']is True and x['model_identity_sha256']==x['model_after_identity_sha256']
  row['specialized_restoration_observation']={'literal_root_restoration':status,'search_prefix_restored':saved['root_path_restored'],'projection_prefix_restored':o['symbolic_point_projection']['root_path_restored'],'model_identity_equal':x['model_identity_sha256']==x['model_after_identity_sha256']}
  ck(row['invocation_id']+'.prefix_and_Model_restored',ok)
 if enabled:
  m=saved['support_ordering_metadata']if row['mode']=='fixed'else saved['support_ordering'];g=m['graph'];fid=g['target_formula_id'];gb=can(g['graph_preimage']);cid=row['receiver_id']
  if cid not in graphs:graphs[cid]=gb
  same=gb==graphs[cid];ck(row['invocation_id']+'.samecase_full_helper_graph',same);graph_comparisons.append({'invocation_id':row['invocation_id'],'full_literal_graph_equal':same,'graph_sha256':g['graph_sha256']})
  calls=[e['support_ordering']for e in saved.get('events',[])if isinstance(e,dict)and isinstance(e.get('support_ordering'),dict)]if row['mode']=='fixed'else m['ranking_calls']
  bases=collections.Counter();afters=collections.Counter();reduced=0;finite=0
  for call in calls:
   rank=call.get('ranking')
   if not isinstance(rank,dict)or rank['status']!='SCORED':continue
   base={c['formula_id']:c['cost']for c in rank['base_costs']}[fid];bases[str(base)]+=1
   order=rank['order'];scores={c['option_index']:c['score_id']for c in rank['option_scores']};distinct={c['score_id']:c for c in rank['distinct_output_scores']}
   if not order:continue
   chosen=distinct[scores[order[0]]];after=chosen['target_cost_after'];afters[str(after)]+=1
   if chosen['marginal_reduction']is not None and chosen['marginal_reduction']>0:reduced+=1
   if chosen['makes_target_potential_finite']:finite+=1
  sup=s['support'];sup.pop('base_target_costs',None);sup.pop('selected_target_costs',None)
  sup['base_target_costs']=dict(bases);sup['selected_target_costs']=dict(afters);sup['selected_positive_marginal_reductions']=reduced;sup['selected_makes_target_finite']=finite
 print(row['receiver_id'][-3:],row['mode'],row['search_ordering'],flush=True)
# Original V1 conflated a specialized chronological prefix with the GCTS graph root.
old_fail=[c for c in D['checks']if not c['passed']]
ck('all12_v1_mismatches_were_only_symbolic_GCTS_root_predicate',len(old_fail)==12 and all(c['name'].endswith('.restored')and any(r['invocation_id']+'.restored'==c['name']and r['mode']=='symbolic'for r in D['rows'])for c in old_fail))
D['checks']=[c for c in D['checks']if not(any(c['name']==r['invocation_id']+'.restored'and r['mode']=='symbolic'for r in D['rows']))]+checks
D['schema']='first-order-suite-retained-comparison-data-v2';D['supersedes_reporting_projection']=desc(O/'retained-comparison-data-v1.json');D['reporting_corrections']={'v1_preserved':True,'not_actual_mutation':True,'restoration':'Symbolic controls have N/A GCTS root; use actual search+projection prefix restoration and unchanged Model identity. All12 original false comparisons are this review predicate, not scientific failures.','potential':'Read rank.base_costs[].cost and option_scores[].score_id→distinct_output_scores[].target_cost_after; do not treat option_scores as flattened target scores.'};D['helper_graph_full_literal_comparisons']=graph_comparisons
D['summary']={'checks':len(D['checks']),'mismatches':sum(not c['passed']for c in D['checks']),'status_counts':dict(collections.Counter(r['status']for r in D['rows'])),'scientific_replays':0}
(O/'retained-comparison-data-v2.json').write_text(json.dumps(D,indent=2)+'\n')
print('DONE',json.dumps({'data':desc(O/'retained-comparison-data-v2.json'),'summary':D['summary']}),flush=True)
