"""Retained metadata only, no control execution."""
import json,pathlib,hashlib
O=pathlib.Path('/private/tmp/gcts-first-order-suite-comparison-peer-20261018');D=json.loads((O/'retained-comparison-data-v2.json').read_bytes());obs=[]
for row in D['rows']:
 if row['mode']!='symbolic'or not row['search']:continue
 raw=pathlib.Path(row['raw_result']['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['raw_result']['sha256'];s=json.loads(raw)['outputs']['search']
 obs.append({'invocation_id':row['invocation_id'],'receiver_id':row['receiver_id'],'search_ordering':row['search_ordering'],'raw_result':row['raw_result'],'preparation_seconds':s['preparation_seconds'],'enumeration_and_return_seconds':s['enumeration_and_return_seconds'],'total_search_seconds':s['seconds'],'scope':'Preparation includes unchanged symbolic grammar/maps plus optional shared graph; not exclusive helper graph profiling.'})
 print(row['receiver_id'][-3:],row['search_ordering'],s['preparation_seconds'],flush=True)
(O/'symbolic-preparation-observations-v1.json').write_text(json.dumps({'schema':'first-order-suite-retained-symbolic-setup-observations-v1','scientific_replays':0,'rows':obs},indent=2)+'\n')
