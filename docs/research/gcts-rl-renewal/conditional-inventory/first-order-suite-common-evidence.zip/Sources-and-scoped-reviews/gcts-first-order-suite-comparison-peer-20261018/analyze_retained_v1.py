"""Stdlib saved JSON analysis only; no scientific imports/evaluation/replay."""
import collections,hashlib,json,pathlib
P=pathlib.Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1');ROOT=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');O=pathlib.Path('/private/tmp/gcts-first-order-suite-comparison-peer-20261018')
I=json.loads((P/'authorized-index-v1.json').read_bytes());CP=ROOT/'.gcts-active/first-order-suite-progress-20261018/ROOT-cohort-closure-v1.json';CL=json.loads(CP.read_bytes());clrows={r['invocation_id']:r for r in CL['actuals']};checks=[];rows=[];baseline={};comparisons=[];current=None;proofs=[]
def can(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def ck(n,b):checks.append({'name':n,'passed':bool(b)})
def cutoffs(tree):
 c=collections.Counter();stack=[tree]
 while stack:
  v=stack.pop()
  if type(v)is dict:
   if 'cutoff'in v:c[str(v['cutoff'])]+=1
   stack.extend(x for x in v.values()if isinstance(x,(dict,list)))
  elif type(v)is list:stack.extend(x for x in v if isinstance(x,(dict,list)))
 return dict(c)
def support(s,mode):
 if not s:return None
 m=s.get('support_ordering_metadata')if mode=='fixed'else s.get('support_ordering')
 if type(m)is not dict:return {'enabled':False}
 g=m.get('graph');target=g.get('target_formula_id')if type(g)is dict else None
 calls=[e['support_ordering']for e in s.get('events',[])if type(e)is dict and type(e.get('support_ordering'))is dict]if mode=='fixed'else m.get('ranking_calls',[])
 stats=collections.Counter();bases=collections.Counter();afters=collections.Counter();work=0;opts=0
 for call in calls:
  rank=call.get('ranking')
  if type(rank)is not dict:stats['no_complete_ranking']+=1;continue
  stats['ranking_'+rank.get('status','UNKNOWN')]+=1;work+=rank.get('counts',{}).get('work',0);opts+=len(rank.get('options',[]))
  bc=rank.get('base_costs',[]);bases[str(bc[target]if type(bc)is list and type(target)is int and target<len(bc)else None)]+=1
  order=rank.get('order',[])
  if order and order!=list(range(len(order))):stats['changed_full_window_order']+=1
  if order and order[0]!=0:stats['changed_first_ranked_option']+=1
  if mode=='fixed'and call.get('selected_index')!=call.get('legacy_index'):stats['changed_legacy_hint_choice']+=1
  scores=rank.get('option_scores',[])
  if order and scores:afters[str(scores[order[0]].get('target_cost_after'))]+=1
 return {'enabled':s.get('support_ordering')=='and_support'if mode=='fixed'else True,'metadata_status':m.get('status'),'graph_seconds':m.get('graph_seconds'),'graph_status':g.get('status')if type(g)is dict else None,'graph_sha256':g.get('graph_sha256')if type(g)is dict else None,'graph_counts':g.get('counts')if type(g)is dict else None,'target_formula_id':target,'call_records':len(calls),'rank_counts':dict(stats),'base_target_costs':dict(bases),'selected_target_costs':dict(afters),'rank_work_sum':work,'rank_option_count':opts,'metrics':m.get('metrics')}
for n,r in enumerate(I['schedule'],1):
 iid=r['invocation_id'];cid=r['receiver_id'];A=pathlib.Path(r['actual_directory']);raw=(A/'result.json').read_bytes();x=json.loads(raw);w=json.loads((A/'worker-receipt.json').read_bytes());q=json.loads((A/'runner-receipt.json').read_bytes());tp=pathlib.Path(r['runner_plan']['path']).parent/(iid+'-terminal-observation')/'terminal.json';t=json.loads(tp.read_bytes());o=x['outputs'];s=o.get('search');reg=o['register'];record=x['records'][reg['query']];comp=o['compile'];m=o.get('model')
 ck(iid+'.raw_join',hashlib.sha256(raw).hexdigest()==w['result']['sha256']and len(raw)==w['result']['bytes'])
 ck(iid+'.identity_status',x['status']==w['status']==clrows[iid]['status']and x['mode']==r['mode']and x['search_ordering']==r['search_ordering']and x['receiver_id']==cid)
 ck(iid+'.resource_terminal',q['resource_candidate_accepted']is True and t['terminal_gate_passed']is True and q['errors']==[])
 ck(iid+'.complete_compile',comp['status']=='complete');ck(iid+'.registry_join',record['purpose']=='check_generated_lemma_definitions'and record['id']==reg['query'])
 data={'compiler':{k:v for k,v in comp.items()if k!='seconds'},'specialization':o['specialize'],'inventory':{k:reg[k]for k in ['definitions','interfaces','native_blocks']}}
 if m:data['model']={k:v for k,v in m.items()if k!='compile_seconds'}
 if 'initial_state'in x:data['initial_state']=x['initial_state']
 if current!=cid:baseline={};current=cid
 cats={}
 for k,v in data.items():
  b=can(v);cats[k]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  if k not in baseline:baseline[k]=b
  same=b==baseline[k];ck(iid+'.samecase_'+k,same);comparisons.append({'invocation_id':iid,'category':k,'full_literal_equal':same,'projection':cats[k]})
 if not m:ck(iid+'.stop_before_Model_search',s is None and 'initial_state'not in x)
 else:ck(iid+'.restored',x['root_restoration']['root_restored']is True and x['model_identity_sha256']==x['model_after_identity_sha256'])
 e=o.get('essential_ancestry');h=o.get('winning_hint_links');ec=e.get('essential_calls',[])if e else[]
 rr={'order':n,'receiver_id':cid,'mode':r['mode'],'search_ordering':r['search_ordering'],'invocation_id':iid,'status':x['status'],'raw_result':{'path':str(A/'result.json'),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)},'worker_receipt':desc(A/'worker-receipt.json'),'runner_receipt':desc(A/'runner-receipt.json'),'terminal':desc(tp),
 'native_proof_candidate':x['native_proof_accepted'],'resource_candidate':q['resource_candidate_accepted'],'terminal_candidate':t['terminal_gate_passed'],'family_hint_success':x['family_hint_success'],'quantified_reasoning_success':x['quantified_reasoning_success'],
 'external_terminal_seconds':(t['terminal_observed_ns']-q['began_ns'])/1e9,'worker_plus_native_MiB':q['conservative_parent_plus_native_peak_bytes']/1048576,'worker_peak_MiB':q['python_wait4_usage']['ru_maxrss']/1048576,'native_peak_MiB':x['transport_receipt']['native_high_water_bytes']/1048576,'native_queries':len(x['records']),
 'phase_seconds':{a['stage']:a['returned_monotonic']-a['started_monotonic']for a in x['stage_intervals']},'serialization_seconds':w['driver_output_receipt']['output']['serialization_to_preflight_seconds'],'reader_decode_seconds':w['result_reading']['decode_seconds'],'reader_roundtrip_seconds':(w['result_reading']['completed_ns']-w['result_reading']['started_ns'])/1e9,
 'compile':{'status':comp['status'],'basis':len(comp['basis']),'schemes':len(comp['admitted_schemes']),'tautologies':len(comp['tautologies']),'variables':comp['variables']},
 'inventory':{'status':reg['status'],'definitions':len(reg['definitions']),'interfaces':len(reg['interfaces']),'specialized_definitions':len(o['specialize']['definitions']),'native_record_id':reg['query'],'native_result':record['result'],'native_limit':x['transport_receipt']['request_stages'][reg['query']]['limit'],'native_seconds':record['seconds']},
 'model':{'placements':len(m['placements']),'arity':m['arity'],'roots':len(m['roots']),'command_counts':m['command_counts']}if m else None,
 'search':{'status':s['status'],'reason':s.get('reason'),'seconds':s['seconds'],'metrics':s['metrics'],'cutoffs':cutoffs(s.get('tree')),'events':len(s.get('events',[])),'proof_rows':len(s.get('proof')or[]),'support':support(s,r['mode'])}if s else None,
 'root_restoration':x.get('root_restoration'),'semantic_categories':cats,
 'essential':{'call_count':len(ec),'levels':dict(collections.Counter(c['level']for c in ec)),'source_families':sorted({c['family']for c in ec}),'nonidentity_calls':sum(c.get('nonidentity')is True for c in ec),'compound_calls':sum(bool(c.get('compound_argument_indices'))for c in ec),'UI':e.get('essential_instantiate_count'),'GEN':e.get('essential_generalize_count'),'root':e.get('root')}if e else None,
 'winning_hint':{'strong_family_hint_use':h.get('strong_family_hint_use'),'changed_order_family_hint_use':h.get('changed_order_family_hint_use'),'links':h.get('links')}if h else None}
 rows.append(rr)
 if x['native_proof_accepted']:proofs.append({'invocation_id':iid,'proof':s['proof'],'essential_ancestry':e,'winning_hint_links':h})
 print('%02d %s %s/%s %s'%(n,cid[-3:],r['mode'],r['search_ordering'],x['status']),flush=True)
 del raw,x,o,comp,reg,record,s,m,data
payload={'schema':'first-order-suite-retained-comparison-data-v1','authorized_index':desc(P/'authorized-index-v1.json'),'cohort_closure':desc(CP),'rows':rows,'samecase_literal_comparisons':comparisons,'checks':checks,'summary':{'checks':len(checks),'mismatches':sum(not c['passed']for c in checks),'status_counts':dict(collections.Counter(r['status']for r in rows)),'scientific_replays':0}}
(O/'retained-comparison-data-v1.json').write_text(json.dumps(payload,indent=2)+'\n');(O/'retained-proof-observations-v1.json').write_text(json.dumps({'schema':'first-order-suite-retained-proof-observations-v1','scope':'Saved observer/proof data only; no new proof validity accepted','proofs':proofs},indent=2)+'\n')
print('DONE',json.dumps({'data':desc(O/'retained-comparison-data-v1.json'),'proofs':desc(O/'retained-proof-observations-v1.json'),'checks':len(checks),'mismatches':sum(not c['passed']for c in checks)}),flush=True)
