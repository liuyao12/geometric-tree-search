"""Stdlib retained headers and independent audit reconciliation only."""
import collections
import gc
import hashlib
import json
from pathlib import Path
OUT=Path(__file__).parent
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
LEDGER=ROOT/'.gcts-active/first-order-suite-progress-20261018'
checks=[]
def raw(p):
 p=Path(p);assert not p.stat().st_flags&0x40000000;return p.read_bytes()
def load(p):return json.loads(raw(p))
def ref(p):
 p=Path(p);b=raw(p);return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def ck(ok,label):
 checks.append(dict(check=label,passed=bool(ok)))
 if not ok:raise ValueError(label)
def emit(name,x):
 p=OUT/name
 if p.exists():raise ValueError('preserve peer '+name)
 p.write_text(json.dumps(x,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n');return ref(p)
core=load(OUT/'audit-v1.json');index=load(core['index']['path']);admit_path=LEDGER/'ROOT-actual-admission-v1.json';admit=load(admit_path)
ck(ref(admit_path)['sha256']=='da6088925e44be6ca4bcb7fb21573fc676c8706eb01cc59f5eb73ceb7998371c' and ref(admit_path)['bytes']==2465113,'exact separate Root admission')
ck(len(admit['actuals'])==40 and admit['authorized_index']==core['index'] and admit['cohort_closure']==core['cohort_closure'],'same entire Root cohort/index/order')
rows=[];positive=[];preimages_checked=set();raw_headers=[]
for row,a,r in zip(index['schedule'],core['actuals'],admit['actuals']):
 label=row['invocation_id'];w=load(a['worker_receipt']['path']);q=load(a['runner_receipt']['path']);rp=load(row['runner_plan']['path']);wp=load(row['worker_plan']['path'])
 ck(label==a['invocation_id']==r['invocation_id'],'same retained current Root/raw peer subject '+label)
 ck(w['worker_plan']==row['worker_plan']==rp['worker_plan'] and w['cold']==rp['cold']==index['cold'],'exact current worker/cold header entries '+label)
 ck(w['integration_declaration']==rp['integration_declaration']==index['case_declarations'][row['receiver_id']] and
    q['runtime_closure']==rp['runtime_closure']==index['runtime_closure'],'whole selected integration/closure header bindings '+label)
 chosen_alias='semantic_inventory_search_v2' if row['mode']=='fixed' else 'quantified_symbolic_control_v2'
 selected=w['selected_search_module'];owned=Path(row['actual_directory'])/'modules'/(chosen_alias+'.py')
 ck(selected['module']==chosen_alias and selected['original']==wp['project_sources'][chosen_alias] and selected['owned']==ref(owned),'exact actual selected search original+owned provenance '+label)
 ck(r['status']==a['status'] and r['fresh_native_proof']==a['native_proof_accepted'] and r['result']==a['result'] and
    r['worker_receipt']==a['worker_receipt'] and r['runner_receipt']==a['runner_receipt'] and r['terminal']==a['terminal'],'Root outcome/raw endpoint joins '+label)
 for field,d in r['semantic_preimages'].items():
  pair=(a['receiver_id'],field)
  if pair not in preimages_checked:
   own=core['complete_case_projection_preimages'][a['receiver_id']][field]
   ck(ref(d['path'])==d and raw(d['path'])==raw(own['path']),'complete literal independent/Root canonical preimage '+str(pair));preimages_checked.add(pair)
 if a['native_proof_accepted']:
  z=a['whole_region'];rr=r['whole_region'];e=a['essential_ancestry'];f=a['full_primitive_expansion'];h=a['winning_hint_joins'];t=a['support_telemetry']
  ck(r['proof']==z['proof'] and rr['union_sha256']==z['union_sha256'] and rr['assigned_mark_points']==z['mark_points'] and
     rr['required_points']==z['required_points'] and rr['selected_placements']==z['selected_placements'] and rr['decoded_rows']==z['decoded_rows'],'Root/independent allpoint/word joins '+label)
  ck(r['essential_ancestry']['root']['essential_rows']==e['essential_rows'] and
     r['essential_ancestry']['root']['essential_recursive_primitive_rule_counts']==e['essential_rule_counts'],'Root/independent exact recursive essential data '+label)
  item=dict(invocation_id=label,receiver_id=a['receiver_id'],mode=a['mode'],search_ordering=a['search_ordering'],
    result=a['result'],whole_region={k:v for k,v in z.items() if k!='proof'},proof_lines=a['proof_lines'],
    essential_rows=e['essential_rows'],padding_rows=e['padding_rows'],essential_recursive_primitive_rule_counts=e['essential_rule_counts'],
    essential_recursive_primitive_commands=sum(e['essential_rule_counts'].values()),essential_primitive_dependency_depth=f['essential_target_dependency_depth'],
    essential_calls=e['essential_calls'],winning_hint_joins=h,support_telemetry=t,
    quantified_reasoning_success=a['quantified_reasoning_success'],inherited_family_hint_success=a['inherited_family_hint_success'])
  if a['mode']=='fixed' and a['search_ordering']=='and_support':
   item['actual_support_hint_choice_changes']=sum(v['legacy_index']!=v['selected_index'] for v in t['ranking_calls'])
   item['essential_rows_with_changed_support_hint_choice']=sorted({v['row'] for v in h['links'] if v['strong_nonidentity_same_instance'] and v['support_changed_hint_choice']})
  positive.append(item)
 rows.append({k:a[k] for k in ('invocation_id','receiver_id','mode','search_ordering','result','worker_receipt','runner_receipt','terminal','status','native_proof_accepted','records','complete_literal_projection_fields')})
 raw_headers.extend([a['worker_receipt'],a['runner_receipt'],a['terminal'],row['worker_plan'],row['runner_plan'],row['authorization']])
 del w,q,rp,wp;gc.collect()
counts=core['status_counts'];derived_counts=dict(collections.Counter(a['status'] for a in core['actuals']))
ck(counts==derived_counts and sum(counts.values())==40,'status denominator derived from all40 retained outcomes')
ck(admit['fresh_native_proofs']==len(positive) and admit['findings']==[],'Root independently derived same positive total with no reported findings')
observations=emit('final-header-and-Root-joins-v1.json',dict(schema='first-order-suite-final-saved-header-and-Root-joins-v1',
 retained_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,
 author_identity='/root',reviewer_identity='/root/receiver_driver_review',checks=checks,check_count=len(checks),findings=[],
 Root_admission=ref(admit_path),parent_audit=ref(OUT/'audit-v1.json'),positive_proof_summary=positive,
 full_raw_results=[a['result'] for a in core['actuals']],exact_headers_and_grants=raw_headers))
preflight=load(OUT/'audit-preflight-observation-v1.json')
preflight['additional_auditor_only_corrections']=[
 'Saved winning_hint_links.links intentionally includes partial-use observations. The auditor now recomputes and compares full-members/exact-ports flags and strong-link filtering instead of assuming every link is strong.',
 'Saved symbolic grammar.rows is the complete list of12 sorted command-domain lists, not an integer row count. Auditor checks len(rows) and every full saved skeleton k against the complete Model C domain.']
preflight_note=emit('auditor-preflight-scope-addendum-v1.json',preflight)
limitations=[
 'Retained-data review only; no project, Model, compiler, helper, scientific search, Native/proof kernel, logic, Reader, codec or renderer import/evaluation/replay, and no actual rerun.',
 'Native mathematical truth is conditional on exact fresh accepted Native transcripts and reviewed pinned Native transport/checker authority. This Python audit did not prove general first-order soundness or re-run native side conditions.',
 'Every full raw result/header pinned. Complete compiler fields except seconds, complete definitions/interfaces/native_blocks, complete Model except compile_seconds and whole initial state were compared literally within each case where present. No hash-only equality or candidate/mark omission; explicit zero remains assigned and missing marks remain absent.',
 'Native inventory UNKNOWN runs retain complete compiler and generated candidate-inventory preimages. They have no admitted Model/initial/search/target proof. Search UNKNOWNs retain their full available common model/initial/search, with no invented positive result or exhaustiveness/refutation claim.',
 'For all12 positives, exact entire finite point occupancy totals are12 at every required target, assigned m-values agree at all reached long-range points, and full C/G/input rows decode to the exact final Native word. This is the current symbolic point encoding, not direct Euclidean/geometric logical soundness.',
 'Full primitive trace is a literal expansion of retained registered bodies with actual ordered ports and index substitution; target-essential ancestry/counts/depth are derived from saved strict-prior dependencies. It is not a replacement proof kernel or new proof search.',
 'All retained essential family calls are level1 existing ground instances. Universal instantiate is an implication licence, not a consequence fact. Positive cases004 use an essential UI command but no GEN;001/009 use equality substitution and no UI/GEN. Quantifier-specific success flags are therefore false although native proof flags are true.',
 'Winning hint links include partial links. Full-member/exact-port/nonidentity qualifying links are separately counted, and actual shared-support changed hint choice, changed ranking permutation and changed incident order are distinguished. No counterfactual replay or causal/general speed claim.',
 'Positive shared-support score receipts are checked for full current graph inputs/edge provenance, recursively justified strict-prior seeds and positive-cost origin arithmetic; no helper fixed-point relaxation was executed. Search-cutoff telemetry is retained with explicit incomplete-search scope.',
 'Rollback/source/callable custody flags remain Source-backed saved runtime observations, not independent state/Graph replay. Conservative resource and process ownership interpretation also remains the separate Control resource review and Root admission.',
 'Ten authored synthetic inputs form eight primary structural groups plus two correlated renamings. They are not official TPTP imports or a blinded external benchmark. One once-only arm per case/strategy supports no statistical, RL, unrestricted-mathematics or GCTS-specific superiority claim.']
review=emit('typed-data-review-v1.json',dict(schema='first-order-suite-retained-data-review-v1',author_identity='/root',reviewer_identity='/root/receiver_driver_review',
 data_review_passed=True,retained_data_only=True,source_only=False,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,
 authorized_index=core['index'],cohort_closure=core['cohort_closure'],Root_admission=ref(admit_path),input_capsule=core['input_capsule'],
 audit=ref(OUT/'audit-v1.json'),audit_summary=ref(OUT/'audit-summary-v1.json'),final_saved_header_joins=observations,
 auditor_Source=ref(OUT/'audit_retained_v1.py'),finalizer_Source=ref(__file__),auditor_preflight_observation=ref(OUT/'audit-preflight-observation-v1.json'),auditor_preflight_addendum=preflight_note,
 checks_passed=core['check_count']+len(checks),findings=[],status_counts=counts,retained_actuals=len(rows),native_positive_actuals=len(positive),
 full_raw_results=[a['result'] for a in core['actuals']],actuals=rows,positive_proof_summary=positive,
 common_literal_preimages=core['complete_case_projection_preimages'],
 authorship_disclosure='Reviewer authored frozen input-only corpus and current inherited driver intake/cold/once orchestration plus a separate old qualification harness; independently Source-reviewed ordering components and Root launcher. Root alone executed actuals and authored admission. This is distinct saved-data scrutiny, not independent own-Source certification. Genuine Library/Control Source reviews and separate resource/display reviews remain separate.',
 limitations=limitations))
handoff=emit('handoff-v1.json',dict(schema='first-order-suite-retained-data-peer-handoff-v1',review=review,audit=ref(OUT/'audit-v1.json'),final_saved_header_joins=observations,
 data_review_passed=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,status_counts=counts))
print(json.dumps(dict(review=review,handoff=handoff,final_checks=len(checks),total_checks=core['check_count']+len(checks),status_counts=counts),sort_keys=True))
