"""Independent stdlib-only retained-data inspection; no scientific/project evaluation."""
import collections
import gc
import hashlib
import json
from pathlib import Path
OUT=Path(__file__).parent
REPO=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
INDEX=Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1/authorized-index-v1.json')
LEDGER=REPO/'.gcts-active/first-order-suite-progress-20261018'
checks=[];pins={};arms=[];common={};projection_paths={}
def check(ok,label):
    checks.append({'check':label,'passed':bool(ok)})
    if not ok:raise ValueError(label)

def raw(p):
    p=Path(p)
    if p.stat().st_flags&0x40000000:raise ValueError('no dataless read: '+str(p))
    return p.read_bytes()

def pin(p):
    p=Path(p);info=p.stat()
    if info.st_flags&0x40000000:raise ValueError('no dataless hash: '+str(p))
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        while True:
            b=f.read(1048576)
            if not b:break
            n+=len(b);h.update(b)
    d=dict(path=str(p),sha256=h.hexdigest(),bytes=n);pins[str(p)]=d;return d

def load(p):return json.loads(raw(p))
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(x):return hashlib.sha256(canonical(x)).hexdigest()
def verified(d):
    actual=pins.get(d['path']) or pin(d['path'])
    check(actual=={k:d[k] for k in ('path','sha256','bytes')},'whole raw pin '+d['path'])

def emit(name,x):
    q=OUT/name
    if q.exists():raise ValueError('preserve frozen peer')
    q.write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(q)

def project(x):
    return dict(compiler={k:v for k,v in x['outputs']['compile'].items() if k!='seconds'},
        inventory={k:x['outputs']['register'][k] for k in ('definitions','interfaces','native_blocks')},
        model={k:v for k,v in x['outputs']['model'].items() if k!='compile_seconds'},
        initial=x['initial_state'],spec=x['declaration'],policy=x['policy'])

def complete_rows(keys,model,candidates):
    by={}
    for key in set(map(tuple,keys)):
        p=candidates[key];row,role=key[:2]
        if role in by.setdefault(row,{}):raise ValueError('duplicate selected row role')
        by[row][role]=p
    result=[]
    defs={d['name']:d for d in model['_inventory']['definitions']}
    for row,roles in sorted(by.items()):
        if set(roles)!=set(range(model['arity']+2)):continue
        command=roles[0]['command'];guard=roles[1]
        if command!=guard['command']:raise ValueError('C/G command mismatch')
        if command['rule']=='block':
            definition=defs[command['name']]['definition'];req=[]
            for port in range(model['arity']):
                packet=roles[2+port]
                if packet['mode']!=model['mode_ids'][command['name']]:raise ValueError('block mode mismatch')
                if port<len(definition['premises']):req.append([packet['source'],definition['premises'][port]])
                elif packet['source'] is not None:raise ValueError('block filler source')
        else:req=guard['requirements']
        result.append(dict(row=row,formula=command['formula'],requirements=req,
            role_keys=[roles[r]['key'] for r in range(model['arity']+2)],command=command))
    return result

def justified(rows):
    indexed={}
    for row in rows:
        i=row['row']
        if type(i)is not int or i<0:raise ValueError('saved row index')
        if i in indexed and any(indexed[i][k]!=row[k] for k in ('formula','requirements')):raise ValueError('saved conflicting row packet')
        indexed[i]=row
    facts={};trace=[]
    for i,row in sorted(indexed.items()):
        missing=[]
        for pos,(source,wanted) in enumerate(row['requirements']):
            if type(source)is not int or not 0<=source<i:raise ValueError('saved strict prior receptor')
            if source not in facts or facts[source]!=wanted:missing.append(pos)
        if not missing:facts[i]=row['formula']
        trace.append(dict(row=i,justified=not missing,missing_requirement_positions=missing))
    return facts,trace

def check_cost_vector(vector,seed_ids,g):
    formulas=g['graph_preimage']['formulas'];edges=g['graph_preimage']['edges']
    if [r['formula_id'] for r in vector]!=list(range(len(formulas))):raise ValueError('full cost vector')
    costs=[r['cost'] for r in vector]
    for i,r in enumerate(vector):
        cost,origin=r['cost'],r['origin']
        if cost is None:
            if origin is not None:raise ValueError('null cost with source')
        elif type(cost)is not int or cost<0:raise ValueError('exact nonnegative cost')
        elif cost==0:
            if i not in seed_ids or origin!={'kind':'CURRENT_JUSTIFIED_FACT'}:raise ValueError('zero without actual seed')
        else:
            e=edges[origin['edge_id']]
            ps=[costs[p] for p in e['ordered_premises']]
            if origin['kind']!='HYPEREDGE' or not e['active_in_root_formula_grammar'] or e['conclusion']!=i or any(v is None for v in ps) or cost!=1+sum(ps) or any(v>=cost for v in ps):raise ValueError('positive cost origin arithmetic / acyclicity')
    if {i for i,v in enumerate(costs) if v==0}!=set(seed_ids):raise ValueError('complete seed zero-cost set')
    # Check recorded fixed-point inequalities, not recompute/execute relaxation.
    for e in edges:
        ps=[costs[p] for p in e['ordered_premises']]
        if e['active_in_root_formula_grammar'] and all(v is not None for v in ps):
            c=costs[e['conclusion']]
            if c is None or c>1+sum(ps):raise ValueError('incoherent complete recorded potential')
    return costs

def audit_ranking(r,g,label):
    if r['graph_sha256']!=g['graph_sha256'] or r['candidate_pruning'] or r['logical_authority'] or not r['complete_option_multiplicity']:raise ValueError('ranking authority/version')
    n=len(r['options']);check(type(r['order'])is list and all(type(i)is int for i in r['order']) and sorted(r['order'])==list(range(n)),label+' all option indices/multiplicity')
    words={canonical(f['formula']):f['formula_id'] for f in g['graph_preimage']['formulas']}
    facts,trace=justified(r['known_rows']);seeds=sorted({words[canonical(f)] for f in facts.values() if canonical(f) in words})
    check(trace==r['base_justification'] and seeds==r['base_seed_formula_ids'],label+' complete recursively justified seed/trace literal joins')
    if r['status']!='SCORED':
        check(r['order']==list(range(n)),label+' inoperative partial scoring/identity fallback')
        return dict(status=r['status'],options=n,known_rows=len(r['known_rows']))
    base=check_cost_vector(r['base_costs'],seeds,g);target=g['target_formula_id'];by={p['option_index']:p for p in r['option_scores']}
    if set(by)!=set(range(n)):raise ValueError('every option score reference')
    scores=[]
    for i,o in enumerate(r['options']):
        f,t=justified(r['known_rows']+o['rows']);ids=sorted({words[canonical(v)] for v in f.values() if canonical(v) in words})
        row=by[i];d=r['distinct_output_scores'][row['score_id']]
        if t!=row['projected_justification'] or d['seed_formula_ids']!=ids or d['added_formula_ids']!=[v for v in ids if v not in seeds]:raise ValueError('option full justification / added seed list')
        costs=check_cost_vector(d['costs'],ids,g)
        before,after=d['target_cost_before'],d['target_cost_after']
        if before!=base[target] or after!=costs[target] or d['marginal_reduction']!=(before-after if before is not None and after is not None else None) or d['makes_target_potential_finite']!=(before is None and after is not None):raise ValueError('saved target cost arithmetic')
        scores.append(after)
    check(r['order']==sorted(range(n),key=lambda i:(scores[i] is None,scores[i] or 0,i)),label+' saved scalar costs explain stable ordering')
    check(True,label+' all positive origins/strict cost decrease/no circular zero support')
    return dict(status=r['status'],options=n,known_rows=len(r['known_rows']),seed_ids=seeds,base_target_cost=base[target],first_option_after_cost=scores[r['order'][0]] if n else None,changed_order=r['order']!=list(range(n)),work=r['counts']['work'])

def audit_graph(g,x):
    p=g['graph_preimage'];co=x['outputs']['compile'];inv=x['outputs']['register'];basis={canonical(f) for f in co['basis']}
    check(g['status']=='COMPLETE' and digest(p)==g['graph_sha256'] and p['input_projection']==dict(spec=x['declaration'],compiled={k:v for k,v in co.items() if k!='seconds'},inventory={k:inv[k] for k in ('status','definitions','interfaces','native_blocks')}),'support graph whole current compiler/spec/inventory preimages')
    fs=p['formulas'];words={canonical(f['formula']):f['formula_id'] for f in fs}
    check(len(words)==len(fs) and all(f['formula_id']==i and f['literal_preimage']==canonical(f['formula']).decode() and f['in_root_basis']==(canonical(f['formula']) in basis) for i,f in enumerate(fs)),'full graph formula literal words and IDs')
    check(g['target_formula']==x['declaration']['target'] and g['target_formula_id']==words[canonical(x['declaration']['target'])],'literal support target')
    block_modes=[];zero_licences=[]
    for i,e in enumerate(p['edges']):
        if e['edge_id']!=i or e['positive_row_cost']!=1:raise ValueError('full positive ordered hyperedges')
        output=fs[e['conclusion']]['formula'];premises=[fs[j]['formula'] for j in e['ordered_premises']];pro=e['provenance'];rule=e['rule']
        if rule=='axiom':assert output==x['declaration']['theory']['axioms'][pro['name']] and not premises
        elif rule=='tautology':assert output==co['tautologies'][pro['admitted_tautology_index']] and not premises
        elif rule in ('instantiate','eq_subst'):
            c=co['admitted_schemes'][pro['admitted_scheme_index']]
            assert c==pro['exact_command'] and c['formula']==output and not premises and pro['zero_read_licence_only'] is True
            zero_licences.append(dict(rule=rule,output=output,ordered_premises=premises))
        elif rule=='mp':assert output==fs[e['ordered_premises'][1]]['formula'][2] and premises[1][0]=='imp' and premises[1][1]==premises[0]
        elif rule=='generalize':assert output[0]=='all' and premises==[output[2]]
        elif rule=='refl':assert output[0]=='eq' and output[1]==output[2] and not premises
        elif rule=='block':
            mode=pro['interface_mode'];name=inv['interfaces'][mode-1];d=next(d for d in inv['definitions'] if d['name']==name)
            assert pro['exact_definition_record']==d and output==d['definition']['conclusion'] and premises==d['definition']['premises'];block_modes.append(mode)
        else:raise ValueError('unknown saved support edge')
    check(sorted(block_modes)==list(range(1,len(inv['interfaces'])+1)), 'every exported interface represented once, no filtering')
    check(True,'all saved graph edge provenance/literal zero-read licences/joint ordered premises joined')
    return dict(graph_sha256=g['graph_sha256'],formulas=len(fs),edges=len(p['edges']),zero_read_licences=zero_licences)

def region(x,w,candidates):
    model=x['outputs']['model'];initial=x['initial_state'];s=x['outputs']['search'];proof=s['proof'];required=set(map(tuple,model['roots']))
    totals={tuple(p):v for p,v in initial['totals']};marks={tuple(p):v for p,v in initial['marks']};selected=list(map(tuple,s['placements']))
    check(len(required)==len(model['roots']) and required==set(map(tuple,initial['allowed_points'])) and len(totals)==len(initial['totals']) and len(marks)==len(initial['marks']),'whole literal required roots/initial point domains')
    check(len(selected)==len(set(selected)) and all(k in candidates for k in selected),'all selected original unique full keys')
    for k in selected:
        p=candidates[k]
        for q,v in p['occupancy']:
            q=tuple(q)
            if q not in required or type(v)is not int or v<=0:raise ValueError('exact occupancy')
            totals[q]=totals.get(q,0)+v
            if totals[q]>12:raise ValueError('overcapacity')
        for q,v in p['marks']:
            q=tuple(q)
            if type(v)is not int or q in marks and marks[q]!=v:raise ValueError('assigned marking disagreement')
            marks[q]=v
    check(set(totals)==required and all(v==12 for v in totals.values()),'entire selected finite region exact12 occupancy')
    enriched=dict(model,_inventory=x['outputs']['register'])
    rows=complete_rows(selected,enriched,candidates)
    check([r['row'] for r in rows]==list(range(len(proof))) and len(selected)==len(proof)*(model['arity']+2),'complete all-row/all-role selected rectangle')
    decoded=[]
    for r in rows:
        command=dict(r['command'])
        if command['rule']=='block':command['inputs']=[i for i,_ in r['requirements']]
        if any(not 0<=i<r['row'] or proof[i]['formula']!=f for i,f in r['requirements']):raise ValueError('selected ordered prior port formula')
        decoded.append(command)
    check(decoded==proof==x['outputs']['final_request']['proof'],'all C/G/input rows decode literal final Native word')
    union=dict(totals=sorted(totals.items()),marks=sorted(marks.items()),selected=sorted(selected))
    check(digest(union)==w['final_region_verification']['union_sha256'] and len(marks)==w['final_region_verification']['assigned_mark_points'],'independent whole raw union matches worker receipt')
    return dict(required_points=len(required),selected_placements=len(selected),decoded_rows=len(rows),mark_points=len(marks),explicit_zero_marks=sum(v==0 for v in marks.values()),union_sha256=digest(union),proof=proof)

def ancestry(x):
    proof=x['outputs']['search']['proof'];inventory=x['outputs']['register'];defs={d['name']:d for d in inventory['definitions']};cache={}
    def scope(lines):
        used=set();assumptions=set();counts=collections.Counter()
        def refs(command):
            if command['rule']=='mp':return [command['antecedent'],command['implication']]
            if command['rule']=='generalize':return [command['source']]
            if command['rule']=='block':return [command['inputs'][i] for i in definition(command['name'])['assumptions']]
            return []
        def visit(i):
            if i in used:return
            if type(i)is not int or not 0<=i<len(lines):raise ValueError('saved proof index')
            used.add(i);c=lines[i]
            if c['rule']=='assumption':assumptions.add(c['index'])
            elif c['rule']=='block':counts.update(definition(c['name'])['counts'])
            else:counts[c['rule']]+=1
            for j in refs(c):
                if not 0<=j<i:raise ValueError('saved proof not strictly prior DAG')
                visit(j)
        visit(len(lines)-1)
        return dict(rows=sorted(used),assumptions=sorted(assumptions),counts=dict(counts),references=[dict(row=i,references=refs(lines[i]),all_declared_references=(lines[i].get('inputs') or refs(lines[i]))) for i in sorted(used)])
    def definition(name):
        if name not in cache:cache[name]=scope(defs[name]['definition']['proof'])
        return cache[name]
    result=scope(proof);saved=x['outputs']['essential_ancestry'];root=saved['root']
    check(result['rows']==root['essential_rows'] and result['references']==root['essential_ordered_references'] and result['counts']==root['essential_recursive_primitive_rule_counts'],'independent saved strict-prior essential ancestry and primitive occurrence arithmetic')
    check(sum(result['counts'].values())==root['essential_recursive_primitive_commands'] and saved['essential_generalize_count']==result['counts'].get('generalize',0) and saved['essential_instantiate_count']==result['counts'].get('instantiate',0),'actual essential UI/GEN counts, excluding padding')
    calls=saved['essential_calls'];expected=[i for i in result['rows'] if proof[i]['rule']=='block']
    check([c['root_row'] for c in calls]==expected and all(len(c['path'])==1 for c in calls),'all actual essential calls are exact root-level instances')
    for c in calls:
        i=c['root_row'];d=defs[c['name']];family=next(f for f in x['policy']['library'] if f['id']==c['family'])
        assert proof[i]['name']==d['name']==c['name'] and proof[i]['inputs']==c['inputs'] and c['arguments']==d['arguments'] and c['family']==d['family'] and c['level']==d['level']
        assert c['nonidentity']==(c['arguments']!=[['pred',n,[]] for n in family['donor_atoms']]) and c['essential_input_indices']==definition(c['name'])['assumptions']
    check(True,'each essential ground family/name/arguments/ordered ports/nonidentity joined')
    return dict(essential_rows=result['rows'],padding_rows=[i for i in range(len(proof)) if i not in result['rows']],essential_rule_counts=result['counts'],essential_calls=[{k:c[k] for k in ('root_row','name','family','inputs','arguments','nonidentity','compound_argument_indices')} for c in calls])

def telemetry_audit(x,candidates):
    s=x['outputs']['search'];model=dict(x['outputs']['model'],_inventory=x['outputs']['register']);inv=x['outputs']['register']
    if x['search_ordering']=='legacy':
        check((s['support_ordering'] is None) if x['mode']=='symbolic' else (s['support_ordering']=='legacy' and s['support_ordering_metadata']['graph'] is None),'legacy support graph absent/disabled')
        return dict(disabled=True)
    shared=s['support_ordering'] if x['mode']=='symbolic' else s['support_ordering_metadata']
    g=shared['graph'];gs=audit_graph(g,x);rows=[]
    if x['mode']=='symbolic':
        calls=shared['ranking_calls'];chosen=s['candidate_rows'];proof=s['proof'];prefetched=0
        for i,call in enumerate(calls):
            r=call['ranking'];check(call['complete_window'] is True and r is not None and call['row']==i,'symbolic complete retained ranking window '+str(i))
            for cand in call['candidates']:
                row,k,v,mode=cand['row'],cand['skeleton_index'],cand['guard_variant'],cand['mode'];command=dict(cand['command']);ports=command.pop('inputs',[])
                assert candidates[(row,0,k,0)]['command']==command and candidates[(row,1,k,v)]['command']==command
                for p,source in enumerate(ports):assert (row,2+p,mode,source+1) in candidates and 0<=source<row
            check(len(r['options'])==len(call['candidates']) and chosen[i]==call['candidates'][r['order'][0]],'symbolic selected candidate and all prefetched options '+str(i))
            check([p['provenance']['chosen_candidate']['command'] for p in r['known_rows']]==proof[:i],'symbolic full prefix seed provenance '+str(i))
            for j,o in enumerate(r['options']):assert o['rows'][0]['provenance']['candidate']==call['candidates'][j] and o['rows'][0]['formula']==call['candidates'][j]['command']['formula']
            rows.append(audit_ranking(r,g,'symbolic row '+str(i)));prefetched+=len(call['candidates'])
        check(prefetched==shared['metrics']['prefetched_candidates'] and len(calls)==shared['metrics']['complete_windows'] and all(r['status']=='SCORED' for r in rows),'all symbolic ranking/prefetch counters and no returned partial ranking')
    else:
        for event in s['events']:
            receipt=event['support_ordering'];r=receipt['ranking'];items=event['items'];before=sorted(range(len(items)),key=lambda i:(-event['scores'][i],i))
            check(receipt['legacy_order']==before and receipt['legacy_index']==before[0] and receipt['selected_index']==event['index'] and receipt['after_order']==[before[i] for i in r['order']],'point full old/new item-order provenance '+str(event['id']))
            current=complete_rows(event['chosen'],model,candidates)
            check([{k:p[k] for k in ('row','formula','requirements')} for p in r['known_rows']]==[{k:p[k] for k in ('row','formula','requirements')} for p in current],'point complete selected rows, not guard-only facts '+str(event['id']))
            ids={p['row'] for p in current}
            for j,o in enumerate(r['options']):
                item=items[before[j]];union=event['chosen']+(item['members'] if item else [])
                expected=[p for p in complete_rows(union,model,candidates) if p['row'] not in ids] if item else []
                assert o['option_id']['original_item_index']==before[j]
                assert [{k:p[k] for k in ('row','formula','requirements')} for p in o['rows']]==[{k:p[k] for k in ('row','formula','requirements')} for p in expected]
                for p in o['rows']:assert p['provenance']['role_keys']==next(v['role_keys'] for v in expected if v['row']==p['row'])
            for a in receipt['validated_aggregates']:
                item=items[a['original_index']];assert a['aggregate']=={k:item[k] for k in ('members','pending','aggregate_sha256','new_occupancy','new_marks')}
            rows.append(dict(event_id=event['id'],legacy_index=receipt['legacy_index'],selected_index=receipt['selected_index'],**audit_ranking(r,g,'point event '+str(event['id']))))
        check(sum(r['legacy_index']!=r['selected_index'] for r in rows)==s['metrics']['support_changed_hint_choices'] and len(rows)==s['metrics']['support_order_calls'],'point changed actual hint choices and complete receipt count')
    return dict(graph=gs,ranking_calls=rows,changed_rankings=sum(r['changed_order'] for r in rows),interrupted_returned_rankings=0,scope='Saved literal row/provenance/seed/positive-cost-origin arithmetic checked; no helper relaxation or search was rerun.')

def tree_summary(s):
    todo=[s['tree']];counts=collections.Counter();edges=0;cutoffs=[]
    while todo:
        n=todo.pop();counts[n['kind']]+=1;edges+=len(n['children'])
        if 'cutoff'in n:cutoffs.append(n['cutoff'])
        todo.extend(c['tree'] for c in n['children'])
    check(sum(counts.values())==s['metrics']['nodes'] and edges==s['metrics']['attempts'],'full recorded point tree node/placement counters')
    return dict(nodes=dict(counts),edges=edges,cutoffs=cutoffs)


def expanded_trace(x):
    """Literal substitution of saved body-reference indices, not logical checking."""
    proof=x['outputs']['search']['proof'];inv=x['outputs']['register'];co=x['outputs']['compile']
    defs={d['name']:d['definition'] for d in inv['definitions']};flat=[];active=[]
    def scope(lines,inputs,path):
        local={}
        for i,c in enumerate(lines):
            rule=c['rule'];where=path+[dict(row=i,rule=rule)]
            if rule=='assumption':
                j=inputs[c['index']]
                if flat[j]['command']['formula']!=c['formula']:raise ValueError('literal expanded assumption formula')
                local[i]=j;continue
            if rule=='block':
                if c['name'] in active:raise ValueError('cyclic saved block dependency')
                d=defs[c['name']]
                if len(c['inputs'])!=len(d['premises']):raise ValueError('full ordered body arity')
                refs=[]
                for p,k in enumerate(c['inputs']):
                    if type(k)is not int or not 0<=k<i:raise ValueError('full saved body strict prior')
                    j=local[k]
                    if flat[j]['command']['formula']!=d['premises'][p]:raise ValueError('expanded full body port formula')
                    refs.append(j)
                active.append(c['name']);j=scope(d['proof'],refs,where+[dict(name=c['name'])]);active.pop()
                if flat[j]['command']['formula']!=c['formula'] or c['formula']!=d['conclusion']:raise ValueError('expanded actual body output')
                local[i]=j;continue
            command=dict(c)
            if rule=='mp':
                a,b=c['antecedent'],c['implication']
                if not (type(a)is int and type(b)is int and 0<=a<i and 0<=b<i):raise ValueError('expanded saved MP ordering')
                command.update(antecedent=local[a],implication=local[b])
                fa=flat[local[a]]['command']['formula'];fi=flat[local[b]]['command']['formula']
                if fi!=['imp',fa,c['formula']]:raise ValueError('expanded saved MP literal formula')
            elif rule=='generalize':
                k=c['source']
                if type(k)is not int or not 0<=k<i or c['formula']!=['all',c['variable'],flat[local[k]]['command']['formula']]:raise ValueError('expanded saved GEN body')
                command['source']=local[k]
            elif rule=='axiom':
                if x['declaration']['theory']['axioms'][c['name']]!=c['formula']:raise ValueError('expanded exact axiom')
            elif rule=='tautology':
                if c['formula'] not in co['tautologies']:raise ValueError('expanded admitted tautology')
            elif rule in ('instantiate','eq_subst'):
                if c not in co['admitted_schemes']:raise ValueError('expanded full admitted licence command')
            elif rule=='refl':
                if c['formula'][0]!='eq' or c['formula'][1]!=c['formula'][2]:raise ValueError('expanded reflexivity endpoints')
            else:raise ValueError('unexpected saved primitive '+rule)
            local[i]=len(flat);flat.append(dict(index=len(flat),origin_path=where,command=command))
        return local[len(lines)-1]
    target=scope(proof,[],[]);used=set()
    def visit(i):
        if i in used:return
        used.add(i);c=flat[i]['command']
        if c['rule']=='mp':visit(c['antecedent']);visit(c['implication'])
        elif c['rule']=='generalize':visit(c['source'])
    visit(target)
    for r in flat:r['essential_to_target']=r['index'] in used
    depths=[]
    for r in flat:
        c=r['command'];refs=[]
        if c['rule']=='mp':refs=[c['antecedent'],c['implication']]
        elif c['rule']=='generalize':refs=[c['source']]
        depths.append(1+max([depths[j] for j in refs],default=0));r['dependency_depth']=depths[-1]
    check(flat[target]['command']['formula']==x['declaration']['target'],'full primitive expansion literal final target')
    check(len(used)==x['outputs']['essential_ancestry']['root']['essential_recursive_primitive_commands'],
          'full expanded strict-prior target trace count matches recursive essential receipt')
    return dict(primitive_trace=flat,final_expanded_row=target,essential_expanded_rows=sorted(used),
                essential_rule_counts=dict(collections.Counter(flat[i]['command']['rule'] for i in used)),
                essential_target_dependency_depth=depths[target],
                scope='Saved formulas, exact admitted commands, actual body ports and reference-index substitution only; no Native/kernel side-condition replay.')


def winning_path(x,candidates):
    s=x['outputs']['search'];links=x['outputs']['winning_hint_links']['links']
    if x['mode']=='symbolic':
        check(not links and x['outputs']['winning_hint_links']['status']=='NOT_APPLICABLE_NO_GCTS_TREE',
              'symbolic no fabricated GCTS winning hint')
        return dict(status='NOT_APPLICABLE_NO_GCTS_TREE')
    keys=s['placements'];node=s['tree'];path=[]
    for key in keys:
        children=[c for c in node['children'] if c['key']==key]
        if len(children)!=1:raise ValueError('full winning path selected child')
        path.append(node);node=children[0]['tree']
    check(node['kind']=='empty' and len(path)==len(keys),'full selected point word to actual empty winning leaf')
    selected=set(map(tuple,keys));calls={c['root_row']:c for c in x['outputs']['essential_ancestry']['essential_calls']}
    joined=[]
    for link in links:
        call=calls[link['row']];n=path[link['path_depth']];hint=s['hints'][link['hint_id']]
        if not (link['name']==call['name'] and link['arguments']==call['arguments'] and link['family']==call['family'] and
                s['proof'][link['row']]['inputs']==call['inputs']):raise ValueError('winning hint exact essential same instance')
        if not (keys[link['path_depth']]==link['key'] and
                link['key'] in hint['item']['members'] and n['kind']==link['selection_kind'] and
                n.get('hint_start',n.get('hint_in'))==hint['id']):raise ValueError('winning hint actual full members/path')
        census=next(c for c in n['census'] if c['point']==n['point'])
        if sorted(census['keys'])!=link['original_order'] or n['alternatives']!=link['preferred_order']:raise ValueError('actual link census/alternatives')
        starts=[(d,n0) for d,n0 in enumerate(path) if n0.get('hint_start')==hint['id']]
        if len(starts)!=1:raise ValueError('unique essential hint start on actual path')
        depth,start=starts[0];event=s['events'][start['policy_event']]
        if event['items'][event['index']]!=hint['item'] or event['chosen']!=keys[:depth] or hint['chosen']!=keys[:depth]:raise ValueError('whole current policy event/hint/prefix')
        full=all(tuple(k) in selected for k in hint['item']['members'])
        ports=[candidates[tuple(k)]['source'] for k in sorted(hint['item']['members'])
               if k[0]==link['row'] and k[1]>=2 and candidates[tuple(k)]['kind']=='lemma_input']
        guards=[candidates[tuple(k)] for k in hint['item']['members'] if k[0]==link['row'] and k[1]==1]
        if len(guards)!=1 or guards[0]['command']['name']!=call['name'] or guards[0]['command']['formula']!=s['proof'][link['row']]['formula']:raise ValueError('same exact hinted block guard/formula')
        exact=ports==s['proof'][link['row']]['inputs']
        if link['changed_original_order']!=(link['original_order']!=link['preferred_order']) or link['exact_ordered_input_sources']!=exact or link['full_hint_members_on_winning_path']!=full:raise ValueError('actual saved hint flag')
        support=event.get('support_ordering')
        joined.append(dict(row=link['row'],hint_id=hint['id'],policy_event=event['id'],name=call['name'],
          arguments=call['arguments'],inputs=call['inputs'],changed_incident_order=link['changed_original_order'],
          full_hint_members_on_winning_path=full,exact_ordered_input_sources=exact,
          strong_nonidentity_same_instance=call['nonidentity'] and full and exact,
          support_changed_hint_choice=(support['selected_index']!=support['legacy_index']) if support else None))
    check(True,'all essential winning same-instance hint/ports/full members/current event/census literal joins')
    good=[j for j in joined if j['strong_nonidentity_same_instance']]
    check(x['outputs']['winning_hint_links']['strong_family_hint_use']==bool(good) and
          x['outputs']['winning_hint_links']['changed_order_family_hint_use']==any(j['changed_incident_order'] for j in good),
          'strong hint flags require actual full members/exact ports; partial links retained honestly')
    return dict(links=joined,link_count=len(joined),changed_incident_links=sum(j['changed_incident_order'] for j in joined),
      strong_link_count=len(good),partial_link_count=len(joined)-len(good),
      support_changed_hint_links=sum(bool(j['support_changed_hint_choice']) for j in joined),
      strong_family_hint_use=x['outputs']['winning_hint_links']['strong_family_hint_use'],
      inherited_quantifier_specific_family_hint_success=x['family_hint_success'])


idx=load(INDEX);closure_path=LEDGER/'ROOT-cohort-closure-v1.json';closed=load(closure_path)
check(pin(INDEX)['sha256']=='8892cb887508d87f0b6d7cf0091975f9654a70ecf60872437688ae76207544d0','exact final40 authorized index')
check(len(idx['schedule'])==len(closed['actuals'])==40 and
      [r['invocation_id'] for r in idx['schedule']]==[r['invocation_id'] for r in closed['actuals']] and
      closed['retained_actuals']==40 and closed['all_workers_and_native_groups_closed'] is True,
      'complete original40 closed order and denominator')
verified(closed['authorized_index']);verified(idx['input_capsule']);verified(idx['runtime_closure'])
capsule=load(idx['input_capsule']['path']);specs={s['id']:s for s in capsule['receivers']}
check(len(specs)==10 and len(capsule['groups'])==10,'ten original inputs andgroup labels retained')
for row,end in zip(idx['schedule'],closed['actuals']):
    check(row['order']==end['order'] and end['invocation_id']==row['invocation_id'],'exact current slot order')
    for d in (row['worker_plan'],row['runner_plan'],row['authorization'],end['worker_receipt'],end['runner_receipt'],end['terminal']):verified(d)
    actual=Path(row['actual_directory']);worker=load(end['worker_receipt']['path']);runner=load(end['runner_receipt']['path']);terminal=load(end['terminal']['path'])
    marker=load(actual/'CONSUMED.json');pin(actual/'CONSUMED.json')
    wp=load(row['worker_plan']['path']);rp=load(row['runner_plan']['path']);auth=load(row['authorization']['path'])
    for packet in (marker,worker,runner):
        check(all(packet[k]==row[k] for k in ('invocation_id','mode','search_ordering','model_storage')),'complete endpoint method/order join '+row['invocation_id'])
    check(auth['actual_execution_authorized'] is True and type(auth['maximum_actual_invocations']) is int and auth['maximum_actual_invocations']==1 and
          auth['subject_sha256']==row['subject_sha256']==digest({k:v for k,v in rp.items() if k!='authorization'}),'exact max1 whole once subject')
    check(terminal['terminal_gate_passed'] is True and runner['resource_candidate_accepted'] is True and runner['python_reaped'] is True and runner['python_exit_code']==0 and
      runner['owned_group_absent'] is True and runner['owned_group_reappearance_observed_ns'] is None and runner['stdout_eof'] is True and runner['stderr_eof'] is True and
      runner['log_capture_complete'] is True and terminal['runner_receipt']==end['runner_receipt'],'closed terminal/group/EOF/resource header joins')
    verified(worker['result']);verified(runner['outputs']['result']);check(worker['result']==runner['outputs']['result'],'same full saved result endpoint')
    x=load(worker['result']['path']);outputs=x['outputs'];co=outputs['compile'];inv=outputs['register'];s=outputs.get('search')
    label=row['invocation_id'];case=row['receiver_id']
    check(x['receiver_id']==worker['receiver_id']==runner['receiver_id']==case and x['declaration']==specs[case] and
          x['receiver_selection']['spec']==specs[case] and x['source_epoch']['receiver_selection']==x['receiver_selection'],'whole original selected receiver/spec/epoch join '+label)
    check(x['mode']==row['mode'] and x['search_ordering']==row['search_ordering']==x['source_epoch']['search_ordering'] and
          worker['source_epoch_sha256']==digest(x['source_epoch']) and worker['receiver_selection_sha256']==digest(x['receiver_selection']),'current whole epoch/mode/hash join '+label)
    original={**wp['project_sources'],'semantic_receiver_driver':wp['components']['receiver_driver'],'bounded_request_oracle':wp['components']['bounded_transport']}
    check(len(original)==24 and x['source_epoch']['sources']['original']==original,'complete current24 Source originals '+label)
    if 'sources' not in common:common['sources']=original
    check(original==common['sources'],'identical complete24 operative scientific acquisition '+label)
    for alias,d in original.items():
        verified(d);owned=x['source_epoch']['sources']['project'][alias];verified(owned)
        check(owned['sha256']==d['sha256'] and owned['bytes']==d['bytes'],'whole actual owned Source identical '+alias)
    for d in x['source_epoch']['native_inputs'].values():verified(d)
    role_aliases=dict(base_compiler='quantified_receptors_v1',family_miner='semantic_lemma_inventory',family_model='interned_quantified_family_points_v1',
      family_registry='semantic_inventory_oracle',family_search='semantic_inventory_search_v2',point_smt='semantic_point_smt',
      symbolic_control='quantified_symbolic_control_v2',support_ordering='receptor_support_ordering_v1')
    check(all(x['module_pins'][role]==x['source_epoch']['sources']['project'][alias] for role,alias in role_aliases.items()),'all actual selected helper/model/search module pins '+label)
    check(x['source_epoch']['declaration']==wp['declaration']==idx['input_capsule'] and
          worker['selected_family_model']['owned']==x['module_pins']['family_model'] and worker['selected_family_model']['original']==original['interned_quantified_family_points_v1'] and worker['support_ordering_module']['owned']==x['module_pins']['support_ordering'] and worker['support_ordering_module']['original']==original['receptor_support_ordering_v1'],
          'inputcapsule/owned compactmodel/helper binding '+label)
    inverse=worker['result_reading']['roundtrip'];whole=raw(worker['result']['path']);body=whole[:-1] if whole.endswith(b'\n') else whole
    check(inverse['literal_bytes_equal'] is True and inverse['body_bytes']==len(body) and inverse['body_sha256']==hashlib.sha256(body).hexdigest(),
          'retained full inverse body SHA/length '+label);del whole,body
    projections=dict(compiler={k:v for k,v in co.items() if k!='seconds'},inventory={k:inv[k] for k in ('definitions','interfaces','native_blocks')},
                     spec=x['declaration'],policy=x['policy'])
    if 'model' in outputs:
        projections.update(model={k:v for k,v in outputs['model'].items() if k!='compile_seconds'},initial=x['initial_state'])
    casepaths=projection_paths.setdefault(case,{})
    for field,value in projections.items():
        by=canonical(value)
        if field not in casepaths:
            q=OUT/(case+'-complete-'+field+'-canonical.json');q.write_bytes(by);casepaths[field]=pin(q)
        check(by==raw(casepaths[field]['path']),'complete within-case literal '+field+' '+label)
        del by
    del projections
    records=x['records'];check([r['id'] for r in records]==list(range(len(records))),'full sequential native request records '+label)
    for record in records:
        check(record['request_sha256']==digest(record['request']) and record['request']['theory']==x['declaration']['theory'],'literal native request/theory/preimage '+label+':'+str(record['id']))
    expected=[(dict(rule='tautology',formula=['imp',['bot'],['bot']]),'first_order_theory_admission')]+[(dict(rule='tautology',formula=f),'first_order_tautology') for f in co['catalog']['basis']]+[(c,'first_order_scheme') for c in co['catalog']['schemes']]
    check(len(co['queries'])==len(expected),'complete compiler queryprefix '+label)
    for rid,(command,purpose) in zip(co['queries'],expected):
        request=dict(protocol='gcts-fol-1',theory=x['declaration']['theory'],blocks=[],proof=[command],target=command['formula'])
        check(records[rid]['purpose']==purpose and records[rid]['request']==request,'exact compiler Native request '+label+':'+str(rid))
    reg_request=dict(protocol='gcts-fol-1',theory=x['declaration']['theory'],blocks=inv['native_blocks'],proof=[dict(rule='tautology',formula=['imp',['bot'],['bot']])],target=['imp',['bot'],['bot']])
    check(records[inv['query']]['request']==reg_request,'complete generated inventory request '+label)
    last=records[-1]
    check(pin(actual/'native/input.bin')['sha256']==last['input_sha256'] and pin(actual/'native/output.bin')['sha256']==last['output_sha256'],
          'retained LAST Native binary SHA only/no decode '+label)
    data=dict(invocation_id=label,receiver_id=case,mode=row['mode'],search_ordering=row['search_ordering'],result=worker['result'],
      worker_receipt=end['worker_receipt'],runner_receipt=end['runner_receipt'],terminal=end['terminal'],status=x['status'],native_proof_accepted=x['native_proof_accepted'],
      quantified_reasoning_success=x['quantified_reasoning_success'],inherited_family_hint_success=x['family_hint_success'],records=len(records),
      compiler_basis=len(co['basis']),generated_definitions=len(inv['definitions']),exported_interfaces=len(inv['interfaces']),inventory_status=inv['status'],
      compiler_query_count=len(co['queries']),inventory_result_status=records[inv['query']]['result']['status'],available_outputs=sorted(outputs),
      complete_literal_projection_fields=sorted(casepaths),stage=x['stage'],resource_candidate=runner['resource_candidate_accepted'])
    if s is not None:
        model=outputs['model'];candidates={tuple(c['key']):c for c in model['placements']}
        check(len(candidates)==len(model['placements']),'complete unique full model candidate keys '+label)
        data.update(model_placements=len(candidates),model_arity=model['arity'],required_points=len(model['roots']),search_metrics=s['metrics'],search_status=s['status'])
        if x['mode']=='fixed':
            check(s['root_restored'] is True and x['root_restoration']['root_restored'] is True,'saved point root restored observation '+label)
            data['tree_summary']=tree_summary(s)
        else:
            grammar=s['grammar']
            check(grammar['spec']==x['declaration'] and grammar['compiler']=={k:v for k,v in co.items() if k!='seconds'} and
                  grammar['inventory']=={k:inv[k] for k in ('definitions','interfaces','native_blocks')} and grammar['mode_ids']==model['mode_ids'] and
                  grammar['interface_order']==inv['interfaces'] and len(grammar['rows'])==x['declaration']['length'] and digest(grammar)==s['grammar_sha256'],
                  'whole symbolic logical grammar/common model mode projection '+label)
            check(all(candidates[(i,0,k,0)]['command']==c for i,row_commands in enumerate(grammar['rows']) for k,c in enumerate(row_commands)) and
                  sum(len(v) for v in grammar['rows'])==sum(k[1]==0 for k in candidates),
                  'every full saved symbolic skeleton k matches complete model C domain '+label)
            data['symbolic_cutoff']=dict(complete_exhaustion=s['complete_exhaustion'],completed_candidate_before_budget_stop=s['completed_candidate_before_budget_stop'],
              interrupted_prefix=s['interrupted_prefix'],root_path_restored=s['root_path_restored'])
        if x['native_proof_accepted']:
            record=outputs['final_native'];request=outputs['final_request']
            check(record==records[record['id']] and record['request']==request and request['proof']==s['proof'] and request['target']==x['declaration']['target'] and
              record['result']['status']=='accepted' and s['proof'][-1]['formula']==request['target'],'positive whole final Native request/record/proof/target '+label)
            defs={d['name']:d['definition'] for d in inv['definitions']};used={c['name'] for c in s['proof'] if c['rule']=='block'}
            check(request['blocks']==[defs[n] for n in inv['interfaces'] if n in used],'exact full used block bodies/native request '+label)
            data['whole_region']=region(x,worker,candidates);data['essential_ancestry']=ancestry(x);data['full_primitive_expansion']=expanded_trace(x)
            data['support_telemetry']=telemetry_audit(x,candidates);data['winning_hint_joins']=winning_path(x,candidates)
            data['proof_lines']=[dict(human_line=i+1,command=c,essential=i in data['essential_ancestry']['essential_rows']) for i,c in enumerate(s['proof'])]
            if x['mode']=='symbolic':check(s['proof']==[c['command'] for c in s['candidate_rows']] and s['root_path_restored'] is True,'symbolic actual selected full candidate word '+label)
        else:
            check(s['proof'] is None and x['status']=='unknown_search_budget' and worker['final_region_verification']['status']=='NOT_CHECKED_NO_NATIVE_PROOF' and
                  'final_request' not in outputs and x['family_hint_success'] is False,'no invented proof/final native result on search UNKNOWN '+label)
            shared=s.get('support_ordering') if x['mode']=='symbolic' else s.get('support_ordering_metadata')
            if row['search_ordering']=='and_support' and shared:
                graph=shared.get('graph')
                data['search_cutoff_support_scope']=dict(graph_status=graph.get('status') if graph else None,
                  ranking_receipts=(len(shared.get('ranking_calls',[])) if x['mode']=='symbolic' else len(s.get('events',[]))),
                  scope='Full raw output retained; positive proof score-use audit is separate. Cutoff telemetry is not a completed search/exhaustion certificate.')
        del model,candidates
    else:
        check(x['status']=='unknown_native_inventory' and inv['status']=='unknown_native_inventory' and
              'model' not in outputs and 'initial_state' not in x and 'final_request' not in outputs and x['native_proof_accepted'] is False,
              'honest stopped native inventory stage/no invented Model or proof '+label)
        data['stage_limit']='Complete compiler and generated candidate inventory recorded; native inventory UNKNOWN. No Model/initial/search/target-proof admission.'
    arms.append(data)
    print(json.dumps(dict(done=len(arms),id=label,status=x['status'],records=len(records),positive=x['native_proof_accepted'])),flush=True)
    del x,outputs,co,inv,s,records,data,worker,runner,terminal;gc.collect()

counts=dict(collections.Counter(a['status'] for a in arms))
audit=emit('audit-v1.json',dict(schema='first-order-suite-retained-data-audit-v1',reviewer_identity='/root/receiver_driver_review',
  retained_data_only=True,source_only=False,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,
  check_count=len(checks),checks=checks,findings=[],index=pin(INDEX),cohort_closure=pin(closure_path),input_capsule=idx['input_capsule'],
  whole_raw_pins=list(pins.values()),complete_case_projection_preimages=projection_paths,actuals=arms,status_counts=counts,
  audit_scope='Complete saved JSON and exact finite integer sums/mark and reference joins only. No scientific module, logical kernel, native codec, Model or search execution.'))
summary=emit('audit-summary-v1.json',dict(schema='first-order-suite-peer-core-summary-v1',audit=audit,check_count=len(checks),actuals=len(arms),status_counts=counts,
  positive_actuals=[a['invocation_id'] for a in arms if a['native_proof_accepted']],scientific_calls=0,scientific_replays=0,scientific_acceptance=False))
print(json.dumps(dict(audit=audit,summary=summary,status_counts=counts,checks=len(checks)),sort_keys=True),flush=True)

