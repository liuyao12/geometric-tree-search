"""Raw metadata final-grant delta only. No scientific imports or execution."""
import collections,hashlib,json,pathlib
ROOT=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
P=pathlib.Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1')
OUT=pathlib.Path('/private/tmp/gcts-first-order-suite-final-grant-peer-20261018')
checks=[];pins={};cache={}
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def eq(x,y):return canon(x)==canon(y)
def ck(n,ok,d=None):checks.append({'name':n,'passed':bool(ok),'detail':d})
def desc(p):
 p=pathlib.Path(p);h=hashlib.sha256();n=0
 with p.open('rb')as f:
  while True:
   b=f.read(1048576)
   if not b:break
   n+=len(b);h.update(b)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':n}
def pin(n,d):
 k=(d['path'],d['sha256'],d['bytes'])
 if k not in cache:cache[k]=desc(d['path'])
 got=cache[k];pins[n]=got
 ck(n+'.whole_raw_descriptor',set(d)=={'path','sha256','bytes'} and eq(got,d) and pathlib.Path(d['path']).is_absolute() and pathlib.Path(d['path'])==pathlib.Path(d['path']).resolve())
 return got
def load(d):return json.loads(pathlib.Path(d['path']).read_bytes())
def contains(x,y):
 if eq(x,y):return True
 if type(x)is dict:return any(contains(v,y)for v in x.values())
 if type(x)is list:return any(contains(v,y)for v in x)
 return False
F=json.loads((P/'prospective-index-v1.json').read_bytes());T=json.loads((P/'authorized-index-v1.json').read_bytes())
pins['authorized_index']=desc(P/'authorized-index-v1.json');pins['prospective_index']=desc(P/'prospective-index-v1.json')
ck('authorized_index.expected_pin',pins['authorized_index']['sha256']=='8892cb887508d87f0b6d7cf0091975f9654a70ecf60872437688ae76207544d0' and pins['authorized_index']['bytes']==90732)
ck('prospective_index.expected_unchanged_pin',pins['prospective_index']['sha256']=='5d4b62d159dedbf313fd185824da9172be7fd055d597f66f0e5d38b82cb5fc4a' and pins['prospective_index']['bytes']==66281)
for k in ['API','Source_and_plan_adoption','cold','composition_handoff','declaration','frozen_scientific_parent','input_capsule','observer','runner','runtime_closure','prospective_index']:pin('index.'+k,T[k])
ck('authorized_index.references_reviewed_false_index',eq(T['prospective_index'],pins['prospective_index']))
for k in F:
 if k not in ['actual_execution_authorized','schedule','schema','scope']:ck('index.unchanged_'+k,eq(T[k],F[k]))
ck('index.exact_40_fresh_metadata_only',T['actual_execution_authorized'] is True and T['actuals_started']==0 and T['subject_count']==40 and T['final_delta_still_required'] is True and T['scientific_calls']==0 and T['scientific_acceptance'] is False and T['source_only'] is True)
A=load(T['Source_and_plan_adoption']);ck('adoption.expected_pin',T['Source_and_plan_adoption']['sha256']=='0ce06ba34471a0efb271662aeba8e1212f0400a70bbdc3f6c38ff37fc573722e' and T['Source_and_plan_adoption']['bytes']==2311)
ck('adoption.explicit_inactive_accepted40',A['accepted_for_exact_prospective_subjects'] is True and A['actual_execution_authorized'] is False and A['actuals_started']==0 and eq(A['prospective_index'],pins['prospective_index']))
ck('adoption.exact_current_roles',eq(A['review_roles'],T['current_review_roles']))
for k in ['Source_adoption','input_design_review']:pin('adoption.'+k,A[k])
ck('adoption.original_input_review769b',A['input_design_review']['sha256']=='769b4e57594093a7335b41962766ca6151c21517068a02676592837f789c617c')
prior_review=load(T['current_review_roles']['prospective_plans']);ck('prospective_current97de',T['current_review_roles']['prospective_plans']['sha256']=='97de1560414b8756d20cd478077ca58bfa50e4960c314bb392f3cf9419c0a72a')
ck('prior_review.covered_exact_index_decl_closure',eq(prior_review['prospective_index'],pins['prospective_index']) and eq(prior_review['declaration'],T['declaration']) and eq(prior_review['runtime_closure'],T['runtime_closure']))
prior_rows={r['invocation_id']:r for r in prior_review['all40_plan_bindings']}
ck('prior_review40bindings',len(prior_rows)==40)
# All existing raw Source/runtime/native files rehashed, no parsing of Native data.
old_audit=json.loads(pathlib.Path(prior_review['raw_audit']['path']).read_bytes());pin('prior_audit',prior_review['raw_audit'])
for k,d in old_audit['pins'].items():pin('reviewed_raw.'+k,d)
role_reviews={}
for role,d in T['current_review_roles'].items():
 pin('current_review.'+role,d);r=load(d);exp=F['review_role_schemas'][role]
 ck('current_review.'+role+'.identity_schema_scope',r['schema']==exp['schema'] and r[exp['pass']] is True and r['reviewer_identity']==exp['reviewer'] and r['author_identity']!=r['reviewer_identity'] and r['source_only'] is True and type(r['scientific_calls'])is int and r['scientific_calls']==0 and r['scientific_acceptance'] is False and r['actual_execution_authorized'] is False)
 role_reviews[role]=r
ck('current_roles.exact_four_distinct_scopes_three_identities',set(role_reviews)==set(F['review_role_schemas']) and len(role_reviews)==4 and len({r['reviewer_identity']for r in role_reviews.values()})==3)
G=load(T['declaration']);CAP=load(T['input_capsule']);C=load(T['runtime_closure']);inputs={s['id']:s for s in CAP['receivers']}
ck('all10_declarations_same_as_false',eq(T['case_declarations'],F['case_declarations']) and len(T['case_declarations'])==10)
for cid,cd in T['case_declarations'].items():
 pin('case.'+cid,cd);case=load(cd)
 ck('case.'+cid+'.exact_spec_global4',eq(case['global_cohort_declaration'],T['declaration']) and eq(case['selected_receiver'],inputs[cid]) and eq(case['schedule'],[r for r in G['schedule']if r['receiver_id']==cid]) and len(case['schedule'])==4)
 ck('case.'+cid+'.unchanged_limits_capsule_closure',eq(case['limits'],G['limits']) and eq(case['parent_structural_declaration'],T['input_capsule']) and eq(case['runtime_closure'],T['runtime_closure']))
bindings=[];subjects=set();actuals=set();terms=set();roles_by_case=collections.Counter()
ck('all40_index_rows',len(T['schedule'])==len(F['schedule'])==len(G['schedule'])==40)
for i,(tr,fr)in enumerate(zip(T['schedule'],F['schedule']),1):
 stem='slot%02d'%i;iid=tr['invocation_id']
 ck(stem+'.row_only_adds_final_auth_plan',set(tr)==set(fr)|{'authorization','runner_plan'} and eq({k:tr[k]for k in fr},fr))
 for k in ['authorization','runner_plan','authorization_draft','runner_plan_draft','worker_plan']:pin(stem+'.'+k,tr[k])
 final=load(tr['runner_plan']);false=load(fr['runner_plan_draft']);auth=load(tr['authorization']);oldauth=load(fr['authorization_draft']);w=load(tr['worker_plan'])
 finalsubject={k:v for k,v in final.items()if k!='authorization'};oldsubject={k:v for k,v in false.items()if k!='authorization'}
 sha=hashlib.sha256(canon(finalsubject)).hexdigest()
 ck(stem+'.full17subject_unchanged',len(finalsubject)==17 and eq(finalsubject,oldsubject) and eq(finalsubject,prior_rows[iid]['subject_preimage']) and sha==tr['subject_sha256']==fr['subject_sha256']==auth['subject_sha256']==oldauth['subject_sha256'])
 ck(stem+'.only_once_auth_descriptor_changed',set(final)==set(false) and {k for k in final if not eq(final[k],false[k])}=={'authorization'} and eq(final['authorization'],tr['authorization']))
 ck(stem+'.auth_delta_only_allowed_fields',set(auth)==set(oldauth) and {k for k in auth if not eq(auth[k],oldauth[k])}=={'actual_execution_authorized','review_roles','scope'})
 ck(stem+'.auth_true_maxone_unchanged_subject',auth['schema']==oldauth['schema']=='ROOT-and-support-ordering-once-authorization-v1' and auth['author_identity']==oldauth['author_identity']=='/root' and oldauth['actual_execution_authorized']is False and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==oldauth['maximum_actual_invocations']==1)
 ck(stem+'.auth_roles_exact_current',set(auth['review_roles'])==set(T['current_review_roles']) and oldauth['review_roles']=={})
 expected={
  'ordering_Source':[w['project_sources'][k]for k in ['semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1']],
  'composition_Source':[final['cold'],w['components']['receiver_driver']],
  'once_Source':[final['runner'],final['observer']],
  'prospective_plans':[final['integration_declaration'],final['runtime_closure'],final['worker_plan']]}
 role_detail={}
 for role,b in auth['review_roles'].items():
  r=role_reviews[role];exp=F['review_role_schemas'][role]
  ck(stem+'.role.'+role+'.exact_binding',set(b)=={'receipt','reviewer_identity','required_subjects'} and eq(b['receipt'],T['current_review_roles'][role]) and b['reviewer_identity']==exp['reviewer'] and eq(b['required_subjects'],expected[role]))
  ck(stem+'.role.'+role+'.full_scoped_literal_subjects',all(contains(r,s)for s in expected[role]))
  role_detail[role]=b
 ck(stem+'.prospective_minsubject_is_percase_not_global',eq(auth['review_roles']['prospective_plans']['required_subjects'][0],T['case_declarations'][tr['receiver_id']]) and not eq(auth['review_roles']['prospective_plans']['required_subjects'][0],T['declaration']))
 ck(stem+'.worker_pin_exact_prior',eq(tr['worker_plan'],prior_rows[iid]['worker_plan']) and eq(w['integration_declaration'],T['case_declarations'][tr['receiver_id']]) and eq(w['project_sources'],C['project_sources']) and eq(w['components'],C['additional_nonseed_components']))
 ck(stem+'.global_schedule_order_same',eq({k:tr[k]for k in G['schedule'][i-1]},G['schedule'][i-1]))
 actual=pathlib.Path(tr['actual_directory']);term=pathlib.Path(tr['runner_plan']['path']).parent/(iid+'-terminal-observation');draftterm=pathlib.Path(tr['runner_plan_draft']['path']).parent/(iid+'-terminal-observation')
 ck(stem+'.fresh_actual_final_and_draft_observer_paths',not actual.exists() and not term.exists() and not draftterm.exists())
 ck(stem+'.no_consumed_terminal_markers',not(actual/'CONSUMED.json').exists() and not(term/'CONSUMED.json').exists() and not(term/'terminal.json').exists())
 subjects.add(sha);actuals.add(str(actual));terms.add(str(term));roles_by_case[tr['receiver_id']]+=1
 bindings.append({'order':i,'invocation_id':iid,'receiver_id':tr['receiver_id'],'mode':tr['mode'],'search_ordering':tr['search_ordering'],'runner_plan':tr['runner_plan'],'authorization':tr['authorization'],'worker_plan':tr['worker_plan'],'false_runner_plan':tr['runner_plan_draft'],'false_authorization':tr['authorization_draft'],'integration_declaration':final['integration_declaration'],'subject_sha256':sha,'subject_fields':17,'subject_unchanged':True,'review_roles':role_detail,'actual_directory':str(actual),'terminal_observation_directory':str(term),'draft_terminal_observation_directory':str(draftterm),'paths_absent':True})
ck('all40_unique_subjects_actual_terminal_paths',len(subjects)==len(actuals)==len(terms)==40)
ck('all10cases_four_each',len(roles_by_case)==10 and set(roles_by_case.values())=={4})
summary={'checks':len(checks),'mismatches':sum(not x['passed']for x in checks),'all_passed':all(x['passed']for x in checks),'grants':40,'unchanged_whole17field_subjects':40,'unchanged_worker_pins':40,'maximum_actual_invocations_per_grant':1,'review_roles_per_grant':4,'distinct_reviewer_identities':3,'percase_declarations':10,'actual_paths_absent':40,'terminal_paths_absent':40,'distinct_raw_files_hashed':len(cache),'scientific_calls':0}
audit={'schema':'first-order-suite-final40-raw-grant-delta-audit-v1','reviewer_identity':'/root/conventional_library','source_only':True,'scientific_calls':0,'summary':summary,'pins':pins,'all40grant_bindings':bindings,'checks':checks}
(OUT/'raw-final-grant-audit-v1.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(summary,indent=2));print(json.dumps(desc(OUT/'raw-final-grant-audit-v1.json')))
