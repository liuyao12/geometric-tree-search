"""Independent stdlib raw/AST/F0 inspection; no scientific module evaluation."""
import ast,hashlib,json,pathlib,subprocess
OUT=pathlib.Path('/private/tmp/gcts-first-order-suite-composition-peer-20261018')
B=pathlib.Path('/private/tmp/gcts-first-order-suite-intake-source-20261018')
H=json.loads((B/'handoff-v1.json').read_bytes());C=json.loads((B/'composition-Source-contract-v1.json').read_bytes());API=json.loads((B/'API-v1.json').read_bytes());checks=[];pins={}
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def ck(n,b,d=None):checks.append({'name':n,'passed':bool(b),'detail':d})
def eq(x,y):return canon(x)==canon(y)
def desc(p):
 p=pathlib.Path(p);r=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(r).hexdigest(),'bytes':len(r)}
def pin(n,d):
 a=desc(d['path']);pins[n]=a;ck(n+'.rawpin',all(a[k]==d[k] for k in ['path','sha256','bytes']));return pathlib.Path(d['path']).read_bytes()
def load(d):return json.loads(pathlib.Path(d['path']).read_bytes())
for name in ['composition_contract','API','delta','generated_Source_map','static_author_evidence','input_capsule','prospective_design']:pin(name,H[name])
pins['handoff']=desc(B/'handoff-v1.json')
for name,d in C['sources'].items():pin('source.'+name,d)
for name,d in C['parents'].items():pin('parent.'+name,d)
for name,d in C['prior_independent_Source_peers'].items():pin('prior_peer.'+name,d)
for name,d in C['expected_project_sources'].items():pin('current_project.'+name,d)
for name,d in C['expected_scientific_components'].items():pin('current_component.'+name,d)
prior=load(C['previous_current_runtime_closure']);pin('previous_current_runtime_closure',C['previous_current_runtime_closure'])
parent_closure=load(C['operative_parent_runtime_closure']);pin('operative_parent_runtime_closure',C['operative_parent_runtime_closure'])
ck('all22project.identical_to_immediate_parent',eq(C['expected_project_sources'],prior['project_sources']) and len(C['expected_project_sources'])==22)
ck('all2components.identical_to_immediate_parent',eq(C['expected_scientific_components'],prior['additional_nonseed_components']) and len(C['expected_scientific_components'])==2)
ck('all24aliases.identical_to_immediate_parent',eq(C['materialized_aliases'],prior['materialized_aliases']) and len(C['materialized_aliases'])==24)
ck('scientific_driver.same_source_and_parent',eq(C['sources']['receiver_driver'],C['parents']['receiver_driver']) and eq(C['sources']['receiver_driver'],C['expected_scientific_components']['receiver_driver']))
old=pathlib.Path(C['parents']['cold']['path']).read_bytes();new=pathlib.Path(C['sources']['cold']['path']).read_bytes()
replacements=[(b"VERSION = 'and-support-ordering-cold-v1'",b"VERSION = 'frozen-fol-suite-intake-cold-v1'"),(b'19fab9173cf52ebd9e0d5517fd4dbbb44ed9d72f3737676d9701fd6a4c8bde5d',b'1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0')]
constructed=old;restored=new
for i,(a,b) in enumerate(replacements):
 ck('replacement%d.old_occurs_once'%i,old.count(a)==1);ck('replacement%d.new_occurs_once'%i,new.count(b)==1)
 constructed=constructed.replace(a,b);restored=restored.replace(b,a)
ck('whole_raw_delta.exactly_two_declared_replacements',constructed==new and restored==old)
old_ast=ast.parse(old);new_ast=ast.parse(new)
class Undo(ast.NodeTransformer):
 def visit_Constant(self,node):
  values={'frozen-fol-suite-intake-cold-v1':'and-support-ordering-cold-v1','1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0':'19fab9173cf52ebd9e0d5517fd4dbbb44ed9d72f3737676d9701fd6a4c8bde5d'}
  if type(node.value)is str and node.value in values:return ast.copy_location(ast.Constant(values[node.value]),node)
  return node
restored_ast=Undo().visit(ast.parse(new))
ck('whole_AST_inverse.exact',ast.dump(old_ast,include_attributes=False)==ast.dump(restored_ast,include_attributes=False))
regions=[]
for before,after in zip(old_ast.body,new_ast.body):
 if isinstance(before,(ast.FunctionDef,ast.ClassDef)):
  bo=old.splitlines(keepends=True)[before.lineno-1:before.end_lineno];ao=new.splitlines(keepends=True)[after.lineno-1:after.end_lineno]
  raw_same=bo==ao;ast_same=ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False)
  if before.name!='main':ck('retained_region.'+before.name,raw_same and ast_same)
  regions.append({'name':before.name,'old_lines':[before.lineno,before.end_lineno],'new_lines':[after.lineno,after.end_lineno],'raw_equal':raw_same,'AST_equal':ast_same})
ck('select_receiver.raw_AST_exact',next(x for x in regions if x['name']=='select_receiver')['raw_equal'] and next(x for x in regions if x['name']=='select_receiver')['AST_equal'])
constants={}
for n in new_ast.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:constants[n.targets[0].id]=ast.literal_eval(n.value)
  except (ValueError,TypeError):pass
ck('cold.pins_complete_capsule',constants['VERSION']=='frozen-fol-suite-intake-cold-v1' and b'19fab917' not in new and replacements[1][1] in new)
ck('cold.operative_parent_unchanged',eq(constants['PARENT_RUNTIME_CLOSURE'],C['operative_parent_runtime_closure']))
ck('cold.driver_pin_equals_contract',eq(constants['RECEIVER_DRIVER_SOURCE'],C['sources']['receiver_driver']))
ck('cold.ordering_map_equals_exact_sources',eq(constants['ORDERING_COMPONENT_SOURCES'],API['ordering_sources']))
ck('cold.compact_model_pin_unchanged',eq(constants['COMPACT_MODEL_SOURCE'],C['expected_project_sources']['interned_quantified_family_points_v1']))
ck('cold.alias_dispatch_same_API',eq(constants['ROLE_MODULES'],{'base_compiler':'quantified_receptors_v1','family_miner':'semantic_lemma_inventory','family_model':'quantified_family_points_v2','family_search':'semantic_inventory_search_v2','family_registry':'semantic_inventory_oracle','point_smt':'semantic_point_smt','symbolic_control':'quantified_symbolic_control_v2','support_ordering':'receptor_support_ordering_v1'}))
old_api=load(API['parent_API']);pin('parent_API',API['parent_API'])
for key in ['worker_fields','once_fields','authorization_fields','review_roles','epoch_schema','worker_schema','once_schema','closure_schema','declaration_schema','driver_API','driver_module_roles','runtime_role_aliases']:
 ck('API.retained.'+key,eq(API[key],old_api[key]))
ck('API.driver_signature_compatible',API['driver_API'].startswith('run_receiver(*, receiver_spec, mode, search_ordering,'))
ck('review_ABI.exact',C['review_ABI']['schema']=='and-support-driver-cold-typed-Source-review-v1' and C['review_ABI']['scope']=='and-support-driver-cold-Source' and C['review_ABI']['reviewer_identity']=='/root/conventional_library')
ck('Source_immutable_inactive',all(x['source_only'] is True and x['scientific_calls']==0 and x['actual_execution_authorized'] is False for x in [H,C,API]))
# Inert patch application to ordinary scratch text. Does not invoke the cold Source.
patches=[]
for direction,start,expected in [('forward',old,new),('inverse',new,old)]:
 scratch=OUT/('scratch-cold-'+direction);scratch.mkdir(exist_ok=True);(scratch/'unit.py').write_bytes(start)
 patch=B/('cold-'+direction+'-v1.patch');pin('patch.'+direction,desc(patch))
 cp=subprocess.run(['patch','--batch','-F','0','-p0','-i',str(patch)],cwd=scratch,capture_output=True,text=True)
 outcome={'direction':direction,'returncode':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr,'whole_bytes_equal':(scratch/'unit.py').read_bytes()==expected}
 ck('inert_F0.'+direction,cp.returncode==0 and outcome['whole_bytes_equal'] and 'fuzz' not in cp.stdout.lower() and 'offset' not in cp.stdout.lower(),outcome);patches.append(outcome)
compile(new,C['sources']['cold']['path'],'exec',dont_inherit=True);ck('compile_new_cold_without_eval',True)
# Explicit Source path reasoning checks retain existing body; no calls to these functions.
lines=new.decode().splitlines();citations={
 'whole_capsule_pin':[292,298],'per_case_cohort_subjects':[299,313],'select_receiver_from_capsule':[204,224],
 'complete_current_Source_maps':[316,352],'shared_copy_import_origin_seals':[353,397],'fixed_native_inputs':[398,416],
 'whole_epoch_and_driver_dispatch':[417,441],'Native_close_reap_and_lossless_reader':[442,479],
 'whole_point_and_work_gates':[480,522],'exception_cleanup_no_acceptance':[523,539],'exact_profile_and_marker':[227,260]}
for k,(lo,hi) in citations.items():ck('cited_Source_range.'+k,1<=lo<=hi<=len(lines))
audit={'schema':'frozen-fol-suite-cold-raw-AST-review-audit-v1','reviewer_identity':'/root/conventional_library','source_only':True,'scientific_calls':0,'sources':C['sources'],'pins':pins,'summary':{'checks':len(checks),'mismatches':sum(not x['passed'] for x in checks),'all_passed':all(x['passed'] for x in checks),'raw_AST_unchanged_top_regions':sum(x['raw_equal'] and x['AST_equal'] for x in regions),'inert_F0_directions':len(patches),'compile_without_eval':1},'regions':regions,'citations':citations,'checks':checks}
(OUT/'raw-Source-audit-v1.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(audit['summary'],indent=2));print(json.dumps(desc(OUT/'raw-Source-audit-v1.json')))
