"""Retained ZIP/raw-result-gzip packaging bytes only. Never extract or execute.

ZIP container decompression compares raw members. Only the forty ordinary
*-result.json.gz downloads are gzip-decompressed. Native gzip/program/table
contents are never decoded or interpreted; native binaries are opaque bytes.
"""
from pathlib import Path, PurePosixPath
import collections
import gzip
import hashlib
import json
import zipfile

D = Path('/private/tmp/gcts-first-order-suite-package-peer-20261018')
ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
P = ROOT / '.gcts-active/first-order-suite-progress-20261018'
ARCHIVE_INDEX = P / 'ROOT-case-archive-assets-v1.json'
DRAFT = P / 'report-draft-assets-v3.json'
PLAN_INDEX = Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1/authorized-index-v1.json')
D.mkdir(exist_ok=True)

def pin(path):
    p = Path(path).resolve()
    h, count = hashlib.sha256(), 0
    with p.open('rb') as stream:
        for b in iter(lambda: stream.read(1048576), b''):
            count += len(b);h.update(b)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=count)

def load(path):
    return json.loads(Path(path).read_bytes())

def write(name,value):
    p=D/name;p.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');return pin(p)

checks=[]
def ck(label,condition,evidence=None):
    checks.append(dict(check=label,passed=bool(condition),evidence=evidence))
    if not condition:raise AssertionError(label)

def stream_equal(stream,original_path,expected):
    """Whole direct byte comparison plus SHA; no content-format interpretation."""
    count,h=0,hashlib.sha256()
    with Path(original_path).open('rb') as original:
        while True:
            b=stream.read(1048576)
            raw=original.read(1048576)
            if b!=raw:return dict(equal=False,bytes=count,sha256=h.hexdigest())
            if not b:break
            count+=len(b);h.update(b)
            if count>expected['bytes']:return dict(equal=False,bytes=count,sha256=h.hexdigest())
    return dict(equal=count==expected['bytes'] and h.hexdigest()==expected['sha256'],
                bytes=count,sha256=h.hexdigest())

archive_index,draft,plans=load(ARCHIVE_INDEX),load(DRAFT),load(PLAN_INDEX)
ck('exact frozen case archive index',pin(ARCHIVE_INDEX)==dict(path=str(ARCHIVE_INDEX),bytes=655200,
   sha256='e687871842c8c6fefdfb9c7399a83445c69235f2b811aca5482af2236861775b'))
ck('exact frozen report download list v3',pin(DRAFT)==dict(path=str(DRAFT),bytes=19199,
   sha256='c1ac5ed8f43b1084087bf352cc5e9e041cc400b62238fa1bcb5e675526d50156'))
ck('exact authorized forty subject index',pin(PLAN_INDEX)['sha256']=='8892cb887508d87f0b6d7cf0091975f9654a70ecf60872437688ae76207544d0')
ck('case count and asset descriptors one to one',len(archive_index['cases'])==len(archive_index['assets'])==10 and
   [c['archive'] for c in archive_index['cases']]==archive_index['assets'])
case_ids=list(dict.fromkeys(r['receiver_id']for r in plans['schedule']))
ck('all ten frozen cases and forty unique subjects present',len(case_ids)==10 and len(plans['schedule'])==40 and
   len({r['invocation_id']for r in plans['schedule']})==40 and
   [c['receiver_id']for c in archive_index['cases']]==case_ids)
runtime=load(plans['runtime_closure']['path'])
module_names=set(runtime['materialized_aliases'])
ck('common24 alias inventory available for packaging completeness',len(module_names)==24)
asset_by_name={Path(d['path']).name:d for d in draft['assets']}
ck('all declared draft asset names unique',len(asset_by_name)==len(draft['assets']))
downloads={name:d for name,d in asset_by_name.items()if name.endswith('-result.json.gz')}
ck('exact forty ordinary result gzip downloads declared',len(downloads)==40)
case_rows=[];gzip_rows=[];all_iids=[];statuses=collections.Counter()
manifest_raw_count=0;zip_raw_total=0;gzip_raw_total=0
seen_gzip_names=set()
for case in archive_index['cases']:
    case_id=case['receiver_id'];tag=case_id+': '
    rows=[r for r in plans['schedule']if r['receiver_id']==case_id]
    ck(tag+'all four original method/order slots retained',len(rows)==4 and
       {(r['mode'],r['search_ordering'])for r in rows}=={(m,o)for m in('fixed','symbolic')for o in('legacy','and_support')})
    descriptor=case['archive']
    ck(tag+'complete compressed archive raw pin',pin(descriptor['path'])==descriptor)
    members=case['members']
    ck(tag+'164 declared raw members, no manifest selfhash cycle',len(members)==164 and 'archive-manifest.json' not in members)
    expected_members={};per_arm=[]
    for row in rows:
        iid=row['invocation_id'];all_iids.append(iid)
        actual=Path(row['actual_directory'])
        observation=Path(row['runner_plan']['path']).parent/(Path(row['runner_plan']['path']).stem+'-terminal-observation')
        launcher=P/'launcher-slots'/iid
        directories={'actuals':actual,'observations':observation,'launcher-slots':launcher}
        sizes={}
        for category,folder in directories.items():
            paths=sorted(p for p in folder.rglob('*')if p.is_file())
            ck(tag+iid+' original raw inventory has no symlinks '+category,all(not p.is_symlink()for p in paths))
            sizes[category]=len(paths)
            for original in paths:
                name=category+'/'+iid+'/'+original.relative_to(folder).as_posix()
                ck(tag+'expected current original included '+name,name in members and members[name]['path']==str(original.resolve()))
                expected_members[name]=members[name]
        ck(tag+iid+' complete33 actual+4 observation+4 launcher files',sizes=={'actuals':33,'observations':4,'launcher-slots':4})
        ck(tag+iid+' all24 owned Source aliases retained',
           {p.stem for p in (actual/'modules').iterdir()if p.is_file()}==module_names)
        expected_actual={'CONSUMED.json','result.json','runner-receipt.json','worker-receipt.json','stdout.bin','stderr.bin',
                         'native/code.bin','native/input.bin','native/output.bin'}|{'modules/'+a+'.py'for a in module_names}
        ck(tag+iid+' exact full original actual file palette',
           {p.relative_to(actual).as_posix()for p in actual.rglob('*')if p.is_file()}==expected_actual)
        worker=load(actual/'worker-receipt.json')
        statuses[worker['status']]+=1
        result_pin=worker['result']
        ck(tag+iid+' archive includes whole raw result receipt',members['actuals/'+iid+'/result.json']==result_pin and
           result_pin['bytes']<=134217728)
        case_number=case_id.rsplit('-',1)[-1]
        gzip_name='fol-'+case_number+'-'+row['mode']+'-'+row['search_ordering'].replace('_','-')+'-result.json.gz'
        ck(tag+iid+' one exact declared ordinary download',gzip_name in downloads and gzip_name not in seen_gzip_names)
        seen_gzip_names.add(gzip_name)
        gzip_pin=downloads[gzip_name]
        ck(tag+iid+' whole compressed ordinary JSON asset pin',pin(gzip_pin['path'])==gzip_pin)
        # WHITELIST: no other gzip file is ever opened with gzip.GzipFile.
        ck(tag+iid+' gzip target is ordinary raw result JSON only',Path(result_pin['path']).name=='result.json' and
           Path(gzip_pin['path']).name==gzip_name and gzip_name.endswith('-result.json.gz'))
        with gzip.open(gzip_pin['path'],'rb')as stream:
            comparison=stream_equal(stream,result_pin['path'],result_pin)
        ck(tag+iid+' complete gzip decode equals every original raw result byte',comparison['equal'],comparison)
        gzip_raw_total+=comparison['bytes']
        gzip_rows.append(dict(invocation_id=iid,receiver_id=case_id,compressed=gzip_pin,original=result_pin,
                              whole_byte_comparison=comparison,stored_status=worker['status'],
                              scientific_or_native_interpretation=False))
        per_arm.append(dict(invocation_id=iid,status=worker['status'],raw_file_counts=sizes,result=result_pin,
                            module_count=24,gzip=gzip_pin))
    ck(tag+'manifest mapping exactly complete current filesystem inventories',members==expected_members)
    with zipfile.ZipFile(descriptor['path'],'r')as archive:
        infos=archive.infolist();names=[i.filename for i in infos]
        ck(tag+'exact165 unique ZIP entries incl internal manifest',len(infos)==165 and len(set(names))==165 and
           set(names)==set(members)|{'archive-manifest.json'})
        ck(tag+'ZIP entries safe relative files and no encryption',all(not info.is_dir()and
           not PurePosixPath(info.filename).is_absolute()and '..'not in PurePosixPath(info.filename).parts and
           not(info.flag_bits&1)for info in infos))
        manifest_bytes=archive.read('archive-manifest.json')
        manifest=json.loads(manifest_bytes)
        ck(tag+'internal manifest schema/case/allfour',manifest['schema']=='first-order-suite-case-archive-manifest-v1'and
           manifest['receiver_id']==case_id and manifest['all_four_actuals']is True)
        ck(tag+'internal manifest whole mapping equals frozen external index',manifest['members']==members)
        per_member=[]
        for name,original in members.items():
            info=archive.getinfo(name)
            ck(tag+'ZIP raw file size matches complete original '+name,info.file_size==original['bytes'])
            with archive.open(info,'r')as stream:
                comparison=stream_equal(stream,original['path'],original)
            # zipfile validates CRC while reading to EOF. We never extract.
            ck(tag+'ZIP whole raw original bytes/hash and CRC '+name,comparison['equal'],comparison)
            zip_raw_total+=comparison['bytes'];manifest_raw_count+=1
            per_member.append(dict(member=name,original=original,comparison=comparison))
        # No opaque Native gzip has been inner-decoded even if one were a ZIP
        # raw member; stream_equal merely compares the compressed-file bytes.
        case_rows.append(dict(receiver_id=case_id,archive=descriptor,raw_member_count=len(members),
                              total_zip_entries=len(infos),manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
                              manifest_bytes=len(manifest_bytes),actuals=per_arm,members=per_member))
    ck(tag+'archive pin unchanged after full read',pin(descriptor['path'])==descriptor)
    print('case ZIP and four ordinary JSON gzips verified',case_id,flush=True)

ck('all40 source outcomes represented once without filtering',len(all_iids)==len(set(all_iids))==40 and
   set(all_iids)=={r['invocation_id']for r in plans['schedule']})
ck('all40 ordinary gzip downloads consumed exactly once',seen_gzip_names==set(downloads)and len(gzip_rows)==40)
ck('all1640 raw case members checked against current originals',manifest_raw_count==1640)
ck('positive and both UNKNOWN categories retained',dict(statuses)=={'native_proof_discovered':12,'unknown_native_inventory':16,'unknown_search_budget':12})
ck('whole case member raw result totals equal ordinary gzip raw totals',
   sum(a['result']['bytes']for c in case_rows for a in c['actuals'])==gzip_raw_total)
audit=write('raw-case-package-audit-v1.json',dict(schema='first-order-suite-case-package-audit-v1',
            author_identity='/root',reviewer_identity='/root/conventional_control_review',
            retained_bytes_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
            archive_index=pin(ARCHIVE_INDEX),draft_assets=pin(DRAFT),authorized_index=pin(PLAN_INDEX),
            check_count=len(checks),mismatch_count=0,checks=checks,cases=case_rows,ordinary_result_gzips=gzip_rows,
            ordinary_gzip_decompressions=40,raw_zip_member_comparisons=manifest_raw_count,
            zip_container_entries=1650,opaque_native_gzip_decodes=0,
            raw_zip_bytes_compared=zip_raw_total,ordinary_result_raw_bytes_compared=gzip_raw_total,
            stored_outcomes=dict(statuses),no_extraction_no_import_no_target_evaluation=True))
resource_peer=Path('/private/tmp/gcts-first-order-suite-retained-resource-peer-20261018/typed-resource-review-v1.json')
receipt=write('typed-case-package-review-v1.json',dict(schema='first-order-suite-case-package-review-v1',
              scope='Ten CASE ZIP archives and forty ordinary raw-result JSON gzip byte packaging only',
              author_identity='/root',reviewer_identity='/root/conventional_control_review',
              package_review_passed=True,retained_bytes_only=True,source_only=True,
              scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
              project_imports=0,native_calls=0,model_calls=0,reader_calls=0,compiler_calls=0,
              search_calls=0,solver_calls=0,renderer_calls=0,proof_replays=0,
              ordinary_result_gzip_decompressions=40,opaque_native_gzip_decodes=0,
              archive_index=pin(ARCHIVE_INDEX),draft_assets=pin(DRAFT),authorized_index=pin(PLAN_INDEX),
              case_archives=[c['archive']for c in archive_index['cases']],
              ordinary_result_downloads=[r['compressed']for r in gzip_rows],
              case_count=10,actual_count=40,raw_member_count=1640,zip_entry_count_including_manifests=1650,
              current_owned_module_copies_included=960,
              stored_outcomes=dict(statuses),raw_zip_bytes_compared=zip_raw_total,
              ordinary_result_raw_bytes_compared=gzip_raw_total,check_count=len(checks),mismatch_count=0,
              audit=audit,audit_Source=pin(Path(__file__)),prior_resource_review=pin(resource_peer),
              ancestry=dict(authored_helper_symbolic_and_inherited_outer=True,
                            authored_prior_resource_peer=True,not_own_Source_certification=True,
                            Root_case_packager_author_is_distinct=True),
              findings=[dict(id='COMPLETE_CASE_BYTES',severity='evidence',finding='All10 ZIPs contain exactly164 raw members plus one non-self-hashed internal manifest. Every raw byte/hash/size and ZIP CRC matches the full current original; filesystem inventory confirms four complete actuals, all24 owned modules per arm, Native code/wire artifacts, observations and launcher-slot files.'),
                        dict(id='COMPLETE_ORDINARY_DOWNLOADS',severity='evidence',finding='All40 whitelisted ordinary result JSON gzip assets decompress to the whole exact current raw result bytes/hash. All12 stored positive,16 inventory UNKNOWN and12 search UNKNOWN outcomes remain; no case or raw result filtering.'),
                        dict(id='LIMITED_RELEASE_SCOPE',severity='scope',finding='This receipt covers only case ZIP/download bytes. Root common archive, final evidence manifest, final current references, local navigation, deployment and live checks are pending independent release closure.')],
              limitations=[
                'ZIP container decompression and forty explicitly whitelisted ordinary raw-result JSON gzip decompressions only. Native code/input/output files are opaque byte comparisons; no opaque Native gzip, machine/program/template codec or scientific object is decoded or evaluated.',
                'No archive extraction, project/Reader/Model/kernel/native/logic/compiler/search/solver/renderer import or evaluation, proof replay, mathematical admission, live process probe, actual launch or grant occurs.',
                'Independent of Root byte packager, but reviewer authored current helper/symbolic/inherited outer and prior resource audit. Those facts are disclosed; this is packaging verification, not new own Source or resource certification.',
                'Source/current-original comparisons describe frozen retained bytes, not a formal filesystem/OS continuous custody guarantee. Every member was streamed to EOF with direct byte equality, hash and declared size; ZIP CRC validation is supplied by the standard library.',
                'The ten archives have165 entries each:164 raw original files and archive-manifest.json. The manifest lists164 other members; it intentionally does not contain a circular hash of itself.',
                'Ten inputs include two linked renames across eight structural groups. All40 outcomes remain. Byte completeness does not establish theorem novelty, native correctness, full pipeline performance, GCTS/RL advantage or statistical generalization.',
                'Root common archive/final manifest/review copies/navigation/live publication remain separate pending release gates. No full publication acceptance is asserted by this limited package receipt.']))
handoff=write('handoff-v1.json',dict(schema='first-order-suite-case-package-peer-handoff-v1',
              retained_bytes_only=True,source_only=True,scientific_calls=0,scientific_acceptance=False,
              actual_execution_authorized=False,receipt=receipt,audit=audit,archive_index=pin(ARCHIVE_INDEX),draft_assets=pin(DRAFT)))
print(json.dumps(handoff,sort_keys=True))
