"""Source-only exact intake-identity delta review; no target evaluation."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

D = Path('/private/tmp/gcts-first-order-suite-once-peer-20261018')
S = Path('/private/tmp/gcts-first-order-suite-intake-source-20261018')
D.mkdir(exist_ok=True)

def pin(path):
    p = Path(path).resolve()
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def load(path):
    return json.loads(Path(path).read_bytes())

def write(name, value):
    p = D / name
    p.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    return pin(p)

checks = []
def ck(name, condition, details=None):
    checks.append(dict(check=name, passed=bool(condition), details=details))
    if not condition:
        raise AssertionError(name)

handoff_path, contract_path = S/'handoff-v1.json', S/'once-Source-contract-v1.json'
h, c = load(handoff_path), load(contract_path)
ck('exact frozen new handoff', pin(handoff_path) == dict(path=str(handoff_path), bytes=5138,
   sha256='5a950ff347671ae4d93267eed8482148bb603d50ff7932fcb698c2d3073034fc'))
ck('exact new once contract', pin(contract_path) == h['once_contract'])
ck('new author distinct reviewer', c['author_identity'] == '/root/receiver_driver_review')
for key in ('API','delta','static_author_evidence','generated_Source_map','input_capsule','prospective_design'):
    ck('whole raw attachment '+key, pin(h[key]['path']) == h[key])
api = load(h['API']['path'])
old_contract_path = Path('/private/tmp/gcts-and-support-cold-source-20261018/once-Source-contract-v1.json')
old_contract = load(old_contract_path)
immediate_peer = Path('/private/tmp/gcts-and-support-once-peer-20261018/typed-Source-review-v1.json')
grandparent_peer = Path('/private/tmp/gcts-compact-model-cold-once-independent-peer-20261018/typed-Source-review-v2.json')
oldp, grandp = load(immediate_peer), load(grandparent_peer)
ck('exact genuine immediate peer chain', pin(immediate_peer) == h['ancestry']['once'] and
   oldp['source_review_passed'] is True and oldp['author_identity'] == '/root/receiver_driver_review' and
   oldp['reviewer_identity'] == '/root/conventional_control_review')
ck('genuine grandparent independent author review', pin(grandparent_peer)['sha256'] ==
   'd1fed0448738dbe07efbd2482a6259dc58ecf21473a3cbf46bf09e61a242d4a2' and
   grandp['source_review_passed'] is True and grandp['author_identity'] == '/root/conventional_control_review' and
   grandp['reviewer_identity'] == '/root/receiver_driver_review')
ck('unchanged once review ABI', c['review_ABI'] == old_contract['review_ABI'])
ck('same required typed receipt schema and scope', c['review_ABI']['schema'] == 'and-support-once-typed-Source-review-v1' and
   c['review_ABI']['scope'] == 'and-support-once-Source')
ck('complete scientific22 project Source map unchanged', c['expected_project_sources'] == old_contract['expected_project_sources'] and len(c['expected_project_sources']) == 22)
sources = c['sources']
parents = c['parents']
texts, parent_texts, trees, parent_trees = {}, {}, {}, {}
retained = {}
diffs, patches = {}, []

def top(tree):
    return {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}

def raw_region(text,node):
    return ''.join(text.splitlines(True)[node.lineno-1:node.end_lineno])

def literal_assignments(tree):
    result = {}
    for node in tree.body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            try:
                result[node.targets[0].id] = ast.literal_eval(node.value)
            except (TypeError,ValueError):
                pass
    return result

for role, source in sources.items():
    ck('new raw whole Source '+role, pin(source['path']) == source == h['sources'][role])
    ck('immediate parent exact Source '+role, pin(parents[role]['path']) == parents[role] == oldp['sources'][role])
    texts[role], parent_texts[role] = Path(source['path']).read_text(), Path(parents[role]['path']).read_text()
    trees[role], parent_trees[role] = ast.parse(texts[role]), ast.parse(parent_texts[role])
    compile(trees[role],source['path'],'exec')  # Code object only. Never exec/eval/import.
    ck('parse compile WITHOUT evaluation '+role, True)
    new_nodes, old_nodes = top(trees[role]), top(parent_trees[role])
    ck('same complete callable inventory '+role, set(new_nodes)==set(old_nodes))
    retained[role] = []
    for name in old_nodes:
        new_raw, old_raw = raw_region(texts[role],new_nodes[name]), raw_region(parent_texts[role],old_nodes[name])
        if role=='terminal_observer' and name=='main':
            old_sha,new_sha=parents['once_runner']['sha256'],sources['once_runner']['sha256']
            ck('observer main only current runner SHA literal replacement', new_raw.count(new_sha)==1 and
               new_raw.replace(new_sha,old_sha)==old_raw)
            normalized = ast.parse(new_raw.replace(new_sha,old_sha))
            ck('observer main AST exact after SHA inverse', ast.dump(normalized.body[0],include_attributes=False)==ast.dump(old_nodes[name],include_attributes=False))
        else:
            ck('INHERITED ONLY exact whole callable raw/AST '+role+'/'+name, new_raw==old_raw and
               ast.dump(new_nodes[name],include_attributes=False)==ast.dump(old_nodes[name],include_attributes=False))
            retained[role].append(name)
    folder=D/('inert-patch-'+role)
    folder.mkdir(exist_ok=True)
    target=folder/'payload.py'
    target.write_text(parent_texts[role])
    forward=''.join(difflib.unified_diff(parent_texts[role].splitlines(True),texts[role].splitlines(True),fromfile='payload.py',tofile='payload.py'))
    inverse=''.join(difflib.unified_diff(texts[role].splitlines(True),parent_texts[role].splitlines(True),fromfile='payload.py',tofile='payload.py'))
    (folder/'forward.patch').write_text(forward);(folder/'inverse.patch').write_text(inverse)
    diffs[role]=forward
    for direction,patch,expected in [('forward',forward,texts[role]),('inverse',inverse,parent_texts[role])]:
        result=subprocess.run(['patch','--batch','-p0'],input=patch.encode(),cwd=folder,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        ck('real independent inert F0 '+role+'/'+direction,result.returncode==0 and target.read_text()==expected)
        patches.append(dict(role=role,direction=direction,exit_code=result.returncode,whole_output=pin(target),
                            stdout=result.stdout.decode(),stderr=result.stderr.decode()))

ng,og=literal_assignments(trees['once_runner']),literal_assignments(parent_trees['once_runner'])
for name in ('PLAN_SCHEMA','AUTH_SCHEMA','WORKER_RECEIPT_SCHEMA','RECEIPT_SCHEMA','LIMITS','KINDS','STORAGES','ORDERINGS','REVIEW_ROLES'):
    ck('INHERITED ONLY whole constant unchanged '+name,ng[name]==og[name])
ck('runner cold whole descriptor exact new cold',ng['COLD_PIN']==h['sources']['cold'] and pin(ng['COLD_PIN']['path'])==ng['COLD_PIN'])
ck('new runner implementation identity',ng['VERSION']=='frozen-fol-suite-intake-external-once-runner-v1')
old_version_line="VERSION = 'and-support-ordering-external-once-runner-v1'"
new_version_line="VERSION = 'frozen-fol-suite-intake-external-once-runner-v1'"
old_cold_line="COLD_PIN = "+repr(og['COLD_PIN'])
new_cold_line="COLD_PIN = "+repr(ng['COLD_PIN'])
ck('whole runner inverse equality only VERSION and COLD_PIN',texts['once_runner'].replace(new_version_line,old_version_line).replace(new_cold_line,old_cold_line)==parent_texts['once_runner'])
observer_old_version="VERSION = 'and-support-ordering-final-terminal-observer-v1'"
observer_new_version="VERSION = 'frozen-fol-suite-intake-final-terminal-observer-v1'"
ck('whole observer inverse equality only VERSION and runner SHA',
   texts['terminal_observer'].replace(observer_new_version,observer_old_version).replace(sources['once_runner']['sha256'],parents['once_runner']['sha256'])==parent_texts['terminal_observer'])
ck('original fixed180/210 conservative1GiB/128MiB/log limits',ng['LIMITS']['work_seconds']==180 and ng['LIMITS']['overall_seconds']==210 and
   ng['LIMITS']['aggregate_peak_bytes']==1073741824 and ng['LIMITS']['result_bytes']==134217728 and
   ng['LIMITS']['stdout_bytes']==ng['LIMITS']['stderr_bytes']==4194304)
ck('original two modes/two orderings/compact storage',ng['KINDS']==('fixed','symbolic') and ng['ORDERINGS']==('legacy','and_support') and ng['STORAGES']==('literal_interned',))
ck('exact same four runtime review roles',ng['REVIEW_ROLES']==og['REVIEW_ROLES'] and len(ng['REVIEW_ROLES'])==4)
for role,binding in api['review_roles'].items():
    ck('API expected reviewer/schema/pass unchanged '+role,
       (binding['schema'],binding['pass'],binding['reviewer'])==ng['REVIEW_ROLES'][role])

# Cold intake is independently reviewed by Library; read only the binding
# constants/coupling required for this new COLD_PIN, not its scientific body.
cold_text=Path(h['sources']['cold']['path']).read_text()
cold_tree=ast.parse(cold_text)
cg=literal_assignments(cold_tree)
ck('new cold worker protocol agrees unchanged outer',cg['PLAN_SCHEMA']=='ROOT-and-support-ordering-worker-plan-v1' and
   cg['WORKER_SCHEMA']==ng['WORKER_RECEIPT_SCHEMA'])
ck('new cold exact input capsule SHA literal',h['input_capsule']['sha256'] in cold_text)
ck('input capsule remains unauthorized Source metadata',load(h['input_capsule']['path'])['actual_execution_authorized'] is False)
design=load(h['prospective_design']['path'])
ck('Root complete fixed40 and10input design not runtime-fourguard substitution',len(design['schedule'])==40 and design['distinct_inputs']==10 and
   design['structural_groups']==8 and design['total_actuals']==40 and design['actual_execution_authorized'] is False)
ck('Root retained failures/no restart/no grammar changes explicit','ALL' in design['failure_policy'] and 'No scientific implementation changes' in design['intervention'])
ck('current protocols remain percase exactfour guard',"len(ids)==4 and len(set(ids))==4" in texts['once_runner'] and
   "{(m,o) for m in KINDS for o in ORDERINGS}" in texts['once_runner'])
ck('future all40 plan/grant coverage is a separate Root external gate',True,
   'The unchanged runtime authenticates one per-case four-arm declaration. It does not independently certify the global ten-case schedule; prospective/full grant peers must cover all40 subjects before first launch.')

audit=write('raw-Source-delta-audit-v1.json',dict(schema='frozen-fol-suite-once-independent-delta-audit-v1',source_only=True,
            scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
            author_identity='/root/receiver_driver_review',reviewer_identity='/root/conventional_control_review',
            handoff=pin(handoff_path),source_contract=pin(contract_path),API=h['API'],sources=sources,parents=parents,
            retained_callable_regions=retained,checks=checks,check_count=len(checks),mismatch_count=0,
            complete_raw_diffs=diffs,actual_inert_patch_directions=patches))
receipt=write('typed-Source-review-v1.json',dict(schema='and-support-once-typed-Source-review-v1',scope='and-support-once-Source',
            source_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
            author_identity='/root/receiver_driver_review',reviewer_identity='/root/conventional_control_review',
            sources=sources,source=sources['once_runner'],source_contract=pin(contract_path),API=h['API'],handoff=pin(handoff_path),
            immediate_parent_review=pin(immediate_peer),genuine_inherited_grandparent_review=pin(grandparent_peer),parents=parents,
            input_capsule=h['input_capsule'],prospective_design=h['prospective_design'],
            no_current_helper_point_symbolic_Source_reaudit=True,
            ancestry=dict(authored_inherited_grandparent_outer=True,authored_current_helper_and_symbolic=True,
                          authored_immediate_delta_review=True,new_intake_identity_delta_author_distinct=True,
                          not_self_certifying_unchanged_inherited_implementation=True),
            audit=audit,review_Source=pin(Path(__file__)),check_count=len(checks),mismatch_count=0,
            compile_without_evaluation_count=2,actual_F0_patch_directions=4,
            project_imports=0,native_calls=0,model_calls=0,solver_calls=0,compiler_calls=0,search_calls=0,
            codec_calls=0,renderer_calls=0,fixture_calls=0,actual_launches=0,
            findings=[dict(id='EXACT_IDENTITY_DELTA',severity='evidence',finding='New outer differs only in VERSION and exact COLD_PIN; every callable body raw/AST identical. New observer differs only in VERSION and exact current runner SHA; whole inverse equality and independent inert patches checked.'),
                      dict(id='UNCHANGED_OPERATIVE_PROTOCOL',severity='scope',finding='Original18/7schemas, four review roles, per-casefourfactorial guards, strictJSON/parser/Python custody, positive180/terminal210,1GiB separate Darwin peaks,128MiB result, marker/argv/reap/group/EOF/permanent reappearance veto and failure handling are unchanged. Their semantics rely on the scoped prior genuine review chain.'),
                      dict(id='GLOBAL_SUITE_RELEASE_GATE',severity='scope',finding='Library separately reviews cold/full capsule/composition; Root and full prospective/final-grant peers must cover all40 subjects and all10 frozeninputs. This Source receipt does not authorize any case, activate grants, alter the scientific24-module closure or accept outcomes.')],
            limitations=[
                'Reviewer authored inherited grandparent outerV2, current helper/symbolic and earlier protocol code. Immediate Receiver delta was reviewed in4f05 with genuine grandparent Receiverd1fed relied upon. This new distinct review only covers the frozen intake identity/pin changes; no self Source certificate of inherited semantics.',
                'Current helper/point/symbolic scientific Sources are unchanged dependencies, not independently re-audited here. Their genuine Source peer84c4 remains separate. No source/plan/actual/suite outcome is accepted by code execution.',
                'Raw/AST, two compile-without-evaluation and four genuine inert text-patch directions only; no project/target/native/Model/compiler/solver/codec/search/renderer/fixture import/evaluation, program decoding, grant or actual.',
                'Runtime review descriptor containment is custody rather than automatic scope/ancestry validation. The same four schemas and expected reviewer map remain. New exact cold/outer/observer and full40/currentinput/closure/declaration/plan subjects require independent external Root release gates.',
                'Original parent Source-entry180positive known exit/210terminal clocks exclude separately observed observer/interpreter prelude. Conservative separate Darwin worker+native highwaters are not simultaneous live aggregate memory or an OS-enforced cap; outer/observer RAM excluded.',
                'Aggregate-memory or earlier failures skip the later final outer whole Python/source loop. Retain conditional custody for diagnostics and no posthoc salvage; permanent no-signal-after-absence/reappearance veto unchanged.',
                'No resource fit/proof/native correctness/RL/GCTS advantage/statistical generalization/ten independent groups or goal completion follows. Ten frozen inputs include two linked renames across eight structural groups; all40 outcomes must remain in denominator.']))
handoff_pin=write('handoff-v1.json',dict(schema='frozen-fol-suite-once-peer-handoff-v1',source_only=True,scientific_calls=0,
                  scientific_acceptance=False,actual_execution_authorized=False,receipt=receipt,audit=audit,
                  sources=sources,source_contract=pin(contract_path)))
print(json.dumps(handoff_pin,sort_keys=True))
