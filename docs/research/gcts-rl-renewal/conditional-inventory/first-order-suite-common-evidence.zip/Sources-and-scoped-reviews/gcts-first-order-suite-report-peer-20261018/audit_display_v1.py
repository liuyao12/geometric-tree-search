from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import collections,gc,gzip,hashlib,json,re

D=Path('/private/tmp/gcts-first-order-suite-report-peer-20261018')
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/first-order-suite-progress-20261018')
PUB=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
CP=Path('/private/tmp/gcts-and-support-comparison-peer-20261018/retained-comparison-data-v1.json')
checks=[];counts=collections.Counter()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def ck(n,x,detail=None):
 checks.append(dict(check=n,passed=bool(x),detail=detail))
 if not x:raise AssertionError(n)
def emit(n,v):
 p=D/n;p.write_text(json.dumps(v,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n');return desc(p)
class Node:
 def __init__(self,t='root',a=None):self.tag=t;self.attrs=dict(a or []);self.children=[]
 def text(self):return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
 def nodes(self):
  yield self
  for c in self.children:
   if isinstance(c,Node):yield from c.nodes()
 def find(self,tag=None,cls=None):return [n for n in self.nodes() if (tag is None or n.tag==tag) and (cls is None or cls in n.attrs.get('class','').split())]
 def direct(self,tag):return [c for c in self.children if isinstance(c,Node) and c.tag==tag]
class DOM(HTMLParser):
 void={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
 def __init__(self,text):
  super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(text);self.close()
 def handle_starttag(self,t,a):
  n=Node(t,a);self.stack[-1].children.append(n)
  if t not in self.void:self.stack.append(n)
 def handle_startendtag(self,t,a):self.stack[-1].children.append(Node(t,a))
 def handle_endtag(self,t):
  for j in range(len(self.stack)-1,0,-1):
   if self.stack[j].tag==t:self.stack=self.stack[:j];return
 def handle_data(self,data):self.stack[-1].children.append(data)
def mathword(n):
 s=n.text().strip();ck('MathJax inline delimiters',s.startswith('\\(') and s.endswith('\\)'));return s[2:-2]
# A restricted reader of displayed TeX, not a formula generator or proof checker.
# It only parses the actual forall/imp/predicate/variable notation in these saved pages.
def parse_formula(tex):
 tex=tex.replace('\\left','').replace('\\right','').replace('\\;','')
 toks=re.findall(r'\\forall|\\Rightarrow|\\rightarrow|[A-Za-z]+|[(),]',tex)
 if ''.join(toks)!=re.sub(r'\s+','',tex):raise ValueError('unexpected displayed formula token: '+tex)
 at=0
 def get():
  nonlocal at
  x=toks[at];at+=1;return x
 def atom():
  x=get()
  if x=='\\forall':
   variable=get();return ['all',variable,atom()]
  if x=='(':
   f=expr()
   if get()!=')':raise ValueError('display formula parenthesis')
   return f
  if x not in ('P','Q','R') or get()!='(':raise ValueError('display predicate syntax')
  args=[]
  if toks[at]!=')':
   while True:
    args.append(['var',get()])
    if toks[at]!=',':break
    get()
  if get()!=')':raise ValueError('display term parenthesis')
  return ['pred',x,args]
 def expr():
  f=atom()
  if at<len(toks) and toks[at] in ('\\Rightarrow','\\rightarrow'):
   get();f=['imp',f,expr()]
  return f
 f=expr()
 if at!=len(toks):raise ValueError('trailing display formula')
 return f

def labeled_pre(node,label):
 result=[]
 for d in node.find('details'):
  s=d.direct('summary')
  if s and s[0].text()==label:
   p=d.direct('pre');ck('one literal pre for '+label,len(p)==1);result.append(json.loads(p[0].text()))
 ck('exact one '+label,len(result)==1);return result[0]
def leading_nodes(cell):
 out=[]
 for x in cell.children:
  if isinstance(x,Node) and x.tag=='details':break
  out.append(x)
 return out
def lead_text(cell):return ''.join(x if isinstance(x,str) else x.text() for x in leading_nodes(cell))
def lead_find(cell,tag):return [n for x in leading_nodes(cell) if isinstance(x,Node) for n in x.nodes() if n.tag==tag]
def tbody_rows(table):return table.direct('tbody')[0].direct('tr')
def formula_spans(node):return node.find('span','sr-math')
def check_table(table,lines,premises,definitions,labels,ess,scope,label):
 rows=tbody_rows(table);ck(label+' full row count',len(rows)==len(lines))
 for j,(tr,cmd) in enumerate(zip(rows,lines)):
  counts['displayed_proof_rows']+=1
  cells=tr.direct('td');ck(label+str(j)+' three cells',len(cells)==3)
  ck(label+str(j)+' exact row ID',tr.attrs['id']==scope+'-line-'+str(j))
  ck(label+str(j)+' one-based display',cells[0].children[0]==str(j+1))
  ck(label+str(j)+' retained essential highlight',('sr-essential' in tr.attrs.get('class','').split())==(j in ess))
  ff=formula_spans(cells[1]);ck(label+str(j)+' one formula',len(ff)==1)
  ck(label+str(j)+' literal formula LaTex AST',canon(parse_formula(mathword(ff[0])))==canon(cmd['formula']))
  ck(label+str(j)+' full literal command',canon(labeled_pre(tr,'Literal command'))==canon(cmd))
  english=lead_text(cells[2]);links=lead_find(cells[2],'a');rule=cmd['rule']
  if rule=='axiom':ck(label+str(j)+' English AX name',english=='Use the given theory premise '+cmd['name']+'.')
  elif rule=='instantiate':
   ck(label+str(j)+' English UI licence',english.startswith('Introduce the universal-instantiation license for ') and english.endswith('.') and ' at term ' in english)
   m=[x for x in lead_find(cells[2],'span') if 'sr-math' in x.attrs.get('class','').split()]
   ck(label+str(j)+' English actual UI universal/term',len(m)==2 and canon(parse_formula(mathword(m[0])))==canon(cmd['universal']) and canon(parse_term(mathword(m[1])))==canon(cmd['term']))
   ck(label+str(j)+' no fabricated UI prior read',links==[])
  elif rule=='generalize':
   ck(label+str(j)+' English actual GEN source',[x.attrs['href'] for x in links]==['#'+scope+'-line-'+str(cmd['source'])] and english.startswith('Universally generalize line '+str(cmd['source']+1)+' in ') and 'native checker supplies the scope side condition.' in english)
   m=[x for x in lead_find(cells[2],'span') if 'sr-math'in x.attrs.get('class','').split()];ck(label+str(j)+' exact GEN variable',len(m)==1 and mathword(m[0])==cmd['variable'])
  elif rule=='mp':ck(label+str(j)+' English ordered MP reads',[x.attrs['href'] for x in links]==['#'+scope+'-line-'+str(cmd['implication']),'#'+scope+'-line-'+str(cmd['antecedent'])] and english=='Apply the implication on line '+str(cmd['implication']+1)+' to line '+str(cmd['antecedent']+1)+'.')
  elif rule=='assumption':
   ck(label+str(j)+' English exact assumption port',english.startswith('Use local input '+str(cmd['index']+1)+', whose declared formula is '))
   m=[x for x in lead_find(cells[2],'span') if 'sr-math'in x.attrs.get('class','').split()];ck(label+str(j)+' exact assumption formula',len(m)==1 and canon(parse_formula(mathword(m[0])))==canon(premises[cmd['index']]))
  elif rule=='block':
   target=labels[cmd['name']]
   ck(label+str(j)+' English exact block/ordered sources',[x.attrs['href'] for x in links]==['#'+target]+['#'+scope+'-line-'+str(i) for i in cmd['inputs']] and english.endswith(', in the recorded port order.'))
   details=[n for n in tr.find('details') if n.direct('summary') and n.direct('summary')[0].text()=='Ordered lemma input ports'];ck(label+str(j)+' ordered port table present',len(details)==1)
   portrows=tbody_rows(details[0].find('table')[0]);ps=definitions[cmd['name']]['premises'];ck(label+str(j)+' exact complete port count',len(portrows)==len(cmd['inputs'])==len(ps))
   for port,(pr,source,premise) in enumerate(zip(portrows,cmd['inputs'],ps)):
    cc=pr.direct('td');ck(label+str(j)+' port'+str(port)+' exact ordinal/index',cc[0].text()==str(port+1) and cc[1].find('a')[0].attrs['href']=='#'+scope+'-line-'+str(source))
    ck(label+str(j)+' port'+str(port)+' declared and actual formula',canon(parse_formula(mathword(formula_spans(cc[2])[0])))==canon(premise) and canon(parse_formula(mathword(formula_spans(cc[3])[0])))==canon(lines[source]['formula']))
    counts['ordered_port_rows']+=1
  elif rule=='tautology':ck(label+str(j)+' exact English tautology',english=='Use a propositional tautology, as named by this recorded rule.' and links==[])
  elif rule=='refl':ck(label+str(j)+' exact English reflexivity',english=='Introduce equality of a term with itself.' and links==[])
  elif rule=='eq_subst':
   ck(label+str(j)+' English equality licence',english.startswith('Introduce the equality-substitution license with placeholder ') and ' and formula context ' in english and links==[])
   m=[x for x in lead_find(cells[2],'span') if 'sr-math' in x.attrs.get('class','').split()]
   ck(label+str(j)+' exact equality placeholder/context',len(m)==2 and parse_name(mathword(m[0]))==cmd['variable'] and canon(parse_formula(mathword(m[1])))==canon(cmd['template']))
  else:raise ValueError('unexpected recorded rendered rule '+rule)

# Independent limited displayed-TeX reader, using literal declaration signatures.
FUNS={};PREDS={}
def tokens(tex):
 text=tex.replace('\\left','').replace('\\right','').replace('\\;','').replace('\\,','')
 text=re.sub(r'\\operatorname\{([A-Za-z][A-Za-z0-9]*)\}',lambda m:m.group(1),text)
 ts=re.findall(r'\\forall|\\Rightarrow|\\rightarrow|\\neg|\\land|\\lor|\\bot|[A-Za-z][A-Za-z0-9]*|[(),=]',text)
 if ''.join(ts)!=re.sub(r'\s+','',text):raise ValueError('unhandled literal display token '+text)
 return ts
class FormulaReader:
 def __init__(self,ts):self.ts=ts;self.i=0
 def peek(self):return self.ts[self.i]if self.i<len(self.ts)else None
 def get(self):x=self.peek();self.i+=1;return x
 def expect(self,x):
  if self.get()!=x:raise ValueError('display expected '+x)
 def term_after_name(self,name):
  args=[]
  if self.peek()=='(':
   self.get()
   if self.peek()!=')':
    while True:
     args.append(self.term())
     if self.peek()!=',':break
     self.get()
   self.expect(')')
  if name in FUNS:return ['fun',name,args]
  if args:raise ValueError('undeclared displayed function '+name)
  return ['var',name]
 def term(self):return self.term_after_name(self.get())
 def atom(self):
  x=self.get()
  if x=='\\forall':return ['all',self.get(),self.atom()]
  if x=='\\neg':return ['not',self.atom()]
  if x=='\\bot':return ['bot']
  if x=='(':
   f=self.expr();self.expect(')');return f
  if x in PREDS:
   args=[]
   if self.peek()=='(':
    self.get()
    if self.peek()!=')':
     while True:
      args.append(self.term())
      if self.peek()!=',':break
      self.get()
    self.expect(')')
   return ['pred',x,args]
  lhs=self.term_after_name(x);self.expect('=');return ['eq',lhs,self.term()]
 def expr(self):
  f=self.atom()
  if self.peek()in('\\Rightarrow','\\rightarrow','\\land','\\lor'):
   op=self.get();f=[{'\\Rightarrow':'imp','\\rightarrow':'imp','\\land':'and','\\lor':'or'}[op],f,self.expr()]
  return f
 def finish(self,kind):
  v=self.expr()if kind=='formula'else self.term()
  if self.i!=len(self.ts):raise ValueError('trailing display tokens')
  return v
def parse_formula(tex):return FormulaReader(tokens(tex)).finish('formula')
def parse_term(tex):return FormulaReader(tokens(tex)).finish('term')
def parse_name(tex):
 ts=tokens(tex)
 if len(ts)!=1:raise ValueError('displayed name must be singular')
 return ts[0]
def statement(tex):
 left,right=tex.split('\\vdash');left=left.strip().replace('\\;','').strip()
 if not left.startswith('\\{')or not left.endswith('\\}'):raise ValueError('statement premise braces')
 left=left[2:-2];parts=[];depth=0;start=0
 for i,c in enumerate(left):
  if c=='(':depth+=1
  elif c==')':depth-=1
  elif c==','and depth==0:parts.append(left[start:i]);start=i+1
 parts.append(left[start:]);return [parse_formula(p)for p in parts if p.strip()],parse_formula(right)
M=json.loads((ROOT/'report-draft-assets-v3.json').read_bytes());ck('exact currentv3 index',desc(ROOT/'report-draft-assets-v3.json')['sha256']=='c1ac5ed8f43b1084087bf352cc5e9e041cc400b62238fa1bcb5e675526d50156')
for p in M['assets']:ck('whole frozen asset '+Path(p['path']).name,desc(p['path'])==p)
records={r['invocation_id']:r for r in json.loads(Path('/private/tmp/gcts-first-order-suite-comparison-peer-20261018/retained-comparison-data-v2.json').read_bytes())['rows']}
main=(PUB/'first-order-suite.html').read_text();md=DOM(main).root;summary=json.loads((PUB/'first-order-suite-summary.json').read_bytes());admission=json.loads((PUB/'first-order-suite-admission.json').read_bytes());capsule=json.loads((PUB/'first-order-suite-inputs.json').read_bytes());specs={s['id']:s for s in capsule['receivers']}
ck('summary full40 actuals literal copy',canon(summary['actuals'])==canon(admission['actuals']) and len(summary['actuals'])==40)
ck('summary exactoutcome counts',summary['admitted_proof_instances']==12 and summary['inventory_stops']==16 and summary['search_budget_stops']==12 and summary['solved_primary_groups']==2 and summary['primary_groups']==8 and summary['solved_inputs_including_renamings']==3 and summary['correlated_renamings']==2 and summary['all_within_profile']is True and summary['all_available_same_case_preimages_equal']is True and summary['new_RL_training']is False)
ck('Rootadmission copy exact',desc(PUB/'first-order-suite-admission.json')==dict(path=str(PUB/'first-order-suite-admission.json'),sha256=summary['Root_admission']['sha256'],bytes=summary['Root_admission']['bytes']))
for public,source in [('first-order-suite-declaration.json',ROOT/'experiment-declaration-v1.json'),('first-order-suite-design.json',ROOT/'prospective-design-v1.json'),('first-order-suite-runtime-closure.json',ROOT/'runtime-closure-v1.json'),('first-order-suite-inputs.json',ROOT/'input-capsule-v1.json')]:ck('whole publiccopy '+public,Path(source).read_bytes()==(PUB/public).read_bytes())
#40 exact displayed outcome/cost rows.
ct=next(n for n in md.nodes()if n.attrs.get('id')=='costs').find('table')[0];trs=tbody_rows(ct);ck('all40 displaycostrows',len(trs)==40)
ordered=sorted(records.values(),key=lambda r:r['order'])
for tr,r in zip(trs,ordered):
 cs=[c for c in tr.children if isinstance(c,Node)and c.tag in('td','th')];ss=[c.text()for c in cs];label=('GCTS'if r['mode']=='fixed'else'Symbolic')+' · '+('legacy'if r['search_ordering']=='legacy'else'shared support')
 ck(r['invocation_id']+' costidentity',ss[0]=='\\('+str(r['order'])+'\\)' and ss[1]==r['receiver_id'][-3:]+' '+label)
 ck(r['invocation_id']+' outcome',ss[2]=={'native_proof_discovered':'Proof','unknown_native_inventory':'Inventory stop','unknown_search_budget':'Search budget'}[r['status']])
 if r['search']:
  work=r['search']['metrics'].get('attempts',r['search']['metrics'].get('prefix_extensions'));unit='placements'if r['mode']=='fixed'else'row extensions'
  ck(r['invocation_id']+' exactworkseconds',ss[3]=='\\('+str(work)+'\\) '+unit and ss[4]=='\\('+format(r['search']['seconds'],'.3f')+'\\)')
 else:ck(r['invocation_id']+' nofabricatedsearch',ss[3]==ss[4]=='Not reached')
 ck(r['invocation_id']+' fullcostmemorybytes',ss[5]=='\\('+format(r['external_terminal_seconds'],'.3f')+'\\)' and ss[6]=='\\('+format(r['worker_plus_native_MiB'],'.1f')+'\\)' and ss[7]=='\\('+format(r['raw_result']['bytes']/1048576,'.2f')+'\\)')
 name='fol-'+r['receiver_id'][-3:]+'-'+r['mode']+'-'+r['search_ordering'].replace('_','-')+'-result.json.gz';ck(r['invocation_id']+' exactdownloadlink',cs[7].find('a')[0].attrs['href']==name and (PUB/name).is_file())
# Matrix andall10 statements, no solving.
mt=md.find('table','matrix')[0];mrs=tbody_rows(mt);ck('matrixall10rows',len(mrs)==10)
for i,tr in enumerate(mrs,1):
 cid='prospective-fol-20261018-%03d'%i;case='case-%03d'%i;cells=[c for c in tr.children if isinstance(c,Node)and c.tag in('th','td')];ck(case+' matrixinput',cells[0].find('a')[0].attrs['href']=='#'+case)
 for cell,(mode,order)in zip(cells[1:],[('fixed','legacy'),('fixed','and_support'),('symbolic','legacy'),('symbolic','and_support')]):
  r=next(r for r in ordered if r['receiver_id']==cid and r['mode']==mode and r['search_ordering']==order);cls={'native_proof_discovered':'proof','unknown_native_inventory':'inventory','unknown_search_budget':'search-stop'}[r['status']];href='fol-%03d-%s-%s-proof.html'%(i,mode,order.replace('_','-'))if cls=='proof'else'#'+case
  ck(case+mode+order+' matrixexact',cell.attrs['class']==cls and cell.find('a')[0].attrs['href']==href)
 node=next(n for n in md.nodes()if n.attrs.get('id')==case);spec=specs[cid];FUNS=spec['theory']['functions'];PREDS=spec['theory']['predicates'];tex=re.search(r'\\\[(.*?)\\\]',node.text(),re.S).group(1);ps,concl=statement(tex)
 ck(case+' fullstatementAST',canon(ps)==canon(list(spec['theory']['axioms'].values()))and canon(concl)==canon(spec['target']))
 ck(case+' group/renamehonest',('Correlated renaming'in node.text())==(i in(9,10)))
#12 complete proof readers, every body/port/scalarpoint value.
proof_details=[]
for pr in M['proof_readers']:
 r=records[pr['invocation_id']];name=pr['file'];html=(PUB/name).read_text();dom=DOM(html).root;data=json.loads(Path(r['raw_result']['path']).read_bytes());spec=data['declaration'];FUNS=spec['theory']['functions'];PREDS=spec['theory']['predicates'];proof=data['outputs']['search']['proof'];inventory=data['outputs']['register'];ob=data['outputs']['essential_ancestry'];model=data['outputs']['model'];search=data['outputs']['search'];defs={d['name']:d for d in inventory['native_blocks']};metas={d['name']:d for d in inventory['definitions']};sections=dom.find('details','sr-definition');labels={};by_definition={}
 ck(name+' allcompletebodies',len(sections)==len(defs))
 for sec in sections:
  packet=labeled_pre(sec,'Literal registered definition and metadata');dn=packet['definition']['name'];labels[dn]=sec.attrs['id'];by_definition[dn]=sec
  ck(name+dn+' fullbodymetadata',canon(packet['definition'])==canon(defs[dn])and canon(packet['metadata'])==canon(metas[dn]))
  ck(name+dn+' summaryconclusion',canon(parse_formula(mathword(formula_spans(sec.direct('summary')[0])[0])))==canon(defs[dn]['conclusion']))
 ck(name+' allnamesdistinct',set(labels)==set(defs))
 rt=dom.find('table','sr-proof')[0];scope=tbody_rows(rt)[0].attrs['id'].rsplit('-line-',1)[0]
 check_table(rt,proof,[],defs,labels,set(ob['root']['essential_rows']),scope,name+' root ')
 for dn,sec in by_definition.items():
  ts=sec.find('table','sr-proof');ck(name+dn+' fulltablepresent',len(ts)==1)
  check_table(ts[0],defs[dn]['proof'],defs[dn]['premises'],defs,labels,set(ob['ground_definition_summaries'][dn]['essential_rows']),sec.attrs['id'],name+' '+dn+' ');counts['registered_bodies']+=1
 tiles=dom.find('details','sr-tile');rs=dom.find('div','sr-tile-row');expected_points=len(proof)*(2+model['arity']);ck(name+' actualderivedtilesrows',len(tiles)==expected_points and len(rs)==len(proof)==12)
 indexed={tuple(p['key']):p for p in model['placements']};selected={tuple(k)for k in search['placements']};seen=set();numeric=0
 for tile in tiles:
  packet=labeled_pre(tile,'Full selected placement packet');key=tuple(packet['key']);candidate=indexed[key];seen.add(key);ck(name+str(key)+' fullactualpacket',key in selected and canon(packet)==canon(candidate));title='C'if key[1]==0 else'G'if key[1]==1 else'I'+str(key[1]-1);ck(name+str(key)+' glyphrole',tile.direct('summary')[0].find('strong')[0].text()==title and tile.find('svg')[0].attrs['aria-label']=='Schematic point placement '+title);color='#2865a5'if key[1]==0 else'#8b52a5'if key[1]==1 else'#b5771a';ck(name+str(key)+' glyphcolor',tile.find('svg')[0].find('rect')[0].attrs['stroke']==color)
  trs=tbody_rows(tile.direct('table')[0]);wanted=[('base occupancy',p,v,'')for p,v in candidate['occupancy']]
  for p,v in candidate['marks']:
   x,y=p;layer,color=('formula','#25845b')if x%4==0 and y>=100 else('command','#2865a5')if x%4==1 and y>=100 else('mode','#8b52a5')if x%4==2 and y==90 else('source','#b5771a')if x%4==2 and y>=100 else('other','#60717e');wanted.append((layer+' marking',p,v,color))
  ck(name+str(key)+' entiret_mrowcount',len(trs)==len(wanted))
  for tr,(layer,p,v,color)in zip(trs,wanted):
   cc=tr.direct('td');point='('+','.join(map(str,p))+')';value=str(v)+'/12'if layer=='base occupancy'else str(v);ck(name+str(key)+str(p)+' exactpointvalue',cc[0].text()==layer and mathword(formula_spans(cc[1])[0])==point and mathword(formula_spans(cc[2])[0])==value)
   if color:ck(name+str(key)+str(p)+' markinglayercolor',cc[0].find('span')[0].attrs['style']=='background:'+color)
   numeric+=1
  if candidate['kind']=='lemma_input':ck(name+str(key)+' exactsourceEnglish','Reads root line '+str(candidate['source']+1)+'.'in tile.text())
  if candidate['kind']=='unused_input':ck(name+str(key)+' literalunusedsentinel','Unused input filler; its source sentinel is 'in tile.text())
  counts['selected_tiles']+=1
 ck(name+' noneomittedduplicated',seen==selected and len(seen)==len(tiles));counts['point_value_rows']+=numeric
 ck(name+' pointglyphlimits','square is a display glyph'in html and'No rotation'in html and'12/12=1'in html)
 ck(name+' exactrawdownload',name.replace('-proof.html','-result.json.gz')in html)
 proof_details.append({'file':name,'invocation_id':r['invocation_id'],'root_rows':len(proof),'registered_bodies':len(defs),'lemma_rows':sum(len(x['proof'])for x in defs.values()),'tiles':len(tiles),'point_value_rows':numeric,'arity':model['arity']})
 print('DISPLAY CHECKED',name,flush=True);del data,model,dom;gc.collect()
#Alllocal ownedlinks and anchors; pending packaging links explicitly excluded.
page_names=['first-order-suite.html','reader.html','and-support-ordering.html']+[p['file']for p in M['proof_readers']];doms={n:DOM((PUB/n).read_text()).root for n in page_names};ids={n:{x.attrs['id']for x in dom.nodes()if'id'in x.attrs}for n,dom in doms.items()};pending={'first-order-suite-evidence-manifest.json','first-order-suite-common-evidence.zip'}|{'first-order-suite-'+x+'-review.json'for x in ['data','resource','comparison','report']};link_notes=[]
for name,dom in doms.items():
 allids=[x.attrs['id']for x in dom.nodes()if'id'in x.attrs];ck(name+' uniqueIDs',len(allids)==len(set(allids)));ck(name+' MathJaxloaded',any(x.tag=='script'and x.attrs.get('src')=='https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js'for x in dom.nodes()))
 ck(name+' noUnicodemathsubstitution',not any(c in(PUB/name).read_text()for c in ['∀','⇒','⊢','∧','∈']))
 for a in dom.find('a'):
  href=a.attrs.get('href','');u=urlsplit(href)
  if u.scheme or u.netloc:continue
  target=u.path or name
  if target in pending:link_notes.append({'page':name,'href':href,'scope':'PENDING_FINAL_PACKAGE'});continue
  if target in ids and u.fragment:ck(name+' anchor '+href,u.fragment in ids[target])
  if target.startswith(('fol-','first-order-suite'))or(name!='reader.html'and target in page_names):ck(name+' actualfile '+href,(PUB/target).is_file())
reader=doms['reader.html'];card=next(n for n in reader.nodes()if n.attrs.get('id')=='first-order-suite');ck('readertruthfulcurrent','LATEST' in card.text()and'2/8'in card.text()and'40'in card.text());ck('oldexperimentnotice','first-order-suite.html'in(PUB/'and-support-ordering.html').read_text())
ck('maincounts_scope_limit_words',all(s in main for s in ['2/8','3/10','before Model or search','not an official TPTP','blind holdout','no new RL','first-position frequencies','3,3,2,2','row-Join setting','not a cap on the total proposal pool','no solve-rate advantage','9','depth','Native','128','4','conservative sum']))
ck('immutablepureRendererpin',desc(M['pure_renderer']['path'])==M['pure_renderer'])
result={'schema':'first-order-suite-human-raw-display-audit-v1','scientific_replays':0,'draft_assets':desc(ROOT/'report-draft-assets-v3.json'),'checks':checks,'counts':dict(counts),'proof_details':proof_details,'pending_link_notes':link_notes,'summary':{'checks':len(checks),'mismatches':sum(not x['passed']for x in checks)}}
p=D/'raw-display-audit-v1.json';p.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print('DONE',json.dumps({'audit':desc(p),'summary':result['summary'],'counts':dict(counts)}),flush=True)
