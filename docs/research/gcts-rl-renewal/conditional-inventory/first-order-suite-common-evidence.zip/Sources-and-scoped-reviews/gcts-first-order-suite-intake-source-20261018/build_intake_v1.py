"""Author only literal Source successors and static metadata; never load targets."""
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

OUT = Path('/private/tmp/gcts-first-order-suite-intake-source-20261018')
OLD = Path('/private/tmp/gcts-and-support-cold-source-20261018')
ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
AUTHOR = '/root/receiver_driver_review'
CHECKS = []


def raw(path):
    path = Path(path)
    assert not (path.stat().st_flags & 0x40000000), str(path)
    return path.read_bytes()


def ref(path):
    path = Path(path)
    value = raw(path)
    return dict(path=str(path), sha256=hashlib.sha256(value).hexdigest(), bytes=len(value))


def put(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + '\n')
    return ref(path)


def check(name, condition, detail=None):
    assert condition, name
    CHECKS.append(dict(check=name, passed=True, detail=detail))


def read_json(path):
    return json.loads(raw(path))


def pinned(pin):
    check('raw pin: ' + pin['path'], ref(pin['path']) == pin)


def assigned(source, name):
    tree = ast.parse(source)
    matches = [node for node in tree.body if isinstance(node, ast.Assign) and
               any(isinstance(t, ast.Name) and t.id == name for t in node.targets)]
    assert len(matches) == 1, name
    return ast.get_source_segment(source, matches[0])


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after, 1)


BASE = dict(author_identity=AUTHOR, source_only=True, scientific_calls=0,
            scientific_acceptance=False, actual_execution_authorized=False,
            own_Source_certificate=False)
parent_map = read_json(OLD / 'generated-Source-map-v1.json')
parent_api = read_json(OLD / 'API-v1.json')
parents = parent_map['sources']
for pin in parents.values():
    pinned(pin)
capsule = ref(ROOT / '.gcts-active/first-order-suite-progress-20261018/input-capsule-v1.json')
check('exact frozen input capsule', capsule['sha256'] ==
      '1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0' and capsule['bytes'] == 22422)
design = ref(ROOT / '.gcts-active/first-order-suite-progress-20261018/prospective-design-v1.json')
check('exact prospective Root design', design['sha256'] ==
      '3b324a86de79a408a4d1317d94c6e03a807e4367afaf15f24cf0ec5e2288139f' and design['bytes'] == 25396)
current_closure = ref(ROOT / '.gcts-active/and-support-ordering-progress-20261018/runtime-closure-v1.json')
check('exact current scientific closure ancestry', current_closure['sha256'] ==
      '8246d2d2afdd3045067af2ae12b45f9fe6619451bbd33fd47e6b09d0ae5f06b8')
closure = read_json(current_closure['path'])
check('complete 22 project aliases unchanged', parent_map['expected_project_sources'] == closure['project_sources'] and
      len(closure['project_sources']) == 22)
check('complete 24 materialized aliases', len(closure['materialized_aliases']) == 24 and
      closure['additional_nonseed_components']['receiver_driver'] == parents['receiver_driver'])
for pin in closure['materialized_aliases'].values():
    pinned(pin)
check('unchanged scientific driver 5f73835', parents['receiver_driver']['sha256'] ==
      '5f73835dfc9219f06f01206ebf6bbac5744eea582cbfb03deed42105f2ccacd0')
capsule_value = read_json(capsule['path'])
check('existing input declaration schema', capsule_value['schema'] == 'ROOT-closed-quantified-benchmark-declaration-v1')
check('ten unique ordinary receivers', len(capsule_value['receivers']) == 10 and
      len({s['id'] for s in capsule_value['receivers']}) == 10)
check('all input profiles unchanged', all(type(s['length']) is int and s['length'] == 12 and
      type(s['instantiation_rounds']) is int and s['instantiation_rounds'] == 2 for s in capsule_value['receivers']))
for pin in capsule_value['input_sources']:
    pinned(pin)
check('whole original specs literal equal capsule', [read_json(p['path']) for p in capsule_value['input_sources']] == capsule_value['receivers'])

replacements = {}
parent_text = {role: raw(pin['path']).decode() for role, pin in parents.items() if role != 'receiver_driver'}
new_names = dict(cold='frozen_fol_suite_cold_v1.py', once_runner='frozen_fol_suite_once_runner_v1.py',
                 terminal_observer='observe_frozen_fol_suite_runner_v1.py')
versions = dict(cold='frozen-fol-suite-intake-cold-v1', once_runner='frozen-fol-suite-intake-external-once-runner-v1',
                terminal_observer='frozen-fol-suite-intake-final-terminal-observer-v1')
sources = {'receiver_driver': parents['receiver_driver']}
for role in ('cold', 'once_runner', 'terminal_observer'):
    source = parent_text[role]
    pairs = [(assigned(source, 'VERSION'), 'VERSION = ' + repr(versions[role]))]
    if role == 'cold':
        pairs.append(('19fab9173cf52ebd9e0d5517fd4dbbb44ed9d72f3737676d9701fd6a4c8bde5d', capsule['sha256']))
    elif role == 'once_runner':
        pairs.append((assigned(source, 'COLD_PIN'), 'COLD_PIN = ' + repr(sources['cold'])))
    else:
        pairs.append((parents['once_runner']['sha256'], sources['once_runner']['sha256']))
    new = source
    for before, after in pairs:
        new = replace_once(new, before, after)
    (OUT / new_names[role]).write_text(new)
    sources[role] = ref(OUT / new_names[role])
    replacements[role] = pairs

region_reports = {}
patch_reports = []
for role in ('cold', 'once_runner', 'terminal_observer'):
    old = parent_text[role]
    new = raw(sources[role]['path']).decode()
    inverse = new
    for before, after in reversed(replacements[role]):
        inverse = replace_once(inverse, after, before)
    check(role + ': entire Source inverse byte equality', inverse == old)
    check(role + ': entire Source inverse AST equality', ast.dump(ast.parse(inverse), include_attributes=False) ==
          ast.dump(ast.parse(old), include_attributes=False))
    compile(new, sources[role]['path'], 'exec', dont_inherit=True)
    check(role + ': compile without evaluation', True)
    old_tree, new_tree = ast.parse(old), ast.parse(new)
    old_regions = {n.name: n for n in old_tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    new_regions = {n.name: n for n in new_tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    check(role + ': all callable region names retained', set(old_regions) == set(new_regions))
    records = []
    for name, old_node in old_regions.items():
        new_node = new_regions[name]
        a, b = ast.get_source_segment(old, old_node), ast.get_source_segment(new, new_node)
        same_raw = a == b
        same_ast = ast.dump(old_node, include_attributes=False) == ast.dump(new_node, include_attributes=False)
        expected = not (name == 'main' and role in ('cold', 'terminal_observer'))
        check(role + ':' + name + ': declared retained region', same_raw == expected and same_ast == expected)
        records.append(dict(name=name, parent_lines=[old_node.lineno, old_node.end_lineno],
                            source_lines=[new_node.lineno, new_node.end_lineno], raw_equal=same_raw, ast_equal=same_ast,
                            parent_sha256=hashlib.sha256(a.encode()).hexdigest(), source_sha256=hashlib.sha256(b.encode()).hexdigest()))
    region_reports[role] = records
    for direction, a, b in (('forward', old, new), ('inverse', new, old)):
        patch = ''.join(difflib.unified_diff(a.splitlines(keepends=True), b.splitlines(keepends=True),
                                           fromfile='unit.py', tofile='unit.py', n=3))
        path = OUT / (role + '-' + direction + '-v1.patch')
        path.write_text(patch)
        with tempfile.TemporaryDirectory(prefix='inert-fol-intake-patch-', dir='/private/tmp') as directory:
            target = Path(directory) / 'unit.py'
            target.write_text(a)
            result = subprocess.run(['/usr/bin/patch', '--batch', '--fuzz=0', '-p0', '-i', str(path)],
                                    cwd=directory, capture_output=True, text=True)
            check(role + ': actual inert F0 ' + direction,
                  result.returncode == 0 and target.read_text() == b,
                  dict(exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
        patch_reports.append(dict(role=role, direction=direction, patch=ref(path), literal_result_equal=True))

newcold = raw(sources['cold']['path']).decode()
check('select_receiver whole raw helper unchanged',
      ast.get_source_segment(newcold, next(n for n in ast.parse(newcold).body if isinstance(n, ast.FunctionDef) and n.name == 'select_receiver')) ==
      ast.get_source_segment(parent_text['cold'], next(n for n in ast.parse(parent_text['cold']).body if isinstance(n, ast.FunctionDef) and n.name == 'select_receiver')))
for constant in ('PLAN_SCHEMA', 'PARENT_RUNTIME_CLOSURE', 'ORDERING_COMPONENT_SOURCES', 'COMPACT_MODEL_SOURCE'):
    check('cold literal constant unchanged: ' + constant, assigned(newcold, constant) == assigned(parent_text['cold'], constant))
newonce = raw(sources['once_runner']['path']).decode()
for constant in ('PLAN_SCHEMA', 'LIMITS', 'REVIEW_ROLES'):
    check('outer literal constant unchanged: ' + constant, assigned(newonce, constant) == assigned(parent_text['once_runner'], constant))
check('capsule unauthorised and no scientific calls', capsule_value['actual_execution_authorized'] is False and capsule_value['scientific_calls'] == 0)
check('operative parent closure lineage preserved', ast.literal_eval(next(n.value for n in ast.parse(newcold).body
      if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PARENT_RUNTIME_CLOSURE' for t in n.targets))) == parent_map['parent_runtime_closure'])
for role in sources:
    pinned(sources[role])

ancestry = dict(
    composition=ref('/private/tmp/gcts-and-support-composition-peer-20261018/typed-Source-review-v1.json'),
    once=ref('/private/tmp/gcts-and-support-once-peer-20261018/typed-Source-review-v1.json'),
    ordering=ref('/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json'))
audit = put('static-author-evidence-v1.json', dict(BASE, schema='frozen-fol-suite-intake-static-author-evidence-v1',
    evidence_kind='Author static evidence, not an independent Source certificate or runtime acceptance',
    checks=CHECKS, checks_passed=len(CHECKS), mismatch_count=0, regions=region_reports, patches=patch_reports,
    compile_without_evaluation_count=3, inert_patch_directions=6, sources=sources))
delta = put('Source-delta-v1.json', dict(BASE, schema='frozen-fol-suite-intake-Source-delta-v1',
    parents=parents, sources=sources, replacements={k:[dict(before=a, after=b) for a,b in v] for k,v in replacements.items()},
    entire_inverse_bytes_equal=True, entire_inverse_AST_equal=True, scientific_driver_byte_identical=True,
    project_module_count=22, component_count=2, operative_alias_count=24, scientific_aliases=closure['materialized_aliases'],
    regions=region_reports, patches=patch_reports, static_author_evidence=audit,
    semantic_change='Only exact ten-input capsule admission pin; no scientific algorithm, grammar, proof or resource policy change.'))
generated_map = put('generated-Source-map-v1.json', dict(BASE,
    schema='frozen-fol-suite-intake-generated-Source-map-v1', sources=sources,
    authored_sources={k:v for k,v in sources.items() if k != 'receiver_driver'}, parent_sources=parents,
    expected_project_sources=closure['project_sources'], expected_components=closure['additional_nonseed_components'],
    materialized_aliases=closure['materialized_aliases'], ordering_sources=parent_map['ordering_sources'],
    parent_runtime_closure=parent_map['parent_runtime_closure'], previous_current_runtime_closure=current_closure,
    input_capsule=capsule, prospective_design=design, schemas=parent_map['schemas'], review_roles=parent_map['review_roles']))
api = copy.deepcopy(parent_api)
api.update(BASE)
api.update(schema='frozen-fol-suite-intake-API-v1', sources=sources,
    input_capsule=capsule, prospective_design=design, parent_API=ref(OLD / 'API-v1.json'),
    schedule='Ten per-case declarations; each exactly four unique method-by-ordering subjects. Root separately freezes all40 global slots in the original input order and declared balanced arm order. This intake does not enforce the global40 schedule by itself.',
    closure_policy='All22 project Sources and both scientific components/24 materialized aliases byte-identical to8246 current closure, including original scientific driver5f73835. Only new cold/outer/observer Source pins and composition metadata change. The operative embedded parent_closure remains63fa;8246 is separate immediate ancestry.',
    authorship='Author of new intake successors also authored inherited AND composition, separate old qualification harness and frozen input-only corpus. No own Source certification. Library reviews new cold/input capsule; Control reviews new outer/observer delta with inherited-author overlap disclosed. Root alone owns closure, plans, grants and actuals.',
    source_state='Frozen Source-only intake for original ten prospective inputs; no evaluation, trial, fixture execution, grant or activation.',
    compatibility='All worker/once/authorization/epoch/result schemas, full field sets, review-role schemas and per-case4-arm validators retained literally. parent_structural_declaration remains the API field name and now binds the exact input capsule.',
    profile='Same12 rows/two UI catalog snapshots, full4-template inventory, compact Model/interned Reader,180work including successful output+worker exit/210terminal/1GiB conservative worker+CPP highwater sum/128MiB result and original log caps. Every outcome retained, no cap changes or case-result filter.')
api_pin = put('API-v1.json', api)
base_contract = dict(BASE, API=api_pin, delta=delta, static_author_evidence=audit, generated_Source_map=generated_map,
    input_capsule=capsule, prospective_design=design, previous_current_runtime_closure=current_closure,
    operative_parent_runtime_closure=parent_map['parent_runtime_closure'], expected_project_sources=closure['project_sources'],
    expected_scientific_components=closure['additional_nonseed_components'], materialized_aliases=closure['materialized_aliases'],
    prior_independent_Source_peers=ancestry,
    author_ancestry=api['authorship'],
    retained_verification=['Complete compiler admission/catalog and original4-template policy',
      'Complete registered definitions/interfaces/native blocks and every Model candidate/mark/initial state',
      'Global dead/forced/earliest-generation scheduler, complete fallback, exact rollback and unchanged primitive costs',
      'Actual selected proof and fresh whole Native request; raw whole finite t/m verification and row decode',
      'Full canonical result/Reader inverse and original resource/terminal/protocol custody'],
    callback_and_UNKNOWN_scope='No handler or callback change. Inherited owned scientific deadline may retain full UNKNOWN within closure210; delegated failures propagate. Unavailable or failed results remain failures/UNKNOWN, never mathematical refutations or salvaged proofs.',
    trusted_boundary='Pinned Python/bundled stdlib/OS loader and trusted metadata assumptions inherited. Source/function seals do not prove the whole OS. Aggregate-memory failure skips the later outer whole-source/Python final loop; worker custody is separate. Full observed resource highwaters are conservative separate peaks, not a hard live aggregate cap.',
    required_next=['Distinct new Source reviews, with inherited-author scope disclosed',
      'Root current full closure and ten exact per-case declarations/global40 schedule',
      'Distinct prospective plan review, then separately scoped max1 true authorizations and raw grant-delta review',
      'Only Root may execute40 prospective once-only sequential arms, all other agents idle; preserve every outcome'],
    scientific_claims='No theorem discovery, suite admission, runtime improvement, Native acceptance, proof validity or search coverage is established by author static evidence.')
required = ['schema','scope','author_identity','reviewer_identity','sources','source_contract','source_only',
            'source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings']
comp = dict(base_contract, schema='frozen-fol-suite-intake-composition-Source-contract-v1',
    sources={k:sources[k] for k in ('cold','receiver_driver')}, parents={k:parents[k] for k in ('cold','receiver_driver')},
    source_changes=['Cold VERSION and sole frozen declaration SHA19fab→exact capsule1a42; whole remaining Source bytes exact.',
      'Scientific driver5f73835 and all24 aliases byte-identical. select_receiver is entirely unchanged.',
      'API field parent_structural_declaration binds capsule; per-case4 validators unchanged, global40 custody belongs prospective Root plans.'],
    review_ABI=dict(schema='and-support-driver-cold-typed-Source-review-v1', scope='and-support-driver-cold-Source',
                    reviewer_identity='/root/conventional_library', required_fields=required))
comp_pin = put('composition-Source-contract-v1.json', comp)
once = dict(base_contract, schema='frozen-fol-suite-intake-once-Source-contract-v1',
    sources={k:sources[k] for k in ('once_runner','terminal_observer')}, parents={k:parents[k] for k in ('once_runner','terminal_observer')},
    source_changes=['Outer VERSION and COLD_PIN only; every callable body raw/AST identical.',
      'Observer VERSION and exact runner SHA only; entire main body reverse literal equality.',
      'No parser, LIMITS, authorization/review roles, source epoch, lifecycle, cleanup, reap, group or EOF policy change.'],
    inherited_scope=['Exclusive CONSUMED before one Popen, exact four cold arguments',
      'Strict whole finite parent JSON, duplicate/nonfinite rejection and raw full subject hashes',
      'Original180 positive output+known worker exit and210 terminal limits;1GiB conservative wait4 peak sum',
      'Full bounded log EOF and authoritative post-known-reap group absence',
      'No signal after latched group absence; permanent reappearance veto cannot be healed in cleanup',
      'Observer225 failure-only direct-child cleanup; residual group on failure needs Root inspection'],
    review_ABI=dict(schema='and-support-once-typed-Source-review-v1', scope='and-support-once-Source',
                    reviewer_identity='/root/conventional_control_review', required_fields=required))
once_pin = put('once-Source-contract-v1.json', once)
handoff = put('handoff-v1.json', dict(BASE, schema='frozen-fol-suite-intake-Source-handoff-v1',
    status='FROZEN_SOURCE_ONLY_REQUIRES_DISTINCT_REVIEW_NO_ACTIVATION', sources=sources,
    authored_sources={k:v for k,v in sources.items() if k != 'receiver_driver'},
    input_capsule=capsule, prospective_design=design, API=api_pin, composition_contract=comp_pin,
    once_contract=once_pin, delta=delta, static_author_evidence=audit, generated_Source_map=generated_map,
    authoring_source=ref(__file__), ancestry=ancestry,
    blockers=[], limits='No actual, native, scientific target, fixture or grant executed. Global40 schedule checked separately by Root and independent prospective peer.'))
print(json.dumps(dict(handoff=handoff, sources=sources, API=api_pin, composition_contract=comp_pin,
                     once_contract=once_pin, checks=len(CHECKS), scientific_calls=0), indent=2))
