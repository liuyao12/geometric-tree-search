"""Capture final outer-runner terminal time; no scientific imports or replay."""
import time
_NOW=time.monotonic_ns
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

VERSION = 'frozen-fol-suite-intake-final-terminal-observer-v1'


def need(value,message):
    if not value:raise ValueError(message)


def pin(path,raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def write_new(path,value):
    raw=json.dumps(value,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n'
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    except BaseException:
        raise


def main(plan_path):
    started=_NOW();path=Path(plan_path).resolve();raw=path.read_bytes()
    need(len(raw)<=16777216,'finite once plan');plan=json.loads(raw)
    need(plan['schema']=='ROOT-and-support-ordering-once-plan-v1','fixed once plan')
    need(pin(__file__,Path(__file__).read_bytes())==plan['observer'],'exact current observer Source')
    for role in ('runner','python'):
        d=plan[role];b=Path(d['path']).read_bytes();need(pin(d['path'],b)==d,'exact '+role)
    need(plan['runner']['sha256']=='7849621343d3dd150cecd3616eeed9667b82c6b68008601c4649aa9117d98df7',
         'reviewed external runner Source')
    folder=path.parent/(path.stem+'-terminal-observation');folder.mkdir(mode=0o700)
    write_new(folder/'CONSUMED.json',dict(plan=pin(path,raw),maximum_runner_launches=1,started_ns=started))
    command=[plan['python']['path'],'-I','-S','-B',plan['runner']['path'],str(path)]
    outcome=dict(schema='and-support-ordering-final-terminal-observation-v1',version=VERSION,
                 plan=pin(path,raw),observer_started_ns=started,command=command,
                 scientific_acceptance=False,mathematical_proof_accepted=False,
                 ROOT_resource_accepted=False,terminal_gate_passed=False)
    with (folder/'stdout.bin').open('xb') as stdout,(folder/'stderr.bin').open('xb') as stderr:
        process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
        outcome['runner_pid']=process.pid
        try:
            code=process.wait(timeout=225)
        except subprocess.TimeoutExpired:
            # Failure-only fallback targets our exact direct child, not an
            # unverified process group. Root must inspect residual ownership.
            process.kill();process.wait(timeout=5)
            outcome.update(error='runner observation timeout; no admission',
                           runner_exit_code=process.returncode,terminal_observed_ns=_NOW(),
                           residual_worker_cleanup_requires_inspection=True)
            write_new(folder/'terminal.json',outcome)
            return 2
    observed=_NOW()
    outcome.update(runner_exit_code=code,terminal_observed_ns=observed,
                   observed_instrument_elapsed_seconds=(observed-started)/1e9)
    actual=Path(plan['actual_directory']);receipt_path=actual/'runner-receipt.json'
    if receipt_path.is_file():
        rr=receipt_path.read_bytes();need(len(rr)<=8388608,'finite final runner receipt')
        receipt=json.loads(rr);outcome['runner_receipt']=pin(receipt_path,rr)
        outcome['runner_clock_elapsed_seconds']=(observed-receipt['began_ns'])/1e9
        outcome['terminal_gate_passed']=(code==0 and observed<receipt['overall_deadline_ns'] and
            receipt['resource_candidate_accepted'] is True and receipt['consumed_once'] is True and
            receipt['invocation_id']==plan['invocation_id'] and receipt['mode']==plan['mode'] and
            receipt['search_ordering']==plan['search_ordering'] and
            receipt['model_storage']==plan['model_storage'] and receipt['result_reader']==plan['result_reader'] and
            receipt['receiver_id']==plan['receiver_id'] and receipt['owned_group_absent'] is True and
            receipt['stdout_eof'] is True and receipt['stderr_eof'] is True and receipt['log_capture_complete'] is True and
            receipt['plan']==pin(path,raw) and not (actual/'POST_RECEIPT_DEADLINE_FAILURE.json').exists())
    outcome['scope']='Final compact-model cold outer terminal/group/EOF gate only. Parent Source-entry epoch excludes observer/Python prelude. Root separately admits exact native/point/knowledge/fullprofile evidence; no own mathematical acceptance.'
    write_new(folder/'terminal.json',outcome)
    print(json.dumps(dict(terminal=str(folder/'terminal.json'),exit_code=code,
                         terminal_gate_passed=outcome['terminal_gate_passed']),sort_keys=True))
    return 0 if outcome['terminal_gate_passed'] else 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one exact once-plan path')
    raise SystemExit(main(sys.argv[1]))
