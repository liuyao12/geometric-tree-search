"""Full40 prospective raw metadata audit. No scientific imports/evaluation."""
import ast,collections,hashlib,json,pathlib
ROOT=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
P=pathlib.Path('/private/tmp/gcts-first-order-suite-plans-ROOT-20261018-v1')
OUT=pathlib.Path('/private/tmp/gcts-first-order-suite-prospective-peer-20261018')
checks=[];raw_cache={};pins={}
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def eq(a,b):return canon(a)==canon(b)
def ck(n,ok,d=None):checks.append({'name':n,'passed':bool(ok),'detail':d})
def desc(p):
 p=pathlib.Path(p);h=hashlib.sha256();n=0
 with p.open('rb')as f:
  while True:
   b=f.read(1048576)
   if not b:break
   n+=len(b);h.update(b)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':n}
def pin(n,d):
 key=(d['path'],d['sha256'],d['bytes'])
 if key not in raw_cache:raw_cache[key]=desc(d['path'])
 got=raw_cache[key];pins[n]=got;ck(n+'.rawpin',all(got[k]==d[k] for k in ['path','sha256','bytes']))
 return got
def load(d):return json.loads(pathlib.Path(d['path']).read_bytes())
I=json.loads((P/'prospective-index-v1.json').read_bytes());pins['prospective_index']=desc(P/'prospective-index-v1.json')
ck('index.expected',pins['prospective_index']['sha256']=='5d4b62d159dedbf313fd185824da9172be7fd055d597f66f0e5d38b82cb5fc4a' and pins['prospective_index']['bytes']==66281)
for k in ['API','cold','composition_handoff','declaration','frozen_scientific_parent','input_capsule','observer','runner','runtime_closure']:pin(k,I[k])
API=load(I['API']);G=load(I['declaration']);C=load(I['runtime_closure']);OLD=load(I['frozen_scientific_parent']);CAP=load(I['input_capsule']);D=json.loads((ROOT/'.gcts-active/first-order-suite-progress-20261018/prospective-design-v1.json').read_bytes())
H=load(I['composition_handoff']);COMP=load(H['composition_contract']);ONCE=load(H['once_contract'])
for k in ['composition_contract','once_contract','delta','generated_Source_map']:pin(k,H[k])
inputs={x['id']:x for x in CAP['receivers']};ck('tenuniqueinputs',len(inputs)==len(CAP['receivers'])==10)
ck('global.design_original_values_retained',all(eq(G[k],D[k]) for k in D if k!='schema'))
ck('global.current_capsule_closure_intake',eq(G['input_capsule'],I['input_capsule']) and eq(G['runtime_closure'],I['runtime_closure']) and eq(G['intake_Source_handoff'],I['composition_handoff']))
ck('global.schedule40_exact_design',eq(G['schedule'],D['schedule']) and len(G['schedule'])==40)
ck('index.inactive',I['actual_execution_authorized'] is False and I['actuals_started']==0 and I['scientific_calls']==0 and I['source_only'] is True)
ck('global.inactive',G['actual_execution_authorized'] is False and G['scientific_calls']==0 and G['goal_complete'] is False)
ck('schemas.API_role_binding',eq(I['review_role_schemas'],API['review_roles']))
changed={k for k in set(C)|set(OLD) if not eq(C.get(k),OLD.get(k))}
ck('closure.only_intake_metadata_changes',changed=={'Source_design','current_composition_handoff','bridge_scope','benchmark_input_capsule','benchmark_intake_parent_closure'},sorted(changed))
ck('closure.operative_parent63fa_unchanged',eq(C['parent_closure'],OLD['parent_closure']) and C['parent_closure']['sha256']=='63fa8e0d66175a925c61b38ff6c727f5d180f738e2735eb07a3317849c3ed5cf')
ck('closure.current_parent8246_intake',eq(C['benchmark_intake_parent_closure'],I['frozen_scientific_parent']) and eq(C['benchmark_input_capsule'],I['input_capsule']))
ck('closure.Source_contract_handoff',eq(C['Source_design'],H['composition_contract']) and eq(C['current_composition_handoff'],I['composition_handoff']))
for k in ['project_sources','additional_nonseed_components','materialized_aliases','project_import_edges','import_sites','literal_dynamic_import_sites','Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python','unresolved_project_imports']:
 ck('closure.unchanged_'+k,eq(C[k],OLD[k]))
ck('closure.complete24_126imports_2dynamic',len(C['project_sources'])==22 and len(C['additional_nonseed_components'])==2 and len(C['materialized_aliases'])==24 and len(C['import_sites'])==126 and len(C['literal_dynamic_import_sites'])==2 and C['unresolved_project_imports']==[])
# Hash only (no decoding/loading) each raw executable/runtime/native/Z3 Source artifact.
def all_descriptors(v):
 if type(v)is dict:
  if {'path','sha256','bytes'}<=set(v) and type(v['path'])is str and type(v['sha256'])is str and type(v['bytes'])is int:yield {k:v[k] for k in ['path','sha256','bytes']}
  for x in v.values():yield from all_descriptors(x)
 elif type(v)is list:
  for x in v:yield from all_descriptors(x)
for n,d in enumerate(all_descriptors(C)):pin('closure_raw%d'%n,d)
limits=G['limits'];case_dict={};bindings=[];subjects=set();actuals=set();draft_terms=set();future_terms=set();workers=set()
ck('index.ten_case_declarations',set(I['case_declarations'])==set(inputs))
for cid,cd in I['case_declarations'].items():
 pin('case.'+cid,cd);case=load(cd);case_dict[cid]=case
 ck(cid+'.schema_capsule_global',case['schema']==API['declaration_schema'] and eq(case['parent_structural_declaration'],I['input_capsule']) and eq(case['global_cohort_declaration'],I['declaration']))
 ck(cid+'.exact_spec_no_route',case['selected_receiver_id']==cid and eq(case['selected_receiver'],inputs[cid]))
 ck(cid+'.fixed_profile_closure_storage',eq(case['limits'],limits) and eq(case['runtime_closure'],I['runtime_closure']) and case['model_storage']=='literal_interned' and case['result_reader']=='interned')
 ck(cid+'.inactive_no_RL',case['actual_execution_authorized'] is False and case['scientific_calls']==0 and case['new_RL_training'] is False)
 expected_rows=[r for r in G['schedule'] if r['receiver_id']==cid]
 ck(cid+'.exact_global_four_schedule',eq(case['schedule'],expected_rows) and len(expected_rows)==4 and len({(r['mode'],r['search_ordering']) for r in expected_rows})==4)
# Constants inspected as literal AST data only; never import/call runner.
source_ast=ast.parse(pathlib.Path(I['runner']['path']).read_bytes());literal={}
for n in source_ast.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:literal[n.targets[0].id]=ast.literal_eval(n.value)
  except(ValueError,TypeError):pass
expected_limits=literal['LIMITS'];expected_env={'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','TZ':'UTC'}
ck('outer.exactlimits',eq(expected_limits,{'aggregate_peak_bytes':1073741824,'failure_cleanup_seconds':5,'overall_seconds':210,'poll_milliseconds':20,'result_bytes':134217728,'runner_plan_bytes':16777216,'stderr_bytes':4194304,'stdout_bytes':4194304,'work_seconds':180,'worker_receipt_bytes':4194304}))
ck('outer.current_cold_pin',eq(literal['COLD_PIN'],I['cold']))
ck('index40rows',len(I['schedule'])==40)
for n,row in enumerate(I['schedule']):
 iid=row['invocation_id'];prefix='slot%02d'%(n+1);base={k:row[k] for k in G['schedule'][n]}
 ck(prefix+'.exact_global_order',eq(base,G['schedule'][n]))
 for k in ['worker_plan','authorization_draft','runner_plan_draft']:pin(prefix+'.'+k,row[k])
 w=load(row['worker_plan']);auth=load(row['authorization_draft']);once=load(row['runner_plan_draft']);cid=row['receiver_id'];case=case_dict[cid]
 ck(prefix+'.once_exact18_fields',set(once)==set(API['once_fields']) and once['schema']==API['once_schema'])
 ck(prefix+'.worker_exact18_fields',set(w)==set(API['worker_fields']) and w['schema']==API['worker_schema'])
 subject={k:v for k,v in once.items() if k!='authorization'};subjectsha=hashlib.sha256(canon(subject)).hexdigest()
 ck(prefix+'.subject_full17fields',len(subject)==17 and subjectsha==row['subject_sha256']==auth['subject_sha256'])
 ck(prefix+'.false_maxone_exact7auth',set(auth)==set(API['authorization_fields']) and auth['schema']==API['authorization_schema'] and auth['actual_execution_authorized'] is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and type(auth['review_roles'])is dict and auth['review_roles']=={} and auth['author_identity']=='/root')
 ck(prefix+'.exact_auth_reference',eq(once['authorization'],row['authorization_draft']))
 ck(prefix+'.worker_declaration_exact',eq(w['declaration'],I['input_capsule']) and eq(w['integration_declaration'],I['case_declarations'][cid]) and eq(w['runtime_closure'],I['runtime_closure']))
 ck(prefix+'.once_intake_exact',eq(once['integration_declaration'],I['case_declarations'][cid]) and eq(once['runtime_closure'],I['runtime_closure']) and eq(once['worker_plan'],row['worker_plan']))
 ck(prefix+'.worker_sources_complete_same24',eq(w['project_sources'],C['project_sources']) and eq(w['components'],C['additional_nonseed_components']) and eq(dict(w['project_sources'],semantic_receiver_driver=w['components']['receiver_driver'],bounded_request_oracle=w['components']['bounded_transport']),C['materialized_aliases']))
 for role in ['cold','python']:
  expected=I['cold'] if role=='cold' else C['runtime']['Python_executable'];ck(prefix+'.'+role+'_exact_worker_once',eq(once[role],expected) and eq(w[role],expected))
 for role in ['runner','observer']:ck(prefix+'.'+role+'_exact_once',eq(once[role],I[role]))
 ck(prefix+'.native_full_rawmaps',eq(w['native_inputs'],{'program_and_template':C['fixed_native_inputs']['program_and_template'],'opaque_microcode_gzip':C['fixed_native_inputs']['opaque_microcode_gzip'],'native_cpp':C['native_CPP']['binary']}))
 expected_z3=[{k:p[k] for k in ['path','sha256','bytes']} for p in C['Z3']['files']]
 ck(prefix+'.Z3_full_rawmaps',set(w['z3'])=={'root','files','library'} and w['z3']['root']==C['Z3']['package_root'] and eq(w['z3']['files'],expected_z3) and w['z3']['library'] in expected_z3 and w['z3']['library']['path']==str(pathlib.Path(w['z3']['root'])/'z3/lib/libz3.dylib'))
 pin(prefix+'.policy',w['policy']);ck(prefix+'.complete_same_policy',eq(w['policy'],{'bytes':4502,'path':'/private/tmp/gcts-semantic-family-next-audit-20261018/semantic-inventory-policy-001.json','sha256':'f5f0c22121f4c503db319fe6e01c4c3a146ac9db9deb7e2ccec0aab1a2f32161'}))
 ck(prefix+'.all_binding_fields',all(eq(row[k],once[k]) and eq(row[k],w[k]) for k in ['invocation_id','mode','search_ordering','receiver_id','actual_directory','model_storage','result_reader']))
 ck(prefix+'.unchanged_outer_limits_environment',eq(once['limits'],expected_limits) and eq(once['environment'],expected_env))
 ck(prefix+'.case_four_fullspec',eq(case['selected_receiver'],inputs[cid]) and any(eq(rr,base) for rr in case['schedule']))
 actual=pathlib.Path(row['actual_directory']);draftterm=pathlib.Path(row['runner_plan_draft']['path']).parent/(iid+'-terminal-observation');futureterm=P/'runner-plans'/(iid+'-terminal-observation')
 ck(prefix+'.actual_and_draft_future_terminal_absent',not actual.exists() and not draftterm.exists() and not futureterm.exists())
 subjects.add(subjectsha);workers.add(row['worker_plan']['path']);actuals.add(str(actual));draft_terms.add(str(draftterm));future_terms.add(str(futureterm))
 bindings.append({'order':row['order'],'receiver_id':cid,'mode':row['mode'],'search_ordering':row['search_ordering'],'invocation_id':iid,'worker_plan':row['worker_plan'],'runner_plan_draft':row['runner_plan_draft'],'authorization_draft':row['authorization_draft'],'subject_sha256':subjectsha,'subject_preimage':subject,'integration_declaration':I['case_declarations'][cid],'actual_directory':str(actual),'draft_terminal_directory':str(draftterm),'future_terminal_directory':str(futureterm),'all_paths_absent':True})
ck('all40.unique_subject_worker_actual_terminal_paths',all(len(s)==40 for s in [subjects,workers,actuals,draft_terms,future_terms]))
ck('global.all_cases_all_arms',collections.Counter((r['receiver_id'],r['mode'],r['search_ordering']) for r in I['schedule'])==collections.Counter((cid,m,o) for cid in inputs for m in ['fixed','symbolic'] for o in ['legacy','and_support']))
summary={'checks':len(checks),'mismatches':sum(not x['passed'] for x in checks),'all_passed':all(x['passed'] for x in checks),'case_declarations':len(case_dict),'once_subjects':len(subjects),'subject_fields':17,'worker_fields':18,'outer_fields_including_auth':18,'false_grants':40,'maximum_invocations_each':1,'distinct_current_raw_files_hashed':len(raw_cache),'actual_directories_absent':len(actuals),'draft_terminal_directories_absent':len(draft_terms),'future_terminal_directories_absent':len(future_terms),'scientific_calls':0}
audit={'schema':'first-order-suite-full40-false-subject-audit-v1','reviewer_identity':'/root/conventional_library','source_only':True,'scientific_calls':0,'summary':summary,'pins':pins,'all40bindings':bindings,'checks':checks}
(OUT/'raw-plan-audit-v1.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(summary,indent=2));print(json.dumps(desc(OUT/'raw-plan-audit-v1.json')))
