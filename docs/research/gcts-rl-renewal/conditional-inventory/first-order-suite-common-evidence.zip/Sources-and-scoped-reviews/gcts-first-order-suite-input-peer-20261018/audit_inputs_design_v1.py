"""Raw JSON/metadata review only. Does not import or evaluate scientific modules."""
import collections, hashlib, json, pathlib
OUT=pathlib.Path('/private/tmp/gcts-first-order-suite-input-peer-20261018')
ROOT=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
BASE=ROOT/'.gcts-active/first-order-suite-progress-20261018'
SRC=pathlib.Path('/private/tmp/gcts-first-order-next-benchmark-source-20261018')
checks=[]; pins={}
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def equal(a,b):return canon(a)==canon(b)
def check(name,ok,detail=None):
 checks.append({'name':name,'passed':bool(ok),'detail':detail})
def desc(p):
 p=pathlib.Path(p);raw=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
def read(p):return json.loads(pathlib.Path(p).read_bytes())
def pin(name,d):
 a=desc(d['path']);pins[name]=a
 check(name+'.raw_descriptor',all(a[k]==d[k] for k in ['path','sha256','bytes']))
 return read(d['path']) if str(d['path']).endswith('.json') else None
cap=read(BASE/'input-capsule-v1.json'); design=read(BASE/'prospective-design-v1.json')
pins['input_capsule']=desc(BASE/'input-capsule-v1.json');pins['prospective_design']=desc(BASE/'prospective-design-v1.json')
check('input_capsule.expected_pin',pins['input_capsule']['sha256']=='1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0' and pins['input_capsule']['bytes']==22422)
check('prospective_design.expected_pin',pins['prospective_design']['sha256']=='3b324a86de79a408a4d1317d94c6e03a807e4367afaf15f24cf0ec5e2288139f' and pins['prospective_design']['bytes']==25396)
suite=pin('original_suite',cap['source_suite']); handoff=pin('original_handoff',cap['source_handoff'])
check('design.same_suite',equal(design['source_suite'],cap['source_suite']))
check('design.same_capsule',equal(design['input_capsule'],pins['input_capsule']))
for k in ['coverage_provenance','design_holdout_controls','primary_sources','static_authoring_audit','authoring_Source']:pin(k,handoff[k])
coverage=read(handoff['coverage_provenance']['path']); controls=read(handoff['design_holdout_controls']['path'])
prior=read(ROOT/'.gcts-active/and-support-ordering-progress-20261018/experiment-declaration-v1.json');pins['prior_declaration']=desc(ROOT/'.gcts-active/and-support-ordering-progress-20261018/experiment-declaration-v1.json')
closure=pin('frozen_scientific_runtime_closure',design['frozen_scientific_runtime_closure'])
check('limits.literal_same_as_prior',equal(design['limits'],prior['limits']))
check('limits.literal_same_as_authored_suite_profile',equal(design['limits'],controls['profile']['limits_literal']))
check('limits.exact_values',equal(design['limits'],{'check_steps':2048,'compile_queries':512,'conservative_worker_plus_native_peak_bytes':1073741824,'guard_steps':1000000000,'overall_seconds':210,'proposal_steps':24,'registry_steps':5000000000,'result_bytes':134217728,'search_max_nodes':5000,'search_seconds':30,'seed':64000,'work_seconds':180}))
check('current_alias_count24',len(closure['materialized_aliases'])==24 and closure['materialized_project_and_component_count']==24 and closure['project_module_count']==22)
check('current_closure.no_missing_project_imports',closure['unresolved_project_imports']==[])
for name,d in closure['project_sources'].items():pin('current_source.'+name,d)
for name,d in closure['additional_nonseed_components'].items():pin('current_component.'+name,d)
check('Source_gate.inactive_all',cap['actual_execution_authorized'] is False and design['actual_execution_authorized'] is False and suite['actual_execution_authorized'] is False and handoff['actual_execution_authorized'] is False)
check('source_only.no_scientific_calls_claim',all(x['scientific_calls']==0 for x in [cap,design,suite,handoff,coverage,controls]))
check('suite.frozen_unexecuted',suite['status']=='FROZEN_INPUT_ONLY_UNEXECUTED' and suite['provenance_class']=='AUTHORED_SYNTHETIC_NOT_OFFICIAL_TPTP')
check('ten_case_counts',len(suite['receivers'])==len(cap['receivers'])==len(cap['input_sources'])==suite['case_count']==design['distinct_inputs']==10)
check('eight_group_counts',suite['structural_group_count']==design['structural_groups']==8 and suite['renaming_control_count']==2)
check('no_RL_training',design['new_RL_training'] is False)
# Static input-tree inspection only: no substitution, truth, compiler, Native or proof computation.
def static_tree(spec):
 funcs=spec['theory']['functions']; preds=spec['theory']['predicates']; binders=set();counts=collections.Counter();nodes=0
 def term(t,env):
  nonlocal nodes
  assert type(t)is list and t;nodes+=1
  if t[0]=='var': assert len(t)==2 and type(t[1])is str and t[1] in env
  else:
   assert t[0]=='fun' and len(t)==3 and type(t[1])is str and type(t[2])is list and t[1] in funcs and len(t[2])==funcs[t[1]]
   for a in t[2]:term(a,env)
 def form(f,env=()):
  nonlocal nodes
  assert type(f)is list and f and type(f[0])is str; nodes+=1;tag=f[0];counts[tag]+=1
  if tag=='pred':
   assert len(f)==3 and f[1] in preds and type(f[2])is list and len(f[2])==preds[f[1]]
   for a in f[2]:term(a,env)
  elif tag=='eq':
   assert len(f)==3;term(f[1],env);term(f[2],env)
  elif tag=='all':
   assert len(f)==3 and type(f[1])is str;binders.add(f[1]);form(f[2],env+(f[1],))
  elif tag=='not':assert len(f)==2;form(f[1],env)
  else:
   assert tag=='imp' and len(f)==3;form(f[1],env);form(f[2],env)
 for a in spec['theory']['axioms'].values():form(a)
 form(spec['target'])
 return {'nodes':nodes,'binders':sorted(binders),'tags':dict(sorted(counts.items()))}
def rename_formula(x,m):
 assert type(x)is list and x
 tag=x[0]
 if tag=='var':return [tag,m['variables'].get(x[1],x[1])]
 if tag=='fun':return [tag,m['functions'].get(x[1],x[1]),[rename_formula(a,m) for a in x[2]]]
 if tag=='pred':return [tag,m['predicates'].get(x[1],x[1]),[rename_formula(a,m) for a in x[2]]]
 if tag=='all':return [tag,m['variables'].get(x[1],x[1]),rename_formula(x[2],m)]
 return [tag]+[rename_formula(a,m) for a in x[1:]]
inputs={};case_details=[]
allowed={'id','title','scope','theory','target','length','instantiation_rounds'}
for i,(record,spec,source_d) in enumerate(zip(suite['receivers'],cap['receivers'],cap['input_sources']),1):
 cid=record['case_id']; original=pin(cid,record['input']);inputs[cid]=original
 check(cid+'.input_source_descriptor',equal(source_d,record['input']))
 check(cid+'.lossless_capsule_copy',equal(original,spec))
 check(cid+'.id_order',cid=='prospective-fol-20261018-%03d'%i and original['id']==cid)
 check(cid+'.only_assertion_input_keys',set(spec)==allowed and set(spec['theory'])=={'axioms','functions','predicates','schemas'})
 check(cid+'.twelve_rows_two_rounds',type(spec['length'])is int and spec['length']==12 and type(spec['instantiation_rounds'])is int and spec['instantiation_rounds']==2)
 check(cid+'.empty_schemas',spec['theory']['schemas']==[])
 check(cid+'.signature_plain_arities',all(type(n)is str and type(a)is int and a>=0 for table in [spec['theory']['functions'],spec['theory']['predicates']] for n,a in table.items()))
 check(cid+'.no_expected_outcome_filter',all(record[k] is None for k in ['expected_runtime_status','expected_proof_rows','expected_basis_or_inventory_counts']) and record['input_only'] is True)
 observed=static_tree(spec); declared=record['static_authoring']
 check(cid+'.static_closed_signature_tree',True,observed)
 check(cid+'.static_authoring_observations',observed['nodes']==declared['input_AST_nodes'] and observed['binders']==declared['initial_binder_names'] and equal(observed['tags'],declared['formula_tag_occurrences']) and declared['all_axioms_closed'] is True and declared['target_closed'] is True)
 check(cid+'.no_compiled_result_or_proof',all(declared[k] is None for k in ['compiled_catalog','model','native_status','proof']))
 group={k:record[k] for k in ['case_id','group','renaming_control_of','structural_primary']}
 check(cid+'.group_literal_copy',equal(group,cap['groups'][i-1]) and equal(group,design['groups'][i-1]))
 check(cid+'.handoff_record',equal(group,{k:handoff['inputs'][i-1][k] for k in group}) and equal(record['input'],handoff['inputs'][i-1]['input']))
 check(cid+'.ordinary_unique_shape_digest',hashlib.sha256(canon(record['shape']).encode()).hexdigest()==record['source_shape_sha256'])
 case_details.append({'case_id':cid,'group':record['group'],'source':pins[cid],'static_tree_observation':observed,'renaming_control_of':record['renaming_control_of'],'primary':record['structural_primary'],'grammar_admission':'UNMEASURED','proof_length':'UNMEASURED','resource_fit':'UNMEASURED'})
for r in suite['receivers']:
 if r['renaming_control_of']:
  src=inputs[r['renaming_control_of']]; dst=inputs[r['case_id']];m=r['renaming_map']
  th={'functions':{m['functions'].get(k,k):v for k,v in src['theory']['functions'].items()},'predicates':{m['predicates'].get(k,k):v for k,v in src['theory']['predicates'].items()},'axioms':{m['axioms'].get(k,k):rename_formula(v,m) for k,v in src['theory']['axioms'].items()},'schemas':[]}
  check(r['case_id']+'.whole_declared_renaming',equal(dst['theory'],th) and equal(dst['target'],rename_formula(src['target'],m)))
  parent=next(a for a in suite['receivers'] if a['case_id']==r['renaming_control_of'])
  check(r['case_id']+'.renaming_same_group_shape',r['group']==parent['group'] and equal(r['shape'],parent['shape']))
check('primary.eight_distinct_stored_shapes',len({r['source_shape_sha256'] for r in suite['receivers'] if r['structural_primary']})==8)
check('all.ten.groups_8_primaries_2_controls',len({r['group'] for r in suite['receivers']})==8 and sum(r['structural_primary'] is True for r in suite['receivers'])==8 and sum(r['structural_primary'] is False for r in suite['receivers'])==2)
arms=[('fixed','legacy'),('symbolic','and_support'),('symbolic','legacy'),('fixed','and_support')]
schedule=design['schedule'];check('schedule.count40',len(schedule)==design['total_actuals']==40)
positions=collections.defaultdict(collections.Counter);actual_dirs=[]
for j,row in enumerate(schedule):
 case=j//4;within=j%4;arm=arms[(within+case)%4]; cid='prospective-fol-20261018-%03d'%(case+1)
 iid='fol-suite-%03d-%s-%s-ROOT-20261018-v1'%(case+1,arm[0],arm[1].replace('_','-'))
 expected={'order':j+1,'case_order':case+1,'within_case_order':within+1,'receiver_id':cid,'mode':arm[0],'search_ordering':arm[1],'model_storage':'literal_interned','result_reader':'interned','invocation_id':iid,'actual_directory':str(ROOT/'.gcts-active'/iid)}
 check('schedule.%02d.exact_declared_rotation'%(j+1),equal(row,expected))
 check('schedule.%02d.actual_directory_absent'%(j+1),not pathlib.Path(row['actual_directory']).exists())
 positions['%s/%s'%arm][within+1]+=1;actual_dirs.append(row['actual_directory'])
check('schedule.all40_unique_paths_ids',len(set(actual_dirs))==40 and len({r['invocation_id'] for r in schedule})==40)
for ci in range(10):check('schedule.case%02d.all4_once'%(ci+1),collections.Counter((r['mode'],r['search_ordering']) for r in schedule[ci*4:ci*4+4])==collections.Counter(arms))
for block in [0,4]:
 for arm in arms:check('latin.block%d.arm%s'%(block//4+1,str(arm)),sorted(r['within_case_order'] for r in schedule[block*4:(block+4)*4] if (r['mode'],r['search_ordering'])==arm)==[1,2,3,4])
check('primary_endpoint.full_bounded_proof_not_UI_GEN_gate','nativepositive aboveprofile remains diagnostic' in design['failure_policy'].lower() and 'equality cases need not have UI or GEN' in controls['success_and_reporting']['secondary'])
check('failure_policy.all_outcomes','Retain ALL' in design['failure_policy'] and 'Failed methods remain in denominator' in design['failure_policy'] and 'closes all40 without tuning' in design['execution'])
check('provenance.not_official_not_blind','Not officialTPTP or blind' in cap['scope'] and 'not a hidden blind test' in controls['split_policy']['blindness'])
check('grammar_and_capacity_not_prefiltered','no anticipated success/census/resource filter' in controls['split_policy']['evaluation'].lower() and 'no finite-grammar impossibility is asserted' in coverage['finite_search_limits'][3])
check('no_outcome_based_training_before_closure','before cohort closure' in controls['split_policy']['training'])
check('schedule.one_once_no_statistical_claim','no statisticalclaim' in design['scoring'] and 'not10independentgroups' in design['scoring'])
summary={'checks':len(checks),'mismatches':sum(not x['passed'] for x in checks),'all_passed':all(x['passed'] for x in checks),'arm_position_counts':{k:dict(sorted(v.items())) for k,v in positions.items()},'actual_directories_absent':sum(not pathlib.Path(p).exists() for p in actual_dirs),'input_count':10,'structural_group_count':8,'renaming_controls':2,'schedule_count':40,'scientific_calls':0,'imports_of_scientific_modules':0}
audit={'schema':'first-order-suite-input-design-raw-audit-v1','author_identity':'/root/conventional_library','source_only':True,'summary':summary,'pins':pins,'cases':case_details,'checks':checks}
(OUT/'raw-audit-v1.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(summary,indent=2))
print('AUDIT',desc(OUT/'raw-audit-v1.json'))
