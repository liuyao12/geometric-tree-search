"""Ordinary input author only. No target imports/calls, labels or witnesses."""
from pathlib import Path
import itertools
import json
import hashlib
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
def base(n,b):
    return dict(schema='finite-unit-center-point-instance-v1',transformations='translations_only_2Z2',
        required_centers=[[2*i,0]for i in range(n)],admissible_origins=[[2*i,0]for i in range(n)],
        tiles=[dict(id=7*i,t=[[[0,0],1]],m=[])for i in range(b)],fixed_background_marks=[],all_root_generations=0)
def literals(model):return[dict(origin=p[:],tile_id=t['id'])for p in model['required_centers']for t in model['tiles']]
def clone(value):return json.loads(json.dumps(value))
def main():
    cases=[]
    def add(name,model,clauses,family,exhaust=False):
        cases.append(dict(id=name,base=clone(model),clauses=clone(clauses),family=family,
            complete_base_assignment_count=len(model['tiles'])**len(model['required_centers']),
            exhaustive_full_palette=exhaust))
    for n in range(1,4):
        for b in range(1,3):
            model=base(n,b);atoms=literals(model)
            add(f'one-n{n}-b{b}-no-clauses',model,[],'complete-one-clause-population',n==1)
            for k in range(3):
                for index,word in enumerate(itertools.product(atoms,repeat=k)):
                    add(f'one-n{n}-b{b}-k{k}-w{index}',model,[list(word)],'complete-one-clause-population',n==1)
    for n in range(1,3):
        for b in range(1,3):
            model=base(n,b);words=[[]]+[[atom]for atom in literals(model)]
            for index,pair in enumerate(itertools.product(words,repeat=2)):
                add(f'two-n{n}-b{b}-w{index}',model,list(pair),'complete-two-clause-population')
    profiles=[]
    model=base(2,2);model['tiles'][0]['m']=[[[100,0],'remote',0]]
    model['fixed_background_marks']=[[[100,0],'remote',1]]
    profiles.append(('assigned-zero-versus-absent',model))
    model=base(2,2)
    for i,tile in enumerate(model['tiles']):tile['m']=[[[100,0],'remote',i],[[102,0],'remote',i]]
    profiles.append(('remote-only-overlap',model))
    model=base(2,2)
    channels=[stem+suffix for stem in('__receptor_anchor__','__receptor_choice__','__receptor_state__')for suffix in('',':0')]
    for tile in model['tiles']:tile['m']=[[[0,0],channel,0]for channel in channels]
    profiles.append(('fresh-channel-collisions',model))
    model=base(3,2);points=[[-8,-4],[-2,-6],[0,-10]]
    model['required_centers']=clone(points);model['admissible_origins']=clone(points)
    profiles.append(('negative-nonrectangular-origins',model))
    for name,model in profiles:
        p0,p1=model['required_centers'][:2]
        a=dict(origin=p0,tile_id=0);b=dict(origin=p1,tile_id=7);c=dict(origin=p0,tile_id=7);d=dict(origin=p1,tile_id=0)
        for label,clauses in [('none',[]),('pair',[[a,b]]),('shared',[[a],[c,d]])]:
            add(name+'-'+label,model,clauses,'explicit-original-mark-profile')
    model=base(3,2);p0,p1,p2=model['required_centers']
    a=dict(origin=p0,tile_id=0);b=dict(origin=p1,tile_id=7);c=dict(origin=p0,tile_id=7);d=dict(origin=p2,tile_id=0)
    for name,clauses in [('repeat-three',[[a,b,a]]),('contradictory-three',[[a,c,b]]),('repeat-four',[[a,b,d,b]])]:
        add(name,model,clauses,'explicit-longer-word-profile')
    diagnostics=[dict(id=name,operation=op)for name,op in[
        ('D01','duplicate_required'),('D02','extra_origin'),('D03','duplicate_tile_id'),
        ('D04','boolean_mark_zero'),('D05','odd_origin'),('D06','foreign_literal_id'),
        ('D07','rotation_field'),('D08','remove_anchor'),('D09','flip_prefix_output'),
        ('D10','remove_original_zero'),('D11','compiler_owned_work'),('D12','verifier_owned_work'),
        ('D13','compiler_foreign_base'),('D14','compiler_foreign_limit'),('D15','verifier_foreign_base')]]
    packet=dict(schema='finite-unit-center-marking-qualification-inputs-v1',cases=cases,diagnostics=diagnostics,
        exact_case_count=len(cases),exact_base_assignment_count=sum(c['complete_base_assignment_count']for c in cases),
        core_translations=147,core_base_assignments=613,explicit_profile_translations=15,explicit_profile_base_assignments=84,
        whole_population='All n1..3,b1..2 ordered single literal words length0..2 plus no clauses; all n1..2,b1..2 ordered pairs of empty/single literal words;15 separately named original-mark/longer-word profiles.',
        exhaustive_scope='Full emitted palette to the power of ALL required centers only for the complete one-clause population with n=1; all other cases use independently checked unique-prefix correspondence, not full-palette enumeration.',
        no_supplied_answers_or_witnesses=True,question='Finite point marking translation qualification, not old680+55 timing rescue, automatic theorem discovery or redundant-negative certification.')
    path=D/'cohort-inputs-v1.json'
    raw=json.dumps(packet,sort_keys=True,indent=2,ensure_ascii=False).encode()+b'\n'
    with path.open('xb')as f:f.write(raw)
    print(json.dumps(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),cases=len(cases),base_assignments=packet['exact_base_assignment_count'],diagnostics=len(diagnostics)),sort_keys=True))
if __name__=='__main__':main()
