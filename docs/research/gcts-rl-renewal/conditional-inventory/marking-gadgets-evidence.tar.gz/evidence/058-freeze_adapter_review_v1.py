"""Reviewer-owned raw/AST-only Source assessment; no adapter evaluation."""
from pathlib import Path
import ast
import hashlib
import json
import sys

C=Path('/private/tmp/gcts-geometric-nogood-review-20261019')
A=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1/physical_wang_adapter_v1.py')
G=Path('/private/tmp/gcts-semantic-runtime-intake-20261018/tape_tree_machine.py')
def pin(path):
    p=Path(path);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
checks=[]
def check(name,ok):
    checks.append(dict(id=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
raw=A.read_bytes();text=raw.decode();at=ast.parse(raw)
check('exact offered Source',pin(A)['sha256']=='5e85cd213960632d7b1cfc6632d5799098b76e59f282443be5a3ea603cdffbac'and len(raw)==9421)
graw=G.read_bytes();gt=ast.parse(graw)
blob=hashlib.sha1(b'blob '+str(len(graw)).encode()+b'\0'+graw).hexdigest()
check('generator exact historical Git object',blob=='23cc9faedfbe7bc5669845d63c63be6f71d879b9')
check('adapter no imports',not any(isinstance(n,(ast.Import,ast.ImportFrom))for n in ast.walk(at)))
check('adapter no generator conversion',not any(isinstance(n,(ast.Yield,ast.YieldFrom))for n in ast.walk(at)))
unused=compile(raw,str(A),'exec');del unused
for name,needle in [
 ('full state iteration','for state,row in enumerate(rows):'),
 ('full symbol iteration','for read,token in enumerate(alphabet):'),
 ('override first','if token in overrides:out,write,move=overrides[token];write_id=ids[write]'),
 ('default preserves read','elif default is not None:out,move=default;write_id=read'),
 ('halt rows undefined',"_need(row is None,'halting states have no outgoing rows')"),
 ('explicit blank alphabet map',"blank=ids['B']"),
 ('literal exact ints exclude bool',"_need(type(value)is int,'exact integer; bool is not an integer')"),
 ('whole copied input retained','physical_table=owned'),
 ('one declared physical head',"out.append(['head',machine['initial'],ids[token]]if index==head else['plain',ids[token]])"),
 ('direct final callback','w.step();check()'),
 ('module owner exact class',"return type(error)is AdapterLimit and error._owner is _OWNER"),
]:check(name,needle in text)
functions={n.name:n for n in at.body if isinstance(n,ast.FunctionDef)}
check('no public-entry callback/quota normalization',not any(isinstance(n,ast.Try)for name in ['compile_table','encode_word']for n in ast.walk(functions[name])))
gfunc=next(n for n in gt.body if isinstance(n,ast.FunctionDef)and n.name=='physical_declaration')
generator_excerpt=ast.get_source_segment(graw.decode(),gfunc).encode()
check('generator nine literal return fields',set(next(n for n in ast.walk(gfunc)if isinstance(n,ast.Return)and isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Name)and n.value.func.id=='dict').value.keywords[i].arg for i in range(9))=={'alphabet','rows','names','start','accept','reject','space','entries','micro_sha256'})
v=dict(schema='physical-wang-adapter-scoped-Source-review-v1',reviewer_identity='/root/conventional_control_review',
    author_identity='/root',review_passed=True,source_review_passed=True,source_only=True,
    subject_imports=0,component_calls=0,scientific_calls=0,fixture_calls=0,simulations=0,process_probes=0,
    actual_execution_authorized=False,runtime_qualified=False,mathematical_proof_admitted=False,
    kernel_faithfulness_established=False,earlier_lowering_faithfulness_established=False,
    unknown_proof_language_established=False,fixed_FOL_table_materialized=False,
    source=pin(A),physical_declaration_generator_source=pin(G),generator_Git_blob=blob,
    reviewed_generator_definition=dict(name='physical_declaration',bytes=len(generator_excerpt),sha256=hashlib.sha256(generator_excerpt).hexdigest()),
    master=pin(C/'basic-tiling-algorithm-isolated-current.md'),
    semantic_assessment=[
      'For each nonhalting physical state and every alphabet token in its original declared order, an explicit override is copied as (next state, integer write-symbol ID, move); otherwise a default copies the read-symbol ID unchanged and preserves its next state/move. Only a genuinely absent override and absent default omit that state/read pair. No reachable-state trimming, symbolic hook or theorem-specific transition choice is introduced.',
      'The three accept/reject/space state IDs must be distinct and all their rows None. The integer TM uses only the accept state as accepting; reject and space remain nonaccepting terminal states. No extra halting loops or acceptance padding is created. Interpretation of a space terminal as UNKNOWN belongs to the future owner and must not be changed to a proof rejection.',
      'The codec uses the exact alphabet-ID map, declared initial state and one strict in-range physical head. Internal @ tokens remain ordinary alphabet symbols, not extra physical heads. Complete supplied cells and full owned table are returned. It does not construct/validate the earlier band/header/virtual-head input layout, a heap, a theorem or an unknown-proof grammar.',
      'All table/cell data is copied before interpretation; cycles, subclasses/non-ordinary containers, nonstring object keys, invalid UTF-8, out-of-range exact integers/Boolean aliases, malformed rows/overrides, unknown tokens and outgoing halting rows are refused in the declared strict profile. Input alphabet order defines integer symbols; no assumed B==0 convention is substituted.',
      'The existing generator returns integer-keyed entries metadata; the offered adapter deliberately accepts ordinary JSON after key projection, with canonical natural STRING keys. A future direct raw Python physical_declaration return must not be silently passed as if already this JSON preimage. Full canonical ordinary projection/pin custody is a separate owner gate.',
    ],
    cost_and_error_scope=[
      'Both public entries expand the complete state×alphabet table; encode_word does not offer an isolated cheap codec path. Full input copies, token encodings, integer checks, family construction and output are real wall/RAM costs. UTF-8 scalar encoding, integer abs and Python list/dict allocation occur before some private bounds; those are bounded-input/OS-gate conditional, not hard per-allocation deadlines.',
      'Callbacks are called directly at entry, each1024 attempted steps and completion. The Source catches/normalizes no callback or quota exception. Foreign exception identity therefore propagates in the ordinary declared owner regime; total allocation/diagnostic failure is not a hostile-code safety guarantee.',
      'is_own_limit is exact-class plus MODULE-owned token, not a per-current-call token. Future wrappers must latch every actual external callback fault first and rethrow its exact object before classifying any AdapterLimit, including an exception created by a genuine older adapter call. Class/module ownership alone cannot prove current-call quota origin.',
      'Private attempted_work and cardinality/string/integer/depth/word limits require an explicit fresh prospective profile and invocation aggregation. This review selects no numeric allowance, imports no table generator and performs no lowering/materialization/codec/transition execution.',
    ],
    limits=[
      'Conditional representation equivalence to the complete SUPPLIED ordinary physical table only. The metadata micro_sha256 is syntax-checked and retained, not independently recomputed from an absent microcode input, public-problem pin or lowering proof.',
      'No faithful FOL kernel/context/theory bridge, completeness/liveness proof, complete fixed FOL physical table/palette, unknown-certificate grammar or proof search is supplied or certified. Integer TM output is a candidate consumed only by separately reviewed compiler/verifier and full plan gates.',
      'No runtime fixtures, stepping simulation, target call, Source loading or actual authorization occurred. Required later cases include default-vs-override precedence, identity write defaults, undefined pairs, all halt states, head bounds/internal @ tokens, exact Boolean/refusal boundaries and external faults before owned quota classification; actual reached coverage must be reported literally.',
      'Root authored this adapter; reviewer separately inspected raw Source and the exact historical generator. Historical C protocol/control authorship and same-author lowerings/components remain ancestry, not formal independent kernel certification.',
    ],
    typed_checks=checks,check_count=len(checks),mismatch_count=0,
    interpreter=dict(executable=sys.executable,version=sys.version,flags='-I -S -B',activity='stdlib raw/AST and discarded unused compile only'),
    tools_stopped_after_handoff=True)
p=C/'typed-physical-wang-adapter-Source-review-v1.json'
if p.exists():raise FileExistsError(p)
p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(dict(receipt=pin(p),checks=len(checks),mismatch_count=0),sort_keys=True))
