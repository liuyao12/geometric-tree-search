"""Saved ordinary JSON/raw bytes only; no point checker or target replay."""
from pathlib import Path
import collections
import hashlib
import itertools
import json
import sys

C=Path('/private/tmp/gcts-geometric-nogood-review-20261019')
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
A=D/'actual-component-v1';O=D/'plan-authorized-v1-terminal-observation'
checks=[];rawpins={}
def h(b):return hashlib.sha256(b).hexdigest()
def pin(path):
    p=Path(path);b=p.read_bytes();v=dict(path=str(p),bytes=len(b),sha256=h(b));rawpins[str(p)]=v;return v
def read(path):return json.loads(Path(path).read_bytes())
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def check(name,ok):
    checks.append(dict(id=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def raw(name,p):check(name,pin(p['path'])==p and not Path(p['path']).is_symlink())
planpath=D/'plan-authorized-v1.json';plan=read(planpath);planpin=pin(planpath)
source_review=read(C/'typed-marking-component-Source-prospective-review-v1.json')
grant_review=read(C/'typed-marking-final-grant-delta-review-v1.json')
subject={k:v for k,v in plan.items()if k!='authorization'}
check('exact reviewed subject',subject==source_review['subject']and h(canon(subject))==source_review['subject_sha256']=='ad27df100beb18e87701817fe2ef3c7d6a51ca2af806f975ee5a62f2c76f7701')
check('exact adopted delta current',grant_review['final_grant_delta_review_passed']is True and grant_review['subject']==subject and grant_review['authorized_plan']==planpin)
for role,p in plan['sources'].items():raw('current Source '+role,p)
for key in('python','declaration','runtime_closure','authorization'):raw('whole '+key,plan[key])
closure=read(plan['runtime_closure']['path']);decl=read(plan['declaration']['path']);auth=read(plan['authorization']['path'])
check('complete current closure',closure['sources']==plan['sources']and closure['python']==plan['python']and closure['declaration']==plan['declaration'])
for i,p in enumerate(closure['stdlib_files']):raw('declared stdlib '+str(i),p)
raw('adopted review pin',auth['review'])
check('Root exact consumed grant',auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==source_review['subject_sha256']and auth['review']==pin(C/'typed-marking-component-Source-prospective-review-v1.json'))
for item in plan['inputs']:raw('full input '+item['id'],item['pin'])
inputs=read(plan['inputs'][0]['pin']['path'])
check('whole original new bank binding',plan['inputs']==decl['inputs']and plan['limits']==decl['limits']and len(inputs['cases'])==162 and sum(r['complete_base_assignment_count']for r in inputs['cases'])==697)
packetpath=A/'canonical-finite-marking-qualification.json';packet=read(packetpath)
result=read(A/'result.json');header=read(A/'worker-receipt.json');runner=read(A/'runner-receipt.json');terminal=read(O/'terminal.json')
consumed=read(A/'CONSUMED.json');worker_consumed=read(A/'WORKER_CONSUMED.json');observer_consumed=read(O/'CONSUMED.json')
retire=read(D/'ROOT-grant-retirement-v1.json')
expected={str(packetpath):('831aa981709ba2bf75dd009849e0cb6171106377a871925445d566f4da9e0472',4559832),str(A/'result.json'):('1412fb1fae8cc34b8c72de7d5097cafa89dfc3590431f48a470e81c4c75d9845',57020),str(A/'runner-receipt.json'):('dbcdd1a28f97838d0f4db7178549fa0f2a037fd93c6f4c3e74c49d191dcf1fe8',5197)}
for p,(sha,size)in expected.items():
    value=pin(p);check('offered exact actual '+Path(p).name,value['sha256']==sha and value['bytes']==size)
for folder in(A,O):
    for p in sorted(folder.iterdir()):check('regular frozen savedfile '+str(p),p.is_file()and not p.is_symlink());pin(p)
check('exact successful actual inventory',sorted(p.name for p in A.iterdir())==['CONSUMED.json','WORKER_CONSUMED.json','canonical-finite-marking-qualification.json','result.json','runner-receipt.json','stderr.bin','stdout.bin','worker-receipt.json'])
check('exact observer inventory',sorted(p.name for p in O.iterdir())==['CONSUMED.json','stderr.bin','stdout.bin','terminal.json'])
check('no failure/prefix rescue',not any(p.name.endswith('.partial')or 'failure'in p.name.lower()for p in A.iterdir()))
for value,name in [(packet,'canonical-finite-marking-qualification.json'),(result,'result.json'),(header,'worker-receipt.json')]:
    check('complete canonical BODY plus LF '+name,(A/name).read_bytes()==canon(value)+b'\n')
check('all plan joins',all(v['plan']==planpin for v in[result,header,runner,terminal,consumed,worker_consumed,observer_consumed]))
check('one-use original Source epoch',consumed['maximum_worker_launches']==1 and consumed['consumed_before_Popen']is True and worker_consumed['maximum_invocations']==1 and observer_consumed['maximum_runner_launches']==1 and consumed['subject_sha256']==source_review['subject_sha256'])
check('exact work and outer deadline',all(v['began_ns']==runner['began_ns']and v['work_deadline_ns']==runner['began_ns']+180000000000 and v['overall_deadline_ns']==runner['began_ns']+210000000000 for v in[consumed,header,runner]))
check('worker/runner identities',worker_consumed['pid']==header['pid']==runner['worker_pid']==runner['owned_pgid']and worker_consumed['ppid']==header['ppid']==terminal['runner_pid']and header['worker_entry_ns']==worker_consumed['worker_entry_ns'])
check('single known zero exit with no signals',runner['worker_launch_attempts']==1 and runner['worker_exit_code']==0 and runner['worker_wait4_status']==0 and runner['worker_reaped']is True and terminal['runner_exit_code']==0 and runner['signals']==[])
check('declared actual command exact',runner['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],str(planpath)]and terminal['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['runner']['path'],str(planpath)])
check('positive complete work and resultread before180',runner['began_ns']<header['positive_worker_completed_ns']<=runner['worker_terminal_observed_ns']<=runner['positive_result_read_completed_ns']<runner['work_deadline_ns'])
check('terminal original210 clock',runner['closed_ns']<terminal['terminal_observed_ns']<runner['overall_deadline_ns']and abs((terminal['terminal_observed_ns']-runner['began_ns'])/1e9-terminal['runner_clock_elapsed_seconds'])<1e-9 and terminal['runner_clock_elapsed_seconds']==17.447299458)
check('observer main independent elapsed',terminal['observer_started_ns']==observer_consumed['observer_started_ns']<runner['began_ns']and abs((terminal['terminal_observed_ns']-terminal['observer_started_ns'])/1e9-terminal['observed_instrument_elapsed_seconds'])<1e-9)
check('recorded positive gates and narrow negative authority',runner['resource_candidate_accepted']is True and runner['finite_encoding_candidate']is True and header['finite_encoding_candidate']is True and terminal['terminal_gate_passed']is True and terminal['ROOT_resource_accepted']is False and all(v['scientific_acceptance']is False and v['mathematical_proof_accepted']is False and v['full_pipeline_qualified']is False for v in[runner,header,result,terminal]))
check('genuine retained positive closure',runner['owned_group_absent']is True and runner['regular_logs_closed']is True and all(v['opened']is True and v['close_attempts']==1 and v['closed']is True for v in runner['log_close_observations'].values())and runner['cleanup']['attempted']is False and runner['errors']==[]and runner['primary_failure']is None and runner['finalization_errors']==[])
for name in('post_child_raw_custody','whole_log_custody','final_physical_ledger'):
    check('outer custody completion '+name,runner[name]['completed_before_deadline']is True and runner[name]['completed_ns']<runner['overall_deadline_ns'])
check('full positive raw/log closure',runner['post_child_raw_custody']['checked']is True and runner['whole_log_custody']['complete']is True and runner['whole_log_custody']['stable']is True)
for name in('stdout','stderr'):raw('full stable log '+name,runner[name]);check('empty worker log '+name,runner[name]['bytes']==0)
raw('known terminal receipt join',terminal['runner_receipt']);raw('positive worker header pin',runner['worker_receipt']);raw('full result pin',runner['result']);raw('consumed pin',runner['consumed_marker'])
for value in runner['outputs']:raw('complete full output pin',value)
check('all output/result/header joins',runner['outputs']==header['outputs']==result['outputs']==result['qualification']['outputs']==[pin(packetpath)]and header['result']==runner['result']==pin(A/'result.json'))
logical=pin(packetpath)['bytes']+pin(A/'result.json')['bytes']
check('stored and fullyexpanded unshared logical cap',logical==4616852 and all(v['logical_result_bytes']==v['expanded_logical_result_bytes']==logical for v in[runner,header])and result['canonical_logical_bytes']==result['expanded_canonical_packet_bytes']==pin(packetpath)['bytes']and logical<=134217728)
before=sum(p.stat().st_size for p in A.iterdir()if p.name!='runner-receipt.json');ledger=runner['final_physical_ledger']
check('physical allfiles plus reserve exact',before==4619821==ledger['before_receipt_bytes']and ledger['conservative_bytes']==before+9437184==runner['conservative_physical_bytes']==14057005 and ledger['enumeration_complete']is True and ledger['stable_writer_quiescence']is True and ledger['within_original_cap']is True and ledger['conservative_bytes']<=134217728)
check('metadata reservations bounded',pin(A/'worker-receipt.json')['bytes']<=4194304 and pin(A/'runner-receipt.json')['bytes']<=8388608 and sum(p.stat().st_size for p in O.iterdir())<=1048576)
check('saved Darwin wait4 lifetime worker peak',type(runner['worker_peak_bytes'])is int and runner['worker_peak_bytes']==runner['worker_wait4_usage']['ru_maxrss']==46170112<1073741824)
check('retirement exact consumed joins',retire['actual_invocations']==1 and retire['remaining_invocations']==0 and retire['retired']is True and retire['repeat_authorized']is False and retire['plan']==planpin and retire['grant']==plan['authorization']and retire['consumed']==pin(A/'CONSUMED.json')and retire['worker_consumed']==pin(A/'WORKER_CONSUMED.json')and retire['runner_receipt']==pin(A/'runner-receipt.json')and retire['terminal']==pin(O/'terminal.json'))

q=result['qualification'];rows=packet['rows'];cases=inputs['cases']
check('packet complete input/profile equality',packet['inputs']==inputs and packet['limits']==decl['component_limits']and packet['full_base_assignments']==697 and packet['full_palette_assignments']==4214)
check('all162 case order/full literal IDs',len(rows)==162 and [r['id']for r in rows]==[r['id']for r in cases]==decl['case_ids']==q['case_ids'])
check('header/result qualification rows exact projection',q['rows']==[{k:r[k]for k in('id','status','assignments_checked','all_primitive_checks_passed','all_projection_checks_passed','all_uniqueness_checks_passed','full_palette_exhausted')}for r in rows])
population=collections.Counter();exhaustive_total=0;exhaustive_valid=0;case_census=[]
for index,(row,case)in enumerate(zip(rows,cases)):
    label='case'+str(index)+' '+case['id']+': '
    comp=row['compilation'];tr=row['independent_translation'];assignments=row['assignments']
    check(label+'full original and compiled metadata',row['original_case']==case and comp['base']==case['base']and comp['clauses']==case['clauses']and comp['status']=='MARKING_GADGET_CANDIDATE'and tr['status']=='VALID_MARKING_GADGET_TRANSLATION'and tr['construction_counts']==comp['construction_counts']and tr['base_tiles']==comp['mapping']['base_tiles']and tr['auxiliary_tiles']==comp['mapping']['auxiliary_tiles'])
    check(label+'strict narrow flags',comp['problem_defining']is True and comp['redundancy_established']is False and comp['mathematical_authority']is False and comp['executed_source_qualified']is False and tr['authority']is False and tr['formal_kernel_certified']is False and row['redundancy_established']is False and row['proof_search']is False)
    words=list(itertools.product([t['id']for t in case['base']['tiles']],repeat=len(case['base']['required_centers'])))
    expected_certificates=[dict(schema='finite-unit-center-placement-certificate-v1',placements=[dict(tile_id=tid,origin=p)for p,tid in zip(case['base']['required_centers'],word)])for word in words]
    check(label+'all complete raw assignment certificates/order',len(assignments)==row['assignments_checked']==case['complete_base_assignment_count']and [a['base_certificate']for a in assignments]==expected_certificates)
    check(label+'all checked row flags/status',row['status']=='VERIFIED_TRANSLATION_AND_ALL_BASE_ASSIGNMENTS'and all(row[k]is True for k in('all_primitive_checks_passed','all_projection_checks_passed','all_uniqueness_checks_passed')))
    expected_preimages={};local=collections.Counter()
    for a in assignments:
        status=a['status'];local[status]+=1;population[status]+=1;basecert=a['base_certificate']
        if status=='UNIQUE_ALLOWED_EXTENSION':
            ext=a['extension'];relation=a['relation'];projection=a['projection']
            ok=(a['original_check']['status']=='VALID_EXACT_FINITE_TILING'and ext['status']=='EXTENSION_CANDIDATE'and projection['status']=='PROJECTION_CANDIDATE'and a['expanded_check']['status']=='VALID_EXACT_FINITE_TILING'and a['projected_check']['status']=='VALID_EXACT_FINITE_TILING'and relation['status']=='VALID_EXTENSION_PROJECTION_RELATION'and relation['extension_exists']is True and relation['certificate']==ext['certificate']==a['expanded_check']['certificate']and relation['base_certificate']==projection['certificate']==a['projected_check']['certificate']==a['original_check']['certificate']==basecert)
            if not ok:raise AssertionError(label+'allowed full saved receipt join')
            expected_preimages[canon(basecert).decode()]=1
        elif status=='FORBIDDEN_BY_DECLARED_CLAUSE':
            relation=a['relation'];ok=(a['original_check']['status']=='VALID_EXACT_FINITE_TILING'and a['extension']is None and a['codec_refusal']['type']=='NoExtension'and relation['status']=='VALID_EXTENSION_PROJECTION_RELATION'and relation['extension_exists']is False and relation['certificate']is None and relation['base_certificate']==basecert)
            if not ok:raise AssertionError(label+'forbidden saved disposition')
            expected_preimages[canon(basecert).decode()]=0
        elif status=='INVALID_ORIGINAL_ASSIGNMENT':
            ok=(a['original_check']['status']=='INVALID_LITERAL_POINT_ASSIGNMENT'and a['extension']is None and a['codec_refusal']['type']=='DeclarationError')
            if not ok:raise AssertionError(label+'original invalid saved disposition')
            expected_preimages[canon(basecert).decode()]=0
        else:raise AssertionError(label+'unknown assignment status')
    check(label+'all saved disposition/certificate joins without legality replay',sum(local.values())==len(assignments))
    exhaustive=row['exhaustive'];check(label+'declared exhaustive versus linear method',row['full_palette_exhausted']is case['exhaustive_full_palette']and (exhaustive is not None)is case['exhaustive_full_palette'])
    exhaustive_count=0;valid=0
    if exhaustive is not None:
        full=exhaustive['assignments'];instance=comp['instance'];emitted_ids=[t['id']for t in instance['tiles']]
        complete_words=list(itertools.product(emitted_ids,repeat=len(instance['required_centers'])))
        fullcerts=[dict(schema='finite-unit-center-placement-certificate-v1',placements=[dict(tile_id=tid,origin=p)for p,tid in zip(instance['required_centers'],word)])for word in complete_words]
        check(label+'ALL raw emitted ID/ALLcenter certificates exact population',exhaustive['method']=='ALL_EMITTED_PALETTE_AT_ALL_REQUIRED_CENTERS'and len(full)==exhaustive['assignment_count']==len(complete_words)and [a['certificate']for a in full]==fullcerts)
        preimages={key:0 for key in expected_preimages}
        for a in full:
            status=a['check']['status']
            if status=='VALID_EXACT_FINITE_TILING':
                if a['check']['certificate']!=a['certificate']:raise AssertionError(label+'normalized full certificate join')
                key=canon(a['projected_base_certificate']).decode()
                if key not in preimages:raise AssertionError(label+'preimage raw certificate outside base population')
                preimages[key]+=1;valid+=1
            elif status!='INVALID_LITERAL_POINT_ASSIGNMENT':raise AssertionError(label+'unknown exhaustive check status')
        check(label+'recorded zero/one preimage receipt joins',preimages==expected_preimages and exhaustive['projection_preimage_counts']==[[k,v]for k,v in sorted(preimages.items())]and exhaustive['exact_expected_preimages_matched']is True)
        exhaustive_count=len(full);exhaustive_total+=len(full);exhaustive_valid+=valid
    case_census.append(dict(id=row['id'],base_assignments=len(assignments),recorded_dispositions=dict(local),exhaustive_raw_assignments=exhaustive_count,recorded_valid_exhaustive_tilings=valid,comparison_scope='Saved receipts/full-value population joins only; no t/m legality or prefix predicate recomputation.'))

check('exact39429112 saved dispositions',dict(population)=={'UNIQUE_ALLOWED_EXTENSION':394,'FORBIDDEN_BY_DECLARED_CLAUSE':291,'INVALID_ORIGINAL_ASSIGNMENT':12}and sum(population.values())==697)
check('exact12/4214 exhaustive saved domain',sum(r['exhaustive']is not None for r in rows)==12 and exhaustive_total==4214 and exhaustive_valid==11)
diags=packet['diagnostics'];check('all15 diagnostic full packet/result order',diags==q['diagnostics']and len(diags)==15 and [r['id']for r in diags]==[r['id']for r in inputs['diagnostics']]==decl['diagnostic_ids']==q['diagnostic_ids'])
for r,d in zip(diags,inputs['diagnostics']):
    check('diagnostic saved reach '+r['id'],r['operation']==d['operation']and r['status']=='PASSED'and r['reached']is True and r['expectation_satisfied']is True and type(r['check_calls_before'])is int and type(r['check_calls_after'])is int and 0<r['check_calls_before']<=r['check_calls_after']<400000000)
check('three exact planned callback controls',all(diags[i]['expected_kind']=='FOREIGN'and diags[i]['exact_foreign_identity']is True and diags[i]['local_callbacks']==1 for i in[12,13,14])and diags[13]['error']['type']=='GadgetLimit')
check('owned UNKNOWN and owned refusal not acceptance',diags[10]['returned']['status']=='UNKNOWN'and diags[10]['returned']['reason']=='work'and diags[10]['returned']['counts']['work']==2 and diags[11]['expected_kind']=='verifier_owned_work'and diags[11]['error']['type']=='ResourceLimit')
check('three complete mutated profile packets retained',all(type(diags[i]['mutated_compilation'])is dict and diags[i]['error']['type']=='Invalid'for i in[7,8,9]))
started=header['call_started'];completed=header['call_completed'];raised=header['call_raised']
check('strict call maps sum started=completed+raised',all(type(v)is int and v>=0 for values in[started,completed,raised]for v in values.values())and all(started[k]==completed.get(k,0)+raised.get(k,0)for k in started))
expected_counts={'compiler.compile_marking_gadget':172,'compiler.extend':697,'compiler.project':394,'compiler.GadgetLimit':1,'verifier.verify_translation':165,'verifier.verify_extension':685,'verifier.verify_tiling':5701,'verifier.is_own_invalid':4218,'verifier.is_own_limit':1}
check('instrumented entries match complete saved populations and controls',started==expected_counts and completed['compiler.extend']==394 and raised['compiler.extend']==303 and completed['verifier.verify_translation']==162 and raised['verifier.verify_translation']==3)
for role in('compiler','verifier'):
    count=sum(v for k,v in started.items()if k.startswith(role+'.'))
    check('role entry census '+role,q[role+'_calls']==result[role+'_calls']==runner[role+'_calls']==count)
check('original callback ceiling and cutoff ordering',type(q['root_check_calls'])is int and diags[-1]['check_calls_after']<=q['root_check_calls']<=header['root_check_calls']==16511575<=400000000)
check('all explicit broader authority flags false',all(packet[k]is False for k in('redundancy_established','learned_markings','trained_RL','proof_search','full_pipeline_qualified','mathematical_proof_accepted'))and all(q[k]is False for k in('full_pipeline_qualified','mathematical_proof_accepted','fixed_FOL_palette_qualified','gcts_rl_advantage_established','learned_markings','trained_RL','redundancy_established')))
check('no scientific runtime roles or separate search APIs',all(type(result[k])is int and result[k]==0 for k in('Native_calls','Model_calls','Reader_calls','inverse_calls','proof_checker_calls','opaque_program_decodes','search_calls','oracle_calls')))
pin(C/'typed-marking-component-Source-prospective-review-v1.json');pin(C/'typed-marking-final-grant-delta-review-v1.json');pin(D/'ROOT-grant-retirement-v1.json')
barrier=D/'ROOT-all-idle-fresh-barrier-v1.json';pin(barrier)
v=dict(schema='finite-point-marking-component-saved-review-v1',reviewer_identity='/root/conventional_control_review',saved_review_passed=True,
    saved_data_only=True,review_component_calls=0,component_calls=0,scientific_calls=0,subject_imports=0,fixture_calls=0,simulations=0,process_probes=0,opaque_decodes=0,
    actual_execution_authorized=False,finite_component_qualification_supported=True,scientific_acceptance=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,
    classification='COMPLETE_FINITE_POINT_MARKING_TRANSLATION_COMPONENT_GATES_SUPPORTED',
    plan=planpin,authorization=plan['authorization'],subject_sha256=source_review['subject_sha256'],sources=plan['sources'],
    complete_packet=pin(packetpath),result=pin(A/'result.json'),runner=pin(A/'runner-receipt.json'),terminal=pin(O/'terminal.json'),retirement=pin(D/'ROOT-grant-retirement-v1.json'),
    finite_scope=dict(translations=162,base_assignments=697,recorded_dispositions=dict(population),exhaustive_artifacts=12,full_emitted_palette_ALL_center_assignments=4214,recorded_valid_exhaustive_tilings=11,diagnostics=15,exact_foreign_first_callback_controls=3),
    metrics=dict(runner_Source_entry_terminal_seconds=terminal['runner_clock_elapsed_seconds'],observer_main_seconds=terminal['observed_instrument_elapsed_seconds'],worker_lifetime_peak_bytes=runner['worker_peak_bytes'],worker_lifetime_peak_MiB=runner['worker_peak_bytes']/1048576,stored_and_expanded_logical_bytes=logical,physical_pre_runner_receipt_bytes=before,conservative_reserved_physical_bytes=ledger['conservative_bytes'],compiler_instrumented_entries=q['compiler_calls'],verifier_instrumented_entries=q['verifier_calls'],header_root_callback_cutoff=header['root_check_calls']),
    literal_observer_ROOT_resource_accepted=terminal['ROOT_resource_accepted'],literal_runner_resource_candidate_accepted=runner['resource_candidate_accepted'],literal_terminal_gate_passed=terminal['terminal_gate_passed'],
    case_census=case_census,typed_checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=sorted(rawpins.values(),key=lambda p:p['path']),
    limitations=[
      'Passive saved-data review only. Full ordinary JSON values, population certificates/order and receipt statuses were joined; this reviewer did NOT recompute point t/m legality, clause truth, state recurrence, structural translation, projections or search outcomes, invoke a checker/codec, import targets or replay the actual.',
      'Finite component qualification is supported only for this exact162/697/4214/15 subject under the declared trusted runtime. Source-only and prelaunch freshness statements are historical; this one actual now executed, closed and its grant is retired. Root may separately adopt the narrow derived status; literal worker remains a qualification CANDIDATE and observer ROOT_resource_accepted remains false as stored.',
      'Full emitted-palette enumeration covers only12 artifacts/4214 ALL-center assignments. Other rows use the independently checked linear prefix correspondence, not exhaustive expanded assignment search. Per-row all-checks flags mean all applicable checks, not a positive extension/project call on forbidden or invalid originals. Saved aggregate394 allowed/291 forbidden/12 invalid is not a newly discovered theorem.',
      'Arbitrary supplied clauses are problem-defining. No primitive redundancy proof or preservation of ALL original solutions is established. Repeated/contradictory words, long-range multichannel point assignments and literal IDs are represented within a finite unit-center2Z2 specialization; no ordinary nearest-neighbor localization, universal fixed palette, fractional/shared support, mixed generation or general engine conformance.',
      'No separate search component/scheduler/rollback engine was offered. Finite itertools enumeration is real combinatorial checking work, so search_calls0 is an API-scope statement, not zero enumeration/CPU work. Physical TM adapter remains Source-only and unimported. No FOL/lowering/kernel/unknown-proof bridge, GCTS learning/RL benefit or old680 failure rescue.',
      '15 diagnostics reached selected malformed-data, owned-work and three first-callback foreign controls only. Exact identity was checked in-process by reviewed Source and retained as a result flag, not reconstructed from serialization. No all-class/late-site/persistent-mutation coverage or real Root-fault branch test is inferred. Missing total private operation costs remain unavailable; per-call counters and Root callbacks are distinct units.',
      'Original180s work/header/result-read/known-exit and later210s custody/terminal gates passed; worker-only Darwin lifetime HWM does not cover parent allocations or simultaneous aggregate RAM. No speed/RAM advantage comparison or measured per-phase allocation is established by this one component actual.',
      'C made no process probe. Known wait4 zero-exit, owned group absence, genuine parent closes/stable whole logs are retained owner observations. Cleanup attempted:false/NOT_OBSERVED is literal on the successful normal path, not a failed negative-cleanup gate. No process state or OS guarantee beyond that trusted record is claimed.',
      'Inherited raw-SourceFileLoader/postload callable binding and exclusive-owner/read-only callback trust remains; no hostile code/pyc/default-content/global/OS seal or formal independent kernel certification. Root owns worker/controller, Library compiler/codecs, B separate verifier; same C reviewer and historical protocol/control ancestry are disclosed.',
    ],
    interpreter=dict(executable=sys.executable,version=sys.version,flags='-I -S -B',activity='own stdlib raw bytes/ordinary JSON and metadata population joins only'),tools_stopped_after_handoff=True)
p=C/'typed-marking-saved-actual-review-v1.json'
if p.exists():raise FileExistsError(p)
p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(dict(receipt=pin(p),checks=len(checks),mismatch_count=0,metrics=v['metrics']),sort_keys=True))
