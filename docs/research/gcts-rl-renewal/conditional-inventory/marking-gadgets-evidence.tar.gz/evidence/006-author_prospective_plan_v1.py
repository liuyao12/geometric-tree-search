"""Ordinary plan/AST metadata author only; no component import or execution."""
from pathlib import Path
import ast
import hashlib
import json
import sys
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
OLD=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
SOURCES=dict(worker=D/'qualify_marking_worker_v1.py',compiler=Path('/private/tmp/gcts-unit-center-receptor-library-20261019/unit_center_marking_compiler_v1.py'),
    verifier=Path('/private/tmp/gcts-finite-marking-verifier-20261019-v1/finite_marking_verifier_v1.py'),
    runner=D/'run_marking_qualification_once_v1.py',observer=D/'observe_marking_qualification_once_v1.py')
LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,
    expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608,observer_bytes=1048576)
POINT_LIMITS=dict(work=400000000,centers=1024,tiles=100000,marks=1000000,clauses=256,literals=1024,
    candidates=1000000,integer_abs=1000000,string_chars=1024,data_depth=64)
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(path):
    path=path.resolve();raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,value):
    path=D/name
    with path.open('xb')as f:f.write(json.dumps(value,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    return pin(path)
def main():
    if Path(sys.executable).resolve()!=PYTHON.resolve():raise ValueError('pinned Python AST attribution')
    sources={k:pin(v)for k,v in SOURCES.items()};inputs=json.loads((D/'cohort-inputs-v1.json').read_bytes())
    input_entries=[dict(id='complete-finite-marking-162-697-4214-15-component-bank',pin=pin(D/'cohort-inputs-v1.json'))]
    declaration=dict(schema='ROOT-wang-encoding-qualification-declaration-v1',author_identity='/root',
        experiment_kind='FINITE_POINT_MARKING_TRANSLATION',limits=LIMITS,
        component_limits={key:dict(POINT_LIMITS)for key in('compiler','verifier')},checkpoint_limit=400000000,
        inputs=input_entries,case_ids=[r['id']for r in inputs['cases']],
        case_assignment_counts=[r['complete_base_assignment_count']for r in inputs['cases']],
        diagnostic_ids=[r['id']for r in inputs['diagnostics']],diagnostics=inputs['diagnostics'],
        exact_translations=162,exact_base_assignments=697,exact_full_palette_assignments=4214,exact_diagnostics=15,
        full_pipeline_qualified=False,actual_execution_authorized=False,
        target='Compile supplied conjunctions into actual point markings; verify exact finite extension/projection and literal identity. This is a distinct representation-component question, not a performance baseline, smaller-bank retry or rescue of original680+55.',
        point_profile='Finite nonempty even-coordinate unit-center translations only; every required origin explicit. General finite marking channels/signed offsets including remote points and assigned0. Full palette×origin universe, no hidden role filter. No fractional/shared positive support, rotations or generic scheduler qualification.',
        method='All697 base assignments checked against original raw point data. Complete independent structural gadget check plus independent unique-prefix necessity/sufficiency. Full raw emitted-palette^ALL-centers enumeration4214 in12 predeclared n1 one-clause artifacts. Other artifacts use linear correspondence, NOT exhaustive emitted assignments.',
        case_bank=inputs['whole_population'],exhaustive_scope=inputs['exhaustive_scope'],
        authority='Arbitrary supplied clauses are problem-defining. No primitive failure redundancy certificate, learned marking, RL policy, unknown theorem/proof discovery, fixed FOL table/palette or full pipeline authority.',
        cost_scope='All parsing/copying/reconstruction/argument and Source guards/output wall charged inside original window. Root400m counts callbacks cumulatively, not CPU steps or old Arena work. Compiler and verifier400m are separate private per-call definitions. Returned work/owned failure prefixes are evidence only where exported; absent totals are unavailable, never fabricated zero.',
        runtime_trust='Exclusive ordinary input ownership/read-only callbacks. Full raw Source pins and recursive callable seals around calls; builtin/frozen/transitive stdlib and OS loader trusted. No hostile-code sandbox or universal loader seal.',
        resource_scope='Complete result/header/known exit/bytes before original180s Source-entry epoch; all cleanup/raw/log/physical/resource and external terminal before210s. Observer225s fallback only, no extension. Darwin worker1GiB; stored/expanded/physical128MiB; original9MiB outer+observer reservation. Parent allocations outside worker HWM.',
        finite_diagnostic_scope='15 declared malformed point/profile, own-work and first-callback foreign-object controls; not every malformed table, callback/exception class, quota or interruption site. Full palette enumeration catches role misplacements in declared subdomain only.',
        preserved_failures='Original whole680+55 off/on deadline negatives and old whole production workload remain failed. No old grant reuse, cap raise, smaller old bank, prefix acceptance, or later custody rescue.',
        no_rescue='One fresh exact-subject actual maximum; every162/697/4214/15 item required. Any UNKNOWN/unreached/failed item prevents whole component candidate admission.',
        snapshot_lifecycle='All complete compiler inputs/outputs and every raw full-palette certificate/disposition retained in the whole result. No graph snapshots because no search engine is offered. Failure metadata is unadmitted diagnostic cutoff only.',
        implementation_ancestry='L compiler+codecs and B independently authored literal point/translation verifier. C separate scoped Source/prospective/data review; no formal-kernel theorem claim.',
        fixed_FOL_adapter='Separate Source-only physical-table integer adapter, not loaded or called in this actual.',
        forbidden_calls=dict(Native=0,Model=0,inverse=0,Reader=0,proof_checker=0,opaque_decode=0,search=0))
    dp=save('declaration-v1.json',declaration)
    previous=json.loads((OLD/'runtime-closure-v3.json').read_bytes());census=[]
    for role,path in SOURCES.items():
        tree=ast.parse(path.read_bytes());imports=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):imports.extend(x.name for x in node.names)
            elif isinstance(node,ast.ImportFrom):imports.append(node.module)
        census.append(dict(role=role,source=sources[role],direct_imports=sorted(set(imports)),
            AST_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
    closure=dict(schema='ROOT-wang-encoding-runtime-closure-v1',python=pin(PYTHON),sources=sources,declaration=dp,
        stdlib_files=[pin(Path(row['path']))for row in previous['stdlib_files']],direct_import_census=census,
        AST_parser=dict(executable=str(Path(sys.executable).resolve()),version=sys.version,
            policy='ast.dump(ast.parse(raw),include_attributes=False), UTF-8 sha256, Source-only census'),
        runtime_trust=declaration['runtime_trust'],source_only=True,actual_execution_authorized=False)
    cp=save('runtime-closure-v1.json',closure)
    subject=dict(schema='ROOT-wang-encoding-qualification-plan-v1',invocation_id='finite-unit-center-marking-162-v1',
        actual_directory=str(D/'actual-component-v1'),python=pin(PYTHON),sources=sources,inputs=input_entries,
        limits=LIMITS,declaration=dp,runtime_closure=cp)
    sha=hashlib.sha256(canon(subject)).hexdigest()
    ap=save('authorization-false-v1.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',
        actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=sha,review=None,
        scope='Source-only prospective offer; no mathematical execution authorization.'))
    pp=save('plan-false-v1.json',dict(subject,authorization=ap))
    offer=save('Source-only-offer-v1.json',dict(schema='ROOT-wang-prospective-offer-v1',subject=subject,
        subject_sha256=sha,false_plan=pp,sources=sources,component_calls=0,actual_execution_authorized=False))
    print(json.dumps(dict(offer=offer,subject_sha256=sha),sort_keys=True))
if __name__=='__main__':main()
