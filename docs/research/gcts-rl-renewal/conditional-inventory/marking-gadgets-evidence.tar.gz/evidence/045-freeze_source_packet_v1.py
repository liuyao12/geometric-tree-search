"""Ordinary Source/AST/metadata author only; no subject import/evaluation."""
import ast
import hashlib
import json
from pathlib import Path
D=Path('/private/tmp/gcts-unit-center-receptor-library-20261019')
S=D/'unit_center_marking_compiler_v1.py'

def pin(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    path=D/name
    with path.open('xb')as stream:stream.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    return pin(path)

raw=S.read_bytes();tree=ast.parse(raw,filename=str(S));compile(tree,str(S),'exec')
assert not any(isinstance(n,(ast.Import,ast.ImportFrom,ast.Yield,ast.YieldFrom,ast.AsyncFunctionDef,ast.Await))for n in ast.walk(tree))
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
assert {'compile_marking_gadget','extend','project'}<=set(functions)
assert not any(isinstance(n,ast.GeneratorExp)for n in ast.walk(functions['_same']))
literals={n.targets[0].id:ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)
    and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
common=dict(author_identity='/root/conventional_library',source_only=True,subject_imports=0,component_calls=0,
    fixture_calls=0,actual_execution_authorized=False,scientific_acceptance=False)
note=pin('/private/tmp/gcts-wang-receptor-ROOT-20261019-v1/nogood-marking-construction.html')
api=save('API-v1.json',dict(schema='unit-center-marking-compiler-API-v1',**common,Source=pin(S),version=literals['VERSION'],
    entries=['compile_marking_gadget(base,clauses,*,check,limits)','extend(compilation,base_certificate,*,check,limits)',
             'project(compilation,extended_certificate,*,check,limits)'],
    limits=literals['LIMIT_KEYS'],limit_rules='Every limit exact positive builtin int, data_depth<=128. No numeric allowance selected here. Work cumulative over all copying/building/rebuilding/reconciliation/codec passes. Capacity limits are per complete object: centers/tiles/clauses/total literals, total emitted prototype+pin mark rows, full palette times all origins, absolute math integer atoms, per-string characters, copy depth. Old Root wall/RAM/output limits are not raised.',
    base=dict(schema=literals['INSTANCE_SCHEMA'],keys=literals['BASE_KEYS'],
        transformations='translations_only_2Z2',required_origins='Nonempty ordered distinct even integer coordinate pairs; admissible_origins exactly same complete list.',
        tiles="Nonempty array {id:distinct nonnegative exact literal int,t:[[[0,0],1]],m:[[signed_offset_pair,Unicode_scalar_channel_str,nonnegative_exact_int],...]}. IDs may be noncontiguous; identical pointdata with different IDs remain distinct. No repeated point/channel within a prototype.",
        fixed_background_marks='Same row format, absolute coordinates, any finite original channels/remote marks; explicit0 retained. No duplicate point/channel. all_root_generations exactint0.'),
    clauses='Ordered arrays of ordered {origin:[x,y],tile_id:original literalID}. Every origin/ID must exist. Empty clauses permitted. Repeated literal, repeated center, contradictory literal and duplicate clause retained without simplification; broader than note distinct-center lemma and requires separate qualification.',
    compilation=dict(schema=literals['COMPILATION_SCHEMA'],keys=literals['RESULT_KEYS'],status='MARKING_GADGET_CANDIDATE',
        instance='Full emitted same-schema ordinary point instance. Every prototype assigns its own center anchor; full translation palette times exact origins, no hidden role filter.',
        mapping_keys=['channels','base_tiles','roles','clause_states','auxiliary_tiles'],
        base_tiles='[[emittedID,originalLiteralID],...] in original tile order; emitted IDs contiguous0-based.',
        roles="[{role:positive unique int,clause:index,literal_index:int|null,center:[x,y],kind:'step'|'empty'}] ordered clause then literal; empty clause has one role with no prototype.",
        clause_states='[{clause:index,states:[absolute points],roles:[roleIDs]}] one per clause; empty states[].',
        auxiliary_tiles='[[emittedID,role,originalChoiceID,incoming0or1,outgoing0or1],...] role then original tile order then incoming0,1.',
        authority='problem_defining:true;redundancy_established:false;mathematical_authority:false;executed_source_qualified:false ALWAYS, regardless any external failure certificate.'),
    placement_certificate=dict(schema=literals['CERTIFICATE_SCHEMA'],keys=['schema','placements'],
        placements='Complete array {tile_id,origin:[x,y]}; arbitrary input order; exact IDs/one per required origin; no extra fields/rotation/duplicates. Returned codecs normalize required-center order.'),
    codec_results='EXTENSION_CANDIDATE or PROJECTION_CANDIDATE with complete certificate,counts,mathematical_authority:false,compilation_rebuilt:true. Codecs rederive full instance/mapping/counts and type-exact compare; check full t/m board including every remote assignment. NoExtension (DeclarationError subclass) means the supplied valid base assignment contains a forbidden conjunction, not unprovability of the original instance.',
    errors='Malformed DeclarationError; own exact-class private per-call GadgetLimit -> UNKNOWN(reason,counts,authorityfalse), no partial instance/certificate. Foreign exceptions including same class, ValueError,StopIteration,SystemExit propagate exact identity. Independent input ownership/current Source guards remain caller obligations.',
    mathematical_scope='Finite long-range point markings, not conventional nearest-neighbor square Wang tiles, fixed universal palette, proof search, Native admission, learned/RL marking or automatic certified-negative authority.'))
layout=save('layout-and-correspondence-v1.json',dict(schema='unit-center-marking-layout-v1',**common,Source=pin(S),construction_note=note,
    fresh_channels="Collect every original prototype/pin channel. In anchor,choice,state order choose '__receptor_'+kind+'__', or append ':0',':1',... first unused. Fresh assignments never alter original channels/values.",
    layout='X=max original center x,Y=max original center y. Enumerate roles r=1..R in clause/literal order (one empty role for empty clause); r-center=[X+2*r,Y+2]. Enumerate state points j=1..S in nonempty clause order, k+1 each: [X+2*(R+j),Y+4]. Both are outside base centers, roles/state points distinct. Exact offsets from each auxiliary center emitted.',
    prototype_order='Lift base tiles first in original order, t unchanged, original m unchanged prefix then center choice(literalID),center anchor0. Step roles then original tile input order then incoming0,1. Empty roles emit no prototype.',
    auxiliary_marks='Center anchor(role);remote choice at literal origin with actual chosen v;state at previous point a;state at next point int(a==1 and v==forbidden tileID). All four rows fixed at compilation, then ordinary marking agreement only.',
    pin_order='Original pins prefix, base center anchor0 in original origin order, every role center anchor(role), then each nonempty chain first state1 and last state0. Required/admissible base order plus role centers.',
    recurrence=r'\(s_0=1,\quad s_i=s_{i-1}\land[v_i=u_i],\quad s_k=0.\)',
    argument='Center anchors force correct base/auxiliary roles because every prototype assigns its own center anchor and all allowed origins are pinned. Shared choice channel reads exactly the original literal tile at each base center. Distinct fresh state points enforce the recurrence; final0 iff at least one forbidden literal fails. Repeated reads of one center use the same choice value, so repetitions/contradictions require no simplification. Empty role pin is assigned by no prototype, hence no complete extension.',
    projection='Removing auxiliaries and fresh channels leaves every original literal ID,t/m/pin unchanged. Every base tiling satisfying all forbidden conjunction exclusions has unique lift/chain extension, including repeated-center words. If a separate independent failure certificate proves those clauses redundant for this exact base, only THEN the original solution set is preserved. This compiler never establishes that premise.',
    no_runtime_scanner='Search receives full emitted t/m data and origin crossproduct, not a classifier or forbidden-clause predicate. Extension codec computes prefix states for a supplied complete base board; this is a correspondence codec, not the search legality mechanism.',
    formulas=r'\(N_{\mathrm{aux tiles}}=2|T|\sum_{C\ne\varnothing}|C|,\quad N_{\mathrm{aux centers}}=\sum_{C\ne\varnothing}|C|+\#\{C=\varnothing\}.\)',
    conformance='Unit-center integer specialization. All required centers are roots0. A future engine must preserve complete t/m incidence including remote points, global DEAD/FORCED/earliest, exact rollback; compiler alone does not qualify such an engine.'))
contract=save('Source-contract-v1.json',dict(schema='unit-center-marking-compiler-Source-contract-v1',**common,Source=pin(S),API=api,layout=layout,
    master=dict(publisher='/private/tmp/gcts-split-controls-publish-20261015',git_object='b820acaf:docs/basic-tiling-algorithm.md',sha256='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4',bytes=36240),
    preservation='No old Source, failed actual, retired grant, corpus or publisher files changed. Pure new compiler/codec; no existing search or V3 cache modified.',
    custody='All caller structures copied with strict finite types, depth/cycle/Unicode checks; persistent whole input reread/type-exact reconciliation before any successful return. No mutable caller aliases retained. Returned candidates are ordinary mutable data, not immutable authority; codecs rebuild complete compilation before use. Counters are passive, not authenticated theorem facts.',
    checkpoints='Initial check plus direct check every charged work unit and final public completion; own caps checked before delegation. No generator wrapper around callback-bearing full comparison. Read-only callbacks/exclusive ownership required; hostile restore-between-reads mutation/OS sandbox not claimed.',
    trust='Same Library author as prior compiler/search/verifier; own static arguments are not independent certification. Root/C/B separate mathematical/Source/qualification scrutiny still required.',
    gaps=['No function, fixture, compiler, codec, search, verifier, Native, Model, Reader or opaque object executed/imported.',
          'Repeated/contradictory centers extend reviewed note scope and have only informal recurrence argument, not a formal kernel proof.',
          'No numbers chosen for private limits, no runtime fit/speed/point-engine conformance or full fixed FOL checking bridge.',
          'Private object copies/rebuilds and full emitted palette×origin universe may be expensive; all costs must be measured under a fresh bounded Root grant.']))
audit=save('author-static-audit-v1.json',dict(schema='unit-center-marking-author-static-audit-v1',**common,Source=pin(S),unused_compiles=2,
    imports=[],public_entries=['compile_marking_gadget','extend','project'],
    confirmations=['Strict type/shape/Unicode/cycle bounds; bool differs from int.',
        'Distinct original literal IDs preserved; no geometric/semantic prototype dedup.',
        'Original t/m/pins copied unchanged; only fresh channels appended.',
        'All emitted prototypes center-anchored; empty role has no matching prototype.',
        'All2*original_palette*clause_literal state variants emitted; exact finite origin union.',
        'Ordered/repeated reads retained; start1/end0 state pins.',
        'Full codec reconstruction/point legality and caller second-read reconciliation.',
        'Only own exact-class owner-token limits normalized; direct callback-bearing comparisons use explicit loops.',
        'Source parsed and compiled without execution; no diagnostic or finite correspondence test reported passed.'],
    remaining='Independent B/C review, malformed/fault/finite extension/projection qualification and new reviewed Root grant pending.'))
h=save('handoff-v1.json',dict(schema='unit-center-marking-compiler-handoff-v1',**common,Source=pin(S),API=api,layout=layout,
    Source_contract=contract,author_static_audit=audit,author_Source=pin(__file__),construction_note=note,
    status='FROZEN_SOURCE_ONLY_UNEXECUTED_NO_GRANT',tools_stopped_after_handoff=True))
print(json.dumps(dict(Source=pin(S),API=api,layout=layout,handoff=h),sort_keys=True))
