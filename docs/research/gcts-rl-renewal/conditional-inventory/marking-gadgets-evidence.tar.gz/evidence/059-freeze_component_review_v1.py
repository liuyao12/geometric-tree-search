"""Independent raw/AST/ordinary input metadata review; no target execution."""
from pathlib import Path
import ast
import hashlib
import itertools
import json
import sys

C=Path('/private/tmp/gcts-geometric-nogood-review-20261019')
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
checks=[]
def h(b):return hashlib.sha256(b).hexdigest()
def pin(path):
    p=Path(path);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=h(b))
def read(path):return json.loads(Path(path).read_bytes())
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def check(name,ok):
    checks.append(dict(id=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def raw(name,p):check(name,pin(p['path'])==p and Path(p['path']).is_absolute()and str(Path(p['path']).resolve())==p['path']and not Path(p['path']).is_symlink())
def definitions(text):return{n.name:ast.dump(n,include_attributes=False)for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def constant(text,name):
    n=next(n for n in ast.parse(text).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets))
    if isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Name)and n.value.func.id=='dict':return{k.arg:ast.literal_eval(k.value)for k in n.value.keywords}
    return ast.literal_eval(n.value)

offer=read(D/'Source-only-offer-v1.json')
check('exact offered raw descriptor',pin(D/'Source-only-offer-v1.json')['sha256']=='0b79f56b76b60beaf1f5b93a123fc66d85c5155017493ec27dd967b8b89289f9'and pin(D/'Source-only-offer-v1.json')['bytes']==4532)
raw('false plan',offer['false_plan']);plan=read(offer['false_plan']['path'])
check('ten complete plan fields',set(plan)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'})
subject={k:v for k,v in plan.items()if k!='authorization'};sha=h(canon(subject))
check('full nine-field exact subject',len(subject)==9 and subject==offer['subject']and sha==offer['subject_sha256']=='ad27df100beb18e87701817fe2ef3c7d6a51ca2af806f975ee5a62f2c76f7701')
check('offer itself no actual grant',offer['actual_execution_authorized']is False and type(offer['component_calls'])is int and offer['component_calls']==0)
sources=plan['sources'];texts={}
check('full five Source closure',set(sources)=={'compiler','verifier','worker','runner','observer'}and sources==offer['sources'])
for role,p in sources.items():
    raw('whole Source '+role,p);texts[role]=Path(p['path']).read_text();unused=compile(texts[role],p['path'],'exec');del unused
raw('whole interpreter',plan['python'])
check('pinned parser/interpreter',sys.executable==plan['python']['path']and sys.version.startswith('3.12.14 ')and plan['python']['sha256']=='21a9986bad1dbbcd813a252b19b4263fc0755ed2dbf8632c83e5d6117a12f319')
raw('declaration',plan['declaration']);raw('runtime closure',plan['runtime_closure'])
decl=read(plan['declaration']['path']);closure=read(plan['runtime_closure']['path'])
check('complete closure binding',closure['sources']==sources and closure['python']==plan['python']and closure['declaration']==plan['declaration'])
check('parser attribution exact',closure['AST_parser']['executable']==sys.executable and closure['AST_parser']['version']==sys.version)
for item in closure['direct_import_census']:
    role=item['role'];tree=ast.parse(texts[role])
    imports=sorted({n.module if isinstance(n,ast.ImportFrom)else a.name for n in ast.walk(tree)if isinstance(n,(ast.Import,ast.ImportFrom))for a in(n.names if isinstance(n,ast.Import)else[None])})
    check('raw AST attribution '+role,item['source']==sources[role]and item['AST_sha256']==h(ast.dump(tree,include_attributes=False).encode())and item['direct_imports']==imports)
check('all five AST census entries',len(closure['direct_import_census'])==5 and {r['role']for r in closure['direct_import_census']}==set(sources))
for i,p in enumerate(closure['stdlib_files']):raw('stdlib entry '+str(i),p)
limits=constant(texts['worker'],'OUTER_LIMITS');point=constant(texts['worker'],'POINT_LIMITS')
check('unchanged literal real gates',limits==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576)==plan['limits']==decl['limits'])
check('explicit exact helper profile',point==dict(work=400000000,centers=1024,tiles=100000,marks=1000000,clauses=256,literals=1024,candidates=1000000,integer_abs=1000000,string_chars=1024,data_depth=64)and decl['component_limits']=={r:point for r in('compiler','verifier')}and decl['checkpoint_limit']==400000000)
for role in('compiler','verifier'):
    check(role+' strict limit keys',set(constant(texts[role],'LIMIT_KEYS'))==set(point))
    check(role+' pure no imports',not any(isinstance(n,(ast.Import,ast.ImportFrom))for n in ast.walk(ast.parse(texts[role]))))
    check(role+' no callback-bearing generator',not any(isinstance(n,(ast.Yield,ast.YieldFrom))for n in ast.walk(ast.parse(texts[role]))))
check('declaration new component question',decl['experiment_kind']=='FINITE_POINT_MARKING_TRANSLATION'and decl['actual_execution_authorized']is False and decl['full_pipeline_qualified']is False)
check('one complete new input',plan['inputs']==decl['inputs']and len(plan['inputs'])==1)
p=plan['inputs'][0]['pin'];raw('whole input preimage',p)
check('exact immutable new bank pin',p['sha256']=='155280e0539b36b9a7afc9e885edcf12fac8c9fe24ec5ec74ea040e5506782ec'and p['bytes']==234761)
inputs=read(p['path']);cases=inputs['cases']
check('exact case IDs/order',len(cases)==inputs['exact_case_count']==decl['exact_translations']==162 and len({r['id']for r in cases})==162 and [r['id']for r in cases]==decl['case_ids'])
check('per-case exact raw metadata fields',all(set(r)=={'id','base','clauses','family','complete_base_assignment_count','exhaustive_full_palette'}for r in cases))
check('all base assignment counts',all(type(r['complete_base_assignment_count'])is int and r['complete_base_assignment_count']==len(r['base']['tiles'])**len(r['base']['required_centers'])for r in cases)and sum(r['complete_base_assignment_count']for r in cases)==inputs['exact_base_assignment_count']==decl['exact_base_assignments']==697)
check('ordered assignment count joins',[r['complete_base_assignment_count']for r in cases]==decl['case_assignment_counts'])
check('all15 diagnostic exact operations/order',len(inputs['diagnostics'])==15 and inputs['diagnostics']==decl['diagnostics']and [r['id']for r in inputs['diagnostics']]==decl['diagnostic_ids'])
single=[r for r in cases if r['family']=='complete-one-clause-population'];pairs=[r for r in cases if r['family']=='complete-two-clause-population']
profiles=[r for r in cases if r['family']not in('complete-one-clause-population','complete-two-clause-population')]
check('complete declared147 core and15 profiles',len(single)==100 and len(pairs)==47 and len(single)+len(pairs)==147 and sum(r['complete_base_assignment_count']for r in single+pairs)==613 and len(profiles)==15 and sum(r['complete_base_assignment_count']for r in profiles)==84)
for n in range(1,4):
    for b in range(1,3):
        subset=[r for r in single if len(r['base']['required_centers'])==n and len(r['base']['tiles'])==b]
        atoms=[dict(origin=[2*i,0],tile_id=7*j)for i in range(n)for j in range(b)]
        wanted=[[]]+[[list(word)]for k in range(3)for word in itertools.product(atoms,repeat=k)]
        check('all ordered literal words metadata n'+str(n)+' b'+str(b),[r['clauses']for r in subset]==wanted)
for n in range(1,3):
    for b in range(1,3):
        subset=[r for r in pairs if len(r['base']['required_centers'])==n and len(r['base']['tiles'])==b]
        words=[[]]+[[dict(origin=[2*i,0],tile_id=7*j)]for i in range(n)for j in range(b)]
        check('all ordered clause pairs metadata n'+str(n)+' b'+str(b),[r['clauses']for r in subset]==[list(v)for v in itertools.product(words,repeat=2)])
exhaustive=[r for r in cases if r['exhaustive_full_palette']]
check('exact12 full-palette artifacts',len(exhaustive)==12 and all(r['exhaustive_full_palette']==(r['family']=='complete-one-clause-population'and len(r['base']['required_centers'])==1)for r in cases))
counts=[]
for r in exhaustive:
    b=len(r['base']['tiles']);n=len(r['base']['required_centers']);k=sum(len(c)for c in r['clauses']);roles=sum(len(c)if c else 1 for c in r['clauses'])
    count=(b+2*b*k)**(n+roles);counts.append(dict(id=r['id'],full_emitted_assignment_count=count))
check('full expanded ALL-center product4214',all(r['full_emitted_assignment_count']<=1000 for r in counts)and sum(r['full_emitted_assignment_count']for r in counts)==decl['exact_full_palette_assignments']==4214)
check('noncontiguous literal IDs exercised',any([t['id']for t in r['base']['tiles']]==[0,7]for r in cases))
for id in ['assigned-zero-versus-absent-none','remote-only-overlap-pair','fresh-channel-collisions-shared','negative-nonrectangular-origins-shared','repeat-three','contradictory-three','repeat-four']:
    check('explicit named profile '+id,any(r['id']==id for r in cases))
check('original inputs no supplied labels/witnesses',inputs['no_supplied_answers_or_witnesses']is True and all(not any(k in r for k in('expected','witness','answer','certificate'))for r in cases))

oldworker=Path('/private/tmp/gcts-wang-calibration-worker-20261019/qualify_wang_calibration_worker_v2.py').read_text()
check('same trusted raw/call ownership wrapper ancestry',definitions(oldworker)['Session']==definitions(texts['worker'])['Session'])
for name in('canonical','clone','descriptor','checked','information','callable_seal'):
    check('unchanged custody helper '+name,definitions(oldworker)[name]==definitions(texts['worker'])[name])
oldrunner=Path('/private/tmp/gcts-wang-execution-ROOT-20261019/run_wang_encoding_once_v5.py').read_text()
olddefs=definitions(oldrunner);newdefs=definitions(texts['runner'])
check('outer only expected definition deltas',[k for k in olddefs if olddefs[k]!=newdefs.get(k)]==['validate_qualification','main'])
normalized=texts['runner'].replace("profile='finite-unit-center-marking-translation-qualification'","profile='complete-finite-wang-calibration'")
check('outer main lifecycle exact except profile label',definitions(normalized)['main']==olddefs['main'])
oldobserver=Path('/private/tmp/gcts-wang-execution-ROOT-20261019/observe_wang_encoding_once_v1.py').read_text()
normalized=texts['observer'].replace("VERSION='finite-point-marking-terminal-observer-v1'","VERSION='wang-encoding-terminal-observer-v1'").replace('Finite unit-center marking translation component only,','Finite Wang encoding calibration only,')
check('observer raw lifecycle exact except version/scope',normalized==oldobserver)
for label,role,text in [
 ('every prototype center assigned','compiler',"[[0, 0], channels['anchor'], 0]"),
 ('complete emitted unit support','compiler',"tiles.append(dict(id=tile_id, t=[[[0, 0], 1]], m=marks))"),
 ('full before-after caller equality','worker',"full literal call arguments after refusal/fault"),
 ('independent remote point assignment','verifier',"key=(p,channel)"),
 ('generic point absent not conflict','verifier',"if key in marks:"),
 ('all repeated literals retained','compiler',"row.append(dict(origin=xy, tile_id=tile_id))"),
 ('fixed empty impossible anchor','compiler',"continue  # No prototype carries this role's pinned anchor value."),
 ('full-palette ALL-centers enumeration','worker',"itertools.product(tile_ids,repeat=len(instance['required_centers']))"),
 ('no role-filtered exhaustion','worker',"counts==expected_preimages"),
 ('global nonvacuous dispositions','worker',"('UNIQUE_ALLOWED_EXTENSION','FORBIDDEN_BY_DECLARED_CLAUSE','INVALID_ORIGINAL_ASSIGNMENT')"),
 ('own quota compiler UNKNOWN only','compiler',"if type(error) is not GadgetLimit or error._owner is not w.owner:"),
 ('Root latch before invalid classifier','worker',"s.fault_gate()\n        if predicate(s,'is_own_invalid',error):"),
 ('root first-fault priority','worker',"primary=s.first_fault if s.first_fault is not None else error"),
]:check(label,text in texts[role])
raw('false maxzero authorization',plan['authorization']);auth=read(plan['authorization']['path'])
check('no current actual grant',auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['subject_sha256']==sha)
check('fresh absent actual',not Path(plan['actual_directory']).exists()and Path(plan['actual_directory']).parent==D)
check('fresh absent observer',not(D/'plan-false-v1-terminal-observation').exists())

manual=[
 dict(id='S1',verdict='NO_BLOCKER_IN_DECLARED_SCOPE',finding='Compiler and independent verifier cover arbitrary finite integer marking offsets, fresh string channels, assigned0, full original m/pins and noncontiguous literal IDs. Unit-center positive support plus required=admissible distinct even origins makes exactly one unit tile per center the complete t check. No NESW truncation, absence-as-zero conflict or hidden anchor-only candidate prefilter supplies primitive tiling validity.'),
 dict(id='S2',verdict='NO_BLOCKER_IN_DECLARED_SCOPE',finding='Every prototype owns its local center anchor, original centers pin base role0, auxiliary centers pin distinct positive roles, and all allowed origins are explicit. Empty support introduces a required role assigned by no prototype while every prototype still assigns another anchor; its impossibility is assigned inequality, not missing data.'),
 dict(id='S3',verdict='NO_BLOCKER_IN_DECLARED_SCOPE',finding='B independently reconstructs complete lifted/auxiliary prototype families, topology, pins, maps, counts and fresh channels from the full base/clauses. It permits coherent alternative layouts; L codecs separately rebuild their exact canonical compiler layout. It imports/calls no compiler. Raw point verification checks complete placements and every translated point/channel assignment.'),
 dict(id='S4',verdict='MANUAL_CONDITIONAL_ARGUMENT',finding='Repeated same-center literals all read the SAME selected literal base ID. Distinct role/state links still compute the ordered conjunction, so duplicate reads do not change its truth and contradictory same-center choices make it false. No clause simplification or deduplication occurs. Global distinct state points/roles and fresh channels keep multiple clauses independent while sharing real base choice values.'),
 dict(id='S5',verdict='FINITE_QUALIFICATION_SCOPE',finding='All697 complete base assignments are planned, including invalid originals, allowed nonvacuous extensions and forbidden combinations. ALL emitted IDs at ALL required centers are exhaustively offered only for the12 declared n1 artifacts4214 assignments, with complete zero/one projection preimage counts. Other uniqueness/exclusion checks use independently verified linear prefix necessity/sufficiency, not full expanded assignment enumeration. No generated outcome or fixture was executed during this review.'),
 dict(id='S6',verdict='CONDITIONAL_CUSTODY_AND_ERRORS',finding='Root wraps actual argument references with whole canonical before/after equality on both success and refusal, raw Source and postload callable binding guards. First actual Root fault dominates expected negatives and private predicates; planned foreign BaseException/GadgetLimit require exact identity. L private own quota returns UNKNOWN; B private predicate accepts module-owned errors only after Root fault latch. All own limits remain fail-closed, no budget outcome becomes absence/UNSAT.'),
 dict(id='S7',verdict='AUTHORITY_AND_COST_BOUNDARY',finding='Supplied clauses are problem-defining and may remove original solutions. No primitive redundancy certificate is supplied or assumed. Complete literal point outputs and all actually enumerated certificates/dispositions are retained on success. New component question is separate from all old680+55 failures. Per-call component400m units differ; Root callback400m is invocation-wide, not aggregate semantic/CPU work. All preparation, checking, guards, enumeration and output remain inside original real gates.'),
]
limitations=[
 'Source/manual reasoning only. No component, fixture, codec, verifier, compiler, search, simulator or renderer was imported, called or evaluated; unused compile code objects were discarded. No actual or deployment permission is granted.',
 'This finite unit-center translation-only component is broader than the old NESW-only verifier in marking support, but is not a general fractional/shared-positive-support, mixed-generation, rotation/reflection or continuous geometry engine. No reference search/scheduler/rollback engine is offered or qualified.',
 '162/697/4214/15 is a fresh declared component domain, not a smaller replacement or rescue of old680+55. Current15 diagnostics cover declared malformed profiles, selected own-work caps and FIRST-callback foreign classes only; not all bad certificates, same-class prior owned exceptions, StopIteration, persistent caller mutation or late interruption sites.',
 'Only B verify_tiling, verify_translation, verify_extension and owner predicates are actually planned; its separate analyze_base_assignment and verify_projection public APIs are Source-reviewed but not exercised by this worker. L compile/extend/project are planned. Call maps count instrumented API entries, not all internal functions or CPU operations.',
 'search_calls:0 means no separate search-engine API. The qualification DOES enumerate finite base and emitted-palette assignments via itertools; that combinatorial checking work is real and charged. No constant-time or no-enumeration claim follows.',
 'Per-row all-checks flags mean all applicable checks passed, not that every invalid/forbidden row had a positive extension or project call. Global nonvacuity and full retained dispositions distinguish these paths. Formal general unique-extension/kernel proof and all-layout testing are not supplied by finite calibration.',
 'Compiler input reread occurs before successful return; refusal paths are additionally covered by the Root complete argument comparison. B module-owned classifier is not per-current-call ownership, so Root first-fault ordering is essential. Read-only callback/exclusive-owner trust remains, not universal temporal mutation or hostile-code/loader/OS sealing.',
 'Raw-pinned SourceFileLoader and recursive postload function/code/default identity checks do not establish initial pyc/compiled-object/default-content/global/closure-cell/OS custody. Pinned interpreter and declared stdlib entries plus builtin/frozen/transitive runtime remain trusted.',
 'Original worker positive result/header/read/known-exit180s, later complete custody/resource/log/ledger/external terminal210s;225s observer fallback is failure cleanup only. Worker-only Darwin lifetime HWM1GiB does not cover parent allocations or simultaneous total RAM. Stored and expanded unshared logical outputs and physical ledger128MiB plus declared9MiB reservations/log limits are unchanged.',
 'Failure packet may retain only completed IDs/active stage/calls/error cutoff, not full current compilation, assignment or exported private work; unavailable is not zero or failed-prefix acceptance. Allocation/diagnostic total failure is not universally error-transparent. All finite runtime outcomes remain unknown until an authorized actual and separate saved audit.',
 'No supplied-clause redundancy, learned markings, RL, GCTS advantage, new discovered theorem, universal fixed palette or full FOL checker/lowering bridge is established. Separate physical_wang_adapter_v1 is NOT in this runtime closure and remains Source-only. Earlier negatives and retired grants remain unchanged.',
 'Library authored compiler/codecs and older mathematical controls; B authored this distinct verifier, Root worker/controller, C current independent scope review and older protocol/control ancestors. Separation and review are not formal independent kernel certification.',
]
v=dict(schema='wang-encoding-Source-prospective-review-v1',reviewer_identity='/root/conventional_control_review',
    author_identities=['/root','/root/conventional_library','/root/benchmark_design'],review_passed=True,source_only=True,
    component_calls=0,scientific_calls=0,subject_imports=0,fixture_calls=0,simulations=0,process_probes=0,renderer_calls=0,
    actual_execution_authorized=False,runtime_qualified=False,scientific_acceptance=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,
    subject=subject,subject_sha256=sha,sources=sources,false_plan=offer['false_plan'],offer=pin(D/'Source-only-offer-v1.json'),
    declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],
    master=pin(C/'basic-tiling-algorithm-isolated-current.md'),
    design_obligations=pin(C/'typed-component-qualification-obligations-v1.json'),
    prior_conditional_argument=pin('/private/tmp/gcts-wang-nogood-review-20261019/typed-gadget-argument-review-v2.json'),
    prior_negative_saved_review=pin('/private/tmp/gcts-wang-nogood-review-20261019/typed-saved-comparison-review-v1.json'),
    compiler_handoff=pin('/private/tmp/gcts-unit-center-receptor-library-20261019/handoff-v1.json'),
    verifier_handoff=pin('/private/tmp/gcts-finite-marking-verifier-20261019-v1/handoff-v1.json'),
    independently_rederived_input_metadata=dict(core_translations=147,core_base_assignments=613,profile_translations=15,profile_base_assignments=84,all_translations=162,all_base_assignments=697,full_palette_artifacts=counts,all_full_palette_assignments=4214,diagnostics=15),
    manual_Source_assessment=manual,typed_static_checks=checks,check_count=len(checks),mismatch_count=0,limitations=limitations,
    next='Root must explicitly adopt these scopes, create one exact-subject max-one grant, obtain narrow auth-only/freshness delta and independently freeze all-peer-idle/fresh-path barrier before any actual. This receipt grants none of that authority.',
    interpreter=dict(executable=sys.executable,version=sys.version,flags='-I -S -B',activity='own stdlib raw/AST/ordinary metadata arithmetic; unused code objects discarded without target evaluation'),tools_stopped_after_handoff=True)
p=C/'typed-marking-component-Source-prospective-review-v1.json'
if p.exists():raise FileExistsError(p)
p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(dict(receipt=pin(p),checks=len(checks),mismatch_count=0),sort_keys=True))
