"""Raw Source composition and AST/unused compile only; never evaluates target."""
from pathlib import Path
import ast
import hashlib
import json
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
OLD=Path('/private/tmp/gcts-wang-calibration-worker-20261019/qualify_wang_calibration_worker_v2.py')
COMP=Path('/private/tmp/gcts-unit-center-receptor-library-20261019/unit_center_marking_compiler_v1.py')
VER=Path('/private/tmp/gcts-finite-marking-verifier-20261019-v1/finite_marking_verifier_v1.py')
def pin(p):
    raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def main():
    # The first draft's common owner wrapper is unchanged. Recompose the bodies
    # from ordinary author text, so corrections do not silently drift the recipe.
    draft=(D/'qualify_marking_worker_DRAFT_v1.py').read_text()
    common=draft[:draft.index('\nimport itertools')]
    body=(D/'worker_body_v1.py.txt').read_text();entry=(D/'worker_main_v1.py.txt').read_text()
    ver=pin(VER)
    need_comp=pin(COMP)
    if need_comp['sha256']!='9a07bd4afbfd7b4c95edd8d9e2a3ea489a025a53e1b18014ca5b429d09291eb9':raise ValueError('changed compiler')
    common=common.replace("'VERIFIER_PIN_PENDING',0",repr(ver['sha256'])+','+str(ver['bytes']))
    raw=common+'\n'+body+'\n'+entry
    target=D/'qualify_marking_worker_v1.py';tree=ast.parse(raw);compile(tree,str(target),'exec')
    with target.open('x')as f:f.write(raw)
    for name in('run_marking_qualification_once_v1.py','observe_marking_qualification_once_v1.py'):
        text=(D/name).read_text();compile(ast.parse(text),str(D/name),'exec')
    record=dict(worker=pin(target),compiler=pin(COMP),verifier=ver,source_only=True,
        unused_compile=True,component_calls=0,actual_execution_authorized=False)
    with (D/'worker-source-freeze-v1.json').open('x')as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(record,sort_keys=True))
if __name__=='__main__':main()
