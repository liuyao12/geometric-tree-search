"""UNEXECUTED worker Source for one complete declared finite Wang calibration.

Only future reviewed once-run execution may load/call the four components.
No Native/FOL/Model/Reader/inverse/solver imports or calls. No hostile sandbox
claim: input ownership, Source/callable custody and finite external gates apply.
"""
import time
NOW = time.monotonic_ns
ENTRY_NS = NOW()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'finite-point-marking-qualification-worker-v1'
SOURCE_ROLES = ('worker', 'compiler', 'verifier', 'runner', 'observer')
SOURCE_PINS = {'compiler': ('9a07bd4afbfd7b4c95edd8d9e2a3ea489a025a53e1b18014ca5b429d09291eb9',20653), 'verifier': ('VERIFIER_PIN_PENDING',0)}

INPUT_SHA = '155280e0539b36b9a7afc9e885edcf12fac8c9fe24ec5ec74ea040e5506782ec'
INPUT_BYTES = 234761
OUTER_LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
    stderr_bytes=4194304, worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608, observer_bytes=1048576)
POINT_LIMITS=dict(work=400000000,centers=1024,tiles=100000,marks=1000000,
    clauses=256,literals=1024,candidates=1000000,integer_abs=1000000,string_chars=1024,data_depth=64)
COMPONENT_LIMITS={role:dict(POINT_LIMITS)for role in('compiler','verifier')}

CHECKPOINT_LIMIT = 400000000
RESERVE_BYTES = 9437184
FORBIDDEN_EVENTS = ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','ctypes.dlopen')


class PolicyFailure(RuntimeError):
    pass


class PlannedForeign(BaseException):
    pass


def need(ok, message):
    if not ok:
        raise PolicyFailure(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def clone(value):
    return json.loads(canonical(value))


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and type(pin['path'])is str and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and
         len(pin['sha256'])==64,'strict finite raw descriptor')
    path=Path(pin['path'])
    need(path.is_absolute()and path==path.resolve()and path.is_file()and not path.is_symlink(),'canonical regular raw input')
    raw=path.read_bytes();need(descriptor(path,raw)==pin,'complete raw hash/size/path join');return raw


def information(error):
    try:return dict(type=type(error).__name__,message=str(error)[:512])
    except BaseException:return dict(type='UNAVAILABLE',message='error metadata unavailable')


def callable_seal(module):
    rows=[];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                rows.append((key,id(value),id(value.__code__),id(value.__defaults__),id(value.__kwdefaults__)))
            elif type(value)is type and value.__module__==module.__name__ and id(value)not in seen:
                seen.add(id(value));rows.append((key,id(value)))
                owned={}
                for child,item in vars(value).items():
                    if type(item)in(staticmethod,classmethod):item=item.__func__
                    owned[child]=item
                pending.append((key+'.',owned))
    return tuple(sorted(rows))


class Session:
    def __init__(self,plan,plan_pin,consumed,actual):
        self.plan,self.plan_pin,self.actual=plan,plan_pin,actual
        self.began=consumed['began_ns'];self.work_deadline=consumed['work_deadline_ns']
        self.overall_deadline=consumed['overall_deadline_ns']
        self.root_calls=0;self.first_fault=None;self.stage='INTAKE';self.active=None
        self.started={};self.completed={};self.raised={};self.modules={};self.seals={};self.denied=[]
        self.oracle_work=0;self.oracle_work_unavailable=0;self.expanded_subtree_delta=0
        self.rows=[];self.diagnostics=[];self.retained=[];self.output_pins=[]
        self.component_limits=clone(COMPONENT_LIMITS)

    def check(self):
        self.root_calls+=1
        try:
            need(self.root_calls<=CHECKPOINT_LIMIT,'invocation-total400m Root callback limit')
            need(NOW()<self.work_deadline,'original absolute180s work deadline')
            if self.first_fault is not None:raise self.first_fault
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def policy(self,action):
        try:return action()
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def guard(self):
        def action():
            self.check()
            for role,pin in self.plan['sources'].items():
                checked(pin)
            for role,module in self.modules.items():
                need(module.__file__==self.plan['sources'][role]['path'] and
                     callable_seal(module)==self.seals[role],'owned module origin/function/code/default binding')
            self.check()
        return self.policy(action)

    def fault_gate(self):
        if self.first_fault is not None:raise self.first_fault

    def own_oracle_limit(self,error):
        self.fault_gate();self.guard();key='oracle.is_own_limit'
        self.started[key]=self.started.get(key,0)+1
        value=self.modules['oracle'].is_own_limit(error)
        self.completed[key]=self.completed.get(key,0)+1;self.guard()
        return value

    def call(self,role,name,data,action,expected_after=None):
        self.guard();before=canonical(data()if callable(data)else data)
        self.check();key=role+'.'+name;self.started[key]=self.started.get(key,0)+1
        try:
            value=action()
        except BaseException as error:
            self.raised[key]=self.raised.get(key,0)+1
            self.fault_gate()
            if role=='oracle'and name=='audit_snapshot':
                oracle=self.modules['oracle']
                if type(error)is oracle.SnapshotLimit and self.own_oracle_limit(error):self.oracle_work+=error.attempted_work
                else:self.oracle_work_unavailable+=1
            self.fault_gate()
            self.guard()
            expected=before if expected_after is None else canonical(expected_after)
            self.policy(lambda:need(canonical(data()if callable(data)else data)==expected,'full literal call arguments after refusal/fault'))
            raise
        self.fault_gate();self.guard()
        expected=before if expected_after is None else canonical(expected_after)
        self.policy(lambda:need(canonical(data()if callable(data)else data)==expected,'full literal call arguments unchanged'))
        self.completed[key]=self.completed.get(key,0)+1
        if role=='oracle'and name=='audit_snapshot':self.oracle_work+=value['audit_work']
        return value

    def load(self,role):
        self.check();pin=self.plan['sources'][role];checked(pin)
        name='wang_actual_'+role
        spec=importlib.util.spec_from_file_location(name,pin['path'])
        need(spec is not None and spec.loader is not None,'exact Python Source loader')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module
        spec.loader.exec_module(module)
        need(module.__file__==pin['path'],'exact loaded Source origin')
        self.modules[role]=module;self.seals[role]=callable_seal(module);self.guard()
        return module

    def calls(self,role):
        return sum(value for key,value in self.started.items()if key.startswith(role+'.'))

    def write_json(self,name,value,cap,closure=False):
        path=self.actual/name;temporary=self.actual/(name+'.partial')
        need(not path.exists()and not temporary.exists(),'never overwrite or retry a packet')
        digest=hashlib.sha256();size=0;parts=0
        fd=os.open(str(temporary),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as output:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).iterencode(value):
                raw=part.encode('utf8');size+=len(raw);need(size+1<=cap,'whole JSON packet cap')
                output.write(raw);digest.update(raw);parts+=1
                if parts%1024==0:
                    if closure:need(NOW()<self.overall_deadline,'failure metadata210 deadline')
                    else:self.check()
            output.write(b'\n');digest.update(b'\n');size+=1;output.flush();os.fsync(output.fileno())
        if closure:need(NOW()<self.overall_deadline,'failure metadata completed before210')
        else:self.check()
        os.rename(temporary,path)
        return dict(path=str(path),bytes=size,sha256=digest.hexdigest())


import itertools


def limits(s,role,work_one=False):
    result=clone(s.component_limits[role])
    if work_one:result['work']=1
    return result


def predicate(s,name,error):
    s.fault_gate();s.guard();key='verifier.'+name
    s.started[key]=s.started.get(key,0)+1
    result=getattr(s.modules['verifier'],name)(error)
    s.completed[key]=s.completed.get(key,0)+1;s.fault_gate();s.guard()
    need(type(result)is bool,'literal private-owner predicate result');return result


def compile_gadget(s,base,clauses,check=None,work_one=False):
    bounds=limits(s,'compiler',work_one);module=s.modules['compiler']
    callback=s.check if check is None else check
    return s.call('compiler','compile_marking_gadget',dict(base=base,clauses=clauses,limits=bounds),
        lambda:module.compile_marking_gadget(base,clauses,check=callback,limits=bounds))


def codec(s,name,compilation,certificate,check=None):
    bounds=limits(s,'compiler');module=s.modules['compiler'];callback=s.check if check is None else check
    return s.call('compiler',name,dict(compilation=compilation,certificate=certificate,limits=bounds),
        lambda:getattr(module,name)(compilation,certificate,check=callback,limits=bounds))


def verify(s,name,args,check=None,work_one=False):
    bounds=limits(s,'verifier',work_one);module=s.modules['verifier'];callback=s.check if check is None else check
    data=dict(args=clone(args),limits=bounds)
    return s.call('verifier',name,data,lambda:getattr(module,name)(*args,check=callback,limits=bounds))


def raw_tiling(s,instance,certificate):
    try:return verify(s,'verify_tiling',[instance,certificate])
    except BaseException as error:
        s.fault_gate()
        if predicate(s,'is_own_invalid',error):return dict(status='INVALID_LITERAL_POINT_ASSIGNMENT',error=information(error))
        raise


def certificate(model,word):
    return dict(schema='finite-unit-center-placement-certificate-v1',placements=[
        dict(tile_id=tile,origin=point[:])for point,tile in zip(model['required_centers'],word)])


def forbidden(clauses,base_certificate):
    chosen={tuple(row['origin']):row['tile_id']for row in base_certificate['placements']}
    return any(all(chosen[tuple(literal['origin'])]==literal['tile_id']for literal in clause)for clause in clauses)


def qualify_case(s,case):
    s.stage='COMPLETE_TRANSLATION';s.active=case['id'];s.check()
    base,clauses=case['base'],case['clauses'];module=s.modules['compiler']
    compilation=compile_gadget(s,base,clauses)
    need(compilation['status']=='MARKING_GADGET_CANDIDATE','complete actual compiler result, never UNKNOWN')
    need(canonical(compilation['base'])==canonical(base)and canonical(compilation['clauses'])==canonical(clauses),
        'full original literal input binding')
    translation=verify(s,'verify_translation',[base,clauses,compilation])
    need(translation['status']=='VALID_MARKING_GADGET_TRANSLATION','independent entire translated profile check')
    assignments=[];expected_preimages={};ids=[t['id']for t in base['tiles']]
    for word in itertools.product(ids,repeat=len(base['required_centers'])):
        s.check();base_certificate=certificate(base,word);original=raw_tiling(s,base,base_certificate)
        item=dict(base_certificate=base_certificate,original_check=original)
        key=canonical(base_certificate).decode()
        if original['status']!='VALID_EXACT_FINITE_TILING':
            error=None
            try:codec(s,'extend',compilation,base_certificate)
            except BaseException as caught:s.fault_gate();error=caught
            need(type(error)is module.DeclarationError,'invalid ORIGINAL assignment refused distinctly from a forbidden conjunction')
            item.update(status='INVALID_ORIGINAL_ASSIGNMENT',extension=None,codec_refusal=information(error))
            expected_preimages[key]=0
        else:
            disallowed=forbidden(clauses,base_certificate)
            if disallowed:
                error=None
                try:codec(s,'extend',compilation,base_certificate)
                except BaseException as caught:s.fault_gate();error=caught
                need(type(error)is module.NoExtension,'actual supplied forbidden combination has no codec extension')
                relation=verify(s,'verify_extension',[base,clauses,compilation,base_certificate,None])
                need(relation['status']=='VALID_EXTENSION_PROJECTION_RELATION'and relation['extension_exists']is False,
                    'independent necessary prefix trajectory forbids extension')
                item.update(status='FORBIDDEN_BY_DECLARED_CLAUSE',extension=None,relation=relation,codec_refusal=information(error))
                expected_preimages[key]=0
            else:
                extension=codec(s,'extend',compilation,base_certificate)
                need(extension['status']=='EXTENSION_CANDIDATE','complete extension, never UNKNOWN')
                expanded_check=verify(s,'verify_tiling',[compilation['instance'],extension['certificate']])
                need(expanded_check['status']=='VALID_EXACT_FINITE_TILING','independent complete raw t/m section')
                relation=verify(s,'verify_extension',[base,clauses,compilation,base_certificate,extension['certificate']])
                need(relation['status']=='VALID_EXTENSION_PROJECTION_RELATION'and relation['extension_exists']is True and
                    canonical(relation['base_certificate'])==canonical(base_certificate),
                    'independent unique-prefix extension and literal projection')
                projection=codec(s,'project',compilation,extension['certificate'])
                need(projection['status']=='PROJECTION_CANDIDATE'and
                    canonical(projection['certificate'])==canonical(base_certificate),'full literal base-ID round trip')
                projected_check=verify(s,'verify_tiling',[base,projection['certificate']])
                need(projected_check['status']=='VALID_EXACT_FINITE_TILING','independent projected original point section')
                item.update(status='UNIQUE_ALLOWED_EXTENSION',extension=extension,expanded_check=expanded_check,
                    relation=relation,projection=projection,projected_check=projected_check)
                expected_preimages[key]=1
        assignments.append(item)
    need(len(assignments)==case['complete_base_assignment_count'],'whole declared base-assignment population')
    exhaustive=None
    if case['exhaustive_full_palette']:
        instance=compilation['instance'];tile_ids=[t['id']for t in instance['tiles']]
        total=len(tile_ids)**len(instance['required_centers'])
        need(total<=1000,'prospective complete full-palette population cap, no truncation')
        counts={key:0 for key in expected_preimages};offered=[]
        reverse={emitted:original_id for emitted,original_id in translation['base_tiles']}
        for word in itertools.product(tile_ids,repeat=len(instance['required_centers'])):
            s.check();candidate=certificate(instance,word);checked_tiling=raw_tiling(s,instance,candidate)
            record=dict(certificate=candidate,check=checked_tiling)
            if checked_tiling['status']=='VALID_EXACT_FINITE_TILING':
                by_origin={tuple(p['origin']):p['tile_id']for p in candidate['placements']}
                need(all(by_origin[tuple(p)]in reverse for p in base['required_centers']),'raw valid expanded tiling anchored base roles')
                projected=certificate(base,[reverse[by_origin[tuple(p)]]for p in base['required_centers']])
                key=canonical(projected).decode();need(key in counts,'every raw valid tiling projects inside complete original universe')
                counts[key]+=1;record['projected_base_certificate']=projected
            offered.append(record)
        need(len(offered)==total and counts==expected_preimages,
            'exhaust ALL emitted tile assignments at ALL required centers; exact zero/one preimages')
        exhaustive=dict(method='ALL_EMITTED_PALETTE_AT_ALL_REQUIRED_CENTERS',assignments=offered,
            assignment_count=total,projection_preimage_counts=[[key,value]for key,value in sorted(counts.items())],
            exact_expected_preimages_matched=True)
    return dict(id=case['id'],family=case['family'],original_case=case,compilation=compilation,
        independent_translation=translation,assignments=assignments,exhaustive=exhaustive,
        status='VERIFIED_TRANSLATION_AND_ALL_BASE_ASSIGNMENTS',assignments_checked=len(assignments),
        all_primitive_checks_passed=True,all_projection_checks_passed=True,all_uniqueness_checks_passed=True,
        full_palette_exhausted=exhaustive is not None,
        uniqueness_method='Full raw-palette enumeration in declared subdomain; independently checked unique prefix states elsewhere.',
        redundancy_established=False,proof_search=False)


def diagnostics(s,inputs,rows):
    compiler=s.modules['compiler'];simple=rows[0];aux=next(r for r in rows if r['compilation']['mapping']['auxiliary_tiles'])
    original_zero=next(r for r in rows if r['id']=='assigned-zero-versus-absent-none')
    for declared in inputs['diagnostics']:
        s.stage='DIAGNOSTIC';s.active=declared['id'];s.check();before=s.root_calls
        op=declared['operation'];record=dict(id=declared['id'],operation=op,status='UNFINISHED',check_calls_before=before)
        s.diagnostics.append(record);actual=None;returned=None;reached=False;hits=0;expected_kind='DECLARATION'
        model=clone(simple['original_case']['base']);clauses=clone(simple['original_case']['clauses'])
        changed=None
        if op=='duplicate_required':model['required_centers'].append(clone(model['required_centers'][0]))
        elif op=='extra_origin':model['admissible_origins'].append([50,50])
        elif op=='duplicate_tile_id':model['tiles'].append(clone(model['tiles'][0]))
        elif op=='boolean_mark_zero':model['tiles'][0]['m']=[[[100,0],'remote',False]]
        elif op=='odd_origin':model['required_centers'][0]=[1,0];model['admissible_origins'][0]=[1,0]
        elif op=='foreign_literal_id':clauses=[[dict(origin=model['required_centers'][0],tile_id=99)]]
        elif op=='rotation_field':model['tiles'][0]['rotation']=0
        elif op in('remove_anchor','flip_prefix_output','remove_original_zero'):
            chosen=original_zero if op=='remove_original_zero'else aux;changed=clone(chosen['compilation'])
            if op=='remove_anchor':
                anchor=changed['mapping']['channels']['anchor'];tile=changed['instance']['tiles'][0]
                index=next(i for i,m in enumerate(tile['m'])if m[0]==[0,0]and m[1]==anchor);tile['m'].pop(index)
            elif op=='flip_prefix_output':
                emitted=changed['mapping']['auxiliary_tiles'][0][0]
                mark=changed['instance']['tiles'][emitted]['m'][-1];mark[2]=1-mark[2]
            else:changed['instance']['tiles'][0]['m'].pop(0)
            expected_kind='VERIFIER_INVALID'
        elif op in('compiler_owned_work','verifier_owned_work'):expected_kind=op
        elif op.startswith('compiler_foreign')or op=='verifier_foreign_base':expected_kind='FOREIGN'
        else:raise PolicyFailure('undeclared diagnostic operation')
        try:
            if expected_kind=='DECLARATION':reached=True;returned=compile_gadget(s,model,clauses)
            elif expected_kind=='VERIFIER_INVALID':
                reached=True;returned=verify(s,'verify_translation',[chosen['original_case']['base'],chosen['original_case']['clauses'],changed])
            elif expected_kind=='compiler_owned_work':reached=True;returned=compile_gadget(s,model,clauses,work_one=True)
            elif expected_kind=='verifier_owned_work':
                reached=True;returned=verify(s,'verify_tiling',[model,certificate(model,[model['tiles'][0]['id']]*len(model['required_centers']))],work_one=True)
            else:
                sentinel=(s.call('compiler','GadgetLimit',{},lambda:compiler.GadgetLimit('planned_foreign'))
                    if op=='compiler_foreign_limit'else PlannedForeign('planned exact foreign callback object'))
                def fault():
                    nonlocal hits,reached
                    s.check();hits+=1;reached=True;raise sentinel
                if op.startswith('compiler'):returned=compile_gadget(s,model,clauses,check=fault)
                else:returned=verify(s,'verify_tiling',[model,certificate(model,[model['tiles'][0]['id']]*len(model['required_centers']))],check=fault)
        except BaseException as error:s.fault_gate();actual=error
        s.fault_gate()
        if expected_kind=='DECLARATION':need(type(actual)is compiler.DeclarationError,'actual compiler malformed-data refusal')
        elif expected_kind=='VERIFIER_INVALID':need(actual is not None and predicate(s,'is_own_invalid',actual),'actual independently owned profile refusal')
        elif expected_kind=='compiler_owned_work':need(type(returned)is dict and returned.get('status')=='UNKNOWN'and returned.get('reason')=='work','owned quota cannot return a candidate')
        elif expected_kind=='verifier_owned_work':need(actual is not None and predicate(s,'is_own_limit',actual),'actual independently owned quota refusal')
        else:need(reached and actual is sentinel,'foreign callback object propagated exactly before any classification')
        record.update(status='PASSED',reached=reached,expectation_satisfied=True,expected_kind=expected_kind,
            error=None if actual is None else information(actual),returned=returned,check_calls_after=s.root_calls,
            exact_foreign_identity=True if expected_kind=='FOREIGN'else None,local_callbacks=hits,
            mutated_compilation=changed)


def qualify(s,inputs):
    need(inputs['exact_case_count']==162 and inputs['exact_base_assignment_count']==697 and
        len(inputs['diagnostics'])==15,'whole prospectively declared new component domain')
    for case in inputs['cases']:s.rows.append(qualify_case(s,case))
    need(sum(r['assignments_checked']for r in s.rows)==697,'all original base assignments covered')
    need(sum(r['exhaustive']['assignment_count']for r in s.rows if r['exhaustive']is not None)==4214,
        'entire declared full-palette product subdomain')
    statuses=[a['status']for row in s.rows for a in row['assignments']]
    for required in('UNIQUE_ALLOWED_EXTENSION','FORBIDDEN_BY_DECLARED_CLAUSE','INVALID_ORIGINAL_ASSIGNMENT'):
        need(required in statuses,'nonvacuous positive, forbidden and original-mark refusal coverage')
    diagnostics(s,inputs,s.rows)
    need(len(s.rows)==162 and len(s.diagnostics)==15,'no missing case or diagnostic')
    return dict(schema='complete-finite-marking-qualification-packet-v1',inputs=inputs,rows=s.rows,
        diagnostics=s.diagnostics,full_base_assignments=697,full_palette_assignments=4214,
        representation='Actual finite point t/m assignments, no clause scanner used for raw tiling validity.',
        limits=COMPONENT_LIMITS,redundancy_established=False,learned_markings=False,trained_RL=False,
        proof_search=False,full_pipeline_qualified=False,mathematical_proof_accepted=False)

def main(plan_path):
    plan_raw=Path(plan_path).read_bytes();need(len(plan_raw)<=16777216,'bounded complete plan')
    plan=json.loads(plan_raw);plan_pin=descriptor(plan_path,plan_raw)
    need(type(plan)is dict and set(plan)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'}and
        plan['schema']=='ROOT-wang-encoding-qualification-plan-v1','exact once-plan compatibility schema')
    need(plan['limits']==OUTER_LIMITS and set(plan['sources'])==set(SOURCE_ROLES),'original caps; five component Sources')
    actual=Path(plan['actual_directory']);need(actual.is_absolute()and actual==actual.resolve()and actual.is_dir(),'owned once actual')
    consumed=json.loads((actual/'CONSUMED.json').read_bytes())
    need(consumed['plan']==plan_pin and consumed['invocation_id']==plan['invocation_id']and
        consumed['schema']=='wang-encoding-qualification-consumed-v1'and
        type(consumed['maximum_worker_launches'])is int and consumed['maximum_worker_launches']==1 and
        consumed['consumed_before_Popen']is True and type(consumed['began_ns'])is int and
        consumed['work_deadline_ns']==consumed['began_ns']+180000000000 and
        consumed['overall_deadline_ns']==consumed['began_ns']+210000000000,'inherited original Source-entry epoch')
    s=Session(plan,plan_pin,consumed,actual)
    try:
        s.check();need(descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['worker'],'complete worker Source pin')
        for role,(sha,size)in SOURCE_PINS.items():need((plan['sources'][role]['sha256'],plan['sources'][role]['bytes'])==(sha,size),'exact mathematical Source')
        for pin in plan['sources'].values():checked(pin)
        checked(plan['python'],67108864)
        declaration=json.loads(checked(plan['declaration']));closure=json.loads(checked(plan['runtime_closure']))
        need(declaration['schema']=='ROOT-wang-encoding-qualification-declaration-v1'and
            declaration['limits']==OUTER_LIMITS and declaration['component_limits']==COMPONENT_LIMITS and
            declaration['checkpoint_limit']==CHECKPOINT_LIMIT and declaration['experiment_kind']=='FINITE_POINT_MARKING_TRANSLATION',
            'new component question; original resource ceilings')
        need(closure['schema']=='ROOT-wang-encoding-runtime-closure-v1'and closure['python']==plan['python']and
            closure['sources']==plan['sources']and closure['declaration']==plan['declaration'],'complete current runtime closure')
        for pin in closure['stdlib_files']:checked(pin)
        need(plan['inputs']==declaration['inputs']and len(plan['inputs'])==1,'whole frozen input capsule')
        raw=checked(plan['inputs'][0]['pin'],134217728)
        need(len(raw)==INPUT_BYTES and hashlib.sha256(raw).hexdigest()==INPUT_SHA,'original complete new component bank')
        inputs=json.loads(raw);s.retained.append(inputs)
        need([r['id']for r in inputs['cases']]==declaration['case_ids']and
            [r['complete_base_assignment_count']for r in inputs['cases']]==declaration['case_assignment_counts']and
            [r['id']for r in inputs['diagnostics']]==declaration['diagnostic_ids'],'full prospective domain and order')
        subject={k:v for k,v in plan.items()if k!='authorization'};auth=json.loads(checked(plan['authorization']))
        need(auth['actual_execution_authorized']is True and auth['author_identity']=='/root'and
            type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and
            auth['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest(),'max-one Root grant of exact new subject')
        s.write_json('WORKER_CONSUMED.json',dict(plan=plan_pin,pid=os.getpid(),ppid=os.getppid(),
            worker_entry_ns=ENTRY_NS,maximum_invocations=1),1048576)
        def audit(event,args):
            if event in FORBIDDEN_EVENTS:
                s.denied.append(event);s.policy(lambda:need(False,'forbidden process/network/dlopen event'))
        sys.addaudithook(audit)
        for role in('compiler','verifier'):s.load(role)
        packet=qualify(s,inputs);s.active=None;s.guard();s.stage='FULL_PACKET_WRITE'
        output=s.write_json('canonical-finite-marking-qualification.json',packet,134217728-RESERVE_BYTES)
        s.output_pins.append(output)
        q=dict(schema='finite-geometric-marking-qualification-candidate-v1',status='COMPLETE_FINITE_MARKING_QUALIFICATION_CANDIDATE',
            outputs=s.output_pins,case_ids=declaration['case_ids'],diagnostic_ids=declaration['diagnostic_ids'],
            rows=[{key:r[key]for key in('id','status','assignments_checked','all_primitive_checks_passed',
                'all_projection_checks_passed','all_uniqueness_checks_passed','full_palette_exhausted')}for r in s.rows],
            diagnostics=s.diagnostics,root_check_calls=s.root_calls,
            root_check_calls_scope='cutoff before metadata serialization; later callbacks still within original invocation ceiling',
            compiler_calls=s.calls('compiler'),verifier_calls=s.calls('verifier'),search_calls=0,oracle_calls=0,
            full_pipeline_qualified=False,mathematical_proof_accepted=False,fixed_FOL_palette_qualified=False,
            gcts_rl_advantage_established=False,learned_markings=False,trained_RL=False,redundancy_established=False)
        zeros=dict(Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,proof_checker_calls=0,opaque_program_decodes=0)
        payload=dict(schema='wang-encoding-qualification-result-v1',invocation_id=plan['invocation_id'],plan=plan_pin,
            declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],qualification=q,outputs=s.output_pins,
            denied_events=s.denied,canonical_logical_bytes=output['bytes'],expanded_canonical_packet_bytes=output['bytes'],
            compiler_calls=s.calls('compiler'),verifier_calls=s.calls('verifier'),search_calls=0,oracle_calls=0,
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,**zeros)
        s.stage='RESULT_WRITE';result=s.write_json('result.json',payload,134217728-RESERVE_BYTES-output['bytes'])
        s.guard()
        for pin in closure['stdlib_files']:checked(pin)
        checked(plan['inputs'][0]['pin'],134217728);s.check()
        logical=output['bytes']+result['bytes'];need(0<logical<=134217728,'full unshared stored/expanded output')
        header=dict(schema='wang-encoding-qualification-worker-receipt-v1',version=VERSION,
            invocation_id=plan['invocation_id'],plan=plan_pin,began_ns=s.began,work_deadline_ns=s.work_deadline,
            overall_deadline_ns=s.overall_deadline,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,
            result=result,outputs=s.output_pins,logical_result_bytes=logical,expanded_logical_result_bytes=logical,
            outer_metadata_reservation=RESERVE_BYTES,finite_encoding_candidate=True,
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,
            call_started=s.started,call_completed=s.completed,call_raised=s.raised,
            root_check_calls=s.root_calls,positive_worker_completed_ns=NOW(),
            snapshot_cutoff_scope='before header serialization/final callback/known exit',**zeros)
        s.stage='HEADER_WRITE';s.write_json('worker-receipt.json',header,4194304)
        need(sum(p.stat().st_size for p in actual.iterdir()if p.is_file())+RESERVE_BYTES<=134217728,
            'all actual files plus original outer9MiB reserve')
        s.check();return 0
    except BaseException as error:
        primary=s.first_fault if s.first_fault is not None else error
        failure=dict(schema='finite-marking-worker-failure-v1',status='FAILED_OR_UNFINISHED',
            plan=plan_pin,invocation_id=plan['invocation_id'],stage=s.stage,active_row=s.active,
            completed_case_ids=[r['id']for r in s.rows],diagnostic_prefix=[dict(id=r['id'],status=r['status'])for r in s.diagnostics],
            call_started=s.started,call_completed=s.completed,call_raised=s.raised,root_check_calls=s.root_calls,
            first_available_fault=information(primary),outputs=s.output_pins,
            no_failed_prefix_admission=True,full_pipeline_qualified=False,mathematical_proof_accepted=False)
        try:s.write_json('worker-failure.json',failure,1048576,closure=True)
        except BaseException:pass
        return 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one exact once-plan path')
    raise SystemExit(main(sys.argv[1]))
