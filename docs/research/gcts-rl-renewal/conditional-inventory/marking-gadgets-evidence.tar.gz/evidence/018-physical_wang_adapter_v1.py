"""Unexecuted literal-table adapter; no checker, simulator or compiler imports.

Expand the existing physical_declaration compressed single-tape table into the
ordinary deterministic TM grammar used by the finite Wang compiler. This is a
representation step, not a proof of the earlier lowering or an unknown-proof
language. Ordinary JSON data only; caller owns complete input/Source custody.
"""
VERSION = 'literal-physical-to-wang-machine-adapter-v1'
LIMIT_KEYS = ('work','states','symbols','transitions','data_items','string_bytes',
              'integer_abs','data_depth','word_cells')
TABLE_KEYS = ('alphabet','rows','names','start','accept','reject','space','entries','micro_sha256')
_OWNER = object()


class AdapterDataError(ValueError):
    pass


class AdapterLimit(RuntimeError):
    def __init__(self,reason,attempted_work,*,_owner=None):
        self.reason=reason;self.attempted_work=attempted_work;self._owner=_owner
        super().__init__(reason)


def is_own_limit(error):
    return type(error)is AdapterLimit and error._owner is _OWNER


def _need(ok,message):
    if not ok:raise AdapterDataError(message)


class _Work:
    def __init__(self,check,limits):
        _need(callable(check),'explicit external budget callback')
        _need(type(limits)is dict and all(type(k)is str for k in limits)and
            set(limits)==set(LIMIT_KEYS),'all exact adapter limits')
        _need(all(type(v)is int and v>0 for v in limits.values()),'positive exact-int limits')
        _need(limits['data_depth']<=128,'bounded ordinary-data depth')
        self.check=check;self.limits=dict(limits);self.work=0;self.items=0
        check()  # Every foreign callback exception escapes unchanged.
    def step(self):
        self.work+=1
        if self.work>self.limits['work']:raise AdapterLimit('work',self.work,_owner=_OWNER)
        if self.work%1024==0:self.check()
    def bound(self,key,value):
        self.step()
        if value>self.limits[key]:raise AdapterLimit(key,self.work,_owner=_OWNER)
    def integer(self,value,lo=None,hi=None):
        self.step();_need(type(value)is int,'exact integer; bool is not an integer')
        self.bound('integer_abs',abs(value))
        if lo is not None:_need(value>=lo,'integer below range')
        if hi is not None:_need(value<hi,'integer outside upper range')
        return value
    def text(self,value):
        self.step();_need(type(value)is str,'literal string')
        try:raw=value.encode('utf8')
        except UnicodeEncodeError:raise AdapterDataError('strict UTF-8 string')from None
        self.bound('string_bytes',len(raw));return value
    def copy(self,value,depth=0,path=None):
        self.step();self.items+=1;self.bound('data_items',self.items);self.bound('data_depth',depth+1)
        kind=type(value)
        if kind is str:return self.text(value)
        if kind is int:return self.integer(value)
        if value is None or kind is bool:return value
        _need(kind in(list,dict),'ordinary JSON arrays/objects/scalars only')
        if path is None:path=set()
        _need(id(value)not in path,'acyclic ordinary data')
        path.add(id(value))
        try:
            if kind is list:return[self.copy(item,depth+1,path)for item in value]
            result={}
            for key,item in value.items():
                self.text(key);result[key]=self.copy(item,depth+1,path)
            return result
        finally:path.remove(id(value))


def _object(value,keys):
    _need(type(value)is dict and all(type(k)is str for k in value)and set(value)==set(keys),
          'exact declared object fields')


def _table(table,w):
    _object(table,TABLE_KEYS)
    alphabet=table['alphabet'];rows=table['rows'];names=table['names']
    _need(type(alphabet)is list and alphabet,'nonempty complete alphabet')
    w.bound('symbols',len(alphabet));ids={}
    for index,token in enumerate(alphabet):
        w.text(token);_need(token and token not in ids,'distinct nonempty literal symbols');ids[token]=index
    _need('B'in ids and 'L'in ids,'existing physical blank and left sentinel symbols')
    _need(type(rows)is list and rows,'nonempty complete state table');w.bound('states',len(rows))
    _need(type(names)is list and len(names)==len(rows),'complete state names')
    for name in names:w.text(name)
    state_count=len(rows)
    start=w.integer(table['start'],0,state_count)
    accept=w.integer(table['accept'],0,state_count)
    reject=w.integer(table['reject'],0,state_count)
    space=w.integer(table['space'],0,state_count)
    halts={accept,reject,space};_need(len(halts)==3,'distinct accept/reject/space states')
    digest=w.text(table['micro_sha256'])
    _need(len(digest)==64 and all(c in'0123456789abcdef'for c in digest),'literal metadata digest')
    entries=table['entries'];_need(type(entries)is dict,'ordinary JSON entry metadata')
    for key,value in entries.items():
        w.text(key)
        _need(key.isascii()and key.isdecimal()and
            (key=='0'or key[0]in'123456789'),'canonical natural entry key')
        _need(type(value)is list and len(value)==4,'physical four-state entry metadata')
        for state in value:w.integer(state,0,state_count)
    transitions=[];default_rows=0;override_pairs=0;missing_pairs=0
    for state,row in enumerate(rows):
        w.step()
        if state in halts:
            _need(row is None,'halting states have no outgoing rows')
            missing_pairs+=len(alphabet);continue
        _need(type(row)is list and len(row)==2,'compressed default/override row')
        default,overrides=row
        if default is not None:
            _need(type(default)is list and len(default)==2,'same-symbol default [state,move]')
            w.integer(default[0],0,state_count);w.integer(default[1],-1,2);default_rows+=1
        _need(type(overrides)is dict,'literal finite symbol overrides')
        for token,action in overrides.items():
            w.text(token);_need(token in ids,'override symbol is in complete alphabet')
            _need(type(action)is list and len(action)==3,'override [state,write,move]')
            w.integer(action[0],0,state_count);w.text(action[1]);_need(action[1]in ids,'write symbol in alphabet')
            w.integer(action[2],-1,2);override_pairs+=1
        for read,token in enumerate(alphabet):
            w.step()
            if token in overrides:out,write,move=overrides[token];write_id=ids[write]
            elif default is not None:out,move=default;write_id=read
            else:missing_pairs+=1;continue
            w.bound('transitions',len(transitions)+1)
            transitions.append([state,read,out,write_id,move])
    return(dict(alphabet_size=len(alphabet),state_count=state_count,blank=ids['B'],
                initial=start,accepting=accept,transitions=transitions),
           dict(alphabet=list(alphabet),symbol_to_integer=[[s,i]for i,s in enumerate(alphabet)],
                accept=accept,reject=reject,space=space),
           dict(states=state_count,symbols=len(alphabet),transitions=len(transitions),
                same_symbol_default_rows=default_rows,explicit_override_pairs=override_pairs,
                undefined_state_symbol_pairs=missing_pairs))


def compile_table(table,*,check,limits):
    """Expand EVERY state/read-symbol pair, preserving only declared undefineds.

    No reachable-state trim, theorem-dependent specialization or halting padding.
    Reject/space are ordinary nonaccepting terminal states. Interpreting a
    space-limited run as UNKNOWN remains the owner experiment's responsibility.
    """
    w=_Work(check,limits);owned=w.copy(table)
    machine,codec,counts=_table(owned,w)
    result=dict(schema='literal-physical-wang-machine-adapter-v1',version=VERSION,
        status='ORDINARY_TM_CANDIDATE',physical_table=owned,machine=machine,codec=codec,
        construction_counts=counts,attempted_work=w.work,
        earlier_lowering_faithfulness_established=False,fixed_FOL_table_materialized=False,
        unknown_proof_language_established=False,mathematical_authority=False)
    w.step();check();result['attempted_work']=w.work;return result


def encode_word(table,cells,physical_head,*,check,limits):
    """Literal token codec, with a single actual TM head at the declared index.

    Internal @ symbols denote virtual tape heads and remain ordinary symbols.
    This function does not parse a proof, build a heap, pin a theorem, or supply
    an unknown-certificate boundary grammar. It is for complete supplied words.
    """
    w=_Work(check,limits);owned=w.copy(table);word=w.copy(cells)
    machine,codec,counts=_table(owned,w)
    _need(type(word)is list and word,'complete nonempty literal physical word')
    w.bound('word_cells',len(word));head=w.integer(physical_head,0,len(word))
    ids={token:index for index,token in enumerate(codec['alphabet'])};out=[]
    for index,token in enumerate(word):
        w.text(token);_need(token in ids,'every physical token is in frozen alphabet')
        out.append(['head',machine['initial'],ids[token]]if index==head else['plain',ids[token]])
    w.step();check()
    return dict(schema='literal-physical-wang-word-codec-v1',version=VERSION,
        physical_table=owned,physical_cells=word,physical_head=head,initial_word=out,
        construction_counts=counts,attempted_work=w.work,
        supplied_complete_word_only=True,public_problem_binding_established=False,
        mathematical_authority=False)
