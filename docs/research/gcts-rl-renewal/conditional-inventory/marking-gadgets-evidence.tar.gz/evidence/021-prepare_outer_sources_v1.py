"""Raw Source author only; retain the original bounded process lifecycle."""
from pathlib import Path
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
OLD=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
source=(OLD/'run_wang_encoding_once_v5.py').read_text()
source=source.replace("VERSION='wang-encoding-once-runner-v5'","VERSION='finite-point-marking-once-runner-v1'")
source=source.replace("SOURCE_ROLES=frozenset(('worker','compiler','search','verifier','oracle','runner','observer'))", "SOURCE_ROLES=frozenset(('worker','compiler','verifier','runner','observer'))")
first=source.index('def validate_qualification(');last=source.index('\n\ndef main(',first)
source=source[:first]+'''def validate_qualification(q,plan,declaration,outputs):
    need(q['schema']=='finite-geometric-marking-qualification-candidate-v1'and
         q['status']=='COMPLETE_FINITE_MARKING_QUALIFICATION_CANDIDATE','complete distinct marking component qualification')
    need(q['outputs']==outputs and len(outputs)==1,'one complete canonical output')
    need(q['case_ids']==declaration['case_ids']and type(q['rows'])is list and
         [r['id']for r in q['rows']]==q['case_ids'],'every prospectively declared translation')
    need(type(q['case_ids'])is list and len(q['case_ids'])==len(set(q['case_ids']))and bool(q['case_ids']),
         'nonempty unique complete case population')
    for row,expected in zip(q['rows'],declaration['case_assignment_counts']):
        need(row['status']=='VERIFIED_TRANSLATION_AND_ALL_BASE_ASSIGNMENTS'and
             type(row['assignments_checked'])is int and row['assignments_checked']==expected and
             row['all_primitive_checks_passed']is True and row['all_projection_checks_passed']is True and
             row['all_uniqueness_checks_passed']is True,'complete input/projection/extension domain')
        need(type(row['full_palette_exhausted'])is bool,'explicit exhaustive-versus-linear scope')
    need(q['diagnostic_ids']==declaration['diagnostic_ids']and
         [r['id']for r in q['diagnostics']]==q['diagnostic_ids'],'complete diagnostic population')
    for row in q['diagnostics']:
        need(row['status']=='PASSED'and row['reached']is True and row['expectation_satisfied']is True,
             'actual diagnostic reach and disposition')
    need(type(q['root_check_calls'])is int and 0<q['root_check_calls']<=400000000,
         'invocation-total original Root checkpoint ceiling')
    need(type(q['compiler_calls'])is int and q['compiler_calls']>0 and
         type(q['verifier_calls'])is int and q['verifier_calls']>0 and
         type(q['search_calls'])is int and q['search_calls']==0 and
         type(q['oracle_calls'])is int and q['oracle_calls']==0,'no disguised search/clause filter')
    for field in('full_pipeline_qualified','mathematical_proof_accepted','fixed_FOL_palette_qualified',
                 'gcts_rl_advantage_established','learned_markings','trained_RL','redundancy_established'):
        need(q[field]is False,'component translation has no broader mathematical authority')
''' +source[last:]
# Compatibility result counters remain explicit; the scientific profile is new.
source=source.replace("profile='complete-finite-wang-calibration'", "profile='finite-unit-center-marking-translation-qualification'")
with (D/'run_marking_qualification_once_v1.py').open('x')as f:f.write(source)
observer=(OLD/'observe_wang_encoding_once_v1.py').read_text()
observer=observer.replace("VERSION='wang-encoding-terminal-observer-v1'", "VERSION='finite-point-marking-terminal-observer-v1'")
observer=observer.replace('Finite Wang encoding calibration only, no FOL proof-checker or search advantage qualification.',
    'Finite unit-center marking translation component only, no FOL proof-checker or search advantage qualification.')
with (D/'observe_marking_qualification_once_v1.py').open('x')as f:f.write(observer)
print('Authored raw five-role lifecycle Sources; no target execution')
