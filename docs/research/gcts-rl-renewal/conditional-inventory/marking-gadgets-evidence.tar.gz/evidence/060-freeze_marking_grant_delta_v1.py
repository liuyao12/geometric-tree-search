"""Narrow ordinary metadata/raw-pin check only; no target or OS process calls."""
from pathlib import Path
import hashlib,json,sys
C=Path('/private/tmp/gcts-geometric-nogood-review-20261019')
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
checks=[]
def h(b):return hashlib.sha256(b).hexdigest()
def pin(path):
    p=Path(path);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=h(b))
def read(path):return json.loads(Path(path).read_bytes())
def check(name,ok):
    checks.append(dict(id=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def raw(name,p):check(name,pin(p['path'])==p and Path(p['path']).is_absolute()and str(Path(p['path']).resolve())==p['path']and not Path(p['path']).is_symlink())
planpath=D/'plan-authorized-v1.json';p=read(planpath);f=read(D/'plan-false-v1.json')
check('offered true plan exact',pin(planpath)['sha256']=='cc1ef4710c5692ad30e738fe0ca435740a257d6d64f1afe2b7d15cb257cbe2c9'and pin(planpath)['bytes']==2986)
check('only auth descriptor changed',set(p)==set(f)and [k for k in p if p[k]!=f[k]]==['authorization'])
subject={k:v for k,v in p.items()if k!='authorization'}
sha=h(json.dumps(subject,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode())
reviewpath=C/'typed-marking-component-Source-prospective-review-v1.json';r=read(reviewpath)
check('nine-field reviewed subject literal unchanged',len(subject)==9 and subject==r['subject']and sha==r['subject_sha256']=='ad27df100beb18e87701817fe2ef3c7d6a51ca2af806f975ee5a62f2c76f7701')
raw('true maxone Root grant whole bytes',p['authorization']);a=read(p['authorization']['path'])
check('grant exact offered pin',p['authorization']['sha256']=='11056c28c36784f3d3dcfb6f8950ba51fc210a55d5839342464d5fbfa21bb2b0'and p['authorization']['bytes']==816)
check('exact seven-field Root grant',set(a)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','review','scope','subject_sha256'}and a['schema']=='ROOT-wang-encoding-authorization-v1'and a['author_identity']=='/root'and a['actual_execution_authorized']is True and type(a['maximum_actual_invocations'])is int and a['maximum_actual_invocations']==1 and a['subject_sha256']==sha)
raw('exact adopted review',a['review'])
check('required Source review ABI and exact pin',a['review']==pin(reviewpath)and a['review']['sha256']=='23998c9237bac994523dba67146ef44e933a5537b043ea65790a2f08d99648ee'and r['schema']=='wang-encoding-Source-prospective-review-v1'and r['reviewer_identity']=='/root/conventional_control_review'and r['review_passed']is True and r['source_only']is True and type(r['component_calls'])is int and r['component_calls']==0 and r['actual_execution_authorized']is False)
check('all five Source descriptors unchanged',p['sources']==r['sources']and set(p['sources'])=={'worker','compiler','verifier','runner','observer'})
for role,value in p['sources'].items():raw('current Source '+role,value)
raw('interpreter',p['python']);raw('whole declaration',p['declaration']);raw('whole runtime closure',p['runtime_closure'])
closure=read(p['runtime_closure']['path']);decl=read(p['declaration']['path'])
check('full declaration/closure joins',closure['sources']==p['sources']and closure['python']==p['python']and closure['declaration']==p['declaration']and decl['limits']==p['limits']and decl['inputs']==p['inputs'])
for i,value in enumerate(closure['stdlib_files']):raw('declared stdlib '+str(i),value)
for item in p['inputs']:raw('full frozen input '+item['id'],item['pin'])
actual=Path(p['actual_directory']);observer=planpath.with_name(planpath.stem+'-terminal-observation')
check('fresh actual absent',actual.is_absolute()and str(actual.resolve())==str(actual)and actual.parent==D and not actual.exists())
check('fresh authorized observer absent',not observer.exists())
raw('false authorization remains intact',f['authorization']);false=read(f['authorization']['path'])
check('preserved false maxzero',false['actual_execution_authorized']is False and type(false['maximum_actual_invocations'])is int and false['maximum_actual_invocations']==0)
v=dict(schema='finite-marking-component-final-grant-delta-review-v1',reviewer_identity='/root/conventional_control_review',
    final_grant_delta_review_passed=True,review_passed=True,metadata_only=True,source_only=True,component_calls=0,scientific_calls=0,
    subject_imports=0,fixture_calls=0,simulations=0,process_probes=0,actual_execution_authorized=False,
    authorized_plan=pin(planpath),authorization=p['authorization'],review=a['review'],false_plan=pin(D/'plan-false-v1.json'),
    subject=subject,subject_sha256=sha,sources=p['sources'],actual_directory=str(actual),authorized_observer_directory=str(observer),
    actual_and_observer_absent_at_review=True,typed_checks=checks,check_count=len(checks),mismatch_count=0,
    scope='Only Root authorization descriptor changes from exact reviewed false plan. All original finite-bank inputs, full five Sources, interpreter/stdlib/closure/declaration/profile/caps remain unchanged. Root author owns one fresh max-one grant; this receipt neither authors grants nor launches anything.',
    limitations=['Point-in-time raw/file freshness only. No process probe, target call, fixture or mathematical evaluation. Root must separately freeze all-peer-idle/fresh-path barrier immediately before actual.',
      'All103 adopted Source/prospective checks and their finite-domain/coverage/loader/OS/cost/authority limitations remain. No old680 rescue, failed-prefix admission, FOL adapter runtime, cap change, theorem or general engine qualification is granted.'],
    interpreter=dict(executable=sys.executable,version=sys.version,flags='-I -S -B'),tools_stopped_after_handoff=True)
path=C/'typed-marking-final-grant-delta-review-v1.json'
if path.exists():raise FileExistsError(path)
path.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps(dict(receipt=pin(path),checks=len(checks),mismatch_count=0),sort_keys=True))
