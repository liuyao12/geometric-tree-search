"""Raw worker Source author only; no mathematical subject import or call."""
from pathlib import Path
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
OLD=Path('/private/tmp/gcts-wang-calibration-worker-20261019/qualify_wang_calibration_worker_v2.py').read_text()
source=OLD[:OLD.index('\ndef compiler_word(')]
source=source.replace("VERSION = 'complete-wang-calibration-worker-v2'", "VERSION = 'finite-point-marking-qualification-worker-v1'")
source=source.replace("SOURCE_ROLES = ('worker', 'compiler', 'search', 'verifier', 'oracle', 'runner', 'observer')", "SOURCE_ROLES = ('worker', 'compiler', 'verifier', 'runner', 'observer')")
a=source.index('SOURCE_PINS = {');b=source.index('\nINPUT_SHA',a)
source=source[:a]+"SOURCE_PINS = {'compiler': ('9a07bd4afbfd7b4c95edd8d9e2a3ea489a025a53e1b18014ca5b429d09291eb9',20653), 'verifier': ('VERIFIER_PIN_PENDING',0)}\n"+source[b:]
source=source.replace("INPUT_SHA = '60ced7c79f91fd475ef88e90cace3ce5fffe15b0c8450d4b3e934d3764ffb80e'", "INPUT_SHA = '155280e0539b36b9a7afc9e885edcf12fac8c9fe24ec5ec74ea040e5506782ec'")
source=source.replace('INPUT_BYTES = 232943','INPUT_BYTES = 234761')
a=source.index('COMPONENT_LIMITS = {');b=source.index('\nCHECKPOINT_LIMIT',a)
source=source[:a]+'''POINT_LIMITS=dict(work=400000000,centers=1024,tiles=100000,marks=1000000,
    clauses=256,literals=1024,candidates=1000000,integer_abs=1000000,string_chars=1024,data_depth=64)
COMPONENT_LIMITS={role:dict(POINT_LIMITS)for role in('compiler','verifier')}
''' +source[b:]
# Keep inherited custody/ownership wrapper unchanged; the mathematical bodies
# below use only compiler/verifier. No oracle/search Source is loaded.
source+='\n'+(D/'worker_body_v1.py.txt').read_text()
source+='\n'+(D/'worker_main_v1.py.txt').read_text()
with (D/'qualify_marking_worker_DRAFT_v1.py').open('x')as f:f.write(source)
print('Authored raw marking worker Source; no evaluation')
