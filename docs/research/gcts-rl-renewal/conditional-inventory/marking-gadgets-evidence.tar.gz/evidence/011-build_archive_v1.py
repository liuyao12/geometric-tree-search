"""Archive exact saved bytes/Source only; no component evaluation."""
from pathlib import Path
import hashlib,json,io,tarfile,gzip
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1');O=D/'publication';R=Path('/private/tmp/gcts-geometric-nogood-review-20261019')
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
review=R/'typed-marking-saved-actual-review-v1.json'
assert review.exists()
files=[]
for p in sorted(D.glob('*')):
 if p.is_file()and p.suffix in('.py','.json','.txt','.md','.html'):files.append(p)
for folder in [D/'actual-component-v1',D/'plan-authorized-v1-terminal-observation',Path('/private/tmp/gcts-unit-center-receptor-library-20261019'),Path('/private/tmp/gcts-finite-marking-verifier-20261019-v1'),R]:
 for p in sorted(folder.iterdir()):
  if p.is_file()and p.suffix in('.py','.json','.bin','.md'):files.append(p)
# Public repository Source of existing lowering, retained unexecuted as adapter provenance.
generator=Path('/private/tmp/gcts-semantic-runtime-intake-20261018/tape_tree_machine.py')
assert hashlib.sha1(b'blob '+str(generator.stat().st_size).encode()+b'\0'+generator.read_bytes()).hexdigest()=='23cc9faedfbe7bc5669845d63c63be6f71d879b9'
files.append(generator)
files=list(dict.fromkeys(files));rows=[]
for i,p in enumerate(files):rows.append(dict(member=f'evidence/{i:03d}-{p.name}',original=pin(p)))
pathmap=dict(schema='ROOT-marking-archive-pathmap-v1',scope='Exact raw Sources/ordinary inputs/once actual/independent scopes. No interpreter, credentials, private overview, primary checkout state or opaque program.',members=rows)
archive=O/'marking-gadgets-evidence.tar.gz'
with archive.open('wb')as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for row,p in zip(rows,files):
    raw=p.read_bytes();info=tarfile.TarInfo(row['member']);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
   raw=json.dumps(pathmap,sort_keys=True,indent=2).encode()+b'\n';info=tarfile.TarInfo('PATHMAP.json');info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
# Passive decompression + hash/identity only, no archived Source execution.
with tarfile.open(archive,'r:gz')as tar:
 names=tar.getnames();assert names==[r['member']for r in rows]+['PATHMAP.json']
 for row in rows:
  raw=tar.extractfile(row['member']).read();assert len(raw)==row['original']['bytes']and hashlib.sha256(raw).hexdigest()==row['original']['sha256']
manifest=dict(schema='ROOT-marking-publication-manifest-v1',archive=pin(archive),archive_members=len(rows)+1,raw_evidence_members=len(rows),raw_evidence_bytes=sum(r['original']['bytes']for r in rows),archive_members_verified=True,pathmap=pathmap,outputs={name:pin(O/name)for name in ['marking-gadgets.html','marking-gadgets-summary.json','marking-gadgets-data.json','reader.html']},source_review=pin(R/'typed-marking-component-Source-prospective-review-v1.json'),grant_delta_review=pin(R/'typed-marking-final-grant-delta-review-v1.json'),saved_review=pin(review),separate_adapter_Source_review=pin(R/'typed-physical-wang-adapter-Source-review-v1.json'),no_overview_index_read_or_edit=True,reader_append=pin(O/'reader-append-custody.json'),publication_review='Separate detached sidecar after this manifest, avoiding a recursive self-hash.',claimed_authority='Finite declared component only; no learned redundancy/search/scheduler/fullFOL/performance/plane theorem authority.')
(O/'marking-gadgets-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(archive=pin(archive),manifest=pin(O/'marking-gadgets-manifest.json'),members=len(rows)+1,raw_bytes=manifest['raw_evidence_bytes']),sort_keys=True))
