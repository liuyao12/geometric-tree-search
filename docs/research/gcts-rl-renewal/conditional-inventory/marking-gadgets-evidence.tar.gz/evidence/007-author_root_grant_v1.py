from pathlib import Path
import hashlib,json
D=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
def pin(p):
 r=p.read_bytes();return dict(path=str(p),bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
def save(p,v):
 with p.open('xb')as f:f.write(json.dumps(v,sort_keys=True,indent=2).encode()+b'\n')
 return pin(p)
o=json.loads((D/'Source-only-offer-v1.json').read_bytes());s=o['subject']
r=Path('/private/tmp/gcts-geometric-nogood-review-20261019/typed-marking-component-Source-prospective-review-v1.json');rv=json.loads(r.read_bytes())
assert rv['review_passed'] is True and rv['subject']==s and rv['subject_sha256']==o['subject_sha256']
assert not Path(s['actual_directory']).exists()
for p in list(s['sources'].values())+[s['python'],s['declaration'],s['runtime_closure']]+[x['pin']for x in s['inputs']]:assert pin(Path(p['path']))==p
ap=save(D/'authorization-once-v1.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',actual_execution_authorized=True,maximum_actual_invocations=1,subject_sha256=o['subject_sha256'],review=pin(r),scope='Root adopts all103 reviewed checks and every scope/limit/trust gap. One fresh exact finite point marking component actual only. No old680 retry or prefix admission, no FOL adapter runtime, no cap extension, all peers/tools must stop before launch. Full failure preserved; this grant is consumed even on failure.'))
pp=save(D/'plan-authorized-v1.json',dict(s,authorization=ap))
print(json.dumps(dict(plan=pp,authorization=ap,review=pin(r)),sort_keys=True))
