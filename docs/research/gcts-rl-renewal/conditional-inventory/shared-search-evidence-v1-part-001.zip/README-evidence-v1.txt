Finite shared-fact point proof search and controls, 2026-11-03.

Download EVERY shared-search-evidence-v1-part-NNN.zip and the external
shared-search-evidence-manifest-v1.json. Each volume is a separate valid ZIP,
at most forty-four MiB. Extract all volumes into one empty directory. Each has
the identical ARCHIVE-file-manifest-v1.json; identical copies may overwrite.
Every original task path is physically stored exactly once, without aliases or
deduplication. The manifest binds every original path/byte count/SHA256 and every
volume's completed bytes/hash. Publication verifies every original and every CRC.

All original task files at the archive cut are physically kept: Sources,
prospective declarations and protocol, full finite catalogues and point models,
raw point results and every retained observation, independent basis/model/full
frontier checks, decoded certificates and native checks, forward and reference
SAT control inputs/results/certificates, qualification mutations and resource
refusals, all UNKNOWNs, logs, reviews, report builder and viewer assets. No
duplicate-path aliases or reconstruction instructions replace original bytes.
Publication Python Sources are physically included. Generated package outputs
and publication planning/deployment receipts are excluded to avoid recursion.
Deployment receipts created after this cut remain local custody evidence. Full task archive
and local paths are explicitly approved for the existing public destination.

Serve the extracted directory with python3 -m http.server and open
report/shared-search-v1.html. Scientific code is inert data for the reader.
The declared finite pred0/imp profile uses named assumptions and structural MP.
Shared prior facts are read by remote active/formula markings without consuming
their owner capacity again. Each selected point certificate still requires full
point-trace, independent decoding and native logical admission. Controls use the
same admitted finite catalogue and line bound; assumptions are not free facts.
All solve refusals remain UNKNOWN. Related line bounds are not independent
theorems. The simple reference DPLL is not a modern SAT performance baseline.
This anchored semantic point search is not literal Wang-grid search or a
uniform finite palette. No GCTS/RL advantage, complete PA/Hilbert/FOL search or
plane-tiling result is established. The research program remains ACTIVE.
