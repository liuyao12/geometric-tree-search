"""Passive saved-byte joins for the prospective shared-fact ground pilot.

Stdlib only: no model/basis builder, encoder, solver, oracle, logical checker or
trace checker is imported or executed. Saved large observation states are
streamed for event census and exact hashes, not semantically replayed. Logical,
point-conformance, CNF and process-admission gates stay separately identified.
All nine original native phases must be terminal and admitted before outputs.
"""
from collections import Counter
import copy
import gc
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[1]
MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
MASTER_SHA='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
SEMANTIC=('statement','proof','slots','slot_to_native','native_to_slot','reference_mapping',
          'proof_dag','selected','selected_sha256','original_statement_sha256','scope')
MUTANTS=('omitted-formulas','omitted-zeros','omitted-mp','omitted-row','bool-slot-bound',
    'float-slot-bound','wrong-goal-mark','wrong-owner-active','self-reference',
    'forward-reference','boolean-reference','referenced-inactive-PAD','dropped-clause',
    'bool-selector','changed-sat-assignment','boolean-unit-reason',
    'basis-resource','point-resource','forward-resource','sat-resource')


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def sha(value):
    h=hashlib.sha256()
    for part in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(value):h.update(part.encode('ascii'))
    h.update(b'\n');return h.hexdigest()


def same(a,b):return sha(a)==sha(b)


def local(name):
    assert type(name) is str and not Path(name).is_absolute()
    p=(ROOT/name).resolve();assert p.is_relative_to(ROOT),name
    return p


def pin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(1048576),b''):h.update(part);size+=len(part)
    return dict(bytes=size,sha256=h.hexdigest())


def read(name):
    path=local(name)
    with (gzip.open(path,'rt',encoding='ascii') if path.suffix=='.gz' else path.open('r',encoding='ascii')) as stream:return json.load(stream)


def save(name,value):
    path=local(name);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(wire(value))
    return dict(path=name,**pin(path))


def seconds(value):
    assert type(value) in (int,float) and math.isfinite(value) and value>=0
    return value


def result_reason(result):
    """Display saved refusal reasons, including limits nested in DPLL trees."""
    if result.get('reason'):return result['reason']
    tree=result.get('certificate');limits=[];stack=[tree] if type(tree) is dict else []
    while stack:
        node=stack.pop()
        if node.get('limit') and node['limit'] not in limits:limits.append(node['limit'])
        stack.extend(child['tree'] for child in node.get('children',[]))
    return ' / '.join(limits) or None


def sources():
    return sorted([*ROOT.glob('source/*.py'),*ROOT.glob('reference/*.py'),*ROOT.glob('reference/upstream/*.py'),
        *ROOT.glob('reference/*.md'),*ROOT.glob('plan/*.md'),*ROOT.glob('plan/*.json'),*ROOT.glob('review/peer-*.md')])


def normalized_point_model(model):
    """Declared byte normalization only; do not construct/search a new model."""
    out=copy.deepcopy(model)
    out['roots'].sort()
    for kind in ('t','m'):out['seed'][kind].sort(key=lambda r:r[0])
    for row in out['inventory']['placements']:
        for kind in ('t','m'):row[kind].sort(key=lambda r:r[0])
    out['inventory']['placements'].sort(key=lambda r:r['id'])
    return out


def runtime():
    p=Path(sys.executable).resolve()
    return dict(executable=dict(path=str(p),**pin(p)),version=sys.version,isolated=sys.flags.isolated,
        no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)


class Stream:
    """Token boundary/hash reader for the frozen compact canonical writer."""
    def __init__(self,stream):self.stream=stream;self.buffer=b'';self.i=0
    def peek(self):
        if self.i==len(self.buffer):self.buffer=self.stream.read(1048576);self.i=0
        assert self.buffer,'UNFINISHED_CANONICAL_JSON'
        return self.buffer[self.i]
    def char(self):c=self.peek();self.i+=1;return c
    def token(self,capture=True):
        h=hashlib.sha256();chunks=[];first=self.peek();done=False;quoted=False;escaped=False;stack=[]
        if first in (123,91):
            while not done:
                self.peek();begin=self.i
                while self.i<len(self.buffer):
                    c=self.buffer[self.i];self.i+=1
                    if quoted:
                        if escaped:escaped=False
                        elif c==92:escaped=True
                        elif c==34:quoted=False
                    elif c==34:quoted=True
                    elif c in (123,91):stack.append(c)
                    elif c in (125,93):
                        assert stack and ((stack[-1]==123 and c==125) or (stack[-1]==91 and c==93))
                        stack.pop()
                        if not stack:done=True;break
                part=self.buffer[begin:self.i];h.update(part)
                if capture:chunks.append(part)
        elif first==34:
            start=True
            while True:
                c=self.char();part=bytes((c,));h.update(part)
                if capture:chunks.append(part)
                if start:start=False;continue
                if escaped:escaped=False
                elif c==92:escaped=True
                elif c==34:break
        else:
            while self.peek() not in (9,10,13,32,44,93,125):
                part=bytes((self.char(),));h.update(part)
                if capture:chunks.append(part)
        h.update(b'\n')
        return (json.loads(b''.join(chunks)) if capture else None),h.hexdigest()


def observations(name,result):
    """Read every event; hash/skip every full state without loading the array."""
    events=[];state_hashes=[]
    with gzip.open(local(name),'rb') as source:
        stream=Stream(source);assert stream.char()==91
        if stream.peek()!=93:
            while True:
                assert stream.char()==123;row={};state_hash=None
                while True:
                    key,_=stream.token();assert key not in row and key in ('event','state')
                    assert stream.char()==58
                    value,digest=stream.token(capture=key!='state')
                    row[key]=value
                    if key=='state':state_hash=digest
                    c=stream.char()
                    if c==125:break
                    assert c==44
                assert set(row)=={'event','state'} and state_hash is not None
                events.append(row['event']);state_hashes.append(state_hash)
                c=stream.char()
                if c==93:break
                assert c==44
        else:stream.char()
        assert stream.buffer[stream.i:]+source.read()==b'\n'
    h=hashlib.sha256()
    for i,event in enumerate(events):
        assert event['seq']==i
        if i<len(result['events']):assert same(event,result['events'][i])
        h.update(wire(event))
    assert len(result['events'])==result['event_extent']['retained']
    assert len(events)<=result['event_extent']['total']
    if len(events)==result['event_extent']['total']:assert h.hexdigest()==result['event_extent']['sha256']
    return dict(observation_count=len(events),event_kinds=dict(Counter(e['kind'] for e in events)),
        event_stream_sha256=h.hexdigest(),full_emitted_stream=len(events)==result['event_extent']['total'],
        state_sha256=state_hashes,scope='Every saved full-state token hashed, not semantically replayed; graph semantics remain the separately saved independent trace receipt.')


def formula_latex(ast):
    if ast[0]=='pred':
        assert len(ast)==3 and ast[2]==[] and re.fullmatch(r'[A-Za-z0-9_]+',ast[1])
        return r'\mathsf{'+ast[1].replace('_',r'\_')+'}'
    assert ast[0]=='imp' and len(ast)==3
    return r'\left('+formula_latex(ast[1])+r'\Rightarrow '+formula_latex(ast[2])+r'\right)'


def english(ast):
    if ast[0]=='pred':return 'proposition '+ast[1]
    assert ast[0]=='imp';return 'if '+english(ast[1])+', then '+english(ast[2])


def theory_reader(statement):
    return dict(hypotheses=[dict(name=name,formula=ast,formula_latex=formula_latex(ast),english=english(ast))
        for name,ast in sorted(statement['theory']['axioms'].items())],
        goal=dict(formula=statement['goal'],formula_latex=formula_latex(statement['goal']),english=english(statement['goal'])))


def proof_reader(proof,forms,decoded=None):
    ids={sha(form):i+1 for i,form in enumerate(forms)};rows=[];dag=dict(nodes=[],edges=[])
    for i,line in enumerate(proof):
        assert line['rule'] in ('axiom','mp')
        dependencies=[line['antecedent'],line['implication']] if line['rule']=='mp' else []
        assert all(type(j) is int and 0<=j<i for j in dependencies)
        if line['rule']=='axiom':text='Use assumption '+line['name']+': '+english(line['formula'])+'.'
        else:text='From lines %d and %d, conclude %s.'%(dependencies[0]+1,dependencies[1]+1,english(line['formula']))
        slot=decoded['native_to_slot'][i] if decoded is not None else None
        fid=ids[sha(line['formula'])]
        rows.append(dict(line=i+1,formula=line['formula'],formula_latex=formula_latex(line['formula']),
            english=text,rule=line['rule'],dependencies=[j+1 for j in dependencies],slot=slot,formula_id=fid))
        dag['nodes'].append(dict(line=i,slot=slot,formula_id=fid))
        if line['rule']=='mp':dag['edges'].extend(dict(premise=line[field],conclusion=i,field=field) for field in ('antecedent','implication'))
    if decoded is not None:assert same(dag,decoded['proof_dag'])
    return rows,dag


class Audit:
    def __init__(self):self.refs={};self.files={};self.protocol=None;self.phase_rows={};self.records=[];self.gaps=[]
    def file(self,name):
        p=pin(local(name));self.files[name]=p;return dict(path=name,**p)
    def ref(self,ref):
        assert type(ref) is dict and {'path','bytes','sha256'}<=set(ref)
        name=ref['path'];expected={k:ref[k] for k in ('bytes','sha256')}
        if name not in self.refs:assert pin(local(name))==expected,name;self.refs[name]=expected
        else:assert self.refs[name]==expected,name
        return name
    def load(self,ref):return read(self.ref(ref))
    def tree_refs(self,value):
        if type(value) is dict:
            if {'path','bytes','sha256'}<=set(value):self.ref(value)
            else:
                for child in value.values():self.tree_refs(child)
        elif type(value) is list:
            for child in value:self.tree_refs(child)

    def provenance(self,proposal):
        protocol=read('data/protocol-frozen-v1.json');self.protocol=protocol
        assert protocol['schema']=='Shared-fact-search-protocol-v1' and protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'
        actual=[dict(path=str(p.relative_to(ROOT)),**pin(p)) for p in sources()]
        assert same(protocol['files'],actual) and same(protocol['runtime'],runtime())
        assert pin(MASTER)['sha256']==pin(local('reference/basic-tiling-algorithm.md'))['sha256']==MASTER_SHA
        phases=['qualify']+[e['case']['id'] for e in proposal['benchmark_cases']]
        assert len(phases)==len(set(phases))==9
        for phase in phases:
            start=read('data/'+phase+'-started.json');inv=read('review/'+phase+'-invocation.json');obs=read('review/'+phase+'-observer.json')
            assert start['status']=='STARTED' and inv['status']=='COMPLETE' and obs['status']=='TERMINAL'
            assert start['phase']==inv['phase']==obs['phase']==phase
            assert type(start['pid']) is int and start['pid']>0 and start['pid']==inv['pid']==obs['pid']
            assert start['protocol_sha256']==sha(protocol)
            assert type(obs['native_exit_code']) is int and obs['native_exit_code']==0 and obs['guard_reason'] is None
            assert inv['postcheck_error'] is obs['postcheck_error'] is None and inv['error_type'] is None
            assert inv['frozen_postcheck']==obs['frozen_postcheck']==protocol['status']
            self.ref(obs['log'])
            self.phase_rows[phase]=dict(phase=phase,execution_admitted=True,pid=start['pid'],native_exit_code=0,
                started=self.file('data/'+phase+'-started.json'),invocation=self.file('review/'+phase+'-invocation.json'),
                observer=self.file('review/'+phase+'-observer.json'),result=self.file('data/'+phase+'-result.json'),
                observed_seconds=seconds(obs['seconds']),sampled_peak_rss_bytes=obs['peak_observed_rss_bytes'],
                worker_seconds=seconds(inv['seconds']),native_lifetime_maxrss=inv['maxrss'],native_lifetime_maxrss_units=inv['maxrss_units'])
        return dict(protocol=self.file('data/protocol-frozen-v1.json'),files=actual,runtime=protocol['runtime'],
            primary_master=dict(path=str(MASTER),**pin(MASTER)),phases=self.phase_rows,
            limits={k:protocol[k] for k in ('point_limits','forward_limits','sat_limits','native_limits','guards')},
            scope='Nine original terminal native processes and exact frozen file/runtime/master bytes joined. Sampled RSS and native lifetime high-water are distinct. No scientific code rerun.')

    def native(self,ref,proof):
        receipt=self.load(ref)
        assert receipt['status']=='VERIFIED' and receipt['checked_lines']==len(proof)
        assert same(receipt['limits'],self.protocol['native_limits'])
        counts=Counter(line['rule'] for line in proof)
        saved_counts=receipt['rule_counts']
        assert type(saved_counts) is dict and set(counts)<=set(saved_counts)
        assert all(type(v) is int and v>=0 and v==counts.get(k,0) for k,v in saved_counts.items())
        assert sum(saved_counts.values())==len(proof)
        return receipt

    def decode(self,refs,prepared,selected):
        adapter=self.load(refs['adapter']);decoded=self.load(refs['independent'])
        assert adapter['status']==decoded['status']=='UNVERIFIED_NATIVE_CERTIFICATE'
        assert all(same(adapter[k],decoded[k]) for k in SEMANTIC)
        statement=prepared['statement'];proof=decoded['proof']
        assert same(decoded['statement'],statement) and decoded['original_statement_sha256']==sha(statement)
        assert decoded['selected']==sorted(selected) and decoded['selected_sha256']==sha(sorted(selected))
        assert decoded['scope']==prepared['binding']['scope'] and proof[-1]['formula']==statement['goal']
        assert 0<len(proof)<=prepared['binding']['slots']
        assert len(decoded['slots'])==prepared['binding']['slots']
        assert decoded['slot_to_native'][-1]==len(proof)-1 and len(decoded['native_to_slot'])==len(proof)
        receipt=self.native(refs['native'],proof)
        binding_name=refs['native']['path'].rsplit('/',1)[0]+'/proof-admission.json'
        binding=read(binding_name);self.file(binding_name)
        assert binding['status']=='VERIFIED' and binding['proof_sha256']==sha(proof)
        assert binding['statement_sha256']==sha(statement) and binding['selected_sha256']==sha(sorted(selected))
        assert binding['native_receipt_sha256']==sha(receipt)
        return decoded,receipt

    def point(self,model,refs):
        result=self.load(refs['search']);trace=self.load(refs['trace'])
        normalized=normalized_point_model(model)
        assert result['status'] in ('SAT','UNSAT','UNKNOWN') and same(result['limits'],self.protocol['point_limits'])
        assert result['model_sha256'] is None or result['model_sha256']==sha(normalized)
        entry=result['entry_state'];restored=result['restored_state'];hashes=result['state_hashes']
        if entry is not None:
            assert same(entry,restored) and hashes['entry']==hashes['restored']==sha(entry)
        else:assert result['status']=='UNKNOWN'
        if result['final_state'] is not None:assert hashes['final']==sha(result['final_state'])
        obs=self.ref(refs['observations']);stream=observations(obs,result)
        rollbacks=result['rollback_records'];extent=result['rollback_extent']
        assert extent['retained']==len(rollbacks)<=extent['total']
        if len(rollbacks)==extent['total']:
            h=hashlib.sha256()
            for row in rollbacks:h.update(wire(row))
            assert h.hexdigest()==extent['sha256']
        if result['status'] in ('SAT','UNSAT'):
            assert trace['status']=='VERIFIED' and trace['run_status']==result['status'] and trace['gaps']==[]
            assert trace['model_sha256']==sha(normalized) and trace['universe_sha256']==sha(normalized['inventory']['placements'])
            assert stream['full_emitted_stream'] and extent['total']==len(rollbacks)
            assert trace['counts']['observations_checked']==stream['observation_count']==result['event_extent']['total']
            assert trace['counts']['rollback_records_checked']==len(rollbacks)
        else:
            assert trace['status']=='UNKNOWN' and trace.get('verified_prefix_only') is True
            assert result['selected']==[] and result['certificate'] is None and result['final_state'] is None
            self.gaps.append(dict(kind='POINT_RESOURCE_PREFIX',reason=result['reason'],trace_reason=trace.get('reason'),raw=refs['search'],trace=refs['trace']))
        return result,trace,stream

    def sat(self,model,refs):
        normalized=normalized_point_model(model)
        encoded=self.load(refs['encoding']);association=self.load(refs['admission'])
        result=self.load(refs['search']);receipt=self.load(refs['certificate'])
        assert encoded['status']=='ENCODED' and association['status']=='VERIFIED'
        cnf=sha(dict(nvars=encoded['nvars'],clauses=encoded['clauses']))
        assert encoded['cnf_sha256']==result['cnf_sha256']==association['cnf_sha256']==cnf
        assert association['model_sha256']==encoded['binding']['input_model_sha256']==sha(model)
        assert encoded['binding']['model_sha256']==sha(normalized)
        assert encoded['binding']['universe_sha256']==sha(normalized['inventory']['placements'])
        assert association['variables']==encoded['nvars'] and association['clauses']==len(encoded['clauses'])
        assert result['status'] in ('SAT','UNSAT','UNKNOWN')
        if 'cnf_sha256' in receipt:assert receipt['cnf_sha256']==cnf
        if result['status'] in ('SAT','UNSAT'):
            assert receipt['status']=='VERIFIED' and receipt['claim']==result['status'] and receipt['cnf_sha256']==cnf
            assert receipt['certificate_sha256']==sha(result['certificate'])
        else:
            assert receipt['status']=='UNKNOWN'
            self.gaps.append(dict(kind='SAT_RESOURCE_REFUSAL',reason=result_reason(result),raw=refs['search'],certificate=refs['certificate']))
        if result['status']=='SAT':
            bits=result['assignment'];assert result['assignment_sha256']==sha(bits) and len(bits)==encoded['nvars']
            assert all(type(b) is int and b in (0,1) for b in bits)
            assert result['selected']==sorted(cid for cid,var in encoded['selector_variables'] if bits[var-1])
        return encoded,result,receipt,association

    def case(self,entry,base,kind):
        case=entry['case'];summary=read(base+'/result.json');self.file(base+'/result.json')
        assert summary['id']==case['id'] and same(summary['case'],case) and summary['status']=='COMPLETED_ADMITTED_ATTEMPTS'
        assert same(read(base+'/declaration.json'),case);self.file(base+'/declaration.json')
        refs=summary['refs'];self.tree_refs(refs)
        compiled=self.load(refs['compile']);prepared=self.load(refs['prepare']);gate=self.load(refs['basis_model'])
        assert compiled['status']=='CATALOGUE_UNVERIFIED' and prepared['status']=='PREPARED_UNVERIFIED'
        cat=compiled['catalogue'];statement=case['statement'];slots=case['profile']['slots']
        assert same(cat,prepared['catalogue']) and same(statement,prepared['statement']) and same(cat['statement'],statement)
        assert cat['provenance']['declaration_sha256']==sha(case) and cat['provenance']['case_id']==case['id']
        assert cat['profile']['slots']==prepared['binding']['slots']==slots
        assert gate['status']==gate['basis']['status']=='VERIFIED'
        assert gate['catalogue_sha256']==prepared['binding']['catalogue_sha256']==sha(cat)
        assert gate['original_statement_sha256']==prepared['binding']['original_statement_sha256']==sha(statement)
        assert gate['scope']==prepared['binding']['scope'] and same(gate['census'],prepared['census']) and same(summary['census'],prepared['census'])
        model=prepared['model'];universe=prepared['universe'];byid={r['id']:r for r in universe}
        assert len(byid)==len(universe)==prepared['census']['rows']
        assert same(model['inventory']['placements'],universe) and gate['model_sha256']==sha(model) and gate['universe_sha256']==sha(universe)
        assert len(refs['zeros'])==len(cat['zeros'])
        for reference,zero in zip(refs['zeros'],cat['zeros']):self.native(reference,[zero['native']])
        point,trace,stream=self.point(model,refs['point']);encoded,sat,cert,association=self.sat(model,refs['sat'])
        forward=self.load(refs['forward']);assert forward['status'] in ('DERIVABLE','NOT_DERIVABLE_WITHIN_BOUND','UNKNOWN')
        if forward.get('binding'):
            assert forward['binding']['catalogue_sha256']==sha(cat) and forward['binding']['statement_sha256']==sha(statement)
            assert forward['binding']['max_lines']==slots
        assert summary['point_status']==point['status'] and summary['sat_status']==sat['status'] and summary['forward_status']==forward['status']
        assert same(summary['point_stats'],point['stats']) and same(summary['forward_counts'],forward.get('counts')) and summary['sat_nodes']==sat.get('nodes')
        actual_exists=dict(point=True if point['status']=='SAT' else False if point['status']=='UNSAT' else None,
            forward=True if forward['status']=='DERIVABLE' else False if forward['status']=='NOT_DERIVABLE_WITHIN_BOUND' else None,
            sat=True if sat['status']=='SAT' else False if sat['status']=='UNSAT' else None)
        assert same(actual_exists,summary['exists']) and all(v==entry['expected_bounded_existence'] for v in actual_exists.values() if v is not None)
        if kind=='QUALIFICATION':assert all(v is not None for v in actual_exists.values())
        oracle=None;projection=None;gap=None
        if kind=='QUALIFICATION':
            oracle=self.load(refs['oracle']);assert oracle['status']=='EXHAUSTED' and oracle['exists']==entry['expected_bounded_existence']
            assert oracle['model_sha256']==sha(model) and len({sha(s) for s in oracle['solutions']})==len(oracle['solutions'])
            if len(encoded['selector_variables'])<=12:
                projection=self.load(refs['projection']);assert projection['status']=='EXHAUSTED'
                assert {sha(s) for s in projection['solutions']}=={sha(s) for s in oracle['solutions']}
            if entry.get('decoder_gap_evidence_required'):
                gap,_=self.decode(refs['gap_proof'],prepared,self.load(refs['gap_proof']['independent'])['selected'])
                active=gap['native_to_slot'];assert any(b-a>1 for a,b in zip(active,active[1:]))
        method_records=[];shared={}
        model_meta=dict(scope=prepared['binding']['scope'],capacity=1,slots=slots,required_points=len(model['roots']),
            roots=model['roots'],universe_count=len(universe),
            formula_count=len(cat['formulas']),formula_colors=[dict(value=str(i+1),formula=f,formula_latex=formula_latex(f)) for i,f in enumerate(cat['formulas'])],
            active_colors=[dict(value='0',meaning='PAD, inactive'),dict(value='1',meaning='Active native line')],
            padding_formula_color='0',seed=model['seed'],positive_support='One owning slot center per candidate; remote reads are mark-only.',
            marking_scope='PROBLEM_DEFINING_NATIVE_PROOF_CONSTRAINTS',coordinate_scope='Opaque semantic slot ports, not a planar Wang grid.')
        theory=theory_reader(statement)
        for method,result in (('point',point),('forward',forward),('sat',sat)):
            positive=actual_exists[method] is True;decoded=None;native=None;selected=[];selected_rows=[];reader=[];dag=None;proof_ref=None;decoded_ref=None
            if positive:
                if method=='forward':
                    proof=result['proof'];assert result['proof_sha256']==sha(proof) and result['lines']==len(proof)<=slots
                    assert proof and proof[-1]['formula']==statement['goal'];native=self.native(refs['forward_native'],proof)
                    proof_ref=dict(refs['forward'],pointer='/proof')
                else:
                    selected=result['selected'];decoded,native=self.decode(refs[method+'_proof'],prepared,selected)
                    proof=decoded['proof'];decoded_ref=refs[method+'_proof']['independent'];proof_ref=dict(decoded_ref,pointer='/proof')
                    selected_rows=[byid[cid] for cid in selected]
                reader,dag=proof_reader(proof,cat['formulas'],decoded)
            elif method=='forward':assert 'forward_native' not in refs
            else:assert method+'_proof' not in refs
            if method in ('point','sat') and positive:
                consumers={}
                for e in dag['edges']:consumers.setdefault(e['premise'],set()).add(e['conclusion'])
                shared[method]=[dict(premise=k,consumers=sorted(v)) for k,v in sorted(consumers.items()) if len(v)>1]
            costs=self.method_costs(method,refs,positive)
            if method=='point':
                raw_ref=refs['point']['search'];resources=dict(stats=point['stats'],limits=self.protocol['point_limits'],
                    internal_seconds=seconds(point['stats']['elapsed_seconds']),
                    trace_status=trace['status'],trace_counts=trace['counts'],trace_gaps=trace.get('gaps',[]),observation_scope=stream)
                admission=dict(status='VERIFIED_POSITIVE' if positive else 'VERIFIED_BOUNDED_NEGATIVE' if actual_exists[method] is False else 'UNKNOWN',
                    trace=refs['point']['trace'],model_and_basis=refs['basis_model'],native=refs.get('point_proof',{}).get('native'),
                    scope='Full graph certificate for completed results only; UNKNOWN has saved prefix assurance, no proof or absence admission.')
            elif method=='sat':
                raw_ref=refs['sat']['search'];resources=dict(nodes=sat.get('nodes'),work=sat.get('work'),limits=self.protocol['sat_limits'],encoding_counts=encoded['counts'],certificate_counts=cert.get('counts'),
                    internal_seconds=seconds(sat['seconds']))
                admission=dict(status='VERIFIED_POSITIVE' if positive else 'VERIFIED_BOUNDED_NEGATIVE' if actual_exists[method] is False else 'UNKNOWN',
                    cnf_association=refs['sat']['admission'],cnf_certificate=refs['sat']['certificate'],native=refs.get('sat_proof',{}).get('native'),
                    scope='Independent exact point/CNF association and CNF certificate; separate native gate for positives. Basic reference DPLL.')
            else:
                raw_ref=refs['forward'];resources=dict(counts=forward.get('counts'),work=forward.get('work'),limits=self.protocol['forward_limits'],
                    internal_seconds=seconds(forward['seconds']))
                admission=dict(status='VERIFIED_POSITIVE' if positive else 'CATALOGUE_BOUNDED_EXHAUSTION' if actual_exists[method] is False else 'UNKNOWN',native=refs.get('forward_native'),
                    scope='Distinct-fact bounded-existence quotient; negative exhaustion is the saved forward-control claim, not an independent UNSAT certificate or point-trace certificate.')
            row=dict(id=case['id']+'--'+method,case_id=case['id'],kind=kind,case=case,method=method,
                status=result['status'],reason=result_reason(result),raw_ref=raw_ref,prepared_ref=refs['prepare'],model_ref=dict(refs['prepare'],pointer='/model'),
                decoded_ref=decoded_ref,proof_ref=proof_ref,proof_reader=reader,theory_reader=theory,proof_dag=dag,
                slot_rows=decoded['slots'] if decoded else [],reference_mapping=decoded['reference_mapping'] if decoded else [],
                selected=selected,selected_rows=selected_rows,costs=costs,resources=resources,admission=admission,model_metadata=model_meta,
                original_statement_sha256=sha(statement))
            method_records.append(row);self.records.append(row)
        assert same(summary['shared_premises'],shared)
        output=dict(id=case['id'],kind=kind,case=case,statement=statement,theory_reader=theory,slots=slots,
            census=prepared['census'],exists=actual_exists,expected_bounded_existence=entry['expected_bounded_existence'],
            shared_premises=shared,record_ids=[x['id'] for x in method_records],refs=refs,case_seconds=seconds(summary['seconds']),
            tiny_oracle_solution_count=len(oracle['solutions']) if oracle else None,
            selector_projection_count=len(projection['solutions']) if projection else None,gap_qualified=gap is not None)
        del prepared,model,universe,point,encoded,sat,forward,oracle;gc.collect()
        return output,summary

    def method_costs(self,method,refs,positive):
        common=dict(compile_call_seconds=seconds(refs['compile']['call_seconds']),
            zeros_native_call_seconds=sum(seconds(x['call_seconds']) for x in refs['zeros']))
        point_preparation=dict(model_prepare_call_seconds=seconds(refs['prepare']['call_seconds']),
            combined_basis_model_assurance_call_seconds=seconds(refs['basis_model']['call_seconds']))
        if method=='forward':
            solve=seconds(refs['forward']['call_seconds']);native=seconds(refs['forward_native']['call_seconds']) if positive else 0
            pipeline=solve+native;private=dict(search_and_save_seconds=solve,native_and_save_seconds=native)
        else:
            solve=seconds(refs[method]['search']['call_seconds']);decode=seconds(refs[method+'_proof']['pipeline_seconds']) if positive else 0
            pipeline=seconds(refs[method]['pipeline_seconds'])+decode
            private=dict(method_pipeline_seconds=seconds(refs[method]['pipeline_seconds']),decoding_native_pipeline_seconds=decode)
            if method=='point':private['observations_write_seconds']=seconds(refs['point']['observations']['write_seconds'])
        return dict(common_logical_preparation=common,point_model_preparation=point_preparation if method!='forward' else None,
            private=private,measured_method_pipeline_seconds=pipeline,
            accounted_seconds_including_reused_preparation=sum(common.values())+pipeline+(sum(point_preparation.values()) if method!='forward' else 0),
            combined_basis_model_cost_not_disaggregated=True,
            scope='Observed once per declaration, reused by controls; not repeated cold preparation. Combined basis/model gate is reported jointly and not charged as common logic to forward. Fixed method order; distinct work units. Forward has no point-model preparation charge.')

    def units(self,qualification):
        summary=read('data/qualification/unit-summary.json');self.file('data/qualification/unit-summary.json')
        assert summary['status']=='VERIFIED' and same(summary['fixtures'],qualification['units'])
        fixtures=read('plan/unit-fixtures-v1.json')['fixtures'];assert len(fixtures)==len(summary['fixtures'])==7
        out=[]
        for fixture,row in zip(fixtures,summary['fixtures']):
            assert row['id']==fixture['id'] and row['status']=='VERIFIED';self.tree_refs(row)
            base='data/qualification/'+fixture['id'];model=read(base+'/model.json');self.file(base+'/model.json')
            assert same(model,dict(schema='Z-growing-point-model-v1',version=fixture['id'],capacity=1,roots=fixture['roots'],seed=fixture['seed'],inventory=dict(kind='EXPLICIT',placements=fixture['rows'])))
            point,trace,stream=self.point(model,row['point']);encoded,sat,cert,association=self.sat(model,row['sat'])
            assert point['status'] in ('SAT','UNSAT') and sat['status']==point['status']
            oracle=self.load(row['oracle']);projection=self.load(row['projection'])
            assert oracle['status']==projection['status']=='EXHAUSTED' and oracle['exists']==fixture['expected']==(point['status']=='SAT')
            assert oracle['model_sha256']==sha(model) and {sha(s) for s in oracle['solutions']}=={sha(s) for s in projection['solutions']}
            if 'first_decision' in fixture:assert point['events'][1]['kind']==fixture['first_decision']
            if fixture.get('require_backtrack'):assert point['stats']['backtracks']>0
            out.append(dict(id=row['id'],status='VERIFIED',point_status=point['status'],sat_status=sat['status'],
                solutions=len(oracle['solutions']),point_stats=point['stats'],observation_scope=stream,artifacts=row))
        return out

    def mutations(self,qualification):
        summary=read('data/mutations/summary.json');self.file('data/mutations/summary.json')
        assert summary['status']=='VERIFIED' and same(summary['controls'],qualification['controls'])
        rows=summary['controls'];assert len(rows)==len(MUTANTS) and {r['id'] for r in rows}==set(MUTANTS)
        out=[]
        for row in rows:
            name=row['id'];input_ref=self.file('data/mutations/'+name+'-input.json.gz');check_ref=self.file('data/mutations/'+name+'-check.json')
            check=read(check_ref['path']);expected='UNKNOWN' if name.endswith('-resource') else 'REJECTED'
            assert row['status']==check['status']==expected
            out.append(dict(id=name,expected=expected,status=check['status'],input=input_ref,receipt=check_ref))
        return out


def main():
    audit=Audit();proposal=read('plan/qualification-cases-proposal-v1.json')
    assert len(proposal['qualification_cases'])==7 and len(proposal['benchmark_cases'])==8
    provenance=audit.provenance(proposal);qualification=read('data/qualify-result.json')
    assert qualification['status']=='VERIFIED_QUALIFICATION' and len(qualification['cases'])==7
    cases=[];qual_cases=[]
    for entry,stored in zip(proposal['qualification_cases'],qualification['cases']):
        row,summary=audit.case(entry,'data/qualification/'+entry['case']['id'],'QUALIFICATION')
        assert same(stored,summary);qual_cases.append(row);cases.append(row)
    units=audit.units(qualification);mutations=audit.mutations(qualification)
    for entry in proposal['benchmark_cases']:
        case_id=entry['case']['id'];row,summary=audit.case(entry,'data/benchmark/'+case_id,'BENCHMARK')
        assert same(summary,read('data/'+case_id+'-result.json'));cases.append(row)
    coverage=dict(phases=len(audit.phase_rows),qualification_declarations=len(qual_cases),unit_fixtures=len(units),
        mutation_statuses=dict(Counter(m['status'] for m in mutations)),benchmark_declarations=8,benchmark_structural_templates=4,
        method_records=len(audit.records),method_statuses={kind:{m:dict(Counter(r['status'] for r in audit.records if r['kind']==kind and r['method']==m)) for m in ('point','forward','sat')} for kind in ('QUALIFICATION','BENCHMARK')},
        native_positive_records=sum(r['admission']['status']=='VERIFIED_POSITIVE' for r in audit.records),
        graph_full_records=sum(r['method']=='point' and r['status'] in ('SAT','UNSAT') for r in audit.records),
        point_prefix_unknowns=sum(r['method']=='point' and r['status']=='UNKNOWN' for r in audit.records),
        actual_found_proofs_not_distinct_theorems=True,additional_searches_by_assembler=0)
    assert coverage['method_records']==45
    limitations=[
        'Closed zero-arity predicates and implication, assumption-only primitive ZERO and finite subformula MP catalogue. No PA, Hilbert geometry, quantifier/GEN qualification or unrestricted FOL completeness claim.',
        'This milestone searches a semantic anchored slot/remote-mark point model. Markings define native proof constraints; they are not learned redundant markings or a planar translation-only Wang palette.',
        'UNKNOWN is unresolved. Point full-audit/serialization work is charged by the engine; a MAX_WORK refusal can occur far before the shared three-second wall ceiling. Work counters have different units and equal wall ceilings do not imply equal resources spent.',
        'Completed point results have full saved independent frontier receipts; resource results retain prefix assurance only, even if every emitted callback happened to fit. No prefix is promoted into a proof or nonprovability result.',
        'Forward distinct-fact memoization preserves bounded existence conditionally on the context-free admitted catalogue; it does not preserve all padded assignments. Its negative exhaustion is a saved control claim, not an independently replayed CNF UNSAT certificate.',
        'The SAT method is a basic stdlib clause-scanning DPLL with no modern solver comparison. Exact model/CNF association and SAT/UNSAT certificates are separate saved independent gates.',
        'Fixed point, forward, SAT order; one attempt per method/declaration. Reused preparation is observed once, not a cold repeated trial. The basis/model assurance call is combined and cannot be exactly split between logical-basis and point-model subcosts.',
        'Seven tiny qualifications and four benchmark theory templates at two bounds are small mechanism checks. Multiple found proofs and bound variants are not distinct mathematical theorems or evidence of broad benchmark superiority.',
        'No RL, family bank, learned marking, supplied target proof, historical proof reuse, universal Wang-grid search or whole-plane tiling claim. Native validity remains separate from graph/CNF semantics and process/byte custody.',
        'This assembler reads/hashes/joins saved data only. It executes no logical checker, decoder, oracle, encoder, solver, model builder or graph replay.',
        'Prefix trace and primitive/forward native receipts do not carry complete input digests themselves. Their input association relies on the frozen reviewed driver, exact artifact paths and saved byte joins; decoded point/SAT positives additionally have proof-admission wrappers.'
    ]
    costs=dict(phases=provenance['phases'],method_order=['point','forward','sat'],repeats=1,
        benchmark_totals={m:sum(r['costs']['accounted_seconds_including_reused_preparation'] for r in audit.records if r['kind']=='BENCHMARK' and r['method']==m) for m in ('point','forward','sat')},
        scope='Per-record private pipeline clocks include persistence/assurance and positive decoding/native checking; preparation is reused and combined basis/model cost is disclosed. Not a modern ATP speed comparison.')
    qual=dict(status='VERIFIED_QUALIFICATION',cases=qual_cases,unit_fixtures=units,mutations=mutations,
        result_ref=audit.file('data/qualify-result.json'))
    audit.file('review/assemble_shared_results_v1.py')
    receipt=dict(schema='Shared-fact-search-saved-audit-v1',status='PASS_SAVED_DATA_AUDIT',
        study_status='VERIFIED_PILOT_WITH_EXPLICIT_UNKNOWN',provenance=provenance,coverage=coverage,
        verified_artifact_refs=audit.refs,files=audit.files,unknown_scopes=audit.gaps,limitations=limitations,scope=__doc__)
    audit_ref=save('review/saved-data-audit-v1.json',receipt)
    summary=dict(schema='Shared-fact-search-saved-summary-v1',status='VERIFIED_PILOT_WITH_EXPLICIT_UNKNOWN',
        cases=cases,records=audit.records,qualification=qual,coverage=coverage,costs=costs,
        provenance=provenance,limitations=limitations,saved_data_audit=audit_ref,
        reader_scope='Literal saved native formulas and deterministic pred0/imp English renderings. Native proof/dependency/slot rows exist only for separately admitted positives; forward has no invented slot placement.')
    summary_ref=save('data/report-summary-v1.json',summary)
    print(json.dumps(dict(status=receipt['status'],summary=summary_ref,audit=audit_ref,coverage=coverage),sort_keys=True))


if __name__=='__main__':main()
