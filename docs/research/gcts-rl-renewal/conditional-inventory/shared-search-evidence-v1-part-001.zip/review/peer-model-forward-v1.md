# Independent Source review of the shared-fact adapter and forward control

Status: **PASS_SOURCE_REVIEW_WITH_EXTERNAL_QUALIFICATION_REQUIRED**. No remaining logical or enumeration blocker was found in the three current Sources below. This is a Source review, not a model, solver, kernel, timing or empirical-conformance result. The reviewer read the master contract first, read all three Source bodies, parsed their Python ASTs and computed byte hashes. No scientific Source was imported or executed, no model was constructed, and no case proof or prior target witness was read. Only this review file was written.

Reviewed current files:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `source/shared_fact_model_v1.py` | 22422 | `455fadf33dea5150b5e35fde599a8edb59c1adac1041d2214a44156a97b6e32e` |
| `source/ground_horn_basis_v1.py` | 8093 | `03a921908b04cb5b459e832748979fc5f7ae81b20bc6646ade64f6c1b88ba5ae` |
| `source/conventional_forward_v1.py` | 10565 | `59d1e97b4a4fd2b8fb171a9f41cc9f09351eca64fef585eb9505b392cfe1dca2` |
| `reference/basic-tiling-algorithm.md` | 21657 | `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9` |

The primary master at `docs/basic-tiling-algorithm.md` was also read. The three scientific Sources have standard-library imports only and no prior proof input.

The ground compiler enumerates every literal assumption/goal subformula, assigns positive IDs by canonical literal serialization, retains every named assumption as its own ZERO payload, and emits every structural MP type. GEN is absent. Its profile/default and declaration hashes bind the original case. The syntax is pred0/imp; the name “Horn” must not imply an additional syntactic restriction or full propositional/first-order proof-search completeness. Overflow returns UNKNOWN without a truncated admitted catalogue. Positive primitive truth still requires the separately executed native gate.

The generic adapter independently validates literal syntax/signatures, declared variables, closed assumptions, unique ZERO IDs and complete structural MP/enabled GEN for the supplied finite registry. It does not enumerate a richer formula/ZERO schema profile or check primitive logical truth, and says so. A generic prepared packet therefore needs an external profile admission and all ZERO native checks. The current six accepted ZERO rule names agree with the native checker interface; raw-kernel rule aliases are absent.

Every candidate owns exactly one unit at exactly one slot center. All centers are explicit roots from the start; active and formula ports are mark-only. Remote reads write active one and the required positive formula ID, so a consumer cannot read PAD or an incompatible owner. Assigned zero is retained. Native integer checks exclude booleans/floats for slot/reference/FID values. Namespaced, scope-bound canonical CIDs retain rule justification and strict-prior reference indices; alternate primitive justifications remain distinct.

Enumeration covers every owning slot, every ZERO/PAD choice, every ordered pair of earlier MP references, and every earlier GEN reference. Internal repeated-port disagreement is the only omitted combination. For finite literal syntax, an MP antecedent cannot equal the implication that contains it, so diagonal reference pairs conflict. With (L) slots, (Z) ZERO types, (M) MP types and (G) GEN types, the checked census is

\[
N_{\mathrm{potential}}=L(Z+1)+M\sum_{i=0}^{L-1}i^2+G\sum_{i=0}^{L-1}i,
\qquad N_{\mathrm{conflict}}=M\sum_{i=0}^{L-1}i.
\]

The Source counts actual conflicts and checks the emitted total against this census. It refuses an over-cap full universe before constructing rows; it does not use a producer or target-proof shortlist. The seed pins the last slot active with the unchanged goal while permitting PAD elsewhere. This is a bounded anchored semantic point encoding with explicit problem-defining markings, not a planar translation-only Wang tile system.

The decoder reconstructs and canonical-compares every mathematical prepared field, including the complete model/universe, before accepting selected IDs. It requires one owner per slot, checks full capacity/mark/seed agreement, orders active slots, deletes PAD and maps all references to active earlier native lines. Noncontiguous active slots and unused active lines are permitted. The whole original statement is retained and the final active line is the unchanged goal. Its `UNVERIFIED_NATIVE_CERTIFICATE` status correctly leaves logical validity to native B, including every unused active line and substitution hygiene.

The forward control starts from the empty fact set, so assumptions/schema instances cost a line. Every transition introduces one unavailable formula through a catalogue ZERO, MP or GEN; references are looked up in the actual retained parent path. Parent states decrease in cardinality during reconstruction, so the produced proof is ordered, has at most the declared line bound, and ends at the newly introduced goal. The declared slot bound must equal its line bound. No facts or complete target derivation are preloaded.

The fact-set memoization quotient preserves bounded existence under the stated context-free catalogue and closed-assumption conditions. Redirecting a repeated literal formula to its earliest occurrence preserves all later premises and GEN side conditions; deleting that repeated introduction cannot increase line cost. If the goal occurred earlier, the proof can end at that earlier occurrence. Every retained set has exactly its cardinality in introductions, so two paths to the same set have the same remaining line allowance and future rule applicability. Conversely every returned path embeds into the PAD slot model with its goal at the last slot. This argument preserves existence, not padded assignments, native proof multiplicity or a bijection of proof graphs. It must be revisited if future rules depend on derivation history, scoped assumptions or consumable resources.

`NOT_DERIVABLE_WITHIN_BOUND` occurs only after the entire reachable bounded queue is exhausted. Work/state/wall refusals return UNKNOWN. Positive native validity remains explicitly pending. The forward control is a conventional quotient search and makes no claim to use the GCTS scheduler or preserve all point-model solution assignments.

One actionable resource-accounting issue was found and resolved before freeze. The initially reviewed forward Source was 10363 bytes, SHA256 `e0f13cd5bf57d3e5fa6173e0421c8e913ac0cefb1aad56756237f5e297c18880`: its scan counted JSON nodes but skipped complete string lengths and dictionary keys. Root patched the scan to visit keys and charge string length to both item/work counters. The reviewer inspected that patch; removing exactly those scan additions from the current bytes reconstructs the initially reviewed SHA. This changes resource accounting only. The current pin above is the approved review target. The preserved earlier bound-guard snapshot predates the already-reviewed slot/line bound check and is not itself the latest approved Source.

Before scientific admission, prospective qualification should still exercise complete independently reconstructed basis/model tables; dropped ZERO/MP/row with adjusted census; bool/float and scope/port mutations; shared reads; a remote contradiction; read-versus-PAD; self/forward-reference refusal; noncontiguous decoding; and an independently admitted closed quantified GEN fixture. Tiny exhaustive point-assignment existence must agree with the forward quotient within the same bounds. The unchanged engine needs its full-event frontier/dependency/rollback gate, and each extracted positive needs native B. Resource and assurance refusals must remain UNKNOWN. None of these executions is claimed by this Source review.

Preparation, primitive admission, full graph assurance, decoding and native checking must be included in later costs. All current resource checks are cooperative and should retain the owned process observer. No search speed, GCTS/RL advantage, new theorem, universal palette search or unrestricted non-theorem result follows from this review.
