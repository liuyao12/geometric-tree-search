# Independent Source review of tiny point/CNF helpers

Final status: **PASS_SOURCE_REVIEW_WITH_EXTERNAL_QUALIFICATION_REQUIRED**. All findings below are closed by the final pins recorded at the end. The initial read requested revisions before freeze; those initial and intermediate pins remain recorded for provenance. This review is Source only. The author read both complete files, parsed Python ASTs and computed hashes. No helper, model builder, engine, solver, checker or case proof was executed/read. No scientific Source was edited.

Initial reviewed pins:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `reference/tiny_point_oracle_v1.py` | 5331 | `280530df40b194578fa33777aca65d2b7c56636cf40bac899801c4ee963c1e9c` |
| `reference/point_cnf_admission_v1.py` | 5401 | `5e87b2e16d74303115673f22b09c54765356532b3aeb351d1aa4da7456dc8d63` |

The point oracle chooses the first uncovered required root, enumerates every incident compatible candidate, and copies the complete total/mark state. For the declared finite model with unit contributions and all support rooted, each exact solution has exactly one candidate covering that chosen root, so this recursive decomposition is complete and does not duplicate solution sets. Seed-filled roots correctly block later contributions. Every positive candidate touches a root, so a full target cannot admit an unselected additional legal positive candidate. The final distinct-solution assertion is appropriate. This oracle deliberately uses a different decision order from GCTS and is not a scheduler-conformance check.

The generic CNF projection search fixes every selector bit pattern and asks whether any remaining-variable assignment extends it. Its clause simplification and repeated unit propagation are logically sound on a well-formed CNF; recursive splitting handles both truth values of an occurring unassigned variable. Unused nonselector variables need no explicit enumeration. With unique selectors, successful masks correspond exactly to the selected-CID subsets that have a CNF extension. No encoder, production solver or certificate code is imported.

The admission checker looks up variables by their complete declared role rather than reproducing encoder allocation. It reconstructs all candidate/mark roles and the entire clause multiset. Its sequential at-most-one clauses are the standard implication/prefix/conflict constraints: root coverage has an at-least-one clause unless already filled by the seed, and every candidate incident to a seed-filled root is forbidden. An empty unfilled root emits an empty clause. Mark variables have at-most-one values, candidate implications request assigned values, and seed units pin values; missing assignments remain unconstrained. Existential auxiliary values therefore preserve exact shared marking agreement. Requiring every variable role to be used excludes extra unexplained variables. Clause/literal order may vary while multiplicity remains exact; the saved CNF digest still binds the actual ordered clause table.

Initial actionable findings sent to Root:

1. `tiny_point_oracle.solve` validates row markings but not native string types for all roots, contribution points and seed marking pairs. It can therefore label malformed engine-ABI inputs exhausted. Require native string points/CIDs and seed marking values, and maintain unique well-formed pairs. Catch `MemoryError`/`RecursionError` as UNKNOWN for this recursive bounded helper. Construct the digest/result before the final wall gate.
2. `selector_projections` needs strict limit, variable and clause validation. Require native integer variable/literal IDs, nonzero literals within the declared range, unique selector IDs/variables and correct pair shape. Otherwise it can silently quantify undeclared variables or project duplicate/aliased selectors. Native booleans/floats must not be accepted as integer IDs.
3. Projection wall checks occur only at recursive entry. A single empty-selector extension can spend arbitrary time scanning/propagating clauses and return EXHAUSTED without another gate. Add checks inside clause/propagation work, at each outer selector mask and after final result construction. Resource refusal must remain UNKNOWN, never a complete projection claim.
4. Admission compares `selector_variables` with native Python equality. A forged `true` or floating value can compare equal to an expected native integer ID. Use typed canonical equality or validate each selector ID's native integer type before equality. Require native string model points/CIDs/seed marking values consistently with the engine ABI. Its last `sha(model)` is evaluated after the final resource gate; construct the receipt first, then gate.

These are type/resource-assurance gaps, rather than a demonstrated mathematical mismatch for the current prospective generated cases. No case was executed. Full catalogue/model admission, full-frontier conformance and native proof truth remain external gates. The helpers do not establish unrestricted proof completeness, a Wang-grid search or an empirical performance result.

The amended Sources were subsequently read in full and AST-parsed without execution:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `reference/tiny_point_oracle_v1.py` | 6920 | `0ce89502cc0dd14dcb83ccc6961dabe46e2c4f04960a21162429d848e253ac29` |
| `reference/point_cnf_admission_v1.py` | 5742 | `1cd19161f8e9d1169e20b06008761e7e8d39687786ef0a879bc74fea4122a3b9` |

These amendments close the original selector integer/range/uniqueness issue, typed selector-metadata comparison, root/contribution/seed-mark types, propagation and final wall gates, and host memory/recursion refusal. The valid-input enumeration and clause mathematics remain unchanged.

One final type gate remained at those intermediate pins: require every candidate ID to be a **nonempty native string**. The tiny oracle then required a string but permitted an empty ID; CNF admission lacked a candidate-ID string assertion. The pinned engine's `_placement` explicitly calls `_string(value['id'], ..., True)`. Root added that gate to both helpers. The reviewer subsequently reread both final bodies in full, AST-parsed them and independently computed these final pins:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `reference/tiny_point_oracle_v1.py` | 6932 | `ac3d372837c3436732d250e5b08cfd4eeb79925287a27b331c9714afb5d99a52` |
| `reference/point_cnf_admission_v1.py` | 5809 | `1e686a79458ae25cc43d1384dbfa14b8ed39df52db513eb5d7ee6d8fb1828754` |

All listed findings are closed at these final pins. No further logical, type or resource-status blocker was found within the declared finite rooted-unit/tiny-CNF scope. Resource checks remain cooperative rather than instantaneous interruption guarantees; the process observer is still required. The generic projection helper's selector labels are opaque strings, while association with actual engine candidate IDs is supplied by the separate model/CNF admission gate. Native truth, all-case qualifications and complete scheduler traces remain external and unexecuted by this reviewer. This final review file is now held unchanged for prospective freeze.
