"""Passive reader of admitted saved shared-fact search records.

No scientific Source imports, model construction, solving, native checking,
certificate replay or proof transformation. Only saved-data selection and
literal point-row display metadata are produced. Full traces are downloads.
"""
import argparse
import copy
import gzip
import hashlib
import html
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
RESULTS = 'shared-search-results-v1.json.gz'


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def pin(path):
    h, n = hashlib.sha256(), 0
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            h.update(block)
            n += len(block)
    return dict(bytes=n, sha256=h.hexdigest())


def is_ref(value):
    return isinstance(value, dict) and {'path', 'bytes', 'sha256'} <= set(value)


def references(value):
    if is_ref(value):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from references(child)
    elif isinstance(value, list):
        for child in value:
            yield from references(child)


def path_for(root, ref):
    path = (root/ref['path']).resolve()
    if not path.is_relative_to(root) or pin(path) != {key: ref[key] for key in ('bytes', 'sha256')}:
        raise ValueError('Saved artifact byte binding: '+str(ref['path']))
    return path


def exclusive(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


def mark_display(record):
    """Read own/remote port identities from the actual selected t/m rows."""
    rows = record.get('selected_rows') or []
    if not rows:
        return dict(status='NO_POINT_CERTIFICATE', slots=[],
            scope='No selected point certificate is supplied for this method/outcome.')
    if record['method'] not in ('point', 'sat') or not record.get('proof_reader'):
        raise ValueError('Selected rows require an independently admitted point/SAT positive')
    if set(record.get('selected') or []) != {row['id'] for row in rows}:
        raise ValueError('Selected rows/identities differ')
    decoded_slots = {row['slot']: row for row in (record.get('slot_rows') or [])}
    slots = []
    for row in rows:
        action = json.loads(row['id'])
        if not isinstance(action, list) or len(action) != 6 or action[0] != 'DAG-candidate-v1':
            raise ValueError('Unsupported saved selected-CID display profile')
        _, scope, index, kind, definition, refs = action
        if type(index) is not int or index < 0:
            raise ValueError('Saved slot index')
        own, requests = {}, []
        for point, value in row['m']:
            port = json.loads(point)
            if not isinstance(port, list) or len(port) != 3 or port[1] != scope or type(port[2]) is not int:
                raise ValueError('Saved mark port display profile')
            if port[0] not in ('DAG-slot-active-v1', 'DAG-slot-formula-v1'):
                raise ValueError('Unknown saved mark layer')
            channel = 'active' if port[0] == 'DAG-slot-active-v1' else 'formula'
            if port[2] == index:
                own[channel] = dict(point=point, value=value)
            else:
                requests.append(dict(channel=channel, owner_slot=port[2], point=point, value=value))
        if set(own) != {'active', 'formula'} or len(row['t']) != 1:
            raise ValueError('Saved owner ports/positive support')
        center, units = row['t'][0]
        if wire(json.loads(center)) != wire(['DAG-slot-center-v1', scope, index]) or type(units) is not int or units != 1:
            raise ValueError('Saved center display binding')
        mapped = decoded_slots.get(index)
        if mapped is None or mapped['cid'] != row['id'] or str(mapped['active']) != own['active']['value'] or str(mapped['formula_id']) != own['formula']['value']:
            raise ValueError('Saved row/decoded slot display mismatch')
        slots.append(dict(slot=index, kind=kind, definition=definition, refs=refs,
            line_index=mapped['native_line_index_or_null'], active=own['active'], formula=own['formula'],
            center=dict(point=center, units=units), requests=requests, exact=row))
    slots.sort(key=lambda item: item['slot'])
    if len({item['slot'] for item in slots}) != len(slots):
        raise ValueError('Duplicate displayed slot')
    by_slot = {item['slot']: item for item in slots}
    for item in slots:
        for request in item['requests']:
            owner = by_slot.get(request['owner_slot'])
            if owner is None or owner[request['channel']]['point'] != request['point'] or owner[request['channel']]['value'] != request['value']:
                raise ValueError('Saved receptor/owner display mismatch')
    return dict(status='ACTUAL_SELECTED_POINT_ROWS', slots=slots,
        scope='Colored own and requested marks are taken literally from the saved selected rows. This display does not independently validate a model, proof, search trace or certificate.')


CSS = r'''
:root{--ink:#233840;--muted:#607478;--line:#dbe5e2;--paper:#f6f8f6;--teal:#267b6b;--blue:#397ea8;--gold:#a87733;--red:#a14f51}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.65 system-ui,sans-serif}a{color:#236c86;text-underline-offset:3px}header{background:#173e42;color:white;padding:46px max(24px,calc((100vw - 1220px)/2)) 32px}header a{color:#c4e6dd}.eyebrow{font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:#acd5cb}h1{font:clamp(32px,5vw,52px)/1.12 Georgia,serif;max-width:900px;margin:15px 0}h2{font:30px/1.2 Georgia,serif;margin:0 0 18px}h3{font:22px/1.25 Georgia,serif;margin:22px 0 10px}p{margin:10px 0}.lede{font-size:18px;max-width:900px;color:#d9e9e3}nav{display:flex;gap:20px;flex-wrap:wrap;font-size:14px;margin-top:22px}main{max-width:1270px;margin:auto;padding:30px 24px 65px}section{background:white;border:1px solid var(--line);border-radius:13px;padding:26px;margin-bottom:24px}.note{font-size:14px;color:var(--muted)}.callout{padding:13px 17px;border-left:4px solid var(--teal);background:#edf5ef}.warning{border-color:var(--gold);background:#fbf4e8}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:13px}.metric{padding:15px;border:1px solid var(--line);border-radius:8px}.metric strong{font:30px Georgia,serif;display:block}.metric span{font-size:13px;color:var(--muted)}.scroll,.formula-scroll{overflow-x:auto}.formula-scroll{max-width:100%;padding:3px 0}table{width:100%;border-collapse:collapse;font-size:14px}td,th{overflow-wrap:anywhere;padding:10px 9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{background:#f3f7f4;color:#44616a}.badge{display:inline-block;background:#eaf0ed;border-radius:5px;padding:2px 7px;font:12px/1.5 ui-monospace,monospace;overflow-wrap:anywhere}.badge.ok{background:#deeee3;color:#2b6547}.badge.unknown{background:#f8ead2;color:#855e22}.finder{display:inline-block;border:1px solid #c6d8d3;border-radius:6px;padding:5px 10px;font-size:13px;font-weight:600;color:#315f65}.proof-table{table-layout:fixed}.proof-table th:nth-child(1){width:5%}.proof-table th:nth-child(2){width:43%}.proof-table th:nth-child(3){width:31%}.proof-table th:nth-child(4){width:21%}.proof-table td:nth-child(2){overflow:hidden}.proof-table tr.chosen{background:#edf5ef}.proof-table button{padding:3px 6px}button,select{font:inherit;color:var(--ink);background:#fff;border:1px solid #b7cbc5;border-radius:7px;padding:8px 12px}button{cursor:pointer}button:hover,button.active{background:#edf5ef;border-color:#498a78}label{display:inline-flex;flex-direction:column;gap:5px;margin:0 12px 14px 0;color:var(--muted);font-size:13px}.check-label{flex-direction:row;align-items:center;gap:8px}code,pre{font:12px/1.5 ui-monospace,monospace}code{overflow-wrap:anywhere}pre{padding:14px;background:#f3f6f4;border-radius:7px;white-space:pre-wrap;max-height:430px;overflow:auto}.two>div{min-width:0}.two{display:grid;grid-template-columns:1.15fr 1fr;gap:24px}.diagram{min-width:560px;width:100%;display:block}.legend{display:flex;gap:17px;flex-wrap:wrap;font-size:12px;margin-bottom:15px}.dot{width:11px;height:11px;border-radius:50%;display:inline-block;margin-right:5px}.links{display:flex;gap:15px;flex-wrap:wrap;font-size:14px}.quick{display:flex;gap:8px;flex-wrap:wrap;margin:15px 0}.quick button{font-size:12px}.mini{font-size:12px;color:var(--muted)}.error{color:var(--red)}details{margin:15px 0}summary{cursor:pointer;color:#356971}footer{font-size:13px;color:var(--muted)}@media(max-width:800px){main{padding:15px 10px}section{padding:18px 12px}.two{grid-template-columns:1fr}.proof-table{min-width:800px}header{padding:34px 20px 25px}}'''

BODY = r'''
<header><div class="eyebrow">GCTS research · search with shared facts</div><h1>Let later inferences<br>read the same earlier fact</h1><p class="lede">A finite proof model with explicit line slots and distant formula receptors. Inspect the actual result of each search method, the certificate it found, and every decoded proof line.</p><nav><a href="#assessment">Assessment</a><a href="#reader">Proof reader</a><a href="#markings">Colored receptors</a><a href="#costs">Costs and limits</a><a href="shared-search-evidence-v1.html">Evidence</a></nav></header>
<main><p id="loading" class="note">Loading the admitted saved-data summary…</p>
<section id="assessment"><h2>What the pilot actually found</h2><div id="assessment-text"></div><div id="metrics" class="grid"></div><p class="callout warning">No GCTS proof-search advantage is established. The present contribution is a checkable reduction to a shared-fact point problem, qualified on tiny examples. Proofs found by conventional controls are attributed to those controls.</p><p class="note">The benchmark point engine's work cap counts bookkeeping and audit serialization, as well as search operations. Reaching that cap before the wall ceiling is an unresolved attempt. Resource accounting needs calibration before adding learning or RL.</p><div id="outcomes" class="scroll"></div></section>
<section id="reader"><h2>Choose an actual attempt</h2><label>Experiment group<select id="group"><option value="BENCHMARK">Benchmark</option><option value="QUALIFICATION">Logical qualification</option></select></label><label>Case<select id="case"></select></label><label>Discovering method<select id="method"></select></label><label class="check-label"><input type="checkbox" id="short-labels" checked>Use short proposition labels</label><div id="attempt"></div><div id="theory"></div><details><summary>Bijective proposition labels and unaltered selected formula</summary><div id="symbol-legend"></div><pre id="literal-formula"></pre><p class="note">Labels change only the display. Untick the box for the saved full-name formulas and English; native proof downloads retain the original symbols.</p></details><div id="proof-state"></div><div id="proof" class="scroll"></div><div id="qualification-links" class="quick"></div><details><summary>Exact saved artifacts for this attempt</summary><div id="record-downloads" class="links"></div><pre id="record-admission"></pre></details></section>
<section id="markings"><h2>Active and formula marking layers</h2><p>Each owner fills one required slot with \(t=1\). Its active and formula markings can be read at distant earlier slots. A PAD owner explicitly assigns zero active and formula values; a consumer requests active one. Several consumers may read one earlier fact without placing it again.</p><p class="note">These are problem-defining marks, with literal agreement constraints. No learned marking, cluster bank or RL policy is used. The model is an anchored symbolic point adaptation; it is not a search on a uniform Wang grid.</p><div id="mark-status"></div><div class="legend"><span><i class="dot" style="background:#258375"></i>Active layer</span><span><i class="dot" style="background:#437faf"></i>Formula layer, colored by literal ID</span><span><i class="dot" style="background:#aab5b6"></i>Inactive PAD</span></div><label class="check-label"><input type="checkbox" id="all-links">Show every recorded receptor connection</label><div class="two"><div id="slot-diagram" class="scroll"></div><div><div id="selected-slot"></div><h3>Shared references in this proof</h3><div id="sharing"></div><details><summary>Formula-ID color legend</summary><div id="fid-legend"></div></details><details><summary>Exact selected row and remote marks</summary><pre id="exact-row"></pre></details></div></div><details><summary>Declared point model and seed metadata</summary><pre id="model-metadata"></pre></details><p class="note">Slot indices retain their zero-based certificate values. Human proof lines are numbered from one. The colored graph is a display of supplied selected rows; proof and full-frontier checks are separate saved receipts.</p></section>
<section id="costs"><h2>Measured costs and scope</h2><p>The fixed method order is point search, forward shared-fact search, then reference DPLL. Search wall ceilings are three seconds; work counters have different meanings. Point auditing runs inside its search budget. The DPLL control is a small reference implementation, not a modern SAT benchmark.</p><h3>Selected attempt</h3><div id="selected-costs" class="scroll"></div><details><summary>Exact cost/resource fields</summary><pre id="exact-costs"></pre></details><h3>Pilot accounting</h3><div id="pilot-costs"></div><h3>Qualification</h3><div id="qualification"></div><h3>Interpretation and next step</h3><p>Sharing is available during this search: a rule can refer to an existing earlier fact. The previous study shortened already discovered proofs afterwards. This representation change alone is not evidence of a better search algorithm.</p><p>Next: calibrate the complete graph and audit resource budgets, and establish stronger conventional baselines before training a policy. This pilot uses a finite assumption-only ground predicate/implication basis. It proves no general completeness result for first-order logic, Peano arithmetic or Hilbert geometry.</p><div id="limitations"></div><details><summary>Saved-data audit and provenance</summary><pre id="provenance"></pre></details><p class="links"><a href="proof-reuse-v1.html#reader">Earlier post-search proof reuse</a><a href="shared-search-evidence-v1.html">Evidence index</a><a download href="shared-search-results-v1.json.gz">Reader projection</a></p><!-- SHARED_SEARCH_ARCHIVE_LINK --></section><footer>Only saved records are projected here. No prover, encoder, native checker or search runs in the browser.</footer></main>'''

SCRIPT = r'''
const $=id=>document.getElementById(id),esc=x=>String(x??'Unavailable').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text=x=>x===null||x===undefined?'Unavailable':typeof x==='object'?JSON.stringify(x):String(x),num=x=>typeof x==='number'?x.toLocaleString('en-US',{maximumFractionDigits:6}):text(x),found=r=>r.status==='SAT'||r.status==='DERIVABLE',absent=r=>r.status==='UNSAT'||r.status==='NOT_DERIVABLE_WITHIN_BOUND';
const names={point:'Point engine',forward:'Conventional forward control',sat:'Reference SAT / DPLL control'},badge=x=>`<span class="badge ${x==='SAT'||x==='DERIVABLE'||String(x).includes('VERIFIED')?'ok':x==='UNKNOWN'?'unknown':''}">${esc(text(x))}</span>`,table=(heads,rows,cls='')=>`<table class="${cls}"><thead><tr>${heads.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`;
let data,recordIndex=0,lineIndex=0,slotIndex=null,aliases={},mathQueue=Promise.resolve();
function typeset(node=document.body){mathQueue=mathQueue.catch(()=>{}).then(async()=>{if(window.MathJax?.startup?.promise)await MathJax.startup.promise;if(window.MathJax?.typesetPromise)await MathJax.typesetPromise([node]);});mathQueue.catch(e=>console.error(e));}window.addEventListener('load',()=>typeset(document.body));
const current=()=>data.records[recordIndex],readers=()=>current().proof_reader??[],edges=()=>current().proof_dag?.edges??[],fidColor=id=>id==='0'?'#9caeb1':`hsl(${(Number(id)*67+175)%360} 42% 43%)`;
function aliasesFor(r){let ns=Object.keys(r.case?.statement?.theory?.predicates??{}).sort(),last=ns.map(n=>n.match(/([A-Za-z])$/)?.[1]?.toUpperCase()??null),unique=last.every(Boolean)&&new Set(last).size===ns.length;return Object.fromEntries(ns.map((n,i)=>[n,unique?last[i]:i<26?String.fromCharCode(65+i):'P'+(i+1)]));}
function shortLatex(a){if(!Array.isArray(a))return null;if(a[0]==='pred'&&Array.isArray(a[2])&&!a[2].length&&aliases[a[1]])return '\\mathsf{'+aliases[a[1]]+'}';if(a[0]==='imp'){let l=shortLatex(a[1]),r=shortLatex(a[2]);if(l!==null&&r!==null)return '\\left('+l+'\\Rightarrow '+r+'\\right)';}return null;}
function formula(r){let latex=$('short-labels').checked?shortLatex(r?.formula):null;return `\\(${esc(latex??r?.formula_latex??'\\text{Unavailable}')}\\)`;}
function english(r){let t=text(r?.english);if($('short-labels').checked)for(let n of Object.keys(aliases).sort((a,b)=>b.length-a.length))t=t.split(n).join(aliases[n]);return t;}
function renderSymbols(){let r=current();aliases=aliasesFor(r);$('symbol-legend').innerHTML=table(['Display label','Unchanged native proposition'],Object.entries(aliases).map(([n,a])=>`<tr><td>\\(\\mathsf{${esc(a)}}\\)</td><td><code>${esc(n)}</code></td></tr>`));renderLiteral();typeset($('symbol-legend'));}
function renderLiteral(){let r=readers()[lineIndex];$('literal-formula').textContent=JSON.stringify(r?{human_line:lineIndex+1,formula:r.formula,rule:r.rule,dependencies:r.dependencies,slot:r.slot,formula_id:r.formula_id,original_english:r.english,proof_source:current().proof_ref}: {scope:'No admitted proof line for this outcome.'},null,2);}
function renderTheory(){let th=current().theory_reader;$('theory').innerHTML=th?table(['Original assumption','Formula','English'],(th.hypotheses??[]).map(h=>`<tr><td><code>${esc(h.name)}</code></td><td><div class="formula-scroll">${formula(h)}</div></td><td>${esc(english(h))}</td></tr>`))+`<h3>Declared target</h3><div class="formula-scroll">${formula(th.goal??th.conclusion)}</div><p>${esc(english(th.goal??th.conclusion))}</p>`:'<p class="note">No human statement projection was supplied; inspect the exact declaration download.</p>';typeset($('theory'));}

function totals(rs,method){let rows=rs.filter(r=>r.method===method);return {all:rows.length,proofs:rows.filter(found).length,absent:rows.filter(absent).length,unknown:rows.filter(r=>r.status==='UNKNOWN').length};}
function renderAssessment(){let bench=data.records.filter(r=>r.kind==='BENCHMARK'),p=totals(bench,'point'),f=totals(bench,'forward'),s=totals(bench,'sat'),q=totals(data.records.filter(r=>r.kind==='QUALIFICATION'),'point');$('assessment-text').innerHTML=`<p><b>Benchmark point search: ${p.proofs} proofs, ${p.absent} finite bounded exhaustions, ${p.unknown} UNKNOWN out of ${p.all} attempts.</b></p><p>The forward control found ${f.proofs} checked proofs and reported ${f.absent} bounded exhaustions; the basic SAT control found ${s.proofs} checked proofs and left ${s.unknown} UNKNOWN. The point engine's actual checked proofs are in the logical qualification group (${q.proofs} positive cases).</p>`;$('metrics').innerHTML=[['point',p],['forward',f],['sat',s]].map(([m,t])=>`<div class="metric"><strong>${t.proofs} / ${t.unknown}</strong><span>${esc(names[m])}: proofs / UNKNOWN</span></div>`).join('');let cases=[...new Set(bench.map(r=>r.case_id))];$('outcomes').innerHTML=table(['Declared benchmark','Point engine','Forward shared-fact','Reference SAT'],cases.map(id=>{let rows=bench.filter(r=>r.case_id===id),c=rows[0].case;return `<tr><td><code>${esc(id)}</code><br><span class="mini">Slot bound ${esc(c.profile.slots)}</span></td>${['point','forward','sat'].map(m=>{let r=rows.find(x=>x.method===m);return `<td>${r?badge(r.status):'No saved record'}${r?.reason?'<br><span class="mini">'+esc(r.reason)+'</span>':''}</td>`;}).join('')}</tr>`;}));}
function populateCases(prefer,preferMethod){let group=$('group').value,records=data.records.filter(r=>r.kind===group),ids=[...new Set(records.map(r=>r.case_id))];$('case').innerHTML=ids.map(id=>`<option value="${esc(id)}">${esc(id)}</option>`).join('');if(ids.includes(prefer))$('case').value=prefer;populateMethods(preferMethod);}
function populateMethods(prefer){let group=$('group').value,id=$('case').value,rows=data.records.map((r,i)=>[r,i]).filter(([r])=>r.kind===group&&r.case_id===id);$('method').innerHTML=rows.map(([r,i])=>`<option value="${i}">${esc(names[r.method]??r.method)} · ${esc(r.status)}</option>`).join('');let match=rows.find(([r])=>r.method===prefer);if(match)$('method').value=match[1];recordIndex=Number($('method').value);selectRecord();}
function selectExact(index){let r=data.records[index];$('group').value=r.kind;populateCases(r.case_id,r.method);}
function recordLinks(r){return Object.entries(r.downloads??{}).map(([key,ref])=>`<a download href="${esc(ref.url)}">${esc(key.replaceAll('_',' '))}${ref.pointer?' · '+esc(ref.pointer):''}</a>`).join('');}
function selectRecord(){let r=current();lineIndex=0;slotIndex=r.mark_display.slots?.find(s=>s.line_index===0)?.slot??null;$('attempt').innerHTML=`<p><span class="finder">${esc(names[r.method]??r.method)}</span> ${badge(r.status)} <span class="mini">${esc(r.kind)} · ${esc(r.case_id)}</span></p>`+(r.reason?`<p class="note">Recorded stop/reason: <code>${esc(r.reason)}</code></p>`:'');renderSymbols();renderTheory();
let has=readers().length>0;$('proof-state').innerHTML=has?`<p class="callout">This proof was discovered by <b>${esc(names[r.method])}</b> and separately native-checked. ${r.method==='point'?(r.kind==='QUALIFICATION'?'This is a tiny qualification proof.':'This is a benchmark point-search proof.'):'It is not attributed to the point engine.'}</p>`:`<p class="callout warning">${r.status==='UNKNOWN'?'This attempt is unresolved. No checked proof is supplied for it.':absent(r)?'This is a finite bounded exhaustion result; no proof of the target is supplied.':'No separately admitted proof is supplied for this saved outcome.'} Another method's proof is not substituted here.</p>`;$('record-downloads').innerHTML=recordLinks(r);$('record-admission').textContent=JSON.stringify(r.admission??null,null,2);renderProof();renderMarks();renderCosts();typeset($('reader'));}
function chooseLine(i){lineIndex=i;renderLiteral();let slot=current().mark_display.slots?.find(s=>s.line_index===i);slotIndex=slot?.slot??null;renderProof();renderMarks();}
function renderProof(){let rs=readers();$('proof').innerHTML=rs.length?table(['Line','Formula','English','Rule / references'],rs.map((r,i)=>{let dependencies=edges().filter(e=>e.conclusion===i).map(e=>e.premise+1);return `<tr class="${i===lineIndex?'chosen':''}"><td><button data-line="${i}">${i+1}</button></td><td><div class="formula-scroll">${formula(r)}</div></td><td>${esc(english(r))}</td><td><code>${esc(r.rule)}</code><br>${dependencies.length?'Uses lines '+[...new Set(dependencies)].join(', '):'No earlier-line reference'}${r.slot!==null&&r.slot!==undefined?'<p class="mini">Certificate slot '+esc(r.slot)+'</p>':''}</td></tr>`;}),'proof-table'):'';document.querySelectorAll('[data-line]').forEach(b=>b.onclick=()=>chooseLine(Number(b.dataset.line)));typeset($('proof'));}
function renderMarks(){let r=current(),display=r.mark_display,slots=display.slots??[],has=display.status==='ACTUAL_SELECTED_POINT_ROWS';$('mark-status').innerHTML=has?`<p class="callout">Actual selected point certificate found by <b>${esc(names[r.method])}</b>. Select a slot or proof line to inspect its two marking layers and earlier-slot requests.</p>`:`<p class="callout warning">${r.method==='forward'&&readers().length?'The forward control supplies a native proof without an anchored point-placement certificate. Its shared logical references appear below; no slot tiling is invented.':'No complete selected point certificate is admitted for this attempt. No marking diagram is borrowed from another method.'}</p>`;$('model-metadata').textContent=JSON.stringify(r.model_metadata??null,null,2);$('slot-diagram').innerHTML='';$('selected-slot').innerHTML='';$('exact-row').textContent='';if(has){if(!slots.some(s=>s.slot===slotIndex))slotIndex=slots.find(s=>s.active.value==='1')?.slot??slots[0].slot;let height=slots.length*83+45,y=s=>35+slots.findIndex(x=>x.slot===s)*83;let p=[`<svg class="diagram" viewBox="0 0 720 ${height}" role="img" aria-label="Actual selected owner slots and long-range active/formula requests"><defs><marker id="mark-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#647d79"/></marker></defs>`];let shown=$('all-links').checked?slots:slots.filter(s=>s.slot===slotIndex);shown.forEach(s=>s.requests.forEach((q,i)=>{let source=y(s.slot)+(q.channel==='active'?21:45),target=y(q.owner_slot)+(q.channel==='active'?21:45),x=450+(s.slot%3)*45+(i%2)*16;p.push(`<path d="M385 ${source} C${x} ${source},${x} ${target},385 ${target}" stroke="${q.channel==='active'?'#258375':fidColor(q.value)}" stroke-width="${s.slot===slotIndex?2.5:1.1}" fill="none" ${q.channel==='active'?'stroke-dasharray="5 3"':''} marker-end="url(#mark-arrow)"><title>${esc('Slot '+s.slot+' requests '+q.channel+' '+q.value+' from slot '+q.owner_slot)}</title></path>`);}));slots.forEach(s=>{let yy=y(s.slot),active=s.active.value==='1';p.push(`<g data-slot="${s.slot}" role="button" tabindex="0"><rect x="24" y="${yy}" width="362" height="66" rx="7" fill="${s.slot===slotIndex?'#e7f3ec':'#f8faf8'}" stroke="${s.slot===slotIndex?'#2a7b69':'#c8d8d1'}" stroke-width="${s.slot===slotIndex?2:1}"/><rect x="170" y="${yy+9}" width="205" height="22" rx="4" fill="${active?'#258375':'#9caeb1'}"/><rect x="170" y="${yy+35}" width="205" height="22" rx="4" fill="${fidColor(s.formula.value)}"/><text x="36" y="${yy+20}" font-size="12" fill="#28444b">Slot ${s.slot} · ${esc(s.kind)}</text><text x="36" y="${yy+42}" font-size="11" fill="#5b7077">${s.line_index===null?'No native line':'Proof line '+(s.line_index+1)}</text><text x="36" y="${yy+57}" font-size="10" fill="#5b7077">One center unit</text><text x="182" y="${yy+24}" font-size="11" fill="white">active port: ${esc(s.active.value)}</text><text x="182" y="${yy+50}" font-size="11" fill="white">formula ID: ${esc(s.formula.value)}</text></g>`);});p.push('</svg>');$('slot-diagram').innerHTML=p.join('');document.querySelectorAll('[data-slot]').forEach(b=>b.onclick=()=>{slotIndex=Number(b.dataset.slot);let s=slots.find(s=>s.slot===slotIndex);if(s.line_index!==null)lineIndex=s.line_index;renderProof();renderMarks();});let selected=slots.find(s=>s.slot===slotIndex),reader=selected.line_index===null?null:readers()[selected.line_index];$('selected-slot').innerHTML=`<h3>Slot ${selected.slot} · ${esc(selected.kind)}</h3><p>Own center capacity: \\(t=1\\). Active value <code>${esc(selected.active.value)}</code>; formula ID <code>${esc(selected.formula.value)}</code>.</p>`+(reader?`<div class="formula-scroll">${formula(reader)}</div><p>${esc(english(reader))}</p>`:'<p class="note">Explicit inactive PAD, with both marking values zero.</p>')+(selected.requests.length?table(['Layer','Earlier owner','Literal value'],selected.requests.map(q=>`<tr><td>${esc(q.channel)}</td><td>Slot ${q.owner_slot}</td><td><code>${esc(q.value)}</code></td></tr>`)):'<p class="note">This owner requests no earlier fact.</p>');$('exact-row').textContent=JSON.stringify(selected.exact,null,2);}
let consumers={};edges().forEach(e=>(consumers[e.premise]??=new Set()).add(e.conclusion));let shared=Object.entries(consumers).filter(([_,v])=>v.size>1);$('sharing').innerHTML=shared.length?table(['One earlier fact','Consumers'],shared.map(([i,js])=>`<tr><td><button data-share="${i}">Proof line ${Number(i)+1}</button><div class="formula-scroll">${formula(readers()[Number(i)])}</div></td><td>${[...js].sort((a,b)=>a-b).map(j=>j+1).join(', ')}</td></tr>`)):`<p class="note">${readers().length?'This certificate contains no fact referenced by multiple later proof lines.':'No admitted proof DAG is available.'}</p>`;document.querySelectorAll('[data-share]').forEach(b=>b.onclick=()=>chooseLine(Number(b.dataset.share)));let fs=new Map();readers().forEach(x=>{if(x.formula_id!==null&&x.formula_id!==undefined)fs.set(x.formula_id,x);});$('fid-legend').innerHTML=fs.size?table(['Literal formula ID','Displayed formula'],[...fs].sort((a,b)=>a[0]-b[0]).map(([id,x])=>`<tr><td><i class="dot" style="background:${fidColor(String(id))}"></i><code>${esc(id)}</code></td><td><div class="formula-scroll">${formula(x)}</div></td></tr>`)):'<p class="note">No selected proof formulas for this outcome.</p>';renderLiteral();typeset($('markings'));}
function flatten(value,prefix='',out=[]){if(value!==null&&typeof value==='object'&&!Array.isArray(value)){for(let [key,v] of Object.entries(value))flatten(v,prefix?prefix+'.'+key:key,out);}else out.push([prefix,value]);return out;}
function renderCosts(){let r=current();$('selected-costs').innerHTML=table(['Recorded field','Value'],flatten(r.costs??{}).map(([key,v])=>`<tr><td>${esc(key.replaceAll('_',' '))}</td><td>${esc(typeof v==='number'?num(v):text(v))}</td></tr>`));$('exact-costs').textContent=JSON.stringify({costs:r.costs,resources:r.resources},null,2);}
function renderOther(){let q=data.qualification;$('qualification').innerHTML='<p>'+badge(q?.status??'Unavailable')+'</p><pre>'+esc(JSON.stringify(q,null,2))+'</pre>';$('pilot-costs').innerHTML='<pre>'+esc(JSON.stringify(data.costs,null,2))+'</pre>';$('limitations').innerHTML='<ul>'+(data.limitations??[]).map(x=>'<li>'+esc(text(x))+'</li>').join('')+'</ul>';$('provenance').textContent=JSON.stringify({input_summary_pin:data.input_summary_pin,coverage:data.coverage,saved_data_audit:data.saved_data_audit,provenance:data.provenance,projection:data.reader_projection},null,2);$('qualification-links').innerHTML=data.records.map((r,i)=>[r,i]).filter(([r])=>r.kind==='QUALIFICATION'&&r.method==='point'&&r.proof_reader?.length).map(([r,i])=>`<button data-qual="${i}">Point qualification: ${esc(r.case_id)}</button>`).join('');document.querySelectorAll('[data-qual]').forEach(b=>b.onclick=()=>selectExact(Number(b.dataset.qual)));}
async function load(){let response=await fetch('shared-search-results-v1.json.gz',{cache:'no-store'});if(!response.ok)throw Error('Reader HTTP '+response.status);let bytes=new Uint8Array(await response.arrayBuffer()),body=bytes[0]===31&&bytes[1]===139?await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text():new TextDecoder().decode(bytes);data=JSON.parse(body);$('loading').remove();$('group').onchange=()=>populateCases();$('case').onchange=()=>populateMethods();$('method').onchange=()=>{recordIndex=Number($('method').value);selectRecord();};$('all-links').onchange=renderMarks;$('short-labels').onchange=()=>{renderTheory();renderProof();renderMarks();renderLiteral();};renderAssessment();renderOther();let index=data.records.findIndex(r=>r.kind==='BENCHMARK'&&r.method==='point'&&r.proof_reader?.length);if(index<0)index=data.records.findIndex(r=>r.kind==='BENCHMARK'&&r.method==='sat'&&r.proof_reader?.length);if(index<0)index=data.records.findIndex(r=>r.kind==='BENCHMARK'&&r.proof_reader?.length);if(index<0)index=0;selectExact(index);typeset();}load().catch(e=>{let n=$('loading');if(n){n.className='error';n.textContent='Unable to load admitted evidence: '+e.message;}console.error(e);});
'''


def page(title, body, script=''):
    config = r'<script>window.MathJax={tex:{inlineMath:[["\\(","\\)"]],displayMath:[["\\[","\\]"]]},options:{skipHtmlTags:["script","noscript","style","textarea","pre","code"]}};</script>'
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>'+html.escape(title)+'</title><style>'+CSS+'</style>'+config+
        '<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script></head><body>'+body+
        ('<script>'+script+'</script>' if script else '')+'</body></html>')


def build(root):
    root = root.resolve()
    summary_path = root/'data/report-summary-v1.json'
    summary = json.loads(summary_path.read_bytes())
    if summary.get('schema') != 'Shared-fact-search-saved-summary-v1' or summary.get('status') != 'VERIFIED_PILOT_WITH_EXPLICIT_UNKNOWN':
        raise ValueError('Admitted shared-fact saved summary required')
    audit = summary.get('saved_data_audit')
    if is_ref(audit):
        audit = json.loads(path_for(root, audit).read_bytes())
    if not isinstance(audit, dict) or audit.get('status') != 'PASS_SAVED_DATA_AUDIT':
        raise ValueError('Saved-data audit admission required')
    out, folder = root/'report', root/'report/shared-search-downloads-v1'
    folder.mkdir(parents=True, exist_ok=True)
    copied, downloads = {}, []
    for ref in references(summary):
        if not str(ref['path']).startswith(('data/', 'review/', 'plan/', 'reference/', 'source/')):
            continue
        key = (ref['bytes'], ref['sha256'])
        if key in copied:
            continue
        source = path_for(root, ref)
        wrapped = source.suffix not in ('.json', '.gz')
        name = ref['sha256'][:16]+'-'+source.name+('.gz' if wrapped else '')
        target = folder/name
        if target.exists():
            raise ValueError('Preserve existing download projection: '+name)
        with target.open('xb') as destination, source.open('rb') as incoming:
            if wrapped:
                with gzip.GzipFile(filename='', fileobj=destination, mode='wb', mtime=0, compresslevel=6) as stream:
                    shutil.copyfileobj(incoming, stream, 1048576)
            else:
                shutil.copyfileobj(incoming, destination, 1048576)
        copied[key] = dict(url='shared-search-downloads-v1/'+name, pointer=ref.get('pointer'))
        downloads.append(dict(original=ref['path'], original_bytes=ref['bytes'],
            original_sha256=ref['sha256'], download=copied[key]['url'], wrapped_gzip=wrapped, **pin(target)))
    records = []
    for saved in summary['records']:
        record = copy.deepcopy(saved)
        if record.get('proof_reader') and not (record['status'] in ('SAT', 'DERIVABLE')):
            raise ValueError('A nonpositive attempt must not inherit another method proof')
        record['mark_display'] = mark_display(record)
        record['downloads'] = {key: dict(copied[(value['bytes'], value['sha256'])], pointer=value.get('pointer'))
            for key, value in record.items() if is_ref(value)
            and (value['bytes'], value['sha256']) in copied}
        records.append(record)
    if not records:
        raise ValueError('No actual saved attempt records')
    view = dict(schema='Passive-shared-fact-search-reader-v1', status=summary['status'],
        input_summary_pin=pin(summary_path), records=records, qualification=summary.get('qualification'),
        costs=summary.get('costs'), coverage=summary.get('coverage'), provenance=summary.get('provenance'),
        limitations=summary.get('limitations', []), saved_data_audit=audit, downloads=downloads,
        reader_projection=dict(scope='Only admitted summary records, native reader text and actual selected row ports are projected. Full traces remain separate byte-bound downloads. No science module import, proof transformation, model generation, encoder, kernel, search or certificate replay.',
            finder_attribution='Each method retains its own outcome and proof only. Conventional control proofs never fill a point-engine UNKNOWN.',
            download_rule='Every direct download ends in .json or .gz. Other original file types are standalone gzip wrappers; full physical archive preserves original paths and bytes.'))
    exclusive(out/RESULTS, gzip.compress(wire(view), mtime=0, compresslevel=6))
    exclusive(out/'shared-search-v1.html', page('Search with shared facts · GCTS research', BODY, SCRIPT).encode())
    rows = ''.join('<tr><td><code>'+html.escape(d['original'])+'</code></td><td><a download href="'+
        html.escape(d['download'], quote=True)+'">'+('Gzip download' if d['wrapped_gzip'] else 'Exact download')+'</a></td><td>'+str(d['original_bytes'])+'</td><td><code>'+d['original_sha256']+'</code></td></tr>' for d in downloads)
    evidence = '<header><div class="eyebrow">Saved evidence</div><h1>Shared-fact search pilot</h1><nav><a href="shared-search-v1.html#reader">Proof reader</a></nav></header><main><section><h2>Exact attempts, checks and certificates</h2><p>Benchmark point UNKNOWNs remain unresolved. Native-admitted conventional proofs and tiny point qualification proofs have separate identities. The reader is a passive projection; complete raw traces and preparation evidence are linked here and physically preserved in the full archive.</p><!-- SHARED_SEARCH_ARCHIVE_LINK --><p><a download href="shared-search-results-v1.json.gz">Reader projection</a></p><div class="scroll"><table><thead><tr><th>Original saved path</th><th>Download</th><th>Original bytes</th><th>Original SHA256</th></tr></thead><tbody>'+rows+'</tbody></table></div></section><section><h2>Projection scope</h2><pre>'+html.escape(json.dumps(dict(summary_pin=view['input_summary_pin'],status=view['status'],projection=view['reader_projection']),indent=2))+'</pre></section></main>'
    exclusive(out/'shared-search-evidence-v1.html', page('Evidence · shared-fact search', evidence).encode())
    return dict(status='PASSIVE_REPORT_WRITTEN', records=len(records), downloads=len(downloads),
        outputs={name: pin(out/name) for name in ('shared-search-v1.html', 'shared-search-evidence-v1.html', RESULTS)})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    print(json.dumps(build(args.root), sort_keys=True))


if __name__ == '__main__':
    main()
