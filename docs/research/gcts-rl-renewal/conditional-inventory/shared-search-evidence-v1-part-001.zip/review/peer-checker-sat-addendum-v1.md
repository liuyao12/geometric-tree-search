# Source review addendum: generic provenance gate

The previously reported generic ABI mismatch is closed in `reference/shared_fact_checker_v1.py`: 34073 bytes, SHA256 `d550bbd3b4a773cef2a9c54cd7850c0b6587fd46263c6e43365b62e44c44a48e`.

Read-only byte comparison confirms that removing the single added `PROVENANCE_DICTIONARY` type gate reproduces the exact previously reviewed Source SHA256 `77948ed9e4a6e99bafde3d80944406c9d6cb50ae984fa8c57c6009904641212d`. The gate now rejects non-dictionary provenance for generic model verification and decoding as well as the ground basis path. No other Source changed in this comparison.

This closes the P2 item in `review/peer-checker-sat-v1.md`. The independent CNF certificate/model association and native proof admission boundaries in that review still apply. This addendum records Source inspection and AST parsing only; no module import, model construction, logical checking, certificate replay or search ran.
