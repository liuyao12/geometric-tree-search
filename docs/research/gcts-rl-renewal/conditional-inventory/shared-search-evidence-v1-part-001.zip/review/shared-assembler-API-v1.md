# Passive shared-fact assembler handoff

Source entry point: `review/assemble_shared_results_v1.py::main()`. Stdlib only; AST parsed, never imported or executed by its author. This file and note are outside the scientific freeze patterns. All original scientific files/data remain untouched.

Exclusive outputs after Root review/execution:

- `review/saved-data-audit-v1.json`, schema `Shared-fact-search-saved-audit-v1`, status `PASS_SAVED_DATA_AUDIT`.
- `data/report-summary-v1.json`, schema `Shared-fact-search-saved-summary-v1`, status `VERIFIED_PILOT_WITH_EXPLICIT_UNKNOWN`.

All nine original phases must have complete matching started/invocation/observer process/protocol/PID/frozen receipts, actual native exit zero and no guard/postcheck error. Missing or contradictory evidence fails before outputs; no partial result is silently admitted. Current exact frozen files/runtime/master and every referenced plain/gzip artifact are byte/hash-checked. Full states are streamed for hashes and event census without replaying graph semantics.

The summary has `records` (45 flat method rows: seven native qualification and eight benchmark declarations, three methods each), `cases` (15 grouped cases), `qualification` (seven native cases, seven unit fixtures, 20 declared mutations), `coverage`, `costs`, `provenance`, `limitations`, and `saved_data_audit`.

Flat record ABI:

```text
id, case_id, kind (QUALIFICATION|BENCHMARK), case, method (point|forward|sat),
status (actual saved method status), reason, raw_ref, prepared_ref, model_ref,
decoded_ref, proof_ref, proof_reader, theory_reader, proof_dag, slot_rows,
reference_mapping, selected, selected_rows, costs, resources, admission,
model_metadata, original_statement_sha256
```

`proof_reader` rows have one-based `line` and `dependencies`, literal `formula`, `formula_latex`, deterministic `english`, native `rule`, actual zero-based `slot` or null, and positive `formula_id`. `proof_dag` and `reference_mapping` preserve the saved native zero-based indices. Point/SAT positives retain separately native-admitted actual selected rows/slots; forward's native derivation has no invented point selection or slots. UNKNOWN records contain empty proof/selection arrays and the actual prefix/resource reason. Qualification GCTS MP proofs remain independently selectable even when every benchmark point attempt is UNKNOWN.

`model_metadata` has `scope`, `capacity`, `slots`, `required_points`, actual `roots`, `universe_count`, `formula_count`, literal `formula_colors`, `active_colors`, `padding_formula_color`, exact `seed`, and explicit semantic/proof-marking scopes. This is an opaque slot/remote-mark model, not a planar Wang grid. `theory_reader` has exact saved hypothesis/goal ASTs, LaTeX and literal propositional English. Only pred0/imp is supported in this lane.

`costs` has `common_logical_preparation`, nullable `point_model_preparation`, `private`, `measured_method_pipeline_seconds`, `accounted_seconds_including_reused_preparation`, and a cost-scope string. The point pipeline includes observation writing and assurance; positive decoder/native pipelines are added once. Combined basis/model assurance remains explicitly joint and is not charged as common logical cost to forward. All clocks are observed once/reused, fixed method order, one attempt; work counters have different units.

`resources` preserves point `stats`, actual trace status/counts/gaps and streamed observation scope; forward counts/work; SAT nodes/work/encoding and certificate counts; all methods include declared limits and actual internal seconds. `admission.status` is separate from actual search `status`: positives need native checking, completed point/CNF negatives need their saved independent full receipts, forward negatives are the bounded-control exhaustion claim, and all resource refusals remain UNKNOWN. A full emitted UNKNOWN callback stream is still only prefix assurance for an unfinished search.

No theorem/graph/CNF checker, encoder, decoder, solver, model builder or tiny oracle executes in this assembler. The independently executed saved receipts provide their scoped semantics; hashing/joins do not authenticate logical truth independently of those gates. Native proofs found by SAT or forward are never attributed to GCTS. No PA/Hilbert, RL, learned marking, universal Wang or broad ATP advantage claim follows.
