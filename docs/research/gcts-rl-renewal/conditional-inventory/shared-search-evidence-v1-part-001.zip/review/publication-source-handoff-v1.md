# Shared-search publication Source handoff

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FUTURE_EVIDENCE**. All five hardened publication Sources from `gcts-proof-dag-reuse-20261103-v1/publication/` were read in full before adaptation. The new files were inspected and AST-parsed as text only. No new scientific Source, publication helper, report builder, package builder, Git operation or network operation has been imported or executed by this author. No research outcome is assumed.

The five new Sources are:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `publication/evidence_common_v1.py` | 9111 | `7135fe9d7901db67fcd4f0b6f85567de8ee1f9fd8ed4a46a0c73098f6af13961` |
| `publication/package_publish_v1.py` | 15254 | `bf762114315dc6fb486dd2378c11d85e44682c268e6d9ee95f194a0baf83cc6c` |
| `publication/observe_github_v1.py` | 4728 | `1d49848b024f223270131c9662f5967c722ce04c00ddbf5a95a0fd600a39fb9e` |
| `publication/verify_live_v1.py` | 5085 | `fea78427e2929e93df1ddd05154f7806a5e763ca829e12757bf8502b0ee6e84e` |
| `publication/complete_publication_v1.py` | 10423 | `cfca5383d768fa201f01e8136bf8e307379e328ac19061c49776a66ec08eab72` |

Publication stays in the existing approved `docs/research/gcts-rl-renewal/conditional-inventory/` prefix. The new main/evidence pages are `shared-search-v1.html` and `shared-search-evidence-v1.html`, with reader anchor `#reader`, result `shared-search-results-v1.json.gz` and `shared-search-downloads-v1/`. Every report HTML/JSON/gzip file is included recursively. The sole existing-file modification is a backlink in `proof-reuse-v1.html`. New Git paths are checked with `ls-tree` before insertion; the isolated bare repository and dedicated index preserve unrelated paths. The package tool creates one sole-parent commit and never pushes or stages the primary checkout. Root supplies a freshly fetched base; an official remote-main GET immediately before local commit preparation must still match it. Any later push must be a normal fast-forward push, with no force option.

The common verifier matches the new driver ABI rather than the previous milestone: protocol schema `Shared-fact-search-protocol-v1`, status `FROZEN_BEFORE_SCIENTIFIC_IMPORTS`, exact current declared Source/plan/peer file list, runtime executable bytes/flags, current primary master and frozen local master. It pins the fully reviewed driver `ae7e94a02c0cc04de4d484ad7c7451ed8a42e99ecd7b777644ea7735aad6179b` and its final driver peer note `ff5047c007e80513ad0330a55d11e116d9430c0703107ed72e7682d7e3fa16f3`. A future driver/peer revision requires a reviewed publication-constant update; it must not bypass those bindings.

All nine original phases are required: qualification and the eight declared benchmark case/bound IDs. Each phase joins its original started, terminal observer, worker invocation, log and result. Names, native integer PIDs, protocol digest, successful frozen postchecks, native exit zero, no guard/postcheck error and complete worker status must agree. Qualification must have `VERIFIED_QUALIFICATION`; benchmark process results must have `COMPLETED_ADMITTED_ATTEMPTS`, which permits explicit internal search/assurance UNKNOWNs. Guarded or unfinished processes cannot be promoted by a retained child result. No solver, graph checker or native checker is imported by publication.

Packaging requires these future Root-verified products:

| Path | Required schema/status |
| --- | --- |
| `data/report-summary-v1.json` | `Shared-fact-search-saved-summary-v1` / `VERIFIED_PILOT_WITH_EXPLICIT_UNKNOWN` |
| `review/saved-data-audit-v1.json` | `Shared-fact-search-saved-audit-v1` / `PASS_SAVED_DATA_AUDIT` |
| `review/report-build-v1.json` | `PASS_REPORT_BUILD` |
| `review/local-ui-qualification-v1.json` | `PASS_LOCAL_UI`, zero native-integer math errors, no body overflow or console errors, exact final main-page Source pin |

`review/root-source-admission-v1.json` is retained with its actual historical `ROOT_SOURCE_READ_AND_AST_ONLY_PENDING_FINAL_PEER_CLOSURE` status and explicit Source-only scope. It is not relabeled as runtime PASS or used as a substitute for final peer/protocol/saved-data admission. `report/build_shared_report_v1.py` receives a separate exact manifest pin at the archive cut. The complete saved data, report builder, peer files and every other original archive member are frozen by per-file byte count/SHA256 and rechecked after archive creation and at completion.

Full approved archives are physical multipart ZIPs named `shared-search-evidence-v1-part-NNN.zip`, each at most 44 MiB and strictly below 50 MiB. `shared-search-evidence-manifest-v1.json` binds all original paths and completed volumes. Every original task file at the archive cut is physically stored once; there is no alias deduplication or reconstruction substitute. All scientific/report/publication Python Sources, declarations, raw traces, proofs, controls, UNKNOWNs, logs, reviews and paths remain. Only generated `package/` outputs and generated publication planning/deployment receipts are excluded to prevent recursion; publication Python Sources are included. Every ZIP CRC, member set and original member hash is checked. Archive links use `<!-- SHARED_SEARCH_ARCHIVE_LINK -->` in both reader pages, and volume count/page pins must remain stable after local UI qualification.

After Root's Source review and actual research/report admission, the invocation sequence is:

1. Use the protocol's pinned Python executable with `-I -S -B` for `publication/package_publish_v1.py --prepare-links`.
2. Validate final local report UI and persist the exact future readiness receipts. Do not rebuild the report after pinning UI bytes.
3. Invoke `publication/observe_github_v1.py base`, fetch the corresponding remote main into the isolated bare repository, review that SHA, then invoke `publication/package_publish_v1.py BASE`. This retains the physical package and isolated prepared commit; it does not push.
4. Root reviews `publication/prepared-v1.json`, full name-status diff and archive verification, then performs the authorized normal push. Use observer modes `commit` and `pages` or `all` until the exact commit is remote main and its Pages run succeeds.
5. Invoke `publication/verify_live_v1.py --workers 2` for every prepared asset body and every live ZIP original/CRC. It uses normal certificate verification and HTTP/1.1. Different prior failure receipts remain under immutable history names; `--retry-failed` reuses only byte-rechecked matches from the same commit.
6. Verify the deployed UI at `shared-search-v1.html#reader`; the live receipt needs exact commit/URL, zero math errors, no body overflow and no console errors, with status `PASS_LIVE_UI` or the established `PASS`.
7. Invoke `publication/complete_publication_v1.py` only after official remote tree/sole-parent/main, successful Pages, all local/live bytes and all UI gates pass. It preflights every primary mirror collision and copies only identical/new bytes into `research-runs/gcts-proof-dag-search-20261103-v1`, never staging or pushing the primary checkout. The publication receipt keeps the research program ACTIVE.

These tools claim only publication custody. They preserve the saved pilot's actual statuses and limitations; they do not infer universal palette search, unrestricted logical completeness, RL or ATP superiority from a report or ZIP.
