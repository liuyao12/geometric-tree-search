# Independent Source review: shared-fact and SAT checking

No logical soundness blocker was found for the declared ground, finite, unit-capacity lane, subject to the separate primitive/native, model, trace and artifact-binding gates below. One small generic input-contract mismatch remains in the reviewed shared-fact checker. This is a read-only Source assessment, not executed qualification or scientific admission.

No module was imported, model constructed, search run, native checker called, certificate replayed or existing Source edited for this review. Full bodies were read. The revised SAT string/key resource accounting and nonempty model-version gate were reread after Root's pre-execution changes.

| Reviewed file | Bytes | SHA256 |
| --- | ---: | --- |
| `reference/shared_fact_checker_v1.py` | 34004 | `77948ed9e4a6e99bafde3d80944406c9d6cb50ae984fa8c57c6009904641212d` |
| `reference/sat_certificate_checker_v1.py` | 10413 | `06ff78c1b12a83789d84eebef08456689ec14f050f6253d1fcb0b30c9aa91684` |
| `source/sat_encoding_v1.py` | 15462 | `3ea009d2b4a975a6f6f1b11c4ceae4bfa9d249f88ea38965a8361ef0e7d2efea` |

The master reference was previously read in full during this task chain and its current bytes rechecked: `docs/basic-tiling-algorithm.md`, 21657 bytes, SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`. The unchanged copied engine's seed initialization was also read to settle zero-valued seed support: such an entry alone does not activate an extra root. This review changes nothing in earlier roots or their publication.

## Actionable observations

**P2: generic provenance type differs from the production adapter.** In `shared_fact_checker_v1.catalogue`, the top-level field set requires `provenance` but never requires its value to be a dictionary. `shared_fact_model_v1.checked_catalogue` does require a dictionary. Consequently the generic `verify_model`/`decode` path can accept a coherently reconstructed catalogue with, for example, an array-valued provenance field, while production preparation rejects it. Ground `verify_basis`/`verify` already compare the exact compiler provenance dictionary, so this does not invalidate current ground-profile admissions or native logical soundness. Add a dictionary type gate at catalogue entry to align the generic ABI before freezing; qualify the malformed-provenance case. Root and the checker author were notified. No edit was made here.

**Admission requirement: bind the entire encoded artifact to its point model.** The independent CNF checker correctly states its narrower claim. Its `cnf_sha256` binds only `nvars` and `clauses`; selector/CID metadata and model/universe bindings are not in that digest. A verified CNF tree alone therefore cannot certify which point inventory it describes. Retain and bind the full encoded artifact's bytes/hash, its `binding.input_model_sha256`, normalized `binding.model_sha256` and `binding.universe_sha256` against the independently admitted model/universe. Bind the exact encoded packet supplied to both solve and certificate-check calls. On SAT, independently decode/check the selected point certificate and then native B. On UNSAT, require encoder-equivalence admission plus the exact bound input; do not promote a CNF-only receipt to native nonprovability. This is a documented trust boundary, not a newly found false-CNF-verification bug.

**Corrected before this receipt:** the earlier encoder checked only that `model.version` was a string, while the engine requires it nonempty. Latest reviewed Source now includes the nonempty gate. Root's latest SAT encoder/checker scans also charge string lengths and dictionary keys; the initial uncharged-string drafts are not the final versions pinned above.

## Shared-fact checker assessment

The verifier imports only standard-library modules. It neither imports nor executes the production adapter, engine, native kernel or control. Its reconstruction uses an independent definition list and candidate descriptors, rather than trusting supplied point rows or decoder maps.

Canonical ASCII JSON plus LF comparisons distinguish integer indices from Boolean/float lookalikes. Formula IDs are reconstructed from the complete sorted literal formula table. Ground admission independently reconstructs every assumption/goal subformula, named assumption ZERO and structural MP, preserving the original declaration/profile/provenance. Generic admission explicitly does not claim completeness of an arbitrary FOL ZERO-generation profile. Primitive payload shape and AST/signature checking do not replace native ZERO truth checking.

The context is checked closed. Enabled GEN definitions are reconstructed from literal universal formulas and their registered bodies; the declared pool contains the formula variables and binders. The exact scope binds the catalogue, slot bound, padding and port/CID versions. Prepared limits, whole model, complete explicit universe, primitive definitions and full enumeration census are compared canonically. No candidate shortlist or supplied completeness flag is trusted. The reconstructed candidate loops enforce strictly earlier references; the self-conflict census correctly accounts for MP's impossible same-slot antecedent/implication assignment in finite literal syntax.

The decoder independently reconstructs the full model before interpreting selected CIDs. Reconstructed unit, owner-only support plus exactly one owner at every required slot suffices for its capacity check; no hidden positive support can be omitted. It checks global marks beginning with target seed pins, so a consumer cannot read PAD's assigned zero. It deletes noncontiguous PAD slots, remaps MP/GEN references, retains original slot IDs and the unchanged final goal, and returns an explicitly unverified native certificate. Its success is not native proof validity or full-frontier trace conformance. Those gates remain separate.

## Point-model/CNF equivalence argument

The encoder refuses unsupported weighted capacities, nonunit candidate support and positive support outside the finite explicit roots. It preserves literal string zero and missing-mark semantics. Every candidate has one Boolean selector. For an unfilled root, the incidence selector clause supplies at least one owner and the sequential AMO supplies at most one; a seed-filled root instead blocks every touching selector. A multi-root candidate has one shared selector, preserving selected-once inventory semantics.

At a marking point, one Boolean variable represents each literal assigned value, with AMO but no artificial at-least-one requirement. Candidate implications and seed unit clauses require exactly the values that selected rows/seed assign. Thus incompatible assigned values cannot coexist, while an unassigned point remains unconstrained. The sequential AMO clauses implement the standard prefix invariant: any selected member sets the later prefix flags and excludes subsequent members; any group with at most one selected member has an auxiliary extension.

Therefore a satisfying CNF assignment projects to an exact selected-CID solution of this scoped point problem. Conversely, a point solution extends to selector and literal-value variables, and each AMO group admits prefix auxiliaries. This is equivalence after existential projection of auxiliary variables. It does not cover dynamically activated optional support, fractional capacity or native rule truth. The code follows this construction; tiny exhaustive point/CNF qualification is still required before any runtime claim.

## CNF certificate/result assessment

The independent checker imports no encoder or solver. It recomputes the exact CNF digest and checks literal ranges with strict integer types. Unit steps name a clause with exactly the required remaining literal; duplicate literal occurrences do not falsify a logical unit. Conflict leaves require a genuinely false clause under the replayed assignment. An UNSAT branch must include both distinct Boolean children and verified UNSAT subtrees. A truncated or UNKNOWN child cannot become a completed UNSAT split.

SAT leaves satisfy every clause, and final full assignments must match the replayed SAT path, satisfy the exact CNF, carry the matching assignment digest and produce the selected CIDs from the supplied selector map. A post-search resource downgrade remains UNKNOWN and is explicitly bound to its saved tree outcome. The final cooperative charge follows hashing before VERIFIED. Wall gates are cooperative, not instruction-level preemption; caller process guards and cost/custody receipts remain necessary.

The simple reference DPLL is not a modern SAT performance benchmark. Its proof certificate validates the exact CNF, not the GCTS scheduler or a first-order calculus. No new proof, empirical comparison, complete-theory absence or search advantage follows from this Source review.
