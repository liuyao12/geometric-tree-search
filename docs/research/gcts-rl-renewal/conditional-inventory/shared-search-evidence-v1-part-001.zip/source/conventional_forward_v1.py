"""Conventional bounded forward shared-fact control; no facts are free.

Input is an independently admitted finite context-free ZERO/MP/GEN catalogue.
This control is not the GCTS point scheduler and does not enumerate padded slot
assignments. Each first introduction of a literal formula costs one native line.
Exact available-FID sets are memoized, retaining one reconstructible derivation.
Native logical validity requires the caller's separate unchanged B check.

Conditional bounded-existence quotient: in any catalogue proof, redirect each
use of a repeated formula to its earliest identical line and delete duplicates.
References remain earlier and every rule's premises remain the same literal
formulas; closed-Gamma GEN side conditions are unchanged. The resulting proof
introduces distinct facts, costs no more lines, and is a path explored here.
Conversely every returned path is a catalogue derivation with at most the bound.
With PAD permitted, either path embeds in the slot model by putting its goal at
the last slot. This is not a bijection of point solutions or proof counts.
"""
from collections import deque
import copy
import hashlib
import json
import math
import time

VERSION='Shared-fact-conventional-forward-v1'
DEFAULT_LIMITS=dict(max_items=2000000,max_formulas=2000,max_producers=20000,
    max_states=200000,max_work=20000000,wall_seconds=2.0)


class Invalid(Exception):pass
class Bound(Exception):pass


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def digest(value):return hashlib.sha256(wire(value)).hexdigest()


def need(condition,reason):
    if not condition:raise Invalid(reason)


class Meter:
    def __init__(self,limits):
        self.limits=dict(DEFAULT_LIMITS)
        if limits is not None:
            need(type(limits) is dict and set(limits)<=set(self.limits),'LIMIT_FIELDS')
            self.limits.update(limits)
        for name,value in self.limits.items():
            if name=='wall_seconds':need(type(value) in (int,float) and math.isfinite(value) and value>0,'WALL_LIMIT')
            else:need(type(value) is int and value>0,'INTEGER_LIMIT:'+name)
        self.start=time.perf_counter();self.work=0;self.items=0

    def tick(self,n=1):
        self.work+=n
        if self.work>self.limits['max_work']:raise Bound('WORK_BOUND')
        if time.perf_counter()-self.start>self.limits['wall_seconds']:raise Bound('WALL_BOUND')

    def scan(self,value):
        stack=[value]
        while stack:
            self.tick();self.items+=1
            if self.items>self.limits['max_items']:raise Bound('ITEM_BOUND')
            item=stack.pop()
            if type(item) is dict:
                need(all(type(k) is str for k in item),'JSON_OBJECT_KEYS');stack.extend(item.keys());stack.extend(item.values())
            elif type(item) is list:stack.extend(item)
            elif type(item) is str:
                self.tick(len(item));self.items+=len(item)
                if self.items>self.limits['max_items']:raise Bound('ITEM_BOUND')
            elif type(item) is float:need(math.isfinite(item),'JSON_FINITE_FLOAT')
            else:need(type(item) in (str,int,bool) or item is None,'NATIVE_JSON_VALUE')


def _catalogue(catalogue,meter):
    need(type(catalogue) is dict and catalogue.get('schema')=='Shared-fact-finite-catalogue-v1','CATALOGUE_SCHEMA')
    forms=catalogue['formulas']
    need(type(forms) is list and forms,'FORMULA_TABLE')
    if len(forms)>meter.limits['max_formulas']:raise Bound('FORMULA_BOUND')
    keys=[wire(form) for form in forms]
    need(len(set(keys))==len(keys),'DUPLICATE_FORMULA')
    fid_by_formula={key:i+1 for i,key in enumerate(keys)}
    statement=catalogue['statement'];goal=statement['goal']
    need(wire(goal) in fid_by_formula,'GOAL_OUTSIDE_UNIVERSE')
    goal_fid=fid_by_formula[wire(goal)]
    for field in ('zeros','mp','gen'):need(type(catalogue[field]) is list,'PRODUCER_LIST:'+field)
    if sum(len(catalogue[k]) for k in ('zeros','mp','gen'))>meter.limits['max_producers']:raise Bound('PRODUCER_BOUND')
    def fid(value):need(type(value) is int and 1<=value<=len(forms),'FORMULA_ID');return value
    producers=[];zero_ids=set();structural=set()
    for row in catalogue['zeros']:
        meter.tick();need(type(row) is dict and set(row)=={'id','native'},'ZERO_FIELDS')
        need(type(row['id']) is str and row['id'] and row['id'] not in zero_ids,'ZERO_ID');zero_ids.add(row['id'])
        native=row['native'];need(type(native) is dict and type(native.get('rule')) is str,'ZERO_NATIVE_LINE')
        need(native['rule'] not in ('mp','generalize'),'REFERENCED_RULE_IS_NOT_ZERO')
        key=wire(native['formula']);need(key in fid_by_formula,'ZERO_FORMULA_OUTSIDE_UNIVERSE')
        producers.append(dict(kind='ZERO',id=row['id'],output=fid_by_formula[key],premises=[],native=native))
    for row in catalogue['mp']:
        meter.tick();need(type(row) is dict and set(row)=={'antecedent','implication','output'},'MP_FIELDS')
        a,h,b=(fid(row[k]) for k in ('antecedent','implication','output'))
        need(wire(forms[h-1])==wire(['imp',forms[a-1],forms[b-1]]),'MP_LITERAL_INCIDENCE')
        key=('MP',a,h,b);need(key not in structural,'DUPLICATE_MP');structural.add(key)
        producers.append(dict(kind='MP',id=digest(row),output=b,premises=[a,h]))
    for row in catalogue['gen']:
        meter.tick();need(type(row) is dict and set(row)=={'source','output','variable'},'GEN_FIELDS')
        a,b=fid(row['source']),fid(row['output']);v=row['variable']
        need(type(v) is str and v,'GEN_VARIABLE')
        need(wire(forms[b-1])==wire(['all',v,forms[a-1]]),'GEN_LITERAL_INCIDENCE')
        key=('GEN',a,b,v);need(key not in structural,'DUPLICATE_GEN');structural.add(key)
        producers.append(dict(kind='GEN',id=digest(row),output=b,premises=[a],variable=v))
    # Order is independent of the goal, proof witnesses and inferred usefulness.
    producers.sort(key=lambda p:wire([p['kind'],p['output'],p['premises'],p.get('variable'),p['id']]))
    meter.tick()
    return forms,goal_fid,producers


def _proof(state,parents,producers,forms,meter):
    path=[]
    while state:
        meter.tick();previous,index=parents[state];path.append(index);state=previous
    proof=[];line_of={};steps=[]
    for index in reversed(path):
        meter.tick();p=producers[index];out=p['output']
        if p['kind']=='ZERO':line=copy.deepcopy(p['native'])
        elif p['kind']=='MP':line=dict(rule='mp',formula=copy.deepcopy(forms[out-1]),
            antecedent=line_of[p['premises'][0]],implication=line_of[p['premises'][1]])
        else:line=dict(rule='generalize',formula=copy.deepcopy(forms[out-1]),
            source=line_of[p['premises'][0]],variable=p['variable'])
        need(out not in line_of,'INTERNAL_DUPLICATE_INTRODUCTION')
        steps.append(dict(line=len(proof),formula_id=out,kind=p['kind'],producer_id=p['id'],
            premise_lines=[line_of[x] for x in p['premises']]))
        line_of[out]=len(proof);proof.append(line)
    return proof,steps


def search(catalogue,max_lines,limits=None):
    """Return DERIVABLE / NOT_DERIVABLE_WITHIN_BOUND / UNKNOWN / REJECTED_INPUT.

    ZERO native validity and complete catalogue admission are external gates.
    No caller proof, preloaded fact set or target derivation parameter exists.
    """
    meter=None;counts=dict(states=0,states_expanded=0,producer_tests=0,enabled=0,memo_hits=0)
    binding={}
    try:
        meter=Meter(limits);need(type(max_lines) is int and max_lines>=0,'LINE_BOUND')
        meter.scan(catalogue);forms,goal,producers=_catalogue(catalogue,meter)
        if 'slots' in catalogue['profile']:
            slots=catalogue['profile']['slots']
            need(type(slots) is int and slots>=0 and max_lines==slots,'DECLARED_SLOT_LINE_BOUND_MISMATCH')
        binding=dict(catalogue_sha256=digest(catalogue),statement_sha256=digest(catalogue['statement']),
            max_lines=max_lines,goal_fid=goal,formula_count=len(forms),producer_count=len(producers))
        meter.tick();empty=();parents={empty:None};queue=deque([empty]);counts['states']=1
        while queue:
            meter.tick();state=queue.popleft();counts['states_expanded']+=1
            if len(state)>=max_lines:continue
            available=set(state)
            for index,p in enumerate(producers):
                meter.tick();counts['producer_tests']+=1
                if p['output'] in available or not all(x in available for x in p['premises']):continue
                counts['enabled']+=1;child=tuple(sorted((*state,p['output'])))
                if child in parents:counts['memo_hits']+=1;continue
                if len(parents)>=meter.limits['max_states']:raise Bound('STATE_BOUND')
                parents[child]=(state,index);counts['states']=len(parents)
                if p['output']==goal:
                    proof,steps=_proof(child,parents,producers,forms,meter)
                    proof_sha=digest(proof);meter.tick()
                    return dict(schema='Shared-fact-forward-result-v1',version=VERSION,status='DERIVABLE',
                        binding=binding,proof=proof,proof_sha256=proof_sha,steps=steps,lines=len(proof),
                        counts=counts,work=meter.work,seconds=time.perf_counter()-meter.start,
                        native_validity='PENDING_INDEPENDENT_NATIVE_B',
                        scope='One bounded catalogue derivation found by forward fact-set search; no supplied proof and no free facts.')
                queue.append(child)
        meter.tick()
        return dict(schema='Shared-fact-forward-result-v1',version=VERSION,status='NOT_DERIVABLE_WITHIN_BOUND',
            binding=binding,counts=counts,work=meter.work,seconds=time.perf_counter()-meter.start,
            scope='Exhausted all reachable distinct-fact sets within the line bound in the supplied finite catalogue; no unrestricted non-theorem claim.')
    except (Bound,MemoryError,RecursionError) as error:
        return dict(schema='Shared-fact-forward-result-v1',version=VERSION,status='UNKNOWN',reason=str(error) or type(error).__name__,
            binding=binding,counts=counts,work=meter.work if meter else 0,
            seconds=time.perf_counter()-meter.start if meter else 0)
    except (Invalid,KeyError,TypeError,ValueError,OverflowError) as error:
        return dict(schema='Shared-fact-forward-result-v1',version=VERSION,status='REJECTED_INPUT',
            reason=str(error) or type(error).__name__,binding=binding,counts=counts)
