"""Exact finite unit-capacity point-model CNF and optional reference DPLL.

One selector represents each distinct candidate. Root capacity is exactly one;
candidate assignments imply shared mark-value variables. Values at a marking
point are at-most-one, not exactly-one: missing remains unconstrained and the
literal string '0' remains assigned. All AMO groups use a linear sequential
encoding. No quadratic candidate-conflict matrix is constructed.

The bounded stdlib DPLL is a simple, fully declared reference control, not a
modern SAT-solver benchmark. Its optional search tree has checkable unit reasons
and conflict clauses. Independent certificate checking and native proof decoding
are separate; SAT alone is not native logical proof admission.
"""
import copy
import hashlib
import json
import math
import time

VERSION='Shared-fact-linear-point-CNF-v1'
ENCODE_LIMITS=dict(max_items=10000000,max_rows=100000,max_variables=1000000,
    max_clauses=3000000,max_literals=10000000,max_work=30000000,wall_seconds=30.0)
SOLVE_LIMITS=dict(max_items=15000000,max_variables=1000000,max_clauses=3000000,
    max_nodes=100000,max_depth=128,max_work=10000000,wall_seconds=2.0)


class Invalid(Exception):pass
class Bound(Exception):pass


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def digest(value):return hashlib.sha256(wire(value)).hexdigest()


def need(condition,reason):
    if not condition:raise Invalid(reason)


class Meter:
    def __init__(self,defaults,limits):
        self.limits=dict(defaults)
        if limits is not None:
            need(type(limits) is dict and set(limits)<=set(defaults),'LIMIT_FIELDS');self.limits.update(limits)
        for k,v in self.limits.items():
            if k=='wall_seconds':need(type(v) in (int,float) and math.isfinite(v) and v>0,'WALL_LIMIT')
            else:need(type(v) is int and v>0,'INTEGER_LIMIT:'+k)
        self.start=time.perf_counter();self.work=0;self.items=0

    def tick(self,n=1):
        self.work+=n
        if self.work>self.limits['max_work']:raise Bound('WORK_BOUND')
        if time.perf_counter()-self.start>self.limits['wall_seconds']:raise Bound('WALL_BOUND')

    def scan(self,value):
        stack=[value]
        while stack:
            self.tick();self.items+=1
            if self.items>self.limits['max_items']:raise Bound('ITEM_BOUND')
            x=stack.pop()
            if type(x) is dict:
                need(all(type(k) is str for k in x),'OBJECT_KEYS');stack.extend(x.keys());stack.extend(x.values())
            elif type(x) is list:stack.extend(x)
            elif type(x) is str:
                self.tick(len(x));self.items+=len(x)
                if self.items>self.limits['max_items']:raise Bound('ITEM_BOUND')
            elif type(x) is float:need(math.isfinite(x),'JSON_FINITE_FLOAT')
            else:need(type(x) in (str,int,bool) or x is None,'NATIVE_JSON')


def _pairs(rows,units=False):
    need(type(rows) is list,'POINT_ASSIGNMENT_LIST');seen=set();out=[]
    for row in rows:
        need(type(row) is list and len(row)==2,'POINT_ASSIGNMENT')
        p,v=row;need(type(p) is str and p not in seen,'POINT_KEY');seen.add(p)
        if units:need(type(v) is int and v in (0,1),'UNIT_CAPACITY_ONLY')
        else:need(type(v) is str,'LITERAL_MARK_STRING')
        out.append([p,v])
    return sorted(out,key=lambda r:r[0])


def _universe(rows,meter):
    need(type(rows) is list,'UNIVERSE_LIST')
    if len(rows)>meter.limits['max_rows']:raise Bound('ROW_BOUND')
    result=[];ids=set()
    for row in rows:
        meter.tick();need(type(row) is dict and set(row)=={'id','t','m'},'CANDIDATE_FIELDS')
        cid=row['id'];need(type(cid) is str and cid and cid not in ids,'CANDIDATE_ID');ids.add(cid)
        t=_pairs(row['t'],True);need(t and all(u==1 for p,u in t),'POSITIVE_UNIT_SUPPORT_REQUIRED')
        result.append(dict(id=cid,t=t,m=_pairs(row['m'])))
    return sorted(result,key=lambda r:r['id'])


def encode(model,universe=None,limits=None):
    """Compile the SAME finite explicit unit model, or refuse unsupported scope.

    All candidate positive points must be explicit roots. This excludes dynamic
    optional growth obligations and weighted/fractional capacities from this
    encoder; they are not silently changed into this finite exact-cover model.
    """
    meter=None
    try:
        meter=Meter(ENCODE_LIMITS,limits);meter.scan(model)
        if universe is not None:meter.scan(universe)
        need(type(model) is dict and set(model)=={'schema','version','capacity','roots','seed','inventory'},'MODEL_FIELDS')
        need(model['schema']=='Z-growing-point-model-v1' and type(model['version']) is str and model['version'],'MODEL_SCHEMA')
        need(type(model['capacity']) is int,'EXACT_INTEGER_CAPACITY')
        if model['capacity']!=1:raise Bound('UNSUPPORTED_WEIGHTED_CAPACITY')
        roots=model['roots'];need(type(roots) is list and all(type(p) is str for p in roots),'ROOTS')
        need(len(roots)==len(set(roots)),'DUPLICATE_ROOT');roots=sorted(roots);rootset=set(roots)
        seed=model['seed'];need(type(seed) is dict and set(seed)=={'t','m'},'SEED_FIELDS')
        st=_pairs(seed['t'],True);sm=_pairs(seed['m'])
        if any(p not in rootset and u>0 for p,u in st):raise Bound('SEED_SUPPORT_OUTSIDE_FINITE_ROOTS')
        inventory=model['inventory'];need(type(inventory) is dict and set(inventory)=={'kind','placements'},'INVENTORY_FIELDS')
        need(inventory['kind']=='EXPLICIT','EXPLICIT_INVENTORY_REQUIRED')
        rows=_universe(inventory['placements'],meter)
        if universe is not None:need(rows==_universe(universe,meter),'UNIVERSE_MODEL_MISMATCH')
        if any(p not in rootset for row in rows for p,u in row['t']):raise Bound('DYNAMIC_SUPPORT_OUTSIDE_FINITE_ROOTS')
        canonical=dict(model,roots=roots,seed=dict(t=st,m=sm),inventory=dict(kind='EXPLICIT',placements=rows))
        binding=dict(input_model_sha256=digest(model),model_sha256=digest(canonical),
            universe_sha256=digest(rows),scope='EXPLICIT_FINITE_UNIT_CAPACITY_ALL_SUPPORT_ROOTED',
            normalization='Sort roots, seed t/m, candidate t/m and CID order; all literal values retained.')
        variables=[];clauses=[];literals=0
        def new_variable(row):
            if len(variables)>=meter.limits['max_variables']:raise Bound('VARIABLE_BOUND')
            variables.append(row);return len(variables)
        def clause(values):
            nonlocal literals
            meter.tick();values=list(values)
            if len(clauses)>=meter.limits['max_clauses']:raise Bound('CLAUSE_BOUND')
            literals+=len(values)
            if literals>meter.limits['max_literals']:raise Bound('LITERAL_BOUND')
            clauses.append(values)
        def amo(xs,kind,point):
            # Sinz sequential AMO: at most n-1 auxiliaries and 3n-4 clauses.
            if len(xs)<2:return
            previous=new_variable(dict(kind='AMO_PREFIX',group=kind,point=point,index=0))
            clause([-xs[0],previous])
            for i in range(1,len(xs)-1):
                current=new_variable(dict(kind='AMO_PREFIX',group=kind,point=point,index=i))
                clause([-xs[i],current]);clause([-previous,current]);clause([-xs[i],-previous]);previous=current
            clause([-xs[-1],-previous])
        selectors={row['id']:new_variable(dict(kind='CANDIDATE',cid=row['id'])) for row in rows}
        incidence={p:[] for p in roots};values={}
        for row in rows:
            meter.tick();x=selectors[row['id']]
            for p,u in row['t']:incidence[p].append(x)
            for p,v in row['m']:values.setdefault(p,set()).add(v)
        for p,v in sm:values.setdefault(p,set()).add(v)
        mark_vars={(p,v):new_variable(dict(kind='MARK_VALUE',point=p,value=v))
            for p in sorted(values) for v in sorted(values[p])}
        seed_units=dict(st)
        for p in roots:
            meter.tick();xs=incidence[p]
            if seed_units.get(p,0)==1:
                for x in xs:clause([-x])
            else:clause(xs);amo(xs,'CAPACITY',p)
        for p in sorted(values):amo([mark_vars[(p,v)] for v in sorted(values[p])],'MARK_AGREEMENT',p)
        for row in rows:
            for p,v in row['m']:clause([-selectors[row['id']],mark_vars[(p,v)]])
        for p,v in sm:clause([mark_vars[(p,v)]])
        cnf_sha=digest(dict(nvars=len(variables),clauses=clauses));meter.tick()
        return dict(schema='Shared-fact-point-CNF-v1',version=VERSION,status='ENCODED',binding=binding,
            nvars=len(variables),clauses=clauses,variables=variables,
            selector_variables=[[cid,var] for cid,var in selectors.items()],cnf_sha256=cnf_sha,
            counts=dict(candidates=len(rows),roots=len(roots),mark_points=len(values),
                mark_values=len(mark_vars),variables=len(variables),clauses=len(clauses),literals=literals,
                auxiliary_variables=sum(v['kind']=='AMO_PREFIX' for v in variables)),
            work=meter.work,seconds=time.perf_counter()-meter.start,
            scope='Existential auxiliary-variable encoding preserves exactly the selected-CID solutions of the declared finite unit point model. Complete universe and native logical validity are separate admission gates.')
    except (Bound,MemoryError,RecursionError) as error:
        return dict(schema='Shared-fact-point-CNF-v1',version=VERSION,status='UNKNOWN',reason=str(error) or type(error).__name__,
            work=meter.work if meter else 0,seconds=time.perf_counter()-meter.start if meter else 0)
    except (Invalid,KeyError,TypeError,ValueError,OverflowError) as error:
        return dict(schema='Shared-fact-point-CNF-v1',version=VERSION,status='REJECTED_INPUT',reason=str(error) or type(error).__name__)


def _checked_cnf(encoded,meter):
    need(type(encoded) is dict and encoded.get('schema')=='Shared-fact-point-CNF-v1' and encoded.get('status')=='ENCODED','ENCODED_CNF_REQUIRED')
    n=encoded['nvars'];clauses=encoded['clauses']
    need(type(n) is int and n>=0 and type(clauses) is list,'CNF_SHAPE')
    if n>meter.limits['max_variables'] or len(clauses)>meter.limits['max_clauses']:raise Bound('CNF_RESOURCE_BOUND')
    for row in clauses:
        meter.tick();need(type(row) is list,'CLAUSE_LIST')
        for lit in row:need(type(lit) is int and 0<abs(lit)<=n,'LITERAL_RANGE')
    need(encoded['cnf_sha256']==digest(dict(nvars=n,clauses=clauses)),'CNF_DIGEST')
    selectors=encoded['selector_variables'];need(type(selectors) is list,'SELECTORS')
    seen_cid=set();seen_var=set()
    for row in selectors:
        need(type(row) is list and len(row)==2,'SELECTOR_ROW');cid,v=row
        need(type(cid) is str and cid not in seen_cid and type(v) is int and 1<=v<=n and v not in seen_var,'SELECTOR_IDENTITY')
        seen_cid.add(cid);seen_var.add(v)
    meter.tick();return n,clauses


def solve(encoded,limits=None):
    """Optional bounded reference DPLL; retain explicit unit/branch/conflict tree.

    UNSAT is certified only when both branches of every retained split exhaust.
    Any cutoff remains UNKNOWN. SAT needs a full satisfying assignment and the
    caller's independent certificate/selected-CID/native checks.
    """
    meter=None;nodes=0;cnf_sha=encoded.get('cnf_sha256') if type(encoded) is dict else None
    try:
        meter=Meter(SOLVE_LIMITS,limits);meter.scan(encoded);n,clauses=_checked_cnf(encoded,meter);cnf_sha=encoded['cnf_sha256']
        def clause_state(row,assignment):
            undecided=[]
            for literal in row:
                meter.tick();v=abs(literal)
                if v not in assignment:undecided.append(literal)
                elif assignment[v]==(1 if literal>0 else 0):return True,[]
            # Repeated literal occurrences do not change a logical unit clause.
            return False,list(dict.fromkeys(undecided))
        def visit(assignment,depth):
            nonlocal nodes
            tree=dict(units=[])
            try:
                meter.tick()
                if nodes>=meter.limits['max_nodes']:raise Bound('NODE_BOUND')
                nodes+=1
                if depth>meter.limits['max_depth']:raise Bound('DEPTH_BOUND')
                while True:
                    changed=False;all_satisfied=True;branch_variable=None
                    for index,row in enumerate(clauses):
                        satisfied,open_literals=clause_state(row,assignment)
                        if satisfied:continue
                        all_satisfied=False
                        if not open_literals:tree.update(outcome='UNSAT',conflict=index);return tree,None
                        if len(open_literals)==1:
                            literal=open_literals[0];assignment[abs(literal)]=int(literal>0)
                            tree['units'].append([literal,index]);changed=True;break
                        if branch_variable is None:branch_variable=min(abs(v) for v in open_literals)
                    if changed:continue
                    if all_satisfied:tree['outcome']='SAT';return tree,assignment
                    break
                tree.update(branch=branch_variable,children=[])
                for value in (0,1):
                    child_assignment=dict(assignment);child_assignment[branch_variable]=value
                    child,answer=visit(child_assignment,depth+1)
                    tree['children'].append(dict(value=value,tree=child))
                    if child['outcome']=='SAT':tree['outcome']='SAT';return tree,answer
                    if child['outcome']=='UNKNOWN':tree['outcome']='UNKNOWN';return tree,None
                tree['outcome']='UNSAT';return tree,None
            except Bound as error:
                tree.update(outcome='UNKNOWN',limit=str(error));return tree,None
        certificate,answer=visit({},0);status=certificate['outcome']
        result=dict(schema='Shared-fact-reference-DPLL-result-v1',version=VERSION,status=status,
            cnf_sha256=cnf_sha,certificate=certificate,nodes=nodes,work=meter.work,
            seconds=time.perf_counter()-meter.start,
            scope='Bounded deterministic stdlib reference DPLL, clause-scan units and smallest variable in the first open clause; not a modern SAT baseline. Independent tree/assignment and native-proof gates remain separate.')
        if status=='SAT':
            assignment=[answer.get(i,0) for i in range(1,n+1)]
            result.update(assignment=assignment,assignment_sha256=digest(assignment),
                selected=sorted(cid for cid,v in encoded['selector_variables'] if assignment[v-1]==1))
        # Final hash/serialization phase is wall-gated, not exact CPU metering.
        try:meter.tick()
        except Bound as error:
            result=dict(result,status='UNKNOWN',saved_search_status=status,reason=str(error))
        return result
    except (Bound,MemoryError,RecursionError) as error:
        return dict(schema='Shared-fact-reference-DPLL-result-v1',version=VERSION,status='UNKNOWN',reason=str(error) or type(error).__name__,
            cnf_sha256=cnf_sha,certificate=None,nodes=nodes,work=meter.work if meter else 0,
            seconds=time.perf_counter()-meter.start if meter else 0)
    except (Invalid,KeyError,TypeError,ValueError,OverflowError) as error:
        return dict(schema='Shared-fact-reference-DPLL-result-v1',version=VERSION,status='REJECTED_INPUT',reason=str(error) or type(error).__name__)
