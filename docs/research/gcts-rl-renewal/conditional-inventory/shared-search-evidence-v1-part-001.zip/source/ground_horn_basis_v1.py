"""Assumption-only finite pred0/imp subformula catalogue, data only.

No target derivation, solver, native checker, model builder or previous study
is imported/read. Complete means this declared subformula/primitive profile,
not complete propositional or first-order proof search.
"""
import copy
import hashlib
import json
import math
import time

DEFAULT_LIMITS = dict(max_formulas=48, max_rows=25000, max_slots=64,
    max_zero_definitions=256, max_items=2000000, max_depth=128, wall_seconds=10.0)
VERSION = 'Ground-Horn-subformula-compiler-v1'


class Refusal(Exception):
    pass


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def limits_value(limits):
    result = dict(DEFAULT_LIMITS)
    if limits is not None:
        need(type(limits) is dict and set(limits) <= set(result), 'LIMIT_FIELDS')
        result.update(limits)
    for key, value in result.items():
        if key == 'wall_seconds':
            need(type(value) in (int, float) and math.isfinite(value) and value > 0, 'POSITIVE_WALL_LIMIT')
        else:
            need(integer(value, 1), 'POSITIVE_INTEGER_LIMIT:'+key)
        need(value <= DEFAULT_LIMITS[key], 'LIMIT_EXCEEDS_DECLARED_CEILING:'+key)
    return result


def compile_case(case, limits=None):
    started, count = time.perf_counter(), 0
    try:
        need(type(case) is dict and {'id', 'statement', 'profile'} <= set(case), 'CASE_FIELDS')
        need('schema' not in case or case['schema'] == 'Shared-fact-proof-case-v1', 'CASE_SCHEMA')
        need(not {'proof', 'target_proof', 'witness', 'selected', 'bank', 'control_proof'} & set(case), 'NO_SUPPLIED_PROOF_OR_BANK')
        need(type(case['id']) is str and case['id'], 'CASE_ID')
        effective = limits_value(case.get('limits') if limits is None else limits)

        def tick(amount=1):
            nonlocal count
            count += amount
            if count > effective['max_items']:
                raise Refusal('PREPARATION_ITEM_BOUND')
            if time.perf_counter()-started > effective['wall_seconds']:
                raise Refusal('PREPARATION_WALL_BOUND')

        def scan(value, depth=0):
            tick()
            if depth > effective['max_depth']:
                raise Refusal('NATIVE_JSON_DEPTH_BOUND')
            if type(value) is str:
                tick(len(value))
            elif type(value) is list:
                for child in value:
                    scan(child, depth+1)
            elif type(value) is dict:
                for key, child in value.items():
                    need(type(key) is str, 'NATIVE_JSON_KEYS')
                    scan(key, depth+1)
                    scan(child, depth+1)
            else:
                need(value is None or type(value) in (int, bool) or
                     type(value) is float and math.isfinite(value), 'FINITE_NATIVE_JSON')
        scan(case)
        statement = case['statement']
        need(type(statement) is dict and set(statement) == {'theory', 'goal'}, 'STATEMENT_FIELDS')
        theory = statement['theory']
        need(type(theory) is dict and set(theory) == {'functions', 'predicates', 'axioms'}, 'THEORY_FIELDS')
        need(type(theory['functions']) is dict and theory['functions'] == {}, 'NO_GROUND_TERM_SIGNATURE')
        predicates, axioms = theory['predicates'], theory['axioms']
        need(type(predicates) is dict and all(type(k) is str and k and type(v) is int and v == 0
             for k, v in predicates.items()), 'PRED0_SIGNATURE')
        need(type(axioms) is dict and all(type(k) is str and k for k in axioms), 'AXIOM_NAMES')
        if len(axioms) > effective['max_zero_definitions']:
            raise Refusal('ZERO_DEFINITION_CAP')
        profile = copy.deepcopy(case['profile'])
        need(type(profile) is dict and profile.get('kind') == 'GROUND_HORN_SUBFORMULAS_V1', 'GROUND_PROFILE_KIND')
        need(integer(profile.get('slots'), 1), 'DECLARED_SLOT_BOUND')
        if profile['slots'] > effective['max_slots']:
            raise Refusal('SLOT_CAP')
        defaults = dict(formula_universe_version='LITERAL_SORTED_CANONICAL_JSON_V1',
                        zero_instance_profile='ASSUMPTIONS_ONLY', variables=[], allow_gen=False)
        for key, value in defaults.items():
            if key in profile:
                need(type(profile[key]) is type(value) and profile[key] == value, 'GROUND_PROFILE_FIELD:'+key)
            profile[key] = value
        found = {}

        def visit(formula, depth=0):
            tick()
            if depth > effective['max_depth']:
                raise Refusal('FORMULA_DEPTH_BOUND')
            need(type(formula) is list and formula and type(formula[0]) is str, 'LITERAL_FORMULA_AST')
            if formula[0] == 'pred':
                need(len(formula) == 3 and type(formula[1]) is str and formula[1] in predicates
                     and type(formula[2]) is list and not formula[2], 'REGISTERED_PRED0_AST')
            else:
                need(formula[0] == 'imp' and len(formula) == 3, 'PRED0_IMP_PROFILE_ONLY')
                visit(formula[1], depth+1)
                visit(formula[2], depth+1)
            key = canonical(formula)
            found[key] = formula
            if len(found) > effective['max_formulas']:
                raise Refusal('COMPLETE_FORMULA_UNIVERSE_CAP')
        for name in sorted(axioms):
            visit(axioms[name])
        visit(statement['goal'])
        formulas = [copy.deepcopy(found[key]) for key in sorted(found)]
        ids = {canonical(formula): i+1 for i, formula in enumerate(formulas)}
        zeros = [dict(id='Z%06d'%i, native=dict(rule='axiom', name=name,
                  formula=copy.deepcopy(axioms[name]))) for i, name in enumerate(sorted(axioms))]
        mp = []
        for implication, formula in enumerate(formulas, 1):
            tick()
            if formula[0] == 'imp':
                mp.append(dict(antecedent=ids[canonical(formula[1])], implication=implication,
                               output=ids[canonical(formula[2])]))
        mp.sort(key=lambda d: (d['antecedent'], d['implication'], d['output']))
        catalogue = dict(schema='Shared-fact-finite-catalogue-v1',
            statement=copy.deepcopy(statement), formulas=formulas, zeros=zeros, mp=mp, gen=[],
            profile=profile, provenance=dict(case_id=case['id'], compiler=VERSION,
                declaration_sha256=digest(case),
                scope='All literal assumption/goal subformulas, every named assumption ZERO and every structural MP. No proof path, search, target witness, GEN or other native schema was supplied.'))
        result = dict(schema='Ground-Horn-basis-compile-v1', status='CATALOGUE_UNVERIFIED',
            catalogue=catalogue, original_statement_sha256=digest(statement),
            census=dict(formulas=len(formulas), zeros=len(zeros), mp=len(mp), gen=0),
            limits=effective, seconds=time.perf_counter()-started, items=count,
            admission='External independent complete-basis reconstruction and all native ZERO checks required. No full logical completeness or proof result is claimed.')
        tick()
        result.update(seconds=time.perf_counter()-started, items=count)
        return result
    except (Refusal, MemoryError, RecursionError) as error:
        return dict(schema='Ground-Horn-basis-compile-v1', status='UNKNOWN',
            reason=str(error) or type(error).__name__, seconds=time.perf_counter()-started,
            catalogue=None, items=count)
    except (ValueError, TypeError, KeyError, IndexError, AttributeError) as error:
        return dict(schema='Ground-Horn-basis-compile-v1', status='REJECTED_INPUT',
            reason=str(error), seconds=time.perf_counter()-started, catalogue=None, items=count)
