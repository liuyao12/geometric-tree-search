"""Prospective shared-fact qualification/pilot. Freeze before module imports.

Only new declarations enter search. No previous proof or target derivation is
read. All Sources, runtime, plans and limits are byte frozen first. Every phase
runs once in its own guarded native child, retains raw output and full graph
observations, and cannot silently restart. This is a finite ground pilot, not RL.
"""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
NATIVE=dict(max_operations=5000000,max_depth=128,max_proof_lines=128)
POINT=dict(wall_seconds=3.0,max_work=100000000,max_nodes=10000,max_events=1000,
           max_rollback_records=1000,max_candidates=25000,max_points=128)
FORWARD=dict(wall_seconds=3.0,max_work=20000000,max_states=200000)
SAT=dict(wall_seconds=3.0,max_work=10000000,max_nodes=100000,max_depth=128)
GUARDS=dict(wall_seconds=180.0,cpu_seconds=150,rss_bytes=1073741824)
TRUSTED={'reference/basic-tiling-algorithm.md':'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9',
    'reference/upstream/growing_point_search_v2.py':'6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb',
    'reference/upstream/frontier_trace_checker_v1.py':'01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f',
    'reference/upstream/native_fol_checker_v1.py':'099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1'}
SEMANTIC=('statement','proof','slots','slot_to_native','native_to_slot','reference_mapping',
          'proof_dag','selected','selected_sha256','original_statement_sha256','scope')


def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def need(ok,reason):
    if not ok:raise ValueError(reason)
def read(p):return json.loads((ROOT/p).read_bytes())
def pin(p):
    raw=p.read_bytes();return dict(path=str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):
    target=ROOT/p;target.parent.mkdir(parents=True,exist_ok=True);raw=wire(x)
    if target.suffix=='.gz':raw=gzip.compress(raw,mtime=0)
    with target.open('xb') as out:out.write(raw)
    return dict(path=p,**{k:v for k,v in pin(target).items() if k!='path'})
def call(p,fn):
    start=time.perf_counter();x=fn();ref=save(p,x)
    print(json.dumps(dict(file=p,status=x.get('status'),seconds=time.perf_counter()-start)),flush=True)
    return x,dict(ref,call_seconds=time.perf_counter()-start)
def module(name,p):
    spec=importlib.util.spec_from_file_location(name,ROOT/p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def sources():
    return sorted([*ROOT.glob('source/*.py'),*ROOT.glob('reference/*.py'),*ROOT.glob('reference/upstream/*.py'),
                   *ROOT.glob('reference/*.md'),*ROOT.glob('plan/*.md'),*ROOT.glob('plan/*.json'),*ROOT.glob('review/peer-*.md')])
def runtime():return dict(executable=pin(Path(sys.executable).resolve()),version=sys.version,isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)
def freeze():
    need(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,'ISOLATED_RUNTIME_REQUIRED')
    need(not (ROOT/'data/protocol-frozen-v1.json').exists(),'NO_REFREEZE')
    need(all(pin(ROOT/p)['sha256']==h for p,h in TRUSTED.items()),'QUALIFIED_UPSTREAM_AND_MASTER_PINS')
    p=dict(schema='Shared-fact-search-protocol-v1',status='FROZEN_BEFORE_SCIENTIFIC_IMPORTS',files=[pin(x) for x in sources()],
        runtime=runtime(),point_limits=POINT,forward_limits=FORWARD,sat_limits=SAT,native_limits=NATIVE,guards=GUARDS,
        qualification='seven prospective ground declarations, seven exact unit models, full tiny assignment and eligible tiny CNF selector enumeration; corruption/resource fixtures',
        benchmark='eight declarations/four templates at bounds six and ten, fixed order, one attempt per control; no RL, no training bank, no previous proofs',
        cost_scope='All preparation/admission/encoding/search/assurance/decoding/native calls and serialization measured separately. Equal search wall ceilings do not imply equal work-counter units. Audit cost is included in point search.',
        frozen_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    return save('data/protocol-frozen-v1.json',p)
def unchanged():
    p=read('data/protocol-frozen-v1.json')
    need(p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_STATUS')
    need(p['files']==[pin(x) for x in sources()],'EXACT_FROZEN_SOURCE_SET')
    need(p['runtime']==runtime(),'EXACT_RUNTIME')
    need(p['point_limits']==POINT and p['forward_limits']==FORWARD and p['sat_limits']==SAT and p['native_limits']==NATIVE and p['guards']==GUARDS,'FROZEN_LIMITS')
    return p
def load_modules():
    return {k:module('dag_'+k,p) for k,p in dict(H='source/ground_horn_basis_v1.py',M='source/shared_fact_model_v1.py',
        K='reference/shared_fact_checker_v1.py',E='reference/upstream/growing_point_search_v2.py',
        T='reference/upstream/frontier_trace_checker_v1.py',B='reference/upstream/native_fol_checker_v1.py',
        F='source/conventional_forward_v1.py',S='source/sat_encoding_v1.py',C='reference/sat_certificate_checker_v1.py',
        A='reference/point_cnf_admission_v1.py',O='reference/tiny_point_oracle_v1.py').items()}
def verified(x):need(x.get('status')=='VERIFIED','GATE_NOT_VERIFIED:'+str(x.get('reason',x.get('status'))))
def point_run(mods,model,base):
    started=time.perf_counter();observations=[]
    def audit(event,state,charge):
        if len(observations)>=POINT['max_events']:charge(POINT['max_work']+1)
        charge(1);observations.append(dict(event=event,state=state))
    result,ref=call(base+'/point-result.json.gz',lambda:mods['E'].solve(model,POINT,audit=audit))
    need(result['status'] in ('SAT','UNSAT','UNKNOWN'),'POINT_RESULT_STATUS')
    saved_at=time.perf_counter();observation_ref=save(base+'/point-observations.json.gz',observations)
    observation_ref['write_seconds']=time.perf_counter()-saved_at
    trace,tref=call(base+'/point-trace.json',lambda:mods['T'].verify(model,model['inventory']['placements'],observations,result,max_items=100000000,wall_seconds=30.0))
    if result['status'] in ('SAT','UNSAT'):verified(trace)
    return result,trace,dict(search=ref,trace=tref,observations=observation_ref,pipeline_seconds=time.perf_counter()-started)
def sat_run(mods,model,base):
    started=time.perf_counter()
    encoded,eref=call(base+'/cnf.json.gz',lambda:mods['S'].encode(model))
    need(encoded['status']=='ENCODED','ENCODER_REFUSAL')
    admission,aref=call(base+'/cnf-admission.json',lambda:mods['A'].verify(model,encoded));verified(admission)
    result,sref=call(base+'/sat-result.json.gz',lambda:mods['S'].solve(encoded,SAT))
    need(result['status'] in ('SAT','UNSAT','UNKNOWN'),'SAT_RESULT_STATUS')
    receipt,cref=call(base+'/sat-certificate.json',lambda:mods['C'].verify(encoded,result))
    if result['status'] in ('SAT','UNSAT'):verified(receipt)
    return encoded,result,receipt,dict(encoding=eref,admission=aref,search=sref,certificate=cref,pipeline_seconds=time.perf_counter()-started)
def decode(mods,prepared,selected,base):
    started=time.perf_counter()
    a,ar=call(base+'/adapter-decoding.json.gz',lambda:mods['M'].decode(prepared,selected))
    b,br=call(base+'/independent-decoding.json.gz',lambda:mods['K'].decode(prepared,selected))
    need(a['status']==b['status']=='UNVERIFIED_NATIVE_CERTIFICATE','DECODE_STATUS')
    need(all(wire(a[k])==wire(b[k]) for k in SEMANTIC),'INDEPENDENT_FULL_DECODING_JOIN')
    statement=prepared['statement']
    native,nr=call(base+'/native-B.json',lambda:mods['B'].check(statement['theory'],b['proof'],statement['goal'],NATIVE));verified(native)
    binding=dict(status='VERIFIED',proof_sha256=sha(b['proof']),statement_sha256=sha(statement),selected_sha256=sha(sorted(selected)),
        native_receipt_sha256=sha(native),scope='Exact full decoder semantic agreement and native B on every extracted line; no target derivation supplied.')
    save(base+'/proof-admission.json',binding)
    return b,dict(adapter=ar,independent=br,native=nr,pipeline_seconds=time.perf_counter()-started)
def case_run(mods,entry,base,tiny=False):
    started=time.perf_counter();case=entry['case'];refs={}
    save(base+'/declaration.json',case)
    compiled,refs['compile']=call(base+'/catalogue.json',lambda:mods['H'].compile_case(case))
    need(compiled['status']=='CATALOGUE_UNVERIFIED','BASIS_COMPILER_REFUSAL');catalogue=compiled['catalogue']
    prepared,refs['prepare']=call(base+'/prepared.json.gz',lambda:mods['M'].prepare(catalogue,case['profile']['slots']))
    need(prepared['status']=='PREPARED_UNVERIFIED','PREPARATION_REFUSAL')
    model=prepared['model']
    gate,refs['basis_model']=call(base+'/basis-model.json',lambda:mods['K'].verify(case,catalogue,prepared));verified(gate)
    zeros=[]
    for i,z in enumerate(catalogue['zeros']):
        check,ref=call(base+'/zero-%03d-native-B.json'%i,lambda z=z:mods['B'].check(case['statement']['theory'],[z['native']],z['native']['formula'],NATIVE));verified(check);zeros.append(ref)
    refs['zeros']=zeros
    point,trace,refs['point']=point_run(mods,model,base)
    forward,refs['forward']=call(base+'/forward-result.json.gz',lambda:mods['F'].search(catalogue,case['profile']['slots'],FORWARD))
    need(forward['status'] in ('DERIVABLE','NOT_DERIVABLE_WITHIN_BOUND','UNKNOWN'),'FORWARD_RESULT_STATUS')
    encoded,sat,cert,refs['sat']=sat_run(mods,model,base)
    proofs={}
    for label,result in [('point',point),('sat',sat)]:
        if result['status']=='SAT':proofs[label],refs[label+'_proof']=decode(mods,prepared,result['selected'],base+'/'+label+'-proof')
    if forward['status']=='DERIVABLE':
        check,refs['forward_native']=call(base+'/forward-native-B.json',lambda:mods['B'].check(case['statement']['theory'],forward['proof'],case['statement']['goal'],NATIVE));verified(check)
    exists={}
    for label,result in [('point',point),('sat',sat)]:
        exists[label]=True if result['status']=='SAT' else False if result['status']=='UNSAT' else None
    exists['forward']=True if forward['status']=='DERIVABLE' else False if forward['status']=='NOT_DERIVABLE_WITHIN_BOUND' else None
    need(len(set(v for v in exists.values() if v is not None))<=1,'COMPLETED_CONTROLS_DISAGREE')
    need(all(v==entry['expected_bounded_existence'] for v in exists.values() if v is not None),'PROSPECTIVE_EXPECTATION_MISMATCH')
    gap=None
    if tiny:
        need(all(v is not None for v in exists.values()),'TINY_QUALIFICATION_CONTROLS_MUST_COMPLETE')
        oracle,refs['oracle']=call(base+'/point-oracle.json.gz',lambda:mods['O'].solve(model))
        need(oracle['status']=='EXHAUSTED' and oracle['exists']==entry['expected_bounded_existence'],'TINY_POINT_ORACLE')
        if len(encoded['selector_variables'])<=12:
            projection,refs['projection']=call(base+'/cnf-projections.json.gz',lambda:mods['O'].selector_projections(encoded))
            need(projection['status']=='EXHAUSTED' and {wire(s) for s in projection['solutions']}=={wire(s) for s in oracle['solutions']},'ALL_SELECTOR_PROJECTIONS')
        if entry.get('decoder_gap_evidence_required'):
            for selected in oracle['solutions']:
                actions=[json.loads(c) for c in selected];active=sorted(a[2] for a in actions if a[3]!='PAD')
                if any(b-a>1 for a,b in zip(active,active[1:])):
                    gap,refs['gap_proof']=decode(mods,prepared,selected,base+'/gap-proof');break
            need(gap is not None,'OBSERVED_NONCONTIGUOUS_ACTIVE_EMBEDDING')
    shared={}
    for label,proof in proofs.items():
        consumers={}
        for e in proof['proof_dag']['edges']:consumers.setdefault(e['premise'],set()).add(e['conclusion'])
        shared[label]=[dict(premise=k,consumers=sorted(v)) for k,v in sorted(consumers.items()) if len(v)>1]
    summary=dict(status='COMPLETED_ADMITTED_ATTEMPTS',id=case['id'],case=case,census=prepared['census'],exists=exists,
        point_status=point['status'],forward_status=forward['status'],sat_status=sat['status'],point_stats=point['stats'],
        forward_counts=forward.get('counts'),sat_nodes=sat.get('nodes'),shared_premises=shared,refs=refs,
        seconds=time.perf_counter()-started,scope='Same declared finite basis and line bound; UNKNOWN is unresolved. Semantic anchored point adaptation; no RL or universal Wang search claim.')
    save(base+'/result.json',summary);return summary
def unit_qualify(mods):
    out=[]
    for f in read('plan/unit-fixtures-v1.json')['fixtures']:
        base='data/qualification/'+f['id'];model=dict(schema='Z-growing-point-model-v1',version=f['id'],capacity=1,roots=f['roots'],seed=f['seed'],inventory=dict(kind='EXPLICIT',placements=f['rows']))
        save(base+'/model.json',model)
        p,t,pr=point_run(mods,model,base);encoded,s,c,sr=sat_run(mods,model,base)
        oracle,oref=call(base+'/point-oracle.json.gz',lambda:mods['O'].solve(model))
        projection,xref=call(base+'/cnf-projections.json.gz',lambda:mods['O'].selector_projections(encoded))
        need(oracle['status']==projection['status']=='EXHAUSTED','UNIT_EXHAUSTION')
        need(p['status'] in ('SAT','UNSAT') and s['status'] in ('SAT','UNSAT'),'UNIT_CONTROLS_MUST_COMPLETE')
        need({wire(x) for x in oracle['solutions']}=={wire(x) for x in projection['solutions']},'UNIT_ALL_SELECTOR_PROJECTIONS')
        need((p['status']=='SAT')==(s['status']=='SAT')==oracle['exists']==f['expected'],'UNIT_EXISTENCE')
        if 'first_decision' in f:need(p['events'][1]['kind']==f['first_decision'],'FIRST_GLOBAL_DECISION')
        if f.get('require_backtrack'):need(p['stats']['backtracks']>0,'OBSERVED_REMOTE_ROLLBACK')
        out.append(dict(id=f['id'],status='VERIFIED',point_stats=p['stats'],point=pr,sat=sr,oracle=oref,projection=xref))
    save('data/qualification/unit-summary.json',dict(status='VERIFIED',fixtures=out));return out
def mutations(mods):
    base='data/qualification/dsgq-mp-l3-v1'
    prepared=json.loads(gzip.decompress((ROOT/(base+'/prepared.json.gz')).read_bytes()))
    case=read(base+'/declaration.json');catalogue=prepared['catalogue'];results=[]
    def test(name,packet,fn,expected='REJECTED'):
        save('data/mutations/'+name+'-input.json.gz',packet)
        check,_=call('data/mutations/'+name+'-check.json',lambda:fn(packet))
        need(check['status']==expected,'MUTATION_EXPECTATION:'+name);results.append(dict(id=name,status=check['status']))
    for field in ('formulas','zeros','mp'):
        packet=copy.deepcopy(catalogue);packet[field].pop()
        test('omitted-'+field,packet,lambda x:mods['K'].verify_basis(case,x))
    for name,alter in [('omitted-row',lambda p:p['universe'].pop()),
        ('bool-slot-bound',lambda p:p['binding'].__setitem__('slots',True)),
        ('float-slot-bound',lambda p:p['binding'].__setitem__('slots',3.0)),
        ('wrong-goal-mark',lambda p:p['model']['seed']['m'][0].__setitem__(1,'0')),
        ('wrong-owner-active',lambda p:p['universe'][0]['m'][0].__setitem__(1,'CORRUPTED'))]:
        packet=copy.deepcopy(prepared);alter(packet)
        test(name,packet,lambda x:mods['K'].verify_model(catalogue,x))
    for name,ref_value in [('self-reference',2),('forward-reference',3),('boolean-reference',True)]:
        packet=copy.deepcopy(prepared);r=next(r for r in packet['universe'] if json.loads(r['id'])[3]=='MP')
        action=json.loads(r['id']);action[5][0]=ref_value;r['id']=wire(action).decode('ascii')
        test(name,packet,lambda x:mods['K'].verify_model(catalogue,x))
    point=json.loads(gzip.decompress((ROOT/(base+'/point-result.json.gz')).read_bytes()))
    if point['status']=='SAT':
        selected=list(point['selected']);action=next(json.loads(c) for c in selected if json.loads(c)[3]=='MP')
        receptor=action[5][0]
        selected=[c for c in selected if json.loads(c)[2]!=receptor]
        selected.append(next(r['id'] for r in prepared['universe'] if json.loads(r['id'])[2:4]==[receptor,'PAD']))
        test('referenced-inactive-PAD',selected,lambda x:mods['K'].decode(prepared,x))
    encoded=json.loads(gzip.decompress((ROOT/(base+'/cnf.json.gz')).read_bytes()))
    for name,alter in [('dropped-clause',lambda p:p['clauses'].pop()),('bool-selector',lambda p:p['selector_variables'][0].__setitem__(1,True))]:
        packet=copy.deepcopy(encoded);alter(packet);packet['cnf_sha256']=sha(dict(nvars=packet['nvars'],clauses=packet['clauses']))
        test(name,packet,lambda x:mods['A'].verify(prepared['model'],x))
    sat=json.loads(gzip.decompress((ROOT/(base+'/sat-result.json.gz')).read_bytes()))
    if sat['status']=='SAT':
        packet=copy.deepcopy(sat);packet['assignment'][0]=1-packet['assignment'][0];packet['assignment_sha256']=sha(packet['assignment'])
        test('changed-sat-assignment',packet,lambda x:mods['C'].verify(encoded,x))
        packet=copy.deepcopy(sat)
        todo=[packet['certificate']]
        while todo:
            node=todo.pop()
            if node['units']:
                node['units'][0][0]=True;break
            todo.extend(c['tree'] for c in node.get('children',[]))
        test('boolean-unit-reason',packet,lambda x:mods['C'].verify(encoded,x))
    test('basis-resource',catalogue,lambda x:mods['K'].verify_basis(case,x,max_work=1),expected='UNKNOWN')
    test('point-resource',prepared['model'],lambda x:mods['E'].solve(x,dict(POINT,max_work=1)),expected='UNKNOWN')
    test('forward-resource',catalogue,lambda x:mods['F'].search(x,3,dict(FORWARD,max_work=1)),expected='UNKNOWN')
    test('sat-resource',encoded,lambda x:mods['S'].solve(x,dict(SAT,max_work=1)),expected='UNKNOWN')
    save('data/mutations/summary.json',dict(status='VERIFIED',controls=results));return results
def worker(phase):
    protocol=unchanged();started=time.perf_counter()
    save('data/'+phase+'-started.json',dict(status='STARTED',pid=os.getpid(),phase=phase,protocol_sha256=sha(protocol),utc=time.time()))
    try:
        mods=load_modules();proposal=read('plan/qualification-cases-proposal-v1.json')
        if phase=='qualify':
            cases=[case_run(mods,e,'data/qualification/'+e['case']['id'],tiny=True) for e in proposal['qualification_cases']]
            units=unit_qualify(mods);controls=mutations(mods)
            result=dict(status='VERIFIED_QUALIFICATION',cases=cases,units=units,controls=controls)
        else:
            gate=read('data/qualify-result.json');need(gate['status']=='VERIFIED_QUALIFICATION','QUALIFICATION_REQUIRED')
            observer=read('review/qualify-observer.json');need(observer['native_exit_code']==0 and observer['guard_reason'] is None,'QUALIFICATION_NATIVE_COMPLETION')
            invocation=read('review/qualify-invocation.json');admission=read('data/qualify-started.json')
            need(observer['frozen_postcheck']==invocation['frozen_postcheck']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS' and observer['postcheck_error'] is invocation['postcheck_error'] is None,'QUALIFICATION_POSTCHECK')
            need(invocation['status']=='COMPLETE' and invocation['pid']==observer['pid']==admission['pid'] and admission['protocol_sha256']==sha(protocol),'QUALIFICATION_PROCESS_PROTOCOL_JOIN')
            need(invocation['phase']==observer['phase']==admission['phase']=='qualify','QUALIFICATION_PHASE_JOIN')
            entries=[x for x in proposal['benchmark_cases'] if x['case']['id']==phase];need(len(entries)==1,'DECLARED_PHASE')
            result=case_run(mods,entries[0],'data/benchmark/'+phase)
        unchanged();save('data/'+phase+'-result.json',result)
        return dict(status='COMPLETE',phase=phase)
    finally:
        error=sys.exc_info()[0]
        post_error=None
        try:postcheck=unchanged()['status']
        except Exception as failure:postcheck='FAILED';post_error=str(failure)
        save('review/'+phase+'-invocation.json',dict(status='ERROR' if error or post_error else 'COMPLETE',phase=phase,pid=os.getpid(),
            seconds=time.perf_counter()-started,maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            maxrss_units='bytes' if sys.platform=='darwin' else 'KiB',frozen_postcheck=postcheck,postcheck_error=post_error,error_type=error.__name__ if error else None))
        if post_error and error is None:raise RuntimeError('FROZEN_POSTCHECK:'+post_error)
def supervise(phase):
    unchanged()
    need(phase=='qualify' or phase in [x['case']['id'] for x in read('plan/qualification-cases-proposal-v1.json')['benchmark_cases']],'DECLARED_PHASE')
    need(not (ROOT/('data/'+phase+'-started.json')).exists(),'NO_PHASE_RESTART')
    log=ROOT/('review/'+phase+'-native.log');need(not log.exists(),'NO_LOG_REPLACEMENT')
    start=time.perf_counter();peak=0;reason=None;probes=[]
    def cpu_guard():resource.setrlimit(resource.RLIMIT_CPU,(GUARDS['cpu_seconds'],GUARDS['cpu_seconds']+1))
    with log.open('xb') as out:
        child=subprocess.Popen([sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),'_worker',phase],cwd=ROOT,
            env={'PATH':'/usr/bin:/bin','LANG':'C','PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=cpu_guard)
        try:
            while child.poll() is None:
                probe=subprocess.run(['/bin/ps','-o','rss=','-p',str(child.pid)],capture_output=True,text=True,timeout=5)
                if probe.returncode==0 and probe.stdout.strip():
                    rss=int(probe.stdout.strip())*1024
                    if rss>peak:peak=rss;probes.append(dict(seconds=time.perf_counter()-start,rss_bytes=rss))
                    if rss>GUARDS['rss_bytes']:reason='RSS_POLL_BOUND';break
                elif child.poll() is None:reason='RSS_PROBE_FAILED';break
                if time.perf_counter()-start>GUARDS['wall_seconds']:reason='WALL_BOUND';break
                time.sleep(.2)
        except BaseException as error:
            reason='OBSERVER_ERROR:'+type(error).__name__
        finally:
            if reason and child.poll() is None:
                try:os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
        code=child.wait()
    post_error=None
    try:postcheck=unchanged()['status']
    except Exception as failure:postcheck='FAILED';post_error=str(failure)
    receipt=dict(status='TERMINAL',phase=phase,pid=child.pid,native_exit_code=code,guard_reason=reason,
        peak_observed_rss_bytes=peak,rss_samples=probes,seconds=time.perf_counter()-start,log=pin(log),
        frozen_postcheck=postcheck,postcheck_error=post_error,scope='Polling RSS guard, native CPU cap and owned child only; nonzero/unfinished remains unresolved, no rerun.')
    save('review/'+phase+'-observer.json',receipt);return receipt
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['freeze','run','_worker']);ap.add_argument('phase',nargs='?');a=ap.parse_args()
    need((a.command=='freeze')==(a.phase is None),'COMMAND_PHASE')
    print(json.dumps(freeze() if a.command=='freeze' else supervise(a.phase) if a.command=='run' else worker(a.phase),sort_keys=True),flush=True)
