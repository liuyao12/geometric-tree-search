# Prospective shared-fact adapter ABI

Unimplemented design. This specifies data and future call boundaries; it supplies no actual case, witness or executable model. All names below are proposed versioned identifiers. Freeze runtime, Source, master and declarations before preparation/classification. No earlier study is modified.

## Native JSON and finite basis

`case` has exactly the following semantic components, plus descriptive metadata:

```text
schema = "Shared-fact-proof-case-v1"
id: nonempty string
statement: {theory:{functions,predicates,axioms}, goal}
variables: unique ordered strings
profile: {
  slots: positive integer,
  allow_padding: true,
  formula_universe_version, formula_depth, term_depth,
  term_pool, zero_instance_profile, closure_rounds,
  closed_assumptions: true
}
limits: {max_formulas, max_zero_definitions, max_rows, preparation_seconds}
generation: {generator_version, seed, structural_partition}
```

Formula/term ASTs use the existing literal native syntax and signature. IDs are assigned by sorting canonical compact ASCII formula JSON plus LF, starting at one; padding is ID zero. The closure algorithm and intermediate census are part of the profile, not inferred from a target proof. If closure exceeds a limit, return UNKNOWN with the partial census clearly unadmitted, without constructing a silently truncated valid model. Canonical scope hashes bind the complete statement, variable/term/formula pools, primitive instance definitions, line/padding semantics and profile version.

Proposed `prepare(case) -> packet`:

```text
{
  schema: "Shared-fact-prepared-v1",
  status: PREPARED_UNVERIFIED | UNKNOWN | REJECTED_INPUT,
  binding, basis, model, universe, definitions, census,
  timings, reason
}
```

`basis` contains the full literal formula table, declared terms and primitive definitions. `definitions` retains every ZERO native payload and structural MP/GEN type. Enumerate every owning slot and every strictly earlier premise-slot choice. Merge repeated port assignments only when their literal values agree; count inconsistent combinations as impossible self-conflicts. A ZERO payload is admitted independently, not trusted because it appears in this table. Keep distinct primitive payload identities even when their formula and point row happen to agree.

## Exact point rows

Use opaque canonical point strings, no coordinate geometry or transformation group:

```text
q_i = canonical(["DAG-slot-center-v1", scope, i])
a_i = canonical(["DAG-slot-active-v1", scope, i])
f_i = canonical(["DAG-slot-formula-v1", scope, i])
```

The canonical output includes the final LF consistently; strings are distinct by namespace. Integer indices exclude booleans and floats. Mark values are strings `"0"`, `"1"` and decimal positive formula IDs, compared literally. Assigned zero is never omitted. Every row uses the unchanged engine's exact fields:

```text
{id: canonical(["DAG-candidate-v1", scope, slot, kind, definition_id, refs]),
 t: [[q_slot, 1]],
 m: sorted unique [point_string, value_string] rows}
```

`kind` is `ZERO`, `MP`, `GEN` or `PAD`; reference arrays and native rule payload are bound by `definitions`/CID. A point row contains all own/read active/formula assignments specified in the design. MP's two references and GEN's one reference are native indices strictly below the owning slot. The only allowed action is selecting this anchored row once. Slot/formula namespace addresses are semantic data, not a planar lattice or translation-only Wang palette.

The model is exactly compatible with the existing engine:

```text
{
  schema: "Z-growing-point-model-v1",
  version: "Shared-fact-slots-active-formula-v1:" + scope,
  capacity: 1,
  roots: sorted([q_i for every slot]),
  seed: {t: [], m: sorted([[a_last,"1"],[f_last,goal_id_string]])},
  inventory: {kind:"EXPLICIT", placements: universe}
}
```

All required centers start active with total zero. Active/formula ports are mark-only, including those a consumer constrains before its owner is selected. The engine's positive graph and complete marking dependency graph are distinct from the extracted logical reference DAG. Every explicit root retains generation zero; selected owner placements have generation one. No new scheduling semantics are introduced.

Initial entry point:

```text
E.solve(model, limits, order=None, audit=capture_every_event)
```

The engine Source remains byte-identical and pinned. The explicit universe appears in the model and as a separately pinned saved artifact. No indexed provider, top-k pool, target derivation or model-time native checker is hidden inside the engine. Enumeration/basis validation is measured preparation and shared by every method.

## Independent admission and decoding

Separate modules, authored independently, should expose:

```text
verify_basis(case, prepared) -> formula/profile/ZERO/coverage receipt
verify_model(case, prepared) -> complete candidate/point-reduction receipt
check_trace(model, universe, observations, result) -> full frontier receipt
decode(binding, definitions, selected) -> UNVERIFIED_NATIVE_CERTIFICATE
B.check(original_theory, decoded_proof, original_goal, native_limits)
```

`verify_model` must reconstruct every row, seed and reference choice without importing the adapter. It checks full enumeration counts, not just supplied hashes or a `complete` flag. `check_trace` may reuse the qualified independent whole-frontier checker unchanged if its existing EXPLICIT ABI fits; qualify that join before a conformance claim.

`decode` selects one owner per slot, checks complete capacity/mark agreement, sorts active slots, deletes PAD and remaps references. It returns the whole original statement and extracted native proof plus:

```text
slots: [{slot,cid,active,formula_id,native_line_index_or_null}]
slot_to_native: integer-or-null array
native_to_slot: integer array
reference_mapping: per-MP/GEN old-slot and new-line references
proof_dag: literal formula IDs, native line IDs and exact dependencies
selected_sha256, original_statement_sha256, scope
```

PAD writes active zero/formula zero and cannot be read as a fact. The last slot is active and supplies the goal. No requirement makes all earlier active rows contiguous or goal-reachable. Native B checks every extracted active line, including unused lines. Positive admission requires independent model/basis/trace/native gates, unchanged statement hashes and complete selected-to-decoded mapping. Mapping success alone is not logical validity.

Only a complete exhausted, fully audited finite search may report absence for this profile and line bound. Time/work/node/storage/assurance refusal remains UNKNOWN; interrupted children cannot justify exclusions. Retain exact entry/restored equality and independent transition checks, complete event/rollback extents and raw observations. Truncated traces cannot be called all-event verification.

## Controls and family ordering ABI

The SAT control uses the same complete candidate table, one selector per candidate, exactly one owner per slot, shared active/formula variables and all seed/candidate marking implications. The forward control starts with an empty available-fact set and counts each newly introduced primitive/derived fact as one line; assumptions are not free preloaded proof lines. Its distinct-fact quotient is an explicitly justified bounded-existence control, not a claim to preserve every point assignment.

The unchanged engine's optional callback is:

```text
order(request, tick) -> unique preferred CID list
request = {
  schema:"Z-candidate-order-request-v1", model_sha256,
  point, generation, legal, selected, excluded
}
```

The callback only ranks members of `legal` at the already selected point. The engine appends all omitted legal CIDs. A future frozen family bank contains primitive expansions, shared internal nodes, external active/formula receptors, original training origins and capture-safe parameter bindings. An increasing injective internal slot map preserves strict reference order; several open receptors may intentionally read one compatible earlier fact. Validate the whole instantiated expansion against selected rows, seed, inventory and current marks, counting shared selected CIDs once. Reconstruct current state from `selected` rather than retain untrailed logical policy state. Record proposals, bindings, rejection reasons, validation work and the actual chosen primitive action. No multi-member expansion is executed atomically through this API.

Future RL, uniform and heuristic family methods share the bank, candidate universe, scheduler, validation and budgets. Frozen training/evaluation partitions are structural, not symbol renamings of the same complete problem. Policy rewards use independently verified outcomes; acquisition/training/setup/proposal/assurance costs remain separate. Initial lexical/forward/SAT qualification does not claim RL was run.

## Evidence/output plan

Keep prospective declarations and complete preparation/basis/model receipts, raw point traces, all method results/refusals, control certificates and native derivations. A readable report would show original slot indices, active/PAD bits, exact formula/English, shared reference arrows and full primitive expansion. Formula depths, original tree height, line count, number of distinct facts and frontier generation have separate fields. An optional raw/NAND/fixed-100 certificate is a later positive backend join under its own caps; it does not change this semantic point search into literal Wang-grid search.

No Source, data, implementation, proof or result is produced by this ABI document. In particular, the existing post-search compression results are not relabeled as search with sharing.
