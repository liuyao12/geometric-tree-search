# Search with shared facts: prospective finite point model

Design only. No implementation, dataset, model construction, supplied proof, search or checker execution accompanies this proposal. Existing reuse/backend studies and the publication in progress are unchanged. The distinction from post-search compression is that an inference may read the same previously assigned fact as another inference during the search itself.

## Point encoding

Freeze an original signature, assumption context \(\Gamma\), goal \(G\), finite literal formula universe \(\mathcal F\), and line bound \(L\). First-stage assumptions are closed. Every formula has a positive stable ID; ID zero is reserved for padding. Formula/term depths, variable pool, ZERO/schema instance profile and all enumeration limits are declared before labels or search. A formula outside \(\mathcal F\) is not available merely because an unbounded calculus could derive it.

For each slot \(i\in\{0,\ldots,L-1\}\), create a required center \(q_i\) and separate mark-only ports \(a_i,f_i\). Every center is an explicit required root initially at zero capacity. Capacity is one. A candidate contributes \(t(q_i)=1\) only at its owning slot. It writes its own active bit and formula ID, and may assign compatible values at distant prior-slot ports. No reference consumes additional capacity at the fact it reads.

| Candidate at slot \(i\) | Own marks | Read-only receptor marks | Native meaning |
| --- | --- | --- | --- |
| ZERO | \(a_i=1,\ f_i=\operatorname{id}(B)\) | None | One admitted primitive axiom/schema instance with formula \(B\) |
| MP | \(a_i=1,\ f_i=\operatorname{id}(B)\) | \(a_j=a_k=1,\ f_j=\operatorname{id}(A),\ f_k=\operatorname{id}(A\Rightarrow B)\), with \(j,k<i\) | Modus ponens from exactly those earlier slots |
| GEN | \(a_i=1,\ f_i=\operatorname{id}(\forall x\,A)\) | \(a_j=1,\ f_j=\operatorname{id}(A)\), with \(j<i\) | Generalization, with the native context side condition |
| PAD | \(a_i=0,\ f_i=0\) | None | No proof line |

All marks are literal assigned values. Zero is not absence. A consumer requests active one, so it conflicts with an inactive owner; the padding formula zero also differs from every formula ID. Multiple reads of one earlier fact are compatible assignments at the same ports, not duplicate placements. Repeated formulas and unused active lines are permitted; the primary model adds no distinct-fact or reachability normal form.

The seed pins \(a_{L-1}=1\) and \(f_{L-1}=\operatorname{id}(G)\), with no positive seed contribution. Every required center must be filled, including PAD slots. Active rows need not be contiguous. Placement identities retain slot, primitive rule definition and all reference indices; alternative primitive justifications of the same formula are not silently merged. Conflicting repeated assignments within one candidate are rejected during complete enumeration and counted, rather than emitted as malformed rows.

ZERO is a finite catalogue of primitive native rule instances, not a catalogue of complete target proofs. It may include original assumptions, universal-instantiation and equality schemas, reflexivity, and the chosen native propositional schemas. The exact profile is frozen, independently enumerated, and every instance separately checked under the original context before use. No post-search selected producer catalogue, control proof or target derivation defines it. The first ground-Horn pilot needs only assumption ZERO instances and MP; GEN and richer ZERO profiles must pass separate qualification before their cases are used.

## Why complete assignments represent bounded proofs

This is a conditional mathematical argument for the reduction, not an automatically discovered theorem. Assume complete enumeration of the declared rule profile and correct independent primitive rule admission.

In an exact point solution, unit capacity and owner-only support select exactly one candidate per slot. Own and read marks agree. Every referenced slot is active and strictly earlier, so induction over slot index validates ZERO, MP and GEN lines. Delete PAD rows, sort active rows by slot and remap all references to their new indices. The last slot supplies the unchanged goal, giving a native proof with at most \(L\) lines. Independently check that complete extracted proof with native B; the point result alone is not the final logical validity gate.

Conversely, any proof of at most \(L\) lines using exactly this formula/rule profile embeds into the slots in order, with its final goal line at slot \(L-1\) and PAD rows in the unused slots. Remap earlier references under that embedding. All owner/read marks agree and every center receives one unit. Thus existence agrees within this finite profile. No claim concerns arbitrary formulas, unrestricted first-order completeness, minimal proof size or the number of equivalent padding assignments.

## Unchanged engine and conformance boundary

Use the already qualified opaque-point engine without changing its scheduler. Initially use an explicit complete universe, not a sampled or policy-supplied provider. All centers are explicit roots of generation zero; ordinary owner placements consequently have generation one. Logical line order is the strict reference relation, not frontier generation, proof depth or chronological search order. Global forced propagation may assign a later logical slot first.

The positive-incidence graph is a collection of slot-centered domains; semantic dependencies are remote marking dependencies. Its edges must not be drawn as if they were the proof DAG. Any mark change must invalidate affected candidates at every center, including a remotely assigned untouched slot. Maintain complete global dead/forced checks, then generation-first branching with degree only as a tie breaker, exact rollback of marks/reference counts/domains/exclusions and full primitive fallback. Missing a provider row or stopping enumeration means UNKNOWN, never a singleton or exhaustion proof.

Independently reconstruct the universe and every retained event graph, check scheduler decisions and restoration, then decode and native-check positives. Full-event evidence is mandatory for a conformance claim. If storage or assurance cannot retain/check all emitted events, stop or report incomplete assurance explicitly; a digest or prefix is not a replacement. Exhaustion establishes only absence in the declared formula/rule profile and line bound. Old tree-height failure ports cannot be transferred to this DAG line bound: sharing changes the resource semantics and contextual fact availability matters.

## Bounded first experiment and controls

Qualify tiny slot models first: target pin; shared premise read by two consumers; consumer versus inactive PAD; remote formula conflict; forward/self reference refusal; all-zero untouched root; global forced/dead precedence; failed-branch revival; and native decoding with noncontiguous active slots. Reject mutations of a reference, formula value, active bit, ZERO admission, complete universe row, graph dependency and branch-local exclusion. No hand-written target proof is an input. Tiny exhaustive assignments are a post-freeze oracle, not a given witness.

The first pilot can freeze eight fresh declarations at two line bounds, \(L\in\{6,10\}\), with at most \(48\) formulas and \(25{,}000\) explicit rows per prepared problem. Use random ground-Horn theories and structured fan-out/reconvergence theories with random facts and target sinks; include a separately qualified small quantified profile. Graph motifs specify problem distributions, not a supplied derivation, candidate order or planted proof certificate. Structural deduplication must remove equivalent training/test problems up to symbol renaming. All seeds, generator parameters, term/formula closure and caps precede classification. Do not assert these masks are difficult in advance; uniform success would provide no solve-rate advantage. Integration on earlier arithmetic/incidence statements is a regression, not fresh held-out evidence.

Declare per-method caps prospectively, for example two seconds search, a common node/work limit, and explicit preparation/assurance/event-storage limits. Overflow of a universe cap is preparation UNKNOWN, not truncation. Start with three primary methods on identical prepared inputs:

- The unchanged point engine with lexical ordering and exact remote markings.
- A conventional SAT encoding of the same slot candidate universe: exactly one owner per slot, seed pins and candidate implications into shared active/formula variables. Use a pinned solver and independently check decoded positives and any claimed UNSAT certificate. Avoid an intentionally wasteful quadratic conflict encoding as the only SAT control.
- A conventional bounded forward shared-fact search, starting with no free proved facts: a used assumption/schema costs a line, as do MP and GEN. Memoize available fact sets and charge added facts. Exact earlier-fact deduplication preserves bounded existence for this context-free profile; document that quotient argument and retain a reconstructible native derivation. It need not enumerate every padded point assignment.

Expanded-tree DP is optional descriptive context, not the sole competitor. Report preparation and primitive admission, search, decoding, full-frontier assurance, native checking, memory and complete pipeline cost separately. Include finite exhaustion, UNKNOWN and resource refusals. A matching SAT/CSP result may explain the mechanism without establishing a distinctive geometric advantage.

## Inventory and later RL

Mine reusable DAG fragments only from previously found, independently checked training proofs. Store their primitive expansions, shared internal facts, typed open receptors, original assumption scope and acquisition provenance. A family binds formula parameters and increasing slot maps; its external receptors can read compatible earlier facts, while internal sharing is represented once. Every instantiation must fit the current finite universe and expand to joint capacity/mark-compatible primitive candidates. It is not an added axiom.

The existing stateless ordering hook can reconstruct the selected assignment, recognize a partially realized family, and prefer a legal constituent in the engine's already chosen branch domain. This supports memoryless continuation preferences without inventing rollback hooks. All primitive candidates remain fallback; global dead/forced and generation rules preempt proposals. Atomic macros or a stateful retained-plan controller need a separately qualified scheduler/rollback extension.

Only after base/control qualification should RL rank these validated family proposals, with a same-bank uniform/heuristic control and proposal-validation cost included. Train from independently verified episode outcomes, then freeze bank and weights before structurally fresh evaluation. Reused inventory acquisition is labeled reused cost, not measured cold learning. No new learning, new theorem, universal tile system or GCTS/RL advantage is established by this design.

Master read for this proposal: `docs/basic-tiling-algorithm.md`, 21,657 bytes, SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`. The optional same-fixed-palette backend is certification after positive search, not literal Wang search. No current Source or evidence is changed.
