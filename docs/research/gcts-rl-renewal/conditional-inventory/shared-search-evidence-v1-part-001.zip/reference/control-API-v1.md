# Shared-fact conventional controls: Source-only API

No module in this handoff has been imported or executed. Root must read and freeze the Sources before qualification. There is no supplied derivation, external solver installation, historical proof input or scientific execution. These are specialized comparison controls; they do not implement the GCTS scheduler.

## Forward fact-set search

`source/conventional_forward_v1.py` exports:

```python
search(catalogue, max_lines, limits=None)
```

The accepted catalogue schema is `Shared-fact-finite-catalogue-v1`, using the agreed original AST ABI:

```text
statement: {theory, goal}
formulas: [literal AST, ...]  # positive IDs are index+1
zeros: [{id: string, native: full primitive native line}, ...]
mp: [{antecedent: FID, implication: FID, output: FID}, ...]
gen: [{source: FID, output: FID, variable: string}, ...]
profile, provenance
```

The Source checks literal MP/GEN incidence, distinct formula/definition identities and native integer IDs. Complete formula/profile enumeration, closed assumptions, ZERO native validity and GEN side conditions require the independent catalogue/model checker and native B gates. It cannot promote an arbitrary supplied catalogue into a logically admitted basis.

If the catalogue declares `profile.slots`, it must be a native nonnegative integer equal to `max_lines`; mismatches are rejected. The primary model adapter always freezes that field, so the forward control cannot silently compare a different line bound.

The initial available set is empty. ZERO, MP or GEN introduces one new literal fact at a cost of one line. Available-FID sets are memoized with one parent derivation. Producer ordering is deterministic and independent of the target's known derivation. `DERIVABLE` includes `proof`, `proof_sha256`, line-level `steps`, `lines`, `binding`, census/work/time and `native_validity='PENDING_INDEPENDENT_NATIVE_B'`. The other statuses are `NOT_DERIVABLE_WITHIN_BOUND`, `UNKNOWN` and `REJECTED_INPUT`.

The bounded-existence relation is conditional on the admitted context-free catalogue: redirect repeated-formula uses to their earliest identical facts and delete duplicates. Every reference remains earlier, every native premise remains the same formula and closed-context GEN has unchanged side conditions. This reduces any bounded slot proof to a distinct-fact path of no more lines; conversely each path embeds with PAD and its goal in the last slot. This quotient preserves existence, not the full set or number of padded assignments. Assumptions/schema instances are never free initial facts.

Forward defaults are `max_items=2000000`, `max_formulas=2000`, `max_producers=20000`, `max_states=200000`, `max_work=20000000`, `wall_seconds=2.0`. All caps are cooperative and callers should retain an outer owned process guard. Memory/recursion/work/state/wall refusals remain `UNKNOWN`.

## SAT encoding of the same explicit point model

`source/sat_encoding_v1.py` exports:

```python
encode(model, universe=None, limits=None)
solve(encoded, limits=None)  # optional bounded stdlib reference DPLL
```

Encoding requires the unchanged `Z-growing-point-model-v1` EXPLICIT ABI with native integer capacity one, positive unit row support and all positive candidate support within the explicit finite roots. Seed values remain exact. Weighted capacity, dynamic support outside finite roots and unsupported resource sizes are explicitly refused; they are not reinterpreted as an exact-cover problem. A separately supplied universe must equal the model inventory after sorting only CID and point rows.

An `ENCODED` packet has schema `Shared-fact-point-CNF-v1` and includes `nvars`, `clauses`, `variables`, `selector_variables`, `cnf_sha256`, `binding`, `counts`, `work` and `seconds`. A clause is an array of signed nonzero native integer variable IDs. Variable IDs start at one. Each selector is `[cid, variable]`. The complete `variables` table records candidate, literal mark value or sequential-AMO prefix roles.

Each unfilled required point gets a candidate at-least-one clause and a linear sequential at-most-one encoding; a seed-filled point forbids every incident candidate. Each candidate implies every assigned mark-value variable. Different values at a marking point are at-most-one; there is no at-least-one mark clause. Seed marks are unit clauses. Missing means unconstrained, while the literal string `"0"` is an ordinary assigned value. A mark-only point participates globally even if it is not a root. Multiple consumers read the same value through one shared mark variable.

For a group of size greater than one, the sequential AMO uses at most one fewer auxiliary variables and a linear number of clauses. Existentially assigning prefix variables makes this equivalent to at-most-one. Thus selector projections preserve exactly the declared point-model solutions; arbitrary unneeded mark assignments add no selector solutions. No pairwise candidate-conflict matrix is constructed. This argument and Source review are distinct from empirical qualification of the encoder.

`binding.input_model_sha256` hashes the original supplied JSON. `model_sha256` and `universe_sha256` hash canonical sorted copies; the normalization is declared explicitly. `cnf_sha256` hashes canonical `{nvars, clauses}` plus LF. The caller must preserve exact encoded-file and selector-metadata byte pins as well as these content digests. A CNF certificate alone does not independently establish model-to-CNF equivalence.

Encoder defaults are `max_items=10000000`, `max_rows=100000`, `max_variables=1000000`, `max_clauses=3000000`, `max_literals=10000000`, `max_work=30000000`, `wall_seconds=30.0`.

## Optional reference solver and independent certificate gate

`solve` returns schema `Shared-fact-reference-DPLL-result-v1`, with `SAT`, `UNSAT`, `UNKNOWN` or `REJECTED_INPUT`. It scans clauses for units, branches on the smallest variable in the first remaining open clause and tries zero before one. It has no clause learning, watched literals, restarts or claim to represent modern SAT performance. It is a bounded reproducible reference control; a speed comparison against it alone cannot establish an advantage over established SAT methods.

SAT includes a full native integer bit assignment and selected CIDs; the caller must independently decode and native-B-check the resulting proof. Every result retains an explicit tree with unit reasons and conflict clause indices. An UNSAT internal node requires both Boolean branches to be UNSAT. Incomplete trees remain UNKNOWN. A final post-search wall refusal retains `saved_search_status` without promoting the result.

Solver defaults are `max_items=15000000`, `max_variables=1000000`, `max_clauses=3000000`, `max_nodes=100000`, `max_depth=128`, `max_work=10000000`, `wall_seconds=2.0`.

The independent module `reference/sat_certificate_checker_v1.py` imports no control/encoder/native module and exports:

```python
verify(encoded, result, limits=None)
```

Its `VERIFIED` receipt claims only SAT or UNSAT for the exact supplied CNF, after replaying all retained unit reasons/branches/conflicts and checking the full SAT assignment and selector projection. It never asserts native logical validity or model-to-CNF equivalence. Resource/search refusals remain UNKNOWN, malformed certificates are REJECTED. Checker defaults are `max_items=30000000`, `max_work=50000000`, `max_nodes=200000`, `max_depth=256`, `wall_seconds=30.0`. JSON serialization/hashing is cooperatively charged by input scans and final wall gates, not exact CPU-instruction metering.

## Required prospective qualification

Root should freeze all Sources/limits/declarations before any execution. Start with independent tiny Horn declarations rather than a supplied target proof. Compare forward existence, point search, tiny exhaustive point assignments and SAT selector solutions at the same line bound. In particular include no free facts, duplicate ZERO justifications, shared reads, inactive PAD, noncontiguous active slots, remote marking conflict, literal zero, target pin, unreachable goal and a true proof that needs more lines than the bound. A separate vacuous GEN fixture is required before claiming generic GEN integration; this Source alone does not qualify it.

For the encoder, compare selector projections against exhaustive point legality on tiny unit models, including shared multi-point candidates, mark-only conflicts, untouched zero roots, seed-filled roots, empty candidate domains and multiple literal values. Test sequential AMO groups of sizes zero, one, two and several; verify SAT/UNSAT certificates separately. Mutate unit reasons, conflict indices, omitted UNSAT branches, branch variables/values, assignment bits, selected IDs, clause/digest bindings and an UNKNOWN prefix. Resource fixtures must remain UNKNOWN. These are a future qualification plan, not executed evidence.
