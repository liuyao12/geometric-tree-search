"""Independent metadata/constraint admission for finite rooted unit CNFs.

No encoder/solver/adapter imports. Variable IDs are looked up by declared roles,
not recreated with the encoder's allocation procedure. Compare the full clause
multiset with exact cover, shared literal agreement and sequential AMO chains.
This supplies encoder association, separate from the CNF-result certificate.
"""
from collections import Counter
import hashlib
import json
import math
import time


def wire(x):
    return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def sha(x):return hashlib.sha256(wire(x)).hexdigest()


def verify(model,encoded,max_items=20000000,wall_seconds=30.0):
    started=time.perf_counter();items=0
    class Limit(Exception):pass
    def tick(n=1):
        nonlocal items
        items+=n
        if items>max_items or time.perf_counter()-started>wall_seconds:raise Limit()
    try:
        assert type(max_items) is int and 0<max_items<=100000000
        assert type(wall_seconds) in (int,float) and math.isfinite(wall_seconds) and 0<wall_seconds<=60
        for obj in (model,encoded):
            todo=[obj]
            while todo:
                x=todo.pop();tick()
                if type(x) is dict:todo.extend(x.keys());todo.extend(x.values())
                elif type(x) is list:todo.extend(x)
                elif type(x) is str:tick(len(x))
        assert model['schema']=='Z-growing-point-model-v1' and type(model['capacity']) is int and model['capacity']==1
        assert type(model['version']) is str and model['version']
        assert model['inventory']['kind']=='EXPLICIT' and encoded['status']=='ENCODED'
        assert encoded['schema']=='Shared-fact-point-CNF-v1'
        roots=sorted(model['roots']);assert all(type(p) is str for p in roots) and len(set(roots))==len(roots)
        rows=sorted((dict(id=r['id'],t=sorted(r['t']),m=sorted(r['m'])) for r in model['inventory']['placements']),key=lambda r:r['id'])
        assert all(type(r['id']) is str and r['id'] for r in rows)
        assert len({r['id'] for r in rows})==len(rows)
        st=sorted(model['seed']['t']);sm=sorted(model['seed']['m'])
        assert len(dict(st))==len(st) and len(dict(sm))==len(sm)
        assert all(type(p) is str and type(v) is int and v in (0,1) and (p in roots or v==0) for p,v in st)
        canonical=dict(model,roots=roots,seed=dict(t=st,m=sm),inventory=dict(kind='EXPLICIT',placements=rows))
        binding=encoded['binding']
        assert binding['input_model_sha256']==sha(model) and binding['model_sha256']==sha(canonical)
        assert binding['universe_sha256']==sha(rows) and binding['scope']=='EXPLICIT_FINITE_UNIT_CAPACITY_ALL_SUPPORT_ROOTED'
        variables=encoded['variables'];n=encoded['nvars']
        assert type(n) is int and n==len(variables)
        lookup={wire(role):i+1 for i,role in enumerate(variables)}
        assert len(lookup)==n
        used=set();wanted=[]
        def var(role):
            tick();v=lookup[wire(role)];used.add(v);return v
        def emit(*lits):tick(len(lits)+1);wanted.append(tuple(sorted(lits)))
        def amo(vs,kind,p):
            prefixes=[var(dict(kind='AMO_PREFIX',group=kind,point=p,index=i)) for i in range(len(vs)-1)] if len(vs)>1 else []
            for i,x in enumerate(vs):
                if i<len(vs)-1:emit(-x,prefixes[i])
                if i>0:emit(-x,-prefixes[i-1])
                if 0<i<len(vs)-1:emit(-prefixes[i-1],prefixes[i])
        incidence={p:[] for p in roots};marks={};selectors=[]
        for r in rows:
            x=var(dict(kind='CANDIDATE',cid=r['id']));selectors.append([r['id'],x])
            assert r['t'] and len(dict(r['t']))==len(r['t']) and len(dict(r['m']))==len(r['m'])
            for p,v in r['t']:
                assert type(p) is str and type(v) is int and v==1 and p in incidence;incidence[p].append(x)
            for p,v in r['m']:
                assert type(p) is str and type(v) is str;marks.setdefault(p,set()).add(v)
        for p,v in sm:
            assert type(p) is str and type(v) is str;marks.setdefault(p,set()).add(v)
        mv={(p,v):var(dict(kind='MARK_VALUE',point=p,value=v)) for p in marks for v in marks[p]}
        for p,xs in incidence.items():
            if dict(st).get(p,0)==1:
                for x in xs:emit(-x)
            else:wanted.append(tuple(sorted(xs)));amo(xs,'CAPACITY',p)
        for p in marks:amo([mv[p,v] for v in sorted(marks[p])],'MARK_AGREEMENT',p)
        for r,(cid,x) in zip(rows,selectors):
            for p,v in r['m']:emit(-x,mv[p,v])
        for p,v in sm:emit(mv[p,v])
        assert used==set(range(1,n+1)) and wire(encoded['selector_variables'])==wire(selectors)
        actual=[]
        for c in encoded['clauses']:
            tick(len(c)+1);assert type(c) is list and all(type(l) is int and 0<abs(l)<=n for l in c)
            actual.append(tuple(sorted(c)))
        assert Counter(actual)==Counter(wanted)
        assert encoded['cnf_sha256']==sha(dict(nvars=n,clauses=encoded['clauses']))
        tick()
        result=dict(status='VERIFIED',model_sha256=sha(model),cnf_sha256=encoded['cnf_sha256'],
            variables=n,clauses=len(actual),items=items,seconds=time.perf_counter()-started,
            scope='Complete selector/role association and clause multiset: exact unit root cover, global shared literal agreement, seed and existential sequential AMO. Native truth remains external.')
        tick()
        return result
    except Limit:return dict(status='UNKNOWN',items=items,reason='ADMISSION_RESOURCE_BOUND')
    except (MemoryError,RecursionError):return dict(status='UNKNOWN',items=items,reason='HOST_RESOURCE')
    except (AssertionError,KeyError,TypeError,ValueError,OverflowError):return dict(status='REJECTED',items=items)
