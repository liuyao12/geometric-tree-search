"""Independent saved-CNF DPLL certificate/assignment checker, stdlib only.

No encoder, solver, native logic, model adapter or proof search is imported.
VERIFIED authenticates only the exact supplied CNF certificate. Model-to-CNF
equivalence and native derivation validity remain separate external gates.
"""
import hashlib
import json
import math
import time

VERSION='Independent-shared-fact-CNF-certificate-v1'
DEFAULTS=dict(max_items=30000000,max_work=50000000,max_nodes=200000,max_depth=256,wall_seconds=30.0)


class Reject(Exception):pass
class Refuse(Exception):pass


def require(ok,reason):
    if not ok:raise Reject(reason)


def digest(value):
    encoder=json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
    h=hashlib.sha256()
    for block in encoder.iterencode(value):h.update(block.encode('ascii'))
    h.update(b'\n');return h.hexdigest()


def verify(encoded,result,limits=None):
    """Return VERIFIED / REJECTED / UNKNOWN, preserving every resource refusal.

    Verify all retained unit traces and children. Conflict leaves name a clause
    false under the replayed assignment; UNSAT splits require both Boolean
    children. SAT requires a satisfied leaf and a separately checked full model.
    UNKNOWN prefixes never prove UNSAT, even if all retained children failed.
    """
    start=time.perf_counter();work=items=nodes=0;settings=dict(DEFAULTS)
    counts=dict(units=0,conflicts=0,branches=0,sat_leaves=0,unknown_leaves=0)
    try:
        if limits is not None:
            require(type(limits) is dict and set(limits)<=set(settings),'LIMIT_FIELDS');settings.update(limits)
        for key,value in settings.items():
            if key=='wall_seconds':require(type(value) in (int,float) and math.isfinite(value) and value>0,'WALL_LIMIT')
            else:require(type(value) is int and value>0,'INTEGER_LIMIT:'+key)
        def charge(n=1):
            nonlocal work
            work+=n
            if work>settings['max_work']:raise Refuse('WORK_BOUND')
            if time.perf_counter()-start>settings['wall_seconds']:raise Refuse('WALL_BOUND')
        stack=[encoded,result]
        while stack:
            charge();items+=1
            if items>settings['max_items']:raise Refuse('ITEM_BOUND')
            value=stack.pop()
            if type(value) is dict:
                require(all(type(k) is str for k in value),'JSON_KEYS');stack.extend(value.keys());stack.extend(value.values())
            elif type(value) is list:stack.extend(value)
            elif type(value) is str:
                charge(len(value));items+=len(value)
                if items>settings['max_items']:raise Refuse('ITEM_BOUND')
            elif type(value) is float:require(math.isfinite(value),'JSON_FINITE_FLOAT')
            else:require(type(value) in (str,int,bool) or value is None,'NATIVE_JSON')
        require(type(encoded) is dict and type(result) is dict,'PACKET_OBJECTS')
        require(encoded.get('schema')=='Shared-fact-point-CNF-v1' and encoded.get('status')=='ENCODED','CNF_PACKET')
        n=encoded['nvars'];clauses=encoded['clauses']
        require(type(n) is int and n>=0 and type(clauses) is list,'CNF_SHAPE')
        for clause in clauses:
            charge();require(type(clause) is list,'CLAUSE_LIST')
            for literal in clause:require(type(literal) is int and 1<=abs(literal)<=n,'CNF_LITERAL')
        cnf_digest=digest(dict(nvars=n,clauses=clauses));charge()
        require(encoded['cnf_sha256']==result['cnf_sha256']==cnf_digest,'EXACT_CNF_BINDING')
        require(result['schema']=='Shared-fact-reference-DPLL-result-v1' and result['status'] in ('SAT','UNSAT','UNKNOWN'),'RESULT_SCHEMA')
        tree=result['certificate']
        if tree is None:
            require(result['status']=='UNKNOWN','MISSING_CERTIFICATE')
            return dict(status='UNKNOWN',version=VERSION,reason='NO_COMPLETE_CERTIFICATE',cnf_sha256=cnf_digest,counts=counts,work=work)
        def eval_clause(index,assignment):
            require(type(index) is int and 0<=index<len(clauses),'CLAUSE_INDEX')
            unknown=set()
            for literal in clauses[index]:
                charge();v=abs(literal)
                if v in assignment:
                    if assignment[v]==int(literal>0):return 'TRUE',set()
                else:unknown.add(literal)
            return ('OPEN' if unknown else 'FALSE'),unknown
        def replay(node,assignment,depth):
            nonlocal nodes
            charge();nodes+=1
            if nodes>settings['max_nodes']:raise Refuse('NODE_BOUND')
            if depth>settings['max_depth']:raise Refuse('DEPTH_BOUND')
            require(type(node) is dict and 'units' in node and 'outcome' in node,'CERTIFICATE_NODE')
            require(type(node['units']) is list and node['outcome'] in ('SAT','UNSAT','UNKNOWN'),'NODE_FIELDS')
            assignment=dict(assignment)
            for unit in node['units']:
                require(type(unit) is list and len(unit)==2,'UNIT_RECORD')
                literal,index=unit
                require(type(literal) is int and 1<=abs(literal)<=n and abs(literal) not in assignment,'UNIT_VARIABLE')
                state,unknown=eval_clause(index,assignment)
                require(state=='OPEN' and unknown=={literal},'UNIT_CLAUSE_REASON')
                assignment[abs(literal)]=int(literal>0);counts['units']+=1
            outcome=node['outcome']
            if 'branch' in node:
                allowed={'units','outcome','branch','children'}|({'limit'} if outcome=='UNKNOWN' else set())
                require(set(node)==allowed or (outcome=='UNKNOWN' and set(node)==allowed-{'limit'}),'BRANCH_FIELDS')
                v=node['branch'];children=node['children']
                require(type(v) is int and 1<=v<=n and v not in assignment,'BRANCH_VARIABLE')
                require(type(children) is list and len(children)<=2,'BRANCH_CHILDREN');counts['branches']+=1
                seen=set();child_results=[];sat_assignment=None
                for child in children:
                    require(type(child) is dict and set(child)=={'value','tree'},'CHILD_FIELDS')
                    value=child['value'];require(type(value) is int and value in (0,1) and value not in seen,'BOOLEAN_SPLIT')
                    seen.add(value);next_assignment=dict(assignment);next_assignment[v]=value
                    child_outcome,answer=replay(child['tree'],next_assignment,depth+1);child_results.append(child_outcome)
                    if child_outcome=='SAT':sat_assignment=answer
                if outcome=='UNSAT':require(seen=={0,1} and child_results==['UNSAT','UNSAT'],'COMPLETE_UNSAT_SPLIT')
                elif outcome=='SAT':require('SAT' in child_results,'SAT_BRANCH_WITNESS')
                else:
                    require(not (seen=={0,1} and child_results==['UNSAT','UNSAT']) and 'SAT' not in child_results,'UNKNOWN_NOT_TERMINAL_PROOF')
                    if 'limit' in node:require(type(node['limit']) is str and node['limit'],'UNKNOWN_LIMIT')
                return outcome,sat_assignment
            if outcome=='UNSAT':
                require(set(node)=={'units','outcome','conflict'},'CONFLICT_FIELDS')
                state,_=eval_clause(node['conflict'],assignment);require(state=='FALSE','CONFLICT_NOT_FALSE')
                counts['conflicts']+=1;return outcome,None
            if outcome=='SAT':
                require(set(node)=={'units','outcome'},'SAT_LEAF_FIELDS')
                for i in range(len(clauses)):require(eval_clause(i,assignment)[0]=='TRUE','SAT_LEAF_UNSATISFIED_CLAUSE')
                counts['sat_leaves']+=1;return outcome,assignment
            require(set(node)=={'units','outcome','limit'} and type(node['limit']) is str and node['limit'],'UNKNOWN_LEAF_FIELDS')
            counts['unknown_leaves']+=1;return outcome,None
        actual,path_assignment=replay(tree,{},0)
        if result['status']=='UNKNOWN':
            if actual!='UNKNOWN':require(result.get('saved_search_status')==actual,'POSTSEARCH_RESOURCE_DOWNGRADE_BINDING')
            charge()
            return dict(status='UNKNOWN',version=VERSION,reason='SEARCH_RESOURCE_REFUSAL',saved_tree_outcome=actual,
                cnf_sha256=cnf_digest,counts=counts,nodes=nodes,work=work,seconds=time.perf_counter()-start)
        require(actual==result['status'],'ROOT_OUTCOME')
        if actual=='SAT':
            full=result['assignment'];require(type(full) is list and len(full)==n,'FULL_ASSIGNMENT_LENGTH')
            require(all(type(value) is int and value in (0,1) for value in full),'FULL_ASSIGNMENT_BITS')
            require(all(full[v-1]==value for v,value in path_assignment.items()),'SAT_PATH_ASSIGNMENT_BINDING')
            for clause in clauses:
                charge(len(clause)+1);require(any(full[abs(lit)-1]==int(lit>0) for lit in clause),'FULL_MODEL_CLAUSE')
            require(result['assignment_sha256']==digest(full),'ASSIGNMENT_DIGEST')
            selectors=encoded['selector_variables'];seen_cid=set();seen_var=set();selected=[]
            for row in selectors:
                require(type(row) is list and len(row)==2,'SELECTOR_ROW');cid,v=row
                require(type(cid) is str and cid not in seen_cid and type(v) is int and 1<=v<=n and v not in seen_var,'SELECTOR_IDENTITY')
                seen_cid.add(cid);seen_var.add(v)
                if full[v-1]:selected.append(cid)
            require(result['selected']==sorted(selected),'SELECTED_CID_BINDING')
        certificate_sha=digest(tree);charge()
        return dict(status='VERIFIED',version=VERSION,claim=actual,cnf_sha256=cnf_digest,
            certificate_sha256=certificate_sha,counts=counts,nodes=nodes,work=work,seconds=time.perf_counter()-start,
            logical_validity='NOT_RUN',point_model_equivalence='CALLER_REQUIRES_SEPARATE_ENCODER_ADMISSION',
            scope='Exact CNF unit/branch/conflict replay and SAT assignment, not native logic or point-frontier conformance.')
    except (Refuse,MemoryError,RecursionError) as error:
        return dict(status='UNKNOWN',version=VERSION,reason=str(error) or type(error).__name__,counts=counts,
            nodes=nodes,work=work,seconds=time.perf_counter()-start)
    except (Reject,KeyError,TypeError,ValueError,OverflowError) as error:
        return dict(status='REJECTED',version=VERSION,reason=str(error) or type(error).__name__,counts=counts,nodes=nodes,work=work)
