# Independent shared-fact checker, version 1

The Source is `reference/shared_fact_checker_v1.py`. It imports only the standard library. It never imports or calls the catalogue/model adapter, engine, native kernel, SAT/forward controls, encoder or an earlier proof. Its author has performed Source inspection and AST parsing only. Root must review and qualify it before scientific use.

All public arguments before `*` are positional. The APIs are:

```text
verify_basis(case, catalogue, *, max_items=100000000,
             max_work=1000000000, wall_seconds=30.0)
verify_model(catalogue, prepared, *, same limits)
verify(case, catalogue, prepared, *, same limits)
decode(prepared, selected, *, same limits)
```

Verification receipts return `VERIFIED`, `REJECTED` or `UNKNOWN`. Successful decoding returns `UNVERIFIED_NATIVE_CERTIFICATE`; its result is a native certificate for a separate kernel check, not a logical-validity receipt. Every return includes `checker` and measured `checker_costs`. Invalid checker limit types/ranges reject. Exhausted checker work, wall, item, depth or allocation resources return `UNKNOWN`; no partially reconstructed table is admitted. Limits are cooperative, with a final gate after copying/hashing. An external process guard remains appropriate.

Canonical comparison preserves JSON types: compact ASCII JSON, sorted dictionary keys, and one final LF. Formula IDs are positive, ordered by that literal formula serialization; zero is reserved for PAD. No alpha-equivalence or substitution is introduced. The meter charges dictionary keys and complete literal strings before serialization; supplied native JSON is scanned before reconstruction. The complete prepared-universe cap is checked arithmetically before expected-row allocation, then every allowed reference tuple is actually enumerated and compared.

`verify_basis` independently reconstructs the entire `GROUND_HORN_SUBFORMULAS_V1` profile from the original case. The supported syntax is exactly predicate symbols of arity zero and implication; there is no additional syntactic Horn restriction. Every assumption/goal subformula is included, every named assumption ZERO is retained in sorted-name order, all structural MP definitions are enumerated, and GEN is absent. The complete case profile/defaults and provenance/declaration hash are bound. Case `schema` is optional to match the compiler; if present it must be `Shared-fact-proof-case-v1`. The declared case must contain `id`, `statement` and `profile`, and may not supply a proof/bank through the forbidden top-level input keys.

An unsupported independent formula/ZERO-generation profile returns `UNKNOWN` from `verify_basis`/`verify`. `verify_model` can still check a supplied generic finite catalogue conditionally: well-formed literal AST/signature/variable pool, closed assumption context, unique primitive ZERO payload IDs, exact structural MP, and every enabled GEN whose body/output belong to the finite registry. Every ZERO payload must separately pass native B; structural acceptance does not establish its truth or complete enumeration of a richer schema profile.

`verify_model` and `verify` reconstruct the scope preimage, binding, all definition tables, all owned rows, exact seed, explicit inventory and census. Every slot has all ZERO/PAD choices; MP uses every ordered pair of strictly earlier slots and GEN every earlier slot. Incompatible repeated receptor demands are counted and omitted as self-conflicts; they are not a search shortlist. Every candidate has its full remote active/formula support. Prepared limits and their fixed ceilings are checked. Measured timing values and the descriptive `admission` text are checked for shape/type rather than recomputed; all mathematical fields are compared exactly. No supplied count, hash or `complete` flag replaces whole enumeration.

For a complete selected assignment, `decode` reconstructs the model again, requires exactly one owner per explicit required slot, checks global seed/mark agreement, and maps active rows in increasing slot order. PAD is assigned zero and cannot satisfy a read. References must map to active strictly earlier native lines. The unchanged last-slot goal and whole original statement are retained.

The adapter and independent decoder may be compared on these semantic fields:

```text
statement, proof, slots, slot_to_native, native_to_slot,
reference_mapping, proof_dag, selected, selected_sha256,
original_statement_sha256, scope
```

`slots` uses integer active bits and `native_line_index_or_null`. All native line and slot references are zero based. `reference_mapping` has the adapter's named slot/native references; `proof_dag` contains `nodes` and `edges`. Receipt schema, diagnostics, costs and scope text need not match the adapter.

Essential prospective qualifications include omitted formula/assumption ZERO/MP/row with adjusted counts, wrong formula ID or scope, wrong owner/seed/active/PAD port, bool/float integer forgeries, shared compatible reads, remote conflicts, self/forward reads, referenced PAD, failed-branch restoration, and noncontiguous active-slot decoding. Add a closed quantified generic fixture for GEN separately. Tiny exhaustive assignment/trace checks and native B admission remain separate executions; this Source handoff claims none have run.

The reduction is a bounded anchored point model. It is not a translation-only Wang palette, unrestricted first-order completeness result, theorem-discovery result, full-frontier engine receipt, or performance comparison.
