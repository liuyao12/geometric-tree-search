"""Postrun raw/typed-data associations only; no project imports or calls."""
import json, hashlib, collections
from pathlib import Path
P=Path('/private/tmp/gcts-corner-family-factorization-20261027-v1'); A=P/'actual-v1'; R=P/'root'
def read(p): return json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes(); return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def canon(x): return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(x): return hashlib.sha256(canon(x)).hexdigest()
def ref(x): assert pin(Path(x['path']))==x
T=read(A/'custody-terminal.json'); S=read(A/'result.json'); plan=read(R/'corner-family-once-plan-v1.json'); owned=read(R/'corner-family-original-owned-tool-transport-v1.json')
assert owned['owned_session_id']==34412 and owned['terminal']['exit_code']==0
assert T['worker_returncode']==0 and T['status']=='COMPLETE_NORMAL_WORKER_REVIEW_PENDING' and T['scientific_admission'] is False
for x in T['artifacts']+[T[k] for k in ['authority','consume','plan','python','worker_result','worker_stdout','worker_stderr']]+list(T['role_pins'].values()): ref(x)
assert S['artifacts']==T['artifacts'] and S['role_pins']==T['role_pins']==plan['role_pins']
assert len(S['artifacts'])==61 and sum(x['bytes'] for x in S['artifacts'])==S['named_bytes_before_final_result']
assert S['named_bytes_before_final_result']+T['worker_result']['bytes']==T['named_worker_output_bytes']==167616315
assert len(list(A.iterdir()))==65 and T['worker_stderr']['bytes']==0
assert T['before_Popen_through_owned_wait_seconds']<720 and S['worker_main_entry_before_final_result_seconds']<600
assert T['owned_child_lifetime_RSS_highwater_bytes']==204800000<1610612736
assert T['worker_stdout']['bytes']+T['worker_stderr']['bytes']<1048576
assert T['cleanup']==[] and T['authenticated_worker_source_bytes_delivered']==37167
consume=read(Path(T['consume']['path'])); assert consume['child_started_at_consume'] is False and type(consume['uses']) is int and consume['uses']==1
C=read(A/'checked-label-catalogue.json'); I=read(A/'inputs.json'); assert digest(I['system'])==I['system_sha256']==C['system_sha256']
labels=[]; counts=collections.Counter(); nodehist=collections.Counter(); aliases=0
for di in range(4):
 for block in range(9):
  chunk=read(A/f'pair-labels-{di}-{block}.json'); assert chunk['system_sha256']==C['system_sha256']; assert len(chunk['records'])==(128 if block<8 else 65)
  for v in chunk['records']:
   i=len(labels); lab=v['label']; assert v['index']==i and lab==C['labels'][i] and v['direct_support']['status']==lab['status']; assert lab['proof_id']==f'PAIR_PROOF:{i}'
   labels.append(lab); counts[lab['status']]+=1
   assert digest(v['direct_support']['certificate'])==v['direct_support']['certificate_sha256']
   if lab['status']=='BASE_CONFLICT':
    assert v['point'] is None and v['csp'] is None
    continue
   pp=v['point']; cc=v['csp']; pr=pp['return']; cr=cc['return']; assert cc['spec_model_ref']=='point.return.model' and 'model' not in cc['spec_without_model']; spec=dict(cc['spec_without_model'],model=pr['model']); aliases+=1
   mh=digest(pr['model']); sh=digest(spec)
   assert mh==cr['model_sha256']==cc['certificate_check']['model_sha256']==cc['export_check']['model_sha256']==pp['independent_return_check']['model_sha256']
   assert sh==cr['spec_sha256']==cc['certificate_check']['spec_sha256']==cc['export_check']['spec_sha256']
   assert pr['status']==cr['status']==('FINITE_EXACT_SOLUTION' if lab['status']=='LOCAL_POSITIVE' else 'EXHAUSTED_FINITE_SEARCH')
   assert cc['certificate_check']['status']=='VERIFIED' and pp['independent_return_check']['status']=='VERIFIED'
   assert cr['certificate']['kind']==('SAT' if lab['status']=='LOCAL_POSITIVE' else 'UNSAT') and cr['certificate']['entry']==cr['context']==pr['context']
   assert pr['nodes']==cr['nodes']<=3 and pr['metrics']['backtracks']==0; nodehist[pr['nodes']]+=1
   assert pp['restored_entry_exact'] is True and cc['restored_entry_exact'] is True and pp['entry_sha256']==pp['restored_sha256']
   assert not pp['trace'] and not cc['trace'] and pp['search_window']['limit_seconds'] is None and cc['search_window']['limit_seconds'] is None
assert labels==C['labels'] and len(labels)==4356 and aliases==2577 and all(counts[k]==v for k,v in S['outcome']['counts'].items())
arr=read(A/'learning-arrivals.json'); running=collections.Counter(); neg=0
assert len(arr['events'])==4356
for i,(ev,lab) in enumerate(zip(arr['events'],labels)):
 running[lab['status']]+=1; neg+=lab['status']=='LOCAL_NEGATIVE'; assert ev['index']==i and ev['label']==lab and all(ev['counts'][k]==running[k] for k in ev['counts'])
 assert ev['provisional_channels']==neg and ev['provisional_assigned_components']==2*neg
 assert (ev['new_fragment'] is not None)==(lab['status']=='LOCAL_NEGATIVE')
 if ev['new_fragment'] is not None: assert ev['new_fragment']['label']==lab
F=read(A/'learned-marking.json'); audit=read(A/'marking-audit.json')
assert F['status']=='COMPLETE_COVER' and F['metrics']['final_channels']==len(F['marking']['channels'])==len(F['families'])==20
assert audit['observed_factor_callbacks']==F['metrics']['budget_callbacks']==738
assert audit['independent_factor_result']['status']=='VERIFIED' and audit['independent_factor_result']['catalogue_resolved'] is True
contact=audit['independent_actual_contacts']; assert contact==audit['independent_factor_result']['contact_check']; assert len(contact['induced_contacts'])==1746 and contact['assigned_components']==690
# Dedicated output canonically reorders slots/flips/names; not byte-identical to arrival fragments.
assert len(arr['final_provisional_channels'])==len(read(A/'dedicated-marking.json')['marking']['channels'])==1746
index=read(A/'benchmarks.json'); assert len(index['records'])==16 and len(index['comparisons'])==8; arms={}; rows=[]
for idx in index['records']:
 ref(idx['record']); d=read(Path(idx['record']['path'])); assert d['arm']==idx['arm'] and d['input']==idx['input']; v=d['data']; rr=v['return']; inp=d['input']; arms[(inp['width'],inp['steps'],inp['negative_final'],d['arm'])]=v
 assert v['restored_entry_exact'] is True
 if d['arm'].startswith('POINT'):
  assert v['entry_sha256']==v['restored_sha256'] and v['independent_return_check']['status']=='VERIFIED'; assert digest(rr['model'])==v['independent_return_check']['model_sha256']
 else:
  assert digest(v['spec'])==rr['spec_sha256']==v['certificate_check']['spec_sha256'] and digest(v['spec']['model'])==rr['model_sha256']; assert v['certificate_check']['status']=='VERIFIED'
  assert rr['certificate']['kind']==('INCOMPLETE' if rr['status']=='UNKNOWN' else 'SAT' if rr['status']=='FINITE_EXACT_SOLUTION' else 'UNSAT')
 w=v['search_window']; assert w['limit_seconds']==20 and w['triggered']==(inp['width']==9); assert not w['triggered'] or rr['status']=='UNKNOWN'
 rows.append(dict(width=inp['width'],height=inp['steps']+2,negative_final=inp['negative_final'],arm=d['arm'],status=rr['status'],nodes=rr['nodes'],branches=rr['metrics']['branch_decisions'],backtracks=rr['metrics']['backtracks'],forced=rr['metrics']['forced_placements'],window_triggered=w['triggered'],solve_return_seconds=w['solve_return_interval_seconds'],total_arm_seconds=v.get('elapsed_construction_solve_verify_cleanup',v.get('elapsed_export_construction_solve_verify_cleanup'))))
for comparison in index['comparisons']:
 pre=(comparison['width'],comparison['steps'],comparison['negative']); pp=arms[pre+(comparison['point_arm'],)]; cc=arms[pre+(comparison['csp_arm'],)]; assert pp['return']['model']==cc['spec']['model']
 pd=[{k:x[k] for k in ('kind','data','state_sha256','domains_sha256')} for x in pp['trace'] if x['kind']=='DECISION']; cd=[{k:x[k] for k in ('kind','data','state_sha256','domains_sha256')} for x in cc['trace'] if x['kind']=='DECISION']; n=min(len(pd),len(cd)); assert n==comparison['check']['common_decisions']>0 and pd[:n]==cd[:n]
 if not(pp['search_window']['triggered'] or cc['search_window']['triggered']): assert pp['trace']==cc['trace'] and pp['return']['status']==cc['return']['status'] and dict(pp['return']['metrics'],nodes=pp['return']['nodes'])==cc['return']['metrics']
oq=read(A/'qualification.json'); nq=read(A/'factorization-qualification.json'); assert oq['status']==nq['status']=='VERIFIED'
assert len(oq['paired_controls'])==26 and len(oq['B_negative_controls'])==32 and len(oq['C_controls'])==20
assert len(nq['normal_controls'])==12 and len(nq['malformed_controls'])==7 and len(nq['budget_exception_controls'])==3
for ctl in nq['normal_controls']:
 for call in ctl['calls']:
  assert call['independent_check']['status']=='VERIFIED' and call['result']['status']=='COMPLETE_COVER' and call['result']['metrics']['budget_callbacks']==call['observed_producer_budget_callbacks']; assert digest(call['catalogue'])==call['independent_check']['catalogue_sha256']
for v in nq['malformed_controls']: assert v['receipt']['status']=='EXPECTED_EXCEPTION'
for v in nq['budget_exception_controls']: assert v['receipt']['status']=='EXPECTED_EXCEPTION' and v['receipt']['same_object'] is True
out=dict(schema='Root-corner-family-whole-raw-structural-review-v1',status='FULL_RAW_STRUCTURAL_ASSOCIATIONS_PASS_INDEPENDENT_SCIENTIFIC_REVIEW_PENDING',owned_session_id=34412,terminal_exit=0,artifacts=[pin(f) for f in sorted(A.iterdir())],role_pins=T['role_pins'],counts=dict(counts),local_compatible_cases=aliases,local_full_returns=2*aliases,local_node_histogram=dict(nodehist),factor_metrics=F['metrics'],benchmark_rows=rows,comparison_profiles=index['comparisons'],resource_custody={k:T[k] for k in ['before_Popen_through_owned_wait_seconds','owned_child_lifetime_RSS_highwater_bytes','named_worker_output_bytes']},scope='Complete raw body hashes and typed same-record model alias reassembly, stored result/certificate/hash/trace/control associations only. No scientific helper/checker/solver/function/import replay. Source-authenticated once and independent whole review required for admission. Separate clocks and RSS retained without additive partition claims.')
f=R/'corner-family-Root-whole-raw-structural-review-v1.json'; b=(json.dumps(out,sort_keys=True,indent=2,allow_nan=False)+'\n').encode(); f.open('xb').write(b); assert f.read_bytes()==b
print(pin(f)); print('ALL_RAW_STRUCTURAL_CHECKS_PASS',dict(counts),len(rows))
