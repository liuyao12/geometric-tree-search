"""Inert bounded corner-mark learning experiment; reviewed once required.

This Source is an authoring draft until the complete public ABI and peer join.
It does not execute a scientific function when imported.  No STATE marking or
target witness is an input to the learner.  Rectangles are regions of unit cells.
"""
import argparse
import copy
import hashlib
import types
import json
import os
from pathlib import Path
import resource
import stat
import sys
import time

ROOT = Path('/private/tmp/gcts-corner-family-factorization-20261027-v1')
ACTUAL = ROOT / 'actual-v1'
SELF = ROOT / 'root/corner_family_worker_v1.py'
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
          'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
ROLES = {'point_engine': ROOT / 'reused-libraries/finite_point_engine_v1.py',
         'cell_csp': ROOT / 'reused-libraries/cell_csp_v1.py',
         'corner_learner': ROOT / 'reused-libraries/corner_marking_synthesis_v1.py',
         'independent_oracle': ROOT / 'reused-libraries/corner_learning_oracle_v3.py',
         'factorizer': ROOT / 'implementation-B/corner_family_factorization_v1.py',
         'factorization_qualification': ROOT / 'independent-L/factorization_qualification_v1.py',
         'worker': SELF, 'observer': ROOT / 'root/corner_family_once_observer_v1.py'}
D = ((1, 0), (0, 1), (1, 1), (-1, 1))
FRAME = ((-1, -1), (-1, 1), (1, -1), (1, 1))
CAPS = {'worker_main_entry_seconds': 600, 'observer_owned_wait_seconds': 720,
        'observed_worker_RSS_limit_bytes': 1610612736,
        'per_output_body_bytes': 67108864, 'named_output_aggregate_bytes': 268435456,
        'combined_worker_logs_bytes': 1048576,
        'per_label_node_limit': 8, 'per_benchmark_node_limit': 5000,
        'per_benchmark_search_window_seconds': 20}


class Refusal(RuntimeError):
    pass


class RunBudget(RuntimeError):
    pass


def need(ok, message):
    if not ok:
        raise Refusal(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'),
                       allow_nan=False) + '\n').encode()


def sha(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def strict(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def nonfinite(value):
        raise Refusal('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def raw(path, cap=67108864):
    need(path.is_absolute() and path.resolve() == path and
         all(not q.is_symlink() for q in (path, *path.parents)), 'canonical path')
    before = path.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= cap,
         'bounded single-link regular file')
    body = path.read_bytes()
    after = path.stat(follow_symlinks=False)
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) and
         len(body) == before.st_size, 'whole stable file')
    return body


def pin(path, body=None):
    if body is None:
        body = raw(path)
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def same(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return set(left) == set(right) and all(same(left[k], right[k]) for k in left)
    if type(left) is list:
        return len(left) == len(right) and all(same(a, b) for a, b in zip(left, right))
    return left == right


def ref(row, cap=67108864):
    need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'} and
         type(row['path']) is str and type(row['bytes']) is int and
         0 <= row['bytes'] <= cap and type(row['sha256']) is str and
         len(row['sha256']) == 64 and all(c in '0123456789abcdef' for c in row['sha256']),
         'exact bounded rawref3')
    path = Path(row['path'])
    body = raw(path, cap)
    need(same(pin(path, body), row), 'complete current rawref')
    return body


def verified(receipt):
    need(type(receipt) is dict and receipt.get('status') == 'VERIFIED',
         'independent check did not verify')
    return receipt


class Context:
    def __init__(self, plan, main_start):
        self.plan = plan
        self.start = main_start
        self.artifacts = []
        self.output_bytes = 0
        self.callbacks = 0

    def tick(self):
        self.callbacks += 1
        if time.perf_counter() - self.start > CAPS['worker_main_entry_seconds']:
            raise RunBudget('worker main-entry time ceiling')
        if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss > CAPS['observed_worker_RSS_limit_bytes']:
            raise RunBudget('observed worker lifetime RSS ceiling')
        logs = sum((ACTUAL / name).stat().st_size for name in ('worker-stdout.bin', 'worker-stderr.bin')
                   if (ACTUAL / name).exists())
        if logs > CAPS['combined_worker_logs_bytes']:
            raise RunBudget('combined worker logs ceiling')
        return None

    def log(self, phase, **data):
        self.tick()
        print(encoded({'phase': phase, 'elapsed_from_main': time.perf_counter() - self.start,
                       **data}).decode().rstrip(), flush=True)

    def write(self, name, value):
        self.tick()
        need('/' not in name and name.endswith('.json'), 'fixed output basename')
        body = encoded(value)
        if (len(body) > CAPS['per_output_body_bytes'] or
                self.output_bytes + len(body) > CAPS['named_output_aggregate_bytes']):
            raise RunBudget('named complete evidence byte ceiling')
        path = ACTUAL / name
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        need(raw(path) == body, 'complete output readback')
        result = pin(path, body)
        self.output_bytes += len(body)
        self.artifacts.append(result)
        self.tick()
        return result


def make_palette():
    alphabet = ('#', '0', '1')
    tiles = []
    for a in alphabet:
        for b in alphabet:
            for c in alphabet:
                out = '#' if b == '#' else ('1' if (a == '1') != (c == '1') else '0')
                tiles.append({'id': 'C:' + a + ':' + b + ':' + c, 'N': 'S:' + b,
                              'E': 'P:' + b + ':' + c, 'S': 'S:' + out,
                              'W': 'P:' + a + ':' + b})
    for s in alphabet:
        tiles.append({'id': 'I:' + s, 'N': 'I:' + s, 'E': 'ROW:TOP',
                      'S': 'S:' + s, 'W': 'ROW:TOP'})
        tiles.append({'id': 'O:' + s, 'N': 'S:' + s, 'E': 'ROW:BOT',
                      'S': 'O:' + s, 'W': 'ROW:BOT'})
    return sorted(tiles, key=lambda row: row['id'])


def placement_id(tile, x, y):
    return json.dumps(['WANG', tile, x, y], ensure_ascii=True, separators=(',', ':'))


def box(d):
    dx, dy = d
    return [[x, y] for x in range(min(0, dx), max(0, dx) + 1)
            for y in range(min(0, dy), max(0, dy) + 1)]


def problem(palette, width, steps, negative):
    initial = ['#'] + ['1' if i % 3 == 0 else '0' for i in range(width - 2)] + ['#']
    final = list(initial)
    for unused in range(steps):
        final = ['#'] + ['1' if (final[i - 1] == '1') != (final[i + 1] == '1') else '0'
                         for i in range(1, width - 1)] + ['#']
    if negative:
        i = width // 2
        final[i] = '0' if final[i] == '1' else '1'
    last = steps + 1
    region = [[x, y] for x in range(width) for y in range(last + 1)]
    boundary = [[x, 0, 'N', 'I:' + initial[x]] for x in range(width)]
    boundary += [[x, last, 'S', 'O:' + final[x]] for x in range(width)]
    for y in range(last + 1):
        color = 'ROW:TOP' if y == 0 else 'ROW:BOT' if y == last else 'P:#:#'
        boundary += [[0, y, 'W', color], [width - 1, y, 'E', color]]
    return {'width': width, 'steps': steps, 'initial': initial, 'final': final,
            'negative_final': negative, 'region': region, 'boundary': boundary}


def augment(model, marking):
    result = copy.deepcopy(model)
    maps = {}
    for channel in marking['channels']:
        for value, key in (('0', 'zeros'), ('1', 'ones')):
            for tile, x, y in channel[key]:
                maps.setdefault(tile, []).append([x, y, channel['id'], value])
    for row in result['placements']:
        identity = strict(row['type'].encode())
        if identity[0] == 'WANG':
            dx, dy = row['translation']
            row['m'] += [[x + dx, y + dy, channel, value]
                         for x, y, channel, value in maps.get(identity[1], [])]
            row['m'].sort(key=lambda term: (term[0], term[1], term[2]))
    return result


def digest_event(trace, kind, data, state):
    state_hash = sha(state)
    common_data = ({'restored_state_sha256': state_hash}
                   if kind == 'ROLLED_BACK' else copy.deepcopy(data))
    trace.append({'seq': len(trace), 'kind': kind, 'data': common_data,
                  'domains_sha256': sha(state['eligible_domains']),
                  'state_sha256': state_hash})


class SearchWindow:
    """Cooperative solve interval only; global budget always propagates."""
    def __init__(self, ctx, seconds, owned_exception):
        self.ctx, self.seconds, self.owned_exception = ctx, seconds, owned_exception
        self.started = None
        self.started_since_main = None
        self.triggered = False
        self.elapsed = None

    def tick(self):
        self.ctx.tick()
        if self.started is not None and time.perf_counter() - self.started > self.seconds:
            self.triggered = True
            raise self.owned_exception('ARM_SEARCH_WINDOW')
        return None

    def begin(self):
        if self.seconds is not None:
            self.started = time.perf_counter()
            self.started_since_main = self.started - self.ctx.start

    def close(self):
        if self.started is not None:
            self.elapsed = time.perf_counter() - self.started
        self.started = None

    def receipt(self):
        return {'limit_seconds': self.seconds, 'started_since_worker_main': self.started_since_main,
                'solve_return_interval_seconds': self.elapsed, 'triggered': self.triggered,
                'scope': 'Window begins immediately before solve; includes solve-time audit elapsed. Cooperative producer budget checkpoints only; an untriggered final audit may overrun. Construction/export/entry and post-return verification/cleanup/write are outside window, inside total arm/global budget.'}


def solve_point(ctx, E, O, model, node_limit, audit, search_seconds=None):
    trace = []
    window = SearchWindow(ctx, search_seconds, E.BudgetExceeded)
    def observe(engine, event):
        receipt = verified(O.verify_point_snapshot(model, engine.snapshot(), event, budget=ctx.tick))
        digest_event(trace, event['kind'], event['data'], receipt['normalized_state'])
    start = time.perf_counter()
    engine = E.Engine(model, audit=observe if audit else None, budget=window.tick)
    entry = engine.snapshot()
    checkpoint = engine.checkpoint()
    window.begin()
    try:
        result = engine.solve(node_limit=node_limit)
    finally:
        window.close()
    ctx.tick()
    need(not window.triggered or result['status'] == 'UNKNOWN', 'expired point window must withhold decisive result')
    result_check = verified(O.verify_point_result(model, result, budget=ctx.tick))
    final = engine.snapshot()
    checked = verified(O.verify_point_snapshot(model, final,
                       {'kind': 'SOLVE_RESULT', 'data': {'status': result['status'],
                        'reason': result['reason'], 'nodes': result['nodes']}}, budget=ctx.tick))
    solve_trace = copy.deepcopy(trace)
    if result['status'] == 'FINITE_EXACT_SOLUTION':
        engine.rollback(checkpoint)
    restored = engine.snapshot()
    need(same(restored, entry), 'point exact entry restoration')
    verified(O.verify_point_snapshot(model, restored, budget=ctx.tick))
    return {'return': result, 'entry_sha256': sha(entry), 'final_sha256': sha(final),
            'restored_sha256': sha(restored), 'restored_entry_exact': True,
            'trace': solve_trace, 'cleanup_trace': trace[len(solve_trace):],
            'independent_final_check': checked, 'independent_return_check': result_check,
            'search_window': window.receipt(),
            'elapsed_construction_solve_verify_cleanup': time.perf_counter() - start}


def solve_csp(ctx, B, O, model, node_limit, audit, search_seconds=None):
    trace = []
    window = SearchWindow(ctx, search_seconds, B.CSPBudgetExceeded)
    start = time.perf_counter()
    spec = B.export_unit_cell_csp(model)
    export_receipt = verified(O.verify_unit_cell_export(model, spec, budget=ctx.tick))
    def observe(engine, event):
        state = engine.snapshot()
        verified(O.verify_normalized_state(model, spec, state, budget=ctx.tick))
        digest_event(trace, event['kind'], event['data'], state)
    engine = B.CellCSP(spec, audit=observe if audit else None, budget=window.tick)
    entry = engine.snapshot()
    checkpoint = engine.checkpoint()
    window.begin()
    try:
        result = engine.solve(node_limit=node_limit)
    finally:
        window.close()
    ctx.tick()
    need(not window.triggered or result['status'] == 'UNKNOWN', 'expired CSP window must withhold decisive result')
    checked = verified(O.verify_unit_cell_result(model, spec, result, None, budget=ctx.tick))
    solve_trace = copy.deepcopy(trace)
    if result['status'] == 'FINITE_EXACT_SOLUTION':
        engine.rollback(checkpoint)
    restored = engine.snapshot()
    need(same(restored, entry), 'CSP exact entry restoration')
    verified(O.verify_normalized_state(model, spec, restored, budget=ctx.tick))
    return {'spec': spec, 'return': result, 'export_check': export_receipt,
            'certificate_check': checked, 'restored_entry_exact': True,
            'trace': solve_trace, 'cleanup_trace': trace[len(solve_trace):],
            'search_window': window.receipt(),
            'elapsed_export_construction_solve_verify_cleanup': time.perf_counter() - start}


def compare_pair(point, csp):
    p, c = point['return'], csp['return']
    interrupted = point['search_window']['triggered'] or csp['search_window']['triggered']
    pd = [ev for ev in point['trace'] if ev['kind'] == 'DECISION']
    cd = [ev for ev in csp['trace'] if ev['kind'] == 'DECISION']
    common = min(len(pd), len(cd))
    def decision_values(events):
        return [{key: ev[key] for key in ('kind', 'data', 'domains_sha256', 'state_sha256')}
                for ev in events]
    need(same(decision_values(pd[:common]), decision_values(cd[:common])), 'shared completed decision prefix mismatch')
    if not interrupted:
        need(same(point['trace'], csp['trace']) and p['status'] == c['status'] and p['nodes'] == c['nodes'],
             'uninterrupted full semantic trace/status/node mismatch')
        need(same(dict(p['metrics'], nodes=p['nodes']), c['metrics']), 'uninterrupted common metric mismatch')
    return {'mode': 'DECISION_PREFIX_ONLY' if interrupted else 'COMPLETE_SEMANTIC_TRACE',
            'point_decisions': len(pd), 'csp_decisions': len(cd), 'common_decisions': common,
            'overlap_vacuous': common == 0, 'all_common_decisions_equal': True,
            'full_trace_status_nodes_and_common_metrics_asserted': not interrupted,
            'point_window_triggered': point['search_window']['triggered'],
            'csp_window_triggered': csp['search_window']['triggered'],
            'scope': 'Wall-window cutoffs may differ. No equal-status/node/metric or speed claim follows from a shared decision prefix.'}


def labels_and_live_constraints(ctx, E, B, C, O, palette, system):
    tile_ids = [row['id'] for row in palette]
    labels, shards, progress, provisional = [], [], [], []
    counts = {key: 0 for key in ('BASE_CONFLICT', 'LOCAL_NEGATIVE', 'LOCAL_POSITIVE', 'UNKNOWN')}
    for di, d in enumerate(D):
        template = E.compile_wang(palette, box(d), None)
        chunk = []
        block = 0
        for a in tile_ids:
            for b in tile_ids:
                ctx.tick()
                rank = len(labels)
                direct = O.local_pair_check(palette, a, b, list(d), budget=ctx.tick)
                classification = direct['status']
                point = csp = model = None
                if classification != 'BASE_CONFLICT':
                    model = copy.deepcopy(template)
                    model['seeds'] = [placement_id(a, 0, 0), placement_id(b, *d)]
                    verified(O.verify_local_model(palette, a, b, list(d), model, budget=ctx.tick))
                    point = solve_point(ctx, E, O, model, CAPS['per_label_node_limit'], False)
                    csp = solve_csp(ctx, B, O, model, CAPS['per_label_node_limit'], False)
                    pr, cr = point['return'], csp['return']
                    need(pr['status'] == cr['status'] and pr['nodes'] == cr['nodes'],
                         'independent local search disagreement')
                    if pr['status'] == 'UNKNOWN':
                        classification = 'UNKNOWN'
                    else:
                        expected = ('LOCAL_POSITIVE' if pr['status'] == 'FINITE_EXACT_SOLUTION'
                                    else 'LOCAL_NEGATIVE')
                        need(classification == expected, 'direct local support disagreement')
                        need(pr['nodes'] <= 3 and pr['metrics']['backtracks'] == 0,
                             'local bbox paper bound contradicted')
                        if expected == 'LOCAL_POSITIVE':
                            need(pr['selected'] == cr['selected'], 'local witness order mismatch')
                    # Exact one-field alias: preserve every producer return and
                    # every spec field; the raw model already occurs in point.
                    need(same(csp['spec']['model'], point['return']['model']), 'typed spec model alias equality')
                    csp['spec_without_model'] = {k: v for k, v in csp.pop('spec').items() if k != 'model'}
                    csp['spec_model_ref'] = 'point.return.model'
                proof_id = None if classification == 'UNKNOWN' else 'PAIR_PROOF:' + str(rank)
                label = {'a': a, 'b': b, 'd': list(d), 'status': classification, 'proof_id': proof_id}
                counts[classification] += 1
                labels.append(label)
                addition = None
                if classification == 'LOCAL_NEGATIVE':
                    fragment = C.new_corner_fragment(tile_ids, label, budget=ctx.tick)
                    need(fragment['status'] == 'SINGLE_LABEL_FRAGMENT_CONSTRUCTED' and
                         fragment['label'] == label, 'fragment association')
                    verified(O.verify_corner_fragment(tile_ids, label, fragment, budget=ctx.tick))
                    addition = fragment
                    provisional.append(fragment['channel'])
                # Every arrival is retained, including an unchanged provisional
                # map. Only actual negative fragments add literal assignments.
                progress.append({'index': rank, 'label': label, 'counts': dict(counts),
                                 'new_fragment': addition,
                                 'provisional_channels': len(provisional),
                                 'provisional_assigned_components': 2 * len(provisional)})
                chunk.append({'index': rank, 'direct_support': direct, 'label': label,
                              'point': point, 'csp': csp})
                if len(chunk) == 128:
                    shards.append(ctx.write('pair-labels-' + str(di) + '-' + str(block) + '.json',
                        {'schema': 'GCTS-corner-local-label-chunk-v1', 'system_sha256': system,
                         'offset': list(d), 'records': chunk,
                         'spec_model_alias': 'Each csp.spec_without_model plus model=point.return.model exactly reconstructs original full spec.'}))
                    chunk = []
                    block += 1
                    ctx.log('LABEL_PROGRESS', completed=len(labels), counts=counts)
        if chunk:
            shards.append(ctx.write('pair-labels-' + str(di) + '-' + str(block) + '.json',
                {'schema': 'GCTS-corner-local-label-chunk-v1', 'system_sha256': system,
                 'offset': list(d), 'records': chunk,
                 'spec_model_alias': 'Each csp.spec_without_model plus model=point.return.model exactly reconstructs original full spec.'}))
    need(len(labels) == 4356, 'complete label census')
    catalogue = {'schema': 'GCTS-four-corner-checked-label-catalogue-v1',
                 'system_sha256': system, 'tile_ids': tile_ids, 'labels': labels}
    trace_ref = ctx.write('learning-arrivals.json',
        {'schema': 'GCTS-corner-live-dedicated-arrivals-v1', 'system_sha256': system,
         'events': progress, 'final_provisional_channels': provisional,
         'scope': 'Actual append-only dedicated provisional marks after every checked label; compact factorization follows once at complete catalogue.'})
    return catalogue, shards, trace_ref, counts


def run_study(ctx, modules):
    E, B, C, O, F, Q = [modules[key] for key in ('point_engine', 'cell_csp', 'corner_learner',
                           'independent_oracle', 'factorizer', 'factorization_qualification')]
    palette = make_palette()
    validated_palette = verified(O.validate_palette(palette, budget=ctx.tick))
    need(same(validated_palette['palette'], palette), 'canonical fixed palette')
    system_record = {'schema': 'GCTS-corner-free-rectangle-system-v1', 'palette': palette,
        'directions': {'N': [0, -1], 'E': [1, 0], 'S': [0, 1], 'W': [-1, 0]},
        'frame': [list(q) for q in FRAME], 'offsets': [list(d) for d in D],
        'translation_lattice': '2Z2', 'local_boundary': 'FREE_RECTANGLE'}
    system = sha(system_record)
    inputs_ref = ctx.write('inputs.json', {'system': system_record, 'system_sha256': system,
        'caps': CAPS, 'benchmark_panels': [[5, 2], [9, 6]],
        'learned_input_boundary': 'Opaque type IDs, geometry and current cold checked labels/proof IDs only; no palette colors, STATE, prior inventory or target witness.',
        'factorization_scope': 'Shared negative-contact bicliques; these are constraint factors, not tile clusters or proof-lemma inventories. No RL.'})
    ctx.log('QUALIFICATION_STARTED')
    qualification = verified(O.qualify_public_apis(palette, E, B, C, budget=ctx.tick))
    qualification_ref = ctx.write('qualification.json', qualification)
    factor_qualification = verified(Q.qualify_factorization(F, O.reconstruct_corner_contacts, budget=ctx.tick))
    factor_qualification_ref = ctx.write('factorization-qualification.json', factor_qualification)
    ctx.log('QUALIFICATION_COMPLETED')
    label_start = time.perf_counter()
    catalogue, label_refs, arrivals_ref, counts = labels_and_live_constraints(ctx, E, B, C, O, palette, system)
    label_elapsed = time.perf_counter() - label_start
    catalogue_ref = ctx.write('checked-label-catalogue.json', catalogue)
    if counts['UNKNOWN']:
        return {'activation': False, 'reason': 'UNRESOLVED_LABELS', 'inputs': inputs_ref,
                'qualification': qualification_ref, 'factor_qualification': factor_qualification_ref,
                'labels': label_refs, 'arrivals': arrivals_ref, 'catalogue': catalogue_ref,
                'counts': counts, 'label_elapsed': label_elapsed, 'dedicated': None,
                'synthesis': None, 'benchmarks': None, 'benchmark_arms': []}
    ctx.log('FACTORIZATION_STARTED', counts=counts)
    synthesis_start = time.perf_counter()
    dedicated = C.dedicated_corner_marking(catalogue, budget=ctx.tick)
    dedicated_ref = ctx.write('dedicated-marking.json', dedicated)
    dedicated_check = verified(O.verify_corner_result(catalogue, dedicated, budget=ctx.tick))
    need(dedicated_check['activation_allowed'] is True, 'dedicated complete contact cover')
    observed_factor_callbacks = 0
    def factor_budget():
        nonlocal observed_factor_callbacks
        observed_factor_callbacks += 1
        return ctx.tick()
    factor_start = time.perf_counter()
    learned = F.factor_corner_marking(catalogue, budget=factor_budget)
    factor_call_elapsed = time.perf_counter() - factor_start
    learned_ref = ctx.write('learned-marking.json', learned)
    need(learned['status'] == 'COMPLETE_COVER' and learned['metrics']['budget_callbacks'] == observed_factor_callbacks,
         'factor status and actual callback count')
    learned_check = verified(Q.verify_factorization_result(catalogue, learned,
                    O.reconstruct_corner_contacts, budget=ctx.tick))
    contacts = verified(O.reconstruct_corner_contacts(catalogue, learned['marking'], budget=ctx.tick))
    need(not contacts['missing_required_negatives'] and not contacts['uncertified_conflicts'] and
         contacts['channels'] <= 66 and len(contacts['induced_contacts']) == counts['LOCAL_NEGATIVE'] and
         all(row['status'] == 'LOCAL_NEGATIVE' for row in contacts['induced_contacts']),
         'exact independently reconstructed nonbase diagonal cover')
    audited = C.audit_corner_marking(catalogue, learned['marking'], budget=ctx.tick)
    verified(O.verify_corner_audit(catalogue, learned['marking'], audited, budget=ctx.tick))
    need(audited['wellformed'] is True and not audited['missing_required_negatives'] and
         not audited['uncertified_conflicts'], 'production audit of final literal map')
    synthesis_elapsed = time.perf_counter() - synthesis_start
    ctx.write('marking-audit.json', {'production': audited, 'independent_dedicated': dedicated_check,
              'independent_factor_result': learned_check, 'independent_actual_contacts': contacts,
              'observed_factor_callbacks': observed_factor_callbacks, 'factor_call_elapsed': factor_call_elapsed,
              'complete_synthesis_and_checks_elapsed': synthesis_elapsed})
    records, arm_refs, comparisons = [], [], []
    for width, steps in ((5, 2), (9, 6)):
        for negative in (False, True):
            specification = problem(palette, width, steps, negative)
            base = E.compile_wang(palette, specification['region'], specification['boundary'])
            marked = augment(base, learned['marking'])
            augmentation = verified(O.verify_corner_augmentation(base, marked, learned['marking'], budget=ctx.tick))
            paired = {}
            order = ('POINT_WANG', 'CSP_WANG', 'POINT_LEARNED', 'CSP_SAME_CONFLICTS')
            if negative:
                order = tuple(reversed(order))
            for arm in order:
                model = marked if arm in ('POINT_LEARNED', 'CSP_SAME_CONFLICTS') else base
                ctx.log('BENCHMARK_STARTED', width=width, steps=steps, negative=negative, arm=arm)
                data = (solve_point(ctx, E, O, model, CAPS['per_benchmark_node_limit'], True,
                                    CAPS['per_benchmark_search_window_seconds']) if arm.startswith('POINT') else
                        solve_csp(ctx, B, O, model, CAPS['per_benchmark_node_limit'], True,
                                  CAPS['per_benchmark_search_window_seconds']))
                row = {'input': specification, 'arm': arm, 'data': data,
                       'augmentation_check': augmentation if model is marked else None}
                name = 'benchmark-' + str(width) + '-' + str(steps) + '-' + ('negative' if negative else 'positive') + '-' + arm + '.json'
                arm_ref = ctx.write(name, row)
                arm_refs.append(arm_ref)
                records.append({'input': specification, 'arm': arm, 'record': arm_ref})
                paired[arm] = data
                ctx.log('BENCHMARK_SAVED', width=width, steps=steps, negative=negative, arm=arm,
                        result=data['return']['status'], nodes=data['return']['nodes'],
                        window_triggered=data['search_window']['triggered'])
            for pa, ca in (('POINT_WANG', 'CSP_WANG'), ('POINT_LEARNED', 'CSP_SAME_CONFLICTS')):
                comparisons.append({'width': width, 'steps': steps, 'negative': negative,
                    'point_arm': pa, 'csp_arm': ca, 'check': compare_pair(paired[pa], paired[ca])})
    benchmark_ref = ctx.write('benchmarks.json', {'schema': 'GCTS-corner-family-matched-benchmark-index-v1',
        'records': records, 'comparisons': comparisons,
        'evidence': 'Each full arm original return/spec/certificate/entry/final/digest trace written before next arm; index references those exact bodies. Full states checked at runtime; full snapshots retained only in qualification.',
        'same_information': 'Actual final literal maps supplied to both point and CSP, never stronger failure table.',
        'clock_scope': 'Per-arm timer includes construction/export/check/audit/cleanup, excludes that arm serialization/write. Search-window scope separately recorded. Whole main-entry clock includes all phases/writes; one process/frozen inventory shared explicitly. No cold-process or statistical speed claim.'})
    return {'activation': True, 'reason': 'COMPLETE_CERTIFIED_RECTANGLE_FACTOR_MARKING',
            'inputs': inputs_ref, 'qualification': qualification_ref,
            'factor_qualification': factor_qualification_ref, 'labels': label_refs,
            'arrivals': arrivals_ref, 'catalogue': catalogue_ref, 'counts': counts,
            'label_elapsed': label_elapsed, 'dedicated': dedicated_ref, 'synthesis': learned_ref,
            'factor_call_elapsed': factor_call_elapsed, 'synthesis_elapsed': synthesis_elapsed,
            'benchmarks': benchmark_ref, 'benchmark_arms': arm_refs}


def main():
    main_start = time.perf_counter()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--consume', required=True)
    args = parser.parse_args()
    ctx = None
    try:
        need(Path(__file__).resolve() == SELF and sys.platform == 'darwin' and
             sys.version_info[:3] == (3, 12, 14) and sys.flags.isolated and sys.flags.no_site
             and sys.dont_write_bytecode and sys.flags.optimize == 0 and __debug__ and
             Path(sys.executable).resolve() == Path(PYTHON['path']), 'fixed D90 -I-S-B runtime')
        ref(PYTHON, PYTHON['bytes'])
        plan_path, consume_path = Path(args.plan), Path(args.consume)
        need(plan_path.parent == ROOT / 'root' and plan_path.suffix == '.json', 'fixed Root plan')
        plan_raw = raw(plan_path, 1048576)
        plan = strict(plan_raw)
        need(type(plan) is dict and set(plan) == {'schema', 'run_id', 'role_pins', 'python', 'limits', 'actual_dir', 'source_contract', 'offer'}, 'plan exact8')
        need(plan['schema'] == 'GCTS-corner-family-once-plan-v1' and
             type(plan['run_id']) is str and plan['run_id'] and same(plan['python'], PYTHON)
             and same(plan['limits'], CAPS) and plan['actual_dir'] == str(ACTUAL), 'fixed typed plan')
        need(type(plan['role_pins']) is dict and set(plan['role_pins']) == set(ROLES), 'closed eight roles')
        source_bodies = {}
        for name, path in ROLES.items():
            source_bodies[name] = ref(plan['role_pins'][name], 2097152)
            need(plan['role_pins'][name]['path'] == str(path), 'fixed role address')
        ref(plan['source_contract'], 1048576)
        ref(plan['offer'], 1048576)
        consume_raw = raw(consume_path, 1048576)
        consume = strict(consume_raw)
        need(type(consume) is dict and set(consume) == {'schema', 'uses', 'authority', 'plan',
             'observer', 'python', 'child_started_at_consume'}, 'consume exact7')
        authority_raw = ref(consume['authority'], 1048576)
        authority_path = Path(consume['authority']['path'])
        authority = strict(authority_raw)
        need(authority_path.parent == ROOT / 'root' and authority_path.suffix == '.json' and
             authority_path != plan_path and consume_path == Path(str(authority_path) + '.CONSUMED.json'),
             'fixed authority and adjacent consumed marker')
        need(type(authority) is dict and set(authority) == {'schema', 'authorized', 'uses',
             'plan', 'observer', 'python'}, 'authority exact6')
        expected_authority = {'schema': 'GCTS-corner-family-once-authority-v1',
             'authorized': True, 'uses': 1, 'plan': pin(plan_path, plan_raw),
             'observer': plan['role_pins']['observer'], 'python': PYTHON}
        need(same(authority, expected_authority), 'complete typed authority association')
        expected_consume = {'schema': 'GCTS-corner-family-once-consumed-v1', 'uses': 1,
             'authority': pin(authority_path, authority_raw), 'plan': pin(plan_path, plan_raw),
             'observer': plan['role_pins']['observer'], 'python': PYTHON, 'child_started_at_consume': False}
        need(same(consume, expected_consume), 'complete typed consumed marker')
        need(ACTUAL.is_dir() and not ACTUAL.is_symlink(), 'observer-owned fresh output')
        ctx = Context(plan, main_start)
        modules = {}
        for name in ('point_engine', 'cell_csp', 'corner_learner', 'independent_oracle',
                     'factorizer', 'factorization_qualification'):
            module = types.ModuleType('gcts_corner_once_' + name)
            module.__file__ = str(ROLES[name])
            module.__package__ = None
            exec(compile(source_bodies[name], str(ROLES[name]), 'exec'), module.__dict__)
            modules[name] = module
        outcome = run_study(ctx, modules)
        for item in plan['role_pins'].values():
            ref(item, 2097152)
        ref(PYTHON, PYTHON['bytes'])
        ref(plan['source_contract'], 1048576)
        ref(plan['offer'], 1048576)
        need(raw(plan_path, 1048576) == plan_raw and raw(consume_path, 1048576) == consume_raw and
             raw(authority_path, 1048576) == authority_raw, 'complete direct metadata postguards')
        ctx.tick()
        result = {'schema': 'GCTS-corner-family-worker-result-v1', 'run_id': plan['run_id'],
                  'status': 'COMPLETE_BOUNDED_STUDY_REVIEW_PENDING', 'outcome': outcome,
                  'artifacts': list(ctx.artifacts), 'named_bytes_before_final_result': ctx.output_bytes,
                  'worker_main_entry_before_final_result_seconds': time.perf_counter() - ctx.start,
                  'worker_lifetime_RSS_bytes_at_sample': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  'budget_callbacks_at_sample': ctx.callbacks, 'role_pins': plan['role_pins'],
                  'clock_tail': 'Final result encoding/write/fsync/readback/hash, final source checks and shutdown follow this sample; no full-process lifetime claim.',
                  'claims': 'Finite rectangle-scoped cold learned literal factors and individually retained matched-control study only; no RL, infinite construction, Turtle/Penrose growth, universal palette or new mathematical theorem.'}
        result_pin = ctx.write('result.json', result)
        for item in plan['role_pins'].values():
            ref(item, 2097152)
        ref(PYTHON, PYTHON['bytes'])
        ref(plan['source_contract'], 1048576)
        ref(plan['offer'], 1048576)
        need(raw(plan_path, 1048576) == plan_raw and raw(consume_path, 1048576) == consume_raw and
             raw(authority_path, 1048576) == authority_raw, 'complete direct metadata postguards')
        print(encoded({'schema': 'GCTS-corner-family-worker-terminal-v1', 'status': 'COMPLETE',
                       'result': result_pin, 'actual_named_bytes': ctx.output_bytes}).decode().rstrip(), flush=True)
        return 0
    except BaseException as error:
        failure = {'schema': 'GCTS-corner-family-worker-terminal-v1', 'status': 'FAILED_UNADMITTED',
                   'error': type(error).__name__ + ': ' + str(error)[:2048],
                   'scientific_outcome_admitted': False,
                   'artifacts_so_far': [] if ctx is None else ctx.artifacts,
                   'scope': 'Spent once; no automatic retry or positive-prefix promotion.'}
        sys.stderr.buffer.write(encoded(failure))
        sys.stderr.buffer.flush()
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
