"""Inert one-child custody observer; no scientific imports or helper calls.

The separately reviewed plan/authority must bind the complete eight-role offer.
This observer can run once.  Failures remain spent, with all captured bytes.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess
import sys
import time

ROOT = Path('/private/tmp/gcts-corner-family-factorization-20261027-v1')
ACTUAL = ROOT / 'actual-v1'
SELF = ROOT / 'root/corner_family_once_observer_v2.py'
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
          'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
ROLES = {'point_engine': ROOT / 'reused-libraries/finite_point_engine_v1.py',
         'cell_csp': ROOT / 'reused-libraries/cell_csp_v1.py',
         'fragment_learner': ROOT / 'reused-libraries/corner_marking_synthesis_v1.py',
         'independent_oracle': ROOT / 'reused-libraries/corner_learning_oracle_v3.py',
         'factorizer': ROOT / 'implementation-B/corner_family_factorization_v1.py',
         'factorization_qualification': ROOT / 'independent-L/factorization_qualification_v1.py',
         'worker': ROOT / 'root/corner_family_worker_v2.py', 'observer': SELF}
CAPS = {'worker_main_entry_seconds': 600, 'observer_owned_wait_seconds': 720,
        'observed_worker_RSS_limit_bytes': 1610612736,
        'per_output_body_bytes': 67108864, 'named_output_aggregate_bytes': 268435456,
        'combined_worker_logs_bytes': 1048576,
        'per_label_node_limit': 8, 'per_benchmark_node_limit': 5000,
        'per_benchmark_search_window_seconds': 20}


# Closed stdlib bootstrap is part of this reviewed observer, not a seventh role.
BOOTSTRAP = "import hashlib,sys\np,n,h=sys.argv[1:4]\nn=int(n)\nb=sys.stdin.buffer.read(n+1)\nif len(b)!=n or hashlib.sha256(b).hexdigest()!=h:\n    raise SystemExit('authenticated Source body mismatch')\nsys.argv=[p]+sys.argv[4:]\ng={'__name__':'__main__','__file__':p,'__package__':None,'__cached__':None,'__builtins__':__builtins__}\nexec(compile(b,p,'exec'),g)\n"


class Refusal(RuntimeError):
    pass


def need(ok, message):
    if not ok:
        raise Refusal(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'),
                       allow_nan=False) + '\n').encode()


def strict(body):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def nonfinite(value):
        raise Refusal('nonfinite JSON')
    return json.loads(body, object_pairs_hook=pairs, parse_constant=nonfinite)


def raw(path, cap=67108864):
    need(path.is_absolute() and path.resolve() == path and
         all(not q.is_symlink() for q in (path, *path.parents)), 'canonical path')
    before = path.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= cap,
         'bounded single-link regular file')
    body = path.read_bytes()
    after = path.stat(follow_symlinks=False)
    need(len(body) == before.st_size and
         (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), 'stable whole read')
    return body


def pin(path, body=None):
    if body is None:
        body = raw(path)
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def same(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return set(left) == set(right) and all(same(left[k], right[k]) for k in left)
    if type(left) is list:
        return len(left) == len(right) and all(same(a, b) for a, b in zip(left, right))
    return left == right


def ref(row, cap=67108864):
    need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'} and
         type(row['path']) is str and type(row['bytes']) is int and
         0 <= row['bytes'] <= cap and type(row['sha256']) is str and
         len(row['sha256']) == 64 and all(c in '0123456789abcdef' for c in row['sha256']),
         'exact bounded rawref3')
    path = Path(row['path'])
    body = raw(path, cap)
    need(same(pin(path, body), row), 'complete current rawref')
    return body


def write(path, value):
    body = encoded(value)
    need(len(body) <= 1048576, 'observer metadata ceiling')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    need(raw(path, 1048576) == body, 'observer complete output readback')
    return pin(path, body)


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def main():
    main_start = time.perf_counter()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority', required=True)
    args = parser.parse_args()
    child = None
    returncode = None
    cleanup = []
    marker_pin = None
    try:
        need(Path(__file__).resolve() == SELF and sys.platform == 'darwin' and
             sys.version_info[:3] == (3, 12, 14) and sys.flags.isolated and sys.flags.no_site
             and sys.dont_write_bytecode and sys.flags.optimize == 0 and __debug__ and
             Path(sys.executable).resolve() == Path(PYTHON['path']), 'fixed D90 -I-S-B')
        ref(PYTHON, PYTHON['bytes'])
        pp, ap = Path(args.plan), Path(args.authority)
        need(pp.parent == ap.parent == ROOT / 'root' and pp != ap and
             pp.suffix == ap.suffix == '.json', 'distinct Root plan/authority')
        plan_raw, authority_raw = raw(pp, 1048576), raw(ap, 1048576)
        p, a = strict(plan_raw), strict(authority_raw)
        need(type(p) is dict and set(p) == {'schema', 'run_id', 'role_pins', 'python',
             'limits', 'actual_dir', 'source_contract', 'offer'}, 'plan exact8')
        need(p['schema'] == 'GCTS-corner-family-once-plan-v1' and
             type(p['run_id']) is str and p['run_id'] and same(p['python'], PYTHON) and
             same(p['limits'], CAPS) and p['actual_dir'] == str(ACTUAL), 'fixed plan semantics')
        need(type(a) is dict and set(a) == {'schema', 'authorized', 'uses', 'plan',
             'observer', 'python'}, 'authority exact6')
        need(a['schema'] == 'GCTS-corner-family-once-authority-v1' and
             a['authorized'] is True and type(a['uses']) is int and a['uses'] == 1 and
             same(a['plan'], pin(pp, plan_raw)) and same(a['python'], PYTHON) and
             same(a['observer'], p['role_pins']['observer']), 'fixed once authority')
        need(type(p['role_pins']) is dict and set(p['role_pins']) == set(ROLES), 'eight closed Source roles')
        source_bodies = {}
        for name, path in ROLES.items():
            source_bodies[name] = ref(p['role_pins'][name], 2097152)
            need(p['role_pins'][name]['path'] == str(path), 'exact role path')
        ref(p['source_contract'], 1048576)
        ref(p['offer'], 1048576)
        marker = Path(str(ap) + '.CONSUMED.json')
        need(not marker.exists() and not marker.is_symlink() and
             not ACTUAL.exists() and not ACTUAL.is_symlink(), 'fresh once paths')
        marker_pin = write(marker, {'schema': 'GCTS-corner-family-once-consumed-v1',
            'uses': 1, 'authority': pin(ap, authority_raw), 'plan': pin(pp, plan_raw),
            'observer': a['observer'], 'python': PYTHON,
            'child_started_at_consume': False})
        sync_directory(marker.parent)
        ACTUAL.mkdir(mode=0o700)
        stdout_path, stderr_path = ACTUAL / 'worker-stdout.bin', ACTUAL / 'worker-stderr.bin'
        so = os.open(stdout_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        se = os.open(stderr_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        command = [PYTHON['path'], '-I', '-S', '-B', '-c', BOOTSTRAP, str(ROLES['worker']),
                   str(len(source_bodies['worker'])), p['role_pins']['worker']['sha256'],
                   '--plan', str(pp), '--consume', str(marker)]
        launch_start = time.perf_counter()
        with os.fdopen(so, 'wb') as stdout, os.fdopen(se, 'wb') as stderr:
            child = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.PIPE,
                                     stdout=stdout, stderr=stderr, start_new_session=True)
            popen_return = time.perf_counter()
            os.set_blocking(child.stdin.fileno(), False)
            input_position = 0
            last_progress_size = -1
            while child.poll() is None:
                if input_position < len(source_bodies['worker']):
                    try:
                        input_position += os.write(child.stdin.fileno(),
                            source_bodies['worker'][input_position:input_position + 4096])
                    except BlockingIOError:
                        pass
                    if input_position == len(source_bodies['worker']):
                        child.stdin.close()
                logs = stdout_path.stat().st_size + stderr_path.stat().st_size
                need(logs <= CAPS['combined_worker_logs_bytes'], 'worker logs ceiling')
                need(time.perf_counter() - launch_start <= CAPS['observer_owned_wait_seconds'],
                     'owned launch/wait ceiling')
                if stdout_path.stat().st_size != last_progress_size:
                    last_progress_size = stdout_path.stat().st_size
                    print(encoded({'kind': 'WORKER_PROGRESS_BYTES', 'stdout_bytes': last_progress_size,
                                   'elapsed_since_before_Popen': time.perf_counter() - launch_start}).decode().rstrip(), flush=True)
                time.sleep(0.1)
            returncode = child.wait(timeout=1)
            owned_wait_end = time.perf_counter()
            child_rss = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
            need(input_position == len(source_bodies['worker']), 'complete authenticated Source delivery')
            need(child_rss <= CAPS['observed_worker_RSS_limit_bytes'], 'final observed child lifetime RSS ceiling')
            stdout.flush()
            stderr.flush()
            os.fsync(stdout.fileno())
            os.fsync(stderr.fileno())
        need(returncode == 0, 'worker did not complete normally')
        stdout_raw, stderr_raw = raw(stdout_path, 1048576), raw(stderr_path, 1048576)
        need(len(stdout_raw) + len(stderr_raw) <= CAPS['combined_worker_logs_bytes'] and
             not stderr_raw, 'whole worker captures')
        lines = stdout_raw.splitlines()
        need(lines, 'worker terminal absent')
        terminal = strict(lines[-1])
        need(type(terminal) is dict and set(terminal) == {'schema', 'status', 'result', 'actual_named_bytes'} and
             type(terminal['actual_named_bytes']) is int and terminal['actual_named_bytes'] >= 0 and
             terminal['schema'] == 'GCTS-corner-family-worker-terminal-v1' and
             terminal['status'] == 'COMPLETE' and
             terminal['result']['path'] == str(ACTUAL / 'result.json'), 'worker terminal exact4')
        result_raw = ref(terminal['result'])
        result = strict(result_raw)
        need(result['schema'] == 'GCTS-corner-family-worker-result-v1' and
             result['run_id'] == p['run_id'] and
             result['status'] == 'COMPLETE_BOUNDED_STUDY_REVIEW_PENDING' and
             same(result['role_pins'], p['role_pins']), 'complete worker result association')
        originals = result['artifacts']
        need(type(originals) is list and len(originals) < 64, 'bounded named artifact list')
        seen = set()
        total = 0
        for row in originals:
            path = Path(row['path'])
            need(path.parent == ACTUAL and path.suffix == '.json' and path.name not in seen
                 and path.name != 'result.json', 'unique direct output artifact')
            seen.add(path.name)
            ref(row)
            total += row['bytes']
        need(type(result['named_bytes_before_final_result']) is int and
             total == result['named_bytes_before_final_result'] and
             total + len(result_raw) == terminal['actual_named_bytes'] and
             total + len(result_raw) <= CAPS['named_output_aggregate_bytes'], 'complete named byte census')
        need({q.name for q in ACTUAL.iterdir()} == seen | {'result.json', 'worker-stdout.bin', 'worker-stderr.bin'},
             'exact physical output census before observer receipt')
        outcome = result['outcome']
        need(type(outcome['activation']) is bool and type(outcome['counts']) is dict and
             set(outcome['counts']) == {'BASE_CONFLICT', 'LOCAL_NEGATIVE', 'LOCAL_POSITIVE', 'UNKNOWN'} and
             all(type(v) is int and v >= 0 for v in outcome['counts'].values()) and
             sum(outcome['counts'].values()) == 4356 and
             len(outcome['labels']) == 36 and outcome['qualification'] in originals and
             all(item in originals for item in outcome['labels']), 'complete scientific input/output census')
        need(outcome['factor_qualification'] in originals, 'new factor qualification full artifact')
        if outcome['activation']:
            need(type(outcome['benchmark_arms']) is list and len(outcome['benchmark_arms']) == 16 and
                 all(item in originals for item in outcome['benchmark_arms']) and
                 outcome['benchmarks'] in originals, 'all16 full benchmark bodies and complete index')
        else:
            need(outcome['benchmark_arms'] == [] and outcome['benchmarks'] is None,
                 'unresolved catalogue cannot activate benchmark study')
        for item in p['role_pins'].values():
            ref(item, 2097152)
        ref(PYTHON, PYTHON['bytes'])
        ref(p['source_contract'], 1048576)
        ref(p['offer'], 1048576)
        need(raw(pp, 1048576) == plan_raw and raw(ap, 1048576) == authority_raw and
             ref(marker_pin) == encoded(strict(ref(marker_pin))), 'whole guard postchecks')
        receipt = {'schema': 'GCTS-corner-family-custody-terminal-v1',
            'status': 'COMPLETE_NORMAL_WORKER_REVIEW_PENDING', 'run_id': p['run_id'],
            'plan': pin(pp, plan_raw), 'authority': pin(ap, authority_raw), 'consume': marker_pin,
            'role_pins': p['role_pins'], 'python': PYTHON, 'command': command,
            'owned_worker_pid': child.pid, 'worker_returncode': returncode,
            'worker_stdout': pin(stdout_path, stdout_raw), 'worker_stderr': pin(stderr_path, stderr_raw),
            'worker_result': terminal['result'], 'artifacts': originals,
            'named_worker_output_bytes': terminal['actual_named_bytes'],
            'Popen_call_seconds': popen_return - launch_start,
            'before_Popen_through_owned_wait_seconds': owned_wait_end - launch_start,
            'after_Popen_return_through_owned_wait_seconds': owned_wait_end - popen_return,
            'observer_main_entry_before_final_receipt_seconds': time.perf_counter() - main_start,
            'owned_child_lifetime_RSS_highwater_bytes': child_rss,
            'RSS_scope': 'Darwin bytes from RUSAGE_CHILDREN after wait; fresh observer launched exactly one child. Observed lifetime high-water gate, not a hard allocation quota.',
            'authenticated_worker_source_bytes_delivered': input_position,
            'owned_process_group': child.pid,
            'observer_lifetime_RSS_highwater_bytes_at_sample': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'all_full_raw_guards_matched': True,
            'clock_tail': 'Observer final receipt encoding/write/fsync/readback/hash/directorysync/stdout/shutdown follow the sample; no hard RSS/process-tree quota or streaming bound is claimed.',
            'scientific_admission': False, 'cleanup': cleanup,
            'scope': 'One exact child and complete raw artifacts only. Independent whole scientific review/admission and publication are separate; no positive prefix or retry.'}
        write(ACTUAL / 'custody-terminal.json', receipt)
        sync_directory(ACTUAL)
        sys.stdout.buffer.write(encoded(receipt))
        sys.stdout.buffer.flush()
        return 0
    except BaseException as error:
        if child is not None and child.stdin is not None and not child.stdin.closed:
            child.stdin.close()
        if child is not None and child.poll() is None:
            try:
                os.killpg(child.pid, signal.SIGTERM)
                cleanup.append('TERM_OWNED_PROCESS_GROUP')
            except ProcessLookupError:
                cleanup.append('OWNED_GROUP_ALREADY_ABSENT')
            try:
                returncode = child.wait(timeout=5)
                cleanup.append('OWNED_WAIT_AFTER_TERM')
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                    cleanup.append('KILL_OWNED_PROCESS_GROUP')
                except ProcessLookupError:
                    cleanup.append('OWNED_GROUP_ALREADY_ABSENT')
                try:
                    returncode = child.wait(timeout=5)
                    cleanup.append('OWNED_WAIT_AFTER_KILL')
                except subprocess.TimeoutExpired:
                    cleanup.append('OWNED_WAIT_UNCONFIRMED_NO_QUIESCENCE_CLAIM')
        failure = {'schema': 'GCTS-corner-family-custody-terminal-v1',
                   'status': 'FAILED_UNADMITTED_NO_AUTOMATIC_RETRY',
                   'error': type(error).__name__ + ': ' + str(error)[:2048],
                   'consume': marker_pin, 'worker_returncode': returncode,
                   'cleanup': cleanup, 'scientific_admission': False,
                   'scope': 'Authority/consume/partial artifacts remain spent; no positive-prefix admission.'}
        sys.stderr.buffer.write(encoded(failure))
        sys.stderr.buffer.flush()
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
