"""Pure diagonal negative-family factorization; Source only until reviewed once.

No imports, palette colors, solver, prior inventory, IO or CLI.  Each emitted
channel occupies one opposite-corner pair and covers an original-negative
biclique.  Missing components stay absent; zero/one polarities are literals.
"""

VERSION = "GCTS-corner-family-factorization-v1"
_OFFSETS = ((1, 0), (0, 1), (1, 1), (-1, 1))
_DIAGONALS = ((1, 1), (-1, 1))
_FRAME = ((-1, -1), (-1, 1), (1, -1), (1, 1))
_STATUSES = ("BASE_CONFLICT", "LOCAL_NEGATIVE", "LOCAL_POSITIVE", "UNKNOWN")
_ALL = (1 << 33) - 1
_METRICS = (
    "catalogue_rows", "base_conflict_labels", "local_positive_labels",
    "unknown_labels", "required_negative_classes", "matrix_edge_insertions",
    "families_emitted", "seed_row_tests", "column_intersections",
    "row_intersections", "covered_pair_visits", "newly_covered_classes",
    "removal_row_updates", "assigned_components", "distinct_prototype_points",
    "final_contact_classes", "final_channels", "budget_callbacks",
)


class FactorCatalogueError(ValueError):
    """Malformed catalogue; one fixed public code as the sole message."""


class FactorBudgetExceeded(RuntimeError):
    """Callback-owned cooperative stop; always propagates without a result."""


def _record(value, fields):
    return (type(value) is dict and all(type(key) is str for key in value)
            and set(value) == set(fields))


def _catalogue(value):
    """Validate all structure, then coverage, then proof/status association."""
    shape = "CORNER_INPUT_SHAPE"
    if not _record(value, ("schema", "system_sha256", "tile_ids", "labels")):
        raise FactorCatalogueError(shape)
    if (type(value["schema"]) is not str
            or value["schema"] != "GCTS-four-corner-checked-label-catalogue-v1"
            or type(value["system_sha256"]) is not str
            or len(value["system_sha256"]) != 64
            or any(c not in "0123456789abcdef" for c in value["system_sha256"])
            or type(value["tile_ids"]) is not list
            or len(value["tile_ids"]) != 33
            or any(type(t) is not str or not t for t in value["tile_ids"])
            or len(set(value["tile_ids"])) != 33
            or value["tile_ids"] != sorted(value["tile_ids"])
            or type(value["labels"]) is not list):
        raise FactorCatalogueError(shape)
    ids = tuple(value["tile_ids"])
    known = set(ids)
    for row in value["labels"]:
        if not _record(row, ("a", "b", "d", "status", "proof_id")):
            raise FactorCatalogueError(shape)
        if (type(row["a"]) is not str or row["a"] not in known
                or type(row["b"]) is not str or row["b"] not in known
                or type(row["d"]) is not list or len(row["d"]) != 2
                or any(type(c) is not int for c in row["d"])
                or type(row["status"]) is not str or row["status"] not in _STATUSES
                or (row["proof_id"] is not None and type(row["proof_id"]) is not str)):
            raise FactorCatalogueError(shape)
    if len(value["labels"]) != 4356:
        raise FactorCatalogueError("CORNER_CATALOGUE_COVERAGE")
    for rank, row in enumerate(value["labels"]):
        direction, residual = divmod(rank, 1089)
        left, right = divmod(residual, 33)
        if (tuple(row["d"]) != _OFFSETS[direction]
                or row["a"] != ids[left] or row["b"] != ids[right]):
            raise FactorCatalogueError("CORNER_CATALOGUE_COVERAGE")
    for row in value["labels"]:
        status, proof = row["status"], row["proof_id"]
        associated = (proof is None if status == "UNKNOWN" else
                      type(proof) is str and bool(proof))
        if (not associated
                or (status == "LOCAL_NEGATIVE" and tuple(row["d"]) not in _DIAGONALS)
                or (status == "BASE_CONFLICT" and tuple(row["d"]) not in _OFFSETS[:2])):
            raise FactorCatalogueError("CORNER_LABEL_ASSOCIATION")
    return {"ids": ids, "system": value["system_sha256"],
            "statuses": tuple(row["status"] for row in value["labels"]),
            "proofs": tuple(row["proof_id"] for row in value["labels"])}


def _tick(metrics, budget):
    if budget is not None:
        metrics["budget_callbacks"] += 1
        budget()


def _indices(bits):
    result = []
    while bits:
        low = bits & -bits
        result.append(low.bit_length() - 1)
        bits -= low
    return tuple(result)


def _invariant(ok):
    if not ok:
        raise RuntimeError("factorization invariant failed")


def _metrics(ctx):
    result = {key: 0 for key in _METRICS}
    result["catalogue_rows"] = len(ctx["statuses"])
    result["base_conflict_labels"] = ctx["statuses"].count("BASE_CONFLICT")
    result["local_positive_labels"] = ctx["statuses"].count("LOCAL_POSITIVE")
    result["unknown_labels"] = ctx["statuses"].count("UNKNOWN")
    result["required_negative_classes"] = ctx["statuses"].count("LOCAL_NEGATIVE")
    return result


def _matrices(ctx, metrics):
    rows = [[0 for _ in range(33)] for _ in _DIAGONALS]
    columns = [[0 for _ in range(33)] for _ in _DIAGONALS]
    for direction in range(2):
        for left in range(33):
            for right in range(33):
                rank = (direction + 2) * 1089 + left * 33 + right
                if ctx["statuses"][rank] == "LOCAL_NEGATIVE":
                    rows[direction][left] |= 1 << right
                    columns[direction][right] |= 1 << left
                    metrics["matrix_edge_insertions"] += 1
    _invariant(metrics["matrix_edge_insertions"] == metrics["required_negative_classes"])
    return (tuple(tuple(row) for row in rows),
            tuple(tuple(column) for column in columns))


def _choose(uncovered, metrics):
    selected = None
    degree = 0
    for index, neighbors in enumerate(uncovered):
        metrics["seed_row_tests"] += 1
        count = neighbors.bit_count()
        if count > degree:
            selected, degree = index, count
    return selected


def _closure(original_rows, original_columns, seed_columns, metrics, budget):
    zero_types = _ALL
    for column in _indices(seed_columns):
        _tick(metrics, budget)
        metrics["column_intersections"] += 1
        zero_types &= original_columns[column]
    _invariant(zero_types != 0)
    one_types = _ALL
    for row in _indices(zero_types):
        _tick(metrics, budget)
        metrics["row_intersections"] += 1
        one_types &= original_rows[row]
    _invariant(one_types != 0 and seed_columns & one_types == seed_columns)
    return zero_types, one_types


def _label_id(rank):
    return "CORNER_PAIR:" + str(rank)


def _cover(direction, zero_types, one_types, original_rows, uncovered,
           covered_classes, metrics, budget):
    covered, newly_covered = [], []
    for row in _indices(zero_types):
        for column in _indices(one_types):
            metrics["covered_pair_visits"] += 1
            if metrics["covered_pair_visits"] % 1024 == 0:
                _tick(metrics, budget)
            bit = 1 << column
            _invariant(original_rows[row] & bit)
            rank = (direction + 2) * 1089 + row * 33 + column
            covered.append(_label_id(rank))
            covered_classes.add(rank)
            if uncovered[row] & bit:
                newly_covered.append(_label_id(rank))
        uncovered[row] &= ~one_types
        metrics["removal_row_updates"] += 1
    metrics["newly_covered_classes"] += len(newly_covered)
    return covered, newly_covered


def _type_rows(ctx, mask, point):
    return [[ctx["ids"][index], point[0], point[1]] for index in _indices(mask)]


def _channel_key(family):
    direction, zero_types, one_types, unused_index = family
    point = _DIAGONALS[direction]
    other = (-point[0], -point[1])
    zi, oi = _FRAME.index(point), _FRAME.index(other)
    return (tuple(4 * i + zi for i in _indices(zero_types)),
            tuple(4 * i + oi for i in _indices(one_types)))


def _marking(ctx, raw_families, trace, metrics):
    ordered = sorted(raw_families, key=_channel_key)
    keys = [_channel_key(family) for family in ordered]
    _invariant(len(set(keys)) == len(keys))
    channels = []
    for index, (direction, zero_types, one_types, family_index) in enumerate(ordered):
        point = _DIAGONALS[direction]
        opposite = (-point[0], -point[1])
        channel_id = "LEARNED_CORNER:" + str(index)
        channels.append({"id": channel_id, "zeros": _type_rows(ctx, zero_types, point),
                         "ones": _type_rows(ctx, one_types, opposite)})
        trace[family_index]["channel_id"] = channel_id
    metrics["final_channels"] = len(channels)
    metrics["assigned_components"] = sum(len(c["zeros"]) + len(c["ones"]) for c in channels)
    metrics["distinct_prototype_points"] = len({tuple(row) for c in channels
                                               for field in ("zeros", "ones") for row in c[field]})
    return {"schema": "GCTS-four-corner-partial-binary-marking-v1",
            "system_sha256": ctx["system"], "channels": channels}


def factor_corner_marking(catalogue, *, budget=None):
    """Cover all asserted diagonal negatives with at most 66 safe families.

    Certificate truth and activation are external gates.  Budget and unrelated
    exceptions propagate: no partial map, old greedy fallback or retry occurs.
    """
    ctx = _catalogue(catalogue)
    if budget is not None and not callable(budget):
        raise TypeError("budget must be callable or None")
    metrics = _metrics(ctx)
    _tick(metrics, budget)
    original_rows, original_columns = _matrices(ctx, metrics)
    remaining_total = metrics["required_negative_classes"]
    covered_classes = set()
    raw_families, trace = [], []
    for direction, displacement in enumerate(_DIAGONALS):
        uncovered = list(original_rows[direction])
        remaining = sum(row.bit_count() for row in uncovered)
        selected_rows = set()
        while True:
            _tick(metrics, budget)
            seed = _choose(uncovered, metrics)
            if seed is None:
                break
            _invariant(seed not in selected_rows)
            seed_columns = uncovered[seed]
            zero_types, one_types = _closure(original_rows[direction], original_columns[direction],
                                            seed_columns, metrics, budget)
            _invariant(zero_types & (1 << seed))
            _tick(metrics, budget)
            covered, newly = _cover(direction, zero_types, one_types, original_rows[direction],
                                    uncovered, covered_classes, metrics, budget)
            _invariant(newly and uncovered[seed] == 0)
            selected_rows.add(seed)
            remaining -= len(newly)
            remaining_total -= len(newly)
            _invariant(remaining >= 0 and remaining_total >= 0 and len(selected_rows) <= 33)
            family_index = len(trace)
            trace.append({"family_index": family_index, "channel_id": None,
                          "d": list(displacement), "seed_row": ctx["ids"][seed],
                          "seed_columns": [ctx["ids"][i] for i in _indices(seed_columns)],
                          "Z": [ctx["ids"][i] for i in _indices(zero_types)],
                          "O": [ctx["ids"][i] for i in _indices(one_types)],
                          "covered_label_ids": covered, "newly_covered_label_ids": newly,
                          "remaining_negative_count": remaining,
                          "remaining_total_negative_count": remaining_total})
            raw_families.append((direction, zero_types, one_types, family_index))
            metrics["families_emitted"] += 1
        _invariant(remaining == 0 and all(row == 0 for row in uncovered))
    marking = _marking(ctx, raw_families, trace, metrics)
    metrics["final_contact_classes"] = len(covered_classes)
    _invariant(remaining_total == 0 and len(trace) <= 66
               and metrics["families_emitted"] == metrics["final_channels"]
               and metrics["newly_covered_classes"] == metrics["required_negative_classes"]
               and metrics["final_contact_classes"] == metrics["required_negative_classes"])
    _tick(metrics, budget)
    return {"schema": "GCTS-four-corner-family-factorization-result-v1",
            "system_sha256": ctx["system"], "status": "COMPLETE_COVER",
            "marking": marking, "metrics": dict(metrics), "families": trace}
