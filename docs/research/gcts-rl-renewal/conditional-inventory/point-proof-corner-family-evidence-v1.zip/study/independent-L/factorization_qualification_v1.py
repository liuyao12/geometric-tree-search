"""Independent family-factorization checks; Source-only until a reviewed once.

No producer/oracle import, IO, CLI, palette, prior label/map or target witness.
The verifier uses Python sets, independently reconstructs the full declared
family trace, and calls only an explicitly supplied contact checker. Synthetic
qualification data is constructed only when the public qualification is called
inside a later authorized once. No model, search engine or solver is created.
"""
import copy
import hashlib
import json

VERSION = 'GCTS-corner-family-independent-qualification-v1'
D = ((1, 0), (0, 1), (1, 1), (-1, 1))
FRAME = ((-1, -1), (-1, 1), (1, -1), (1, 1))
METRICS = ('catalogue_rows', 'base_conflict_labels', 'local_positive_labels',
           'unknown_labels', 'required_negative_classes', 'matrix_edge_insertions',
           'families_emitted', 'seed_row_tests', 'column_intersections',
           'row_intersections', 'covered_pair_visits', 'newly_covered_classes',
           'removal_row_updates', 'assigned_components', 'distinct_prototype_points',
           'final_contact_classes', 'final_channels', 'budget_callbacks')
FAMILY = ('family_index', 'channel_id', 'd', 'seed_row', 'seed_columns', 'Z', 'O',
          'covered_label_ids', 'newly_covered_label_ids', 'remaining_negative_count',
          'remaining_total_negative_count')


class QualificationError(ValueError):
    """Invalid evidence or qualification assertion; never a negative label."""


class QualificationCallbackError(RuntimeError):
    """Deliberately unrelated qualification callback exception."""


def _need(condition, message='INVALID_FACTORIZATION_EVIDENCE'):
    if not condition:
        raise QualificationError(message)


def _record(value, fields):
    _need(type(value) is dict and set(value) == set(fields))


def _same(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return set(left) == set(right) and all(_same(left[k], right[k]) for k in left)
    if type(left) is list:
        return len(left) == len(right) and all(_same(a, b) for a, b in zip(left, right))
    return left == right


def _equal(left, right):
    _need(_same(left, right))


def _tick(budget):
    if budget is not None:
        if not callable(budget):
            raise TypeError('budget must be callable or None')
        budget()  # Exception-signaled; return values do not impose a limit.


def _hash(value):
    data = json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False) + '\n'
    return hashlib.sha256(data.encode()).hexdigest()


def _catalogue(catalogue, budget):
    """Full strict wire validation/copy, without palette or proof inference."""
    _record(catalogue, ('schema', 'system_sha256', 'tile_ids', 'labels'))
    _equal(catalogue['schema'], 'GCTS-four-corner-checked-label-catalogue-v1')
    system = catalogue['system_sha256']
    _need(type(system) is str and len(system) == 64 and all(c in '0123456789abcdef' for c in system))
    ids = catalogue['tile_ids']
    _need(type(ids) is list and len(ids) == 33 and all(type(v) is str and v for v in ids))
    _need(ids == sorted(set(ids)))
    labels = catalogue['labels']
    _need(type(labels) is list and len(labels) == 4356)
    counts = {s: 0 for s in ('BASE_CONFLICT', 'LOCAL_NEGATIVE', 'LOCAL_POSITIVE', 'UNKNOWN')}
    for rank, row in enumerate(labels):
        _tick(budget)
        _record(row, ('a', 'b', 'd', 'status', 'proof_id'))
        di, r = divmod(rank, 1089); ai, bi = divmod(r, 33)
        _equal([row['a'], row['b'], row['d']], [ids[ai], ids[bi], list(D[di])])
        _need(type(row['status']) is str and row['status'] in counts)
        if row['status'] == 'UNKNOWN':
            _equal(row['proof_id'], None)
        else:
            _need(type(row['proof_id']) is str and bool(row['proof_id']))
        if row['status'] == 'LOCAL_NEGATIVE':
            _need(di >= 2)
        if row['status'] == 'BASE_CONFLICT':
            _need(di < 2)
        counts[row['status']] += 1
    return copy.deepcopy(catalogue), counts


def _reference(catalogue, counts, budget):
    """Set-based full original/uncovered closures, independent of F bitmasks."""
    ids = catalogue['tile_ids']; labels = catalogue['labels']
    original = {d: set() for d in D[2:]}
    for rank, row in enumerate(labels):
        if row['status'] == 'LOCAL_NEGATIVE':
            di, rest = divmod(rank, 1089); ai, bi = divmod(rest, 33)
            original[D[di]].add((ai, bi))
    uncovered = {d: set(edges) for d, edges in original.items()}
    total = sum(map(len, uncovered.values()))
    families, patterns = [], []
    metrics = {name: 0 for name in METRICS}
    metrics.update(catalogue_rows=4356, base_conflict_labels=counts['BASE_CONFLICT'],
                   local_positive_labels=counts['LOCAL_POSITIVE'], unknown_labels=counts['UNKNOWN'],
                   required_negative_classes=total, matrix_edge_insertions=total)
    for d in D[2:]:
        used_seeds = set()
        while True:
            _tick(budget)
            degrees = []
            for ai in range(33):
                _tick(budget)
                degrees.append(sum((ai, bi) in uncovered[d] for bi in range(33)))
                metrics['seed_row_tests'] += 1
            seed = min(range(33), key=lambda ai: (-degrees[ai], ai))
            if degrees[seed] == 0:
                break
            _need(seed not in used_seeds)
            used_seeds.add(seed)
            seed_columns = [bi for bi in range(33) if (seed, bi) in uncovered[d]]
            z = set(range(33))
            for bi in seed_columns:
                _tick(budget)
                z.intersection_update(ai for ai in range(33) if (ai, bi) in original[d])
                metrics['column_intersections'] += 1
            _need(seed in z)
            closed = set(range(33))
            for ai in sorted(z):
                _tick(budget)
                closed.intersection_update(bi for bi in range(33) if (ai, bi) in original[d])
                metrics['row_intersections'] += 1
            _need(bool(closed) and set(seed_columns) <= closed)
            covered = {(ai, bi) for ai in z for bi in closed}
            _need(covered <= original[d])
            newly = covered & uncovered[d]
            _need(bool(newly))
            uncovered[d].difference_update(covered)
            total -= len(newly)
            _need(not any((seed, bi) in uncovered[d] for bi in range(33)))
            metrics['covered_pair_visits'] += len(covered)
            metrics['newly_covered_classes'] += len(newly)
            metrics['removal_row_updates'] += len(z)
            di = D.index(d)
            label_ids = lambda edges: ['CORNER_PAIR:'+str(di*1089+ai*33+bi) for ai, bi in sorted(edges)]
            families.append({'family_index': len(families), 'channel_id': None, 'd': list(d),
                             'seed_row': ids[seed], 'seed_columns': [ids[j] for j in seed_columns],
                             'Z': [ids[i] for i in sorted(z)], 'O': [ids[j] for j in sorted(closed)],
                             'covered_label_ids': label_ids(covered),
                             'newly_covered_label_ids': label_ids(newly),
                             'remaining_negative_count': len(uncovered[d]),
                             'remaining_total_negative_count': total})
            zeros = [[ids[i], d[0], d[1]] for i in sorted(z)]
            ones = [[ids[j], -d[0], -d[1]] for j in sorted(closed)]
            key = (tuple(i*4+FRAME.index(d) for i in sorted(z)),
                   tuple(j*4+FRAME.index((-d[0], -d[1])) for j in sorted(closed)))
            patterns.append((key, len(families)-1, zeros, ones))
            _need(len(used_seeds) <= 33 and len(families) <= 66)
    _equal(total, 0)
    _need(all(not u for u in uncovered.values()))
    _need(len({key for key, _i, _z, _o in patterns}) == len(patterns))
    channels = []
    prototype_points = set()
    for index, (_key, emitted, zeros, ones) in enumerate(sorted(patterns, key=lambda r: r[0])):
        name = 'LEARNED_CORNER:'+str(index)
        channels.append({'id': name, 'zeros': zeros, 'ones': ones})
        families[emitted]['channel_id'] = name
        prototype_points.update(tuple(r) for r in zeros+ones)
    marking = {'schema': 'GCTS-four-corner-partial-binary-marking-v1',
               'system_sha256': catalogue['system_sha256'], 'channels': channels}
    required_contacts = [dict(label_id='CORNER_PAIR:'+str(i), **copy.deepcopy(row))
                         for i, row in enumerate(labels) if row['status'] == 'LOCAL_NEGATIVE']
    metrics.update(families_emitted=len(families), assigned_components=sum(len(c['zeros'])+len(c['ones']) for c in channels),
                   distinct_prototype_points=len(prototype_points), final_contact_classes=len(required_contacts),
                   final_channels=len(channels))
    _equal(metrics['seed_row_tests'], 33*(len(families)+2))
    _equal(metrics['newly_covered_classes'], metrics['required_negative_classes'])
    return marking, families, metrics, required_contacts


def verify_factorization_result(catalogue, result, reconstruct_corner_contacts, *, budget=None):
    """Full independent result/trace/counter/map/contact check, never calls F.

    Labels are supplied assertions: this verifies representation of all negative
    classes, not their original raw-palette certificate truth. A resolved flag
    does not replace Root's separate certificate/wholepoint activation gate.
    """
    _tick(budget)
    _need(callable(reconstruct_corner_contacts))
    snapshot, counts = _catalogue(catalogue, budget)
    _record(result, ('schema', 'system_sha256', 'status', 'marking', 'metrics', 'families'))
    _equal(result['schema'], 'GCTS-four-corner-family-factorization-result-v1')
    _equal(result['system_sha256'], snapshot['system_sha256']); _equal(result['status'], 'COMPLETE_COVER')
    expected_marking, expected_families, expected_metrics, contacts = _reference(snapshot, counts, budget)
    _equal(result['marking'], expected_marking)
    _need(type(result['families']) is list)
    for family in result['families']:
        _record(family, FAMILY)
    _equal(result['families'], expected_families)
    _record(result['metrics'], METRICS)
    for key, value in result['metrics'].items():
        _need(type(value) is int and value >= 0)
        if key != 'budget_callbacks':
            _equal(value, expected_metrics[key])
    callbacks = (4+2*len(expected_families)+expected_metrics['column_intersections']+
                 expected_metrics['row_intersections']+expected_metrics['covered_pair_visits']//1024)
    _need(result['metrics']['budget_callbacks'] in (0, callbacks))
    def oracle_budget():
        _tick(budget)
        return None
    contact_check = reconstruct_corner_contacts(snapshot, result['marking'], budget=oracle_budget)
    _record(contact_check, ('status', 'induced_contacts', 'required_negative_ids',
                            'missing_required_negatives', 'uncertified_conflicts', 'channels', 'assigned_components'))
    _equal(contact_check['status'], 'VERIFIED')
    _equal(contact_check['induced_contacts'], contacts)
    _equal(contact_check['required_negative_ids'], [r['label_id'] for r in contacts])
    _equal(contact_check['missing_required_negatives'], []); _equal(contact_check['uncertified_conflicts'], [])
    _equal(contact_check['channels'], len(expected_families))
    _equal(contact_check['assigned_components'], expected_metrics['assigned_components'])
    _tick(budget)
    return {'schema': 'GCTS-corner-family-independent-result-check-v1', 'status': 'VERIFIED',
            'catalogue_sha256': _hash(snapshot), 'result_sha256': _hash(result),
            'marking_sha256': _hash(result['marking']), 'catalogue_resolved': counts['UNKNOWN'] == 0,
            'families_by_direction': [{'d': list(d), 'families': sum(f['d'] == list(d) for f in expected_families)} for d in D[2:]],
            'expected_metrics_without_budget_callbacks': {k:v for k,v in expected_metrics.items() if k != 'budget_callbacks'},
            'producer_budget_callbacks': result['metrics']['budget_callbacks'],
            'expected_budget_callbacks_if_supplied': callbacks,
            'budget_counter_scope': 'Producer callback=None permits0; otherwise qualification/actual caller must compare its observed callback count. All other metrics independently reconstructed.',
            'contact_check': contact_check,
            'scope': 'Exact family trace/map/all negative contact representation; raw label certificate truth and resolved-catalogue activation remain separate.'}


def _synthetic_catalogue(negative_edges=(), unknown_edges=(), opaque=False):
    ids = [('Opaque id '+str(i).zfill(2)+' [uninterpreted]') if opaque else
           ('TEST_TYPE:'+str(i).zfill(2)) for i in range(33)]
    negatives = set(negative_edges); unknown = set(unknown_edges)
    _need(not (negatives & unknown))
    labels = []
    for di, d in enumerate(D):
        for ai, a in enumerate(ids):
            for bi, b in enumerate(ids):
                key = (di, ai, bi)
                status = ('LOCAL_NEGATIVE' if key in negatives else
                          'UNKNOWN' if key in unknown else 'LOCAL_POSITIVE')
                labels.append({'a': a, 'b': b, 'd': list(d), 'status': status,
                               'proof_id': None if status == 'UNKNOWN' else 'SYNTHETIC_ONLY:'+str(len(labels))})
    return {'schema': 'GCTS-four-corner-checked-label-catalogue-v1', 'system_sha256': 'a'*64,
            'tile_ids': ids, 'labels': labels}


def _normal_cases():
    dense = [(2,a,b) for a in (0,1,2) for b in (4,5,6,7)]
    overlap = [(2,0,3),(2,0,4),(2,1,3),(2,1,4),(2,1,5),(2,2,4),(2,2,5)]
    both = _synthetic_catalogue([(2,0,1),(3,2,3)])
    both['labels'][0]['status'] = 'BASE_CONFLICT'
    return [
        ('F01_EMPTY', _synthetic_catalogue(), 0, 0),
        ('F02_ONE_EDGE_FALSE_CALLBACK', _synthetic_catalogue([(2,0,1)]), 1, 2),
        ('F03_BOTH_DIRECTIONS', both, 2, 4),
        ('F04_DENSE_BICLIQUE', _synthetic_catalogue(dense), 1, 7),
        ('F05_OVERLAPPING_BICLIQUES', _synthetic_catalogue(overlap), 3, 12),
        ('F06_SAME_TYPE_BOTH_SLOTS', _synthetic_catalogue([(2,0,0)]), 1, 2),
        ('F07_ALL_NEGATIVE_ONE_ORIENTATION', _synthetic_catalogue([(2,a,b) for a in range(33) for b in range(33)]), 1, 66),
        ('F08_DISCONNECTED_ROWS', _synthetic_catalogue([(2,0,3),(2,1,4),(2,2,4)]), 2, 5),
        ('F09_UNKNOWN_IS_NONEDGE', _synthetic_catalogue([(2,0,4),(2,0,5),(2,1,4)], [(2,1,5),(0,0,0)]), 2, 6),
        ('F10_OPAQUE_PURITY_REPEAT', _synthetic_catalogue(overlap, opaque=True), 3, 12),
        ('F11_CALLBACK_SNAPSHOT', _synthetic_catalogue(dense), 1, 7),
        ('F12_FULL_FAMILY_BOUND', _synthetic_catalogue([(d,i,i) for d in (2,3) for i in range(33)]), 66, 132),
    ]


def _mutable_ids(value):
    if type(value) is dict:
        found = {id(value)}
        for child in value.values():
            found.update(_mutable_ids(child))
        return found
    if type(value) is list:
        found = {id(value)}
        for child in value:
            found.update(_mutable_ids(child))
        return found
    return set()


def _normal_call(F_api, contacts, catalogue, budget, false_return=False, mutate_callback=False):
    before = copy.deepcopy(catalogue)
    observed = [0]
    def callback():
        observed[0] += 1
        _tick(budget)
        if mutate_callback and observed[0] == 1:
            catalogue['tile_ids'][0] = 'CALLER_MUTATED_ID'
            catalogue['labels'][0]['status'] = 'CALLER_MUTATED_STATUS'
        return False if false_return else None
    result = F_api.factor_corner_marking(catalogue, budget=callback)
    expected_input = copy.deepcopy(before)
    if mutate_callback:
        expected_input['tile_ids'][0] = 'CALLER_MUTATED_ID'
        expected_input['labels'][0]['status'] = 'CALLER_MUTATED_STATUS'
    _equal(catalogue, expected_input)
    _need(not (_mutable_ids(catalogue) & _mutable_ids(result)))
    check = verify_factorization_result(before, result, contacts, budget=budget)
    _equal(result['metrics']['budget_callbacks'], observed[0])
    _equal(observed[0], check['expected_budget_callbacks_if_supplied'])
    return {'catalogue': before, 'result': result, 'independent_check': check,
            'observed_producer_budget_callbacks': observed[0],
            'budget_return_ignored_false_control': false_return,
            'caller_callback_mutation_control': mutate_callback,
            'input_mutated_only_as_declared': True}


def _expect_exception(call, error_type, code=None, identity=None):
    try:
        call()
    except error_type as error:
        if code is not None:
            _equal(error.args, (code,))
        if identity is not None:
            _need(error is identity)
        return {'status': 'EXPECTED_EXCEPTION', 'type': type(error).__name__,
                'args': list(error.args), 'same_object': identity is not None}
    raise QualificationError('EXPECTED_EXCEPTION_NOT_RAISED')


def qualify_factorization(F_api, reconstruct_corner_contacts, *, budget=None):
    """One future qualification: 12 normal controls, 23 F calls, 13 O checks."""
    _tick(budget)
    _equal(F_api.VERSION, 'GCTS-corner-family-factorization-v1')
    _need(callable(F_api.factor_corner_marking) and callable(reconstruct_corner_contacts))
    cases = _normal_cases(); normal = []
    for name, catalogue, channels, components in cases:
        _tick(budget)
        call = _normal_call(F_api, reconstruct_corner_contacts, catalogue, budget,
                            false_return=name == 'F02_ONE_EDGE_FALSE_CALLBACK',
                            mutate_callback=name == 'F11_CALLBACK_SNAPSHOT')
        _equal(call['result']['metrics']['final_channels'], channels)
        _equal(call['result']['metrics']['assigned_components'], components)
        record = {'id': name, 'calls': [call]}
        if name == 'F10_OPAQUE_PURITY_REPEAT':
            # Preserve first full evidence, mutate only its returned local object,
            # then check a second producer call has independent fresh storage.
            saved = copy.deepcopy(call)
            original_return = call['result']
            original_return['marking']['channels'][0]['zeros'].append(['LOCAL_RETURN_MUTATION', 1, 1])
            again = _normal_call(F_api, reconstruct_corner_contacts, copy.deepcopy(saved['catalogue']), budget)
            _equal(again['result']['marking'], saved['result']['marking'])
            _equal(again['result']['families'], saved['result']['families'])
            _need(not (_mutable_ids(original_return) & _mutable_ids(again['result'])))
            record['calls'] = [saved, again]
            record['local_return_mutation_isolated'] = True
        normal.append(record)
    base = copy.deepcopy(normal[0]['calls'][0]['catalogue'])
    malformed = []
    v = copy.deepcopy(base); v['extra'] = None
    malformed.append(('E01_EXTRA_FIELD',v,'CORNER_INPUT_SHAPE'))
    v = copy.deepcopy(base); v['labels'][0]['d'][0] = True
    malformed.append(('E02_BOOL_COORDINATE',v,'CORNER_INPUT_SHAPE'))
    v = copy.deepcopy(base); v['labels'].pop()
    malformed.append(('E03_MISSING_LABEL',v,'CORNER_CATALOGUE_COVERAGE'))
    v = copy.deepcopy(base); v['labels'][0]['status'] = 'UNKNOWN'
    malformed.append(('E04_UNKNOWN_PROOF',v,'CORNER_LABEL_ASSOCIATION'))
    v = copy.deepcopy(base); v['labels'][0]['status'] = 'LOCAL_NEGATIVE'
    malformed.append(('E05_AXIAL_NEGATIVE',v,'CORNER_LABEL_ASSOCIATION'))
    v = copy.deepcopy(base); v['tile_ids'][1] = v['tile_ids'][0]
    malformed.append(('E06_DUPLICATE_IDS',v,'CORNER_INPUT_SHAPE'))
    negatives = []
    for name, value, code in malformed:
        _tick(budget)
        before = copy.deepcopy(value)
        receipt = _expect_exception(lambda value=value: F_api.factor_corner_marking(value),
                                     F_api.FactorCatalogueError, code)
        _equal(value, before)
        negatives.append({'id': name, 'input': value, 'receipt': receipt})
    negatives.append({'id': 'E07_NONCALLABLE_BUDGET', 'input': base,
                      'receipt': _expect_exception(lambda: F_api.factor_corner_marking(base, budget=0),
                                                  TypeError, 'budget must be callable or None')})
    _equal(base, normal[0]['calls'][0]['catalogue'])
    dense = copy.deepcopy(normal[3]['calls'][0]['catalogue'])
    exceptional = []
    for name, error in (('B01_OWNED_ENTRY', F_api.FactorBudgetExceeded('QUALIFICATION_OWNED')),
                         ('B02_UNRELATED', QualificationCallbackError('QUALIFICATION_UNRELATED'))):
        before = copy.deepcopy(dense)
        def stop(error=error):
            _tick(budget)
            raise error
        receipt = _expect_exception(lambda: F_api.factor_corner_marking(dense, budget=stop),
                                     type(error), identity=error)
        _equal(dense, before)
        exceptional.append({'id': name, 'receipt': receipt})
    dense_before = copy.deepcopy(dense)
    limit = normal[3]['calls'][0]['observed_producer_budget_callbacks']
    observed = [0]; failure = F_api.FactorBudgetExceeded('QUALIFICATION_FINAL_CALLBACK')
    def final_stop():
        _tick(budget)
        observed[0] += 1
        if observed[0] == limit:
            raise failure
    receipt = _expect_exception(lambda: F_api.factor_corner_marking(dense, budget=final_stop),
                                 type(failure), identity=failure)
    _equal(observed[0], limit)
    _equal(dense, dense_before)
    exceptional.append({'id': 'B03_FINAL_CALLBACK_NO_PREFIX', 'receipt': receipt,
                        'observed_callback_count': observed[0]})
    _equal(len(normal), 12); _equal(sum(len(r['calls']) for r in normal), 13)
    _equal(len(negatives), 7); _equal(len(exceptional), 3)
    _tick(budget)
    return {'schema': 'GCTS-corner-family-independent-qualification-v1', 'status': 'VERIFIED',
            'normal_controls': normal, 'malformed_controls': negatives,
            'budget_exception_controls': exceptional,
            'counts': {'normal_controls': 12, 'normal_F_calls': 13, 'malformed_F_calls': 7,
                       'budget_exception_F_calls': 3, 'total_F_public_calls': 23,
                       'normal_independent_contact_calls': 13},
            'scope': 'Synthetic opaque-label API/family/point-contact qualification only; no raw-palette certificates, prior labels/maps or engine-discovered theorem.'}
