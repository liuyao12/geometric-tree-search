"""Whole current evidence byte/JSON/association review; NO project imports.

No solver, model constructor, contact/point/certificate checker, factorizer or
reference closure is invoked or reimplemented here. Proof truth was checked
inside the authenticated reviewed once. This audit joins retained structures.
"""
import collections,hashlib,json,math,stat
from pathlib import Path
study=Path('/private/tmp/gcts-corner-family-factorization-20261027-v1');root=study/'root';actual=study/'actual-v1';out=Path('/private/tmp/gcts-L-family-whole-actual-review-20261027-v1')
def raw(p):
 p=Path(p);assert p.is_absolute() and p.resolve()==p and all(not q.is_symlink() for q in (p,*p.parents));a=p.stat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1;b=p.read_bytes();z=p.stat();assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns) and len(b)==a.st_size;return b
def ref(p,b=None):
 b=raw(p) if b is None else b;return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def pairs(rows):
 d={}
 for k,v in rows:assert k not in d;d[k]=v
 return d
def bad(x):raise AssertionError('nonfinite JSON')
def dec(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=bad)
def enc(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(v):return hashlib.sha256(enc(v)).hexdigest()
def same(a,b):
 if type(a)is not type(b):return False
 if type(a)is dict:return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
 if type(a)is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b
def load(p):return dec(raw(p))
def finite(x):assert type(x)is float and math.isfinite(x) and x>=0

def proof_shape(cert):
 assert set(cert)=={'schema','kind','model_sha256','spec_sha256','entry','root','solution'} and cert['schema']=='GCTS-unit-cell-csp-certificate-v1'
 kind=cert['kind'];assert kind in ('SAT','UNSAT','INCOMPLETE')
 if kind=='SAT':assert cert['root'] is None and type(cert['solution'])is list
 elif kind=='INCOMPLETE':assert cert['root'] is None and cert['solution'] is None
 else:assert cert['solution'] is None and type(cert['root'])is dict
 stack=[] if kind!='UNSAT' else [cert['root']];count=0
 while stack:
  n=stack.pop();count+=1;assert type(n)is dict and n['kind'] in ('DEAD','FORCED','BRANCH') and type(n['domains_sha256'])is str and len(n['domains_sha256'])==64
  if n['kind']=='DEAD':assert set(n)=={'kind','domains_sha256','point'}
  elif n['kind']=='FORCED':assert set(n)=={'kind','domains_sha256','point','id','child'};stack.append(n['child'])
  else:assert set(n)=={'kind','domains_sha256','point','id','candidates','child','remainder'};stack.extend((n['child'],n['remainder']))
 return {'kind':kind,'structural_proof_nodes':count}

def full_event_hashes(events):
 for i,e in enumerate(events):
  assert set(e)=={'seq','kind','data','snapshot','domains_sha256','state_sha256'} and same(e['seq'],i)
  assert e['state_sha256']==sha(e['snapshot']) and e['domains_sha256']==sha(e['snapshot']['eligible_domains'])
 return len(events)

def digest_trace(events,start=0):
 for i,e in enumerate(events):
  assert set(e)=={'seq','kind','data','domains_sha256','state_sha256'} and same(e['seq'],start+i)
  assert e['kind'] in ('INITIALIZED','DECISION','PLACED','EXCLUDED','ROLLED_BACK','SOLVE_RESULT') and type(e['data'])is dict
  assert all(type(e[k])is str and len(e[k])==64 for k in ('domains_sha256','state_sha256'))
 return [e for e in events if e['kind']=='DECISION']

pp=root/'corner-family-once-plan-v1.json';ap=root/'corner-family-Root-once-authority-v1.json';mp=Path(str(ap)+'.CONSUMED.json');tp=root/'corner-family-original-owned-tool-transport-v1.json';ip=root/'corner-family-Root-exact-prospective-invocation-v1.json'
p,a,m,t,inv=[load(q) for q in (pp,ap,mp,tp,ip)]
assert t['owned_session_id']==t['initial']['session_id']==34412 and t['terminal']['exit_code']==0
assert same(a,{'schema':'GCTS-corner-family-once-authority-v1','authorized':True,'uses':1,'plan':ref(pp),'observer':p['role_pins']['observer'],'python':p['python']})
assert same(m,{'schema':'GCTS-corner-family-once-consumed-v1','uses':1,'authority':ref(ap),'plan':ref(pp),'observer':p['role_pins']['observer'],'python':p['python'],'child_started_at_consume':False})
guards=[ref(q) for q in (pp,ap,mp,tp,ip)]
for z in [*p['role_pins'].values(),p['python'],p['source_contract'],p['offer']]:assert ref(z['path'])==z;guards.append(z)
assert sum(z['bytes'] for z in p['role_pins'].values())==236040
cust=load(actual/'custody-terminal.json');result=load(actual/'result.json');arts=result['artifacts'];outcome=result['outcome']
assert cust['schema']=='GCTS-corner-family-custody-terminal-v1' and cust['status']=='COMPLETE_NORMAL_WORKER_REVIEW_PENDING' and cust['worker_returncode']==0 and cust['cleanup']==[] and cust['scientific_admission'] is False
assert result['schema']=='GCTS-corner-family-worker-result-v1' and result['status']=='COMPLETE_BOUNDED_STUDY_REVIEW_PENDING' and result['run_id']==cust['run_id']==p['run_id']
assert same(result['role_pins'],p['role_pins']) and same(cust['role_pins'],p['role_pins']) and cust['plan']==ref(pp) and cust['authority']==ref(ap) and cust['consume']==ref(mp) and cust['python']==p['python']
assert cust['authenticated_worker_source_bytes_delivered']==p['role_pins']['worker']['bytes'] and cust['owned_process_group']==cust['owned_worker_pid']>0
child_command=[p['python']['path'],'-I','-S','-B','-c',inv['outer_argv'][5],p['role_pins']['worker']['path'],str(p['role_pins']['worker']['bytes']),p['role_pins']['worker']['sha256'],'--plan',str(pp),'--consume',str(mp)]
assert same(cust['command'],child_command)
so=raw(actual/'worker-stdout.bin');se=raw(actual/'worker-stderr.bin');oo=raw(root/'corner-family-owned-outer-stdout-v1.bin');oe=raw(root/'corner-family-owned-outer-stderr-v1.bin');assert not se and not oe
assert ref(actual/'worker-stdout.bin',so)==cust['worker_stdout'] and ref(actual/'worker-stderr.bin',se)==cust['worker_stderr']
worker_lines=[dec(q) for q in so.splitlines()];outer_lines=[dec(q) for q in oo.splitlines()];terminal=worker_lines[-1]
assert same(outer_lines[-1],cust) and same(terminal,{'schema':'GCTS-corner-family-worker-terminal-v1','status':'COMPLETE','result':ref(actual/'result.json'),'actual_named_bytes':cust['named_worker_output_bytes']}) and cust['worker_result']==ref(actual/'result.json')
assert len(arts)==61 and len({z['path'] for z in arts})==61 and same(cust['artifacts'],arts)
for z in arts:assert Path(z['path']).parent==actual and ref(z['path'])==z and z['bytes']<=p['limits']['per_output_body_bytes']
assert sum(z['bytes'] for z in arts)==result['named_bytes_before_final_result']==167589579
assert sum(z['bytes'] for z in arts)+ref(actual/'result.json')['bytes']==cust['named_worker_output_bytes']==167616315<=p['limits']['named_output_aggregate_bytes']
physical=sorted(actual.iterdir(),key=lambda q:q.name);physical_refs=[ref(q) for q in physical]
assert len(physical)==65 and {q.name for q in physical}=={Path(z['path']).name for z in arts}|{'result.json','worker-stdout.bin','worker-stderr.bin','custody-terminal.json'}
assert len(so)+len(se)<=p['limits']['combined_worker_logs_bytes']
for z in arts:
 b=raw(z['path']);assert enc(dec(b))==b
assert enc(cust)==raw(actual/'custody-terminal.json') and enc(result)==raw(actual/'result.json')
for k in ('Popen_call_seconds','before_Popen_through_owned_wait_seconds','after_Popen_return_through_owned_wait_seconds','observer_main_entry_before_final_receipt_seconds'):finite(cust[k])
finite(result['worker_main_entry_before_final_result_seconds']);assert result['worker_main_entry_before_final_result_seconds']<=600 and cust['before_Popen_through_owned_wait_seconds']<=720
assert math.isclose(cust['Popen_call_seconds']+cust['after_Popen_return_through_owned_wait_seconds'],cust['before_Popen_through_owned_wait_seconds'],rel_tol=0,abs_tol=1e-8)
assert type(cust['owned_child_lifetime_RSS_highwater_bytes'])is int and cust['owned_child_lifetime_RSS_highwater_bytes']==204800000<=p['limits']['observed_worker_RSS_limit_bytes']
assert type(result['worker_lifetime_RSS_bytes_at_sample'])is int and result['worker_lifetime_RSS_bytes_at_sample']<=cust['owned_child_lifetime_RSS_highwater_bytes']
inputs=load(actual/'inputs.json');cat=load(actual/'checked-label-catalogue.json');arrivals=load(actual/'learning-arrivals.json');assert sha(inputs['system'])==cat['system_sha256']==inputs['system_sha256']
assert len(cat['labels'])==4356 and len(cat['tile_ids'])==33 and len(arrivals['events'])==4356 and len(arrivals['final_provisional_channels'])==1746
D=((1,0),(0,1),(1,1),(-1,1));ids=cat['tile_ids'];counts=collections.Counter();certs=collections.Counter();shard_summary=[];aliases=0;index=0;alias_digest=hashlib.sha256();fragments=[]
for di,d in enumerate(D):
 for block in range(9):
  name='pair-labels-'+str(di)+'-'+str(block)+'.json';chunk=load(actual/name);rows=chunk['records'];assert chunk['offset']==list(d) and chunk['system_sha256']==cat['system_sha256'] and len(rows)==(128 if block<8 else 65)
  c=collections.Counter()
  for row in rows:
   rank=index;index+=1;label=row['label'];ai,bi=divmod(rank-di*1089,33)
   assert row['index']==rank and same(label,cat['labels'][rank]) and [label['a'],label['b'],label['d']]==[ids[ai],ids[bi],list(d)] and label['proof_id']=='PAIR_PROOF:'+str(rank)
   assert row['direct_support']['status']==label['status'] and row['direct_support']['certificate_sha256']==sha(row['direct_support']['certificate'])
   event=arrivals['events'][rank];assert event['index']==rank and same(event['label'],label);counts[label['status']]+=1;c[label['status']]+=1
   assert all(event['counts'][k]==counts.get(k,0) for k in outcome['counts'])
   frag=event['new_fragment']
   if label['status']=='LOCAL_NEGATIVE':
    assert same(frag['label'],label) and frag['label_id']=='CORNER_PAIR:'+str(rank) and frag['status']=='SINGLE_LABEL_FRAGMENT_CONSTRUCTED'
    assert same(frag['induced_contacts'],[dict(label_id='CORNER_PAIR:'+str(rank),**label)]);fragments.append(frag['channel'])
   else:assert frag is None
   if label['status']=='BASE_CONFLICT':assert row['point'] is None and row['csp'] is None
   else:
    pt,cs=row['point'],row['csp'];pr,cr=pt['return'],cs['return'];assert cs['spec_model_ref']=='point.return.model' and set(cs['spec_without_model'])=={'schema','variables','unaries','binary','preprocessed','policy'}
    restored=dict(cs['spec_without_model']);restored['model']=pr['model'];mh,sh=sha(pr['model']),sha(restored)
    assert cr['model_sha256']==mh==cr['certificate']['model_sha256'] and cr['spec_sha256']==sh==cr['certificate']['spec_sha256']
    assert pr['status']==cr['status'] and same(pr['nodes'],cr['nodes']) and pr['nodes']<=3 and pr['metrics']['backtracks']==0
    assert pt['restored_entry_exact'] is True and cs['restored_entry_exact'] is True and pt['entry_sha256']==pt['restored_sha256']
    assert cs['certificate_check']['status']=='VERIFIED' and cs['certificate_check']['model_sha256']==mh and cs['certificate_check']['spec_sha256']==sh
    assert pt['independent_final_check']['status']==pt['independent_return_check']['status']==cs['export_check']['status']=='VERIFIED'
    shape=proof_shape(cr['certificate']);certs[shape['kind']]+=1
    assert same(cr['certificate']['entry'],cr['context'])
    if label['status']=='LOCAL_POSITIVE':assert shape['kind']=='SAT' and same(pr['selected'],cr['selected']) and same(cr['certificate']['solution'],cr['final']['assigned'])
    else:assert shape['kind']=='UNSAT' and same(cr['entry'],cr['final'])
    aliases+=1;alias_digest.update(enc({'index':rank,'model_sha256':mh,'spec_sha256':sh}))
   assert event['provisional_channels']==len(fragments) and event['provisional_assigned_components']==2*len(fragments)
  shard_summary.append({'rawref':ref(actual/name),'records':len(rows),'counts':dict(c)})
assert index==4356 and aliases==2577 and all(outcome['counts'][k]==counts.get(k,0) for k in outcome['counts']) and outcome['counts']=={'BASE_CONFLICT':1779,'LOCAL_POSITIVE':831,'LOCAL_NEGATIVE':1746,'UNKNOWN':0}
assert same(fragments,arrivals['final_provisional_channels'])
# Qualification structural evidence: full snapshots are hashed, not re-solved.
oldq=load(actual/'qualification.json');assert oldq['status']=='VERIFIED' and len(oldq['paired_controls'])==26 and len(oldq['B_negative_controls'])==32 and len(oldq['C_controls'])==20
qevents=0
for rec in oldq['paired_controls']:
 qevents+=full_event_hashes(rec['events'])
 if rec['result'] is not None and rec['mode']=='CSP':
  cr=rec['result'];assert cr['model_sha256']==sha(rec['model']) and cr['spec_sha256']==sha(rec['spec']);proof_shape(cr['certificate'])
for n in range(1,14):
 pair=[q for q in oldq['paired_controls'] if q['id']=='Q'+str(n).zfill(2)];assert len(pair)==2 and same(pair[0]['events'],pair[1]['events'])
newq=load(actual/'factorization-qualification.json');assert newq['status']=='VERIFIED' and newq['counts']=={'normal_controls':12,'normal_F_calls':13,'malformed_F_calls':7,'budget_exception_F_calls':3,'total_F_public_calls':23,'normal_independent_contact_calls':13}
assert len(newq['normal_controls'])==12 and sum(len(r['calls']) for r in newq['normal_controls'])==13 and len(newq['malformed_controls'])==7 and len(newq['budget_exception_controls'])==3
f_q_summaries=[]
for ctrl in newq['normal_controls']:
 for call in ctrl['calls']:
  chk=call['independent_check'];rr=call['result'];assert chk['status']=='VERIFIED' and chk['catalogue_sha256']==sha(call['catalogue']) and chk['result_sha256']==sha(rr) and chk['marking_sha256']==sha(rr['marking'])
  assert call['observed_producer_budget_callbacks']==rr['metrics']['budget_callbacks']==chk['expected_budget_callbacks_if_supplied']
  f_q_summaries.append({'id':ctrl['id'],'families':rr['metrics']['families_emitted'],'components':rr['metrics']['assigned_components'],'callbacks':rr['metrics']['budget_callbacks'],'catalogue_sha256':chk['catalogue_sha256'],'result_sha256':chk['result_sha256']})
for rec in newq['malformed_controls']+newq['budget_exception_controls']:assert rec['receipt']['status']=='EXPECTED_EXCEPTION'
learn=load(actual/'learned-marking.json');ded=load(actual/'dedicated-marking.json');audit=load(actual/'marking-audit.json');metrics=learn['metrics'];families=learn['families'];channels=learn['marking']['channels'];required=['CORNER_PAIR:'+str(i) for i,x in enumerate(cat['labels']) if x['status']=='LOCAL_NEGATIVE'];required_set=set(required)
assert len(families)==len(channels)==20<=66 and learn['status']=='COMPLETE_COVER'
assert [ch['id'] for ch in channels]==['LEARNED_CORNER:'+str(i) for i in range(20)]
# Trace/data bookkeeping only: no row-choice/common-neighbor closure algorithm.
channel_by_id={ch['id']:ch for ch in channels};covered_all=set();new_all=set();covered_visits=0;column_count=0;row_count=0;trace_summary=[];direction_new=collections.Counter();direction_totals=collections.Counter(tuple(row['d']) for row in cat['labels'] if row['status']=='LOCAL_NEGATIVE')
for index,f in enumerate(families):
 assert f['family_index']==index and len(set(f['Z']))==len(f['Z']) and len(set(f['O']))==len(f['O']) and f['Z']==sorted(f['Z']) and f['O']==sorted(f['O']) and f['seed_row'] in f['Z'] and set(f['seed_columns'])<=set(f['O'])
 d=tuple(f['d']);assert d in D[2:];ch=channel_by_id[f['channel_id']]
 assert same(ch['zeros'],[[a,*d] for a in f['Z']]) and same(ch['ones'],[[b,-d[0],-d[1]] for b in f['O']])
 covered=set(f['covered_label_ids']);new=set(f['newly_covered_label_ids']);assert len(covered)==len(f['covered_label_ids'])==len(f['Z'])*len(f['O']) and new==covered-covered_all and covered<=required_set
 assert all(cat['labels'][int(x.split(':')[1])]['a'] in f['Z'] and cat['labels'][int(x.split(':')[1])]['b'] in f['O'] and cat['labels'][int(x.split(':')[1])]['d']==f['d'] for x in covered)
 covered_all.update(covered);new_all.update(new);direction_new[d]+=len(new);assert f['remaining_negative_count']==direction_totals[d]-direction_new[d] and f['remaining_total_negative_count']==1746-len(new_all)
 covered_visits+=len(covered);column_count+=len(f['seed_columns']);row_count+=len(f['Z'])
 trace_summary.append({'family_index':index,'channel_id':f['channel_id'],'d':f['d'],'seed_row':f['seed_row'],'seed_columns':len(f['seed_columns']),'Z':len(f['Z']),'O':len(f['O']),'covered':len(covered),'new':len(new),'remaining_total':f['remaining_total_negative_count']})
assert covered_all==new_all==required_set
components=sum(len(ch['zeros'])+len(ch['ones']) for ch in channels);points={tuple(row) for ch in channels for side in ('zeros','ones') for row in ch[side]}
expected_facts={'catalogue_rows':4356,'base_conflict_labels':1779,'local_positive_labels':831,'unknown_labels':0,'required_negative_classes':1746,'matrix_edge_insertions':1746,'families_emitted':20,'seed_row_tests':33*(20+2),'column_intersections':column_count,'row_intersections':row_count,'covered_pair_visits':covered_visits,'newly_covered_classes':len(new_all),'removal_row_updates':row_count,'assigned_components':components,'distinct_prototype_points':len(points),'final_contact_classes':len(covered_all),'final_channels':20}
assert all(same(metrics[k],v) for k,v in expected_facts.items())
cb=4+2*20+column_count+row_count+covered_visits//1024;factor_check=audit['independent_factor_result'];assert cb==738==metrics['budget_callbacks']==audit['observed_factor_callbacks']==factor_check['producer_budget_callbacks']==factor_check['expected_budget_callbacks_if_supplied']
assert factor_check['status']=='VERIFIED' and factor_check['catalogue_resolved'] is True and factor_check['catalogue_sha256']==sha(cat) and factor_check['result_sha256']==sha(learn) and factor_check['marking_sha256']==sha(learn['marking']) and same(factor_check['expected_metrics_without_budget_callbacks'],expected_facts)
expected_contacts=[dict(label_id='CORNER_PAIR:'+str(i),**row) for i,row in enumerate(cat['labels']) if row['status']=='LOCAL_NEGATIVE']
contact_receipts=[audit['independent_actual_contacts'],factor_check['contact_check'],audit['independent_dedicated']['contacts']]
for cr in contact_receipts:assert cr['status']=='VERIFIED' and same(cr['induced_contacts'],expected_contacts) and cr['missing_required_negatives']==[] and cr['uncertified_conflicts']==[] and cr['required_negative_ids']==required
assert same(audit['production']['induced_contacts'],expected_contacts) and audit['production']['missing_required_negatives']==[] and audit['production']['uncertified_conflicts']==[] and audit['production']['wellformed'] is True
assert audit['independent_dedicated']['activation_allowed'] is True and audit['independent_dedicated']['result_sha256']==sha(ded)
assert ded['metrics']['final_channels']==1746 and ded['metrics']['final_assigned_components']==3492
# All immediate full arm files and the complete eight comparison profiles.
bench=load(actual/'benchmarks.json');assert len(bench['records'])==16 and len(bench['comparisons'])==8 and bench['schema']=='GCTS-corner-family-matched-benchmark-index-v1'
arm_packets={};arm_summaries=[];norm_nodes={};arm_models={};all_proof_shapes=[]
for rr in bench['records']:
 assert ref(rr['record']['path'])==rr['record'] and rr['record'] in arts and rr['record'] in outcome['benchmark_arms']
 packet=load(rr['record']['path']);assert same(packet['input'],rr['input']) and packet['arm']==rr['arm']
 spec_input=packet['input'];key=(spec_input['width'],spec_input['steps'],spec_input['negative_final'],packet['arm']);assert key not in arm_packets
 assert (key[0],key[1]) in ((5,2),(9,6)) and type(key[2])is bool and key[3] in ('POINT_WANG','CSP_WANG','POINT_LEARNED','CSP_SAME_CONFLICTS')
 data=packet['data'];ret=data['return'];window=data['search_window'];assert same(window['limit_seconds'],20) and type(window['triggered'])is bool
 finite(window['solve_return_interval_seconds']);finite(window['started_since_worker_main']);assert data['restored_entry_exact'] is True
 decisions=digest_trace(data['trace']);digest_trace(data['cleanup_trace'],len(data['trace']));assert len(decisions)==ret['nodes'] and type(ret['nodes'])is int and ret['nodes']<=5000
 assert data['trace'][0]['kind']=='INITIALIZED' and data['trace'][-1]['kind']=='SOLVE_RESULT' and same(data['trace'][-1]['data'],{'status':ret['status'],'reason':ret['reason'],'nodes':ret['nodes']})
 if key[3].startswith('POINT'):
  model=ret['model'];mh=sha(model);assert data['entry_sha256']==data['restored_sha256']
  fin=data['independent_final_check'];chk=data['independent_return_check'];assert fin['status']==chk['status']=='VERIFIED' and chk['model_sha256']==mh and fin['receipt']['model_sha256']==mh
  assert fin['receipt']['snapshot_sha256']==data['final_sha256'] and fin['receipt']['state_sha256']==sha(fin['normalized_state'])==data['trace'][-1]['state_sha256'] and fin['receipt']['domains_sha256']==sha(fin['normalized_state']['eligible_domains'])
  elapsed=data['elapsed_construction_solve_verify_cleanup'];kind=None
 else:
  spec=data['spec'];model=spec['model'];mh=sha(model);sh=sha(spec);assert ret['model_sha256']==mh==ret['certificate']['model_sha256'] and ret['spec_sha256']==sh==ret['certificate']['spec_sha256']
  assert data['certificate_check']['status']==data['export_check']['status']=='VERIFIED' and data['certificate_check']['model_sha256']==mh and data['certificate_check']['spec_sha256']==sh
  assert same(ret['certificate']['entry'],ret['context']) and sha(ret['entry'])==data['trace'][0]['state_sha256'] and sha(ret['final'])==data['trace'][-1]['state_sha256']
  shape=proof_shape(ret['certificate']);kind=shape['kind'];all_proof_shapes.append(dict(descriptor=list(key),**shape))
  if kind=='SAT':assert same(ret['certificate']['solution'],ret['final']['assigned'])
  if kind in ('UNSAT','INCOMPLETE'):assert same(ret['final'],ret['entry'])
  elapsed=data['elapsed_export_construction_solve_verify_cleanup']
 finite(elapsed);assert elapsed>=window['solve_return_interval_seconds']
 if window['triggered']:
  assert ret['status']=='UNKNOWN' and ret['reason']=='EXTERNAL_BUDGET' and ret['solution_verified'] is False and same(ret['selected'],ret['context']['selected'])
  if kind is not None:assert kind=='INCOMPLETE'
 else:
  assert key[0]==5 and ret['status']==('EXHAUSTED_FINITE_SEARCH' if key[2] else 'FINITE_EXACT_SOLUTION') and ret['solution_verified'] is (not key[2])
  if kind is not None:assert kind==('UNSAT' if key[2] else 'SAT')
 assert same(ret['selected'],data['independent_final_check']['normalized_state']['selected']) if key[3].startswith('POINT') else same(ret['selected'],ret['final']['selected'])
 for metric,value in ret['metrics'].items():
  if metric=='candidate_removals':assert all(type(v)is int and v>=0 for v in value.values())
  else:assert type(value)is int and value>=0
 arm_packets[key]=packet;arm_models[key]=model
 arm_summaries.append({'descriptor':list(key),'rawref':rr['record'],'status':ret['status'],'reason':ret['reason'],'nodes':ret['nodes'],'window':window,'inclusive_arm_elapsed_excluding_write':elapsed,'metrics':ret['metrics'],'model_sha256':mh,'trace_events':len(data['trace']),'cleanup_events':len(data['cleanup_trace']),'trace_sha256':sha(data['trace'])})
assert len(arm_packets)==16 and len(outcome['benchmark_arms'])==16 and len({z['path'] for z in outcome['benchmark_arms']})==16
assert set(arm_packets)=={(w,s,n,arm) for w,s in ((5,2),(9,6)) for n in (False,True) for arm in ('POINT_WANG','CSP_WANG','POINT_LEARNED','CSP_SAME_CONFLICTS')}
comparison_summaries=[]
for row in bench['comparisons']:
 pk=(row['width'],row['steps'],row['negative'],row['point_arm']);ck=(row['width'],row['steps'],row['negative'],row['csp_arm']);pd=arm_packets[pk]['data'];cd=arm_packets[ck]['data'];check=row['check']
 assert same(arm_models[pk],arm_models[ck]) and same(arm_packets[pk]['input'],arm_packets[ck]['input'])
 pt,ct=pd['trace'],cd['trace'];pdec=[q for q in pt if q['kind']=='DECISION'];cdec=[q for q in ct if q['kind']=='DECISION'];common=min(len(pdec),len(cdec))
 def projection(e):return {k:v for k,v in e.items() if k!='seq'}
 assert all(same(projection(x),projection(y)) for x,y in zip(pdec,cdec))
 assert check['common_decisions']==common and check['point_decisions']==len(pdec) and check['csp_decisions']==len(cdec) and check['all_common_decisions_equal'] is True and check['overlap_vacuous'] is (common==0)
 assert check['point_window_triggered'] is pd['search_window']['triggered'] and check['csp_window_triggered'] is cd['search_window']['triggered']
 windowed=pd['search_window']['triggered'] or cd['search_window']['triggered']
 if windowed:assert check['mode']=='DECISION_PREFIX_ONLY' and check['full_trace_status_nodes_and_common_metrics_asserted'] is False and common>0
 else:
  assert check['mode']=='COMPLETE_SEMANTIC_TRACE' and check['full_trace_status_nodes_and_common_metrics_asserted'] is True and same(pt,ct)
  for name in ('status','reason','nodes','selected','context','solution_verified'):assert same(pd['return'][name],cd['return'][name])
  assert same(dict(pd['return']['metrics'],nodes=pd['return']['nodes']),cd['return']['metrics'])
 comparison_summaries.append({'descriptor':[row['width'],row['steps'],row['negative'],row['point_arm'],row['csp_arm']],'mode':check['mode'],'point_decisions':len(pdec),'csp_decisions':len(cdec),'overlap':common,'vacuous':common==0,'full_trace_compared':not windowed})
assert [x['overlap'] for x in comparison_summaries if x['full_trace_compared']]==[33,21,35,15]
assert [x['overlap'] for x in comparison_summaries if not x['full_trace_compared']]==[55,42,59,45]
for w,s in ((5,2),(9,6)):
 for neg in (False,True):
  base=arm_models[w,s,neg,'POINT_WANG'];marked=arm_models[w,s,neg,'POINT_LEARNED'];bh,mh=sha(base),sha(marked)
  for arm in ('POINT_LEARNED','CSP_SAME_CONFLICTS'):
   ar=arm_packets[w,s,neg,arm]['augmentation_check'];assert ar['status']=='VERIFIED' and ar['base_sha256']==bh and ar['augmented_sha256']==mh and ar['channels']==20 and ar['added_components']==w*(s+2)*690
  assert all(same(base[k],marked[k]) for k in ('schema','capacity','required','seeds')) and len(base['placements'])==len(marked['placements'])
  assert all(all(same(x[k],y[k]) for k in ('id','type','translation','t')) for x,y in zip(base['placements'],marked['placements']))
  # Literal expansion was checked inside once; outside only whole hash/count associations.
started=[x for x in worker_lines if x.get('phase')=='BENCHMARK_STARTED'];saved=[x for x in worker_lines if x.get('phase')=='BENCHMARK_SAVED'];assert len(started)==len(saved)==16
for start,save,rr in zip(started,saved,bench['records']):
 ip=rr['input'];key=(ip['width'],ip['steps'],ip['negative_final'],rr['arm']);ret=arm_packets[key]['data']['return']
 assert all(start[k]==save[k] for k in ('width','steps','negative','arm')) and (start['width'],start['steps'],start['negative'],start['arm'])==key
 assert save['result']==ret['status'] and save['nodes']==ret['nodes'] and save['window_triggered'] is arm_packets[key]['data']['search_window']['triggered']
assert sum(x['data']['return']['status']=='UNKNOWN' for x in arm_packets.values())==8
assert sum(x['data']['return']['status']=='FINITE_EXACT_SOLUTION' for x in arm_packets.values())==4
assert sum(x['data']['return']['status']=='EXHAUSTED_FINITE_SEARCH' for x in arm_packets.values())==4
for val in (outcome['factor_call_elapsed'],outcome['synthesis_elapsed'],outcome['label_elapsed']):finite(val)
assert outcome['activation'] is True and outcome['factor_call_elapsed']==audit['factor_call_elapsed'] and outcome['synthesis_elapsed']==audit['complete_synthesis_and_checks_elapsed']
# One-level audit support: raw originals remain complete; no model/closure replay.
support={'schema':'L-family-whole-actual-complete-raw-structural-support-v1','status':'COMPLETE_STRUCTURAL_ASSOCIATIONS_PASS_WITH_AUTHENTICATED_SOURCE_INHERITANCE','guards':guards,'original_transport':ref(tp),'all65_physical_rawrefs':physical_refs,'all61_prefinal_artifacts':arts,'worker_result':ref(actual/'result.json'),'custody':ref(actual/'custody-terminal.json'),'outer_stdout':ref(root/'corner-family-owned-outer-stdout-v1.bin',oo),'outer_stderr':ref(root/'corner-family-owned-outer-stderr-v1.bin',oe),'prefinal_named_bytes':167589579,'workerJSON_including_result_count':62,'workerJSON_including_result_bytes':167616315,'complete65_physical_bytes':sum(z['bytes'] for z in physical_refs),'canonical_JSON_fullread':True,'shards':shard_summary,'label_counts':outcome['counts'],'label_records':4356,'samecase_model_aliases':aliases,'samecase_alias_hash_ledger':alias_digest.hexdigest(),'local_certificate_kinds':dict(certs),'old_qualification_full_event_hashes':qevents,'old_qualification_counts':oldq['counts'],'new_qualification_counts':newq['counts'],'new_qualification_normal_summaries':f_q_summaries,'actual_F_all17_factual_metric_joins':expected_facts,'actual_F_observed_and_declared_budget_callbacks':738,'actual_F_family_trace_bookkeeping':trace_summary,'complete_contact_cover_rows':len(expected_contacts),'contact_cover_hash':sha(expected_contacts),'actual_F_qualified_receipt':factor_check,'per_arm':arm_summaries,'CSP_arm_certificate_structure':all_proof_shapes,'all8_comparisons':comparison_summaries,'clocks':{k:cust[k] for k in ('Popen_call_seconds','before_Popen_through_owned_wait_seconds','after_Popen_return_through_owned_wait_seconds','observer_main_entry_before_final_receipt_seconds')},'worker_main_entry_prefinal_seconds':result['worker_main_entry_before_final_result_seconds'],'resource_observations':{'worker_SELF_prefinal_bytes':result['worker_lifetime_RSS_bytes_at_sample'],'owned_child_lifetime_bytes':cust['owned_child_lifetime_RSS_highwater_bytes'],'observer_SELF_presample_bytes':cust['observer_lifetime_RSS_highwater_bytes_at_sample'],'no_sum_or_exact_tree_claim':True},'reported_phase_scalars':{'label_elapsed':outcome['label_elapsed'],'sole_F_call':outcome['factor_call_elapsed'],'complete_factor_and_checks':outcome['synthesis_elapsed']},'scope':'Entire current JSON parsed and whole rawpins joined. Fresh independent hash/type/schema/fieldalias/counter/trace/certificate-shape associations only. No point/contact/CSP/proof semantic checker, factorizer/reference closure, solver, fixture/model constructor, scientific import/helper/CLI invoked or replayed. Mathematical truth uses prior complete Source peers plus independent checks actually executed inside authenticated once; main full states were runtime-checked but only digests retained.','subject_calls':0}
b=(json.dumps(support,sort_keys=True,ensure_ascii=True,indent=2)+'\n').encode();path=out/'family-whole-actual-complete-raw-structural-support-v1.json';path.open('xb').write(b)
print(json.dumps(ref(path,b)));print(json.dumps({'physical':len(physical_refs),'artifacts_before_result':len(arts),'workerJSON_total_bytes':cust['named_worker_output_bytes'],'aliases':aliases,'F_metric17':expected_facts,'pairs':comparison_summaries,'arm_statuses':dict(collections.Counter(x['data']['return']['status'] for x in arm_packets.values()))}))
