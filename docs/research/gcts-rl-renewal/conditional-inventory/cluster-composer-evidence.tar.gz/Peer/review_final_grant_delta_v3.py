"""Saved authorization/descriptor-only delta; no scientific code is loaded."""
from pathlib import Path
import hashlib,json
C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
checks=[];pins={}
def raw(p):return Path(p).read_bytes()
def word(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 b=raw(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def j(p):return json.loads(raw(p))
def need(n,v,d=None):
 checks.append(dict(check=n,passed=bool(v),detail=d))
 if not v:raise AssertionError(n)
def pin(d):
 if d['path'] not in pins:
  a=desc(d['path']);need('whole_raw_pin:'+d['path'],a==d);pins[d['path']]=a
 else:need('repeated_pin_consistency:'+d['path'],pins[d['path']]==d)
 return d
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_bytes((json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode());return desc(p)
def contains(v,x):
 if word(v)==word(x):return True
 if type(v)is dict:return any(contains(a,x) for a in v.values())
 if type(v)is list:return any(contains(a,x) for a in v)
 return False
adoption=pin(dict(path=str(D/'ROOT-scope-adoption-and-grants-v3.json'),bytes=4472,
 sha256='756cc929eee97dd38e184d389c8069863393f5e4a9feac1d71fb1e77618b4de8'))
ad=j(adoption['path']);prpin=pin(dict(path=str(C/'typed-prospective-plan-review-v3.json'),bytes=25620,
 sha256='5f6951598ad135d729948a59c0e7bc91d77cbdbaad7707b3d339aed65aa0553d'))
pr=j(prpin['path'])
need('current_prospective_positive',pr['prospective_review_passed'] is True and pr['actual_execution_authorized'] is False)
expected={
 'current_components_Source':pr['current_components_Source'],
 'once_Source':pr['current_once_Source'],
 'prospective_plans':prpin}
need('Root_adoption_exact_three_roles',ad['review_roles']==expected and ad['source_scopes_adopted'] is True)
reviews={}
for role,d in expected.items():pin(d);reviews[role]=j(d['path'])
for d in reviews['current_components_Source']['subjects']+reviews['once_Source']['subjects']:pin(d)
pin(pr['declaration']);pin(pr['runtime_closure'])
cl=j(pr['runtime_closure']['path']);declaration=j(pr['declaration']['path'])
for d in [cl['runtime']['Python_executable'],cl['current_master']]:pin(d)
need('all_four_grants_present_only_current_arms',len(ad['plans'])==len(pr['subjects'])==4)
plans=[];actuals=[];terminals=[];authpaths=[]
for i,(entry,before) in enumerate(zip(ad['plans'],pr['subjects'])):
 pp,ap=pin(entry['once_plan']),pin(entry['authorization'])
 p,a=j(pp['path']),j(ap['path']);fp=pin(before['false_once_plan']);f=j(fp['path'])
 need('only_authorization_field_changes:'+str(i),set(p)==set(f) and [k for k in p if word(p[k])!=word(f[k])]==['authorization'])
 need('false_sentinel_preserved:'+str(i),f['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',sha256='NO_AUTHORIZATION',bytes=0))
 need('true_descriptor_exact:'+str(i),p['authorization']==ap and p['authorization']!=f['authorization'])
 subject={k:v for k,v in p.items() if k!='authorization'};sha=hashlib.sha256(word(subject)).hexdigest()
 need('exact_complete18_subject_values_and_hash:'+str(i),len(subject)==18 and word(subject)==word(before['subject']) and sha==before['subject_sha256']==entry['subject_sha256'])
 need('declared_original_schedule_order:'+str(i),p['invocation_id']==before['invocation_id']==declaration['schedule'][i]['invocation_id'] and
 (p['mode'],p['search_ordering'])==(entry['mode'],entry['search_ordering']) and declaration['schedule'][i]['order']==i+1)
 need('exact_sevenfield_true_Root_grant:'+str(i),set(a)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'} and
 a['schema']=='ROOT-owned-evidence-integration-once-authorization-v1' and a['author_identity']=='/root' and
 a['actual_execution_authorized'] is True and type(a['maximum_actual_invocations'])is int and a['maximum_actual_invocations']==1 and a['subject_sha256']==sha)
 need('exact_three_current_role_keys:'+str(i),set(a['review_roles'])==set(expected))
 worker=j(pin(before['worker_plan'])['path'])
 minimum={
 'current_components_Source':list(worker['project_sources'].values())+list(worker['components'].values())+list(cl['evidence_sources'].values())+list(cl['schema_sources'].values())+[p['cold']],
 'once_Source':[p['runner'],p['observer']],
 'prospective_plans':[p['integration_declaration'],p['runtime_closure'],p['worker_plan']]}
 for role,binding in a['review_roles'].items():
  review=reviews[role]
  need('exact_binding_schema:'+str(i)+':'+role,set(binding)=={'receipt','reviewer_identity','required_subjects'} and binding['receipt']==expected[role] and binding['reviewer_identity']=='/root/conventional_control_review')
  need('review_status_and_identity:'+str(i)+':'+role,review['reviewer_identity']=='/root/conventional_control_review' and review['author_identity']!='/root/conventional_control_review' and
   review['source_only'] is True and review['scientific_acceptance'] is False and review['actual_execution_authorized'] is False and type(review['scientific_calls'])is int and review['scientific_calls']==0 and
   review['prospective_review_passed' if role=='prospective_plans' else 'source_review_passed'] is True)
  need('all_minimum_fullsubjects_bound:'+str(i)+':'+role,len(binding['required_subjects'])>=len(minimum[role]) and all(d in binding['required_subjects'] for d in minimum[role]))
  for d in binding['required_subjects']:
   need('exact_descriptor_occurs_in_review:'+str(i)+':'+role+':'+d['path'],type(d)is dict and set(d)=={'path','sha256','bytes'} and contains(review,d))
 actual=Path(p['actual_directory']);terminal=Path(pp['path']).parent/(Path(pp['path']).stem+'-terminal-observation')
 need('fresh_actual_and_observer_paths:'+str(i),not actual.exists() and not terminal.exists())
 need('fresh_once_markers_absent:'+str(i),not (actual/'CONSUMED.json').exists() and not (terminal/'CONSUMED.json').exists())
 actuals.append(str(actual));terminals.append(str(terminal));authpaths.append(ap['path'])
 plans.append(dict(invocation_id=p['invocation_id'],mode=p['mode'],search_ordering=p['search_ordering'],
  subject_sha256=sha,subject=subject,false_once_plan=fp,authorized_once_plan=pp,authorization=ap,
  actual_directory=str(actual),terminal_observation_directory=str(terminal)))
need('four_unique_never_consumed_subjects',len(set(actuals))==len(set(terminals))==len(set(authpaths))==4 and len({p['subject_sha256'] for p in plans})==4)
need('author_overlap_and_no_authority_promotion',ad['inherited_author_overlap_disclosed'] is True and ad['ROOT_resource_accepted'] is False and ad['mathematical_proof_accepted'] is False and ad['scientific_calls']==0)
audit=save('final-grant-delta-v3-raw-metadata-audit.json',dict(schema='quantified-composer-final-grant-delta-raw-audit-v3',
 reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,actual_execution_authorized=False,
 checks=checks,check_count=len(checks),mismatch_count=0,raw_pins=list(pins.values()),
 scope='Exact descriptor/auth-only ordinary JSON delta and filesystem absence only. No subject/component/module/function/fixture/Reader/codec/inverse/Native/Model/search was imported, called, decoded or replayed; no process-table probe.'))
review=save('typed-final-grant-delta-review-v3.json',dict(schema='owned-evidence-integration-final-grant-delta-review-v1',
 reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=True,
 final_grant_delta_review_passed=True,grant_delta_review_passed=True,scientific_calls=0,scientific_acceptance=False,
 mathematical_proof_admitted=False,full_pipeline_qualified=False,actual_execution_authorized=False,
 saved_data_only=True,component_imports=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,Native_calls=0,
 adoption=adoption,prospective_review=prpin,review_roles=expected,plans=plans,audit=audit,
 check_count=len(checks),mismatch_count=0,findings=[],
 conclusions=[
  'Each full18-field subject is literally and canonically unchanged from the current positive V3 false review. The sole once-plan field change is sentinel authorization to its exact fresh Root true/maxone seven-field descriptor. All four canonical subject hashes match the prospective receipt and Root grant/adoption independently.',
  'Exactly three scoped current review roles bind current component30/once2/prospective declaration+closure+worker minimum subjects. Every required exact three-field descriptor appears literally in the pinned typed receipt; all identities/status/no-science/no-authority fields match. One Control reviewer across three roles and inherited author overlap remain explicit.',
  'All current component/outer/Python/master/declaration/closure raw pins revalidated; input/profile/caps/environment/arm/Source fields are unchanged because the entire subject is unchanged. No new scientific or code factor is introduced by the grant metadata.',
  'Four distinct actual and corresponding authorized-observer directories/consumed markers were absent at review. FixedAND, symbolicAND, fixedcomposed, symboliccomposed order is unchanged; no consumed invocation is reused and no adaptive retuning is authorized by this receipt.',
  'Root grants and external precise scope adoption are separate human-owner authority. This peer receipt only confirms saved metadata consistency and point-in-time freshness, not execution authority, fit, proof/resource admission or process closure.'
 ],
 limitations=[
  'No code/function/module/fixture, Native wire or proof, Reader, inverse or codec evaluation/replay; ordinary metadata/raw hash checks only. No process-table query or continuous OS/Python integrity claim.',
  'Trusted exclusive-owner/loader/callable and inherited Source scope limits remain exact. No fullGCTS/RL/generalFOL/primitiveWang or causal speed advantage is inferred.',
  'Original30s/5000distinctunits,180positive-worker/knownexit and laterouter210,1GiB separate highwater SUM,128MiB physical+logical,4MiB logs and all private counters remain unchanged. Failed/UNKNOWN/fulloutput-incomplete outcomes cannot be rescued or retried.',
  'Stop all tools after handoff and remain idle during the four Root-controlled serial bounded actuals until authoritative terminal/cohort closure release.'
 ],tools_stopped_after_handoff=True))
print(json.dumps(dict(review=review,audit=audit,checks=len(checks),mismatch_count=0),sort_keys=True))
