"""Saved prelaunch failure only; no process probe or scientific code execution."""
from pathlib import Path
import ast,hashlib,json
C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
T=D/'plans-v2/once-plans/quantified-composer-006-fixed-and-support-ROOT-20261019-v1-terminal-observation'
checks=[]
def raw(p):return Path(p).read_bytes()
def j(p):return json.loads(raw(p))
def word(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 b=raw(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(n,v,d=None):
 checks.append(dict(check=n,passed=bool(v),detail=d))
 if not v:raise AssertionError(n)
def pin(d):need('whole_raw_pin:'+d['path'],desc(d['path'])==d);return d
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_bytes((json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode());return desc(p)
terminal=desc(T/'terminal.json');t=j(terminal['path']);marker=desc(T/'CONSUMED.json');mk=j(marker['path'])
stdout=desc(T/'stdout.bin');stderr=desc(T/'stderr.bin');err=raw(stderr['path']).decode()
p=j(pin(t['plan'])['path']);w=j(pin(p['worker_plan'])['path']);d=j(pin(p['integration_declaration'])['path']);cl=j(pin(p['runtime_closure'])['path'])
runner=pin(p['runner']);observer=pin(p['observer']);rt=raw(runner['path']).decode();ot=raw(observer['path']).decode()
need('observer_marker_exact_once_plan',mk['plan']==t['plan'] and mk['maximum_runner_launches']==1 and mk['started_ns']==t['observer_started_ns'])
need('saved_runner_failed_prelaunch',t['runner_exit_code']==1 and t['terminal_gate_passed'] is False and t['ROOT_resource_accepted'] is False and t['mathematical_proof_accepted'] is False)
need('zero_stdout_full_traceback',stdout['bytes']==0 and stderr['bytes']==1001 and 'OnceRunnerError: full current integration declaration binding' in err and 'line 184, in intake_subject' in err and 'line 257, in run_once' in err)
need('exact_observed_interval',t['terminal_observed_ns']>t['observer_started_ns'] and
 (t['terminal_observed_ns']-t['observer_started_ns'])/1e9==t['observed_instrument_elapsed_seconds']==0.058430875)
outer_binding={
 'schema':d['schema']=='ROOT-quantified-composer-four-arm-declaration-v1',
 'runtime_closure_descriptor':d['runtime_closure']==p['runtime_closure'],
 'parent_structural_full_descriptor':d['parent_structural_declaration']==w['declaration'],
 'selected_receiver_id':d['selected_receiver_id']==p['receiver_id'],
 'result_reader':d['result_reader']==p['result_reader']}
need('only_parent_structural_conjunct_false',outer_binding==dict(schema=True,runtime_closure_descriptor=True,parent_structural_full_descriptor=False,selected_receiver_id=True,result_reader=True))
left,right=d['parent_structural_declaration'],w['declaration'];pin(left);pin(right)
need('mismatch_path_only',left['path']!=right['path'] and left['bytes']==right['bytes']==22422 and
 left['sha256']==right['sha256']=='1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0' and raw(left['path'])==raw(right['path']))
tree=ast.parse(rt);run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_once')
intake=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='intake_subject')
intake_call=next(n for n in ast.walk(run) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='intake_subject')
mkdir=next(n for n in ast.walk(run) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='mkdir' and isinstance(n.func.value,ast.Name) and n.func.value.id=='os')
popen=next(n for n in ast.walk(run) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='Popen')
need('failure_before_actual_mkdir_and_scientific_Popen',intake_call.lineno==257 and mkdir.lineno==268 and popen.lineno==353 and intake_call.lineno<mkdir.lineno<popen.lineno)
need('cold_would_require_same_full_descriptor',"integration['parent_structural_declaration']==plan['declaration']" in raw(p['cold']['path']).decode())
need('observer_reaps_runner_before_terminal_source',"code=process.wait(timeout=225)" in ot and "runner_exit_code=code" in ot)
manifest=desc(D/'false-plan-manifest-v2.json');m=j(manifest['path']);outcomes=[]
for i,row in enumerate(m['plans']):
 actual=Path(row['row']['actual_directory']);name=Path(row['false_once_plan']['path']).name
 term=D/'plans-v2/once-plans'/(Path(name).stem+'-terminal-observation')
 need('no_scientific_actual_directory:'+str(i),not actual.exists() and not (actual/'CONSUMED.json').exists())
 if i==0:need('first_observer_only',term==T and term.exists())
 else:need('remaining_observers_not_run:'+str(i),not term.exists())
 outcomes.append(dict(invocation_id=row['row']['invocation_id'],mode=row['row']['mode'],search_ordering=row['row']['search_ordering'],
  status='PRE_SCIENTIFIC_INTAKE_FAILURE' if i==0 else 'NOT_RUN_AFTER_COMMON_PROTOCOL_ABORT',
  scientific_outcome=None,actual_directory=str(actual),actual_directory_absent=True,observer_directory=str(term),observer_directory_exists=term.exists()))
prior=pin(desc(C/'typed-prospective-plan-review-v2.json'));delta=pin(desc(C/'typed-final-grant-delta-review-v2.json'))
need('original_reviews_retained',j(prior['path'])['prospective_review_passed'] is True and j(delta['path'])['final_grant_delta_review_passed'] is True)
new_obligations=[
 dict(id='O1_outer_complete_worker_once',requirements='Exact schema/key sets; every invocation/mode/ordering/certification/path/cold/Python/receiver/storage/reader/declaration/closure worker-once field;22project+2component keys and full28aliases plus separate schema1.'),
 dict(id='O2_outer_all_five_declaration_conjuncts',requirements='Check schema, declaration.runtime_closure==once.runtime_closure, declaration.parent_structural_declaration==worker.declaration as FULL descriptor including path, selected_receiver_id and result_reader independently for each of four subjects. Equal SHA/bytes alone never replaces a required descriptor equality.'),
 dict(id='O3_outer_profile_schedule_limits',requirements='Exact evidence/profile Sources and finalization profile, unique four IDs/actual paths, exact method-by-ordering product, current row full fields, scientific constants and outer limits/environment; no inherited stale scope claim.'),
 dict(id='O4_cold_all_intake_joins',requirements='Exact capsule1a42 hash AND declared structural descriptor path; current integration parent_structural==worker.declaration and selectedreceiver/current schedule match; unique full selected receiver; parent rawclosure214e; expected22project replacements and full component/evidence/schema/native/Python/Z3 maps/aliases; Source-bound literal evidence and finalization profiles. Verify every metadata-only conjunct, not just version/schema or descriptor containment.'),
 dict(id='O5_fresh_subjects_and_lineage',requirements='Preserve failed V2 observer/marker/logs/terminal and all old subjects/receipts. Fresh V3 allfour invocation IDs, actual paths and once paths; no reuse of the attempted observer subject. Three remaining old arms stay NOT_RUN, not UNKNOWN or failed scientific results. Exact7new Source bytes/caps/input/profile unchanged; corrected metadata is a real subject change and needs a new full prospective review/grants/final delta.'),
 dict(id='O6_scope',requirements='Source PASS establishes reviewed code/ancestry only. It does not establish that a supplied metadata tuple satisfies every runtime guard or has executed successfully. Protected loader/OS and all fullpoint/Native/inverse/resource gates remain; no new proof or benefit claim.')]
obpin=save('prospective-guard-contract-obligations-v3.json',dict(schema='quantified-composer-prospective-guard-contract-obligations-v3',
 author_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,actual_execution_authorized=False,
 obligations=new_obligations,root_correction_pending=True,source_references=[runner,p['cold']],
 scope='Predeclared saved ordinary metadata comparisons for a fresh tuple. No subject guard/intake/cold function or fixture may be executed by this review.'))
audit=save('prelaunch-failure-v2-raw-audit.json',dict(schema='quantified-composer-prelaunch-failure-raw-audit-v2',
 reviewer_identity='/root/conventional_control_review',saved_data_only=True,source_only=True,scientific_calls=0,
 actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,
 outer_binding_conjuncts=outer_binding,scope='Ordinary metadata/raw pins/Source AST order/filesystem absence only; no process probe or subject replay.'))
review=save('typed-prelaunch-failure-review-v2.json',dict(schema='quantified-composer-prelaunch-failure-saved-review-v2',
 reviewer_identity='/root/conventional_control_review',author_identity='/root',saved_review_passed=True,
 saved_data_only=True,source_only=True,scientific_calls=0,scientific_acceptance=False,mathematical_proof_admitted=False,
 resource_admission=False,full_pipeline_qualified=False,actual_execution_authorized=False,
 component_imports=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,Native_calls=0,search_calls=0,
 actual_outcome='COHORT_ABORTED_BEFORE_SCIENTIFIC_WORKER',outcomes=outcomes,
 terminal=terminal,observer_consumed_marker=marker,stdout=stdout,stderr=stderr,once_plan=t['plan'],worker_plan=p['worker_plan'],
 declaration=p['integration_declaration'],runtime_closure=p['runtime_closure'],runner=runner,observer=observer,
 descriptor_mismatch=dict(declaration_parent_structural=left,worker_declaration=right,
  exact_bytes_equal=True,sha256_equal=True,path_equal=False,full_descriptor_equal=False),
 intake_binding_conjuncts=outer_binding,observer_runner_launches=1,scientific_worker_launches=0,
 observed_instrument_elapsed_seconds=t['observed_instrument_elapsed_seconds'],saved_runner_exit_code=1,
 Root_authoritative_observer_exit_code=2,terminal_gate_passed=False,
 source_order=dict(intake_call_line=intake_call.lineno,actual_mkdir_line=mkdir.lineno,scientific_Popen_line=popen.lineno),
 prior_prospective_PASS_superseded_for_readiness=prior,prior_auth_delta_review=delta,
 peer_error_disclosure='Control failed to check the FULL declaration.parent_structural_declaration==worker.declaration descriptor conjunction, including path, while reviewing the false metadata. Prior prospective PASS therefore overclaimed this binding and is invalid as readiness evidence. The raw original review stays immutable. Auth-only delta comparisons remained literal-correct but could not establish missing intake conformance.',
 Source_scope_disposition='Existing Source reviews retain only their original code/ancestry/no-runtime scope. No executable defect is established by this descriptor mismatch; code correctly failed closed before scientific launch. A Source PASS never meant this metadata tuple would pass intake or runtime qualification.',
 required_successor_obligations=obpin,audit=audit,check_count=len(checks),mismatch_count=0,findings=[],
 conclusions=[
  'The saved observer consumed exactly one runner plan and captured a normal exit1 traceback at intake_subject line184 via run_once line257. The failed full descriptor path conjunction is independently reconstructed; the other four conjuncts are true. The two capsule files have identical complete raw bytes/hash/length and different literal paths.',
  'Source order places that failing call before actualmkdir268 and scientificPopen353. The first actual directory/CONSUMED/worker/Native/results do not exist; all four scientific actual directories are absent. The observer did launch the metadata runner once; this is not a no-process event.',
  'Only the first observer folder/marker/logs/terminal exists. Remaining three arms are NOT_RUN after the Root-authoritative common-protocol abort; they have no scientific search outcome. No proof, Model/schema/runtime/resource result or scientific timing can be inferred.',
  '0.058430875seconds is the retained observer-main metadata-runner failure interval, not proof/search/compiler/inverse performance. No scientific worker/Native highwater exists or is admitted. Observer Source waited the runner before final terminal; no independent current-process-table probe or scientific process-group observation was made by this peer.',
  'Preserve the failed observer attempt and all obsolete grants/subjects. Fresh corrected cohort metadata must bind the exact worker structural descriptor and all other cold/outer conjuncts, with distinct IDs/actual/plan/observer paths, unchanged code/input/caps and new reviews/grants. This is not an unchanged subject retry.'
 ],limitations=['Saved evidence/Source reasoning only; no subject/module/function/helper/fixture/Reader/codec/inverse/Native/Model/search evaluation or opaque decode.',
 'Saved-data review PASS means the negative evidence is consistent, not qualification. All historical proof/UNKNOWN/component outcomes retain their own status. No GCTS/RL/new theorem/causal performance claim.',
 'Root authoritative closure/release is relied on for resuming this metadata audit. No OS process probe, live resource reconstruction or new worker launch was performed.'],
 tools_stopped_after_handoff=True))
print(json.dumps(dict(review=review,audit=audit,obligations=obpin,checks=len(checks)),sort_keys=True))
