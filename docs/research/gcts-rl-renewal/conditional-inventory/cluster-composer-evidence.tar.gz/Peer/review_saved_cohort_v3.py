"""Independent saved-byte/ordinary-JSON audit. No project code is imported."""
from pathlib import Path
from collections import Counter
import hashlib,json,math

D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
checks=[];pins={};rows=[]
def raw(p):return Path(p).read_bytes()
def word(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 b=raw(p);return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def j(p):return json.loads(raw(p))
def need(n,v,detail=None):checks.append({'check':n,'passed':bool(v),'detail':detail})
def pin(d):
 if d['path'] not in pins:
  a=desc(d['path']);need('raw_pin:'+d['path'],a==d);pins[d['path']]=a
 else:need('consistent_pin:'+d['path'],pins[d['path']]==d)
 return d
def pin_tree(o):
 if type(o)is dict:
  if set(o)=={'path','sha256','bytes'}:pin(o)
  else:
   for v in o.values():pin_tree(v)
 elif type(o)is list:
  for v in o:pin_tree(v)
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_bytes((json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode());return desc(p)
def same(a,b):return word(a)==word(b)
def contains(o,x):
 if same(o,x):return True
 if type(o)is dict:return any(contains(v,x) for v in o.values())
 if type(o)is list:return any(contains(v,x) for v in o)
 return False

closure_pin=pin({'path':str(D/'ROOT-cohort-V3-closure-v1.json'),'sha256':'902e62a5bdd90876205b2e4bc69a5109abe91b23a750b2bd0078236477456cec','bytes':16220})
root=j(closure_pin['path'])
adoption_pin=pin({'path':str(D/'ROOT-scope-adoption-and-grants-v3.json'),'sha256':'756cc929eee97dd38e184d389c8069863393f5e4a9feac1d71fb1e77618b4de8','bytes':4472})
ad=j(adoption_pin['path'])
prospective_pin=pin({'path':str(C/'typed-prospective-plan-review-v3.json'),'sha256':'5f6951598ad135d729948a59c0e7bc91d77cbdbaad7707b3d339aed65aa0553d','bytes':25620})
pr=j(prospective_pin['path'])
delta_pin=pin({'path':str(C/'typed-final-grant-delta-review-v3.json'),'sha256':'4f38eca55f261f4b38b0f2dfe5924a1fe862ad4e9e5a09576275c1b01c410da8','bytes':22832})
delta=j(delta_pin['path'])
need('final_delta_was_positive_and_no_actual_authority',delta['final_grant_delta_review_passed'] is True and delta['actual_execution_authorized'] is False)
need('current_prospective_was_positive_not_runtime_certification',pr['prospective_review_passed'] is True and pr['actual_execution_authorized'] is False)
cl=j(pin(pr['runtime_closure'])['path']);declaration=j(pin(pr['declaration'])['path'])
expected_roles={'current_components_Source':pr['current_components_Source'],'once_Source':pr['current_once_Source'],'prospective_plans':prospective_pin}
need('adoption_three_exact_roles',same(ad['review_roles'],expected_roles))
review_packets={}
for role,d in expected_roles.items():
 review_packets[role]=j(pin(d)['path'])
 if role!='prospective_plans':
  for s in review_packets[role]['subjects']:pin(s)
pin(cl['current_master']);pin(cl['runtime']['Python_executable'])
pin_tree(cl['stdlib_entry_references']);pin_tree(cl['new_direct_stdlib_entry_references'])
need('component30_current_and_once2',len(review_packets['current_components_Source']['subjects'])==30 and len(review_packets['once_Source']['subjects'])==2)
need('all4_completed_authoritative_handles',len(root['rows'])==len(ad['plans'])==len(pr['subjects'])==4 and root['all_owned_exec_handles_closed'] is True and root['all_four_scientific_worker_launches_closed'] is True)
need('authoritative_exec_handle_order',[r['owned_exec_handle'] for r in root['rows']]==[61804,49106,63507,19635])
pin(root['prior_setup_failure']);pin(root['launch_record_defect'])
old_peer=pin(desc(C/'typed-prelaunch-failure-review-v2.json'))
defect=j(root['launch_record_defect']['path'])
need('launch_record_defect_retained_not_backdated',defect['old_barrier_file_created'] is False and 'KeyError' in defect['metadata_record_defect'] and 'following launch still ran' in defect['metadata_record_defect'])
need('Root_launch_defect_claims_only_attributed',defect['author_identity']=='/root' and defect['no_source_input_cap_or_schedule_change'] is True)
previous_terminal=None;native_census=[];last_wires=[];source_copy_count=0
for i,(rr,grant,before) in enumerate(zip(root['rows'],ad['plans'],pr['subjects'])):
 tag=str(i)+':'+rr['mode']+':'+rr['search_ordering']
 for k in ('consumed_marker','runner_receipt','terminal','worker_failure'):pin(rr[k])
 pin_tree(rr['logs']);pin_tree(rr['observer_logs'])
 pp,ap=pin(grant['once_plan']),pin(grant['authorization'])
 p,a=j(pp['path']),j(ap['path']);wp=pin(p['worker_plan']);w=j(wp['path'])
 fp=pin(before['false_once_plan']);fplan=j(fp['path'])
 subject={k:v for k,v in p.items() if k!='authorization'};sha=hashlib.sha256(word(subject)).hexdigest()
 need('whole18_subject_unchanged:'+tag,len(subject)==18 and same(subject,before['subject']) and sha==before['subject_sha256']==grant['subject_sha256'])
 need('auth_only_delta_still_exact:'+tag,set(p)==set(fplan) and [k for k in p if not same(p[k],fplan[k])]==['authorization'] and p['authorization']==ap)
 need('sevenfield_true_max1_Root_grant:'+tag,set(a)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'} and a['author_identity']=='/root' and a['actual_execution_authorized'] is True and type(a['maximum_actual_invocations'])is int and a['maximum_actual_invocations']==1 and a['subject_sha256']==sha)
 need('full_worker_subject_binding:'+tag,w['invocation_id']==p['invocation_id']==declaration['schedule'][i]['invocation_id'] and w['actual_directory']==p['actual_directory'] and w['mode']==p['mode'] and w['search_ordering']==p['search_ordering'] and w['receiver_id']==p['receiver_id']=='prospective-fol-20261018-006')
 need('declaration_fullcapsule_descriptor_binding:'+tag,same(w['declaration'],declaration['input_capsule']) and same(w['declaration'],declaration['parent_structural_declaration']) and same(w['integration_declaration'],p['integration_declaration']) and same(w['runtime_closure'],p['runtime_closure']))
 pin_tree(w['native_inputs']);pin(w['policy']);pin(w['declaration']);pin(w['python']);pin_tree(w['z3'])
 for role,binding in a['review_roles'].items():
  need('exact_role_receipt:'+tag+':'+role,binding['receipt']==expected_roles[role] and binding['reviewer_identity']=='/root/conventional_control_review')
  for s in binding['required_subjects']:need('required_exact_subject_in_receipt:'+tag+':'+role+':'+s['path'],contains(review_packets[role],s))
 need('same_three_review_role_keys:'+tag,set(a['review_roles'])==set(expected_roles))
 run=j(rr['runner_receipt']['path']);fail=j(rr['worker_failure']['path']);mark=j(rr['consumed_marker']['path']);term=j(rr['terminal']['path'])
 actual=Path(p['actual_directory']);obs=Path(rr['terminal']['path']).parent;omp=pin(desc(obs/'CONSUMED.json'));om=j(omp['path'])
 need('exact_current_sourceplan_and_grant_receipts:'+tag,run['plan']==mark['plan']==term['plan']==om['plan']==pp and run['authorization']==ap and run['runtime_closure']==p['runtime_closure'] and run['integration_declaration']==p['integration_declaration'] and same(run['review_roles'],a['review_roles']) and run['subject_sha256']==sha)
 need('same_saved_arm_fields:'+tag,all(run[k]==mark[k]==p[k] for k in ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader')))
 need('once_worker_and_runner_consumption:'+tag,mark['consumed_before_Popen'] is True and mark['maximum_worker_launches']==1 and run['consumed_once'] is True and run['worker_launch_attempts']==1 and om['maximum_runner_launches']==1 and om['started_ns']==term['observer_started_ns'])
 need('known_python_worker_exit1_reaped:'+tag,run['python_exit_code']==rr['worker_exit_code']==1 and run['python_wait4_status']==256 and run['python_reaped'] is True and run['worker_pid_observed'] is True and run['python_pid']==run['owned_pgid'])
 need('outer_observer_exec_exit2_separate:'+tag,term['runner_exit_code']==rr['runner_exit_code']==rr['observer_exit_code']==rr['owned_exec_exit_code']==2 and term['runner_receipt']==rr['runner_receipt'])
 need('terminal_command_exact_python_and_current_runner:'+tag,term['command']==[p['python']['path'],'-I','-S','-B',p['runner']['path'],pp['path']])
 need('limits_literal_plan_and_original_numeric_caps:'+tag,same(run['limits'],p['limits']) and p['limits']['work_seconds']==180 and p['limits']['overall_seconds']==210 and p['limits']['aggregate_peak_bytes']==1073741824 and p['limits']['result_bytes']==134217728 and p['limits']['stderr_bytes']==p['limits']['stdout_bytes']==4194304)
 began=run['began_ns'];wd=run['work_deadline_ns'];od=run['overall_deadline_ns'];end=term['terminal_observed_ns']
 need('sourceentry_deadlines_and_consumed_clocks:'+tag,began==mark['began_ns'] and wd==mark['work_deadline_ns']==began+180000000000 and od==mark['overall_deadline_ns']==began+210000000000)
 need('known_cleanup_order_before210_after180:'+tag,wd<run['worker_terminal_observed_ns']<=run['postreap_group_and_pipe_closed_ns']<=run['checks_closed_ns']<=end<od and term['observer_started_ns']<=began)
 elapsed=(end-began)/1e9;observed=(end-term['observer_started_ns'])/1e9
 need('exact_terminal_clock_arithmetic:'+tag,elapsed==term['runner_clock_elapsed_seconds']==rr['runner_terminal_seconds'] and observed==term['observed_instrument_elapsed_seconds'])
 need('serial_only_after_previous_terminal:'+tag,previous_terminal is None or term['observer_started_ns']>previous_terminal);previous_terminal=end
 need('group_absence_permanent_latch_and_no_signals:'+tag,run['owned_group_absent'] is True and run['owned_group_reappearance_observed_ns'] is None and run['owned_group_probe_count']>=1 and run['owned_group_first_absent_ns']<=run['owned_group_last_probe_ns']<end and run['signals']==[])
 need('whole_python_and_log_custody_saved_scope:'+tag,run['python_custody']['python']==p['python'] and run['python_custody']['whole_baseline_authenticated'] is True and run['python_custody']['formal_continuous_seal'] is False and run['python_custody']['trusted_OS_metadata_assumption'] is True)
 need('worker_and_observer_log_complete_with_caps:'+tag,run['stdout_eof'] is True and run['stderr_eof'] is True and run['log_capture_complete'] is True and same(run['outputs'],rr['logs']) and run['stdout_bytes']==rr['logs']['stdout']['bytes']==0 and run['stderr_bytes']==rr['logs']['stderr']['bytes']<=4194304 and all(v['bytes']<=4194304 for v in rr['observer_logs'].values()))
 need('all_acceptance_flags_false:'+tag,all(fail[k] is False for k in ('complete_output_accepted','logical_proof_accepted','resource_accepted','retry_authorized','scientific_acceptance')) and all(run[k] is False for k in ('ROOT_resource_accepted','resource_candidate_accepted','logical_proof_transport_candidate','mathematical_proof_accepted','scientific_acceptance')) and all(term[k] is False for k in ('ROOT_resource_accepted','mathematical_proof_accepted','scientific_acceptance','terminal_gate_passed')))
 need('missing_final_result_header_forest_not_rescued:'+tag,all(not (actual/n).exists() for n in ('result.json','worker-receipt.json','evidence-forest.json')) and fail['driver_returned_receipt'] is None and fail['result_already_published'] is None and fail['diagnostic_output_prefixes']==[] and run['worker_receipt'] is None and run['native_transport'] is None)
 need('exact_deadline_failure_no_cleanup_error:'+tag,fail['error_type']=='_DeadlineStop' and fail['message']=='receiver cooperative work deadline' and fail['cleanup_errors']==[] and run['errors'][0]['type']=='OnceRunnerError' and run['errors'][0]['message']=='normal exact Python exit0')
 stderr=raw(rr['logs']['stderr']['path']).decode('utf-8')
 need('raw_traceback_agrees_assemble_deadline:'+tag,'in assemble' in stderr and 'receiver cooperative work deadline' in stderr and 'semantic_receiver_driver._DeadlineStop' in stderr)
 nt=fail['native_transport'];queries=nt['request_stages'];purposes=Counter(x['purpose'] for x in queries)
 need('Native_closed_parent_worker_same_owned_group:'+tag,nt['closed'] is True and nt['all_reaped'] is True and nt['same_owned_process_group'] is True and nt['parent_pid']==nt['parent_pgid']==nt['native_pgid']==run['python_pid'] and nt['native_pid']!=run['python_pid'])
 need('Native_exit0_and_EOF_no_late_signals:'+tag,nt['native_exit_code']==rr['native_exit_code']==0 and nt['wait4_status']==0 and nt['cleanup_errors']==[] and nt['termination_signals']==[] and nt['stderr_complete'] is True and nt['stderr_bytes']==0 and nt['stdout_eof'] is True and nt['stdout_pending_bytes']==0)
 need('Native_transport_not_proof_or_resource_authority:'+tag,all(nt[k] is False for k in ('aggregate_resource_accepted','logical_proof_accepted','scientific_acceptance','CPP_self_reported_peak_is_resource_authority')) and nt['constructor_completed'] is True)
 need('Native24_exact_purpose_and_ID_census:'+tag,len(queries)==nt['complete_records']==rr['native_queries']==24 and purposes=={'first_order_theory_admission':1,'first_order_tautology':18,'first_order_scheme':5} and [q['ordinal'] for q in queries]==list(range(24)) and [q['record_id'] for q in queries]==list(range(24)))
 for q in queries:
  need('Native_stage_hash_only_complete:'+tag+':'+str(q['ordinal']),set(q)=={'input_sha256','output_sha256','request_sha256','limit','ordinal','record_id','purpose','stage'} and q['stage']=='COMPLETED' and q['limit']==1000000000 and all(len(q[k])==64 and all(c in '0123456789abcdef' for c in q[k]) for k in ('input_sha256','output_sha256','request_sha256')))
 need('Native_last_wire_only_raw_no_fullrequests:'+tag,set(x.name for x in (actual/'native').iterdir())=={'code.bin','input.bin','output.bin'})
 nfiles={k:pin(desc(actual/'native'/k)) for k in ('code.bin','input.bin','output.bin')}
 need('last_wire_hashjoins_exact:'+tag,nfiles['input.bin']['sha256']==queries[-1]['input_sha256'] and nfiles['output.bin']['sha256']==queries[-1]['output_sha256'] and nfiles['code.bin']['sha256']=='97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed')
 native_census.append(queries);last_wires.append(nfiles)
 wh=run['python_wait4_usage']['ru_maxrss'];nh=nt['wait4_usage']['ru_maxrss'];diagnostic_sum=wh+nh
 need('Native_highwater_join:'+tag,nh==nt['native_high_water_bytes']==rr['native_highwater_bytes'])
 need('worker_highwater_alone_and_sum_exceed1GiB:'+tag,type(wh)is int and wh==rr['worker_highwater_bytes'] and wh>1073741824 and diagnostic_sum>1073741824 and diagnostic_sum==rr['conservative_separate_sum_bytes'])
 need('accepted_aggregate_unavailable_not_posthocsum:'+tag,run['conservative_parent_plus_native_peak_bytes'] is None and run['live_group_memory_limit_claimed'] is False and run['perprocess_peaks_may_doublecount_conservatively'] is True)
 fo=fail['owned_finalization_observation'];ph=fo['phases'];stats=fail['owned_evidence_statistics'];co=fail['cold_observation'];counts=co['counts']
 need('exact_four_driver_phases_final_assemble_unfinished:'+tag,[v['phase'] for v in ph]==['oracle_close','transport_receipt_copy','native_records_copy','final_assemble'] and all(v['completed'] is True and v['action_returned'] is True and v['error_type'] is None for v in ph[:3]) and ph[-1]['completed'] is False and ph[-1]['action_returned'] is False and ph[-1]['returned_monotonic'] is None and ph[-1]['error_type']=='_DeadlineStop' and fo['completed'] is False)
 need('bounded_driver_observation_ordinary_no_authority:'+tag,all(fo[k] is False for k in ('authority','mathematical_authority','resource_authority')) and len(word(fo))<=65536 and fo['profile']=='owned-finalization-phase-instrumented-v1' and len(fo['passive_statistics'])==1 and fo['passive_statistics'][0]['label']=='before_final_assemble')
 assembly_open=ph[-1]['failure_observed_monotonic']-ph[-1]['started_monotonic']
 need('open_assembly_interval_arithmetic:'+tag,assembly_open==rr['assembly_open_seconds'] and assembly_open>0 and abs(ph[-1]['failure_observed_monotonic']-wd/1e9)<0.01)
 need('cold_prefix_cutoff_no_inverse_statistics:'+tag,co['inverse_statistics'] is None and co['snapshot_cutoff_ns']>=co['phases'][-1]['opened_at_failure_ns']>=wd and co['snapshot_cutoff_ns']<run['worker_terminal_observed_ns'] and co['truncated'] is False and co['diagnostic_errors']==0 and all(co[k] is False for k in ('authority','mathematical_authority','resource_authority')) and [v['phase'] for v in co['phases']]==['owned-adapter-boundary-diagnostics','driver_run'] and co['phases'][0]['state']=='RETURNED' and co['phases'][1]['state']=='OPEN_AT_FAILURE' and co['phases'][1]['error_type']=='_DeadlineStop')
 need('guard_aggregate_exact_but_nested:'+tag,counts['source_guard_invocations']==counts['source_guard_completed']==counts['source_guard_timed_intervals']==rr['source_guard_calls'] and counts['source_guard_failed']==0 and counts['source_guard_elapsed_ns']/1e9==rr['source_guard_nested_seconds'] and counts['overall_tick_invocations']>counts['source_guard_invocations'])
 stages=fail['stage_intervals']
 need('116_completed_intake_prefix_stages_only:'+tag,len(stages)==116 and stages[-1]['stage']=='owned-adapter-boundary-diagnostics' and all(s['started_ns']<=s['returned_ns']<=wd for s in stages) and all(stages[n]['returned_ns']<=stages[n+1]['started_ns'] for n in range(len(stages)-1)))
 need('passive_state_unsealed_not_a_qualified_document:'+tag,stats['failed'] is True and stats['authority'] is False and stats['arena']['authority'] is False and stats['arena']['lifecycle']=='ACTIVE' and stats['arena']['documents']==stats['arena']['physical_wire_bytes']==stats['arena']['logical_document_bytes']==0 and stats['arena']['roots']==171 and stats['arena']['nodes']==1110)
 need('private_counters_below400m_not_ownquota_failure:'+tag,0<stats['operations']<400000000 and 0<stats['arena']['counters']['work']<400000000)
 aliases={**cl['materialized_aliases'],**cl['schema_sources']}
 need('exact29_owned_module_files_no_extras:'+tag,len(aliases)==29 and set(x.name for x in (actual/'modules').iterdir())=={name+'.py' for name in aliases})
 ownedmap={}
 for name,original in aliases.items():
  pin(original);owned=pin(desc(actual/'modules'/(name+'.py')));ownedmap[name]={'original':original,'owned':owned}
  need('owned_source_equal_whole_original:'+tag+':'+name,owned['bytes']==original['bytes'] and owned['sha256']==original['sha256']);source_copy_count+=1
 need('selected_search_helper_driver_exact_current_map:'+tag,all(aliases[name]==w['project_sources'].get(name,w['components'].get(name,cl['evidence_sources'].get(name))) for name in ('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1','semantic_receiver_driver')))
 need('Root_report_negative_numbers_independently_match:'+tag,rr['assembly_completed'] is False and rr['memory_cap_exceeded'] is True and rr['resource_admitted'] is False and rr['admitted_search_result'] is False and rr['logical_proof_accepted'] is False and rr['complete_result_exists'] is False)
 rows.append({'mode':p['mode'],'search_ordering':p['search_ordering'],'invocation_id':p['invocation_id'],'subject_sha256':sha,'actual_directory':str(actual),'exec_handle_authoritatively_closed_by_Root':rr['owned_exec_handle'],'exec_exit_code_reported_by_Root':rr['owned_exec_exit_code'],
 'authorized_plan':pp,'authorization':ap,'worker_plan':wp,'consumed_marker':rr['consumed_marker'],'observer_consumed_marker':omp,'worker_failure':rr['worker_failure'],'runner_receipt':rr['runner_receipt'],'terminal':rr['terminal'],'worker_logs':rr['logs'],'observer_logs':rr['observer_logs'],
 'worker_pid':run['python_pid'],'native_pid':nt['native_pid'],'runner_pid':term['runner_pid'],'worker_exit':1,'Native_exit':0,'runner_exit':2,'observer_exec_exit_reported_by_Root':2,
 'runner_Sourceentry_terminal_seconds':elapsed,'observer_main_terminal_seconds':observed,'worker_knownexit_seconds':(run['worker_terminal_observed_ns']-began)/1e9,'checks_closed_seconds':(run['checks_closed_ns']-began)/1e9,
 'worker_highwater_bytes':wh,'Native_highwater_bytes':nh,'diagnostic_separate_highwater_sum_bytes':diagnostic_sum,'diagnostic_separate_highwater_sum_MiB':diagnostic_sum/1048576,'accepted_aggregate_bytes':None,
 'open_final_assemble_seconds':assembly_open,'source_guard_nested_seconds':counts['source_guard_elapsed_ns']/1e9,'source_guard_invocations':counts['source_guard_invocations'],'overall_tick_invocations':counts['overall_tick_invocations'],
 'adapter_operations':stats['operations'],'Arena_work':stats['arena']['counters']['work'],'owned_module_copy_count':len(ownedmap),'owned_Source_map':ownedmap,'Native_stage_count':len(queries),'Native_purpose_counts':dict(purposes),'last_Native_raw_files':nfiles,
 'result_available':False,'worker_header_available':False,'forest_available':False,'inverse_statistics_available':False,'search_status_available':False,'composer_use_or_benefit_established':False,'proof_admitted':False,'resource_admitted':False,'outcome':'INCOMPLETE_PRODUCTION_PROFILE_DEADLINE_AND_MEMORY_FAILURE'})

need('identical24_hash_stage_streams_across_arms',all(same(q,native_census[0]) for q in native_census))
need('identical_last_three_Native_rawbytes_across_arms',all(all(r[k]['sha256']==last_wires[0][k]['sha256'] and r[k]['bytes']==last_wires[0][k]['bytes'] for k in r) for r in last_wires))
need('116_current_owned_Source_copies_all_checked',source_copy_count==116)
mismatches=[v for v in checks if not v['passed']]
table=save('saved-cohort-v3-four-outcome-table.json',{'schema':'quantified-composer-four-negative-outcomes-v1','saved_data_only':True,'scientific_calls':0,'rows':rows,'memory_scope':'Darwin separate worker/Native wait4 highwaters summed diagnostically; not accepted runner ledger, live group RSS or simultaneous memory. Worker alone exceeds original 1 GiB in every arm.','time_scope':'Sourceentry terminal includes cleanup; unfinished assembly start-to-error is an open interval, not completed phase cost. Sourceguard intervals overlap phases and are not disjoint costs.'})
audit=save('saved-cohort-v3-raw-metadata-audit.json',{'schema':'quantified-composer-saved-negative-raw-audit-v1','reviewer_identity':'/root/conventional_control_review','saved_data_only':True,'scientific_calls':0,'check_count':len(checks),'mismatch_count':len(mismatches),'checks':checks,'raw_pins':list(pins.values()),'table':table,'no_subject_imports_or_calls':True,'no_Native_or_opaque_decoding':True,'no_independent_process_table_probe':True})
review=save('typed-saved-actual-review-v3.json',{'schema':'owned-evidence-composer-cohort-saved-negative-review-v1','reviewer_identity':'/root/conventional_control_review','author_identity':'/root','saved_data_only':True,'saved_review_passed':not mismatches,'scientific_calls':0,'component_imports':0,'component_calls':0,'fixture_calls':0,'codec_calls':0,'inverse_calls':0,'Native_calls':0,'opaque_decodes':0,'scientific_acceptance':False,'mathematical_proof_admitted':False,'resource_admitted':False,'full_pipeline_qualified':False,'actual_execution_authorized':False,'new_actuals_authorized':False,
 'cohort_closure':closure_pin,'grant_adoption':adoption_pin,'prospective_review':prospective_pin,'final_delta_review':delta_pin,'current_Source_roles':expected_roles,'prior_setup_failure_peer':old_peer,'launch_record_defect':root['launch_record_defect'],'table':table,'audit':audit,'check_count':len(checks),'mismatch_count':len(mismatches),'findings':mismatches,
 'verified_negative_evidence':['Four distinct V3 subjects/grants/consumptions match the earlier full eighteen-field prospective and final-delta review. Three current role bindings, all thirty current Source descriptors, all 116 owned module copies, full capsule/policy/Python/Z3/Native raw pins rejoin unchanged. No full final Source epoch exists because result/header never completed.',
 'All four workers escaped exact _DeadlineStop during unfinished final_assemble. Each worker exited1, runner2 and externally observed owner exec2; Native exited0. Recorded wait4 reaping, group absence/no reappearance latch, complete logs/pipe EOF, no late signals and serial after-terminal launch order agree. Closure is retained authority, not a newly performed process-table probe.',
 'No result.json, worker-receipt.json or evidence-forest.json exists; no returned driver receipt or saved result prefix exists. All acceptance flags remain false. The failed scientific intermediate state is unavailable and cannot be reconstructed into an admitted Model/search/proof or ranking/composer comparison.',
 'Each worker highwater alone exceeds original 1 GiB. Separately summing worker and Native wait4 peaks gives only a diagnostic conservative sum. Runner accepted aggregate is null; no resource admission or simultaneous/live group RSS claim is made.',
 'All 24 Native hash-stage entries match across all four arms: one theory, eighteen tautology, five scheme requests. No final-target-proof stage or full request/reply record is retained. The last raw three Native wire files match their hashes only; no Native wire, program or opaque gzip was decoded.',
 'Driver final_assemble was open for roughly 89 to 113 seconds before recorded deadline error; this is unfinished start-to-error observation. Cold Sourceguard aggregates roughly39 to40 seconds overlap work/phase intervals and cannot be subtracted or added as disjoint computation costs. Inverse timing/counters and downstream point/proof/fullreader results are unavailable.',
 'Original work180/terminal210/1GiB/physical and logical128MiB/log4MiB and private quotas were not increased. Assembly passive counters remain below private400m bounds; actual failure is deadline plus independently excessive memory. Complete logical/physical-output cap admission is unavailable.',
 'Root optional prelaunch barrier writer failed KeyError and following launch still proceeded. That orchestration mistake is retained, not backdated or silently repaired. Existing true grants and current peer review/final-delta pins remain verified separately; Root-only claims about human message receipt/peer idleness are attributed to Root, not newly observed by this saved audit.' ],
 'ancestry_and_trust':['Control authored inherited symbolic/AND-helper/outer protocol ancestors and earlier metadata reviews; current Library composer/consumers and Root driver/cold changes are distinct. This is independent saved-data consistency review, not fresh own Source certification or mathematical kernel validation.',
 'Earlier Control V2 prospective/final-delta missed capsule descriptor-path equality. The V2 setup failure and three NOT_RUN arms remain preserved; corrected V3 subjects were separately reviewed. Source PASS never promised runtime success.',
 'Saved raw bytes and ordinary JSON are trusted as retained evidence under the pinned Python/Darwin/exclusive-owner assumptions. Rehashing present originals and owned copies does not establish continuous OS/loader/callable integrity or recover missing final Source epochs.',
 'Finite proof adaptation is specialized; no complete primitive-Wang/GCTS master conformance, RL/learning, causal speed/RAM gain, generic quantified theorem, composer superiority or fullproof availability follows. Old outcomes/standalone qualification keep their historical status.' ],
 'tools_stopped_after_handoff':True})
handoff=save('saved-cohort-v3-review-handoff.json',{'schema':'quantified-composer-saved-review-handoff-v1','review':review,'audit':audit,'table':table,'scientific_calls':0,'mismatch_count':len(mismatches),'tools_stopped_after_handoff':True})
print(json.dumps({'review':review,'audit':audit,'table':table,'handoff':handoff,'check_count':len(checks),'mismatch_count':len(mismatches),'failures':mismatches},sort_keys=True))
