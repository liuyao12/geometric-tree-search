"""Narrow ordinary-metadata successor review. No scientific code is evaluated."""
from pathlib import Path
import hashlib,json
C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
checks=[];pins={}
def raw(p):return Path(p).read_bytes()
def word(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 b=raw(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def j(p):return json.loads(raw(p))
def need(n,v,d=None):
 checks.append(dict(check=n,passed=bool(v),detail=d))
 if not v:raise AssertionError(n)
def pin(d):
 if d['path'] not in pins:
  actual=desc(d['path']);need('whole_raw_pin:'+d['path'],actual==d);pins[d['path']]=actual
 else:need('repeated_pin_consistent:'+d['path'],pins[d['path']]==d)
 return d
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_bytes((json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode());return desc(p)
def diffs(a,b,p=''):
 if word(a)==word(b):return []
 if type(a)is dict and type(b)is dict:
  out=[]
  for k in sorted(set(a)|set(b)):
   q=p+'/'+k
   out.extend([q] if k not in a or k not in b else diffs(a[k],b[k],q))
  return out
 if type(a)is list and type(b)is list and len(a)==len(b):
  return [q for i,(x,y) in enumerate(zip(a,b)) for q in diffs(x,y,p+'/'+str(i))]
 return [p]
manifest=pin(dict(path=str(D/'false-plan-manifest-v2.json'),bytes=7718,sha256='c5bffc085ed3ae26790d484d1fc8bfabf72c7252da552f47093ec8729c0aa459'))
m=j(manifest['path']);delta_pin=pin(m['metadata_successor_delta']);delta=j(delta_pin['path']);oldm=j(pin(delta['parent_manifest'])['path'])
negative_pin=pin(desc(C/'typed-prospective-plan-review-v1-negative.json'));negative=j(negative_pin['path'])
components=pin(desc(C/'typed-components-Source-review-v1.json'));once=pin(desc(C/'typed-once-Source-review-v1.json'))
need('prior_v1_negative_two_findings_preserved',negative['prospective_review_passed'] is False and negative['finding_count']==2)
need('current_Source_scopes_positive',j(components['path'])['source_review_passed'] is True and j(once['path'])['source_review_passed'] is True)
artifact_deltas=[]
for d in delta['artifact_deltas']:
 pin(d['before']);pin(d['after']);actual=sorted(diffs(j(d['before']['path']),j(d['after']['path'])))
 need('exact_full_reported_delta:'+d['kind']+':'+d['after']['path'],actual==sorted(d['paths']))
 artifact_deltas.append(dict(kind=d['kind'],before=d['before'],after=d['after'],actual_changed_paths=actual))
need('exact_ten_successor_artifacts',len(artifact_deltas)==10)
clpin=pin(m['runtime_closure']);dpin=pin(m['declaration']);cl=j(clpin['path']);decl=j(dpin['path'])
oldcl=j(oldm['runtime_closure']['path']);olddecl=j(oldm['declaration']['path'])
need('declaration_current_conformance_corrected',decl['conformance'].startswith('Shared generic composer/ordering experiment.') and 'Representation adapter only' not in decl['conformance'])
need('closure_current_scientific_scope_corrected',cl['limitations'][3]!=oldcl['limitations'][3] and
 'Only out-of-band instrumentation changes' not in cl['limitations'][3])
need('no_hidden_declaration_changes',set(diffs(olddecl,decl))=={'/conformance','/runtime_closure/path','/runtime_closure/sha256','/runtime_closure/bytes'})
need('no_hidden_closure_changes',set(diffs(oldcl,cl))=={
 '/limitations/3','/metadata_builder/path','/metadata_builder/sha256','/metadata_builder/bytes',
 '/metadata_only_Root_review/path','/metadata_only_Root_review/sha256','/metadata_only_Root_review/bytes','/parent_metadata_authoring_context_only'})
need('full_scientific_sources_and_census_unchanged',all(cl[k]==oldcl[k] for k in
 ('project_sources','additional_nonseed_components','evidence_sources','schema_sources','cold','outer_sources','materialized_aliases','Source_AST_census','current_import_census_summary')))
need('full_input_runtime_profile_limits_and_schedule_unchanged',all(decl[k]==olddecl[k] for k in
 ('selected_receiver','selected_receiver_id','input_capsule','evidence_profile','limits','schedule','composer_policy','finalization_profile','current_sources','clock_scope','clock_memory_output_authority','failure_policy','success_reporting')))
for d in j(components['path'])['subjects']+j(once['path'])['subjects']:pin(d)
need('exact_thirty_current_source_subjects',len(j(components['path'])['subjects'])==30)
for d in (m['source_bindings'],m['metadata_builder'],m['metadata_only_Root_review'],cl['current_master']):pin(d)
expected_roles={
 'fixed_and_support', 'symbolic_and_support','fixed_composed_support','symbolic_composed_support'}
subjects=[];first_worker=None;actuals=[];false_terms=[]
for index,(entry,oldentry) in enumerate(zip(m['plans'],oldm['plans'])):
 need('original_schedule_row_unchanged:'+str(index),entry['row']==oldentry['row']==decl['schedule'][index])
 wp,fp=pin(entry['worker_plan']),pin(entry['false_once_plan']);w,p=j(wp['path']),j(fp['path'])
 ow,op=j(oldentry['worker_plan']['path']),j(oldentry['false_once_plan']['path'])
 need('worker_only_descriptor_rebind:'+str(index),set(diffs(ow,w))=={
 '/integration_declaration/bytes','/integration_declaration/path','/integration_declaration/sha256',
 '/runtime_closure/bytes','/runtime_closure/path','/runtime_closure/sha256'})
 need('false_once_only_descriptor_rebind:'+str(index),set(diffs(op,p))=={
 '/integration_declaration/bytes','/integration_declaration/path','/integration_declaration/sha256',
 '/runtime_closure/bytes','/runtime_closure/path','/runtime_closure/sha256','/worker_plan/path','/worker_plan/sha256'})
 need('strict_authorization_sentinel:'+str(index),p['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',sha256='NO_AUTHORIZATION',bytes=0))
 subject={k:v for k,v in p.items() if k!='authorization'}
 need('exact_subject18:'+str(index),len(subject)==18 and len(p)==19)
 need('exact_worker19:'+str(index),len(w)==19)
 need('full_literal_worker_declaration_closure_chain:'+str(index),p['worker_plan']==wp and w['runtime_closure']==clpin==p['runtime_closure'] and w['integration_declaration']==dpin==p['integration_declaration'])
 need('exact_selected_arm_row:'+str(index),all(p[k]==w[k]==entry['row'][k] for k in
 ('invocation_id','mode','search_ordering','receiver_id','inventory_certification_mode','actual_directory','model_storage','result_reader')))
 need('whole_source_maps_match_closure:'+str(index),w['project_sources']==cl['project_sources'] and w['components']==cl['additional_nonseed_components'] and p['cold']==w['cold']==cl['cold'])
 need('current_outer_sources:'+str(index),p['runner']==cl['outer_sources']['runner'] and p['observer']==cl['outer_sources']['observer'])
 need('all_direct_subject_runtime_maps_unchanged:'+str(index),all(w[k]==ow[k] for k in
 ('project_sources','components','declaration','native_inputs','policy','python','z3','cold')))
 pin(w['declaration']);cap=j(w['declaration']['path'])
 need('entire_immutable_capsule_hash:'+str(index),w['declaration']['sha256']=='1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0')
 need('full_original006_literal_same:'+str(index),len([r for r in cap['receivers'] if r['id']==p['receiver_id']])==1 and
 next(r for r in cap['receivers'] if r['id']==p['receiver_id'])==decl['selected_receiver'] and p['receiver_id']=='prospective-fol-20261018-006')
 need('unchanged_original_horizon_and_no_context_injection:'+str(index),decl['selected_receiver']['length']==12 and
 decl['selected_receiver']['instantiation_rounds']==2 and not decl['selected_receiver'].get('blocks') and
 not decl['selected_receiver'].get('assumptions') and decl['selected_receiver']['theory']['schemas']==[])
 need('matched_limits_and_environment:'+str(index),p['limits']==op['limits'] and p['environment']==op['environment']=={'LANG':'C','LC_ALL':'C','PYTHONHASHSEED':'0'})
 need('serial_order_frozen:'+str(index),entry['row']['order']==index+1)
 actual=Path(p['actual_directory']);false_term=Path(fp['path']).with_name(Path(fp['path']).stem+'-terminal-observation')
 need('fresh_absent_actual_and_false_terminal:'+str(index),not actual.exists() and not false_term.exists())
 actuals.append(str(actual));false_terms.append(str(false_term))
 if first_worker is None:first_worker=w
 else:need('identical_common_worker_context:'+str(index),all(w[k]==first_worker[k] for k in w if k not in
   ('invocation_id','mode','search_ordering','actual_directory')))
 subjects.append(dict(invocation_id=p['invocation_id'],mode=p['mode'],search_ordering=p['search_ordering'],
  subject=subject,subject_sha256=hashlib.sha256(word(subject)).hexdigest(),false_once_plan=fp,worker_plan=wp))
need('full_exact_four_arm_product',len(subjects)==4 and {s['mode']+'_'+s['search_ordering'] for s in subjects}==expected_roles and
 len(set(actuals))==4 and len({s['invocation_id'] for s in subjects})==4)
for d in [first_worker['python'],first_worker['policy'],*first_worker['native_inputs'].values(),*first_worker['z3']['files']]:pin(d)
need('source_epoch_29imports_no_new_alias',cl['current_scientific_alias_count']==28 and cl['schema_extra_component_count']==1 and len(cl['materialized_aliases'])==28)
need('qualified_component_not_pipeline',cl['full_pipeline_qualified'] is False and decl['actual_execution_authorized'] is False and decl['scientific_calls']==0 and m['no_grant_created'] is True)
need('no_current_grant_json',not (D/'plans-v2'/'authorizations').exists() and not list((D/'plans-v2').glob('**/authorization*.json')))
audit=save('prospective-v2-raw-metadata-audit.json',dict(schema='quantified-composer-prospective-v2-raw-metadata-audit-v1',
 reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,actual_execution_authorized=False,
 checks=checks,check_count=len(checks),mismatch_count=0,pins=list(pins.values()),exact_artifact_deltas=artifact_deltas,
 scope='Only whole raw pins and ordinary JSON/descriptor/delta/freshness comparisons. Native inputs rawhash only, no opaque decode; no subject module/Source/helper/fixture/Reader/codec/inverse/Native/Model/search evaluation.'))
review=save('typed-prospective-plan-review-v2.json',dict(schema='owned-evidence-integration-prospective-plan-review-v1',
 reviewer_identity='/root/conventional_control_review',author_identity='/root',metadata_author_identity=m['author_identity'],
 prospective_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,
 mathematical_proof_admitted=False,actual_execution_authorized=False,full_pipeline_qualified=False,
 component_imports=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,Native_calls=0,
 manifest=manifest,declaration=dpin,runtime_closure=clpin,metadata_delta=delta_pin,subjects=subjects,
 required_subjects=[dpin,clpin]+[s['worker_plan'] for s in subjects],
 current_components_Source=components,current_once_Source=once,prior_V1_negative=negative_pin,
 prior_V1_successful_binding_audit=desc(C/'current-coupling-and-prospective-v1-audit.json'),
 check_count=len(checks),mismatch_count=0,findings=[],audit=audit,
 corrected_scope_literals=dict(conformance=decl['conformance'],Source_limit=cl['limitations'][3]),
 observed_absent_actual_paths=actuals,observed_absent_false_terminal_paths=false_terms,
 limits=decl['limits'],evidence_profile=decl['evidence_profile'],
 conclusions=[
  'Both known V1 current-scope errors are corrected. Exact ordinary delta paths match all ten whole before/after metadata artifacts. Changes are only those two scope values, builder/review/historical provenance and recomputedV2 closure/declaration/worker/once descriptors. Every current Source/input/profile/numeric allowance/schedule/ID/actual-dir string remains exact; V1 files/negative remain immutable.',
  'Four full literal18-field subjects are recorded, with independent canonical SHA256; authorization is the one excluded field and remains the deliberately unlaunchable NO_AUTHORIZATION sentinel. They bind full worker/declaration/closure, exact current cold/runner/observer/Python, environment, original limits and all common input/maps.',
  'Exact schedule order is fixed AND, symbolic AND, fixed composed, symbolic composed, once each. All share full original006 from the exact22422-byte ten-case capsule,12rows/two rounds/full library, same29 scientific imports plus currentcold/outer bindings, Native/Python/Z3/Source/evidence/old-reader/finalization profiles and caps. No task route, easier target or additional context was introduced.',
  'The helper/composer is a shared conventional deterministic planning proposal, not a new rule or authority. On/off Source tuple is identical; only explicit ordering selects the proposer. Old row-lemma metric stays unchanged and composed/essential quantifier/family use must be independently joined after actual full admission.',
  'Mathematical Native proof, complete whole point/decode, full evidence/canonical inverse, resource/custody admission, essential UI+UG, essential family call and actual composed-hint consumption remain distinct endpoints. All four prior006 UNKNOWNs and prior001 outcomes remain historical; no held-out discovery, causal speedup, GCTS/RL or universal FOL/primitive-Wang claim.',
  'All current actual and false-observer directories were absent at this review, and no current authorization JSON existed. Reusing unexecuted planned identifiers after metadata correction is not a consumed retry. Fresh Root maxone grants and a separate auth-only final delta/freshness check are still required.'
 ],
 ancestry='Control authored old symbolic/support/outer ancestors. Current full Source/once scopes bind retained algorithms to genuine prior peers and independently assess new distinct-authored deltas. This ordinary metadata review neither re-certifies own inherited Source nor proves the Python/OS/kernel trust chain.',
 limitations=[
  'No scientific input, program, proof or codec/inverse was decoded/replayed/evaluated. Native/program/gzip/binary entries were only raw-hashed. No subject module was imported, no fixture or callback called and no actual launched.',
  'Worker positive work/full evidence/result reading and known exit before180 monotonic seconds; later outer full raw/custody/resource/group/EOF and terminal before210; observer225failureonly. Separate Darwin worker+Native highwater SUM1GiB is not live group RAM; outer/prelude exclusions and9MiB reservations retain old scope.',
  'Current 128MiB physical ordinary+forest+metadata and logical expanded caps, separate4MiB logs, arena400m/adapter400m/inverse30m and helper200k remain distinct units; symbolic map scans use the search clock. No runtime fit, exact process/callback closure, source loading/OS deep seal or proof admission is established by prospective metadata.',
  'A Source-matched four-arm finite development test on an exposed synthetic assertion is not a dedicated-prover baseline, blind benchmark or generalization result. Full rejected/UNKNOWN/resource-failed outputs must be retained; no consumed retry/cap rise/failed prefix rescue.',
  'One Control reviewer fills the explicitly distinct Source/once/prospective roles. Root separately adopts exact scopes; this review is not an execution grant. All peers must be idle for any authorized bounded actual.'
 ]))
out=save('prospective-review-handoff-v2.json',dict(schema='quantified-composer-prospective-peer-handoff-v2',
 review=review,audit=audit,source_only=True,scientific_calls=0,actual_execution_authorized=False,
 prospective_review_passed=True,check_count=len(checks),mismatch_count=0,tools_stopped_after_handoff=True,
 next='Root scope adoption and fresh maxone grants, then separate unchanged-subject auth-only delta/freshness review before actuals.'))
print(json.dumps(dict(handoff=out,review=review,audit=audit,checks=len(checks),subjects=[dict(invocation_id=s['invocation_id'],subject_sha256=s['subject_sha256']) for s in subjects]),sort_keys=True))
