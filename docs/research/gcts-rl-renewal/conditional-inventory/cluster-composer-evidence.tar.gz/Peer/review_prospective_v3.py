"""Full ordinary-metadata guard matrix; never calls any subject guard or module."""
from pathlib import Path
import ast,hashlib,json
C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
checks=[];pins={};matrix=[]
def raw(p):return Path(p).read_bytes()
def word(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def j(p):return json.loads(raw(p))
def desc(p):
 b=raw(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(n,v,d=None):
 checks.append(dict(check=n,passed=bool(v),detail=d))
 if not v:raise AssertionError(n)
def guard(arm,n,v,detail=None):
 need(arm+':'+n,v,detail);matrix.append(dict(invocation_id=arm,guard=n,passed=bool(v),detail=detail))
def pin(d):
 if d['path'] not in pins:
  a=desc(d['path']);need('whole_pin:'+d['path'],a==d);pins[d['path']]=a
 else:need('repeat_descriptor:'+d['path'],pins[d['path']]==d)
 return d
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_bytes((json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode());return desc(p)
def diffs(a,b,p=''):
 if word(a)==word(b):return []
 if type(a)is dict and type(b)is dict:
  return [q for k in sorted(set(a)|set(b)) for q in
    ([p+'/'+k] if k not in a or k not in b else diffs(a[k],b[k],p+'/'+k))]
 if type(a)is list and type(b)is list and len(a)==len(b):
  return [q for i,(x,y) in enumerate(zip(a,b)) for q in diffs(x,y,p+'/'+str(i))]
 return [p]
def literals(p):
 tree=ast.parse(raw(p).decode(),filename=str(p));out={};expressions={}
 for n in tree.body:
  if isinstance(n,ast.Assign):
   for target in n.targets:
    if isinstance(target,ast.Name):
     expressions[target.id]=n.value
     try:out[target.id]=ast.literal_eval(n.value)
     except (ValueError,TypeError):pass
 return out,expressions,tree
manifest=pin(dict(path=str(D/'false-plan-manifest-v3.json'),bytes=9454,sha256='d1359098f89791c4cf499fc155e6f6c192675ddc79df07edccccafb7f37314c2'))
m=j(manifest['path']);clpin=pin(m['runtime_closure']);dpin=pin(m['declaration']);cl,decl=j(clpin['path']),j(dpin['path'])
delta_pin=pin(m['metadata_successor_delta']);delta=j(delta_pin['path']);oldm=j(pin(delta['parent_manifest'])['path'])
oldcl=j(oldm['runtime_closure']['path']);olddecl=j(oldm['declaration']['path'])
for a in delta['artifact_deltas']:
 pin(a['before']);pin(a['after']);need('whole_metadata_delta:'+a['after']['path'],sorted(diffs(j(a['before']['path']),j(a['after']['path'])))==sorted(a['paths']))
components=pin(desc(C/'typed-components-Source-review-v1.json'));once=pin(desc(C/'typed-once-Source-review-v1.json'))
failure=pin(desc(C/'typed-prelaunch-failure-review-v2.json'));obligations=pin(desc(C/'prospective-guard-contract-obligations-v3.json'))
for p in j(components['path'])['subjects']+j(once['path'])['subjects']:pin(p)
need('all_code_runtime_profile_census_unchanged',all(cl[k]==oldcl[k] for k in
 ('project_sources','additional_nonseed_components','evidence_sources','schema_sources','schema_kernel_source','cold','outer_sources','materialized_aliases','Source_AST_census','current_import_census_summary','Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python','evidence_profile','finalization_profile')))
need('all_scientific_input_policy_limits_unchanged',all(decl[k]==olddecl[k] for k in
 ('selected_receiver','selected_receiver_id','input_capsule','limits','evidence_profile','finalization_profile','composer_policy','conformance','scope','success_reporting','failure_policy','current_sources')))
need('correct_structural_descriptor_material_change',decl['parent_structural_declaration']==decl['input_capsule'] and decl['parent_structural_declaration']!=olddecl['parent_structural_declaration'])
history=pin(m['shared_failure_history']);h=j(history['path'])
for p in h['preserved_raw_descriptors']:pin(p)
need('failed_V2_history_not_upgraded',h['resource_or_proof_upgraded'] is False and h['new_actual_authority'] is False and
 [r['status'] for r in h['cohort_statuses']]==['PREWORKER_PROTOCOL_FAILURE']+['NOT_RUN_COMMON_PROTOCOL_ABORT']*3)
cc,ce,ct=literals(cl['cold']['path']);rc,re,rt=literals(cl['outer_sources']['runner']['path'])
parent_pin=pin(cc['PARENT_RUNTIME_CLOSURE']);parent=j(parent_pin['path'])
# Project only literal Source constants/keyword data; no dict-expression or
# subject top-level assignment/function is executed.
diag_arena=dict(cc['ARENA_LIMITS'])
diag_arena.update({k.arg:ast.literal_eval(k.value) for k in ce['DIAGNOSTIC_ARENA_LIMITS'].keywords})
diag_adapter={k.arg:ast.literal_eval(k.value) for k in ce['DIAGNOSTIC_ADAPTER_LIMITS'].keywords}
diag_scope=next(ast.literal_eval(k.value) for k in ce['ADAPTER_DIAGNOSTIC_PROFILE'].keywords if k.arg=='scope')
expected_profile=dict(schema='owned-evidence-integration-profile-v1',sources=cc['EVIDENCE_SOURCES'],
 arena_limits=cc['ARENA_LIMITS'],adapter_limits=cc['ADAPTER_LIMITS'],inverse_limits=cc['INVERSE_LIMITS'],
 inverse_version=cc['INVERSE_VERSION'],inverse_execution_profile=cc['INVERSE_PROFILE'],
 logical_output='complete-legacy-JSON-body-plus-LF',sole_document=cc['EVIDENCE_DOCUMENT'],
 unfinished_storage='NO_COMPLETE_RESULT_NO_PROOF_OR_RESOURCE_ADMISSION',
 physical_accounting='ordinary_result+forest+all_root_JSON_metadata_including_worker_receipt',
 encoded_and_logical_cap_bytes=cc['OUTPUT_CAP_BYTES'],
 adapter_diagnostics=dict(schema='owned-adapter-finite-diagnostic-profile-v1',cases=list(cc['ADAPTER_DIAGNOSTICS']),
 maximum_fresh_Stores=8,arena_limits=diag_arena,adapter_limits=diag_adapter,scope=diag_scope))
need('complete_profile_literal_Source_projection',word(expected_profile)==word(decl['evidence_profile'])==word(cl['evidence_profile']))
source_anchors=[]
for fn in rt.body:
 if isinstance(fn,ast.FunctionDef) and fn.name=='intake_subject':
  for n in ast.walk(fn):
   if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='need':
    source_anchors.append(dict(line=n.lineno,predicate_AST=ast.dump(n.args[0],include_attributes=False),
      message=ast.literal_eval(n.args[1]) if len(n.args)>1 and isinstance(n.args[1],ast.Constant) else 'computed worker-field message'))

expected_fields={'schema','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory','runner','observer','python','cold','worker_plan','integration_declaration','runtime_closure','authorization','limits','environment'}
worker_fields={'schema','invocation_id','mode','actual_directory','cold','python','project_sources','components','native_inputs','policy','declaration','runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage','search_ordering','inventory_certification_mode'}
old_ids={r['row']['invocation_id'] for r in oldm['plans']};old_dirs={r['row']['actual_directory'] for r in oldm['plans']}
subjects=[];first=None
for i,entry in enumerate(m['plans']):
 fp,wp=pin(entry['false_once_plan']),pin(entry['worker_plan']);p,w=j(fp['path']),j(wp['path']);arm=p['invocation_id'];schedule=decl['schedule']
 guard(arm,'O1_once_exact19_fields',set(p)==expected_fields and p['schema']==rc['PLAN_SCHEMA'])
 guard(arm,'O1_worker_exact19_fields',set(w)==worker_fields and w['schema']==cc['PLAN_SCHEMA'])
 guard(arm,'O1_strict_mode_order_certification_storage_reader',p['mode'] in rc['KINDS'] and p['inventory_certification_mode'] in rc['CERTIFICATIONS'] and
   type(p['search_ordering'])is str and p['search_ordering'] in rc['ORDERINGS'] and type(p['model_storage'])is str and p['model_storage'] in rc['STORAGES'] and p['result_reader']=='interned')
 guard(arm,'O1_selector_explicit_original006',type(p['receiver_id'])is str and bool(p['receiver_id']) and p['receiver_id']=='prospective-fol-20261018-006')
 for key in ('invocation_id','mode','search_ordering','inventory_certification_mode','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure'):
  guard(arm,'O1_worker_once_full_binding_'+key,word(w[key])==word(p[key]))
 guard(arm,'O1_worker22_and_components2',len(w['project_sources'])==22 and set(w['components'])=={'receiver_driver','bounded_transport'})
 guard(arm,'O1_exact_cold_Source',p['cold']==rc['COLD_PIN']==cl['cold'])
 guard(arm,'O1_four_evidence_keys',type(cl['evidence_sources'])is dict and set(cl['evidence_sources'])=={'adapter','arena','join','inverse'})
 guard(arm,'O1_schema_Source_equals_outer_constant',cl['schema_sources']==rc['SCHEMA_SOURCES'])
 names=dict(w['project_sources'],semantic_receiver_driver=w['components']['receiver_driver'],bounded_request_oracle=w['components']['bounded_transport'])
 names.update({cc['EVIDENCE_ALIASES'][r]:d for r,d in cl['evidence_sources'].items()})
 guard(arm,'O1_exact28_complete_aliases',len(names)==28 and cl['schema']=='ROOT-cluster-composer-runtime-closure-v1' and
  cl['project_sources']==w['project_sources'] and cl['additional_nonseed_components']==w['components'] and cl['materialized_aliases']==names and cl['runtime']['Python_executable']==p['python'])
 for label,value in {
  'schema':decl['schema']=='ROOT-quantified-composer-four-arm-declaration-v1',
  'runtime_closure_full_descriptor':decl['runtime_closure']==p['runtime_closure'],
  'parent_structural_FULL_path_bytes_sha_descriptor':decl['parent_structural_declaration']==w['declaration'],
  'selected_receiver_id':decl['selected_receiver_id']==p['receiver_id'],
  'result_reader':decl['result_reader']==p['result_reader']}.items():guard(arm,'O2_each_declaration_conjunct_'+label,value)
 guard(arm,'O2_all_structural_descriptors_identical',w['declaration']==decl['parent_structural_declaration']==decl['input_capsule'],dict(worker=w['declaration'],parent=decl['parent_structural_declaration']))
 guard(arm,'O3_evidence_profile_and_Sources',decl['evidence_profile']==cl['evidence_profile'] and decl['evidence_profile']['sources']==cl['evidence_sources'])
 guard(arm,'O3_finalization_profile_literal',decl['finalization_profile']==cl['finalization_profile']=='owned-finalization-phase-instrumented-v1')
 ids=[r['invocation_id'] for r in schedule]
 guard(arm,'O3_full_four_arm_product',len(ids)==4 and len(set(ids))==4 and ids.count(arm)==1 and len({r['actual_directory'] for r in schedule})==4 and
  {(r['mode'],r['inventory_certification_mode'],r['search_ordering']) for r in schedule}=={(a,b,c) for a in rc['KINDS'] for b in rc['CERTIFICATIONS'] for c in rc['ORDERINGS']} and
  all(r['receiver_id']==p['receiver_id'] and r['model_storage']=='literal_interned' and r['result_reader']=='interned' for r in schedule))
 row=schedule[ids.index(arm)]
 for key in ('mode','search_ordering','inventory_certification_mode','result_reader','receiver_id','actual_directory','model_storage'):
  guard(arm,'O3_current_schedule_row_'+key,row[key]==p[key])
 guard(arm,'O3_current_order_explicit',row==entry['row'] and row['order']==i+1)
 for key,value in {'work_seconds':180,'overall_seconds':210,'conservative_worker_plus_native_peak_bytes':1073741824,'result_bytes':134217728,
  'search_seconds':30,'search_max_nodes':5000,'compile_queries':512,'inventory_registration_aggregate_micro_steps':5000000000}.items():
  guard(arm,'O3_outer_scientific_limit_'+key,decl['limits'][key]==value)
 guard(arm,'O3_full_outer_limits',p['limits']==rc['LIMITS'])
 guard(arm,'O3_strict_environment',type(p['environment'])is dict and all(type(k)is str and type(v)is str for k,v in p['environment'].items()) and
  not set(p['environment'])&{'PATH','PYTHONPATH','PYTHONHOME','Z3_LIBRARY_PATH','DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH'} and p['environment']=={'LANG':'C','LC_ALL':'C','PYTHONHASHSEED':'0'})
 pin(w['declaration']);cap=j(w['declaration']['path'])
 guard(arm,'O4_full_capsule1a42_hash',w['declaration']['sha256']=='1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0' and w['declaration']['bytes']==22422)
 matches=[r for r in cap['receivers'] if r['id']==p['receiver_id']]
 guard(arm,'O4_unique_full_literal_selected_receiver',len(matches)==1 and word(matches[0])==word(decl['selected_receiver']) and matches[0]['length']==12 and matches[0]['instantiation_rounds']==2)
 guard(arm,'O4_cold_current_integration_three_conjuncts',decl['schema']=='ROOT-quantified-composer-four-arm-declaration-v1' and decl['parent_structural_declaration']==w['declaration'] and decl['selected_receiver_id']==w['receiver_id'])
 guard(arm,'O4_cold_Source_bound_complete_profiles',word(decl['evidence_profile'])==word(expected_profile) and decl['finalization_profile']==cc['FINALIZATION_PROFILE'])
 guard(arm,'O4_cold_parent_closure_full_descriptor',cl['schema']=='ROOT-cluster-composer-runtime-closure-v1' and cl['parent_closure']==cc['PARENT_RUNTIME_CLOSURE'])
 ep=dict(parent['project_sources']);ep['semantic_inventory_oracle']=cc['REGISTRY_SOURCE'];ep['quantified_family_points_v2']=cc['ORDINARY_MODEL_SOURCE']
 ep['semantic_inventory_search_v2']=cc['ORDERING_COMPONENT_SOURCES']['family_search'];ep['receptor_support_ordering_v1']=cc['ORDERING_COMPONENT_SOURCES']['support_ordering'];ep['quantified_symbolic_control_v2']=cc['ORDERING_COMPONENT_SOURCES']['symbolic_control']
 guard(arm,'O4_cold_full_expected_project_map',w['project_sources']==cl['project_sources']==ep and ep['interned_quantified_family_points_v1']==cc['COMPACT_MODEL_SOURCE'])
 for key in ('Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python'):
  guard(arm,'O4_cold_retained_runtime_map_'+key,cl[key]==parent[key])
 guard(arm,'O4_cold_python_and_components',p['python']==cl['runtime']['Python_executable'] and w['components']==cl['additional_nonseed_components'] and w['components']['receiver_driver']==cc['RECEIVER_DRIVER_SOURCE'] and
  w['components']['bounded_transport']==parent['additional_nonseed_components']['bounded_transport'])
 guard(arm,'O4_cold_exact_evidence_schema_kernel',cl['evidence_sources']==cc['EVIDENCE_SOURCES'] and cl['schema_sources']==cc['SCHEMA_SOURCES'] and cl['schema_kernel_source']==cc['SCHEMA_KERNEL_SOURCE'])
 expected_z3=[{k:r[k] for k in ('path','sha256','bytes')} for r in cl['Z3']['files']]
 guard(arm,'O4_cold_complete_Z3_runtime',w['z3']['files']==expected_z3 and w['z3']['root']==cl['Z3']['package_root'] and
  w['z3']['library']['path']==str(Path(w['z3']['root'])/'z3/lib/libz3.dylib') and w['z3']['library'] in w['z3']['files'])
 guard(arm,'O4_cold_exact_native_input_roles',set(w['native_inputs'])=={'program_and_template','opaque_microcode_gzip','native_cpp'} and
  w['native_inputs']['program_and_template']==cl['fixed_native_inputs']['program_and_template'] and w['native_inputs']['opaque_microcode_gzip']==cl['fixed_native_inputs']['opaque_microcode_gzip'] and
  w['native_inputs']['native_cpp']==cl['native_CPP']['binary'])
 guard(arm,'O4_policy_immutable',w['policy']['sha256']=='f5f0c22121f4c503db319fe6e01c4c3a146ac9db9deb7e2ccec0aab1a2f32161' and w['policy']['bytes']==4502)
 for q in [w['policy'],w['python'],*w['native_inputs'].values(),*w['z3']['files']]:pin(q)
 actual=Path(p['actual_directory']);term=Path(fp['path']).parent/(Path(fp['path']).stem+'-terminal-observation')
 guard(arm,'O5_distinct_never_attempted_ID_and_actual',arm not in old_ids and str(actual) not in old_dirs and 'cohort-v3' in arm and 'actual-cohort-v3-' in str(actual))
 guard(arm,'O5_paths_absolute_private_resolved_and_fresh',actual.is_absolute() and actual==actual.resolve() and actual.parent==D and not actual.exists() and not term.exists() and not (actual/'CONSUMED.json').exists())
 guard(arm,'O5_strict_false_auth_sentinel',p['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',sha256='NO_AUTHORIZATION',bytes=0))
 subject={k:v for k,v in p.items() if k!='authorization'}
 guard(arm,'O5_full_new18_field_subject',len(subject)==18 and p['worker_plan']==wp and p['integration_declaration']==dpin and p['runtime_closure']==clpin)
 subjects.append(dict(invocation_id=arm,mode=p['mode'],search_ordering=p['search_ordering'],subject=subject,
  subject_sha256=hashlib.sha256(word(subject)).hexdigest(),false_once_plan=fp,worker_plan=wp,
  expected_actual_directory=str(actual),expected_false_observer_directory=str(term)))
 if first is None:first=w
 else:guard(arm,'O6_full_common_math_runtime_context',all(w[k]==first[k] for k in w if k not in ('invocation_id','mode','search_ordering','actual_directory')))
need('all_four_new_false_subjects',len(subjects)==4 and len({r['subject_sha256'] for r in subjects})==4)
need('no_current_grants',not (D/'plans-v3/authorizations').exists())
need('history_prospective_only',cl['runtime_activation_authorized'] is False and cl['full_pipeline_qualified'] is False and decl['actual_execution_authorized'] is False and m['no_grant_created'] is True)
guard_pin=save('prospective-v3-full-guard-matrix.json',dict(schema='quantified-composer-full-metadata-guard-matrix-v3',
 reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,actual_execution_authorized=False,
 source_anchors=dict(runner=cl['outer_sources']['runner'],cold=cl['cold'],intake_subject_needs=source_anchors),
 guards=matrix,guard_count=len(matrix),all_observed_metadata_guards_passed=True,
 scope='Each condition here is an independently authored ordinary-metadata comparison. No extracted subject condition, guard/intake function, module or fixture was evaluated.',
 runtime_only_gates_NOT_claimed=['Future worker PID/process-group leadership and actualCWD','Future external CONSUMED/deadline/Python entry identity','Module import/owned Source/captured callable/loader gates','Native table/code/theory/scheme/schema/compiler/Model/search execution','Whole point/Native proof/finalization/inverse/canonical output','Resource/knownexit/group/EOF/terminal admission']))
audit=save('prospective-v3-raw-metadata-audit.json',dict(schema='quantified-composer-prospective-v3-audit-v1',
 reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,actual_execution_authorized=False,
 checks=checks,check_count=len(checks),mismatch_count=0,guard_matrix=guard_pin,raw_pins=list(pins.values()),
 scope='Raw pin/full descriptor/ordinary JSON/AST literal constants and filesystem absence only. No Native opaque decode, component/function/Reader/codec/inverse/Model/fixture/guard execution or process probe.'))
review=save('typed-prospective-plan-review-v3.json',dict(schema='owned-evidence-integration-prospective-plan-review-v1',
 reviewer_identity='/root/conventional_control_review',author_identity='/root',metadata_author_identity=m['author_identity'],
 prospective_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,
 mathematical_proof_admitted=False,actual_execution_authorized=False,full_pipeline_qualified=False,
 component_imports=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,Native_calls=0,
 manifest=manifest,declaration=dpin,runtime_closure=clpin,metadata_delta=delta_pin,subjects=subjects,
 required_subjects=[dpin,clpin]+[r['worker_plan'] for r in subjects],
 current_components_Source=components,current_once_Source=once,failed_V2_peer_evidence=failure,
 guard_obligations=obligations,guard_matrix=guard_pin,shared_failure_history=history,audit=audit,
 check_count=len(checks),mismatch_count=0,findings=[],
 conclusions=[
  'All five outer declaration conjuncts are independently checked perarm, including the formerly missed full parent_structural_declaration==worker.declaration path/bytes/SHA equality. Full worker.declaration, current parent structural declaration and inputcapsule descriptors are now identical, not merely byte-equal.',
  'The complete outer worker/once/alias/evidence/schema/profile/finalization/schedule/limit/environment metadata conditions and cold pre-import capsule/current-declaration/selectedreceiver/parent/runtime/project/component/evidence/schema/Z3/native mappings are recorded as individually passed ordinary-data comparisons in the full guard matrix. Runtime-only process/import/scientific/output/resource gates are explicitly pending and were not simulated.',
  'Four fresh cohort-v3 IDs and private actual/plan/observer paths preserve fixedAND,symbolicAND,fixedcomposed,symboliccomposed order. All current code32census, thirty required component subjects, exact original full006/12rows/two rounds, full frozen policy/library/inputbytes, real/private caps and evidence profiles remain unchanged.',
  'The V2 attempt is preserved as one preworker protocol failure with zero scientific launches; remaining three old arms remain NOT_RUN_COMMON_PROTOCOL_ABORT. Old grants/observer marker/logs/terminal, all earlier negatives and Control’s missed-join disclosure remain immutable. V3 materially corrects the descriptor and creates new subjects; it is not an unchanged retry or rescued old result.',
  'Every current false plan has the unlaunchable authorization sentinel. All new actual and false-observer/consumed paths are absent, and no plans-v3 authorization directory exists at review. Separate Root precise scope adoption, maxone grants, auth-only final delta/freshness and all peers idle remain required before any actual.',
  'Source PASS is a static code/ancestry premise only and does not imply metadata guard satisfaction or runtime success. This prospective PASS is only the newly checked full metadata scope; no proof/search outcome, fit, resource admission, RL/GCTS benefit or allFOL/primitiveWang conformance is established.'
 ],
 peer_correction='The earlier V2 prospective review missed a mandatory descriptor-path equality and was superseded as readiness evidence by the saved negative review. This V3 receipt checks that condition explicitly for every arm and retains that error rather than retroactively revising the old review.',
 ancestry='Control authored historical symbolic/helper/outer ancestors; retained code relies on genuine prior peer ancestry, current distinct-author deltas have their scoped Source reviews. This ordinary metadata review does not independently certify own Source, OS/loader/kernel soundness or actual execution.',
 limitations=['No subject code/module/guard/helper/fixture/Reader/codec/inverse/Native/Model/search or renderer was imported, called, decoded or replayed; Native inputs rawhash only.',
 'Original180positive worker/fullreading/knownexit and laterouter210, observer225failureonly, separate1GiBhighwaterSUM notliveRSS, both128MiB and4MiBlog gates/counters remain exact. No complete actual result is assumed.',
 'Quantified inference, family use, composed-hint use, complete Native/wholepoint proof and full profile/resource adoption remain separate endpoints on an exposed synthetic case. Old UNKNOWNs retain their status; no newtheorem or causal benefit claim.',
 'One Control identity fills three disclosed review roles. Root grant authority is separate; no execution is authorized by this review.'],
 tools_stopped_after_handoff=True))
print(json.dumps(dict(review=review,audit=audit,guard_matrix=guard_pin,checks=len(checks),guards=len(matrix),subjects=[dict(invocation_id=r['invocation_id'],subject_sha256=r['subject_sha256']) for r in subjects]),sort_keys=True))
