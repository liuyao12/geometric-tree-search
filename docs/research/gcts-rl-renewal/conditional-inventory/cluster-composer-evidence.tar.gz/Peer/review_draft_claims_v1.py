"""Saved raw HTML/JSON only; no rendering, script or subject evaluation."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re
C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
P=D/'publication-draft';checks=[]
def desc(p):
 b=Path(p).read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def need(n,b):checks.append({'check':n,'passed':bool(b)})
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_text(json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n');return desc(p)
hpath=P/'cluster-composer.html';spath=P/'cluster-composer-summary.json';h=hpath.read_text();s=json.loads(spath.read_text())
hp,sp=desc(hpath),desc(spath)
need('offered_html_exact',hp['sha256']=='5b40eef373b0b69af68a7f248aeab9433e466f5738c71b9a58fee8de580dd2eb' and hp['bytes']==13624)
need('offered_summary_exact',sp['sha256']=='e585327d25e09389454853171064a9224a52d435683aa94be487306dfaa6342f' and sp['bytes']==20087)
root=json.loads((D/'ROOT-cohort-V3-closure-v1.json').read_text());need('summary_entire_closure_literal',s['closure']==root)
table=json.loads((C/'saved-cohort-v3b-four-outcome-table.json').read_text())
need('summary_no_admission',s['accepted_proofs']==s['admitted_results']==0 and s['goal_complete'] is False and s['composer_status'].startswith('UNAVAILABLE') and s['scientific_comparison'].startswith('UNAVAILABLE'))
cap=json.loads(Path('/private/tmp/gcts-new-quantified-task-design-20261019/original-full-input-capsule.json').read_text());receiver=next(x for x in cap['receivers'] if x['id']=='prospective-fol-20261018-006')
need('summary_original_input_literal_preserved',s['input']==receiver)
for i,r in enumerate(table['rows']):
 for label,val,unit in [('terminal',r['runner_Sourceentry_terminal_seconds'],'s'),('assembly',r['open_final_assemble_seconds'],'s'),('memory',r['diagnostic_separate_highwater_sum_bytes']/1073741824,'GiB')]:
  need('rounded_'+label+'_'+str(i),('\\('+format(val,'.3f')+'\\,\\mathrm{'+unit+'}\\)') in h)
need('five_original_input_formulae_no_proofword',h.count('\\forall x')==5 and '<ol><li>\\(' in h and 'The input supplies no proof word.' in h and 'No new proof rows are presented.' in h)
need('all4_failed_no_benefit',all(x in h for x in ['All four frozen runs failed','no admitted proof, search result or method comparison','does not show that the composer works','No trained policy or learned failure marking']))
need('schematic_roles_explicit',all(x in h for x in ['schematic of command, guard and input roles','not tiles from an accepted proof','not the missing universal primitive Wang palette']))
need('old001_no_target_or_proof_display',all(x not in h for x in ['native_proof_discovered','proof-discovered','accepted proof rows']))
need('original_resource_clock_scope',all(x in h for x in ['including complete result reading and known worker exit','Later outer custody','positive boundary','not simultaneous live group memory','worker alone exceeded','full process lifetime','not enforced as a live operating-system ceiling']))
need('negative_native_shutdown_no_acceptance',all(x in h for x in ['No complete <code>result.json</code>','clean subprocess shutdown is not proof or resource acceptance','Runners and observers returned code']))
need('nested_cost_not_disjoint',all(x in h for x in ['intervals overlap phases','cannot be added as disjoint costs','not completed proof-search measurements']))
need('setup_1plus3separate',all(x in h for x in ['before creating a scientific worker','other three old arms were not run','not UNKNOWN search outcomes','readiness claim is superseded','Full descriptor equality']))
need('Root_keyerror_explicit_not_repaired',all(x in h for x in ['optional prelaunch record writer','KeyError','failed to inspect that command exit','no barrier file is backdated']))
need('future_allocation_hypothesis_not_measured',all(x in h for x in ['Static Source inspection','no allocation profile establishes','unimplemented and unqualified','failed prefixes must not become qualification inputs']))
need('no_new_engine_universality_or_RL_claim',all(x in h for x in ['RL, learned pruning','remain separate open research tasks','goals, not results of this round','No benchmark superiority']))
need('MathJax_LaTex_delimiters_present',all(x in h for x in ['tex-chtml.js','window.MathJax','\\forall','\\to','\\mathrm']))
findings=[{'severity':'required_clarification','location':'summary.input.scope','finding':'The literal original input scope ends All runtime outcomes unmeasured. Preserve that historical input verbatim but explicitly label its provenance/current-status separation; all four current full-profile failures have now been measured.'},{'severity':'required_clarification','location':'HTML question/path interface labels','finding':'Existing admitted interfaces / Admitted inference interfaces should be conditional design language, not an assertion of complete current registry or Model admission. No full current registry/Model result survives these failures.'}]
audit=save('draft-claims-raw-audit-v1.json',{'schema':'quantified-composer-draft-claim-audit-v1','saved_data_only':True,'scientific_calls':0,'html':hp,'summary':sp,'checks':checks,'check_count':len(checks),'mismatch_count':sum(not x['passed'] for x in checks),'scope':'Raw draft HTML/ordinary JSON/rounded arithmetic only. No rendering or JS, proof, Native, Reader, inverse, composer, Model or scientific evaluation. Archive and final publication not offered yet.'})
receipt=save('typed-draft-claims-review-v1.json',{'schema':'quantified-composer-draft-claims-review-v1','reviewer_identity':'/root/conventional_control_review','author_identity':'/root','saved_data_only':True,'scientific_calls':0,'component_calls':0,'render_calls':0,'scientific_acceptance':False,'actual_execution_authorized':False,'final_publication_approved':False,'draft_claim_review_passed':False,'findings':findings,'audit':audit,'html':hp,'summary':sp,'saved_negative_review':desc(C/'typed-saved-actual-review-v3b.json'),'check_count':len(checks),'mismatch_count':sum(not x['passed'] for x in checks),'limitations':['Core numerical and negative outcome claims checked; two historical/conditional-scope clarifications remain. Final archive/manifest and complete frozen publication packet require separate exact-byte review.','Earlier reviewer authored symbolic/AND-helper/outer ancestors; independent current saved-data review is not fresh own Source or mathematical certification.']})
print(json.dumps({'review':receipt,'audit':audit,'check_count':len(checks),'raw_mismatch_count':sum(not x['passed'] for x in checks),'failed_checks':[x for x in checks if not x['passed']]},sort_keys=True))
