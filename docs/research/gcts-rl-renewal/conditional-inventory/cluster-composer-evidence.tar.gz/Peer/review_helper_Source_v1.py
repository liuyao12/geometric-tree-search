"""Raw/AST/unused-compile/inert-text review only. Subject code is never loaded."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
L=Path('/private/tmp/gcts-cluster-composer-library-20261019')
checks=[]
def data(p):return Path(p).read_bytes()
def desc(p):
    b=data(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(name,value,detail=None):
    checks.append(dict(check=name,passed=bool(value),detail=detail))
    if not value:raise AssertionError(name)
def pin(d):
    need('whole_pin:'+d['path'],desc(d['path'])==d);return d
def j(p):return json.loads(data(p))
def save(name,obj):
    p=C/name
    if p.exists():raise FileExistsError(p)
    p.write_bytes((json.dumps(obj,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode())
    return desc(p)

handoff=pin(dict(path=str(L/'helper-handoff-v1.json'),bytes=2018,
    sha256='fe70169f578a375df6c5c8d80eddb6ee404bc35ff1cf18d39e2ebac3b0609299'))
h=j(handoff['path'])
for key in ('Source','parent','API','contract','additions'):
    pin(h[key])
for p in h['patches']:pin(p)
src,old,added=(data(h[key]['path']) for key in ('Source','parent','additions'))
need('new_complete_raw_parent_prefix',src.startswith(old))
need('new_complete_raw_suffix_only',src==old+b'\n'+added)
t,pt,at=(ast.parse(b.decode(),filename=h[k]['path']) for b,k in
    ((src,'Source'),(old,'parent'),(added,'additions')))
need('entire_historical_AST_prefix_exact',len(t.body)==len(pt.body)+len(at.body) and
    all(ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
        for a,b in zip(t.body[:len(pt.body)],pt.body)))
need('additions_AST_exact',all(ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
    for a,b in zip(t.body[len(pt.body):],at.body)))
need('only_two_new_constants_one_public_function',len(at.body)==3 and
    isinstance(at.body[0],ast.Assign) and isinstance(at.body[1],ast.Assign) and
    isinstance(at.body[2],ast.FunctionDef) and at.body[2].name=='compose_support_cluster')
need('no_new_imports',not any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(at)))
need('no_new_yield_or_async_boundary',not any(isinstance(n,(ast.Yield,ast.YieldFrom,ast.AsyncFunctionDef,ast.Await)) for n in ast.walk(at)))
need('no_new_exec_eval_or_dynamic_import',not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
    and n.func.id in ('exec','eval','__import__','compile') for n in ast.walk(at)))
fn=at.body[2]
need('exact_keyword_only_API',not fn.args.posonlyargs and not fn.args.args and
    [a.arg for a in fn.args.kwonlyargs]==['graph','check','work_limit'] and fn.args.vararg is None and fn.args.kwarg is None)
need('private_work_default_same',isinstance(fn.args.kw_defaults[2],ast.Name) and fn.args.kw_defaults[2].id=='DEFAULT_WORK_LIMIT')
text=added.decode()
requirements={
 'empty_seeds_only':'costs, origins = _potential(owned, [], w)',
 'owning_copy_charged':'owned = _copy(graph, copy_charge, counts)',
 'copy_charge_uses_private_work':"w.step('copy_visits')",
 'complete_graph_only':"if owned['status'] != 'COMPLETE':",
 'complete_acquisition_only':"compiled['status'] != 'complete' or not _inventory_admission_ready(inventory)",
 'original_twelve_rows':"type(spec['length']) is not int or spec['length'] != 12",
 'no_supplied_assumptions_blocks_schemas':"spec.get('assumptions') or spec.get('blocks') or spec['theory']['schemas']",
 'current_graph_binding':"owned.get('graph_sha256') != _sha(owned['graph_preimage'])",
 'full_formula_preimage_not_hash_only':"entry['literal_preimage'] != word.decode('utf8') or word in words",
 'strict_int_ids':"type(entry['formula_id']) is not int or entry['formula_id'] != ordinal",
 'typed_edge_cost_one':"type(edge['positive_row_cost']) is not int or edge['positive_row_cost'] != 1",
 'all_repeated_ports_visited':"for source in edge['ordered_premises']:",
 'target_literal_binding':"same(formulas[target]['formula'],spec['target'])",
 'no_finite_plan_abstains':"record['reason'] = 'NO_FINITE_HEURISTIC_DERIVATION'",
 'explicit_cycle_stop':"record['reason'] = 'CYCLIC_ORIGINS'",
 'strict_cost_descent':"not 0 < value < cost",
 'origin_cost_equal_AND_sum':"cost != 1 + sum(port_costs)",
 'colored_shared_postorder':"if state.get(formula_id) == 2:",
 'topological_target_last':"postorder[-1] != target or len(set(postorder)) != len(postorder)",
 'actual_DAG_not_potential_cost_capacity':"len(postorder) > spec['length']",
 'target_final_row_mapping':"row_of[target] = length-1",
 'strict_prior_serialized_refs':"any(not 0 <= source < row for source in sources)",
 'exact_axiom_name_formula':"same(spec['theory']['axioms'][name],formula)",
 'exact_admitted_tautology':"same(compiled['tautologies'][item],formula)",
 'exact_UI_EQ_ordinary_command':"same(actual,provenance['exact_command'])",
 'no_rewrite_UI_consequent':"command = actual",
 'literal_refl':"formula[0] != 'eq' or not same(formula[1],formula[2])",
 'ordered_MP_antecedent_implication':"command.update(antecedent=sources[0],implication=sources[1])",
 'UG_reads_actual_body':"same(formula[2],formulas[ports[0]]['formula'])",
 'UG_variable_closed_context':"provenance['root_context'] != compiled['catalog']['root_context']",
 'exported_blocks_only':"name not in inventory['interfaces'] or name not in definitions",
 'full_block_record_join':"same(actual,provenance['exact_definition_record'])",
 'ordered_repeated_block_premises':"same(definition['premises'],[formulas[p]['formula'] for p in ports])",
 'zero_read_padding_only':"if not selected[f]['ordered_premises']",
 'padding_does_not_invent_copy_rule':"command=leaf[1]",
 'padding_before_target':"for formula_id,command in produced[:-1]:",
 'full_final_row_target_check':"not same(rows[-1]['command']['formula'],spec['target'])",
 'origin_and_row_map_fullreceipt':"formula_to_producer_row=[dict(formula_id=f,row=row_of[f]) for f in postorder]",
 'all_authority_false':"logical_authority=False, native_proof_accepted=False",
 'no_pruning_or_exhaustion_claim':"candidate_pruning=False, complete_search_claimed=False",
 'private_stop_owner_identity':"if stopped.owner is not w:",
 'private_stop_clears_proposal':"proposal=None,proposal_sha256=None",
 'full_input_postcomparison':"if _json(graph) != original:",
}
for name,needle in requirements.items():need(name,needle in text)
handlers=[n for n in ast.walk(fn) if isinstance(n,ast.ExceptHandler)]
need('only_own_stop_handler',len(handlers)==1 and isinstance(handlers[0].type,ast.Name) and handlers[0].type.id=='_OwnStop')
checked=next(n for n in fn.body if isinstance(n,ast.FunctionDef) and n.name=='checked')
need('delegated_check_direct_non_generator',not any(isinstance(n,(ast.Yield,ast.YieldFrom,ast.Try)) for n in ast.walk(checked)) and
    any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='check' for n in ast.walk(checked)))

compile_counts=[]
for payload,label in ((old,'parent'),(added,'additions'),(src,'full_current')):
    code=compile(payload.decode(),'<unused-'+label+'>','exec',dont_inherit=True)
    del code
    compile_counts.append(label)
need('three_unused_compile_no_eval',len(compile_counts)==3)

inert=C/'helper-inert-text-review-v1'
inert.mkdir(exist_ok=False)
(inert/'helper.py').write_bytes(old)
for direction,p,wanted in [('forward',h['patches'][0],src),('reverse',h['patches'][1],old)]:
    r=subprocess.run(['patch','-s','-p1','-i',p['path']],cwd=inert,capture_output=True,text=True)
    need('actual_inert_text_patch_'+direction,r.returncode==0,dict(stdout=r.stdout,stderr=r.stderr))
    need('actual_inert_text_whole_bytes_'+direction,(inert/'helper.py').read_bytes()==wanted)

prior_peer=desc('/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json')
obligations=desc(C/'generic-composer-design-review-v1.json')
audit=save('helper-Source-audit-v1.json',dict(schema='root-cluster-composer-helper-raw-AST-audit-v1',
    reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,
    actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,
    unused_compile_only=compile_counts,actual_inert_text_patch_directions=2,
    Source_AST_sha256=hashlib.sha256(ast.dump(t,include_attributes=False).encode()).hexdigest(),
    new_function_AST_sha256=hashlib.sha256(ast.dump(fn,include_attributes=False).encode()).hexdigest(),
    scope='No subject code/module/function/fixture/graph/potential/Model/Native/codec/inverse/search/callback was evaluated. patch operated only inert Source text.'))
review=save('typed-helper-Source-review-v1.json',dict(
    schema='root-cluster-composer-helper-typed-Source-review-v1',source_review_passed=True,
    reviewer_identity='/root/conventional_control_review',author_identity='/root/conventional_library',
    source_only=True,scientific_calls=0,component_imports=0,component_calls=0,fixture_calls=0,
    codec_calls=0,inverse_calls=0,Native_calls=0,callback_calls=0,
    scientific_acceptance=False,mathematical_proof_admitted=False,actual_execution_authorized=False,
    full_pipeline_qualified=False,review_scope='New Library-authored additive compose_support_cluster only, bound to the full exact current helper Source and immutable historical prefix. Consumers, new driver/cold, plans and runtime are excluded.',
    Source=h['Source'],subjects=[h['Source']],parent=h['parent'],API=h['API'],source_contract=h['contract'],
    handoff=handoff,additions=h['additions'],patches=h['patches'],audit=audit,
    review_obligations=obligations,check_count=len(checks),mismatch_count=0,findings=[],
    ancestry=dict(disclosure='Control authored the original AND-support helper and symbolic control; Library authored this new append-only proposer. All historical raw bytes and AST nodes are unchanged. Control is not freshly certifying its inherited algorithm; the genuine prior Receiver review and existing Root gate reviews remain ancestry with their protected-caller limitations.',
        genuine_historical_helper_peer=prior_peer),
    conclusions=[
      'The entire18508-byte parent is a raw and AST prefix; old VERSION/APIs/_potential are unchanged, no new import or replacement definition. Only two composer constants and a public non-generator function are appended.',
      'Only a complete supplied graph with complete authenticated acquisition is considered; EMPTY seeds are hardcoded. Formula identities retain full canonical literal words. Every edge has typed IDs, ordered ports and row cost one. Current graph authenticity/admission remains a protected caller obligation, not independently established by its self-hash.',
      'The inherited positive tree potential selects one origin per exact formula. The new colored postorder verifies positive strict cost descent and exact sum at each reached producer, shares repeated producer nodes, retains repeated premise ports and requires target last. A finite potential is never equated with a realizable twelve-row capacity certificate.',
      'Serialization validates named axiom formula, admitted tautology, exact admitted UI/EQ implication command, literal reflexivity, MP antecedent/implication roles, UG variable/body/closed root context and exported complete block record with exact ordered premises. No consequent is turned into an axiom and no copy rule is invented.',
      'Actual distinct producer count is checked against twelve. Non-target producers occupy consecutive prior rows; target is remapped to row11; any gap repeats an existing selected zero-read command before that actual final producer. Consequently the inserted gap does not invalidate prior source rows or create an extra inference rule. Consumers must still prove original command/guard/port/key membership.',
      'Only owner-matched _OwnStop becomes ABSTAIN with no proposal. Incomplete graph, no finite selected derivation, overlong selected DAG, cycle or unavailable existing padding has no impossibility/pruning meaning. Direct callback delegation is non-generator and uncaught except that same private owner stop; exact foreign errors including StopIteration are not normalized by this helper.',
      'Invocation-local owned graph copying is charged through the same <=200000 work quota, with attempted/returned callbacks and copy visits retained. Full canonical original preimage and postcomparison bind the protected input under the exclusive-owner contract. JSON serialization/hashing, receipt construction and builtin scalar work also consume the caller clock but are not all individual private-operation charges.',
      'Selected origins, full selected edge records, postorder, formula-to-row map, ordinary row commands, padding flag/policy, proposal hash and counters are retained on PROPOSED. Private stops may retain only completed construction subrecords; an empty field is not evidence that no provisional work happened. No complete partial-derivation or exact checkpoint-latency claim.'
    ],
    mandatory_consumer_gates=[
      'Call once per fresh root/arm on the exact current complete authenticated compiler/inventory/support graph; no earlier facts or retained proposal input/cache. Both off/on arms import the same whole helper and preserve old and_support behavior.',
      'Resolve every proposed ordinary row to exact original skeleton index, guard variant, mode and all ordered/repeated sources and unused input fillers. Full Model membership and whole aggregate legality precede fixed hint use.',
      'Fixed consumes one validated full-word hint only through unchanged global dead/forced/earliest-generation scheduler and all base alternatives with rollback. Symbolic must preserve one-to-one original candidate/ref/padding multiplicity and exact prefix membership while prioritizing corresponding original candidates.',
      'Any prefix conflict, abstention, quota/deadline or incomplete priority scan must preserve all original alternatives and correct UNKNOWN/exhaustion semantics. Helper callback identity can still be wrapped by an incorrect future generator consumer, which is not covered here.',
      'Charge graph construction, copying, potential, extraction, mapping/validation, failed proposals and all record output to the same original search/global clocks/caps. Private200000 counts are not a hard elapsed-time or allocation guarantee.',
      'Fresh full whole-point, unchanged final Native proof and used original block closure, Source/input/rollback custody, complete raw output/forest/inverse/legacy comparator and original resource/terminal gates remain mandatory. Proposal authority flags stay false.'
    ],
    limitations=[
      'This is Source-only review with three unused compile objects and two actual inert text patch directions. No helper, fixture, callback, graph/potential, compiler, Native, Model, solver, search, codec, inverse or renderer function/module was run.',
      'The caller supplies the graph produced by the sealed current build_support_graph from completely authenticated inputs and protects it against arbitrary malicious/reentrant callback mutation. A self-consistent forged graph/hash is not certified by this API. No continuous OS, Python implementation, whole-callable/cell/default-content integrity seal is claimed.',
      'Selecting one minimum-positive-tree-cost origin DAG does not minimize shared DAG rows or prove that no alternative fits. ABSTAIN is not nonprovability. No case006 route or twelve-row proof was constructed or evaluated.',
      'No current consumer, driver/cold coupling, complete closure, prospective subject, runtime qualification, proof, fit, speed/RAM advantage, learned marking, RL result, GCTS-specific superiority or activation authority is certified by this helper receipt.'
    ]))
out=save('helper-review-handoff-v1.json',dict(schema='root-cluster-composer-helper-peer-handoff-v1',
    review=review,audit=audit,Source=h['Source'],source_only=True,scientific_calls=0,
    actual_execution_authorized=False,source_review_passed=True,check_count=len(checks),mismatch_count=0,
    tools_stopped_after_handoff=True,next='Distinct full point/symbolic consumer and current pipeline/plan review required; no runtime grant.'))
print(json.dumps(dict(handoff=out,review=review,audit=audit,checks=len(checks)),sort_keys=True))
