"""Metadata-only independent consumer review; never evaluates subject code."""
from pathlib import Path
import ast,copy,hashlib,json,subprocess
C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
L=Path('/private/tmp/gcts-cluster-composer-library-20261019')
checks=[]
def raw(p):return Path(p).read_bytes()
def desc(p):
 b=raw(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(name,ok,detail=None):
 checks.append(dict(check=name,passed=bool(ok),detail=detail))
 if not ok:raise AssertionError(name)
def load(p):return json.loads(raw(p))
def pin(d):need('whole_pin:'+d['path'],desc(d['path'])==d);return d
def dump(n):return ast.dump(n,include_attributes=False)
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_bytes((json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode());return desc(p)
hp=pin(dict(path=str(L/'handoff-v1.json'),bytes=3551,sha256='8e56b836d621c088ca47c886574dda6e67e72a182dd1f4f15977bd91a56de194'))
h=load(hp['path'])
for key in ('API','Source_contract','helper_Source_peer','helper_handoff','point_additions','author_static_audit'):pin(h[key])
for d in list(h['sources'].values())+list(h['parents'].values()):pin(d)
need('helper_exact_reviewed_pin',h['sources']['support_ordering']==load(h['helper_Source_peer']['path'])['Source'])
pairs={};patches=[]
for role,alias,filename in [('point','family_search','point.py'),('symbolic','symbolic_control','symbolic.py')]:
 old=raw(h['parents'][role]['path']);new=raw(h['sources'][alias]['path']);pt=ast.parse(old.decode());nt=ast.parse(new.decode())
 pairs[role]=(old,new,pt,nt)
 parentdefs={n.name:n for n in pt.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 newdefs={n.name:n for n in nt.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 changed='search' if role=='point' else 'search_symbolic'
 for name,node in parentdefs.items():
  if name!=changed:need('whole_retained_definition:'+role+':'+name,name in newdefs and dump(node)==dump(newdefs[name]))
 for payload,label in [(old,role+'_parent'),(new,role+'_successor')]:
  code=compile(payload.decode(),'<unused-'+label+'>','exec',dont_inherit=True);del code
 inert=C/('consumer-inert-'+role+'-v1');inert.mkdir(exist_ok=False);(inert/filename).write_bytes(old)
 for direction,wanted in [('forward',new),('inverse',old)]:
  pp=desc(L/(role+'-'+direction+'.patch'));patches.append(pp)
  r=subprocess.run(['patch','-s','-p1','-i',pp['path']],cwd=inert,capture_output=True,text=True)
  need('actual_inert_patch:'+role+':'+direction,r.returncode==0,dict(stdout=r.stdout,stderr=r.stderr))
  need('inert_whole_bytes:'+role+':'+direction,(inert/filename).read_bytes()==wanted)

po,pn,pt,nt=pairs['point'];so,sn,st,snt=pairs['symbolic']
ptext=pn.decode();stext=sn.decode()
def top(tree,name):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
def inner(node,name):return next(n for n in ast.walk(node) if isinstance(n,ast.FunctionDef) and n.name==name)
ps,pns=top(pt,'search'),top(nt,'search')
for name in ('review','support_check'):need('point_inner_exact:'+name,dump(inner(ps,name))==dump(inner(pns,name)))
pv,pnv=inner(ps,'visit'),inner(pns,'visit')
old_loop=next(n for n in pv.body if isinstance(n,ast.For))
new_loop=next(n for n in pnv.body if isinstance(n,ast.For))
need('entire_base_placement_copy_update_recursion_backtrack_loop_exact',dump(old_loop)==dump(new_loop))
need('point_complete_tail_rollback_and_result_exact',po[po.index(b'    ok,tree=visit(initial,graph,None)'):]==pn[pn.index(b'    ok,tree=visit(initial,graph,None)'):])
ss,sns=top(st,'search_symbolic'),top(snt,'search_symbolic')
for name in ('complete_row_packet','ranked_candidates'):need('symbolic_inner_exact:'+name,dump(inner(ss,name))==dump(inner(sns,name)))
ov,nv=inner(ss,'visit'),copy.deepcopy(inner(sns,'visit'))
newfor=next(n for n in ast.walk(nv) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='candidate')
oldfor=next(n for n in ast.walk(ov) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='candidate')
need('symbolic_only_visit_change_is_explicit_strategy_iterator',isinstance(newfor.iter,ast.IfExp))
newfor.iter=copy.deepcopy(oldfor.iter)
need('symbolic_rest_of_visit_exact_after_iterator_projection',dump(nv)==dump(ov))
need('symbolic_rollback_and_final_projection_return_exact',so[so.index(b'    # Only completed literal data/custody observations'):]==sn[sn.index(b'    # Only completed literal data/custody observations'):])

point_checks={
 'old_AND_explicit_off_accepted':"support_ordering not in ('legacy','and_support','composed_support')",
 'deterministic_fixed_only':"support_ordering in ('and_support','composed_support') and (mode!='fixed' or stochastic)",
 'one_root_composer_call':'composed=compose_support_cluster(graph=support_graph,check=support_check,work_limit=SUPPORT_WORK_LIMIT)',
 'full_proposal_preimage':"hashlib.sha256(_composer_json(plan)).hexdigest()!=proposal['proposal_sha256']",
 'root_empty_seeds_and_target_last':"plan['root_seed_rows']!=[]",
 'full_unique_actual_skeleton':"if len(hits)!=1:abstain('NO_UNIQUE_ACTUAL_COMMAND_SKELETON')",
 'actual_MP_variant':"variant=basis.get(_composer_json(proof[source]['formula']))",
 'block_exported_interface':"if command['name'] not in model.mode:abstain('UNAVAILABLE_INTERFACE')",
 'strict_ordered_repeated_block_refs':"type(source)is not int or not 0<=source<row",
 'C_G_all_input_roles':"keys=[(row,0,k,0),(row,1,k,variant)]",
 'exact_unused_fillers':"sources[port]+1 if port<len(sources) else 0",
 'actual_key_membership':"if key not in model.metadata:abstain('MISSING_ACTUAL_GUARD_OR_INPUT_KEY')",
 'C_G_command_identity':"_composer_json(model.metadata[keys[1]]['command'])!=wanted",
 'all_rows_projected':"if len(packets)!=model.spec['length']:abstain('INCOMPLETE_ACTUAL_ROWS')",
 'fresh_root_whole_aggregate':"actual=aggregate(model,members,root)",
 'mapping_own_token':"if stopped.owner is not owner:raise",
 'mapping_private_work':"if work>=SUPPORT_PROJECTION_WORK_LIMIT:",
 'each_branch_fresh_aggregate':"actual=aggregate(model,members,state);support_check()",
 'incident_constituent_required':"[k for k in actual['pending'] if k in g.domains.get(p,set())]",
 'explicit_composed_kind_levelzero':"kind='composed',level=0",
 'abstention_original_quota':"items,work=join(state,g,p,proposal_limit,proposal_checks)",
 'one_slot_reserved_within_rowquota':"items,work=join(state,g,p,proposal_limit-1,proposal_checks)",
 'old_AND_runs_before_override':"item,support_choice=_support_choice(model,state,items,event,support_graph,support_check)",
 'appended_policy_zero_not_distribution':"appended zero is not a sampling probability",
 'old_AND_index_retained':"before_AND_support_index=before,selected_index=slot",
 'all_original_base_alternatives':"[k for k in keys if k in preferred]+[k for k in keys if k not in preferred]",
 'new_deadline_yields_unknown_cutoff':"tree['cutoff']='composer_projection_deadline';return None,tree",
}
for n,x in point_checks.items():need('point:'+n,x in ptext)
symbolic_checks={
 'off_AND_strategy_retained':"'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1'",
 'new_strategy_explicit':"'ROOT_AND_OR_CLUSTER_COMPOSER_V1'",
 'one_root_composer_call':"support_record['composer']=support_ordering.compose_support_cluster(",
 'same_private_cap_and_search_budget':"graph=support_record['graph'],check=budget.check,work_limit=SUPPORT_WORK_LIMIT)",
 'exact_root_proposal_hash':"_sha(plan)!=proposal['proposal_sha256'] or plan['root_seed_rows']!=[]",
 'exact_full_current_prefix':"if _json(path)!=_json(proof[:row]):",
 'clockcharged_full_skeleton_scan':"if _json(actual)==_json(skeleton):hits.append(k)",
 'unique_actual_skeleton_only':"if len(hits)!=1:",
 'strict_ordered_ports':"all(type(source)is int and 0<=source<row and",
 'same_primitive_guard':"variant=_primitive_guard(command,path,basis_index,tautologies,schemes)",
 'full_candidate_identity':"preferred=dict(row=row,skeleton_index=hits[0],guard_variant=variant,",
 'AND_fallback':'yield from iterator  # exact existing AND-support fallback',
 'preferred_actual_member_first':'yield preferred',
 'exact_one_match_suppression':"if _json(candidate)==wanted:",
 'duplicate_identity_rejected':"if observation['original_match_count']!=1:",
 'missing_on_complete_exhaustion_rejected':"promoted member missing on complete original enumeration",
 'no_early_exhaustion_claim':"original_iterator_exhausted=False,exact_membership_checked=False",
 'normal_bound_extension_counter':'budget.extend()',
}
for n,x in symbolic_checks.items():need('symbolic:'+n,x in stext)
need('no_target_case_literals_in_new_consumers',all(x not in ptext+stext for x in
    ('prospective-fol-20261018-006','fol-suite-006','quantified-shared-premise-fork-join')))
mapping=top(nt,'_map_composed_word')
mh=[n for n in ast.walk(mapping) if isinstance(n,ast.ExceptHandler)]
need('mapping_only_private_stop_handler',len(mh)==1 and isinstance(mh[0].type,ast.Name) and mh[0].type.id=='_ComposerMappingStop')
need('mapping_direct_callbacks_not_generator',not any(isinstance(n,(ast.Yield,ast.YieldFrom)) for n in ast.walk(mapping)))
need('old_symbolic_budget_class_unchanged',dump(top(st,'_Budget'))==dump(top(snt,'_Budget')))

audit=save('consumer-Source-audit-v1.json',dict(schema='root-cluster-composer-consumer-raw-AST-audit-v1',
 reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,
 actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,
 unused_compiles=4,actual_inert_text_patch_directions=4,patches=patches,
 scope='Full consumer raw deltas, exact retained definitions/placement-loop/iterator bodies, AST and inert text restoration only. No project/module/helper/fixture/Model/Native/search/codec/inverse/callback evaluation.'))
review=save('typed-consumer-Source-review-v1.json',dict(schema='root-cluster-composer-consumers-typed-Source-review-v1',
 source_review_passed=True,reviewer_identity='/root/conventional_control_review',author_identity='/root/conventional_library',
 source_only=True,scientific_calls=0,component_imports=0,component_calls=0,fixture_calls=0,callback_calls=0,
 scientific_acceptance=False,mathematical_proof_admitted=False,actual_execution_authorized=False,full_pipeline_qualified=False,
 handoff=hp,sources=h['sources'],subjects=list(h['sources'].values()),parents=h['parents'],API=h['API'],source_contract=h['Source_contract'],
 helper_Source_peer=h['helper_Source_peer'],audit=audit,check_count=len(checks),mismatch_count=0,findings=[],
 inherited_peer=desc('/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json'),
 authorship_disclosure='Control authored inherited symbolic and AND-helper bodies; Library authored the new point and symbolic composer consumers. This review independently assesses the new Library edits and binds retained raw/AST bodies to prior genuine Receiver peer ancestry. It is not fresh independent certification of Control-owned inherited algorithms.',
 conclusions=[
  'OFF and_support uses the original graph construction, rank windows/Join ranking, guards, ordered source enumeration, complete alternatives and quotas. Pure retained top-level definitions and nested point review/check, symbolic rank/row projections, whole point placement/copy/update/recursion loop and rollback/result tails are raw or AST exact. Metadata VERSION/current Source startup changes are explicit, not runtime trace/timing equivalence.',
  'Point ON calls the same root EMPTY-seed helper once inside its original search clock and maps the full ordinary word to unique actual skeletons, guard variants, mode/input source keys and unused fillers. All actual keys, complete row packets and a fresh root aggregate must exist; caller Model identity/custody remains an external mandatory gate.',
  'At a genuine branch with no active hint, ON freshly aggregates the mapped word with the current actual state and requires a pending constituent incident to the Graph-selected point. It then reserves one row-proposal slot by calling Join with23 under the declared24 default, preserving the original sampled/defer generator and checks2048. This is a row quota, not a total pool limit. Incompatibility/abstention uses Join24 and ordinary AND support.',
  'The original AND choice and policy arrays are retained before an explicit deterministic composed override. Appended probability0 is labelled as bookkeeping, not a sampling probability. The original support ranking receipt covers the original Join pool before append; the literal field before_AND_support_index contains the completed AND selected index immediately before composer override, not a pre-AND policy index.',
  'Composed items use kind composed and level0; this does not rename an aggregate as an ordinary single-lemma row. The unchanged Graph global dead/forced/earliest-generation decision, one-base-placement loop, full incident alternatives and exact root restoration are retained. A full-word hint never bulk-installs rows or changes candidate degree.',
  'Symbolic ON requires exact literal root-plan prefix, current preimage hash, unique original skeleton and the same primitive guard or every ordered/repeated strict-prior block port. It constructs the exact original row/skeleton/variant/mode/command identity and moves that one member to the front. If resumed, it skips exactly one later canonical full identity and rejects duplicate/missing identities on complete underlying exhaustion. Early win/stop retains no imagined skip or exhaustion.',
  'The original AND-support ranked iterator remains complete and unchanged; unmatched prefix, proposal abstention or no available exact member uses it directly. Original multiplicity, ordered source tuples, all other candidate/padding identities, extension counting, private budget owner checks, stack cleanup, final key projection and complete input literal custody remain.',
  'Point mapping has its own200000-operation owner stop; symbolic membership scans are charged to the unchanged absolute search clock and do not have a separate200000 mapping counter. Helper/build/ranking200000 limits are separate calls. Copies, mapping, aggregates, hash/JSON work and all failed/proposal overhead consume the existing search/global time and output caps; no hard elapsed latency or fit guarantee is established.'
 ],
 mandatory_full_coupling=[
  'Root driver/cold must pin these exact three whole modules in all four off/on arms and preserve identical compiler/inventory/Model/initial semantics, full original006/12rows/two rounds and current real/private caps. No prior proposal/cache or consumed subject reuse.',
  'Retain the old winning_hint_links single-lemma metric unchanged and derive any composed-hint/essential family use separately from actual path constituents and ordered ports. Candidate proposal, local proof diagnostic, quantified inference, family use and complete resource/point/Native/inverse admission are different claims.',
  'Fresh whole Native proof plus all used original definitions, complete point/decode, Source/input/rollback custody, whole raw result/forest inverse and old comparator, original positive/terminal clocks, highwater/log/group/EOF gates remain mandatory; this receipt is not the whole pipeline or prospective plan review.',
  'Protected exclusive-owner current inputs/modules/clock remain trusted. No arbitrary hostile callback/memory/OS seal or all-exception identity through inherited generator adapters is claimed. New mapping callbacks are direct; symbolic inherited generators and trusted internal budget checks retain their old exact scope.'
 ],
 limitations=[
  'No consumer/helper/fixture/Model/Graph/compiler/Native/solver/search/codec/inverse/renderer/callback was imported, called or evaluated. Four compile objects were unused; four patch directions only changed inert copies.',
  'No proof route or command order for006 was authored. No proposal success, exact runtime membership, full pipeline qualification, learned marking, RL, general-FOL/primitive-Wang completion or GCTS-specific benefit follows.',
  'Cold/driver/outer current closure and prospective four-arm declarations/subjects/grants remain separate pending reviews. No execution authority is delegated.'
 ]))
handoff=save('consumer-review-handoff-v1.json',dict(schema='root-cluster-composer-consumers-peer-handoff-v1',
 review=review,audit=audit,source_only=True,scientific_calls=0,actual_execution_authorized=False,
 check_count=len(checks),mismatch_count=0,source_review_passed=True,
 next='Separate current Root driver/cold/outer/dependency and prospective plan scopes required.',tools_stopped_after_handoff=True))
print(json.dumps(dict(handoff=handoff,review=review,audit=audit,checks=len(checks)),sort_keys=True))
