"""Control-owned raw/AST/ordinary-metadata review. Never loads subject code."""
from pathlib import Path
import ast
import hashlib
import json

C = Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
D = Path('/private/tmp/gcts-finalization-integration-ROOT-20261019')
C.mkdir(exist_ok=True)
checks = []

def raw(path):
    return Path(path).read_bytes()

def desc(path):
    b = raw(path)
    return dict(path=str(path), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def need(name, ok, detail=None):
    checks.append(dict(check=name, passed=bool(ok), detail=detail))
    if not ok:
        raise AssertionError(name)

def pinned(d):
    actual = desc(d['path'])
    need('whole_raw_pin:' + d['path'], actual == d)
    return actual

def load(path):
    return json.loads(raw(path))

def save(name, value):
    p = C / name
    if p.exists():
        raise FileExistsError(str(p))
    p.write_bytes((json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, indent=2) + '\n').encode())
    return desc(p)

master = pinned(dict(path='/private/tmp/gcts-cadence-integration-ROOT-20261019/basic-tiling-algorithm-HEAD.md', bytes=36240,
    sha256='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'))
closure_pin = pinned(dict(path=str(D/'runtime-closure-v1.json'), bytes=123025,
    sha256='efc15108d03dc3cf75151867ed85598d8ab264547b1d3e38e52545b3b2d86406'))
closure = load(closure_pin['path'])
all_sources = {}
for group in ('project_sources', 'additional_nonseed_components', 'evidence_sources', 'schema_sources'):
    for alias, d in closure[group].items():
        need('unique_alias:' + alias, alias not in all_sources)
        all_sources[alias] = pinned(d)
all_sources['cold'] = pinned(closure['cold'])
need('current_parent_source_count30', len(all_sources) == 30)

capsule = pinned(dict(path='/private/tmp/gcts-local-operational-20261019/full-assertion-capsule.json', bytes=22422,
    sha256='1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0'))
cap = load(capsule['path'])
identifier = 'prospective-fol-20261018-006'
selected = [r for r in cap['receivers'] if r['id'] == identifier]
need('unique_original006', len(selected) == 1)
case = selected[0]
case_pin = pinned(next(d for d in cap['input_sources'] if d['path'].endswith('/'+identifier+'.json')))
need('individual_input_whole_literal_equals_capsule_receiver', load(case_pin['path']) == case)
group = next(g for g in cap['groups'] if g['case_id'] == identifier)
need('006_original_structural_primary', group == dict(case_id=identifier,
    group='quantified-shared-premise-fork-join', renaming_control_of=None, structural_primary=True))
need('unchanged_horizon', type(case['length']) is int and case['length'] == 12 and
    type(case['instantiation_rounds']) is int and case['instantiation_rounds'] == 2)
need('closed_initial_quantified_shape', set(case['theory']['axioms']) == {'a0','a1','a2','a3'} and
    all(f[:2] == ['all','x'] for f in case['theory']['axioms'].values()) and case['target'][:2] == ['all','x'])
need('no_functions_schemas_or_supplied_root_blocks', case['theory']['functions'] == {} and
    case['theory']['schemas'] == [] and not case.get('assumptions') and not case.get('blocks'))
need('exact_monadic_signature', case['theory']['predicates'] == dict(P=1,Q=1,R=1,S=1))

table_path = '/private/tmp/gcts-first-order-suite-retained-resource-peer-20261018/forty-result-resource-table-v1.json'
table_pin = pinned(dict(path=table_path, bytes=132126,
    sha256='9d12fdd149715202009f17c0f0b5ec7df6a0a6bb655dde1713a8a854a14b94fb'))
prior_review = desc('/private/tmp/gcts-first-order-suite-retained-resource-peer-20261018/typed-resource-review-v1.json')
rows = [r for r in load(table_path)['rows'] if r['invocation_id'].startswith('fol-suite-006-')]
need('all_four_prior006_rows', len(rows) == 4 and {r['order'] for r in rows} == {21,22,23,24})
need('prior006_all_unknown_no_proof_resource_closed', all(r['stored_status'] == 'unknown_search_budget' and
    r['search_status'] == 'unknown_search_budget' and r['stored_native_proof_flag'] is False and
    r['resource_profile_pass'] is True and r['group_absent'] is True and
    r['stdout_eof'] is True and r['stderr_eof'] is True for r in rows))
need('prior_units_distinct', all(r['search_work_unit'] == ('proof_row_extension' if r['mode']=='symbolic'
    else 'base_point_placement') for r in rows))
prior006 = [{k:r[k] for k in ('invocation_id','mode','search_ordering','order','stored_status',
    'search_work_count','search_work_unit','search_seconds','external_terminal_seconds',
    'result_bytes','conservative_peak_sum_bytes','resource_profile_pass','retained_pins')} for r in rows]

policy_pin = desc('/private/tmp/gcts-semantic-family-next-audit-20261018/semantic-inventory-policy-001.json')
kernel_pin = desc('/private/tmp/gcts-semantic-family-next-audit-20261018/fol_checker.tree')
policy = load(policy_pin['path'])
need('four_frozen_family_templates', len(policy['library']) == 4)

source_evidence = {}
targets = {
 'quantified_receptors_v1': ('syntax','domains','compile_guards'),
 'quantified_family_points_v2': ('Model',),
 'quantified_symbolic_control_v2': ('_intake','_primitive_guard','search_symbolic'),
 'semantic_inventory_search_v2': ('_complete_rows','_support_choice','search'),
 'receptor_support_ordering_v1': ('build_support_graph','_justified','_potential','rank_support_options'),
 'semantic_inventory_guidance': ('row_requirements','Join'),
 'semantic_receptor_points': ('Model',),
 'native_receptor_points': ('assignment',),
 'semantic_lemma_inventory': ('specialize','used_definitions'),
 'turtle': ('State','Graph'),
 'receiver_driver': ('_proof_observation','_winning_hint_links','run_receiver_owned'),
 'certificate_boundary_search': ('choices',),
 'logic': ('tautology','Kernel'),
}
for alias, names in targets.items():
    p = all_sources[alias]['path']
    text = raw(p).decode()
    tree = ast.parse(text, filename=p)
    records = []
    for n in tree.body:
        if isinstance(n, (ast.FunctionDef,ast.ClassDef)) and n.name in names:
            records.append(dict(name=n.name, line=n.lineno, end_line=n.end_lineno,
                AST_sha256=hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest(),
                raw_segment_sha256=hashlib.sha256(ast.get_source_segment(text,n).encode()).hexdigest()))
    need('all_declared_review_spans:' + alias, set(n['name'] for n in records) == set(names))
    source_evidence[alias] = dict(source=all_sources[alias], reviewed_definitions=records,
        full_AST_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest())

compiler = raw(all_sources['quantified_receptors_v1']['path']).decode()
point = raw(all_sources['semantic_inventory_search_v2']['path']).decode()
symbolic = raw(all_sources['quantified_symbolic_control_v2']['path']).decode()
driver = raw(all_sources['receiver_driver']['path']).decode()
support = raw(all_sources['receptor_support_ordering_v1']['path']).decode()
graph = raw(all_sources['turtle']['path']).decode()
need('compiler_frozen_policy_named', "TERM_POLICY = 'TARGET_FREE_SUBTERMS_UNION_ALL_INITIAL_BINDER_VARIABLES_V1'" in compiler and 'INSTANTIATION_ROUNDS = 2' in compiler)
need('shared_driver_search_caps_and_fixed_policy', 'attempts=5000, seconds=seconds' in driver and
    'proposal_limit=24, proposal_checks=2048, seed=64000' in driver and
    'stochastic=False, weights=None, support_ordering=search_ordering' in driver and 'seconds = min(30, boundary.remaining())' in driver)
need('proof_observer_distinguishes_quantifiers_and_hints', 'quantified_reasoning_success=bool(instantiate and generalize)' in driver and
    "result['family_hint_success'] = result['quantified_reasoning_success'] and links['strong_family_hint_use']" in driver)
need('fixed_hint_retains_all_alternatives', "[k for k in keys if k in preferred]+[k for k in keys if k not in preferred]" in point)
need('symbolic_complete_reference_multiplicity', 'for sources in itertools.product(*choices):' in symbolic and
    'no candidate/ref/word/padding quotient or pruning.' in symbolic and
    'Only completed windows are ranked.' in symbolic)
need('graph_generation_priority', "(state.generations.get(p,state.roots.get(p,0)),len(self.domains[p]),p)" in graph)
need('support_positive_ordered_AND_cost', 'value = 1 + sum(values)' in support and
    "positive_row_cost=1" in support and "zero_read_licence_only=True" in support)

exposure = dict(schema='quantified-case006-review-exposure-v1', reviewer_identity='/root/conventional_control_review',
    source_only=True, scientific_calls=0, actual_execution_authorized=False,
    case=case_pin, capsule=capsule,
    exposed_material=[
      'Full original case006 assertion, signature, four universally quantified axioms, target, horizon and catalogue-round metadata.',
      'Existing generic four-family library policy, compiler, checker Source, scheduler, symbolic enumeration and driver observation Source.',
      'Retained prior four case006 UNKNOWN outcomes, resource table and saved original-result descriptors; large result bodies were not reopened in this review.'
    ],
    proof_route_authored=False, proof_commands_authored=False, new_lemma_or_target_order_authored=False,
    exposure_scope='Already evaluated synthetic case. This new review exposure is separate from prior task/policy authorship. Do not classify the case as held out or send this analysis as a solver hint; no reviewed Source/program was executed.')
exposure_pin = save('review-exposure-v1.json', exposure)

common_zero = dict(source_only=True, scientific_calls=0, component_imports=0, component_calls=0,
    fixture_calls=0, codec_calls=0, inverse_calls=0, Native_calls=0, actual_execution_authorized=False,
    scientific_acceptance=False, mathematical_proof_admitted=False, full_pipeline_qualified=False)

composer = dict(schema='generic-support-composer-design-review-v1', reviewer_identity='/root/conventional_control_review',
    author_identity='/root/conventional_control_review', **common_zero,
    design_only=True, implementation_source_pass=False,
    assessment='Plausible generic deterministic conventional planning proposal, conditional on the obligations below. It is a new search factor, not the V8 selector-only change or a runtime-qualified extension of the old ordering heuristic.',
    current_Root_design_direction='Root has selected once-per-arm root composition with EMPTY seeds, explicit composed_support off/on and four fresh fixed/symbolic by off/on arms. The old and_support path remains unchanged. Concrete API, Source, declarations, exact subjects and runtime qualification are still pending. Empty seeds deliberately avoid the generic seed-row ambiguity in G3; this is a design constraint, not an evaluated implementation fact.',
    basis=dict(support_helper=all_sources['receptor_support_ordering_v1'],
        fixed_search=all_sources['semantic_inventory_search_v2'], symbolic=all_sources['quantified_symbolic_control_v2'],
        full_parent_closure=closure_pin, current_master=master),
    obligations=[
      dict(id='G1_complete_inputs', requirement='Use only the current complete authenticated compiler, full admitted inventory and full literal support graph. Incomplete graph/scoring/private stop yields retained abstention or UNKNOWN, never a claim of no proof or grammar exhaustion. No target/case IDs, formula names, authored route, new rule, term or family.'),
      dict(id='G2_origins_not_authority', requirement='A finite potential is only a selected plan candidate. Recheck exact edge IDs, formula IDs, active root-basis flag, positive costs, complete ordered premises and all frozen provenance. Reject cycles, missing edges, mismatched definitions and future/self references before returning a proposal. The potential is not a capacity bound or proof checker.'),
      dict(id='G3_seed_custody', requirement='CURRENT_JUSTIFIED_FACT origins currently carry no row ID. Bind each seed to an actual recursively justified earlier row in the present prefix/state; do not credit guard-only, incomplete, future, or merely proposed formulas. Preserve ordered/repeated premise ports even when one earlier row supplies multiple equal premises.'),
      dict(id='G4_licenses', requirement='Zero-read instantiate/eq_subst edges emit exactly the admitted implication command, never the instantiated consequent as an axiom. Axiom names/formulas, tautology indexes, reflexivity, MP antecedent/implication roles, generalization variable/body and block mode/name/arguments/definition/port order must map to the current original grammar exactly.'),
      dict(id='G5_capacity_and_tail', requirement='Count actual emitted original commands after shared DAG scheduling, strict-prior index remapping, legal fillers and any target-tail reification. The last serialized row must be exactly the original target. Reusing a previously derived target is not an extra copy rule; any duplicate must be an independently valid original command with valid prior references. Abstain on more than twelve rows or if exact twelve-row padding cannot be constructed from the existing grammar.'),
      dict(id='G6_dedup_scope', requirement='Deduplicate shared formulas only inside this optional proposal with an explicit formula-to-original-row map and exact reference remapping. Do not deduplicate or filter original row skeletons, guard variants, block source tuples, repeated ports, candidate identities, or padding alternatives in either search lane.'),
      dict(id='G7_same_common_proposal', requirement='Both lanes call the same fresh generic proposer from the same original data, with the same declared proposer policy/private cap, and retain its complete receipt. Charge setup, copies, graph/relaxation, plan extraction, mapping and failed/abstained work in the original search/global clock. No proposal/table cache from a prior lane or consumed actual. Equal API policy does not imply equal measured time.'),
      dict(id='G8_fixed_scheduler', requirement='Map the complete word through the actual Model to all C/G/input-role keys and validate its whole aggregate in the actual state. A hint must meet the graph-selected point to activate; otherwise it waits or abstains. Consume at most one base placement through unchanged global dead, forced and earliest-generation decisions; retain all base alternatives and exact rollback. No bulk macro execution or changing degree counts.'),
      dict(id='G9_symbolic_membership', requirement='Prioritize only exact original candidates: row, skeleton index, guard variant, mode, command and ordered source tuple. Preserve a one-to-one complete original iterator and all multiplicities. If direct membership construction is used to emit an out-of-order member, prove its identity and record the exact subsequent occurrence suppression; do not inject an extra command, suppress all equal-formula alternatives, truncate a bounded scan, or report exhaustion from incomplete scoring. Partial deadline work is UNKNOWN.'),
      dict(id='G10_prefix_conflict', requirement='Specify what happens after the actual search prefix diverges from the planned word. A stale row index/seed/context is never reused. Either discard the optional hint and resume all originals or regenerate under the same declared policy and charged budget. No search-state mutation during proposal construction.'),
      dict(id='G11_errors_ownership', requirement='Only private owner-identified finite proposal stops may become abstention/UNKNOWN. Exact caller/Source/deadline/foreign errors, including StopIteration, propagate without PEP479 wrapping or misclassification. Use direct non-generator boundaries or preserve the current documented limitations; do not broaden all-exception claims. Copy/own literal inputs and receipts; all original spec/library/Model state remain unchanged on every path.'),
      dict(id='G12_records', requirement='Retain full graph binding, selected origins, seed-row bindings, topological and serialized row maps, ordered port references, tail/padding decisions, Model keys, aggregate validation, all cost counters and stop reasons. Full raw records remain subject to both existing output caps; no event/candidate shortening or silent root dropping.'),
      dict(id='G13_acceptance', requirement='A proposal remains authority false. Completed full point/decode, fresh whole Native proof with all used original dependency closure, input/Source/rollback custody, full saved inverse/legacy canonical comparison and unchanged lifecycle/resource gates precede any final admission. A valid proof need not use a family; mathematical proof, quantified inference, essential family use and actual composed-hint consumption are separate outcomes.'),
      dict(id='G14_attribution', requirement='If the proposer constructs a complete proof candidate, report that shared conventional planning result and subsequent point/symbolic consumption separately. Do not attribute the route to learned markings, RL, generic GCTS superiority, or the mere availability of a family. The old and_support strategy remains an explicit immutable control if compared.'),
      dict(id='G15_qualification', requirement='Before any fresh actual, independently review the concrete helper, both adapters, all changed Source/dependency/callback/record gates and exact false subjects. Predeclare generic cycle/unknown/ordered-repeat/shared-output/zero-license/tail/padding/prefix-conflict/multiplicity/foreign-error/rollback obligations without running them now. Keep case006 unchanged and no fit guarantee.')
    ],
    actual_profile_selection_or_grant=False,
    limitation='No code was authored for the composer, no graph or potential was evaluated, no case006 proof route was constructed, and feasibility within the original horizon/time/memory/output caps is unmeasured.')
composer_pin = save('generic-composer-design-review-v1.json', composer)

review = dict(schema='new-quantified-engine-support-claim-review-v1', reviewer_identity='/root/conventional_control_review',
    **common_zero, support_claim_review_completed=True, implementation_source_certified=False,
    review_scope='Current engine contract, exact original case006 validity/exposure, retained prior outcomes, and prospective claim/acceptance obligations. Not a new full algorithm Source certificate, prospective plan review or runtime qualification.',
    mismatch_count=0, findings=[],
    authorship_disclosure='Control authored inherited symbolic control, AND-support helper and old outer/protocol ancestors. Current Root consumer gates/driver/Library cold/evidence components have prior genuine distinct-author reviews. Raw/AST checks here bind retained algorithms and explain their scope; they are not fresh independent certification of Control-owned inherited bodies.',
    current_master=master, parent_runtime_closure=closure_pin, source_binding_count=30,
    parent_source_bindings=all_sources, source_evidence=source_evidence, kernel_source=kernel_pin, policy_source=policy_pin,
    input=dict(capsule=capsule, individual=case_pin, literal_selected_receiver=case, original_group=group),
    benchmark_judgement=dict(
        genuinely_quantified_requirement=True,
        argument='The closed universal axiom formulas and the different closed universal target are distinct opaque atoms under the retained propositional-tautology interpretation. Assigning truth to those axiom atoms and falsity to the target atom satisfies that propositional abstraction. This is only an abstraction argument that pure propositional atom handling cannot connect them, not a first-order countermodel, nonprovability claim, proof route, or demonstration that a twelve-row solution exists.',
        required_runtime_evidence='Observe actual essential instantiate and generalize commands in the fresh accepted recursive proof expansion, not universal formulas, unused licenses, template presence or local Native stage labels. The current driver reports those occurrences separately from essential family calls and winning hint links.',
        limited_class='Original exposed synthetic monadic universal positive fork/join case with four unary predicates, no functions, schemas, supplied root assumptions, existential/quantifier-alternation/equality/induction challenge. Not PA, Hilbert, arbitrary FOL, primitive Wang or a held-out external benchmark.',
        horizon='Exactly twelve original rows and two frozen initial-binder catalogue rounds. Prior UNKNOWNs establish neither impossibility nor horizon sufficiency. Do not retarget, add terms/families or write a command order.'),
    prior_evidence=dict(table=table_pin, prior_resource_review=prior_review, rows=prior006,
        scope='This review rehashed the saved table and prior receipt, not the four large original result bodies. Original result descriptors are retained historical references. All four are previously resource-admitted UNKNOWN outcomes, not new proof evidence or current-profile comparisons.'),
    engine_contract=dict(
        common_grammar='Same full bounded compiler basis/schemes, original named axioms, admitted complete family inventory, derived maximum interface arity, strict earlier sources, C/G and every input filler role; exactly twelve rows and target last.',
        fixed='Deterministic fixed-policy factored point search. Integer capacity twelve per singleton positive root, full literal word markings and complete candidate incidence/dependencies. Global dead, global forced, then earliest generation; all declared roots are generation zero, so branch generation ties reduce to degree/key. Validated semantic single-row and sampled-cluster proposals plus shared AND-support only reorder all original base alternatives. No current RL training or learned marking elimination.',
        symbolic='Specialized chronological proof-row DFS over the same original skeletons/guards/modes and every ordered source tuple. Shared AND-support ranks complete stable windows of sixty-four. No point-graph scheduler; common Model construction and final point projection still charged. Complete candidate/ref/padding multiplicity retained. Not a dedicated Vampire/E baseline or a no-point-setup timing control.',
        defaults='Generic point API defaults 20000 attempts/60 seconds; the actual shared driver explicitly overrides both arms to 5000 and at most thirty remaining seconds. Units differ: base-point placements versus proof-row extensions. Proposal24/checks2048, deterministic seed64000, weightsNone, FIXED vector; compiler queries512/micro1e9, Native/fallback5e9; arity derived over all exported interfaces. Private helper work200000 is not a proof/search completeness bound.',
        finite_scope='Full point-domain/master claims are limited to this finite fixed-role proof adaptation. No primitive-square Wang, seeded outward growth, infinite tiling, full master section8 runtime conformance theorem or general FOL completeness follows from this Source inspection.'),
    comparison_requirements=[
        'Same immutable case006, full admitted knowledge/library/policy, original grammar/horizon, Model/initial semantics, original Source/runtime/Native/Z3/Python pins and whole certificate gates in both fresh arms.',
        'Count all acquisition/compilation/full inventory admission/common Model/proposer/search/point/final Native/rollback/serialization/forest/inverse/old-reader/outer cleanup costs and failed prefixes under the stated windows. Do not equate unlike 5000-operation units or quote only successful search time.',
        'The frozen four-family policy is reused knowledge. Report its donor/training provenance and earlier acquisition cost separately; a fresh runtime process is not fresh lemma discovery or RL training. For any future GCTS-specific comparison with a dedicated prover, export identical validated knowledge/certification scope or explicitly withhold such attribution.',
        'Keep mathematical admission, essential quantified inference, essential nonidentity family use, actual same-ports hint consumption and changed-order observations distinct. A mere complete proposal, family availability, local Native proof diagnostic, or UNKNOWN does not establish receptor reuse or speed benefit.',
        'Current finite buffered-comparator qualification on the two case001 preimages does not qualify a larger case006 production record. Historical fixed outputs already exceeded one hundred million bytes. Full current ordinary+forest/metadata physical accounting, expanded logical cap, all private counters and real hardware caps remain decisive; fit is unmeasured.',
        'Fresh declarations/Source tuples/false subjects and maxone grants must precede any future actual. Preserve all four old006 UNKNOWNs and prior001 outcomes. Do not reuse consumed subjects or classify a new complete endpoint as held-out discovery or an old/new causal ablation.'
    ],
    profile_scope='Original positive worker work/result reading/known exit before180 monotonic seconds; subsequent full outer checks/terminal before210. Darwin separate Python+Native highwater sum <=1GiB (not simultaneous live RAM); full physical and expanded logical128MiB, logs4MiB, disclosed outer reservation and arena400m/adapter400m/inverse30m remain separate units. No future grant or allowance change selected here.',
    required_new_scientific_design=composer_pin,
    current_cold_status='Library V8 packet received as inactive Source-only selector/label successor; not independently certified by this note. Root is now considering a separately reviewed generic composer, so a V8-only case006 run is not the substantive new search intervention.',
    exposure_record=exposure_pin,
    limitations=[
        'No subject function/module/fixture/codec/inverse/Native/Model/search/renderer was imported, called or replayed; no opaque Native content decoded.',
        'No proof route, commands, task-specific rule/order, new lemma, easier target or term pool was authored.',
        'Pinned checker Source was read as text only. Current Native program build/source correspondence, Python/OS/exclusive-owner loading and schema-admission structural trust remain the previously declared boundaries; no independent kernel soundness theorem is claimed.',
        'Prior finite component and pipeline admissions retain their original exact scopes and outcomes. This note establishes no new runtime success, candidate availability, performance advantage or full GCTS/RL conformance.'
    ])
review_pin = save('typed-support-claim-review-v1.json', review)
audit = dict(schema='new-quantified-support-claim-raw-AST-audit-v1', reviewer_identity='/root/conventional_control_review',
    **common_zero, checks=checks, check_count=len(checks), mismatch_count=0,
    implementation_compile_calls=0, AST_parse_only=True,
    scope='Raw whole pin checks, ordinary JSON shape/equality/history selection and selected Source AST custody. Subject definitions were never evaluated.')
audit_pin = save('raw-support-claim-audit-v1.json', audit)
handoff = dict(schema='new-quantified-support-claim-review-handoff-v1', reviewer_identity='/root/conventional_control_review',
    **common_zero, support_claim_review=review_pin, generic_composer_design_review=composer_pin,
    exposure=exposure_pin, audit=audit_pin, check_count=len(checks), mismatch_count=0,
    next='Await exact new scientific/helper/adapter/Source coupling packet; no Source PASS, plan review or execution authority for the contemplated composer.',
    tools_stopped_after_handoff=True)
handoff_pin = save('support-claim-handoff-v1.json', handoff)
print(json.dumps(dict(handoff=handoff_pin, review=review_pin, composer=composer_pin, audit=audit_pin, checks=len(checks)),sort_keys=True))
