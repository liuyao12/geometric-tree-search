"""Source/AST/ordinary metadata only; no subject definitions are evaluated."""
from pathlib import Path
import ast,hashlib,json,subprocess
C=Path('/private/tmp/gcts-new-quantified-integration-peer-20261019')
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
L=Path('/private/tmp/gcts-new-quantified-integration-library-20261019')
checks=[]
def raw(p):return Path(p).read_bytes()
def desc(p):
 b=raw(p);return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def j(p):return json.loads(raw(p))
def dump(n):return ast.dump(n,include_attributes=False)
def need(n,ok,d=None):
 checks.append(dict(check=n,passed=bool(ok),detail=d))
 if not ok:raise AssertionError(n)
def pin(d):need('whole_pin:'+d['path'],desc(d['path'])==d);return d
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_bytes((json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode());return desc(p)
def constants(tree):
 out={}
 for n in tree.body:
  if isinstance(n,ast.Assign):
   for name in n.targets:
    if isinstance(name,ast.Name):
     try:out[name.id]=ast.literal_eval(n.value)
     except (ValueError,TypeError):pass
 return out
manifest=pin(dict(path=str(D/'false-plan-manifest-v1.json'),bytes=6502,sha256='cdfcb5fdd204b0637b08c2eb15143feaf66c4f3c5c5df350715da52fdf74d2b6'))
m=j(manifest['path']);closure_pin=pin(m['runtime_closure']);decl_pin=pin(m['declaration'])
cl=j(closure_pin['path']);decl=j(decl_pin['path'])
parent_cl=j('/private/tmp/gcts-finalization-integration-ROOT-20261019/runtime-closure-v1.json')
parent_review=desc('/private/tmp/gcts-finalization-integration-peer-20261019/typed-components-Source-review-v1.json')
parent_once=desc('/private/tmp/gcts-finalization-integration-peer-20261019/typed-once-Source-review-v1.json')
all_sources={**cl['project_sources'],**cl['additional_nonseed_components'],**cl['evidence_sources'],**cl['schema_sources'],'cold':cl['cold']}
need('thirty_current_component_subjects',len(all_sources)==30 and len(cl['project_sources'])==22 and len(cl['materialized_aliases'])==28)
for d in all_sources.values():pin(d)
for d in cl['outer_sources'].values():pin(d)
need('same_retained_evidence_and_schema',cl['evidence_sources']==parent_cl['evidence_sources'] and cl['schema_sources']==parent_cl['schema_sources'])
for k in ('Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python'):
 need('inherited_full_runtime_map:'+k,cl[k]==parent_cl[k])
need('unchanged_current_master',cl['current_master']==parent_cl['current_master'])
pin(cl['current_master'])
need('current_not_activated',cl['actual_execution_authorized'] is False and cl['scientific_calls']==0 and cl['source_only'] is True and cl['runtime_activation_authorized'] is False)

contracts={k:desc(D/(k+'-Source-contract-v1.json')) for k in ('driver','cold','outer')}
ds,cs,os=(j(contracts[k]['path']) for k in ('driver','cold','outer'))
need('driver_pin_matches_closure',ds['driver']==cl['additional_nonseed_components']['receiver_driver'])
need('cold_pin_matches_closure',cs['cold']==cl['cold'] and os['sources']['cold']==cl['cold'])
need('outer_pins_match_closure',os['sources']['runner']==cl['outer_sources']['runner'] and os['sources']['observer']==cl['outer_sources']['observer'])
for role,obj,key in [('driver',ds,'driver'),('cold',cs,'cold')]:
 parent=pin(obj['parent']);new=pin(obj[key]);text=raw(parent['path']).decode()
 for change in obj['changes']:
  need('exact_declared_edit_count:'+role+':'+change['old'][:55],text.count(change['old'])==change['count'])
  text=text.replace(change['old'],change['new'])
 need('all_and_only_contract_replacements:'+role,text.encode()==raw(new['path']))

v8h=j(pin(dict(path=str(L/'handoff-v1.json'),bytes=7844,sha256='44c39c339136487caf67322114f7a44c9a01fc2ba081dd70ffba589e9b0778ae'))['path'])
v8delta=j(pin(v8h['Source_delta'])['path'])
v7=pin(v8delta['parent']);v8=pin(v8delta['successor'])
text=raw(v7['path']).decode()
for e in v8delta['edits']:
 need('coldV8_declared_edit_unique:'+e['label'],text.count(e['before'])==1);text=text.replace(e['before'],e['after'])
need('coldV8_all_and_only_four_edits',text.encode()==raw(v8['path']))
need('coldV9_parent_is_that_V8',cs['parent']==v8)

inert_specs=[('driver',ds['parent'],ds['driver'],D/'driver-parent-successor.patch'),
 ('cold',cs['parent'],cs['cold'],D/'cold-parent-successor.patch'),
 ('runner',os['parents']['runner'],os['sources']['runner'],D/'runner-parent-successor.patch'),
 ('observer',os['parents']['observer'],os['sources']['observer'],D/'observer-parent-successor.patch')]
patch_pins=[]
for role,parent,current,patch in inert_specs:
 pin(parent);pin(current);patch_pins.append(desc(patch))
 folder=C/('coupling-inert-'+role+'-v1');folder.mkdir(exist_ok=False);target=folder/'subject.py';target.write_bytes(raw(parent['path']))
 for reverse,wanted in [(False,raw(current['path'])),(True,raw(parent['path']))]:
  args=['patch','-s']+(['-R'] if reverse else [])+['-i',str(patch),str(target)]
  r=subprocess.run(args,capture_output=True,text=True)
  need('actual_inert_patch:'+role+':'+str(reverse),r.returncode==0,dict(stdout=r.stdout,stderr=r.stderr))
  need('actual_inert_whole_reconstruction:'+role+':'+str(reverse),target.read_bytes()==wanted)

for direction in ('forward','inverse'):
 pin(v8delta[direction])
folder=C/'coupling-inert-coldV8-v1';folder.mkdir(exist_ok=False)
target=folder/'owned_evidence_cold_v7.py';target.write_bytes(raw(v7['path']))
for direction,wanted in [('forward',raw(v8['path'])),('inverse',raw(v7['path']))]:
 r=subprocess.run(['patch','-s','-p1','-i',v8delta[direction]['path']],cwd=folder,capture_output=True,text=True)
 need('actual_inert_V8patch:'+direction,r.returncode==0,dict(stdout=r.stdout,stderr=r.stderr))
 need('actual_inert_V8whole:'+direction,target.read_bytes()==wanted)

trees={}
for role,d in [('driver',ds['driver']),('cold',cs['cold']),('runner',os['sources']['runner']),('observer',os['sources']['observer'])]:
 source=raw(d['path']).decode();trees[role]=ast.parse(source,filename=d['path'])
 code=compile(source,'<unused-'+role+'>','exec',dont_inherit=True);del code
 pt=ast.parse(raw((ds if role=='driver' else cs if role=='cold' else os['parents'])[('parent' if role in ('driver','cold') else role)]['path']).decode())
 olddefs={n.name:n for n in pt.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 newdefs={n.name:n for n in trees[role].body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 allowed={'driver':{'_Boundary','run_receiver','run_receiver_owned'},'cold':{'main'},'runner':{'intake_subject','run_once'},'observer':{'main'}}[role]
 need('same_top_definition_names:'+role,set(olddefs)==set(newdefs))
 for name,n in olddefs.items():
  if name not in allowed:need('raw_retained_AST:'+role+':'+name,dump(n)==dump(newdefs[name]))

dc,cc,rc,oc=(constants(trees[k]) for k in ('driver','cold','runner','observer'))
need('driver_new_three_dependency_pins',all(dc['DEPENDENCY_PINS'][role]==(d['sha256'],d['bytes']) for role,d in ds['new_dependency_sources'].items()))
need('driver_schema_role_retained',dc['DEPENDENCY_PINS']['schema_certificate']==(cl['schema_sources']['mp_schema_certificate']['sha256'],cl['schema_sources']['mp_schema_certificate']['bytes']))
need('cold_exact_driver',cc['RECEIVER_DRIVER_SOURCE']==ds['driver'])
need('cold_exact_three_current_sources',cc['ORDERING_COMPONENT_SOURCES']==ds['new_dependency_sources'])
need('runner_exact_cold',rc['COLD_PIN']==cs['cold'])
need('all_four_factorial_product',rc['KINDS']==('fixed','symbolic') and rc['ORDERINGS']==('and_support','composed_support') and rc['CERTIFICATIONS']==('schema_then_native',))
need('observer_exact_runner_literal',os['sources']['runner']['sha256'] in raw(os['sources']['observer']['path']).decode())
parent_runner=constants(ast.parse(raw(os['parents']['runner']['path']).decode()))
need('all_original_outer_LIMITS_exact',rc['LIMITS']==parent_runner['LIMITS'])
need('all_original_review_role_ABIs_exact',rc['REVIEW_ROLES']==parent_runner['REVIEW_ROLES'])
need('cold_caps_native_constants_unchanged',all(cc[k]==constants(ast.parse(raw(v7['path']).decode()))[k] for k in
 ('INVERSE_LIMITS','INVERSE_VERSION','INVERSE_PROFILE','ARENA_LIMITS','ADAPTER_LIMITS','SCHEMA_SOURCES','EVIDENCE_SOURCES','ROLE_MODULES')))
need('qualified_buffered_comparator_raw_AST_exact',dump(next(n for n in trees['cold'].body if isinstance(n,ast.FunctionDef) and n.name=='verify_literal_result'))==dump(next(n for n in ast.parse(raw(v7['path']).decode()).body if isinstance(n,ast.FunctionDef) and n.name=='verify_literal_result')))

for row in cl['Source_AST_census']:
 pin(row['source']);t=ast.parse(raw(row['source']['path']).decode(),filename=row['source']['path'])
 need('current_full_AST_census:'+row['alias'],hashlib.sha256(dump(t).encode()).hexdigest()==row['AST_sha256'])
need('complete_unique32_Source_census',len(cl['Source_AST_census'])==32 and
 {r['source']['path'] for r in cl['Source_AST_census']}=={d['path'] for d in list(all_sources.values())+list(cl['outer_sources'].values())})
need('nonliteral_cold_imports_explicit',len(cl['current_import_census_summary']['nonliteral_dynamic_sites'])==2 and cl['current_import_census_summary']['source_or_loader_closure_proved'] is False)
source_check_count=len(checks)

# Separate prospective V1 metadata pass: raw binding and freshness, not execution.
subjects=[]
for row in m['plans']:
 pin(row['worker_plan']);pin(row['false_once_plan'])
 w,p=j(row['worker_plan']['path']),j(row['false_once_plan']['path'])
 subject={k:v for k,v in p.items() if k!='authorization'}
 need('full18_field_subject:'+row['row']['invocation_id'],len(subject)==18)
 need('false_authorization_sentinel:'+row['row']['invocation_id'],p['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',sha256='NO_AUTHORIZATION',bytes=0))
 need('worker_and_once_current_maps:'+row['row']['invocation_id'],w['project_sources']==cl['project_sources'] and w['components']==cl['additional_nonseed_components'] and p['worker_plan']==row['worker_plan'] and w['cold']==cl['cold']==p['cold'])
 need('metadata_subject_chain:'+row['row']['invocation_id'],w['integration_declaration']==decl_pin==p['integration_declaration'] and w['runtime_closure']==closure_pin==p['runtime_closure'])
 need('current_outer_and_caps:'+row['row']['invocation_id'],p['runner']==os['sources']['runner'] and p['observer']==os['sources']['observer'] and p['limits']==rc['LIMITS'])
 need('exact_schedule_row:'+row['row']['invocation_id'],all(w[k]==p[k]==row['row'][k] for k in ('invocation_id','mode','search_ordering','inventory_certification_mode','receiver_id','result_reader','model_storage','actual_directory')))
 pin(w['declaration']);need('same_full_original_capsule:'+row['row']['invocation_id'],w['declaration']['sha256']=='1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0')
 need('exact_original006_not_route_or_targetedit:'+row['row']['invocation_id'],decl['selected_receiver']==next(r for r in j(w['declaration']['path'])['receivers'] if r['id']==p['receiver_id']))
 need('fresh_actual_and_false_terminal:'+row['row']['invocation_id'],not Path(p['actual_directory']).exists() and not Path(row['false_once_plan']['path']).with_name(Path(row['false_once_plan']['path']).stem+'-terminal-observation').exists())
 subjects.append(dict(false_once_plan=row['false_once_plan'],worker_plan=row['worker_plan'],subject=subject,
  subject_sha256=hashlib.sha256(json.dumps(subject,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()))
need('four_full_matched_arms',len(subjects)==4 and {(r['row']['mode'],r['row']['search_ordering']) for r in m['plans']}=={(a,b) for a in ('fixed','symbolic') for b in ('and_support','composed_support')})
need('all_retained_hardware_and_private_profile_values',all(decl['evidence_profile'][k]==parent_cl['evidence_profile'][k] for k in decl['evidence_profile'] if k!='adapter_diagnostics'))
diag=dict(parent_cl['evidence_profile']['adapter_diagnostics']);diag['scope']=decl['evidence_profile']['adapter_diagnostics']['scope']
need('only_current_diagnostic_scope_label_change',diag==decl['evidence_profile']['adapter_diagnostics'] and decl['evidence_profile']==cl['evidence_profile'])
need('exact_limits_profile',decl['limits']==j('/private/tmp/gcts-finalization-integration-ROOT-20261019/case-declaration-v1.json')['limits'])
need('no_false_actual_authority',decl['actual_execution_authorized'] is False and decl['scientific_calls']==0 and m['no_grant_created'] is True)

findings=[
 dict(id='P1_STALE_REPRESENTATION_ONLY',severity='metadata_blocker_before_prospective_PASS',artifact=decl_pin,field='conformance',
      literal=decl['conformance'],required_correction='Declare the new generic shared composer/proof-word proposal and explicit search-order factor. Retain unchanged grammar/point/scheduler/Native semantics and finite adaptation gaps; do not classify the whole current intervention as representation-only.'),
 dict(id='P2_STALE_SCIENTIFIC_SOURCES_UNCHANGED',severity='metadata_blocker_before_prospective_PASS',artifact=closure_pin,field='limitations[3]',
      literal=cl['limitations'][3],required_correction='State exact new helper/point/symbolic Sources and current driver/cold/outer coupling; restrict raw unchanged-source claims to the actually retained modules/evidence. Preserve V1 and rebind full metadata-only V2 subjects.')]
need('findings_bound_to_exact_stale_literals',decl['conformance'].startswith('Representation adapter only.') and cl['limitations'][3].startswith('Only out-of-band instrumentation changes'))
audit=save('current-coupling-and-prospective-v1-audit.json',dict(schema='quantified-composer-current-coupling-raw-AST-audit-v1',
 source_only=True,scientific_calls=0,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatch_count=0,
 source_scope_check_count=source_check_count,known_metadata_findings=findings,unused_compiles=4,
 actual_inert_text_patch_directions=10,patches=patch_pins,scope='All observed pins/static invariants matched. Two known prose metadata blockers are recorded separately; no subject import/call/fixture/codec/inverse/Native/Model/Reader/search evaluation.'))
common=dict(reviewer_identity='/root/conventional_control_review',author_identity='/root',author_identities=['/root','/root/conventional_library'],
 source_only=True,scientific_calls=0,scientific_acceptance=False,mathematical_proof_admitted=False,actual_execution_authorized=False,
 component_imports=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,Native_calls=0,full_pipeline_qualified=False)
components=save('typed-components-Source-review-v1.json',dict(**common,
 schema='owned-evidence-integration-components-typed-Source-review-v1',source_review_passed=True,
 subjects=list(all_sources.values()),source_subjects=all_sources,subject_count=30,
 helper_Source_review=desc(C/'typed-helper-Source-review-v1.json'),consumer_Source_review=desc(C/'typed-consumer-Source-review-v1.json'),
 Source_contracts=contracts,library_selector_handoff=desc(L/'handoff-v1.json'),audit=audit,
 current_master=cl['current_master'],parent_components_Source_review=parent_review,
 prior_buffered_comparator_Source_review=desc('/private/tmp/gcts-buffered-canonical-peer-20261019/typed-cold-Source-review-v1.json'),
 prior_finite_comparator_saved_review=desc('/private/tmp/gcts-buffered-canonical-peer-20261019/typed-saved-qualification-review-v1.json'),
 check_count=source_check_count,mismatch_count=0,findings=[],
 excluded_metadata_blockers=findings,
 scope='Exact current thirty component Sources. Independent new Library composer/consumers and Root driver/cold coupling; retained raw/AST Source provenance and protected runtime assumptions, not fresh independent own-algorithm certification. Offered V1 prospective metadata is expressly not approved.',
 ancestry='Control authored inherited symbolic/support and old outer/protocol ancestors. Genuine Receiver helper/ordering peer remains ancestry; Root/L new bodies and deltas are distinct-authored and reviewed here. Prior component/finite-helper success is not006 production qualification.',
 conclusions=[
  'All22 project+2 components+4 evidence+schema1+cold subjects are bound to exact current whole bytes. Complete32 Source AST census includes outer/observer with two nonliteral cold import sites explicitly unresolved; lexical/static data is not a loader/runtime correctness seal.',
  'Driver only changes explicit versions, three new dependency pins, composed_support acceptance and exact strategy mapping. All compilation/full library/schema registry/context custody/Model/primitive candidate/final Native/whole-point/serialization/rollback/failure bodies and the old single-lemma winning_hint_links metric are otherwise retained by exact raw replacement and AST checks.',
  'Library coldV8 changes exactly version, early literal001 restriction to a strict nonempty selector and two truthful diagnostic scope labels. Later exact full1a42 capsule, unique selected ID/full receiver preimage and current reviewed declaration binding remain mandatory. RootV9 binds driver/three modules/new schemas and exact fixed-symbolic by off-on factorial; no alternative case or implicit fallback is authorized.',
  'The buffered canonical comparator is exact raw/AST from the independently reviewed V7 candidate, preserving original direct callback entry/every65536 generatedparts/final schedule, flush-before-callback, complete BODY/EOF/hash and surrounding LF rules. Its finite prior helper qualification and explicit own-mismatch/later-encoder-error precedence limit remain the same; no new large006 record is runtime-qualified.',
  'All four evidence modules, schema certifier/raw kernel, original Native inputs/compiler/rules/policy/Python/Z3 maps and arena400m/adapter400m/inverse30m plus real/output/log gates remain literal current ancestors. Base28/Z3/cold sealing before separate schema import, no rebaseline, full original+owned maps/Source epoch and final provenance are retained.',
  'Cold exact four-arm product checks include mode, schema_then_native, and_support/composed_support, receiver, storage, reader, unique IDs/actual dirs and exact current schedule row. Full fresh Native proof/request/used block closure, whole point/decode, independent full saved forest BODY+LF inverse, old full ordinary comparator and all custody/known-exit/resource checks remain mandatory. Local Native diagnostics or completed inverse cannot rescue a failed full run.',
  'Finalization observations remain out-of-band bounded passive metadata with authorityfalse, cutoff and nested/overlapping phase caveats; no new component callback/cadence/guard or scientific observer is injected. Quantifier/family/single-lemma metrics are unchanged; composed use must be independently reconstructed later from complete accepted path evidence.',
  'Current master ca6ee is revalidated/read; point/symbolic adaptation and all-root-generation0/no learned m-elimination/noRL/no primitive Wang/fullFOL limitations remain. The new shared conventional planner may find a candidate, but point consumption is a separate endpoint and no acceleration claim is established.'
 ],
 limitations=[
  'No new subject function/module/fixture/Reader/codec/inverse/Native/Model/search was evaluated. Four current compile objects were unused; ten patch directions touched inert Source copies only.',
  'Trusted exclusive-owner raw-pinned Python/bundled stdlib/recursive loader and OS remain conditional; captured Source/raw/callable identities are not a continuous formal machine/cell/default-content seal. No malicious mutating callback or whole-kernel soundness theorem is claimed.',
  'This Source receipt excludes prospective V1 prose approval, all grants/actuals/fit/performance/proof authority. Source-matched arms still need corrected prospective subjects, Root scope adoption, fresh maxone grants, final delta and all peers idle.'
 ]))
once=save('typed-once-Source-review-v1.json',dict(**common,
 schema='owned-evidence-integration-once-typed-Source-review-v1',source_review_passed=True,
 subjects=[os['sources']['runner'],os['sources']['observer']],source_subjects=cl['outer_sources'],
 source_contract=contracts['outer'],audit=audit,parent_once_Source_review=parent_once,check_count=source_check_count,mismatch_count=0,findings=[],
 ancestry='Control authored inherited outer/lifecycle ancestors; genuine old Receiver d1fed Source review and later distinct Root delta reviews remain ancestry. Current Root changes are independently reviewed, retained own lifecycle bodies are raw/AST bound rather than freshly self-certified.',
 conclusions=[
  'Only explicit version/cold/runner bindings, nonempty early receiver selector, current closure/declaration schemas, exact factorial product and driver observation version gate change. Every untouched top-level callable is AST exact; whole inert forward/reverse patches reconstruct both full parent and current Sources.',
  'Review role grammar, strict JSON/parser and complete18-field subject excludingauthorization, exact seven-field Root maxone grant, required current30 and runner/observer subjects, marker/O_EXCL-before-Popen and freshness remain original. The selector is later bound to exact reviewed full capsule/declaration/worker/schedule row; no Source receipt grants arbitrary tasks.',
  'Original180 monotonic positive worker work/result/header/known exit and subsequent outer210 full raw/custody/resource/group/EOF terminal scope remain unchanged; observer225 is failure cleanup only. Separate Darwin worker+Native highwater sum<=1GiB, not live RSS; whole ordinary+forest+metadata128MiB, separate4MiB logs and9MiB outer reservations remain exact.',
  'Known wait4 reaping, process group/EOF closure, permanent absence-then-reappearance veto and no signaling after observed absence are retained. Outer/observer RAM and interpreter/pre-source prelude remain excluded/disclosed; no current process probe or runtime closure is fabricated by this Source review.',
  'All outputs, Source epoch/maps, storage/inverse/schema/selected search/helper, observation and full fresh Native transport custody joins remain unconditional original gates. A current local result is never promoted from failed/missing complete evidence; Root final saved-data adoption is separate.'
 ],
 limits=rc['LIMITS'],excluded_metadata_blockers=findings,
 limitations=['Source-only/no runtime, process launch, callback, test or actual. Inherited own lifecycle is not independently self-certified. Exact protected Python/OS trust and later prospective/Root authorization remain required.']))
negative=save('typed-prospective-plan-review-v1-negative.json',dict(**common,
 schema='owned-evidence-integration-prospective-plan-review-v1',prospective_review_passed=False,
 manifest=manifest,declaration=decl_pin,runtime_closure=closure_pin,subjects=subjects,
 required_subjects=[decl_pin,closure_pin]+[s['worker_plan'] for s in subjects],
 findings=findings,finding_count=2,mismatch_count=0,audit=audit,
 disposition='Retain offered V1 immutable. No executable/input/cap correction is indicated. Create metadata-only V2 closure/declaration/full four worker+once plans/manifest and rebind exact future subjects; no grant/actual/retry has been approved.',
 checks_scope='All four literal18-field false subjects/raw chains, exact schedule/product/current Source/input/cap matches and point-in-time absent actual/false observer paths were inspected; prose scope blockers prevent adoption. Source scopes are separate positive receipts.',
 no_actual_authorization=True))
out=save('current-coupling-review-handoff-v1.json',dict(schema='quantified-composer-current-coupling-peer-handoff-v1',
 components_Source_review=components,once_Source_review=once,prospective_negative=negative,audit=audit,
 source_only=True,scientific_calls=0,actual_execution_authorized=False,source_review_passed=True,
 prospective_review_passed=False,known_metadata_findings=2,tools_stopped_after_handoff=True))
print(json.dumps(dict(handoff=out,components=components,once=once,negative=negative,audit=audit,checks=len(checks)),sort_keys=True))
