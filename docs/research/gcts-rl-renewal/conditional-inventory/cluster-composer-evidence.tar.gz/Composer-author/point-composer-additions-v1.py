
def _composer_json(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,
                      allow_nan=False).encode('utf8')


class _ComposerMappingStop(Exception):
    def __init__(self,owner,reason):
        self.owner,self.reason=owner,reason
        super().__init__(reason)


def _map_composed_word(model,proposal,check):
    """Map the ordinary proposed word into actual current Model keys only."""
    owner=object();work=0
    receipt=dict(status='ABSTAIN',reason=None,work=0,work_limit=SUPPORT_PROJECTION_WORK_LIMIT,
                 proposal_sha256=proposal.get('proposal_sha256'),rows=[],members=[],
                 aggregate=None,logical_authority=False,candidate_pruning=False)
    def charge():
        nonlocal work
        check()
        if work>=SUPPORT_PROJECTION_WORK_LIMIT:
            raise _ComposerMappingStop(owner,'UNKNOWN_COMPOSER_MAPPING_WORK')
        work+=1;receipt['work']=work
    def abstain(reason):
        raise _ComposerMappingStop(owner,reason)
    try:
        charge()
        if proposal.get('schema')!=COMPOSER_SCHEMA or proposal.get('version')!=COMPOSER_VERSION:
            raise ValueError('current root composer protocol')
        if proposal['status']!='PROPOSED':abstain('COMPOSER_ABSTAINED')
        plan=proposal['proposal']
        if hashlib.sha256(_composer_json(plan)).hexdigest()!=proposal['proposal_sha256']:
            raise ValueError('full literal composed plan preimage')
        proof=plan['proof']
        if (len(proof)!=model.spec['length'] or plan['root_seed_rows']!=[] or
                _composer_json(proof[-1]['formula'])!=_composer_json(model.spec['target'])):
            raise ValueError('root-only full original word and final target')
        basis={_composer_json(f):i for i,f in enumerate(model.compiled['basis'])}
        members=[]
        for row,command in enumerate(proof):
            charge();skeleton=_literal(command,charge)
            if command['rule']=='block':
                if 'inputs' not in skeleton:abstain('MISSING_BLOCK_INPUTS')
                del skeleton['inputs']
            wanted=_composer_json(skeleton);hits=[]
            for k,actual in enumerate(model.domains[row]):
                charge()
                if _composer_json(actual)==wanted:hits.append(k)
            if len(hits)!=1:abstain('NO_UNIQUE_ACTUAL_COMMAND_SKELETON')
            k=hits[0];variant=0;mode=0;sources=[]
            if command['rule']=='mp':
                source=command['implication']
                if type(source)is not int or not 0<=source<row:abstain('MP_REFERENCE')
                variant=basis.get(_composer_json(proof[source]['formula']))
                if variant is None:abstain('MP_VARIANT')
            if command['rule']=='block':
                if command['name'] not in model.mode:abstain('UNAVAILABLE_INTERFACE')
                mode=model.mode[command['name']];sources=command['inputs']
                definition=next(d['definition'] for d in model.interfaces if d['name']==command['name'])
                if len(sources)!=len(definition['premises']):abstain('ORDERED_BLOCK_ARITY')
                for source,formula in zip(sources,definition['premises']):
                    charge()
                    if (type(source)is not int or not 0<=source<row or
                            _composer_json(proof[source]['formula'])!=_composer_json(formula)):
                        abstain('ORDERED_BLOCK_REFERENCE')
            keys=[(row,0,k,0),(row,1,k,variant)]
            for port in range(model.arity):
                charge()
                keys.append((row,2+port,mode,sources[port]+1 if port<len(sources) else 0))
            for key in keys:
                charge()
                if key not in model.metadata:abstain('MISSING_ACTUAL_GUARD_OR_INPUT_KEY')
            if (_composer_json(model.metadata[keys[0]]['command'])!=wanted or
                    _composer_json(model.metadata[keys[1]]['command'])!=wanted):
                abstain('ACTUAL_COMMAND_GUARD_MISMATCH')
            receipt['rows'].append(dict(row=row,command=_literal(command,charge),
                skeleton_index=k,guard_variant=variant,mode=mode,keys=_literal(keys,charge)))
            members.extend(keys)
        charge()
        packets=_complete_rows(model,members,charge)
        if len(packets)!=model.spec['length']:abstain('INCOMPLETE_ACTUAL_ROWS')
        # Fresh full union at root. This is point consistency, not a theorem.
        root=model.initial();charge();actual=aggregate(model,members,root);charge()
        if actual is None:abstain('ROOT_AGGREGATE_CONFLICT')
        receipt.update(status='MAPPED',members=_literal(members,charge),
                       aggregate=_literal(actual,charge),complete_rows=packets)
    except _ComposerMappingStop as stopped:
        if stopped.owner is not owner:raise
        receipt.update(status='ABSTAIN',reason=stopped.reason,members=[],aggregate=None)
    check()
    return receipt
