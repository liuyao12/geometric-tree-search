"""Direct chronological symbolic control for the fixed quantified row grammar.

No Model, point, marking, Graph, native query, solver or learned evaluator is
constructed here. Returned words/keys are candidates for the caller's common
whole-point/decode and fresh whole-native gates, never accepted proofs here.
"""
import hashlib
import itertools
import json
import math
import time

VERSION = 'quantified-symbolic-prefix-control-v3-root-composed-support'
RESULT_SCHEMA = 'quantified-symbolic-prefix-search-result-v1'
GRAMMAR_SCHEMA = 'quantified-symbolic-complete-row-grammar-v1'
COMPILER_VERSION = 'quantified-initial-binder-receptors-v1'
CATALOG_SCHEMA = 'quantified-initial-binder-syntax-catalog-v1'
TERM_POLICY = 'TARGET_FREE_SUBTERMS_UNION_ALL_INITIAL_BINDER_VARIABLES_V1'
ROOT_CONTEXT = 'CLOSED_THEORY_AXIOMS_NO_OPEN_ROOT_ASSUMPTIONS'
STRATEGIES = ('NOVEL_BACKWARD_PRIORITY_DFS_V1', 'LEXICAL_PREFIX_DFS_V1',
              'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1', 'ROOT_AND_OR_CLUSTER_COMPOSER_V1')
SUPPORT_VERSION = 'receptor-and-support-ordering-v1'
SUPPORT_WINDOW = 64
SUPPORT_WORK_LIMIT = 200000




# New explicit consumer gate. The driver separately authenticates every full
# registry packet. This predicate is not an independent mathematical checker.
SCHEMA_ADMISSION_GATE_VERSION = 'explicit-complete-schema-consumer-gate-v1'
def _inventory_admission_ready(inventory):
    if inventory.get('status') == 'native_accepted':
        return True  # historical path, unchanged
    c = inventory.get('certification')
    return (inventory.get('status') == 'schema_admitted' and type(c) is dict
            and c.get('schema') == 'schema-then-native-inventory-certification-v1'
            and c.get('version') == 'inventory-schema-then-native-v1'
            and c.get('mode') == 'schema_then_native'
            and c.get('complete') is True and c.get('Model_permission') is True
            and c.get('native_accepted') is False
            and c.get('fresh_Native_target_proof_accepted') is False
            and c.get('final_whole_Native_required') is True)

class SymbolicDataError(ValueError):
    pass


class _Stop(Exception):
    def __init__(self, owner, reason):
        self.owner = owner
        self.reason = reason
        super().__init__(reason)


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def _owned(value):
    return json.loads(_json(value))


def _sha(value):
    return hashlib.sha256(_json(value)).hexdigest()


class _Budget:
    def __init__(self, attempts, seconds):
        # The first search clock precedes input copying and skeleton preparation.
        self.began = time.perf_counter()
        if type(attempts) is not int or not 0 <= attempts <= 5000:
            raise SymbolicDataError('prefix extensions must be an integer in0..5000')
        if type(seconds) not in (int, float) or not math.isfinite(seconds) or not 0 <= seconds <= 30:
            raise SymbolicDataError('search seconds must be finite in0..30')
        self.attempts = attempts
        self.seconds = seconds
        self.end = self.began + seconds
        self.extensions = 0
        self.last = self.began

    def check(self):
        now = time.perf_counter()
        if now < self.last:
            raise SymbolicDataError('nonmonotonic search clock')
        self.last = now
        if now >= self.end:
            raise _Stop(self, 'search_wall_budget')
        return now

    def extend(self):
        self.check()
        if self.extensions >= self.attempts:
            raise _Stop(self, 'prefix_extension_budget')
        self.extensions += 1


def _intake(spec, compiled, inventory, compiler, budget):
    budget.check()
    if spec['length'] != 12 or spec.get('instantiation_rounds') != 2:
        raise SymbolicDataError('this frozen comparison requires twelve rows and two syntax rounds')
    if spec.get('assumptions') or spec.get('blocks') or spec['theory']['schemas']:
        raise SymbolicDataError('no supplied root assumptions, blocks or theory schemas')
    catalog = compiled['catalog']
    if (catalog.get('schema') != CATALOG_SCHEMA or
            catalog.get('producer_version') != COMPILER_VERSION or
            catalog.get('term_policy') != TERM_POLICY or
            catalog.get('root_context') != ROOT_CONTEXT or catalog.get('rounds') != 2):
        raise SymbolicDataError('wrong quantified catalog or root scope')
    if getattr(compiler, 'VERSION', None) != COMPILER_VERSION or not callable(getattr(compiler, 'domains', None)):
        raise SymbolicDataError('current pinned compiler.domains required')
    if compiled['status'] != 'complete' or not _inventory_admission_ready(inventory):
        return False
    if _json(compiled['basis']) != _json(catalog['basis']) or _json(compiled['variables']) != _json(catalog['variables']):
        raise SymbolicDataError('complete compiler catalog/basis linkage')
    basis_keys = [_json(f) for f in compiled['basis']]
    if len(set(basis_keys)) != len(basis_keys):
        raise SymbolicDataError('basis must have unique literal formulas')
    definitions = inventory['definitions']
    names = [d['name'] for d in definitions]
    if len(set(names)) != len(names):
        raise SymbolicDataError('duplicate definition name')
    by_name = dict(zip(names, definitions))
    interfaces = inventory['interfaces']
    if len(set(interfaces)) != len(interfaces) or any(n not in by_name for n in interfaces):
        raise SymbolicDataError('unique registered exported interfaces required')
    native = inventory['native_blocks']
    if [_json(d['definition']) for d in definitions] != [_json(d) for d in native]:
        raise SymbolicDataError('full ground metadata/native definition linkage')
    budget.check()
    return True


def _backward_distances(basis, variables, interfaces, budget):
    """Uniform dependency distances for ordering only, not a proof or pruning."""
    dependencies = {_json(f): set() for f in basis}
    variable_set = set(variables)
    for formula in basis:
        budget.check()
        key = _json(formula)
        if formula[0] == 'all' and formula[1] in variable_set:
            dependencies[key].add(_json(formula[2]))
        if formula[0] == 'imp':
            # A later MP deriving its consequent may need both earlier formulas.
            dependencies.setdefault(_json(formula[2]), set()).update((_json(formula[1]), key))
    for definition in interfaces:
        budget.check()
        d = definition['definition']
        dependencies.setdefault(_json(d['conclusion']), set()).update(_json(f) for f in d['premises'])
    return dependencies


def _distances_from_target(target, dependencies, budget):
    distances = {_json(target): 0}
    queue = [_json(target)]
    cursor = 0
    while cursor < len(queue):
        budget.check()
        parent = queue[cursor]
        cursor += 1
        for child in sorted(dependencies.get(parent, ())):
            if child not in distances:
                distances[child] = distances[parent] + 1
                queue.append(child)
    return distances


def _primitive_guard(command, prefix, basis_index, tautologies, schemes):
    """Exactly the existing Model guard equations, no native rule extension."""
    rule = command['rule']
    formula = command['formula']
    if rule == 'mp':
        antecedent, implication = command['antecedent'], command['implication']
        if any(type(i) is not int or not 0 <= i < len(prefix) for i in (antecedent, implication)):
            return None
        actual = prefix[implication]['formula']
        variant = basis_index.get(_json(actual))
        if (variant is not None and actual[0] == 'imp' and
                actual[1] == prefix[antecedent]['formula'] and actual[2] == formula):
            return variant
        return None
    if rule == 'generalize':
        source = command['source']
        if (type(source) is int and 0 <= source < len(prefix) and
                formula[0] == 'all' and formula[1] == command['variable'] and
                prefix[source]['formula'] == formula[2]):
            return 0
        return None
    if rule == 'refl':
        return 0 if formula[0] == 'eq' and formula[1] == formula[2] else None
    if rule == 'tautology':
        return 0 if _json(formula) in tautologies else None
    # The caller separately supplies the exact named-axiom lookup.
    if rule == 'axiom':
        raise SymbolicDataError('axiom guard requires the declaration')
    # In the frozen compiler these are UI/EQ zero-read implication licences.
    # No universal/equality operand is promoted to an available proof fact.
    return 0 if _json(command) in schemes else None


def _key_projection(chosen, arity, budget):
    keys = []
    for item in chosen:
        budget.check()
        row, k, variant, mode = item['row'], item['skeleton_index'], item['guard_variant'], item['mode']
        keys.extend(([row, 0, k, 0], [row, 1, k, variant]))
        if item['command']['rule'] == 'block':
            sources = item['command']['inputs']
            for port in range(arity):
                keys.append([row, 2 + port, mode, sources[port] + 1 if port < len(sources) else 0])
        else:
            keys.extend([row, 2 + port, 0, 0] for port in range(arity))
    if len({tuple(k) for k in keys}) != len(keys):
        raise SymbolicDataError('duplicate projected key')
    return keys


def search_symbolic(*, spec, compiled, inventory, compiler, attempts=5000,
                    seconds=30, strategy='NOVEL_BACKWARD_PRIORITY_DFS_V1',
                    support_ordering=None):
    """Bounded conventional search; Root must check returned keys and whole proof.

    Complete input acquisition is a caller-native admission obligation, exactly
    as for the point Model. Caller Source custody runs before/after this stage.
    Only the private cooperative budget is caught. Compiler/caller/data errors
    propagate; normally returned incomplete acquisition is UNKNOWN, never pruning.
    """
    budget = _Budget(attempts, seconds)
    if strategy not in STRATEGIES:
        raise SymbolicDataError('undeclared symbolic strategy')
    if strategy in ('ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1','ROOT_AND_OR_CLUSTER_COMPOSER_V1') and (
            getattr(support_ordering, 'VERSION', None) != SUPPORT_VERSION or
            getattr(support_ordering, 'STRATEGY', None) != 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1' or
            not callable(getattr(support_ordering, 'build_support_graph', None)) or
            not callable(getattr(support_ordering, 'rank_support_options', None))):
        raise SymbolicDataError('current injected support ordering required')
    if strategy=='ROOT_AND_OR_CLUSTER_COMPOSER_V1' and (
            getattr(support_ordering,'COMPOSER_VERSION',None)!='root-and-or-cluster-composer-v1' or
            not callable(getattr(support_ordering,'compose_support_cluster',None))):
        raise SymbolicDataError('current rootcomposer required')
    originals = (spec, compiled, inventory)
    frozen_inputs = _json(list(originals))
    spec, compiled, inventory = _owned(list(originals))
    metrics = dict(prefix_nodes=0, prefix_extensions=0, backtracks=0,
                   skeleton_tests=0, primitive_guard_rejections=0,
                   unavailable_block_skeletons=0, block_port_tuples=0,
                   dead_prefixes=0)
    grammar = dict(schema=GRAMMAR_SCHEMA, preparation_complete=False,
                   spec=spec, compiler={k: v for k, v in compiled.items() if k != 'seconds'},
                   inventory={k: inventory[k] for k in ('definitions', 'interfaces', 'native_blocks')},
                   rows=[], interface_order=[], mode_ids={}, required_interface_arity=None,
                   scope='Exact full sorted row skeletons before guard filtering. Ordered block sources and native primitive reads are selected from actual earlier rows; no multiplicity/padding quotient.')
    events = []
    path = []
    chosen = []
    found = None
    interrupted_prefix = None
    status = 'unknown_search_budget'
    reason = None
    preparation_completed = None
    grammar_sha = None
    distances_record = []
    support_record = None
    if strategy in ('ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1','ROOT_AND_OR_CLUSTER_COMPOSER_V1'):
        support_record = dict(version=SUPPORT_VERSION, graph=None, ranking_calls=[],
                              window_size=SUPPORT_WINDOW, work_limit=SUPPORT_WORK_LIMIT,
                              metrics=dict(prefetched_candidates=0, complete_windows=0,
                                           scored_windows=0, fallback_windows=0),
                              scope='Bounded stable windows over the unchanged complete candidate iterator; no candidate/ref/word/padding quotient or pruning. Only completed windows are ranked. Partial prefetch is retained on an owned search stop.')
    try:
        if not _intake(spec, compiled, inventory, compiler, budget):
            status = 'unknown_incomplete_acquisition'
            reason = 'full compiler and full registry admission required before search'
        else:
            definitions = {d['name']: d for d in inventory['definitions']}
            interfaces = [definitions[n] for n in inventory['interfaces']]
            modes = {d['name']: i + 1 for i, d in enumerate(interfaces)}
            arity = max([len(d['definition']['premises']) for d in interfaces] + [0])
            grammar['interface_order'] = list(inventory['interfaces'])
            grammar['mode_ids'] = modes
            grammar['required_interface_arity'] = arity
            for row in range(spec['length']):
                budget.check()
                rows = compiler.domains(spec, compiled['catalog'], row)
                formulas = [spec['target']] if row + 1 == spec['length'] else compiled['basis']
                rows += [dict(rule='block', formula=f, name=d['name']) for f in formulas for d in interfaces]
                rows.sort(key=lambda c: (c['rule'], _json(c['formula']), _json(c)))
                if len({_json(c) for c in rows}) != len(rows):
                    raise SymbolicDataError('duplicate full sorted skeleton')
                grammar['rows'].append(rows)
            basis_index = {_json(f): i for i, f in enumerate(compiled['basis'])}
            tautologies = {_json(f) for f in compiled['tautologies']}
            schemes = {_json(c) for c in compiled['admitted_schemes']}
            dependencies = _backward_distances(compiled['basis'], compiled['variables'], interfaces, budget)
            distances = _distances_from_target(spec['target'], dependencies, budget)
            distances_record = [dict(formula=json.loads(k), distance=v) for k, v in sorted(distances.items())]
            if support_record is not None:
                support_record['graph'] = support_ordering.build_support_graph(
                    spec=spec, compiled=compiled, inventory=inventory,
                    check=budget.check, work_limit=SUPPORT_WORK_LIMIT)
            if strategy=='ROOT_AND_OR_CLUSTER_COMPOSER_V1':
                budget.check()
                support_record['composer']=support_ordering.compose_support_cluster(
                    graph=support_record['graph'],check=budget.check,work_limit=SUPPORT_WORK_LIMIT)
                budget.check();support_record['composed_row_preferences']=[]
                support_record['composer_scope']='Same root-only EMPTY-seed proposal as point lane. On abstention use unchanged AND-support windows, not lexical fallback.'
            grammar['preparation_complete'] = True
            grammar_sha = _sha(grammar)
            preparation_completed = budget.check()

            def candidates(row):
                available = {}
                for source, command in enumerate(path):
                    available.setdefault(_json(command['formula']), []).append(source)
                indices = list(range(len(grammar['rows'][row])))
                if strategy in ('NOVEL_BACKWARD_PRIORITY_DFS_V1',
                                 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1','ROOT_AND_OR_CLUSTER_COMPOSER_V1'):
                    indices.sort(key=lambda k: (
                        _json(grammar['rows'][row][k]['formula']) in available,
                        distances.get(_json(grammar['rows'][row][k]['formula']), len(distances) + 1), k))
                for k in indices:
                    budget.check()
                    metrics['skeleton_tests'] += 1
                    command = grammar['rows'][row][k]
                    rule = command['rule']
                    if rule == 'block':
                        definition = definitions[command['name']]['definition']
                        choices = [available.get(_json(f), []) for f in definition['premises']]
                        if command['formula'] != definition['conclusion'] or any(not c for c in choices):
                            metrics['unavailable_block_skeletons'] += 1
                            continue
                        for sources in itertools.product(*choices):
                            budget.check()
                            metrics['block_port_tuples'] += 1
                            actual = _owned(command)
                            actual['inputs'] = list(sources)
                            yield dict(row=row, skeleton_index=k, guard_variant=0,
                                       mode=modes[command['name']], command=actual)
                    else:
                        if rule == 'axiom':
                            variant = 0 if spec['theory']['axioms'][command['name']] == command['formula'] else None
                        else:
                            variant = _primitive_guard(command, path, basis_index, tautologies, schemes)
                        if variant is None:
                            metrics['primitive_guard_rejections'] += 1
                            continue
                        yield dict(row=row, skeleton_index=k, guard_variant=variant,
                                   mode=0, command=_owned(command))

            def complete_row_packet(command, row, source_commands, provenance):
                rule = command['rule']
                if rule == 'block':
                    definition = definitions[command['name']]['definition']
                    requirements = [[source, formula] for source, formula in
                                    zip(command['inputs'], definition['premises'])]
                    if len(command['inputs']) != len(definition['premises']):
                        raise SymbolicDataError('full ordered block port tuple required')
                elif rule == 'mp':
                    requirements = [[command['antecedent'], source_commands[command['antecedent']]['formula']],
                                    [command['implication'], source_commands[command['implication']]['formula']]]
                elif rule == 'generalize':
                    requirements = [[command['source'], command['formula'][2]]]
                else:
                    requirements = []
                return dict(row=row, formula=_owned(command['formula']),
                            requirements=_owned(requirements), provenance=_owned(provenance))

            def ranked_candidates(row):
                iterator = candidates(row)
                if support_record is None:
                    yield from iterator
                    return
                # Enumeration and every prefetch/scoring check use the same
                # original absolute budget; there is no scoring-clock reset.
                known_rows = [complete_row_packet(command, source, path,
                                                  dict(chosen_candidate=chosen[source]))
                              for source, command in enumerate(path)]
                while True:
                    window = []
                    record = dict(row=row, complete_window=False,
                                  source_iterator_exhausted=False,
                                  candidates=window, ranking=None)
                    support_record['ranking_calls'].append(record)
                    for unused in range(SUPPORT_WINDOW):
                        budget.check()
                        try:
                            candidate = next(iterator)
                        except StopIteration:
                            record['source_iterator_exhausted'] = True
                            break
                        window.append(candidate)
                        support_record['metrics']['prefetched_candidates'] += 1
                    record['complete_window'] = True
                    if not window:
                        # Natural end is recorded; it is never replaced by a
                        # shortlist, scoring failure or yielded-candidate cap.
                        return
                    support_record['metrics']['complete_windows'] += 1
                    options = [dict(option_id=dict(window_option=index,
                                                    skeleton_index=candidate['skeleton_index'],
                                                    guard_variant=candidate['guard_variant'],
                                                    mode=candidate['mode']),
                                    rows=[complete_row_packet(candidate['command'], row, path,
                                                              dict(candidate=candidate))])
                               for index, candidate in enumerate(window)]
                    receipt = support_ordering.rank_support_options(
                        graph=support_record['graph'], known_rows=known_rows,
                        options=options, check=budget.check,
                        work_limit=SUPPORT_WORK_LIMIT)
                    record['ranking'] = receipt
                    order = receipt['order']
                    if sorted(order) != list(range(len(window))):
                        raise SymbolicDataError('support order changed candidate multiplicity')
                    label = 'scored_windows' if receipt['status'] == 'SCORED' else 'fallback_windows'
                    support_record['metrics'][label] += 1
                    for index in order:
                        budget.check()
                        yield window[index]
                    if record['source_iterator_exhausted']:
                        return

            def composed_candidates(row):
                iterator=ranked_candidates(row)
                if strategy!='ROOT_AND_OR_CLUSTER_COMPOSER_V1':
                    yield from iterator
                    return
                proposal=support_record['composer']
                observation=dict(row=row,status='ABSTAIN',reason=None,promoted_candidate=None,
                    proposal_sha256=proposal.get('proposal_sha256'),original_match_count=0,
                    original_iterator_exhausted=False,exact_membership_checked=False,
                    scope='One exact fullidentity candidate moved tofront; its ONE later original occurrence is skipped. Every other ref/tuple/padding occurrence remains.')
                support_record['composed_row_preferences'].append(observation)
                preferred=None
                if proposal['status']!='PROPOSED':
                    observation['reason']='COMPOSER_ABSTAINED'
                else:
                    plan=proposal['proposal'];proof=plan['proof']
                    if (proposal.get('version')!='root-and-or-cluster-composer-v1' or
                            _sha(plan)!=proposal['proposal_sha256'] or plan['root_seed_rows']!=[] or
                            len(proof)!=spec['length']):
                        raise SymbolicDataError('current complete root-only composed preimage')
                    if _json(path)!=_json(proof[:row]):
                        observation['reason']='CURRENT_PREFIX_DIFFERS_FROM_ROOT_PLAN'
                    else:
                        command=_owned(proof[row]);skeleton=_owned(command)
                        if command['rule']=='block':
                            del skeleton['inputs']
                        hits=[]
                        for k,actual in enumerate(grammar['rows'][row]):
                            budget.check()
                            if _json(actual)==_json(skeleton):hits.append(k)
                        if len(hits)!=1:
                            observation['reason']='NO_UNIQUE_ACTUAL_SKELETON'
                        else:
                            variant=None;mode=0;rule=command['rule']
                            if rule=='block':
                                definition=definitions[command['name']]['definition']
                                sources=command['inputs']
                                if (len(sources)==len(definition['premises']) and
                                        _json(command['formula'])==_json(definition['conclusion']) and
                                        all(type(source)is int and 0<=source<row and
                                            _json(path[source]['formula'])==_json(formula)
                                            for source,formula in zip(sources,definition['premises']))):
                                    variant=0;mode=modes[command['name']]
                            elif rule=='axiom':
                                variant=0 if _json(spec['theory']['axioms'][command['name']])==_json(command['formula']) else None
                            else:
                                variant=_primitive_guard(command,path,basis_index,tautologies,schemes)
                            if variant is None:
                                observation['reason']='ACTUAL_GUARD_OR_ORDERED_PORTS_UNAVAILABLE'
                            else:
                                preferred=dict(row=row,skeleton_index=hits[0],guard_variant=variant,
                                               mode=mode,command=command)
                                observation.update(status='PROMOTED',promoted_candidate=_owned(preferred),
                                    exact_membership_checked=True,reason=None)
                if preferred is None:
                    yield from iterator  # exact existing AND-support fallback
                    observation['original_iterator_exhausted']=True
                    return
                wanted=_json(preferred)
                budget.check()
                yield preferred
                # This may not resume if the preferred subtree wins/stops. In
                # that case exact grammar+guard membership above, not imagined
                # iterator exhaustion or a skipped-occurrence claim, is retained.
                for candidate in iterator:
                    budget.check()
                    if _json(candidate)==wanted:
                        observation['original_match_count']+=1
                        if observation['original_match_count']!=1:
                            raise SymbolicDataError('duplicate full candidate identity')
                        continue
                    yield candidate
                observation['original_iterator_exhausted']=True
                if observation['original_match_count']!=1:
                    raise SymbolicDataError('promoted member missing on complete original enumeration')

            def visit(parent_event):
                nonlocal found, interrupted_prefix
                budget.check()
                metrics['prefix_nodes'] += 1
                if len(path) == spec['length']:
                    if path[-1]['formula'] != spec['target']:
                        raise SymbolicDataError('final assertion changed')
                    found = dict(stage='WORD_COMPLETE', proof=_owned(path), rows=_owned(chosen))
                    return True
                count = 0
                try:
                    for candidate in (composed_candidates(len(path)) if strategy=='ROOT_AND_OR_CLUSTER_COMPOSER_V1' else ranked_candidates(len(path))):
                        budget.extend()
                        metrics['prefix_extensions'] = budget.extensions
                        count += 1
                        event = dict(id=len(events), parent=parent_event, row=len(path),
                                     skeleton_index=candidate['skeleton_index'],
                                     guard_variant=candidate['guard_variant'], mode=candidate['mode'],
                                     command=_owned(candidate['command']), action='descend')
                        events.append(event)
                        path.append(candidate['command'])
                        chosen.append(candidate)
                        try:
                            if visit(event['id']):
                                event['action'] = 'winning_candidate_path'
                                return True
                            event['action'] = 'backtracked'
                            metrics['backtracks'] += 1
                        except _Stop as stopped:
                            if stopped.owner is not budget:
                                raise
                            event['action'] = 'budget_cutoff'
                            event['reason'] = stopped.reason
                            if interrupted_prefix is None:
                                interrupted_prefix = dict(proof=_owned(path), rows=_owned(chosen))
                            raise
                        finally:
                            chosen.pop()
                            path.pop()
                    if count == 0:
                        metrics['dead_prefixes'] += 1
                    return False
                except _Stop as stopped:
                    if stopped.owner is budget and interrupted_prefix is None:
                        interrupted_prefix = dict(proof=_owned(path), rows=_owned(chosen))
                    raise

            complete = visit(None)
            status = 'symbolic_proof_candidate' if complete else 'exhausted_finite_symbolic_grammar'
            if found is not None:
                found['placements'] = _key_projection(found['rows'], arity, budget)
                found['stage'] = 'KEY_PROJECTION_COMPLETE'
            budget.check()
    except _Stop as stopped:
        if stopped.owner is not budget:
            raise
        status = 'unknown_search_budget'
        reason = stopped.reason
    # Only completed literal data/custody observations follow a normal budget stop.
    # A thrown external/compiler/data error does not get converted into UNKNOWN.
    if path or chosen:
        raise SymbolicDataError('prefix stack not restored')
    if _json(list(originals)) != frozen_inputs:
        raise SymbolicDataError('caller input packets changed during search')
    elapsed = time.perf_counter() - budget.began
    if elapsed >= seconds and status != 'unknown_incomplete_acquisition':
        status = 'unknown_search_budget'
        reason = reason or 'search_wall_budget_at_return'
    accepted_candidate = found if status == 'symbolic_proof_candidate' else None
    return dict(schema=RESULT_SCHEMA, version=VERSION, status=status, reason=reason,
                strategy=strategy, proof=accepted_candidate['proof'] if accepted_candidate else None,
                placements=accepted_candidate['placements'] if accepted_candidate else [],
                candidate_rows=accepted_candidate['rows'] if accepted_candidate else [],
                completed_candidate_before_budget_stop=found if found is not None and accepted_candidate is None else None,
                interrupted_prefix=interrupted_prefix,
                grammar=grammar, grammar_sha256=grammar_sha,
                backward_distances=distances_record, events=events, metrics=metrics,
                support_ordering=support_record,
                seconds=elapsed,
                preparation_seconds=preparation_completed - budget.began if preparation_completed is not None else None,
                enumeration_and_return_seconds=elapsed - (preparation_completed - budget.began) if preparation_completed is not None else None,
                limits=dict(prefix_extensions=attempts, seconds=seconds),
                root_path_restored=True,
                complete_exhaustion=status == 'exhausted_finite_symbolic_grammar',
                native_proof_accepted=False, point_region_verified=False,
                scientific_acceptance=False,
                scope='Bounded conventional chronological symbolic control. Novel-output/backward distance and optional positive-cost AND support are ordering only: no repeated formula, reference tuple, word padding or primitive fallback is pruned. Complete-word correspondence is conditional on the frozen compiler/model inputs; no reference-GCTS scheduler or trace equivalence. Root must verify projected keys against the common full point model, decode exact word and obtain fresh whole native acceptance. Common point-model setup and post-check costs remain charged; no standalone no-point-encoding or dedicated-prover speed claim.')
