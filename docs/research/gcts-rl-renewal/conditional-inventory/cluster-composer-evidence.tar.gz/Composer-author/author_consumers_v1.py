"""Raw Source-only successor writer; never imports or calls the consumers."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

LIB=Path('/private/tmp/gcts-cluster-composer-library-20261019')
POINT=Path('/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py')
SYMBOLIC=Path('/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_symbolic_control_v3.py')


def replace(text,old,new,count=1):
    if text.count(old)!=count:raise ValueError('inert exact replacement count '+old[:80])
    return text.replace(old,new)


def pin(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    p0=POINT.read_text();p=p0
    p=replace(p,"import collections,random,time","import collections,random,time\nimport hashlib,json")
    p=replace(p,"    build_support_graph, rank_support_options)","    build_support_graph, rank_support_options,\n    COMPOSER_VERSION, COMPOSER_SCHEMA, compose_support_cluster)")
    p=replace(p,"VERSION = 'semantic-inventory-search-v2-shared-and-support'","VERSION = 'semantic-inventory-search-v3-root-composed-support'")
    p=replace(p,"def search(model,",(LIB/'point-composer-additions-v1.py').read_text()+"\n\ndef search(model,")
    p=replace(p,"support_ordering not in ('legacy','and_support')","support_ordering not in ('legacy','and_support','composed_support')")
    p=replace(p,"support_ordering=='and_support' and (mode!='fixed' or stochastic)","support_ordering in ('and_support','composed_support') and (mode!='fixed' or stochastic)")
    p=replace(p,"    if mode in ('learned','no-family')", "    if support_ordering=='composed_support' and (type(proposal_limit)is not int or not 1<=proposal_limit<=24):raise ValueError('composer one reserved rowproposal slot within1..24')\n    if mode in ('learned','no-family')")
    p=replace(p,"    support_graph=None;support_stopped=False","    support_graph=None;support_stopped=False;composer_mapping=None")
    p=replace(p,"if support_ordering=='and_support':","if support_ordering in ('and_support','composed_support'):",count=2)
    p=replace(p,"            metrics['support_graph_work']+=support_graph['counts']['work']", """            metrics['support_graph_work']+=support_graph['counts']['work']
            if support_ordering=='composed_support':
                if COMPOSER_VERSION!='root-and-or-cluster-composer-v1':raise ValueError('current rootcomposer')
                support_check()
                composed=compose_support_cluster(graph=support_graph,check=support_check,work_limit=SUPPORT_WORK_LIMIT)
                support_check();support_metadata['composer']=composed
                metrics['composer_work']+=composed['counts']['work']
                composer_mapping=_map_composed_word(model,composed,support_check)
                support_metadata['composer_mapping']=composer_mapping
                metrics['composer_mapping_work']+=composer_mapping['work']
                support_metadata['scope']='Root-only EMPTY-seed composed word advice. A usable fullactualword reserves1of24 rowproposal slots; arbitrarysample/defer and completebasefallback remain. Abstention uses unchanged AND-support ordering.'""")
    p=replace(p,"            stage=time.perf_counter();items,work=join(state,g,p,proposal_limit,proposal_checks)","""            stage=time.perf_counter();composed_item=None
            if support_ordering=='composed_support' and composer_mapping is not None and composer_mapping['status']=='MAPPED':
                try:
                    support_check();members=[tuple(k) for k in composer_mapping['members']]
                    actual=aggregate(model,members,state);support_check()
                    metrics['composer_branch_aggregate_checks']+=1
                    eligible=[] if actual is None else [k for k in actual['pending'] if k in g.domains.get(p,set())]
                    tree['composed_review']=dict(proposal_sha256=composer_mapping['proposal_sha256'],
                        status='ELIGIBLE' if eligible else 'ABSTAIN_INCOMPATIBLE_OR_NOT_INCIDENT',
                        aggregate=actual,eligible=eligible,logical_authority=False)
                    if eligible:
                        composed_item=actual;composed_item.update(kind='composed',level=0,
                            proposal_sha256=composer_mapping['proposal_sha256'])
                except _SupportDeadline:
                    metrics['support_deadline_stops']+=1;tree['cutoff']='composer_projection_deadline';return None,tree
            if composed_item is None:
                items,work=join(state,g,p,proposal_limit,proposal_checks)
            else:
                items,work=join(state,g,p,proposal_limit-1,proposal_checks)
                metrics['composer_reserved_row_slots']+=1""")
    p=replace(p,"            event.update(id=len(events),point=p,chosen=list(state.order),items=items,weights=scoring);", """            if composed_item is not None and not support_deadline:
                before=event['index'];slot=len(items);items.append(composed_item)
                feature=vector(composed_item,model,state,g)
                event['features'].append(feature);event['scores'].append(sum(w*x for w,x in zip(scoring,feature)))
                event['probabilities'].append(0.)
                event['composed_preference']=dict(before_AND_support_index=before,selected_index=slot,
                    proposal_sha256=composed_item['proposal_sha256'],rowproposal_slot=1,
                    probability_scope='Original Join policy probabilities retained; appended zero is not a sampling probability. This is an explicit deterministic composed override.',
                    kind='composed',logical_authority=False)
                event['index']=slot;item=composed_item;metrics['composed_hints_preferred']+=1
            event.update(id=len(events),point=p,chosen=list(state.order),items=items,weights=scoring);""")
    s0=SYMBOLIC.read_text();s=s0
    s=replace(s,"VERSION = 'quantified-symbolic-prefix-control-v2-and-support-ordering'","VERSION = 'quantified-symbolic-prefix-control-v3-root-composed-support'")
    s=replace(s,"STRATEGIES = ('NOVEL_BACKWARD_PRIORITY_DFS_V1', 'LEXICAL_PREFIX_DFS_V1',\n              'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1')","STRATEGIES = ('NOVEL_BACKWARD_PRIORITY_DFS_V1', 'LEXICAL_PREFIX_DFS_V1',\n              'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1', 'ROOT_AND_OR_CLUSTER_COMPOSER_V1')")
    s=replace(s,"if strategy == 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1'", "if strategy in ('ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1','ROOT_AND_OR_CLUSTER_COMPOSER_V1')",count=2)
    s=replace(s,"getattr(support_ordering, 'STRATEGY', None) != strategy", "getattr(support_ordering, 'STRATEGY', None) != 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1'")
    s=replace(s,"    originals = (spec, compiled, inventory)","""    if strategy=='ROOT_AND_OR_CLUSTER_COMPOSER_V1' and (
            getattr(support_ordering,'COMPOSER_VERSION',None)!='root-and-or-cluster-composer-v1' or
            not callable(getattr(support_ordering,'compose_support_cluster',None))):
        raise SymbolicDataError('current rootcomposer required')
    originals = (spec, compiled, inventory)""")
    s=replace(s,"'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1'):\n                    indices.sort", "'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1','ROOT_AND_OR_CLUSTER_COMPOSER_V1'):\n                    indices.sort")
    s=replace(s,"            grammar['preparation_complete'] = True", """            if strategy=='ROOT_AND_OR_CLUSTER_COMPOSER_V1':
                budget.check()
                support_record['composer']=support_ordering.compose_support_cluster(
                    graph=support_record['graph'],check=budget.check,work_limit=SUPPORT_WORK_LIMIT)
                budget.check();support_record['composed_row_preferences']=[]
                support_record['composer_scope']='Same root-only EMPTY-seed proposal as point lane. On abstention use unchanged AND-support windows, not lexical fallback.'
            grammar['preparation_complete'] = True""")
    anchor="            def visit(parent_event):\n"
    wrapper="""            def composed_candidates(row):
                iterator=ranked_candidates(row)
                if strategy!='ROOT_AND_OR_CLUSTER_COMPOSER_V1':
                    yield from iterator
                    return
                proposal=support_record['composer']
                observation=dict(row=row,status='ABSTAIN',reason=None,promoted_candidate=None,
                    proposal_sha256=proposal.get('proposal_sha256'),original_match_count=0,
                    original_iterator_exhausted=False,exact_membership_checked=False,
                    scope='One exact fullidentity candidate moved tofront; its ONE later original occurrence is skipped. Every other ref/tuple/padding occurrence remains.')
                support_record['composed_row_preferences'].append(observation)
                preferred=None
                if proposal['status']!='PROPOSED':
                    observation['reason']='COMPOSER_ABSTAINED'
                else:
                    plan=proposal['proposal'];proof=plan['proof']
                    if (proposal.get('version')!='root-and-or-cluster-composer-v1' or
                            _sha(plan)!=proposal['proposal_sha256'] or plan['root_seed_rows']!=[] or
                            len(proof)!=spec['length']):
                        raise SymbolicDataError('current complete root-only composed preimage')
                    if _json(path)!=_json(proof[:row]):
                        observation['reason']='CURRENT_PREFIX_DIFFERS_FROM_ROOT_PLAN'
                    else:
                        command=_owned(proof[row]);skeleton=_owned(command)
                        if command['rule']=='block':
                            del skeleton['inputs']
                        hits=[]
                        for k,actual in enumerate(grammar['rows'][row]):
                            budget.check()
                            if _json(actual)==_json(skeleton):hits.append(k)
                        if len(hits)!=1:
                            observation['reason']='NO_UNIQUE_ACTUAL_SKELETON'
                        else:
                            variant=None;mode=0;rule=command['rule']
                            if rule=='block':
                                definition=definitions[command['name']]['definition']
                                sources=command['inputs']
                                if (len(sources)==len(definition['premises']) and
                                        _json(command['formula'])==_json(definition['conclusion']) and
                                        all(type(source)is int and 0<=source<row and
                                            _json(path[source]['formula'])==_json(formula)
                                            for source,formula in zip(sources,definition['premises']))):
                                    variant=0;mode=modes[command['name']]
                            elif rule=='axiom':
                                variant=0 if _json(spec['theory']['axioms'][command['name']])==_json(command['formula']) else None
                            else:
                                variant=_primitive_guard(command,path,basis_index,tautologies,schemes)
                            if variant is None:
                                observation['reason']='ACTUAL_GUARD_OR_ORDERED_PORTS_UNAVAILABLE'
                            else:
                                preferred=dict(row=row,skeleton_index=hits[0],guard_variant=variant,
                                               mode=mode,command=command)
                                observation.update(status='PROMOTED',promoted_candidate=_owned(preferred),
                                    exact_membership_checked=True,reason=None)
                if preferred is None:
                    yield from iterator  # exact existing AND-support fallback
                    observation['original_iterator_exhausted']=True
                    return
                wanted=_json(preferred)
                budget.check()
                yield preferred
                # This may not resume if the preferred subtree wins/stops. In
                # that case exact grammar+guard membership above, not imagined
                # iterator exhaustion or a skipped-occurrence claim, is retained.
                for candidate in iterator:
                    budget.check()
                    if _json(candidate)==wanted:
                        observation['original_match_count']+=1
                        if observation['original_match_count']!=1:
                            raise SymbolicDataError('duplicate full candidate identity')
                        continue
                    yield candidate
                observation['original_iterator_exhausted']=True
                if observation['original_match_count']!=1:
                    raise SymbolicDataError('promoted member missing on complete original enumeration')

"""
    s=replace(s,anchor,wrapper+anchor)
    s=replace(s,"for candidate in ranked_candidates(len(path)):","for candidate in (composed_candidates(len(path)) if strategy=='ROOT_AND_OR_CLUSTER_COMPOSER_V1' else ranked_candidates(len(path))):")
    for label,path,old,new in (
            ('point',LIB/'semantic_inventory_search_v3.py',p0,p),
            ('symbolic',LIB/'schema_admission_symbolic_control_v4.py',s0,s)):
        compile(ast.parse(new),str(path),'exec')
        with path.open('xb')as stream:stream.write(new.encode())
        for direction,before,after in [('forward',old,new),('inverse',new,old)]:
            patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
                fromfile='a/'+label+'.py',tofile='b/'+label+'.py'))
            with (LIB/(label+'-'+direction+'.patch')).open('xb')as stream:stream.write(patch.encode())
    print(json.dumps(dict(point=pin(LIB/'semantic_inventory_search_v3.py'),
        symbolic=pin(LIB/'schema_admission_symbolic_control_v4.py'),component_calls=0),sort_keys=True))


if __name__=='__main__':
    main()
