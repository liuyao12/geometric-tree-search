"""Same complete reference scheduler, with branch-local exact cluster ordering."""
import collections,random,time
import hashlib,json
from native_receptor_points import fingerprint
from native_inventory_policy import choose
from native_inference_inventory import aggregate
from semantic_inventory_guidance import Join,vector,FEATURES,FIXED
from turtle import Graph
from semantic_inventory_guidance import row_requirements
from receptor_support_ordering_v1 import (VERSION as SUPPORT_VERSION,
    STRATEGY as SUPPORT_STRATEGY, GRAPH_SCHEMA, RANK_SCHEMA,
    build_support_graph, rank_support_options,
    COMPOSER_VERSION, COMPOSER_SCHEMA, compose_support_cluster)

VERSION = 'semantic-inventory-search-v3-root-composed-support'
SUPPORT_PROJECTION_WORK_LIMIT = 200000
SUPPORT_WORK_LIMIT = 200000


class _SupportDeadline(TimeoutError):
    """Only this module's own search-clock stop is converted to UNKNOWN."""


class _ProjectionStop(Exception):
    """A finite proposal projection abstains; it removes no original item."""


def _literal(value, charge):
    charge()
    if type(value) is dict:
        if any(type(k) is not str for k in value):
            raise ValueError('literal point projection dictionaries')
        return {k: _literal(v, charge) for k, v in value.items()}
    if type(value) in (list, tuple):
        return [_literal(v, charge) for v in value]
    if value is None or type(value) in (str, int, bool, float):
        return value
    raise ValueError('literal point projection values')


def _complete_rows(model, keys, charge):
    """Project actual complete C/G/all-input rows, without declaring facts.

    The shared helper independently checks literal ordered strict-prior
    requirements and recursively derives justified rows. Guard-only outputs
    and incomplete arbitrary samples never create a row packet here.
    """
    by_row = {}
    for key in sorted(set(keys)):
        charge()
        if key not in model.metadata or len(key) != 4:
            raise ValueError('actual point key required')
        row, role = key[:2]
        if (type(row) is not int or type(role) is not int or
                not 0 <= row < model.spec['length'] or
                not 0 <= role < 2 + model.arity):
            raise ValueError('actual row and declared input role required')
        roles = by_row.setdefault(row, {})
        if role in roles:
            raise ValueError('multiple placements on one row role')
        roles[role] = key
    result = []
    for row, roles in sorted(by_row.items()):
        charge()
        if len(roles) != 2 + model.arity:
            continue
        ordered = []
        for role in range(2 + model.arity):
            charge()
            ordered.append(roles[role])
        requirements = row_requirements(model, ordered, row)
        if requirements is None:
            continue
        command = model.metadata[roles[0]]['command']
        guard = model.metadata[roles[1]]['command']
        if command != guard:
            raise ValueError('complete row C/G agreement')
        result.append(dict(row=row,
            formula=_literal(guard['formula'], charge),
            requirements=_literal(requirements, charge),
            provenance=dict(kind='ACTUAL_COMPLETE_POINT_ROW',
                role_keys=_literal(ordered, charge),
                command=_literal(command, charge))))
    return result


def _support_choice(model, state, items, event, support_graph, check):
    """Rank the unchanged pool; original FIXED score/index breaks all ties."""
    projection = dict(work=0, limit=SUPPORT_PROJECTION_WORK_LIMIT,
                      aggregate_checks=0)
    legacy_order = sorted(range(len(items)),
                          key=lambda i: (-event['scores'][i], i))
    before = event['index']
    receipt = dict(schema='point-and-support-choice-v1',
        status='STABLE_FALLBACK', reason=None,
        legacy_index=before, selected_index=before,
        legacy_order=legacy_order, after_order=legacy_order[:],
        original_policy_scores=event['scores'][:],
        original_policy_probabilities=event['probabilities'][:],
        original_policy_probabilities_scope='Unchanged policy evidence; support ordering is deterministic.',
        projection=projection, validated_aggregates=[], ranking=None)

    def charge():
        check()
        if projection['work'] >= projection['limit']:
            raise _ProjectionStop('point_support_projection_work_budget')
        projection['work'] += 1

    try:
        known = _complete_rows(model, state.selected, charge)
        known_ids = {packet['row'] for packet in known}
        options = []
        for index in legacy_order:
            charge()
            item = items[index]
            rows = []
            if item is not None:
                check()
                actual = aggregate(model, item['members'], state)
                check()
                projection['aggregate_checks'] += 1
                if actual != {k: item[k] for k in
                        ('members', 'pending', 'aggregate_sha256',
                         'new_occupancy', 'new_marks')}:
                    raise ValueError('current support option aggregate')
                receipt['validated_aggregates'].append(dict(
                    original_index=index, aggregate=_literal(actual, charge)))
                union = set(state.selected).union(item['members'])
                rows = [packet for packet in _complete_rows(model, union, charge)
                        if packet['row'] not in known_ids]
            options.append(dict(option_id=dict(original_item_index=index), rows=rows))
        check()
        ranking = rank_support_options(graph=support_graph, known_rows=known,
            options=options, check=check, work_limit=SUPPORT_WORK_LIMIT)
        check()
        if (ranking.get('schema') != RANK_SCHEMA or
                ranking.get('version') != SUPPORT_VERSION or
                ranking.get('strategy') != SUPPORT_STRATEGY or
                ranking.get('status') not in ('SCORED', 'STABLE_FALLBACK')):
            raise ValueError('current shared support ranking protocol')
        order = ranking['order']
        if (type(order) is not list or any(type(i) is not int for i in order) or
                sorted(order) != list(range(len(items)))):
            raise ValueError('all original option multiplicity required')
        if ranking['status'] == 'STABLE_FALLBACK' and order != list(range(len(items))):
            raise ValueError('support abstention must preserve stable policy order')
        after = [legacy_order[i] for i in order]
        receipt.update(status=ranking['status'], reason=ranking['reason'],
                       after_order=after, selected_index=after[0], ranking=ranking)
    except _ProjectionStop:
        receipt['reason'] = 'point_support_projection_work_budget'
    check()
    return items[receipt['selected_index']], receipt



def _composer_json(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,
                      allow_nan=False).encode('utf8')


class _ComposerMappingStop(Exception):
    def __init__(self,owner,reason):
        self.owner,self.reason=owner,reason
        super().__init__(reason)


def _map_composed_word(model,proposal,check):
    """Map the ordinary proposed word into actual current Model keys only."""
    owner=object();work=0
    receipt=dict(status='ABSTAIN',reason=None,work=0,work_limit=SUPPORT_PROJECTION_WORK_LIMIT,
                 proposal_sha256=proposal.get('proposal_sha256'),rows=[],members=[],
                 aggregate=None,logical_authority=False,candidate_pruning=False)
    def charge():
        nonlocal work
        check()
        if work>=SUPPORT_PROJECTION_WORK_LIMIT:
            raise _ComposerMappingStop(owner,'UNKNOWN_COMPOSER_MAPPING_WORK')
        work+=1;receipt['work']=work
    def abstain(reason):
        raise _ComposerMappingStop(owner,reason)
    try:
        charge()
        if proposal.get('schema')!=COMPOSER_SCHEMA or proposal.get('version')!=COMPOSER_VERSION:
            raise ValueError('current root composer protocol')
        if proposal['status']!='PROPOSED':abstain('COMPOSER_ABSTAINED')
        plan=proposal['proposal']
        if hashlib.sha256(_composer_json(plan)).hexdigest()!=proposal['proposal_sha256']:
            raise ValueError('full literal composed plan preimage')
        proof=plan['proof']
        if (len(proof)!=model.spec['length'] or plan['root_seed_rows']!=[] or
                _composer_json(proof[-1]['formula'])!=_composer_json(model.spec['target'])):
            raise ValueError('root-only full original word and final target')
        basis={_composer_json(f):i for i,f in enumerate(model.compiled['basis'])}
        members=[]
        for row,command in enumerate(proof):
            charge();skeleton=_literal(command,charge)
            if command['rule']=='block':
                if 'inputs' not in skeleton:abstain('MISSING_BLOCK_INPUTS')
                del skeleton['inputs']
            wanted=_composer_json(skeleton);hits=[]
            for k,actual in enumerate(model.domains[row]):
                charge()
                if _composer_json(actual)==wanted:hits.append(k)
            if len(hits)!=1:abstain('NO_UNIQUE_ACTUAL_COMMAND_SKELETON')
            k=hits[0];variant=0;mode=0;sources=[]
            if command['rule']=='mp':
                source=command['implication']
                if type(source)is not int or not 0<=source<row:abstain('MP_REFERENCE')
                variant=basis.get(_composer_json(proof[source]['formula']))
                if variant is None:abstain('MP_VARIANT')
            if command['rule']=='block':
                if command['name'] not in model.mode:abstain('UNAVAILABLE_INTERFACE')
                mode=model.mode[command['name']];sources=command['inputs']
                definition=next(d['definition'] for d in model.interfaces if d['name']==command['name'])
                if len(sources)!=len(definition['premises']):abstain('ORDERED_BLOCK_ARITY')
                for source,formula in zip(sources,definition['premises']):
                    charge()
                    if (type(source)is not int or not 0<=source<row or
                            _composer_json(proof[source]['formula'])!=_composer_json(formula)):
                        abstain('ORDERED_BLOCK_REFERENCE')
            keys=[(row,0,k,0),(row,1,k,variant)]
            for port in range(model.arity):
                charge()
                keys.append((row,2+port,mode,sources[port]+1 if port<len(sources) else 0))
            for key in keys:
                charge()
                if key not in model.metadata:abstain('MISSING_ACTUAL_GUARD_OR_INPUT_KEY')
            if (_composer_json(model.metadata[keys[0]]['command'])!=wanted or
                    _composer_json(model.metadata[keys[1]]['command'])!=wanted):
                abstain('ACTUAL_COMMAND_GUARD_MISMATCH')
            receipt['rows'].append(dict(row=row,command=_literal(command,charge),
                skeleton_index=k,guard_variant=variant,mode=mode,keys=_literal(keys,charge)))
            members.extend(keys)
        charge()
        packets=_complete_rows(model,members,charge)
        if len(packets)!=model.spec['length']:abstain('INCOMPLETE_ACTUAL_ROWS')
        # Fresh full union at root. This is point consistency, not a theorem.
        root=model.initial();charge();actual=aggregate(model,members,root);charge()
        if actual is None:abstain('ROOT_AGGREGATE_CONFLICT')
        receipt.update(status='MAPPED',members=_literal(members,charge),
                       aggregate=_literal(actual,charge),complete_rows=packets)
    except _ComposerMappingStop as stopped:
        if stopped.owner is not owner:raise
        receipt.update(status='ABSTAIN',reason=stopped.reason,members=[],aggregate=None)
    check()
    return receipt


def search(model,mode='base',weights=None,stochastic=False,seed=0,attempts=20000,seconds=60,proposal_limit=24,proposal_checks=2048,support_ordering='legacy'):
    if mode not in ('base','zero','fixed','learned','no-family'):raise ValueError('ordering lane')
    if support_ordering not in ('legacy','and_support','composed_support'):raise ValueError('support ordering lane')
    if support_ordering in ('and_support','composed_support') and (mode!='fixed' or stochastic):raise ValueError('AND support requires deterministic fixed mode')
    if support_ordering=='composed_support' and (type(proposal_limit)is not int or not 1<=proposal_limit<=24):raise ValueError('composer one reserved rowproposal slot within1..24')
    if mode in ('learned','no-family') and (weights is None or len(weights)!=len(FEATURES)):raise ValueError('policy dimension')
    scoring=[0.]*len(FEATURES) if mode=='zero' else list(FIXED) if mode=='fixed' else list(weights) if weights is not None else None
    began=time.perf_counter();initial=model.initial();graph=Graph(model,initial);root_state=fingerprint(initial);root_graph=graph.fingerprint();metrics=collections.Counter();events=[];hints=[];found=None;rng=random.Random(seed);join=Join(model,mode!='no-family')
    support_graph=None;support_stopped=False;composer_mapping=None
    support_metadata=dict(schema='point-and-support-metadata-v1',version=VERSION,
        ordering=support_ordering,strategy=SUPPORT_STRATEGY,
        status='LEGACY_DISABLED',graph=None,graph_seconds=0.,
        helper_work_limit=SUPPORT_WORK_LIMIT,
        projection_work_limit=SUPPORT_PROJECTION_WORK_LIMIT,
        choice_receipts='Each applicable events[i].support_ordering retains full literal ranking evidence.',
        logical_authority=False,candidate_pruning=False,
        scope='Ordering existing validated Join items only; no new proposer, fact, marking, rule or bulk placement.')
    def support_check():
        if time.perf_counter()-began>=seconds:
            raise _SupportDeadline('point_support_search_deadline')
    if support_ordering in ('and_support','composed_support'):
        if SUPPORT_VERSION!='receptor-and-support-ordering-v1' or SUPPORT_STRATEGY!='ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1':raise ValueError('shared support implementation')
        stage=time.perf_counter()
        try:
            support_check()
            support_graph=build_support_graph(spec=model.spec,compiled=model.compiled,
                inventory=model.inventory,check=support_check,work_limit=SUPPORT_WORK_LIMIT)
            support_check()
            if (support_graph.get('schema')!=GRAPH_SCHEMA or support_graph.get('version')!=SUPPORT_VERSION or support_graph.get('strategy')!=SUPPORT_STRATEGY or support_graph.get('status') not in ('COMPLETE','UNKNOWN_WORK_BUDGET')):raise ValueError('current shared support graph protocol')
            support_metadata.update(status=support_graph['status'],graph=support_graph)
            metrics['support_graph_work']+=support_graph['counts']['work']
            if support_ordering=='composed_support':
                if COMPOSER_VERSION!='root-and-or-cluster-composer-v1':raise ValueError('current rootcomposer')
                support_check()
                composed=compose_support_cluster(graph=support_graph,check=support_check,work_limit=SUPPORT_WORK_LIMIT)
                support_check();support_metadata['composer']=composed
                metrics['composer_work']+=composed['counts']['work']
                composer_mapping=_map_composed_word(model,composed,support_check)
                support_metadata['composer_mapping']=composer_mapping
                metrics['composer_mapping_work']+=composer_mapping['work']
                support_metadata['scope']='Root-only EMPTY-seed composed word advice. A usable fullactualword reserves1of24 rowproposal slots; arbitrarysample/defer and completebasefallback remain. Abstention uses unchanged AND-support ordering.'
        except _SupportDeadline:
            support_stopped=True;support_metadata['status']='UNKNOWN_SEARCH_DEADLINE';metrics['support_deadline_stops']+=1
        support_metadata['graph_seconds']=time.perf_counter()-stage
    def review(state,g,hint,p):
        if hint is None:return None,dict(phase='absent',pending=[],eligible=[])
        pending=[k for k in hint['item']['members'] if k not in state.selected]
        if not pending:return None,dict(phase='completed',pending=[],eligible=[])
        illegal=[k for k in pending if not state.legal(model.placement(k))]
        if illegal:return None,dict(phase='invalid',pending=pending,illegal=illegal,eligible=[])
        eligible=[k for k in pending if k in g.domains.get(p,set())]
        return hint,dict(phase='eligible' if eligible else 'waiting',pending=pending,eligible=eligible)
    def visit(state,g,hint):
        nonlocal found
        if support_stopped:
            return None,dict(kind='unknown',point=None,census=[],state_sha256=root_state,
                hint_in=None,review=dict(phase='absent',pending=[],eligible=[]),
                children=[],cutoff='support_graph_deadline')
        kind,p,keys=g.decision(state);metrics['nodes']+=1
        active,trace=review(state,g,hint,p);tree=dict(kind=kind,point=p,census=[dict(point=q,generation=state.generations[q],keys=sorted(cs)) for q,cs in sorted(g.domains.items())],state_sha256=fingerprint(state),hint_in=hint['id'] if hint else None,review=trace,children=[])
        if hint:metrics['hint_'+trace['phase']]+=1
        if kind=='dead':metrics['dead']+=1;return False,tree
        if kind=='empty':found=state;return True,tree
        metrics[kind]+=1
        if kind=='branch' and active is None and mode!='base':
            stage=time.perf_counter();composed_item=None
            if support_ordering=='composed_support' and composer_mapping is not None and composer_mapping['status']=='MAPPED':
                try:
                    support_check();members=[tuple(k) for k in composer_mapping['members']]
                    actual=aggregate(model,members,state);support_check()
                    metrics['composer_branch_aggregate_checks']+=1
                    eligible=[] if actual is None else [k for k in actual['pending'] if k in g.domains.get(p,set())]
                    tree['composed_review']=dict(proposal_sha256=composer_mapping['proposal_sha256'],
                        status='ELIGIBLE' if eligible else 'ABSTAIN_INCOMPATIBLE_OR_NOT_INCIDENT',
                        aggregate=actual,eligible=eligible,logical_authority=False)
                    if eligible:
                        composed_item=actual;composed_item.update(kind='composed',level=0,
                            proposal_sha256=composer_mapping['proposal_sha256'])
                except _SupportDeadline:
                    metrics['support_deadline_stops']+=1;tree['cutoff']='composer_projection_deadline';return None,tree
            if composed_item is None:
                items,work=join(state,g,p,proposal_limit,proposal_checks)
            else:
                items,work=join(state,g,p,proposal_limit-1,proposal_checks)
                metrics['composer_reserved_row_slots']+=1
            for k,v in work.items():metrics[k]+=v
            features=[vector(item,model,state,g) for item in items];item,event=choose(items,features,scoring,rng,stochastic)
            support_deadline=False
            if support_ordering in ('and_support','composed_support'):
                metrics['support_order_calls']+=1
                try:
                    item,support_choice=_support_choice(model,state,items,event,support_graph,support_check)
                    event['support_ordering']=support_choice;event['index']=support_choice['selected_index']
                    metrics['support_projection_work']+=support_choice['projection']['work']
                    metrics['support_aggregate_checks']+=support_choice['projection']['aggregate_checks']
                    if support_choice['ranking'] is not None:metrics['support_ranking_work']+=support_choice['ranking']['counts']['work']
                    if support_choice['status']=='STABLE_FALLBACK':metrics['support_stable_fallbacks']+=1
                    if support_choice['selected_index']!=support_choice['legacy_index']:metrics['support_changed_hint_choices']+=1
                except _SupportDeadline:
                    support_deadline=True;metrics['support_deadline_stops']+=1
                    event['support_ordering']=dict(schema='point-and-support-choice-v1',
                        status='UNKNOWN_SEARCH_DEADLINE',reason='point_support_search_deadline',
                        legacy_index=event['index'],selected_index=None,ranking=None,
                        scope='No support score or hint was consumed; full unchanged items retained in this event.')
            if composed_item is not None and not support_deadline:
                before=event['index'];slot=len(items);items.append(composed_item)
                feature=vector(composed_item,model,state,g)
                event['features'].append(feature);event['scores'].append(sum(w*x for w,x in zip(scoring,feature)))
                event['probabilities'].append(0.)
                event['composed_preference']=dict(before_AND_support_index=before,selected_index=slot,
                    proposal_sha256=composed_item['proposal_sha256'],rowproposal_slot=1,
                    probability_scope='Original Join policy probabilities retained; appended zero is not a sampling probability. This is an explicit deterministic composed override.',
                    kind='composed',logical_authority=False)
                event['index']=slot;item=composed_item;metrics['composed_hints_preferred']+=1
            event.update(id=len(events),point=p,chosen=list(state.order),items=items,weights=scoring);tree['policy_event']=event['id'];events.append(event);metrics['proposal_seconds']+=time.perf_counter()-stage
            if support_deadline:tree['cutoff']='support_ordering_deadline';return None,tree
            if item is not None:
                if aggregate(model,item['members'],state)!={k:item[k] for k in ('members','pending','aggregate_sha256','new_occupancy','new_marks')}:raise ValueError('invalid row aggregate')
                active=dict(id=len(hints),item=item);hints.append(dict(id=active['id'],chosen=list(state.order),point=p,item=item));tree['hint_start']=active['id'];metrics['hints_started']+=1
                active,start=review(state,g,active,p);tree['start_review']=start
                if active is None or not start['eligible']:raise ValueError('cluster does not reach selected point')
                trace=start
        preferred=set(trace['eligible']) if active else set();alternatives=keys if kind=='forced' else [k for k in keys if k in preferred]+[k for k in keys if k not in preferred];tree['alternatives']=alternatives
        for k in alternatives:
            if metrics['attempts']>=attempts or time.perf_counter()-began>=seconds:tree['cutoff']='before_placement';return None,tree
            metrics['attempts']+=1;child=state.copy();cg=g.copy();cg.update(model,child,child.place(model.placement(k)));ok,sub=visit(child,cg,active);tree['children'].append(dict(key=k,role='member' if k in preferred else 'base',tree=sub))
            if ok is not False:return ok,tree
            metrics['backtracks']+=1
        return False,tree
    ok,tree=visit(initial,graph,None);restored=fingerprint(initial)==root_state and graph.fingerprint()==root_graph
    if not restored:raise ValueError('state/graph rollback')
    return dict(status='finite_marked_proof_region' if ok else 'unknown_search_budget' if ok is None else 'exhausted_finite_marked_region',
                proof=model.decode(found.order) if found else None,placements=found.order if found else [],tile_generations=found.tile_generations if found else [],
                tree=tree,metrics=dict(metrics),graph_metrics=dict(model.metrics),events=events,hints=hints,mode=mode,weights=scoring,
                stochastic=stochastic,seed=seed,seconds=time.perf_counter()-began,root_state_sha256=root_state,root_restored=restored,
                support_ordering=support_ordering,support_ordering_metadata=support_metadata,
                limits=dict(attempts=attempts,seconds=seconds,proposal_limit=proposal_limit,proposal_checks=proposal_checks),
                scope='Reference global dead/forced/earliest-generation point search. Semantic row and open arbitrary cluster hints only reorder original alternatives. No learned candidate pruning or primitive-square GCTS.')
