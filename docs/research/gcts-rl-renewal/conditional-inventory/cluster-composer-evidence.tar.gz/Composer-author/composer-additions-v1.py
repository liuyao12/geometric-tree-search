
# Explicit additive proposer API. Historical VERSION and support APIs above
# remain unchanged. This component supplies advice, never proof authority.
COMPOSER_VERSION = 'root-and-or-cluster-composer-v1'
COMPOSER_SCHEMA = 'root-and-or-cluster-proposal-v1'


def compose_support_cluster(*, graph, check, work_limit=DEFAULT_WORK_LIMIT):
    """One root-only EMPTY-seed AND/OR proposal over the full current graph.

    Positive tree costs choose origins, not a row-capacity certificate. Actual
    shared producers are topologically deduplicated and counted afterward.
    Only ordinary existing commands are serialized; consumers must establish
    exact grammar/guard/point membership. Final Native remains mandatory.
    """
    counts = dict(work=0, copy_nodes=0, callback_attempts=0, callback_returns=0)
    if not callable(check):
        raise SupportDataError('protected composer check required')

    def checked():
        counts['callback_attempts'] += 1
        check()  # No foreign exception, including StopIteration, is converted.
        counts['callback_returns'] += 1

    w = _Work(checked, work_limit, counts)
    record = dict(schema=COMPOSER_SCHEMA, version=COMPOSER_VERSION,
        support_version=VERSION, status='ABSTAIN', reason=None,
        root_seed_rows=[], graph_sha256=None, target_formula_id=None,
        potential_tree_cost=None, costs_and_origins=[],
        construction_prefix=dict(postorder=[], selected_edges=[], rows=[]),
        proposal=None, proposal_sha256=None, counts=counts, work_limit=work_limit,
        logical_authority=False, native_proof_accepted=False,
        candidate_pruning=False, complete_search_claimed=False)
    checked()
    original = _json(graph)
    record['source_snapshot_bytes'] = len(original)

    def copy_charge():
        w.step('copy_visits')

    def same(a, b):
        w.step('literal_comparisons')
        return _json(a) == _json(b)

    def index(value, maximum, label):
        if type(value) is not int or not 0 <= value < maximum:
            raise SupportDataError('strict composer index: ' + label)
        return value

    owned = None
    try:
        owned = _copy(graph, copy_charge, counts)
        if (owned.get('schema') != GRAPH_SCHEMA or owned.get('version') != VERSION or
                owned.get('strategy') != STRATEGY or
                owned.get('graph_sha256') != _sha(owned['graph_preimage'])):
            raise SupportDataError('exact current complete composer graph preimage')
        record['graph_sha256'] = owned['graph_sha256']
        if owned['status'] != 'COMPLETE':
            record['reason'] = 'INCOMPLETE_SUPPORT_GRAPH'
        else:
            pre = owned['graph_preimage']
            projection = pre['input_projection']
            spec, compiled, inventory = (projection[k] for k in ('spec','compiled','inventory'))
            if (type(spec['length']) is not int or spec['length'] != 12 or
                    spec.get('assumptions') or spec.get('blocks') or spec['theory']['schemas'] or
                    compiled['status'] != 'complete' or not _inventory_admission_ready(inventory)):
                raise SupportDataError('original closed twelve-row complete acquisition required')
            formulas, edges = pre['formulas'], pre['edges']
            if type(formulas) is not list or type(edges) is not list:
                raise SupportDataError('literal graph formula/edge arrays')
            words = set()
            for ordinal, entry in enumerate(formulas):
                w.step('formula_records_checked')
                word = _json(entry['formula'])
                if (type(entry['formula_id']) is not int or entry['formula_id'] != ordinal or
                        entry['literal_preimage'] != word.decode('utf8') or word in words or
                        type(entry['in_root_basis']) is not bool):
                    raise SupportDataError('unique full literal graph formula identity')
                words.add(word)
            allowed = {'axiom','tautology','instantiate','eq_subst','refl','mp','generalize','block'}
            for ordinal, edge in enumerate(edges):
                w.step('edge_records_checked')
                if (type(edge['edge_id']) is not int or edge['edge_id'] != ordinal or
                        edge['rule'] not in allowed or type(edge['ordered_premises']) is not list or
                        type(edge['positive_row_cost']) is not int or edge['positive_row_cost'] != 1 or
                        type(edge['active_in_root_formula_grammar']) is not bool or
                        type(edge['provenance']) is not dict):
                    raise SupportDataError('literal typed graph edge/provenance')
                index(edge['conclusion'],len(formulas),'conclusion')
                for source in edge['ordered_premises']:
                    w.step('edge_ordered_ports_checked')
                    index(source,len(formulas),'ordered premise')
            target = index(owned['target_formula_id'],len(formulas),'target')
            record['target_formula_id'] = target
            if not same(formulas[target]['formula'],spec['target']):
                raise SupportDataError('literal current target linkage')
            costs, origins = _potential(owned, [], w)  # EMPTY, never current facts
            record['costs_and_origins'] = [dict(formula_id=i,cost=value,origin=origins[i])
                                           for i,value in enumerate(costs)]
            record['potential_tree_cost'] = costs[target]
            if costs[target] is None:
                record['reason'] = 'NO_FINITE_HEURISTIC_DERIVATION'
            else:
                state, selected, postorder = {}, {}, []
                stack = [(target,False)]
                while stack:
                    w.step('origin_DFS_frames')
                    formula_id, leaving = stack.pop()
                    if leaving:
                        state[formula_id] = 2
                        postorder.append(formula_id)
                        continue
                    if state.get(formula_id) == 2:
                        continue
                    if state.get(formula_id) == 1:
                        record['reason'] = 'CYCLIC_ORIGINS'
                        break
                    origin, cost = origins[formula_id], costs[formula_id]
                    if (type(origin) is not dict or origin.get('kind') != 'HYPEREDGE' or
                            type(cost) is not int or cost <= 0):
                        raise SupportDataError('EMPTY-seed reachable producer must be a positive hyperedge')
                    edge = edges[index(origin['edge_id'],len(edges),'origin')]
                    if edge['conclusion'] != formula_id or not edge['active_in_root_formula_grammar']:
                        raise SupportDataError('origin must be active exact producer')
                    port_costs = []
                    for source in edge['ordered_premises']:
                        w.step('origin_ordered_ports')
                        value = costs[source]
                        if type(value) is not int or not 0 < value < cost:
                            raise SupportDataError('strict positive origin cost descent')
                        port_costs.append(value)
                    if cost != 1 + sum(port_costs):
                        raise SupportDataError('fixed-point origin cost equality')
                    selected[formula_id] = edge
                    state[formula_id] = 1
                    stack.append((formula_id,True))
                    # Repeated ordered ports stay repeated in the edge; DFS
                    # producer nodes alone are shared by exact formula identity.
                    for source in reversed(edge['ordered_premises']):
                        stack.append((source,False))
                    record['construction_prefix']['selected_edges'].append(edge)
                record['construction_prefix']['postorder'] = list(postorder)
                if record['reason'] is None and len(postorder) > spec['length']:
                    record['reason'] = 'SERIALIZED_DAG_EXCEEDS_ORIGINAL_ROWS'
                if record['reason'] is None:
                    if not postorder or postorder[-1] != target or len(set(postorder)) != len(postorder):
                        raise SupportDataError('acyclic shared postorder ends at target')
                    length = spec['length']
                    row_of = {f:i for i,f in enumerate(postorder[:-1])}
                    row_of[target] = length-1
                    definitions = {d['name']:d for d in inventory['definitions']}

                    def command_for(formula_id):
                        w.step('commands_serialized')
                        edge = selected[formula_id]
                        rule, provenance = edge['rule'], edge['provenance']
                        formula = formulas[formula_id]['formula']
                        ports = edge['ordered_premises']
                        sources = [row_of[p] for p in ports]
                        row = row_of[formula_id]
                        if any(not 0 <= source < row for source in sources):
                            raise SupportDataError('serialized strict prior references')
                        command = dict(rule=rule,formula=formula)
                        if rule == 'axiom':
                            name = provenance['name']
                            if ports or name not in spec['theory']['axioms'] or not same(spec['theory']['axioms'][name],formula):
                                raise SupportDataError('exact declared axiom origin')
                            command['name'] = name
                        elif rule == 'tautology':
                            item = index(provenance['admitted_tautology_index'],len(compiled['tautologies']),'tautology')
                            if ports or not same(compiled['tautologies'][item],formula):
                                raise SupportDataError('exact admitted tautology origin')
                        elif rule in ('instantiate','eq_subst'):
                            item = index(provenance['admitted_scheme_index'],len(compiled['admitted_schemes']),'scheme')
                            actual = compiled['admitted_schemes'][item]
                            if (ports or actual['rule'] != rule or not same(actual['formula'],formula) or
                                    not same(actual,provenance['exact_command'])):
                                raise SupportDataError('exact zero-read implication licence origin')
                            command = actual
                        elif rule == 'refl':
                            if ports or formula[0] != 'eq' or not same(formula[1],formula[2]):
                                raise SupportDataError('literal reflexivity origin')
                        elif rule == 'mp':
                            if len(ports) != 2:
                                raise SupportDataError('ordered two-port MP')
                            antecedent, implication = [formulas[p]['formula'] for p in ports]
                            if (implication[0] != 'imp' or not same(implication[1],antecedent) or
                                    not same(implication[2],formula)):
                                raise SupportDataError('literal antecedent/implication MP origin')
                            command.update(antecedent=sources[0],implication=sources[1])
                        elif rule == 'generalize':
                            if (len(ports) != 1 or formula[0] != 'all' or
                                    formula[1] != provenance['variable'] or formula[1] not in compiled['variables'] or
                                    not same(formula[2],formulas[ports[0]]['formula']) or
                                    provenance['root_context'] != compiled['catalog']['root_context']):
                                raise SupportDataError('closed-root literal generalization origin')
                            command.update(variable=formula[1],source=sources[0])
                        else:
                            name = provenance['interface_name']
                            if name not in inventory['interfaces'] or name not in definitions:
                                raise SupportDataError('only complete exported interfaces')
                            actual = definitions[name]
                            definition = actual['definition']
                            if (not same(actual,provenance['exact_definition_record']) or
                                    not same(definition['conclusion'],formula) or
                                    not same(definition['premises'],[formulas[p]['formula'] for p in ports])):
                                raise SupportDataError('full original block/ordered repeated port origin')
                            command.update(name=name,inputs=sources)
                        return command

                    produced = [(f,command_for(f)) for f in postorder]
                    padding = length-len(produced)
                    leaf = next(((f,c) for f,c in produced if not selected[f]['ordered_premises']),None)
                    if padding and leaf is None:
                        record['reason'] = 'NO_EXISTING_ZERO_READ_PADDING'
                    else:
                        rows = []
                        for formula_id,command in produced[:-1]:
                            w.step('serialized_rows')
                            rows.append(dict(row=len(rows),formula_id=formula_id,command=command,
                                edge_id=selected[formula_id]['edge_id'],padding=False,
                                ordered_source_rows=[row_of[p] for p in selected[formula_id]['ordered_premises']]))
                        for unused in range(padding):
                            w.step('padding_rows')
                            rows.append(dict(row=len(rows),formula_id=leaf[0],command=leaf[1],
                                edge_id=selected[leaf[0]]['edge_id'],padding=True,ordered_source_rows=[]))
                        formula_id,command = produced[-1]
                        rows.append(dict(row=len(rows),formula_id=formula_id,command=command,
                            edge_id=selected[formula_id]['edge_id'],padding=False,
                            ordered_source_rows=[row_of[p] for p in selected[formula_id]['ordered_premises']]))
                        record['construction_prefix']['rows'] = rows
                        if (len(rows) != length or rows[-1]['row'] != length-1 or
                                not same(rows[-1]['command']['formula'],spec['target'])):
                            raise SupportDataError('full original row count and final target')
                        proposal = dict(graph_sha256=owned['graph_sha256'],root_seed_rows=[],
                            target_formula_id=target,target_formula=spec['target'],length=length,
                            postorder_formula_ids=postorder,
                            formula_to_producer_row=[dict(formula_id=f,row=row_of[f]) for f in postorder],
                            selected_edges=[selected[f] for f in postorder],
                            distinct_producer_count=len(produced),padding_count=padding,rows=rows,
                            proof=[r['command'] for r in rows],
                            padding_policy='REPEAT_EXISTING_SELECTED_ZERO_READ_LEAF_BEFORE_FINAL_TARGET')
                        record.update(status='PROPOSED',proposal=proposal,proposal_sha256=_sha(proposal))
    except _OwnStop as stopped:
        if stopped.owner is not w:
            raise
        record.update(status='ABSTAIN',reason='UNKNOWN_COMPOSER_WORK_BUDGET',proposal=None,proposal_sha256=None)
    checked()
    if _json(graph) != original:
        raise SupportDataError('caller graph changed during root composition')
    checked()
    return record
