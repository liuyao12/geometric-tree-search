"""Exclusive passive publication freeze; no scientific import or evaluation."""
from pathlib import Path
import json,hashlib,tarfile,gzip,io
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
F=D/'publication-frozen-v1'
assert not F.exists()
F.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def descriptor(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def checked(d):
 b=Path(d['path']).read_bytes();assert len(b)==d['bytes'] and sha(b)==d['sha256'];return b
def save(name,b):
 p=F/name
 with p.open('xb')as f:f.write(b)
 return dict(path=name,bytes=len(b),sha256=sha(b))
report=(D/'publication-draft/cluster-composer.html').read_bytes()
report=report.replace(b'<a href="cluster-composer-manifest.json">Publication manifest</a>',
 b'<a href="cluster-composer-manifest.json">Publication manifest</a> \xc2\xb7 <a href="cluster-composer-review.json">Independent publication review</a>')
assert b'cluster-composer-review.json'in report
files=[save('cluster-composer.html',report),
       save('cluster-composer-summary.json',(D/'publication-draft/cluster-composer-summary.json').read_bytes())]
reader=P/'reader.html';before=reader.read_bytes()
assert sha(before)=='08a9aa2747ef77b6f7bb99de84dd64061b44b6a65f3d68974328a1592d13b9c2'
addition=b'<section id="cluster-composer"><h2>Shared cluster composer: failed full-profile comparison</h2><p>The <a href="cluster-composer.html#results">new four-arm experiment</a> tested a shared deterministic proposer in GCTS and conventional search. All four runs failed the deadline and memory profile during incomplete evidence assembly. No proof, admitted search result or method advantage is established. The report preserves an earlier setup rejection and identifies an unimplemented evidence-capture optimization for separate qualification.</p></section>'
assert before.count(b'</main>')==1 and b'id="cluster-composer"'not in before
files.append(save('reader.html',before.replace(b'</main>',addition+b'</main>')))
parallel=P/'buffered-canonical.html';parallel_before=parallel.read_bytes()
assert sha(parallel_before)=='d6ee6fd5f42cf8ee66db85567346d3a865f5da7ff5c90faf55ce276ba2606ab4'
old=b'<section id="team"><h2>Three roles, one integrated record.</h2>'
new=old+b'<p><strong>Follow-up:</strong> the <a href="cluster-composer.html">shared cluster-composer experiment</a> produced four full-profile failures and no admitted proof or search comparison. Parallel Source work, independent negative auditing and the next qualification design are recorded separately.</p>'
assert parallel_before.count(old)==1
files.append(save('buffered-canonical.html',parallel_before.replace(old,new)))
payload={}
def add(name,p):
 p=Path(p);b=p.read_bytes();assert name not in payload;payload[name]=b
closure=json.loads((D/'runtime-closure-v3.json').read_bytes())
sources=dict(closure['materialized_aliases'],**closure['schema_sources'],
             __cold__=closure['cold'],**{'__'+k+'__':v for k,v in closure['outer_sources'].items()})
assert len(sources)==32
for alias,d in sorted(sources.items()):
 checked(d);add('Source/'+alias+'.py',d['path'])
for p in sorted(D.glob('*.json')):add('Root/'+p.name,p)
for p in sorted(D.glob('*.py')):add('Root-authoring/'+p.name,p)
for version in ('plans-v1','plans-v2','plans-v3'):
 for p in sorted((D/version).rglob('*')):
  if p.is_file():add('Root/'+str(p.relative_to(D)),p)
for a in sorted(D.glob('actual-cohort-v3-*')):
 for p in sorted(a.iterdir()):
  if p.is_file():add('Root/'+str(p.relative_to(D)),p)
for folder,label in [
 ('/private/tmp/gcts-new-quantified-integration-peer-20261019','Peer'),
 ('/private/tmp/gcts-assembly-next-design-library-20261019','Assembly-design'),
 ('/private/tmp/gcts-assembly-qualification-design-20261019','Qualification-design'),
 ('/private/tmp/gcts-cluster-composer-library-20261019','Composer-author'),
 ('/private/tmp/gcts-cluster-composer-metadata-library-20261019','Metadata-author')]:
 for p in sorted(Path(folder).iterdir()):
  if p.is_file()and p.suffix in ('.json','.py','.patch'):add(label+'/'+p.name,p)
for name,p in [
 ('Inputs/original-full-capsule.json','/private/tmp/gcts-new-quantified-task-design-20261019/original-full-input-capsule.json'),
 ('Inputs/original-case006.json','/private/tmp/gcts-new-quantified-task-design-20261019/original-case006.json'),
 ('Inputs/policy.json','/private/tmp/gcts-semantic-family-next-audit-20261018/semantic-inventory-policy-001.json'),
 ('Contract/basic-tiling-algorithm.md','/private/tmp/gcts-cadence-integration-ROOT-20261019/basic-tiling-algorithm-HEAD.md'),
 ('Kernel/fol_checker.tree','/private/tmp/gcts-semantic-family-next-audit-20261018/fol_checker.tree')]:add(name,p)
info=dict(schema='cluster-composer-passive-packet-v1',scope='Source, original ordinary inputs, plans, frozen reviews and negative observations only. No successful proof/result from V3. Native/interpreter/Z3 artifacts are pinned, not redistributed; not a portable replay environment.',native_binary_payloads_included=False,scientific_calls_by_archiver=0,failed_prefixes_used_as_qualification_inputs=False,accepted_proofs=0,admitted_results=0,goal_complete=False,
 members=[dict(path=k,bytes=len(v),sha256=sha(v))for k,v in sorted(payload.items())])
payload['packet-info.json']=(json.dumps(info,sort_keys=True,indent=2)+'\n').encode()
raw=io.BytesIO()
with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0)as gz:
 with tarfile.open(fileobj=gz,mode='w')as tar:
  for name,b in sorted(payload.items()):
   t=tarfile.TarInfo(name);t.size=len(b);t.mtime=0;t.mode=0o644;t.uid=t.gid=0;t.uname=t.gname=''
   tar.addfile(t,io.BytesIO(b))
archive=raw.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(payload)
 for member in members:assert tar.extractfile(member).read()==payload[member.name]
files.append(save('cluster-composer-evidence.tar.gz',archive))
manifest=dict(schema='cluster-composer-publication-manifest-v1',files=files,packet_members=len(payload),
 protected_overview_modified=False,primary_reader_accessed=False,
 current_publish_base_commit='a2310f747a4c27c42d313e82967a2cb90d7a887f',
 detached_review='cluster-composer-review.json',
 detached_review_scope='The separately published peer review authenticates this manifest and is outside it to avoid a self-reference. Root live whole-body verification records its hash separately.',
 source_or_pipeline_qualification_from_publication=False,accepted_proofs=0,admitted_results=0,goal_complete=False)
save('cluster-composer-manifest.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps(dict(folder=str(F),files=[descriptor(p)for p in sorted(F.iterdir())],packet_members=len(payload)),indent=2))
