"""Root metadata grant creation; invoke only after explicit scope adoption."""
from pathlib import Path
import hashlib,json,sys
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
def rawpin(d):
 p=Path(d['path']);b=p.read_bytes();assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256'];return b
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def save(p,v):
 assert not p.exists(),str(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(json.dumps(v,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n');return pin(p)
def contains(v,x):
 if v==x:return True
 if type(v)is dict:return any(contains(i,x) for i in v.values())
 if type(v)is list:return any(contains(i,x) for i in v)
 return False
assert len(sys.argv)==5 and sys.argv[1]=='ROOT_ADOPTS_EXACT_REVIEW_SCOPES', 'explicit Root scope adoption plus three typed receipt paths'
rolespecs=[('current_components_Source','owned-evidence-integration-components-typed-Source-review-v1','source_review_passed'),('once_Source','owned-evidence-integration-once-typed-Source-review-v1','source_review_passed'),('prospective_plans','owned-evidence-integration-prospective-plan-review-v1','prospective_review_passed')]
reviews={}
for (role,schema,passed),path in zip(rolespecs,sys.argv[2:]):
 d=pin(path);r=json.loads(rawpin(d));assert r['schema']==schema and r[passed] is True and r['reviewer_identity']=='/root/conventional_control_review' and r['author_identity']!=r['reviewer_identity'];assert r['source_only'] is True and r['scientific_calls']==0 and type(r['scientific_calls'])is int and r['scientific_acceptance'] is False and r['actual_execution_authorized'] is False
 reviews[role]=(d,r)
m=load(D/'false-plan-manifest-v1.json');closure=json.loads(rawpin(m['runtime_closure']));rows=[]
assert len(m['plans'])==4
assert {(a['row']['mode'],a['row']['search_ordering'])for a in m['plans']}=={(mode,ordering)for mode in ('fixed','symbolic')for ordering in ('and_support','composed_support')}
for arm in m['plans']:
 w=json.loads(rawpin(arm['worker_plan']));o=json.loads(rawpin(arm['false_once_plan']));assert not Path(o['actual_directory']).exists()
 required={'current_components_Source':list(w['project_sources'].values())+list(w['components'].values())+list(closure['evidence_sources'].values())+list(closure['schema_sources'].values())+[o['cold']], 'once_Source':[o['runner'],o['observer']], 'prospective_plans':[o['integration_declaration'],o['runtime_closure'],o['worker_plan']]}
 roles={}
 for role,(d,r) in reviews.items():
  for x in required[role]:rawpin(x);assert contains(r,x),(role,x)
  roles[role]=dict(receipt=d,reviewer_identity='/root/conventional_control_review',required_subjects=required[role])
 subject={k:v for k,v in o.items() if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest();assert contains(reviews['prospective_plans'][1],sha),'exact prospectively reviewed subject hash'
 a=dict(schema='ROOT-owned-evidence-integration-once-authorization-v1',author_identity='/root',actual_execution_authorized=True,maximum_actual_invocations=1,subject_sha256=sha,review_roles=roles,scope='Exactly one fresh named source-matched quantified006 method-by-composer arm under unchanged full180 monotonic positive work/result reading/known exit and210 later outer custody/resource/group/EOF/external terminal. Separate worker+Native conservative highwater sum1GiB, logical+physical output128MiB, each stdout/stderr/workerreceipt4MiB, runnerplan16MiB and original work/proposal/search caps. Root adopts current component/outer/prospective reviews with inherited author overlap disclosed. Generic EMPTY-root composer independently runs once per ON arm under the same search30s/5000 limit. Both modes retain complete original alternatives, same full input/admitted library/candidate Model/Native/point/result/inverse gates. Deterministic proposer is no RL, learned marking, new mathematical axiom, proof authority or GCTS-specific advantage. Qualified finite comparator does not imply fullcold success. No human route, cached cross-arm word, hidden component call, retry, failed-prefix rescue, cap relaxation, changed horizon/catalog or elided costs. Preserve every outcome.')
 ap=save(D/'plans-v1/authorizations'/(o['invocation_id']+'.json'),a);o['authorization']=ap;assert hashlib.sha256(canonical({k:v for k,v in o.items() if k!='authorization'})).hexdigest()==sha
 op=save(D/'plans-v1/once-plans'/(o['invocation_id']+'.json'),o);rows.append(dict(mode=o['mode'],search_ordering=o['search_ordering'],once_plan=op,authorization=ap,subject_sha256=sha))
adopt=dict(schema='ROOT-owned-evidence-scope-adoption-v1',author_identity='/root',review_roles={k:v[0] for k,v in reviews.items()},scientific_calls=0,scientific_acceptance=False,mathematical_proof_accepted=False,ROOT_resource_accepted=False,source_scopes_adopted=True,execution_scope='Four separate fresh maximum-one method-by-composer subjects only; serial execution with all peers idle, no adaptation or retuning between arms.',inherited_author_overlap_disclosed=True,plans=rows)
p=save(D/'ROOT-scope-adoption-and-grants-v1.json',adopt);print(json.dumps(p));print(json.dumps(rows,indent=2))
