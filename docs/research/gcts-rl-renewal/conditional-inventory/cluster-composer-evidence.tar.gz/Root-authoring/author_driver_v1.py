"""Current driver policy/Source rebinding only; raw AST and unused compile."""
from pathlib import Path
import ast,difflib,hashlib,json,sys
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
P=Path('/private/tmp/gcts-finalization-instrumentation-ROOT-20261019/owned_evidence_receiver_driver_v6.py')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,s):
 p=D/n;assert not p.exists();p.write_text(s);return pin(p)
assert len(sys.argv)==4
sources={k:pin(p)for k,p in zip(('family_search','symbolic_control','support_ordering'),sys.argv[1:])}
assert all(v['path'].startswith('/private/tmp/gcts-cluster-composer-library-20261019/')for v in sources.values())
a=P.read_text();s=a;changes=[]
def replace(old,new,count):
 global s
 assert s.count(old)==count,(old,s.count(old));s=s.replace(old,new);changes.append(dict(old=old,new=new,count=count))
replace("VERSION = 'semantic-family-schema-admission-driver-v4'","VERSION = 'semantic-family-schema-admission-driver-v5-composition-policy'",1)
replace("OWNED_VERSION='semantic-family-owned-evidence-driver-v2-instrumented'","OWNED_VERSION='semantic-family-owned-evidence-driver-v3-composition-policy'",1)
tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='DEPENDENCY_PINS'for t in n.targets))
lines=s.splitlines(True);old=''.join(lines[node.lineno-1:node.end_lineno]).rstrip();values=ast.literal_eval(node.value)
for role,d in sources.items():values[role]=(d['sha256'],d['bytes'])
replace(old,'DEPENDENCY_PINS = '+repr(values),1)
replace("not in ('legacy', 'and_support'):","not in ('legacy', 'and_support', 'composed_support'):",3)
replace('explicit legacy/and_support Source-epoch ordering required','explicit legacy/and_support/composed_support Source-epoch ordering required',1)
replace('mandatory explicit legacy/and_support ordering','mandatory explicit legacy/and_support/composed_support ordering',2)
old="symbolic_strategy = ('NOVEL_BACKWARD_PRIORITY_DFS_V1' if search_ordering == 'legacy'\n                         else 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1')"
new="symbolic_strategy = {'legacy': 'NOVEL_BACKWARD_PRIORITY_DFS_V1',\n                         'and_support': 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1',\n                         'composed_support': 'ROOT_AND_OR_CLUSTER_COMPOSER_V1'}[search_ordering]"
replace(old,new,2)
replace('No new RL, nested family reuse, all-FOL or primitive Wang completion.','Optional root composition is a deterministic shared proposal, not RL or a learned family theorem; no all-FOL or primitive Wang completion.',2)
restored=s
for change in reversed(changes):restored=restored.replace(change['new'],change['old'])
assert restored==a
compile(s,str(D/'owned_evidence_receiver_driver_v7.py'),'exec')
driver=save('owned_evidence_receiver_driver_v7.py',s)
save('driver-parent-successor.patch',''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='parent-v6',tofile='successor-v7')))
record=dict(schema='ROOT-composed-policy-driver-Source-contract-v1',author_identity='/root',parent=pin(P),driver=driver,new_dependency_sources=sources,changes=changes,source_only=True,scientific_calls=0,actual_execution_authorized=False,unused_compiles=1,raw_inverse_reconstructed_parent=True,scope='Only explicit new ordering/strategy selection, three current dependency pins and truthful version/scope text. Every compiler/registry/checker/native/proof/point/old winning-lemma metric/serialization/custody/budget body retained. Existing family_hint_success stays narrow to row lemma hints; separately audit composed-consumption after complete Native/point admission. No old proof status upgraded.')
save('driver-Source-contract-v1.json',json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(driver=driver,contract=pin(D/'driver-Source-contract-v1.json')),indent=2))
