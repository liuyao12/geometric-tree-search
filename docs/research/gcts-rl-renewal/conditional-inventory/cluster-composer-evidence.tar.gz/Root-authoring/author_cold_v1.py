"""Raw Source rebinding to reviewed policy consumers; no subject evaluation."""
from pathlib import Path
import ast,difflib,hashlib,json,sys
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
P=Path('/private/tmp/gcts-new-quantified-integration-library-20261019/owned_evidence_cold_v8.py')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert len(sys.argv)==2
driver=pin(sys.argv[1]);assert driver['path']==str(D/'owned_evidence_receiver_driver_v7.py')
driver_contract=json.loads((D/'driver-Source-contract-v1.json').read_bytes())
ordering_sources=driver_contract['new_dependency_sources']
a=P.read_text();s=a;changes=[]
def replace(old,new,count):
 global s
 assert s.count(old)==count,(old,s.count(old));s=s.replace(old,new);changes.append(dict(old=old,new=new,count=count))
tree=ast.parse(s)
for name,new in [('VERSION',"'owned-evidence-intake-cold-v9-composer-factorial'"),('RECEIVER_DRIVER_SOURCE',repr(driver)),('ORDERING_COMPONENT_SOURCES',repr(ordering_sources))]:
 node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets))
 lines=a.splitlines(True);old=''.join(lines[node.lineno-1:node.end_lineno]).rstrip()
 replace(old,name+' = '+new,1)
replace("plan['search_ordering'] in ('legacy','and_support')","plan['search_ordering'] in ('legacy','and_support','composed_support')",1)
replace("need(plan['search_ordering']=='and_support','fixed shared support ordering in certification comparison')","need(plan['search_ordering'] in ('and_support','composed_support'),'explicit composer off/on ordering in matched factorial comparison')",1)
old="""need(len(schedule)==2 and len({r['invocation_id'] for r in schedule})==2 and
             len({r['actual_directory'] for r in schedule})==2 and
             {(r['mode'],r['inventory_certification_mode']) for r in schedule}==
                 {('fixed','schema_then_native'),('symbolic','schema_then_native')} and
             all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and
                 r['result_reader']=='interned' and r['search_ordering']=='and_support' for r in schedule),
             'two complete matched methods under the explicit schema admission lane')"""
new="""need(len(schedule)==4 and len({r['invocation_id'] for r in schedule})==4 and
             len({r['actual_directory'] for r in schedule})==4 and
             {(r['mode'],r['inventory_certification_mode'],r['search_ordering']) for r in schedule}==
                 {(m,'schema_then_native',o) for m in ('fixed','symbolic') for o in ('and_support','composed_support')} and
             all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and
                 r['result_reader']=='interned' for r in schedule),
             'four exact matched method-by-composer arms under explicit schema admission')"""
replace(old,new,1)
replace("receipt['version']=='semantic-family-owned-evidence-driver-v2-instrumented'","receipt['version']=='semantic-family-owned-evidence-driver-v3-composition-policy'",1)
replace("integration['schema']=='ROOT-owned-evidence-integration-comparison-declaration-v1'","integration['schema']=='ROOT-quantified-composer-four-arm-declaration-v1'",1)
replace("closure['schema']=='ROOT-owned-evidence-integration-raw-runtime-closure-v1'","closure['schema']=='ROOT-cluster-composer-runtime-closure-v1'",1)
replace("expected_project['receptor_support_ordering_v1']=ORDERING_COMPONENT_SOURCES['support_ordering']","expected_project['semantic_inventory_search_v2']=ORDERING_COMPONENT_SOURCES['family_search']\n        expected_project['receptor_support_ordering_v1']=ORDERING_COMPONENT_SOURCES['support_ordering']",1)
restored=s
for c in reversed(changes):restored=restored.replace(c['new'],c['old'])
assert restored==a
parenttree=ast.parse(a);newtree=ast.parse(s)
def definition(tree,name):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name==name)
for name in ['verify_literal_result','select_receiver','run_adapter_diagnostics','verify_saved_forest']:
 old=[n for n in parenttree.body if isinstance(n,ast.FunctionDef)and n.name==name]
 if old:assert ast.dump(old[0],include_attributes=False)==ast.dump(definition(newtree,name),include_attributes=False)
out=D/'owned_evidence_cold_v9.py';assert not out.exists();compile(s,str(out),'exec');out.write_text(s)
patch=D/'cold-parent-successor.patch';assert not patch.exists();patch.write_text(''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='parent-v8',tofile='successor-v9')))
record=dict(schema='ROOT-composer-factorial-cold-Source-contract-v1',author_identity='/root',parent=pin(P),cold=pin(out),driver=driver,changes=changes,source_only=True,scientific_calls=0,actual_execution_authorized=False,unused_compiles=1,raw_inverse_reconstructed_parent=True,scope='Only driver/version binding, explicit composed_support intake and exact4arm schedule. Qualified literal comparator and all source/compiler/native/point/inverse/result/resource/failure gates otherwise unchanged. This authoring metadata is no Source/runtime pass or grant.')
p=D/'cold-Source-contract-v1.json';assert not p.exists();p.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(cold=pin(out),contract=pin(p)),indent=2))
