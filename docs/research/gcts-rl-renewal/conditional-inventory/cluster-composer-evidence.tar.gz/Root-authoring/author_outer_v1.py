"""Raw/AST Root outer successor authoring; no subject evaluation or launch."""
from pathlib import Path
import ast,difflib,hashlib,json,sys
D=Path('/private/tmp/gcts-new-quantified-integration-ROOT-20261019')
P=Path('/private/tmp/gcts-finalization-integration-ROOT-20261019')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,value):
 p=D/n;assert not p.exists();p.write_bytes(value.encode());return pin(p)
assert len(sys.argv)==2
cold=pin(sys.argv[1]);assert cold['path']==str(D/'owned_evidence_cold_v9.py')
parent=P/'owned_evidence_once_runner_v3.py';a=parent.read_text();s=a
old="VERSION = 'owned-evidence-external-once-runner-v3-instrumented'"
new="VERSION = 'owned-evidence-external-once-runner-v4-composer-factorial'"
assert s.count(old)==1;s=s.replace(old,new)
tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='COLD_PIN'for t in n.targets))
lines=s.splitlines(True);oldpin=''.join(lines[node.lineno-1:node.end_lineno]).rstrip();newpin='COLD_PIN = '+repr(cold)
assert s.count(oldpin)==1;s=s.replace(oldpin,newpin)
oldguard="need(plan['receiver_id']=='prospective-fol-20261018-001','frozen familiar original001 assertion; no rescue selector')"
newguard="need(type(plan['receiver_id'])is str and bool(plan['receiver_id']),'explicit receiver from the exact current declaration; no implicit selector')"
assert s.count(oldguard)==1;s=s.replace(oldguard,newguard)
oldorders="ORDERINGS = ('and_support',)"
neworders="ORDERINGS = ('and_support','composed_support')"
assert s.count(oldorders)==1;s=s.replace(oldorders,neworders)
oldfactor="""need(len(ids)==2 and len(set(ids))==2 and ids.count(plan['invocation_id'])==1 and
         len({r['actual_directory'] for r in schedule})==2 and
         {(r['mode'],r['inventory_certification_mode']) for r in schedule}==
             {(m,c) for m in KINDS for c in CERTIFICATIONS} and
         all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and
             r['result_reader']=='interned' and r['search_ordering']=='and_support' for r in schedule),'complete matched fixed/symbolic explicit schema declaration')"""
newfactor="""need(len(ids)==4 and len(set(ids))==4 and ids.count(plan['invocation_id'])==1 and
         len({r['actual_directory'] for r in schedule})==4 and
         {(r['mode'],r['inventory_certification_mode'],r['search_ordering']) for r in schedule}==
             {(m,c,o) for m in KINDS for c in CERTIFICATIONS for o in ORDERINGS} and
         all(r['receiver_id']==plan['receiver_id'] and r['model_storage']=='literal_interned' and
             r['result_reader']=='interned' for r in schedule),'complete fixed/symbolic-by-composer explicit schema factorial declaration')"""
assert s.count(oldfactor)==1;s=s.replace(oldfactor,newfactor)
oldreceipt="driver_receipt['version']=='semantic-family-owned-evidence-driver-v2-instrumented'"
newreceipt="driver_receipt['version']=='semantic-family-owned-evidence-driver-v3-composition-policy'"
assert s.count(oldreceipt)==1;s=s.replace(oldreceipt,newreceipt)
oldschemas=("closure['schema']=='ROOT-owned-evidence-integration-raw-runtime-closure-v1'", "declaration['schema']=='ROOT-owned-evidence-integration-comparison-declaration-v1'")
newschemas=("closure['schema']=='ROOT-cluster-composer-runtime-closure-v1'", "declaration['schema']=='ROOT-quantified-composer-four-arm-declaration-v1'")
for before,after in zip(oldschemas,newschemas):
 assert s.count(before)==1;s=s.replace(before,after)
restored=s
for before,after in zip(oldschemas,newschemas):restored=restored.replace(after,before)
assert restored.replace(newreceipt,oldreceipt).replace(newfactor,oldfactor).replace(neworders,oldorders).replace(new,old).replace(newpin,oldpin).replace(newguard,oldguard)==a
compile(s,str(D/'owned_evidence_once_runner_v4.py'),'exec')
runner=save('owned_evidence_once_runner_v4.py',s)
observer=P/'observe_owned_evidence_runner_v3.py';a2=observer.read_text();o=a2
oldver="VERSION = 'owned-evidence-final-terminal-observer-v3-instrumented'"
newver="VERSION = 'owned-evidence-final-terminal-observer-v4-composer-factorial'"
assert o.count(oldver)==1;o=o.replace(oldver,newver)
oldsha='1099886bf7dbf7d4a0321843a3da306f373d321d77a156d6d8d94160626484f0'
assert o.count(oldsha)==1;o=o.replace(oldsha,runner['sha256'])
assert o.replace(newver,oldver).replace(runner['sha256'],oldsha)==a2
compile(o,str(D/'observe_owned_evidence_runner_v4.py'),'exec')
obs=save('observe_owned_evidence_runner_v4.py',o)
save('runner-parent-successor.patch',''.join(difflib.unified_diff(a.splitlines(True),s.splitlines(True),fromfile='parent-v3',tofile='successor-v4')))
save('observer-parent-successor.patch',''.join(difflib.unified_diff(a2.splitlines(True),o.splitlines(True),fromfile='parent-v3',tofile='successor-v4')))
x=dict(schema='ROOT-declared-quantified-outer-Source-contract-v1',author_identity='/root',parents=dict(runner=pin(parent),observer=pin(observer)),sources=dict(cold=cold,runner=runner,observer=obs),scope='Only frozen coldV9 binding, explicit nonempty early receiver check, exact4arm method-by-ordering factorial and version/pin rebinding. Exact later current declaration/full worker selection/schedule and every original resource/log/group/Native/evidence/result gate retained. No grant or execution.',clock_scope='Original positive worker/result/header/knownexit180, laterouter and observedterminal210; observer225failureonly; separate worker+Native highwater sum1GiB,128MiB output and original separate4MiB log gates unchanged.',original_caps_retained=True,scientific_calls=0,actual_execution_authorized=False,source_only=True,unused_compiles=2,raw_inverse_reconstructed_parent=True,claim_limits='Specialized finite proof-region adaptation; no new reference conformance, fullFOL universality, RL or search-advantage admission. Exact task/horizon/policy/trust and prospective subject review required separately.')
save('outer-Source-contract-v1.json',json.dumps(x,sort_keys=True,indent=2)+'\n')
print(json.dumps(x,indent=2))
