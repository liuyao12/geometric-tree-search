"""Unexecuted Source: ordinary-JSON-only successor for frozen false metadata.

No subject import, AST census rerun, science, process, proof, actual or grant.
Only new v2 metadata filenames are writable after exact Root metadata review.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = '/private/tmp/gcts-new-quantified-integration-ROOT-20261019'
PARENT_MANIFEST = {'path': ROOT + '/false-plan-manifest-v1.json', 'bytes': 6502,
                   'sha256': 'cdfcb5fdd204b0637b08c2eb15143feaf66c4f3c5c5df350715da52fdf74d2b6'}
OLD_CONFORMANCE = ('Representation adapter only. Same complete point domains, t/m values, '
    'candidate graph, global dead/forced processing, earliest generation branching, rollback, '
    'actual Model inputs, original primitive rules and final Native gates. Specialized finite '
    'proof-region adaptation; no new complete shared-engine conformance theorem.')
NEW_CONFORMANCE = OLD_CONFORMANCE.replace('Representation adapter only.',
    'Shared generic composer/ordering experiment.', 1)
OLD_LIMITATION = ('Only out-of-band instrumentation changes current driver/cold; '
                  'every old scientific/evidence Source remains exact.')
NEW_LIMITATION = ('Current support helper, point search and symbolic control change for the '
    'shared generic composer/ordering experiment, with new Driver/cold/runner/observer coupling. '
    'All other retained project/component modules and evidence/schema/Native/Z3 Sources remain '
    'exact; no other scientific rule, grammar, policy or cap change.')
FALSE_AUTHORIZATION = {'path': 'NO_AUTHORIZATION_FALSE_PLAN', 'bytes': 0,
                       'sha256': 'NO_AUTHORIZATION'}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                       allow_nan=False) + '\n').encode('utf-8')


def safe_path(value):
    path = Path(value)
    need(path.is_absolute() and path == path.resolve() and not path.is_symlink(),
         'canonical nonsymlink path')
    need('/.gcts-active/' not in str(path), 'protected active path')
    need(not (str(path).startswith('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/')
              and path.name in ('index.html', 'reader.html')), 'protected primary page')
    return path


def describe(path, raw):
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def pin(path):
    path = safe_path(path)
    need(path.is_file(), 'regular raw file')
    return describe(path, path.read_bytes())


def checked(descriptor):
    need(type(descriptor) is dict and set(descriptor) == {'path', 'bytes', 'sha256'},
         'exact raw descriptor')
    path = safe_path(descriptor['path'])
    raw = path.read_bytes()
    need(describe(path, raw) == descriptor, 'frozen whole descriptor mismatch: '+str(path))
    return raw


def load(descriptor):
    return json.loads(checked(descriptor))


def differences(left, right, prefix=''):
    if type(left) is dict and type(right) is dict:
        found = []
        for key in sorted(set(left) | set(right)):
            pointer = prefix + '/' + key
            if key not in left or key not in right:
                found.append(pointer)
            else:
                found.extend(differences(left[key], right[key], pointer))
        return found
    if type(left) is list and type(right) is list and len(left) == len(right):
        return [p for i, (a, b) in enumerate(zip(left, right))
                for p in differences(a, b, prefix + '/' + str(i))]
    return [] if left == right else [prefix]


def exact_delta(left, right, allowed):
    actual = differences(left, right)
    need(actual and set(actual) <= set(allowed),
         'ONLY predeclared metadata paths change: '+str(actual))
    return actual


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root_directory')
    parser.add_argument('parent_manifest_json')
    parser.add_argument('Root_metadata_review_json')
    args = parser.parse_args(argv)
    root = safe_path(args.root_directory)
    need(str(root) == ROOT and root.is_dir(), 'exact existing Root metadata directory')
    need(pin(args.parent_manifest_json) == PARENT_MANIFEST, 'exact frozen V1 false manifest')
    parent = load(PARENT_MANIFEST)
    self_pin = pin(Path(__file__).resolve())
    review_pin = pin(args.Root_metadata_review_json)
    review = load(review_pin)
    need(review.get('metadata_build_authorized') is True and
         review.get('actual_execution_authorized') is False and
         review.get('metadata_builder') == self_pin and
         review.get('parent_manifest') == PARENT_MANIFEST,
         'exact Root successor metadata-only authorization, never subject authority')
    oldclosure = load(parent['runtime_closure'])
    olddecl = load(parent['declaration'])
    need(sys.version_info[:2] == (3, 12) and
         pin(Path(sys.executable).resolve()) == oldclosure['metadata_authoring_python'],
         'same pinned3.12 ordinary metadata authoring runtime')
    need(olddecl['conformance'] == OLD_CONFORMANCE and
         oldclosure['limitations'][3] == OLD_LIMITATION, 'exact two reviewed stale fields')
    need(oldclosure['schema'] == 'ROOT-cluster-composer-runtime-closure-v1' and
         olddecl['schema'] == 'ROOT-quantified-composer-four-arm-declaration-v1',
         'unchanged executable-bound closure/declaration schemas')
    need(parent['actual_execution_authorized'] is False and
         oldclosure['actual_execution_authorized'] is False and
         olddecl['actual_execution_authorized'] is False,
         'frozen false-only parent, no grant or actual')
    need(oldclosure['evidence_profile'] == olddecl['evidence_profile'],
         'current selected-receiver profile already coupled in V1')
    binding = load(parent['source_bindings'])
    # Source raw pins only: no Source interpretation/import/AST/function call.
    for descriptor in list(binding['sources'].values()) + list(binding['project_replacements'].values()):
        checked(descriptor)
    need(len(binding['sources']) == 4 and len(binding['project_replacements']) == 3,
         'same exact seven Sources; no replacement')
    need(len(parent['plans']) == 4 and
         [entry['row'] for entry in parent['plans']] == olddecl['schedule'],
         'same exact four frozen subject identities and schedule')
    planroot = root / 'plans-v2'
    need(not planroot.exists() and not planroot.is_symlink(), 'fresh V2 plan namespace')
    for entry in parent['plans']:
        actual = safe_path(entry['row']['actual_directory'])
        need(not actual.exists() and not actual.is_symlink(), 'planned actual stays absent')
        for namespace in ('plans-v1', 'plans-v2'):
            terminal = root / namespace / 'false-once-plans' / (entry['row']['invocation_id']+'-terminal-observation')
            need(not terminal.exists() and not terminal.is_symlink(), 'no terminal directory')
    pending, delta_rows = [], []

    def stage(path, value):
        need(root in path.parents, 'new metadata path inside Root')
        raw = canonical(value)
        pending.append((path, raw))
        return describe(path, raw)

    history = dict(parent_false_manifest=PARENT_MANIFEST,
        parent_metadata_builder=parent['metadata_builder'],
        parent_metadata_only_Root_review=parent['metadata_only_Root_review'],
        scope='FrozenV1 and its negative stale-scope prospective review remain historical and unmodified; V2 awaits distinct current prospective review.')
    closure = copy.deepcopy(oldclosure)
    closure['limitations'][3] = NEW_LIMITATION
    closure['metadata_builder'] = self_pin
    closure['metadata_only_Root_review'] = review_pin
    closure['parent_metadata_authoring_context_only'] = history
    paths = exact_delta(oldclosure, closure, ['/limitations/3', '/metadata_builder/path',
        '/metadata_builder/bytes', '/metadata_builder/sha256',
        '/metadata_only_Root_review/path', '/metadata_only_Root_review/bytes',
        '/metadata_only_Root_review/sha256', '/parent_metadata_authoring_context_only'])
    closure_pin = stage(root / 'runtime-closure-v2.json', closure)
    delta_rows.append(dict(kind='runtime_closure', before=parent['runtime_closure'], after=closure_pin, paths=paths))
    declaration = copy.deepcopy(olddecl)
    declaration['conformance'] = NEW_CONFORMANCE
    declaration['runtime_closure'] = closure_pin
    paths = exact_delta(olddecl, declaration, ['/conformance', '/runtime_closure/path',
        '/runtime_closure/bytes', '/runtime_closure/sha256'])
    declaration_pin = stage(root / 'case-declaration-v2.json', declaration)
    delta_rows.append(dict(kind='declaration', before=parent['declaration'], after=declaration_pin, paths=paths))
    need(declaration['limits'] == olddecl['limits'] and
         declaration['evidence_profile'] == olddecl['evidence_profile'] and
         closure['evidence_profile'] == oldclosure['evidence_profile'] and
         declaration['selected_receiver'] == olddecl['selected_receiver'] and
         declaration['schedule'] == olddecl['schedule'], 'all science/input/profile/schedule unchanged')
    plans = []
    for entry in parent['plans']:
        row = entry['row']
        oldworker = load(entry['worker_plan'])
        oldonce = load(entry['false_once_plan'])
        need(oldonce['authorization'] == FALSE_AUTHORIZATION, 'same false sentinel')
        need(oldworker['runtime_closure'] == parent['runtime_closure'] and
             oldworker['integration_declaration'] == parent['declaration'] and
             oldonce['runtime_closure'] == parent['runtime_closure'] and
             oldonce['integration_declaration'] == parent['declaration'] and
             oldonce['worker_plan'] == entry['worker_plan'], 'whole parent cross references')
        worker = copy.deepcopy(oldworker)
        worker['runtime_closure'] = closure_pin
        worker['integration_declaration'] = declaration_pin
        changed = exact_delta(oldworker, worker,
            ['/'+key+'/'+field for key in ('runtime_closure', 'integration_declaration')
             for field in ('path','bytes','sha256')])
        worker_pin = stage(planroot / 'worker-plans' / (row['invocation_id']+'.json'), worker)
        delta_rows.append(dict(kind='worker_plan', before=entry['worker_plan'], after=worker_pin, paths=changed))
        once = copy.deepcopy(oldonce)
        once['runtime_closure'] = closure_pin
        once['integration_declaration'] = declaration_pin
        once['worker_plan'] = worker_pin
        changed = exact_delta(oldonce, once,
            ['/'+key+'/'+field for key in ('runtime_closure','integration_declaration','worker_plan')
             for field in ('path','bytes','sha256')])
        once_pin = stage(planroot / 'false-once-plans' / (row['invocation_id']+'.json'), once)
        delta_rows.append(dict(kind='false_once_plan', before=entry['false_once_plan'], after=once_pin, paths=changed))
        plans.append(dict(row=copy.deepcopy(row), worker_plan=worker_pin, false_once_plan=once_pin))
    delta_pin = stage(root / 'metadata-successor-delta-v2.json', dict(
        schema='ROOT-composer-metadata-successor-delta-v2', parent_manifest=PARENT_MANIFEST,
        metadata_builder=self_pin, metadata_only_Root_review=review_pin,
        substantive_corrections=['declaration.conformance prefix', 'runtime_closure.limitations[3]'],
        current_header_corrections='Current metadata builder/review with complete historical provenance; exact recomputed V2 metadata references only.',
        artifact_deltas=delta_rows, source_bindings=parent['source_bindings'],
        seven_Sources_unchanged=True, input_profile_limits_schemas_and_schedule_unchanged=True,
        source_or_AST_census_rerun=False, scientific_calls=0,
        actual_execution_authorized=False, current_prospective_review_pending=True))
    manifest = copy.deepcopy(parent)
    manifest.update(runtime_closure=closure_pin, declaration=declaration_pin, plans=plans,
        metadata_builder=self_pin, metadata_only_Root_review=review_pin,
        parent_metadata_authoring_context_only=history, metadata_successor_delta=delta_pin)
    allowed = ['/runtime_closure/'+f for f in ('path','bytes','sha256')]
    allowed += ['/declaration/'+f for f in ('path','bytes','sha256')]
    allowed += ['/'+k+'/'+f for k in ('metadata_builder','metadata_only_Root_review') for f in ('path','bytes','sha256')]
    allowed += ['/parent_metadata_authoring_context_only','/metadata_successor_delta']
    allowed += ['/plans/'+str(i)+'/'+k+'/'+f for i in range(4)
                for k in ('worker_plan','false_once_plan') for f in ('path','bytes','sha256')]
    exact_delta(parent, manifest, allowed)
    manifest_pin = stage(root / 'false-plan-manifest-v2.json', manifest)
    need(len(pending) == 12, 'exact11 successor plan metadata files plus narrow delta')
    for path, raw in pending:
        need(not path.exists() and not path.is_symlink(), 'exclusive V2 metadata only: '+str(path))
    for path, raw in pending:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
        need(pin(path) == describe(path, raw), 'whole emitted metadata check')
    print(json.dumps(dict(schema='composer-metadata-successor-build-result-v2',
        status='FALSE_METADATA_ONLY_PENDING_CURRENT_PROSPECTIVE_REVIEW',
        manifest=manifest_pin, closure=closure_pin, declaration=declaration_pin,
        delta=delta_pin, files=len(pending), scientific_calls=0,
        actual_execution_authorized=False, no_actual_or_grant_created=True)))


if __name__ == '__main__':
    main(sys.argv[1:])
