"""Unexecuted Source: ordinary-JSON-only material metadata correction/new cohort.

Fresh V3 subjects, never an unchanged retry. No subject import, Source function,
hidden preflight, AST census, proof/Native/solver/engine operation or grant.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = '/private/tmp/gcts-new-quantified-integration-ROOT-20261019'
PARENT_MANIFEST = {'path': ROOT+'/false-plan-manifest-v2.json', 'bytes': 7718,
                  'sha256': 'c5bffc085ed3ae26790d484d1fc8bfabf72c7252da552f47093ec8729c0aa459'}
FALSE_AUTHORIZATION = {'path': 'NO_AUTHORIZATION_FALSE_PLAN', 'bytes': 0,
                       'sha256': 'NO_AUTHORIZATION'}
COHORT = 'cohort-v3'
CASE_ID = 'prospective-fol-20261018-006'
COLD_DESCRIPTOR_CONTRACT = {
    'path': '/private/tmp/gcts-cluster-composer-metadata-library-20261019/cold-intake-descriptor-contract-v3.json',
    'bytes': 7431, 'sha256': '03d6c2ce968c4948bb624e67cf39460c8e9a9fe936dc4b47383d8866419d4024'}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                       allow_nan=False)+'\n').encode('utf-8')


def safe_path(value):
    p = Path(value)
    need(p.is_absolute() and p == p.resolve() and not p.is_symlink(), 'canonical nonsymlink path')
    need('/.gcts-active/' not in str(p), 'protected active path')
    need(not (str(p).startswith('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/')
              and p.name in ('index.html','reader.html')), 'protected primary page')
    return p


def descriptor(path, raw):
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def pin(path):
    p = safe_path(path)
    need(p.is_file(), 'regular raw file')
    return descriptor(p, p.read_bytes())


def checked(value):
    need(type(value) is dict and set(value) == {'path','bytes','sha256'}, 'exact whole descriptor')
    p = safe_path(value['path'])
    raw = p.read_bytes()
    need(descriptor(p, raw) == value, 'frozen whole descriptor mismatch: '+str(p))
    return raw


def load(value):
    return json.loads(checked(value))


def differences(left, right, pointer=''):
    if type(left) is dict and type(right) is dict:
        out = []
        for key in sorted(set(left)|set(right)):
            p = pointer+'/'+key
            if key not in left or key not in right:
                out.append(p)
            else:
                out.extend(differences(left[key],right[key],p))
        return out
    if type(left) is list and type(right) is list and len(left)==len(right):
        return [p for i,(a,b) in enumerate(zip(left,right))
                for p in differences(a,b,pointer+'/'+str(i))]
    return [] if left==right else [pointer]


def bounded_delta(left, right, allowed):
    paths = differences(left,right)
    need(paths and set(paths)<=set(allowed), 'ONLY declared material metadata changes: '+str(paths))
    return paths


def descriptor_fields(*keys):
    return ['/'+key+'/'+field for key in keys for field in ('path','bytes','sha256')]


def metadata_joins(once, worker, declaration, closure, row, expected_capsule,
                   closure_pin, declaration_pin, worker_pin, source_binding,
                   cold_contract, lineage):
    """Explicit ordinary in-memory JSON comparisons, NOT subject preflight.

    Mirrors raw runner163-208/cold790-858 descriptor predicates. Never calls,
    imports, evaluates or emulates a scientific/Native/Model/checker function.
    """
    joined = ('invocation_id','mode','search_ordering','inventory_certification_mode',
              'actual_directory','cold','python','receiver_id','result_reader',
              'model_storage','integration_declaration','runtime_closure')
    need(all(worker[k]==once[k] for k in joined), 'complete exact worker/once joins')
    need(once['worker_plan']==worker_pin and once['runtime_closure']==closure_pin and
         once['integration_declaration']==declaration_pin, 'exact staged plan descriptors')
    need(once['cold']==source_binding['sources']['cold'] and
         once['runner']==source_binding['sources']['runner'] and
         once['observer']==source_binding['sources']['observer'], 'exact same outer/cold Sources')
    constants = cold_contract['Source_constants']
    need(cold_contract['cold_source']==once['cold'] and
         closure['parent_closure']==constants['PARENT_RUNTIME_CLOSURE'],
         'exact full caller/cold parent descriptor including path')
    expected_project = dict(lineage['project_sources'])
    expected_project.update(semantic_inventory_oracle=constants['REGISTRY_SOURCE'],
        quantified_family_points_v2=constants['ORDINARY_MODEL_SOURCE'],
        semantic_inventory_search_v2=source_binding['project_replacements']['semantic_inventory_search_v2'],
        receptor_support_ordering_v1=source_binding['project_replacements']['receptor_support_ordering_v1'],
        quantified_symbolic_control_v2=source_binding['project_replacements']['quantified_symbolic_control_v2'])
    need(expected_project['interned_quantified_family_points_v1']==constants['COMPACT_MODEL_SOURCE'] and
         worker['project_sources']==closure['project_sources']==expected_project,
         'complete parent project with registry/ordinaryModel/new3ordering replacements')
    need(all(closure[k]==lineage[k] for k in ('Z3','Z3_imports','external_imports',
        'fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python')),
        'complete exact unchanged parent Native/Z3/runtime/stdlib maps')
    need(worker['components']['receiver_driver']==source_binding['sources']['driver'] and
         worker['components']['bounded_transport']==lineage['additional_nonseed_components']['bounded_transport'],
         'exact new Driver and unchanged bounded transport descriptors')
    need(closure['evidence_sources']==constants['EVIDENCE_SOURCES'] and
         closure['schema_sources']==constants['SCHEMA_SOURCES'] and
         closure['schema_kernel_source']==constants['SCHEMA_KERNEL_SOURCE'],
         'exact Source-bound evidence/schema/kernel raw maps')
    need(constants['EVIDENCE_ALIASES']==dict(adapter='owned_evidence_adapter',
         arena='exact_evidence_arena',join='owned_inventory_join',
         inverse='independent_forest_inverse'), 'exact four evidence alias names')
    need(worker['z3']['files']==[{k:p[k] for k in ('path','sha256','bytes')}
                               for p in closure['Z3']['files']] and
         worker['z3']['root']==closure['Z3']['package_root'] and
         worker['z3']['library']['path']==str(Path(worker['z3']['root'])/'z3/lib/libz3.dylib'),
         'complete Z3 raw file map/package root/library path')
    need(worker['schema']=='ROOT-owned-evidence-integration-worker-plan-v1' and
         len(worker['project_sources'])==22 and
         set(worker['components'])=={'receiver_driver','bounded_transport'}, '22project+2component intake')
    evidence = closure['evidence_sources']
    need(set(evidence)=={'adapter','arena','join','inverse'} and
         len(closure['schema_sources'])==1, 'exact four evidence and one schema roles')
    names = dict(worker['project_sources'], semantic_receiver_driver=worker['components']['receiver_driver'],
                 bounded_request_oracle=worker['components']['bounded_transport'])
    names.update(owned_evidence_adapter=evidence['adapter'],exact_evidence_arena=evidence['arena'],
                 owned_inventory_join=evidence['join'],independent_forest_inverse=evidence['inverse'])
    need(len(names)==28 and closure['schema']=='ROOT-cluster-composer-runtime-closure-v1' and
         closure['project_sources']==worker['project_sources'] and
         closure['additional_nonseed_components']==worker['components'] and
         closure['materialized_aliases']==names and
         closure['runtime']['Python_executable']==once['python'], 'whole alias/runtime joins')
    need(declaration['schema']=='ROOT-quantified-composer-four-arm-declaration-v1' and
         declaration['runtime_closure']==closure_pin and
         declaration['parent_structural_declaration']==worker['declaration']==
             declaration['input_capsule']==expected_capsule and
         declaration['selected_receiver_id']==once['receiver_id']==CASE_ID and
         declaration['result_reader']==once['result_reader'],
         'exact descriptor PATH+SIZE+SHA joins, not equal-content substitution')
    need(declaration['evidence_profile']==closure['evidence_profile'] and
         closure['evidence_profile']==cold_contract['current_evidence_profile_preimage'] and
         declaration['evidence_profile']['sources']==evidence and
         declaration['finalization_profile']==closure['finalization_profile']==
             'owned-finalization-phase-instrumented-v1', 'whole evidence/profile joins')
    schedule = declaration['schedule']
    ids = [r['invocation_id'] for r in schedule]
    need(len(ids)==len(set(ids))==4 and ids.count(once['invocation_id'])==1 and
         len({r['actual_directory'] for r in schedule})==4 and
         {(r['mode'],r['inventory_certification_mode'],r['search_ordering']) for r in schedule}==
             {(m,'schema_then_native',o) for m in ('fixed','symbolic')
              for o in ('and_support','composed_support')} and
         all(r['receiver_id']==CASE_ID and r['model_storage']=='literal_interned' and
             r['result_reader']=='interned' for r in schedule), 'complete fresh four-arm schedule')
    need(schedule[ids.index(once['invocation_id'])]==row and
         all(row[k]==once[k] for k in ('mode','search_ordering','inventory_certification_mode',
             'result_reader','receiver_id','actual_directory','model_storage')),
         'exact current selected row joins')
    need(once['authorization']==FALSE_AUTHORIZATION, 'false sentinel only')
    return dict(scope='Ordinary JSON authoring predicates only; no runtime/proof/Native/resource authority.',
        exact_descriptor_joins=True, all_row_and_profile_joins=True, subject_function_calls=0)


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root_directory')
    parser.add_argument('parent_manifest_json')
    parser.add_argument('shared_failure_history_json')
    parser.add_argument('Root_metadata_review_json')
    args = parser.parse_args(argv)
    root = safe_path(args.root_directory)
    need(str(root)==ROOT and root.is_dir(), 'exact existing Root metadata directory')
    need(pin(args.parent_manifest_json)==PARENT_MANIFEST, 'exact frozen V2 false manifest')
    parent = load(PARENT_MANIFEST)
    self_pin = pin(Path(__file__).resolve())
    failure_pin = pin(args.shared_failure_history_json)
    failure = load(failure_pin)
    review_pin = pin(args.Root_metadata_review_json)
    review = load(review_pin)
    need(review.get('metadata_build_authorized') is True and
         review.get('actual_execution_authorized') is False and
         review.get('metadata_builder')==self_pin and review.get('parent_manifest')==PARENT_MANIFEST and
         review.get('shared_failure_history')==failure_pin and
         review.get('cold_descriptor_contract')==COLD_DESCRIPTOR_CONTRACT,
         'Root exact metadata-only Source/parent/history review, never grant')
    oldclosure, olddecl = load(parent['runtime_closure']), load(parent['declaration'])
    need(sys.version_info[:2]==(3,12) and
         pin(Path(sys.executable).resolve())==oldclosure['metadata_authoring_python'],
         'same pinned3.12 metadata runtime')
    need(parent['actual_execution_authorized'] is False and
         oldclosure['actual_execution_authorized'] is False and
         olddecl['actual_execution_authorized'] is False, 'false-only frozen parent')
    need(failure['schema']=='composer-shared-preworker-failure-history-v3' and
         failure['frozen_failed_manifest']==PARENT_MANIFEST and
         failure['scientific_acceptance'] is False and failure['mathematical_proof_accepted'] is False and
         failure['ROOT_resource_accepted'] is False, 'shared failure remains negative/history only')
    for value in failure['preserved_raw_descriptors']:
        checked(value)
    terminal = load(failure['terminal'])
    need(terminal['runner_exit_code']==1 and terminal['terminal_gate_passed'] is False and
         terminal['mathematical_proof_accepted'] is False and terminal['ROOT_resource_accepted'] is False,
         'exact preworker failure terminal, no result upgrade')
    binding = load(parent['source_bindings'])
    cold_contract = load(COLD_DESCRIPTOR_CONTRACT)
    lineage = load(cold_contract['Source_constants']['PARENT_RUNTIME_CLOSURE'])
    for value in list(binding['sources'].values())+list(binding['project_replacements'].values()):
        checked(value)  # Whole Source raw hashes only.
    need(len(binding['sources'])==4 and len(binding['project_replacements'])==3, 'same exact seven Sources')
    old_rows = [entry['row'] for entry in parent['plans']]
    need(old_rows==olddecl['schedule'] and len(old_rows)==4, 'same parent four rows')
    old_workers = [load(entry['worker_plan']) for entry in parent['plans']]
    old_once = [load(entry['false_once_plan']) for entry in parent['plans']]
    capsule_pin = old_workers[0]['declaration']
    need(all(w['declaration']==capsule_pin for w in old_workers) and
         olddecl['input_capsule']==capsule_pin and capsule_pin['bytes']==22422 and
         capsule_pin['sha256']=='1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0',
         'one exact original full capsule descriptor, including path')
    need(olddecl['parent_structural_declaration']!=capsule_pin and
         olddecl['parent_structural_declaration']['bytes']==capsule_pin['bytes'] and
         olddecl['parent_structural_declaration']['sha256']==capsule_pin['sha256'],
         'specific old equal-content/different-path protocol defect')
    capsule = load(capsule_pin)  # Ordinary complete authored input JSON, no opaque program.
    matches = [r for r in capsule['receivers'] if r['id']==CASE_ID]
    need(len(matches)==1 and matches[0]==olddecl['selected_receiver'] and
         matches[0]['length']==12 and matches[0]['instantiation_rounds']==2,
         'same exact full original006, twelve rows/two rounds')
    rows = []
    for oldrow in old_rows:
        row = copy.deepcopy(oldrow)
        stem = row['mode']+'-'+row['search_ordering'].replace('_','-')
        row['invocation_id']='quantified-composer-006-'+stem+'-ROOT-20261019-'+COHORT
        row['actual_directory']=str(root/('actual-'+COHORT+'-'+stem))
        rows.append(row)
    need(not ({r['invocation_id'] for r in rows}&{r['invocation_id'] for r in old_rows}) and
         not ({r['actual_directory'] for r in rows}&{r['actual_directory'] for r in old_rows}),
         'new subject identities/directories, not unchanged retry')
    planroot = root/'plans-v3'
    need(not planroot.exists() and not planroot.is_symlink(), 'fresh plans-v3 namespace')
    for row in rows:
        actual = safe_path(row['actual_directory'])
        terminal_path = planroot/'false-once-plans'/(row['invocation_id']+'-terminal-observation')
        need(not actual.exists() and not actual.is_symlink() and not terminal_path.exists() and
             not terminal_path.is_symlink(), 'new actual/terminal paths remain absent')
    pending, delta_rows, joins = [], [], []

    def stage(path, value):
        need(root in path.parents, 'new metadata only inside exact Root')
        raw = canonical(value)
        pending.append((path,raw))
        return descriptor(path,raw)

    history = dict(parent_false_manifest=PARENT_MANIFEST,
        parent_metadata_builder=parent['metadata_builder'],
        parent_metadata_only_Root_review=parent['metadata_only_Root_review'],
        earlier_metadata_context=parent.get('parent_metadata_authoring_context_only'),
        shared_preworker_failure_history=failure_pin,
        scope='FrozenV1/V2, old grants/consumed terminal and preworker protocol failure retained. Remaining three old arms NOT_RUN_COMMON_PROTOCOL_ABORT. V3 is material descriptor correction plus new subjects, not an unchanged retry or upgraded old result.')
    closure = copy.deepcopy(oldclosure)
    closure.update(metadata_builder=self_pin, metadata_only_Root_review=review_pin,
        parent_metadata_authoring_context_only=history, shared_failure_history=failure_pin)
    allowed = (descriptor_fields('metadata_builder','metadata_only_Root_review')+
        ['/parent_metadata_authoring_context_only','/shared_failure_history'])
    # A whole historical context is replaced intentionally; bound it as a field.
    cpaths = differences(oldclosure,closure)
    need(all(p.startswith('/parent_metadata_authoring_context_only/') or p in allowed for p in cpaths),
         'only current provenance/failure history closure changes')
    closure_pin = stage(root/'runtime-closure-v3.json',closure)
    delta_rows.append(dict(kind='runtime_closure',before=parent['runtime_closure'],after=closure_pin,paths=cpaths))
    declaration = copy.deepcopy(olddecl)
    declaration.update(parent_structural_declaration=capsule_pin,runtime_closure=closure_pin,
                       schedule=rows,shared_failure_history=failure_pin)
    schedule_paths=['/schedule/'+str(i)+'/'+k for i in range(4) for k in ('invocation_id','actual_directory')]
    dpaths=bounded_delta(olddecl,declaration,descriptor_fields('parent_structural_declaration','runtime_closure')+
                        schedule_paths+['/shared_failure_history'])
    declaration_pin=stage(root/'case-declaration-v3.json',declaration)
    delta_rows.append(dict(kind='declaration',before=parent['declaration'],after=declaration_pin,paths=dpaths))
    need(declaration['limits']==olddecl['limits'] and declaration['evidence_profile']==olddecl['evidence_profile'] and
         closure['evidence_profile']==oldclosure['evidence_profile'] and
         declaration['selected_receiver']==olddecl['selected_receiver'] and
         declaration['schema']==olddecl['schema'] and closure['schema']==oldclosure['schema'],
         'input/profile/limits/schemas exact unchanged')
    plans=[]
    for entry,row,oldworker,oldplan in zip(parent['plans'],rows,old_workers,old_once):
        need(oldplan['authorization']==FALSE_AUTHORIZATION, 'parent false sentinel retained')
        worker=copy.deepcopy(oldworker)
        worker.update(invocation_id=row['invocation_id'],actual_directory=row['actual_directory'],
                      runtime_closure=closure_pin,integration_declaration=declaration_pin)
        paths=bounded_delta(oldworker,worker,descriptor_fields('runtime_closure','integration_declaration')+
                            ['/invocation_id','/actual_directory'])
        worker_pin=stage(planroot/'worker-plans'/(row['invocation_id']+'.json'),worker)
        delta_rows.append(dict(kind='worker_plan',before=entry['worker_plan'],after=worker_pin,paths=paths))
        once=copy.deepcopy(oldplan)
        once.update(invocation_id=row['invocation_id'],actual_directory=row['actual_directory'],
                    runtime_closure=closure_pin,integration_declaration=declaration_pin,worker_plan=worker_pin)
        paths=bounded_delta(oldplan,once,descriptor_fields('runtime_closure','integration_declaration','worker_plan')+
                            ['/invocation_id','/actual_directory'])
        once_pin=stage(planroot/'false-once-plans'/(row['invocation_id']+'.json'),once)
        delta_rows.append(dict(kind='false_once_plan',before=entry['false_once_plan'],after=once_pin,paths=paths))
        joins.append(metadata_joins(once,worker,declaration,closure,row,capsule_pin,
                                   closure_pin,declaration_pin,worker_pin,binding,cold_contract,lineage))
        plans.append(dict(row=row,worker_plan=worker_pin,false_once_plan=once_pin))
    delta_pin=stage(root/'metadata-successor-delta-v3.json',dict(
        schema='ROOT-composer-metadata-successor-delta-v3',parent_manifest=PARENT_MANIFEST,
        metadata_builder=self_pin,metadata_only_Root_review=review_pin,shared_failure_history=failure_pin,
        descriptor_join_contract=COLD_DESCRIPTOR_CONTRACT,
        material_correction='parent_structural_declaration equals exact worker.declaration/input_capsule descriptor; new cohort-v3 IDs/directories and all V3 metadata references.',
        artifact_deltas=delta_rows,ordinary_descriptor_join_receipts=joins,
        seven_Sources_input_profile_limits_policy_unchanged=True,
        old_result_or_resource_upgraded=False,subject_function_calls=0,scientific_calls=0,
        actual_execution_authorized=False,current_prospective_review_pending=True))
    manifest=copy.deepcopy(parent)
    manifest.update(runtime_closure=closure_pin,declaration=declaration_pin,plans=plans,
        metadata_builder=self_pin,metadata_only_Root_review=review_pin,
        parent_metadata_authoring_context_only=history,shared_failure_history=failure_pin,
        metadata_successor_delta=delta_pin)
    mpaths=differences(parent,manifest)
    prefixes=('/runtime_closure/','/declaration/','/plans/','/metadata_builder/',
              '/metadata_only_Root_review/','/parent_metadata_authoring_context_only/',
              '/metadata_successor_delta/')
    need(all(p=='/shared_failure_history' or p.startswith(prefixes) for p in mpaths),
         'only declared new cohort/provenance/reference manifest differences')
    manifest_pin=stage(root/'false-plan-manifest-v3.json',manifest)
    need(len(pending)==12,'exact twelve new false metadata files including delta')
    for path,raw in pending:
        need(not path.exists() and not path.is_symlink(),'exclusive V3 metadata only: '+str(path))
    for path,raw in pending:
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
        need(pin(path)==descriptor(path,raw),'whole emitted metadata')
    print(json.dumps(dict(schema='composer-metadata-successor-build-result-v3',
        status='FALSE_NEW_SUBJECTS_PENDING_CURRENT_PROSPECTIVE_REVIEW',manifest=manifest_pin,
        closure=closure_pin,declaration=declaration_pin,delta=delta_pin,files=len(pending),
        shared_failure_history=failure_pin,subject_function_calls=0,scientific_calls=0,
        actual_execution_authorized=False,no_actual_or_grant_created=True)))


if __name__=='__main__':
    main(sys.argv[1:])
