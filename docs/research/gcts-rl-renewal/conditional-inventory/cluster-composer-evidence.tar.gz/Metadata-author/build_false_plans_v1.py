"""Raw/AST/ordinary-JSON metadata author; NEVER imports a subject.

Not executed at Source-authoring time. See API-v1.json for the reviewed CLI.
This program can emit inactive false plans only. It cannot create a grant,
launch a process, decode a scientific payload, or make an actual directory.
"""
import argparse
import ast
import builtins
import copy
import hashlib
import json
from pathlib import Path
import symtable
import sys

VERSION = 'cluster-composer-four-arm-false-metadata-builder-v1'
AUTHOR = '/root/benchmark_design'
ROOT = '/private/tmp/gcts-new-quantified-integration-ROOT-20261019'
PARENT = '/private/tmp/gcts-finalization-integration-ROOT-20261019'
DESIGN = '/private/tmp/gcts-cluster-composer-design-20261019'
INPUTS = '/private/tmp/gcts-new-quantified-task-design-20261019'
CASE_ID = 'prospective-fol-20261018-006'
REPLACEMENTS = frozenset(('receptor_support_ordering_v1',
                         'semantic_inventory_search_v2',
                         'quantified_symbolic_control_v2'))
MASTER = {'path': '/private/tmp/gcts-cadence-integration-ROOT-20261019/basic-tiling-algorithm-HEAD.md',
          'bytes': 36240, 'sha256': 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'}
CAPSULE = {'path': INPUTS + '/original-full-input-capsule.json', 'bytes': 22422,
           'sha256': '1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0'}
SPEC = {'path': INPUTS + '/original-case006.json', 'bytes': 2395,
        'sha256': 'e488d2152352671290bcc1fdc5a6f51b18fa456aacb0423ff6d0c41c22a566a4'}
CLAIM_DESIGN = {'path': DESIGN + '/generic-family-composer-experiment-v2.json',
                'bytes': 17414, 'sha256': 'b3bcf92ffb5ceb1b09326f831b770927d83400695909fa74be825068f3f47bf6'}
PRIOR_ENDPOINT = {'path': INPUTS + '/prior-case006-status-and-resource-metadata-v1.json',
                  'bytes': 29334, 'sha256': '7ff9a54c0b325926a18380ae0842c1da88b53ccc491a12857af57eb1e2eb0e96'}
FINITE_ADOPTION = {'path': '/private/tmp/gcts-buffered-canonical-ROOT-20261019/ROOT-finite-comparator-adoption-v1.json',
                   'bytes': 1084, 'sha256': '897a364c237c03f018da76666b7904c913d6b7a7b1711fbc9e5ccbe48781dd4f'}
# FINITE_ADOPTION's literal pin is intentionally checked by the metadata author;
# a mismatch must fail closed, never be replaced silently by current bytes.
FALSE_AUTHORIZATION = {'path': 'NO_AUTHORIZATION_FALSE_PLAN', 'bytes': 0,
                       'sha256': 'NO_AUTHORIZATION'}
LIMITS = {'check_steps': 2048, 'compile_queries': 512,
          'conservative_worker_plus_native_peak_bytes': 1073741824,
          'guard_steps': 1000000000, 'overall_seconds': 210,
          'proposal_steps': 24, 'registry_steps': 5000000000,
          'result_bytes': 134217728, 'search_max_nodes': 5000,
          'search_seconds': 30, 'seed': 64000, 'work_seconds': 180}
RUNNER_LIMITS = {'work_seconds': 180, 'overall_seconds': 210,
                 'aggregate_peak_bytes': 1073741824, 'stdout_bytes': 4194304,
                 'stderr_bytes': 4194304, 'result_bytes': 134217728,
                 'worker_receipt_bytes': 4194304, 'runner_plan_bytes': 16777216,
                 'failure_cleanup_seconds': 5, 'poll_milliseconds': 20}
RUNTIME_NAMES = frozenset(('__name__', '__file__', '__package__', '__spec__',
                           '__loader__', '__builtins__', '__cached__', '__doc__'))


def need(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                       allow_nan=False) + '\n').encode('utf-8')


def safe_path(value):
    p = Path(value)
    need(p.is_absolute() and p == p.resolve() and not p.is_symlink(),
         'canonical absolute nonsymlink path: ' + str(p))
    need('/.gcts-active/' not in str(p) and p.name != '.gcts-active',
         'protected active checkout must not be opened')
    primary = '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/'
    need(not (str(p).startswith(primary) and p.name in ('reader.html', 'index.html')),
         'protected dataless primary reader/overview must not be opened')
    return p


def describe(path, raw):
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def raw_pin(value):
    p = safe_path(value)
    need(p.is_file(), 'ordinary regular file required: ' + str(p))
    return describe(p, p.read_bytes())


def checked(pin):
    need(type(pin) is dict and set(pin) == {'path', 'bytes', 'sha256'},
         'exact path/bytes/sha256 descriptor required')
    need(type(pin['bytes']) is int and pin['bytes'] >= 0 and
         type(pin['sha256']) is str and len(pin['sha256']) == 64,
         'nonplaceholder raw descriptor required')
    p = safe_path(pin['path'])
    raw = p.read_bytes()
    need(describe(p, raw) == pin, 'whole pin mismatch: ' + str(p))
    return raw


def ordinary_json(pin):
    return json.loads(checked(pin))


def read_json_path(path):
    return ordinary_json(raw_pin(path))


def literals(raw, filename):
    result = {}
    tree = ast.parse(raw, filename=filename)
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                result[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError, SyntaxError):
                pass
    return tree, result


def module_global_census(raw, filename):
    """Syntactic name evidence only, never a claim of runtime resolution."""
    table = symtable.symtable(raw.decode('utf-8'), filename, 'exec')
    module_bound = {s.get_name() for s in table.get_symbols()
                    if s.is_assigned() or s.is_imported() or s.is_parameter()}
    builtin_names = set(dir(builtins))
    missing, runtime = [], []

    def visit(t, path):
        for symbol in t.get_symbols():
            if symbol.is_global() and symbol.is_referenced() and symbol.get_name() not in module_bound:
                name = symbol.get_name()
                row = dict(name=name, scope_path=path, scope_line=t.get_lineno(),
                           syntactic_global_reference=True)
                if name in RUNTIME_NAMES:
                    runtime.append(row)
                elif name not in builtin_names:
                    missing.append(row)
        for child in t.get_children():
            visit(child, path + '/' + child.get_name() + ':' + str(child.get_lineno()))

    visit(table, '<module>')
    return dict(module_syntactic_bindings=sorted(module_bound),
                unresolved_global_references=missing,
                runtime_injected_names=runtime,
                scope='symtable lexical evidence only: assignments/imports may be conditional, injected names remain loader trust, and no runtime binding or callable origin is proved.')


def make_census(modules, external_roots):
    records, internal, unknown, relative, dynamic_unresolved = [], [], [], [], []
    stdlib = set()
    standard = set(sys.stdlib_module_names) | set(sys.builtin_module_names)
    names = set(modules)

    def classify(module, level, owner, line):
        if level:
            relative.append(dict(alias=owner, module=module, level=level, line=line))
            return 'UNRESOLVED_RELATIVE'
        top = module.split('.')[0] if module else ''
        if top in names:
            internal.append(dict(source=owner, target=top, line=line))
            return 'DECLARED_OWNED_ALIAS'
        if top in external_roots:
            return 'INHERITED_EXTERNAL_TRUST'
        if top in standard:
            stdlib.add(top)
            return 'DECLARED_STDLIB_OR_BUILTIN_ROOT'
        unknown.append(dict(alias=owner, module=module, line=line))
        return 'UNRESOLVED_IMPORT_ROOT'

    for alias, source in modules.items():
        raw = checked(source)
        tree = ast.parse(raw, filename=source['path'])
        imports, dynamic = [], []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for item in node.names:
                    imports.append(dict(kind='import', module=item.name, asname=item.asname,
                                        line=node.lineno, column=node.col_offset,
                                        classification=classify(item.name, 0, alias, node.lineno)))
            elif isinstance(node, ast.ImportFrom):
                imports.append(dict(kind='from', module=node.module, level=node.level,
                    names=[dict(name=x.name, asname=x.asname) for x in node.names],
                    line=node.lineno, column=node.col_offset,
                    classification=classify(node.module, node.level, alias, node.lineno)))
            elif isinstance(node, ast.Call) and (
                isinstance(node.func, ast.Name) and node.func.id == '__import__' or
                isinstance(node.func, ast.Attribute) and node.func.attr == 'import_module'):
                literal = (node.args[0].value if node.args and isinstance(node.args[0], ast.Constant)
                           and type(node.args[0].value) is str else None)
                row = dict(line=node.lineno, column=node.col_offset,
                           callable_AST=ast.dump(node.func, include_attributes=False),
                           literal_module=literal,
                           argument_AST=ast.dump(node.args[0], include_attributes=False) if node.args else None,
                           classification=classify(literal, 0, alias, node.lineno) if literal is not None
                           else 'UNRESOLVED_NONLITERAL_DYNAMIC_SITE')
                dynamic.append(row)
                if literal is None:
                    dynamic_unresolved.append(dict(alias=alias, **row))
        globals_record = module_global_census(raw, source['path'])
        records.append(dict(alias=alias, source=source,
            AST_sha256=hashlib.sha256(ast.dump(tree, include_attributes=True).encode()).hexdigest(),
            imports=imports, dynamic_import_sites=dynamic, **globals_record))
    unbound = [dict(alias=r['alias'], **x) for r in records for x in r['unresolved_global_references']]
    return records, dict(schema='composer-current-raw-AST-census-v1', sources=len(records),
        internal_edges=internal, static_import_sites=sum(len(r['imports']) for r in records),
        dynamic_import_sites=sum(len(r['dynamic_import_sites']) for r in records),
        unresolved_import_roots=unknown, relative_import_sites=relative,
        nonliteral_dynamic_sites=dynamic_unresolved, unresolved_global_references=unbound,
        no_syntactic_unresolved_globals_observed=not unbound,
        stdlib_roots=sorted(stdlib), external_roots=sorted(external_roots),
        status='RAW_AST_ONLY_PENDING_CURRENT_SOURCE_AND_RUNTIME_REVIEW',
        source_or_loader_closure_proved=False,
        scope='All declared source bytes parsed under pinned3.12, never imported. Zero unresolved static imports is not proof of global/callable/dynamic/loader resolution. Every unresolved site is retained; no deceptive COMPLETE status.')


def stdlib_references(root, used):
    root = safe_path(root)
    records = {}
    for name in sorted(used):
        pins = []
        for p in (root / (name + '.py'), root / name / '__init__.py'):
            if p.is_file():
                pins.append(raw_pin(p))
        dyn = root / 'lib-dynload'
        if dyn.is_dir():
            for p in sorted(dyn.glob(name + '.*.so')):
                pins.append(raw_pin(p))
        records[name] = dict(pins=pins, builtin=name in sys.builtin_module_names,
            scope='Direct named entry files/extensions only; recursive standard library, frozen precedence, linked native libraries, interpreter and OS loader remain inherited trust. No import occurred.')
    return records


def missing_paths(value, path=''):
    if value is None:
        return [path]
    if isinstance(value, dict):
        return [p for k, v in value.items() for p in missing_paths(v, path + '/' + k)]
    if isinstance(value, list):
        return [p for i, v in enumerate(value) for p in missing_paths(v, path + '/' + str(i))]
    return []


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root_directory')
    parser.add_argument('cold_source')
    parser.add_argument('driver_source')
    parser.add_argument('runner_source')
    parser.add_argument('observer_source')
    parser.add_argument('source_bindings_json')
    parser.add_argument('--root-review', default=None)
    parser.add_argument('--draft-only', action='store_true')
    args = parser.parse_args(argv)
    root = safe_path(args.root_directory)
    need(str(root) == ROOT and root.is_dir(), 'exact existing Root metadata directory')
    binding_pin = raw_pin(args.source_bindings_json)
    bindings = ordinary_json(binding_pin)
    need(bindings.get('schema') == 'composer-false-metadata-bindings-v1', 'bindings schema')
    need(set(bindings) == {'schema', 'parent_runtime_closure', 'parent_case_declaration',
         'parent_worker_plan', 'parent_false_once_plan', 'sources', 'project_replacements',
         'literal_binding_requirements', 'current_review_requirements',
         'inherited_source_receipts_context_only'}, 'exact binding envelope; no opaque input fields')
    missing = missing_paths(bindings)
    if args.draft_only:
        print(json.dumps(dict(schema='composer-metadata-draft-status-v1',
            status='DRAFT_INCOMPLETE_NOT_PLAN_READY' if missing else 'DRAFT_PINS_UNCHECKED_NOT_PLAN_READY',
            missing_fields=missing, files_written=0, scientific_calls=0,
            actual_execution_authorized=False,
            note='Draft path performs no source census, plan production, grant or subject operation.')))
        return
    need(not missing, 'all exact pins/literal requirements required; no placeholder plans')
    need(args.root_review is not None, 'Root current metadata-only review required')
    review_pin = raw_pin(args.root_review)
    review = ordinary_json(review_pin)
    self_pin = raw_pin(Path(__file__).resolve())
    need(review.get('metadata_build_authorized') is True and
         review.get('actual_execution_authorized') is False and
         review.get('metadata_builder') == self_pin and review.get('source_bindings') == binding_pin,
         'exact Source+binding Root metadata authorization, never actual authority')
    oldclosure_pin = raw_pin(Path(PARENT) / 'runtime-closure-v1.json')
    oldclosure = ordinary_json(oldclosure_pin)
    olddecl_pin = raw_pin(Path(PARENT) / 'case-declaration-v1.json')
    base = ordinary_json(olddecl_pin)
    oldworker_pin = raw_pin(Path(PARENT) / 'plans-v1/worker-plans/finalization-integration-001-fixed-ROOT-20261019-v1.json')
    oldworker = ordinary_json(oldworker_pin)
    oldonce_pin = raw_pin(Path(PARENT) / 'plans-v1/false-once-plans/finalization-integration-001-fixed-ROOT-20261019-v1.json')
    oldonce = ordinary_json(oldonce_pin)
    need(raw_pin(Path(sys.executable).resolve()) == oldworker['python'] and
         sys.version_info[:2] == (3, 12), 'exact parent pinned Python3.12 metadata author')
    need(bindings['parent_runtime_closure'] == oldclosure_pin and
         bindings['parent_case_declaration'] == olddecl_pin and
         bindings['parent_worker_plan'] == oldworker_pin and
         bindings['parent_false_once_plan'] == oldonce_pin,
         'exact pinned complete production parent metadata')
    checked(MASTER); checked(CLAIM_DESIGN); checked(PRIOR_ENDPOINT)
    need(base['limits'] == LIMITS, 'original full scientific limits unchanged')
    need(base['evidence_profile'] == oldclosure['evidence_profile'], 'exact full evidence profile')
    profile = base['evidence_profile']
    need(profile['adapter_limits']['operations'] == 400000000 and
         profile['arena_limits']['work'] == 400000000 and
         profile['inverse_limits']['work'] == 30000000,
         'distinct unchanged400m/400m/30m evidence counters')
    sources = bindings['sources']
    need(set(sources) == {'cold', 'driver', 'runner', 'observer'}, 'four out-of-band Sources')
    for role, cli_path in [('cold', args.cold_source), ('driver', args.driver_source),
                           ('runner', args.runner_source), ('observer', args.observer_source)]:
        need(raw_pin(cli_path) == sources[role], 'exact CLI new ' + role + ' Source')
    project = dict(oldworker['project_sources'])
    replacements = bindings['project_replacements']
    need(set(replacements) == REPLACEMENTS, 'only three L project aliases may change')
    for name, source in replacements.items():
        checked(source)
        need(source != project[name], 'replacement Source must be explicit new pin: ' + name)
        project[name] = source
    components = dict(oldworker['components'])
    components['receiver_driver'] = sources['driver']
    evidence = copy.deepcopy(oldclosure['evidence_sources'])
    schema_sources = copy.deepcopy(oldclosure['schema_sources'])
    names = dict(project, semantic_receiver_driver=sources['driver'],
        bounded_request_oracle=components['bounded_transport'],
        owned_evidence_adapter=evidence['adapter'], exact_evidence_arena=evidence['arena'],
        owned_inventory_join=evidence['join'], independent_forest_inverse=evidence['inverse'])
    need(len(project) == 22 and len(components) == 2 and len(evidence) == 4 and
         len(names) == 28 and len(schema_sources) == 1 and not (set(names) & set(schema_sources)),
         'exact22+2+4+1 scientific alias inventory; no added role')
    aliases = dict(names, **schema_sources)
    need(len(aliases) == 29, 'exact29 scientific aliases')
    changed = REPLACEMENTS | {'semantic_receiver_driver'}
    need({k:v for k,v in names.items() if k not in changed} ==
         {k:v for k,v in oldclosure['materialized_aliases'].items() if k not in changed},
         'all other materialized aliases exact historical parent')
    trees, literal_maps = {}, {}
    for role, source in sources.items():
        trees[role], literal_maps[role] = literals(checked(source), source['path'])
    _, old_runner_literals = literals(checked(oldonce['runner']), oldonce['runner']['path'])
    need(old_runner_literals['LIMITS'] == RUNNER_LIMITS and
         literal_maps['runner']['LIMITS'] == old_runner_literals['LIMITS'],
         'newRunner literal LIMITS equals original outer limits exactly')
    expected_ordering_pins = dict(family_search=project['semantic_inventory_search_v2'],
        support_ordering=project['receptor_support_ordering_v1'],
        symbolic_control=project['quantified_symbolic_control_v2'])
    need(literal_maps['cold'].get('ORDERING_COMPONENT_SOURCES') == expected_ordering_pins and
         literal_maps['cold'].get('EVIDENCE_SOURCES') == evidence and
         literal_maps['cold'].get('SCHEMA_SOURCES') == schema_sources,
         'new cold exact three ordering pins and unchanged evidence/schema literal maps')
    requirements = bindings['literal_binding_requirements']
    need(type(requirements) is list and requirements, 'explicit actual literal binding requirements')
    literal_checks = []
    for request in requirements:
        need(set(request) == {'source_role', 'name', 'value'} and request['source_role'] in sources,
             'exact ordinary literal binding requirement')
        actual = literal_maps[request['source_role']].get(request['name'], object())
        need(actual == request['value'], 'current Source literal binding: ' + request['name'])
        literal_checks.append(request)
    need(any(x['source_role']=='cold' and x['value']==sources['driver'] for x in requirements) and
         any(x['source_role']=='runner' and x['value']==sources['cold'] for x in requirements),
         'coldDriver and runnerCold exact literal dependencies required')
    observer_constants = [n.value for n in ast.walk(trees['observer']) if isinstance(n, ast.Constant)]
    need(sources['runner']['sha256'] in observer_constants,
         'observer must contain current runner SHA literal; guard semantics remain current review')
    need(set(bindings['current_review_requirements']) == {'components', 'driver_cold', 'outer', 'prospective_four_subjects'},
         'distinct current review-role slots required')
    # Review *requirements* are ordinary scope strings, never forged receipts.
    need(all(type(v) is str and v for v in bindings['current_review_requirements'].values()),
         'current independent review requirements must be explicit')
    qualification = ordinary_json(FINITE_ADOPTION)
    need(qualification['finite_comparator_qualified'] is True and
         qualification['production_full_cold_qualified'] is False and
         qualification['mathematical_proof_accepted'] is False,
         'pre-adopted finite comparator only, no coldV9 production pass')
    inherited_source_receipts = bindings['inherited_source_receipts_context_only']
    need(type(inherited_source_receipts) is list and inherited_source_receipts,
         'explicit historical Source receipt references')
    for receipt in inherited_source_receipts:
        checked(receipt)
    checked(oldworker['python']); checked(oldworker['policy'])
    need(oldworker['policy']['bytes'] == 4502 and oldworker['policy']['sha256'] ==
         'f5f0c22121f4c503db319fe6e01c4c3a146ac9db9deb7e2ccec0aab1a2f32161',
         'same original4502-byte policy; no retraining/mining')
    for native in oldworker['native_inputs'].values():
        checked(native)  # Whole raw hashes only. Never parse/decode program or gzip.
    for source in oldworker['z3']['files']:
        checked(source)
    checked(oldworker['z3']['library']); checked(oldclosure['schema_kernel_source'])
    for entry in oldclosure['stdlib_entry_references'].values():
        if 'pin' in entry:
            checked(entry['pin'])
        for source in entry.get('pins', []):
            checked(source)
    corpus = ordinary_json(CAPSULE)
    selected = ordinary_json(SPEC)
    matches = [x for x in corpus['receivers'] if x['id'] == CASE_ID]
    need(len(matches)==1 and matches[0]==selected and selected['length']==12 and
         selected['instantiation_rounds']==2, 'exact full original006 assertion')
    census_modules = dict(aliases, __cold__=sources['cold'],
                          __runner__=sources['runner'], __observer__=sources['observer'])
    census, summary = make_census(census_modules, set(oldclosure['external_imports']))
    need(len(census)==32, '29 aliases plus cold/runner/observer raw census')
    direct_stdlib = stdlib_references(oldclosure['runtime']['stdlib_root'], summary['stdlib_roots'])
    # No AST site is promoted to complete resolution by the builder. Unknown
    # static/relative imports stop plan production; dynamic/global sites remain
    # fully recorded and pending independent Source/runtime review.
    need(not summary['unresolved_import_roots'] and not summary['relative_import_sites'],
         'unresolved static/relative import roots require new explicit scope review')
    pending = []

    def stage(path, value):
        raw = canonical(value)
        need(path.parent == root or root in path.parents, 'metadata path inside exact Root output')
        pending.append((path, raw))
        return describe(path, raw)

    clock = dict(worker_positive_boundary_seconds=180, later_outer_terminal_seconds=210,
        worker_scope='Positive work, complete result/evidence reading and known worker exit by180 monotonic seconds from parent Source entry.',
        outer_scope='Later resource/custody/EOF/group and external terminal by210; failure cleanup after deadline never admits a result.',
        memory='Conservative separate Darwin scientific worker+Native highwater sum, possible double counting; not180CPU or live aggregate RSS; controller/observer excluded.',
        failed_prefix='No complete result means no proof/resource admission. Failed Native/partial evidence/prefix cannot be rescued, replayed, relabelled positive or retried.',
        output=dict(result_bytes=134217728, stdout_bytes=4194304, stderr_bytes=4194304,
                    worker_receipt_bytes=4194304, runner_plan_bytes=16777216,
                    log_reserve_bytes=8388608, observer_metadata_reserved_bytes=1048576,
                    total_original_outer_reserve_bytes=9437184))
    closure = copy.deepcopy(oldclosure)
    historical_fields = {}
    for key in ('prerequisite_finalization_components', 'prerequisite_helper_qualification',
                'next_integration_design', 'inherited_role_bindings'):
        if key in closure:
            historical_fields[key] = closure.pop(key)
    closure.update(schema='ROOT-cluster-composer-runtime-closure-v1', author_identity=AUTHOR,
        cohort_owner_identity='/root', source_only=True, scientific_calls=0,
        actual_execution_authorized=False, scientific_acceptance=False,
        status='FALSE_METADATA_PINNED_PENDING_CURRENT_REVIEWS_NOT_RUNTIME_QUALIFIED',
        previous_full_production_closure=oldclosure_pin, current_master=MASTER,
        project_sources=project, additional_nonseed_components=components,
        materialized_aliases=names, schema_sources=schema_sources, evidence_sources=evidence,
        cold=sources['cold'], outer_sources=dict(runner=sources['runner'], observer=sources['observer']),
        current_scientific_alias_count=28, schema_extra_component_count=1,
        scientific_alias_total=29, Source_AST_census=census, current_import_census_summary=summary,
        new_direct_stdlib_entry_references=direct_stdlib,
        literal_Source_bindings_checked=literal_checks, source_bindings=binding_pin,
        metadata_only_Root_review=review_pin, metadata_builder=self_pin,
        metadata_authoring_python=oldworker['python'],
        claim_design=CLAIM_DESIGN, exposure_and_prior_endpoint=PRIOR_ENDPOINT,
        narrow_finite_comparator_prerequisite=dict(adoption=FINITE_ADOPTION,
            production_full_cold_qualified=False, full_cold_V9_production_pass_inherited=False,
            scope='Exactly pre-adopted finite V7 comparator helper; no new composer, proof, full-cold production retention/cost/fit or full006 authority.'),
        inherited_Source_receipts_context_only=inherited_source_receipts,
        historical_parent_review_and_qualification_fields_context_only=historical_fields,
        distinct_current_review_requirements=bindings['current_review_requirements'],
        clock_memory_output_authority=clock,
        inherited_role_bindings_scope='Historical context only, never a current Source review, plan grant or actual permission.',
        review_scope='Raw29alias+3outer AST and lexical-global census only. New support/point/symbolic Sources and Driver/cold/outer require distinct current review; no science evaluated.',
        full_pipeline_qualified=False, runtime_activation_authorized=False,
        loader_trust='Pinned interpreter/bundled stdlib, frozen/builtin precedence, recursive native/stdlib loader and OS remain conditional. Direct raw entries and AST imports are not a full origin/callable/runtime seal.',
        limitations=list(oldclosure['limitations']) + [
            'New generic composer may discover a word; GCTS validates/schedules it. Both finite consumers receive the same proposal design and full fallback; no RL or advantage claim.',
            'EMPTY root seeds, once per charged cold actual; no CURRENT_JUSTIFIED_FACT reification, dynamic recomposition or cross-arm cached proof.',
            'All unresolved dynamic and global references are explicit. Syntactic bindings do not prove runtime origin or absence of loader mutation.',
            'Finite comparator and historical Source reviews do not establish current coldV9/006 production success.'])
    closure_pin = stage(root / 'runtime-closure-v1.json', closure)
    schedule = []
    for ordering in ('and_support', 'composed_support'):
        for mode in ('fixed', 'symbolic'):
            invocation = 'quantified-composer-006-' + mode + '-' + ordering.replace('_','-') + '-ROOT-20261019-v1'
            schedule.append(dict(order=len(schedule)+1, invocation_id=invocation,
                mode=mode, search_ordering=ordering, inventory_certification_mode='schema_then_native',
                model_storage='literal_interned', result_reader='interned', receiver_id=CASE_ID,
                actual_directory=str(root / ('actual-' + mode + '-' + ordering.replace('_','-') + '-v1'))))
    planroot = root / 'plans-v1'
    need(not planroot.exists() and not planroot.is_symlink(), 'fresh false-plan namespace only')
    for row in schedule:
        actual = Path(row['actual_directory'])
        terminal = planroot / 'false-once-plans' / (row['invocation_id'] + '-terminal-observation')
        need(not actual.exists() and not actual.is_symlink() and
             not terminal.exists() and not terminal.is_symlink(), 'actual/terminal paths remain absent')
    declaration = copy.deepcopy(base)
    declaration.update(schema='ROOT-quantified-composer-four-arm-declaration-v1',
        author_identity=AUTHOR, cohort_owner_identity='/root', source_only=True,
        scientific_calls=0, actual_execution_authorized=False, goal_complete=False,
        status='FALSE_SUBJECTS_ONLY_PENDING_DISTINCT_CURRENT_REVIEWS',
        parent_instrumentation_declaration=olddecl_pin, current_master=MASTER,
        runtime_closure=closure_pin, selected_receiver_id=CASE_ID, selected_receiver=selected,
        input_capsule=CAPSULE, schedule=schedule, current_sources=sources,
        claim_design=CLAIM_DESIGN, prior_endpoint=PRIOR_ENDPOINT,
        changed_profile='Generic empty-root family composition offered identically to fixed/symbolic consumers; explicit composed_support versus unchanged and_support. Fresh4arm Source-matched design, not faster-output repaint of old UNKNOWNs.',
        scope='Exposed unresolved quantified006 development continuation. Standalone planner may discover; GCTS validates/schedules; no new theorem, RL, causal speedup or GCTS-specific advantage claim.',
        composer_policy='ROOT only; EMPTY seeds; once per charged arm; no current-fact reification or cached shared word. Full legal12-row word or abstain; independent guards/ordered ports/Native/point gates; unchanged scheduler, complete fallback and symbolic iterator/reference multiplicity.',
        distinct_current_review_requirements=bindings['current_review_requirements'],
        clock_memory_output_authority=clock,
        failure_policy='Retain all UNKNOWN, composer abstention, errors and full-profile failures. No failed prefix rescue, target route, helper axiom, altered horizon/catalog, cap rise, consumed retry or inherited production pass.',
        success_reporting='Actual whole fresh Native proof, complete exact point/output/resources/custody, essential primitive quantifier/family ancestry and exact composed-hint use are separate endpoints. Old4UNKNOWN context only, not a causal speed baseline.')
    declaration_pin = stage(root / 'case-declaration-v1.json', declaration)
    plans = []
    for row in schedule:
        worker = dict(oldworker)
        worker.update({k:v for k,v in row.items() if k!='order'})
        worker.update(cold=sources['cold'], project_sources=project, components=components,
            declaration=CAPSULE, runtime_closure=closure_pin, integration_declaration=declaration_pin)
        need(set(worker)==set(oldworker), 'exact inherited worker plan fields')
        worker_pin = stage(planroot / 'worker-plans' / (row['invocation_id']+'.json'), worker)
        once = dict(oldonce)
        once.update({k:v for k,v in row.items() if k!='order'})
        once.update(runner=sources['runner'], observer=sources['observer'], cold=sources['cold'],
            worker_plan=worker_pin, integration_declaration=declaration_pin,
            runtime_closure=closure_pin, authorization=dict(FALSE_AUTHORIZATION),
            limits=dict(RUNNER_LIMITS), environment={'PYTHONHASHSEED':'0','LC_ALL':'C','LANG':'C'})
        need(set(once)==set(oldonce), 'exact inherited once-plan fields; sentinel only')
        once_pin = stage(planroot / 'false-once-plans' / (row['invocation_id']+'.json'), once)
        plans.append(dict(row=row, worker_plan=worker_pin, false_once_plan=once_pin))
    manifest = stage(root / 'false-plan-manifest-v1.json', dict(
        schema='ROOT-quantified-composer-false-manifest-v1', author_identity=AUTHOR,
        scientific_calls=0, actual_execution_authorized=False, source_only=True,
        status='FALSE_PLANS_PINNED_PENDING_CURRENT_SOURCE_AND_PROSPECTIVE_REVIEWS',
        declaration=declaration_pin, runtime_closure=closure_pin, plans=plans,
        metadata_builder=self_pin, source_bindings=binding_pin, metadata_only_Root_review=review_pin,
        scientific_aliases=29, census_sources=32, no_actual_or_terminal_directory_created=True,
        no_grant_created=True, full_pipeline_qualified=False,
        pending='Distinct current component/Driver-cold/outer/prospective4subject review, scope adoption and fresh grants/final delta/all peers idle remain Root obligations. Sentinel authorization deliberately unlaunchable.'))
    # All metadata/absence work above precedes writes. Exclusive writes can leave
    # only an incomplete metadata prefix on I/O failure; no successful completion
    # result is printed unless every exact emitted byte is checked below.
    for path, raw in pending:
        need(not path.exists() and not path.is_symlink(), 'exclusive new metadata: '+str(path))
    for path, raw in pending:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
        need(raw_pin(path)==describe(path, raw), 'whole emitted metadata bytes')
    print(json.dumps(dict(schema='composer-false-metadata-build-result-v1',
        status='FALSE_PLANS_PINNED_PENDING_DISTINCT_CURRENT_REVIEWS', manifest=manifest,
        closure=closure_pin, declaration=declaration_pin, files=len(pending),
        scientific_calls=0, actual_execution_authorized=False,
        unresolved_global_reference_count=len(summary['unresolved_global_references']),
        nonliteral_dynamic_site_count=len(summary['nonliteral_dynamic_sites']),
        source_or_loader_closure_proved=False, full_pipeline_qualified=False)))


if __name__ == '__main__':
    main(sys.argv[1:])
