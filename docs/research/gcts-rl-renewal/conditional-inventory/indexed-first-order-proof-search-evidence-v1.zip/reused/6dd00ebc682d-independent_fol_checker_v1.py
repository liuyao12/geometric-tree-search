"""Independent classical one-sorted FOL certificate checker, with equality.

Only supplied closed finite theory axioms are trusted. This is not a PA axiom
recognizer, theorem searcher, typed geometry kernel, or finite Wang compiler.
No legacy/project imports, IO, callbacks, executable payloads, or module calls.
"""

VERSION = 'GCTS-INDEPENDENT-CLASSICAL-FOL-CHECKER-v1'
SCHEMA = 'GCTS-independent-FOL-check-receipt-v1'
_SCOPE = ('Derivability from exactly supplied closed finite theory axioms in '
          'classical one-sorted FOL with equality. No theory-membership, '
          'consistency, automatic-discovery, typed-geometry, or Wang claim.')
_RULE_FIELDS = (
    ('axiom', ('rule', 'formula', 'name')),
    ('tautology', ('rule', 'formula')),
    ('refl', ('rule', 'formula')),
    ('instantiate', ('rule', 'formula', 'universal', 'term')),
    ('distribute', ('rule', 'formula', 'variable', 'antecedent', 'consequent')),
    ('eq_subst', ('rule', 'formula', 'variable', 'template', 'left', 'right')),
    ('mp', ('rule', 'formula', 'antecedent', 'implication')),
    ('generalize', ('rule', 'formula', 'source', 'variable')),
)
_LIMIT_FIELDS = ('max_operations', 'max_depth', 'max_proof_lines')


class _Invalid(Exception):
    pass


class _Limit(Exception):
    pass


class _Budget:
    def __init__(self, limits):
        self.limits = dict(limits)
        self.operations = 0
        self.max_depth_seen = 0
        self.by_kind = {}
        self.atoms_max = 0
        self.assignments = 0
        self.rules = {name: 0 for name, fields in _RULE_FIELDS}
        self.checked = 0
        self.line = None

    def visit(self, kind, depth=1, units=1):
        self.max_depth_seen = max(self.max_depth_seen, depth)
        if depth > self.limits['max_depth']:
            raise _Limit('DEPTH_LIMIT')
        if units > self.limits['max_operations'] - self.operations:
            raise _Limit('OPERATION_LIMIT')
        self.operations += units
        self.by_kind[kind] = self.by_kind.get(kind, 0) + units


def _limits(value):
    if type(value) is not dict or len(value) != 3:
        raise _Invalid('INVALID_LIMITS')
    if any(type(key) is not str for key in value):
        raise _Invalid('INVALID_LIMITS')
    if set(value) != set(_LIMIT_FIELDS):
        raise _Invalid('INVALID_LIMITS')
    if any(type(value[key]) is not int or value[key] < 1 for key in _LIMIT_FIELDS):
        raise _Invalid('INVALID_LIMITS')
    return {key: value[key] for key in _LIMIT_FIELDS}


def _name(value, budget, depth):
    budget.visit('identifier', depth)
    if type(value) is not str:
        raise _Invalid('IDENTIFIER_TYPE')
    budget.visit('identifier', depth, len(value))
    if not value:
        raise _Invalid('EMPTY_IDENTIFIER')
    return value


def _fields(value, expected, budget, depth):
    budget.visit('grammar', depth)
    if type(value) is not dict:
        raise _Invalid('RECORD_TYPE')
    for key in value:
        _name(key, budget, depth)
    if len(value) != len(expected) or any(key not in value for key in expected):
        raise _Invalid('RECORD_FIELDS')


def _keys(value, budget, depth):
    budget.visit('grammar', depth)
    if type(value) is not dict:
        raise _Invalid('SIGNATURE_MAP_TYPE')
    keys = []
    for key in value:
        keys.append(_name(key, budget, depth))
    budget.visit('ordering', depth, len(keys) * max(1, len(keys).bit_length()))
    return sorted(keys)


def _signature(value, budget):
    result = {}
    for key in _keys(value, budget, 1):
        budget.visit('grammar')
        arity = value[key]
        if type(arity) is not int or arity < 0:
            raise _Invalid('ARITY_TYPE_OR_RANGE')
        result[key] = arity
    return result


def _term(value, functions, budget, depth=1):
    budget.visit('grammar', depth)
    if type(value) is not list or not value:
        raise _Invalid('TERM_ARRAY')
    tag = _name(value[0], budget, depth)
    if tag == 'var' and len(value) == 2:
        return ('var', _name(value[1], budget, depth))
    if tag != 'fun' or len(value) != 3:
        raise _Invalid('TERM_SHAPE')
    symbol = _name(value[1], budget, depth)
    args = value[2]
    if type(args) is not list:
        raise _Invalid('TERM_ARGUMENT_ARRAY')
    if symbol not in functions or functions[symbol] != len(args):
        raise _Invalid('FUNCTION_OR_ARITY')
    return ('fun', symbol, tuple(_term(x, functions, budget, depth + 1) for x in args))


def _formula(value, functions, predicates, budget, depth=1):
    budget.visit('grammar', depth)
    if type(value) is not list or not value:
        raise _Invalid('FORMULA_ARRAY')
    tag = _name(value[0], budget, depth)
    if tag == 'bot' and len(value) == 1:
        return ('bot',)
    if tag == 'eq' and len(value) == 3:
        return ('eq', _term(value[1], functions, budget, depth + 1),
                _term(value[2], functions, budget, depth + 1))
    if tag == 'pred' and len(value) == 3:
        symbol = _name(value[1], budget, depth)
        args = value[2]
        if type(args) is not list:
            raise _Invalid('PREDICATE_ARGUMENT_ARRAY')
        if symbol not in predicates or predicates[symbol] != len(args):
            raise _Invalid('PREDICATE_OR_ARITY')
        return ('pred', symbol, tuple(_term(x, functions, budget, depth + 1) for x in args))
    if tag == 'all' and len(value) == 3:
        variable = _name(value[1], budget, depth)
        return ('all', variable, _formula(value[2], functions, predicates, budget, depth + 1))
    if tag == 'not' and len(value) == 2:
        return ('not', _formula(value[1], functions, predicates, budget, depth + 1))
    if tag in ('and', 'or', 'imp') and len(value) == 3:
        return (tag, _formula(value[1], functions, predicates, budget, depth + 1),
                _formula(value[2], functions, predicates, budget, depth + 1))
    raise _Invalid('FORMULA_SHAPE')


def _term_free(term, budget, depth=1):
    budget.visit('free_variable', depth)
    if term[0] == 'var':
        return {term[1]}
    result = set()
    for child in term[2]:
        result.update(_term_free(child, budget, depth + 1))
    return result


def _free(formula, budget, depth=1):
    budget.visit('free_variable', depth)
    tag = formula[0]
    if tag == 'bot':
        return set()
    if tag == 'eq':
        return (_term_free(formula[1], budget, depth + 1) |
                _term_free(formula[2], budget, depth + 1))
    if tag == 'pred':
        result = set()
        for term in formula[2]:
            result.update(_term_free(term, budget, depth + 1))
        return result
    if tag == 'all':
        return _free(formula[2], budget, depth + 1) - {formula[1]}
    if tag == 'not':
        return _free(formula[1], budget, depth + 1)
    return _free(formula[1], budget, depth + 1) | _free(formula[2], budget, depth + 1)


def _names(formula, budget, depth=1):
    budget.visit('all_variable_names', depth)
    tag = formula[0]
    if tag in ('eq', 'pred', 'bot'):
        return _free(formula, budget, depth)
    if tag == 'all':
        return {formula[1]} | _names(formula[2], budget, depth + 1)
    if tag == 'not':
        return _names(formula[1], budget, depth + 1)
    return _names(formula[1], budget, depth + 1) | _names(formula[2], budget, depth + 1)


def _term_replace(term, variable, replacement, budget, depth=1):
    budget.visit('substitution', depth)
    if term[0] == 'var':
        return replacement if term[1] == variable else term
    return ('fun', term[1], tuple(_term_replace(x, variable, replacement, budget, depth + 1)
                                  for x in term[2]))


def _rename_bound(formula, old, fresh, budget, depth=1):
    """Rename occurrences bound by the enclosing binder, stopping at shadows."""
    budget.visit('renaming', depth)
    tag = formula[0]
    if tag == 'bot':
        return formula
    if tag == 'eq':
        return ('eq', _term_replace(formula[1], old, ('var', fresh), budget, depth + 1),
                _term_replace(formula[2], old, ('var', fresh), budget, depth + 1))
    if tag == 'pred':
        return ('pred', formula[1], tuple(_term_replace(t, old, ('var', fresh), budget, depth + 1)
                                          for t in formula[2]))
    if tag == 'all':
        if formula[1] == old:
            return formula
        return ('all', formula[1], _rename_bound(formula[2], old, fresh, budget, depth + 1))
    if tag == 'not':
        return ('not', _rename_bound(formula[1], old, fresh, budget, depth + 1))
    return (tag, _rename_bound(formula[1], old, fresh, budget, depth + 1),
            _rename_bound(formula[2], old, fresh, budget, depth + 1))


def _substitute(formula, variable, replacement, replacement_free, budget, depth=1):
    budget.visit('substitution', depth)
    tag = formula[0]
    if tag == 'bot':
        return formula
    if tag == 'eq':
        return ('eq', _term_replace(formula[1], variable, replacement, budget, depth + 1),
                _term_replace(formula[2], variable, replacement, budget, depth + 1))
    if tag == 'pred':
        return ('pred', formula[1], tuple(_term_replace(t, variable, replacement, budget, depth + 1)
                                          for t in formula[2]))
    if tag == 'all':
        binder, body = formula[1], formula[2]
        if binder == variable or variable not in _free(body, budget, depth + 1):
            return formula
        if binder in replacement_free:
            used = _names(body, budget, depth + 1) | replacement_free | {variable, binder}
            number = 0
            while True:
                budget.visit('fresh_name', depth)
                fresh = '__fol_fresh_' + str(number)
                _name(fresh, budget, depth)
                if fresh not in used:
                    break
                number += 1
            body = _rename_bound(body, binder, fresh, budget, depth + 1)
            binder = fresh
        return ('all', binder, _substitute(body, variable, replacement,
                                          replacement_free, budget, depth + 1))
    if tag == 'not':
        return ('not', _substitute(formula[1], variable, replacement,
                                  replacement_free, budget, depth + 1))
    return (tag, _substitute(formula[1], variable, replacement, replacement_free, budget, depth + 1),
            _substitute(formula[2], variable, replacement, replacement_free, budget, depth + 1))


def _term_key(term, environment, budget, depth=1):
    budget.visit('alpha_key', depth)
    if term[0] == 'var':
        for index, binder in enumerate(reversed(environment)):
            budget.visit('binding_lookup', depth)
            if binder == term[1]:
                return ('bound', index)
        return ('free', term[1])
    return ('fun', term[1], tuple(_term_key(t, environment, budget, depth + 1) for t in term[2]))


def _alpha(formula, environment, budget, depth=1):
    budget.visit('alpha_key', depth)
    tag = formula[0]
    if tag == 'bot':
        return formula
    if tag == 'eq':
        return ('eq', _term_key(formula[1], environment, budget, depth + 1),
                _term_key(formula[2], environment, budget, depth + 1))
    if tag == 'pred':
        return ('pred', formula[1], tuple(_term_key(t, environment, budget, depth + 1)
                                          for t in formula[2]))
    if tag == 'all':
        return ('all', _alpha(formula[2], environment + (formula[1],), budget, depth + 1))
    if tag == 'not':
        return ('not', _alpha(formula[1], environment, budget, depth + 1))
    return (tag, _alpha(formula[1], environment, budget, depth + 1),
            _alpha(formula[2], environment, budget, depth + 1))


def _tree_equal(left, right, budget):
    pending = [(left, right, 1)]
    while pending:
        a, b, depth = pending.pop()
        budget.visit('equality', depth)
        if type(a) is not type(b):
            return False
        if type(a) is tuple:
            if len(a) != len(b):
                return False
            for x, y in reversed(tuple(zip(a, b))):
                pending.append((x, y, depth + 1))
        else:
            if type(a) is str:
                budget.visit('equality', depth, len(a) + len(b))
            if a != b:
                return False
    return True


def _equivalent(left, right, budget):
    return _tree_equal(_alpha(left, (), budget), _alpha(right, (), budget), budget)


def _skeleton(formula, atoms, budget, depth=1):
    budget.visit('tautology_skeleton', depth)
    tag = formula[0]
    if tag == 'bot':
        return ('bot',)
    if tag == 'not':
        return ('not', _skeleton(formula[1], atoms, budget, depth + 1))
    if tag in ('and', 'or', 'imp'):
        return (tag, _skeleton(formula[1], atoms, budget, depth + 1),
                _skeleton(formula[2], atoms, budget, depth + 1))
    key = _alpha(formula, (), budget)
    for index, old in enumerate(atoms):
        budget.visit('tautology_atom_comparison', depth)
        if _tree_equal(key, old, budget):
            return ('atom', index)
    atoms.append(key)
    budget.atoms_max = max(budget.atoms_max, len(atoms))
    return ('atom', len(atoms) - 1)


def _truth(skeleton, values, budget, depth=1):
    budget.visit('tautology_truth', depth)
    tag = skeleton[0]
    if tag == 'bot':
        return False
    if tag == 'atom':
        return values[skeleton[1]]
    if tag == 'not':
        return not _truth(skeleton[1], values, budget, depth + 1)
    if tag == 'imp':
        return (not _truth(skeleton[1], values, budget, depth + 1) or
                _truth(skeleton[2], values, budget, depth + 1))
    if tag == 'and':
        return (_truth(skeleton[1], values, budget, depth + 1) and
                _truth(skeleton[2], values, budget, depth + 1))
    return (_truth(skeleton[1], values, budget, depth + 1) or
            _truth(skeleton[2], values, budget, depth + 1))


def _tautology(formula, budget):
    atoms = []
    skeleton = _skeleton(formula, atoms, budget)
    budget.visit('tautology_assignment', 1, len(atoms))
    values = [False] * len(atoms)
    while True:
        budget.visit('tautology_assignment')
        budget.assignments += 1
        if not _truth(skeleton, values, budget):
            return False
        index = len(values) - 1
        while index >= 0:
            budget.visit('tautology_counter')
            if not values[index]:
                values[index] = True
                break
            values[index] = False
            index -= 1
        if index < 0:
            return True


def _prior(value, formulas, budget):
    budget.visit('reference')
    if type(value) is not int or not 0 <= value < len(formulas):
        raise _Invalid('PRIOR_REFERENCE')
    return formulas[value]


def _line(value, functions, predicates, formulas, budget):
    budget.visit('grammar')
    if type(value) is not dict:
        raise _Invalid('PROOF_LINE_RECORD')
    # Reject non-string keys before membership/lookup can compare arbitrary objects.
    for key in value:
        _name(key, budget, 1)
    if 'rule' not in value:
        raise _Invalid('RECORD_FIELDS')
    rule = _name(value['rule'], budget, 1)
    expected = None
    for name, fields in _RULE_FIELDS:
        budget.visit('rule_lookup')
        if name == rule:
            expected = fields
            break
    if expected is None:
        raise _Invalid('UNKNOWN_RULE')
    _fields(value, expected, budget, 1)
    formula = _formula(value['formula'], functions, predicates, budget)
    params = {}
    if rule == 'axiom':
        params['name'] = _name(value['name'], budget, 1)
    elif rule == 'instantiate':
        params['universal'] = _formula(value['universal'], functions, predicates, budget)
        params['term'] = _term(value['term'], functions, budget)
    elif rule == 'distribute':
        params['variable'] = _name(value['variable'], budget, 1)
        for key in ('antecedent', 'consequent'):
            params[key] = _formula(value[key], functions, predicates, budget)
    elif rule == 'eq_subst':
        params['variable'] = _name(value['variable'], budget, 1)
        params['template'] = _formula(value['template'], functions, predicates, budget)
        for key in ('left', 'right'):
            params[key] = _term(value[key], functions, budget)
    elif rule == 'mp':
        params['antecedent'] = _prior(value['antecedent'], formulas, budget)
        params['implication'] = _prior(value['implication'], formulas, budget)
    elif rule == 'generalize':
        params['variable'] = _name(value['variable'], budget, 1)
        params['source'] = _prior(value['source'], formulas, budget)
    return rule, formula, params


def _rule(rule, formula, params, axioms, budget):
    budget.rules[rule] += 1
    budget.visit('rule')
    if rule == 'axiom':
        if params['name'] not in axioms:
            raise _Invalid('UNKNOWN_AXIOM')
        return _equivalent(formula, axioms[params['name']], budget)
    if rule == 'tautology':
        return _tautology(formula, budget)
    if rule == 'refl':
        return formula[0] == 'eq' and _tree_equal(formula[1], formula[2], budget)
    if rule == 'instantiate':
        universal = params['universal']
        if universal[0] != 'all':
            return False
        term = params['term']
        instance = _substitute(universal[2], universal[1], term, _term_free(term, budget), budget)
        return _equivalent(formula, ('imp', universal, instance), budget)
    if rule == 'distribute':
        variable, p, q = params['variable'], params['antecedent'], params['consequent']
        if variable in _free(p, budget):
            raise _Invalid('DISTRIBUTE_FRESHNESS')
        expected = ('imp', ('all', variable, ('imp', p, q)),
                    ('imp', p, ('all', variable, q)))
        return _equivalent(formula, expected, budget)
    if rule == 'eq_subst':
        variable, template = params['variable'], params['template']
        left, right = params['left'], params['right']
        a = _substitute(template, variable, left, _term_free(left, budget), budget)
        b = _substitute(template, variable, right, _term_free(right, budget), budget)
        return _equivalent(formula, ('imp', ('eq', left, right), ('imp', a, b)), budget)
    if rule == 'mp':
        implication = params['implication']
        return (implication[0] == 'imp' and
                _equivalent(implication[1], params['antecedent'], budget) and
                _equivalent(implication[2], formula, budget))
    return _equivalent(formula, ('all', params['variable'], params['source']), budget)


def _receipt(budget, status, reason):
    return {'schema': SCHEMA, 'status': status, 'reason': reason,
            'error_line': None if budget is None else budget.line,
            'checked_lines': 0 if budget is None else budget.checked,
            'rule_counts': ({name: 0 for name, fields in _RULE_FIELDS} if budget is None
                            else dict(budget.rules)),
            'visits': {'operations': 0 if budget is None else budget.operations,
                       'max_depth_seen': 0 if budget is None else budget.max_depth_seen,
                       'by_kind': {} if budget is None else dict(budget.by_kind),
                       'tautology_atoms_max': 0 if budget is None else budget.atoms_max,
                       'tautology_assignments': 0 if budget is None else budget.assignments},
            'limits': None if budget is None else dict(budget.limits), 'scope': _SCOPE}


def check(theory, proof, target, limits):
    """Check one whole proof; no prefix of REJECTED/UNKNOWN is admitted."""
    budget = None
    try:
        validated_limits = _limits(limits)
        budget = _Budget(validated_limits)
        _fields(theory, ('functions', 'predicates', 'axioms'), budget, 1)
        functions = _signature(theory['functions'], budget)
        predicates = _signature(theory['predicates'], budget)
        axioms = {}
        for name in _keys(theory['axioms'], budget, 1):
            formula = _formula(theory['axioms'][name], functions, predicates, budget)
            if _free(formula, budget):
                raise _Invalid('OPEN_THEORY_AXIOM')
            axioms[name] = formula
        target_formula = _formula(target, functions, predicates, budget)
        budget.visit('grammar')
        if type(proof) is not list:
            raise _Invalid('PROOF_ARRAY')
        if not proof:
            raise _Invalid('EMPTY_PROOF')
        if len(proof) > budget.limits['max_proof_lines']:
            raise _Limit('PROOF_LINE_LIMIT')
        formulas = []
        for index, line in enumerate(proof):
            budget.line = index
            rule, formula, params = _line(line, functions, predicates, formulas, budget)
            if not _rule(rule, formula, params, axioms, budget):
                raise _Invalid('RULE_FORMULA_MISMATCH')
            formulas.append(formula)
            budget.checked += 1
        budget.line = None
        budget.visit('target')
        if not _equivalent(formulas[-1], target_formula, budget):
            raise _Invalid('FINAL_TARGET_MISMATCH')
        return _receipt(budget, 'VERIFIED', 'WHOLE_PROOF_VERIFIED')
    except _Invalid as error:
        return _receipt(budget, 'REJECTED', str(error))
    except _Limit as error:
        return _receipt(budget, 'UNKNOWN_BUDGET', str(error))
    except RecursionError:
        return _receipt(budget, 'UNKNOWN_BUDGET', 'HOST_RECURSION_LIMIT')
    except MemoryError:
        return _receipt(budget, 'UNKNOWN_BUDGET', 'HOST_MEMORY_LIMIT')
