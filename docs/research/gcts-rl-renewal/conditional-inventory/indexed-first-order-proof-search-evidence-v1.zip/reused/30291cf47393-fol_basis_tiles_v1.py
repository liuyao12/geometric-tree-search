"""Finite input-derived Hilbert-eight schema catalogue and unit point tiles.

Pure compiler/decoder only. No proof search, external certificate, imports of
project code, IO, or calls at module scope. COMPLETE means this declared finite
catalogue is complete, not that bounded first-order logic is complete.
"""
import json
import math
import time

VERSION = 'U-FINITE-HILBERT8-BASIS-v1'
_SCOPE = ('Finite exact-literal Hilbert-eight basis/schema and strict earlier-reference '
          'slot universe only; no full FOL, PA, Hilbert-geometry, Wang, or RL claim. '
          'A selected certificate still requires actual native and independent checking.')


class InputError(ValueError):
    """Malformed public input; never a proof of nonderivability."""


class _Stop(Exception):
    pass


class _Budget:
    def __init__(self, limits, started):
        self.limits = limits
        self.started = started
        self.work = 0
        self.terms = 0
        self.formulas = 0
        self.instances = 0
        self.candidates = 0

    def tick(self, units=1, depth=0):
        if depth > self.limits['max_depth']:
            raise _Stop('DEPTH_LIMIT')
        if units > self.limits['max_work'] - self.work:
            raise _Stop('WORK_LIMIT')
        self.work += units
        if time.perf_counter() - self.started >= self.limits['wall_seconds']:
            raise _Stop('WALL_LIMIT')

    def costs(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.started,
                'terms': self.terms, 'formulas': self.formulas,
                'instances': self.instances, 'candidates': self.candidates}


def _fields(value, fields):
    if (type(value) is not dict or len(value) != len(fields) or
            any(type(k) is not str for k in value) or set(value) != set(fields)):
        raise InputError('RECORD_FIELDS')


def _limits(value):
    bounds = {'max_work': 1000000000, 'max_candidates': 1000000,
              'max_basis': 100000, 'max_instances': 100000, 'max_depth': 128}
    _fields(value, tuple(bounds) + ('wall_seconds',))
    wall = value['wall_seconds']
    if (type(wall) not in (int, float) or not math.isfinite(wall) or
            wall <= 0 or wall > 60):
        raise InputError('WALL_SECONDS')
    for key, upper in bounds.items():
        if type(value[key]) is not int or not 0 <= value[key] <= upper:
            raise InputError('LIMIT_INTEGER')
    return dict(value)


def _name(value, budget):
    budget.tick()
    if type(value) is not str or not 1 <= len(value) <= 64:
        raise InputError('NAME_TYPE_OR_LENGTH')
    budget.tick(len(value))
    if any(ord(c) < 32 or ord(c) > 126 for c in value):
        raise InputError('NAME_ASCII')
    return value


def _signature(value, budget):
    budget.tick()
    if type(value) is not dict:
        raise InputError('SIGNATURE')
    result = {}
    for name, arity in value.items():
        _name(name, budget)
        if type(arity) is not int or arity < 0:
            raise InputError('ARITY')
        result[name] = arity
    budget.tick(len(result) * max(1, len(result).bit_length()))
    return {name: result[name] for name in sorted(result)}


def _term(value, functions, budget, depth=1):
    budget.tick(1, depth)
    if type(value) is not list or not value or type(value[0]) is not str:
        raise InputError('TERM')
    if value[0] == 'var' and len(value) == 2:
        return ('var', _name(value[1], budget))
    if value[0] != 'fun' or len(value) != 3:
        raise InputError('TERM_SHAPE')
    name = _name(value[1], budget)
    if (type(value[2]) is not list or name not in functions or
            len(value[2]) != functions[name]):
        raise InputError('FUNCTION_ARITY')
    budget.tick(len(value[2]), depth)
    return ('fun', name, tuple(_term(x, functions, budget, depth + 1) for x in value[2]))


def _formula(value, functions, predicates, budget, depth=1):
    budget.tick(1, depth)
    if type(value) is not list or not value or type(value[0]) is not str:
        raise InputError('FORMULA')
    tag = value[0]
    if tag == 'bot' and len(value) == 1:
        return ('bot',)
    if tag == 'eq' and len(value) == 3:
        return ('eq', _term(value[1], functions, budget, depth + 1),
                _term(value[2], functions, budget, depth + 1))
    if tag == 'pred' and len(value) == 3:
        name = _name(value[1], budget)
        if (type(value[2]) is not list or name not in predicates or
                len(value[2]) != predicates[name]):
            raise InputError('PREDICATE_ARITY')
        budget.tick(len(value[2]), depth)
        return ('pred', name, tuple(_term(x, functions, budget, depth + 1) for x in value[2]))
    if tag == 'all' and len(value) == 3:
        return ('all', _name(value[1], budget),
                _formula(value[2], functions, predicates, budget, depth + 1))
    if tag == 'not' and len(value) == 2:
        return ('not', _formula(value[1], functions, predicates, budget, depth + 1))
    if tag in ('and', 'or', 'imp') and len(value) == 3:
        return (tag, _formula(value[1], functions, predicates, budget, depth + 1),
                _formula(value[2], functions, predicates, budget, depth + 1))
    raise InputError('FORMULA_SHAPE')


def _wire(value, budget, depth=0):
    """Charged detached JSON copy; immutable internal AST tuples become arrays."""
    budget.tick(1, depth)
    if type(value) is str:
        budget.tick(2 + 12 * len(value), depth)
        return value
    if type(value) in (int, float, bool) or value is None:
        return value
    if type(value) in (tuple, list):
        budget.tick(len(value), depth)
        return [_wire(x, budget, depth + 1) for x in value]
    if type(value) is dict:
        budget.tick(len(value), depth)
        return {k: _wire(v, budget, depth + 1) for k, v in value.items()}
    raise InputError('NON_JSON_VALUE')


def _key(value, budget):
    wire = _wire(value, budget)
    result = json.dumps(wire, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False)
    budget.tick(len(result))
    return result


def _ordered(values, budget):
    budget.tick(len(values) * max(1, len(values).bit_length()))
    return [values[k] for k in sorted(values)]


def _term_free(term, budget, depth=1):
    budget.tick(1, depth)
    if term[0] == 'var':
        return {term[1]}
    result = set()
    for child in term[2]:
        result.update(_term_free(child, budget, depth + 1))
    return result


def _free(formula, budget, depth=1, all_names=False):
    budget.tick(1, depth)
    tag = formula[0]
    if tag == 'bot':
        return set()
    if tag == 'eq':
        return _term_free(formula[1], budget, depth + 1) | _term_free(formula[2], budget, depth + 1)
    if tag == 'pred':
        result = set()
        for term in formula[2]:
            result.update(_term_free(term, budget, depth + 1))
        return result
    if tag == 'all':
        names = _free(formula[2], budget, depth + 1, all_names)
        return names | {formula[1]} if all_names else names - {formula[1]}
    if tag == 'not':
        return _free(formula[1], budget, depth + 1, all_names)
    return (_free(formula[1], budget, depth + 1, all_names) |
            _free(formula[2], budget, depth + 1, all_names))


def _replace_term(term, variable, replacement, budget, depth=1):
    budget.tick(1, depth)
    if term[0] == 'var':
        return replacement if term[1] == variable else term
    return ('fun', term[1], tuple(_replace_term(t, variable, replacement, budget, depth + 1)
                                  for t in term[2]))


def _subst(formula, variable, replacement, budget, depth=1):
    """Independent hygienic substitution with the native checker's freshN spelling."""
    budget.tick(1, depth)
    tag = formula[0]
    if tag == 'bot':
        return formula
    if tag == 'eq':
        return ('eq', _replace_term(formula[1], variable, replacement, budget, depth + 1),
                _replace_term(formula[2], variable, replacement, budget, depth + 1))
    if tag == 'pred':
        return ('pred', formula[1], tuple(_replace_term(t, variable, replacement, budget, depth + 1)
                                          for t in formula[2]))
    if tag == 'all':
        name, body = formula[1], formula[2]
        if name == variable or variable not in _free(body, budget):
            return formula
        replacement_free = _term_free(replacement, budget)
        if name in replacement_free:
            occupied = _free(body, budget, all_names=True) | replacement_free | {variable, name}
            index = 0
            fresh = 'fresh0'
            while fresh in occupied:
                budget.tick()
                index += 1
                fresh = 'fresh' + str(index)
            body = _subst(body, name, ('var', fresh), budget, depth + 1)
            name = fresh
        return ('all', name, _subst(body, variable, replacement, budget, depth + 1))
    if tag == 'not':
        return ('not', _subst(formula[1], variable, replacement, budget, depth + 1))
    return (tag, _subst(formula[1], variable, replacement, budget, depth + 1),
            _subst(formula[2], variable, replacement, budget, depth + 1))


def _children(formula):
    if formula[0] == 'all':
        return (formula[2],)
    if formula[0] == 'not':
        return (formula[1],)
    if formula[0] in ('and', 'or', 'imp'):
        return (formula[1], formula[2])
    return ()


def _add_formula(formula, formulas, budget):
    key = _key(formula, budget)
    if key in formulas:
        return
    if len(formulas) >= budget.limits['max_basis']:
        raise _Stop('BASIS_LIMIT')
    formulas[key] = formula
    budget.formulas = len(formulas)
    for child in _children(formula):
        _add_formula(child, formulas, budget)


def _collect_terms(formula, terms, budget):
    def term_visit(term, depth=1):
        budget.tick(1, depth)
        terms[_key(term, budget)] = term
        if term[0] == 'fun':
            for child in term[2]:
                term_visit(child, depth + 1)
    budget.tick()
    if formula[0] == 'eq':
        term_visit(formula[1])
        term_visit(formula[2])
    elif formula[0] == 'pred':
        for term in formula[2]:
            term_visit(term)
    for child in _children(formula):
        _collect_terms(child, terms, budget)


def _term_contexts(term, hole, budget, depth=1):
    budget.tick(1, depth)
    yield ('var', hole)
    if term[0] == 'fun':
        for index, child in enumerate(term[2]):
            for changed in _term_contexts(child, hole, budget, depth + 1):
                args = list(term[2])
                budget.tick(len(args), depth)
                args[index] = changed
                yield ('fun', term[1], tuple(args))


def _contexts(formula, hole, budget, depth=1):
    budget.tick(1, depth)
    tag = formula[0]
    if tag == 'eq':
        for changed in _term_contexts(formula[1], hole, budget, depth + 1):
            yield ('eq', changed, formula[2])
        for changed in _term_contexts(formula[2], hole, budget, depth + 1):
            yield ('eq', formula[1], changed)
    elif tag == 'pred':
        for index, term in enumerate(formula[2]):
            for changed in _term_contexts(term, hole, budget, depth + 1):
                args = list(formula[2])
                budget.tick(len(args), depth)
                args[index] = changed
                yield ('pred', formula[1], tuple(args))
    elif tag == 'all':
        for changed in _contexts(formula[2], hole, budget, depth + 1):
            yield ('all', formula[1], changed)
    elif tag == 'not':
        for changed in _contexts(formula[1], hole, budget, depth + 1):
            yield ('not', changed)
    elif tag in ('and', 'or', 'imp'):
        for changed in _contexts(formula[1], hole, budget, depth + 1):
            yield (tag, changed, formula[2])
        for changed in _contexts(formula[2], hole, budget, depth + 1):
            yield (tag, formula[1], changed)


def _atoms(formula, found, budget, depth=1):
    budget.tick(1, depth)
    tag = formula[0]
    if tag == 'not':
        _atoms(formula[1], found, budget, depth + 1)
    elif tag in ('and', 'or', 'imp'):
        _atoms(formula[1], found, budget, depth + 1)
        _atoms(formula[2], found, budget, depth + 1)
    elif tag != 'bot':
        found[_key(formula, budget)] = formula


def _truth(formula, valuation, budget, depth=1):
    budget.tick(1, depth)
    tag = formula[0]
    if tag == 'bot':
        return False
    if tag == 'not':
        return not _truth(formula[1], valuation, budget, depth + 1)
    if tag in ('and', 'or', 'imp'):
        left = _truth(formula[1], valuation, budget, depth + 1)
        right = _truth(formula[2], valuation, budget, depth + 1)
        if tag == 'and':
            return left and right
        if tag == 'or':
            return left or right
        return not left or right
    return valuation[_key(formula, budget)]


def _tautology(formula, atom_limit, budget):
    atoms = {}
    _atoms(formula, atoms, budget)
    if len(atoms) > atom_limit:
        return False
    keys = sorted(atoms)
    budget.tick(len(keys) * max(1, len(keys).bit_length()))
    for bits in range(1 << len(keys)):
        budget.tick(len(keys) + 1)
        valuation = {key: bool(bits & (1 << i)) for i, key in enumerate(keys)}
        if not _truth(formula, valuation, budget):
            return False
    return True


def _add_line(line, instances, formulas, budget):
    key = _key(line, budget)
    if key in instances:
        return
    if len(instances) >= budget.limits['max_instances']:
        raise _Stop('INSTANCE_LIMIT')
    _add_formula(line['formula'], formulas, budget)
    instances[key] = line
    budget.instances = len(instances)


def _inputs(theory, goal, slots, profile, budget):
    _fields(profile, ('ui_rounds', 'bridge_arity', 'max_tautology_atoms'))
    for key, upper in (('ui_rounds', 8), ('bridge_arity', 2), ('max_tautology_atoms', 16)):
        if type(profile[key]) is not int or not 0 <= profile[key] <= upper:
            raise InputError('PROFILE')
    if type(slots) is not int or not 1 <= slots <= 64:
        raise InputError('SLOTS')
    _fields(theory, ('functions', 'predicates', 'axioms'))
    functions = _signature(theory['functions'], budget)
    predicates = _signature(theory['predicates'], budget)
    if type(theory['axioms']) is not dict:
        raise InputError('AXIOMS')
    axioms = {}
    for name, formula in theory['axioms'].items():
        _name(name, budget)
        parsed = _formula(formula, functions, predicates, budget)
        if _free(parsed, budget):
            raise InputError('OPEN_THEORY_AXIOM')
        axioms[name] = parsed
    goal = _formula(goal, functions, predicates, budget)
    budget.tick(len(axioms) * max(1, len(axioms).bit_length()))
    return ({'functions': functions, 'predicates': predicates,
             'axioms': {name: axioms[name] for name in sorted(axioms)}}, goal, dict(profile))


def _universe(theory, goal, rounds, profile, budget):
    formulas, terms0, instances, goals = {}, {}, {}, {}
    _add_formula(goal, goals, budget)
    budget.formulas = 0
    for formula in tuple(theory['axioms'].values()) + (goal,):
        _add_formula(formula, formulas, budget)
    variables = set()
    for formula in _ordered(formulas, budget):
        _collect_terms(formula, terms0, budget)
        variables.update(_free(formula, budget, all_names=True))
    for name in sorted(variables):
        term = ('var', name)
        terms0[_key(term, budget)] = term
    instantiation_terms = _ordered(terms0, budget)
    budget.terms = len(terms0)
    for name, formula in theory['axioms'].items():
        _add_line({'rule': 'axiom', 'formula': formula, 'name': name}, instances, formulas, budget)
    stages = [{'stage': 'input', 'formula_count': len(formulas), 'instance_count': len(instances)}]
    for round_index in range(rounds):
        snapshot = _ordered(formulas, budget)
        for universal in snapshot:
            budget.tick()
            if universal[0] != 'all':
                continue
            for term in instantiation_terms:
                budget.tick()
                instance = _subst(universal[2], universal[1], term, budget)
                line = {'rule': 'instantiate', 'formula': ('imp', universal, instance),
                        'universal': universal, 'term': term}
                _add_line(line, instances, formulas, budget)
        stages.append({'stage': 'UI' + str(round_index + 1),
                       'formula_count': len(formulas), 'instance_count': len(instances)})
    pre = _ordered(formulas, budget)
    terms1 = dict(terms0)
    variables = set()
    for formula in pre:
        _collect_terms(formula, terms1, budget)
        variables.update(_free(formula, budget, all_names=True))
    terms = _ordered(terms1, budget)
    budget.terms = len(terms)
    hole_index = 0
    hole = '__u_hole0'
    while hole in variables:
        budget.tick()
        hole_index += 1
        hole = '__u_hole' + str(hole_index)
    templates = {}
    for formula in pre:
        for template in _contexts(formula, hole, budget):
            templates[_key(template, budget)] = template
    for left in terms:
        for right in terms:
            budget.tick()
            _add_formula(('eq', left, right), formulas, budget)
        _add_line({'rule': 'refl', 'formula': ('eq', left, left)}, instances, formulas, budget)
    atom_extended = set(formulas)
    equalities = [formula for formula in pre if formula[0] == 'eq']
    for template in _ordered(templates, budget):
        for equality in equalities:
            budget.tick()
            left, right = equality[1], equality[2]
            a = _subst(template, hole, left, budget)
            b = _subst(template, hole, right, budget)
            if _key(a, budget) in atom_extended and _key(b, budget) in atom_extended:
                _add_line({'rule': 'eq_subst', 'formula': ('imp', equality, ('imp', a, b)),
                           'variable': hole, 'template': template, 'left': left, 'right': right},
                          instances, formulas, budget)
    stages.append({'stage': 'equality', 'formula_count': len(formulas), 'instance_count': len(instances)})
    snapshot = _ordered(formulas, budget)
    snapshot_keys = set(formulas)
    for universal in snapshot:
        budget.tick()
        if universal[0] != 'all' or universal[2][0] != 'imp':
            continue
        variable, p, q = universal[1], universal[2][1], universal[2][2]
        all_q = ('all', variable, q)
        if variable not in _free(p, budget) and _key(all_q, budget) in snapshot_keys:
            _add_line({'rule': 'distribute', 'formula': ('imp', universal, ('imp', p, all_q)),
                       'variable': variable, 'antecedent': p, 'consequent': q}, instances, formulas, budget)
    stages.append({'stage': 'distribution', 'formula_count': len(formulas), 'instance_count': len(instances)})
    a_set = _ordered(formulas, budget)
    b_set = {}
    for formula in theory['axioms'].values():
        b_set[_key(formula, budget)] = formula
    for term in terms:
        formula = ('eq', term, term)
        b_set[_key(formula, budget)] = formula
    ordered_b, ordered_goals = _ordered(b_set, budget), _ordered(goals, budget)
    # Stream the declared factory. Duplicate full lines are removed by _add_line.
    for a in a_set:
        budget.tick()
        if _tautology(a, profile['max_tautology_atoms'], budget):
            _add_line({'rule': 'tautology', 'formula': a}, instances, formulas, budget)
        if profile['bridge_arity'] >= 1:
            for g in ordered_goals:
                bridge = ('imp', a, g)
                if _tautology(bridge, profile['max_tautology_atoms'], budget):
                    _add_line({'rule': 'tautology', 'formula': bridge}, instances, formulas, budget)
                if profile['bridge_arity'] >= 2:
                    for b in ordered_b:
                        bridge2 = ('imp', a, ('imp', b, g))
                        if _tautology(bridge2, profile['max_tautology_atoms'], budget):
                            _add_line({'rule': 'tautology', 'formula': bridge2}, instances, formulas, budget)
    stages.append({'stage': 'tautology', 'formula_count': len(formulas), 'instance_count': len(instances)})
    basis = {'instantiation_terms': instantiation_terms, 'terms': terms,
             'variables': sorted(variables), 'formulas': _ordered(formulas, budget),
             'templates': _ordered(templates, budget), 'hole': hole, 'stages': stages}
    lines = _ordered(instances, budget)
    records = [{'id': 'i' + str(i), 'rule': line['rule'], 'line': line} for i, line in enumerate(lines)]
    return basis, records


def _tiles(basis, instances, goal, slots, budget):
    candidates, steps = [], {}
    formulas = basis['formulas']
    keys = {_key(formula, budget) for formula in formulas}
    formula_colors = {_key(formula, budget): _key(formula, budget) for formula in formulas}

    def add(cid, slot, line, instance, uses):
        budget.tick()
        if slot == slots - 1 and line['formula'] != goal:
            return
        marks = {'out:' + str(slot): formula_colors[_key(line['formula'], budget)]}
        for source, formula in uses:
            key, color = 'out:' + str(source), formula_colors[_key(formula, budget)]
            if key in marks and marks[key] != color:
                return
            marks[key] = color
        if len(candidates) >= budget.limits['max_candidates']:
            raise _Stop('CANDIDATE_LIMIT')
        budget.tick(len(marks) * max(1, len(marks).bit_length()))
        candidates.append({'id': cid, 't': ['slot:' + str(slot)],
                           'm': [[key, marks[key]] for key in sorted(marks)]})
        steps[cid] = {'slot': slot, 'line': line, 'instance': instance}
        budget.candidates = len(candidates)

    for slot in range(slots):
        for instance in instances:
            add('r' + str(slot) + ':' + instance['id'], slot,
                instance['line'], instance['id'], ())
        for index, formula in enumerate(formulas):
            budget.tick()
            if formula[0] == 'imp' and _key(formula[1], budget) in keys and _key(formula[2], budget) in keys:
                for antecedent in range(slot):
                    for implication in range(slot):
                        line = {'rule': 'mp', 'formula': formula[2],
                                'antecedent': antecedent, 'implication': implication}
                        add('r' + str(slot) + ':mp:' + str(index) + ':' + str(antecedent) + ':' + str(implication),
                            slot, line, None, ((antecedent, formula[1]), (implication, formula)))
            if formula[0] == 'all' and _key(formula[2], budget) in keys:
                for source in range(slot):
                    line = {'rule': 'generalize', 'formula': formula,
                            'variable': formula[1], 'source': source}
                    add('r' + str(slot) + ':gen:' + str(index) + ':' + str(source),
                        slot, line, None, ((source, formula[2]),))
    return {'required': ['slot:' + str(i) for i in range(slots)], 'candidates': candidates}, steps


def build(theory, goal, slots, profile, limits):
    """Build a whole finite declared universe, or UNKNOWN with no partial bundle."""
    started = time.perf_counter()
    limits = _limits(limits)
    budget = _Budget(limits, started)
    try:
        budget.tick()
        theory, goal, profile = _inputs(theory, goal, slots, profile, budget)
        basis, instances = _universe(theory, goal, profile['ui_rounds'], profile, budget)
        model, steps = _tiles(basis, instances, goal, slots, budget)
        bundle = _wire({'schema': 'U-finite-Hilbert8-point-model-v1', 'version': VERSION,
                        'theory': theory, 'goal': goal, 'slots': slots, 'profile': profile,
                        'basis': basis, 'instances': instances, 'model': model, 'steps': steps,
                        'costs': None, 'scope': _SCOPE}, budget)
        budget.tick()
        costs = budget.costs()
        bundle['costs'] = dict(costs)
        return {'schema': 'U-Hilbert8-build-result-v1', 'version': VERSION,
                'status': 'COMPLETE', 'reason': None, 'bundle': bundle, 'costs': costs}
    except _Stop as exc:
        return {'schema': 'U-Hilbert8-build-result-v1', 'version': VERSION,
                'status': 'UNKNOWN', 'reason': str(exc), 'bundle': None, 'costs': budget.costs()}


def decode(bundle, selected):
    """Detach selected row metadata; does not perform a semantic proof check."""
    if type(bundle) is not dict or bundle.get('schema') != 'U-finite-Hilbert8-point-model-v1' or bundle.get('version') != VERSION:
        raise InputError('BUNDLE')
    slots = bundle.get('slots')
    steps = bundle.get('steps')
    if type(slots) is not int or not 1 <= slots <= 64 or type(steps) is not dict:
        raise InputError('BUNDLE_ROWS')
    if type(selected) is not list or len(selected) != slots or any(type(x) is not str for x in selected) or len(set(selected)) != slots:
        raise InputError('SELECTED')
    rows = {}
    for cid in selected:
        if cid not in steps:
            raise InputError('UNKNOWN_SELECTED_ID')
        step = steps[cid]
        _fields(step, ('slot', 'line', 'instance'))
        slot = step['slot']
        if type(slot) is not int or not 0 <= slot < slots or slot in rows or type(step['line']) is not dict:
            raise InputError('ROW_COVER')
        rows[slot] = step['line']
    # Compiler-produced bundle is the trusted bounded input to this adapter.
    # A JSON roundtrip detaches all selected metadata, without cloning the model.
    proof = json.loads(json.dumps([rows[i] for i in range(slots)], ensure_ascii=True, allow_nan=False))
    target = json.loads(json.dumps(bundle['goal'], ensure_ascii=True, allow_nan=False))
    return {'status': 'UNVERIFIED_CERTIFICATE', 'proof': proof, 'target': target}
