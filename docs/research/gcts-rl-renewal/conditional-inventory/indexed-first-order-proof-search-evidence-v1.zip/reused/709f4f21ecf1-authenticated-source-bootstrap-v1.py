import hashlib,sys
p,n,h=sys.argv[1:4]
n=int(n)
b=sys.stdin.buffer.read(n+1)
if len(b)!=n or hashlib.sha256(b).hexdigest()!=h:
    raise SystemExit('authenticated Source body mismatch')
sys.argv=[p]+sys.argv[4:]
g={'__name__':'__main__','__file__':p,'__package__':None,'__cached__':None,'__builtins__':__builtins__}
exec(compile(b,p,'exec'),g)
