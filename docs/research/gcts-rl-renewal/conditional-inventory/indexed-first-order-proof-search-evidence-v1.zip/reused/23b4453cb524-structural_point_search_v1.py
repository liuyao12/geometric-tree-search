"""Finite explicit singleton-unit t / literal-string m search, all roots zero.

Inert Source: no module-body model, search, fixture, I/O or project import.
The supplied finite candidate list is the entire declared placement universe.
"""
import hashlib
import json
import math
import time

VERSION = 'S-STRUCTURAL-UNIT-POINT-SEARCH-v1'
SCHEMA = 'S-structural-unit-point-result-v1'
STATE_SCHEMA = 'S-structural-unit-point-state-v1'


class InputError(ValueError):
    """A malformed model, limits object, or noncallable order argument."""


class OrderingError(ValueError):
    """An ordering return is neither None nor a unique legal ID prefix list."""


class _Stop(Exception):
    def __init__(self, owner, reason):
        self.owner = owner
        self.reason = reason


def _need(condition, message):
    if not condition:
        raise InputError(message)


def _fields(value, names, message):
    _need(type(value) is dict and len(value) == len(names)
          and all(type(key) is str for key in value) and set(value) == set(names), message)


def _limits(value):
    _fields(value, ('wall_seconds', 'max_nodes', 'max_events'), 'limits exact3')
    wall = value['wall_seconds']
    _need(type(wall) in (int, float), 'wall_seconds exact nonbool number')
    try:
        wall = float(wall)
    except (OverflowError, ValueError):
        raise InputError('wall_seconds finite positive number') from None
    _need(math.isfinite(wall) and wall > 0, 'wall_seconds finite positive number')
    for key in ('max_nodes', 'max_events'):
        _need(type(value[key]) is int and value[key] >= 0, key + ' exact nonnegative int')
    return {'wall_seconds': wall, 'max_nodes': value['max_nodes'], 'max_events': value['max_events']}


def _stats():
    return {key: 0 for key in (
        'operations', 'validation_items', 'required_points', 'candidates', 'mark_assignments',
        'mark_points', 'dependency_links', 'initial_edges', 'nodes', 'forced_placements',
        'branch_decisions', 'backtracks', 'scoped_exclusions', 'deactivated_selected',
        'candidate_eliminations_capacity', 'candidate_eliminations_mark',
        'candidate_eliminations_exclusion', 'dependency_visits', 'trail_writes',
        'trail_undos', 'max_trail', 'ordering_calls', 'ordering_prefix_items',
        'ordering_changed_first', 'certificate_checks', 'cleanup_operations')}


class _Meter:
    def __init__(self, started, limits, stats):
        self.started = started
        self.deadline = started + limits['wall_seconds']
        _need(math.isfinite(self.deadline), 'finite deadline')
        self.limits = limits
        self.stats = stats

    def tick(self, amount=1):
        self.stats['operations'] += amount
        if time.perf_counter() >= self.deadline:
            raise _Stop(self, 'WALL_SECONDS')

    def node(self):
        self.tick()
        if self.stats['nodes'] >= self.limits['max_nodes']:
            raise _Stop(self, 'MAX_NODES')
        self.stats['nodes'] += 1


def _text(value, meter, message):
    meter.tick()
    _need(type(value) is str, message)
    meter.tick(len(value))
    return value


def _sorted(values, meter, key=None):
    meter.tick(len(values))
    result = sorted(values, key=key)
    meter.tick(len(values))
    return result


def _wire(value, meter):
    encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                               separators=(',', ':'), allow_nan=False)
    chunks = []
    for part in encoder.iterencode(value):
        meter.tick(len(part))
        chunks.append(part.encode('ascii'))
    meter.tick()
    return b''.join(chunks) + b'\n'


def _digest(value, meter):
    result = hashlib.sha256(_wire(value, meter)).hexdigest()
    meter.tick()
    return result


def _prepare(model, meter):
    meter.tick()
    _fields(model, ('required', 'candidates'), 'model exact2')
    _need(type(model['required']) is list and type(model['candidates']) is list, 'model arrays')
    required, points, candidates, ids = [], set(), [], set()
    for point in model['required']:
        point = _text(point, meter, 'required point exact string')
        _need(point not in points, 'duplicate required point')
        points.add(point)
        required.append(point)
        meter.stats['validation_items'] += 1
    meter.stats['required_points'] = len(required)
    for row in model['candidates']:
        meter.tick()
        _fields(row, ('id', 't', 'm'), 'candidate exact3')
        cid = _text(row['id'], meter, 'candidate ID exact string')
        _need(cid not in ids, 'duplicate candidate ID')
        _need(type(row['t']) is list and len(row['t']) == 1, 't exactly one unit support point')
        anchor = _text(row['t'][0], meter, 't point exact string')
        _need(anchor in points, 'positive support must be required')
        _need(type(row['m']) is list, 'm pair array')
        marks, seen = [], set()
        for pair in row['m']:
            meter.tick()
            _need(type(pair) is list and len(pair) == 2, 'm exact point/value pair')
            point = _text(pair[0], meter, 'm point exact string')
            value = _text(pair[1], meter, 'm value exact string')
            _need(point not in seen, 'duplicate m point within candidate')
            seen.add(point)
            marks.append([point, value])
            meter.stats['validation_items'] += 1
            meter.stats['mark_assignments'] += 1
        ids.add(cid)
        candidates.append({'id': cid, 't': [anchor], 'm': _sorted(marks, meter, key=lambda x: x[0])})
        meter.stats['validation_items'] += 1
    meter.stats['candidates'] = len(candidates)
    return {'required': required, 'candidates': _sorted(candidates, meter, key=lambda x: x['id'])}


class _Events:
    def __init__(self, meter):
        self.meter = meter
        self.rows = []
        self.count = 0
        self.bytes = 0
        self.hash = hashlib.sha256()

    def emit(self, kind, data):
        row = {'seq': self.count, 'kind': kind, 'data': data}
        raw = _wire(row, self.meter)
        self.hash.update(raw)
        self.bytes += len(raw)
        if len(self.rows) < self.meter.limits['max_events']:
            self.rows.append(row)
        self.count += 1


class _State:
    def __init__(self, model, meter):
        self.meter = meter
        self.required = list(model['required'])
        self.candidates, self.domains, self.reverse, self.active = {}, {}, {}, {}
        self.totals, self.marks, self.dependencies = {}, {}, {}
        self.selected, self.excluded, self.trail = set(), set(), []
        for point in self.required:
            meter.tick()
            self.domains[point] = set()
            self.totals[point] = 0
        for row in model['candidates']:
            meter.tick()
            cid, anchor = row['id'], row['t'][0]
            marks = {}
            for point, value in row['m']:
                meter.tick()
                marks[point] = value
                self.dependencies.setdefault(point, []).append(cid)
                meter.stats['dependency_links'] += 1
            self.candidates[cid] = (anchor, marks)
            self.active[cid] = True
            self.domains[anchor].add(cid)
            self.reverse[cid] = {anchor}
            meter.stats['initial_edges'] += 1
        meter.stats['mark_points'] = len(self.dependencies)

    def _put(self, table, key, value):
        self.meter.tick()
        existed = key in table
        old = table.get(key)
        if existed and old == value:
            return
        self.trail.append(('map', table, key, existed, old))
        table[key] = value
        self._trailed()

    def _set(self, table, key, present):
        self.meter.tick()
        old = key in table
        if old == present:
            return
        self.trail.append(('set', table, key, old, None))
        if present:
            table.add(key)
        else:
            table.remove(key)
        self._trailed()

    def _trailed(self):
        stats = self.meter.stats
        stats['trail_writes'] += 1
        stats['max_trail'] = max(stats['max_trail'], len(self.trail))

    def undo(self, checkpoint):
        # Mandatory exact inverse; refusing wall/node budgets cannot interrupt it.
        while len(self.trail) > checkpoint:
            kind, table, key, flag, old = self.trail.pop()
            if kind == 'map':
                if flag:
                    table[key] = old
                else:
                    table.pop(key, None)
            elif flag:
                table.add(key)
            else:
                table.discard(key)
            self.meter.stats['trail_undos'] += 1
            self.meter.stats['cleanup_operations'] += 1

    def deactivate(self, cid, reason):
        self.meter.tick()
        if not self.active[cid]:
            return
        anchor = self.candidates[cid][0]
        self._put(self.active, cid, False)
        self._set(self.domains[anchor], cid, False)
        self._set(self.reverse[cid], anchor, False)
        self.meter.stats[reason] += 1

    def place(self, cid, forced, events):
        self.meter.tick()
        anchor, marks = self.candidates[cid]
        assert self.active[cid] and self.totals[anchor] == 0
        self._set(self.selected, cid, True)
        self._put(self.totals, anchor, 1)
        for other in _sorted(self.domains[anchor], self.meter):
            self.deactivate(other, 'deactivated_selected' if other == cid else 'candidate_eliminations_capacity')
        for point, value in marks.items():
            self.meter.tick()
            previous = self.marks.get(point)
            assert previous is None or previous[0] == value
            self._put(self.marks, point, (value, 1 if previous is None else previous[1] + 1))
            if previous is None:
                for other in self.dependencies[point]:
                    self.meter.tick()
                    self.meter.stats['dependency_visits'] += 1
                    if self.active[other] and self.candidates[other][1][point] != value:
                        self.deactivate(other, 'candidate_eliminations_mark')
        if forced:
            self.meter.stats['forced_placements'] += 1
        events.emit('PLACED', {'candidate': cid, 'point': anchor, 'forced': forced,
                              'root_generation': 0, 'tile_generation': 1})

    def exclude(self, cid):
        assert self.active[cid] and cid not in self.selected
        self._set(self.excluded, cid, True)
        self.deactivate(cid, 'candidate_eliminations_exclusion')
        self.meter.stats['scoped_exclusions'] += 1

    def snapshot(self):
        selected = _sorted(self.selected, self.meter)
        excluded = _sorted(self.excluded, self.meter)
        totals, domains, forward, reverse, generations = [], [], [], [], []
        for point in self.required:
            self.meter.tick()
            ids = _sorted(self.domains[point], self.meter)
            totals.append([point, self.totals[point]])
            domains.append([point, ids])
            generations.append([point, 0])
            for cid in ids:
                self.meter.tick()
                forward.append([point, cid, 1])
        for cid in _sorted(self.candidates, self.meter):
            self.meter.tick()
            for point in self.reverse[cid]:
                self.meter.tick()
                reverse.append([cid, point, 1])
        markings = []
        for point in _sorted(self.marks, self.meter):
            self.meter.tick()
            value, count = self.marks[point]
            markings.append([point, value, count])
        return {'schema': STATE_SCHEMA, 'selected': selected, 'totals': totals,
                'markings': markings, 'domains': domains, 'excluded': excluded,
                'forward_incidence': forward, 'reverse_incidence': reverse,
                'generations': generations}


def _schedule(state, meter):
    dead, forced, branch = None, None, None
    for point in state.required:
        meter.tick()
        if state.totals[point]:
            continue
        degree = len(state.domains[point])
        if degree == 0:
            dead = point if dead is None else min(dead, point)
        elif degree == 1:
            forced = point if forced is None else min(forced, point)
        elif branch is None or (degree, point) < branch:
            branch = (degree, point)
    if dead is not None:
        return 'DEAD', dead
    if forced is not None:
        return 'FORCED', forced
    return ('BRANCH', branch[1]) if branch is not None else ('SOLUTION', None)


def _ordered(point, legal, order, meter):
    if order is None:
        return legal, 'LEXICAL'
    meter.tick()
    meter.stats['ordering_calls'] += 1
    preference = order(point, list(legal))
    meter.tick()
    if preference is None:
        return legal, 'NO_PREFERENCE_LEXICAL'
    if type(preference) is not list or len(preference) > len(legal):
        raise OrderingError('ordering must return None or unique legal ID prefix list')
    allowed, seen, result = set(legal), set(), []
    for cid in preference:
        meter.tick()
        if type(cid) is not str or cid not in allowed or cid in seen:
            raise OrderingError('ordering prefix contains nonstring, unknown or duplicate ID')
        seen.add(cid)
        result.append(cid)
    meter.stats['ordering_prefix_items'] += len(result)
    for cid in legal:
        meter.tick()
        if cid not in seen:
            result.append(cid)
    if result[0] != legal[0]:
        meter.stats['ordering_changed_first'] += 1
    return result, 'PREFIX_PLUS_COMPLETE_LEXICAL_FALLBACK'


def _certificate(state, meter):
    selected = _sorted(state.selected, meter)
    totals, marks = {}, {}
    for point in state.required:
        meter.tick()
        totals[point] = 0
    for cid in selected:
        meter.tick()
        meter.stats['certificate_checks'] += 1
        anchor, assignments = state.candidates[cid]
        totals[anchor] += 1
        assert totals[anchor] <= 1
        for point, value in assignments.items():
            meter.tick()
            meter.stats['certificate_checks'] += 1
            old = marks.get(point)
            assert old is None or old[0] == value
            marks[point] = (value, 1 if old is None else old[1] + 1)
    for point in state.required:
        meter.tick()
        assert totals[point] == state.totals[point] == 1
    assert marks == state.marks
    return {'selected': selected, 'totals': [[p, totals[p]] for p in state.required],
            'markings': [[p, marks[p][0], marks[p][1]] for p in _sorted(marks, meter)],
            'generations': [[cid, 1] for cid in selected]}


def solve(model, limits, *, order=None):
    """Solve one supplied finite unit-point model; always undo private search deltas."""
    started = time.perf_counter()
    copied_limits = _limits(limits)
    _need(order is None or callable(order), 'order must be None or callable')
    stats = _stats()
    meter = _Meter(started, copied_limits, stats)
    events = _Events(meter)
    state = None
    model_sha = entry = restored = entry_sha = restored_sha = None
    selected = certificate = None
    records, stack = [], []
    status, reason = 'UNKNOWN', 'INCOMPLETE'
    try:
        normalized = _prepare(model, meter)
        model_sha = _digest(normalized, meter)
        state = _State(normalized, meter)
        entry = state.snapshot()
        entry_sha = _digest(entry, meter)
        while True:
            meter.node()
            kind, point = _schedule(state, meter)
            if kind == 'DEAD':
                events.emit('DEAD', {'point': point, 'generation': 0})
                if not stack:
                    status, reason = 'UNSAT', 'COMPLETE_FINITE_SEARCH_EXHAUSTED'
                    break
                frame = stack.pop()
                before = len(state.trail)
                state.undo(frame['checkpoint'])
                stats['backtracks'] += 1
                image = state.snapshot()
                actual = _digest(image, meter)
                assert actual == frame['parent_sha256']
                record = {'reason': 'COMPLETE_FAILED_CHILD', 'candidate': frame['candidate'],
                          'from_trail': before, 'to_trail': frame['checkpoint'],
                          'undone': before - frame['checkpoint'], 'expected_sha256': frame['parent_sha256'],
                          'restored_sha256': actual, 'equal': True}
                records.append(record)
                events.emit('ROLLBACK', record)
                state.exclude(frame['candidate'])
                events.emit('EXCLUDED', {'candidate': frame['candidate'], 'parent_sha256': actual,
                                         'meaning': 'complete failed child in this restored parent only'})
            elif kind == 'FORCED':
                cid = next(iter(state.domains[point]))
                state.place(cid, True, events)
            elif kind == 'SOLUTION':
                certificate = _certificate(state, meter)
                selected = certificate['selected']
                status, reason = 'SAT', 'EXACT_FINITE_TARGET_AND_LITERAL_MARKINGS'
                events.emit('SOLUTION', {'selected': list(selected)})
                break
            else:
                legal = _sorted(state.domains[point], meter)
                ranked, policy = _ordered(point, legal, order, meter)
                parent_sha = _digest(state.snapshot(), meter)
                frame = {'checkpoint': len(state.trail), 'candidate': ranked[0], 'parent_sha256': parent_sha}
                stack.append(frame)
                stats['branch_decisions'] += 1
                events.emit('BRANCH', {'point': point, 'generation': 0, 'legal': legal,
                                       'ordering': ranked, 'policy': policy})
                state.place(ranked[0], False, events)
    except _Stop as stop:
        if stop.owner is not meter:
            raise
        status, reason = 'UNKNOWN', stop.reason
        selected = certificate = None
    finally:
        if state is not None:
            before = len(state.trail)
            state.undo(0)
            records.append({'reason': 'FINAL_MANDATORY_CLEANUP', 'candidate': None,
                            'from_trail': before, 'to_trail': 0, 'undone': before,
                            'expected_sha256': entry_sha, 'restored_sha256': None, 'equal': None})
    if state is not None and entry is not None:
        try:
            restored = state.snapshot()
            restored_sha = _digest(restored, meter)
            assert restored == entry and restored_sha == entry_sha
            meter.tick()
            records[-1]['restored_sha256'] = restored_sha
            records[-1]['equal'] = True
        except _Stop as stop:
            if stop.owner is not meter:
                raise
            restored = restored_sha = None
            status, reason = 'UNKNOWN', stop.reason
            selected = certificate = None
    stats['elapsed_seconds'] = time.perf_counter() - started
    stats['events'] = events.count
    stats['retained_events'] = len(events.rows)
    return {'schema': SCHEMA, 'version': VERSION, 'status': status, 'reason': reason,
            'selected': selected, 'certificate': certificate, 'stats': stats,
            'events': events.rows,
            'event_extent': {'count': events.count, 'retained': len(events.rows), 'JSONL_bytes': events.bytes,
                             'SHA256': events.hash.hexdigest(), 'retained_complete': len(events.rows) == events.count,
                             'evaluation_complete': status in ('SAT', 'UNSAT')},
            'model_sha256': model_sha, 'entry_state': entry, 'restored_state': restored,
            'state_hashes': {'entry': entry_sha, 'restored': restored_sha}, 'rollback_records': records,
            'scope': 'Finite explicit singleton-unit t and exact literal-string m; all supplied roots generation0. '
                     'MRV/count then point-key ties within generation0, global dead then global forced first. '
                     'No fractional/multi-support/growing/infinite-tiling, new marking learning, RL or proof validity claim. '
                     'Wall includes validation/build/search/hash work and callbacks; mandatory trail cleanup may exceed it, '
                     'is separately counted, and final observation can be null on refusal. '
                     'Return JSON serialization and caller tail follow the elapsed sample; no hard OS time/RAM guarantee.'}
