"""Independent exact Version1 proof-byte grammar codec; no logical validation.

All entrypoints are inert until separately authorized. COMPLETE is grammatical
completion only, never a theorem, proof search, PA, or physical-tile claim.
"""

VERSION = 'GCTS-INDEPENDENT-PROOF-BYTE-STREAM-v1'
RESULT_SCHEMA = 'GCTS-independent-proof-byte-stream-result-v1'
LIMIT_NAMES = ('max_operations', 'max_depth', 'max_lines', 'max_items',
               'max_name_bytes', 'max_reference')
RULE_ORDER = ('axiom', 'tautology', 'refl', 'instantiate', 'distribute',
              'eq_subst', 'mp', 'generalize')
RULE_FIELDS = {
    'axiom': ('rule', 'name', 'formula'),
    'tautology': ('rule', 'formula'),
    'refl': ('rule', 'formula'),
    'instantiate': ('rule', 'universal', 'term', 'formula'),
    'distribute': ('rule', 'variable', 'antecedent', 'consequent', 'formula'),
    'eq_subst': ('rule', 'variable', 'template', 'left', 'right', 'formula'),
    'mp': ('rule', 'antecedent', 'implication', 'formula'),
    'generalize': ('rule', 'source', 'variable', 'formula'),
}


class _Invalid(Exception):
    """Encountered grammar/type error, with a fixed public reason code."""


class _Budget(Exception):
    """Encountered resource refusal, never a grammar or logical rejection."""


def _limits(value):
    if type(value) is not dict or len(value) != len(LIMIT_NAMES):
        return None
    if not all(type(key) is str for key in value) or set(value) != set(LIMIT_NAMES):
        return None
    if not all(type(value[key]) is int and value[key] >= 0 for key in LIMIT_NAMES):
        return None
    return {key: value[key] for key in LIMIT_NAMES}


class _Context:
    def __init__(self, limits):
        self.limits = limits
        self.offset = 0
        self.counts = {
            'operations': 0, 'by_kind': {}, 'bytes_read': 0,
            'bytes_emitted': 0, 'lines': 0, 'terms': 0, 'formulas': 0,
            'names': 0, 'name_bytes': 0, 'references': 0,
            'reference_marks': 0, 'list_items': 0, 'max_depth_seen': 0,
            'max_name_bytes_seen': 0, 'max_reference_seen': 0,
            'stream_bytes': None,
        }

    def tick(self, kind, amount=1):
        if self.counts['operations'] + amount > self.limits['max_operations']:
            raise _Budget('OPERATION_LIMIT')
        self.counts['operations'] += amount
        by_kind = self.counts['by_kind']
        by_kind[kind] = by_kind.get(kind, 0) + amount

    def depth(self, value):
        self.counts['max_depth_seen'] = max(self.counts['max_depth_seen'], value)
        if value > self.limits['max_depth']:
            raise _Budget('DEPTH_LIMIT')
        self.tick('grammar_depth')

    def line(self):
        self.tick('line')
        self.counts['lines'] += 1
        if self.counts['lines'] > self.limits['max_lines']:
            raise _Budget('LINE_LIMIT')

    def item(self):
        self.tick('list_item')
        self.counts['list_items'] += 1
        if self.counts['list_items'] > self.limits['max_items']:
            raise _Budget('ITEM_LIMIT')

    def name_byte(self, length):
        self.tick('name_byte')
        self.counts['name_bytes'] += 1
        self.counts['max_name_bytes_seen'] = max(
            self.counts['max_name_bytes_seen'], length)
        if length > self.limits['max_name_bytes']:
            raise _Budget('NAME_LIMIT')

    def reference_mark(self, value):
        self.tick('reference_mark')
        self.counts['reference_marks'] += 1
        self.counts['max_reference_seen'] = max(
            self.counts['max_reference_seen'], value)
        if value > self.limits['max_reference']:
            raise _Budget('REFERENCE_LIMIT')

    def result(self, operation, status, reason, proof=None, stream_hex=None):
        counts = dict(self.counts)
        counts['by_kind'] = dict(self.counts['by_kind'])
        return {
            'schema': RESULT_SCHEMA, 'version': VERSION,
            'operation': operation, 'status': status, 'reason': reason,
            'proof': proof, 'stream_hex': stream_hex, 'offset': self.offset,
            'counts': counts,
            'limits': None if self.limits is None else dict(self.limits),
        }


class _Reader(_Context):
    def __init__(self, stream, limits):
        super().__init__(limits)
        self.stream = stream
        self.counts['stream_bytes'] = len(stream)

    def byte(self):
        # A read attempt is charged even if the stream ends at this position.
        self.tick('byte_read_attempt')
        if self.offset == len(self.stream):
            raise _Invalid('TRUNCATED_STREAM')
        value = self.stream[self.offset]
        self.offset += 1
        self.counts['bytes_read'] += 1
        return value

    def name(self):
        self.tick('name')
        self.counts['names'] += 1
        chars = []
        while True:
            value = self.byte()
            if value == 0:
                if not chars:
                    raise _Invalid('EMPTY_NAME')
                self.tick('name_materialize', len(chars))
                return ''.join(chars)
            if not 32 <= value <= 126:
                raise _Invalid('NAME_BYTE')
            self.name_byte(len(chars) + 1)
            self.tick('name_append')
            chars.append(chr(value))

    def reference(self):
        self.tick('reference')
        self.counts['references'] += 1
        value = 0
        while True:
            token = self.byte()
            if token == 81:
                return value
            if token != 80:
                raise _Invalid('REFERENCE_BYTE')
            value += 1
            self.reference_mark(value)

    def array(self, *values):
        self.tick('AST_materialize', len(values))
        return list(values)

    def terms(self, depth):
        values = []
        while True:
            marker = self.byte()
            if marker == 65:
                return values
            if marker != 64:
                raise _Invalid('LIST_MARKER')
            self.item()
            value = self.term(depth)
            self.tick('term_list_append')
            values.append(value)

    def term(self, depth):
        self.depth(depth)
        self.tick('term')
        self.counts['terms'] += 1
        tag = self.byte()
        if tag == 32:
            return self.array('var', self.name())
        if tag == 33:
            name = self.name()
            values = self.terms(depth + 1)
            return self.array('fun', name, values)
        raise _Invalid('TERM_TAG')

    def formula(self, depth):
        self.depth(depth)
        self.tick('formula')
        self.counts['formulas'] += 1
        tag = self.byte()
        if tag == 48:
            return self.array('bot')
        if tag == 49:
            left = self.term(depth + 1)
            right = self.term(depth + 1)
            return self.array('eq', left, right)
        if tag == 50:
            name = self.name()
            values = self.terms(depth + 1)
            return self.array('pred', name, values)
        if tag == 51:
            return self.array('not', self.formula(depth + 1))
        if tag in (52, 53, 54):
            left = self.formula(depth + 1)
            right = self.formula(depth + 1)
            name = {52: 'and', 53: 'or', 54: 'imp'}[tag]
            return self.array(name, left, right)
        if tag == 55:
            name = self.name()
            return self.array('all', name, self.formula(depth + 1))
        raise _Invalid('FORMULA_TAG')

    def proof_line(self):
        code = self.byte()
        if not 0 <= code <= 7:
            raise _Invalid('RULE_CODE')
        rule = RULE_ORDER[code]
        self.tick('line_fields', len(RULE_FIELDS[rule]))
        if code == 0:
            name = self.name()
            return {'rule': rule, 'name': name, 'formula': self.formula(1)}
        if code in (1, 2):
            return {'rule': rule, 'formula': self.formula(1)}
        if code == 3:
            universal = self.formula(1)
            term = self.term(1)
            return {'rule': rule, 'universal': universal, 'term': term,
                    'formula': self.formula(1)}
        if code == 4:
            variable = self.name()
            antecedent = self.formula(1)
            consequent = self.formula(1)
            return {'rule': rule, 'variable': variable,
                    'antecedent': antecedent, 'consequent': consequent,
                    'formula': self.formula(1)}
        if code == 5:
            variable = self.name()
            template = self.formula(1)
            left = self.term(1)
            right = self.term(1)
            return {'rule': rule, 'variable': variable, 'template': template,
                    'left': left, 'right': right, 'formula': self.formula(1)}
        if code == 6:
            antecedent = self.reference()
            implication = self.reference()
            return {'rule': rule, 'antecedent': antecedent,
                    'implication': implication, 'formula': self.formula(1)}
        source = self.reference()
        variable = self.name()
        return {'rule': rule, 'source': source, 'variable': variable,
                'formula': self.formula(1)}

    def run(self):
        if self.byte() != 1:
            raise _Invalid('VERSION_BYTE')
        proof = []
        while True:
            marker = self.byte()
            if marker == 17:
                if not proof:
                    raise _Invalid('EMPTY_PROOF')
                if self.offset != len(self.stream):
                    raise _Invalid('TRAILING_BYTES')
                self.tick('proof_finish')
                return proof
            if marker != 16:
                raise _Invalid('LINE_MARKER')
            self.line()
            value = self.proof_line()
            self.tick('proof_list_append')
            proof.append(value)


class _Writer(_Context):
    def __init__(self, limits):
        super().__init__(limits)
        self.output = bytearray()
        self.active = set()

    def byte(self, value):
        self.tick('byte_write')
        self.output.append(value)
        self.offset += 1
        self.counts['bytes_emitted'] += 1

    def enter(self, value):
        self.tick('array_shape')
        if type(value) is not list:
            raise _Invalid('AST_ARRAY')
        key = id(value)
        if key in self.active:
            raise _Invalid('CYCLIC_AST')
        self.active.add(key)
        return key

    def name(self, value):
        self.tick('name')
        self.counts['names'] += 1
        if type(value) is not str:
            raise _Invalid('NAME_TYPE')
        if not value:
            raise _Invalid('EMPTY_NAME')
        for length, character in enumerate(value, 1):
            self.tick('name_character')
            code = ord(character)
            if not 32 <= code <= 126:
                raise _Invalid('NAME_BYTE')
            self.name_byte(length)
            self.byte(code)
        self.byte(0)

    def reference(self, value):
        self.tick('reference')
        self.counts['references'] += 1
        if type(value) is not int or value < 0:
            raise _Invalid('REFERENCE_TYPE')
        for index in range(value):
            self.reference_mark(index + 1)
            self.byte(80)
        self.byte(81)

    def terms(self, values, depth):
        key = self.enter(values)
        try:
            for value in values:
                self.item()
                self.byte(64)
                self.term(value, depth)
            self.byte(65)
        finally:
            self.active.remove(key)

    def term(self, value, depth):
        self.depth(depth)
        self.tick('term')
        self.counts['terms'] += 1
        key = self.enter(value)
        try:
            if not value or type(value[0]) is not str:
                raise _Invalid('TERM_TAG')
            if value[0] == 'var':
                if len(value) != 2:
                    raise _Invalid('TERM_SHAPE')
                self.byte(32)
                self.name(value[1])
            elif value[0] == 'fun':
                if len(value) != 3:
                    raise _Invalid('TERM_SHAPE')
                self.byte(33)
                self.name(value[1])
                self.terms(value[2], depth + 1)
            else:
                raise _Invalid('TERM_TAG')
        finally:
            self.active.remove(key)

    def formula(self, value, depth):
        self.depth(depth)
        self.tick('formula')
        self.counts['formulas'] += 1
        key = self.enter(value)
        try:
            if not value or type(value[0]) is not str:
                raise _Invalid('FORMULA_TAG')
            tag = value[0]
            if tag == 'bot':
                if len(value) != 1:
                    raise _Invalid('FORMULA_SHAPE')
                self.byte(48)
            elif tag == 'eq':
                if len(value) != 3:
                    raise _Invalid('FORMULA_SHAPE')
                self.byte(49)
                self.term(value[1], depth + 1)
                self.term(value[2], depth + 1)
            elif tag == 'pred':
                if len(value) != 3:
                    raise _Invalid('FORMULA_SHAPE')
                self.byte(50)
                self.name(value[1])
                self.terms(value[2], depth + 1)
            elif tag == 'not':
                if len(value) != 2:
                    raise _Invalid('FORMULA_SHAPE')
                self.byte(51)
                self.formula(value[1], depth + 1)
            elif tag in ('and', 'or', 'imp'):
                if len(value) != 3:
                    raise _Invalid('FORMULA_SHAPE')
                self.byte({'and': 52, 'or': 53, 'imp': 54}[tag])
                self.formula(value[1], depth + 1)
                self.formula(value[2], depth + 1)
            elif tag == 'all':
                if len(value) != 3:
                    raise _Invalid('FORMULA_SHAPE')
                self.byte(55)
                self.name(value[1])
                self.formula(value[2], depth + 1)
            else:
                raise _Invalid('FORMULA_TAG')
        finally:
            self.active.remove(key)

    def proof_line(self, value):
        self.tick('line_shape')
        if type(value) is not dict:
            raise _Invalid('LINE_RECORD')
        if len(value) > 6:
            raise _Invalid('LINE_FIELDS')
        if not all(type(key) is str for key in value):
            raise _Invalid('LINE_FIELDS')
        rule = value.get('rule')
        if type(rule) is not str or rule not in RULE_FIELDS:
            raise _Invalid('RULE_CODE')
        expected = RULE_FIELDS[rule]
        if len(value) != len(expected) or set(value) != set(expected):
            raise _Invalid('LINE_FIELDS')
        self.tick('line_fields', len(expected))
        self.byte(RULE_ORDER.index(rule))
        if rule == 'axiom':
            self.name(value['name'])
        elif rule == 'instantiate':
            self.formula(value['universal'], 1)
            self.term(value['term'], 1)
        elif rule == 'distribute':
            self.name(value['variable'])
            self.formula(value['antecedent'], 1)
            self.formula(value['consequent'], 1)
        elif rule == 'eq_subst':
            self.name(value['variable'])
            self.formula(value['template'], 1)
            self.term(value['left'], 1)
            self.term(value['right'], 1)
        elif rule == 'mp':
            self.reference(value['antecedent'])
            self.reference(value['implication'])
        elif rule == 'generalize':
            self.reference(value['source'])
            self.name(value['variable'])
        self.formula(value['formula'], 1)

    def run(self, proof):
        self.byte(1)
        for line in proof:
            self.line()
            self.byte(16)
            self.proof_line(line)
        self.byte(17)
        # Account for a complete output copy and its two-character hex image.
        self.tick('output_materialize', 3 * self.offset)
        stream_hex = bytes(self.output).hex()
        self.counts['stream_bytes'] = self.offset
        return stream_hex


def decode(stream, limits):
    """Read the whole exact bytes stream; no semantic theorem checking."""
    checked = _limits(limits)
    if checked is None:
        return _Context(None).result('decode', 'REJECTED', 'INVALID_LIMITS')
    if type(stream) is not bytes:
        return _Context(checked).result('decode', 'REJECTED', 'STREAM_TYPE')
    context = _Reader(stream, checked)
    try:
        proof = context.run()
        return context.result('decode', 'COMPLETE', 'FULL_STREAM_DECODED',
                              proof=proof)
    except _Invalid as error:
        return context.result('decode', 'REJECTED', error.args[0])
    except _Budget as error:
        return context.result('decode', 'UNKNOWN_BUDGET', error.args[0])
    except RecursionError:
        return context.result('decode', 'UNKNOWN_BUDGET', 'HOST_RECURSION_LIMIT')
    except MemoryError:
        return context.result('decode', 'UNKNOWN_BUDGET', 'HOST_MEMORY_LIMIT')


def encode(proof, limits):
    """Write one canonical grammar stream; no semantic theorem checking."""
    checked = _limits(limits)
    if checked is None:
        return _Context(None).result('encode', 'REJECTED', 'INVALID_LIMITS')
    if type(proof) is not list:
        return _Context(checked).result('encode', 'REJECTED', 'PROOF_TYPE')
    if not proof:
        return _Context(checked).result('encode', 'REJECTED', 'EMPTY_PROOF')
    context = _Writer(checked)
    try:
        stream_hex = context.run(proof)
        return context.result('encode', 'COMPLETE', 'CANONICAL_STREAM_ENCODED',
                              stream_hex=stream_hex)
    except _Invalid as error:
        return context.result('encode', 'REJECTED', error.args[0])
    except _Budget as error:
        return context.result('encode', 'UNKNOWN_BUDGET', error.args[0])
    except RecursionError:
        return context.result('encode', 'UNKNOWN_BUDGET', 'HOST_RECURSION_LIMIT')
    except MemoryError:
        return context.result('encode', 'UNKNOWN_BUDGET', 'HOST_MEMORY_LIMIT')
