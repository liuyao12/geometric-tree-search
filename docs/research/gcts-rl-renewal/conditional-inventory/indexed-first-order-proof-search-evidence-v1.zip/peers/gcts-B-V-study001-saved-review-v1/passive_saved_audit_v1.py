"""Passive current saved JSON/hash/type/equality/arithmetic joins; no subject imports."""
import collections,gzip,hashlib,json,math,pathlib
V=pathlib.Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1');A=V/'actual/study-001';D=pathlib.Path('/private/tmp/gcts-B-V-study001-saved-review-v1')
H=lambda b:hashlib.sha256(b).hexdigest()
def wire(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def col(x):return wire(x)[:-1].decode()
def eq(a,b):return wire(a)==wire(b)
def pairs(items):
 r={}
 for k,v in items:assert k not in r;r[k]=v
 return r
def parse(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in()).throw(ValueError(x)))
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def rp(ref):assert pin(pathlib.Path(ref['path']))==ref,ref['path']
def get(name):
 p=A/name;b=p.read_bytes();return parse(gzip.decompress(b)if p.suffix=='.gz'else b)
W=get('worker-result.json.gz');O=get('observer-result.json');P=parse((V/'root/study-once-plan-001.json').read_bytes());T=parse((V/'root/original-study001-tool-custody-v1.json').read_bytes());ROOT=parse((V/'root/original-study001-saved-summary-v1.json').read_bytes())
assert T['initial']['session_id']==T['poll']['session_id']==67121 and T['initial']['chunk_id']=='d87634' and T['terminal']['chunk_id']=='e088f6' and T['terminal']['exit_code']==0 and 'session_id'not in T['terminal']
assert parse(T['terminal']['output'].encode())=={'receipt':pin(A/'observer-result.json'),'status':'COMPLETE'}
assert O['status']==W['status']=='COMPLETE' and O['returncode']==0 and O['failure']is None and O['cleanup_errors']==[] and O['group_gone']and O['wait_confirmed']and O['both_streams_EOF']
assert O['worker_terminal']==get('stdout.bin') and O['worker_terminal']['plan']==pin(V/'root/study-once-plan-001.json') and O['worker_terminal']['public_calls']==W['outer_public_calls']
assert O['observed_stream_bytes']=={'stdout':1066,'stderr':0} and all(O['retained_streams_complete'].values())and(A/'stderr.bin').read_bytes()==b''
for r in O['files']:rp(r)
assert {r['path']for r in O['files']}=={str(p)for p in A.iterdir()if p.name!='observer-result.json'} and sum(r['bytes']for r in O['files'])==O['stored_bytes']
for group in ('sources','metadata'):
 for r in P[group].values():rp(r)
rp(P['python']);rp(P['bootstrap'])
AUTH=parse((V/'root/study-once-authority-001.json').read_bytes());C=parse((V/'root/study-once-authority-001.json.CONSUMED.json').read_bytes());CC=get('CONSUMED.json')
assert AUTH['authorized']is True and type(AUTH['uses'])is int and AUTH['uses']==1 and AUTH['plan']==O['worker_terminal']['plan'] and AUTH['python']==P['python'] and AUTH['runner']==P['sources']['runner']
assert C['status']=='SPENT' and C['authority']==pin(V/'root/study-once-authority-001.json')and C['plan']==AUTH['plan'] and CC=={'authority':C['authority'],'consumed':pin(V/'root/study-once-authority-001.json.CONSUMED.json')}
assert O['stdin_bytes_sent']==P['sources']['runner']['bytes'] and len(O['files'])<=P['limits']['max_files'] and O['stored_bytes']<=P['limits']['total_bytes'] and all(r['bytes']<=P['limits']['file_bytes']for r in O['files'])
assert O['whole_observer_seconds']<=P['limits']['observer_seconds'] and O['worker_terminal']['elapsed_seconds']<=P['limits']['worker_seconds'] and max(O['wait4_peak_bytes'],O['worker_terminal']['self_lifetime_peak_bytes'])<=P['limits']['rss_bytes']
art={};refs=[]
for ref in W['artifacts']+[O['worker_terminal']['result']]:
 rp(ref['stored']);b=pathlib.Path(ref['stored']['path']).read_bytes();raw=gzip.decompress(b)if ref['encoding']=='gzip-json'else b
 assert len(raw)==ref['raw_bytes']and H(raw)==ref['raw_sha256']and len(raw)<=P['limits']['file_bytes'];x=parse(raw);assert raw==wire(x);assert ref['name']not in art;art[ref['name']]=x;refs.append(ref)
assert art['worker-result']==W
value_count=0;types=collections.Counter()
for x in art.values():
 todo=[x]
 while todo:
  y=todo.pop();value_count+=1;types[type(y).__name__]+=1
  if type(y)is dict:assert all(type(k)is str for k in y);todo.extend(y.values())
  elif type(y)is list:todo.extend(y)
  elif type(y)is float:assert math.isfinite(y)
  else:assert type(y)in(str,int,bool,type(None))

def catalogue(c):
 b=c['logical_basis'];forms=b['formulas'];colors=b['colors'];assert colors==[col(f)for f in forms]and colors==sorted(set(colors));idx={s:i for i,s in enumerate(colors)}
 assert c['goal_id']==idx[col(c['goal'])] and type(c['goal_id'])is int and c['costs']['candidates']==0 and c['costs']['formulas']==len(forms)and c['costs']['instances']==len(c['zero_instances'])
 assert c['mp_index']==[[i,idx[col(f[1])],idx[col(f[2])]]for i,f in enumerate(forms)if f[0]=='imp'and col(f[1])in idx and col(f[2])in idx]
 assert c['gen_index']==[[i,idx[col(f[2])],f[1]]for i,f in enumerate(forms)if f[0]=='all'and col(f[2])in idx]
 z=c['zero_instances'];assert [r['id']for r in z]==['i'+str(i)for i in range(len(z))]and[col(r['line'])for r in z]==sorted(set(col(r['line'])for r in z))
 for r in z:assert type(r['formula_id'])is int and forms[r['formula_id']]==r['line']['formula']and r['rule']==r['line']['rule']
 return {'forms':forms,'colors':colors,'zero':{r['id']:r for r in z},'mp':{r[0]:r for r in c['mp_index']},'gen':{r[0]:r for r in c['gen_index']}}

def selected(c,n,ids):
 d=catalogue(c);rows={};marks={};refs=collections.Counter();tiles=[]
 for cid in ids:
  fields=cid.split(':');i=int(fields[0][1:]);assert 0<=i<n and i not in rows
  if len(fields)==2:
   z=d['zero'][fields[1]];line=z['line'];out=z['formula_id'];use={}
  elif fields[1]=='mp':
   fi,a,b=map(int,fields[2:]);_,ant,out=d['mp'][fi];assert 0<=a<i and 0<=b<i;use={a:ant};assert b not in use or use[b]==fi;use[b]=fi;line={'rule':'mp','formula':d['forms'][out],'antecedent':a,'implication':b}
  else:
   fi,source=map(int,fields[2:]);_,body,var=d['gen'][fi];assert 0<=source<i;out=fi;use={source:body};line={'rule':'generalize','formula':d['forms'][out],'source':source,'variable':var}
  use[i]=out;rows[i]=line
  for q,v in use.items():assert q not in marks or marks[q]==v;marks[q]=v;refs[q]+=1
  tiles.append({'id':cid,'t':['slot:'+str(i)],'m':[['out:'+str(q),d['colors'][v]]for q,v in sorted(use.items(),key=lambda z:'out:'+str(z[0]))]})
 assert set(rows)==set(range(n));proof=[rows[i]for i in range(n)]
 for i,line in enumerate(proof):
  if line['rule']=='mp':assert proof[line['implication']]['formula']==['imp',proof[line['antecedent']]['formula'],line['formula']]
  elif line['rule']=='generalize':assert line['formula']==['all',line['variable'],proof[line['source']]['formula']]
 assert proof[-1]['formula']==c['goal']
 cert={'selected':sorted(ids),'totals':[1]*n,'markings':[[q,d['colors'][marks[q]],refs[q]]for q in range(n)],'generations':[[cid,1]for cid in sorted(ids)]}
 return proof,cert,tiles

point_rows=[];event_rows=[];rollback_total=0

def point(c,n,p,label):
 global rollback_total
 model={'slots':n,'colors':c['logical_basis']['colors'],'goal_id':c['goal_id'],'zero':[[r['id'],r['formula_id']]for r in c['zero_instances']],'mp_index':c['mp_index'],'gen_index':c['gen_index']}
 if p['entry_state']is None:
  assert p['status']=='UNKNOWN'and p['restored_state']is None and p['families']is None and p['state_hashes']=={'entry':None,'restored':None}
  if p['model']is not None:assert p['model']==model and p['model_sha256']==H(wire(model))
  else:assert p['model_sha256']is None
 else:
  assert p['model']==model and p['model_sha256']==H(wire(model));e=p['entry_state'];r=p['restored_state'];assert eq(e,r)and p['state_hashes']=={'entry':H(wire(e)),'restored':H(wire(r))}
  assert e['occupied']==[False]*n and e['selected']==e['values']==[None]*n and e['refs']==[0]*n and e['excluded']==[]and e['root_generations']==[0]*n
  fam=p['families'];assert fam==sorted(fam,key=lambda x:x[0])and len({x[0]for x in fam})==len(fam)
  exp=[]
  for row in range(n):
   for iid,out in model['zero']:
    if row<n-1 or out==model['goal_id']:exp.append(['r%d:%s'%(row,iid),'zero',row,out,None,None])
   for fi,ant,out in model['mp_index']:
    if row<n-1 or out==model['goal_id']:exp.append(['r%d:mp:%d:'%(row,fi),'mp',row,out,ant,fi])
   for fi,body,var in model['gen_index']:
    if row<n-1 or fi==model['goal_id']:exp.append(['r%d:gen:%d:'%(row,fi),'gen',row,fi,body,None])
  assert fam==sorted(exp,key=lambda x:x[0]);byrow=[[]for _ in range(n)];deps=[[]for _ in range(n)];rev=[];factors=[];degrees=[0]*n
  for k,(_,kind,row,out,left,right)in enumerate(fam):
   byrow[row].append(k);qs=[row]if kind=='zero'else list(range(row+1));rev.append(qs)
   for q in qs:deps[q].append(k)
   rr=sorted(range(row),key=str);count=1 if kind=='zero'else row if kind=='gen'else row*row-(row if left!=right else 0)
   factors.append([True,[]if kind=='zero'else rr,rr if kind=='mp'else[],count]);degrees[row]+=count
  assert e['required']==e['frontier']==['slot:'+str(q)for q in range(n)]and e['row_families']==byrow and e['family_rows']==[f[2]for f in fam]and e['marking_dependencies']==deps and e['reverse_marking_dependencies']==rev and e['factors']==factors and e['degrees']==degrees
  assert p['stats']['families']==len(fam)and p['stats']['virtual_members']==sum(degrees)and p['stats']['dependency_links']==sum(map(len,rev))
 ex=p['event_extent'];ev=p['events'];assert ex['retained']==len(ev)<=ex['count']and ex['evaluation_complete']==(p['status']!='UNKNOWN')and p['stats']['events']==ex['count']
 for i,v in enumerate(ev):assert set(v)=={'seq','kind','data'}and v['seq']==i
 if len(ev)==ex['count']:assert ex['JSONL_bytes']==len(b''.join(wire(v)for v in ev))and ex['SHA256']==H(b''.join(wire(v)for v in ev))
 else:assert ex['JSONL_bytes']>=sum(len(wire(v))for v in ev)
 records=p['rollback_records'];assert sum(x['undone']for x in records)==p['stats']['trail_undos']==p['stats']['trail_writes'];rollback_total+=len(records)
 for rec in records:
  assert rec['undone']>=0 and rec['target']>=0
  if rec['reason']=='FAILED_CHILD':assert rec['after_core_sha256']==rec['expected_parent_core_sha256']
  else:assert rec['reason']=='FINAL_MANDATORY_CLEANUP'and rec is records[-1]and rec['target']==0 and rec['full_restored_sha256']==p['state_hashes']['restored']and rec['undone']==p['stats']['cleanup_undos']
 if p['status']=='SAT':
  proof,cert,tiles=selected(c,n,p['selected']);assert p['certificate']==cert
 else:assert p['status']in('UNSAT','UNKNOWN')and p['selected']is p['certificate']is None
 point_rows.append({'label':label,'status':p['status'],'prepared':p['entry_state']is not None,'families':p['stats']['families'],'virtual_members':p['stats']['virtual_members'],'stats':p['stats'],'events':ex,'rollback_count':len(records),'entry_sha256':p['state_hashes']['entry']})

normal=[];obs_rows=[];qual=[];expected_proofs={}
for name,x in art.items():
 if not name.startswith('qualification-')or'whole-proof-check'in name:continue
 qual.append({'name':name,'sha256':H(wire(x))})
 if 'materialized'not in x:continue
 c=x['basis_return']['compiled'];catalogue(c);n=x['slots'];assert x['basis_return']['status']=='COMPLETE'and x['core_compiled']['status']=='VERIFIED'
 mat=x['materialized']['bundle'];old=x['reference']['bundle'];assert mat['model']['required']==old['model']['required']and{q['id']:q for q in mat['model']['candidates']}=={q['id']:q for q in old['model']['candidates']}and mat['steps']==old['steps']
 proj={k:v for k,v in c['logical_basis'].items()if k!='colors'};zs=[{k:v for k,v in z.items()if k!='formula_id'}for z in c['zero_instances']];assert mat['basis']==old['basis']==proj and mat['instances']==old['instances']==zs
 cs={q['id']:q for q in mat['model']['candidates']};colors=c['logical_basis']['colors'];ci={s:i for i,s in enumerate(colors)};cm={cid:(int(q['t'][0].split(':')[1]),{int(p.split(':')[1]):ci[v]for p,v in q['m']})for cid,q in cs.items()};product=1
 for root in mat['model']['required']:product*=sum(q['t']==[root]for q in cs.values())
 assert product==x['product'];sol=x['full_solution_ID_sets'];assert len({tuple(q)for q in sol})==len(sol)
 for ids in sol:selected(c,n,ids)
 p=x['indexed'];point(c,n,p,name);assert p['status']==x['explicit']['status']==('SAT'if sol else'UNSAT')and eq(x['explicit']['entry_state'],x['explicit']['restored_state'])
 if sol:
  assert sorted(p['selected'])in sol and sorted(x['explicit']['selected'])in sol
  for lane,key,ids in [('point','core_selection',p['selected']),('explicit','explicit_selection',x['explicit']['selected'])]:
   pr,_,_=selected(c,n,ids);assert x[key]['status']=='VERIFIED'and x[key]['proof']==pr;expected_proofs[name+'-'+lane+'-whole-proof-check']=(pr,x['problem'])
  assert x['backward']['status']=='DERIVABLE';expected_proofs[name+'-control-whole-proof-check']=(x['backward']['proof'],x['problem'])
 else:assert x['core_selection']is x['explicit_selection']is None and x['backward']['status']=='NOT_DERIVABLE'and x['backward']['details']['exhaustive']is True
 assert len(x['observations'])==x['graph_audit']['observations']and[x['event']for x in x['observations']]==p['events']
 for ob in x['observations']:
  st=ob['state'];vals=[None]*n;refs2=[0]*n;selected_ids=[]
  for row,cid in enumerate(st['selected']):
   assert st['occupied'][row]==(cid is not None)
   if cid is None:continue
   assert cm[cid][0]==row;selected_ids.append(cid)
   for q,v in cm[cid][1].items():assert vals[q]is None or vals[q]==v;vals[q]=v;refs2[q]+=1
  assert st['values']==vals and st['refs']==refs2
  legal=[[]for _ in range(n)];fcount=collections.Counter();fam=p['families'];fm={f[0]:k for k,f in enumerate(fam)}
  for cid,(row,marks)in cm.items():
   if st['occupied'][row]or cid in st['excluded']:continue
   if all(vals[q]is None or vals[q]==v for q,v in marks.items()):
    legal[row].append(cid);fields=cid.split(':');prefix=cid if len(fields)==2 else ':'.join(fields[:3])+':';fcount[fm[prefix]]+=1
  legal=[sorted(q)for q in legal];assert ob['audit']['legal_ids']==legal and st['degrees']==list(map(len,legal))and ob['audit']['state_sha256']==H(wire(st))
  assert ob['audit']['core_sha256']==H(wire({k:st[k]for k in ('occupied','selected','values','refs','excluded')}))
  for k,(_,kind,row,out,left,right)in enumerate(fam):
   enabled=not st['occupied'][row]and(vals[row]is None or vals[row]==out)
   factor=[False,[],[],0]if not enabled else[True,[]if kind=='zero'else sorted([q for q in range(row)if vals[q]is None or vals[q]==left],key=str),[]if kind!='mp'else sorted([q for q in range(row)if vals[q]is None or vals[q]==right],key=str),fcount[k]]
   assert st['factors'][k]==factor
  for cid in st['excluded']:assert not any(set(selected_ids+[cid]).issubset(solution)for solution in sol)
  assert all(ob['state'][k]==p['entry_state'][k]for k in ('required','root_generations','row_families','family_rows','marking_dependencies','reverse_marking_dependencies'))
  obs_rows.append({'case':name,'event':ob['event'],'state_sha256':ob['audit']['state_sha256']})
 normal.append({'name':name,'slots':n,'members':len(cs),'product':product,'solutions':len(sol),'status':p['status'],'observations':len(x['observations'])})
assert len(normal)==15 and len(qual)==23
base=art['qualification-GIVEN-2'];c=base['basis_return']['compiled']
for name,x in art.items():
 if name.startswith('qualification-REFUSAL'):
  point(c,2,x['result'],name);assert x['result']['status']=='UNKNOWN'and x['audit']['status']=='VERIFIED';assert len(x['observations'])==x['audit']['observations']
x=art['qualification-CALLBACK-FALSE-MUTATION'];point(c,2,x['result'],'mutation');assert x['result']['status']=='SAT'and x['audit']['status']=='VERIFIED'
x=art['qualification-CALLBACK-FOREIGN'];assert x['propagated']is True and x['post_exception_state']is None and x['before_throw'][-1]['event']['kind']=='PLACED'
x=art['qualification-SHARED-DAG'];catalogue(x['basis_return']['compiled']);assert x['compiled_check']['status']=='VERIFIED'and[x['result']['status']for x in x['controls']]==['NOT_DERIVABLE','DERIVABLE'];assert len(x['controls'][1]['result']['proof'])==8;expected_proofs['qualification-SHARED-DAG-control-8-whole-proof-check']=(x['controls'][1]['result']['proof'],x['problem'])
assert all(x['receipt']['status']=='REJECTED'for x in art['qualification-DATA-NEGATIVES']['controls'])
main=[]
for case in W['results']:
 cid=case['id'];inp=art[cid+'-input'];b=art[cid+'-full-build'];assert inp['goal']==b.get('compiled',{}).get('goal',inp['goal'])if b['status']=='COMPLETE'else True
 assert b['status']==case['build_status']and b['costs']==case['build_costs']and case['slots']==(6 if cid=='arith-add-zero-at-successor'else8 if cid=='incidence-typing-specialized-line'else16)
 if b['status']=='UNKNOWN':assert b['compiled']is None and b['reason']==case['build_reason']and case['point']['status']==case['control']['status']=='NOT_RUN_INCOMPLETE_BUILD'
 else:
  c=b['compiled'];catalogue(c);assert c['theory']==inp['theory']and c['goal']==inp['goal']and c['profile']==W['profile'];assert case['compiled_audit']==art[cid+'-independent-compiled']and case['compiled_audit']['status']=='VERIFIED'
  n=case['slots'];p=art[cid+'-point-full-result'];point(c,n,p,cid);control=art[cid+'-control-full-result'];assert p['status']==case['point']['status']and p['reason']==case['point']['reason']and p['event_extent']==case['point']['event_extent']and p['stats']==case['point']['statistics']
  assert control['status']==case['control']['status']and control['reason']==case['control']['reason']and control['proof']==case['control']['proof']
  if p['status']=='SAT':
   pr,cert,tiles=selected(c,n,p['selected']);assert pr==art[cid+'-point-decoded-certificate']['proof']==case['point']['proof']==art[cid+'-point-selection-audit']['proof']and tiles==case['point']['tiles'];expected_proofs[cid+'-point-whole-proof-check']=(pr,inp)
  else:assert case['point']['proof']is None and case['point']['tiles']==[]
  if control['status']=='DERIVABLE':
   assert len(control['proof'])<=n and control['proof'][-1]['formula']==inp['goal']and control['details']['distinct_facts']==len(control['proof']);expected_proofs[cid+'-control-whole-proof-check']=(control['proof'],inp)
   padding=n-len(control['proof']);pp=control['details']['padded_proof'];assert len(pp)==n and pp[:padding]==[control['proof'][0]]*padding
   for old,new in zip(control['proof'],pp[padding:]):
    expect=json.loads(wire(old))
    for k in ('antecedent','implication')if old['rule']=='mp'else('source',)if old['rule']=='generalize'else():expect[k]+=padding
    assert new==expect
  else:assert control['status']=='NOT_DERIVABLE'and control['reason']=='FINITE_BASIS_LINE_BOUND'and control['proof']is None and control['details']['exhaustive']is True and control['details']['slots']==n
  assert art[cid+'-whole-case-result']==case
 main.append({'id':cid,'slots':case['slots'],'build':b['status'],'reason':b['reason'],'costs':b['costs'],'point':case['point']['status'],'control':case['control']['status'],'build_seconds':case['build_seconds'],'point_seconds':case['point'].get('seconds'),'control_seconds':case['control'].get('seconds')})
assert len(main)==8 and len(expected_proofs)==29
native=[];program=art['fixed-native-program']
for name,(pr,inp)in expected_proofs.items():
 x=art[name];assert x['status']=='VERIFIED'and x['proof']==pr and x['theory']==inp['theory']and x['goal']==inp['goal']and pr[-1]['formula']==inp['goal']
 assert x['native']['status']=='accepted'and type(x['native']['value'])is int and x['native']['value']==1 and x['independent']['status']=='VERIFIED'and x['independent']['checked_lines']==len(pr)
 assert x['encoding']['status']==x['decoding']['status']=='COMPLETE'and x['decoding']['proof']==pr and x['decoding']['stream_hex']is None
 raw=bytes.fromhex(x['encoding']['stream_hex']);assert len(raw)==x['decoding']['offset']and list(raw)==x['choice']['byte_values']and x['choice']['status']=='VERIFIED'
 v=x['carrier']['value'];assert v['byte_count']==len(raw)==len(v['byte_rows'])and v['known']['target']==inp['goal']and v['known']['theory']==dict(inp['theory'],schemas=[])
 assert v['program_sha256']==H(wire(program)[:-1])and v['nodes'][:len(program['nodes'])]==program['nodes']and v['trusted_prefix_sha256']==H(wire(v['nodes'][:v['trusted_prefix_nodes']])[:-1])
 rows={r['node_index']:r['byte_index']for r in v['byte_rows']}
 assert len(v['nodes'])==len(x['initial_nodes'])and x['final_heap'][:len(x['initial_nodes'])]==x['initial_nodes']and len(x['final_heap'])==x['native']['heap_nodes']
 for j,(before,after)in enumerate(zip(v['nodes'],x['initial_nodes'])):assert after==([raw[rows[j]],before[1]]if j in rows else before)
 census=collections.Counter(line['rule']for line in pr);assert all(x['independent']['rule_counts'][r]==census[r]for r in x['independent']['rule_counts'])
 native.append({'name':name,'lines':len(pr),'bytes':len(raw),'native_steps':x['native']['steps'],'seconds':x['seconds'],'rule_counts':dict(census),'proof_sha256':H(wire(pr))})
for check in W['qualification_checks']:
 full=art[check['id']+'-'+check['lane']+'-whole-proof-check'];assert check['check']['status']=='VERIFIED'and check['check']['independent']==full['independent']and check['check']['native_steps']==full['native']['steps']and check['check']['proof_lines']==len(full['proof'])
assert len(W['qualification_checks'])==25 and sum(x['lines']for x in native)==78 and sum(x['native_steps']for x in native)==2699260
assert W['qualification']['status']=='PASS'and W['qualification']['counts']=={'basis_build':16,'basis_materialize':15,'reference_build':15,'indexed_solve':21,'explicit_solve':15,'core_compiled':19,'core_selection':16,'core_backward':17,'emitted':23,'observations':66}
assert ROOT['rows']==[{k:x[k]for k in x}for x in ROOT['rows']] and ROOT['whole_checks']==len(native)and ROOT['checked_lines']==78 and ROOT['native_steps']==2699260 and ROOT['actual_files']==len(O['files'])and ROOT['stored_bytes']==O['stored_bytes']
oldpath=pathlib.Path('/private/tmp/gcts-first-order-proof-search-20261028-v1/actual/study-001/incidence-typing-specialized-line-full-build.json.gz');old=parse(gzip.decompress(oldpath.read_bytes()))['bundle'];now=art['incidence-typing-specialized-line-full-build']['compiled'];oldpoint=pathlib.Path('/private/tmp/gcts-first-order-proof-search-20261028-v1/actual/study-001/incidence-typing-specialized-line-point-full-result.json.gz');oldp=parse(gzip.decompress(oldpoint.read_bytes()));newp=art['incidence-typing-specialized-line-point-full-result']
assert old['basis']=={k:v for k,v in now['logical_basis'].items()if k!='colors'}and old['instances']==[{k:v for k,v in z.items()if k!='formula_id'}for z in now['zero_instances']]and oldp['selected']==newp['selected']
comparison={'U_build':pin(oldpath),'U_point':pin(oldpoint),'full_basis_projection_equal':True,'all_zero_witness_payloads_equal':True,'selected_virtual_IDs_equal':True,'U_one_cold_build_seconds':0.11153704201569781,'V_one_cold_build_seconds':W['results'][1]['build_seconds'],'U_one_cold_point_seconds':0.16016495900112204,'V_one_cold_point_seconds':W['results'][1]['point']['seconds'],'scope':'One original cold observation per study; no repeated benchmark, causal speed ratio, comparable work-unit or aggregate speedup claim. Qualification/native count and refusal/cache caps/control algorithm differ.'}
support={'schema':'B-V-study001-complete-passive-saved-support-v1','status':'PASS','observer':pin(A/'observer-result.json'),'worker':pin(A/'worker-result.json.gz'),'plan':pin(V/'root/study-once-plan-001.json'),'tool_custody':pin(V/'root/original-study001-tool-custody-v1.json'),'artifacts':refs,'raw_artifact_bytes':sum(r['raw_bytes']for r in refs),'JSON_values':value_count,'JSON_types':dict(types),'physical_files':len(list(A.iterdir())),'physical_bytes':sum(p.stat().st_size for p in A.iterdir()),'observer_listed_files':len(O['files']),'observer_listed_bytes':O['stored_bytes'],'qualification_normal':normal,'all23_qualification_records':qual,'qualification_observation_summaries':obs_rows,'main_cases':main,'point_integrity':point_rows,'rollback_records_joined':rollback_total,'native_checks':native,'comparison_U':comparison,'public_call_ledger':W['outer_public_calls'],'native_actual_rules':dict(sum((collections.Counter(x['rule_counts'])for x in native),collections.Counter())),'scope':'Passive stored byte/JSON/equality/type/hash/arithmetic relations only. No scientific Source/helper/function, codec/VM/checker/proof/search rerun; no main virtual member enumeration or intermediate graph replay. Tiny saved explicit rows allow complete current-domain relational joins; saved exhaustive solution sets are not re-enumerated. Source trust and actual authenticated receipts remain explicit.'}
p=D/'complete-passive-V-study001-support-v1.json';p.write_bytes(wire(support));print(json.dumps({'support':pin(p),'physical_files':support['physical_files'],'physical_bytes':support['physical_bytes'],'raw_artifacts':len(refs),'raw_artifact_bytes':support['raw_artifact_bytes'],'JSON_values':value_count,'normal_models':len(normal),'observed_normal_states':len(obs_rows),'native':len(native),'native_lines':sum(x['lines']for x in native),'rollback_records':rollback_total,'main':main,'native_rules':support['native_actual_rules']},indent=2))
