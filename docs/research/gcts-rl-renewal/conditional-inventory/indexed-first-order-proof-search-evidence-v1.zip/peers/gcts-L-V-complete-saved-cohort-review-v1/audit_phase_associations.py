from pathlib import Path
import json,gzip,hashlib,math
S=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1');A=S/'actual/study-001';O=Path('/private/tmp/gcts-L-V-complete-saved-cohort-review-v1')
def w(v):return(json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(v):return hashlib.sha256(w(v)).hexdigest()
def read(p):return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def ref(p):
 b=p.read_bytes();return{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
R=read(A/'worker-result.json.gz');obs=read(A/'observer-result.json');plan=read(S/'root/study-once-plan-001.json');auth=read(S/'root/study-once-authority-001.json');marker=read(S/'root/study-once-authority-001.json.CONSUMED.json');local=read(A/'CONSUMED.json')
assert marker=={'authority':ref(S/'root/study-once-authority-001.json'),'plan':ref(S/'root/study-once-plan-001.json'),'status':'SPENT'}
assert local=={'authority':ref(S/'root/study-once-authority-001.json'),'consumed':ref(S/'root/study-once-authority-001.json.CONSUMED.json')}
assert read(A/'stdout.bin')==obs['worker_terminal'] and (A/'stderr.bin').read_bytes()==b''
assert obs['retained_streams_complete']=={'stdout':True,'stderr':True}
objs={a['name']:read(Path(a['stored']['path']))for a in R['artifacts']}
checks=[];states=[]
for row in R['results']:
 if row['build_status']!='COMPLETE':continue
 name=row['id'];b=objs[name+'-full-build']['compiled'];p=objs[name+'-point-full-result'];n=row['slots'];forms=b['logical_basis']['formulas'];f=p['families'];rf=[[]for _ in range(n)];dep=[[]for _ in range(n)];reverse=[];degree=[0]*n;factors=[]
 model={'slots':n,'colors':b['logical_basis']['colors'],'goal_id':b['goal_id'],'zero':[[x['id'],x['formula_id']]for x in b['zero_instances']],'mp_index':b['mp_index'],'gen_index':b['gen_index']}
 assert w(model)==w(p['model'])
 for k,(prefix,kind,i,out,a,c)in enumerate(f):
  refs=sorted(range(i),key=str);count=1 if kind=='zero'else i if kind=='gen'else i*i-i
  factors.append([True,[]if kind=='zero'else refs,refs if kind=='mp'else[],count]);degree[i]+=count;rf[i].append(k);d=[i]if kind=='zero'else list(range(i+1));reverse.append(d)
  for j in d:dep[j].append(k)
 state={'schema':'V-indexed-unit-point-state-v1','occupied':[False]*n,'selected':[None]*n,'values':[None]*n,'refs':[0]*n,'excluded':[],'required':['slot:'+str(i)for i in range(n)],'frontier':['slot:'+str(i)for i in range(n)],'root_generations':[0]*n,'degrees':degree,'factors':factors,'row_families':rf,'family_rows':[x[2]for x in f],'marking_dependencies':dep,'reverse_marking_dependencies':reverse}
 assert w(state)==w(p['entry_state'])==w(p['restored_state'])
 for lane in ('point','control'):
  v=row[lane];assert math.isclose(v['pipeline_seconds'],row['build_seconds']+v['seconds'],abs_tol=1e-12)
  expected=v['pipeline_seconds']+row['compiled_audit_seconds']+(v.get('selection_audit_seconds',0))+(v['check']['seconds']if v['check'] else 0)
  assert math.isclose(expected,v['checked_total_seconds'],abs_tol=1e-12)
 if p['status']=='SAT':
  actual=objs[name+'-point-selection-audit'];lines=[None]*n;binds=[];values={};refs={};selected=p['selected'];assert len(selected)==len(set(selected))==n
  z={x['id']:x for x in b['zero_instances']};mp={x[0]:x for x in b['mp_index']};gen={x[0]:x for x in b['gen_index']}
  for cid in selected:
   parts=cid.split(':');i=int(parts[0][1:]);marks={};assert lines[i]is None
   if len(parts)==2:
    zz=z[parts[1]];out=zz['formula_id'];line=zz['line']
   elif parts[1]=='mp':
    fi,a,c=map(int,parts[2:]);_,ant,out=mp[fi];assert a<i and c<i and a!=c;marks={a:ant,c:fi};line={'rule':'mp','formula':forms[out],'antecedent':a,'implication':c}
   else:
    fi,source=map(int,parts[2:]);_,body,var=gen[fi];assert source<i;marks={source:body};out=fi;line={'rule':'generalize','formula':forms[fi],'source':source,'variable':var}
   marks[i]=out;lines[i]=line
   for j,v in marks.items():assert j not in values or values[j]==v;values[j]=v;refs[j]=refs.get(j,0)+1
   binds.append({'id':cid,'t':['slot:'+str(i)],'m':sorted([['out:'+str(j),model['colors'][v]]for j,v in marks.items()])})
  assert w(actual['proof'])==w(lines)==w(row['point']['proof']) and lines[-1]['formula']==row['problem']['goal']
  assert w(sorted(binds,key=lambda x:x['id']))==w(actual['details']['candidate_bindings'])
  cert={'selected':selected,'totals':[1]*n,'markings':[[i,model['colors'][values[i]],refs[i]]for i in range(n)],'generations':[[cid,1]for cid in selected]};assert w(cert)==w(p['certificate'])
  checks.append({'id':name,'selected_rows':n,'full_t_m_and_native_rows':True,'proof_lines':len(lines),'control_proof_lines':len(row['control']['proof'])})
 states.append({'id':name,'initial_full_state_sha256':sha(state),'all_static_factors_and_both_graphs':True,'clock_arithmetic':True})
assert len(states)==4 and len(checks)==2
fullchecks=[x for k,x in objs.items()if k.endswith('-whole-proof-check')];assert len(fullchecks)==29
lines=sum(len(x['proof'])for x in fullchecks);assert lines==78
record={'schema':'V-L-selected-main-and-clock-associations-v1','status':'PASS','prepared_main_initial_and_actual_restored_graphs':states,'main_selected_proofs':checks,'primary_whole_proofs':{'qualifying':25,'main':4,'total':29,'lines':lines,'native_steps_as_stored':sum(x['native']['steps']for x in fullchecks),'scope':'Whole theorem/proof/native/B raw associations read; complementary C lane checks full codec/carrier/native bridge. No project checker or VM replay.'},'whole_clock_and_memory':{'worker_main_entry_elapsed_seconds':obs['worker_terminal']['elapsed_seconds'],'observer_named_whole_seconds':obs['whole_observer_seconds'],'worker_SELF_lifetime_peak_bytes':obs['worker_terminal']['self_lifetime_peak_bytes'],'wait4_child_lifetime_peak_bytes':obs['wait4_peak_bytes'],'scope':'Separate clock origins and lifetime memory scopes; no numerical RSS sum, no hard quota, no invented phase partition. Checked lane totals are algebraically verified; repeated common basis cost appears in each lane total for standalone comparison, not summed as actual cohort wall.'},'once':{'authority':ref(S/'root/study-once-authority-001.json'),'marker':ref(S/'root/study-once-authority-001.json.CONSUMED.json'),'local_marker_receipt':ref(A/'CONSUMED.json'),'spent':True},'actual_size':{'worker_artifacts':90,'worker_artifact_raw_bytes':sum(x['raw_bytes']for x in R['artifacts']),'worker_artifact_stored_bytes':sum(x['stored']['bytes']for x in R['artifacts']),'physical_files':95,'physical_stored_bytes':sum(p.stat().st_size for p in A.iterdir())},'source_calls':0}
p=O/'V-selected-main-and-clock-associations-v1.json'
with p.open('x')as f:f.write(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps({'record':ref(p),'proofs':record['primary_whole_proofs'],'size':record['actual_size']},indent=2))
