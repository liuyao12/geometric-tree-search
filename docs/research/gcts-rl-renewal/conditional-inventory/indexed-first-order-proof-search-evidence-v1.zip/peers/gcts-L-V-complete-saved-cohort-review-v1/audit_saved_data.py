# Administrative saved-data associations only; no subject import/helper/replay.
from pathlib import Path
import json,gzip,hashlib,itertools,collections,stat,math
S=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1');A=S/'actual/study-001';O=Path('/private/tmp/gcts-L-V-complete-saved-cohort-review-v1')
def wire(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def h(b):return hashlib.sha256(b).hexdigest()
def sha(v):return h(wire(v))
def pairs(ps):
 d={}
 for k,v in ps:assert k not in d;d[k]=v
 return d
def load(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in()).throw(AssertionError(x)))
def read(p):return load(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def same(a,b):return wire(a)==wire(b)
def rawref(r):
 p=Path(r['path']);b=p.read_bytes();assert ref(p)==r;return b
W=read(A/'worker-result.json.gz');obs=read(A/'observer-result.json');objects={};census=[]
for row in W['artifacts']:
 b=rawref(row['stored']);raw=gzip.decompress(b) if row['encoding']=='gzip-json' else b
 assert len(raw)==row['raw_bytes'] and h(raw)==row['raw_sha256'];v=load(raw);assert wire(v)==raw
 assert row['name'] not in objects;objects[row['name']]=v;census.append(row)
assert len(census)==90
for r in obs['files']:rawref(r)
assert len(obs['files'])==94 and {Path(r['path']).name for r in obs['files']}=={p.name for p in A.iterdir()}-{'observer-result.json'}
assert len(list(A.iterdir()))==95 and sum(r['bytes']for r in obs['files'])==obs['stored_bytes']
assert {Path(r['stored']['path']).name for r in census}.union({'CONSUMED.json','worker-result.json.gz','stdout.bin','stderr.bin'})=={p.name for p in A.iterdir()}-{'observer-result.json'}
assert all(p.is_file() and not p.is_symlink() and p.stat().st_nlink==1 for p in A.iterdir())
assert obs['status']=='COMPLETE' and obs['returncode']==0 and obs['wait_confirmed'] and obs['both_streams_EOF'] and obs['group_gone'] and obs['failure'] is None and not obs['cleanup_errors']
assert obs['wait4_peak_bytes']<1073741824 and obs['whole_observer_seconds']<240
plan=read(S/'root/study-once-plan-001.json');auth=read(S/'root/study-once-authority-001.json');rawref(auth['plan']);rawref(auth['python']);rawref(auth['runner']);assert auth['authorized'] is True and type(auth['uses'])is int and auth['uses']==1
assert auth['runner']==plan['sources']['runner']
guards=[]
def scan(v):
 if type(v)is dict:
  if set(v)=={'path','bytes','sha256'}:rawref(v);guards.append(v)
  else:
   for x in v.values():scan(x)
 elif type(v)is list:
  for x in v:scan(x)
scan(plan)
tool=read(S/'root/original-study001-tool-custody-v1.json');assert tool['initial']['session_id']==tool['poll']['session_id']==67121 and tool['terminal']['exit_code']==0
outer=load(tool['terminal']['output']);assert outer['status']=='COMPLETE' and outer['receipt']==ref(A/'observer-result.json')
assert obs['worker_terminal']['result']['stored']==ref(A/'worker-result.json.gz') and obs['worker_terminal']['status']=='COMPLETE'
rawref(obs['streams']['stdout']);assert rawref(obs['streams']['stderr'])==b''
# All arithmetic below reads already saved t/m records; no project checker call.
def initial_families(c,n):
 f=[];goal=c['goal_id']
 for i in range(n):
  for z in c['zero_instances']:
   if i!=n-1 or z['formula_id']==goal:f.append(['r%d:%s'%(i,z['id']),'zero',i,z['formula_id'],None,None])
  for imp,a,q in c['mp_index']:
   if i!=n-1 or q==goal:f.append(['r%d:mp:%d:'%(i,imp),'mp',i,q,a,imp])
  for allid,b,v in c['gen_index']:
   if i!=n-1 or allid==goal:f.append(['r%d:gen:%d:'%(i,allid),'gen',i,allid,b,None])
 return sorted(f)
def universe(c,n):
 f=initial_families(c,n);cand={};steps={};forms=c['logical_basis']['formulas'];colors=c['logical_basis']['colors'];z={x['id']:x for x in c['zero_instances']}
 for k,(prefix,kind,i,out,left,right) in enumerate(f):
  if kind=='zero':poss=[(prefix,{},z[prefix.split(':')[1]]['line'],prefix.split(':')[1])]
  elif kind=='gen':
   v=next(v for a,b,v in c['gen_index']if a==out)
   poss=[(prefix+str(a),{a:left},{'rule':'generalize','formula':forms[out],'source':a,'variable':v},None)for a in range(i)]
  else:poss=[(prefix+str(a)+':'+str(b),{a:left,b:right},{'rule':'mp','formula':forms[out],'antecedent':a,'implication':b},None)for a in range(i)for b in range(i)if a!=b or left==right]
  for cid,marks,line,ins in poss:
   marks[i]=out;cand[cid]=(i,marks,k);steps[cid]={'slot':i,'line':line,'instance':ins}
 raw={cid:{'id':cid,'t':['slot:'+str(i)],'m':sorted([['out:'+str(q),colors[v]]for q,v in marks.items()])}for cid,(i,marks,k)in cand.items()}
 return f,cand,steps,raw
def full_sets(raw,n):
 rows=[[cid for cid,v in raw.items()if v['t']==['slot:'+str(i)]]for i in range(n)];prod=math.prod(map(len,rows));assert prod<=20000
 good=[]
 for ids in itertools.product(*rows):
  values={};ok=True
  for cid in ids:
   for p,v in raw[cid]['m']:
    if p in values and values[p]!=v:ok=False;break
    values[p]=v
   if not ok:break
  if ok:good.append(tuple(sorted(ids)))
 return prod,sorted(good)
def state_check(c,n,f,cands,s,solutions=None):
 colors=c['logical_basis']['colors'];selected=[x for x in s['selected']if x is not None];values=[None]*n;refs=[0]*n
 assert len(s['occupied'])==len(s['selected'])==len(s['values'])==len(s['refs'])==n
 assert all(type(x)is bool for x in s['occupied']) and all(type(x)is int and x>=0 for x in s['refs'])
 for i,cid in enumerate(s['selected']):
  assert s['occupied'][i]==(cid is not None)
  if cid is None:continue
  row,marks,k=cands[cid];assert row==i and cid not in s['excluded']
  for p,v in marks.items():assert values[p]is None or values[p]==v;values[p]=v;refs[p]+=1
 assert same(values,s['values']) and same(refs,s['refs'])
 assert all(x is None or type(x)is int for x in s['values']);assert s['excluded']==sorted(set(s['excluded'])) and all(x in cands for x in s['excluded'])
 legal=[[]for _ in range(n)];cnt=[0]*len(f)
 for cid,(i,marks,k)in cands.items():
  if not s['occupied'][i] and cid not in s['excluded'] and all(values[p]is None or values[p]==v for p,v in marks.items()):legal[i].append(cid);cnt[k]+=1
 factors=[];byrow=[[]for _ in range(n)];deps=[[]for _ in range(n)];reverse=[]
 for k,(prefix,kind,i,out,a,b)in enumerate(f):
  byrow[i].append(k);r=[i]if kind=='zero'else list(range(i+1));reverse.append(r)
  for p in r:deps[p].append(k)
  enabled=not s['occupied'][i] and (values[i]is None or values[i]==out)
  factors.append([True,([]if kind=='zero'else sorted([j for j in range(i)if values[j]is None or values[j]==a],key=str)),([]if kind!='mp'else sorted([j for j in range(i)if values[j]is None or values[j]==b],key=str)),cnt[k]]if enabled else[False,[],[],0])
 expected={'required':['slot:'+str(i)for i in range(n)],'frontier':['slot:'+str(i)for i in range(n)if not s['occupied'][i]],'root_generations':[0]*n,'degrees':list(map(len,legal)),'factors':factors,'row_families':byrow,'family_rows':[x[2]for x in f],'marking_dependencies':deps,'reverse_marking_dependencies':reverse}
 for k,v in expected.items():assert same(s[k],v),k
 if solutions is not None:
  for cid in s['excluded']:assert not any(set(selected+[cid])<=set(sol)for sol in solutions)
 return [sorted(x)for x in legal]
def result_restore(v):
 assert same(v['entry_state'],v['restored_state']);assert v['state_hashes']=={'entry':sha(v['entry_state']),'restored':sha(v['restored_state'])}
 assert sum(x['undone']for x in v['rollback_records'])==v['stats']['trail_writes']==v['stats']['trail_undos']
 for r in v['rollback_records']:
  if r['reason']=='FAILED_CHILD':assert r['after_core_sha256']==r['expected_parent_core_sha256']
  else:assert r['target']==0 and r['full_restored_sha256']==v['state_hashes']['restored']
qual=[];proofs=[];observed=0;product_total=solution_total=members=0;event_kinds=collections.Counter()
normal=[(k,v)for k,v in objects.items()if k.startswith('qualification-')and 'case'in v]
assert len(normal)==15
for name,v in normal:
 c=v['basis_return']['compiled'];n=v['slots'];assert v['basis_return']['status']=='COMPLETE';f,cands,steps,raw=universe(c,n)
 for holder in ('materialized','reference'):
  b=v[holder]['bundle'];assert same({x['id']:x for x in b['model']['candidates']},raw) and same(b['steps'],steps);assert len(b['model']['candidates'])==len(raw)
  assert same(b['basis'],{k:x for k,x in c['logical_basis'].items()if k!='colors'}) and same(b['instances'],[{k:x for k,x in z.items()if k!='formula_id'}for z in c['zero_instances']])
 prod,sol=full_sets(raw,n);assert prod==v['product'] and same([list(x)for x in sol],sorted(v['full_solution_ID_sets']))
 product_total+=prod;solution_total+=len(sol);members+=len(raw)
 assert v['indexed']['status']==v['explicit']['status']==('SAT'if sol else'UNSAT')
 assert v['backward']['status']==('DERIVABLE'if sol else'NOT_DERIVABLE')
 assert same(v['indexed']['families'],f)
 previous=None;event_bytes=b''
 for row in v['observations']:
  e,s=row['event'],row['state'];legal=state_check(c,n,f,cands,s,sol);assert sha(s)==row['audit']['state_sha256'];assert legal==row['audit']['legal_ids'];assert row['audit']['status']=='VERIFIED'
  assert e['seq']==len(event_bytes.splitlines());event_bytes+=wire(e);event_kinds[e['kind']]+=1
  if previous is not None:
   old,oldlegal=previous
   if e['kind']=='BRANCH':
    front=[i for i in range(n)if not old['occupied'][i]];assert all(len(oldlegal[i])>=2 for i in front);q=min(front,key=lambda i:(len(oldlegal[i]),'slot:'+str(i)));assert e['data']['row']==q and e['data']['first_candidate']==oldlegal[q][0]
   elif e['kind']=='PLACED':
    d=e['data'];assert d['candidate']in oldlegal[d['row']]
    if d['forced']:
     front=[i for i in range(n)if not old['occupied'][i]];assert all(oldlegal[i]for i in front);q=min([i for i in front if len(oldlegal[i])==1],key=lambda i:'slot:'+str(i));assert q==d['row']
   elif e['kind']=='DEAD':assert not legal[e['data']['row']]
  previous=(s,legal);observed+=1
 p=v['indexed'];assert p['event_extent']['SHA256']==h(event_bytes) and p['events']==[r['event']for r in v['observations']];assert p['event_extent']['JSONL_bytes']==len(event_bytes);result_restore(p)
 state_check(c,n,f,cands,p['entry_state']);state_check(c,n,f,cands,p['restored_state'])
 if sol:
  assert tuple(p['selected'])in sol and tuple(sorted(v['explicit']['selected']))in sol
  for lane,key in [('point','core_selection'),('explicit','explicit_selection'),('control','backward')]:
   proof=v[key]['proof'];proofs.append((name,lane,v['problem'],proof));assert proof[-1]['formula']==v['problem']['goal']
 assert same(v['explicit']['entry_state'],v['explicit']['restored_state'])
 qual.append({'name':name,'slots':n,'candidates':len(raw),'families':len(f),'product':prod,'full_solutions':len(sol),'indexed':p['status'],'backward':v['backward']['status'],'observations':len(v['observations']),'event_kinds':dict(collections.Counter(r['event']['kind']for r in v['observations']))})
# Separate control profiles and saved observations, without replay.
given=objects['qualification-GIVEN-2'];c=given['basis_return']['compiled'];f,cands,steps,raw=universe(c,2)
refusals=[]
for field in ['nodes','operations','families','virtual-members']:
 v=objects['qualification-REFUSAL-max-'+field];p=v['result'];assert p['status']=='UNKNOWN' and p['selected']is None and p['certificate']is None
 if p['entry_state']is None:assert p['restored_state']is None and p['state_hashes']=={'entry':None,'restored':None} and p['families']is None
 else:result_restore(p);state_check(c,2,f,cands,p['entry_state'])
 for row in v['observations']:state_check(c,2,f,cands,row['state']);observed+=1
 refusals.append({'field':field,'reason':p['reason'],'model_present':p['model']is not None,'entry_present':p['entry_state']is not None,'events':p['event_extent']['count']})
v=objects['qualification-CALLBACK-FALSE-MUTATION'];assert v['result']['status']=='SAT';result_restore(v['result'])
for row in v['observations']:state_check(c,2,f,cands,row['state']);observed+=1
foreign=objects['qualification-CALLBACK-FOREIGN'];assert foreign['propagated']is True and foreign['post_exception_state']is None and foreign['before_throw'][-1]['event']['kind']=='PLACED'
for row in foreign['before_throw']:state_check(c,2,f,cands,row['state']);observed+=1
neg=objects['qualification-DATA-NEGATIVES']['controls'];assert len(neg)==4 and all(x['receipt']['status']=='REJECTED'for x in neg)
shared=objects['qualification-SHARED-DAG'];assert [x['result']['status']for x in shared['controls']]==['NOT_DERIVABLE','DERIVABLE'];assert len(shared['controls'][1]['result']['proof'])==8
proofs.append(('qualification-SHARED-DAG-control-8','shared',shared['problem'],shared['controls'][1]['result']['proof']))
assert len(proofs)==25 and observed==66
qwhole=objects['whole-indexed-point-qualification'];assert same(qwhole,W['qualification']) and qwhole['counts']['observations']==66
# Exact associations to all saved qualifying whole native check objects.
for name,lane,problem,proof in proofs:
 artifact=name+'-whole-proof-check' if lane=='shared' else name+'-'+lane+'-whole-proof-check'
 check=objects[artifact];assert same(check['proof'],proof) and same(check['theory'],problem['theory']) and same(check['goal'],problem['goal'])
 assert check['status']=='VERIFIED' and check['independent']['status']=='VERIFIED' and check['native']['value']==1
# Eight unchanged main cases; independent large static cardinalities, not full trace replay.
main=[]
for row in W['results']:
 name=row['id'];inp=objects[name+'-input'];assert same({k:v for k,v in inp.items()if k!='slots'},row['problem']) and inp['slots']==row['slots']
 build=objects[name+'-full-build'];assert build['status']==row['build_status'];n=row['slots']
 if build['status']=='UNKNOWN':
  assert build['compiled']is None and row['point']['status']==row['control']['status']=='NOT_RUN_INCOMPLETE_BUILD';assert build['reason']==row['build_reason']
  main.append({'id':name,'slots':n,'build':'UNKNOWN','build_reason':build['reason'],'build_seconds':row['build_seconds'],'point':'NOT_RUN_INCOMPLETE_BUILD','control':'NOT_RUN_INCOMPLETE_BUILD'});continue
 c=build['compiled'];forms=c['logical_basis']['formulas'];colors=[json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'))for v in forms];assert same(colors,c['logical_basis']['colors']) and colors==sorted(set(colors))
 idx={x:i for i,x in enumerate(colors)};mp=[];gen=[]
 for i,v in enumerate(forms):
  if v[0]=='imp':
   a,b=[json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'))for x in v[1:]]
   if a in idx and b in idx:mp.append([i,idx[a],idx[b]])
  if v[0]=='all':
   b=json.dumps(v[2],sort_keys=True,ensure_ascii=True,separators=(',',':'))
   if b in idx:gen.append([i,idx[b],v[1]])
 assert same(mp,c['mp_index']) and same(gen,c['gen_index'])
 p=objects[name+'-point-full-result'];control=objects[name+'-control-full-result'];assert p['status']==row['point']['status'] and control['status']==row['control']['status'];f=initial_families(c,n);assert same(p['families'],f)
 members=sum(1 if k=='zero' else i if k=='gen' else i*i-i for prefix,k,i,out,a,b in f);links=sum(1 if k=='zero' else i+1 for prefix,k,i,out,a,b in f)
 assert p['stats']['families']==len(f) and p['stats']['virtual_members']==members and p['stats']['dependency_links']==links
 result_restore(p);assert p['model_sha256']==sha(p['model']);assert all(not x for x in p['entry_state']['occupied']) and all(x is None for x in p['entry_state']['values'])
 assert p['selected']is None and p['certificate']is None if p['status']=='UNKNOWN' else p['selected']is not None
 assert len(p['events'])==p['event_extent']['retained']<=p['event_extent']['count'] and all(e['seq']==i for i,e in enumerate(p['events']))
 if p['event_extent']['count']==len(p['events']):assert h(b''.join(wire(e)for e in p['events']))==p['event_extent']['SHA256']
 if p['status']=='SAT':
  audit=objects[name+'-point-selection-audit'];assert audit['status']=='VERIFIED' and same(audit['proof'],row['point']['proof'])
  for lane,key in [('point','point'),('control','control')]:
   chk=objects[name+'-'+lane+'-whole-proof-check'];proof=row[key]['proof'];assert same(chk['proof'],proof) and same(chk['theory'],inp['theory']) and same(chk['goal'],inp['goal']);assert chk['independent']['status']=='VERIFIED'and chk['native']['value']==1
 else:assert control['status']=='NOT_DERIVABLE' and control['reason']=='FINITE_BASIS_LINE_BOUND' and control['proof']is None and control['details']['exhaustive']is True
 main.append({'id':name,'slots':n,'build':'COMPLETE','formulas':len(forms),'instances':len(c['zero_instances']),'families':len(f),'virtual_members':members,'dependency_links':links,'build_seconds':row['build_seconds'],'point':p['status'],'point_reason':p['reason'],'point_seconds':row['point']['seconds'],'control':control['status'],'control_reason':control['reason'],'control_seconds':row['control']['seconds'],'control_states':control['details']['states'],'control_transitions':control['details']['transitions'],'point_retained_events':len(p['events']),'point_event_count':p['event_extent']['count'],'trail_writes_undone':p['stats']['trail_undos'],'checked_point_seconds':row['point']['checked_total_seconds'],'checked_control_seconds':row['control']['checked_total_seconds']})
assert len(main)==8 and sum(x['build']=='COMPLETE'for x in main)==4
support={'schema':'V-L-complete-saved-cohort-audit-support-v1','status':'PASS','all_raw_artifacts':census,'worker':ref(A/'worker-result.json.gz'),'observer':ref(A/'observer-result.json'),'current_guard_refs':guards,'qualification':qual,'qualification_totals':{'models':len(qual),'products':product_total,'full_tilings':solution_total,'candidate_rows':members if False else sum(x['candidates']for x in qual),'observations':observed,'event_kinds_normal':dict(event_kinds),'proof_associations':len(proofs)},'refusals':refusals,'negative_mutations':[x['mutation']for x in neg],'shared_controls':[{'slots':x['slots'],'status':x['result']['status'],'details':{k:v for k,v in x['result']['details'].items()if k!='padded_proof'}}for x in shared['controls']],'main_cases':main,'custody':{'actual_physical_files':95,'observer_inventory':94,'worker_artifacts':90,'stored_preobserver_bytes':obs['stored_bytes'],'worker_seconds':obs['worker_terminal']['elapsed_seconds'],'observer_seconds':obs['whole_observer_seconds'],'wait4_peak_bytes':obs['wait4_peak_bytes'],'worker_SELF_peak_bytes':obs['worker_terminal']['self_lifetime_peak_bytes'],'original_tool':ref(S/'root/original-study001-tool-custody-v1.json'),'owned_terminal_exit':0,'source_calls_in_audit':0},'scope':'Saved-data-only standard JSON/gzip/hash and finite tiny t/m arithmetic; no project imports/functions/checkers/solvers/VM/source/CLI replay. Tiny products independently enumerated from already saved complete candidate records. Main finite negative control receipts rely on complete Source-reviewed DFS, not a saved exhaustive refutation tree. Main capped event hashes cannot be reconstructed from prefix bodies; no full intermediate audit claim.'}
with (O/'V-complete-independent-saved-cohort-audit-support-v1.json').open('x')as f:f.write(json.dumps(support,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':'PASS','support':ref(O/'V-complete-independent-saved-cohort-audit-support-v1.json'),'qualification_totals':support['qualification_totals'],'main':main,'custody':support['custody']},indent=2))
