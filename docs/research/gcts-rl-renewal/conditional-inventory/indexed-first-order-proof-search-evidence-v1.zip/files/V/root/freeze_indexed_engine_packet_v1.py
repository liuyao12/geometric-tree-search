"""Metadata and discarded syntax compilation only; no subject import/call."""
from pathlib import Path
import ast
import hashlib
import json

R = Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1/root')
source = R / 'indexed_proof_point_search_v1.py'
raw = source.read_bytes()
tree = ast.parse(raw)
compile(raw, str(source), 'exec', dont_inherit=True)
def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
api = json.loads((R / 'indexed-point-engine-prefrozen-ABI-v1.json').read_bytes())
api.update(
    schema='V-indexed-proof-point-engine-complete-public-ABI-v1',
    status='FROZEN_SOURCE_ONLY_NO_CALLS', Source=ref(source),
    VERSION='V-INDEXED-UNIT-PROOF-POINT-SEARCH-v1',
    model_exact6=['slots', 'colors', 'goal_id', 'zero', 'mp_index', 'gen_index'],
    family_exact6=['prefix', 'kind', 'row', 'output_id', 'left_id_or_null', 'right_id_or_null'],
    family_order='Whole literal prefix lexical order, static final-goal filtering before family materialization. Each prefix defines a disjoint virtual ID block. Factors use lexical str(index) order.',
    factor_exact4=['output_enabled', 'left_refs', 'right_refs', 'eligible_count'],
    snapshot_exact15=['occupied', 'selected', 'values', 'refs', 'excluded', 'schema',
                     'required', 'frontier', 'root_generations', 'degrees', 'factors',
                     'row_families', 'family_rows', 'marking_dependencies', 'reverse_marking_dependencies'],
    result_exact17=['schema', 'version', 'status', 'reason', 'model', 'families', 'model_sha256',
                    'selected', 'certificate', 'stats', 'events', 'event_extent', 'entry_state',
                    'restored_state', 'state_hashes', 'rollback_records', 'scope'],
    event_extent_exact5=['count', 'retained', 'JSONL_bytes', 'SHA256', 'evaluation_complete'],
    events=['ENTRY', 'DEAD', 'ROLLBACK', 'EXCLUDED', 'SOLUTION', 'PLACED', 'BRANCH'],
    certificate_exact4=['selected', 'totals', 'markings', 'generations'],
    snapshot_notes='values are out:i formula ID or None; refs are actual assignment multiplicities. Selected/occupied are row ordered; required/frontier name slot:i. Factors align result families; row_families and family_rows store both incidence directions. Static recipes/colors are in model/families or independently reconstructed from compiled+slots. Root generations0; dependencies conservative. Detached snapshots.',
    callback_exception_scope='Foreign exception propagates after mandatory undo. No hidden state receipt is returned to a throwing observer. Runtime tests may check propagation and normal/budget restoration images; throwing-callback cleanup additionally relies on full Source trail coverage. Do not fabricate post-exception observations.',
    return_scope='Point-model hash binds colors/indexes/zero identities/slots, not full native schema payload. Root separately binds complete compiled raw artifact and actual C1+B certificate checks. V stats/events are not old S wire.'
)
api_path = R / 'indexed-point-engine-complete-public-ABI-v1.json'
api_path.write_text(json.dumps(api, indent=2, sort_keys=True) + '\n')
handoff = dict(schema='V-indexed-point-engine-inert-handoff-v1', status='FROZEN_SOURCE_ONLY',
               Source=ref(source), API=ref(api_path),
               named_units=sum(isinstance(x, (ast.FunctionDef, ast.ClassDef)) for x in ast.walk(tree)),
               syntax='AST and unused compile pass, no subject execution.',
               equivalence='Exact finite virtual U identities via full factor products, compatible markings and scoped exclusions. Not a sampled proposal graph.',
               remaining='Complete independent Source peer and Root current Source/caller adoption plus fresh owned once before any subject import/function/fixture/search/checker call.')
packet = R / 'indexed-point-engine-complete-inert-handoff-v1.json'
packet.write_text(json.dumps(handoff, indent=2, sort_keys=True) + '\n')
print(json.dumps(handoff))
