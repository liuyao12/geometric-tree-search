"""Saved JSON arithmetic and HTML materialization only. No scientific calls."""
from pathlib import Path
import collections,gzip,hashlib,json
R=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1/root')
A=R.parent/'actual/study-001'
def load(p):
 p=Path(p);b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
o=load(A/'observer-result.json')
assert o['status']=='COMPLETE'
w=load(o['worker_terminal']['result']['stored']['path'])
assert w['status']=='COMPLETE'
plan=load(R/'study-once-plan-001.json')
design=load(R/'prospective-design-v1.json')
artifacts={x['name']:x for x in w['artifacts']}
def artifact(name):return load(artifacts[name]['stored']['path'])
cases=[]
for original in w['results']:
 row=json.loads(json.dumps(original))
 row['candidate_count']=None
 row['graph_counts']=None
 if row['build_status']=='COMPLETE':
  answer=artifact(row['id']+'-point-full-result')
  if answer['entry_state'] is not None:
   row['graph_counts']={'members':answer['stats']['virtual_members'],'families':answer['stats']['families']}
 for tile in row['point'].get('tiles',[]):
  assert len(tile['t'])==1
  tile['slot']=int(tile['t'][0].split(':')[1])
 cases.append(row)
checks=[]
for p in sorted(A.glob('*-whole-proof-check.json*')):
 x=load(p)
 assert x['status']=='VERIFIED' and x['native']['status']=='accepted' and type(x['native']['value']) is int and x['native']['value']==1 and x['independent']['status']=='VERIFIED'
 checks.append(dict(artifact=ref(p),proof_lines=len(x['proof']),proof_bytes=len(bytes.fromhex(x['encoding']['stream_hex'])),native_steps=x['native']['steps'],seconds=x['seconds'],native_status=x['native']['status'],native_value=x['native']['value'],independent=x['independent']['status']))
normal=[]
for name,item in artifacts.items():
 if name.startswith('qualification-') and not name.endswith('-whole-proof-check'):
  q=load(item['stored']['path'])
  if 'full_solution_ID_sets' in q:
   normal.append(dict(id=q['case']+'-'+str(q['slots']),status=q['graph_audit']['status'],transitions=q['product'],solutions=len(q['full_solution_ID_sets'])))
assert len(normal)==15 and len(w['qualification_checks'])==25 and w['qualification']['status']=='PASS'
complete=[x for x in cases if x['build_status']=='COMPLETE']
ps=[x for x in cases if x['point']['status']=='SAT']
cs=[x for x in cases if x['control']['status']=='DERIVABLE']
main=set(design['cohorts']['main'])
pm=[x for x in ps if x['id'] in main];cm=[x for x in cs if x['id'] in main]
assert len(checks)==25+len(ps)+len(cs)
refusals=collections.Counter(x.get('build_reason') for x in cases if x['build_status']!='COMPLETE')
build_total=sum(x['build_seconds'] for x in cases)
findings=[
 f"The compact compiler completed {len(complete)} of eight unchanged prospective inputs. GCTS point search produced {len(ps)} verified certificates; the same-basis backward shared-DAG control produced {len(cs)}. Among the six substantive arithmetic/geometry targets, the counts are {len(pm)} and {len(cm)} respectively. Neither lane received a proof sequence.",
 'Compilation refusals: '+(', '.join(f'{k}: {v}' for k,v in sorted(refusals.items())) if refusals else 'none')+'. An unfinished catalogue or resource-limited search remains UNKNOWN; it does not establish unprovability.',
 f"All {len(checks)} recorded whole-certificate checks passed actual unchanged native C1 and the independent first-order checker, totaling {sum(x['proof_lines'] for x in checks)} checked lines. Twenty-five certificates belong to qualification. The whole original worker took {o['worker_terminal']['elapsed_seconds']:.4f} seconds, including failed work, audits, logging and verification.",
 f"Common catalogue construction took {build_total:.4f} seconds in total; native proof checks took {sum(x['seconds'] for x in checks):.4f} seconds. Phase samples are not a partition of the whole run. Search pipelines and checked totals are retained in the results JSON. This is one cold run, without a statistical speed claim."]
neg=[x for x in cases if x['control']['status']=='NOT_DERIVABLE']
assessment=[
 'The conventional control was faster on both successful calibrations and resolved two finite bounded cases where GCTS timed out. This configuration demonstrates no GCTS search advantage.',
 'The negative control outcomes rely on the reviewed exhaustive algorithm and its saved exhaustion receipts. A separate, independently checkable refutation tree is not stored.',
 f'The backward control exhausted {len(neg)} completed catalogues within the declared line bound; GCTS reached its wall limit on those cases. These are finite-catalogue negatives, not proofs that the target statements are false or unprovable from the full axioms. Catalogue coverage and the line bound remain possible limitations.',
 'Both search lanes benefit from the compact compiler. A GCTS-specific contribution still requires a measured gain from its markings or cluster search.',
 'Lossless structural sharing and exact factorized candidate counts address the eager-construction bottleneck without deliberately dropping formulas, rule witnesses or row references. Source arguments cover the declared catalogue construction; fifteen exhaustive tiny models confirm its projection and graph behavior on those models. Tiny observations do not establish unrestricted first-order completeness.',
 ('The conventional backward control solved more cases than the indexed point engine in this cohort. That is evidence against a GCTS advantage in this configuration; it suggests that relevance to the goal and sharing established facts are more useful here than generic row-tiling search.' if len(cs)>len(ps) else 'The two lanes provide a concrete within-catalogue comparison. Any difference concerns these bounded inputs and implementations; it does not establish superiority over existing theorem provers.'),
 'A useful next experiment is a checked inventory of conditional cluster families. The same acquired lemmas and acquisition/invocation costs must be available to a conventional control. RL can propose instantiated clusters while the complete base-tile fallback and native checker preserve the validity boundary. No new RL training is claimed here.']
data=dict(cases=cases,findings=findings,assessment=assessment,
 profile=dict(generation_profile=w['profile'],limits=w['limits'],design=design,original_worker_seconds=o['worker_terminal']['elapsed_seconds'],original_observer_seconds=o['whole_observer_seconds'],child_wait4_peak_bytes=o['wait4_peak_bytes'],common_compilation_seconds=build_total,all_kernel_bridge_seconds=sum(x['seconds'] for x in checks),cost_scope='One cold run. Cooperative component samples; checked_total includes compiled/selected audits and certificate checking. Common native initialization and qualification separate. Output tails excluded from component clocks but captured by whole worker. No hard OS quota or work-unit equivalence.'),
 bridge_summary=f"Fifteen exhaustive tiny models checked the complete virtual candidate universe and every observed indexed graph against independent enumeration. All {sum(x['transitions'] for x in normal)} full row combinations were enumerated, yielding {sum(x['solutions'] for x in normal)} satisfying assignments across the fifteen separate models. Separate controls covered four resource refusals, detached/mutating and throwing observers, four data forgeries, and shared-premise proof bounds. The solvers each returned one witness where successful; they did not enumerate all solutions.",bridge_controls=normal)
public=dict(schema='V-indexed-first-order-proof-search-public-results-v1',observed=w,reader=data,all_native_checks=checks,original_observer=ref(A/'observer-result.json'),original_worker=ref(o['worker_terminal']['result']['stored']['path']),source_pins=plan['sources'],metadata_pins=plan['metadata'],scientific_admission=ref(R/'Root-study001-complete-scientific-admission-v1.json'),native_check_totals=dict(certificates=len(checks),lines=sum(x['proof_lines'] for x in checks),bytes=sum(x['proof_bytes'] for x in checks),native_steps=sum(x['native_steps'] for x in checks)),interpretation='Bounded symbolic point adaptation with remote markings; all native proofs checked. Complete compressed candidate counts rather than sampled proposals. No new RL, fixed universal literal Wang palette, unrestricted FOL/PA/Hilbert completeness or broad superiority claim.')
html=(R/'indexed-first-order-reader-template-v4.html').read_text()
embedded=json.dumps(data,ensure_ascii=True,sort_keys=True,separators=(',',':')).replace('<','\\u003c').replace('&','\\u0026')
assert html.count('__RESEARCH_DATA__')==1
html=html.replace('__RESEARCH_DATA__',embedded)
out=R/'report-draft';out.mkdir(exist_ok=True)
for name,b in [('indexed-first-order-proof-search-v1.html',html.encode()),('indexed-first-order-proof-search-results-v1.json',(json.dumps(public,indent=2,sort_keys=True,ensure_ascii=True)+'\n').encode())]:
 p=out/name
 with p.open('xb') as f:f.write(b)
 assert p.read_bytes()==b
 print(json.dumps(ref(p),sort_keys=True))
