"""Complete indexed unit-point proof-row search. No module-body subject calls.

Virtual members denote the full U row/reference universe. Families are an
exact compressed graph, never a proposal shortlist. No FOL kernel is here.
"""
import hashlib
import json
import math
import time

VERSION = 'V-INDEXED-UNIT-PROOF-POINT-SEARCH-v1'


class InputError(ValueError):
    pass


class _Stop(Exception):
    def __init__(self, owner, reason):
        self.owner, self.reason = owner, reason


def _need(ok, reason):
    if not ok:
        raise InputError(reason)


def _wire(x):
    return (json.dumps(x, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _hash(x):
    return hashlib.sha256(_wire(x)).hexdigest()


class _Meter:
    def __init__(self, limits):
        _need(type(limits) is dict and set(limits) == {'wall_seconds', 'max_nodes',
              'max_operations', 'max_families', 'max_virtual_members', 'max_events'}, 'limits exact6')
        wall = limits['wall_seconds']
        _need(type(wall) in (int, float) and 0 < wall <= 60 and math.isfinite(wall), 'wall')
        _need(all(type(v) is int and 0 <= v <= 10**12 for k, v in limits.items()
                  if k != 'wall_seconds'), 'integer limits')
        self.limits = dict(limits)
        self.start = time.perf_counter()
        self.stats = {k: 0 for k in ('operations', 'nodes', 'families', 'virtual_members',
            'dependency_links', 'family_refreshes', 'placements', 'forced_placements',
            'branch_decisions', 'backtracks', 'scoped_exclusions', 'trail_writes',
            'trail_undos', 'max_trail', 'cleanup_undos', 'observations', 'events')}

    def tick(self, n=1):
        if n > self.limits['max_operations'] - self.stats['operations']:
            raise _Stop(self, 'MAX_OPERATIONS')
        self.stats['operations'] += n
        if time.perf_counter() - self.start >= self.limits['wall_seconds']:
            raise _Stop(self, 'WALL_SECONDS')

    def node(self):
        self.tick()
        if self.stats['nodes'] >= self.limits['max_nodes']:
            raise _Stop(self, 'MAX_NODES')
        self.stats['nodes'] += 1


def _point_model(compiled, n, m):
    _need(type(compiled) is dict and compiled.get('schema') == 'V-interned-Hilbert8-basis-v1'
          and compiled.get('version') == 'V-INTERNED-FINITE-HILBERT8-v1', 'compiled identity')
    _need(type(n) is int and 1 <= n <= 64, 'slots')
    colors = compiled['logical_basis']['colors']
    _need(type(colors) is list and all(type(c) is str for c in colors), 'literal colors')
    m.tick(sum(len(c) + 1 for c in colors))
    _need(colors == sorted(set(colors)), 'unique canonical-order colors')
    size = len(colors)
    def fid(x):
        _need(type(x) is int and 0 <= x < size, 'formula ID')
        return x
    goal = fid(compiled['goal_id'])
    zero = []
    for i, row in enumerate(compiled['zero_instances']):
        m.tick()
        _need(type(row) is dict and row.get('id') == 'i' + str(i), 'zero identity')
        zero.append([row['id'], fid(row['formula_id'])])
    imps, gens = [], []
    for row in compiled['mp_index']:
        m.tick(); _need(type(row) is list and len(row) == 3, 'MP triple')
        imps.append([fid(x) for x in row])
    for row in compiled['gen_index']:
        m.tick(); _need(type(row) is list and len(row) == 3 and type(row[2]) is str, 'GEN triple')
        gens.append([fid(row[0]), fid(row[1]), row[2]])
    _need([r[0] for r in imps] == sorted(set(r[0] for r in imps))
          and [r[0] for r in gens] == sorted(set(r[0] for r in gens)), 'unique ordered index heads')
    return dict(slots=n, colors=list(colors), goal_id=goal, zero=zero, mp_index=imps, gen_index=gens)


class _State:
    def __init__(self, model, meter):
        self.model, self.m = model, meter
        self.n = n = model['slots']
        self.occupied = [False] * n
        self.selected = [None] * n
        self.values = [None] * n
        self.refs = [0] * n
        self.degrees = [0] * n
        self.families, self.factors, self.excluded = [], [], []
        self.row_families = [[] for _ in range(n)]
        self.mark_deps = [set() for _ in range(n)]
        self.family_deps, self.by_prefix = [], {}
        self.lex_refs = [tuple(sorted(range(i), key=str)) for i in range(n)]
        self.trail = []
        last = sum(out == model['goal_id'] for iid, out in model['zero'])
        last += sum(out == model['goal_id'] for implication, antecedent, out in model['mp_index'])
        last += sum(universal == model['goal_id'] for universal, body, variable in model['gen_index'])
        predicted = (n - 1) * (len(model['zero']) + len(model['mp_index']) + len(model['gen_index'])) + last
        if predicted > meter.limits['max_families']:
            raise _Stop(meter, 'MAX_FAMILIES')
        recipes = []
        for i in range(n):
            for iid, out in model['zero']:
                meter.tick()
                if i != n - 1 or out == model['goal_id']:
                    recipes.append(('r' + str(i) + ':' + iid, 'zero', i, out, None, None))
            for implication, antecedent, out in model['mp_index']:
                meter.tick()
                if i != n - 1 or out == model['goal_id']:
                    recipes.append(('r' + str(i) + ':mp:' + str(implication) + ':',
                                    'mp', i, out, antecedent, implication))
            for universal, body, variable in model['gen_index']:
                meter.tick()
                if i != n - 1 or universal == model['goal_id']:
                    recipes.append(('r' + str(i) + ':gen:' + str(universal) + ':',
                                    'gen', i, universal, body, None))
        _need(len(recipes) == predicted, 'complete static family preflight')
        meter.tick(len(recipes) * max(1, len(recipes).bit_length()))
        for recipe in sorted(recipes):
            prefix, kind, row, out, left, right = recipe
            meter.tick()
            if row == n - 1 and out != model['goal_id']:
                continue
            if len(self.families) >= meter.limits['max_families']:
                raise _Stop(meter, 'MAX_FAMILIES')
            index = len(self.families)
            self.families.append(recipe)
            self.by_prefix[prefix] = index
            self.row_families[row].append(index)
            support = tuple(range(row + 1)) if kind != 'zero' else (row,)
            self.family_deps.append(support)
            for point in support:
                meter.tick(); self.mark_deps[point].add(index)
                meter.stats['dependency_links'] += 1
            self.excluded.append(set())
            factor = self.factor(index)
            self.factors.append(factor)
            self.degrees[row] += factor[3]
            meter.stats['families'] += 1
            meter.stats['virtual_members'] += factor[3]
            if meter.stats['virtual_members'] > meter.limits['max_virtual_members']:
                raise _Stop(meter, 'MAX_VIRTUAL_MEMBERS')

    def put(self, array, key, value):
        self.m.tick()
        if array[key] == value:
            return
        self.trail.append(('array', array, key, array[key]))
        array[key] = value
        self.m.stats['trail_writes'] += 1
        self.m.stats['max_trail'] = max(self.m.stats['max_trail'], len(self.trail))

    def compatible(self, point, formula):
        value = self.values[point]
        return value is None or value == formula

    def parse(self, cid):
        _need(type(cid) is str, 'member string')
        parts = cid.split(':')
        if len(parts) == 2:
            prefix, a, b = cid, None, None
        elif len(parts) == 4 and parts[1] == 'gen':
            prefix, a, b = ':'.join(parts[:3]) + ':', int(parts[3]), None
        elif len(parts) == 5 and parts[1] == 'mp':
            prefix, a, b = ':'.join(parts[:3]) + ':', int(parts[3]), int(parts[4])
        else:
            raise InputError('member shape')
        _need(prefix in self.by_prefix, 'member family')
        f = self.by_prefix[prefix]
        expected = prefix if a is None else prefix + str(a) + ('' if b is None else ':' + str(b))
        _need(cid == expected, 'canonical member')
        return f, a, b

    def marks(self, member):
        f, a, b = member
        prefix, kind, row, out, left, right = self.families[f]
        values = {row: out}
        if kind != 'zero':
            _need(type(a) is int and 0 <= a < row, 'strict earlier source')
            values[a] = left
        if kind == 'mp':
            _need(type(b) is int and 0 <= b < row, 'strict earlier implication')
            if b in values and values[b] != right:
                return None
            values[b] = right
        return values

    def raw_legal(self, member):
        f, a, b = member
        row = self.families[f][2]
        if self.occupied[row]:
            return False
        marks = self.marks(member)
        return marks is not None and all(self.compatible(p, v) for p, v in marks.items())

    def factor(self, f):
        self.m.tick()
        prefix, kind, row, out, left, right = self.families[f]
        if self.occupied[row] or not self.compatible(row, out):
            return (False, (), (), 0)
        if kind == 'zero':
            a, b, count = (), (), 1
        else:
            a = tuple(j for j in self.lex_refs[row] if self.compatible(j, left))
            self.m.tick(row + 1)
            if kind == 'gen':
                b, count = (), len(a)
            else:
                b = tuple(j for j in self.lex_refs[row] if self.compatible(j, right))
                self.m.tick(row + 1)
                count = len(a) * len(b)
                if left != right:
                    count -= len(set(a).intersection(b))
        for cid in self.excluded[f]:
            self.m.tick()
            if self.raw_legal(self.parse(cid)):
                count -= 1
        _need(count >= 0, 'nonnegative complete factor count')
        return (True, a, b, count)

    def refresh(self, families):
        for f in sorted(families):
            self.m.tick(); self.m.stats['family_refreshes'] += 1
            old = self.factors[f][3]
            new = self.factor(f)
            self.put(self.factors, f, new)
            row = self.families[f][2]
            self.put(self.degrees, row, self.degrees[row] + new[3] - old)

    def first(self, row):
        for f in self.row_families[row]:
            self.m.tick()
            enabled, aa, bb, count = self.factors[f]
            if count == 0:
                continue
            prefix, kind, own, out, left, right = self.families[f]
            if kind == 'zero':
                return prefix
            first_refs = aa if kind == 'gen' else sorted(aa, key=lambda a: str(a) + ':')
            for a in first_refs:
                candidates = (None,) if kind == 'gen' else bb
                for b in candidates:
                    self.m.tick()
                    if b is not None and a == b and left != right:
                        continue
                    cid = prefix + str(a) + ('' if b is None else ':' + str(b))
                    if cid not in self.excluded[f]:
                        return cid
        raise RuntimeError('complete nonempty domain has no first member')

    def place(self, cid):
        member = self.parse(cid); f, a, b = member
        _need(self.raw_legal(member) and cid not in self.excluded[f], 'legal selected member')
        row = self.families[f][2]
        self.put(self.occupied, row, True)
        self.put(self.selected, row, cid)
        dirty = set(self.row_families[row])
        for point, formula in self.marks(member).items():
            self.m.tick()
            if self.values[point] is None:
                self.put(self.values, point, formula)
                dirty.update(self.mark_deps[point])
            else:
                _need(self.values[point] == formula, 'literal marking agreement')
            self.put(self.refs, point, self.refs[point] + 1)
        self.refresh(dirty)
        self.m.stats['placements'] += 1

    def exclude(self, cid):
        f, a, b = self.parse(cid)
        _need(cid not in self.excluded[f], 'new contextual exclusion')
        self.m.tick()
        self.trail.append(('excluded', self.excluded[f], cid, False))
        self.excluded[f].add(cid)
        self.m.stats['trail_writes'] += 1
        self.m.stats['max_trail'] = max(self.m.stats['max_trail'], len(self.trail))
        self.refresh((f,))
        self.m.stats['scoped_exclusions'] += 1

    def core(self):
        return dict(occupied=list(self.occupied), selected=list(self.selected),
                    values=list(self.values), refs=list(self.refs),
                    excluded=sorted(cid for group in self.excluded for cid in group))

    def snapshot(self):
        answer = self.core()
        answer.update(schema='V-indexed-unit-point-state-v1',
            required=['slot:' + str(i) for i in range(self.n)],
            frontier=['slot:' + str(i) for i in range(self.n) if not self.occupied[i]],
            root_generations=[0] * self.n, degrees=list(self.degrees),
            factors=[[on, list(a), list(b), count] for on, a, b, count in self.factors],
            row_families=[list(x) for x in self.row_families],
            family_rows=[f[2] for f in self.families],
            marking_dependencies=[sorted(x) for x in self.mark_deps],
            reverse_marking_dependencies=[list(x) for x in self.family_deps])
        return answer

    def undo(self, target, cleanup=False):
        count = 0
        while len(self.trail) > target:
            kind, container, key, old = self.trail.pop()
            if kind == 'array':
                container[key] = old
            else:
                container.remove(key)
            self.m.stats['trail_undos'] += 1
            if cleanup:
                self.m.stats['cleanup_undos'] += 1
            count += 1
        return count


def solve(compiled, slots, limits, *, observe=None):
    """Exact virtual-member search. Caller must freeze the logical catalogue."""
    m = _Meter(limits)
    _need(observe is None or callable(observe), 'observer callable')
    state = model = entry = restored = None
    model_hash = entry_hash = restored_hash = None
    selected = certificate = None
    status, reason, fatal = 'UNKNOWN', 'PREPARATION_INCOMPLETE', None
    events, rollbacks, stack = [], [], []
    digest = hashlib.sha256(); event_bytes = 0

    def emit(kind, data):
        nonlocal event_bytes
        m.tick()
        event = dict(seq=m.stats['events'], kind=kind, data=data)
        raw = _wire(event); m.tick(len(raw)); digest.update(raw); event_bytes += len(raw)
        m.stats['events'] += 1
        if len(events) < m.limits['max_events']:
            events.append(event)
        if observe is not None:
            snapshot = state.snapshot()
            detached = json.loads(_wire(snapshot)); m.tick(len(_wire(snapshot)))
            m.stats['observations'] += 1
            observe(json.loads(raw), detached)
            m.tick()

    try:
        model = _point_model(compiled, slots, m)
        model_hash = _hash(model); m.tick(len(_wire(model)))
        state = _State(model, m)
        entry = state.snapshot(); entry_hash = _hash(entry); m.tick(len(_wire(entry)))
        emit('ENTRY', {})
        while True:
            m.node()
            frontier = [i for i in range(slots) if not state.occupied[i]]
            ordered = sorted(frontier, key=lambda i: 'slot:' + str(i))
            dead = next((i for i in ordered if state.degrees[i] == 0), None)
            if dead is not None:
                emit('DEAD', {'row': dead, 'generation': 0})
                if not stack:
                    status, reason = 'UNSAT', 'COMPLETE_VIRTUAL_UNIVERSE_EXHAUSTED'
                    break
                target, child, parent_hash = stack.pop()
                before = _hash(state.core()); writes = state.undo(target)
                after = _hash(state.core())
                _need(after == parent_hash, 'complete parent core restored')
                record = dict(reason='FAILED_CHILD', target=target, undone=writes,
                              before_core_sha256=before, after_core_sha256=after,
                              expected_parent_core_sha256=parent_hash)
                rollbacks.append(record); m.stats['backtracks'] += 1
                emit('ROLLBACK', record)
                state.exclude(child)
                emit('EXCLUDED', {'candidate': child, 'parent_core_sha256': parent_hash})
                continue
            if not frontier:
                chosen = sorted(x for x in state.selected if x is not None)
                totals, marks, refs = [0] * slots, {}, {}
                for cid in chosen:
                    m.tick(); member = state.parse(cid); totals[state.families[member[0]][2]] += 1
                    for p, v in state.marks(member).items():
                        _need(p not in marks or marks[p] == v, 'whole selected m')
                        marks[p] = v; refs[p] = refs.get(p, 0) + 1
                _need(totals == [1] * slots and all(marks[i] == state.values[i]
                      and refs[i] == state.refs[i] for i in range(slots)), 'whole selected t/m/refcounts')
                selected = chosen
                certificate = dict(selected=chosen, totals=totals,
                    markings=[[i, model['colors'][marks[i]], refs[i]] for i in range(slots)],
                    generations=[[cid, 1] for cid in chosen])
                emit('SOLUTION', {'selected': chosen})
                status, reason = 'SAT', 'EXACT_FINITE_POINT_AND_LITERAL_MARKINGS'
                break
            forced = next((i for i in ordered if state.degrees[i] == 1), None)
            if forced is not None:
                cid = state.first(forced); state.place(cid)
                m.stats['forced_placements'] += 1
                emit('PLACED', {'candidate': cid, 'row': forced, 'forced': True,
                                'root_generation': 0, 'tile_generation': 1})
                continue
            row = min(frontier, key=lambda i: (state.degrees[i], 'slot:' + str(i)))
            cid = state.first(row)
            parent_hash = _hash(state.core())
            emit('BRANCH', {'row': row, 'generation': 0, 'degree': state.degrees[row],
                            'first_candidate': cid, 'order': 'COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS'})
            stack.append((len(state.trail), cid, parent_hash))
            m.stats['branch_decisions'] += 1
            state.place(cid)
            emit('PLACED', {'candidate': cid, 'row': row, 'forced': False,
                            'root_generation': 0, 'tile_generation': 1})
    except BaseException as error:
        if type(error) is _Stop and error.owner is m:
            reason = error.reason
        else:
            fatal = error
        status, selected, certificate = 'UNKNOWN', None, None
    finally:
        cleanup_start = time.perf_counter()
        if state is not None:
            before = _hash(state.core()); undone = state.undo(0, cleanup=True)
            restored = state.snapshot(); restored_hash = _hash(restored)
            rollbacks.append(dict(reason='FINAL_MANDATORY_CLEANUP', target=0, undone=undone,
                before_core_sha256=before, after_core_sha256=_hash(state.core()),
                full_restored_sha256=restored_hash))
            if entry is not None and restored != entry:
                fatal = RuntimeError('full indexed state restoration failed')
        m.stats['cleanup_seconds'] = time.perf_counter() - cleanup_start
    if fatal is not None:
        raise fatal
    m.stats['elapsed_seconds'] = time.perf_counter() - m.start
    return dict(schema='V-indexed-unit-point-result-v1', version=VERSION,
        status=status, reason=reason, model=model,
        families=None if state is None else [list(x) for x in state.families],
        model_sha256=model_hash, selected=selected, certificate=certificate,
        stats=m.stats, events=events,
        event_extent=dict(count=m.stats['events'], retained=len(events), JSONL_bytes=event_bytes,
                          SHA256=digest.hexdigest(), evaluation_complete=status in ('SAT', 'UNSAT')),
        entry_state=entry, restored_state=restored,
        state_hashes=dict(entry=entry_hash, restored=restored_hash), rollback_records=rollbacks,
        scope='Exact finite anchored unit all-root0 indexed point adaptation. Complete virtual '
              'candidate identity counts, not sampled families. Native proof validity separate. '
              'No fractional/shared-support/growing geometry, unrestricted FOL, RL or Wang claim. '
              'Per-rollback hashes cover core values; full factors appear in entry/restored and '
              'tiny observer snapshots only. Cleanup/final observation/serialization can exceed '
              'cooperative search wall; outer owned-process quotas required separately.')
