"""Stdlib archive of retained files only. No scientific imports/calls."""
from pathlib import Path
import hashlib,json,zipfile
V=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1');R=V/'root'
OUT=R/'report-draft/indexed-first-order-proof-search-evidence-v1.zip'
plan=json.loads((R/'study-once-plan-001.json').read_bytes())
selected=set(p for p in V.rglob('*') if p.is_file() and not p.is_symlink() and p!=OUT)
peer_dirs=['/private/tmp/gcts-C-V-two-components-Source-peer-v1','/private/tmp/gcts-B-V-independent-core-peer-v1','/private/tmp/gcts-B-V-independent-graph-peer-v1','/private/tmp/gcts-C-V-worker-Source-peer-v1','/private/tmp/gcts-B-V-study001-saved-review-v1','/private/tmp/gcts-L-V-complete-saved-cohort-review-v1','/private/tmp/gcts-C-V-saved-native-peer-v1','/private/tmp/gcts-C-V-publication-Source-peer-v1']
for d in peer_dirs:selected.update(p for p in Path(d).rglob('*') if p.is_file() and not p.is_symlink())
for x in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['bootstrap']]:
 p=Path(x['path']);b=p.read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'];selected.add(p)
for p in Path('/private/tmp/gcts-first-order-proof-search-20261028-v1/actual/bridge-001').iterdir():
 if p.is_file() and not p.is_symlink():selected.add(p)
for suffix in ['root/first_order_study_once_v1.py','root/publish_first_order_proof_search_api_v1.py','root/verify_first_order_proof_search_live_v1.py','actual/study-001/incidence-typing-specialized-line-full-build.json.gz','actual/study-001/incidence-typing-specialized-line-point-full-result.json.gz']:
 selected.add(Path('/private/tmp/gcts-first-order-proof-search-20261028-v1')/suffix)
assert not OUT.exists() and len(selected)<512
rows=[];bodies=[];names=set();rawtotal=0
for p in sorted(selected):
 assert p.is_file() and not p.is_symlink()
 b=p.read_bytes();rawtotal+=len(b);assert len(b)<=33554432 and rawtotal<=134217728
 digest=hashlib.sha256(b).hexdigest()
 if p.is_relative_to(V):name='files/V/'+p.relative_to(V).as_posix()
 elif any(p.is_relative_to(Path(d)) for d in peer_dirs):name='peers/'+p.parent.name+'/'+p.name
 else:name='reused/'+hashlib.sha256(str(p).encode()).hexdigest()[:12]+'-'+p.name
 assert name not in names;names.add(name)
 rows.append(dict(member=name,origin=str(p),bytes=len(b),sha256=digest));bodies.append((name,b))
actual={str(p) for p in (V/'actual/study-001').iterdir() if p.is_file()}
assert len(actual)==95 and actual.issubset({x['origin'] for x in rows})
manifest=dict(schema='V-complete-recorded-evidence-archive-v1',scope='Prepublication scientific evidence cut. All95 V originals, current and superseded unrun Sources, authoring/audit metadata, complete scientific and Source peers, current reader/results/UI checks; closed operative reused Sources/input metadata, six original U bridge files and two exact common-case comparison originals. Indirect older-history references are provenance, not a claim that all earlier research histories are duplicated. Runtime interpreter binary is identified by hash but not bundled. Future publication/TLS/live receipts necessarily follow this cut and remain durably separate. No omitted main event bodies or postthrow images are invented.',V_scientific_originals=95,original_once='PERMANENTLY_SPENT_NO_AUTOMATIC_RERUN',records=rows,record_count=len(rows),record_bytes=rawtotal,human_authorization=dict(quote='Approve publishing the full archive',destination='Existing public liuyao12/geometric-tree-search GitHub Pages',data='Source snapshots, raw proof certificates, execution logs and local file paths'),reproduction='Source/plan/runtime pins identify the original once. For a reproduction use a new owned output/authority and review scope; no spent authority is reusable. The two successful research statements are elementary calibrations; main targets remain unresolved. No RL or universal literal Wang completeness or GCTS advantage claimed.')
mb=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in bodies+[('archive-manifest.json',mb)]:
  zi=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16;z.writestr(zi,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(OUT) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(rows)+1
 for row in rows:
  b=z.read(row['member']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 assert z.read('archive-manifest.json')==mb
b=OUT.read_bytes();assert len(b)<=33554432
receipt=dict(schema='V-full-recorded-evidence-package-receipt-v1',archive=dict(path=str(OUT),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()),manifest=dict(bytes=len(mb),sha256=hashlib.sha256(mb).hexdigest()),members=len(rows)+1,original_records=len(rows),record_bytes=rawtotal,V_scientific_originals=95,all_members_whole_readback=True,cut='PREPUBLICATION_SCIENCE_AND_CONTENT')
p=R/'complete-evidence-package-receipt-v1.json'
with p.open('x')as f:json.dump(receipt,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(receipt,sort_keys=True))
