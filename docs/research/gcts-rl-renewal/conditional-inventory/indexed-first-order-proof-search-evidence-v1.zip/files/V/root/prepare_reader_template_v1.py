"""Saved HTML-only template successor. No scientific calls."""
from pathlib import Path
import hashlib,json
p=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1/root')
s=Path('/private/tmp/gcts-first-order-proof-search-20261028-v1/root/first-order-reader-template.html').read_text()
s=s.replace('First-order point-tile proof search — GCTS research','Compact proof tiles and a goal-directed control — GCTS research')
s=s.replace('milestone U','milestone V').replace('Quantifiers, equality and unknown proof structure','Compact proof tiles and a goal-directed control')
s=s.replace('first-order-proof-search-results-v1.json','indexed-first-order-proof-search-results-v1.json').replace('first-order-proof-search-evidence-v1.zip','indexed-first-order-proof-search-evidence-v1.zip')
s=s.replace('<a href="normalization-proof-search-v1.html#reader">Previous normalization and RL study</a>','<a href="first-order-proof-search-v1.html#reader">Previous eager representation study</a>')
s=s.replace('A finite, mechanically generated formula basis supplies admissible inference tiles.','The unchanged finite logical catalogue is compiled with shared formula structure. An exact indexed graph represents every admissible inference tile without expanding every row-reference combination.')
s=s.replace('GCTS chooses the row tiles and their earlier-line references.','GCTS chooses row tiles and earlier-line references; a conventional backward search uses the same catalogue and shares common premises.')
s=s.replace('white-space:nowrap}.pass','white-space:normal;max-width:100%;overflow-wrap:anywhere}.pass').replace('font-size:12px}.formula','font-size:12px;max-width:100%;overflow-x:auto}.formula')
s=s.replace('Each square represents an actual selected symbolic tile.','In the GCTS lane, each square represents an actual selected symbolic tile. The control lane displays its native certificate rows; these were selected by backward search rather than by the point engine.')
s=s.replace('Same-basis symbolic control</option>','Same-basis backward DAG control</option>')
begin=s.index('<section class="panel"><h2>The remaining route to a fixed Wang palette</h2>')
end=s.index('<section class="panel"><h2>What this says about GCTS and learning</h2>',begin)
s=s[:begin]+'''<section class="panel"><h2>Representation and independent checks</h2>
<div class="bridge"><div><strong>Interned formulas</strong><small>Shared subexpressions and cached operations; the logical catalogue is unchanged.</small></div><div><strong>Indexed tile families</strong><small>Every row-reference candidate retains its identity. Exact family counts replace explicit expansion.</small></div><div><strong>Backward control</strong><small>Demand the conclusion, choose inference producers and share premise facts, within the same line bound.</small></div><div><strong>Two proof checkers</strong><small>Every reported successful certificate must pass actual native C1 and the independent first-order checker.</small></div></div>
<div id="bridge-results"></div>
<p>These are symbolic point tiles with remote markings. They do not yet constitute a fixed literal Wang palette. The whole-checker machine construction and accepting-boundary equivalence remain open, as does an unrestricted mathematical formalization.</p>
</section>
'''+s[end:]
s=s.replace('<th>Transitions</th>','<th>Complete assignments</th>')
s=s.replace("const tile=lane.tiles?.find(t=>t.slot===i);","const tile=lane.tiles?.find(t=>t.slot===i);")
s=s.replace("(r.candidate_count===null?'':'<br>'+r.candidate_count+' candidates')","(r.graph_counts?'<br>'+r.graph_counts.members+' virtual members / '+r.graph_counts.families+' families':'')")
s=s.replace("esc(tile?.id||'symbolic control certificate')","esc(tile?.id||'backward-search certificate')")
s=s.replace('<th>Complete model</th>','<th>Catalogue / virtual graph</th>')
assert s.count('__RESEARCH_DATA__')==1
assert "function operand(f)" in s and "operand(f[1])" in s
q=p/'indexed-first-order-reader-template-v1.html'
with q.open('x') as f:f.write(s)
print(json.dumps({'path':str(q),'bytes':len(s.encode()),'sha256':hashlib.sha256(s.encode()).hexdigest()},sort_keys=True))
