from pathlib import Path
import ast, hashlib, json
u=Path('/private/tmp/gcts-first-order-proof-search-20261028-v1/root')
v=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1/root')
a=(u/'first_order_study_once_v1.py').read_text()
assert hashlib.sha256(a.encode()).hexdigest()=='14d4230e09dd580ca3b029d49b1e1993da8a7a0ef015fea54257b1bf7e85b351'
s=a.replace('Closed U worker','Closed V worker').replace("ROOT = Path('/private/tmp/gcts-first-order-proof-search-20261028-v1')","ROOT = Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1')")
s=s.replace("'runner', 'compiler', 'engine', 'independent', 'state_audit',","'runner', 'compiler', 'engine', 'independent', 'graph_audit', 'reference', 'explicit',")
s=s.replace('U-first-order-proof-once','V-indexed-first-order-proof-once').replace("types.ModuleType('U_'","types.ModuleType('V_'")
begin=s.index('    qualification_checks = []\n')
end=s.index('    result_ref = emit(\'worker-result\', result)\n',begin)
replacement='''    qualification_checks = []
    def qualification_emit(name, data):
        identity = 'qualification-' + name.replace('_', '-')
        emit(identity, data)
        proofs = []
        if 'core_selection' in data and data['core_selection'] is not None:
            proofs.append(('point', data['core_selection']['proof']))
        if 'backward' in data and data['backward']['status'] == 'DERIVABLE':
            proofs.append(('control', data['backward']['proof']))
        if name == 'SHARED-DAG':
            for control in data['controls']:
                if control['result']['status'] == 'DERIVABLE':
                    proofs.append(('control-' + str(control['slots']), control['result']['proof']))
        for lane, proof in proofs:
            require(type(proof) is list and proof, 'complete qualification proof')
            qualification_checks.append({'id': identity, 'lane': lane,
                'check': checked_proof(identity, lane, data['problem'], proof)})
    qualification = call('graph_audit', 'qualify', modules['compiler'], modules['reference'],
                         modules['engine'], modules['explicit'], modules['independent'],
                         qualification_emit)
    emit('whole-indexed-point-qualification', qualification)
    require(qualification['status'] == 'PASS' and len(qualification_checks) == 17,
            'whole prospective qualification and native-check census')
    rows = []
    for name in design['order']:
        given = (calibrations if name in calibrations else cases)[name]
        problem = dict(given, profile=profile)
        slots = design['slots'][name]
        input_image = raw_json(problem)
        emit(name + '-input', dict(problem, slots=slots))
        before = time.perf_counter()
        built = call('compiler', 'build_basis', problem['theory'], problem['goal'],
                     profile, limits['basis'])
        build_seconds = time.perf_counter() - before
        require(raw_json(problem) == input_image, 'compiler preserves frozen input')
        emit(name + '-full-build', built)
        row = {'id': name, 'problem': problem, 'slots': slots,
               'build_status': built['status'], 'build_seconds': build_seconds,
               'build_costs': built['costs'],
               'point': {'status': 'NOT_RUN_INCOMPLETE_BUILD'},
               'control': {'status': 'NOT_RUN_INCOMPLETE_BUILD'}}
        if built['status'] != 'COMPLETE':
            require(built['status'] == 'UNKNOWN' and built['compiled'] is None,
                    'no partial compiled universe on refusal')
            row['build_reason'] = built['reason']
            rows.append(row)
            continue
        compiled = built['compiled']
        before = time.perf_counter()
        verified = call('independent', 'verify_compiled', problem, compiled,
                        limits=limits['independent'])
        audit_seconds = time.perf_counter() - before
        emit(name + '-independent-compiled', verified)
        row['compiled_audit'] = verified
        row['compiled_audit_seconds'] = audit_seconds
        require(verified['status'] == 'VERIFIED', 'whole independent compiled binding')
        before = time.perf_counter()
        answer = call('engine', 'solve', compiled, slots, limits['point'])
        point_seconds = time.perf_counter() - before
        emit(name + '-point-full-result', answer)
        if answer['entry_state'] is not None:
            require(answer['entry_state'] == answer['restored_state'], 'full indexed final restoration')
            require(hashlib.sha256(raw_json(answer['entry_state'])).hexdigest()
                    == answer['state_hashes']['entry'] == answer['state_hashes']['restored'],
                    'full indexed entry/restored hashes')
        require(answer['stats']['trail_writes'] == answer['stats']['trail_undos'],
                'complete actual mandatory trail cleanup')
        point = {'status': answer['status'], 'reason': answer['reason'],
                 'seconds': point_seconds, 'pipeline_seconds': build_seconds + point_seconds,
                 'statistics': answer['stats'], 'event_extent': answer['event_extent'],
                 'proof': None, 'check': None, 'tiles': [], 'selection_audit_seconds': 0}
        if answer['status'] == 'SAT':
            before = time.perf_counter()
            selected = call('independent', 'verify_selection', problem, compiled, slots,
                            answer['selected'], limits=limits['independent'])
            point['selection_audit_seconds'] = time.perf_counter() - before
            emit(name + '-point-selection-audit', selected)
            require(selected['status'] == 'VERIFIED', 'independent selected derivation')
            decoded = call('compiler', 'decode', compiled, slots, answer['selected'])
            emit(name + '-point-decoded-certificate', decoded)
            require(decoded['status'] == 'UNVERIFIED_CERTIFICATE'
                    and decoded['proof'] == selected['proof'], 'exact independent proof agreement')
            point['proof'] = decoded['proof']
            point['check'] = checked_proof(name, 'point', problem, decoded['proof'])
            point['tiles'] = selected['details']['candidate_bindings']
        before = time.perf_counter()
        control = call('independent', 'backward_dag', problem, compiled, slots, limits['control'])
        control_seconds = time.perf_counter() - before
        emit(name + '-control-full-result', control)
        control_summary = {'status': control['status'], 'reason': control['reason'],
                           'seconds': control_seconds,
                           'pipeline_seconds': build_seconds + control_seconds,
                           'proof': control['proof'], 'details': control['details'],
                           'costs': control['costs'], 'check': None}
        if control['status'] == 'DERIVABLE':
            require(type(control['proof']) is list and control['proof'], 'control proof explicit')
            control_summary['check'] = checked_proof(name, 'control', problem, control['proof'])
        for lane in (point, control_summary):
            lane['checked_total_seconds'] = (lane['pipeline_seconds'] + audit_seconds
                + lane.get('selection_audit_seconds', 0)
                + (0 if lane['check'] is None else lane['check']['seconds']))
        row.update(basis_counts={k: len(compiled['logical_basis'][k]) for k in
                                 ('instantiation_terms', 'terms', 'variables', 'formulas', 'templates')},
                   instance_count=len(compiled['zero_instances']), point=point, control=control_summary)
        require(raw_json(problem) == input_image, 'all lanes preserve frozen input')
        rows.append(row)
        emit(name + '-whole-case-result', row)
    require(len(rows) == 8, 'all prospective cases observed once')
    result = {'schema': 'V-indexed-first-order-proof-search-study-v1', 'status': 'COMPLETE',
              'results': rows, 'profile': profile, 'limits': limits,
              'qualification': qualification, 'qualification_checks': qualification_checks,
              'bridge_records': bridge_records,
              'native_preparation_seconds': native_preparation_seconds,
              'outer_public_calls': dict(calls), 'artifacts': list(artifacts),
              'scope': 'Eight unchanged U assertion-only cases and line bounds. Complete interned '
                       'logical catalogue, compressed exact indexed point graph and shared-fact '
                       'backward DAG control. Main preparation failures are UNKNOWN. All chosen '
                       'whole proofs checked by actual unchanged native C1 and independent B. '
                       'No RL, unrestricted PA/Hilbert/FOL completeness, fixed universal literal '
                       'Wang palette or superiority claim. Tiny qualification compares full '
                       'U projection and explicit domains/every observed transition. Main graph '
                       'integrity relies on Source review, tiny qualification, full entry/restored '
                       'images and independently checked final proofs, not exhaustive main histories. '
                       'Pipeline excludes separately retained common native initialization, '
                       'qualification, output serialization; checked_total adds compiled audit, '
                       'selection audit where applicable, and certificate verification. Work '
                       'counters differ by implementation and cannot establish speed ratios.'}
'''
s=s[:begin]+replacement+s[end:]
s=s.replace("'schema': 'U-owned-observer-result-v1'","'schema': 'V-owned-indexed-observer-result-v1'")
# All U ownership, limits, cleanup, retained-byte compilation and native bridge preserved.
out=v/'indexed_first_order_study_once_v1.py'
with out.open('x') as f:f.write(s)
ast.parse(s);compile(s,str(out),'exec')
print(json.dumps({'Source':{'path':str(out),'bytes':len(s.encode()),'sha256':hashlib.sha256(s.encode()).hexdigest()},'status':'INERT_DRAFT_AWAIT_FINAL_QUALIFIER_ABI_AND_PEER','subject_calls':0},sort_keys=True))
