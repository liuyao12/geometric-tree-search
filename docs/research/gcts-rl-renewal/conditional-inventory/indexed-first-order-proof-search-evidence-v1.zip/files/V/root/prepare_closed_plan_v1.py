"""Stdlib-only Source/data pin assembly. No subject imports or calls or grant."""
from pathlib import Path
import hashlib,json
V=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1')
U=Path('/private/tmp/gcts-first-order-proof-search-20261028-v1')
def ref(path):
 p=Path(path);a=p.read_bytes();return dict(path=str(p),bytes=len(a),sha256=hashlib.sha256(a).hexdigest())
def put(path,obj):
 a=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()
 with Path(path).open('xb') as f:f.write(a)
 return ref(path)
old=json.loads((U/'root/study-once-plan-001.json').read_bytes())
sources={k:v for k,v in old['sources'].items() if k not in ('state_audit','compiler','engine','independent','runner')}
sources.update(runner=ref(V/'root/indexed_first_order_study_once_v2.py'),
 compiler=ref(V/'implementation-B/interned_fol_basis_v2.py'),
 engine=ref(V/'root/indexed_proof_point_search_v2.py'),
 independent=ref(V/'implementation-L/indexed_basis_verifier_v1.py'),
 graph_audit=ref(V/'implementation-L/indexed_graph_qualification_v1.py'),
 reference=old['sources']['compiler'],explicit=old['sources']['engine'])
metadata={k:v for k,v in old['metadata'].items() if k not in ('caller_ABI','compiler_ABI','design','experiment_limits','independent_ABI','independent_source_peer')}
paths={
 'caller_ABI':V/'root/indexed-first-order-owned-caller-ABI-v1.json',
 'compiler_ABI':V/'implementation-B/V-interned-Hilbert8-complete-public-ABI-v2.json',
 'engine_ABI':V/'root/indexed-point-engine-complete-public-ABI-v2.json',
 'independent_ABI':V/'implementation-L/V-independent-indexed-basis-audit-complete-public-ABI-v1.json',
 'qualifier_ABI':V/'implementation-L/V-independent-indexed-graph-qualification-complete-public-ABI-v1.json',
 'design':V/'root/prospective-design-v1.json',
 'experiment_limits':V/'root/prospective-study-limits-v1.json',
 'compiler_source_peer':Path('/private/tmp/gcts-C-V-two-components-Source-peer-v1/V-interned-basis-Source2-focused-complete-independent-peer-v1.json'),
 'engine_source_peer':Path('/private/tmp/gcts-C-V-two-components-Source-peer-v1/V-indexed-engine-Source2-focused-complete-independent-peer-v1.json'),
 'independent_source_peer':Path('/private/tmp/gcts-B-V-independent-core-peer-v1/V-independent-core-complete-Source-peer-review-v1.json'),
 'qualifier_source_peer':Path('/private/tmp/gcts-B-V-independent-graph-peer-v1/V-independent-graph-qualification-complete-Source-peer-review-v1.json'),
 'caller_source_peer':Path('/private/tmp/gcts-C-V-worker-Source-peer-v1/V-indexed-worker-complete-independent-Source-peer-review-v1.json'),
 'Root_adoption':V/'root/Root-complete-Source-adoption-v1.json'}
metadata.update({k:ref(v) for k,v in paths.items()})
plan=dict(schema='V-indexed-first-order-proof-once-plan-v1',sources=sources,metadata=metadata,
 python=old['python'],bootstrap=old['bootstrap'],actual_dir=str(V/'actual/study-001'),limits=old['limits'])
print(json.dumps(put(V/'root/study-once-plan-001.json',plan),sort_keys=True))
