"""Inert closed-plan P2 Git Data API publisher for three NEW indexed-first-order-proof-search files.

No scientific imports or local Git mutation. Root must authenticate retained
Source bytes, adopt the exact plan/payloads, and issue one fresh authority.
A nonzero/uncertain attempt remains spent: never repeat a network mutation.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import signal
import stat
import subprocess
import sys
import time
import traceback

VERSION = 'INDEXED-FIRST-ORDER-PROOF-SEARCH-P2-PUBLISHER-v1'
STUDY = Path('/private/tmp/gcts-indexed-first-order-proof-search-20261028-v1')
ROOT = STUDY / 'root'
SELF_PATH = STUDY / 'root/publish_indexed_first_order_proof_search_api_v1.py'
P2 = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-batch-20261020/publisher-recovery-6338a77')
ROOT_STAGE = ROOT / 'publication-indexed-first-order-proof-search-v1'
PUBLISHER_STAGE = STUDY / 'publisher-indexed-first-order-proof-search-payload'
OUT = ROOT / 'publication-indexed-first-order-proof-search-api-v1'
REPOSITORY = 'liuyao12/geometric-tree-search'
API_PREFIX = 'repos/' + REPOSITORY + '/'
GIT_PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('indexed-first-order-proof-search-v1.html',
         'indexed-first-order-proof-search-results-v1.json',
         'indexed-first-order-proof-search-evidence-v1.zip')
PAYLOAD_CAPS = (1048576, 8388608, 33554432)
EXPECTED_PARENT = '46da9608bf1a9c3d24976d3d4890cbc20f459916'
EXPECTED_TREE = '646f0193ab23f625220733744d1d8ce1a16a9f05'
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
          'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
GH = '/Users/liuyao/bin/gh'
ADMIN_CAP = 1048576
REQUEST_CAP = 50331648
RESPONSE_CAP = 16777216
STDERR_CAP = 1048576
OUTPUT_CAP = 268435456
OUTPUT_COUNT = 64
API_SECONDS = 60
PUBLISHER_SECONDS = 900
CLEANUP_SECONDS = 5
EXPECTED_API_CALLS = 12
AUTHORIZATION_SCOPE = 'PUBLIC_FULL_TASK_EVIDENCE_AT_EXISTING_GITHUB_PAGES_DESTINATION'


class PublicationFailure(Exception):
    pass


def need(condition, message):
    if not condition:
        raise PublicationFailure(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def nonfinite(value):
        raise PublicationFailure('nonfinite JSON constant')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def fields(value, names, label):
    need(type(value) is dict and all(type(k) is str for k in value)
         and set(value) == set(names), label)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def git_sha(value):
    need(type(value) is str and re.fullmatch('[0-9a-f]{40}', value) is not None,
         'exact Git SHA1')
    return value


def blob_sha(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()


def canonical(value):
    need(type(value) is str, 'path string')
    p = Path(value)
    need(p.is_absolute() and str(p) == value and os.path.normpath(value) == value
         and all(not q.is_symlink() for q in (p, *p.parents)) and p.resolve() == p,
         'absolute canonical nonsymlink path')
    return p


def pin(path, raw):
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha256(raw)}


def read(path, cap):
    path = canonical(str(path))
    before = path.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and 0 <= before.st_size <= cap, 'bounded single-link regular file')
    with path.open('rb') as handle:
        raw = handle.read(cap + 1)
    after = path.stat(follow_symlinks=False)
    need(len(raw) <= cap and len(raw) == before.st_size == after.st_size
         and (before.st_dev, before.st_ino, before.st_mtime_ns)
         == (after.st_dev, after.st_ino, after.st_mtime_ns), 'changed or incomplete file')
    return raw


def rawref(value, cap):
    fields(value, ('path', 'bytes', 'sha256'), 'rawref exact3')
    need(type(value['bytes']) is int and 0 <= value['bytes'] <= cap
         and type(value['sha256']) is str
         and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None, 'rawref types/cap')
    raw = read(canonical(value['path']), cap)
    need(encode(pin(value['path'], raw)) == encode(value), 'complete rawref identity')
    return raw


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def fresh(path):
    canonical(str(path))
    need(not path.exists() and not path.is_symlink(), 'fresh path required')


def create(path, raw, cap):
    need(type(raw) is bytes and len(raw) <= cap, 'bounded output body')
    canonical(str(path))
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    need(read(path, cap) == raw, 'exclusive full output readback')
    return pin(path, raw)


def admin(path):
    path = canonical(path)
    need(path.parent == ROOT and path.suffix == '.json' and not path.name.startswith('.'),
         'Root administrative JSON path')
    raw = read(path, ADMIN_CAP)
    return parse(raw), pin(path, raw)


def plan_read(path):
    plan, ref = admin(path)
    fields(plan, ('schema', 'repository', 'branch', 'expected_parent', 'expected_tree',
                  'root_stage', 'publisher_stage', 'files', 'human_authorization'), 'plan exact9')
    need(plan['schema'] == 'Root-indexed-first-order-proof-search-P2-plan-v1'
         and plan['repository'] == REPOSITORY and plan['branch'] == 'main'
         and plan['expected_parent'] == EXPECTED_PARENT
         and plan['expected_tree'] == EXPECTED_TREE, 'fixed repository/main/parent/tree')
    need(plan['root_stage'] == str(ROOT_STAGE)
         and plan['publisher_stage'] == str(PUBLISHER_STAGE), 'fixed twin staging directories')
    rows = plan['files']
    need(type(rows) is list and len(rows) == 3, 'three ordered payloads')
    for row, name, cap in zip(rows, NAMES, PAYLOAD_CAPS, strict=True):
        fields(row, ('path', 'root_source', 'publisher_source', 'git_blob_sha1'), 'payload row exact4')
        need(row['path'] == GIT_PREFIX + name, 'exact approved target order')
        for key, directory in (('root_source', ROOT_STAGE), ('publisher_source', PUBLISHER_STAGE)):
            r = row[key]
            fields(r, ('path', 'bytes', 'sha256'), 'payload rawref exact3')
            need(r['path'] == str(directory / name) and type(r['bytes']) is int
                 and 0 < r['bytes'] <= cap and type(r['sha256']) is str
                 and re.fullmatch('[0-9a-f]{64}', r['sha256']) is not None, 'fixed payload path/type/cap')
        need(row['root_source']['bytes'] == row['publisher_source']['bytes']
             and row['root_source']['sha256'] == row['publisher_source']['sha256'], 'declared twin identities')
        git_sha(row['git_blob_sha1'])
    human = plan['human_authorization']
    fields(human, ('quote', 'date', 'scope'), 'human authorization exact3')
    need(type(human['quote']) is str and 1 <= len(human['quote']) <= 16384
         and type(human['date']) is str and re.fullmatch('[0-9]{4}-[0-9]{2}-[0-9]{2}', human['date']) is not None
         and human['scope'] == AUTHORIZATION_SCOPE, 'literal existing full-archive authorization')
    return plan, ref


def local_guards(plan, plan_ref, authority_ref, publisher_ref):
    rawref(plan_ref, ADMIN_CAP)
    rawref(authority_ref, ADMIN_CAP)
    rawref(publisher_ref, ADMIN_CAP)
    rawref(PYTHON, PYTHON['bytes'])
    bodies = []
    for directory in (ROOT_STAGE, PUBLISHER_STAGE):
        canonical(str(directory))
        need(directory.is_dir(), 'staging directory')
        need({p.name for p in directory.iterdir()} == set(NAMES), 'exact three-body staging census')
    for row, cap in zip(plan['files'], PAYLOAD_CAPS, strict=True):
        root_raw = rawref(row['root_source'], cap)
        p2_raw = rawref(row['publisher_source'], cap)
        need(root_raw == p2_raw and blob_sha(root_raw) == row['git_blob_sha1'],
             'full twin and Git blob identities')
        bodies.append(root_raw)
    return bodies


def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


class Session:
    def __init__(self, started):
        self.started = started
        self.calls = 0
        self.mutation_dispatched = False
        self.files = []

    def wall(self):
        need(time.monotonic() - self.started <= PUBLISHER_SECONDS,
             'publisher main-entry cooperative wall ceiling')

    def save(self, name, raw, cap):
        need(re.fullmatch('[a-z0-9][a-z0-9_.-]*', name) is not None, 'receipt basename')
        paths = list(OUT.iterdir())
        need(len(paths) + 1 <= OUTPUT_COUNT, 'receipt count cap')
        need(sum(p.stat().st_size for p in paths) + len(raw) <= OUTPUT_CAP, 'receipt aggregate cap')
        result = create(OUT / name, raw, cap)
        self.files.append(result)
        return result

    def census(self):
        need({p.name for p in OUT.iterdir()} == {Path(r['path']).name for r in self.files}, 'exact named receipt census')
        need(len(self.files) <= OUTPUT_COUNT and sum(r['bytes'] for r in self.files) <= OUTPUT_CAP, 'whole receipt caps')
        for r in self.files:
            rawref(r, REQUEST_CAP)
        return list(self.files)

    def api(self, label, method, suffix, body=None):
        self.wall()
        need(re.fullmatch('[a-z0-9][a-z0-9_-]*', label) is not None, 'API label')
        need(method in ('GET', 'POST', 'PATCH') and self.calls < EXPECTED_API_CALLS, 'closed API methods/count')
        request = b'' if body is None else encode(body)
        need(len(request) <= REQUEST_CAP, 'API request cap')
        request_ref = self.save(label + '-request.bin', request, REQUEST_CAP)
        argv = [GH, 'api', '--hostname', 'github.com', '--method', method,
                '-H', 'Accept: application/vnd.github+json', API_PREFIX + suffix]
        if body is not None:
            argv += ['--input', '-']
        totals = {'stdout': 0, 'stderr': 0}
        buffers = {'stdout': bytearray(), 'stderr': bytearray()}
        eof = {'stdout': False, 'stderr': False}
        caps = {'stdout': RESPONSE_CAP, 'stderr': STDERR_CAP}
        sent, events, fault = 0, [], None
        cleanup_errors = []
        process, selector = None, None
        api_started = time.monotonic()
        self.calls += 1
        # Conservatively record dispatch even if Popen itself reports failure.
        if method != 'GET':
            self.mutation_dispatched = True
        try:
            selector = selectors.DefaultSelector()
            process = subprocess.Popen(argv, cwd=P2, stdin=subprocess.PIPE if body is not None else subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            for kind, stream in (('stdout', process.stdout), ('stderr', process.stderr)):
                os.set_blocking(stream.fileno(), False)
                selector.register(stream, selectors.EVENT_READ, kind)
            if body is not None:
                os.set_blocking(process.stdin.fileno(), False)
                selector.register(process.stdin, selectors.EVENT_WRITE, 'stdin')
            while True:
                need(time.monotonic() - api_started <= API_SECONDS, 'API subprocess wall ceiling')
                self.wall()
                for key, _ in selector.select(timeout=0.05):
                    kind = key.data
                    if kind == 'stdin':
                        try:
                            count = os.write(key.fileobj.fileno(), request[sent:sent + 65536])
                        except BlockingIOError:
                            continue
                        sent += count
                        if sent == len(request):
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                    else:
                        try:
                            chunk = os.read(key.fileobj.fileno(), 65536)
                        except BlockingIOError:
                            continue
                        if not chunk:
                            eof[kind] = True
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                        else:
                            totals[kind] += len(chunk)
                            room = max(0, caps[kind] - len(buffers[kind]))
                            buffers[kind].extend(chunk[:room])
                            need(totals[kind] <= caps[kind], 'API response/stderr byte cap')
                code = process.poll()
                if code is not None and not selector.get_map():
                    need(not group_exists(process.pid), 'API descendant process group remains')
                    break
        except Exception as error:
            fault = {'exception_type': type(error).__name__, 'message': str(error)}
        finally:
            try:
                if process is not None:
                    try:
                        if process.poll() is None or group_exists(process.pid):
                            for sig in (signal.SIGTERM, signal.SIGKILL):
                                try:
                                    os.killpg(process.pid, sig)
                                    events.append({'signal': int(sig), 'delivered': True})
                                except ProcessLookupError:
                                    events.append({'signal': int(sig), 'delivered': False})
                                except Exception as error:
                                    cleanup_errors.append({'site': 'group signal', 'type': type(error).__name__, 'message': str(error)})
                            try:
                                process.kill()
                            except ProcessLookupError:
                                pass
                            except Exception as error:
                                cleanup_errors.append({'site': 'owned child kill', 'type': type(error).__name__, 'message': str(error)})
                    except Exception as error:
                        cleanup_errors.append({'site': 'cleanup observation', 'type': type(error).__name__, 'message': str(error)})
                    finally:
                        try:
                            process.wait(timeout=CLEANUP_SECONDS)
                        except Exception as error:
                            cleanup_errors.append({'site': 'owned wait', 'type': type(error).__name__, 'message': str(error)})
            finally:
                if process is not None:
                    for stream in (process.stdin, process.stdout, process.stderr):
                        if stream is not None and not stream.closed:
                            try:
                                stream.close()
                            except Exception as error:
                                cleanup_errors.append({'site': 'pipe close', 'type': type(error).__name__, 'message': str(error)})
                if selector is not None:
                    try:
                        selector.close()
                    except Exception as error:
                        cleanup_errors.append({'site': 'selector close', 'type': type(error).__name__, 'message': str(error)})
        if cleanup_errors and fault is None:
            fault = {'exception_type': 'CleanupFailure', 'message': 'owned API cleanup failed; no retry'}
        stdout, stderr = bytes(buffers['stdout']), bytes(buffers['stderr'])
        stdout_ref = self.save(label + '-stdout.json', stdout, RESPONSE_CAP)
        stderr_ref = self.save(label + '-stderr.bin', stderr, STDERR_CAP)
        rc = None if process is None else process.returncode
        transport = {'schema': 'C-indexed-first-order-proof-search-API-transport-v1', 'method': method,
                     'route': API_PREFIX + suffix, 'request': request_ref,
                     'request_bytes_sent': sent if body is not None else 0,
                     'stdout': stdout_ref, 'stderr': stderr_ref, 'observed_stream_totals': totals,
                     'EOF': eof, 'returncode': rc, 'fault': fault, 'cleanup_signals': events, 'cleanup_errors': cleanup_errors,
                     'elapsed_api_entry_seconds': time.monotonic() - api_started,
                     'process_group_gone': process is None or not group_exists(process.pid),
                     'scope': 'Full bodies only if normal cap/EOF/return gates pass; failure prefixes are unadmitted. No automatic retry.'}
        self.save(label + '-transport.json', encode(transport), ADMIN_CAP)
        need(fault is None and rc == 0 and all(eof.values())
             and (body is None or sent == len(request)) and transport['process_group_gone'],
             'API failed or uncertain; stop spent attempt without retry')
        return parse(stdout)


def head(session, label):
    value = session.api(label, 'GET', 'git/ref/heads/main')
    need(value['ref'] == 'refs/heads/main' and value['object']['type'] == 'commit', 'main commit reference')
    return git_sha(value['object']['sha'])


def leaves(session, label, tree):
    value = session.api(label, 'GET', 'git/trees/' + git_sha(tree) + '?recursive=1')
    need(value['sha'] == tree and value['truncated'] is False and type(value['tree']) is list,
         'complete untruncated recursive Git tree')
    result, seen = {}, set()
    for item in value['tree']:
        path = item['path']
        need(type(path) is str and path and not path.startswith('/')
             and all(p not in ('', '.', '..') for p in path.split('/')) and path not in seen,
             'safe unique Git tree path')
        seen.add(path)
        git_sha(item['sha'])
        need(item['type'] in ('tree', 'blob', 'commit') and type(item['mode']) is str, 'Git entry type/mode')
        if item['type'] != 'tree':
            row = {k: item[k] for k in ('mode', 'type', 'sha')}
            if item['type'] == 'blob':
                need(type(item.get('size')) is int and item['size'] >= 0, 'blob size')
                row['size'] = item['size']
            result[path] = row
    return result


def publish(plan_arg, authority_arg, started, ownership):
    need(Path(__file__) == SELF_PATH and Path.cwd() == P2, 'exact Source and isolated P2 cwd')
    need(sys.executable == PYTHON['path'] and sys.platform == 'darwin'
         and sys.version_info[:3] == (3, 12, 14) and sys.flags.isolated == 1
         and sys.flags.no_site == 1 and sys.flags.optimize == 0 and sys.dont_write_bytecode,
         'D90 -I -S -B required')
    plan, plan_ref = plan_read(plan_arg)
    authority, authority_ref = admin(authority_arg)
    fields(authority, ('schema', 'authorized', 'uses', 'plan', 'publisher', 'python'), 'authority exact6')
    publisher_ref = authority['publisher']
    fields(publisher_ref, ('path', 'bytes', 'sha256'), 'publisher rawref exact3')
    need(publisher_ref['path'] == str(SELF_PATH), 'current publisher path')
    rawref(publisher_ref, ADMIN_CAP)
    expected = {'schema': 'Root-indexed-first-order-proof-search-P2-once-authority-v1',
                'authorized': True, 'uses': 1, 'plan': plan_ref, 'publisher': publisher_ref, 'python': PYTHON}
    need(encode(authority) == encode(expected), 'whole typed authority/plan/runtime association')
    rawref(PYTHON, PYTHON['bytes'])
    marker = Path(authority_ref['path'] + '.CONSUMED.json')
    fresh(marker)
    fresh(OUT)
    consume = {'schema': 'Root-indexed-first-order-proof-search-P2-consumed-v1',
               'uses': 1, 'authority': authority_ref, 'plan': plan_ref, 'publisher': publisher_ref,
               'meaning': 'permanently spent before any payload-body transport or network; no retry'}
    consumed_ref = create(marker, encode(consume), ADMIN_CAP)
    sync_dir(ROOT)
    OUT.mkdir(mode=0o700)
    ownership['out'] = True
    sync_dir(ROOT)
    session = Session(started)
    bodies = local_guards(plan, plan_ref, authority_ref, publisher_ref)
    session.save('preflight.json', encode({'plan': plan_ref, 'authority': authority_ref,
                 'publisher': publisher_ref, 'python': PYTHON, 'consumed': consumed_ref,
                 'targets': plan['files'], 'parent': EXPECTED_PARENT, 'tree': EXPECTED_TREE}), ADMIN_CAP)
    before_head = head(session, '01-head-before')
    need(before_head == EXPECTED_PARENT, 'main moved; stop without retry')
    commit_before = session.api('02-commit-before', 'GET', 'git/commits/' + before_head)
    need(commit_before['sha'] == before_head and commit_before['tree']['sha'] == EXPECTED_TREE,
         'fixed parent/tree identity')
    before = leaves(session, '03-tree-before', EXPECTED_TREE)
    targets = {row['path'] for row in plan['files']}
    need(all(path not in before for path in targets), 'all three NEW target leaves must be absent')
    for index, (row, raw) in enumerate(zip(plan['files'], bodies, strict=True)):
        response = session.api('04-blob-' + str(index), 'POST', 'git/blobs',
                               {'content': base64.b64encode(raw).decode('ascii'), 'encoding': 'base64'})
        need(response['sha'] == row['git_blob_sha1'], 'remote payload blob identity')
    tree = session.api('05-create-tree', 'POST', 'git/trees', {'base_tree': EXPECTED_TREE,
                       'tree': [{'path': row['path'], 'mode': '100644', 'type': 'blob',
                                 'sha': row['git_blob_sha1']} for row in plan['files']]})
    after_tree = git_sha(tree['sha'])
    after = leaves(session, '06-tree-after', after_tree)
    need({k: v for k, v in before.items() if k not in targets}
         == {k: v for k, v in after.items() if k not in targets}, 'every nontarget leaf mode/type/SHA/size preserved')
    need(len(after) == len(before) + 3, 'exact three new leaves')
    for row in plan['files']:
        need(after.get(row['path']) == {'mode': '100644', 'type': 'blob',
             'sha': row['git_blob_sha1'], 'size': row['root_source']['bytes']}, 'exact new target leaf')
    commit = session.api('07-create-commit', 'POST', 'git/commits',
                         {'message': 'Publish indexed finite first-order proof search outcomes and evidence',
                          'tree': after_tree, 'parents': [before_head]})
    new_head = git_sha(commit['sha'])
    need(commit['tree']['sha'] == after_tree and [p['sha'] for p in commit['parents']] == [before_head],
         'single adopted parent and exact tree')
    need(head(session, '08-head-before-update') == before_head, 'head race; stop without retry')
    updated = session.api('09-update-main', 'PATCH', 'git/refs/heads/main', {'sha': new_head, 'force': False})
    need(updated['ref'] == 'refs/heads/main' and updated['object']['type'] == 'commit'
         and updated['object']['sha'] == new_head, 'uncertain main mutation; read-only reconciliation only')
    need(head(session, '10-head-after') == new_head, 'post-head differs; read-only reconciliation only')
    need(session.calls == EXPECTED_API_CALLS, 'exact twelve API calls')
    need(local_guards(plan, plan_ref, authority_ref, publisher_ref) == bodies, 'complete post-payload twins unchanged')
    rawref(consumed_ref, ADMIN_CAP)
    session.wall()
    terminal = {'schema': 'Root-indexed-first-order-proof-search-P2-terminal-v1',
                'status': 'EXACT_THREE_NEW_PATHS_COMMITTED_LIVE_CHECK_PENDING', 'version': VERSION,
                'plan': plan_ref, 'authority': authority_ref, 'consumed': consumed_ref,
                'publisher': publisher_ref, 'python': PYTHON, 'commit': new_head, 'parent': before_head,
                'before_tree': EXPECTED_TREE, 'after_tree': after_tree, 'files': plan['files'],
                'all_nontarget_leaves_preserved': True, 'nontarget_leaf_count': len(before),
                'API_calls': session.calls, 'all_prior_receipts': session.census(),
                'main_entry_elapsed_seconds_before_terminal': time.monotonic() - started,
                'scope': 'Administrative publication only. No science/checker execution. Needs authoritative caller exit0 and full raw captures plus separate normal-TLS whole-body checks of exactly three new targets. Parent/import/startup and final terminal/flush/shutdown tails are not a hard whole-lifetime quota.'}
    terminal_ref = session.save('terminal.json', encode(terminal), ADMIN_CAP)
    session.census()
    session.wall()
    return {'schema': 'Root-indexed-first-order-proof-search-P2-outer-v1', 'status': terminal['status'],
            'commit': new_head, 'terminal': terminal_ref, 'requires_authoritative_exit_zero': True}


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority', required=True)
    args = parser.parse_args()
    ownership = {'out': False}
    try:
        result = publish(args.plan, args.authority, started, ownership)
        sys.stdout.buffer.write(encode(result))
        sys.stdout.buffer.flush()
        return 0
    except Exception as error:
        # No retry or read-only reconciliation is performed by this Source.
        failure = {'schema': 'Root-indexed-first-order-proof-search-P2-failure-v1', 'status': 'UNADMITTED_NO_AUTOMATIC_RETRY',
                   'exception_type': type(error).__name__, 'message': str(error),
                   'scope': 'If marker exists the authority is permanently spent. Any mutation may have happened; Root must reconcile separately with read-only evidence.'}
        try:
            if ownership['out'] and OUT.is_dir() and not OUT.is_symlink():
                raw = encode(failure)
                paths = list(OUT.iterdir())
                need(len(paths) + 1 <= OUTPUT_COUNT and sum(p.stat().st_size for p in paths) + len(raw) <= OUTPUT_CAP, 'failure receipt reserve')
                create(OUT / 'failure.json', raw, ADMIN_CAP)
        except Exception:
            pass
        traceback.print_exc(file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
