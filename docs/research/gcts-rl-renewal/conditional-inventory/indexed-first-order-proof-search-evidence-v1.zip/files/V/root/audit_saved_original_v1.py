"""Stdlib saved-data integrity/arithmetic only. No scientific imports/calls."""
from pathlib import Path
import gzip,hashlib,json
R=Path('/private/tmp/gcts-indexed-first-order-search-20261028-v1/root');A=R.parent/'actual/study-001'
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):
 p=Path(p);b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
def bound(r):
 assert ref(r['path'])==r;return Path(r['path']).read_bytes()
o=load(A/'observer-result.json');plan=load(R/'study-once-plan-001.json')
assert o['status']=='COMPLETE' and o['returncode']==0 and o['failure'] is None and not o['cleanup_errors']
assert o['wait_confirmed'] and o['both_streams_EOF'] and o['group_gone']
assert o['retained_streams_complete']==dict(stdout=True,stderr=True)
assert bound(o['streams']['stderr'])==b''
assert json.loads(bound(o['streams']['stdout']))==o['worker_terminal']
assert len(o['files'])==len({r['path'] for r in o['files']})
assert set(p for p in A.iterdir() if p.name!='observer-result.json')=={Path(r['path']) for r in o['files']}
for r in o['files']:bound(r)
assert sum(r['bytes'] for r in o['files'])==o['stored_bytes']
for r in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python'],plan['bootstrap']]:bound(r)
auth=load(R/'study-once-authority-001.json');assert auth['uses']==1 and type(auth['uses'])is int and auth['authorized'] is True
assert auth['plan']==ref(R/'study-once-plan-001.json') and auth['runner']==plan['sources']['runner'] and auth['python']==plan['python']
consumed=load(R/'study-once-authority-001.json.CONSUMED.json')
assert consumed==dict(authority=ref(R/'study-once-authority-001.json'),plan=auth['plan'],status='SPENT')
w=load(o['worker_terminal']['result']['stored']['path']);art={x['name']:x for x in w['artifacts']}
assert len(art)==len(w['artifacts'])
rawbytes=0
for r in art.values():
 b=bound(r['stored']);raw=gzip.decompress(b) if r['encoding']=='gzip-json' else b
 assert len(raw)==r['raw_bytes'] and hashlib.sha256(raw).hexdigest()==r['raw_sha256'];json.loads(raw);rawbytes+=len(raw)
assert w['qualification']['status']=='PASS' and len(w['qualification_checks'])==25
normal=[]
for name,r in art.items():
 if name.startswith('qualification-') and not name.endswith('-whole-proof-check'):
  x=load(r['stored']['path'])
  if 'full_solution_ID_sets' in x:normal.append(x)
assert len(normal)==15 and sum(len(x['observations']) for x in normal)<=w['qualification']['counts']['observations']
checks=[]
for p in sorted(A.glob('*-whole-proof-check.json*')):
 c=load(p);stream=bytes.fromhex(c['encoding']['stream_hex'])
 assert c['status']=='VERIFIED' and c['encoding']['status']==c['decoding']['status']=='COMPLETE'
 assert c['decoding']['proof']==c['proof'] and c['decoding']['stream_hex']==c['encoding']['stream_hex']
 assert c['choice']['status']=='VERIFIED' and c['choice']['byte_values']==list(stream)
 nodes=[list(n) for n in c['carrier']['value']['nodes']]
 assert len(c['carrier']['value']['byte_rows'])==len(stream)
 for row in c['carrier']['value']['byte_rows']:nodes[row['node_index']][0]=stream[row['byte_index']]
 assert nodes==c['initial_nodes']
 assert c['native']['status']=='accepted' and type(c['native']['value'])is int and c['native']['value']==1
 assert c['independent']['status']=='VERIFIED' and c['independent']['checked_lines']==len(c['proof'])
 assert c['proof'][-1]['formula']==c['goal'] and c['native']['heap_nodes']==len(c['final_heap'])
 checks.append(c)
assert len(checks)==29
for row in w['results']:
 if row['build_status']!='COMPLETE':
  assert row['build_status']=='UNKNOWN' and row['point']['status']==row['control']['status']=='NOT_RUN_INCOMPLETE_BUILD';continue
 ans=load(art[row['id']+'-point-full-result']['stored']['path'])
 assert ans['entry_state']==ans['restored_state'] and ans['stats']['trail_writes']==ans['stats']['trail_undos']
 for state in ('entry','restored'):
  b=(json.dumps(ans[state+'_state'],sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
  assert hashlib.sha256(b).hexdigest()==ans['state_hashes'][state]
 assert sum(ans['entry_state']['degrees'])==ans['stats']['virtual_members']
 assert sum(map(len,ans['entry_state']['marking_dependencies']))==ans['stats']['dependency_links']
 if ans['status']=='SAT':assert row['point']['proof'] is not None and row['point']['check']['status']=='VERIFIED'
 assert ans['status']==row['point']['status']
result={'schema':'V-Root-original-complete-saved-integrity-audit-v1','status':'PASS_SAVED_INTEGRITY_ONLY','observer':ref(A/'observer-result.json'),'worker':o['worker_terminal']['result'],'plan':auth['plan'],'file_count':len(o['files']),'stored_bytes':o['stored_bytes'],'raw_artifact_bytes':rawbytes,'normal_models':len(normal),'products':sum(x['product'] for x in normal),'solutions':sum(len(x['full_solution_ID_sets']) for x in normal),'observations':w['qualification']['counts']['observations'],'proofs':len(checks),'proof_lines':sum(len(c['proof']) for c in checks),'native_steps':sum(c['native']['steps'] for c in checks),'no_rerun':True,'scope':'Every original file/hash and artifact lossless body; typed once/ownership guards; all29 saved native codec/carrier/proof/status/heap bindings; all4 prepared final graph restorations/stat cardinalities. Original runtime claims remain bounded; independent saved scientific peers pending.'}
p=R/'Root-original-study001-complete-saved-integrity-audit-v1.json'
with p.open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(result,sort_keys=True))
