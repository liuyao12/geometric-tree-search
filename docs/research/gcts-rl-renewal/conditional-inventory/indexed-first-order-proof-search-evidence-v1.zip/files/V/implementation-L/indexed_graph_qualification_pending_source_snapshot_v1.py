"""Inert independent tiny exhaustive virtual-graph qualification.

All producers/checker are injected only by a future owned once. No project
imports, IO, module-body fixtures or subject calls. Public audit_state assumes
an independently verified COMPLETE compiled catalogue; it checks point graphs,
not native schema truth. Main benchmarks need not retain full tiny snapshots.
"""
import hashlib
import itertools
import json
import math
import time

VERSION = 'V-INDEPENDENT-INDEXED-GRAPH-QUALIFICATION-v1'
AUDIT_LIMITS = dict(wall_seconds=15, max_work=20000000)
ENGINE_LIMITS = dict(wall_seconds=2, max_nodes=50000,
                     max_operations=20000000, max_families=10000,
                     max_virtual_members=100000, max_events=100000)
BUILD_LIMITS = dict(wall_seconds=2, max_work=20000000, max_basis=10000,
                    max_instances=10000, max_depth=128,
                    max_cache_entries=100000, max_interned=100000)
ROW_LIMITS = dict(wall_seconds=2, max_work=20000000,
                  max_candidates=100000, max_depth=128)
PRODUCT_CAP = 20000
SCOPE = ('Independent complete tiny explicit candidate universe, every retained '
         'observer image and finite full-tiling enumeration. Native logical '
         'basis/schema truth is Source-reviewed; whole proofs still need actual '
         'native C1 and independent B. No post-throw state or full main history '
         'is fabricated. No unrestricted FOL or performance claim.')


class AuditError(ValueError):
    pass


class AuditBudget(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise AuditError(message)


def _fields(x, keys):
    _need(type(x) is dict and len(x) == len(keys)
          and all(type(k) is str for k in x) and set(x) == set(keys), 'fields')


class _Meter:
    def __init__(self, limits=None, wall=15, work=20000000):
        self.start = time.perf_counter()
        limits = dict(wall_seconds=wall, max_work=work) if limits is None else limits
        _fields(limits, {'wall_seconds', 'max_work'})
        w = limits['wall_seconds']
        _need(type(w) in (int, float) and 0 < w <= 60 and math.isfinite(w), 'wall')
        _need(type(limits['max_work']) is int and 0 <= limits['max_work'] <= 1000000000,
              'work limit')
        self.wall = w
        self.maximum = limits['max_work']
        self.work = 0

    def tick(self, n=1):
        if n > self.maximum - self.work:
            raise AuditBudget('WORK')
        self.work += n
        if time.perf_counter() - self.start > self.wall:
            raise AuditBudget('WALL')


def _weight(value, m, depth=0):
    m.tick()
    if depth > 128:
        raise AuditBudget('DEPTH')
    if value is None or type(value) is bool:
        return 5
    if type(value) is int:
        _need(value.bit_length() <= 256, 'bounded integer wire')
        return 80
    if type(value) is float:
        _need(math.isfinite(value), 'finite wire')
        return 32
    if type(value) is str:
        m.tick(len(value))
        return 2 + 12 * len(value)
    if type(value) is list:
        m.tick(len(value))
        return 2 + sum(1 + _weight(v, m, depth + 1) for v in value)
    _need(type(value) is dict and all(type(k) is str for k in value), 'native wire')
    m.tick(len(value))
    return 2 + sum(2 + _weight(k, m, depth + 1) + _weight(v, m, depth + 1)
                   for k, v in value.items())


def _wire(value, m):
    upper = _weight(value, m)
    m.tick(upper)
    if upper > 16000000:
        raise AuditBudget('WIRE')
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _same(a, b, m):
    return _wire(a, m) == _wire(b, m)


def _sha(value, m):
    return hashlib.sha256(_wire(value, m)).hexdigest()


def _clone(value, m):
    return json.loads(_wire(value, m))


def _model(compiled, slots, m):
    _need(type(slots) is int and 1 <= slots <= 64, 'slots')
    # Full logical catalogue validation belongs to separately injected L core.
    colors = compiled['logical_basis']['colors']
    m.tick(len(colors) + len(compiled['zero_instances']))
    return {'slots': slots, 'colors': list(colors), 'goal_id': compiled['goal_id'],
            'zero': [[r['id'], r['formula_id']] for r in compiled['zero_instances']],
            'mp_index': _clone(compiled['mp_index'], m),
            'gen_index': _clone(compiled['gen_index'], m)}


def _graph(compiled, slots, m):
    model = _model(compiled, slots, m)
    forms = compiled['logical_basis']['formulas']
    zero = {r['id']: r for r in compiled['zero_instances']}
    families = []
    candidates = {}
    steps = {}
    for row in range(slots):
        for iid, output in model['zero']:
            m.tick()
            if row == slots - 1 and output != model['goal_id']:
                continue
            prefix = 'r%d:%s' % (row, iid)
            if len(families)>=10000:
                raise AuditBudget('FAMILIES')
            families.append([prefix, 'zero', row, output, None, None])
        for fi, antecedent, output in model['mp_index']:
            m.tick()
            if row != slots - 1 or output == model['goal_id']:
                if len(families)>=10000:
                    raise AuditBudget('FAMILIES')
                families.append(['r%d:mp:%d:' % (row, fi), 'mp', row,
                                 output, antecedent, fi])
        for fi, body, variable in model['gen_index']:
            m.tick()
            if row != slots - 1 or fi == model['goal_id']:
                if len(families)>=10000:
                    raise AuditBudget('FAMILIES')
                families.append(['r%d:gen:%d:' % (row, fi), 'gen', row,
                                 fi, body, None])
    m.tick(len(families))
    families.sort(key=lambda f: f[0])
    byrow = [[] for _ in range(slots)]
    deps = [[] for _ in range(slots)]
    reverse = []
    for k, family in enumerate(families):
        m.tick()
        prefix, kind, row, output, left, right = family
        byrow[row].append(k)
        points = [row] if kind == 'zero' else list(range(row + 1))
        m.tick(len(points))
        reverse.append(points)
        for point in points:
            deps[point].append(k)
        if kind == 'zero':
            options = [(prefix, {}, zero[prefix.split(':')[1]]['line'],
                        prefix.split(':')[1])]
        elif kind == 'gen':
            variable = next(v for fi, body, v in model['gen_index'] if fi == output)
            options = ((prefix + str(a), {a: left},
                       {'rule': 'generalize', 'formula': forms[output],
                        'source': a, 'variable': variable}, None)
                       for a in range(row))
        else:
            options = ((prefix + '%d:%d' % (a, b), {a: left, b: right},
                       {'rule': 'mp', 'formula': forms[output],
                        'antecedent': a, 'implication': b}, None)
                       for a in range(row) for b in range(row)
                       if a != b or left == right)
        for cid, marks, line, instance in options:
            m.tick()
            if len(candidates) >= 100000:
                raise AuditBudget('MEMBERS')
            marks[row] = output
            _need(cid not in candidates, 'candidate identity collision')
            candidates[cid] = (row, marks, k)
            steps[cid] = {'slot': row, 'line': line, 'instance': instance}
    domain = [[] for _ in range(slots)]
    raw = []
    for cid in sorted(candidates):
        m.tick()
        row, marks, family = candidates[cid]
        domain[row].append(cid)
        raw.append({'id': cid, 't': ['slot:' + str(row)],
                    'm': [[point, model['colors'][value]] for point, value in
                          sorted(('out:' + str(q), v) for q, v in marks.items())]})
    return {'model': model, 'families': families, 'byrow': byrow,
            'deps': deps, 'reverse': reverse, 'candidates': candidates,
            'steps': steps, 'domain': domain,
            'raw_model': {'required': ['slot:' + str(q) for q in range(slots)],
                          'candidates': raw}}


def _solutions(graph, m):
    count = 1
    for domain in graph['domain']:
        m.tick()
        count *= len(domain)
        if count > PRODUCT_CAP:
            raise AuditBudget('TINY_PRODUCT')
    m.tick(count * max(1, graph['model']['slots']))
    result = []
    for selected in itertools.product(*graph['domain']):
        assigned = {}
        compatible = True
        for cid in selected:
            m.tick()
            for point, value in graph['candidates'][cid][1].items():
                m.tick()
                if point in assigned and assigned[point] != value:
                    compatible = False
                    break
                assigned[point] = value
            if not compatible:
                break
        if compatible:
            result.append(tuple(sorted(selected)))
    return count, result


def _core(state):
    return {k: state[k] for k in ('occupied', 'selected', 'values', 'refs', 'excluded')}


def _state(graph, state, m, solutions=None):
    _fields(state, {'schema', 'occupied', 'selected', 'values', 'refs', 'excluded',
                    'required', 'frontier', 'root_generations', 'degrees', 'factors',
                    'row_families', 'family_rows', 'marking_dependencies',
                    'reverse_marking_dependencies'})
    _need(state['schema'] == 'V-indexed-unit-point-state-v1', 'state schema')
    n = graph['model']['slots']
    for key in ('occupied', 'selected', 'values', 'refs'):
        _need(type(state[key]) is list and len(state[key]) == n, 'state row array')
    _need(all(type(v) is bool for v in state['occupied']), 'occupied bool')
    _need(all(v is None or type(v) is str for v in state['selected']), 'selected type')
    _need(all(v is None or type(v) is int and 0 <= v < len(graph['model']['colors'])
              for v in state['values']), 'values IDs')
    _need(all(type(v) is int and v >= 0 for v in state['refs']), 'refs type')
    excluded = state['excluded']
    _need(type(excluded) is list and all(type(cid) is str for cid in excluded)
          and excluded == sorted(set(excluded))
          and all(cid in graph['candidates'] for cid in excluded), 'excluded')
    expected_values = [None] * n
    expected_refs = [0] * n
    selected_ids = []
    for row, cid in enumerate(state['selected']):
        m.tick()
        _need(state['occupied'][row] == (cid is not None), 'occupied/selected')
        if cid is None:
            continue
        _need(cid in graph['candidates'] and graph['candidates'][cid][0] == row
              and cid not in excluded, 'selected actual member/root')
        selected_ids.append(cid)
        for point, value in graph['candidates'][cid][1].items():
            m.tick()
            _need(expected_values[point] is None or expected_values[point] == value,
                  'selected actual m conflict')
            expected_values[point] = value
            expected_refs[point] += 1
    _need(_same(state['values'], expected_values, m)
          and _same(state['refs'], expected_refs, m), 'whole assigned values/refcounts')
    # Complete physical legality independently visits every virtual candidate.
    legal = [[] for _ in range(n)]
    family_counts = [0] * len(graph['families'])
    for cid, (row, marks, k) in graph['candidates'].items():
        m.tick()
        if state['occupied'][row] or cid in excluded:
            continue
        if all(expected_values[p] is None or expected_values[p] == value
               for p, value in marks.items()):
            legal[row].append(cid)
            family_counts[k] += 1
    for domain in legal:
        m.tick(len(domain))
        domain.sort()
    factors = []
    for k, (_, kind, row, output, left, right) in enumerate(graph['families']):
        m.tick()
        enabled = not state['occupied'][row] and (
            expected_values[row] is None or expected_values[row] == output)
        if not enabled:
            factors.append([False, [], [], 0])
            continue
        left_refs = [] if kind == 'zero' else sorted(
            [q for q in range(row) if expected_values[q] is None
             or expected_values[q] == left], key=str)
        right_refs = [] if kind != 'mp' else sorted(
            [q for q in range(row) if expected_values[q] is None
             or expected_values[q] == right], key=str)
        m.tick(row * 2)
        factors.append([True, left_refs, right_refs, family_counts[k]])
    expected = {
        'required': ['slot:' + str(q) for q in range(n)],
        'frontier': ['slot:' + str(q) for q in range(n) if not state['occupied'][q]],
        'root_generations': [0] * n,
        'degrees': [len(domain) for domain in legal], 'factors': factors,
        'row_families': graph['byrow'],
        'family_rows': [f[2] for f in graph['families']],
        'marking_dependencies': graph['deps'],
        'reverse_marking_dependencies': graph['reverse']}
    for key, value in expected.items():
        _need(_same(state[key], value, m), 'full graph ' + key)
    if solutions is not None:
        selected_set = set(selected_ids)
        for cid in excluded:
            m.tick(len(solutions))
            _need(not any(selected_set.union([cid]).issubset(sol) for sol in solutions),
                  'excluded member has actual full completion in this context')
    return {'status': 'VERIFIED', 'state_sha256': _sha(state, m),
            'core_sha256': _sha(_core(state), m),
            'legal_ids': legal, 'selected': sorted(selected_ids),
            'scope': 'All materialized members, factors, values/refcounts and both graph/dependency directions; optional full tiny completion exclusion proof.'}


def audit_state(compiled, slots, state, *, limits=None):
    m = _Meter(limits)
    try:
        graph = _graph(compiled, slots, m)
        result = _state(graph, state, m)
        result['work'] = m.work
        result['seconds'] = time.perf_counter() - m.start
        return result
    except AuditError as error:
        return {'status': 'REJECTED', 'reason': str(error), 'scope': SCOPE}
    except AuditBudget as error:
        return {'status': 'UNKNOWN', 'reason': str(error), 'scope': SCOPE}


def _event(graph, event, state, receipt, previous, m):
    _fields(event, {'seq', 'kind', 'data'})
    _need(type(event['seq']) is int and event['seq'] >= 0
          and type(event['kind']) is str, 'event types')
    kind, data = event['kind'], event['data']
    if previous is None:
        _need(kind == 'ENTRY' and event['seq'] == 0, 'first entry event')
        _fields(data, set())
        _need(not any(state['occupied']) and not any(state['refs'])
              and not state['excluded'], 'empty entry')
        return
    old = previous['state']
    legal = previous['audit']['legal_ids']
    if kind == 'DEAD':
        _fields(data, {'row', 'generation'})
        q = data['row']
        _need(type(q) is int and 0 <= q < len(legal) and not state['occupied'][q]
              and type(data['generation']) is int and data['generation'] == 0
              and not receipt['legal_ids'][q] and _same(old,state,m), 'actual global dead')
    elif kind == 'BRANCH':
        _fields(data, {'row', 'generation', 'degree', 'first_candidate', 'order'})
        frontier = [q for q in range(len(legal)) if not old['occupied'][q]]
        _need(frontier and all(len(legal[q]) >= 2 for q in frontier),
              'branch before global dead/forced')
        q = min(frontier, key=lambda r: (len(legal[r]), 'slot:' + str(r)))
        _need(type(data['row']) is int and data['row'] == q
              and type(data['generation']) is int and data['generation'] == 0
              and type(data['degree']) is int and data['degree'] == len(legal[q])
              and data['first_candidate'] == legal[q][0]
              and data['order'] == 'COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS'
              and _same(old, state, m), 'complete MRV lexical branch')
    elif kind == 'PLACED':
        _fields(data, {'candidate', 'row', 'forced', 'root_generation', 'tile_generation'})
        q, cid = data['row'], data['candidate']
        _need(type(q) is int and 0 <= q < len(legal) and type(data['forced']) is bool
              and cid in legal[q] and state['selected'][q] == cid
              and type(data['root_generation']) is int and data['root_generation'] == 0
              and type(data['tile_generation']) is int and data['tile_generation'] == 1,
              'placed actual legal unit member')
        if data['forced']:
            frontier = [r for r in range(len(legal)) if not old['occupied'][r]]
            _need(all(legal[r] for r in frontier), 'forced before later dead')
            singles = [r for r in frontier if len(legal[r]) == 1]
            _need(singles and q == min(singles, key=lambda r: 'slot:' + str(r)),
                  'global forced lexical root')
        else:
            _need(cid == legal[q][0], 'complete lexical branch continuation')
        expected_selected = list(old['selected'])
        expected_selected[q] = cid
        _need(_same(expected_selected, state['selected'], m)
              and _same(old['excluded'], state['excluded'], m), 'one placement')
    elif kind == 'EXCLUDED':
        _fields(data, {'candidate', 'parent_core_sha256'})
        cid = data['candidate']
        _need(type(cid) is str and cid in graph['candidates']
              and data['parent_core_sha256'] == previous['audit']['core_sha256'],
              'exclusion exact parent')
        for key in ('occupied', 'selected', 'values', 'refs'):
            _need(_same(old[key], state[key], m), 'exclusion changes only exclusions')
        _need(cid not in old['excluded'] and state['excluded'] == sorted(old['excluded'] + [cid]),
              'one scoped exclusion')
    elif kind == 'ROLLBACK':
        _fields(data, {'reason', 'target', 'undone', 'before_core_sha256',
                       'after_core_sha256', 'expected_parent_core_sha256'})
        _need(data['reason'] == 'FAILED_CHILD'
              and data['before_core_sha256'] == previous['audit']['core_sha256']
              and data['after_core_sha256'] == receipt['core_sha256']
              and data['expected_parent_core_sha256'] == receipt['core_sha256'],
              'actual failed-child core restoration')
    elif kind == 'SOLUTION':
        _fields(data, {'selected'})
        _need(all(state['occupied']) and data['selected'] == receipt['selected']
              and _same(old,state,m),
              'whole actual solution event')
    else:
        raise AuditError('unexpected event kind')


def _certificate(graph, selected, indexed, m):
    n = graph['model']['slots']
    totals = [0] * n
    values = [None] * n
    refs = [0] * n
    for cid in selected:
        _need(cid in graph['candidates'], 'certificate member')
        row, marks, family = graph['candidates'][cid]
        totals[row] += 1
        for point, value in marks.items():
            _need(values[point] is None or values[point] == value, 'certificate m')
            values[point] = value
            refs[point] += 1
    _need(totals == [1] * n and all(v is not None for v in values), 'whole t/m')
    if indexed:
        return {'selected': sorted(selected), 'totals': totals,
                'markings': [[q, graph['model']['colors'][values[q]], refs[q]] for q in range(n)],
                'generations': [[cid, 1] for cid in sorted(selected)]}
    return {'selected': sorted(selected),
            'totals': [['slot:' + str(q), 1] for q in range(n)],
            'markings': [['out:' + str(q), graph['model']['colors'][values[q]], refs[q]] for q in range(n)],
            'generations': [[cid, 1] for cid in sorted(selected)]}


def _result(graph, result, observations, m, solutions=None):
    _fields(result, {'schema', 'version', 'status', 'reason', 'model', 'families',
                     'model_sha256', 'selected', 'certificate', 'stats', 'events',
                     'event_extent', 'entry_state', 'restored_state', 'state_hashes',
                     'rollback_records', 'scope'})
    _need(_same(result['model'], graph['model'], m)
          and _same(result['families'], graph['families'], m)
          and result['model_sha256'] == _sha(graph['model'], m), 'result whole model/families')
    _need(result['status'] in ('SAT', 'UNSAT', 'UNKNOWN'), 'status')
    if solutions is not None:
        _need(result['status'] == ('SAT' if solutions else 'UNSAT'), 'tiny exhaustive outcome')
    if result['status'] == 'SAT':
        selected = result['selected']
        _need(type(selected) is list and selected == sorted(set(selected)), 'selected shape')
        if solutions is not None:
            _need(tuple(selected) in solutions, 'full tiny solution membership')
        _need(_same(result['certificate'], _certificate(graph, selected, True, m), m),
              'exact actual point certificate')
    else:
        _need(result['selected'] is None and result['certificate'] is None, 'no false certificate')
    hashes = result['state_hashes']
    _fields(hashes, {'entry', 'restored'})
    if result['entry_state'] is not None:
        _state(graph, result['entry_state'], m)
        _need(result['restored_state'] is not None, 'prepared restoration exists')
        _state(graph, result['restored_state'], m)
        _need(_same(result['entry_state'], result['restored_state'], m)
              and hashes['entry'] == _sha(result['entry_state'], m)
              and hashes['restored'] == _sha(result['restored_state'], m), 'full restoration')
    else:
        _need(result['status'] == 'UNKNOWN' and result['restored_state'] is None
              and hashes == {'entry': None, 'restored': None}, 'preparation-refused scope')
    extent = result['event_extent']
    _fields(extent, {'count', 'retained', 'JSONL_bytes', 'SHA256', 'evaluation_complete'})
    events = [row['event'] for row in observations]
    _need(_same(result['events'], events, m), 'all tiny full observed event bodies retained')
    _need(all(type(v) is int and v >= 0 for v in
              [extent['count'], extent['retained'], extent['JSONL_bytes']]), 'event extent ints')
    stream = b''.join(_wire(event, m) for event in events)
    _need(extent['count'] == extent['retained'] == len(events)
          and extent['JSONL_bytes'] == len(stream)
          and extent['SHA256'] == hashlib.sha256(stream).hexdigest()
          and type(extent['evaluation_complete']) is bool
          and extent['evaluation_complete'] == (result['status'] != 'UNKNOWN'), 'full event extent')
    stat = result['stats']
    integer_keys = {'operations','nodes','families','virtual_members','dependency_links',
                    'family_refreshes','placements','forced_placements','branch_decisions',
                    'backtracks','scoped_exclusions','trail_writes','trail_undos','max_trail',
                    'cleanup_undos','observations','events'}
    _fields(stat, integer_keys.union({'cleanup_seconds','elapsed_seconds'}))
    _need(all(type(stat[k]) is int and stat[k] >= 0 for k in integer_keys), 'stats integers')
    _need(all(type(stat[k]) in (int, float) and math.isfinite(stat[k]) and stat[k] >= 0
              for k in ('cleanup_seconds','elapsed_seconds')), 'stats clocks')
    _need(stat['events'] == len(events) and stat['observations'] == len(events), 'observation census')
    records = result['rollback_records']
    _need(type(records) is list, 'rollback records')
    undone = 0
    final = None
    for record in records:
        m.tick()
        reason = record['reason']
        extra = 'expected_parent_core_sha256' if reason == 'FAILED_CHILD' else 'full_restored_sha256'
        _fields(record, {'reason','target','undone','before_core_sha256','after_core_sha256',extra})
        _need(reason in ('FAILED_CHILD', 'FINAL_MANDATORY_CLEANUP')
              and type(record['target']) is type(record['undone']) is int
              and record['target'] >= 0 and record['undone'] >= 0, 'rollback types')
        undone += record['undone']
        if reason == 'FAILED_CHILD':
            _need(record['after_core_sha256'] == record['expected_parent_core_sha256']
                  and any(row['event']['kind'] == 'ROLLBACK' and
                          _same(row['event']['data'], record, m) for row in observations),
                  'failed child full record associated')
        else:
            _need(final is None and record is records[-1] and record['target'] == 0,
                  'one last whole cleanup')
            final = record
    _need(undone == stat['trail_undos'] and stat['trail_writes'] == stat['trail_undos'],
          'actual all-write rollback conservation')
    if result['entry_state'] is not None:
        _need(final is not None and final['undone'] == stat['cleanup_undos']
              and final['full_restored_sha256'] == hashes['restored']
              and final['after_core_sha256'] == _sha(_core(result['restored_state']), m),
              'final cleanup scope')
    return {'status':'VERIFIED','observations':len(observations),'undo_entries':undone,
            'scope':SCOPE}


def _run(indexed, compiled, slots, graph, m, solutions=None, limits=None, mutate=False):
    observations = []
    def observe(event, state):
        m.tick()
        receipt = _state(graph, state, m, solutions)
        _event(graph, event, state, receipt, observations[-1] if observations else None, m)
        _need(event['seq'] == len(observations), 'complete observation sequence')
        observations.append({'event':_clone(event,m),'state':_clone(state,m),'audit':receipt})
        if mutate:
            event.clear()
            state['selected'].append('FOREIGN_MUTATION')
        return False
    result = indexed.solve(compiled, slots, dict(ENGINE_LIMITS) if limits is None else limits,
                           observe=observe)
    receipt = _result(graph, result, observations, m, solutions)
    return result, observations, receipt


def _cases():
    p=['pred','P',[]]; q=['pred','Q',[]]
    return [
        ('GIVEN',{'p':p},p,(1,2,3)),
        ('MP',{'p':p,'pq':['imp',p,q]},q,(1,2,3)),
        ('GEN',{'p':p},['all','x',p],(1,2,3)),
        ('LATE-DEAD',{'p':p},q,(2,)),
        ('UNSEEDED-CYCLE',{'pq':['imp',p,q],'qp':['imp',q,p]},p,(1,2,3)),
        ('ZERO-WITNESS-ALIASES',{'a':p,'b':p},p,(1,2))]


def qualify(basis, reference, indexed, explicit, checker, emit):
    m = _Meter(wall=60, work=1000000000)
    _need(callable(emit), 'emit callable')
    profile={'ui_rounds':0,'bridge_arity':0,'max_tautology_atoms':4}
    counts={'basis_build':0,'basis_materialize':0,'reference_build':0,
            'indexed_solve':0,'explicit_solve':0,'core_compiled':0,
            'core_selection':0,'core_backward':0,'emitted':0,'observations':0}
    retained={}
    for name, axioms, goal, rows in _cases():
        predicates={k:0 for k in ('P','Q') if k == 'P' or name in ('MP','UNSEEDED-CYCLE','LATE-DEAD')}
        theory={'functions':{},'predicates':predicates,'axioms':axioms}
        problem={'theory':theory,'goal':goal,'profile':dict(profile)}
        for slots in rows:
            m.tick()
            input_sha=_sha(problem,m)
            built=basis.build_basis(theory,goal,dict(profile),dict(BUILD_LIMITS));counts['basis_build']+=1
            _need(built['status']=='COMPLETE' and built['compiled'] is not None,'tiny basis complete')
            compiled=built['compiled']
            core=checker.verify_compiled(problem,compiled);counts['core_compiled']+=1
            _need(core['status']=='VERIFIED','core whole catalogue')
            materialized=basis.materialize(compiled,slots,dict(ROW_LIMITS));counts['basis_materialize']+=1
            old_limits=dict(ROW_LIMITS,max_basis=10000,max_instances=10000)
            old=reference.build(theory,goal,slots,dict(profile),old_limits);counts['reference_build']+=1
            _need(materialized['status']==old['status']=='COMPLETE','both full row catalogues')
            graph=_graph(compiled,slots,m)
            bundle=materialized['bundle']; oldbundle=old['bundle']
            for wire in (bundle,oldbundle):
                _need(_same(wire['model']['required'],graph['raw_model']['required'],m)
                      and _same({c['id']:c for c in wire['model']['candidates']},
                                {c['id']:c for c in graph['raw_model']['candidates']},m)
                      and len(wire['model']['candidates'])==len(graph['candidates'])
                      and _same(wire['steps'],graph['steps'],m),'whole explicit universe/steps')
            projection={k:v for k,v in compiled['logical_basis'].items() if k!='colors'}
            zeros=[{k:v for k,v in r.items() if k!='formula_id'} for r in compiled['zero_instances']]
            for wire in (bundle,oldbundle):
                _need(_same(wire['basis'],projection,m) and _same(wire['instances'],zeros,m),
                      'exact U logical projection/witness payloads')
            product,solutions=_solutions(graph,m)
            point,observations,audit=_run(indexed,compiled,slots,graph,m,solutions)
            counts['indexed_solve']+=1;counts['observations']+=len(observations)
            if name=='LATE-DEAD':
                _need(observations[0]['state']['degrees']==[1,0]
                      and [r['event']['kind'] for r in observations]==['ENTRY','DEAD'],
                      'later empty row before earlier singleton')
            if name=='GIVEN' and slots==2:
                _need(all(v is None for v in observations[0]['state']['values'])
                      and any(0 in r['state']['values'] for r in observations),
                      'assigned formula ID0 differs from missing')
            if name=='ZERO-WITNESS-ALIASES' and slots==1:
                _need(observations[0]['state']['degrees']==[2],
                      'equal-output aliases remain distinct members')
            if name=='UNSEEDED-CYCLE' and slots==3:
                _need(any(r['event']['kind']=='EXCLUDED' for r in observations)
                      and any(r['event']['kind']=='ROLLBACK' for r in observations),
                      'actual failed-child exclusion and restoration exercised')
            simple=explicit.solve(graph['raw_model'],{'wall_seconds':2,'max_nodes':50000,'max_events':100000})
            counts['explicit_solve']+=1
            _need(simple['status']==point['status'],'same complete tiny point outcome')
            _need(_same(simple['entry_state'],simple['restored_state'],m),'old S actual restoration')
            if point['status']=='SAT':
                _need(tuple(sorted(simple['selected'])) in solutions
                      and _same(simple['certificate'],_certificate(graph,simple['selected'],False,m),m),
                      'old S full tiny certificate')
                selection=checker.verify_selection(problem,compiled,slots,point['selected'])
                counts['core_selection']+=1
                _need(selection['status']=='VERIFIED','independent native selection proof')
            else:
                _need(simple['selected'] is None and simple['certificate'] is None,'old S no false certificate')
                selection=None
            backward=checker.backward_dag(problem,compiled,slots);counts['core_backward']+=1
            _need(backward['status']==('DERIVABLE' if solutions else 'NOT_DERIVABLE'),
                  'backward shared-fact exhaustive tiny equivalence')
            _need(_sha(problem,m)==input_sha,'producer input purity')
            record={'case':name,'slots':slots,'problem':problem,'basis_return':built,
                    'materialized':materialized,'reference':old,'product':product,
                    'full_solution_ID_sets':[list(s) for s in solutions],
                    'indexed':point,'observations':observations,'graph_audit':audit,
                    'explicit':simple,'core_compiled':core,'core_selection':selection,
                    'backward':backward}
            emit(name+'-'+str(slots),record);counts['emitted']+=1
            retained[(name,slots)]=(problem,compiled,graph,solutions,point,observations)
    # Separate refusals: no normal outcome or post-throw state is invented.
    problem,compiled,graph,solutions,point,observations=retained[('GIVEN',2)]
    for field in ('max_nodes','max_operations','max_families','max_virtual_members'):
        limits=dict(ENGINE_LIMITS);limits[field]=0
        stopped,seen,audit=_run(indexed,compiled,2,graph,m,limits=limits)
        counts['indexed_solve']+=1;counts['observations']+=len(seen)
        _need(stopped['status']=='UNKNOWN','separate owned refusal UNKNOWN')
        emit('REFUSAL-'+field.replace('_','-'),{'limit':limits,'result':stopped,'observations':seen,'audit':audit})
        counts['emitted']+=1
    mutated,seen,audit=_run(indexed,compiled,2,graph,m,solutions,mutate=True)
    counts['indexed_solve']+=1;counts['observations']+=len(seen)
    emit('CALLBACK-FALSE-MUTATION',{'result':mutated,'observations':seen,'audit':audit})
    counts['emitted']+=1
    class ForeignObserverError(Exception):
        pass
    before_throw=[]
    def throwing(event,state):
        receipt=_state(graph,state,m,solutions)
        before_throw.append({'event':_clone(event,m),'state':_clone(state,m),'audit':receipt})
        if event['kind']=='PLACED':
            raise ForeignObserverError('owned qualification sentinel after placement')
        return False
    propagated=False
    try:
        counts['indexed_solve']+=1
        indexed.solve(compiled,2,dict(ENGINE_LIMITS),observe=throwing)
    except ForeignObserverError:
        propagated=True
    _need(propagated and len(before_throw)>=2
          and before_throw[-1]['event']['kind']=='PLACED', 'foreign callback propagation after actual mutation')
    counts['observations']+=len(before_throw)
    emit('CALLBACK-FOREIGN',{'propagated':True,'before_throw':before_throw,
                           'post_exception_state':None,'cleanup_scope':'Source trail coverage only; no returned receipt'})
    counts['emitted']+=1
    # Shared premise must cost once: eight distinct facts, seven insufficient.
    p=['pred','P',[]];q=['pred','Q',[]];r=['pred','R',[]];g=['pred','G',[]]
    theory={'functions':{},'predicates':{'P':0,'Q':0,'R':0,'G':0},
            'axioms':{'p':p,'pq':['imp',p,q],'pr':['imp',p,r],'qrg':['imp',q,['imp',r,g]]}}
    problem={'theory':theory,'goal':g,'profile':dict(profile)}
    built=basis.build_basis(theory,g,dict(profile),dict(BUILD_LIMITS));counts['basis_build']+=1
    _need(built['status']=='COMPLETE','shared DAG complete catalogue')
    check=checker.verify_compiled(problem,built['compiled']);counts['core_compiled']+=1
    _need(check['status']=='VERIFIED','shared catalogue verified')
    shared=[]
    for slots in (7,8):
        result=checker.backward_dag(problem,built['compiled'],slots);counts['core_backward']+=1
        _need(result['status']==('NOT_DERIVABLE' if slots==7 else 'DERIVABLE'), 'shared DAG exact line bound')
        shared.append({'slots':slots,'result':result})
    emit('SHARED-DAG',{'problem':problem,'basis_return':built,'compiled_check':check,'controls':shared})
    counts['emitted']+=1
    # Isolated data-only negatives; no additional producer call.
    problem,compiled,graph,solutions,point,observations=retained[('MP',3)]
    negatives=[]
    for kind in ('missing-MP','zero-bool-ID','wrong-color'):
        bad=_clone(compiled,m)
        if kind=='missing-MP': bad['mp_index']=bad['mp_index'][1:]
        elif kind=='zero-bool-ID': bad['zero_instances'][0]['formula_id']=False
        else: bad['logical_basis']['colors'][0]='FORGED'
        verdict=checker.verify_compiled(problem,bad);counts['core_compiled']+=1
        _need(verdict['status']=='REJECTED','isolated catalogue negative')
        negatives.append({'mutation':kind,'input':bad,'receipt':verdict})
    forged=_clone(observations[0]['state'],m)
    forged['degrees'][0]+=1
    verdict=audit_state(compiled,3,forged)
    _need(verdict['status']=='REJECTED','one count forgery')
    negatives.append({'mutation':'one-degree','input':forged,'receipt':verdict})
    emit('DATA-NEGATIVES',{'controls':negatives});counts['emitted']+=1
    _need(counts['basis_build']==16 and counts['basis_materialize']==15
          and counts['reference_build']==15 and counts['indexed_solve']==21
          and counts['explicit_solve']==15 and counts['core_compiled']==19
          and counts['core_selection']==8 and counts['core_backward']==17
          and counts['emitted']==23,'closed call/record census')
    return {'status':'PASS','version':VERSION,'counts':counts,
            'seconds':time.perf_counter()-m.start,'work':m.work,'scope':SCOPE}
