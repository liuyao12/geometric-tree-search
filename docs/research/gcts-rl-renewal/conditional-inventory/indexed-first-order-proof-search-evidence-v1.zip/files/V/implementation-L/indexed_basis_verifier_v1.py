"""Independent catalogue/virtual-row binding and complete bounded backward DAG DFS.

Source-only module: no IO, project imports or executable fixtures. Logical basis
and zero-schema truth are supplied by separately Source-reviewed construction;
all whole chosen proofs still require actual native C1 and independent B checks.
"""
import json
import math
import time

VERSION = 'V-INDEPENDENT-INDEXED-BASIS-AUDIT-v1'
VERIFY_LIMITS = dict(wall_seconds=15, max_work=100000000,
                     max_depth=128, max_candidates=100000)
SEARCH_LIMITS = dict(wall_seconds=2, max_states=20000,
                     max_transitions=500000, max_work=20000000)
SCOPE = ('Finite Source-reviewed eight-rule basis/schema witnesses. Independent '
         'complete public representation, virtual row/ref/literal binding and '
         'bounded acyclic shared-fact DAG search. Not independent logical basis '
         'generation or a hostile-data firewall. Every whole proof needs actual '
         'native C1 plus independent B. No unrestricted FOL unprovability claim.')
ZERO_FIELDS = {
    'axiom': {'rule', 'formula', 'name'},
    'tautology': {'rule', 'formula'},
    'refl': {'rule', 'formula'},
    'instantiate': {'rule', 'formula', 'universal', 'term'},
    'distribute': {'rule', 'formula', 'variable', 'antecedent', 'consequent'},
    'eq_subst': {'rule', 'formula', 'variable', 'template', 'left', 'right'},
}


class InputError(ValueError):
    pass


class BudgetExceeded(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise InputError(message)


class _Meter:
    def __init__(self, limits, defaults):
        self.start = time.perf_counter()
        limits = dict(defaults) if limits is None else limits
        _fields(limits, set(defaults))
        wall = limits['wall_seconds']
        _need(type(wall) in (int, float) and 0 < wall <= 60
              and math.isfinite(wall), 'wall limit')
        _need(all(type(v) is int and 0 <= v <= 1000000000000
                  for k, v in limits.items() if k != 'wall_seconds'),
              'integer limits')
        self.limits = dict(limits)
        self.work = 0

    def tick(self, n=1):
        if n > self.limits['max_work'] - self.work:
            raise BudgetExceeded('WORK')
        self.work += n
        if time.perf_counter() - self.start > self.limits['wall_seconds']:
            raise BudgetExceeded('WALL')

    def costs(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.start,
                'scope': 'Own input copy, validation, indexing, search and proof/detached-return construction included. Caller JSON serialization tail excluded. Cooperative, not an OS quota.'}


def _fields(x, keys):
    _need(type(x) is dict and len(x) == len(keys)
          and all(type(k) is str for k in x) and set(x) == set(keys),
          'record fields')


def _copy(x, m, depth=0):
    m.tick()
    if depth > m.limits.get('max_depth', 128):
        raise BudgetExceeded('DEPTH')
    if x is None or type(x) in (bool, int):
        return x
    if type(x) is float:
        _need(math.isfinite(x), 'nonfinite JSON')
        return x
    if type(x) is str:
        m.tick(len(x))
        return x
    if type(x) is list:
        m.tick(len(x))
        return [_copy(y, m, depth + 1) for y in x]
    _need(type(x) is dict, 'native JSON')
    m.tick(len(x))
    _need(all(type(k) is str for k in x), 'native JSON keys')
    return {k: _copy(v, m, depth + 1) for k, v in x.items()}


def _key(x, m):
    text = json.dumps(x, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)
    m.tick(len(text))
    return text


def _same(a, b, m):
    pending = [(a, b)]
    while pending:
        m.tick()
        x, y = pending.pop()
        if type(x) is not type(y):
            return False
        if type(x) is dict:
            if len(x) != len(y) or set(x) != set(y):
                return False
            m.tick(len(x))
            pending.extend((v, y[k]) for k, v in x.items())
        elif type(x) is list:
            if len(x) != len(y):
                return False
            m.tick(len(x))
            pending.extend(zip(x, y))
        else:
            if type(x) is str:
                m.tick(len(x) + len(y))
            if x != y:
                return False
    return True


def _name(s):
    return (type(s) is str and 1 <= len(s) <= 64
            and all(32 <= ord(c) <= 126 for c in s))


def _slots(slots):
    _need(type(slots) is int and 1 <= slots <= 64, 'slots')


def _prepare(problem, compiled, m):
    _fields(problem, {'theory', 'goal', 'profile'})
    _fields(compiled, {'schema', 'version', 'theory', 'goal', 'goal_id',
                      'profile', 'logical_basis', 'zero_instances',
                      'mp_index', 'gen_index', 'costs', 'scope'})
    _need(type(compiled['schema']) is str
          and compiled['schema'] == 'V-interned-Hilbert8-basis-v1'
          and type(compiled['version']) is str
          and compiled['version'] == 'V-INTERNED-FINITE-HILBERT8-v1',
          'compiled identity')
    # Detach before deriving any cached index. These values never alias producers.
    p = _copy(problem, m)
    c = _copy(compiled, m)
    for key in ('theory', 'goal', 'profile'):
        _need(_same(p[key], c[key], m), 'input binding')
    _fields(p['theory'], {'functions', 'predicates', 'axioms'})
    for key in ('functions', 'predicates'):
        _need(type(p['theory'][key]) is dict, 'signature')
        for name, arity in p['theory'][key].items():
            m.tick()
            _need(_name(name) and type(arity) is int and arity >= 0,
                  'signature name/arity')
    _need(type(p['theory']['axioms']) is dict
          and all(_name(k) for k in p['theory']['axioms']), 'axiom names')
    _fields(p['profile'], {'ui_rounds', 'bridge_arity', 'max_tautology_atoms'})
    for key, cap in [('ui_rounds', 8), ('bridge_arity', 2),
                     ('max_tautology_atoms', 16)]:
        _need(type(p['profile'][key]) is int and 0 <= p['profile'][key] <= cap,
              'profile')
    b = c['logical_basis']
    _fields(b, {'instantiation_terms', 'terms', 'variables', 'formulas',
                'colors', 'templates', 'hole', 'stages'})
    for key in ('instantiation_terms', 'terms', 'formulas', 'templates'):
        _need(type(b[key]) is list, 'basis list')
        m.tick(len(b[key]))
        images = [_key(x, m) for x in b[key]]
        _need(images == sorted(set(images)), 'canonical basis order/uniqueness')
    forms = b['formulas']
    if len(forms) > m.limits.get('max_candidates', 100000):
        raise BudgetExceeded('FORMULAS')
    colors = [_key(f, m) for f in forms]
    _need(_same(b['colors'], colors, m), 'complete canonical colors')
    m.tick(len(colors))
    index = {color: i for i, color in enumerate(colors)}
    goal_key = _key(p['goal'], m)
    _need(goal_key in index and type(c['goal_id']) is int
          and c['goal_id'] == index[goal_key], 'goal ID')
    _need(type(b['variables']) is list
          and all(_name(v) for v in b['variables'])
          and b['variables'] == sorted(set(b['variables'])), 'variables')
    fresh = 0
    while '__u_hole' + str(fresh) in b['variables']:
        m.tick()
        fresh += 1
    _need(type(b['hole']) is str and b['hole'] == '__u_hole' + str(fresh),
          'fresh catalogue hole')
    zero = c['zero_instances']
    _need(type(zero) is list, 'zero catalogue')
    if len(zero) > m.limits.get('max_candidates', 100000):
        raise BudgetExceeded('INSTANCES')
    zero_by_id = {}
    previous = None
    for number, record in enumerate(zero):
        m.tick()
        _fields(record, {'id', 'rule', 'formula_id', 'line'})
        _need(type(record['id']) is str and record['id'] == 'i' + str(number)
              and type(record['rule']) is str and record['rule'] in ZERO_FIELDS,
              'zero identity')
        line = record['line']
        _fields(line, ZERO_FIELDS[record['rule']])
        _need(type(line['rule']) is str and line['rule'] == record['rule'],
              'zero rule')
        image = _key(line, m)
        _need(previous is None or previous < image, 'canonical zero order')
        previous = image
        conclusion = _key(line['formula'], m)
        _need(conclusion in index and type(record['formula_id']) is int
              and record['formula_id'] == index[conclusion], 'zero formula ID')
        if record['rule'] == 'axiom':
            _need(type(line['name']) is str
                  and line['name'] in p['theory']['axioms']
                  and _same(line['formula'], p['theory']['axioms'][line['name']], m),
                  'given exact supplied axiom')
        zero_by_id[record['id']] = record
    labels = ['input'] + ['UI' + str(i + 1)
              for i in range(p['profile']['ui_rounds'])] + [
                  'equality', 'distribution', 'tautology']
    _need(type(b['stages']) is list and len(b['stages']) == len(labels),
          'stage count')
    oldf = oldi = 0
    for row, label in zip(b['stages'], labels):
        m.tick()
        _fields(row, {'stage', 'formula_count', 'instance_count'})
        _need(type(row['stage']) is str and row['stage'] == label
              and type(row['formula_count']) is type(row['instance_count']) is int
              and oldf <= row['formula_count'] <= len(forms)
              and oldi <= row['instance_count'] <= len(zero), 'stage witnesses')
        oldf, oldi = row['formula_count'], row['instance_count']
    _need(oldf == len(forms) and oldi == len(zero), 'final stage census')
    mp = []
    gen = []
    for fi, formula in enumerate(forms):
        m.tick()
        _need(type(formula) is list and len(formula) > 0
              and type(formula[0]) is str, 'formula witness')
        if formula[0] == 'imp':
            _need(len(formula) == 3, 'imp shape')
            a, q = _key(formula[1], m), _key(formula[2], m)
            if a in index and q in index:
                mp.append([fi, index[a], index[q]])
        if formula[0] == 'all':
            _need(len(formula) == 3 and _name(formula[1]), 'all shape')
            body = _key(formula[2], m)
            if body in index:
                gen.append([fi, index[body], formula[1]])
    _need(_same(c['mp_index'], mp, m) and _same(c['gen_index'], gen, m),
          'complete producer indices')
    _fields(c['costs'], {'work', 'seconds', 'terms', 'formulas', 'instances',
                        'candidates', 'cache_hits', 'cache_misses',
                        'canonical_serializations', 'substitution_calls'})
    for key, value in c['costs'].items():
        _need((type(value) in (int, float) and math.isfinite(value) and value >= 0)
              if key == 'seconds' else (type(value) is int and value >= 0),
              'basis costs types')
    _need(c['costs']['formulas'] == len(forms)
          and c['costs']['instances'] == len(zero)
          and c['costs']['candidates'] == 0, 'basis cost census')
    m.tick(len(mp) + len(gen))
    return {'problem': p, 'compiled': c, 'forms': forms, 'colors': colors,
            'goal': c['goal_id'], 'zero': zero_by_id,
            'mp': {row[0]: row for row in mp},
            'gen': {row[0]: row for row in gen}}


def _receipt(status, reason, proof, details, m):
    return {'schema': 'V-independent-basis-audit-result-v1', 'version': VERSION,
            'status': status, 'reason': reason, 'proof': proof,
            'details': details, 'costs': m.costs(), 'scope': SCOPE}


def verify_compiled(problem, compiled, *, limits=None):
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        data = _prepare(problem, compiled, m)
        details = {'formulas': len(data['forms']), 'zero_instances': len(data['zero']),
                   'mp_producers': len(data['mp']), 'gen_producers': len(data['gen']),
                   'logical_generation': 'Source-reviewed, not independently rerun'}
        m.tick()
        return _receipt('VERIFIED', None, None, details, m)
    except InputError as error:
        return _receipt('REJECTED', str(error), None, None, m)
    except BudgetExceeded as error:
        return _receipt('UNKNOWN', str(error), None, None, m)


def _nat(text):
    _need(type(text) is str and len(text) > 0 and len(text) <= 20
          and text.isascii() and text.isdigit()
          and (len(text) == 1 or text[0] != '0'), 'canonical index')
    return int(text)


def _virtual(cid, slots, data, m):
    m.tick()
    _need(type(cid) is str and len(cid) <= 128, 'candidate ID')
    fields = cid.split(':')
    _need(len(fields) >= 2 and fields[0].startswith('r'), 'candidate ID shape')
    slot = _nat(fields[0][1:])
    _need(slot < slots, 'candidate row')
    marks = {}
    if len(fields) == 2:
        _need(fields[1] in data['zero'], 'zero witness ID')
        record = data['zero'][fields[1]]
        output = record['formula_id']
        line = record['line']
        instance = record['id']
        canonical = 'r' + str(slot) + ':' + instance
    elif len(fields) == 5 and fields[1] == 'mp':
        fi, a, b = (_nat(s) for s in fields[2:])
        _need(fi in data['mp'] and a < slot and b < slot, 'MP prior refs')
        _, antecedent, output = data['mp'][fi]
        for point, value in [(a, antecedent), (b, fi)]:
            _need(point not in marks or marks[point] == value,
                  'internal coincident receptor conflict')
            marks[point] = value
        line = {'rule': 'mp', 'formula': data['forms'][output],
                'antecedent': a, 'implication': b}
        instance = None
        canonical = 'r%d:mp:%d:%d:%d' % (slot, fi, a, b)
    elif len(fields) == 4 and fields[1] == 'gen':
        fi, source = (_nat(s) for s in fields[2:])
        _need(fi in data['gen'] and source < slot, 'GEN prior ref')
        _, body, variable = data['gen'][fi]
        output = fi
        marks[source] = body
        line = {'rule': 'generalize', 'formula': data['forms'][fi],
                'source': source, 'variable': variable}
        instance = None
        canonical = 'r%d:gen:%d:%d' % (slot, fi, source)
    else:
        raise InputError('candidate ID family')
    _need(cid == canonical, 'canonical candidate ID')
    marks[slot] = output
    _need(slot != slots - 1 or output == data['goal'], 'last target filter')
    binding = {'id': cid, 't': ['slot:' + str(slot)],
               'm': [['out:' + str(point), data['colors'][value]]
                     for point, value in sorted(marks.items(),
                         key=lambda pair: 'out:' + str(pair[0]))]}
    return slot, marks, line, instance, binding


def _selection(data, slots, selected, m):
    _slots(slots)
    _need(type(selected) is list and len(selected) == slots
          and all(type(cid) is str for cid in selected)
          and len(set(selected)) == slots, 'selected exact coverage shape')
    rows = {}
    assigned = {}
    bindings = []
    for cid in selected:
        slot, marks, line, instance, binding = _virtual(cid, slots, data, m)
        _need(slot not in rows, 'duplicate occupied row')
        rows[slot] = (line, instance)
        for point, value in marks.items():
            m.tick()
            _need(point not in assigned or assigned[point] == value,
                  'whole selected marking conflict')
            assigned[point] = value
        bindings.append(binding)
    _need(set(rows) == set(range(slots)), 'all row roots covered')
    proof = []
    for slot in range(slots):
        m.tick()
        line = rows[slot][0]
        if line['rule'] == 'mp':
            a, b = line['antecedent'], line['implication']
            implication = proof[b]['formula']
            _need(type(implication) is list and len(implication) == 3
                  and implication[0] == 'imp'
                  and _same(implication[1], proof[a]['formula'], m)
                  and _same(implication[2], line['formula'], m), 'actual MP')
        elif line['rule'] == 'generalize':
            _need(_same(line['formula'], ['all', line['variable'],
                       proof[line['source']]['formula']], m), 'actual GEN')
        proof.append(_copy(line, m))
    _need(_same(proof[-1]['formula'], data['problem']['goal'], m), 'final goal')
    return proof, sorted(bindings, key=lambda row: row['id'])


def verify_selection(problem, compiled, slots, selected, *, limits=None):
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        _slots(slots)
        data = _prepare(problem, compiled, m)
        proof, bindings = _selection(data, slots, selected, m)
        m.tick()
        return _receipt('VERIFIED', None, proof,
                        {'slots': slots, 'candidate_bindings': bindings}, m)
    except InputError as error:
        return _receipt('REJECTED', str(error), None, None, m)
    except BudgetExceeded as error:
        return _receipt('UNKNOWN', str(error), None, None, m)


def _producers(data, m):
    m.tick(len(data['forms']))
    result = [[] for _ in data['forms']]
    for iid, record in data['zero'].items():
        m.tick()
        result[record['formula_id']].append(('zero', iid, ()))
    for fi, antecedent, consequent in data['compiled']['mp_index']:
        m.tick()
        result[consequent].append(('mp', fi, (antecedent, fi)))
    for fi, body, variable in data['compiled']['gen_index']:
        m.tick()
        result[fi].append(('gen', fi, (body,)))
    # Deterministic complete preference only; no producer is removed.
    for rows in result:
        m.tick(len(rows))
        rows.sort(key=lambda row: (len(row[2]), str(row[0]), str(row[1])))
    return result


def _acyclic(chosen, m):
    done = set()
    active = set()
    def visit(fact):
        m.tick()
        if fact in active:
            return False
        if fact in done or fact not in chosen:
            return True
        active.add(fact)
        for premise in chosen[fact][2]:
            if not visit(premise):
                return False
        active.remove(fact)
        done.add(fact)
        return True
    return all(visit(fact) for fact in chosen)


def _proof_from_dag(data, chosen, slots, m):
    proof = []
    indices = {}
    def emit(fact):
        m.tick()
        if fact in indices:
            return indices[fact]
        kind, identity, premises = chosen[fact]
        refs = [emit(p) for p in premises]
        if kind == 'zero':
            line = _copy(data['zero'][identity]['line'], m)
        elif kind == 'mp':
            line = {'rule': 'mp', 'formula': _copy(data['forms'][fact], m),
                    'antecedent': refs[0], 'implication': refs[1]}
        else:
            line = {'rule': 'generalize', 'formula': _copy(data['forms'][fact], m),
                    'source': refs[0], 'variable': data['gen'][identity][2]}
        indices[fact] = len(proof)
        proof.append(line)
        return indices[fact]
    emit(data['goal'])
    _need(1 <= len(proof) <= slots and len(proof) == len(chosen),
          'complete reachable DAG size')
    # At-most bound to exact-row certificate: repeat first zero, shift refs.
    padding = slots - len(proof)
    _need(proof[0]['rule'] in ZERO_FIELDS, 'DAG begins with zero witness')
    padded = [_copy(proof[0], m) for _ in range(padding)]
    for original in proof:
        line = _copy(original, m)
        if line['rule'] == 'mp':
            line['antecedent'] += padding
            line['implication'] += padding
        if line['rule'] == 'generalize':
            line['source'] += padding
        padded.append(line)
    return proof, padded


def backward_dag(problem, compiled, slots, limits=None):
    m = _Meter(limits, SEARCH_LIMITS)
    states = transitions = 0
    try:
        _slots(slots)
        data = _prepare(problem, compiled, m)
        producers = _producers(data, m)
        goal = data['goal']
        # Depth is at most slots<=64; each recursive frame owns one branch.
        # Producers are tried lazily, so pending siblings cannot grow the heap.
        def visit(chosen, pending):
            nonlocal states, transitions
            m.tick()
            if states >= m.limits['max_states']:
                raise BudgetExceeded('STATES')
            states += 1
            if not pending:
                return chosen
            fact, rest = pending[0], pending[1:]
            if fact in chosen:
                return visit(chosen, rest)
            if len(chosen) >= slots:
                return None
            for producer in producers[fact]:
                m.tick()
                if transitions >= m.limits['max_transitions']:
                    raise BudgetExceeded('TRANSITIONS')
                transitions += 1
                m.tick(len(chosen) + len(rest) + len(producer[2]) + 1)
                branch = dict(chosen)
                branch[fact] = producer
                if not _acyclic(branch, m):
                    continue
                missing = []
                seen = set(branch)
                for prerequisite in producer[2] + rest:
                    m.tick()
                    if prerequisite not in seen:
                        seen.add(prerequisite)
                        missing.append(prerequisite)
                if len(branch) + len(missing) > slots:
                    continue
                found = visit(branch, tuple(missing))
                if found is not None:
                    return found
            return None
        found = visit({}, (goal,))
        if found is not None:
            proof, padded = _proof_from_dag(data, found, slots, m)
            details = {'states': states, 'transitions': transitions,
                       'distinct_facts': len(found), 'slots': slots,
                       'padded_proof': padded, 'exhaustive': False,
                       'shortest': False}
            m.tick()
            return _receipt('DERIVABLE', None, proof, details, m)
        m.tick()
        return _receipt('NOT_DERIVABLE', 'FINITE_BASIS_LINE_BOUND', None,
                        {'states': states, 'transitions': transitions,
                         'slots': slots, 'exhaustive': True, 'shortest': False}, m)
    except InputError as error:
        return _receipt('REJECTED', str(error), None,
                        {'states': states, 'transitions': transitions}, m)
    except BudgetExceeded as error:
        return _receipt('UNKNOWN', str(error), None,
                        {'states': states, 'transitions': transitions,
                         'exhaustive': False}, m)
