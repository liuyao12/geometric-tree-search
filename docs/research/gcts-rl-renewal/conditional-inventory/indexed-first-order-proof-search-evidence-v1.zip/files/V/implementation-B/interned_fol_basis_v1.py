"""Losslessly interned U finite Hilbert-eight catalogue, without row expansion.

Only pure data compilation/decoding. No project imports, proof/search inputs,
IO, executable fixtures or module-level subject calls. Resource refusal never
exports a partial basis. Exact U catalogue equivalence is not FOL completeness.
"""
import json
import math
import time

VERSION = 'V-INTERNED-FINITE-HILBERT8-v1'
COMPAT_VERSION = 'U-FINITE-HILBERT8-BASIS-v1'
_SCOPE = ('Exact U finite basis/schema witnesses and strict earlier-reference slots; '
          'finite anchored unit-point adaptation, not unrestricted FOL/PA/Hilbert '
          'completeness, fixed universal Wang tiles, RL or a performance claim. '
          'Every chosen certificate needs actual native C1 and independent B.')


class InputError(ValueError):
    pass


class _Stop(Exception):
    pass


def _fields(value, names):
    if (type(value) is not dict or len(value) != len(names) or
            any(type(k) is not str for k in value) or set(value) != set(names)):
        raise InputError('FIELDS')


def _limits(value, basis=True):
    caps = {'max_work': 1000000000, 'max_depth': 128}
    if basis:
        caps.update(max_basis=100000, max_instances=100000,
                    max_interned=1000000, max_cache_entries=1000000)
    else:
        caps['max_candidates'] = 1000000
    _fields(value, tuple(caps) + ('wall_seconds',))
    wall = value['wall_seconds']
    if type(wall) not in (int, float) or not 0 < wall <= 60 or not math.isfinite(wall):
        raise InputError('WALL')
    for key, maximum in caps.items():
        if type(value[key]) is not int or not 0 <= value[key] <= maximum:
            raise InputError('LIMIT_INTEGER')
    return dict(value)


class _Meter:
    def __init__(self, limits, started):
        self.limits, self.started = limits, started
        self.work = 0
        self.terms = self.formulas = self.instances = self.candidates = 0
        self.cache_hits = self.cache_misses = 0
        self.canonical_serializations = self.substitution_calls = 0

    def tick(self, units=1, depth=0):
        if depth > self.limits['max_depth']:
            raise _Stop('DEPTH_LIMIT')
        if units > self.limits['max_work'] - self.work:
            raise _Stop('WORK_LIMIT')
        self.work += units
        if time.perf_counter() - self.started >= self.limits['wall_seconds']:
            raise _Stop('WALL_LIMIT')

    def costs(self):
        return {k: getattr(self, k) for k in ('work', 'terms', 'formulas', 'instances',
                'candidates', 'cache_hits', 'cache_misses', 'canonical_serializations',
                'substitution_calls')} | {'seconds': time.perf_counter() - self.started}


def _name(value, meter):
    meter.tick()
    if type(value) is not str or not 1 <= len(value) <= 64:
        raise InputError('NAME')
    meter.tick(len(value))
    if any(ord(c) < 32 or ord(c) > 126 for c in value):
        raise InputError('NAME_ASCII')
    return value


def _signature(value, meter):
    if type(value) is not dict:
        raise InputError('SIGNATURE')
    result = {}
    for key, arity in value.items():
        _name(key, meter)
        if type(arity) is not int or arity < 0:
            raise InputError('ARITY')
        result[key] = arity
    meter.tick(len(result) * max(1, len(result).bit_length()))
    return {key: result[key] for key in sorted(result)}


def _copy(value, meter, depth=0):
    meter.tick(1, depth)
    if type(value) is str:
        meter.tick(2 + 12 * len(value), depth)
        return value
    if value is None or type(value) in (bool, int, float):
        return value
    if type(value) in (tuple, list):
        meter.tick(len(value), depth)
        return [_copy(x, meter, depth + 1) for x in value]
    if type(value) is dict:
        meter.tick(len(value), depth)
        return {k: _copy(v, meter, depth + 1) for k, v in value.items()}
    raise InputError('NON_JSON')


class _Pool:
    """Structural hash-consing plus bounded, immutable auxiliary memo values."""
    def __init__(self, meter):
        self.m = meter
        self.nodes, self.colors, self.depths, self.intern, self.memo = [], [], [], {}, {}

    def quote(self, text):
        self.m.tick(2 + 12 * len(text))
        return json.dumps(text, ensure_ascii=True, separators=(',', ':'))

    def node(self, row):
        self.m.tick()
        if row in self.intern:
            self.m.cache_hits += 1
            return self.intern[row]
        self.m.cache_misses += 1
        if len(self.nodes) >= self.m.limits['max_interned']:
            raise _Stop('INTERNED_LIMIT')
        tag = row[0]
        if tag in ('var', 'bot'): children = ()
        elif tag in ('fun', 'pred'): children = row[2]
        elif tag == 'all': children = (row[2],)
        else: children = row[1:]
        height = 1 + max((self.depths[i] for i in children), default=0)
        self.m.tick(len(children) + 1, height)
        if tag in ('var', 'all'):
            pieces = [self.quote(tag), self.quote(row[1])]
            if tag == 'all': pieces.append(self.colors[row[2]])
        elif tag in ('fun', 'pred'):
            args = row[2]
            self.m.tick(sum(len(self.colors[i]) + 1 for i in args))
            pieces = [self.quote(tag), self.quote(row[1]),
                      '[' + ','.join(self.colors[i] for i in args) + ']']
        elif tag == 'bot':
            pieces = [self.quote(tag)]
        else:
            pieces = [self.quote(tag)] + [self.colors[i] for i in row[1:]]
        self.m.tick(2 + sum(len(p) + 1 for p in pieces))
        color = '[' + ','.join(pieces) + ']'
        index = len(self.nodes)
        self.nodes.append(row); self.colors.append(color); self.depths.append(height); self.intern[row] = index
        self.m.canonical_serializations += 1
        return index

    def cached(self, key, compute):
        self.m.tick()
        if key in self.memo:
            self.m.cache_hits += 1
            return self.memo[key]
        self.m.cache_misses += 1
        if len(self.memo) >= self.m.limits['max_cache_entries']:
            raise _Stop('CACHE_LIMIT')
        result = compute()
        if len(self.memo) >= self.m.limits['max_cache_entries']:
            raise _Stop('CACHE_LIMIT')
        self.memo[key] = result
        return result

    def ordered(self, ids):
        self.m.tick(len(ids) * max(1, len(ids).bit_length()))
        return sorted(ids, key=self.colors.__getitem__)

    def children(self, index):
        row = self.nodes[index]
        if row[0] == 'all': return (row[2],)
        if row[0] == 'not': return (row[1],)
        if row[0] in ('and', 'or', 'imp'): return row[1:]
        return ()

    def native(self, index):
        def make():
            row = self.nodes[index]; tag = row[0]
            if tag in ('var', 'bot'): return row
            if tag in ('fun', 'pred'):
                return (tag, row[1], tuple(self.native(i) for i in row[2]))
            if tag == 'all': return (tag, row[1], self.native(row[2]))
            return (tag,) + tuple(self.native(i) for i in row[1:])
        return self.cached(('native', index), make)

    def names(self, index, bound=False):
        def make():
            row = self.nodes[index]; tag = row[0]
            if tag == 'var': return frozenset((row[1],))
            if tag == 'bot': return frozenset()
            if tag in ('fun', 'pred'):
                ids = row[2]
            elif tag == 'all':
                names = self.names(row[2], bound)
                return names | {row[1]} if bound else names - {row[1]}
            else:
                ids = row[1:]
            names = set()
            for i in ids: names.update(self.names(i, bound))
            return frozenset(names)
        return self.cached(('names', index, bound), make)

    def terms(self, index):
        def make():
            row = self.nodes[index]; tag = row[0]
            result = {index} if tag in ('var', 'fun') else set()
            if tag in ('fun', 'pred'): children = row[2]
            elif tag == 'all': children = (row[2],)
            elif tag in ('var', 'bot'): children = ()
            else: children = row[1:]
            for child in children: result.update(self.terms(child))
            self.m.tick(len(result))
            return frozenset(result)
        return self.cached(('terms', index), make)

    def subst(self, index, variable, replacement):
        self.m.substitution_calls += 1
        def make():
            row = self.nodes[index]; tag = row[0]
            if tag == 'var': return replacement if row[1] == variable else index
            if tag == 'bot': return index
            if tag in ('fun', 'pred'):
                return self.node((tag, row[1], tuple(self.subst(i, variable, replacement) for i in row[2])))
            if tag == 'all':
                name, body = row[1], row[2]
                if name == variable or variable not in self.names(body): return index
                free_replacement = self.names(replacement)
                if name in free_replacement:
                    occupied = self.names(body, True) | free_replacement | {variable, name}
                    number = 0; fresh = 'fresh0'
                    while fresh in occupied:
                        self.m.tick(); number += 1; fresh = 'fresh' + str(number)
                    body = self.subst(body, name, self.node(('var', fresh)))
                    name = fresh
                return self.node(('all', name, self.subst(body, variable, replacement)))
            return self.node((tag,) + tuple(self.subst(i, variable, replacement) for i in row[1:]))
        return self.cached(('subst', index, variable, replacement), make)

    def contexts(self, index, hole):
        def make():
            row = self.nodes[index]; tag = row[0]; result = set()
            if tag in ('var', 'fun'):
                result.add(hole)
                if tag == 'fun':
                    for j, child in enumerate(row[2]):
                        for changed in self.contexts(child, hole):
                            args = list(row[2]); self.m.tick(len(args)); args[j] = changed
                            result.add(self.node(('fun', row[1], tuple(args))))
            elif tag == 'pred':
                for j, child in enumerate(row[2]):
                    for changed in self.contexts(child, hole):
                        args = list(row[2]); self.m.tick(len(args)); args[j] = changed
                        result.add(self.node(('pred', row[1], tuple(args))))
            elif tag == 'all':
                for changed in self.contexts(row[2], hole):
                    result.add(self.node(('all', row[1], changed)))
            elif tag != 'bot':
                for j, child in enumerate(row[1:], 1):
                    for changed in self.contexts(child, hole):
                        args = list(row); self.m.tick(len(args)); args[j] = changed
                        result.add(self.node(tuple(args)))
            self.m.tick(len(result))
            return tuple(self.ordered(result))
        return self.cached(('contexts', index, hole), make)

    def atoms(self, index):
        def make():
            row = self.nodes[index]; tag = row[0]
            if tag == 'bot': return frozenset()
            if tag not in ('not', 'and', 'or', 'imp'): return frozenset((index,))
            result = set()
            for child in row[1:]: result.update(self.atoms(child))
            self.m.tick(len(result))
            return frozenset(result)
        return self.cached(('atoms', index), make)

    def pattern(self, count, position):
        def make():
            assignments = 1 << count; run = 1 << position
            self.m.tick(assignments)
            block = (1 << run) - 1; result = 0
            for start in range(run, assignments, run * 2):
                self.m.tick(max(1, (assignments + 63) // 64))
                result |= block << start
            return result
        return self.cached(('pattern', count, position), make)

    def truth_bits(self, index, atoms):
        def make():
            row = self.nodes[index]; tag = row[0]; assignments = 1 << len(atoms)
            self.m.tick(max(1, (assignments + 63) // 64))
            full = (1 << assignments) - 1
            if tag == 'bot': return 0
            if tag == 'not': return self.truth_bits(row[1], atoms) ^ full
            if tag in ('and', 'or', 'imp'):
                left, right = self.truth_bits(row[1], atoms), self.truth_bits(row[2], atoms)
                if tag == 'and': return left & right
                if tag == 'or': return left | right
                return (left ^ full) | right
            self.m.tick(len(atoms))
            return self.pattern(len(atoms), atoms.index(index))
        return self.cached(('truth_bits', index, atoms), make)

    def tautology(self, index, maximum):
        def make():
            atoms = self.atoms(index)
            if len(atoms) > maximum: return False
            atoms = tuple(self.ordered(atoms))
            self.m.tick(max(1, ((1 << len(atoms)) + 63) // 64))
            return self.truth_bits(index, atoms) == (1 << (1 << len(atoms))) - 1
        return self.cached(('tautology', index, maximum), make)

    def line_color(self, line):
        parts = []
        ast_fields = {'formula', 'universal', 'term', 'template', 'left', 'right'}
        for key in sorted(line):
            value = self.colors[line[key]] if key in ast_fields else self.quote(line[key])
            self.m.tick(len(value)); parts.append(self.quote(key) + ':' + value)
        self.m.tick(sum(len(x) + 1 for x in parts) + 2)
        return '{' + ','.join(parts) + '}'

    def line_native(self, line):
        ast_fields = {'formula', 'universal', 'term', 'template', 'left', 'right'}
        return {k: self.native(v) if k in ast_fields else v for k, v in line.items()}


def _term(value, functions, pool, depth=1):
    pool.m.tick(1, depth)
    if type(value) is not list or not value or type(value[0]) is not str:
        raise InputError('TERM')
    if value[0] == 'var' and len(value) == 2:
        return pool.node(('var', _name(value[1], pool.m)))
    if value[0] != 'fun' or len(value) != 3:
        raise InputError('TERM_SHAPE')
    name = _name(value[1], pool.m)
    if type(value[2]) is not list or name not in functions or len(value[2]) != functions[name]:
        raise InputError('FUNCTION_ARITY')
    pool.m.tick(len(value[2]), depth)
    return pool.node(('fun', name, tuple(_term(x, functions, pool, depth + 1) for x in value[2])))


def _formula(value, functions, predicates, pool, depth=1):
    pool.m.tick(1, depth)
    if type(value) is not list or not value or type(value[0]) is not str:
        raise InputError('FORMULA')
    tag = value[0]
    if tag == 'bot' and len(value) == 1: return pool.node(('bot',))
    if tag == 'eq' and len(value) == 3:
        return pool.node(('eq', _term(value[1], functions, pool, depth + 1),
                          _term(value[2], functions, pool, depth + 1)))
    if tag == 'pred' and len(value) == 3:
        name = _name(value[1], pool.m)
        if type(value[2]) is not list or name not in predicates or len(value[2]) != predicates[name]:
            raise InputError('PREDICATE_ARITY')
        pool.m.tick(len(value[2]), depth)
        return pool.node(('pred', name, tuple(_term(x, functions, pool, depth + 1) for x in value[2])))
    if tag == 'all' and len(value) == 3:
        return pool.node(('all', _name(value[1], pool.m),
                          _formula(value[2], functions, predicates, pool, depth + 1)))
    if tag == 'not' and len(value) == 2:
        return pool.node(('not', _formula(value[1], functions, predicates, pool, depth + 1)))
    if tag in ('and', 'or', 'imp') and len(value) == 3:
        return pool.node((tag, _formula(value[1], functions, predicates, pool, depth + 1),
                          _formula(value[2], functions, predicates, pool, depth + 1)))
    raise InputError('FORMULA_SHAPE')


def _add_formula(index, formulas, pool):
    pending = [index]
    while pending:
        pool.m.tick(); current = pending.pop()
        if current in formulas: continue
        if len(formulas) >= pool.m.limits['max_basis']: raise _Stop('BASIS_LIMIT')
        formulas.add(current); pool.m.formulas = len(formulas)
        pending.extend(pool.children(current))


def _zero(line, records, formulas, pool):
    key = pool.line_color(line)
    if key in records: return
    if len(records) >= pool.m.limits['max_instances']: raise _Stop('INSTANCE_LIMIT')
    _add_formula(line['formula'], formulas, pool)
    records[key] = line; pool.m.instances = len(records)


def _inputs(theory, goal, profile, pool):
    _fields(profile, ('ui_rounds', 'bridge_arity', 'max_tautology_atoms'))
    for key, maximum in (('ui_rounds', 8), ('bridge_arity', 2), ('max_tautology_atoms', 16)):
        if type(profile[key]) is not int or not 0 <= profile[key] <= maximum: raise InputError('PROFILE')
    _fields(theory, ('functions', 'predicates', 'axioms'))
    functions, predicates = _signature(theory['functions'], pool.m), _signature(theory['predicates'], pool.m)
    if type(theory['axioms']) is not dict: raise InputError('AXIOMS')
    axioms = {}
    for name, value in theory['axioms'].items():
        _name(name, pool.m); index = _formula(value, functions, predicates, pool)
        if pool.names(index): raise InputError('OPEN_THEORY_AXIOM')
        axioms[name] = index
    goal = _formula(goal, functions, predicates, pool)
    pool.m.tick(len(axioms) * max(1, len(axioms).bit_length()))
    return {'functions': functions, 'predicates': predicates,
            'axioms': {k: axioms[k] for k in sorted(axioms)}}, goal, dict(profile)


def _catalogue(theory, goal, profile, pool):
    formulas, goals, zero = set(), set(), {}
    _add_formula(goal, goals, pool); pool.m.formulas = 0
    for index in tuple(theory['axioms'].values()) + (goal,): _add_formula(index, formulas, pool)
    terms0, variables = set(), set()
    for index in pool.ordered(formulas):
        terms0.update(pool.terms(index)); variables.update(pool.names(index, True))
    for name in sorted(variables): terms0.add(pool.node(('var', name)))
    instantiation_terms = pool.ordered(terms0); pool.m.terms = len(terms0)
    for name, index in theory['axioms'].items(): _zero({'rule': 'axiom', 'formula': index, 'name': name}, zero, formulas, pool)
    stages = [{'stage': 'input', 'formula_count': len(formulas), 'instance_count': len(zero)}]
    for round_index in range(profile['ui_rounds']):
        snapshot = pool.ordered(formulas)
        for universal in snapshot:
            row = pool.nodes[universal]; pool.m.tick()
            if row[0] != 'all': continue
            for term in instantiation_terms:
                instance = pool.subst(row[2], row[1], term)
                out = pool.node(('imp', universal, instance))
                _zero({'rule': 'instantiate', 'formula': out, 'universal': universal, 'term': term}, zero, formulas, pool)
        stages.append({'stage': 'UI' + str(round_index + 1), 'formula_count': len(formulas), 'instance_count': len(zero)})
    pre = pool.ordered(formulas); terms, variables = set(terms0), set()
    for index in pre:
        terms.update(pool.terms(index)); variables.update(pool.names(index, True))
    terms = pool.ordered(terms); pool.m.terms = len(terms)
    number = 0; hole = '__u_hole0'
    while hole in variables:
        pool.m.tick(); number += 1; hole = '__u_hole' + str(number)
    hole_id = pool.node(('var', hole)); templates = set()
    for index in pre: templates.update(pool.contexts(index, hole_id))
    for left in terms:
        for right in terms: _add_formula(pool.node(('eq', left, right)), formulas, pool)
        _zero({'rule': 'refl', 'formula': pool.node(('eq', left, left))}, zero, formulas, pool)
    atom_extended = frozenset(formulas)
    equalities = [index for index in pre if pool.nodes[index][0] == 'eq']
    for template in pool.ordered(templates):
        for equality in equalities:
            left, right = pool.nodes[equality][1:]
            a, b = pool.subst(template, hole, left), pool.subst(template, hole, right)
            if a in atom_extended and b in atom_extended:
                out = pool.node(('imp', equality, pool.node(('imp', a, b))))
                _zero({'rule': 'eq_subst', 'formula': out, 'variable': hole,
                       'template': template, 'left': left, 'right': right}, zero, formulas, pool)
    stages.append({'stage': 'equality', 'formula_count': len(formulas), 'instance_count': len(zero)})
    snapshot = pool.ordered(formulas); snapshot_set = frozenset(formulas)
    for universal in snapshot:
        row = pool.nodes[universal]; pool.m.tick()
        if row[0] != 'all' or pool.nodes[row[2]][0] != 'imp': continue
        variable = row[1]; p, q = pool.nodes[row[2]][1:]; all_q = pool.node(('all', variable, q))
        if variable not in pool.names(p) and all_q in snapshot_set:
            out = pool.node(('imp', universal, pool.node(('imp', p, all_q))))
            _zero({'rule': 'distribute', 'formula': out, 'variable': variable,
                   'antecedent': p, 'consequent': q}, zero, formulas, pool)
    stages.append({'stage': 'distribution', 'formula_count': len(formulas), 'instance_count': len(zero)})
    a_set = pool.ordered(formulas)
    b_set = set(theory['axioms'].values()) | {pool.node(('eq', t, t)) for t in terms}
    ordered_b, ordered_goals = pool.ordered(b_set), pool.ordered(goals)
    for a in a_set:
        if pool.tautology(a, profile['max_tautology_atoms']): _zero({'rule': 'tautology', 'formula': a}, zero, formulas, pool)
        if profile['bridge_arity'] >= 1:
            for g in ordered_goals:
                bridge = pool.node(('imp', a, g))
                if pool.tautology(bridge, profile['max_tautology_atoms']): _zero({'rule': 'tautology', 'formula': bridge}, zero, formulas, pool)
                if profile['bridge_arity'] >= 2:
                    for b in ordered_b:
                        bridge2 = pool.node(('imp', a, pool.node(('imp', b, g))))
                        if pool.tautology(bridge2, profile['max_tautology_atoms']): _zero({'rule': 'tautology', 'formula': bridge2}, zero, formulas, pool)
    stages.append({'stage': 'tautology', 'formula_count': len(formulas), 'instance_count': len(zero)})
    ordered = pool.ordered(formulas); ids = {n: i for i, n in enumerate(ordered)}
    records = []
    pool.m.tick(len(zero) * max(1, len(zero).bit_length()))
    for i, key in enumerate(sorted(zero)):
        line = zero[key]
        records.append({'id': 'i' + str(i), 'rule': line['rule'],
                        'formula_id': ids[line['formula']], 'line': pool.line_native(line)})
    mp, gen = [], []
    for i, index in enumerate(ordered):
        row = pool.nodes[index]; pool.m.tick()
        if row[0] == 'imp' and row[1] in ids and row[2] in ids: mp.append([i, ids[row[1]], ids[row[2]]])
        if row[0] == 'all' and row[2] in ids: gen.append([i, ids[row[2]], row[1]])
    basis = {'instantiation_terms': [pool.native(i) for i in instantiation_terms],
             'terms': [pool.native(i) for i in terms], 'variables': sorted(variables),
             'formulas': [pool.native(i) for i in ordered], 'colors': [pool.colors[i] for i in ordered],
             'templates': [pool.native(i) for i in pool.ordered(templates)], 'hole': hole, 'stages': stages}
    return basis, records, mp, gen, ids[goal]


def build_basis(theory, goal, profile, limits):
    started = time.perf_counter(); limits = _limits(limits); meter = _Meter(limits, started)
    try:
        meter.tick(); pool = _Pool(meter)
        theory, goal, profile = _inputs(theory, goal, profile, pool)
        basis, records, mp, gen, goal_id = _catalogue(theory, goal, profile, pool)
        exported_theory = {'functions': theory['functions'], 'predicates': theory['predicates'],
                           'axioms': {k: pool.native(v) for k, v in theory['axioms'].items()}}
        compiled = _copy({'schema': 'V-interned-Hilbert8-basis-v1', 'version': VERSION,
                         'theory': exported_theory, 'goal': pool.native(goal), 'goal_id': goal_id,
                         'profile': profile, 'logical_basis': basis, 'zero_instances': records,
                         'mp_index': mp, 'gen_index': gen, 'costs': None, 'scope': _SCOPE}, meter)
        meter.tick(); costs = meter.costs(); compiled['costs'] = dict(costs)
        return {'schema': 'V-interned-Hilbert8-basis-result-v1', 'version': VERSION,
                'status': 'COMPLETE', 'reason': None, 'compiled': compiled, 'costs': costs}
    except _Stop as error:
        return {'schema': 'V-interned-Hilbert8-basis-result-v1', 'version': VERSION,
                'status': 'UNKNOWN', 'reason': str(error), 'compiled': None, 'costs': meter.costs()}


def _compiled(value):
    if (type(value) is not dict or value.get('schema') != 'V-interned-Hilbert8-basis-v1'
            or value.get('version') != VERSION): raise InputError('COMPILED')
    return value['logical_basis'], value['zero_instances']


def _row(compiled, slot, kind, first, second=None, third=None, indexes=None):
    """Trusted complete compiled catalogue to one exact U virtual candidate."""
    basis, zero = _compiled(compiled); forms, colors = basis['formulas'], basis['colors']
    if indexes is None:
        indexes = ({r[0]: r[1:] for r in compiled['mp_index']}, {r[0]: r[1:] for r in compiled['gen_index']})
    if kind == 'zero':
        if not 0 <= first < len(zero): raise InputError('INSTANCE')
        record = zero[first]; out = record['formula_id']; line = record['line']; instance = record['id']
        cid = 'r' + str(slot) + ':' + instance; uses = ()
    elif kind == 'mp':
        table = indexes[0]
        if first not in table or type(second) is not int or type(third) is not int or not 0 <= second < slot or not 0 <= third < slot:
            raise InputError('MP_REFERENCE')
        a, out = table[first]; instance = None
        line = {'rule': 'mp', 'formula': forms[out], 'antecedent': second, 'implication': third}
        cid = 'r' + str(slot) + ':mp:' + str(first) + ':' + str(second) + ':' + str(third)
        uses = ((second, a), (third, first))
    elif kind == 'gen':
        table = indexes[1]
        if first not in table or type(second) is not int or not 0 <= second < slot: raise InputError('GEN_REFERENCE')
        body, variable = table[first]; out = first; instance = None
        line = {'rule': 'generalize', 'formula': forms[out], 'source': second, 'variable': variable}
        cid = 'r' + str(slot) + ':gen:' + str(first) + ':' + str(second); uses = ((second, body),)
    else: raise InputError('ROW_KIND')
    marks = {'out:' + str(slot): colors[out]}
    for source, formula_id in uses:
        p, v = 'out:' + str(source), colors[formula_id]
        if p in marks and marks[p] != v: return None
        marks[p] = v
    candidate = {'id': cid, 't': ['slot:' + str(slot)], 'm': [[p, marks[p]] for p in sorted(marks)]}
    return candidate, {'slot': slot, 'line': line, 'instance': instance}, out


def materialize(compiled, slots, limits):
    started = time.perf_counter(); limits = _limits(limits, False); meter = _Meter(limits, started)
    if type(slots) is not int or not 1 <= slots <= 64: raise InputError('SLOTS')
    basis, zero = _compiled(compiled)
    meter.terms, meter.formulas, meter.instances = len(basis['terms']), len(basis['formulas']), len(zero)
    candidates, steps = [], {}
    try:
        meter.tick(len(compiled['mp_index']) + len(compiled['gen_index']))
        indexes = ({r[0]: r[1:] for r in compiled['mp_index']}, {r[0]: r[1:] for r in compiled['gen_index']})
        def add(row):
            meter.tick()
            if row is None: return
            candidate, step, out = row
            if step['slot'] == slots - 1 and out != compiled['goal_id']: return
            if len(candidates) >= limits['max_candidates']: raise _Stop('CANDIDATE_LIMIT')
            candidates.append(candidate); steps[candidate['id']] = step; meter.candidates = len(candidates)
        for slot in range(slots):
            for i in range(len(zero)): add(_row(compiled, slot, 'zero', i, indexes=indexes))
            for fi in range(len(basis['formulas'])):
                meter.tick()
                if fi in indexes[0]:
                    for antecedent in range(slot):
                        for implication in range(slot): add(_row(compiled, slot, 'mp', fi, antecedent, implication, indexes))
                if fi in indexes[1]:
                    for source in range(slot): add(_row(compiled, slot, 'gen', fi, source, indexes=indexes))
        old_basis = {k: v for k, v in basis.items() if k != 'colors'}
        old_zero = [{k: v for k, v in row.items() if k != 'formula_id'} for row in zero]
        bundle = _copy({'schema': 'U-finite-Hilbert8-point-model-v1', 'version': COMPAT_VERSION,
                        'theory': compiled['theory'], 'goal': compiled['goal'], 'slots': slots,
                        'profile': compiled['profile'], 'basis': old_basis, 'instances': old_zero,
                        'model': {'required': ['slot:' + str(i) for i in range(slots)], 'candidates': candidates},
                        'steps': steps, 'costs': None, 'scope': _SCOPE}, meter)
        meter.tick(); costs = meter.costs(); bundle['costs'] = {k: costs[k] for k in ('work', 'seconds', 'terms', 'formulas', 'instances', 'candidates')}
        return {'schema': 'V-Hilbert8-explicit-row-result-v1', 'version': VERSION,
                'status': 'COMPLETE', 'reason': None, 'bundle': bundle, 'costs': costs}
    except _Stop as error:
        return {'schema': 'V-Hilbert8-explicit-row-result-v1', 'version': VERSION,
                'status': 'UNKNOWN', 'reason': str(error), 'bundle': None, 'costs': meter.costs()}


def decode(compiled, slots, selected):
    _compiled(compiled)
    if type(slots) is not int or not 1 <= slots <= 64: raise InputError('SLOTS')
    if type(selected) is not list or len(selected) != slots or any(type(s) is not str for s in selected) or len(set(selected)) != slots:
        raise InputError('SELECTED')
    rows = {}
    indexes = ({r[0]: r[1:] for r in compiled['mp_index']}, {r[0]: r[1:] for r in compiled['gen_index']})
    for cid in selected:
        fields = cid.split(':')
        try:
            if len(fields) < 2 or not fields[0].startswith('r'): raise InputError('ID')
            slot = int(fields[0][1:])
            if not 0 <= slot < slots or slot in rows: raise InputError('ROW')
            if len(fields) == 2 and fields[1].startswith('i'):
                row = _row(compiled, slot, 'zero', int(fields[1][1:]), indexes=indexes)
            elif len(fields) == 5 and fields[1] == 'mp':
                row = _row(compiled, slot, 'mp', int(fields[2]), int(fields[3]), int(fields[4]), indexes)
            elif len(fields) == 4 and fields[1] == 'gen':
                row = _row(compiled, slot, 'gen', int(fields[2]), int(fields[3]), indexes=indexes)
            else: raise InputError('ID')
        except ValueError as error:
            raise InputError('ID') from error
        if row is None or row[0]['id'] != cid: raise InputError('NONCANONICAL_OR_CONFLICTING_ID')
        if slot == slots - 1 and row[2] != compiled['goal_id']: raise InputError('FINAL_GOAL')
        rows[slot] = row[1]['line']
    proof = json.loads(json.dumps([rows[i] for i in range(slots)], ensure_ascii=True, allow_nan=False))
    target = json.loads(json.dumps(compiled['goal'], ensure_ascii=True, allow_nan=False))
    return {'status': 'UNVERIFIED_CERTIFICATE', 'proof': proof, 'target': target}
