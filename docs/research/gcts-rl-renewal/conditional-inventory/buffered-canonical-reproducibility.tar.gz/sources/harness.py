"""Finite comparator-only qualification, Source authored without evaluation.

Future worker supplies two AST-pinned extracted verifier modules, the exact
interned Reader, pinned ordinary inputs and a real deadline/Source checkpoint.
No full cold, driver, Model, inverse, search, Native or opaque data is loaded.
"""
import hashlib
import json

VERSION = 'buffered-canonical-comparator-qualification-v2'
RESULT_BYTES = 131072
MAX_COMPARATOR_CALLS = 256
FIXTURE_NAMES = (
    'canonical_scalars_and_empty_containers',
    'typed_zero_and_missing',
    'Unicode_key_order_and_UTF8_split',
    'tuple_reader_array_projection',
    'long_part_and_buffer_edges',
    'many_small_parts_checkpoint_census',
    'mismatch_first_middle_last',
    'short_truncated_and_extra_data',
    'single_optional_helper_LF',
    'noncanonical_raw_forms',
    'invalid_UTF8_or_surrogate_data',
    'nonfinite_unsupported_and_legal_subclasses',
    'initial_callback_identity_three_classes',
    'part_boundary_callback_identity_three_classes',
    'final_callback_identity_three_classes',
    'mismatch_flushed_before_boundary_callback',
    'EOF_flush_before_final_callback',
    'pending_mismatch_vs_later_encoder_error',
    'input_and_callable_custody',
    'whole_retained_preimage_equivalence',
)


class QualificationFailure(AssertionError):
    pass


class _IntSubclass(int):
    pass


class _ListSubclass(list):
    pass


class _DictSubclass(dict):
    pass


def _need(ok, message):
    if not ok:
        raise QualificationFailure(message)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf8')


def qualify(original, candidate, *, checkpoint, reader, inputs, read_input):
    """Attach bounded unfinished prefix, then preserve every escaping error."""
    progress = dict(rows=[], active_fixture=None, stage='initial_checkpoint',
                    comparator_calls=0, completed_inputs=[], root_checkpoint_calls=0)
    try:
        return _qualify(original, candidate, checkpoint, reader, inputs, read_input, progress)
    except BaseException as error:
        try:
            prefix = dict(schema='buffered-canonical-qualification-prefix-v1',
                status='FAILED_OR_UNFINISHED', authority=False, mathematical_authority=False,
                full_pipeline_qualified=False, completed_diagnostics=progress['rows'],
                active_fixture=progress['active_fixture'], stage=progress['stage'],
                comparator_calls=progress['comparator_calls'], completed_inputs=progress['completed_inputs'],
                root_checkpoint_calls=progress['root_checkpoint_calls'])
            raw = _canonical(prefix)
            _need(len(raw) <= RESULT_BYTES, 'bounded complete qualification prefix')
            error.qualification_prefix = json.loads(raw)
        except BaseException as metadata_error:
            try:
                error.qualification_prefix = dict(schema='buffered-canonical-qualification-prefix-unavailable-v1',
                    status='UNAVAILABLE', authority=False, mathematical_authority=False,
                    full_pipeline_qualified=False, complete_prefix_retained=False,
                    metadata_error_type=type(metadata_error).__name__[:128])
            except BaseException:
                pass
        raise


def _qualify(original, candidate, checkpoint, reader, inputs, read_input, progress):
    real_fault = [None]

    def root_check():
        try:
            checkpoint()
            # Count only successful returns from the supplied Root callback.
            progress['root_checkpoint_calls'] += 1
        except BaseException as error:
            real_fault[0] = error
            raise

    def rethrow_real_fault():
        if real_fault[0] is not None:
            raise real_fault[0]

    def invoke(module, data, raw, *, fault_at=None, sentinel=None):
        root_check()
        progress['comparator_calls'] += 1
        _need(progress['comparator_calls'] <= MAX_COMPARATOR_CALLS, 'finite comparator call cap')
        calls = 0
        reached = False

        def counted():
            nonlocal calls, reached
            root_check()  # real deadline/Source errors always precede fixture faults
            calls += 1
            if fault_at is not None and calls == fault_at:
                reached = True
                raise sentinel

        result = None
        observed = None
        try:
            result = module.verify_literal_result(data, raw, counted)
        except BaseException as error:
            rethrow_real_fault()  # cannot call a real Root refusal an expected negative
            observed = error
        rethrow_real_fault()      # also check a normally returned call
        root_check()
        return dict(result=result, error=observed, calls=calls, reached=reached)

    def good(data, raw=None, exact_parts=None):
        root_check()
        if raw is None:
            raw = _canonical(data) + b'\n'
        root_check()
        results = []
        for module in (original, candidate):
            output = invoke(module, data, raw)
            rethrow_real_fault()
            if output['error'] is not None:
                raise output['error']
            result = output['result']
            _need(type(result) is dict and result['literal_bytes_equal'] is True,
                  'full comparator result required')
            _need(type(result['chunks']) is int and result['chunks'] > 0 and
                  output['calls'] == 2 + result['chunks'] // 65536,
                  'initial + every periodic + final callback (including collision)')
            if exact_parts is not None:
                _need(result['chunks'] == exact_parts, 'planned exact part boundary actually reached')
            results.append(dict(result=result, callback_calls=output['calls']))
        _need(_canonical(results[0]) == _canonical(results[1]), 'complete return and callback census exact')
        return results[0]

    def bad(data, raw, allowed=(ValueError, TypeError, UnicodeError), *, planned_at=None):
        names = []
        for module in (original, candidate):
            sentinel = RuntimeError('planned after generated mismatch') if planned_at is not None else None
            output = invoke(module, data, raw, fault_at=planned_at, sentinel=sentinel)
            rethrow_real_fault()
            error = output['error']
            _need(error is not None and output['result'] is None, 'no mismatched/malformed success')
            if planned_at is not None:
                _need(output['reached'] is False and error is not sentinel,
                      'all prior bytes compared before external checkpoint')
            if not isinstance(error, allowed):
                raise error
            names.append(type(error).__name__)
        return names

    def fault_identity(data, raw, ordinal):
        reached = []
        for module in (original, candidate):
            for cls in (RuntimeError, ValueError, StopIteration):
                sentinel = cls('planned comparator checkpoint fault')
                output = invoke(module, data, raw, fault_at=ordinal, sentinel=sentinel)
                rethrow_real_fault()
                _need(output['reached'] is True and output['calls'] == ordinal and
                      output['error'] is sentinel and output['result'] is None,
                      'reached exact foreign error identity, never normal exhaustion')
                reached.append(module.__name__ + ':' + cls.__name__)
        return reached

    def run(name, action):
        _need(name == FIXTURE_NAMES[len(progress['rows'])], 'declared finite order')
        progress['active_fixture'] = name
        progress['stage'] = 'before_checkpoint'
        root_check()
        progress['stage'] = 'action'
        details = action()
        rethrow_real_fault()
        progress['stage'] = 'after_checkpoint'
        root_check()
        progress['rows'].append(dict(name=name, status='passed', mathematical_authority=False,
                details=details, root_checkpoint_calls_after=progress['root_checkpoint_calls'],
                comparator_calls_after=progress['comparator_calls']))
        progress['active_fixture'] = None

    progress['stage'] = 'initial_checkpoint'
    root_check()
    _need([row['id'] for row in inputs] == ['fixed', 'symbolic'], 'all two whole inputs in fixed order')
    boundary_data = [0] * 65535
    double_boundary_data = [0] * 131071
    boundary_raw = _canonical(boundary_data) + b'\n'
    double_boundary_raw = _canonical(double_boundary_data) + b'\n'
    root_check()
    reached_boundaries = {}

    def scalars():
        data = [None, True, False, 0, -3, 2.5, '', 'plain', [], {}]
        return good(data)

    def typed():
        data = {'values': [False, 0, 0.0, -0.0, None], 'present_null': None}
        good(data)
        _need(_canonical(False) != _canonical(0) != _canonical(0.0) != _canonical(-0.0),
              'exact type/float lexemes distinct')
        _need(_canonical({'x': None}) != _canonical({}), 'missing is distinct')
        return dict(typed_values=5, absent_key_preserved=True)

    def unicode_case():
        data = {'z': '\\"\n\t', 'λ': 'λ' * 40000, 'a': '😀'}
        result = good(data)
        return dict(full_result=result, encoded_string_exceeds_buffer=True,
                    UTF8_split_is_byte_preserving=True)

    def tuples():
        data = {'rows': ((0, 1), [False, None, ('x',)])}
        return good(data)

    def edges():
        results = []
        for size in (65535, 65536, 65537, 131073):
            results.append(good('x' * size)['result']['body_bytes'])
        return dict(source_string_lengths=[65535, 65536, 65537, 131073], body_bytes=results)

    def census():
        observed = []
        for parts in (65535, 65536, 65537, 131071, 131072, 131073):
            if parts == 65536:
                data, raw = boundary_data, boundary_raw
            elif parts == 131072:
                data, raw = double_boundary_data, double_boundary_raw
            else:
                data = [0] * (parts - 1)
                raw = _canonical(data) + b'\n'
            result = good(data, raw, exact_parts=parts)
            _need(result['callback_calls'] == 2 + parts // 65536,
                  'last periodic and final calls counted separately')
            observed.append(dict(expected_parts=parts, actual_parts=result['result']['chunks'],
                                 callback_calls=result['callback_calls']))
            if parts in (65536, 131072):
                reached_boundaries[parts] = result['callback_calls']
        _need([r['callback_calls'] for r in observed] == [2, 3, 3, 3, 4, 4],
              'just-below/exact/just-above actual callback census')
        return dict(actual_census=observed,
                    final_periodic_collision_not_deduplicated=True)

    def mismatch():
        data = {'payload': 'x' * 140000}
        raw = _canonical(data) + b'\n'
        outcomes = []
        for pos in (0, len(raw) // 2, len(raw) - 2):
            wrong = raw[:pos] + bytes([raw[pos] ^ 1]) + raw[pos + 1:]
            outcomes.append(bad(data, wrong))
        return dict(mismatch_positions=[0, len(raw) // 2, len(raw) - 2], rejections=outcomes)

    def lengths():
        data = [1, 2, 3]
        body = _canonical(data)
        return dict(rejections=[bad(data, body[:-1]), bad(data, body + b'x'),
                                bad(data, body + b'\nextra')])

    def LF():
        data = {'x': 1}
        body = _canonical(data)
        good(data, body)
        good(data, body + b'\n')
        return dict(noLF_and_singleLF_same_parent_API=True, doubleLF=bad(data, body + b'\n\n'),
                    production_externalLF_gate_tested=False)

    def noncanonical():
        return dict(rejections=[bad({'a': 1, 'b': 2}, b'{"b":2,"a":1}\n'),
            bad({'a': 1}, b'{ "a": 1 }\n'), bad(1, b'1.0\n'),
            bad({'a': 1}, b'{"a":1,"a":1}\n')])

    def invalid_strings():
        return dict(raw_invalid_UTF8=bad('x', b'"\xff"\n'),
                    lone_surrogate=bad('\ud800', b'"irrelevant"\n'))

    def unsupported():
        legal = good(_DictSubclass({'n': _IntSubclass(2), 'xs': _ListSubclass([1, 2])}))
        return dict(legal_encoder_subclasses_accepted=legal,
                    unsupported=bad(object(), b'null\n'),
                    nonfinite=bad(float('inf'), b'null\n'), blanket_subclass_rejection=False)

    def initial_fault():
        return dict(reached=fault_identity([1], b'[1]\n', 1))

    def periodic_fault():
        _need(set(reached_boundaries) == {65536, 131072}, 'both exact boundaries qualified first')
        # At a divisible last part, this is the last PERIODIC call, not final.
        return dict(boundary65536=fault_identity(boundary_data, boundary_raw, 2),
                    boundary131072=fault_identity(double_boundary_data, double_boundary_raw, 3))

    def final_fault():
        return dict(boundary65536=fault_identity(boundary_data, boundary_raw, 3),
                    boundary131072=fault_identity(double_boundary_data, double_boundary_raw, 4))

    def mismatch_before_callback():
        raw = b'X' + boundary_raw[1:]
        return dict(rejections=bad(boundary_data, raw, planned_at=2),
                    planned_checkpoint=2, planned_foreign_sentinel_reached=False)

    def EOF_before_callback():
        data = {'small': 'tail'}
        raw = _canonical(data) + b'\n'
        wrong = raw[:-2] + b'X\n'
        good(data, raw)
        return dict(rejections=bad(data, wrong, planned_at=2),
                    final_callback_reached_on_equal_counterpart=True)

    def precedence():
        data = [0, object()]
        return dict(error_types=bad(data, b'Xnotcanonical\n'),
                    only_rejection_required=True, all_negative_error_precedence_equal=False)

    def custody():
        data = {'array': [0, False, -0.0], 'tuple': (1, 2)}
        before = _canonical(data)
        raw = before + b'\n'
        good(data, raw)
        _need(_canonical(data) == before and raw == before + b'\n', 'input preimages unchanged')
        return dict(ordinary_input_unchanged=True, callable_custody_is_worker_gate=True,
                    no_code_default_or_module_mutations=True)

    def whole_inputs():
        results = []
        for entry in inputs:
            root_check()
            raw = read_input(entry['result'])
            root_check()
            _need(type(raw) is bytes and hashlib.sha256(raw).hexdigest() == entry['result']['sha256']
                  and len(raw) == entry['result']['bytes'], 'whole exact retained ordinary input')
            data, sharing = reader.decode_result(raw, checkpoint=root_check)
            root_check()
            result = good(data, raw)
            results.append(dict(id=entry['id'], input=entry['result'], result=result,
                                reader_version=sharing['version'], representation_only=True))
            progress['completed_inputs'].append(entry['id'])
            # Sequential lifetime only. No whole old result or decoded graph is
            # retained in output, used as proof input, or passed to a project.
            del data, raw, sharing
            root_check()
        _need(progress['completed_inputs'] == ['fixed', 'symbolic'], 'both whole inputs completed')
        return dict(complete_inputs=results, sequential=True, proof_replays=0)

    actions = (scalars, typed, unicode_case, tuples, edges, census, mismatch,
        lengths, LF, noncanonical, invalid_strings, unsupported, initial_fault,
        periodic_fault, final_fault, mismatch_before_callback, EOF_before_callback,
        precedence, custody, whole_inputs)
    _need(len(actions) == len(FIXTURE_NAMES) == 20, 'complete declared action census')
    for name, action in zip(FIXTURE_NAMES, actions):
        run(name, action)
    progress['stage'] = 'final_checkpoint'
    root_check()
    result = dict(schema='buffered-canonical-comparator-qualification-v1',
        status='FINITE_COMPARATOR_QUALIFICATION_CANDIDATE', authority=False,
        mathematical_authority=False, resource_authority=False, full_pipeline_qualified=False,
        diagnostics=progress['rows'], comparator_calls=progress['comparator_calls'],
        root_checkpoint_calls_at_result_snapshot=progress['root_checkpoint_calls'],
        root_checkpoint_count_scope='Successful supplied callback returns only; row counters follow its after_checkpoint, result snapshot precedes result_final_checkpoint.',
        completed_inputs=list(progress['completed_inputs']), expected_fixture_names=list(FIXTURE_NAMES),
        real_checkpoint_faults_never_expected_negatives=True,
        negative_error_precedence_equivalent=False,
        no_claim='Finite representation/callback checks only, no full cold/proof/Model/Native/inverse/search call or performance/fit claim.')
    _need(len(_canonical(result)) <= RESULT_BYTES, 'complete bounded comparator qualification output')
    progress['stage'] = 'result_final_checkpoint'
    root_check()
    return result
