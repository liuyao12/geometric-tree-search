"""Prospective extracted-comparator worker. Source only until an exact Root grant.

Never imports either whole cold module. Only the two frozen AST-sliced verifier
Sources, the qualification harness and the pinned lossless Reader are loaded.
"""
import time
NOW = time.monotonic_ns
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'buffered-canonical-extracted-qualification-worker-v2'
LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728,
    stdout_bytes=4194304, stderr_bytes=4194304)
PLAN_SCHEMA = 'ROOT-buffered-canonical-qualification-once-plan-v2'
PLAN_FIELDS = frozenset(('schema', 'invocation_id', 'actual_directory', 'python',
    'worker', 'harness', 'original', 'candidate', 'reader', 'runner', 'observer',
    'inputs', 'limits', 'cold_sources', 'extraction_manifest', 'runtime_closure',
    'declaration', 'authorization'))
EXTRACT_HEADER = '"""Frozen comparator slice; not the complete cold module."""\nimport json\nimport hashlib\n\n'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf8')


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin) is dict and set(pin) == {'path', 'bytes', 'sha256'} and
         type(pin['bytes']) is int and 0 <= pin['bytes'] <= cap, 'strict bounded raw descriptor')
    path = Path(pin['path'])
    need(path.is_absolute() and path == path.resolve() and path.is_file() and not path.is_symlink(),
         'exact owned regular raw Source/input')
    raw = path.read_bytes()
    need(len(raw) <= cap and descriptor(path, raw) == pin, 'whole raw size/hash/EOF')
    return raw


def save_new(path, value, cap):
    raw = canonical(value) + b'\n'
    need(len(raw) <= cap, 'bounded complete ordinary qualification output')
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return descriptor(path, raw)


def expected_extraction(raw):
    text = raw.decode('utf8')
    lines = text.splitlines(True)
    tree = ast.parse(text)
    selected = []
    fingerprints = {}
    for name, kind in (('ColdError', ast.ClassDef), ('need', ast.FunctionDef),
                       ('verify_literal_result', ast.FunctionDef)):
        hits = [n for n in tree.body if isinstance(n, kind) and n.name == name]
        need(len(hits) == 1, 'one exact original/candidate Source definition: ' + name)
        node = hits[0]
        selected.append(''.join(lines[node.lineno - 1:node.end_lineno]).rstrip() + '\n')
        fingerprints[name] = hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
    return (EXTRACT_HEADER + '\n'.join(selected)).encode('utf8'), fingerprints


def load(pin, name):
    checked(pin)
    spec = importlib.util.spec_from_file_location(name, pin['path'])
    need(spec is not None and spec.loader is not None, 'explicit Source loader')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    need(Path(module.__file__).resolve() == Path(pin['path']).resolve(), 'exact loaded origin')
    return module


def callable_snapshot(modules):
    bindings = []
    codes = []
    seen_classes = set()
    def function(value):
        if isinstance(value, types.FunctionType):
            codes.append((value, value.__code__, value.__globals__, value.__defaults__, value.__kwdefaults__))
    def klass(module, cls):
        if cls in seen_classes:
            return
        seen_classes.add(cls)
        for name, value in list(vars(cls).items()):
            if isinstance(value, (staticmethod, classmethod)):
                bindings.append((cls, name, value)); function(value.__func__)
            elif isinstance(value, types.FunctionType):
                bindings.append((cls, name, value)); function(value)
            elif isinstance(value, property):
                bindings.append((cls, name, value))
                for member in (value.fget, value.fset, value.fdel):
                    function(member)
            elif isinstance(value, type) and value.__module__ == module.__name__:
                bindings.append((cls, name, value)); klass(module, value)
    for module in modules:
        for name, value in list(vars(module).items()):
            if isinstance(value, (types.FunctionType, types.ModuleType, type)):
                bindings.append((module, name, value))
            function(value)
            if isinstance(value, type) and value.__module__ == module.__name__:
                klass(module, value)
    # The unchanged canonical encoder and full-body hash are also exact bindings.
    bindings.extend([(json, 'JSONEncoder', json.JSONEncoder), (hashlib, 'sha256', hashlib.sha256)])
    for name in ('iterencode', 'encode'):
        value = getattr(json.JSONEncoder, name)
        bindings.append((json.JSONEncoder, name, value))
        codes.append((value, value.__code__, value.__globals__, value.__defaults__, value.__kwdefaults__))
    def guard():
        for owner, name, value in bindings:
            need(vars(owner).get(name) is value, 'comparator/encoder/reader binding unchanged')
        for value, code, namespace, defaults, kwdefaults in codes:
            need(value.__code__ is code and value.__globals__ is namespace and
                 value.__defaults__ is defaults and value.__kwdefaults__ is kwdefaults,
                 'extracted helper code/globals/default identities unchanged')
    return guard


def main(plan_path):
    need(sys.platform == 'darwin' and sys.flags.isolated and sys.flags.no_site and
         sys.dont_write_bytecode, 'reviewed isolated Darwin -I -S -B worker')
    plan_path = Path(plan_path).resolve()
    plan_raw = plan_path.read_bytes()
    need(len(plan_raw) <= 16777216, 'finite once plan')
    plan = json.loads(plan_raw)
    need(type(plan) is dict and set(plan) == PLAN_FIELDS and plan['schema'] == PLAN_SCHEMA,
         'exact comparator-only plan')
    need(plan['limits'] == LIMITS and Path(sys.executable).resolve() == Path(plan['python']['path']),
         'same180/210/1GiB/128MiB/log gates and exact Python')
    need(descriptor(__file__, Path(__file__).read_bytes()) == plan['worker'], 'current worker Source')
    actual = Path(plan['actual_directory'])
    need(actual == actual.resolve() == Path.cwd(), 'exact owned actual directory')
    marker = json.loads((actual / 'CONSUMED.json').read_bytes())
    need(marker['schema'] == 'buffered-canonical-qualification-consumed-v1' and
         marker['invocation_id'] == plan['invocation_id'] and
         marker['plan'] == descriptor(plan_path, plan_raw) and marker['maximum_worker_launches'] == 1 and
         marker['consumed_before_Popen'] is True, 'reviewed max-one outer consumption')
    began, work, overall = marker['began_ns'], marker['work_deadline_ns'], marker['overall_deadline_ns']
    need(work == began + 180000000000 and overall == began + 210000000000,
         'unchanged original Source-entry absolute endpoints')
    guard = None
    phase = 'intake'
    qualification = None
    helper_qualification_calls = 0
    prefix_fault_checks = []
    active_prefix_control = None
    retained_prefixes_detached = False
    def checkpoint():
        need(NOW() < work, 'positive complete qualification work/metadata inside original180')
        if guard is not None:
            guard()
    def read_input(pin):
        checkpoint()
        raw = checked(pin, LIMITS['result_bytes'])
        checkpoint()
        return raw
    try:
        checkpoint()
        source_roles = ('python', 'worker', 'harness', 'original', 'candidate', 'reader', 'runner', 'observer')
        for role in source_roles:
            checked(plan[role], 67108864 if role == 'python' else 16777216); checkpoint()
        declaration = json.loads(checked(plan['declaration']))
        closure = json.loads(checked(plan['runtime_closure']))
        manifest = json.loads(checked(plan['extraction_manifest']))
        need(declaration['schema'] == 'buffered-canonical-comparator-qualification-declaration-v2' and
             declaration['full_pipeline_qualified'] is False and declaration['limits'] == LIMITS,
             'finite comparator-only declaration, not production fit')
        need(closure['schema'] == 'buffered-canonical-qualification-runtime-closure-v1' and
             closure['status'] == 'COMPLETE_REVIEWED_PROSPECTIVE' and
             closure['python'] == plan['python'] and
             closure['executed_sources'] == {role: plan[role] for role in source_roles if role != 'python'} and
             closure['cold_sources'] == plan['cold_sources'] and closure['inputs'] == plan['inputs'],
             'complete exact executed closure, no pending outer pins')
        for entry in closure['stdlib_entry_references'].values():
            if 'pin' in entry:
                checked(entry['pin']); checkpoint()
            for pin in entry.get('pins', []):
                checked(pin); checkpoint()
        need([v['id'] for v in plan['inputs']] == ['fixed', 'symbolic'] and
             declaration['inputs'] == plan['inputs'] and
             sum(v['result']['bytes'] for v in plan['inputs']) <= LIMITS['result_bytes'],
             'both complete ordinary inputs sequentially, aggregate bounded128MiB')
        phase = 'reconcile_extracted_Source'
        for role in ('original', 'candidate'):
            expected, ast_pins = expected_extraction(checked(plan['cold_sources'][role]))
            need(checked(plan[role]) == expected and manifest['comparators'][role]['extracted'] == plan[role] and
                 manifest['comparators'][role]['origin'] == plan['cold_sources'][role] and
                 manifest['comparators'][role]['definition_AST_sha256'] == ast_pins,
                 'whole frozen extracted bytes and every original AST definition')
            checkpoint()
        denied = []
        def audit(event, args):
            if event in ('subprocess.Popen', 'os.fork', 'os.posix_spawn', 'os.system',
                         'socket.connect', 'socket.bind', 'ctypes.dlopen'):
                denied.append(event)
                raise RuntimeError('process/network/dlopen forbidden in comparator-only worker')
        # No whole cold is imported, so the old ctypes startup dependency is not
        # invoked here. Current runtime closure must bind actual direct imports.
        sys.addaudithook(audit)
        phase = 'load_only_reviewed_slices_harness_reader'
        original = load(plan['original'], '_buffered_qualification_original')
        candidate = load(plan['candidate'], '_buffered_qualification_candidate')
        reader = load(plan['reader'], '_buffered_qualification_reader')
        harness = load(plan['harness'], '_buffered_qualification_harness')
        guard = callable_snapshot((original, candidate, reader, harness))
        checkpoint()
        need(list(harness.FIXTURE_NAMES) == declaration['expected_fixture_names'] and
             len(set(harness.FIXTURE_NAMES)) == len(harness.FIXTURE_NAMES) == 20 and
             harness.MAX_COMPARATOR_CALLS == declaration['maximum_comparator_calls'] == 256 and
             harness.RESULT_BYTES == declaration['helper_result_bytes'] == 131072 and
             declaration['maximum_helper_qualification_calls'] == 3 and
             declaration['expected_prefix_control_names'] ==
                 ['original_expected_mismatch', 'candidate_expected_mismatch'],
             'all twenty exact declared fixture groups')
        phase = 'qualify'
        normal_root_checkpoint_calls = [0]
        def normal_checkpoint():
            checkpoint()
            normal_root_checkpoint_calls[0] += 1
        helper_qualification_calls += 1
        qualification = harness.qualify(original, candidate, checkpoint=normal_checkpoint, reader=reader,
                                         inputs=plan['inputs'], read_input=read_input)
        checkpoint()
        need(qualification['schema'] == 'buffered-canonical-comparator-qualification-v1' and
             qualification['status'] == 'FINITE_COMPARATOR_QUALIFICATION_CANDIDATE' and
             qualification['authority'] is False and qualification['full_pipeline_qualified'] is False and
             [row['name'] for row in qualification['diagnostics']] == declaration['expected_fixture_names'] and
             all(row['status'] == 'passed' and row['mathematical_authority'] is False
                 for row in qualification['diagnostics']) and
             qualification['completed_inputs'] == ['fixed', 'symbolic'] and not denied,
             'complete finite comparator-only returned packet')
        # These extra calls stop during group7 before the full-input group.
        # K comes from this fresh normal call's completed group6; it is never a
        # precomputed acceptance number or a second full-preimage qualification.
        phase = 'qualify_real_fault_propagation_controls'
        rows = qualification['diagnostics']
        K = rows[5]['root_checkpoint_calls_after']
        B = rows[5]['comparator_calls_after']
        need(type(K) is int and K > 0 and type(B) is int and B > 0,
             'fresh normal group6 successful callback/comparator census')
        need(type(normal_root_checkpoint_calls[0]) is int and
             normal_root_checkpoint_calls[0] == qualification['root_checkpoint_calls_at_result_snapshot'] + 1,
             'normal snapshot precedes exactly one final successful supplied callback')
        frozen_prefixes = []
        for name, offset, comparator_offset in (
                ('original_expected_mismatch', 3, 1),
                ('candidate_expected_mismatch', 6, 2)):
            checkpoint()
            active_prefix_control = dict(name=name, status='STARTED', reached_checkpoint=None,
                                         prefix=None, mathematical_authority=False)
            supplied_calls = [0]
            actual_root_fault = [None]
            reached = [False]
            control_input_reads = [0]
            target = K + offset
            planned = ValueError('planned supplied checkpoint inside ' + name)
            def control_checkpoint():
                try:
                    checkpoint()  # real clock/Source guard always runs first
                except BaseException as root_error:
                    actual_root_fault[0] = root_error
                    raise
                supplied_calls[0] += 1
                if supplied_calls[0] == target:
                    reached[0] = True
                    raise planned
            def no_input_reread(pin):
                control_input_reads[0] += 1
                raise RuntimeError('prefix control must not reach whole-input loading')
            observed = None
            helper_qualification_calls += 1
            need(helper_qualification_calls <= declaration['maximum_helper_qualification_calls'],
                 'finite three qualification calls, no retry')
            try:
                harness.qualify(original, candidate, checkpoint=control_checkpoint, reader=reader,
                                inputs=plan['inputs'], read_input=no_input_reread)
            except BaseException as error:
                if actual_root_fault[0] is not None:
                    raise actual_root_fault[0]  # never classify a real Root fault as the control
                observed = error
                raw_prefix = getattr(error, 'qualification_prefix', None)
                if type(raw_prefix) is dict:
                    need(len(canonical(raw_prefix)) <= 131072, 'bounded actual interruption prefix')
                    active_prefix_control['prefix'] = json.loads(canonical(raw_prefix))
            if actual_root_fault[0] is not None:
                raise actual_root_fault[0]
            checkpoint()  # exact current code/Source/deadline before interpreting expected refusal
            need(observed is planned and reached[0] is True and supplied_calls[0] == target,
                 'actual reached exact planned exception object, never normal return')
            prefix = active_prefix_control['prefix']
            need(type(prefix) is dict and
                 prefix['schema'] == 'buffered-canonical-qualification-prefix-v1' and
                 prefix['status'] == 'FAILED_OR_UNFINISHED' and prefix['authority'] is False and
                 prefix['mathematical_authority'] is False and prefix['full_pipeline_qualified'] is False and
                 [r['name'] for r in prefix['completed_diagnostics']] == declaration['expected_fixture_names'][:6] and
                 all(r['status'] == 'passed' and r['mathematical_authority'] is False
                     for r in prefix['completed_diagnostics']) and
                 prefix['active_fixture'] == 'mismatch_first_middle_last' and prefix['stage'] == 'action' and
                 prefix['completed_inputs'] == [] and prefix['root_checkpoint_calls'] == target - 1 and
                 prefix['comparator_calls'] == B + comparator_offset and control_input_reads[0] == 0,
                 'six completed groups, genuine group7 action refusal, no full-input reread')
            # Root callback during group7 is the original initial checkpoint at
            # K+3, or candidate initial at K+6 after the original own mismatch.
            # Counted failing callback does not count as a successful harness return.
            active_prefix_control.update(status='passed', reached_checkpoint=target)
            record = dict(name=name, status='passed', mathematical_authority=False,
                exact_exception_identity=True, reached_checkpoint=target,
                actual_root_fault_observed=False, helper_callable_bindings_unchanged=True,
                no_full_input_reread=True, prefix=prefix)
            frozen_prefixes.append(canonical(prefix))
            prefix_fault_checks.append(record)
            active_prefix_control = None
            checkpoint()
        need(helper_qualification_calls == 3 and
             [r['name'] for r in prefix_fault_checks] == declaration['expected_prefix_control_names'],
             'exact normal plus two reached interruption calls')
        need(all(canonical(row['prefix']) == saved for row, saved in zip(prefix_fault_checks, frozen_prefixes)) and
             prefix_fault_checks[0]['prefix'] is not prefix_fault_checks[1]['prefix'],
             'both complete saved prefixes remain detached after subsequent calls')
        retained_prefixes_detached = True
        comparator_calls_total = qualification['comparator_calls'] + sum(
            row['prefix']['comparator_calls'] for row in prefix_fault_checks)
        need(type(comparator_calls_total) is int and 0 < comparator_calls_total <= 3 * 256,
             'all comparator calls across exactly three helper calls retained and bounded')
        for role in source_roles:
            checked(plan[role], 67108864 if role == 'python' else 16777216); checkpoint()
        phase = 'serialize_result'
        result = save_new(actual / 'result.json', dict(
            schema='buffered-canonical-qualification-result-v1', version=VERSION,
            invocation_id=plan['invocation_id'], plan=descriptor(plan_path, plan_raw),
            extraction_manifest=plan['extraction_manifest'], runtime_closure=plan['runtime_closure'],
            qualification=qualification, helper_qualification_calls=helper_qualification_calls,
            prefix_fault_checks=prefix_fault_checks, retained_prefixes_detached=retained_prefixes_detached,
            comparator_calls_total=comparator_calls_total, normal_root_checkpoint_calls=normal_root_checkpoint_calls[0],
            full_pipeline_qualified=False,
            mathematical_proof_accepted=False, scientific_acceptance=False,
            Native_calls=0, Model_calls=0, inverse_calls=0, search_calls=0,
            opaque_program_decodes=0, denied_events=denied), LIMITS['result_bytes'])
        checkpoint()
        save_new(actual / 'worker-receipt.json', dict(
            schema='buffered-canonical-qualification-worker-receipt-v1',
            invocation_id=plan['invocation_id'], plan=descriptor(plan_path, plan_raw),
            began_ns=began, work_deadline_ns=work, overall_deadline_ns=overall,
            positive_worker_completed_ns=NOW(), result=result,
            logical_result_bytes=result['bytes'], outer_metadata_reservation=9437184,
            comparator_qualification_candidate=True, full_pipeline_qualified=False,
            scientific_acceptance=False, mathematical_proof_accepted=False), 4194304)
        checkpoint()
    except BaseException as error:
        binding = dict(attempted=guard is not None, passed=None, error_type=None)
        if guard is not None:
            try:
                guard(); binding['passed'] = True
            except BaseException as metadata_error:
                binding.update(passed=False, error_type=type(metadata_error).__name__)
        try:
            prefix = getattr(error, 'qualification_prefix', None)
            if prefix is not None:
                need(type(prefix) is dict and len(canonical(prefix)) <= 131072, 'bounded unfinished prefix')
            save_new(actual / 'worker-failure.json', dict(
                schema='buffered-canonical-qualification-failure-v1',
                status='FAILED_OR_UNFINISHED', authority=False, phase=phase,
                error_type=type(error).__name__, message=str(error)[:4096],
                qualification_prefix=prefix, returned_nonadmitted_packet=qualification,
                helper_qualification_calls=helper_qualification_calls, prefix_fault_checks=prefix_fault_checks,
                active_prefix_control=active_prefix_control, retained_prefixes_detached=retained_prefixes_detached,
                callable_binding_check=binding, scientific_acceptance=False,
                full_pipeline_qualified=False, mathematical_proof_accepted=False), 1048576)
        except BaseException as metadata_error:
            try:
                if not (actual / 'worker-failure.json').exists():
                    save_new(actual / 'worker-failure.json', dict(
                        schema='buffered-canonical-qualification-failure-v1', status='FAILED_OR_UNFINISHED',
                        diagnostics='UNAVAILABLE', authority=False, error_type=type(error).__name__,
                        metadata_error_type=type(metadata_error).__name__[:128],
                        scientific_acceptance=False, full_pipeline_qualified=False), 1048576)
            except BaseException:
                pass
        raise
    return 0


if __name__ == '__main__':
    need(len(sys.argv) == 2, 'one reviewed future once-plan path')
    raise SystemExit(main(sys.argv[1]))
