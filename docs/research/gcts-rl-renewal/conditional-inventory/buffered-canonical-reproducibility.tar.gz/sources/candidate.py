"""Frozen comparator slice; not the complete cold module."""
import json
import hashlib

class ColdError(ValueError):
    pass

def need(ok, message):
    if not ok:
        raise ColdError(message)

def verify_literal_result(data, raw, checkpoint):
    """Full canonical inverse; bounded comparison buffer, original part schedule.

    chunks still counts JSONEncoder parts, not byte blocks. Every generated
    byte is compared, with pending bytes flushed before each old checkpoint.
    Callback exceptions are direct and uncaught (including StopIteration).
    Own mismatch detection is block-late; precedence against a later encoder
    failure on malformed direct-helper data may differ from the old loop.
    """
    checkpoint()
    body = raw[:-1] if raw.endswith(b'\n') else raw
    encoder = json.JSONEncoder(sort_keys=True, separators=(',', ':'),
                               ensure_ascii=False, allow_nan=False)
    offset = 0; chunks = 0
    pending = bytearray(); block_bytes = 65536

    def flush():
        nonlocal offset
        if pending:
            need(raw[offset:offset+len(pending)] == pending, 'whole canonical literal byte comparison')
            offset += len(pending)
            pending.clear()

    for text in encoder.iterencode(data):
        value = text.encode('utf8')
        if len(value) <= block_bytes-len(pending):
            pending.extend(value)
            if len(pending) == block_bytes:
                flush()
        else:
            at = 0
            while at < len(value):
                take = min(block_bytes-len(pending), len(value)-at)
                pending.extend(value[at:at+take]); at += take
                if len(pending) == block_bytes:
                    flush()
        chunks += 1
        if chunks % 65536 == 0:
            flush()
            checkpoint()
    flush()
    need(offset == len(body), 'whole canonical writer EOF')
    checkpoint()
    return dict(literal_bytes_equal=True, body_bytes=offset,
                body_sha256=hashlib.sha256(body).hexdigest(), chunks=chunks)
