"""Frozen comparator slice; not the complete cold module."""
import json
import hashlib

class ColdError(ValueError):
    pass

def need(ok, message):
    if not ok:
        raise ColdError(message)

def verify_literal_result(data, raw, checkpoint):
    """Full streaming canonical inverse on the pinned writer domain."""
    checkpoint()
    body = raw[:-1] if raw.endswith(b'\n') else raw
    encoder = json.JSONEncoder(sort_keys=True, separators=(',', ':'),
                               ensure_ascii=False, allow_nan=False)
    offset = 0; chunks = 0
    for text in encoder.iterencode(data):
        value = text.encode('utf8')
        need(raw[offset:offset+len(value)] == value, 'whole canonical literal byte comparison')
        offset += len(value); chunks += 1
        if chunks % 65536 == 0:
            checkpoint()
    need(offset == len(body), 'whole canonical writer EOF')
    checkpoint()
    return dict(literal_bytes_equal=True, body_bytes=offset,
                body_sha256=hashlib.sha256(body).hexdigest(), chunks=chunks)
