"""Metadata-only Root grant builder; exact scope adoption required, no launch."""
from pathlib import Path
import hashlib,json,sys
D=Path('/private/tmp/gcts-buffered-canonical-ROOT-20261019')
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def checked(x):
 assert pin(x['path'])==x;return load(x['path'])
def contains(v,x):
 if v==x:return True
 if type(v)is dict:return any(contains(y,x)for y in v.values())
 if type(v)is list:return any(contains(y,x)for y in v)
 return False
def save(p,x):
 assert not p.exists(),str(p);p.write_bytes(json.dumps(x,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n');return pin(p)
assert len(sys.argv)==5 and sys.argv[1]=='ROOT_ADOPTS_EXACT_REVIEW_SCOPES'
p=load(D/'plan-false-v2.json');assert len(p)==18 and p['authorization']==dict(path='NO_AUTHORIZATION_FALSE_PLAN',bytes=0,sha256='NO_AUTHORIZATION');subject={k:v for k,v in p.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
required=dict(Source=[p[k]for k in ('worker','harness','original','candidate','reader','extraction_manifest')]+list(p['cold_sources'].values()),outer_Source=[p[k]for k in ('runner','observer')],plans=[p[k]for k in ('declaration','runtime_closure','extraction_manifest')])
specs=[('Source','buffered-canonical-qualification-components-Source-review-v1','source_review_passed'),('outer_Source','buffered-canonical-qualification-outer-Source-review-v1','source_review_passed'),('plans','buffered-canonical-qualification-prospective-plan-review-v1','prospective_review_passed')];roles={}
for (role,schema,key),path in zip(specs,sys.argv[2:]):
 d=pin(path);r=checked(d);assert r['schema']==schema and r[key]is True and r['reviewer_identity']=='/root/conventional_control_review' and r['author_identity']!=r['reviewer_identity'] and r['source_only']is True and type(r['scientific_calls'])is int and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False
 for x in required[role]:assert pin(x['path'])==x and contains(r,x),(role,x)
 if role=='plans':assert r['subject']==subject and r['subject_sha256']==sha
 roles[role]=d
actual=Path(p['actual_directory']);truepath=D/'plan-authorized-v2.json';assert not actual.exists() and not (D/'plan-authorized-v2-terminal-observation').exists() and not truepath.exists()
a=dict(schema='ROOT-buffered-canonical-qualification-once-authorization-v1',author_identity='/root',actual_execution_authorized=True,maximum_actual_invocations=1,subject_sha256=sha,review_roles=roles,scope='Exactly one fresh reviewed comparator-only qualification worker; all20groups plus both complete ordinary preimages serially through pinnedReader once; exactly two additional qualifier interruptions at original and candidate group7 initial comparator checkpoints, with exact detached six-group unfinished prefixes and no fullinput reread. Exactly3helperqualify calls, every cost charged within the same bounds. Only extracted old/new comparator helpers, Reader andharness loaded, nofullcold/Native/Model/inverse/search/opaqueprogram. Positiveworker+result/header+knownreapedexit180monotonic Sourceentry; lateroutercustody/resource/log/group/metadataandterminal210; observer225failurefallback. Same1GiBworkerwait4highwater,128MiBlogical/physicaloutputs+9MiBouterreserves/logcaps. Allparsing/copy/hash/callbacktests charged; realRootfaults neverexpectednegatives. Preserveownnegativeprecedencevariationexplicit; no math/fullproduction/fit/speed/GCTS/RLqualificationoroldfailure-rescue. OneControlreviewerfillsthreeexplicitcurrentauthor-delta/prospectivescopeswithinheritedtrustlimits; noinitialcompiled-object/defaultcontent/OSseal. No hiddenpreflight/helperinvocation, retry,limitrelaxationorotheractual. Finaltruegrantdelta/freshness/allpeerstool-idle requiredbeforelaunch.')
ap=save(D/'authorization-v2.json',a);p['authorization']=ap;assert hashlib.sha256(canonical({k:v for k,v in p.items()if k!='authorization'})).hexdigest()==sha;tp=save(truepath,p)
r=save(D/'ROOT-scope-adoption-and-grant-v2.json',dict(schema='ROOT-buffered-canonical-qualification-scope-adoption-and-grant-v1',author_identity='/root',subject_sha256=sha,roles=roles,authorization=ap,once_plan=tp,semantic_scope='Exact current V2 reviews adopted; 20normal groups and two unfinished-prefix fault-propagation controls in oneboundedhelperqualification, explicitnegative-path/trustlimits. No science/math/fullpipelinequalification frommetadata.',scientific_calls=0,scientific_acceptance=False,goal_complete=False))
print(json.dumps(dict(record=r,authorization=ap,plan=tp),indent=2))
