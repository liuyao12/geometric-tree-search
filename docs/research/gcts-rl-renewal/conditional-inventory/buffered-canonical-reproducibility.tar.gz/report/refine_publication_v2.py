"""Saved-data presentation refinement; preserve first packet and never replay subjects."""
from pathlib import Path
import io,json,hashlib,shutil,tarfile,gzip
D=Path('/private/tmp/gcts-buffered-canonical-ROOT-20261019');S=D/'publication-staging';V=D/'publication-staging-v1'
assert not V.exists();shutil.copytree(S,V)
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,x):p.write_bytes(json.dumps(x,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
p=S/'buffered-canonical-summary.json';x=json.loads(p.read_bytes())
x['root_finite_scope_adoption']=json.loads((D/'ROOT-finite-comparator-adoption-v1.json').read_bytes())
x['independent_saved_review']=json.loads(Path('/private/tmp/gcts-buffered-canonical-peer-20261019/typed-saved-qualification-review-v1.json').read_bytes())
write(p,x)
h=S/'buffered-canonical.html';s=h.read_text();needle='<div class="table-wrap"><table><thead><tr><th>Finite diagnostic group</th>'
assert s.count(needle)==1;s=s.replace(needle,'<p class="small">The saved observer field <code>ROOT_resource_accepted</code> remains false as originally written. Its terminal and runner candidate gates are true. Root separately adopted only the finite helper qualification after the independent saved-data review; the <a href="buffered-canonical-summary.json">summary preserves that review and adoption</a>. No historical field or prior failed full attempt was rewritten.</p>'+needle)
s=s.replace('No complete input was read again.','This interruption control did not reread either complete input.')
h.write_text(s)
old=V/'buffered-canonical-reproducibility.tar.gz';out=S/'buffered-canonical-reproducibility.tar.gz'
with out.open('wb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   with tarfile.open(old,'r:gz')as previous:
    for member in previous.getmembers():
     assert member.isfile();data=(S/'buffered-canonical-summary.json').read_bytes()if member.name=='report/buffered-canonical-summary.json'else previous.extractfile(member).read()
     info=tarfile.TarInfo(member.name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
   data=Path(__file__).read_bytes();info=tarfile.TarInfo('report/refine_publication_v2.py');info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
m=S/'buffered-canonical-manifest.json';x=json.loads(m.read_bytes());x['files']={n:pin(S/n)for n in x['files']};x['refinement']='Preserved first packet privately; added explicit literal observer false versus Root narrow adoption, saved review, and clarified control-only no-reread scope. No subject evaluations.';write(m,x)
print(json.dumps(dict(manifest=pin(m),summary=pin(p),page=pin(h),archive=pin(out)),indent=2))
