"""Raw Source/AST label metadata and complete saved JSON joins; no subject calls."""
from pathlib import Path
import ast
import hashlib
import json
import stat

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-conditional-selector-successor-20261021'
R = D / 'root'
C = D / 'review-C'
A = D / 'actual/qualify-controls-0'
O = A.with_name(A.name + '.observer')
T = D / 'runtime'


def pin(path):
    path = Path(path)
    assert stat.S_ISREG(path.lstat().st_mode), str(path)
    h = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for body in iter(lambda: stream.read(1048576), b''):
            h.update(body)
            size += len(body)
    return dict(path=str(path), bytes=size, sha256=h.hexdigest())


def verify(row):
    assert pin(row['path']) == row, row
    return row


def read(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_bytes())


def same(left, right):
    # Type-preserving equality of already saved JSON only, never a classifier.
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return set(left) == set(right) and all(same(left[k], right[k]) for k in left)
    if type(left) is list:
        return len(left) == len(right) and all(same(a, b) for a, b in zip(left, right))
    return left == right


def source_ast(name):
    return ast.parse((T / name).read_text())


def function(tree, name):
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)


def assignment(nodes, name):
    return next(n.value for n in nodes if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))


def first_labels(sequence):
    # Inspect string label tokens only; fixture expressions are never evaluated.
    assert isinstance(sequence, (ast.List, ast.Tuple))
    labels = []
    for item in sequence.elts:
        assert isinstance(item, (ast.List, ast.Tuple))
        first = item.elts[0]
        assert isinstance(first, ast.Constant) and type(first.value) is str
        labels.append(first.value)
    return labels


def call_id(node):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'dict':
        for key in node.keywords:
            if key.arg == 'id' and isinstance(key.value, ast.Constant):
                return key.value.value
    return None


plan_pin = pin(R / 'plans/qualify-controls-0-v1.json')
assert plan_pin['sha256'] == '766ca1411a7189679e76b0b3581482920bef9030c9ff91f3c8755217b312b226'
plan = read(plan_pin['path'])
inputs = plan['files']
assert len(inputs) == len({r['path'] for r in inputs}) == 50
for row in inputs:
    verify(row)
prior_review_pin = pin(C / 'typed-qualification-whole-prospective-Source-plan-review-v1.json')
assert prior_review_pin['sha256'] == '77c8a29e11669b3768f4ca3ebc9a2d20d2a6cec7ad49d44345524b7a2a315456'
assert read(prior_review_pin['path'])['review_passed'] is True
result_pin = pin(A / 'result.json')
assert (result_pin['bytes'], result_pin['sha256']) == (477405, '3c40d411e9a73b59b10c11649e9da2ab7955ab8474108f257e7727bcf6d4f358')
header_pin = pin(A / 'worker-header.json')
terminal_pin = pin(A / 'terminal.json')
observer_pin = pin(O / 'observer.json')
grant_pin = pin(R / 'grants/qualify-controls-0-v1.json')
barrier_pin = pin(R / 'before-qualification-once-barrier-v1.json')
consumed_pin = pin(A / 'CONSUMED.json')
owned_pin = pin(A / 'owned-child.json')
result, header, terminal, observer = [read(p['path']) for p in
                                      (result_pin, header_pin, terminal_pin, observer_pin)]
grant, barrier, consumed, owned = [read(p['path']) for p in
                                  (grant_pin, barrier_pin, consumed_pin, owned_pin)]
assert grant['authorized'] is True and grant['review_passed'] is True and grant['uses'] == 1
assert grant['plan_sha256'] == consumed['plan_sha256'] == owned['plan_sha256'] == plan_pin['sha256']
assert consumed['uses'] == 1 and type(consumed['uses']) is int
assert consumed['grant_sha256'] == grant_pin['sha256']
assert grant['prospective_review'] == prior_review_pin
assert grant['runner_sha256'] == verify(next(r for r in inputs if r['path'] == plan['runner_path']))['sha256']
assert barrier['grant'] == grant_pin and barrier['plan'] == plan_pin
assert barrier['prospective_review'] == prior_review_pin and barrier['current_source_pins_rehashed'] == 50
assert barrier['all_actual_directories_absent'] is True and barrier['timed_actuals_serial'] is True
assert barrier['browser_and_nonobserver_tools_idle_during_actual'] is True
assert barrier['owned_preview_servers_running'] is False
assert all(x['case_id'] == 'qualify-controls-0' for x in (result, header, terminal, observer, consumed, owned))
assert result['stage'] == 'qualify'
assert result['status'] == header['status'] == 'COMPLETE'
assert result['error'] is None and result['first_Root_fault'] is False
assert header['first_Root_fault'] is False and header['native_closed_and_reaped'] is True
assert result['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True
assert header['result'] == terminal['result'] == result_pin and terminal['header'] == header
assert terminal['header_valid'] is terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is True
assert terminal['process_exit_code'] == observer['parent_exit_code'] == 0
assert terminal['reason'] is observer['reason'] is None and not terminal['errors'] and not observer['errors']
assert observer['resource_candidate_before_receipt'] is observer['resource_candidate_accepted'] is True
assert observer['fallback_trigger_seconds'] is None and observer['owned_child'] == owned
assert owned['child_pid'] == owned['child_pgid']
assert header['callbacks'] == result['callbacks'] == 158525 < plan['limits']['root_callbacks']
assert result['old_qualification_reused'] is terminal['old_qualification_reused'] is False
assert all(s['status'] == 'COMPLETED' for s in result['stages']) and len(result['stages']) == 19
assert max(s['began'] + s['seconds'] for s in result['stages']) < plan['limits']['work_seconds']
assert result['elapsed_seconds'] < plan['limits']['positive_seconds']
assert terminal['known_exit_seconds'] <= plan['limits']['positive_seconds']
assert terminal['final_custody_gate_seconds'] <= plan['limits']['custody_seconds']
assert observer['known_parent_exit_seconds'] <= plan['limits']['custody_seconds']
assert observer['final_observer_gate_seconds'] <= plan['limits']['custody_seconds']

transport = result['native_transport']
assert result['native_queries'] == transport['request_stages'] == []
assert result['native_requests_started'] == transport['complete_records'] == 0
assert result['guard_compilations'] == result['work_snapshots'] == []
assert transport['constructor_completed'] is transport['closed'] is transport['all_reaped'] is True
assert transport['native_exit_code'] == transport['wait4_status'] == 0
assert transport['cleanup_errors'] == transport['termination_signals'] == []
assert transport['stdout_eof'] is transport['stderr_complete'] is transport['same_owned_process_group'] is True
assert transport['stderr_bytes'] == transport['stdout_pending_bytes'] == 0
assert transport['parent_pid'] == transport['parent_pgid'] == owned['child_pid']
assert transport['native_pgid'] == owned['child_pgid'] and transport['native_pid'] != owned['child_pid']
assert result['native_peak_bytes'] == header['native_peak_bytes'] == transport['native_high_water_bytes'] == 12206080
assert transport['logical_proof_accepted'] is transport['scientific_acceptance'] is False
assert pin(A / 'native/boundary-oracle')['sha256'] == pin(plan['native']['executable_path'])['sha256']
assert pin(A / 'native/code.bin')['sha256'] == '97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed'
assert result['full_physical_Wang_claim'] is False

combined = terminal['parent_usage']['ru_maxrss'] + max(terminal['child_usage']['ru_maxrss'],
    header['python_peak_after_output_bytes']) + header['native_peak_bytes'] + terminal['memory_terminal_output_reserve_bytes']
assert combined == terminal['conservative_combined_peak_bytes'] == 262504448
whole = combined + observer['final_observer_peak_bytes'] + observer['final_output_memory_reserve_bytes']
assert whole == observer['final_conservative_whole_peak_bytes'] == observer['conservative_whole_peak_bytes'] == 293765120
assert whole < plan['limits']['memory_bytes']
assert terminal['stored_bytes_before_terminal_receipt'] <= plan['limits']['physical_bytes'] - plan['limits']['reserved_outer_bytes']
assert observer['stored_bytes_before_observer_receipt'] + observer['receipt_allowance_bytes'] <= plan['limits']['physical_bytes']
for carrier, folder in ((terminal, A), (observer, O)):
    for stream in ('stdout', 'stderr'):
        log = carrier['logs'][stream]
        assert log['eof'] is True and log['overflow'] is False
        assert log['bytes'] == log['stored'] == (folder / (stream + '.bin')).stat().st_size
        assert log['bytes'] <= plan['limits']['log_bytes']
assert json.loads((O / 'stdout.bin').read_bytes()) == terminal
worker_stdout = json.loads((A / 'stdout.bin').read_bytes())
assert worker_stdout['case_id'] == 'qualify-controls-0' and worker_stdout['status'] == 'COMPLETE'
assert worker_stdout['callbacks'] == result['callbacks']

s = result['scientific_result']
assert s['schema'] == 'gcts-conditional-selector-pretraining-qualification-v1'
assert s['stage'] == 'qualify' and s['stage_id'] == 'qualify-controls-0'
assert s['status'] == 'COMPLETE_PRETRAINING_CONTROL_QUALIFICATION'
assert s['stage_complete'] is s['job_record_complete'] is True
assert s['resource_admitted'] is False and s['export'] is None
assert s['donor_acquisition_performed'] is s['target_model_or_search_performed'] is False
assert s['real_training_episode_performed'] is s['learned_policy_exported'] is False
assert s['native_records'] == [] and s['limits'] == plan['experiment_limits']
assert same(s['inputs'], read(plan['input_path']))
assert same(s['independent_graph_bank'], read(plan['independent_graph_bank_path']))
assert s['format_check']['complete'] is True and s['format_check']['phase'] == 'training'
assert s['format_check']['statement_ids'] == [x['id'] for x in s['inputs']['training']]
assert len(s['format_check']['input_structures']) == 8
assert all(x['structure']['category'] == 'ACYCLIC_SINGLE_PRODUCER' for x in s['format_check']['input_structures'])
assert s['denominators'] == dict(train_applicable_rows=305, independent_graph_cases=17,
    unexpected_first_fault_cases=2, inherited_diagnostic_carrier=True)

# These are declared Source label tokens, not old actual passes or executed fixtures.
expected_ids = {}
expected_ids['numeric'] = ['zero-initial-policy','two-action-softmax','translated-equal-softmax',
    'duplicate-features-preserve-actions','sole-abstain-softmax','fixed-first-no-draw',
    'fixed-sole-abstain-no-draw','uniform-low-endpoint','uniform-high-endpoint','rl-high-endpoint',
    'one-abstain-score-gradient','two-decisions-use-sum-not-mean','pre-update-baseline-controls-advantage',
    'no-decisions-zero-gradient','reward-components-and-costs','bool-weight-refused',
    'empty-action-array-refused','missing-abstain-refused','illegal-choice-refused','altered-draw-refused',
    'unexplained-baseline-refused','foreign-runtimeerror-identity','foreign-selectorerror-identity']
word_func = function(source_ast('word_point_reference_verifier_v3.py'), 'run_word_reference_diagnostics')
word_labels = ['full-synthetic-word-reduction']
for stmt in word_func.body:
    if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
        call = stmt.value
        if isinstance(call.func, ast.Name) and call.func.id in ('changed_tile','reject','reject_overlay'):
            assert isinstance(call.args[0], ast.Constant)
            word_labels.append(call.args[0].value)
        elif isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name) and call.func.value.id == 'controls' and call.func.attr == 'append':
            label = call_id(call.args[0])
            if label is not None:
                word_labels.append(label)
expected_ids['word'] = word_labels + ['foreign-' + t for t in ('RuntimeError','ValueError','StopIteration','ReferenceMismatch')]
graph_tree = source_ast('graph_copy_reference_v1.py')
graph_declarations = ast.literal_eval(assignment(graph_tree.body, 'CONTROLS'))
expected_ids['graph'] = [r['id'] for r in graph_declarations]
expected_ids['encoding'] = ['canonical-value-' + str(i) for i in range(21)] + ['malformed-value-' + str(i) for i in range(7)] + ['encoder-foreign-' + t for t in ('RuntimeError','ValueError','StopIteration','ReferenceMismatch')] + ['nested-' + container + '-' + t for container in ('list','dict') for t in ('RuntimeError','ValueError','StopIteration','ReferenceMismatch')]
principal_tree = source_ast('principal_family_reference_v1.py')
principal_func = function(principal_tree, 'run_principal_reference_controls')
expected_ids['principal'] = ['graph-' + label for label in first_labels(assignment(principal_func.body,'graphs'))] + ['refuse-' + label for label in first_labels(assignment(principal_func.body,'bad'))] + ['donor-control-' + label for label in ('generic-MP','generic-serial','generic-curried','shared-antecedent','opaque-quantifier-equality','equal-formula-named-alias','incidental-equal-atoms-erased')] + ['donor-refuse-' + label for label in ('bool-reference','float-reference','negative-reference','self-reference','unknown-axiom','wrong-axiom-formula','wrong-MP-formula','wrong-target','imported-block','open-assumption','extra-command-key','schema-enabled')] + ['certificate-refuse-' + label for label in ('missing-trace','empty-trace','extra-trace-step','wrong-trace-rule','wrong-constraint','wrong-solved-row','wrong-donor-argument','wrong-provenance','wrong-structural-id','wrong-template-conclusion')] + ['foreign-' + label for label in ('ValueError','StopIteration','public-Invalid-impostor')]
expected_ids['matched_symbolic'] = ['named-axioms-no-point-interface','actual-first-prefix-occurrence','both-actual-prefix-occurrences','saturated-prefix-no-packet','missing-receptor-no-packet','equal-template-distinct-family-units','equal-formula-named-occurrences','missing-original-guard-no-packet','empty-library-primitive-fallback','no-applicable-library-primitive-fallback','foreign-RuntimeError','foreign-ValueError','foreign-StopIteration']
num_func = function(source_ast('conditional_selector_numeric_controls_v1.py'),'run_numeric_controls')
numeric_records = [n.value.args[0].value for n in num_func.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id == 'record' and isinstance(n.value.args[0],ast.Constant)]
expected_ids['conditional_numeric'] = ['initial-symbolic','initial-point'] + numeric_records + first_labels(assignment(num_func.body,'malformed_vectors')) + ['bool-rng-draw','unit-upper-rng-draw','undeclared-selection-mode','undeclared-engine'] + first_labels(assignment(num_func.body,'episode_cases')) + ['seventeenth-episode','overlong-policy-carrier'] + first_labels(assignment(num_func.body,'replay_cases')) + ['unexplained-nonzero-origin'] + ['foreign-identity-' + str(i) for i in range(4)]
semantic_tree = source_ast('conditional_family_semantic_controls_v2.py')
expected_ids['conditional_semantic'] = list(ast.literal_eval(assignment(semantic_tree.body,'CONTROL_IDS')))
corpus_tree = source_ast('conditional_selector_corpus_contract_v3.py')
expected_ids['conditional_corpus'] = list(ast.literal_eval(assignment(corpus_tree.body,'FORMAT_CONTROL_IDS')) + ast.literal_eval(assignment(corpus_tree.body,'GRAPH_CONTROL_IDS')) + ast.literal_eval(assignment(corpus_tree.body,'FOREIGN_CONTROL_IDS')))
inventory = s['control_bank_inventory']
assert inventory['complete'] is True and inventory['enumerated_rows'] == 305
assert inventory['inherited_diagnostic_carrier_retained'] is True
assert [b['bank'] for b in inventory['banks']] == list(expected_ids)
bank_summaries = []
for b in inventory['banks']:
    key = b['bank']
    rows = s['controls'][key]['controls']
    assert s['controls'][key]['complete'] is True and s['controls'][key]['schema'] == b['schema']
    assert b['count'] == len(rows) == len(expected_ids[key])
    assert [row['id'] for row in rows] == b['control_ids'] == expected_ids[key]
    assert len(set(b['control_ids'])) == len(rows)
    assert all(row.get('passed') is True if key == 'conditional_numeric' else row.get('status') == 'PASSED' for row in rows)
    bank_summaries.append(dict(bank=key,schema=b['schema'],count=b['count'],exact_ordered_control_ids=b['control_ids'],all_returned_passed=True))
assert sum(b['count'] for b in bank_summaries) == 305
assert all(s['controls'][k] is None for k in ('corpus','reference_setup_calibration','native_batch','guard_resolver','guard_differential'))
assert inventory['acquisition_only_status'] == 'NOT_REQUESTED_FRESH_ACQUISITION_OBLIGATION'

inherited = s['controls']['inherited']
assert inherited['status'] == 'complete' and inherited['global_dead_forced_generation_controls'] is True
assert inherited['callback_identity_propagated'] is inherited['incomplete_certificate_rejected'] is True
assert inherited['base_solutions'] == inherited['marked_solutions'] and len(inherited['base_solutions']) == 2
assert len(inherited['full_domain_audits']) == 9 and all(x['complete'] is True for x in inherited['full_domain_audits'])
assert inherited['marking_verification']['complete'] is True and inherited['marking_verification']['certificates'] == 1
assert inherited['marked_extension_check']['complete'] is True
assert inherited['incomplete_support_scan']['certificates'] == [] and inherited['incomplete_support_scan']['complete_proposal_prefix'] is False
assert s['controls']['word']['positive']['complete'] is True and s['controls']['word']['overlay']['complete'] is True
assert s['controls']['word']['tiny_full_byte_pair_comparisons'] == 49
graph = s['controls']['graph']
assert graph['fixture_count'] == len(graph['fixtures']) == 10
for declaration, row in zip(graph_declarations, graph['controls']):
    assert row['complete'] is True and row['fixture'] == declaration['fixture']
    assert [e['action'] for e in row['events'] if 'action' in e] == json.loads(json.dumps(declaration['actions']))
    refs = [row['initial_nodes']] + [e.get('full_reference_equal_nodes', {}) for e in row['events']]
    for ref in refs:
        assert all(type(i) is int and 0 <= i < len(row['snapshots']) for i in ref.values())
for row in s['controls']['principal']['controls'][:7]:
    assert all(same(row['actual'][k],row['expected'][k]) for k in ('premises','row_formulas','conclusion','parameters'))
for row in s['controls']['principal']['controls']:
    if row['id'].startswith('donor-control-'):
        assert row['verification']['complete'] is True
        assert same(row['family']['parameters'],row['expected']['parameters']) and same(row['family']['template'],row['expected']['template'])

bank = read(plan['independent_graph_bank_path'])
independent = s['independent_graph_checks']
assert independent['complete'] is True and independent['count'] == 17
assert independent['accepted_cases'] == 12 and independent['refusal_cases'] == 5
assert len(independent['controls']) == len(bank['cases']) == 17
for expected, actual in zip(bank['cases'],independent['controls']):
    assert actual['id'] == expected['id'] and actual['kind'] == expected['kind']
    assert actual['status'] == 'PASSED' and same(actual['spec'],expected['spec']) and actual['reason'] == expected['reason']
    if expected['kind'] == 'ACCEPT':
        full = dict(schema=bank['expected_receipt_schema'],scope=bank['expected_receipt_scope'],**expected['expected'])
        assert len(full) == 14 and same(actual['expected'],full) and same(actual['actual'],full)
    else:
        assert same(actual['expected'],expected['expected']) and same(actual['actual'],expected['expected'])
corpus_rows = {row['id']:row for row in s['controls']['conditional_corpus']['controls']}
for expected in bank['cases'][:6]:
    assert same(corpus_rows[expected['id']]['actual'],dict(schema=bank['expected_receipt_schema'],scope=bank['expected_receipt_scope'],**expected['expected']))
assert corpus_rows['ungrounded-curried']['actual']['relevant'] == ['p']
faults = s['first_fault_checks']
assert faults['complete'] is True and faults['count'] == len(faults['controls']) == 2
for i, row in enumerate(faults['controls']):
    assert row['id'] == 'unexpected-first-foreign-' + str(i) and row['status'] == 'PASSED'
    assert row['first_type'] == ('RuntimeError' if i == 0 else 'CorpusFormatError')
    assert row['exact_first_identity_preserved'] is True and row['postfault_nested_checks'] == 0
    assert row['corpus_bank_completed'] is row['prefix_admitted'] is False
assert len(result['qualification_progress']) == 1
progress = result['qualification_progress'][0]
assert progress['complete'] is True and progress['status'] == 'COMPLETE' and progress['qualified_prefix'] is False
assert same(progress['input_validation'],s['format_check'])
groups = progress['groups']
assert [g['id'] for g in groups] == ['inherited_fixed_train_controls','conditional_numeric','conditional_semantic','conditional_corpus','independent_graph_bank','unexpected_first_faults']
assert all(g['status'] == 'COMPLETED' for g in groups)
for key,value in groups[0]['receipt'].items():
    assert same(value,s['controls'][key])
for group in groups[1:4]:
    assert same(group['receipt'],s['controls'][group['id']])
assert same(groups[4]['receipt'],independent) and same(groups[5]['receipt'],faults)

census = []
for folder in (A,O):
    for path in folder.rglob('*'):
        if path.is_dir():
            continue
        assert not path.name.endswith('.partial')
        census.append(pin(path))
census.sort(key=lambda r:r['path'])
assert len(census) == 12 and len({r['path'] for r in census}) == 12
total_bytes = sum(row['bytes'] for row in census)
assert total_bytes == 8083836 and total_bytes < plan['limits']['physical_bytes']
assert not (A/'failure.json').exists() and not list((A/'native').glob('*.partial'))
for row in inputs + census:
    verify(row)
assert pin(plan_pin['path']) == plan_pin

checks = [
    ('Exact once/current Source and custody chain','Reviewed plan766c and all50 guard bodies remain current. Root once grant/consumed uses1/hash/barrier/current owned process group bind exact result/header/terminal/observer. Root serial-idle declaration is labeled an operational attestation, not an independent retrospective OS measurement.'),
    ('Complete resource and cleanup admission conditions','Worker/header COMPLETE, unchanged Sources, no Root fault/error; parent/Native exits0, closed/reaped same group, EOF/log/callback/time gates pass. Parent waited-child/header/Native/reserve sum262,504,448 B plus observer/reserve gives293,765,120 B under original1GiB; all12 current files total8,083,836 B under128MiB and output caps.'),
    ('Nine exact training-applicable banks','All305 fresh rows return expected status carriers and exact ordered unique Source-label IDs/schema/count. Inherited tiny diagnostic carrier includes nine complete domain audits, equal two base/marked solutions, dead/forced/generation and rollback/certificate scope. It is not an invented extra flat bank denominator.'),
    ('Independent full structural and refusal joins','All17 exact bank cases reconcile: twelve complete14field expected/actual receipts and five exact owned refusal class/message carriers. Six original corpus fixture receipts match these expectations; the formerly wrong ungrounded-curried relevant field is [p]. No closure/classifier/proof replay occurred in C.'),
    ('Two callback regressions and complete diagnostic retention','Both fresh RuntimeError/unowned CorpusFormatError probes report exact first identity, zero postfault callbacks and no admitted prefix. All six progress groups are complete and receipt-equal to final carriers; no earlier incomplete prefix is promoted. This is finite corpus-harness coverage, not a universal exception theorem.'),
    ('No donor/policy/real proof/query qualification','No Native requests/records/stages/guard ledgers/work snapshots; ready Native process only prepared and closed. No donor, library, real target search/model/episode, policy/export or Native logical acceptance. Subject resource_admitted remains false; C true science/stage flags refer exclusively to this fresh component-control qualification.'),
    ('Honest costs, full census and future scope','Unique observer elapsed ledger2.643614583997987 s, final gate2.6439021669939393 s, nested clocks and Root-reported tool stdout2.644288374998723 s remain distinct. Full12file post-terminal census is separate from before-receipt samples. Cost is extra prerequisite work; D19 remains closed and future34job/32episode/192slot study is unexecuted/unapproved by this review.')]
review_doc = dict(schema='D20-C-training-control-qualification-actual-review-v1',
    review_passed=True,resource_admitted=True,scientific_qualified=True,stage_complete=True,
    stage='qualify',stage_id='qualify-controls-0',
    scope='PASS for the once fresh complete training-component qualification only. No Root admission issued, learner result, policy/library/proof export, future acquisition/training/evaluation grant or benefit claim. No scientific, numeric/RNG, classifier, Graph or Native replay by C.',
    plan=plan_pin,result=result_pin,header=header_pin,terminal=terminal_pin,observer=observer_pin,
    grant=grant_pin,consumed=consumed_pin,owned_child=owned_pin,Root_barrier_attestation=barrier_pin,
    prospective_review=prior_review_pin,input_pins=inputs,
    complete_actual_file_census=census,physical_census=dict(files=census,file_count=12,total_bytes=total_bytes,
        scope='Exact current post-terminal actual and external-observer regular files, including binaries/tables as opaque raw pins. Distinct from observer before-receipt sample.'),
    banks=bank_summaries,denominators=s['denominators'],explicit_control_cases=324,
    independent_graph_case_ids=[r['id'] for r in independent['controls']],first_fault_checks=faults,
    inherited_domain_audits=9,progress_groups=6,Native_starts=0,Native_records=0,Native_proofs_accepted=0,
    donor_acquisitions=0,real_training_episodes=0,policy_exports=0,target_proofs=0,
    whole_seconds=observer['elapsed_seconds'],whole_peak_bytes=whole,
    costs=dict(observer_elapsed_seconds=observer['elapsed_seconds'],
        final_observer_gate_seconds=observer['final_observer_gate_seconds'],
        worker_record_seconds=result['elapsed_seconds'],worker_header_seconds=header['seconds'],
        worker_stdout_seconds=worker_stdout['seconds'],subject_entry_seconds=s['seconds'],
        parent_known_exit_seconds=terminal['known_exit_seconds'],parent_final_gate_seconds=terminal['final_custody_gate_seconds'],
        Root_reported_tool_stdout_seconds=2.644288374998723,
        Root_reported_tool_session='41446',Root_reported_tool_exit_code=0,
        scope='Charge one unique observer elapsed ledger sample. Root tool observation is separately attributed, not independent remeasurement. Nested clocks overlap and are never added.'),
    resource_components=dict(worker_python_peak=result['python_peak_bytes'],worker_post_output_peak=header['python_peak_after_output_bytes'],
        waited_child_peak=terminal['child_usage']['ru_maxrss'],Native_peak=header['native_peak_bytes'],parent_peak=terminal['parent_usage']['ru_maxrss'],
        parent_output_reserve=terminal['memory_terminal_output_reserve_bytes'],parent_combined_peak=combined,
        observer_peak=observer['final_observer_peak_bytes'],observer_output_reserve=observer['final_output_memory_reserve_bytes']),
    checks=[dict(check=title,evidence=evidence,passed=True) for title,evidence in checks],failures=[],
    scientific_imports=0,scientific_calls=0,helper_invocations=0,control_executions_by_C=0,
    classifier_numeric_RNG_Graph_Native_replays=0,partial_files_parsed=0,
    Root_admission_issued=False,future_main_authority=False,tools_idle_after_freeze=True,
    review_program=pin(__file__))
output = C/'typed-training-control-qualification-actual-review-v1.json'
with output.open('xb') as stream:
    stream.write((json.dumps(review_doc,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps(pin(output),sort_keys=True))
