"""Root-only explicit-allowlist raw ZIP packager for the single D20 qualification.
No research imports/calls, directory scan, extraction or partial JSON parsing.
Final exact inventory/authority and independent Source review precede invocation.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

VERSION = 'D20-explicit-qualification-raw-packager-v1'
STUDY = Path(__file__).resolve().parents[1]
OUT = STUDY/'publication'
CASE = 'qualify-controls-0'
RESERVED = {'snapshot-manifest.json','publication-inventory.json','publication-authority.json'}
REQUIRED = {'once_plan','qualification_result','worker_header','terminal_receipt','external_observer',
            'Root_admission','C_actual_review','training_input','independent_graph_bank'}


def need(value,message):
    if not value:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode('utf-8')


def regular(path):
    path = Path(path)
    need(path.is_absolute() and path.is_file() and not path.is_symlink() and path == path.resolve(),
         'canonical absolute ordinary current file only')
    need(not any(p in ('.git','.aws','.env','.gcts-active','__pycache__') for p in path.parts), 'forbidden private/cache path')
    return path


def pin(path):
    path = regular(path); h = hashlib.sha256(); size = 0
    with path.open('rb') as stream:
        for body in iter(lambda:stream.read(1048576),b''):
            h.update(body); size += len(body)
    return dict(path=str(path),bytes=size,sha256=h.hexdigest())


def verify(row):
    need(set(row) == {'path','bytes','sha256'} and type(row['bytes']) is int and row['bytes'] >= 0
         and type(row['sha256']) is str and len(row['sha256']) == 64,'exact raw pin')
    need(pin(row['path']) == row,'current bytes differ from raw pin')
    return Path(row['path'])


def read(path,expected):
    path = regular(path); need('.partial' not in path.name,'partial bytes are never JSON intake')
    body = path.read_bytes()
    need((str(path),len(body),hashlib.sha256(body).hexdigest()) == tuple(expected[k] for k in ('path','bytes','sha256')),
         'complete JSON intake must match its explicit raw pin')
    return json.loads(body)


def safe(name):
    need(type(name) is str and name and '\\' not in name and '\x00' not in name,'portable relative member')
    p = PurePosixPath(name)
    need(not p.is_absolute() and str(p) == name and all(part not in ('','.','..') for part in p.parts),'no member traversal/alias')
    return name


def main(inventory_path):
    inventory_path = regular(inventory_path)
    need(inventory_path.is_relative_to(STUDY/'root'),'Root explicit inventory only')
    inventory_pin = pin(inventory_path); inventory = read(inventory_path,inventory_pin)
    need(inventory['schema'] == 'D20-qualification-publication-inventory-v1','single qualification inventory schema')
    files,omitted = inventory['files'],inventory['omitted_runtime']
    need(type(files) is list and type(omitted) is list and REQUIRED <= {r['role'] for r in files}, 'complete explicit qualification roles')
    def by_role(role):
        rows = [r for r in files if r['role'] == role]
        need(len(rows) == 1,'one exact core file for role '+role)
        return rows[0]
    for role in REQUIRED:
        by_role(role)
    plan_row = by_role('once_plan'); plan = read(plan_row['path'],plan_row)
    need(plan['case_id'] == CASE and plan['stage'] == 'qualify' and plan['required_upstream_ids'] == plan['upstream_receipts'] == [],
         'one cold qualification, no main stage or old upstream adoption')
    guards = {r['path']:r for r in plan['files']}
    need(len(guards) == len(plan['files']) == 50,'exact current50 Source/input guards')
    pin_only = {plan['python']['path'],plan['native']['executable_path'],
        str(Path(plan['actual_dir'])/'native/boundary-oracle'),str(Path(plan['actual_dir'])/'native/code.bin')}
    selected = {}; omitted_map = {}; names = set()
    for row in files:
        need(type(row) is dict and set(row) == {'path','bytes','sha256','archive_path','role'} and type(row['role']) is str,
             'exact explicit selected row')
        raw = {k:row[k] for k in ('path','bytes','sha256')}; path = verify(raw); name = safe(row['archive_path'])
        need(row['path'] not in selected and row['path'] not in pin_only and name not in names|RESERVED,
             'unique selected body, never executable/table pin-only or reserved member')
        need(path.is_relative_to(STUDY) or row['path'] in guards,'only task-owned or exact plan-declared Source bodies')
        need(path not in (inventory_path,Path(inventory['publication_authority']['path'])), 'explicit inventory/authority reserved bodies, no selfpin cycle')
        need(path.name not in ('training-control-qualification-evidence.zip','training-control-qualification-manifest.json')
             and not path.name.endswith(('.zip','.tar','.tar.gz','.tgz')),'no archive/output selfcycle')
        selected[row['path']] = dict(row,opaque_partial=('.partial' in path.name)); names.add(name)
    for row in omitted:
        need(type(row) is dict and set(row) == {'path','bytes','sha256','role','reason'},'exact pin-only omission row')
        raw = {k:row[k] for k in ('path','bytes','sha256')}; verify(raw)
        need(row['path'] in pin_only and row['path'] not in selected and row['path'] not in omitted_map,
             'only declared executable/generated-table identities omitted, disjoint from selected bodies')
        omitted_map[row['path']] = row
    need(set(omitted_map) == pin_only and set(selected).isdisjoint(omitted_map),'all4 mandatory runtime omissions, no contradictory body')
    for identity,row in guards.items():
        candidate = selected.get(identity,omitted_map.get(identity))
        need(candidate is not None and {k:candidate[k] for k in ('path','bytes','sha256')} == row,'every plan Source/input retained or exact runtime pin-only')
    need(by_role('training_input')['path'] == plan['input_path']
         and by_role('independent_graph_bank')['path'] == plan['independent_graph_bank_path'],'both physical phase inputs retained')
    result = read(by_role('qualification_result')['path'],by_role('qualification_result')); science = result['scientific_result']
    need(result['case_id'] == CASE and result['stage'] == 'qualify' and result['status'] == 'COMPLETE'
         and result['first_Root_fault'] is False and result['source_unchanged'] is True
         and result['native_requests_started'] == 0 and result['native_queries'] == [],'complete current qualification, zero Native queries')
    need(science['stage_id'] == CASE and science['stage_complete'] is science['job_record_complete'] is True
         and science['resource_admitted'] is False and science['export'] is None
         and science['denominators'] == dict(train_applicable_rows=305,independent_graph_cases=17,
             unexpected_first_fault_cases=2,inherited_diagnostic_carrier=True),'exact305+17+2 qualification, no policy/export')
    core = {'plan':'once_plan','result':'qualification_result','header':'worker_header',
            'terminal':'terminal_receipt','observer':'external_observer','C_actual_review':'C_actual_review'}
    admission = read(by_role('Root_admission')['path'],by_role('Root_admission'))
    need(admission['schema'] == 'D20-Root-training-control-qualification-admission-v1' and admission['case_id'] == CASE
         and all(admission[k] is True for k in ('admitted','resource_admitted','scientific_qualified','stage_complete')),
         'separate complete reviewed Root qualification admission required')
    for key,role in core.items():
        need(admission[key] == {k:by_role(role)[k] for k in ('path','bytes','sha256')},
             'Root admission must join exact '+key+' body')
    review = read(by_role('C_actual_review')['path'],by_role('C_actual_review'))
    need(review['schema'] == 'D20-C-training-control-qualification-actual-review-v1'
         and review['stage_id'] == CASE and review['stage'] == 'qualify'
         and all(review[k] is True for k in ('review_passed','resource_admitted','scientific_qualified','stage_complete')),
         'independent complete C actual qualification review required')
    for key in ('plan','result','header','terminal','observer'):
        need(review[key] == admission[key], 'C review and Root admission component mismatch')
    authority_path = verify(inventory['publication_authority']); authority = read(authority_path,inventory['publication_authority'])
    need(authority_path.is_relative_to(STUDY/'root') and authority['publication_authorized'] is True
         and type(authority['scientific_calls']) is int and authority['scientific_calls'] == 0,'Root passive publication authority')
    rows = sorted(selected.values(),key=lambda r:r['archive_path'])
    extra = [(inventory_path,'publication-inventory.json'),(authority_path,'publication-authority.json')]
    for path,name in extra:
        rows.append(dict(pin(path),archive_path=name,role='explicit_packaging_input',opaque_partial=False))
    rows.sort(key=lambda r:r['archive_path'])
    snapshot = dict(schema='D20-training-control-qualification-raw-snapshot-v1',inventory=inventory_pin,
        files=rows,omitted_runtime=[omitted_map[k] for k in sorted(omitted_map)],source_input_count=50,
        phase_input_count=2,actual_count=1,stage_id=CASE,denominators=science['denominators'],
        export=None,Native_queries=0,real_training_episodes=0,learned_policies=0,
        scope='Single fresh qualification only. Explicit Root allowlist, no directory scan/pin chasing or old main-study/result adoption. Executables/generatedtables rawpins only. Later installation/live receipts remain outside snapshot.',
        scientific_imports=0,scientific_calls=0,partial_files_parsed=0)
    body = encoded(snapshot); archive = OUT/'training-control-qualification-evidence.zip'; dest = OUT/'training-control-qualification-manifest.json'
    need(not archive.exists() and not dest.exists(),'immutable exclusive publication outputs already exist')
    OUT.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as bundle:
        def info(name):
            z = zipfile.ZipInfo(safe(name),date_time=(1980,1,1,0,0,0)); z.create_system = 3
            z.external_attr = (stat.S_IFREG|0o644)<<16; z.compress_type = zipfile.ZIP_DEFLATED
            z.comment = b''; z.extra = b''
            return z
        bundle.writestr(info('snapshot-manifest.json'),body,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
        for row in rows:
            h = hashlib.sha256(); size = 0
            with regular(row['path']).open('rb') as source,bundle.open(info(row['archive_path']),'w') as target:
                for chunk in iter(lambda:source.read(1048576),b''):
                    h.update(chunk); size += len(chunk); target.write(chunk)
            need((size,h.hexdigest()) == (row['bytes'],row['sha256']),'input changed during streaming copy')
    expected = {r['archive_path']:(r['bytes'],r['sha256']) for r in rows}
    expected['snapshot-manifest.json'] = (len(body),hashlib.sha256(body).hexdigest()); seen = set()
    with zipfile.ZipFile(archive,'r') as bundle:
        for member in bundle.infolist():
            name = safe(member.filename)
            need(name in expected and name not in seen and not member.is_dir()
                 and stat.S_IFMT(member.external_attr>>16) == stat.S_IFREG
                 and member.date_time == (1980,1,1,0,0,0),'all and only ordinary deterministic declared members')
            seen.add(name); h = hashlib.sha256(); size = 0
            with bundle.open(member) as stream:
                for chunk in iter(lambda:stream.read(1048576),b''):
                    h.update(chunk); size += len(chunk)
            need((size,h.hexdigest()) == expected[name],'full raw ZIP member readback hash/length')
    need(seen == set(expected),'complete exact archive member census')
    for row in rows+list(omitted_map.values()):
        verify({k:row[k] for k in ('path','bytes','sha256')})
    final = dict(snapshot,archive=pin(archive),all_members_raw_verified=True,
        raw_members=len(rows),regular_members_including_snapshot=len(seen),uncompressed_bytes=sum(r['bytes'] for r in rows),
        embedded_snapshot=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest()))
    with dest.open('xb') as stream:
        stream.write(encoded(final))
    print(json.dumps(dict(archive=pin(archive),manifest=pin(dest),raw_members=len(rows)),sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--inventory',required=True)
    main(str(Path(parser.parse_args().inventory).resolve()))
