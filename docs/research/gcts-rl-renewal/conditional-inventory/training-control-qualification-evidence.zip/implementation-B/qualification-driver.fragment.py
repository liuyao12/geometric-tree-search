

# D20 pretraining qualification only. All inherited function/class bodies above
# remain exact D19 v19; the corrected corpus import is the sole inherited edit.
QUALIFICATION_VERSION = 'gcts-conditional-selector-pretraining-qualification-v1'
_D20_BANKS = (
    ('numeric','selector-independent-numeric-controls-v1',23),
    ('word','word-reference-tiny-diagnostics-v1',48),
    ('graph','literal-graph-copy-reference-controls-v1',22),
    ('encoding','canonical-json-subtree-encoding-controls-v2',40),
    ('principal','independent-principal-MP-reference-v1',53),
    ('matched_symbolic','D18-independent-matched-symbolic-controls-v2',13),
    ('conditional_numeric','D19-conditional-selector-numeric-controls-v1',57),
    ('conditional_semantic','D19-independent-conditional-semantic-controls-v2',18),
    ('conditional_corpus','D19-corpus-contract-controls-v1',31))
_D20_STRUCTURAL_FIELDS = ('category','target','seeds','rules','grounded','target_ancestors',
    'relevant','edges','producer_counts','cyclic_components','whole_cyclic_atoms','whole_producer_counts')


def _d20_bank_inventory(controls, check):
    inventory = []; total = 0
    for key,schema,count in _D20_BANKS:
        check(); receipt = controls[key]
        need(type(receipt) is dict and receipt['schema'] == schema and receipt['complete'] is True,
             'complete exact qualification bank '+key)
        rows = receipt['controls']; need(type(rows) is list and len(rows) == count,
                                         'complete qualification row population '+key)
        ids = []; seen = set()
        for row in rows:
            check(); need(type(row) is dict and type(row['id']) is str and row['id'] not in seen,
                          'unique original qualification bank control ID')
            need(row.get('passed') is True if key == 'conditional_numeric' else row.get('status') == 'PASSED',
                 'every actual qualification bank control passed')
            ids.append(row['id']); seen.add(row['id'])
        for field in ('count','control_count'):
            if field in receipt:
                need(type(receipt[field]) is int and receipt[field] == count,
                     'exact declared qualification bank count')
        inventory.append(dict(bank=key,schema=schema,count=count,control_ids=ids))
        total += count
    need(total == 305 and controls['inherited']['status'] == 'complete',
         'all305 ordered bank rows plus the complete inherited diagnostic carrier')
    for key in ('corpus','reference_setup_calibration','native_batch','guard_resolver','guard_differential'):
        need(controls[key] is None,'acquisition-only control not requested in qualification')
    return dict(complete=True,banks=inventory,enumerated_rows=total,
        inherited_diagnostic_carrier_retained=True,
        acquisition_only_status='NOT_REQUESTED_FRESH_ACQUISITION_OBLIGATION',
        scope='Nine complete train-applicable control banks, each exact ordered ID list, plus full inherited tiny diagnostic carrier. No successful prefix qualifies an unfinished bank or main study.')


def _d20_independent_graph_checks(bank, check):
    check(); need(type(bank) is dict and set(bank) == {'schema','expected_receipt_schema',
        'expected_receipt_scope','expected_structural_fields','cases','scope'}
        and bank['schema'] == 'D20-independent-Horn-expected-bank-v1',
        'separately pinned complete independent graph bank')
    need(tuple(bank['expected_structural_fields']) == _D20_STRUCTURAL_FIELDS,
         'all12 declared structural fields, no subset expected oracle')
    cases = bank['cases']; need(type(cases) is list and len(cases) == 17,
                                'complete17 independent graph cases')
    rows = []; ids = set(); counts = dict(ACCEPT=0,REFUSE=0)
    for case in cases:
        check(); need(type(case) is dict and set(case) == {'id','kind','spec','expected','reason'}
             and type(case['id']) is str and case['id'] not in ids and case['kind'] in counts,
             'exact distinct independent fixture carrier')
        ids.add(case['id']); counts[case['kind']] += 1
        if case['kind'] == 'ACCEPT':
            need(type(case['expected']) is dict and set(case['expected']) == set(_D20_STRUCTURAL_FIELDS),
                 'complete independent structural expected receipt')
            actual = conditional_corpus_reference.classify_input(case['spec'],check=check)
            expected = dict(schema=bank['expected_receipt_schema'],scope=bank['expected_receipt_scope'],**case['expected'])
            need(_same_wire(actual,expected,check),'exact independent full graph receipt '+case['id'])
            rows.append(dict(id=case['id'],kind='ACCEPT',status='PASSED',spec=case['spec'],
                             expected=expected,actual=actual,reason=case['reason']))
        else:
            expected = case['expected']
            need(type(expected) is dict and set(expected) == {'type','owned','message'}
                 and expected['type'] == 'CorpusFormatError' and expected['owned'] is True
                 and type(expected['message']) is str,'exact independent owned refusal expectation')
            caught = None
            try:
                conditional_corpus_reference.classify_input(case['spec'],check=check)
            except BaseException as error:
                # Only the classifier's privately owned format refusal is an
                # expected diagnostic. Root and all foreign objects escape.
                if not conditional_corpus_reference.is_owned_error(error):
                    raise
                caught = error
            check(); need(caught is not None and type(caught).__name__ == expected['type']
                          and str(caught) == expected['message'],'exact independent owned refusal')
            rows.append(dict(id=case['id'],kind='REFUSE',status='PASSED',spec=case['spec'],
                expected=expected,actual=dict(type=type(caught).__name__,owned=True,message=str(caught)),reason=case['reason']))
            caught.__traceback__ = None
    need(counts == dict(ACCEPT=12,REFUSE=5),'fixed independent12positive/5refusal population')
    return dict(schema='D20-independent-Horn-actual-checks-v1',complete=True,count=17,
        accepted_cases=12,refusal_cases=5,controls=rows,
        scope='Independent literal full graph-field expectations, distinct17-case denominator. Input-theory structure only, no theorem proof, corpus pruning, learned feature or donor acquisition.')


def _d20_corpus_first_fault_checks(document, check):
    rows = []
    for index in range(2):
        check()
        first = (RuntimeError('D20 intentional first foreign callback') if index == 0 else
                 conditional_corpus_reference.CorpusFormatError('D20 foreign same-public-class callback'))
        following = ValueError('D20 forbidden post-first-fault nested callback')
        need(not conditional_corpus_reference.is_owned_error(first), 'diagnostic first error is foreign to the corpus')
        state = dict(fired=False,postfault_nested_checks=0,trigger=None)
        def interrupt_outer():
            check()
            if state['fired']:
                state['postfault_nested_checks'] += 1
                raise following
            frame = sys._getframe(1)
            try:
                at_site = (frame.f_code.co_name == 'interrupt' and
                           frame.f_code.co_qualname == 'run_contract_controls.<locals>.interrupt' and
                           frame.f_globals is conditional_corpus_reference.__dict__)
            finally:
                del frame
            if at_site:
                state['fired'] = True; state['trigger'] = 'corpus nested interrupt before its intentional sentinel'
                raise first
        caught = None
        try:
            conditional_corpus_reference.run_contract_controls(document,check=interrupt_outer)
        except BaseException as error:
            if error is not first:
                raise
            caught = error
        need(caught is first and state['fired'] and state['postfault_nested_checks'] == 0,
             'first unexpected foreign identity escapes without an intervening nested callback')
        first.__traceback__ = None
        check(); rows.append(dict(id='unexpected-first-foreign-'+str(index),status='PASSED',
            first_type=type(first).__name__,exact_first_identity_preserved=True,
            postfault_nested_checks=0,trigger=state['trigger'],
            corpus_bank_completed=False,prefix_admitted=False))
        interrupt_outer = None; caught = None
    return dict(schema='D20-corpus-harness-first-foreign-identity-controls-v1',complete=True,count=2,
        controls=rows,
        scope='Two synthetic unexpected-first-fault diagnostics. Full corpus prefixes repeat as charged diagnostic work and grant no extra305-row pass, corpus result, learner episode or prefix admission. No classifier/module monkeypatch. sys._getframe detects this harness fault site only, never a policy feature.')


def run_conditional_qualification(document, *, independent_graph_bank, check, limits, modules, oracle):
    """Complete standalone pretraining control qualification, never a learner."""
    owner = getattr(oracle,'qualification_progress',None)
    if type(owner) is not list or owner:
        check(); need(False,'Root-owned empty qualification progress list required')
    progress = dict(schema='D20-qualification-progress-v1',stage='qualify',stage_id='qualify-controls-0',
        status='STARTED',complete=False,groups=[],qualified_prefix=False,
        scope='Ordinary diagnostic retention only; any failure prevents whole qualification and main-stage intake.')
    owner.append(progress)
    check(); began = time.perf_counter()
    need(set(modules) == set(MODULE_ROLES) and _same_wire(limits,LIMITS,check)
         and not oracle.records and getattr(oracle,'guard_compilations',None) == [],
         'unchanged roles/limits and cold qualification, no proof query or compiler ledger')
    original = _checked_literal(document,check); bank_before = _checked_literal(independent_graph_bank,check)
    validation = conditional_corpus_reference.validate_training(document,check=check)
    progress['input_validation'] = validation
    group = dict(id='inherited_fixed_train_controls',status='STARTED',receipt=None); progress['groups'].append(group)
    controls = _fixed_controls('train',document,modules,oracle,check,limits)
    group.update(status='COMPLETED',receipt=dict(controls))
    for key,operation in (
        ('conditional_numeric',lambda:conditional_numeric_reference.run_numeric_controls(conditional_selector,check=check)),
        ('conditional_semantic',lambda:conditional_semantic_reference.run_conditional_semantic_controls(sys.modules[__name__],check=check)),
        ('conditional_corpus',lambda:conditional_corpus_reference.run_contract_controls(document,check=check))):
        check(); group = dict(id=key,status='STARTED',receipt=None); progress['groups'].append(group)
        receipt = operation(); need(receipt['complete'] is True,'whole qualification bank returned complete')
        controls[key] = receipt; group.update(status='COMPLETED',receipt=receipt)
    controls['conditional_corpus_status'] = 'COMPLETE_TRAINING_ONLY_CONTROLS'
    controls['conditional_corpus_scope'] = 'Qualification prospectively runs the same31 train-applicable controls on the full physical training input. Inherited D19 schema/training-stage scope text is retained verbatim; this is not a real training episode. No evaluation/acquisition/policy payload. Corrected owned-control Source is separately pinned.'
    inventory = _d20_bank_inventory(controls,check)
    check(); group = dict(id='independent_graph_bank',status='STARTED',receipt=None); progress['groups'].append(group)
    independent = _d20_independent_graph_checks(independent_graph_bank,check); group.update(status='COMPLETED',receipt=independent)
    check(); group = dict(id='unexpected_first_faults',status='STARTED',receipt=None); progress['groups'].append(group)
    faults = _d20_corpus_first_fault_checks(document,check); group.update(status='COMPLETED',receipt=faults)
    check(); need(_same_wire(document,original,check) and _same_wire(independent_graph_bank,bank_before,check),
                  'qualification physical inputs remain exact')
    need(not oracle.records and getattr(oracle,'guard_compilations',None) == [],
         'qualification makes no Native proof/licence request and constructs no target compiler/model')
    progress.update(status='COMPLETE',complete=True)
    return dict(schema=QUALIFICATION_VERSION,stage='qualify',stage_id='qualify-controls-0',
        status='COMPLETE_PRETRAINING_CONTROL_QUALIFICATION',stage_complete=True,job_record_complete=True,
        resource_admitted=False,export=None,inputs=original,independent_graph_bank=bank_before,
        limits=_checked_literal(limits,check),format_check=validation,controls=controls,
        control_bank_inventory=inventory,independent_graph_checks=independent,first_fault_checks=faults,
        denominators=dict(train_applicable_rows=305,independent_graph_cases=17,unexpected_first_fault_cases=2,
                          inherited_diagnostic_carrier=True),
        donor_acquisition_performed=False,target_model_or_search_performed=False,
        real_training_episode_performed=False,learned_policy_exported=False,native_records=[],
        seconds=time.perf_counter()-began,
        scope='Fresh once-only qualification prerequisite, not a donor/library/policy/evaluation or proof admission. Synthetic tiny model/kernel/Graph controls retain original scopes; no real target model or search. Whole Root resource and independent actual gates remain separate. Future34mainjobs/32episodes/192slots retain original semantics and budgets; this additional prerequisite cost is explicit.')
