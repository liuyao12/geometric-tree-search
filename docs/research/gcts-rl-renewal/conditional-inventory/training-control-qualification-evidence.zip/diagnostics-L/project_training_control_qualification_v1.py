"""Project this once D20 qualification from complete JSON, after Source review.

No scientific module imports, classifier/control/numeric/RNG replay or admission
creation. Explicit current paths only; no directory scan or partial parsing.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

STUDY = Path(__file__).resolve().parents[1]
CASE = 'qualify-controls-0'
RESULT_SHA = '3c40d411e9a73b59b10c11649e9da2ab7955ab8474108f257e7727bcf6d4f358'
BANK_SHA = '914cc9a31ca9f22176087811b6ae4f768b622cc296031aec95cc0df0a6da44b2'
ROOT_SCHEMA = 'D20-Root-training-control-qualification-admission-v1'
REVIEW_SCHEMA = 'D20-C-training-control-qualification-actual-review-v1'
GROUPS = (('numeric',23),('word',48),('graph',22),('encoding',40),
          ('principal',53),('matched_symbolic',13),('conditional_numeric',57),
          ('conditional_semantic',18),('conditional_corpus',31))
DENOMINATORS = dict(train_applicable_rows=305,independent_graph_cases=17,
                    unexpected_first_fault_cases=2,inherited_diagnostic_carrier=True)
GATES = ('admitted','resource_admitted','scientific_qualified','stage_complete')


def need(value,message):
    if not value:
        raise ValueError(message)


def literal(value):
    """Typed literal JSON equality; never infer a graph or numeric update."""
    return json.dumps(value,sort_keys=True,separators=(',',':'),
                      ensure_ascii=True,allow_nan=False)


class Saved:
    def __init__(self):
        self.inputs = {}

    def raw_pin(self,path):
        path = Path(path).resolve(); body = path.read_bytes()
        row = dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
        old = self.inputs.get(str(path))
        need(old is None or old == row,'complete raw input changed')
        self.inputs[str(path)] = row
        return row

    def read_json(self,path):
        path = Path(path).resolve()
        need('.partial' not in path.name,'partial content is never parsed')
        row = self.raw_pin(path); body = path.read_bytes()
        need(hashlib.sha256(body).hexdigest()==row['sha256'],'stable complete JSON read')
        return json.loads(body)

    def declared_pin(self,row,path=None):
        need(type(row) is dict and set(row)=={'path','bytes','sha256'},'exact complete raw pin')
        if path is not None:
            need(row['path']==str(Path(path).resolve()),'fixed current canonical path')
        need(self.raw_pin(row['path'])==row,'declared raw input matches')
        return row

    def stable(self):
        for row in tuple(self.inputs.values()):
            need(self.raw_pin(row['path'])==row,'final raw stability')


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('plan','result','header','terminal','observer','admission','C-review','bank','output'):
        parser.add_argument('--'+name,required=True,type=Path)
    return parser.parse_args()


def main():
    args = parse_args(); saved = Saved()
    actual = STUDY/'actual'/CASE; observer_dir = STUDY/'actual'/(CASE+'.observer')
    fixed = dict(plan=STUDY/'root/plans'/(CASE+'-v1.json'),result=actual/'result.json',
        header=actual/'worker-header.json',terminal=actual/'terminal.json',
        observer=observer_dir/'observer.json',admission=STUDY/'root/admission'/(CASE+'-v1.json'),
        bank=STUDY/'inputs/independent-Horn-expected-bank-v1.json',
        output=STUDY/'publication/training-control-qualification-data.json')
    for name,path in fixed.items():
        need(getattr(args,name).resolve()==path.resolve(),'exact current '+name+' path')
    review_path = args.C_review.resolve()
    need(review_path.is_relative_to(STUDY/'review-C') and review_path.suffix=='.json',
         'explicit current task C review path')
    plan = saved.read_json(args.plan); result = saved.read_json(args.result)
    header = saved.read_json(args.header); terminal = saved.read_json(args.terminal)
    observer = saved.read_json(args.observer); admission = saved.read_json(args.admission)
    review = saved.read_json(review_path); bank = saved.read_json(args.bank)
    need(saved.raw_pin(args.result)['sha256']==RESULT_SHA,'this exact complete once actual')
    need(saved.raw_pin(args.bank)['sha256']==BANK_SHA,'exact independently authored17case bank')
    need(admission['schema']==ROOT_SCHEMA and admission['case_id']==CASE,'current Root decision')
    need(review['schema']==REVIEW_SCHEMA,'current independent actual review')
    need(all(type(admission[k]) is bool for k in GATES),'typed Root whole gates')
    need(type(review['review_passed']) is bool and review['review_passed'] is True,
         'passed independent actual classification review')
    for name in ('resource_admitted','scientific_qualified','stage_complete'):
        need(type(review[name]) is bool and review[name] is admission[name],
             'same Root/independent '+name+' gate')
    need(admission['admitted'] is all(admission[k] for k in GATES[1:]),'Root gate conjunction')
    for name in ('plan','result','header','terminal','observer'):
        saved.declared_pin(admission[name],getattr(args,name))
        need(literal(review[name])==literal(admission[name]),'same reviewed current '+name+' pin')
    saved.declared_pin(admission['C_actual_review'],review_path)
    for name in ('protocol','prospective_review'):
        saved.declared_pin(admission[name])
    need(literal(admission['qualification_counts'])==literal(DENOMINATORS),'complete separate denominators')
    need(admission['acquisition_seal'] is None and admission['policy_seal'] is None,
         'qualification creates no donor or policy seal')
    need(plan['case_id']==CASE and plan['stage']=='qualify','exact fixed qualification plan')
    need(literal(plan['protocol'])==literal(admission['protocol']),'same protocol pin')
    need(literal(review['input_pins'])==literal(plan['files']),'independently reviewed exact input closure')
    for row in plan['files']:
        saved.declared_pin(row)
    for name in ('input_path','independent_graph_bank_path'):
        need(str(Path(plan[name]).resolve()) in {row['path'] for row in plan['files']},
             'phase/bank belongs to exact guarded input closure')
    need(Path(plan['independent_graph_bank_path']).resolve()==args.bank.resolve(),'same original case bank')
    training = saved.read_json(plan['input_path'])

    need(result['case_id']==CASE and result['stage']=='qualify' and result['status']=='COMPLETE'
         and result['error'] is None and result['first_Root_fault'] is False
         and result['source_unchanged'] is True,'complete successful worker packet')
    need(result['native_requests_started']==0 and result['native_queries']==[]
         and result['work_snapshots']==[],'no Native query or real episode snapshots')
    transport = result['native_transport']
    need(transport['closed'] is True and transport['all_reaped'] is True
         and transport['native_exit_code']==0 and transport['cleanup_errors']==[],
         'owned Native constructor closed and reaped')
    need(header['status']=='COMPLETE' and header['case_id']==CASE
         and header['native_closed_and_reaped'] is True and header['first_Root_fault'] is False,
         'complete current worker header')
    need(literal(header['result'])==literal(saved.raw_pin(args.result)),'header result pin')
    need(terminal['process_exit_code']==0 and terminal['header_valid'] is True
         and terminal['errors']==[] and terminal['final_custody_gate_passed'] is True
         and terminal['threads_terminal'] is True and terminal['sources_unchanged'] is True,
         'complete positive parent custody packet')
    need(literal(terminal['header'])==literal(header)
         and literal(terminal['result'])==literal(saved.raw_pin(args.result)),
         'same complete header/result in terminal')
    need(observer['parent_exit_code']==0 and observer['errors']==[]
         and observer['resource_candidate_accepted'] is True
         and observer['fallback_trigger_seconds'] is None,'complete positive observer resource packet')
    need(observer['owned_child']['plan_sha256']==saved.raw_pin(args.plan)['sha256'],
         'same owned plan through observer')
    need(admission['whole_seconds']==observer['elapsed_seconds']
         and admission['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes'],
         'Root uses observer sample and final whole peak distinctly')
    need(review['whole_seconds']==admission['whole_seconds']
         and review['whole_peak_bytes']==admission['whole_peak_bytes'],'same independently reviewed costs')

    census = admission['physical_census']
    need(type(census) is dict and census['includes_complete_actual_and_observer'] is True,
         'explicit postterminal complete physical census')
    need(type(census['files']) is list and len({r['path'] for r in census['files']})==len(census['files']),
         'unique complete actual census identities')
    for row in census['files']:
        path = Path(row['path']).resolve()
        need(path.is_relative_to(actual) or path.is_relative_to(observer_dir),'census current owned roots only')
        saved.declared_pin(row)
    need(sum(row['bytes'] for row in census['files'])==census['total_bytes'],
         'postterminal whole physical total from complete raw census, not earlier sample')
    reviewed_census = review['physical_census']
    need(literal(sorted(census['files'],key=lambda r:r['path']))==
         literal(sorted(reviewed_census['files'],key=lambda r:r['path']))
         and reviewed_census['total_bytes']==census['total_bytes']
         and reviewed_census['file_count']==len(census['files']),
         'same independently reviewed complete postterminal census')
    for name in ('result','header','terminal','observer'):
        need(saved.raw_pin(getattr(args,name)) in census['files'],'census includes current '+name)

    science = result['scientific_result']
    need(science['schema']=='gcts-conditional-selector-pretraining-qualification-v1'
         and science['stage']=='qualify' and science['stage_id']==CASE
         and science['status']=='COMPLETE_PRETRAINING_CONTROL_QUALIFICATION'
         and science['job_record_complete'] is True and science['stage_complete'] is True,
         'complete current qualification scientific carrier')
    need(literal(science['denominators'])==literal(DENOMINATORS),'same saved separate counts')
    need(literal(science['inputs'])==literal(training)
         and literal(science['independent_graph_bank'])==literal(bank),'exact current literal inputs')
    need(science['native_records']==[] and science['export'] is None
         and science['donor_acquisition_performed'] is False
         and science['real_training_episode_performed'] is False
         and science['target_model_or_search_performed'] is False
         and science['learned_policy_exported'] is False,'no proof/learning/export action adopted')
    controls = science['controls']; inventory = science['control_bank_inventory']
    need(inventory['complete'] is True and inventory['enumerated_rows']==305
         and inventory['inherited_diagnostic_carrier_retained'] is True,'all original banks preserved')
    need([(r['bank'],r['count']) for r in inventory['banks']]==list(GROUPS),
         'all nine exact original bank denominators and order')
    groups = []
    for declaration in inventory['banks']:
        name = declaration['bank']; receipt = controls[name]; rows = receipt['controls']
        need(receipt['complete'] is True and len(rows)==declaration['count']
             and [r['id'] for r in rows]==declaration['control_ids']
             and receipt['schema']==declaration['schema'],'complete original '+name+' receipt')
        for row in rows:
            need(row.get('status')=='PASSED' or row.get('passed') is True,
                 'literal reported pass carrier, no computation')
        groups.append(dict(id=name,label=name,expected_count=declaration['count'],
            returned_count=len(rows),status='COMPLETE_REPORTED_PASSED',receipt=copy.deepcopy(receipt)))
    inherited = controls['inherited']
    need(type(inherited) is dict and inherited['status']=='complete','inherited diagnostic carrier retained')
    independent = science['independent_graph_checks']
    need(independent['complete'] is True and independent['count']==17
         and independent['accepted_cases']==12 and independent['refusal_cases']==5,
         'all independent cases remain distinct')
    need([r['id'] for r in independent['controls']]==[r['id'] for r in bank['cases']],
         'all exact17 case IDs in declared order')
    case_results = []
    for declared,observed in zip(bank['cases'],independent['controls']):
        need(observed['status']=='PASSED' and observed['kind']==declared['kind']
             and literal(observed['spec'])==literal(declared['spec'])
             and observed['reason']==declared['reason'],'same literal independent case')
        expected = copy.deepcopy(declared['expected'])
        if declared['kind']=='ACCEPT':
            expected.update(schema=bank['expected_receipt_schema'],scope=bank['expected_receipt_scope'])
        need(literal(observed['expected'])==literal(expected)
             and literal(observed['actual'])==literal(expected),
             'saved complete expected/actual literal equality; no classifier call')
        case_results.append(dict(id=declared['id'],status=observed['status'],
            actual=copy.deepcopy(observed['actual']) if declared['kind']=='ACCEPT' else None,
            refusal=copy.deepcopy(observed['actual']) if declared['kind']=='REFUSE' else None,
            receipt=copy.deepcopy(observed)))
    faults = science['first_fault_checks']
    need(faults['complete'] is True and faults['count']==2 and len(faults['controls'])==2,
         'two foreign-fault diagnostics distinct from305 original rows')
    for ordinal,row in enumerate(faults['controls']):
        need(row['id']=='unexpected-first-foreign-'+str(ordinal) and row['status']=='PASSED'
             and row['exact_first_identity_preserved'] is True and row['postfault_nested_checks']==0
             and row['prefix_admitted'] is False and row['corpus_bank_completed'] is False,
             'saved first-fault identity result, no prefix adoption')

    admitted = admission['admitted']
    output = dict(schema='D20-training-control-qualification-reader-v1',
        status_text=('Once control qualification admitted. All original305 rows,17 independently expected cases and2 foreign diagnostics returned complete.'
                     if admitted else 'Complete qualification packet retained as diagnostic; Root whole qualification is not admitted.'),
        summary=dict(original_rows_returned=305,independent_cases_returned=17,fault_diagnostics_returned=2),
        admission=admission,
        claim_scope='Finite control qualification only. No new target proof, donor acquisition, real training episode, learner policy or empirical learned comparison. D19 remains closed with its original failed training job and unavailable dependent population.',
        original_banks=groups,inherited_carrier=copy.deepcopy(inherited),expected_bank=bank,
        case_results=case_results,fault_diagnostics=copy.deepcopy(faults['controls']),
        costs=dict(observer_sample_seconds=observer['elapsed_seconds'],
            whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],
            worker_elapsed_seconds=result['elapsed_seconds'],callbacks=result['callbacks'],
            Native_started=result['native_requests_started'],physical_bytes=census['total_bytes']),
        cost_scope='One cold qualification actual counted once. Observer elapsed is the before-final-receipt sample, distinct from final_observer_gate_seconds and tool end-to-end. Physical bytes come from the complete postterminal actual-plus-observer census, not stored_bytes_before_observer_receipt. Nested control/entry/worker/custody clocks overlap and are not summed.',
        failure=None,
        evidence=dict(plan=saved.raw_pin(args.plan),result=saved.raw_pin(args.result),
            header=saved.raw_pin(args.header),terminal=saved.raw_pin(args.terminal),
            observer=saved.raw_pin(args.observer),Root_admission=saved.raw_pin(args.admission),
            C_actual_review=saved.raw_pin(review_path),expected_bank=saved.raw_pin(args.bank),
            full_raw_control_receipts=copy.deepcopy(controls),
            full_raw_independent_receipt=copy.deepcopy(independent),
            full_raw_first_fault_receipt=copy.deepcopy(faults),
            full_raw_format_receipt=copy.deepcopy(science['format_check']),
            physical_census=copy.deepcopy(census),
            clocks=dict(entry_seconds=science['seconds'],worker_header_seconds=header['seconds'],
                parent_final_custody_gate_seconds=terminal['final_custody_gate_seconds'],
                observer_elapsed_sample=observer['elapsed_seconds'],
                observer_final_gate_seconds=observer['final_observer_gate_seconds']),
            limits=copy.deepcopy(plan['limits']),experiment_limits=copy.deepcopy(plan['experiment_limits'])),
        scientific_imports=0,scientific_calls=0,classifier_replays=0,control_replays=0,
        numeric_RNG_replays=0,partial_files_parsed=0)
    saved.stable(); output['evidence']['input_pins'] = list(saved.inputs.values())
    body = (json.dumps(output,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(body)
    print(json.dumps(dict(path=str(args.output.resolve()),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())))


if __name__=='__main__':
    main()
