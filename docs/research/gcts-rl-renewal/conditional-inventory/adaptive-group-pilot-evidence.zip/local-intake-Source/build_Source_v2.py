"""Raw relocation-only successor; imports no scientific or previous runner code."""
import ast,hashlib,json
from pathlib import Path
D=Path(__file__).parent;P=Path('/private/tmp/gcts-adaptive-group-intake-ROOT-source-20261019');L=Path('/private/tmp/gcts-local-operational-20261019')
def pin(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def const(s,name,value):
 a=s.index(name+' = ');b=s.index('\n',a);return s[:a]+name+' = '+repr(value)+s[b:]
def save(name,s):
 ast.parse(s);compile(s,name,'exec');p=D/name;assert not p.exists();p.write_text(s);return pin(p)
s=(P/'adaptive_group_cold_v1.py').read_text();s=const(s,'VERSION','adaptive-group-local-intake-cold-v2');s=const(s,'PARENT_RUNTIME_CLOSURE',pin(L/'parent-runtime-closure.json'));cold=save('adaptive_group_local_cold_v2.py',s)
s=(P/'adaptive_group_once_runner_v1.py').read_text();s=const(s,'VERSION','adaptive-group-local-external-once-runner-v2');s=const(s,'COLD_PIN',cold);runner=save('adaptive_group_local_once_runner_v2.py',s)
s=(P/'observe_adaptive_group_runner_v1.py').read_text();s=const(s,'VERSION','adaptive-group-local-final-terminal-observer-v2');old=pin(P/'adaptive_group_once_runner_v1.py');assert s.count(old['sha256'])==1;s=s.replace(old['sha256'],runner['sha256']);observer=save('observe_adaptive_group_local_runner_v2.py',s)
checks=[]
for a,b in [('adaptive_group_cold_v1.py','adaptive_group_local_cold_v2.py'),('adaptive_group_once_runner_v1.py','adaptive_group_local_once_runner_v2.py'),('observe_adaptive_group_runner_v1.py','observe_adaptive_group_local_runner_v2.py')]:
 x={n.name:ast.dump(n,include_attributes=False)for n in ast.parse((P/a).read_bytes()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))};y={n.name:ast.dump(n,include_attributes=False)for n in ast.parse((D/b).read_bytes()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
 for name,body in x.items():
  # Observer main changes only the pinned runner SHA string.
  if a.startswith('observe_') and name=='main':continue
  assert body==y[name];checks.append(dict(callable=name,source=b,unchanged_ast=True))
c=dict(schema='ROOT-adaptive-group-local-intake-Source-contract-v2',author_identity='/root',source_only=True,scientific_calls=0,module_evaluations=0,actual_execution_authorized=False,cold=cold,runner=runner,observer=observer,parent_closure=pin(L/'parent-runtime-closure.json'),parents={p.name:pin(p)for p in [P/'adaptive_group_cold_v1.py',P/'adaptive_group_once_runner_v1.py',P/'observe_adaptive_group_runner_v1.py']if p.exists()},unchanged_callable_checks=checks,
 repair='Move operational metadata and actual output entirely to private/tmp. Replace cold parent-closure descriptor with a byte-identical local clone. Once cold pin/observer runner pin and VERSIONs follow. No scientific algorithm, driver/registry, data/signature/catalogue/inventory, scheduler or cap changes.',
 previous_attempt='Original observer attempt terminal timeout225s before any actual worker marker. Consumed observer/grant not reused; preserved as launch/resource failure. This successor requires a new explicit subject and declaration, not re-execution of old slot.',
 limits='Original180/210s,1GiB conservative worker+Native peak,128MiB result,4MiB each log,5e9 registration; all old lifecycle and error/UNKNOWN bodies retained.',
 remaining_limitation='Blocking system calls are not formally interruptible; existing observer bounds failure and never admits after210. Local metadata avoids the observed dataless-document hydration path. No new pre-marker journal is claimed.')
p=D/'Source-contract-v2.json';p.write_text(json.dumps(c,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(contract=pin(p),cold=cold,runner=runner,observer=observer,unchanged_callables=len(checks))))
