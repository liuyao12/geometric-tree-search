"""Author metadata only. Parses/compiles Source without evaluating any module."""
from pathlib import Path
import ast, difflib, hashlib, json, subprocess
ROOT=Path('/private/tmp/gcts-recursive-receptor-source-20261019')
PARENT=Path('/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py')
checks=[]
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def keep(label,ok,scope):
    checks.append(dict(check=label,passed=bool(ok),scope=scope))
    if not ok: raise AssertionError(label)
def write(name,data):
    p=ROOT/name;p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');return pin(p)
def regions(p):
    text=p.read_text();tree=ast.parse(text,filename=str(p));result={}
    def visit(n,prefix=''):
        for c in ast.iter_child_nodes(n):
            if isinstance(c,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                name=prefix+c.name
                raw=ast.get_source_segment(text,c)
                result[name]=dict(raw_sha256=hashlib.sha256(raw.encode()).hexdigest(),ast_sha256=hashlib.sha256(ast.dump(c,include_attributes=False).encode()).hexdigest(),line=c.lineno,end_line=c.end_lineno)
                visit(c,name+'.')
            else:visit(c,prefix)
    visit(tree);return result,tree
planner=ROOT/'recursive_receptor_planner_v1.py';search=ROOT/'semantic_inventory_search_v3.py'
for p in (planner,search):
    text=p.read_text();ast.parse(text,filename=str(p));compile(text,str(p),'exec',dont_inherit=True)
    keep('compile_without_eval:'+p.name,True,'No compiled code object evaluated or imported.')
old,ot=regions(PARENT);new,nt=regions(search);pr,pt=regions(planner)
retained=[]
for name in old:
    if name not in ('search','search.visit'):
        keep('retained_raw_AST:'+name,old[name]['raw_sha256']==new[name]['raw_sha256'] and old[name]['ast_sha256']==new[name]['ast_sha256'],'Parent inherited callable exact; search and its branch visit own explicit delta.')
        retained.append(name)
oldtext=PARENT.read_text();newtext=search.read_text()
for label,segment in {
 'scheduler_global_decision':"kind,p,keys=g.decision(state);metrics['nodes']+=1",
 'dead_empty_forced_order':"if kind=='dead':metrics['dead']+=1;return False,tree\n        if kind=='empty':found=state;return True,tree\n        metrics[kind]+=1",
 'old_Join_pool':"stage=time.perf_counter();items,work=join(state,g,p,proposal_limit,proposal_checks)\n            for k,v in work.items():metrics[k]+=v",
 'unchanged_scorer':"features=[vector(item,model,state,g) for item in items];item,event=choose(items,features,scoring,rng,stochastic)",
 'incident_preference_full_fallback':"preferred=set(trace['eligible']) if active else set();alternatives=keys if kind=='forced' else [k for k in keys if k in preferred]+[k for k in keys if k not in preferred];tree['alternatives']=alternatives",
 'single_key_copy_update':"metrics['attempts']+=1;child=state.copy();cg=g.copy();cg.update(model,child,child.place(model.placement(k)));ok,sub=visit(child,cg,active);tree['children'].append(dict(key=k,role='member' if k in preferred else 'base',tree=sub))",
 'root_rollback':"ok,tree=visit(initial,graph,None);restored=fingerprint(initial)==root_state and graph.fingerprint()==root_graph\n    if not restored:raise ValueError('state/graph rollback')",
 'current_hint_revalidation':"if aggregate(model,item['members'],state)!={k:item[k] for k in ('members','pending','aggregate_sha256','new_occupancy','new_marks')}:raise ValueError('invalid row aggregate')"
}.items():keep(label,segment in oldtext and segment in newtext,'Exact literal parent segment retained; this is static conformance evidence only.')
imports=[]
for n in ast.walk(pt):
    if isinstance(n,ast.Import):imports += [a.name for a in n.names]
    elif isinstance(n,ast.ImportFrom):imports.append(n.module)
keep('planner_stdlib_imports_only',set(imports)=={'collections','json','math'},'No project/Model/Native/search/compiler imports.')
methods=[n for n in ast.walk(pt) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id in ('state','graph') and n.func.attr in ('place','update','copy')]
keep('no_State_Graph_mutator_calls',not methods,'No native state placement or graph mutation in planner; assignments confined to owned maps/metadata.')
keep('no_Target_case_IDs',not any(x in planner.read_text() for x in ('fol-suite-','P(x)','c3-fixed','targetproof')),'Generic literal rule-guard/interface enumeration, no saved proof or theorem route input.')
keep('private_owner_quota_only_handlers',all(isinstance(h.type,ast.Name) and h.type.id=='_Quota' for n in ast.walk(pt) if isinstance(n,ast.Try) for h in n.handlers),'Delegated callback/schema/Source errors are not normalized by broad exception handlers.')
patches=[]
for label,before,after,filename in [('planner-add',b'',planner.read_bytes(),planner.name),('search-successor',PARENT.read_bytes(),search.read_bytes(),search.name)]:
    pre=ROOT/(label+'-preimage.txt');pre.write_bytes(before)
    forward=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile=filename,tofile=filename))
    reverse=''.join(difflib.unified_diff(after.decode().splitlines(True),before.decode().splitlines(True),fromfile=filename,tofile=filename))
    fp=ROOT/(label+'-forward.patch');rp=ROOT/(label+'-inverse.patch');fp.write_text(forward);rp.write_text(reverse)
    work=ROOT/('inert-patch-'+label);work.mkdir(exist_ok=True);dest=work/filename;dest.write_bytes(before)
    f=subprocess.run(['patch','--batch','-F','0',filename,str(fp)],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    keep('real_F0_forward:'+label,f.returncode==0 and dest.read_bytes()==after,'Text-only patch to owned inert scratch file; no scientific function invoked.')
    inv=subprocess.run(['patch','--batch','-F','0',filename,str(rp)],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    # Some patch implementations delete an empty final file. Empty preimage is the exact text lineage.
    restored=dest.read_bytes() if dest.exists() else b''
    keep('real_F0_inverse:'+label,inv.returncode==0 and restored==before,'Full raw preimage restored; add-file lineage starts with empty text, not an earlier algorithm.')
    patches.append(dict(label=label,preimage=pin(pre),forward=pin(fp),inverse=pin(rp),forward_output=f.stdout,inverse_output=inv.stdout,forward_raw_exact=True,inverse_raw_exact=True))
references={
 'master':'/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md',
 'parent_search':str(PARENT),
 'shared_support_helper':'/private/tmp/gcts-and-support-ordering-source-20261018/receptor_support_ordering_v1.py',
 'compact_model':'/private/tmp/gcts-compact-point-representation-source-20261018/interned_quantified_family_points_v1.py',
 'ordinary_model':'/private/tmp/gcts-quantified-adapter-source-20261018/quantified_family_points_v2.py',
 'row_guidance':'/private/tmp/gcts-semantic-family-next-audit-20261018/semantic_inventory_guidance.py',
 'aggregate':'/private/tmp/gcts-semantic-family-next-audit-20261018/native_inference_inventory.py',
 'state_graph':'/private/tmp/gcts-semantic-family-next-audit-20261018/turtle.py',
 'parent_component_review':'/private/tmp/gcts-and-support-ordering-independent-peer-20261018/typed-ordering-components-Source-review-v1.json',
 'current_runtime_closure':'/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/inventory-certification-progress-20261018/runtime-closure-v1.json',
 'design':'/private/tmp/gcts-recursive-cluster-design-20261018/design-v1.json',
 'prior_API':'/private/tmp/gcts-recursive-cluster-design-20261018/API-proposal-v1.json'}
refs={k:pin(v) for k,v in references.items()}
audit=write('author-static-audit-v1.json',dict(schema='recursive-receptor-author-static-audit-v1',author_identity='/root/conventional_library',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,checks=checks,check_count=len(checks),mismatches=0,source_regions=dict(parent=old,successor=new,planner=pr),retained_callable_names=retained,patches=patches,limits='Static author preservation evidence, not independent Source certification or runtime qualification. No module/function/fixture was evaluated.'))
write('source-delta-v1.json',dict(schema='recursive-receptor-source-delta-v1',sources=dict(receptor_planner=pin(planner),point_search=pin(search)),parent=refs['parent_search'],patches=patches,author_static_audit=audit,new_callables=list(pr),retained_parent_callables=retained,changed_parent_callables=['search','search.visit'],integration_modified_regions=['stdlib planner import/version','optional search keyword validation','inside-clock constructor and identity metadata','setup-deadline visit stop','genuine branch after unchanged Join and before unchanged vector/choose','event receipt/result metadata'],unmodified=['all parent top-level helper bodies','nested support_check/review bodies','Graph implementation','State implementation','original Join implementation/pool','feature weights','ordinary candidate universe and domains','forced/dead/success handling','incident full alternative fallback','one-key place+Graph.update with copied State/Graph','exact initial root restoration','decoder and full final gate owned by caller'],references=refs))
write('reference-sources-v1.json',refs)
print(json.dumps(dict(planner=pin(planner),point_search=pin(search),checks=len(checks),audit=audit),indent=2))
