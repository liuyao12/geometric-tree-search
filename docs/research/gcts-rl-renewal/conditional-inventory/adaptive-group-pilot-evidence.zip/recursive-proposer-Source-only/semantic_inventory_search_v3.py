"""Same complete reference scheduler, with branch-local exact cluster ordering."""
import collections,random,time
from native_receptor_points import fingerprint
from native_inventory_policy import choose
from native_inference_inventory import aggregate
from semantic_inventory_guidance import Join,vector,FEATURES,FIXED
from turtle import Graph
from semantic_inventory_guidance import row_requirements
from receptor_support_ordering_v1 import (VERSION as SUPPORT_VERSION,
    STRATEGY as SUPPORT_STRATEGY, GRAPH_SCHEMA, RANK_SCHEMA,
    build_support_graph, rank_support_options)

from recursive_receptor_planner_v1 import (VERSION as RECEPTOR_VERSION,
    ReceptorClosurePlanner)

VERSION = 'semantic-inventory-search-v3-optional-recursive-receptors'
SUPPORT_PROJECTION_WORK_LIMIT = 200000
SUPPORT_WORK_LIMIT = 200000


class _SupportDeadline(TimeoutError):
    """Only this module's own search-clock stop is converted to UNKNOWN."""


class _ProjectionStop(Exception):
    """A finite proposal projection abstains; it removes no original item."""


def _literal(value, charge):
    charge()
    if type(value) is dict:
        if any(type(k) is not str for k in value):
            raise ValueError('literal point projection dictionaries')
        return {k: _literal(v, charge) for k, v in value.items()}
    if type(value) in (list, tuple):
        return [_literal(v, charge) for v in value]
    if value is None or type(value) in (str, int, bool, float):
        return value
    raise ValueError('literal point projection values')


def _complete_rows(model, keys, charge):
    """Project actual complete C/G/all-input rows, without declaring facts.

    The shared helper independently checks literal ordered strict-prior
    requirements and recursively derives justified rows. Guard-only outputs
    and incomplete arbitrary samples never create a row packet here.
    """
    by_row = {}
    for key in sorted(set(keys)):
        charge()
        if key not in model.metadata or len(key) != 4:
            raise ValueError('actual point key required')
        row, role = key[:2]
        if (type(row) is not int or type(role) is not int or
                not 0 <= row < model.spec['length'] or
                not 0 <= role < 2 + model.arity):
            raise ValueError('actual row and declared input role required')
        roles = by_row.setdefault(row, {})
        if role in roles:
            raise ValueError('multiple placements on one row role')
        roles[role] = key
    result = []
    for row, roles in sorted(by_row.items()):
        charge()
        if len(roles) != 2 + model.arity:
            continue
        ordered = []
        for role in range(2 + model.arity):
            charge()
            ordered.append(roles[role])
        requirements = row_requirements(model, ordered, row)
        if requirements is None:
            continue
        command = model.metadata[roles[0]]['command']
        guard = model.metadata[roles[1]]['command']
        if command != guard:
            raise ValueError('complete row C/G agreement')
        result.append(dict(row=row,
            formula=_literal(guard['formula'], charge),
            requirements=_literal(requirements, charge),
            provenance=dict(kind='ACTUAL_COMPLETE_POINT_ROW',
                role_keys=_literal(ordered, charge),
                command=_literal(command, charge))))
    return result


def _support_choice(model, state, items, event, support_graph, check):
    """Rank the unchanged pool; original FIXED score/index breaks all ties."""
    projection = dict(work=0, limit=SUPPORT_PROJECTION_WORK_LIMIT,
                      aggregate_checks=0)
    legacy_order = sorted(range(len(items)),
                          key=lambda i: (-event['scores'][i], i))
    before = event['index']
    receipt = dict(schema='point-and-support-choice-v1',
        status='STABLE_FALLBACK', reason=None,
        legacy_index=before, selected_index=before,
        legacy_order=legacy_order, after_order=legacy_order[:],
        original_policy_scores=event['scores'][:],
        original_policy_probabilities=event['probabilities'][:],
        original_policy_probabilities_scope='Unchanged policy evidence; support ordering is deterministic.',
        projection=projection, validated_aggregates=[], ranking=None)

    def charge():
        check()
        if projection['work'] >= projection['limit']:
            raise _ProjectionStop('point_support_projection_work_budget')
        projection['work'] += 1

    try:
        known = _complete_rows(model, state.selected, charge)
        known_ids = {packet['row'] for packet in known}
        options = []
        for index in legacy_order:
            charge()
            item = items[index]
            rows = []
            if item is not None:
                check()
                actual = aggregate(model, item['members'], state)
                check()
                projection['aggregate_checks'] += 1
                if actual != {k: item[k] for k in
                        ('members', 'pending', 'aggregate_sha256',
                         'new_occupancy', 'new_marks')}:
                    raise ValueError('current support option aggregate')
                receipt['validated_aggregates'].append(dict(
                    original_index=index, aggregate=_literal(actual, charge)))
                union = set(state.selected).union(item['members'])
                rows = [packet for packet in _complete_rows(model, union, charge)
                        if packet['row'] not in known_ids]
            options.append(dict(option_id=dict(original_item_index=index), rows=rows))
        check()
        ranking = rank_support_options(graph=support_graph, known_rows=known,
            options=options, check=check, work_limit=SUPPORT_WORK_LIMIT)
        check()
        if (ranking.get('schema') != RANK_SCHEMA or
                ranking.get('version') != SUPPORT_VERSION or
                ranking.get('strategy') != SUPPORT_STRATEGY or
                ranking.get('status') not in ('SCORED', 'STABLE_FALLBACK')):
            raise ValueError('current shared support ranking protocol')
        order = ranking['order']
        if (type(order) is not list or any(type(i) is not int for i in order) or
                sorted(order) != list(range(len(items)))):
            raise ValueError('all original option multiplicity required')
        if ranking['status'] == 'STABLE_FALLBACK' and order != list(range(len(items))):
            raise ValueError('support abstention must preserve stable policy order')
        after = [legacy_order[i] for i in order]
        receipt.update(status=ranking['status'], reason=ranking['reason'],
                       after_order=after, selected_index=after[0], ranking=ranking)
    except _ProjectionStop:
        receipt['reason'] = 'point_support_projection_work_budget'
    check()
    return items[receipt['selected_index']], receipt


def search(model,mode='base',weights=None,stochastic=False,seed=0,attempts=20000,seconds=60,proposal_limit=24,proposal_checks=2048,support_ordering='legacy',receptor_proposals='legacy',receptor_source_epoch=None,receptor_source_guard=None,receptor_limits=None):
    if mode not in ('base','zero','fixed','learned','no-family'):raise ValueError('ordering lane')
    if support_ordering not in ('legacy','and_support'):raise ValueError('support ordering lane')
    if support_ordering=='and_support' and (mode!='fixed' or stochastic):raise ValueError('AND support requires deterministic fixed mode')
    if receptor_proposals not in ('legacy','recursive_receptors'):raise ValueError('recursive receptor proposal lane')
    if receptor_proposals=='recursive_receptors' and (mode!='fixed' or stochastic):raise ValueError('recursive receptors require deterministic fixed mode')
    if receptor_proposals=='recursive_receptors' and (type(receptor_source_epoch) is not dict or not callable(receptor_source_guard)):raise ValueError('recursive receptor current Source custody required')
    if mode in ('learned','no-family') and (weights is None or len(weights)!=len(FEATURES)):raise ValueError('policy dimension')
    scoring=[0.]*len(FEATURES) if mode=='zero' else list(FIXED) if mode=='fixed' else list(weights) if weights is not None else None
    began=time.perf_counter();initial=model.initial();graph=Graph(model,initial);root_state=fingerprint(initial);root_graph=graph.fingerprint();metrics=collections.Counter();events=[];hints=[];found=None;rng=random.Random(seed);join=Join(model,mode!='no-family')
    support_graph=None;support_stopped=False
    support_metadata=dict(schema='point-and-support-metadata-v1',version=VERSION,
        ordering=support_ordering,strategy=SUPPORT_STRATEGY,
        status='LEGACY_DISABLED',graph=None,graph_seconds=0.,
        helper_work_limit=SUPPORT_WORK_LIMIT,
        projection_work_limit=SUPPORT_PROJECTION_WORK_LIMIT,
        choice_receipts='Each applicable events[i].support_ordering retains full literal ranking evidence.',
        logical_authority=False,candidate_pruning=False,
        scope='Ordering existing validated Join items only; no new proposer, fact, marking, rule or bulk placement.')
    def support_check():
        if time.perf_counter()-began>=seconds:
            raise _SupportDeadline('point_support_search_deadline')
    if support_ordering=='and_support':
        if SUPPORT_VERSION!='receptor-and-support-ordering-v1' or SUPPORT_STRATEGY!='ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1':raise ValueError('shared support implementation')
        stage=time.perf_counter()
        try:
            support_check()
            support_graph=build_support_graph(spec=model.spec,compiled=model.compiled,
                inventory=model.inventory,check=support_check,work_limit=SUPPORT_WORK_LIMIT)
            support_check()
            if (support_graph.get('schema')!=GRAPH_SCHEMA or support_graph.get('version')!=SUPPORT_VERSION or support_graph.get('strategy')!=SUPPORT_STRATEGY or support_graph.get('status') not in ('COMPLETE','UNKNOWN_WORK_BUDGET')):raise ValueError('current shared support graph protocol')
            support_metadata.update(status=support_graph['status'],graph=support_graph)
            metrics['support_graph_work']+=support_graph['counts']['work']
        except _SupportDeadline:
            support_stopped=True;support_metadata['status']='UNKNOWN_SEARCH_DEADLINE';metrics['support_deadline_stops']+=1
        support_metadata['graph_seconds']=time.perf_counter()-stage
    receptor_planner=None;receptor_stopped=False
    receptor_metadata=dict(schema='point-recursive-receptor-metadata-v1',version=VERSION,
        proposer_version=RECEPTOR_VERSION,mode=receptor_proposals,status='LEGACY_DISABLED',
        identity=None,setup_seconds=0.,proposal_receipts='Each applicable event.receptor_proposals retains the literal proposal prefix and current packet/union reconstruction.',
        model_record_custody='Caller retains the entire ordinary Model record and its current Source/input identity; no snapshot digest alone authenticates a tile.',
        authority='Ordering advice only; no independent mathematical check, new rule/fact/candidate, pruning, bulk placement or degree authority.')
    if receptor_proposals=='recursive_receptors' and not support_stopped:
        stage=time.perf_counter()
        try:
            support_check()
            receptor_planner=ReceptorClosurePlanner(model,source_epoch=receptor_source_epoch,
                source_guard=receptor_source_guard,check=support_check,
                aggregate=aggregate,row_requirements=row_requirements,limits=receptor_limits)
            support_check()
            receptor_metadata['identity']=receptor_planner.identity_record()
            receptor_metadata['status']=receptor_metadata['identity']['setup']['status']
        except _SupportDeadline:
            receptor_stopped=True;receptor_metadata['status']='UNKNOWN_SEARCH_DEADLINE';metrics['receptor_deadline_stops']+=1
        receptor_metadata['setup_seconds']=time.perf_counter()-stage
    elif receptor_proposals=='recursive_receptors':
        receptor_metadata['status']='NOT_STARTED_PRIOR_SEARCH_DEADLINE'
    def review(state,g,hint,p):
        if hint is None:return None,dict(phase='absent',pending=[],eligible=[])
        pending=[k for k in hint['item']['members'] if k not in state.selected]
        if not pending:return None,dict(phase='completed',pending=[],eligible=[])
        illegal=[k for k in pending if not state.legal(model.placement(k))]
        if illegal:return None,dict(phase='invalid',pending=pending,illegal=illegal,eligible=[])
        eligible=[k for k in pending if k in g.domains.get(p,set())]
        return hint,dict(phase='eligible' if eligible else 'waiting',pending=pending,eligible=eligible)
    def visit(state,g,hint):
        nonlocal found
        if support_stopped or receptor_stopped:
            return None,dict(kind='unknown',point=None,census=[],state_sha256=root_state,
                hint_in=None,review=dict(phase='absent',pending=[],eligible=[]),
                children=[],cutoff='support_graph_deadline' if support_stopped else 'recursive_receptor_setup_deadline')
        kind,p,keys=g.decision(state);metrics['nodes']+=1
        active,trace=review(state,g,hint,p);tree=dict(kind=kind,point=p,census=[dict(point=q,generation=state.generations[q],keys=sorted(cs)) for q,cs in sorted(g.domains.items())],state_sha256=fingerprint(state),hint_in=hint['id'] if hint else None,review=trace,children=[])
        if hint:metrics['hint_'+trace['phase']]+=1
        if kind=='dead':metrics['dead']+=1;return False,tree
        if kind=='empty':found=state;return True,tree
        metrics[kind]+=1
        if kind=='branch' and active is None and mode!='base':
            stage=time.perf_counter();items,work=join(state,g,p,proposal_limit,proposal_checks)
            for k,v in work.items():metrics[k]+=v
            receptor_receipt=None;original_pool_size=len(items)
            if receptor_proposals=='recursive_receptors':
                metrics['receptor_proposal_calls']+=1
                try:
                    extra,receptor_receipt=receptor_planner(state,g,p)
                    support_check()
                    items=items+extra
                    metrics['receptor_validated_extras']+=len(extra)
                    metrics['receptor_work']+=receptor_receipt['counts'].get('work',0)
                    metrics['receptor_aggregate_checks']+=receptor_receipt['counts'].get('aggregate_checks',0)
                except _SupportDeadline:
                    metrics['receptor_deadline_stops']+=1
                    event=dict(id=len(events),point=p,chosen=list(state.order),items=items,
                        weights=scoring,index=None,scores=[],probabilities=[],
                        receptor_proposals=dict(status='UNKNOWN_SEARCH_DEADLINE',
                            original_pool_size=original_pool_size,
                            scope='No recursive prefix or hint consumed; all original Join/sample/defer items retained.'))
                    tree['policy_event']=event['id'];events.append(event)
                    metrics['proposal_seconds']+=time.perf_counter()-stage
                    tree['cutoff']='recursive_receptor_proposal_deadline';return None,tree
            features=[vector(item,model,state,g) for item in items];item,event=choose(items,features,scoring,rng,stochastic)
            if receptor_receipt is not None:
                event['receptor_proposals']=dict(original_pool_size=original_pool_size,
                    appended_proposals=len(items)-original_pool_size,receipt=receptor_receipt)
            support_deadline=False
            if support_ordering=='and_support':
                metrics['support_order_calls']+=1
                try:
                    item,support_choice=_support_choice(model,state,items,event,support_graph,support_check)
                    event['support_ordering']=support_choice;event['index']=support_choice['selected_index']
                    metrics['support_projection_work']+=support_choice['projection']['work']
                    metrics['support_aggregate_checks']+=support_choice['projection']['aggregate_checks']
                    if support_choice['ranking'] is not None:metrics['support_ranking_work']+=support_choice['ranking']['counts']['work']
                    if support_choice['status']=='STABLE_FALLBACK':metrics['support_stable_fallbacks']+=1
                    if support_choice['selected_index']!=support_choice['legacy_index']:metrics['support_changed_hint_choices']+=1
                except _SupportDeadline:
                    support_deadline=True;metrics['support_deadline_stops']+=1
                    event['support_ordering']=dict(schema='point-and-support-choice-v1',
                        status='UNKNOWN_SEARCH_DEADLINE',reason='point_support_search_deadline',
                        legacy_index=event['index'],selected_index=None,ranking=None,
                        scope='No support score or hint was consumed; full unchanged items retained in this event.')
            event.update(id=len(events),point=p,chosen=list(state.order),items=items,weights=scoring);tree['policy_event']=event['id'];events.append(event);metrics['proposal_seconds']+=time.perf_counter()-stage
            if support_deadline:tree['cutoff']='support_ordering_deadline';return None,tree
            if item is not None:
                if aggregate(model,item['members'],state)!={k:item[k] for k in ('members','pending','aggregate_sha256','new_occupancy','new_marks')}:raise ValueError('invalid row aggregate')
                active=dict(id=len(hints),item=item);hints.append(dict(id=active['id'],chosen=list(state.order),point=p,item=item));tree['hint_start']=active['id'];metrics['hints_started']+=1
                active,start=review(state,g,active,p);tree['start_review']=start
                if active is None or not start['eligible']:raise ValueError('cluster does not reach selected point')
                trace=start
        preferred=set(trace['eligible']) if active else set();alternatives=keys if kind=='forced' else [k for k in keys if k in preferred]+[k for k in keys if k not in preferred];tree['alternatives']=alternatives
        for k in alternatives:
            if metrics['attempts']>=attempts or time.perf_counter()-began>=seconds:tree['cutoff']='before_placement';return None,tree
            metrics['attempts']+=1;child=state.copy();cg=g.copy();cg.update(model,child,child.place(model.placement(k)));ok,sub=visit(child,cg,active);tree['children'].append(dict(key=k,role='member' if k in preferred else 'base',tree=sub))
            if ok is not False:return ok,tree
            metrics['backtracks']+=1
        return False,tree
    ok,tree=visit(initial,graph,None);restored=fingerprint(initial)==root_state and graph.fingerprint()==root_graph
    if not restored:raise ValueError('state/graph rollback')
    return dict(status='finite_marked_proof_region' if ok else 'unknown_search_budget' if ok is None else 'exhausted_finite_marked_region',
                proof=model.decode(found.order) if found else None,placements=found.order if found else [],tile_generations=found.tile_generations if found else [],
                tree=tree,metrics=dict(metrics),graph_metrics=dict(model.metrics),events=events,hints=hints,mode=mode,weights=scoring,
                stochastic=stochastic,seed=seed,seconds=time.perf_counter()-began,root_state_sha256=root_state,root_restored=restored,
                support_ordering=support_ordering,support_ordering_metadata=support_metadata,
                receptor_proposals=receptor_proposals,receptor_metadata=receptor_metadata,
                limits=dict(attempts=attempts,seconds=seconds,proposal_limit=proposal_limit,proposal_checks=proposal_checks),
                scope='Reference global dead/forced/earliest-generation point search. Semantic row and open arbitrary cluster hints only reorder original alternatives. No learned candidate pruning or primitive-square GCTS.')
