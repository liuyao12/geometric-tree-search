"""Bounded receptor-DAG proposals over an unchanged factored point Model.

All returned items are ordering advice. They add no candidate, rule, fact,
marking, pruning or degree authority. No scientific module is imported here.
The caller supplies authenticated original aggregate/row-projection functions.
"""
import collections
import json
import math

VERSION = 'recursive-receptor-DAG-planner-v1'
RESULT_SCHEMA = 'recursive-receptor-planner-call-v1'
PROPOSAL_SCHEMA = 'recursive-receptor-DAG-proposal-v1'
IDENTITY_SCHEMA = 'recursive-receptor-planner-identity-v1'
DEFAULT_LIMITS = dict(per_call_work=200000, extra_proposals=8,
    max_dependency_depth=4, max_new_complete_rows=8,
    max_distinct_base_keys=128, aggregate_checks=2048,
    min_new_complete_rows=2, trace_records=2048)
FALSE_AUTHORITY = dict(logical_proof_accepted=False, candidate_pruning=False,
    degree_authority=False, universal_family_accepted=False,
    learned_negative=False, macro_execution=False)


class PlannerDataError(ValueError):
    pass


class _Quota(Exception):
    def __init__(self, owner, reason):
        self.owner = owner
        self.reason = reason
        super().__init__(reason)


def _limits(value):
    result = dict(DEFAULT_LIMITS)
    if value is not None:
        if type(value) is not dict or set(value) - set(result):
            raise PlannerDataError('declared planner limits')
        result.update(value)
    if any(type(v) is not int or v <= 0 for v in result.values()):
        raise PlannerDataError('positive integer planner limits')
    if result['min_new_complete_rows'] > result['max_new_complete_rows']:
        raise PlannerDataError('minimum/maximum complete rows')
    return result


class _Work:
    def __init__(self, check, limits):
        if not callable(check):
            raise PlannerDataError('charged caller check required')
        self.check = check
        self.limits = limits
        self.counts = collections.Counter()
        self.owner = object()

    def step(self, category='work'):
        self.check()  # Delegated exceptions always propagate unchanged.
        if self.counts['work'] >= self.limits['per_call_work']:
            raise _Quota(self.owner, 'planner_work_budget')
        self.counts['work'] += 1
        if category != 'work':
            self.counts[category] += 1

    def bound(self, category, maximum, reason):
        self.step()
        if self.counts[category] >= maximum:
            raise _Quota(self.owner, reason)
        self.counts[category] += 1


def _literal(value, w):
    w.step('literal_nodes')
    if type(value) is dict:
        if any(type(k) is not str for k in value):
            raise PlannerDataError('ordinary literal string-key object')
        return {k: _literal(v, w) for k, v in value.items()}
    if type(value) in (list, tuple):
        return [_literal(v, w) for v in value]
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) is float and math.isfinite(value):
        return value
    raise PlannerDataError('ordinary finite literal value')


def _bytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def _key(value):
    if type(value) not in (tuple, list) or len(value) != 4 or any(type(x) is not int for x in value):
        raise PlannerDataError('actual four-integer placement key')
    return tuple(value)


def _point(value):
    if type(value) not in (tuple, list) or len(value) != 2 or any(type(x) is not int for x in value):
        raise PlannerDataError('actual two-integer point')
    return tuple(value)


def _row(packet):
    if type(packet) is not dict or type(packet.get('row')) is not int or packet['row'] < 0:
        raise PlannerDataError('complete producer row packet')
    if type(packet.get('requirements')) is not list:
        raise PlannerDataError('ordered complete producer requirements')
    for req in packet['requirements']:
        if (type(req) not in (list, tuple) or len(req) != 2 or
                type(req[0]) is not int or not 0 <= req[0] < packet['row']):
            raise PlannerDataError('literal strict-earlier receptor')
    if 'formula' not in packet or type(packet.get('members')) is not list:
        raise PlannerDataError('actual output and role keys required')
    return packet['row']


def _known(packets, w):
    indexed = {}
    for packet in packets:
        w.step('known_rows')
        j = _row(packet)
        if j in indexed:
            raise PlannerDataError('one complete packet per row')
        indexed[j] = packet
    justified = {}
    for j, packet in sorted(indexed.items()):
        w.step('known_rows')
        valid = True
        for i, f in packet['requirements']:
            w.step('known_ports')
            if i not in justified or justified[i]['formula'] != f:
                valid = False
        if valid:
            justified[j] = packet
    return justified


def _enumerate_dags(roots, available, known, selected, w, traces):
    """Logical producer DAG search only; point validation is a separate gate."""
    limits = w.limits
    seen = set()
    emitted = 0

    def note(reason, **fields):
        w.bound('trace_records', limits['trace_records'], 'planner_trace_budget')
        traces.append(dict(reason=reason, **fields))

    def finish(root, assigned):
        nonlocal emitted
        nodes = [assigned[j] for j in sorted(assigned)]
        keys = sorted({_key(k) for p in nodes for k in p['members']})
        new_rows = [p['row'] for p in nodes if any(_key(k) not in selected for k in p['members'])]
        height = {}
        ports = []
        for packet in nodes:
            j = packet['row']
            depth = 0
            for position, (i, formula) in enumerate(packet['requirements']):
                w.step('closed_ports')
                source = assigned.get(i) or known.get(i)
                if source is None or source['formula'] != formula:
                    raise PlannerDataError('closed DAG lost an actual support')
                if i in assigned:
                    depth = max(depth, 1 + height[i])
                ports.append(dict(consumer_row=j, port_index=position,
                    source_row=i, formula=_literal(formula, w),
                    source_kind='producer_node' if i in assigned else 'existing_justified_row'))
            height[j] = depth
        if (not limits['min_new_complete_rows'] <= len(new_rows) <= limits['max_new_complete_rows'] or
                len(keys) > limits['max_distinct_base_keys'] or
                height[root['row']] > limits['max_dependency_depth']):
            note('closed_plan_size_or_depth_abstention', root_row=root['row'], new_rows=new_rows)
            return None
        identity = tuple(keys)
        if identity in seen:
            return None
        seen.add(identity)
        emitted += 1
        return dict(schema=PROPOSAL_SCHEMA, version=VERSION,
            root_row=root['row'], nodes=_literal(nodes, w), ports=ports,
            members=[list(k) for k in keys], new_complete_rows=new_rows,
            planner_depth=height[root['row']], open_receptors=[],
            closure='CLOSED_RELATIVE_TO_CURRENT_JUSTIFIED_ROWS',
            authority=dict(FALSE_AUTHORITY))

    def extend(root, assigned, pending):
        w.step('DAG_states')
        if emitted >= limits['extra_proposals']:
            return
        if not pending:
            proposal = finish(root, assigned)
            if proposal is not None:
                yield proposal
            return
        consumer, position, source, wanted, depth = pending[0]
        rest = pending[1:]
        if source in known:
            if known[source]['formula'] == wanted:
                yield from extend(root, assigned, rest)
            else:
                note('existing_justified_row_formula_conflict', source_row=source)
            return
        if source in assigned:
            if assigned[source]['formula'] == wanted:
                yield from extend(root, assigned, rest)
            else:
                note('shared_producer_row_formula_conflict', source_row=source)
            return
        if depth > limits['max_dependency_depth']:
            note('OPEN_CONDITIONAL_depth', consumer_row=consumer, port_index=position,
                 source_row=source, formula=_literal(wanted, w))
            return
        count = 0
        for packet in available(source, wanted):
            w.step('producer_choices')
            if _row(packet) != source or packet['formula'] != wanted:
                raise PlannerDataError('demand producer returned a different literal row/output')
            count += 1
            new = dict(assigned)
            new[source] = packet
            fresh = {p['row'] for p in new.values() if any(_key(k) not in selected for k in p['members'])}
            if len(fresh) > limits['max_new_complete_rows']:
                note('OPEN_CONDITIONAL_row_budget', source_row=source)
                continue
            children = [(source, n, i, f, depth + 1)
                        for n, (i, f) in enumerate(packet['requirements'])]
            yield from extend(root, new, children + rest)
            if emitted >= limits['extra_proposals']:
                return
        if not count:
            note('OPEN_CONDITIONAL_no_producer_in_bounded_prefix', consumer_row=consumer,
                 port_index=position, source_row=source, formula=_literal(wanted, w))

    for root in roots:
        w.step('anchor_rows')
        j = _row(root)
        pending = [(j, n, i, f, 1) for n, (i, f) in enumerate(root['requirements'])]
        yield from extend(root, {j: root}, pending)
        if emitted >= limits['extra_proposals']:
            note('proposal_prefix_cap', proposals=emitted)
            return


def propose_logical_dags(*, demand_snapshot, available_producers,
                         current_justified_rows, signature_context,
                         source_epoch, check, limits=None):
    """Untrusted generic logical proposal prefix, not executable proof authority.

    available_producers(row, literal_formula) yields complete actual row packets.
    The point adapter separately rebuilds/validates every returned physical plan.
    """
    limits = _limits(limits)
    w = _Work(check, limits)
    proposals, traces = [], []
    status, reason = 'COMPLETE_BOUNDED_PREFIX', None
    try:
        if not callable(available_producers):
            raise PlannerDataError('actual producer iterator required')
        known = _known(current_justified_rows, w)
        selected = {_key(k) for k in demand_snapshot['selected_keys']}
        for p in _enumerate_dags(demand_snapshot['roots'], available_producers,
                                 known, selected, w, traces):
            proposals.append(p)
    except _Quota as stop:
        if stop.owner is not w.owner:
            raise
        status, reason = 'ABSTAIN_BOUNDED_PREFIX', stop.reason
    return dict(schema='recursive-receptor-logical-prefix-v1', version=VERSION,
        status=status, reason=reason, proposals=proposals, traces=traces,
        counts=dict(w.counts), signature_context=signature_context,
        source_epoch_reference=source_epoch, authority=dict(FALSE_AUTHORITY))


class ReceptorClosurePlanner:
    """Read-only point adapter; all call-local assignments use copied maps.

    Input Source/model identity is retained once. Per-call receipts contain full
    state and forward/reverse graph projections. Proposal keys refer to the full
    ordinary Model record that the caller must retain, never to hash-only tiles.
    """
    def __init__(self, model, *, source_epoch, source_guard, check,
                 aggregate, row_requirements, limits=None):
        if not all(callable(f) for f in (source_guard, check, aggregate, row_requirements)):
            raise PlannerDataError('authenticated injected authorities required')
        self.model = model
        self.source_epoch = source_epoch
        self.source_guard = source_guard
        self.check = check
        self.aggregate = aggregate
        self.row_requirements = row_requirements
        self.limits = _limits(limits)
        self.guards = {}
        self._identity = None
        self._setup = dict(status='NOT_STARTED', reason=None, counts={})
        w = _Work(check, self.limits)
        try:
            source_guard(); w.step()
            if type(source_epoch) is not dict:
                raise PlannerDataError('whole caller Source epoch required')
            if model.compiled['status'] != 'complete' or model.inventory['status'] != 'native_accepted':
                raise PlannerDataError('full current Native admission required')
            context = dict(spec=model.spec,
                compiler={k:v for k,v in model.compiled.items() if k != 'seconds'},
                inventory={k:model.inventory[k] for k in ('definitions','interfaces','native_blocks')},
                arity=model.arity)
            self._epoch_bytes = _bytes(_literal(source_epoch, w))
            self._context_bytes = _bytes(_literal(context, w))
            # Enumeration is charged; sorting the small per-row index is
            # bracketed by the same caller deadline, not a separate clock.
            for k in model.metadata:
                w.step('guard_index_keys')
                k = _key(k)
                if k not in model.cache:
                    raise PlannerDataError('metadata without actual original placement')
                if k[1] == 1:
                    self.guards.setdefault(k[0], []).append(k)
            for j, ks in self.guards.items():
                w.step('guard_index_sort'); ks.sort(); w.step()
            self.guards = {j:tuple(ks) for j,ks in self.guards.items()}
            self._identity = dict(schema=IDENTITY_SCHEMA, version=VERSION,
                source_epoch=json.loads(self._epoch_bytes),
                model_input_context=json.loads(self._context_bytes),
                limits=dict(self.limits),
                complete_model_record_reference=dict(payload_path='outputs.model',
                    required_contents='Entire ordinary Model record: every placement/t/m mark, metadata, ordered domain, alignment, dependency, initial assignment and admitted interface.',
                    custody='Caller must retain/authenticate that whole record with current executable/input Source epoch; no digest alone is authority.'),
                full_Model_required='Caller retains all original Model placements/marks/metadata; keys below are literal references, never a shortened tile encoding.',
                authority=dict(FALSE_AUTHORITY))
            self._setup.update(status='READY')
            self._custody(w)
        except _Quota as stop:
            if stop.owner is not w.owner:
                raise
            self.guards = {}
            self._setup.update(status='ABSTAIN_SETUP_BOUND', reason=stop.reason)
        self._setup['counts'] = dict(w.counts)

    def identity_record(self):
        # Owned metadata only; no reconstruction or current scientific call.
        return json.loads(_bytes(dict(identity=self._identity, setup=self._setup)))

    def _custody(self, w):
        w.step('custody_checks'); self.source_guard(); w.step()
        if _bytes(self.source_epoch) != self._epoch_bytes:
            raise PlannerDataError('caller Source epoch changed')
        m = self.model
        context = dict(spec=m.spec,
            compiler={k:v for k,v in m.compiled.items() if k != 'seconds'},
            inventory={k:m.inventory[k] for k in ('definitions','interfaces','native_blocks')},
            arity=m.arity)
        if _bytes(context) != self._context_bytes:
            raise PlannerDataError('effective Model input/admission context changed')

    def _snapshot(self, state, graph, point, w):
        def pairs(mapping):
            result = []
            for p, value in sorted(mapping.items()):
                w.step('snapshot_assignments'); result.append([list(_point(p)), value])
            return result
        domains, edges = [], []
        for p, keys in sorted(graph.domains.items()):
            w.step('snapshot_points'); row = []
            for k in sorted(keys):
                w.step('snapshot_incidences'); row.append(list(_key(k)))
            domains.append([list(_point(p)), row])
        for k, points in sorted(graph.edges.items()):
            w.step('snapshot_candidates'); edge = []
            for p in sorted(points):
                w.step('snapshot_reverse_incidences'); edge.append(list(_point(p)))
            edges.append([list(_key(k)), edge])
        return dict(point=list(_point(point)), totals=pairs(state.totals),
            marks=pairs(state.marks), generations=pairs(state.generations), roots=pairs(state.roots),
            selected=[list(_key(k)) for k in sorted(state.selected)],
            order=[list(_key(k)) for k in state.order],
            tile_generations=list(state.tile_generations),
            allowed_points=[list(_point(p)) for p in sorted(state.allowed_points)],
            graph_domains=domains, graph_edges=edges)

    def _packet(self, keys, w):
        m = self.model
        keys = [_key(k) for k in keys]
        rows = {k[0] for k in keys}
        if len(rows) != 1:
            raise PlannerDataError('one complete actual row')
        j = next(iter(rows)); roles = {k[1]:k for k in keys}
        if len(roles) != len(keys) or set(roles) != set(range(2 + m.arity)):
            raise PlannerDataError('complete unique C/G/all-input roles')
        for k in keys:
            w.step('packet_keys')
            if k not in m.cache or k not in m.metadata:
                raise PlannerDataError('unknown original key')
        c, g = m.metadata[roles[0]], m.metadata[roles[1]]
        if c['kind'] != 'command' or c['command'] != g['command'] or g['kind'] != 'guard':
            raise PlannerDataError('complete C/G native-guard agreement')
        req = self.row_requirements(m, keys, j)
        if req is None:
            raise PlannerDataError('incomplete typed row requirements')
        packet = dict(row=j, formula=_literal(g['command']['formula'], w),
            requirements=_literal(req, w), members=[list(roles[r]) for r in range(2+m.arity)],
            command=_literal(g['command'], w), native_guard_key=list(roles[1]),
            level=0, interface=None)
        if g['command']['rule'] == 'block':
            found=[]
            for d in m.interfaces:
                w.step('interface_lookups')
                if d['name']==g['command']['name']:
                    found.append(d)
            if len(found) != 1:
                raise PlannerDataError('exact admitted ground interface')
            d=found[0]; packet.update(level=d['level'], interface=_literal(d,w))
            premises=d['definition']['premises'];mode=m.mode[d['name']];exact=[]
            if len(premises)>m.arity:
                raise PlannerDataError('whole interface fits all declared roles')
            for r in range(m.arity):
                w.step('typed_input_roles');meta=m.metadata[roles[2+r]]
                if meta['input']!=r or meta['mode']!=mode:
                    raise PlannerDataError('actual block input role/mode')
                if r<len(premises):
                    if meta['kind']!='lemma_input':
                        raise PlannerDataError('actual ordered premise receptor')
                    exact.append([meta['source'],premises[r]])
                elif meta['kind']!='unused_input' or meta['source'] is not None:
                    raise PlannerDataError('all extra block input fillers retained')
            if _bytes(exact) != _bytes(packet['requirements']):
                raise PlannerDataError('full ordered ground interface inputs')
        else:
            for r in range(m.arity):
                w.step('typed_input_roles');meta=m.metadata[roles[2+r]]
                if (meta['input']!=r or meta['mode']!=0 or
                        meta['kind']!='unused_input' or meta['source'] is not None):
                    raise PlannerDataError('all primitive input fillers retained')
        _row(packet)
        return packet

    def _selected_packets(self, state, w):
        rows = {}
        for k in state.selected:
            w.step('selected_keys');k=_key(k)
            if k[1] in rows.setdefault(k[0], {}):
                raise PlannerDataError('multiple selected keys on a role')
            rows[k[0]][k[1]]=k
        return [self._packet(list(roles.values()),w) for j,roles in sorted(rows.items())
                if len(roles)==2+self.model.arity]

    def _rows(self, state, row, wanted, anchor, w):
        m=self.model;occupied={k[1]:k for k in state.selected if k[0]==row}
        for guard in self.guards.get(row, ()):
            w.step('row_guard_choices');meta=m.metadata[guard];cmd=meta['command']
            if wanted is not None and cmd['formula']!=wanted:
                continue
            pair=[(row,0,guard[2],0),guard]
            if anchor is not None and anchor[1]<2 and anchor not in pair:
                continue
            if any(k not in m.cache or (k[1] in occupied and occupied[k[1]]!=k) or
                   (k not in state.selected and not state.legal(m.placement(k))) for k in pair):
                continue
            mode=m.mode[cmd['name']] if cmd['rule']=='block' else 0
            lists=[]
            for role in range(2,2+m.arity):
                candidates=[occupied[role]] if role in occupied else m.align_cache[(4*row,role)]
                valid=[]
                for k in candidates:
                    w.step('row_input_choices');k=_key(k)
                    if anchor is not None and anchor[1]==role and k!=anchor:
                        continue
                    if m.metadata[k]['mode']==mode and (k in state.selected or state.legal(m.placement(k))):
                        valid.append(k)
                lists.append(valid)
            def extend(position, members):
                w.step('row_join_states')
                if position == len(lists):
                    yield self._packet(members,w);return
                for k in lists[position]:
                    yield from extend(position+1,members+[k])
            yield from extend(0,pair)

    def _validate(self, proposal, state, graph, point, known, w):
        nodes=[self._packet(p['members'],w) for p in proposal['nodes']]
        if _bytes(nodes)!=_bytes(proposal['nodes']):
            raise PlannerDataError('fresh complete DAG row reconstruction')
        combined=self._selected_packets(state,w)
        byrow={p['row']:p for p in combined}
        for p in nodes:
            if p['row'] in byrow and _bytes(byrow[p['row']])!=_bytes(p):
                raise PlannerDataError('actual selected row conflict')
            byrow[p['row']]=p
        justified=_known(list(byrow.values()),w)
        if any(p['row'] not in justified for p in nodes):
            raise PlannerDataError('open receptor cannot earn operative fact credit')
        node_map={p['row']:p for p in nodes}
        if len(node_map)!=len(nodes) or nodes!=[node_map[j] for j in sorted(node_map)]:
            raise PlannerDataError('unique source-ordered producer nodes')
        root=proposal['root_row']
        if type(root) is not int or root not in node_map:
            raise PlannerDataError('actual proposal root row')
        reachable=set();todo=[root]
        while todo:
            w.step('reconstructed_DAG_nodes');j=todo.pop()
            if j in reachable:
                continue
            reachable.add(j)
            todo.extend(i for i,f in node_map[j]['requirements'] if i in node_map)
        if reachable!=set(node_map):
            raise PlannerDataError('every producer is on an actual receptor ancestry')
        ports=[];height={}
        for p in nodes:
            j=p['row'];depth=0
            for position,(i,f) in enumerate(p['requirements']):
                w.step('reconstructed_DAG_ports')
                source=node_map.get(i) or known.get(i)
                if source is None or source['formula']!=f:
                    raise PlannerDataError('fresh literal receptor support')
                if i in node_map:
                    depth=max(depth,1+height[i])
                ports.append(dict(consumer_row=j,port_index=position,source_row=i,
                    formula=_literal(f,w),source_kind='producer_node' if i in node_map else 'existing_justified_row'))
            height[j]=depth
        members=sorted({_key(k) for p in nodes for k in p['members']})
        new_rows=[p['row'] for p in nodes if any(_key(k) not in state.selected for k in p['members'])]
        if (not self.limits['min_new_complete_rows']<=len(new_rows)<=self.limits['max_new_complete_rows'] or
                len(members)>self.limits['max_distinct_base_keys'] or height[root]>self.limits['max_dependency_depth']):
            raise PlannerDataError('fresh complete-row/key/depth bounds')
        reconstructed=dict(schema=PROPOSAL_SCHEMA,version=VERSION,root_row=root,nodes=nodes,
            ports=ports,members=[list(k) for k in members],new_complete_rows=new_rows,
            planner_depth=height[root],open_receptors=[],
            closure='CLOSED_RELATIVE_TO_CURRENT_JUSTIFIED_ROWS',authority=dict(FALSE_AUTHORITY))
        if _bytes(reconstructed)!=_bytes(proposal):
            raise PlannerDataError('fresh whole proposal reconstruction')
        root_pending=[_key(k) for k in node_map[root]['members'] if _key(k) not in state.selected]
        if not any(k in graph.domains[point] for k in root_pending):
            return None
        for k in members:
            w.step('current_key_validation')
            if k in state.selected:
                continue
            c=self.model.placement(k)
            if not state.legal(c) or any(k not in graph.domains.get(p,set()) for p,v in c.occupancy if v>0):
                return None
        w.bound('aggregate_checks',self.limits['aggregate_checks'],'planner_aggregate_budget')
        item=self.aggregate(self.model,members,state)
        w.step()
        if item is None or not any(k in graph.domains[point] for k in item['pending']):
            return None
        item.update(kind='recursive',level=max([p['level'] for p in nodes]+[0]),
            planner_depth=proposal['planner_depth'],receptor_proposal=proposal)
        return item

    def __call__(self, state, graph, point):
        w=_Work(self.check,self.limits);items=[]
        receipt=dict(schema=RESULT_SCHEMA,version=VERSION,status='NOT_STARTED',reason=None,
            limits=dict(self.limits),context=None,logical_prefix=None,proposals=[],counts={},
            identity_reference='search.receptor_metadata.identity',authority=dict(FALSE_AUTHORITY))
        try:
            self.check();self.source_guard()
            if self._setup['status']!='READY':
                receipt.update(status='ABSTAIN_SETUP_BOUND',reason=self._setup['reason'],counts=dict(w.counts));return items,receipt
            self._custody(w)
            kind,chosen,keys=graph.decision(state)
            if kind!='branch' or chosen!=point:
                raise PlannerDataError('planner requires the genuine globally selected branch')
            before=self._snapshot(state,graph,point,w)
            selected=self._selected_packets(state,w);known=_known(selected,w)
            def roots():
                for anchor in sorted(keys):
                    w.step('anchor_keys')
                    yield from self._rows(state,anchor[0],None,anchor,w)
            def available(row,formula):
                yield from self._rows(state,row,formula,None,w)
            prefix=propose_logical_dags(demand_snapshot=dict(roots=roots(),selected_keys=list(state.selected)),
                available_producers=available,current_justified_rows=list(known.values()),
                signature_context=dict(context='existing Native-admitted finite ground grammar'),
                source_epoch='search.receptor_metadata.identity.source_epoch',
                check=lambda:w.step('logical_work'),limits=self.limits)
            receipt['logical_prefix']=prefix
            for number,proposal in enumerate(prefix['proposals']):
                w.step('proposal_validation')
                item=self._validate(proposal,state,graph,point,known,w)
                receipt['proposals'].append(dict(index=number,status='VALIDATED' if item is not None else 'CURRENT_POINT_ABSTENTION',proposal=proposal))
                if item is not None:
                    items.append(item)
            after=self._snapshot(state,graph,point,w)
            self._custody(w)
            if _bytes(before)!=_bytes(after):
                raise PlannerDataError('planner mutated full state or graph')
            receipt['context']=dict(before=before,after=after,literal_equal=True)
            receipt.update(status=prefix['status'],reason=prefix['reason'])
        except _Quota as stop:
            if stop.owner is not w.owner:
                raise
            items=[]
            receipt.update(status='ABSTAIN_BOUNDED_PREFIX',reason=stop.reason,
                operative_items_discarded=True,
                scope='No incomplete custody/validation prefix supplies a hint; original pool remains.')
        receipt['counts']=dict(w.counts)
        return items,receipt
