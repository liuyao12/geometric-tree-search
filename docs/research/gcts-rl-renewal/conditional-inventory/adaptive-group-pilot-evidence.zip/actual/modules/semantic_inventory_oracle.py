"""Whole unchanged native checking with explicit generated lemma definitions."""
import copy,hashlib,json,time
from certificate_boundary_search import Oracle,digest
from tape_binary import write_micro_input

class RequestOracle(Oracle):
    def request(self,request,limit=5*10**9,purpose='semantic_inventory'):
        began=time.perf_counter();request=copy.deepcopy(request);initial=self.initial(request)
        inp=self.directory/'input.bin';out=self.directory/'output.bin';write_micro_input(initial,inp)
        self.process.stdin.write(str(inp)+' '+str(out)+' '+str(limit)+'\n');self.process.stdin.flush()
        reply=self.process.stdout.readline()
        if not reply:raise ValueError('native oracle stopped: '+self.process.stderr.read())
        result=json.loads(reply);record=dict(id=len(self.records),request=request,query_target='fixed_assertion',request_sha256=digest(request),
              input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
              result=result,seconds=time.perf_counter()-began,purpose=purpose)
        self.records.append(record);return record
    def query(self,spec,proof,final,limit):
        if not final:raise ValueError('semantic inventory pilot uses only declared fixed query targets')
        return self.request(dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=spec.get('blocks',[]),
                                 proof=proof,target=spec['target']),limit)
    def close(self):
        super().close()
        for stream in (self.process.stdin,self.process.stdout,self.process.stderr):stream.close()


INVENTORY_CERTIFICATION_VERSION = 'native-inventory-exact-dependency-closures-v2'
INVENTORY_CERTIFICATION_SCHEMA = 'native-inventory-dependency-closure-certification-v1'
MAX_REGISTRATION_MICRO_STEPS = 5 * 10**9

class InventoryCertificationError(ValueError):
    """Malformed certificate/custody is never inventory authority."""

def _strict_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')

def _strict_sha(value):
    return hashlib.sha256(_strict_bytes(value)).hexdigest()

def _ordered_inventory(inventory):
    """Check registry coherence, not mathematical truth; Native checks bodies."""
    if type(inventory) is not dict:
        raise InventoryCertificationError('inventory must be a literal object')
    for field in ('definitions', 'interfaces', 'native_blocks'):
        if type(inventory.get(field)) is not list:
            raise InventoryCertificationError('complete inventory list '+field)
    rows = inventory['definitions']
    blocks = inventory['native_blocks']
    if blocks != [row.get('definition') if type(row) is dict else None
                  for row in rows]:
        raise InventoryCertificationError('complete definition/native-block order')
    names = []
    dependencies = {}
    seen = set()
    for row, block in zip(rows, blocks):
        if type(row) is not dict or type(block) is not dict:
            raise InventoryCertificationError('literal definition object')
        name = row.get('name')
        if (type(name) is not str or not name or name in seen or
                block.get('name') != name or type(block.get('proof')) is not list):
            raise InventoryCertificationError('unique joined definition identity')
        calls = []
        for command in block['proof']:
            if type(command) is not dict or type(command.get('rule')) is not str:
                raise InventoryCertificationError('literal primitive/call command')
            if command['rule'] == 'block':
                called = command.get('name')
                if type(called) is not str or called not in seen:
                    raise InventoryCertificationError('dependency must precede call')
                if called not in calls:
                    calls.append(called)
        names.append(name)
        dependencies[name] = calls
        seen.add(name)
    interfaces = inventory['interfaces']
    if (any(type(name) is not str or name not in seen for name in interfaces) or
            len(set(interfaces)) != len(interfaces)):
        raise InventoryCertificationError('every original interface is registered')
    return names, dependencies

def plan_dependency_closures(inventory):
    """Every definition, not just exported/used interfaces, receives a request.

    Each request carries its complete recursive dependency closure in the
    unchanged registry order. Earlier acceptance is never an imported axiom.
    """
    names, dependencies = _ordered_inventory(inventory)
    closures = {}
    plans = []
    for name in names:
        needed = {name}
        for dep in dependencies[name]:
            needed.update(closures[dep])
        closures[name] = needed
        plans.append(dict(definition=name,
                          names=[n for n in names if n in needed]))
    if not plans:
        # Native must still check the full theory and a closed tautology.
        plans = [dict(definition=None, names=[])]
    return plans

def _closure_request(spec, blocks):
    taut = ['imp', ['bot'], ['bot']]
    return dict(protocol='gcts-fol-1', theory=copy.deepcopy(spec['theory']),
                blocks=copy.deepcopy(blocks),
                proof=[dict(rule='tautology', formula=copy.deepcopy(taut))],
                target=copy.deepcopy(taut))

def _checked_native_record(oracle, result, request, purpose, before, allowance):
    if type(result) is not dict or type(oracle.records) is not list:
        raise InventoryCertificationError('full retained Native record required')
    index = result.get('id')
    if (type(index) is not int or index != before or
            len(oracle.records) != before + 1 or oracle.records[index] != result):
        raise InventoryCertificationError('one fresh serial Native record')
    if (result.get('purpose') != purpose or result.get('request') != request or
            result.get('request_sha256') != _strict_sha(request)):
        raise InventoryCertificationError('whole current Native request join')
    outcome = result.get('result')
    if type(outcome) is not dict:
        raise InventoryCertificationError('Native outcome object')
    status = outcome.get('status')
    if status not in ('accepted', 'rejected', 'unknown_space_budget',
                      'unknown_step_budget'):
        raise InventoryCertificationError('known Native disposition')
    steps = outcome.get('micro_steps')
    if type(steps) is not int or not 0 <= steps <= allowance:
        raise InventoryCertificationError('exact consumed Native step budget')
    return index, status, steps

def _check_inventory_dependency_closures(spec, inventory, oracle, limit):
    began = time.perf_counter()
    if type(limit) is not int or not 0 < limit <= MAX_REGISTRATION_MICRO_STEPS:
        raise InventoryCertificationError('positive unchanged aggregate step cap')
    if type(spec) is not dict or type(spec.get('theory')) is not dict:
        raise InventoryCertificationError('full declared theory')
    if type(getattr(oracle, 'records', None)) is not list:
        raise InventoryCertificationError('original full Native record stream')
    original_bytes = _strict_bytes(inventory)
    snapshot = copy.deepcopy(inventory)
    original_theory = _strict_bytes(spec['theory'])
    plans = plan_dependency_closures(snapshot)
    blocks = {block['name']:block for block in snapshot['native_blocks']}
    names = [row['name'] for row in snapshot['definitions']]
    receipts = []
    accepted = set()
    used = 0
    disposition = 'native_accepted'
    stop_reason = None
    for ordinal, plan in enumerate(plans):
        if _strict_bytes(inventory) != original_bytes:
            raise InventoryCertificationError('original complete inventory mutated')
        if _strict_bytes(spec['theory']) != original_theory:
            raise InventoryCertificationError('original full theory mutated')
        remaining = limit - used
        if remaining == 0:
            disposition = 'unknown_native_inventory'
            stop_reason = 'aggregate_registration_micro_step_budget'
            break
        request = _closure_request(spec, [blocks[name] for name in plan['names']])
        expected = copy.deepcopy(request)
        before = len(oracle.records)
        purpose = 'check_generated_lemma_definition_closure'
        q = oracle.request(request, remaining, purpose)
        index, status, consumed = _checked_native_record(
            oracle, q, expected, purpose, before, remaining)
        receipts.append(dict(ordinal=ordinal, definition=plan['definition'],
                             closure_names=list(plan['names']), query=index,
                             request_sha256=_strict_sha(expected),
                             assigned_micro_step_limit=remaining,
                             consumed_micro_steps=consumed,
                             aggregate_consumed_before=used,
                             aggregate_consumed_after=used+consumed,
                             result_status=status))
        used += consumed
        if _strict_bytes(inventory) != original_bytes:
            raise InventoryCertificationError('original complete inventory mutated')
        if _strict_bytes(spec['theory']) != original_theory:
            raise InventoryCertificationError('original full theory mutated')
        if status != 'accepted':
            disposition = ('native_rejected' if status == 'rejected'
                           else 'unknown_native_inventory')
            stop_reason = status
            break
        accepted.update(plan['names'])
    complete = (disposition == 'native_accepted' and len(receipts) == len(plans)
                and accepted == set(names))
    if disposition == 'native_accepted' and not complete:
        raise InventoryCertificationError('acceptance requires complete coverage')
    if _strict_bytes(snapshot) != original_bytes:
        raise InventoryCertificationError('owned complete inventory mutated')
    certification = dict(
        schema=INVENTORY_CERTIFICATION_SCHEMA,
        version=INVENTORY_CERTIFICATION_VERSION,
        mode='dependency_closures',
        inventory_sha256=hashlib.sha256(original_bytes).hexdigest(),
        theory_sha256=hashlib.sha256(original_theory).hexdigest(),
        aggregate_micro_step_limit=limit,
        aggregate_consumed_micro_steps=used,
        all_original_definition_names=names,
        all_original_interfaces=list(snapshot['interfaces']),
        planned_requests=plans,
        receipts=receipts,
        accepted_definition_names=[name for name in names if name in accepted],
        complete=complete, stop_reason=stop_reason,
        scope='Every original definition is checked with its exact recursive '
              'dependency closure by the unchanged Native checker. All bodies '
              'are rechecked inside each request; no prior theorem is imported. '
              'The entire original inventory is returned even after rejection '
              'or UNKNOWN. Only complete all-definition acceptance is authority. '
              'The same aggregate registration micro-step cap is shared across '
              'all requests; all preparation, calls and output remain charged. '
              'Fresh whole final proof checking remains mandatory.')
    return dict(snapshot, status=disposition, query=None,
                queries=[row['query'] for row in receipts],
                certification=certification, seconds=time.perf_counter()-began)

def _check_inventory_modes_v2_parent(spec, inventory, oracle, limit=5*10**9, *, mode='bulk'):
    """Explicit unchanged bulk control or all-definition closure certification."""
    if mode == 'bulk':
        return _check_inventory_bulk_parent(spec, inventory, oracle, limit)
    if mode == 'dependency_closures':
        return _check_inventory_dependency_closures(spec, inventory, oracle, limit)
    raise InventoryCertificationError('unknown inventory certification mode')

def _check_inventory_bulk_parent(spec,inventory,oracle,limit=5*10**9):
    taut=['imp',['bot'],['bot']]
    request=dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=inventory['native_blocks'],proof=[dict(rule='tautology',formula=taut)],target=taut)
    q=oracle.request(request,limit,'check_generated_lemma_definitions')
    status='native_accepted' if q['result']['status']=='accepted' else 'native_rejected' if q['result']['status']=='rejected' else 'unknown_native_inventory'
    return dict(**inventory,status=status,query=q['id'],seconds=q['seconds'])


GROUP_CERTIFICATION_VERSION = 'native-inventory-adaptive-groups-v1'
GROUP_CERTIFICATION_SCHEMA = 'native-inventory-adaptive-group-certification-v1'


def _group_closure_names(target_names, names, dependencies):
    """Complete dependency closure, including every target, in original order."""
    wanted = set()
    pending = list(target_names)
    while pending:
        name = pending.pop()
        if name in wanted:
            continue
        wanted.add(name)
        pending.extend(dependencies[name])
    return [name for name in names if name in wanted]


def _check_inventory_adaptive_groups(spec, inventory, oracle, limit):
    """Space failures split a group; every probe shares one unchanged work cap.

    This is a different explicit certification strategy, not a retry of an old
    invocation. No accepted prefix is exposed as search authority. A child
    request rechecks every dependency body; accepted parents are never axioms.
    """
    began = time.perf_counter()
    if type(limit) is not int or not 0 < limit <= MAX_REGISTRATION_MICRO_STEPS:
        raise InventoryCertificationError('positive unchanged aggregate step cap')
    if type(spec) is not dict or type(spec.get('theory')) is not dict:
        raise InventoryCertificationError('full declared theory')
    if type(getattr(oracle, 'records', None)) is not list:
        raise InventoryCertificationError('original full Native record stream')
    original_bytes = _strict_bytes(inventory)
    original_theory = _strict_bytes(spec['theory'])
    snapshot = copy.deepcopy(inventory)
    names, dependencies = _ordered_inventory(snapshot)
    blocks = {block['name']: block for block in snapshot['native_blocks']}
    # Even an empty inventory must admit the whole theory and a closed tautology.
    pending = [dict(path=[], target_names=list(names))]
    receipts = []
    accepted = set()
    used = 0
    disposition = 'native_accepted'
    stop_reason = None
    while pending:
        if _strict_bytes(inventory) != original_bytes or _strict_bytes(snapshot) != original_bytes:
            raise InventoryCertificationError('complete original inventory mutated')
        if _strict_bytes(spec['theory']) != original_theory:
            raise InventoryCertificationError('original full theory mutated')
        remaining = limit - used
        if remaining == 0:
            disposition = 'unknown_native_inventory'
            stop_reason = 'aggregate_registration_micro_step_budget'
            break
        group = pending[0]
        targets = group['target_names']
        closure = _group_closure_names(targets, names, dependencies)
        request = _closure_request(spec, [blocks[name] for name in closure])
        expected = copy.deepcopy(request)
        before = len(oracle.records)
        purpose = 'check_generated_lemma_definition_group'
        q = oracle.request(request, remaining, purpose)
        index, status, consumed = _checked_native_record(
            oracle, q, expected, purpose, before, remaining)
        if status == 'accepted':
            action = 'accept_group'
        elif status == 'unknown_space_budget' and len(targets) > 1:
            action = 'split_group'
        else:
            action = 'stop_inventory'
        receipts.append(dict(
            ordinal=len(receipts), path=list(group['path']),
            target_names=list(targets), closure_names=closure, query=index,
            request_sha256=_strict_sha(expected),
            assigned_micro_step_limit=remaining, consumed_micro_steps=consumed,
            aggregate_consumed_before=used, aggregate_consumed_after=used+consumed,
            result_status=status, action=action))
        used += consumed
        if _strict_bytes(inventory) != original_bytes or _strict_bytes(snapshot) != original_bytes:
            raise InventoryCertificationError('complete original inventory mutated')
        if _strict_bytes(spec['theory']) != original_theory:
            raise InventoryCertificationError('original full theory mutated')
        if action == 'accept_group':
            accepted.update(closure)
            pending.pop(0)
        elif action == 'split_group':
            midpoint = len(targets) // 2
            path = group['path']
            pending[:1] = [dict(path=path+[0], target_names=targets[:midpoint]),
                           dict(path=path+[1], target_names=targets[midpoint:])]
        else:
            disposition = ('native_rejected' if status == 'rejected'
                           else 'unknown_native_inventory')
            stop_reason = status
            break
    complete = not pending and accepted == set(names)
    if (disposition == 'native_accepted') is not complete:
        raise InventoryCertificationError('only complete all-definition acceptance is authority')
    certification = dict(
        schema=GROUP_CERTIFICATION_SCHEMA, version=GROUP_CERTIFICATION_VERSION,
        mode='adaptive_groups', inventory_sha256=hashlib.sha256(original_bytes).hexdigest(),
        theory_sha256=hashlib.sha256(original_theory).hexdigest(),
        aggregate_micro_step_limit=limit, aggregate_consumed_micro_steps=used,
        all_original_definition_names=names,
        all_original_interfaces=list(snapshot['interfaces']),
        initial_group=dict(path=[], target_names=list(names)),
        split_policy='left_first_binary_midpoint_only_after_space_unknown',
        receipts=receipts, pending_groups=copy.deepcopy(pending),
        accepted_definition_names=[name for name in names if name in accepted],
        complete=complete, stop_reason=stop_reason,
        scope='Full-theory Native requests carry complete recursive dependency '
              'closures in unchanged registry order. Every failed parent probe '
              'is charged. Space UNKNOWN alone splits a nonsingleton group at '
              'its index midpoint, left child first. No accepted prefix or '
              'earlier result is imported as an axiom. All original definitions '
              'and interfaces are returned on every disposition. Search requires '
              'complete coverage; final whole proof Native checking is separate.')
    return dict(snapshot, status=disposition, query=None,
                queries=[receipt['query'] for receipt in receipts],
                certification=certification, seconds=time.perf_counter()-began)


def check_inventory(spec, inventory, oracle, limit=5*10**9, *, mode='bulk'):
    """Historical modes are exact delegates; adaptive grouping is explicit."""
    if mode == 'adaptive_groups':
        return _check_inventory_adaptive_groups(spec, inventory, oracle, limit)
    return _check_inventory_modes_v2_parent(spec, inventory, oracle, limit, mode=mode)
