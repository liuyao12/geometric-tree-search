"""Raw files and metadata only; no scientific evaluation or imports."""
from pathlib import Path
import hashlib,json,os
D=Path(__file__).parent;P=D/'plans'
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
seen={}
def check(d):
 assert pin(d['path'])==d,d
 seen[d['path']]=d
 return load(d['path'])if d['path'].endswith('.json')else None
idx=load(P/'authorized-index-v2.json');row=idx['schedule'][0]
once=check(row['runner_plan']);worker=check(row['worker_plan']);closure=check(idx['runtime_closure'])
auth=check(row['authorization'])
for k in ('cold','runner','observer','python'):check(once[k])
for d in worker['project_sources'].values():check(d)
for d in worker['components'].values():check(d)
def walk(v):
 if type(v)is dict:
  if set(v)=={'path','sha256','bytes'}:
   if v['path'].startswith('/private/tmp/')or v['path']==once['python']['path']:check(v)
  else:
   for x in v.values():walk(x)
 elif type(v)is list:
  for x in v:walk(x)
# Opaque Native inputs are raw-hashed, never decompressed or interpreted.
walk(worker['native_inputs']);walk(worker['z3']);walk(worker['policy'])
for d in (idx['case_declaration'],idx['design'],idx['input_capsule']):check(d)
for role,b in auth['review_roles'].items():
 check(b['receipt'])
 for d in b['required_subjects']:check(d)
check(closure['parent_closure'])
sub={k:v for k,v in once.items()if k!='authorization'}
assert len(sub)==18 and hashlib.sha256(json.dumps(sub,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()==row['subject_sha256']==auth['subject_sha256']
assert auth['actual_execution_authorized']is True and auth['maximum_actual_invocations']==1
assert not Path(row['actual_directory']).exists()
assert not(P/'runner-plans'/(row['invocation_id']+'-terminal-observation')).exists()
out=dict(schema='ROOT-adaptive-group-local-prelaunch-v2',author_identity='/root',source_only=True,scientific_calls=0,
 goal_complete=False,all_raw_pins_verified=seen,scientific_aliases=len(worker['project_sources'])+len(worker['components']),
 whole_subject_sha256=row['subject_sha256'],fresh_actual_and_observer_absent=True,agents_must_be_idle=True,
 prior_failed_observer_retained=True,opaque_Native_gzip_decodes=0)
f=D/'ROOT-prelaunch-v2.json';assert not f.exists();f.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(preflight=pin(f),raw_pins=len(seen),scientific_calls=0)))
