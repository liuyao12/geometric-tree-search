"""New inert local subject after a pre-worker launch failure. No science evaluation."""
from pathlib import Path
import copy,hashlib,json
D=Path(__file__).parent
O=Path('/private/tmp/gcts-adaptive-group-pilot-plans-ROOT-20261019-v1')
E=Path('/private/tmp/gcts-local-operational-20261019/failed-launch-evidence')
L=E.parent;S=Path('/private/tmp/gcts-adaptive-group-local-intake-ROOT-source-20261019')
P=D/'plans';P.mkdir();(P/'worker-plans').mkdir();(P/'runner-plan-drafts').mkdir();(P/'authorization-drafts').mkdir()
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):
 p=Path(p);assert not p.exists();p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
def sha(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
oldidx=load(O/'prospective-index-v1.json');oldrow=oldidx['schedule'][0]
oldw=load(oldrow['worker_plan']['path']);oldonce=load(oldrow['runner_plan_draft']['path']);h=load(S/'Source-contract-v2.json')
closure=load(E/'runtime-closure-v1.json')
closure.update(parent_closure=pin(L/'parent-runtime-closure.json'),current_composition_handoff=pin(S/'Source-contract-v2.json'),
 bridge_scope='Fresh local operational-metadata continuation after pre-worker file-hydration timeout. Same complete24 aliases, same registry/driver and every scientific input/limit. No recursive proposer. Old failed observer attempt retained; no original grant or slot reused.')
cp=save(D/'runtime-closure-v2.json',closure)
iid='adaptive-group-002-fixed-local-ROOT-20261019-v2';rid=oldrow['receiver_id']
row={k:v for k,v in oldrow.items()if k in ['order','mode','inventory_certification_mode','search_ordering','model_storage','result_reader','receiver_id']};row.update(invocation_id=iid,actual_directory=str(D/'actual-v2'))
design=load(E/'prospective-design-v1.json');design.update(schedule=[row],runtime_closure=cp,intake_Source_contract=pin(S/'Source-contract-v2.json'),
 original_input_capsule=pin(L/'full-assertion-capsule.json'),
 operational_continuation=dict(previous_observer_attempt=oldrow['invocation_id'],previous_terminal=str(Path(oldrow['runner_plan_draft']['path']).parent.parent/'runner-plans'/ (oldrow['invocation_id']+'-terminal-observation')/'terminal.json'),previous_outcome='timeout225s before actual directory/marker; no Native or worker scientific execution',previous_attempt_retained=True,new_subject_and_max_one_grant_required=True,scientific_algorithm_unchanged=True,repair='Every actively read declaration/closure/input and actual output is local. Ancestor Root path descriptors remain historical data only.'),
 launch_and_pilot_accounting='This is the second observer launch attempt, following one pre-worker filesystem timeout. At most one mathematical grouping pilot may execute. All attempts/costs retained; no batching strategy, input or limit changed.',
 goal_complete=False)
dp=save(D/'prospective-design-v2.json',design)
case=load(E/'case-declaration-v1.json');case.update(global_cohort_declaration=dp,parent_structural_declaration=pin(L/'full-assertion-capsule.json'),runtime_closure=cp,schedule=[row],intake_Source_handoff=pin(S/'Source-contract-v2.json'))
dec=save(D/'case-declaration-v2.json',case)
worker=copy.deepcopy(oldw)
for k in ['invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory']:worker[k]=row[k]
worker.update(cold=h['cold'],runtime_closure=cp,integration_declaration=dec,declaration=pin(L/'full-assertion-capsule.json'))
wp=save(P/'worker-plans'/(iid+'.json'),worker)
once=copy.deepcopy(oldonce)
for k in ['invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory']:once[k]=row[k]
once.update(cold=h['cold'],runner=h['runner'],observer=h['observer'],runtime_closure=cp,worker_plan=wp,integration_declaration=dec);once.pop('authorization')
subject=sha(once);assert len(once)==18
ap=save(P/'authorization-drafts'/(iid+'.json'),dict(schema='ROOT-adaptive-group-once-authorization-v1',author_identity='/root',actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=subject,review_roles={},scope='Fresh local metadata subject only, false/max0. Does not retry or replace original failed observer slot. No launch permitted until current exact review and new Root grant.'))
once['authorization']=ap;op=save(P/'runner-plan-drafts'/(iid+'.json'),once)
idx=dict(oldidx,schedule=[dict(**row,worker_plan=wp,runner_plan_draft=op,authorization_draft=ap,subject_sha256=subject)],design=dp,runtime_closure=cp,input_capsule=pin(L/'full-assertion-capsule.json'),case_declaration=dec,cold=h['cold'],runner=h['runner'],observer=h['observer'],intake_Source_contract=pin(S/'Source-contract-v2.json'),local_operational_continuation=True,actual_execution_authorized=False)
ip=save(P/'prospective-index-v2.json',idx)
# Pre-consumption active metadata are local; no cloud project file is needed.
active=[wp,dp,cp,dec,idx['input_capsule'],h['parent_closure']]
assert all(p['path'].startswith('/private/tmp/')for p in active)
assert worker['project_sources']==oldw['project_sources']and worker['components']==oldw['components']and worker['native_inputs']==oldw['native_inputs']and worker['policy']==oldw['policy']and worker['z3']==oldw['z3']
assert case['selected_receiver']==load(E/'case-declaration-v1.json')['selected_receiver']and case['limits']==load(E/'case-declaration-v1.json')['limits']
print(json.dumps(dict(index=ip,design=dp,closure=cp,worker=wp,subject=subject,active_metadata_local=True)))
