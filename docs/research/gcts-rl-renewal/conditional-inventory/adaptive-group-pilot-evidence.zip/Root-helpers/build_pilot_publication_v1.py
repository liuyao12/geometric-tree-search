"""Publish saved evidence/documents only. No scientific replay or imports."""
from pathlib import Path
import hashlib,html,json,zipfile
D=Path(__file__).parent
PUB=Path('/private/tmp/gcts-split-controls-publish-20261015')
OUT=PUB/'docs/research/gcts-rl-renewal/conditional-inventory'
PEER=Path('/private/tmp/gcts-adaptive-group-local-peer-20261019')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def raw_pin(b):return dict(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
admit=load(D/'ROOT-actual-admission-v1.json');a=admit['actuals'][0]
assert admit['findings']==[] and admit['within_resource_profile']==1 and admit['fresh_native_proofs']==0
assert a['admission_checks_passed']and a['ROOT_resource_admitted']and a['status']=='unknown_native_inventory'
reviewpath=PEER/'peer-saved-evidence-review-v2.json';review=load(reviewpath)
# Root must inspect the independent audit before building this final packet.
assert review.get('reviewer_identity')=='/root/conventional_control_review'
assert review.get('scientific_calls')==0
assert review.get('saved_data_review_passed')is True and review.get('resource_review_passed')is True and review.get('mismatch_count')==0
data=load(D/'actual-v2/result.json');w=load(D/'plans/worker-plans/adaptive-group-002-fixed-local-ROOT-20261019-v2.json')
reg=a['registration'];walk=reg['group_walk']
assert [r['targets']for r in walk]==[38,19,9,10]and reg['accepted_definitions']==9
assert 'model'not in data['outputs']and 'search'not in data['outputs']
cert=data['outputs']['register']['certification'];transport=load(D/'actual-v2/worker-receipt.json')['native_transport']
records=[]
for receipt in cert['receipts']:
 q=data['records'][receipt['query']]
 records.append(dict(query=q['id'],group_receipt=receipt,Native_record=q,broker_COMPLETED_stage=next(s for s in transport['request_stages']if s['record_id']==q['id']and s['stage']=='COMPLETED')))
summary=dict(schema='adaptive-group-pilot-public-summary-v1',date='2026-10-19 UTC',
 status='IN_PROFILE_INVENTORY_UNKNOWN',target=data['declaration'],
 observer_launch_attempts=2,worker_scientific_pilots=1,preworker_failures=1,
 accepted_complete_inventories=0,searches_started=0,new_theorems=0,new_RL_training=False,goal_complete=False,
 recursive_proposer_enabled=False,GCTS_or_RL_search_advantage_established=False,
 registration=reg,worker_seconds=a['worker_seconds'],outer_terminal_seconds=a['outer_terminal_seconds'],
 conservative_worker_plus_Native_peak_bytes=a['peak_sum_bytes'],result_bytes=a['result']['bytes'],
 native_queries=a['native_queries'],compiler_inventory_full_prior_literal_equal=a['full_prior_compiler_inventory_literal_equal'],
 first_full_group_prior_request_and_machine_match=a['first_probe_prior_bulk_literal_and_machine_match'],
 Root_admission=pin(D/'ROOT-actual-admission-v1.json'),independent_saved_review=pin(reviewpath),
 policy='Left-first binary midpoint split only after nonsingleton space UNKNOWN. Every request charged against one original5e9 allowance. All original38 definitions/interfaces retained; no prefix activation.',
 next_decision='Do not tune more batch variants. Investigate explicit schema-level certification as a separate unimplemented architecture; qualify recursive proposer separately before fair controls.',
 limits=load(D/'case-declaration-v2.json')['limits'],
 scope='Known-case engineering pilot, not blind benchmark, theorem falsity, new proof or independent kernel soundness proof.')
save(OUT/'adaptive-group-pilot-summary.json',summary)
(OUT/'adaptive-group-pilot-admission.json').write_bytes((D/'ROOT-actual-admission-v1.json').read_bytes())
(OUT/'adaptive-group-pilot-result.json').write_bytes((D/'actual-v2/result.json').read_bytes())
(OUT/'adaptive-group-pilot-schema-design.json').write_bytes(Path('/private/tmp/gcts-schema-next-design-20261019/design-note-v1.json').read_bytes())
fmt=lambda n:r'\('+format(n,',').replace(',',r'\,')+r'\)'
rows=[]
for group,receipt in zip(walk,cert['receipts']):
 status={'unknown_space_budget':'Space UNKNOWN','accepted':'Accepted','unknown_step_budget':'Work UNKNOWN'}[group['native_status']]
 rows.append('<tr><th><code>'+str(group['query'])+'</code></th><td>'+fmt(group['targets'])+' / '+fmt(group['closure_definitions'])+'</td><td>'+fmt(group['request_bytes'])+'</td><td>'+fmt(group['consumed_micro_steps'])+'</td><td>'+fmt(receipt['assigned_micro_step_limit'])+'</td><td>'+status+'</td></tr>')
template=(D/'pilot-report-template.html').read_text()
subs={'GROUP_ROWS':''.join(rows),'WORKER_SECONDS':format(a['worker_seconds'],'.6f'),
 'TERMINAL_SECONDS':format(a['outer_terminal_seconds'],'.6f'),'PEAK_MIB':format(a['peak_sum_MiB'],'.3f'),
 'PEER_STATUS':'The completed pilot now also has an independent audit of its full saved records, without replay.',
 'AUDIT_STATUS':'Root admission and the separate saved-data review agree on the retained UNKNOWN outcome.',
 'REQUEST_RECORDS':json.dumps(records,sort_keys=True,separators=(',',':'),ensure_ascii=True).replace('</','<\\/')}
for key,value in subs.items():template=template.replace('@@'+key+'@@',value)
assert '@@'not in template
(OUT/'adaptive-group-pilot.html').write_text(template)
# Exact raw archive members; .gz members are copied as opaque bytes, never decoded.
members={};identities=[]
def add(name,p,expected=None):
 p=Path(p);b=p.read_bytes();d=pin(p)
 if expected is not None:assert d==expected,(d,expected)
 assert name not in members,name
 members[name]=b;identities.append(dict(member=name,source=d,**raw_pin(b)))
for p in sorted(D.glob('*.json')):
 if p.name=='prior-public-evidence-manifest.json':continue
 add('Root/'+p.name,p)
for p in sorted(D.glob('*.py')):add('Root-helpers/'+p.name,p)
add('Root-helpers/pilot-report-template.html',D/'pilot-report-template.html')
for p in sorted((D/'plans').rglob('*')):
 if p.is_file():add('plans/'+str(p.relative_to(D/'plans')),p)
for p in sorted((D/'actual-v2').rglob('*')):
 if p.is_file():add('actual/'+str(p.relative_to(D/'actual-v2')),p)
for p in sorted((D/'semantic-preimages').glob('*.json')):add('semantic-preimages/'+p.name,p)
for key,d in w['native_inputs'].items():add('Native-inputs/'+Path(d['path']).name,d['path'],d)
add('inputs/policy.json',w['policy']['path'],w['policy'])
for name in ('case-declaration-v2.json','runtime-closure-v2.json','prospective-design-v2.json'):
 assert 'Root/'+name in members
for p in sorted(PEER.glob('*')):
 if p.is_file()and p.suffix in ('.json','.py'):add('independent-local-reviews/'+p.name,p)
for folder,label in [
 ('/private/tmp/gcts-adaptive-group-local-intake-ROOT-source-20261019','local-intake-Source'),
 ('/private/tmp/gcts-adaptive-group-intake-ROOT-source-20261019','prior-intake-Source'),
 ('/private/tmp/gcts-adaptive-group-intake-peer-20261019','prior-intake-independent-review'),
 ('/private/tmp/gcts-adaptive-group-prospective-peer-20261019','prior-prospective-independent-review'),
 ('/private/tmp/gcts-adaptive-groups-ROOT-source-20261019','grouping-Source'),
 ('/private/tmp/gcts-adaptive-groups-independent-peer-20261019','grouping-independent-review'),
 ('/private/tmp/gcts-adaptive-group-preconsumption-diagnosis-20261019','preworker-diagnosis'),
 ('/private/tmp/gcts-recursive-qualification-source-20261019','recursive-qualification-Source-only'),
 ('/private/tmp/gcts-recursive-receptor-source-20261019','recursive-proposer-Source-only'),
 ('/private/tmp/gcts-schema-next-design-20261019','future-schema-design-only')]:
 for p in sorted(Path(folder).glob('*')):
  if p.is_file()and p.suffix in ('.json','.py','.html'):add(label+'/'+p.name,p)
local=Path('/private/tmp/gcts-local-operational-20261019')
for p in sorted(local.glob('*.json')):add('local-operational/'+p.name,p)
for p in sorted((local/'failed-launch-evidence').glob('*.json')):add('retained-failed-launch/'+p.name,p)
old=Path('/private/tmp/gcts-adaptive-group-pilot-plans-ROOT-20261019-v1')
for p in sorted(old.rglob('*')):
 if p.is_file()and p.suffix in ('.json','.bin'):add('retained-failed-launch-plans/'+str(p.relative_to(old)),p)
for role,b in load(D/'plans/authorizations/adaptive-group-002-fixed-local-ROOT-20261019-v2.json')['review_roles'].items():
 name='scoped-review-receipts/'+role+'.json';add(name,b['receipt']['path'],b['receipt'])
add('prior/parallel-research-summary.json',OUT/'parallel-research-summary.json')
design=load('/private/tmp/gcts-schema-next-design-20261019/design-note-v1.json')
for alias in ('raw_kernel_source','boundary_source','family_miner_and_specializer','ground_registry'):
 d=design['references'][alias];add('design-referenced-Source/'+Path(d['path']).name,d['path'],d)
readme='''This is retained research evidence, not a reusable launch authorization.
Two observer attempts and one worker/Native pilot are retained. The old timeout
occurred before worker consumption. The local pilot is within profile and
UNKNOWN; no Model, search or new target proof exists.

Root-helpers reproduce metadata/admission/publication only, without scientific
replay. Exact original Sources, runtime metadata and Native inputs are retained.
The opaque Native microcode gzip is copied raw; posthoc archive construction
does not decode it. Interpreter and external Z3 distribution bytes are not
bundled; their complete identities are in the runtime closure and worker plan.
Reproduction requires that pinned runtime on the declared platform and a fresh
reviewed subject/output directory and one-use authorization. Never reuse either
archived consumed observer slot or import its earlier acceptance as fresh proof.

Recursive qualification and schema-design packets remain unexecuted/proposed.
Independent reviews cover Source or saved evidence as explicitly stated; they
are not independent mathematical kernel soundness proofs.
'''.encode()
members['README.txt']=readme;identities.append(dict(member='README.txt',**raw_pin(readme)))
archive=OUT/'adaptive-group-pilot-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,b in sorted(members.items()):
  i=zipfile.ZipInfo(name,(2026,10,19,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16
  z.writestr(i,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(members)
 for name,b in members.items():assert z.read(name)==b
assets=[pin(OUT/n)for n in ('adaptive-group-pilot.html','adaptive-group-pilot-summary.json','adaptive-group-pilot-admission.json','adaptive-group-pilot-result.json','adaptive-group-pilot-schema-design.json')]
save(OUT/'adaptive-group-pilot-evidence-manifest.json',dict(schema='adaptive-group-pilot-public-manifest-v1',
 archive=pin(archive),members=identities,assets=assets,scientific_replays=0,posthoc_opaque_Native_gzip_decodes=0,
 status='one_admitted_in_profile_UNKNOWN',new_theorems=0,new_RL_training=False,goal_complete=False,
 runtime_distribution='Pinned Python and Z3 distribution not bundled; full identities in runtime closure and plan.',
 Root_admission=pin(D/'ROOT-actual-admission-v1.json'),independent_review=pin(reviewpath)))
print(json.dumps(dict(assets=assets,archive=pin(archive),members=len(members)),sort_keys=True))
