"""Document/retained-evidence validation only, no scientific replay."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re,zipfile
D=Path(__file__).parent;PUB=Path('/private/tmp/gcts-split-controls-publish-20261015');P=PUB/'docs/research/gcts-rl-renewal/conditional-inventory'
class Page(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.scripts=[];self.texts=[];self.inscript=False
 def handle_starttag(self,t,a):
  a=dict(a)
  if 'id'in a:self.ids.append(a['id'])
  if t=='a'and'href'in a:self.links.append(a['href'])
  if t=='script':self.inscript=True
  assert t not in ('sup','sub'),'Use established LaTeX renderer'
 def handle_endtag(self,t):
  if t=='script':self.inscript=False
 def handle_data(self,d):
  if self.inscript:self.scripts.append(d)
  else:self.texts.append(d)
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
f=P/'adaptive-group-pilot.html';s=f.read_text();p=Page();p.feed(s)
assert len(p.ids)==len(set(p.ids))and'@@'not in s
assert s.count('\\(')==s.count('\\)')and s.count('\\[')==s.count('\\]')
assert not any(c in ''.join(p.texts)for c in '∀∃⊢⇒→∧∨¬Σ×≤≥ℕ')
links=[]
for href in p.links:
 if href.startswith('https://'):continue
 name,_,frag=href.partition('#');name=name.partition('?')[0]
 target=f if not name else P/name
 assert target.is_file(),href
 if frag:
  pp=p
  if target!=f:pp=Page();pp.feed(target.read_text())
  assert frag in pp.ids,href
 links.append(href)
js=D/'report-inline-syntax-only.js';js.write_text('\n'.join(p.scripts))
m=json.loads((P/'adaptive-group-pilot-evidence-manifest.json').read_bytes());z=P/'adaptive-group-pilot-evidence.zip'
assert pin(z)==m['archive']
with zipfile.ZipFile(z)as archive:
 assert archive.testzip()is None
 for d in m['members']:
  b=archive.read(d['member']);assert len(b)==d['bytes']and hashlib.sha256(b).hexdigest()==d['sha256']
for d in m['assets']:assert pin(Path(d['path']))==d
summary=json.loads((P/'adaptive-group-pilot-summary.json').read_bytes())
assert summary['worker_scientific_pilots']==1 and summary['observer_launch_attempts']==2
assert summary['new_theorems']==0 and summary['searches_started']==0 and summary['new_RL_training']is False
assert summary['registration']['accepted_definitions']==9 and summary['registration']['consumed_micro_steps']==5000000000
assert (P/'adaptive-group-pilot-admission.json').read_bytes()==(D/'ROOT-actual-admission-v1.json').read_bytes()
assert (P/'adaptive-group-pilot-result.json').read_bytes()==(D/'actual-v2/result.json').read_bytes()
assert 'adaptive-group-pilot.html?v=20261019-ag1'in(P/'reader.html').read_text()
out=dict(schema='ROOT-adaptive-group-publication-static-validation-v1',document=pin(f),links_verified=len(links),archive_members_verified=len(m['members']),all_asset_bytes_verified=True,claim_counts_equal_saved_result=True,math_delimiters_balanced=True,inline_JS_extracted_for_syntax_only=str(js),scientific_replays=0,goal_complete=False)
q=D/'ROOT-publication-static-validation-v1.json';q.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out))
