This is retained research evidence, not a reusable launch authorization.
Two observer attempts and one worker/Native pilot are retained. The old timeout
occurred before worker consumption. The local pilot is within profile and
UNKNOWN; no Model, search or new target proof exists.

Root-helpers reproduce metadata/admission/publication only, without scientific
replay. Exact original Sources, runtime metadata and Native inputs are retained.
The opaque Native microcode gzip is copied raw; posthoc archive construction
does not decode it. Interpreter and external Z3 distribution bytes are not
bundled; their complete identities are in the runtime closure and worker plan.
Reproduction requires that pinned runtime on the declared platform and a fresh
reviewed subject/output directory and one-use authorization. Never reuse either
archived consumed observer slot or import its earlier acceptance as fresh proof.

Recursive qualification and schema-design packets remain unexecuted/proposed.
Independent reviews cover Source or saved evidence as explicitly stated; they
are not independent mathematical kernel soundness proofs.
