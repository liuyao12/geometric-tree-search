"""Raw JSON/AST/pin prospective composition review. No target evaluation."""
from pathlib import Path
import ast
from collections import Counter
import hashlib
import json

D=Path('/private/tmp/gcts-adaptive-group-prospective-peer-20261019');D.mkdir(exist_ok=True)
P=Path('/private/tmp/gcts-adaptive-group-pilot-plans-ROOT-20261019-v1')
I=P/'prospective-index-v1.json'
checks=[];pins={}
def ck(label,value,evidence=None):
 checks.append(dict(check=label,passed=bool(value),evidence=evidence))
 if not value:raise AssertionError(label)
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(path):
 p=Path(path).resolve();h=hashlib.sha256();n=0
 with p.open('rb')as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
 return dict(path=str(p),sha256=h.hexdigest(),bytes=n)
def exact(d,label):
 if d['path']not in pins:pins[d['path']]=pin(d['path'])
 ck(label,d==pins[d['path']],d)
 return d
def load(p):return json.loads(Path(p).read_bytes())
def pload(d,label):exact(d,label);return load(d['path'])
def descriptors(v):
 if type(v)is dict:
  if set(('path','sha256','bytes'))<=set(v) and type(v['path'])is str and type(v['sha256'])is str and type(v['bytes'])is int:yield {k:v[k]for k in ('path','sha256','bytes')}
  for a in v.values():yield from descriptors(a)
 elif type(v)is list:
  for a in v:yield from descriptors(a)

idx=load(I)
ck('fixed exact prospective index',pin(I)==dict(path=str(I),sha256='869e0d44b8a1fc0d28cdfc925f485b5965c37202b4c17ac8697481e72884ddcf',bytes=4218))
ck('false Source-only index',idx['schema']=='ROOT-adaptive-group-prospective-index-v1' and idx['source_only']is True and idx['scientific_calls']==0 and idx['actual_execution_authorized']is False and idx['subject_count']==1 and len(idx['schedule'])==1)
design=pload(idx['design'],'whole design');decl=pload(idx['case_declaration'],'whole case declaration');closure=pload(idx['runtime_closure'],'whole current runtime closure');capsule=pload(idx['input_capsule'],'whole original input capsule')
parent=pload(closure['parent_closure'],'whole prior certification closure')
row=idx['schedule'][0];worker=pload(row['worker_plan'],'whole worker plan');runner=pload(row['runner_plan_draft'],'whole false once plan');auth=pload(row['authorization_draft'],'whole false authorization')
ck('one exactly matched developmental pilot',row['receiver_id']=='prospective-fol-20261018-002' and row['mode']=='fixed' and row['search_ordering']=='and_support' and row['inventory_certification_mode']=='adaptive_groups' and row['model_storage']=='literal_interned' and row['result_reader']=='interned' and row['order']==1)
ck('design schedule same whole row',len(design['schedule'])==len(decl['schedule'])==1 and design['schedule']==decl['schedule'] and all(row[k]==v for k,v in design['schedule'][0].items()))
ck('decl/runtime/design full crosslinks',decl['global_cohort_declaration']==idx['design'] and decl['runtime_closure']==design['runtime_closure']==worker['runtime_closure']==runner['runtime_closure']==idx['runtime_closure'] and decl['parent_structural_declaration']==worker['declaration']==design['original_input_capsule']==idx['input_capsule'])
ck('exact new schemas',design['schema']=='ROOT-adaptive-group-prospective-design-v1' and decl['schema']=='ROOT-adaptive-group-experiment-declaration-v1' and closure['schema']=='ROOT-adaptive-group-raw-runtime-closure-v1' and worker['schema']=='ROOT-adaptive-group-worker-plan-v1' and runner['schema']=='ROOT-adaptive-group-once-plan-v1' and auth['schema']=='ROOT-adaptive-group-once-authorization-v1')
ck('all declarations unactivated',all(x['actual_execution_authorized']is False and x['scientific_calls']==0 for x in (design,decl,closure)))
selected=[r for r in capsule['receivers']if r['id']==row['receiver_id']]
ck('full literal selected input unique originalcase002',len(selected)==1 and len(capsule['receivers'])==10 and decl['selected_receiver']==selected[0] and decl['selected_receiver_id']==row['receiver_id'])
ck('original input dimensions and absence of route',selected[0]['length']==12 and selected[0]['instantiation_rounds']==2 and set(selected[0])=={'id','title','scope','length','instantiation_rounds','theory','target'} and selected[0]['theory']['schemas']==[])
ck('known prior outcome selection honest',design['selection']['not_blind']is True and design['selection']['known_prior_outcomes']is True and design['selection']['case']==2 and design['factors']['recursive_proposer']=='NOT_IMPORTED_OR_ACTIVATED')
ck('all19fieldplans and exact7field falseauth',len(worker)==len(runner)==19 and set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'})
ck('auth zero launch and no role grant',auth['actual_execution_authorized']is False and auth['author_identity']=='/root' and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review_roles']=={})
subject={k:v for k,v in runner.items()if k!='authorization'};subject_sha=hashlib.sha256(canon(subject)).hexdigest()
ck('full18field subject excluding ONLY auth descriptor',len(subject)==18 and subject_sha==auth['subject_sha256']==row['subject_sha256'])
ck('draft plan points exact falseauth and worker',runner['authorization']==row['authorization_draft'] and runner['worker_plan']==row['worker_plan'])
for key in ('invocation_id','receiver_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','actual_directory'):
 ck('exact pilot identity:'+key,worker[key]==runner[key]==row[key])
ck('case declaration bound in both plans',worker['integration_declaration']==runner['integration_declaration']==idx['case_declaration'])
for k in ('cold','runner','observer'):
 exact(idx[k],'exact current instrument:'+k);ck('plan current Source:'+k,runner[k]==idx[k])
ck('worker exact cold',worker['cold']==idx['cold'])
ck('same full22plus2 alias maps',worker['project_sources']==closure['project_sources'] and worker['components']==closure['additional_nonseed_components'] and len(worker['project_sources'])==22 and set(worker['components'])=={'bounded_transport','receiver_driver'})
names=dict(worker['project_sources'],semantic_receiver_driver=worker['components']['receiver_driver'],bounded_request_oracle=worker['components']['bounded_transport'])
ck('all24 aliases complete',names==closure['materialized_aliases'] and len(names)==closure['materialized_project_and_component_count']==24 and set(names)==set(parent['materialized_aliases']))
ck('no recursive proposer/science changes beyond registrydriver',[k for k in names if names[k]!=parent['materialized_aliases'][k]]==['semantic_inventory_oracle','semantic_receiver_driver'])
ck('same Native Python Z3 runtime envelope',closure['runtime']==parent['runtime'] and closure['fixed_native_inputs']==parent['fixed_native_inputs'] and closure['Z3']==parent['Z3'] and closure['native_CPP']==parent['native_CPP'] and worker['python']==runner['python']==closure['runtime']['Python_executable'] and worker['z3']['root']==closure['Z3']['package_root'] and worker['z3']['files']==[{k:z[k]for k in ('path','sha256','bytes')}for z in closure['Z3']['files']] and worker['z3']['library'] in worker['z3']['files'])
ck('exact source contracts joined',closure['Source_design']==idx['source_contract'] and design['intake_Source_contract']==idx['intake_Source_contract'] and decl['intake_Source_handoff']==idx['intake_Source_contract'])
expected_limits=dict(check_steps=2048,compile_queries=512,conservative_worker_plus_native_peak_bytes=1073741824,guard_steps=1000000000,inventory_registration_aggregate_micro_steps=5000000000,overall_seconds=210,proposal_steps=24,registry_steps=5000000000,result_bytes=134217728,search_max_nodes=5000,search_seconds=30,seed=64000,work_seconds=180)
ck('whole unchanged declaration scientific profile',design['limits']==decl['limits']==expected_limits)
once_limits=dict(work_seconds=180,overall_seconds=210,aggregate_peak_bytes=1073741824,stdout_bytes=4194304,stderr_bytes=4194304,result_bytes=134217728,worker_receipt_bytes=4194304,runner_plan_bytes=16777216,failure_cleanup_seconds=5,poll_milliseconds=20)
ck('whole original once resource profile',runner['limits']==once_limits)
ck('literal safe child environment',all(type(k)is str and type(v)is str for k,v in runner['environment'].items()) and not set(runner['environment'])&{'PATH','PYTHONPATH','PYTHONHOME','Z3_LIBRARY_PATH','DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH'})
actual=Path(row['actual_directory']);authorized=P/'authorized-index-v1.json';true_runner=P/'runner-plans'/(row['invocation_id']+'.json');true_auth=P/'authorizations'/(row['invocation_id']+'.json')
for label,path in [('actual',actual),('draft-terminal',Path(row['runner_plan_draft']['path']).with_name(Path(row['runner_plan_draft']['path']).stem+'-terminal-observation')),('true-terminal',true_runner.with_name(true_runner.stem+'-terminal-observation')),('authorized-index',authorized),('true-runner-plan',true_runner),('true-grant',true_auth)]:
 ck('fresh absent boundary:'+label,not path.exists(),str(path))
ck('actual parent exists canonical path',actual.is_absolute() and actual==actual.resolve() and actual.parent.is_dir())

# Authenticate all source/runtime bytes without loading libraries/programs.
for d in descriptors(idx):exact(d,'whole descriptor recursively:'+d['path'])
for d in descriptors(closure):exact(d,'whole closure raw descriptor:'+d['path'])
exact(worker['policy'],'exact full4template policy')
ck('policy rawidentity retained',worker['policy']['sha256']=='f5f0c22121f4c503db319fe6e01c4c3a146ac9db9deb7e2ccec0aab1a2f32161' and worker['policy']['bytes']==4502)
ck('Native input whole maps',worker['native_inputs']==dict(native_cpp=closure['native_CPP']['binary'],opaque_microcode_gzip=closure['fixed_native_inputs']['opaque_microcode_gzip'],program_and_template=closure['fixed_native_inputs']['program_and_template']))

imports=[];dynamic=[]
for alias,d in names.items():
 exact(d,'whole current alias:'+alias);tree=ast.parse(Path(d['path']).read_text(),filename=d['path'])
 for n in ast.walk(tree):
  if isinstance(n,ast.Import):
   for a in n.names:imports.append((alias,'Import',a.name,a.name.split('.')[0],n.lineno))
  elif isinstance(n,ast.ImportFrom):
   ck('no relative unresolved import:'+alias+':'+str(n.lineno),n.level==0 and n.module is not None)
   imports.append((alias,'ImportFrom',n.module,n.module.split('.')[0],n.lineno))
  elif isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='__import__':
   ck('literal dynamic import:'+alias+':'+str(n.lineno),len(n.args)==1 and isinstance(n.args[0],ast.Constant) and type(n.args[0].value)is str)
   dynamic.append((alias,n.lineno,n.args[0].value,ast.dump(n,include_attributes=False)))
declared_imports=[(x['source_module'],x['form'],x['import_name'],x['root'],x['line'])for x in closure['import_sites']]
ck('full126 import sites exact AST inventory',Counter(imports)==Counter(declared_imports) and len(imports)==126)
ck('two literal math imports exact',Counter(dynamic)==Counter((x['module'],x['line'],x['import_name'],x['call_AST'])for x in closure['literal_dynamic_import_sites']) and len(dynamic)==2)
ck('no unresolved declared project/dynamic imports',closure['unresolved_project_imports']==[] and closure['unresolved_dynamic_import_sites']==[])
ck('all project imports close over full24map',all(x['root']in names for x in closure['import_sites']if x['kind']=='project'))
ck('complete pinned41Z3 files',len(closure['Z3']['files'])==41)

scientific=dict(path='/private/tmp/gcts-adaptive-groups-independent-peer-20261019/typed-Source-review-v1.json',sha256='ff2d6a15e9625f6873554d7b682abe601c3865ec4af0297c20f59e4111e9c65c',bytes=11934)
intake=dict(path='/private/tmp/gcts-adaptive-group-intake-peer-20261019/typed-Source-review-v1.json',sha256='3500e7c81bd3419fb91d71e75c5e235f327f4878930431ada1c54244cf58d079',bytes=10939)
review_refs=dict(scientific=scientific,intake=intake,ordering=idx['unchanged_ordering_review'])
for k,d in review_refs.items():
 rr=pload(d,'exact current review:'+k)
 ck('current review scopeflags:'+k,rr['source_review_passed']is True and rr['source_only']is True and rr['scientific_calls']==0 and rr['scientific_acceptance']is False and rr['actual_execution_authorized']is False and rr['author_identity']!=rr['reviewer_identity'])
ck('scientific review fullregistry and driver subjects',names['semantic_inventory_oracle']==load(scientific['path'])['sources']['registry'] and names['semantic_receiver_driver']==load(scientific['path'])['sources']['driver'])
ck('intake review exactall3 current entry subjects',load(intake['path'])['sources']==dict(cold=idx['cold'],once_runner=idx['runner'],terminal_observer=idx['observer']))

audit=dict(schema='adaptive-group-prospective-plan-audit-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,prospective_index=pin(I),design=idx['design'],case_declaration=idx['case_declaration'],runtime_closure=idx['runtime_closure'],worker_plan=row['worker_plan'],runner_plan_draft=row['runner_plan_draft'],authorization_draft=row['authorization_draft'],subject_sha256=subject_sha,current_reviews=review_refs,all24_aliases=names,raw_pins=list(pins.values()),AST_import_sites=imports,AST_dynamic_import_sites=dynamic,check_count=len(checks),mismatch_count=0,checks=checks,review_Source=pin(Path(__file__)))
ap=D/'raw-prospective-plan-audit-v1.json';ap.write_text(json.dumps(audit,sort_keys=True,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(check_count=len(checks),unique_raw_pins=len(pins),audit=pin(ap),subject_sha256=subject_sha),indent=2))
