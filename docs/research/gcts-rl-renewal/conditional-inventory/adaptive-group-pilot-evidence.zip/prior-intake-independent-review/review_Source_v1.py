"""Raw Source/AST intake review. Never import or execute reviewed programs."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

D=Path('/private/tmp/gcts-adaptive-group-intake-peer-20261019');D.mkdir(exist_ok=True)
N=Path('/private/tmp/gcts-adaptive-group-intake-ROOT-source-20261019')
checks=[]
def ck(label,value,evidence=None):checks.append(dict(check=label,passed=bool(value),evidence=evidence))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(p):return json.loads(Path(p).read_bytes())
def raw(s,n):return ''.join(s.splitlines(True)[n.lineno-1:n.end_lineno])
def dump(n):return ast.dump(n,include_attributes=False)
def fns(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def constants(t):
 out={}
 for n in t.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:out[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
 return out
def replace(s,a,b,count=1):
 ck('inverse-count:'+str(len(checks)),s.count(a)==count,dict(literal=a,actual=s.count(a),expected=count))
 return s.replace(a,b)

cpath=N/'Source-contract-v1.json';c=load(cpath)
ck('exact-contract',pin(cpath)==dict(path=str(cpath),sha256='ad8b46d5268277504d45bb1c1f9a4f95f616f171923e5149a319f21e3e52ddc7',bytes=7292))
ck('contract-no-execution',c['source_only'] is True and c['scientific_calls']==0 and c['module_evaluations']==0 and c['actual_execution_authorized'] is False)
current={k:c[k]for k in ('cold','runner','observer')}
oldfiles=dict(cold='inventory_certification_cold_v1.py',runner='inventory_certification_once_runner_v1.py',observer='observe_inventory_certification_runner_v1.py')
parents={k:c['parent_sources'][v]for k,v in oldfiles.items()}
texts={};oldtexts={};trees={};oldtrees={};consts={};oldconsts={};retained=[]
for role,desc in current.items():
 ck(role+'-current-whole-pin',pin(desc['path'])==desc)
 ck(role+'-parent-whole-pin',pin(parents[role]['path'])==parents[role])
 texts[role]=Path(desc['path']).read_text();oldtexts[role]=Path(parents[role]['path']).read_text()
 trees[role]=ast.parse(texts[role],filename=desc['path']);oldtrees[role]=ast.parse(oldtexts[role]);compile(trees[role],desc['path'],'exec')
 ck(role+'-compile-without-evaluation',True)
 ck(role+'-all-import-AST-exact',[dump(n)for n in trees[role].body if isinstance(n,(ast.Import,ast.ImportFrom))]==[dump(n)for n in oldtrees[role].body if isinstance(n,(ast.Import,ast.ImportFrom))])
 consts[role]=constants(trees[role]);oldconsts[role]=constants(oldtrees[role])
 exclude={'cold':{'main'},'runner':{'intake_subject'},'observer':{'main'}}[role]
 for name,node in fns(oldtrees[role]).items():
  if name in exclude:continue
  nn=fns(trees[role])[name]
  ck(role+'-retained-raw-AST:'+name,raw(oldtexts[role],node)==raw(texts[role],nn) and dump(node)==dump(nn))
  retained.append(dict(component=role,callable=name,raw_AST_exact=True))

cc=consts['cold'];rc=consts['runner'];oc=consts['observer']
ck('new-cold-driver-registry-fullpins',cc['RECEIVER_DRIVER_SOURCE']==c['driver'] and cc['REGISTRY_SOURCE']==c['registry'] and pin(c['driver']['path'])==c['driver'] and pin(c['registry']['path'])==c['registry'])
ck('parent-current24-closure-rawpin',cc['PARENT_RUNTIME_CLOSURE']==c['parent_closure'] and pin(c['parent_closure']['path'])==c['parent_closure'])
ck('exact-v5-epoch',cc['EPOCH_SCHEMA']=='semantic-family-receiver-source-epoch-v5-adaptive-inventory-groups')
ck('profile-entirely-exact',rc['LIMITS']==oldconsts['runner']['LIMITS'],rc['LIMITS'])
ck('one-specific-pilot-factor',rc['KINDS']==('fixed',) and rc['CERTIFICATIONS']==('adaptive_groups',) and rc['ORDERINGS']==('and_support',) and rc['STORAGES']==('literal_interned',))
ck('all-other-cold-constant-values-exact',all(cc[k]==v for k,v in oldconsts['cold'].items()if k not in ('VERSION','PLAN_SCHEMA','EPOCH_SCHEMA','WORKER_SCHEMA','PARENT_RUNTIME_CLOSURE','RECEIVER_DRIVER_SOURCE','REGISTRY_SOURCE')))
ck('current-cold-hardpin',rc['COLD_PIN']==c['cold'])
expected_roles={
 'ordering_Source':('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
 'registry_Source':('adaptive-group-registry-driver-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'composition_Source':('adaptive-group-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'once_Source':('adaptive-group-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'prospective_plans':('adaptive-group-prospective-plan-review-v1','prospective_review_passed','/root/conventional_control_review')}
ck('exact-five-scoped-roles',rc['REVIEW_ROLES']==expected_roles,rc['REVIEW_ROLES'])
ck('new-worker-schemas-cold-once',cc['PLAN_SCHEMA']=='ROOT-adaptive-group-worker-plan-v1' and rc['WORKER_RECEIPT_SCHEMA']==cc['WORKER_SCHEMA']=='adaptive-group-worker-receipt-v1')
ck('new-once-auth-result-schemas',rc['PLAN_SCHEMA']=='ROOT-adaptive-group-once-plan-v1' and rc['AUTH_SCHEMA']=='ROOT-adaptive-group-once-authorization-v1' and rc['RECEIPT_SCHEMA']=='adaptive-group-external-once-receipt-v1')

# Full inverse normalization proves no unlisted statements changed.
for role in current:
 s=texts[role]
 for key,value in consts[role].items():
  if key in oldconsts[role] and value!=oldconsts[role][key]:
   nt=next(n for n in trees[role].body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==key for x in n.targets))
   ot=next(n for n in oldtrees[role].body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==key for x in n.targets))
   s=replace(s,raw(texts[role],nt),raw(oldtexts[role],ot))
 if role=='cold':
  repairs=[
   ("need(plan['mode']=='fixed'","need(plan['mode'] in ('fixed','symbolic')"),
   ("need(plan['inventory_certification_mode']=='adaptive_groups'","need(plan['inventory_certification_mode'] in ('bulk','dependency_closures')"),
   ("integration['schema']=='ROOT-adaptive-group-experiment-declaration-v1'","integration['schema']=='ROOT-inventory-certification-experiment-declaration-v1'"),
   ('len(schedule)==1 and len({r[\'invocation_id\'] for r in schedule})==1','len(schedule)==4 and len({r[\'invocation_id\'] for r in schedule})==4'),
   ("len({r['actual_directory'] for r in schedule})==1","len({r['actual_directory'] for r in schedule})==4"),
   ("{('fixed','adaptive_groups')}","{(m,c) for m in ('fixed','symbolic') for c in ('bulk','dependency_closures')}"),
   ('one complete fixed/adaptive-group pilot subject with common assertion/storage/reader','four unique complete method-by-certification subjects with common assertion/storage/reader'),
   ("closure['schema']=='ROOT-adaptive-group-raw-runtime-closure-v1'","closure['schema']=='ROOT-inventory-certification-raw-runtime-closure-v1'"),
   ('complete same24 project/component aliases in the declared pilot','complete same24 project/component aliases in all four arms')]
 elif role=='runner':
  repairs=[
   ("worker['schema']=='ROOT-adaptive-group-worker-plan-v1'","worker['schema']=='ROOT-inventory-certification-worker-plan-v1'"),
   ("closure['schema']=='ROOT-adaptive-group-raw-runtime-closure-v1'","closure['schema']=='ROOT-inventory-certification-raw-runtime-closure-v1'"),
   ("declaration['schema']=='ROOT-adaptive-group-experiment-declaration-v1'","declaration['schema']=='ROOT-inventory-certification-experiment-declaration-v1'"),
   ('len(ids)==1 and len(set(ids))==1','len(ids)==4 and len(set(ids))==4'),
   ("len({r['actual_directory'] for r in schedule})==1","len({r['actual_directory'] for r in schedule})==4"),
   ('complete single fixed/adaptive-group pilot declaration','complete unique four-arm factorial declaration')]
 else:
  repairs=[
   ("plan['schema']=='ROOT-adaptive-group-once-plan-v1'","plan['schema']=='ROOT-inventory-certification-once-plan-v1'"),
   (c['runner']['sha256'],parents['runner']['sha256']),
   ("schema='adaptive-group-final-terminal-observation-v1'","schema='inventory-certification-final-terminal-observation-v1'")]
 for x,y in repairs:s=replace(s,x,y)
 ck(role+'-whole-inverse-raw-AST-exact',s==oldtexts[role] and dump(ast.parse(s))==dump(oldtrees[role]))

cold=texts['cold'];run=texts['runner'];obs=texts['observer']
requirements={
 'cold-unchanged-full-input-capsule':('cold','1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0'),
 'cold-mode-exact':('cold',"need(plan['mode']=='fixed'"),
 'cold-certification-exact':('cold',"need(plan['inventory_certification_mode']=='adaptive_groups'"),
 'cold-ordering-exact':('cold',"need(plan['search_ordering']=='and_support'"),
 'cold-reader-exact':('cold',"need(plan['result_reader']=='interned'"),
 'cold-storage-exact':('cold',"type(plan['model_storage']) is str and plan['model_storage']=='literal_interned'"),
 'cold-one-unique-schedule':('cold',"len(schedule)==1 and len({r['invocation_id'] for r in schedule})==1"),
 'cold-one-factor-set':('cold',"{('fixed','adaptive_groups')}"),
 'cold-parent-exact-declaration':('cold',"integration['parent_structural_declaration']==plan['declaration']"),
 'cold-only-registry-project-replacement':('cold',"expected_project['semantic_inventory_oracle']=REGISTRY_SOURCE"),
 'cold-exact24-all-imported':('cold',"need(len(plan['project_sources'])==22 and len(names)==24"),
 'cold-code-native-pin-same':('cold',"epoch=dict(schema=EPOCH_SCHEMA"),
 'cold-certification-driver-call':('cold',"inventory_certification_mode=plan['inventory_certification_mode']"),
 'cold-result-factor':('cold',"result_data['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode']"),
 'once-one-exact-row':('runner',"len(ids)==1 and len(set(ids))==1"),
 'once-fixed-product':('runner',"{(m,c) for m in KINDS for c in CERTIFICATIONS}"),
 'once-whole-worker-factor':('runner',"('invocation_id','mode','search_ordering','inventory_certification_mode','actual_directory','cold','python','receiver_id','result_reader','model_storage','integration_declaration','runtime_closure')"),
 'once-cap-metadata':('runner',"'inventory_registration_aggregate_micro_steps':5000000000"),
 'once-review-driver-subject':('runner',"'composition_Source':[plan['cold'],worker['components']['receiver_driver']]"),
 'once-review-registry-subject':('runner',"'registry_Source':[worker['project_sources']['semantic_inventory_oracle']]"),
 'once-review-no-self-author':('runner',"review['author_identity']!=reviewer and review['source_only'] is True"),
 'once-review-raw-whole-descriptor':('runner',"need(contains_literal(review,subject)"),
 'once-subject-only-auth-excluded':('runner',"subject={k:v for k,v in plan.items() if k!='authorization'}"),
 'once-current-maxone':('runner',"auth['maximum_actual_invocations']==1"),
 'once-consumed-marker-before-Popen':('runner',"marker_pin=write_new(actual/'CONSUMED.json'"),
 'once-current-result-epoch-factor':('runner',"result['source_epoch']['inventory_certification_mode']==plan['inventory_certification_mode']"),
 'once-positive-known-exit-before180':('runner',"worker_receipt['work_completed'] is True and terminal_ns<work_end"),
 'once-permanent-reappearance-veto':('runner',"need(group_reappearance_observed_ns is None,'owned PGID reappearance is permanently unaccepted')"),
 'once-native-exact-parent-reap':('runner',"native['parent_pid']==pid and native['parent_pgid']==pgid"),
 'once-separate-peaks':('runner',"aggregate=wait_usage['ru_maxrss']+native['native_high_water_bytes']"),
 'once-captured-OS-guard':('runner',"'callback_policy':'OUTER_POLL_METADATA_ONLY_NO_REBASELINE'"),
 'observer-whole-factor-join':('observer',"receipt['inventory_certification_mode']==plan['inventory_certification_mode']"),
 'observer-new-runner-hardpin':('observer',c['runner']['sha256']),
 'observer-full-EOF':('observer',"receipt['stdout_eof'] is True and receipt['stderr_eof'] is True and receipt['log_capture_complete'] is True"),
 'observer-clock-scope':('observer','Parent Source-entry epoch excludes observer/Python prelude')}
for label,(role,s) in requirements.items():ck(label,s in texts[role],s)
ck('once-only-one-worker-Popen',run.count('subprocess.Popen(')==1 and run.index("marker_pin=write_new(actual/'CONSUMED.json'")<run.index('subprocess.Popen('))
ck('exact-four-coldargv-unchanged',"plan['cold']['path'],plan['worker_plan']['path'],str(began),str(work_end),str(overall_end)]" in run)
ck('final-outer-rawloop-still-after-profile',run.index("need(aggregate<=LIMITS['aggregate_peak_bytes']")<run.index("for key,cap in [('runner',1048576),('observer',1048576),('python',67108864)"))
ck('worker-and-once-plan-fields-still19',len(next(n.value for n in ast.walk(fns(trees['cold'])['main'])if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='fields'for t in n.targets)).elts)==19 and len(next(n.value for n in ast.walk(fns(trees['runner'])['run_once'])if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='fields'for t in n.targets)).elts)==19)

reviews={
 'parent_once':dict(path='/private/tmp/gcts-inventory-certification-once-peer-20261018/typed-once-Source-review-v1.json',sha256='df6ced88c37337787caa574f16de862ff479ee5634bca27c0192eece56aa870f',bytes=11952),
 'parent_cold':dict(path='/private/tmp/gcts-inventory-batching-ROOT-peer-20261018/typed-driver-cold-Source-review-v1.json',sha256='f9e30b79bf10bf098822d7b2177649862f72aee99ec653327ca6124c404eb20d',bytes=11740),
 'current_registry_driver':dict(path='/private/tmp/gcts-adaptive-groups-independent-peer-20261019/typed-Source-review-v1.json',sha256='ff2d6a15e9625f6873554d7b682abe601c3865ec4af0297c20f59e4111e9c65c',bytes=11934),
 'genuine_old_outer_Receiver':dict(path='/private/tmp/gcts-compact-model-cold-once-independent-peer-20261018/typed-Source-review-v2.json',sha256='d1fed0448738dbe07efbd2482a6259dc58ecf21473a3cbf46bf09e61a242d4a2',bytes=7732)}
for k,p in reviews.items():
 r=load(p['path']);ck('exact-review-ancestry:'+k,pin(p['path'])==p and r['source_review_passed'] is True and r['scientific_calls']==0)
ck('scientific-current-review-both-sources',all(c[k] in load(reviews['current_registry_driver']['path'])['sources'].values()for k in ['registry','driver']))

patches=[]
for role in current:
 folder=D/(role+'-inert-F0');folder.mkdir(exist_ok=True)
 for direction,a,b in [('forward',oldtexts[role],texts[role]),('inverse',texts[role],oldtexts[role])]:
  p=folder/(direction+'.patch');p.write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='payload.txt',tofile='payload.txt')))
  (folder/'payload.txt').write_text(a)
  result=subprocess.run(['patch','--batch','--fuzz=0','-p0','-i',str(p)],cwd=folder,capture_output=True,text=True)
  ck('inert-F0:'+role+':'+direction,result.returncode==0 and (folder/'payload.txt').read_text()==b,dict(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
  patches.append(dict(component=role,direction=direction,patch=pin(p)))
audit=dict(schema='adaptive-group-intake-raw-Source-audit-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,contract=pin(cpath),sources=current,parents=parents,registry=c['registry'],driver=c['driver'],parent_closure=c['parent_closure'],checks=checks,check_count=len(checks),mismatch_count=sum(not r['passed']for r in checks),retained_callables=retained,ancestry_reviews=reviews,actual_inert_F0_directions=patches,compile_without_evaluation_count=3,review_Source=pin(Path(__file__)))
ap=D/'raw-Source-audit-v1.json';ap.write_text(json.dumps(audit,sort_keys=True,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(check_count=len(checks),mismatches=[r for r in checks if not r['passed']],audit=pin(ap)),indent=2))
