"""Raw Source derivation and syntax-only checks. No science import/evaluation."""
import ast,hashlib,json
from pathlib import Path
D=Path(__file__).parent
P=Path('/private/tmp/gcts-inventory-certification-intake-ROOT-source-20261018')
S=Path('/private/tmp/gcts-adaptive-groups-ROOT-source-20261019')
C=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/inventory-certification-progress-20261018/runtime-closure-v1.json')
def pin(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def replace(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n)
 return s.replace(a,b)
def constant(s,name,value):
 a=s.index(name+' = ');b=s.index('\n',a)
 return s[:a]+name+' = '+repr(value)+s[b:]
def save(name,s):
 ast.parse(s);compile(s,name,'exec');p=D/name;assert not p.exists();p.write_text(s);return pin(p)
def common(s):
 for a,b in [
 ('ROOT-inventory-certification-worker-plan-v1','ROOT-adaptive-group-worker-plan-v1'),
 ('semantic-family-receiver-source-epoch-v4-inventory-certification','semantic-family-receiver-source-epoch-v5-adaptive-inventory-groups'),
 ('inventory-certification-worker-receipt-v1','adaptive-group-worker-receipt-v1'),
 ('ROOT-inventory-certification-experiment-declaration-v1','ROOT-adaptive-group-experiment-declaration-v1'),
 ('ROOT-inventory-certification-raw-runtime-closure-v1','ROOT-adaptive-group-raw-runtime-closure-v1'),
 ('ROOT-inventory-certification-once-plan-v1','ROOT-adaptive-group-once-plan-v1'),
 ('ROOT-inventory-certification-once-authorization-v1','ROOT-adaptive-group-once-authorization-v1'),
 ('inventory-certification-external-once-receipt-v1','adaptive-group-external-once-receipt-v1'),
 ('inventory-certification-final-terminal-observation-v1','adaptive-group-final-terminal-observation-v1')]:s=s.replace(a,b)
 return s
s=common((P/'inventory_certification_cold_v1.py').read_text())
s=constant(s,'VERSION','adaptive-group-intake-cold-v1')
s=constant(s,'PARENT_RUNTIME_CLOSURE',pin(C))
s=constant(s,'RECEIVER_DRIVER_SOURCE',pin(S/'inventory_certification_receiver_driver_v3.py'))
s=constant(s,'REGISTRY_SOURCE',pin(S/'semantic_inventory_oracle_v3.py'))
s=replace(s,"plan['mode'] in ('fixed','symbolic')","plan['mode']=='fixed'")
s=replace(s,"plan['inventory_certification_mode'] in ('bulk','dependency_closures')","plan['inventory_certification_mode']=='adaptive_groups'")
s=replace(s,"len(schedule)==4 and len({r['invocation_id'] for r in schedule})==4 and\n             len({r['actual_directory'] for r in schedule})==4", "len(schedule)==1 and len({r['invocation_id'] for r in schedule})==1 and\n             len({r['actual_directory'] for r in schedule})==1")
s=replace(s,"{(m,c) for m in ('fixed','symbolic') for c in ('bulk','dependency_closures')}","{('fixed','adaptive_groups')}")
s=s.replace('four unique complete method-by-certification subjects','one complete fixed/adaptive-group pilot subject').replace('same24 project/component aliases in all four arms','same24 project/component aliases in the declared pilot')
cold=save('adaptive_group_cold_v1.py',s)
s=common((P/'inventory_certification_once_runner_v1.py').read_text())
s=constant(s,'VERSION','adaptive-group-external-once-runner-v1')
s=constant(s,'KINDS',('fixed',));s=constant(s,'CERTIFICATIONS',('adaptive_groups',));s=constant(s,'COLD_PIN',cold)
s=constant(s,'REVIEW_ROLES',{
 'ordering_Source':('and-support-ordering-components-typed-Source-review-v1','source_review_passed','/root/receiver_driver_review'),
 'registry_Source':('adaptive-group-registry-driver-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'composition_Source':('adaptive-group-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'once_Source':('adaptive-group-intake-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),
 'prospective_plans':('adaptive-group-prospective-plan-review-v1','prospective_review_passed','/root/conventional_control_review')})
s=replace(s,"len(ids)==4 and len(set(ids))==4","len(ids)==1 and len(set(ids))==1")
s=replace(s,"len({r['actual_directory'] for r in schedule})==4","len({r['actual_directory'] for r in schedule})==1")
s=s.replace('complete unique four-arm factorial declaration','complete single fixed/adaptive-group pilot declaration')
runner=save('adaptive_group_once_runner_v1.py',s)
s=common((P/'observe_inventory_certification_runner_v1.py').read_text())
s=constant(s,'VERSION','adaptive-group-final-terminal-observer-v1')
s=replace(s,'d030e8a59113a5d0a8d6bacaba72208f3ca4480704d2f8acb7e3998f09e64968',runner['sha256'])
observer=save('observe_adaptive_group_runner_v1.py',s)
# Independently count/compare every retained top-level callable after raw derivation.
def funcs(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
checks=[]
for old,new,changed in [('inventory_certification_cold_v1.py','adaptive_group_cold_v1.py',{'main'}),('inventory_certification_once_runner_v1.py','adaptive_group_once_runner_v1.py',{'intake_subject'}),('observe_inventory_certification_runner_v1.py','observe_adaptive_group_runner_v1.py',{'main'})]:
 a=funcs(P/old);b=funcs(D/new)
 for k,v in a.items():
  if k in changed:continue
  assert v==b[k],(old,k)
  checks.append(dict(parent=old,callable=k,unchanged_ast=True))
contract=dict(schema='ROOT-adaptive-group-intake-Source-contract-v1',author_identity='/root',source_only=True,scientific_calls=0,module_evaluations=0,actual_execution_authorized=False,
 cold=cold,runner=runner,observer=observer,registry=pin(S/'semantic_inventory_oracle_v3.py'),driver=pin(S/'inventory_certification_receiver_driver_v3.py'),parent_closure=pin(C),
 parent_sources={p.name:pin(p) for p in [P/'inventory_certification_cold_v1.py',P/'inventory_certification_once_runner_v1.py',P/'observe_inventory_certification_runner_v1.py']},
 schema_and_schedule='Fresh v5 epoch + adaptive-group envelopes; exact one fixed/and_support/adaptive_groups arm. All24 imports/Z3/Native/full reader remain charged; same original assertion capsule; no recursive factor.',
 retained_profile=dict(work_seconds=180,overall_seconds=210,aggregate_peak_bytes=1073741824,result_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,registration_micro_steps=5000000000,search_seconds=30,search_units=5000),
 review_scope='New registry/driver review plus current cold/once/observer delta review; inherited ordering review unchanged. Composition and once roles may point to the same explicitly scoped intake review, rather than count as independent reviewers. Previous parent reviews/ancestry retained.',
 checks=checks,compile_without_evaluation=3,status='SOURCE_ONLY_UNEXECUTED')
p=D/'Source-contract-v1.json';assert not p.exists();p.write_text(json.dumps(contract,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(contract=pin(p),cold=cold,runner=runner,observer=observer,unchanged_callable_checks=len(checks))))
