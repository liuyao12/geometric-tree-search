"""Narrow saved-metadata authorization delta; no launcher or target calls."""
import hashlib
import json
from pathlib import Path

OUT=Path('/private/tmp/gcts-adaptive-group-local-peer-20261019')
BASE=Path('/private/tmp/gcts-adaptive-group-local-pilot-20261019')
checks=[]

def check(name,condition,detail=None):
    checks.append(dict(check=name,passed=bool(condition),detail=detail))
    if not condition:raise AssertionError(name)

def pin(p):
    b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

def load(d,label):
    p=Path(d['path']);b=p.read_bytes()
    check(label+' complete raw pin',set(d)=={'path','sha256','bytes'} and dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==d)
    return json.loads(b)

def objects(v):
    stack=[v];result=[]
    while stack:
        x=stack.pop()
        if type(x)is dict:result.append(x);stack.extend(x.values())
        elif type(x)is list:stack.extend(x)
    return result

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def write(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    return pin(p)

ai=dict(path=str(BASE/'plans/authorized-index-v2.json'),sha256='35d13556e897e0fec9be4535c0b695ce623868d894023221477b142642d8d177',bytes=5974)
pi=dict(path=str(BASE/'plans/prospective-index-v2.json'),sha256='6a40ab447ea7680745dac26aeb07dc534a1d11a2ff4c5442981209a792e96a90',bytes=4032)
pr=dict(path=str(OUT/'typed-prospective-review-v2.json'),sha256='c29ed63c22ac2b8ff45e000b9d4f4f1ca698576210495a57dfae184336817820',bytes=27201)
authorized=load(ai,'authorized index');prospective=load(pi,'false index');peer=load(pr,'current false prospective review')
check('current prospective PASS exact false index scope',peer['schema']=='adaptive-group-prospective-plan-review-v1' and peer['prospective_review_passed']is True and peer['prospective_index']==pi and peer['scientific_acceptance']is False and peer['actual_execution_authorized']is False)
check('one Root max-one continuation authorized index',authorized['schema']=='ROOT-adaptive-group-authorized-index-v1' and authorized['author_identity']=='/root' and authorized['actual_execution_authorized']is True and authorized['actuals_started']==0 and authorized['subject_count']==1 and len(authorized['schedule'])==1)
for key in prospective:
    if key not in ('schema','actual_execution_authorized','schedule'):
        check('same false-index field '+key,authorized[key]==prospective[key])
row=authorized['schedule'][0];oldrow=prospective['schedule'][0]
check('schedule only adds true runner/auth descriptors',set(row)==set(oldrow)|{'runner_plan','authorization'})
for key,value in oldrow.items():check('schedule unchanged '+key,row[key]==value)
oldonce=load(oldrow['runner_plan_draft'],'false once plan')
newonce=load(row['runner_plan'],'authorized once plan')
oldauth=load(oldrow['authorization_draft'],'false authorization')
newauth=load(row['authorization'],'true authorization')
worker=load(row['worker_plan'],'unchanged worker plan')
check('worker unchanged exact prospective descriptor',row['worker_plan']==peer['worker_plan'] and row['worker_plan']==oldrow['worker_plan'])
check('same exact19 once fields; only auth descriptor differs',len(newonce)==len(oldonce)==19 and set(newonce)==set(oldonce) and {k for k in newonce if newonce[k]!=oldonce[k]}=={'authorization'})
check('new once auth and worker joined to authorized index',newonce['authorization']==row['authorization'] and newonce['worker_plan']==row['worker_plan'])
subject={k:v for k,v in newonce.items() if k!='authorization'}
oldsubject={k:v for k,v in oldonce.items() if k!='authorization'}
sha=hashlib.sha256(canonical(subject)).hexdigest()
check('whole18-field preimage unchanged',len(subject)==18 and subject==oldsubject)
check('exact4c4e subject at all boundaries',sha==row['subject_sha256']==oldrow['subject_sha256']==oldauth['subject_sha256']==newauth['subject_sha256']==peer['subject_sha256']=='4c4ee9f38b8a86ef2ff5edfe7e925a86649590ee8fb99cc0bdc6c2fb52b7f657')
check('false/max0 draft remains false',oldauth['actual_execution_authorized']is False and type(oldauth['maximum_actual_invocations'])is int and oldauth['maximum_actual_invocations']==0 and oldauth['review_roles']=={})
check('true/max1 exact Root grant',newauth['author_identity']=='/root' and newauth['actual_execution_authorized']is True and type(newauth['maximum_actual_invocations'])is int and newauth['maximum_actual_invocations']==1)
check('auth only authorized flag/maximum/roles/scope change',set(newauth)==set(oldauth) and {k for k in newauth if newauth[k]!=oldauth[k]}=={'actual_execution_authorized','maximum_actual_invocations','review_roles','scope'})
check('same local iid/actual/receiver/method choices',newonce['invocation_id']=='adaptive-group-002-fixed-local-ROOT-20261019-v2' and newonce['actual_directory']==str(BASE/'actual-v2') and all(newonce[k]==worker[k]==row[k] for k in ('invocation_id','actual_directory','mode','receiver_id','search_ordering','inventory_certification_mode','model_storage','result_reader')))
check('new iid different old failed slot',newonce['invocation_id']!='adaptive-group-002-fixed-ROOT-20261019-v1')
source_reviews=peer['current_Source_reviews']
expected_receipts={'ordering_Source':source_reviews['ordering'],'registry_Source':source_reviews['registry_driver'],'composition_Source':source_reviews['current_intake'],'once_Source':source_reviews['current_intake'],'prospective_plans':pr}
expected_reviewers={k:('/root/receiver_driver_review' if k=='ordering_Source' else '/root/conventional_control_review') for k in expected_receipts}
aliases=peer['all24scientific_sources']
expected_subjects={
 'ordering_Source':[aliases[k] for k in ('semantic_inventory_search_v2','quantified_symbolic_control_v2','receptor_support_ordering_v1')],
 'registry_Source':[aliases['semantic_inventory_oracle'],aliases['semantic_receiver_driver']],
 'composition_Source':[newonce['cold'],aliases['semantic_receiver_driver']],
 'once_Source':[newonce['runner'],newonce['observer']],
 'prospective_plans':[newonce['integration_declaration'],newonce['runtime_closure'],newonce['worker_plan']]}
roles=newauth['review_roles']
check('exact5 scoped role names',set(roles)==set(expected_receipts))
check('authorized index role descriptors exact',authorized['current_review_roles']==expected_receipts)
role_summaries={};all_subjects=[]
schemas={'ordering_Source':'and-support-ordering-components-typed-Source-review-v1','registry_Source':'adaptive-group-registry-driver-typed-Source-review-v1','composition_Source':'adaptive-group-intake-typed-Source-review-v1','once_Source':'adaptive-group-intake-typed-Source-review-v1','prospective_plans':'adaptive-group-prospective-plan-review-v1'}
for name,binding in roles.items():
    check(name+' exact binding fields/receipt/reviewer',set(binding)=={'receipt','reviewer_identity','required_subjects'} and binding['receipt']==expected_receipts[name] and binding['reviewer_identity']==expected_reviewers[name])
    check(name+' exact full required subjects',binding['required_subjects']==expected_subjects[name])
    review=load(binding['receipt'],name+' exact current raw receipt')
    passkey='prospective_review_passed' if name=='prospective_plans' else 'source_review_passed'
    check(name+' actual schema/PASS/identity/scope flags',review['schema']==schemas[name] and review[passkey]is True and review['reviewer_identity']==expected_reviewers[name] and review['author_identity']!=review['reviewer_identity'] and review['source_only']is True and type(review['scientific_calls'])is int and review['scientific_calls']==0 and review['scientific_acceptance']is False and review['actual_execution_authorized']is False)
    tree_objects=objects(review)
    for d in binding['required_subjects']:
        check(name+' full descriptor present '+Path(d['path']).name,d in tree_objects)
        all_subjects.append(d)
    role_summaries[name]=dict(receipt=binding['receipt'],reviewer_identity=binding['reviewer_identity'],required_subjects=binding['required_subjects'],review_scope=review.get('scope','See exact receipt scopes and limitations'))
check('four unique raw receipts covering5roles',len({(b['receipt']['path'],b['receipt']['sha256'],b['receipt']['bytes']) for b in roles.values()})==4)
check('two reviewer identities honestly disclosed',set(b['reviewer_identity'] for b in roles.values())=={'/root/receiver_driver_review','/root/conventional_control_review'})
check('composition/once same exact receipt not separate reviewers',roles['composition_Source']['receipt']==roles['once_Source']['receipt'] and roles['composition_Source']['reviewer_identity']==roles['once_Source']['reviewer_identity'])
check('registry scope BOTH full current registry and driver',roles['registry_Source']['required_subjects']==[aliases['semantic_inventory_oracle'],aliases['semantic_receiver_driver']] and len(roles['registry_Source']['required_subjects'])==2)
adoption_path=BASE/'ROOT-final-grant-adoption-v2.json';adoption=json.loads(adoption_path.read_bytes())
check('Root adoption exact indexes/subject/roles',adoption['authorized_index']==ai and adoption['false_index']==pi and adoption['subject_sha256']==sha and adoption['current_review_roles']==expected_receipts and adoption['actuals_started']==0 and adoption['maximum_actual_invocations']==1 and adoption['original_failed_attempt_retained']is True and adoption['new_local_operational_slot']is True and adoption['exact18field_subject_unchanged']is True and adoption['scientific_acceptance']is False and adoption['scientific_calls']==0)
actual=Path(newonce['actual_directory']);observer=Path(row['runner_plan']['path']).parent/(Path(row['runner_plan']['path']).stem+'-terminal-observation')
fresh=[actual,actual/'CONSUMED.json',actual/'worker-receipt.json',actual/'runner-receipt.json',actual/'result.json',observer,observer/'CONSUMED.json',observer/'terminal.json']
for p in fresh:check('launch freshness absent '+str(p),not p.exists())
check('fresh actual/observer parent directories exist',actual.parent.is_dir() and observer.parent.is_dir())
audit=write(OUT/'final-grant-delta-audit-v2.json',dict(schema='adaptive-group-local-final-grant-delta-audit-v2',source_only=True,scientific_calls=0,checks=checks,authorized_index=ai,prospective_index=pi,prospective_review=pr,whole_subject_preimage=subject,subject_sha256=sha,complete_authorization=newauth,current_roles=role_summaries,adoption=pin(adoption_path),grant_helper_raw_pin=pin(BASE/'grant_local_v2.py'),fresh_absent_paths=[str(x) for x in fresh]))
receipt=dict(schema='adaptive-group-final-grant-delta-review-v2',author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,final_grant_delta_review_passed=True,grant_delta_review_passed=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,resource_acceptance=False,scope='Narrow saved-metadata false-to-true authorization delta only; no new Source/semantic/runtime evaluation',authorized_index=ai,prospective_index=pi,prospective_review=pr,worker_plan=row['worker_plan'],false_runner_plan=row['runner_plan_draft'],authorized_runner_plan=row['runner_plan'],false_authorization=row['authorization_draft'],authorized_authorization=row['authorization'],case_declaration=authorized['case_declaration'],runtime_closure=authorized['runtime_closure'],subject_sha256=sha,subject_field_count=18,only_runner_plan_change='authorization descriptor',authorization_delta=['actual_execution_authorized:false->true','maximum_actual_invocations:0->1','review_roles:{}->exact5scopedroles','scope:currentsinglelocalgrant'],current_review_roles=role_summaries,unique_receipt_count=4,reviewer_identity_count=2,registry_scope_includes_both_current_registry_and_driver=True,check_count=len(checks),mismatch_count=0,Root_adoption=pin(adoption_path),audit=audit,review_Source=pin(Path(__file__)),fresh_paths_checked=[str(x) for x in fresh],ancestry={'reviewer_authored_inherited_outer_broker_earlier_driver':True,'reviewer_authored_current_helper_symbolic':True,'reviewer_previously_authored_current_Source_and_prospective_reviews':True,'no_new_independent_self_Source_certificate':True,'Root_authored_current_grant_metadata':True,'composition_and_once_same_receipt_not_two_reviewers':True},limitations=['Only the saved grant delta and exact role coverage/freshness are checked; this is not an execution or mathematical authorization issued by the reviewer. Root owns the true grant and launch decision.','Current full18-field scientific subject, worker bytes and all prior prospective data/Source/runtime/profile bindings are unchanged. Their previous scoped reviews are relied upon, not repeated scientific evaluation.','Five roles use four unique receipts and two reviewer identities. Composition and once intentionally share f56b and are not independent second reviews. Prior own outer/helper/symbolic/driver authorship remains disclosed; genuine Receiver ordering and inherited Source review scopes remain separate.','The old pre-worker timeout remains retained and is not relabeled a grouping result. This is a distinct local invocation; both total observer attempts and all costs must be reported. No original consumed slot is reused.','No target import, Native/Model/compiler/solver/search/Reader/renderer/codec/fixture evaluation, trial or launch occurred. Filesystem locality does not supply a formal interruptible-I/O guarantee; original resource/terminal/custody gates and final Native/point scientific admission remain future obligations.','Freshness is a metadata observation at review time, not continuous process ownership. Root must keep other agents idle and preflight the exact pinned observer command once immediately before its launch.'],idle_after_receipt=True)
r=write(OUT/'typed-final-grant-delta-review-v2.json',receipt)
h=write(OUT/'final-grant-delta-handoff-v2.json',dict(schema='adaptive-group-local-final-grant-delta-peer-handoff-v2',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=r,audit=audit,authorized_index=ai,subject_sha256=sha))
print(json.dumps(dict(review=r,audit=audit,handoff=h,checks=len(checks)),indent=2))
