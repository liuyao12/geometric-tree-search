"""Independent retained JSON/byte joins only; no scientific import or replay."""
import hashlib
import json
import math
from pathlib import Path

BASE=Path('/private/tmp/gcts-adaptive-group-local-pilot-20261019')
ACTUAL=BASE/'actual-v2'
OUT=Path('/private/tmp/gcts-adaptive-group-local-peer-20261019')
checks=[];artifacts={}

def check(label,value,detail=None):
    checks.append(dict(check=label,passed=bool(value),detail=detail))
    if not value:raise AssertionError(label)

def pin(path):
    raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def raw_pin(d,label):
    path=Path(d['path']);raw=path.read_bytes()
    check(label+' whole raw SHA/size',set(d)=={'path','sha256','bytes'} and dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))==d)
    artifacts[d['path']]=d
    return raw

def pairs(rows):
    v={}
    for k,x in rows:
        if k in v:raise ValueError('duplicate JSON key')
        v[k]=x
    return v

def bad_constant(x):raise ValueError('nonfinite JSON constant')
def parse(raw):return json.loads(raw,object_pairs_hook=pairs,parse_constant=bad_constant)
def load(d,label):return parse(raw_pin(d,label))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(v):return hashlib.sha256(canonical(v)).hexdigest()
def write(p,v):
    with p.open('xb') as stream:stream.write((json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
    return pin(p)

admission_desc=dict(path=str(BASE/'ROOT-actual-admission-v1.json'),sha256='6e19521d521bdd6f485b325e302ac4f4e1ba4e15dd5440ce1cde209718a509b5',bytes=12879)
admission=load(admission_desc,'Root authored admission bound as conclusion only')
check('one admitted-record packet/no Root replay claims',admission['retained_actuals']==1 and len(admission['actuals'])==1 and admission['scientific_replays']==0 and admission['Native_calls']==0)
root=admission['actuals'][0]
index=load(admission['authorized_index'],'authorized index')
check('exact authorized index current pin',admission['authorized_index']['sha256']=='35d13556e897e0fec9be4535c0b695ce623868d894023221477b142642d8d177')
row=index['schedule'][0]
plan=load(row['runner_plan'],'true once plan');worker=load(row['worker_plan'],'worker plan');auth=load(row['authorization'],'true Root grant')
source_delta=load(dict(path=str(OUT/'typed-Source-review-v2.json'),sha256='f56bee67a3d6653091294657b1d6b9339de29307479d507372bcb9b946ed4d8e',bytes=9973),'current Source relocation peer')
prospective=load(dict(path=str(OUT/'typed-prospective-review-v2.json'),sha256='c29ed63c22ac2b8ff45e000b9d4f4f1ca698576210495a57dfae184336817820',bytes=27201),'current prospective peer')
delta=load(dict(path=str(OUT/'typed-final-grant-delta-review-v2.json'),sha256='4f4b1379e4ac868df2e92a3b4920994f3a684ea5614f874da8f01294938d32ca',bytes=12688),'final true-grant delta peer')
check('previous exact grant delta PASS and no own launch',delta['final_grant_delta_review_passed']is True and delta['actual_execution_authorized']is False and delta['authorized_index']==admission['authorized_index'])
check('exact subject still4c4e/max1',len(plan)==19 and digest({k:v for k,v in plan.items()if k!='authorization'})==auth['subject_sha256']==row['subject_sha256']=='4c4ee9f38b8a86ef2ff5edfe7e925a86649590ee8fb99cc0bdc6c2fb52b7f657' and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1)
check('exact5review roles unchanged from final delta',auth['review_roles']=={k:{'receipt':v['receipt'],'reviewer_identity':v['reviewer_identity'],'required_subjects':v['required_subjects']} for k,v in delta['current_review_roles'].items()})
for name,b in auth['review_roles'].items():
    rv=load(b['receipt'],'retained exact role '+name)
    check(name+' Source-only no activation and expected reviewer',rv['source_only']is True and rv['scientific_calls']==0 and rv['actual_execution_authorized']is False and rv['reviewer_identity']==b['reviewer_identity'])
rr=load(root['runner_receipt'],'whole runner receipt');wr=load(root['worker_receipt'],'whole worker receipt');terminal=load(root['terminal'],'whole final observer terminal');result_raw=raw_pin(root['result'],'whole current raw result');result=parse(result_raw)
marker=load(rr['consumed_marker'],'exclusive consumed marker')
obsdir=Path(root['terminal']['path']).parent
observer_consumed=load(pin(obsdir/'CONSUMED.json'),'exclusive observer consumed marker')
for k in ('invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id'):
    check('whole run identity '+k,rr[k]==plan[k]==row[k])
    if k in wr:check('worker run identity '+k,wr[k]==plan[k])
    if k in result:check('result run identity '+k,result[k]==plan[k])
check('Root row true plan joined',root['runner_plan']==row['runner_plan'] and root['worker_plan']==row['worker_plan'] and rr['plan']==row['runner_plan'] and wr['worker_plan']==row['worker_plan'] and rr['authorization']==row['authorization'])
check('exact runner/worker/Native PIDs distinct and PGID owned',terminal['runner_pid']!=rr['python_pid'] and rr['python_pid']==rr['owned_pgid'] and rr['python_pid']!=rr['native_transport']['native_pid'])
check('one consumed before worker launch',marker['plan']==row['runner_plan'] and marker['invocation_id']==plan['invocation_id'] and marker['consumed_before_Popen']is True and marker['maximum_worker_launches']==1 and rr['consumed_once']is True and rr['worker_launch_attempts']==1 and rr['worker_pid_observed']is True and observer_consumed['maximum_runner_launches']==1 and observer_consumed['plan']==row['runner_plan'])
check('exact all known exit0 and wait4 statuses',terminal['runner_exit_code']==0 and rr['python_exit_code']==0 and rr['python_wait4_status']==0 and rr['python_reaped']is True and rr['native_transport']['native_exit_code']==0 and rr['native_transport']['wait4_status']==0)
began=rr['began_ns'];work=began+180000000000;overall=began+210000000000
check('one original Source-entry absolute180/210 across marker/worker',rr['work_deadline_ns']==wr['work_deadline_ns']==marker['work_deadline_ns']==work and rr['overall_deadline_ns']==wr['overall_deadline_ns']==marker['overall_deadline_ns']==overall and wr['began_ns']==marker['began_ns']==began)
check('strict worker output/verification/exit before180',began<wr['driver_returned_ns']<=wr['custody_checked_ns']<=wr['result_reading']['completed_ns']<=rr['worker_terminal_observed_ns']<work)
check('strict terminal/finalchecks/drain before210',rr['worker_terminal_observed_ns']<=rr['postreap_group_and_pipe_closed_ns']<=rr['checks_closed_ns']<=terminal['terminal_observed_ns']<overall and rr['owned_group_last_probe_ns']<=rr['checks_closed_ns'])
check('correct complete known EOF/group/no reappearance/no signals',rr['owned_group_absent']is True and rr['stdout_eof']is True and rr['stderr_eof']is True and rr['log_capture_complete']is True and rr['owned_group_reappearance_observed_ns']is None and rr['signals']==[] and rr['errors']==[] and rr['owned_group_probe_count']>=1 and rr['worker_terminal_observed_ns']<=rr['owned_group_first_absent_ns']<=rr['owned_group_last_probe_ns'])
check('no late failure marker',not(ACTUAL/'POST_RECEIPT_DEADLINE_FAILURE.json').exists())
expected_command=[plan['python']['path'],'-I','-S','-B',plan['runner']['path'],row['runner_plan']['path']]
check('observer exact pinned command and known terminal',terminal['command']==expected_command and terminal['plan']==row['runner_plan'] and terminal['runner_receipt']==root['runner_receipt'] and terminal['terminal_gate_passed']is True)
check('observer elapsed excludes its prelude consistently',terminal['runner_clock_elapsed_seconds']==(terminal['terminal_observed_ns']-began)/1e9 and terminal['observed_instrument_elapsed_seconds']==(terminal['terminal_observed_ns']-terminal['observer_started_ns'])/1e9)
for key,d in rr['outputs'].items():
    raw=raw_pin(d,'complete outer output '+key)
    if key in ('stdout','stderr'):
        check(key+' captured bytes under4MiB',len(raw)==rr[key+'_bytes']<=4194304)
check('raw result pointer joins worker/output/Root',rr['outputs']['result']==wr['result']==root['result'])
output=wr['driver_output_receipt']['output']
check('whole atomic result driver hash/size/cap',all(output[k]==root['result'][k]for k in ('path','sha256','bytes')) and output['atomic']is True and output['complete']is True and output['cap_bytes']==134217728 and len(result_raw)<=134217728)
check('positive or UNKNOWN serialization preflight under original work',began/1e9<=output['serialization_started_monotonic']<=output['payload_serialized_monotonic']<=output['publication_preflight_monotonic']<work/1e9 and wr['work_completed']is True and result['work_window_complete']is True)
check('full own stdlib JSON reencoding exact raw body',canonical(result)+b'\n'==result_raw)
reading=wr['result_reading'];body=result_raw[:-1]
check('retained complete Reader inverse metadata matches independent whole raw',reading['reader']=='interned' and reading['roundtrip']['literal_bytes_equal']is True and reading['roundtrip']['body_bytes']==len(body) and reading['roundtrip']['body_sha256']==hashlib.sha256(body).hexdigest() and reading['started_ns']<=reading['decoded_ns']<=reading['completed_ns']<work)
check('Reader decode elapsed exact',reading['decode_seconds']==(reading['decoded_ns']-reading['started_ns'])/1e9)

transport=result['transport_receipt']
check('whole Native transport identical4retained copies',transport==wr['native_transport']==rr['native_transport']==wr['driver_output_receipt']['transport_receipt'])
check('exact Native process ownership/reaping/closure',transport['native_pid']>0 and transport['parent_pid']==transport['parent_pgid']==transport['native_pgid']==rr['python_pid'] and transport['same_owned_process_group']is True and transport['all_reaped']is True and transport['closed']is True and transport['constructor_completed']is True and transport['native_exit_code']==0 and transport['wait4_status']==0)
check('complete Native EOF/bounded IO/no cleanup or signals',transport['stdout_eof']is True and transport['stdout_pending_bytes']==0 and transport['stderr_complete']is True and transport['stderr_bytes']==0 and transport['stdout_bytes']<=transport['limits']['stdout_total_bytes'] and transport['cleanup_errors']==[] and transport['termination_signals']==[])
check('Native same absolute work/closure deadlines',transport['work_deadline']==work/1e9 and transport['closure_deadline']==overall/1e9)
worker_peak=rr['python_wait4_usage']['ru_maxrss'];native_peak=transport['wait4_usage']['ru_maxrss'];peak=worker_peak+native_peak
check('separate Darwin highwater exact sum under1GiB',type(worker_peak)is int and type(native_peak)is int and worker_peak>0 and native_peak>0 and native_peak==transport['native_high_water_bytes'] and peak==rr['conservative_parent_plus_native_peak_bytes']<=1073741824)
check('no live peak or self CPP authority claim',rr['live_group_memory_limit_claimed']is False and transport['CPP_self_reported_peak_is_resource_authority']is False)
check('resource candidate reconstructs original limits',rr['limits']==plan['limits'] and rr['resource_candidate_accepted']is True and rr['logical_proof_transport_candidate']is False and rr['scientific_acceptance']is False)

closure=load(plan['runtime_closure'],'current runtime closure');epoch=result['source_epoch'];names=dict(worker['project_sources'],semantic_receiver_driver=worker['components']['receiver_driver'],bounded_request_oracle=worker['components']['bounded_transport'])
check('complete24 original/owned epoch maps',len(names)==24 and epoch['sources']['original']==names==closure['materialized_aliases'] and set(epoch['sources']['project'])==set(names) and epoch['sources']['cold']==plan['cold'])
check('whole sourceepoch canonical hash',digest(epoch)==wr['source_epoch_sha256'])
origin_lookup={x['module']:x['path']for x in wr['import_origins']}
for name,original in names.items():
    owned=epoch['sources']['project'][name]
    raw_pin(original,'current original Source '+name);raw_pin(owned,'current owned Source '+name)
    check('owned/original raw byte authority '+name,original['sha256']==owned['sha256'] and original['bytes']==owned['bytes'] and owned['path']==str(ACTUAL/'modules'/(name+'.py')) and origin_lookup[name]==owned['path'])
check('no recursive proposer alias or origin',not any('recursive' in x.lower()for x in names) and not any('recursive' in x.lower()for x in origin_lookup))
for key in ('cold','runner','observer'):raw_pin(plan[key],'current exact '+key+' Source')
raw_pin(worker['python'],'whole current pinned Python');raw_pin(worker['policy'],'whole policy')
check('epoch/runtime Python/policy/declaration joins',epoch['python']==worker['python']==plan['python'] and epoch['policy']==worker['policy'] and epoch['declaration']==worker['declaration'] and epoch['z3']==worker['z3'])
for d in worker['z3']['files']:raw_pin(d,'Z3 raw only '+Path(d['path']).name)
check('full41 Z3 raw files retained',len(worker['z3']['files'])==41)
for name,d in epoch['native_inputs'].items():raw_pin(d,'native raw only '+name)
check('native epoch exact program/binary/opaque artifacts from plan',{k:v for k,v in epoch['native_inputs'].items()if k!='code_bin'}==worker['native_inputs'])
for field,module in [('selected_family_model','interned_quantified_family_points_v1'),('selected_search_module','semantic_inventory_search_v2'),('support_ordering_module','receptor_support_ordering_v1')]:
    check('selected owned/current '+field,wr[field]['module']==module and wr[field]['original']==names[module] and wr[field]['owned']==epoch['sources']['project'][module])
role_aliases={'base_compiler':'quantified_receptors_v1','family_miner':'semantic_lemma_inventory','family_model':'interned_quantified_family_points_v1','family_registry':'semantic_inventory_oracle','family_search':'semantic_inventory_search_v2','point_smt':'semantic_point_smt','symbolic_control':'quantified_symbolic_control_v2','support_ordering':'receptor_support_ordering_v1'}
check('actual scientific role pins exact selected owned modules',result['module_pins']=={k:epoch['sources']['project'][v]for k,v in role_aliases.items()})
check('outer Python metadata evidence scoped correctly',rr['python_custody']['python']==plan['python'] and rr['python_custody']['whole_baseline_authenticated']is True and rr['python_custody']['formal_continuous_seal']is False and rr['python_custody']['worker_callback_guard_claimed']is False and rr['python_custody']['callback_policy']=='OUTER_POLL_METADATA_ONLY_NO_REBASELINE')

prior_path=BASE/'prior-case002-fixed-bulk-result.json';prior_desc=pin(prior_path);prior=load(prior_desc,'whole local prior bulk baseline')
manifest_desc=pin(BASE/'prior-public-evidence-manifest.json');manifest=load(manifest_desc,'saved public prior manifest metadata')
stack=[manifest];matches=[]
while stack:
    x=stack.pop()
    if type(x)is dict:
        if x.get('sha256')==prior_desc['sha256'] and x.get('bytes')==prior_desc['bytes']:matches.append(x)
        stack.extend(x.values())
    elif type(x)is list:stack.extend(x)
check('local prior fullraw matches saved public archive manifest',len(matches)>=1 and prior_desc['sha256']=='c8bc92e3d1035ef21d3fca88bc923e24308f8acfcfdef242747323911383292b' and prior_desc['bytes']==367907)
check('exact full declared receiver prior/current/selection',result['declaration']==prior['declaration']==result['receiver_selection']['spec']==epoch['receiver_selection']['spec'] and result['receiver_selection']==epoch['receiver_selection'] and digest(result['receiver_selection'])==wr['receiver_selection_sha256'])
check('whole compiler literal equality omitting onlyseconds',{k:v for k,v in result['outputs']['compile'].items()if k!='seconds'}=={k:v for k,v in prior['outputs']['compile'].items()if k!='seconds'})
check('whole original specialized inventory identical prior bulk',result['outputs']['specialize']==prior['outputs']['specialize'])
inventory=result['outputs']['specialize'];reg=result['outputs']['register'];cert=reg['certification'];defs=inventory['definitions'];blocks=inventory['native_blocks'];all_names=[x['name']for x in defs]
check('all38 definitions/blocks/interfaces full ordered preserved',len(all_names)==len(blocks)==len(inventory['interfaces'])==38 and len(set(all_names))==38 and blocks==[x['definition']for x in defs] and all(x['name']==b['name']for x,b in zip(defs,blocks)) and all(reg[k]==inventory[k]for k in ('definitions','interfaces','native_blocks')))
dependencies={};seen=[]
for name,block in zip(all_names,blocks):
    deps=[]
    for cmd in block['proof']:
        if cmd['rule']=='block':
            check('definition call strict-prior literal '+name,cmd['name']in seen)
            if cmd['name']not in deps:deps.append(cmd['name'])
    dependencies[name]=deps;seen.append(name)
check('actual inventory has no nontrivial dependency edges',sum(map(len,dependencies.values()))==0)
check('cert full preimages and original interfaces',cert['inventory_sha256']==digest(inventory) and cert['theory_sha256']==digest(result['declaration']['theory']) and cert['all_original_definition_names']==all_names and cert['all_original_interfaces']==inventory['interfaces'] and cert['initial_group']==dict(path=[],target_names=all_names))
records=result['records'];stages=transport['request_stages']
check('all55 records/transport stages complete ordered',len(records)==len(stages)==transport['complete_records']==55 and [x['id']for x in records]==list(range(55)))
for n,(record,stage)in enumerate(zip(records,stages)):
    check('Native'+str(n)+' request whole SHA',record['request_sha256']==digest(record['request']))
    check('Native'+str(n)+' full broker hash/id/purpose join',stage['ordinal']==stage['record_id']==record['id']==n and stage['stage']=='COMPLETED' and all(stage[k]==record[k]for k in ('purpose','request_sha256','input_sha256','output_sha256')))
    check('Native'+str(n)+' actual steps under passed budget',type(stage['limit'])is int and type(record['result']['micro_steps'])is int and 0<=record['result']['micro_steps']<=stage['limit']<=5000000000)
    check('Native'+str(n)+' whole full original theory',record['request']['theory']==result['declaration']['theory'] and record['request']['protocol']=='gcts-fol-1')
check('compile original51 record requests/guards/machinefields equal prior',len(result['outputs']['compile']['queries'])==51 and result['outputs']['compile']['queries']==list(range(51)) and all(records[i]['request']==prior['records'][i]['request'] and {k:v for k,v in records[i]['result'].items()if k not in ('seconds','peak_native_memory_bytes')}=={k:v for k,v in prior['records'][i]['result'].items()if k not in ('seconds','peak_native_memory_bytes')} and stages[i]['limit']==1000000000 for i in range(51)))
check('four and onlyfour registration queries',reg['queries']==[51,52,53,54] and [x['purpose']for x in records[51:]]==['check_generated_lemma_definition_group']*4 and len(cert['receipts'])==4)
pending=[dict(path=[],target_names=list(all_names))];accepted=set();used=0;group_rows=[];requests=[]
for ordinal,receipt in enumerate(cert['receipts']):
    proposed=pending[0];targets=proposed['target_names'];wanted=set(targets);todo=list(targets)
    while todo:
        for name in dependencies[todo.pop()]:
            if name not in wanted:wanted.add(name);todo.append(name)
    closure_names=[name for name in all_names if name in wanted]
    q=records[51+ordinal];stage=stages[51+ordinal];req=dict(protocol='gcts-fol-1',theory=result['declaration']['theory'],blocks=[blocks[all_names.index(name)]for name in closure_names],proof=[dict(rule='tautology',formula=['imp',['bot'],['bot']])],target=['imp',['bot'],['bot']])
    remaining=5000000000-used;consumed=q['result']['micro_steps'];status=q['result']['status']
    action='accept_group' if status=='accepted' else 'split_group' if status=='unknown_space_budget' and len(targets)>1 else 'stop_inventory'
    check('group'+str(ordinal)+' actual queue head/path/ordered targets',receipt['ordinal']==ordinal and receipt['path']==proposed['path'] and receipt['target_names']==targets)
    check('group'+str(ordinal)+' full independent dependency closure',receipt['closure_names']==closure_names)
    check('group'+str(ordinal)+' complete literal request',q['request']==req and receipt['request_sha256']==q['request_sha256']==digest(req) and q['query_target']=='fixed_assertion')
    check('group'+str(ordinal)+' exact residual broker budget',receipt['assigned_micro_step_limit']==stage['limit']==remaining and receipt['aggregate_consumed_before']==used and receipt['consumed_micro_steps']==consumed and receipt['aggregate_consumed_after']==used+consumed)
    check('group'+str(ordinal)+' native status/action/onefreshquery',receipt['query']==q['id']==51+ordinal and receipt['result_status']==status and receipt['action']==action)
    used+=consumed
    if action=='accept_group':accepted.update(closure_names);pending.pop(0)
    elif action=='split_group':
        middle=len(targets)//2;pending[:1]=[dict(path=proposed['path']+[0],target_names=targets[:middle]),dict(path=proposed['path']+[1],target_names=targets[middle:])]
    else:check('stop is last recorded request',ordinal==len(cert['receipts'])-1)
    group_rows.append(dict(query=q['id'],path=receipt['path'],target_count=len(targets),closure_count=len(closure_names),request_bytes=len(canonical(req)),request_sha256=digest(req),assigned_micro_steps=remaining,consumed_micro_steps=consumed,aggregate_after=used,status=status,action=action,native_result=q['result'],broker_stage=stage))
    requests.append(dict(query=q['id'],path=receipt['path'],dependency_closure=closure_names,full_reconstructed_request=req))
check('exact observed4path progression',[(x['path'],x['target_count'],x['status'])for x in group_rows]==[([],38,'unknown_space_budget'),([0],19,'unknown_space_budget'),([0,0],9,'accepted'),([0,1],10,'unknown_step_budget')])
check('all failed parent cost charged total5e9',used==cert['aggregate_consumed_micro_steps']==cert['aggregate_micro_step_limit']==5000000000)
check('accepted9/pending29 exact coverage',cert['accepted_definition_names']==[n for n in all_names if n in accepted] and len(accepted)==9 and cert['pending_groups']==pending and [x['path']for x in pending]==[[0,1],[1]] and len({n for x in pending for n in x['target_names']})==29 and accepted.isdisjoint({n for x in pending for n in x['target_names']}) and accepted|{n for x in pending for n in x['target_names']}==set(all_names))
check('incomplete inventory stays UNKNOWN no partial authority',cert['complete']is False and cert['stop_reason']=='unknown_step_budget' and reg['status']==result['status']=='unknown_native_inventory' and result['outputs']['inventory_record_join']['complete']is False and result['outputs']['inventory_record_join']['full_original_inventory']is False)
first=records[51];prior_bulk=[x for x in prior['records']if x['purpose']=='check_generated_lemma_definitions']
check('first full group exactly same prior bulk full request',len(prior_bulk)==1 and first['request']==prior_bulk[0]['request'] and first['request_sha256']==prior_bulk[0]['request_sha256'] and first['input_sha256']==prior_bulk[0]['input_sha256'])
machine_fields=('status','start','state','micro_steps','micro_fnv64','physical_head','physical_steps')
check('first bulk exact all non-time non-peak machinefields',all(first['result'][k]==prior_bulk[0]['result'][k]for k in machine_fields))
raw_pin(dict(path=str(ACTUAL/'native/input.bin'),sha256=records[-1]['input_sha256'],bytes=(ACTUAL/'native/input.bin').stat().st_size),'last native input raw hash only')
raw_pin(dict(path=str(ACTUAL/'native/output.bin'),sha256=records[-1]['output_sha256'],bytes=(ACTUAL/'native/output.bin').stat().st_size),'last native output raw hash only')
check('no Model/search/point/proof products or positive flags',not(set(result['outputs'])&{'model','search','point_verification','final_native','essential_observation'}) and all(result[k]is False for k in ('native_proof_accepted','quantified_reasoning_success','family_hint_success')) and 'initial_state'not in result and wr['final_region_verification']=={'status':'NOT_CHECKED_NO_NATIVE_PROOF'} and wr['logical_proof_accepted']is False)
for name in ('before_oracle','compile','compile_record_joins','specialize','register','inventory_record_join'):check('ordered returned stage present '+name,name in result['outputs'])
for x in result['stage_intervals']:check('returned scientific stage within shared work '+x['stage'],began/1e9<=x['started_monotonic']<=x['returned_monotonic']<work/1e9)
for x in wr['cold_stages']:check('cold stage charged '+x['stage'],began<=x['started_ns']<=x['returned_ns']<work)
check('Native close before output and under work',result['scientific_stopped_monotonic']<=result['closure_started_monotonic']<=result['oracle_closed_monotonic']<=output['serialization_started_monotonic']<work/1e9)
closeout=load(admission['cohort_closure'],'Root saved cohort/PID closeout metadata')
check('Root closed PID metadata exact retained PIDs',closeout['exact_worker_pid']==rr['python_pid'] and closeout['exact_native_pid']==transport['native_pid'] and closeout['runner_receipt']==root['runner_receipt'] and closeout['terminal']==root['terminal'] and closeout['all_workers_and_native_groups_closed']is True and closeout['exact_pid_inspection_stdout_empty']is True and closeout['exact_pid_inspection_exit_code']==1)
failed_path=Path('/private/tmp/gcts-local-operational-20261019/failed-launch-evidence/ROOT-failed-attempt-closure-v1.json');failed=load(pin(failed_path),'preserved old preworker attempt closeout')
check('two observer attempts exactlyone scientific pilot',closeout['total_observer_launch_attempts']==2 and closeout['total_worker_scientific_pilots']==1 and closeout['previous_observer_launch_failed_preworker']is True and failed['Native_queries']==0 and failed['scientific_worker_launch_observed']is False and failed['observer_terminal']['terminal_gate_passed']is False)
elapsed=(terminal['terminal_observed_ns']-began)/1e9;worker_elapsed=(rr['worker_terminal_observed_ns']-began)/1e9
summary=dict(status=result['status'],resource_profile_passed=True,proof_accepted=False,Model_constructed=False,search_reached=False,definition_count=len(all_names),accepted_definitions=len(accepted),pending_definitions=29,group_requests=len(group_rows),all_native_queries=len(records),registration_micro_steps=used,worker_peak_bytes=worker_peak,native_peak_bytes=native_peak,conservative_peak_sum_bytes=peak,conservative_peak_sum_MiB=peak/1048576,worker_exit_seconds=worker_elapsed,external_terminal_Source_entry_seconds=elapsed,observer_instrument_elapsed_seconds=terminal['observed_instrument_elapsed_seconds'],result_bytes=len(result_raw),compile_seconds=result['outputs']['compile']['seconds'],registration_seconds=reg['seconds'],Reader_decode_seconds=reading['decode_seconds'],observer_attempts=2,scientific_pilots=1)
check('Root outcome table independently reconstructed values',root['status']==summary['status'] and root['outer_terminal_seconds']==elapsed and root['worker_seconds']==worker_elapsed and root['peak_sum_bytes']==peak and root['peak_sum_MiB']==peak/1048576 and root['native_queries']==len(records) and root['registration']['consumed_micro_steps']==used and root['registration']['accepted_definitions']==len(accepted) and root['model_placements']==root['required_points']==0 and root['proof']is None)
for actual_group,expected in zip(root['registration']['group_walk'],group_rows):check('Root group presentation exact query'+str(expected['query']),actual_group['query']==expected['query'] and actual_group['path']==expected['path'] and actual_group['targets']==expected['target_count'] and actual_group['closure_definitions']==expected['closure_count'] and actual_group['consumed_micro_steps']==expected['consumed_micro_steps'] and actual_group['aggregate_used']==expected['aggregate_after'] and actual_group['request_bytes']==expected['request_bytes'] and actual_group['native_status']==expected['status'])
request_packet=write(OUT/'reconstructed-group-requests-v2.json',dict(schema='adaptive-group-retained-literal-requests-v2',retained_data_only=True,scientific_calls=0,dependency_names=dependencies,requests=requests,first_bulk_prior_machine_fields={k:first['result'][k]for k in machine_fields}))
audit=write(OUT/'saved-evidence-audit-v2.json',dict(schema='adaptive-group-local-retained-evidence-audit-v2',retained_data_only=True,scientific_calls=0,checks=checks,artifacts=list(artifacts.values()),group_table=group_rows,summary=summary,whole_original_inventory_sha256=digest(inventory),whole_compiler_nontiming_sha256=digest({k:v for k,v in result['outputs']['compile'].items()if k!='seconds'}),pending_groups=pending,accepted_names=[n for n in all_names if n in accepted],prior_manifest_matches=matches,independent_reconstructed_requests=request_packet))
receipt=dict(schema='adaptive-group-local-peer-saved-evidence-review-v2',author_identity='/root',reviewer_identity='/root/conventional_control_review',saved_data_review_passed=True,resource_review_passed=True,source_only=True,retained_data_only=True,scientific_calls=0,scientific_replays=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,project_imports=0,native_calls=0,model_calls=0,compiler_calls=0,solver_calls=0,search_calls=0,Reader_calls=0,codec_calls=0,opaque_native_decode_calls=0,scope='Independent retained request/queue/budget/hash/compiler-inventory equality and resource/custody joins only; not independent mathematical kernel soundness or proof admission',Root_admission=admission_desc,authorized_index=admission['authorized_index'],runner_plan=row['runner_plan'],worker_plan=row['worker_plan'],authorization=row['authorization'],result=root['result'],worker_receipt=root['worker_receipt'],runner_receipt=root['runner_receipt'],terminal=root['terminal'],cohort_closure=admission['cohort_closure'],prior_full_baseline=prior_desc,prior_public_manifest=manifest_desc,original_failed_attempt=pin(failed_path),current_Source_review=pin(OUT/'typed-Source-review-v2.json'),prospective_review=pin(OUT/'typed-prospective-review-v2.json'),final_grant_delta_review=pin(OUT/'typed-final-grant-delta-review-v2.json'),reconstructed_group_requests=request_packet,summary=summary,group_table=group_rows,check_count=len(checks),mismatch_count=0,raw_artifact_count=len(artifacts),audit=audit,review_Source=pin(Path(__file__)),findings=[dict(id='FOUR_GROUPS_COMPLETE_LITERAL_ACCOUNTING',finding='Full38 request, left19, left9, then remaining10 match the independently reconstructed binary queue, exact original-order dependency closures and full-theory Native packets. Space-only parent splits and the accepted9/remaining29 coverage match. All actual dependencies are empty; multi-level closures were not exercised.'),dict(id='RESIDUAL_BUDGET_EXHAUSTED',finding='Actual broker limits5,000,000,000;4,127,145,391;3,066,864,234;1,271,634,576 and all failed-probe costs match receipts and sum exactly5e9. Last Native status unknown_step_budget halts the incomplete inventory; no prefix search authority follows.'),dict(id='FULL_PRIOR_EQUALITY',finding='Whole compiler excluding only seconds and the whole specialized inventory are literal-equal to the pinned saved prior bulk result. First full-group request/input hash and every non-time/non-peak machine field match prior bulk. Native time/self-reported peak differ and are not equality or resource authority requirements.'),dict(id='IN_PROFILE_UNKNOWN',finding='Worker and Native exit0, exact wait4 and ownership/EOF/group-absence evidence, no signals/reappearance, serialization/known worker exit and external terminal meet the original180/210/caps. Separate Darwin highwater sum272.703125MiB is within1GiB. This accepts resource evidence for UNKNOWN, not the receiver theorem.'),dict(id='ATTEMPTS_RETAINED',finding='Old225second pre-worker observer failure is retained; there are two observer attempts and exactly one scientific grouping pilot. No Model/search/proof was reached in the successful local launch.')],ancestry={'reviewer_authored_inherited_outer_broker_earlier_driver':True,'reviewer_authored_current_helper_symbolic':True,'reviewer_previously_reviewed_Root_registry_driver_and_intake_metadata':True,'execution_and_admission_author':'/root','retained_audit_not_new_own_Source_certificate':True},limitations=[
 'No Native/kernel soundness, logical inference, formula evaluation, compiler/model/search/solver/Reader replay, scientific fixture, renderer or program/opaque codec was run. This independently checks saved literal packets and arithmetic/byte/hash joins only. Machine statuses remain outputs of the pinned trusted Native execution, not re-proved mathematical facts.',
 'Only the last native input.bin/output.bin are retained as raw files; those full hashes match record54. For earlier54 queries, input/output SHA strings are joined across full records and completed broker stages, not independently regenerated or decoded. First full-group historical machine equivalence is a saved-data equality, not a new execution.',
 'All38 actual definition dependency lists are empty; the pilot therefore does not runtime-qualify nontrivial recursive dependency closure. All original definitions/interfaces/bodies and strict order are retained without mathematical evaluation.',
 'Nine accepted definitions are an incomplete prefix. Twenty-nine remain pending and the aggregate5e9 cap is exhausted. UNKNOWN neither refutes the receiver theorem nor grants Model/search/whole-inventory authority. There is no final target proof, whole-region acceptance, useful cluster/search performance or GCTS/RL superiority result.',
 'The1GiB test sums separate Darwin Python and Native highwater peaks and can double count; it is not a simultaneous live-RAM measurement or OS enforcement. Outer/observer/controller memory and pre-Source-entry interpreter/observer prelude remain excluded/separately observed. Whole serialization/read/verification and known worker exit are charged to the original Source-entry work clock.',
 'Original and owned24 module bytes, runtime inputs,41Z3 files and retained import origins are joined. Trust in Python/bundled stdlib/platform loader/OS metadata and captured-callable custody remains conditional, not formal continuous sealing or arbitrary adversarial mutation coverage. Final outer raw checks were eligible here because the profile passed; failures cannot inherit that claim.',
 'Reaping/group absence evidence is retained exact-PID wait4/EOF/probe metadata plus Root recorded final PID inspection, not an independent live process probe by this reviewer or proof of continuous absence between samples. No new launch, retry, Source change, tuning, grant or publication is authorized.',
 'Reviewer authored inherited outer/protocol and current helper/symbolic Sources and earlier driver/checkers; Root authored current execution and admission. This is a distinct retained-data review of Root evidence, not a new independent Source certificate of inherited own components or an independent mathematical kernel audit.'] )
saved=write(OUT/'peer-saved-evidence-review-v2.json',receipt)
handoff=write(OUT/'saved-evidence-handoff-v2.json',dict(schema='adaptive-group-local-saved-peer-handoff-v2',reviewer_identity='/root/conventional_control_review',retained_data_only=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=saved,audit=audit,reconstructed_group_requests=request_packet,summary=summary))
print(json.dumps(dict(review=saved,audit=audit,handoff=handoff,checks=len(checks),raw_artifacts=len(artifacts),summary=summary),indent=2))
