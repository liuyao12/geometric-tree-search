"""Ordinary frozen metadata/Source hashing only; no target imports or activation."""
import ast
import hashlib
import json
from pathlib import Path
import stat

OUT=Path('/private/tmp/gcts-adaptive-group-local-peer-20261019')
INDEX=Path('/private/tmp/gcts-adaptive-group-local-pilot-20261019/plans/prospective-index-v2.json')
OLD=Path('/private/tmp/gcts-adaptive-group-pilot-plans-ROOT-20261019-v1')
EVIDENCE=Path('/private/tmp/gcts-local-operational-20261019/failed-launch-evidence')
checks=[];verified={};raws={}

def check(label,value,detail=None):
    checks.append(dict(check=label,passed=bool(value),detail=detail))
    if not value:raise AssertionError(label)

def pin(path):
    b=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

def load(d,label):
    check(label+' exact descriptor',type(d)is dict and set(d)=={'path','sha256','bytes'} and type(d['path'])is str and type(d['bytes'])is int and d['bytes']>0 and type(d['sha256'])is str and len(d['sha256'])==64)
    p=Path(d['path']);check(label+' absolute canonical nonsymlink regular',p.is_absolute() and p==p.resolve() and stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink())
    if d['path'] not in verified:
        b=p.read_bytes();check(label+' full raw SHA/bytes',dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))==d);verified[d['path']]=d;raws[d['path']]=b
    else:check(label+' same complete descriptor on reuse',verified[d['path']]==d)
    return raws[d['path']]

def json_load(d,label):return json.loads(load(d,label))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
def write(p,v):
    with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    return pin(p)

index_desc=dict(path=str(INDEX),sha256='6a40ab447ea7680745dac26aeb07dc534a1d11a2ff4c5442981209a792e96a90',bytes=4032)
index=json_load(index_desc,'current prospective index')
check('Root false Source-only one-subject index',index['schema']=='ROOT-adaptive-group-prospective-index-v1' and index['author_identity']=='/root' and index['source_only']is True and index['scientific_calls']==0 and index['actual_execution_authorized']is False and index['subject_count']==1 and len(index['schedule'])==1 and index['local_operational_continuation']is True)
row=index['schedule'][0]
design=json_load(index['design'],'current design')
decl=json_load(index['case_declaration'],'current case declaration')
closure=json_load(index['runtime_closure'],'current runtime closure')
worker=json_load(row['worker_plan'],'current whole worker plan')
once=json_load(row['runner_plan_draft'],'current whole once draft')
auth=json_load(row['authorization_draft'],'current false authorization')
input_data=json_load(index['input_capsule'],'current complete assertion capsule')
contract=json_load(index['intake_Source_contract'],'current local intake contract')
science_contract=json_load(index['source_contract'],'unchanged registry driver Source contract')
for label,v in [('design',design),('case declaration',decl),('runtime closure',closure)]:
    check(label+' Root/source-only/no execution',v['author_identity']=='/root' and v['source_only']is True and v['scientific_calls']==0 and v['actual_execution_authorized']is False)
check('index current design and declaration closure descriptors joined',design['runtime_closure']==decl['runtime_closure']==worker['runtime_closure']==once['runtime_closure']==index['runtime_closure'] and decl['global_cohort_declaration']==index['design'] and decl['intake_Source_handoff']==index['intake_Source_contract'])
check('same one-row full schedule in design and declaration',design['schedule']==decl['schedule'] and len(decl['schedule'])==1)
schedule=decl['schedule'][0]
for key in ('invocation_id','mode','search_ordering','inventory_certification_mode','receiver_id','result_reader','model_storage','actual_directory'):
    check('full schedule/once/worker/index literal '+key,row[key]==schedule[key]==once[key]==worker[key])
check('schedule order1 and fresh distinct invocation',row['order']==schedule['order']==1 and row['invocation_id']=='adaptive-group-002-fixed-local-ROOT-20261019-v2')
check('exact sole arm and original fixed choices',(row['mode'],row['search_ordering'],row['inventory_certification_mode'],row['model_storage'],row['result_reader'],row['receiver_id'])==('fixed','and_support','adaptive_groups','literal_interned','interned','prospective-fol-20261018-002'))
once_keys={'schema','invocation_id','mode','search_ordering','inventory_certification_mode','model_storage','result_reader','receiver_id','actual_directory','runner','observer','python','cold','worker_plan','integration_declaration','runtime_closure','authorization','limits','environment'}
worker_keys={'schema','invocation_id','mode','actual_directory','cold','python','project_sources','components','native_inputs','policy','declaration','runtime_closure','z3','receiver_id','result_reader','integration_declaration','model_storage','search_ordering','inventory_certification_mode'}
auth_keys={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'}
check('worker exact19 fields and original schema',set(worker)==worker_keys and len(worker)==19 and worker['schema']=='ROOT-adaptive-group-worker-plan-v1')
check('once exact19 fields and original schema',set(once)==once_keys and len(once)==19 and once['schema']=='ROOT-adaptive-group-once-plan-v1')
check('auth exact7 fields false max0 empty roles',set(auth)==auth_keys and auth['schema']=='ROOT-adaptive-group-once-authorization-v1' and auth['author_identity']=='/root' and auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review_roles']=={})
subject={k:v for k,v in once.items() if k!='authorization'}
subject_sha=hashlib.sha256(canonical(subject)).hexdigest()
check('subject excludes only authorization18 full fields',len(subject)==18 and subject_sha==auth['subject_sha256']==row['subject_sha256']=='4c4ee9f38b8a86ef2ff5edfe7e925a86649590ee8fb99cc0bdc6c2fb52b7f657')
check('once current exact worker/auth/integration joins',once['worker_plan']==row['worker_plan'] and once['authorization']==row['authorization_draft'] and once['integration_declaration']==worker['integration_declaration']==index['case_declaration'])
for role in ('cold','runner','observer'):
    load(index[role],'current '+role+' Source')
    check(role+' exact Source index/contract/once joins',index[role]==contract[role]==once[role])
check('worker new cold descriptor same',worker['cold']==once['cold'])

oldworker=json.loads((OLD/'worker-plans/adaptive-group-002-fixed-ROOT-20261019-v1.json').read_bytes())
oldonce=json.loads((OLD/'runner-plan-drafts/adaptive-group-002-fixed-ROOT-20261019-v1.json').read_bytes())
oldclosure=json.loads((EVIDENCE/'runtime-closure-v1.json').read_bytes())
olddecl=json.loads((EVIDENCE/'case-declaration-v1.json').read_bytes())
olddesign=json.loads((EVIDENCE/'prospective-design-v1.json').read_bytes())
check('old frozen worker full bytes identity',pin(OLD/'worker-plans/adaptive-group-002-fixed-ROOT-20261019-v1.json')['sha256']=='52f62c0207679783a7268ed595c7a28e9c19bc197c7b297ef2149191a04c56c3')
check('old frozen false once bytes identity',pin(OLD/'runner-plan-drafts/adaptive-group-002-fixed-ROOT-20261019-v1.json')['sha256']=='ad36bca0483e29f318ecd1c3e919c5dfe805aa604f1e2d9236f4a09ad36b8ea4')
check('old runtime closure local evidence whole bytes identity',pin(EVIDENCE/'runtime-closure-v1.json')['sha256']=='3c4d2091e8fdd5c371c1eeb540e9bbc393cc515279f8134a6102f5ca3502e1b8')
check('old case declaration local evidence bytes identity',pin(EVIDENCE/'case-declaration-v1.json')['sha256']=='8f38cf43c5389499f1fd62948668befd8d38eee88aa53909359a714e5920fa90')
check('old design local evidence bytes identity',pin(EVIDENCE/'prospective-design-v1.json')['sha256']=='53b649fdf0749ef356cfabd9835c39e0feffb2157085438b92c5497645c1bb4f')
worker_changes={k for k in worker if worker[k]!=oldworker[k]}
once_changes={k for k in once if once[k]!=oldonce[k]}
closure_changes={k for k in closure if closure[k]!=oldclosure[k]}
check('worker only local operational descriptor/id changes',worker_changes=={'actual_directory','invocation_id','cold','declaration','integration_declaration','runtime_closure'},sorted(worker_changes))
check('once only local operational descriptor/id changes',once_changes=={'actual_directory','invocation_id','cold','observer','runner','worker_plan','integration_declaration','runtime_closure','authorization'},sorted(once_changes))
check('closure only parent local path/current handoff/scope description',set(closure)==set(oldclosure) and closure_changes=={'parent_closure','current_composition_handoff','bridge_scope'},sorted(closure_changes))
check('same scientific limits old and new',decl['limits']==design['limits']==olddecl['limits']==olddesign['limits'])
limits={'work_seconds':180,'overall_seconds':210,'aggregate_peak_bytes':1073741824,'stdout_bytes':4194304,'stderr_bytes':4194304,'result_bytes':134217728,'worker_receipt_bytes':4194304,'runner_plan_bytes':16777216,'failure_cleanup_seconds':5,'poll_milliseconds':20}
check('once exact full limits unchanged',once['limits']==oldonce['limits']==limits)
expected_science={'work_seconds':180,'overall_seconds':210,'conservative_worker_plus_native_peak_bytes':1073741824,'result_bytes':134217728,'search_seconds':30,'search_max_nodes':5000,'compile_queries':512,'guard_steps':1000000000,'inventory_registration_aggregate_micro_steps':5000000000,'registry_steps':5000000000,'check_steps':2048,'proposal_steps':24,'seed':64000}
check('full original scientific limit dictionary',decl['limits']==expected_science)
check('whole original same environment',once['environment']==oldonce['environment']=={'LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','TZ':'UTC'})
check('complete original input clone same raw hash and size',worker['declaration']==decl['parent_structural_declaration']==index['input_capsule']==design['original_input_capsule'] and worker['declaration']['sha256']==oldworker['declaration']['sha256']=='1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0' and worker['declaration']['bytes']==oldworker['declaration']['bytes']==22422)
check('complete original capsule10 receiver entries',len(input_data['receivers'])==10)
receivers=[v for v in input_data['receivers'] if v['id']==row['receiver_id']]
check('exact selected case002 full literal same old/new',len(receivers)==1 and receivers[0]==decl['selected_receiver']==olddecl['selected_receiver'])
check('same original12rows2catalogrounds and no supplied proof keys',receivers[0]['length']==12 and receivers[0]['instantiation_rounds']==2 and not(set(receivers[0])&{'proof','commands','route','binding','hints'}))
check('all24 original scientific aliases retained',worker['project_sources']==oldworker['project_sources']==closure['project_sources'] and worker['components']==oldworker['components']==closure['additional_nonseed_components'] and len(worker['project_sources'])==22 and set(worker['components'])=={'receiver_driver','bounded_transport'})
aliases=dict(worker['project_sources'],semantic_receiver_driver=worker['components']['receiver_driver'],bounded_request_oracle=worker['components']['bounded_transport'])
check('full alias map24 exact',len(aliases)==24 and closure['materialized_aliases']==oldclosure['materialized_aliases']==aliases)
check('no recursive proposal alias',not any('recursive' in name.lower() for name in aliases))
for name,d in aliases.items():load(d,'scientific Source raw only '+name)
check('same registry3abd driver16186 and same support modules',aliases['semantic_inventory_oracle']['sha256']=='3abdba011e81344ba8d260ee665c980eb860326e36abfd50ff35750f3a12c6ff' and aliases['semantic_receiver_driver']['sha256']=='16186e8a0c3906be90d716145cff3d52830ab0cd1f12a0fd366342abf6e55912')
for key in ('native_inputs','policy','python','z3'):
    check('worker original full '+key+' unchanged',worker[key]==oldworker[key])
load(worker['policy'],'complete unchanged policy bytes')
load(worker['python'],'whole unchanged Python bytes')
for name,d in worker['native_inputs'].items():
    if type(d)is dict and set(d)=={'path','sha256','bytes'}:load(d,'native input raw only '+name)
check('worker Python closure exact',worker['python']==once['python']==closure['runtime']['Python_executable'])
check('all41 Z3 complete file projections',len(worker['z3']['files'])==41 and worker['z3']['files']==[{k:v[k] for k in ('path','sha256','bytes')} for v in closure['Z3']['files']] and worker['z3']['root']==closure['Z3']['package_root'])
for d in worker['z3']['files']:load(d,'Z3 file raw only '+d['path'].rsplit('/',1)[-1])
check('same exact native Z3 library binding',worker['z3']['library']==oldworker['z3']['library'] and worker['z3']['library']['path']==str(Path(worker['z3']['root'])/'z3/lib/libz3.dylib'))
load(closure['native_CPP']['source'],'unchanged Native CPP raw only')
load(closure['native_CPP']['binary'],'unchanged Native binary raw only')
check('parent closure hardpin joins contract and local clone',closure['parent_closure']==contract['parent_closure'])
load(closure['parent_closure'],'local parent clone full bytes')
check('parent clone only outer descriptor path',closure['parent_closure']['sha256']==oldclosure['parent_closure']['sha256']=='214e306b85ec29ea8863c32509c47649e4984c76498752d92d2b9756fcfe5c58' and closure['parent_closure']['bytes']==oldclosure['parent_closure']['bytes']==73601)
check('current composition Source contract exact',closure['current_composition_handoff']==index['intake_Source_contract'])
operational=[index_desc,index['design'],index['case_declaration'],index['runtime_closure'],index['input_capsule'],closure['parent_closure'],row['worker_plan'],row['runner_plan_draft'],row['authorization_draft']]
for d in operational:check('live operational path local '+Path(d['path']).name,d['path'].startswith('/private/tmp/'))
actual=Path(row['actual_directory']);check('new actual local canonical absent parent exists',str(actual).startswith('/private/tmp/') and actual==actual.resolve() and not actual.exists() and actual.parent.is_dir())
fresh=[actual,actual/'CONSUMED.json',actual/'runner-receipt.json',actual/'result.json',Path(row['runner_plan_draft']['path']).parent/(row['invocation_id']+'-terminal-observation'),INDEX.parent/'runner-plans'/row['invocation_id'],INDEX.parent/'runner-plans'/(row['invocation_id']+'.json'),INDEX.parent/'runner-plans'/(row['invocation_id']+'-terminal-observation'),INDEX.parent/'authorizations'/(row['invocation_id']+'.json'),INDEX.parent/'authorized-index-v2.json',INDEX.parent/'authorized-index-v1.json']
for p in fresh:check('fresh no marker/grant/actual '+str(p),not p.exists())
check('fresh subject distinct old failed one',row['invocation_id']!=oldonce['invocation_id'] and row['actual_directory']!=oldonce['actual_directory'] and subject_sha!='9b1cfa4b5ecd435878805cdee641b33baac7f7a6bca7cb6deb5f473fe144649d')
failed=json.loads((EVIDENCE/'ROOT-failed-attempt-closure-v1.json').read_bytes())
terminal=Path('/private/tmp/gcts-adaptive-group-pilot-plans-ROOT-20261019-v1/runner-plans/adaptive-group-002-fixed-ROOT-20261019-v1-terminal-observation/terminal.json')
saved_terminal=json.loads(terminal.read_bytes())
check('old failed terminal literal preserved in Root closeout',failed['observer_terminal']==saved_terminal and failed['attempt_consumed']is True and failed['Native_queries']==0 and failed['scientific_worker_launch_observed']is False and failed['actual_directory_absent']is True and failed['runner_pid_absent']is True and failed['retry_performed']is False)
check('new continuation explicitly accounts second observer attempt',design['operational_continuation']['previous_observer_attempt']==oldonce['invocation_id'] and design['operational_continuation']['previous_attempt_retained']is True and design['operational_continuation']['new_subject_and_max_one_grant_required']is True and 'second observer launch attempt' in design['launch_and_pilot_accounting'])
reviews={
 'ordering':index['unchanged_ordering_review'],
 'registry_driver':{'path':'/private/tmp/gcts-adaptive-groups-independent-peer-20261019/typed-Source-review-v1.json','sha256':'ff2d6a15e9625f6873554d7b682abe601c3865ec4af0297c20f59e4111e9c65c','bytes':11934},
 'current_intake':{'path':'/private/tmp/gcts-adaptive-group-local-peer-20261019/typed-Source-review-v2.json','sha256':'f56bee67a3d6653091294657b1d6b9339de29307479d507372bcb9b946ed4d8e','bytes':9973}}
review_objects={k:json_load(d,k+' exact scoped Source peer') for k,d in reviews.items()}
for name,v in review_objects.items():
    check(name+' actual Source PASS/no science/no launch',v['source_review_passed']is True and v['source_only']is True and v['scientific_calls']==0 and v['scientific_acceptance']is False and v['actual_execution_authorized']is False and v['author_identity']!=v['reviewer_identity'])
check('ordering genuine distinct Receiver; registry/intake same Control disclosed',review_objects['ordering']['reviewer_identity']=='/root/receiver_driver_review' and review_objects['registry_driver']['reviewer_identity']==review_objects['current_intake']['reviewer_identity']=='/root/conventional_control_review')
check('current Source receipt exact3 subjects',review_objects['current_intake']['sources']=={'cold':index['cold'],'once_runner':index['runner'],'terminal_observer':index['observer']})
check('registry Source receipt binds BOTH current registry and driver',review_objects['registry_driver']['sources']['registry']==aliases['semantic_inventory_oracle'] and review_objects['registry_driver']['sources']['driver']==aliases['semantic_receiver_driver'])
audit=write(OUT/'prospective-audit-v2.json',dict(schema='adaptive-group-local-prospective-raw-audit-v2',source_only=True,scientific_calls=0,checks=checks,verified_raw_descriptors=list(verified.values()),subject_preimage=subject,subject_sha256=subject_sha,complete_worker=worker,complete_once=once,complete_false_authorization=auth,exact_selected_input=receivers[0],all24aliases=aliases,worker_changes=sorted(worker_changes),once_changes=sorted(once_changes),closure_changes=sorted(closure_changes),old_terminal=pin(terminal),old_failed_closeout=pin(EVIDENCE/'ROOT-failed-attempt-closure-v1.json')))
review=dict(schema='adaptive-group-prospective-plan-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',prospective_review_passed=True,source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,module_evaluations=0,project_imports=0,native_calls=0,model_calls=0,compiler_calls=0,solver_calls=0,search_calls=0,codec_calls=0,fixture_calls=0,scope='One false local operational continuation subject; full unchanged scientific maps/profile/input and prior failed observer accounting, not activation or own component Source certification',prospective_index=index_desc,design=index['design'],case_declaration=index['case_declaration'],runtime_closure=index['runtime_closure'],input_capsule=index['input_capsule'],parent_closure=closure['parent_closure'],worker_plan=row['worker_plan'],runner_plan_draft=row['runner_plan_draft'],authorization_draft=row['authorization_draft'],subject_sha256=subject_sha,subject_field_count=18,current_intake_sources={'cold':index['cold'],'once_runner':index['runner'],'terminal_observer':index['observer']},source_contract=index['intake_Source_contract'],scientific_Source_contract=index['source_contract'],all24scientific_sources=aliases,scientific_native_inputs=worker['native_inputs'],Python=worker['python'],Z3=worker['z3'],policy=worker['policy'],current_Source_reviews=reviews,complete_schedule=[schedule],check_count=len(checks),mismatch_count=0,unique_raw_pin_count=len(verified),audit=audit,review_Source=pin(Path(__file__)),findings=[dict(id='UNCHANGED_SCIENTIFIC_INPUT_AND_PROFILE',finding='Full worker scientific/native/policy/Python/Z3 and24alias maps remain literal-equal to the failed subject; full1a42 input clone and selected case002/12rows/2rounds are exact. No proof/route/binding or recursive proposer added.'),dict(id='LOCAL_OPERATIONAL_PATHS',finding='All live declaration/runtime closure/input/parent closure/plan/auth and output paths are private/tmp. Original ancestor descriptors remain unchanged historical metadata; no hydration guarantee or continuous bounded-I/O claim follows.'),dict(id='FRESH_FALSE_SUBJECT',finding='Exactly one current fixed/and_support/adaptive_groups slot, false/max0/empty review_roles. Full18field subject4c4e matches canonical preimage; old failed slot and saved terminal remain explicit. No actual/observer/final grant paths exist at this review.'),dict(id='SOURCE_ANCESTRY_AND_FUTURE_GATE',finding='Current local Source delta f56b and scientific ff2d plus genuine Receiver ordering84c4 are bound. Composition and once use the same reviewer receipt, not distinct reviews. Future true grant must add complete exact5roles, including BOTH scientific registry and driver subjects, and undergo fresh delta/scope review.')],limitations=[
 'Reviewer authored inherited outer/broker/earlier driver and current helper/symbolic control and prepared prior benchmark/diagnoses. Root authored these plans and local intake. This independently reviews Root metadata composition only, not a fresh own-code Source or scientific correctness certificate. Current scientific/import semantics rely on the exact separately scoped receipts; Source-only reviews are not runtime qualification.',
 'No target, Native, oracle, Model, compiler, solver, search, Reader, renderer, scientific fixture or program/opaque codec was imported or evaluated. Only saved ordinary JSON/Source raw hashing, literal comparisons and metadata path freshness checks. Native inputs and Z3 binary files were hashed raw only.',
 'This is explicitly the second observer launch attempt after the first225second pre-worker hydration timeout, not the first total attempt. The original observer-consumed slot and failure remain, and Root closeout reports no scientific worker/Native query. This review does not independently probe processes or make a new scientific claim about the old failure.',
 'Current authorization is false/max0 and does not permit launch. Future Root must create a separate true/max1 grant for this exact subject, bind all5expected role receipts to complete required subjects, include BOTH registry and driver for ff2d, disclose that composition/once share one intake receipt, and separately verify final freshness/author-reviewer scope. No circular self-review or launch authorization follows from this receipt.',
 'Local materialization avoids the reported dataless-document path but synchronous filesystem calls remain potentially blocking and there is no new pre-marker journal. Source-entry180/210 and225failure-only observer limits, original caps and all custody/resource assumptions remain. All costs/failed attempts must be retained; no restarted scientific run or envelope increase is approved.',
 '1GiB remains the conservative sum of separate Darwin worker and Native high-water measurements, not simultaneous live RAM or OS enforcement. Observer/interpreter prelude and outer/observer/controller RAM scopes remain separate. Final whole-Python/raw Source loop remains conditional on aggregate-profile pass, not a property of earlier failed diagnostics.',
 'Historical ancestor Root paths occur as metadata and were not recursively opened. Only exact live/intake scientific dependencies were raw authenticated. No guarantee covers arbitrary loader/OS mutation, future file residency or continuous process absence. Future runtime/admission must check exact originals+owned aliases, deadlines, child reaping, EOF/logs/group absence and full output.',
 'Any group Native UNKNOWN keeps complete all-definition authority unavailable; no partial Model/search acceptance is inferred. A successful future search still requires fresh whole final Native and full point proof gates. No fit, speed, new theorem, GCTS-specific advantage, RL, publication or goal completion claim is made.'
])
r=write(OUT/'typed-prospective-review-v2.json',review)
h=write(OUT/'prospective-handoff-v2.json',dict(schema='adaptive-group-local-prospective-peer-handoff-v2',author_identity='/root',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,review=r,audit=audit,prospective_index=index_desc,subject_sha256=subject_sha))
print(json.dumps(dict(review=r,handoff=h,audit=audit,checks=len(checks),raw_pins=len(verified)),indent=2))
