"""Raw/AST/compile-only local intake delta review; never imports targets."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import stat
import subprocess

OUT = Path('/private/tmp/gcts-adaptive-group-local-peer-20261019')
CONTRACT = Path('/private/tmp/gcts-adaptive-group-local-intake-ROOT-source-20261019/Source-contract-v2.json')
checks = []

def check(label, value, detail=None):
    checks.append(dict(check=label, passed=bool(value), detail=detail))
    if not value:
        raise AssertionError(label)

def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))

def write(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
    return pin(path)

def assignments(tree):
    return {node.targets[0].id:ast.literal_eval(node.value)
            for node in tree.body if isinstance(node,ast.Assign)
            and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)
            and isinstance(node.value,(ast.Constant,ast.Dict,ast.Tuple,ast.List,ast.Set))}

def region(raw, node):
    return b''.join(raw.splitlines(keepends=True)[node.lineno-1:node.end_lineno])

contract_raw=CONTRACT.read_bytes()
contract=json.loads(contract_raw)
check('exact reviewed contract raw pin',pin(CONTRACT)==dict(path=str(CONTRACT),sha256='3b12c05a16db6defb3dbe231b6778e9566670f864fe1418962505f69be913488',bytes=7145))
check('Root authored Source-only contract',contract['author_identity']=='/root' and contract['source_only'] is True and contract['scientific_calls']==0 and contract['actual_execution_authorized'] is False)
paths={role:Path(contract[role]['path']) for role in ('cold','runner','observer')}
parent_names={'cold':'adaptive_group_cold_v1.py','runner':'adaptive_group_once_runner_v1.py','observer':'observe_adaptive_group_runner_v1.py'}
old={role:Path(contract['parents'][parent_names[role]]['path']) for role in paths}
raws={};oldraws={};constants={};parent_constants={};deltas={};regions=[];patches=[]
expected_new={
 'cold':('2f075c6f135d96837c24d569d9436375f504938bf8ad7182daa10e3d04f72ee0',35296),
 'runner':('0ff157a8edbd8e26ebb3eec4388728e7f80dde523be57789743663e243f6c787',33684),
 'observer':('9daed7145bf5a4659efec2d3db2e522b7486bd25cd991a337377c21c58007d87',4967)}
expected_old={
 'cold':('859dc04ca73f88cde35b947138d88f907326f5a023050b40f4cf0f00a547d24e',35357),
 'runner':('082f942538276b0ffc6f25fd23399de8f64f9d6cd573cd348620d3ec6df9aeeb',33666),
 'observer':('24ec1a274339b33ad9e3fa49aac00a11729851a3d342782f744c3cdf48e33c0d',4961)}
for role in paths:
    path=paths[role];parent=old[role]
    raw=path.read_bytes();before=parent.read_bytes();raws[role]=raw;oldraws[role]=before
    check(role+' exact new raw pin',pin(path)==contract[role] and (pin(path)['sha256'],len(raw))==expected_new[role])
    check(role+' exact parent raw pin',pin(parent)==contract['parents'][parent_names[role]] and (pin(parent)['sha256'],len(before))==expected_old[role])
    tree=ast.parse(raw,filename=str(path));prior=ast.parse(before,filename=str(parent))
    constants[role]=assignments(tree);parent_constants[role]=assignments(prior)
    compile(raw,str(path),'exec',dont_inherit=True)
    check(role+' compile without evaluation',True)
    check(role+' imports raw/AST unchanged',[(ast.dump(n,include_attributes=False),region(raw,n)) for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]==[(ast.dump(n,include_attributes=False),region(before,n)) for n in prior.body if isinstance(n,(ast.Import,ast.ImportFrom))])
    newdefs={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef))}
    olddefs={n.name:n for n in prior.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef))}
    check(role+' no added or removed callable definitions',set(newdefs)==set(olddefs))
    for name in olddefs:
        if role=='observer' and name=='main':
            normalized=region(raw,newdefs[name]).replace(expected_new['runner'][0].encode(),expected_old['runner'][0].encode())
            check('observer main only runner SHA literal',normalized==region(before,olddefs[name]))
        else:
            check(role+'.'+name+' raw retained',region(raw,newdefs[name])==region(before,olddefs[name]))
            check(role+'.'+name+' AST retained',ast.dump(newdefs[name],include_attributes=False)==ast.dump(olddefs[name],include_attributes=False))
            regions.append(dict(source=role,callable=name,raw_sha256=hashlib.sha256(region(raw,newdefs[name])).hexdigest()))
    changes=[]
    if role=='cold':
        changes=[("VERSION = 'adaptive-group-intake-cold-v1'","VERSION = 'adaptive-group-local-intake-cold-v2'"),
                 (repr(parent_constants[role]['PARENT_RUNTIME_CLOSURE']),repr(constants[role]['PARENT_RUNTIME_CLOSURE']))]
    elif role=='runner':
        changes=[("VERSION = 'adaptive-group-external-once-runner-v1'","VERSION = 'adaptive-group-local-external-once-runner-v2'"),
                 (repr(parent_constants[role]['COLD_PIN']),repr(constants[role]['COLD_PIN']))]
    else:
        changes=[("VERSION = 'adaptive-group-final-terminal-observer-v1'","VERSION = 'adaptive-group-local-final-terminal-observer-v2'"),
                 (expected_old['runner'][0],expected_new['runner'][0])]
    forward=before;reverse=raw
    for a,b in changes:
        aa=a.encode();bb=b.encode()
        check(role+' old literal occurs exactly once: '+a[:45],forward.count(aa)==1)
        check(role+' new literal occurs exactly once: '+b[:45],reverse.count(bb)==1)
        forward=forward.replace(aa,bb);reverse=reverse.replace(bb,aa)
    check(role+' whole forward literal equality',forward==raw)
    check(role+' whole inverse literal equality',reverse==before)
    deltas[role]=dict(changes=[dict(before=a,after=b) for a,b in changes],whole_forward_exact=True,whole_inverse_exact=True)
    folder=OUT/('inert-'+role);folder.mkdir()
    target=folder/'subject.txt';target.write_bytes(before)
    for direction,origin,dest in [('forward',before,raw),('inverse',raw,before)]:
        patch=folder/(direction+'.patch')
        patch.write_text(''.join(difflib.unified_diff(origin.decode().splitlines(True),dest.decode().splitlines(True),fromfile='subject.txt',tofile='subject.txt')))
        proc=subprocess.run(['/usr/bin/patch','--batch','--fuzz=0','subject.txt','-i',str(patch)],cwd=str(folder),capture_output=True,text=True,timeout=10)
        check(role+' '+direction+' actual zero-fuzz inert patch',proc.returncode==0 and target.read_bytes()==dest,proc.stdout+proc.stderr)
        patches.append(dict(source=role,direction=direction,patch=pin(patch),result_sha256=hashlib.sha256(target.read_bytes()).hexdigest()))

check('31 retained callable raw/AST regions',len(regions)==31)
check('author retained callable inventory exact',sorted((x['source'],x['callable']) for x in contract['unchanged_callable_checks'])==sorted((paths[x['source']].name,x['callable']) for x in regions))
check('cold parent clone descriptor exact',constants['cold']['PARENT_RUNTIME_CLOSURE']==contract['parent_closure'])
check('clone changes path only',set(constants['cold']['PARENT_RUNTIME_CLOSURE'])=={'path','sha256','bytes'} and all(constants['cold']['PARENT_RUNTIME_CLOSURE'][k]==parent_constants['cold']['PARENT_RUNTIME_CLOSURE'][k] for k in ('sha256','bytes')))
clone=Path(contract['parent_closure']['path'])
check('clone is regular nonsymlink local tmp file',stat.S_ISREG(clone.lstat().st_mode) and not clone.is_symlink() and str(clone).startswith('/private/tmp/'))
check('local clone full raw matches original frozen214e bytes',pin(clone)==contract['parent_closure'])
check('runner hard cold pin matches new complete cold descriptor',constants['runner']['COLD_PIN']==contract['cold'])
check('five review roles and their exact schemas unchanged',constants['runner']['REVIEW_ROLES']==parent_constants['runner']['REVIEW_ROLES'] and len(constants['runner']['REVIEW_ROLES'])==5)
for role in ('cold','runner'):
    for name,value in parent_constants[role].items():
        if name not in {'VERSION','PARENT_RUNTIME_CLOSURE','COLD_PIN'}:
            check(role+' constant retained '+name,constants[role].get(name)==value)
check('driver16186 and registry3abd same literal Sources',constants['cold']['RECEIVER_DRIVER_SOURCE']['sha256']=='16186e8a0c3906be90d716145cff3d52830ab0cd1f12a0fd366342abf6e55912' and constants['cold']['REGISTRY_SOURCE']['sha256']=='3abdba011e81344ba8d260ee665c980eb860326e36abfd50ff35750f3a12c6ff')
prior_peer=Path('/private/tmp/gcts-adaptive-group-intake-peer-20261019/typed-Source-review-v1.json')
check('exact prior intake Source receipt pin',pin(prior_peer)['sha256']=='3500e7c81bd3419fb91d71e75c5e235f327f4878930431ada1c54244cf58d079' and pin(prior_peer)['bytes']==10939)
prior_review=json.loads(prior_peer.read_bytes())
check('prior Root Source delta PASS properly scoped',prior_review['source_review_passed'] is True and prior_review['scientific_acceptance'] is False and prior_review['actual_execution_authorized'] is False)
audit=write(OUT/'raw-Source-audit-v2.json',dict(schema='adaptive-group-local-intake-raw-Source-audit-v2',source_only=True,scientific_calls=0,checks=checks,retained_regions=regions,deltas=deltas,inert_patches=patches))
limitations=[
 'Reviewer authored the inherited original outer/broker and earlier receiver driver, and current support helper/symbolic control. Root authored this relocation delta. The31 retained callable bodies rely on the prior scoped intake review3500e and genuine inherited Receiver d1fed peer; this receipt is not a new independent self-certificate of inherited own Source or the scientific registry/driver.',
 'Only the hardcoded parent-closure read is redirected by this Source delta. Other operational metadata, current declaration/runtime closure/authorization/receipt paths and actual output location remain exact plan-bound inputs. Future Root prospective/final-grant review must establish that all desired operational files and the new actual directory are materialized local files, fresh max-one subjects and distinct from the failed observer slot. This Source does not enforce a private/tmp prefix.',
 'The214e parent closure clone is authenticated by full raw SHA/size. It retains historical original path strings as metadata; changing its outer descriptor path does not remap scientific originals or23/24 module aliases. Current full24 map and current driver16186/registry3abd remain literal, unchanged authority. This review neither imports modules nor qualifies their execution.',
 'The failed original observer attempt is preserved. Root reports its delayed read-only declaration probe ultimately returned and all raw/role/resolve checks passed after hydration. That report is context only, not a scientific result or an independently reproduced timing observation here. No new launch, grant, retry or actual is authorized.',
 'Synchronous Path.resolve/open/stat/read can still block beyond a before-read clock check. Local materialization avoids the reported dataless-document intake path but gives no formal bounded I/O guarantee. No pre-marker stage journal or receipt was added; observer failure fallback and Root residual ownership inspection remain necessary.',
 'Original180second positive work/output/known-worker-exit and210second terminal admission limits,225second failure-only observer timeout,1GiB conservative sum of separate Darwin worker+Native highwaters,128MiB raw result and4MiB each log remain unchanged. The sum is not simultaneous live memory or an OS-enforced limit; observer/interpreter prelude and outer/controller/observer memory exclusions remain.',
 'Pinned runtime, OS metadata/captured callable and loader trust limits remain. Final outer whole-Python/Source raw checks are conditional on aggregate profile pass and cannot be claimed for earlier or memory-failed diagnostics. Exact grant role descriptor containment is custody, not independent scope semantics. Composition and once may use this one receipt and must not be counted as two reviewers; registry role must still include BOTH registry and driver as externally required.',
 'Raw/AST/compile-without-evaluation and inert text patch operations only. No scientific Native/oracle/Model/compiler/solver/search/Reader/renderer/codec/fixture imports or evaluation, opaque program decoding, plan activation, result decoding or actuals. Source PASS is not capacity, runtime, proof, benchmark fairness, publication or goal completion acceptance.'
]
review=dict(schema='adaptive-group-intake-typed-Source-review-v1',author_identity='/root',reviewer_identity='/root/conventional_control_review',scope='Independent Root-authored local relocation Source delta only; inherited bodies and future local plan binding explicitly conditional',source_only=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,resource_acceptance=False,project_imports=0,module_evaluations=0,native_calls=0,model_calls=0,compiler_calls=0,solver_calls=0,search_calls=0,codec_calls=0,renderer_calls=0,fixture_calls=0,check_count=len(checks),mismatch_count=0,compile_without_evaluation_count=3,actual_F0_patch_directions=6,retained_raw_AST_callable_count=len(regions),source=contract['cold'],sources={'cold':contract['cold'],'once_runner':contract['runner'],'terminal_observer':contract['observer']},source_contract=pin(CONTRACT),parent_closure=contract['parent_closure'],parents={role:contract['parents'][parent_names[role]] for role in paths},driver=constants['cold']['RECEIVER_DRIVER_SOURCE'],registry=constants['cold']['REGISTRY_SOURCE'],inherited_reviews={'immediate_intake':pin(prior_peer),'genuine_old_outer_Receiver':prior_review['inherited_reviews']['genuine_old_outer_Receiver'],'current_registry_driver':prior_review['current_scientific_Source_review']},prior_preconsumption_diagnosis={'path':'/private/tmp/gcts-adaptive-group-preconsumption-diagnosis-20261019/preconsumption-Source-diagnosis-v1.json','sha256':'9eec301eb7b16ea59a78e6988d6a1fdcdff5ad09042327de7931c781037bd60d','bytes':6790},findings=[dict(id='EXACT_RELOCATION_ONLY',severity='evidence',finding='All3 Sources whole forward and inverse exact under6 enumerated literal substitutions:3VERSIONs, parent-closure descriptor path, cold descriptor and observer runner SHA. All31 unchanged callables are raw/AST exact; observer main reverses exactly after runner-SHA substitution.'),dict(id='LOCAL_PARENT_SAME_AUTHORITY',severity='evidence',finding='New local regular nonsymlink parent-runtime-closure file matches the original214e full SHA/73601bytes; only its enclosing descriptor path changes. Same scientific driver/registry,24aliases, input capsule, schemas, single fixed/and_support/adaptive_groups mode, limits and review roles remain.'),dict(id='FUTURE_PLAN_LOCALITY',severity='scope',finding='Future current plans must bind materialized local operational descriptors/new directory and preserve failed observer evidence; Source alone does not enforce private/tmp locality or authorize activation.'),dict(id='BLOCKING_IO_LIMIT_RETAINED',severity='scope',finding='Blocking syscall/pre-marker journal limitations remain explicitly disclosed. Local relocation does not change deadlines or promise I/O latency.')],limitations=limitations,audit=audit,review_Source=pin(Path(__file__)),ancestry=dict(current_delta_author='/root',reviewer_distinct_from_current_author=True,reviewer_authored_inherited_outer_and_earlier_driver=True,reviewer_authored_current_helper_symbolic=True,inherited_body_not_new_independent_self_certificate=True,composition_and_once_same_receipt_not_distinct_reviewers=True))
r=write(OUT/'typed-Source-review-v2.json',review)
h=write(OUT/'handoff-v2.json',dict(schema='adaptive-group-local-intake-peer-handoff-v2',reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,source_review=r,audit=audit,current_sources=review['sources'],source_contract=pin(CONTRACT)))
print(json.dumps(dict(review=r,handoff=h,audit=audit,checks=len(checks)),indent=2))
