"""Distinct raw/AST Source review. No reviewed callable is imported or executed."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import subprocess

D=Path('/private/tmp/gcts-adaptive-groups-independent-peer-20261019');D.mkdir(exist_ok=True)
N=Path('/private/tmp/gcts-adaptive-groups-ROOT-source-20261019')
checks=[]
def ck(name,condition,evidence=None):checks.append(dict(check=name,passed=bool(condition),evidence=evidence))
def pin(path):
 p=Path(path).resolve();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def load(p):return json.loads(Path(p).read_bytes())
def raw(text,n):return ''.join(text.splitlines(True)[n.lineno-1:n.end_lineno])
def dump(n):return ast.dump(n,include_attributes=False)
def fns(t):return {n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def const(t):
 out={}
 for n in t.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:out[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
 return out
def normalized_name(n,name):
 n=copy.deepcopy(n);n.name=name;return n
def save(name,v):
 p=D/name;p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)

contract_path=N/'Source-contract-v1.json';c=load(contract_path)
ck('exact-contract',pin(contract_path)==dict(path=str(contract_path),sha256='fa36563c7a3c5f283c473521ac5ba6a154d3fe0309d358b8f9160845b97bfb99',bytes=6521))
current={k:dict(path=str(N/name),sha256=sha,bytes=size) for k,name,sha,size in [
 ('registry','semantic_inventory_oracle_v3.py','3abdba011e81344ba8d260ee665c980eb860326e36abfd50ff35750f3a12c6ff',19364),
 ('driver','inventory_certification_receiver_driver_v3.py','16186e8a0c3906be90d716145cff3d52830ab0cd1f12a0fd366342abf6e55912',70193)]}
parents={k:c['parent_'+k]for k in current}
texts={};trees={};oldtexts={};oldtrees={}
for k in current:
 ck(k+'-exact-current-pin',pin(current[k]['path'])==current[k]);ck(k+'-parent-whole-pin',pin(parents[k]['path'])==parents[k])
 ck(k+'-contract-current-descriptor',current[k] in c['sources'])
 texts[k]=Path(current[k]['path']).read_text();oldtexts[k]=Path(parents[k]['path']).read_text()
 trees[k]=ast.parse(texts[k],filename=current[k]['path']);oldtrees[k]=ast.parse(oldtexts[k])
 compile(trees[k],current[k]['path'],'exec');ck(k+'-compile-without-evaluation',True)
 oldimports=[dump(n)for n in oldtrees[k].body if isinstance(n,(ast.Import,ast.ImportFrom))]
 newimports=[dump(n)for n in trees[k].body if isinstance(n,(ast.Import,ast.ImportFrom))]
 ck(k+'-all-import-AST-unchanged',oldimports==newimports)

retained=[]
for k in current:
 a=fns(oldtrees[k]);b=fns(trees[k])
 for name,node in a.items():
  target={'check_inventory':'_check_inventory_modes_v2_parent','_inventory_record_join':'_inventory_record_join_v2_parent'}.get(name,name)
  if k=='driver' and name=='run_receiver':continue
  current_node=b[target]
  ast_same=dump(node)==dump(normalized_name(current_node,name))
  source_old=raw(oldtexts[k],node);source_new=raw(texts[k],current_node)
  if target!=name:source_new=source_new.replace('def '+target+'(','def '+name+'(',1)
  ck(k+'-retained-raw-and-name-normalized-AST:'+name,ast_same and source_old==source_new)
  retained.append(dict(component=k,parent_callable=name,current_callable=target,raw_body_exact=True,AST_exact_after_only_name_normalization=True))

reg=texts['registry'];drv=texts['driver'];rf=fns(trees['registry']);df=fns(trees['driver'])
rc=const(trees['registry']);pc=const(oldtrees['registry']);dc=const(trees['driver']);pd=const(oldtrees['driver'])
ck('registry-whole-parent-prefix-inverse-exact',reg[:reg.index('\n\nGROUP_CERTIFICATION_VERSION')].replace('def _check_inventory_modes_v2_parent(','def check_inventory(',1)==oldtexts['registry'])
ck('new-registry-constants-only-additive',all(rc[k]==v for k,v in pc.items()) and rc['GROUP_CERTIFICATION_VERSION']=='native-inventory-adaptive-groups-v1' and rc['GROUP_CERTIFICATION_SCHEMA']=='native-inventory-adaptive-group-certification-v1')
ck('max-registration-cap-unchanged-expression',dump(next(n for n in trees['registry'].body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='MAX_REGISTRATION_MICRO_STEPS'for x in n.targets)))==dump(next(n for n in oldtrees['registry'].body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='MAX_REGISTRATION_MICRO_STEPS'for x in n.targets))))

# Exact inverse of the reviewed driver delta, not execution of its join.
new_join=raw(drv,df['_inventory_record_join'])
inv=drv.replace(new_join+'\n\n','',1)
inv=inv.replace('def _inventory_record_join_v2_parent(','def _inventory_record_join(',1)
inv=inv.replace("VERSION = 'semantic-family-inventory-certification-driver-v3'","VERSION = 'semantic-family-inventory-certification-driver-v2'",1)
inv=inv.replace("SOURCE_EPOCH_SCHEMA = 'semantic-family-receiver-source-epoch-v5-adaptive-inventory-groups'","SOURCE_EPOCH_SCHEMA = 'semantic-family-receiver-source-epoch-v4-inventory-certification'",1)
inv=inv.replace("('3abdba011e81344ba8d260ee665c980eb860326e36abfd50ff35750f3a12c6ff', 19364)","('2010ca7cb6f3da0734efe03e5be0f7e166b7e4d5939078dea0451361cf5890f3', 12626)",1)
inv=inv.replace("inventory_certification_mode not in ('bulk','dependency_closures','adaptive_groups')","inventory_certification_mode not in ('bulk','dependency_closures')",1)
ck('whole-driver-inverse-raw-AST-exact',inv==oldtexts['driver'] and dump(ast.parse(inv))==dump(oldtrees['driver']))
ck('only-registry-dependency-pin-changed',set(dc['DEPENDENCY_PINS'])==set(pd['DEPENDENCY_PINS']) and [k for k in dc['DEPENDENCY_PINS']if dc['DEPENDENCY_PINS'][k]!=pd['DEPENDENCY_PINS'][k]]==['family_registry'] and dc['DEPENDENCY_PINS']['family_registry']==(current['registry']['sha256'],current['registry']['bytes']))
ck('all-other-driver-literal-constants-exact',all(dc[k]==v for k,v in pd.items()if k not in ('VERSION','SOURCE_EPOCH_SCHEMA','DEPENDENCY_PINS')))
ck('required-v5-epoch',dc['SOURCE_EPOCH_SCHEMA']==c['epoch']=='semantic-family-receiver-source-epoch-v5-adaptive-inventory-groups')

newreg=raw(reg,rf['_check_inventory_adaptive_groups']);closure=raw(reg,rf['_group_closure_names']);dispatch=raw(reg,rf['check_inventory']);join=new_join
requirements={
 'whole-full-inventory-snapshot':'original_bytes = _strict_bytes(inventory)',
 'complete-snapshot-owned':'snapshot = copy.deepcopy(inventory)',
 'strict-prior-global-validation':'names, dependencies = _ordered_inventory(snapshot)',
 'full-initial-root-set':'pending = [dict(path=[], target_names=list(names))]',
 'unchanged-full-theory-snapshot':"original_theory = _strict_bytes(spec['theory'])",
 'positive-strict-original-cap':'type(limit) is not int or not 0 < limit <= MAX_REGISTRATION_MICRO_STEPS',
 'zero-remaining-explicit-UNKNOWN':"stop_reason = 'aggregate_registration_micro_step_budget'",
 'current-residual-limit':'remaining = limit - used',
 'exact-residual-delegation':'q = oracle.request(request, remaining, purpose)',
 'complete-closure-request':'request = _closure_request(spec, [blocks[name] for name in closure])',
 'current-whole-request-copy':'expected = copy.deepcopy(request)',
 'native-record-sequence-and-counter-gate':'index, status, consumed = _checked_native_record(',
 'split-only-space-nonsingleton':"elif status == 'unknown_space_budget' and len(targets) > 1:",
 'all-other-nonaccept-stops':"action = 'stop_inventory'",
 'failed-parent-charged':'used += consumed',
 'stable-midpoint':'midpoint = len(targets) // 2',
 'left-before-right':"pending[:1] = [dict(path=path+[0], target_names=targets[:midpoint]),\n                           dict(path=path+[1], target_names=targets[midpoint:])]",
 'accepted-full-closure':'accepted.update(closure)',
 'remove-only-accepted-target-group':'pending.pop(0)',
 'coverage-and-empty-pending':'complete = not pending and accepted == set(names)',
 'strict-all-or-none':"if (disposition == 'native_accepted') is not complete:",
 'pending-groups-preserved':'pending_groups=copy.deepcopy(pending)',
 'all-original-interface-order-preserved':"all_original_interfaces=list(snapshot['interfaces'])",
 'all-returned-complete-original-snapshot':'return dict(snapshot, status=disposition, query=None,',
 'returned-all-serial-queryids':"queries=[receipt['query'] for receipt in receipts]",
}
for name,s in requirements.items():ck('registry:'+name,s in newreg,s)
ck('registry-charging-before-any-queue-action',newreg.index('used += consumed')<newreg.index("if action == 'accept_group':"))
ck('registry-pre-post-whole-input-and-snapshot-guards',newreg.count("_strict_bytes(inventory) != original_bytes or _strict_bytes(snapshot) != original_bytes")==2 and newreg.count("_strict_bytes(spec['theory']) != original_theory")==2)
ck('new-functions-no-exception-swallow',not any(isinstance(n,(ast.Try,getattr(ast,'TryStar',ast.Try)))for name in ('_group_closure_names','_check_inventory_adaptive_groups','check_inventory')for n in ast.walk(rf[name])))
ck('new-group-closure-complete-in-original-order',all(s in closure for s in ['pending = list(target_names)','wanted.add(name)','pending.extend(dependencies[name])','return [name for name in names if name in wanted]']))
ck('public-default-and-exact-parent-delegation',"mode='bulk'" in dispatch and "if mode == 'adaptive_groups':" in dispatch and 'return _check_inventory_modes_v2_parent(spec, inventory, oracle, limit, mode=mode)' in dispatch)
ck('new-registry-loop-finiteness-source-invariant',len([n for n in ast.walk(rf['_check_inventory_adaptive_groups'])if isinstance(n,ast.While)])==1 and 'while pending:' in newreg and 'midpoint = len(targets) // 2' in newreg)

driver_requirements={
 'old-modes-delegate-first':"if certification_mode != 'adaptive_groups':\n        return _inventory_record_join_v2_parent(inventory, records, spec, boundary, certification_mode)",
 'whole-original-fingerprint':"cert.get('inventory_sha256') != _sha(original)",
 'whole-theory-fingerprint':"cert.get('theory_sha256') != _sha(spec['theory'])",
 'original-cap-exact':"cert['aggregate_micro_step_limit'] != 5*10**9",
 'ordered-native-blocks-exact':"blocks != [d['definition'] for d in definitions]",
 'global-identity-and-name-uniqueness':"type(name) is not str or not name or name in seen",
 'strict-prior-all-body-calls':"if line['rule'] == 'block' and line['name'] not in seen:",
 'every-original-interface-joined':"cert.get('all_original_interfaces') != inventory['interfaces']",
 'full-root-queue-rebuilt':"queue = [dict(path=[], target_names=list(names))]",
 'nonempty-even-empty-inventory-transcript':"if type(receipts) is not list or not receipts:",
 'fresh-consecutive-record-suffix':"ids != list(range(len(records)-len(ids),len(records)))",
 'no-extra-after-stop-coverage-budget':"if terminal is not None or not queue or used >= 5*10**9:",
 'direct-body-dependencies-independent':"todo.extend(line['name'] for line in by_name[n]['proof'] if line['rule']=='block')",
 'original-order-closure-rebuilt':'closure = [n for n in names if n in needed]',
 'literal-path-targets-closure':"receipt['path'] != group['path']",
 'literal-targets':"receipt.get('target_names') != group['target_names']",
 'literal-closure':"receipt.get('closure_names') != closure",
 'exact-assigned-residual':"receipt['assigned_micro_step_limit'] != remaining",
 'whole-full-theory-request':"request = dict(protocol='gcts-fol-1', theory=spec['theory'],",
 'unchanged-native-root':"proof=[dict(rule='tautology',formula=taut)], target=taut)",
 'fresh-native-purpose':"q['purpose'] != 'check_generated_lemma_definition_group'",
 'whole-request-checked-by-parent':"current = _record_join(records,receipt['query'],request,boundary)",
 'counter-within-actual-remaining':'type(steps) is not int or not 0<=steps<=remaining',
 'charged-counters-receipt-check':"receipt['aggregate_consumed_after'] != used+steps",
 'status-literal-join':"receipt.get('result_status') != status",
 'space-only-group-split':"elif status == 'unknown_space_budget' and len(targets)>1:",
 'left-before-right':"queue[:1] = [dict(path=group['path']+[0],target_names=targets[:midpoint]),\n                         dict(path=group['path']+[1],target_names=targets[midpoint:])]",
 'every-action-joined':"receipt.get('action') != action",
 'complete-no-terminal':"complete = not queue and accepted==set(names) and terminal is None",
 'aggregate-end-UNKNOWN':"elif used == 5*10**9:",
 'reject-premature-prefix':"raise DriverDataError('no premature accepted prefix authority')",
 'full-status-queue-step-coverage-joined':"cert.get('pending_groups') != queue",
 'full-accepted-ordered-names':"cert.get('accepted_definition_names') != [n for n in names if n in accepted]",
}
for name,s in driver_requirements.items():ck('driver:'+name,s in join,s)
ck('driver-no-delegation-to-registry-planner',not any(isinstance(n,ast.Name) and n.id in ('_group_closure_names','plan_dependency_closures','_ordered_inventory','_check_inventory_adaptive_groups')for n in ast.walk(df['_inventory_record_join'])))
ck('driver-new-join-no-broad-catch',not any(isinstance(n,(ast.Try,getattr(ast,'TryStar',ast.Try)))for n in ast.walk(df['_inventory_record_join'])))
ck('driver-direct-traversal-cooperative-boundaries',join.count('boundary.check(')>=4)
run=raw(drv,df['run_receiver']);old_run=raw(oldtexts['driver'],fns(oldtrees['driver'])['run_receiver'])
ck('whole-run-body-exact-after-only-mode-tuple-repair',run.replace("('bulk','dependency_closures','adaptive_groups')","('bulk','dependency_closures')",1)==old_run)
ck('all-or-none-barrier-precedes-model-search',run.index("if inventory['status'] != 'native_accepted':")<run.index("model = modules['family_model'].Model(") and "stage('inventory_record_join', lambda: _inventory_record_join(" in run)
ck('fresh-final-used-recursive-closure-unchanged',"blocks=modules['family_miner'].used_definitions(inventory, proof)" in run and "oracle.request(request, 5*10**9, 'fresh_quantified_receiver_final')" in run)

parents_peers={
 'registry':dict(path='/private/tmp/gcts-inventory-batching-ROOT-peer-20261018/typed-registry-Source-review-v1.json',sha256='7888512ae4a4d34f23c8b824605746f994ece08025136a44b4c27ffbc605cd39',bytes=13073),
 'driver_cold':dict(path='/private/tmp/gcts-inventory-batching-ROOT-peer-20261018/typed-driver-cold-Source-review-v1.json',sha256='f9e30b79bf10bf098822d7b2177649862f72aee99ec653327ca6124c404eb20d',bytes=11740)}
for role,p in parents_peers.items():
 r=load(p['path']);ck('parent-genuine-Source-peer:'+role,pin(p['path'])==p and r['source_review_passed'] is True and r['reviewer_identity']=='/root/conventional_library' and r['scientific_calls']==0)

patches=[]
for k in current:
 folder=D/(k+'-inert-F0');folder.mkdir(exist_ok=True)
 old=oldtexts[k];new=texts[k]
 for direction,a,b in [('forward',old,new),('inverse',new,old)]:
  p=folder/(direction+'.patch');p.write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='payload.txt',tofile='payload.txt')))
  (folder/'payload.txt').write_text(a)
  r=subprocess.run(['patch','--batch','--fuzz=0','-p0','-i',str(p)],cwd=folder,capture_output=True,text=True)
  ck('inert-F0:'+k+':'+direction,r.returncode==0 and (folder/'payload.txt').read_text()==b,dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
  patches.append(dict(component=k,direction=direction,patch=pin(p)))

audit=dict(schema='adaptive-group-registry-driver-raw-Source-audit-v1',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,reviewer_identity='/root/conventional_control_review',author_identity='/root',sources=current,parents=parents,contract=pin(contract_path),checks=checks,check_count=len(checks),mismatch_count=sum(not x['passed']for x in checks),retained_callable_evidence=retained,parent_reviews=parents_peers,inert_F0_patch_directions=patches,compile_without_evaluation_count=2,review_Source=pin(Path(__file__)))
ap=save('raw-Source-audit-v1.json',audit)
print(json.dumps(dict(check_count=len(checks),mismatches=[x for x in checks if not x['passed']],audit=ap),indent=2))
