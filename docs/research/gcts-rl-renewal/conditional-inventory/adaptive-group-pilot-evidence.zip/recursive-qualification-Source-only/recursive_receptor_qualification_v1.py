"""Prospective finite qualification, not a prover or performance benchmark.

No scientific module imports. Root must inject a freshly admitted full context,
current Source guards and unchanged complete Graph. This module is unexecuted.
Synthetic logical packets exercise plumbing and have no Native authority.
"""
import json

VERSION='recursive-receptor-qualification-v1'
RESULT_SCHEMA='recursive-receptor-qualification-result-v1'
PLANNER_VERSION='recursive-receptor-DAG-planner-v1'
MAX_SCHEDULER_PREFIX=4
MAX_METADATA_BYTES=128*1024*1024


class QualificationError(ValueError):
    pass


def _literal(value,check):
    check()
    if type(value) is dict:
        if any(type(k) is not str for k in value):
            raise QualificationError('literal string-key metadata')
        return {k:_literal(v,check) for k,v in value.items()}
    if type(value) in (list,tuple):
        return [_literal(v,check) for v in value]
    if value is None or type(value) in (str,int,bool):
        return value
    raise QualificationError('finite integer/literal qualification metadata')


def _encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def _snapshot(state,graph,check):
    def assignments(mapping):
        out=[]
        for p,v in sorted(mapping.items()):
            check();out.append([list(p),v])
        return out
    domains=[];edges=[]
    for p,keys in sorted(graph.domains.items()):
        check();domains.append([list(p),[list(k) for k in sorted(keys)]])
    for k,points in sorted(graph.edges.items()):
        check();edges.append([list(k),[list(p) for p in sorted(points)]])
    return dict(totals=assignments(state.totals),marks=assignments(state.marks),
        generations=assignments(state.generations),roots=assignments(state.roots),
        selected=[list(k) for k in sorted(state.selected)],order=[list(k) for k in state.order],
        tile_generations=list(state.tile_generations),
        allowed_points=None if state.allowed_points is None else [list(p) for p in sorted(state.allowed_points)],
        domains=domains,edges=edges)


def _logical_cases(planner,check):
    """Small arbitrary port graph, never a command/route for a receiver target."""
    forms=[['pred','fixture_'+str(i),[]] for i in range(4)]
    def packet(row,formula,requirements):
        return dict(row=row,formula=formula,requirements=requirements,
                    members=[[row,0,row,0],[row,1,row,0]])
    known=packet(0,forms[0],[])
    one=packet(1,forms[1],[[0,forms[0]]])
    two=packet(2,forms[2],[[1,forms[1]]])
    root=packet(3,forms[3],[[1,forms[1]],[1,forms[1]],[2,forms[2]]])
    table={1:one,2:two}
    def available(row,formula):
        check()
        if row in table and table[row]['formula']==formula:
            yield table[row]
    def invoke(root_packet,available_producers=available,limits=None,callback=check):
        return planner.propose_logical_dags(demand_snapshot=dict(roots=[root_packet],selected_keys=known['members']),
            available_producers=available_producers,current_justified_rows=[known],
            signature_context=dict(kind='SYNTHETIC_UNTRUSTED_PORT_FIXTURE_NO_NATIVE_AUTHORITY'),
            source_epoch=dict(kind='FIXTURE_ONLY_NOT_CURRENT_MODEL'),check=callback,limits=limits)
    receipts=[]
    shared=invoke(root)
    if not shared['proposals']:
        raise QualificationError('shared logical proposal missing')
    p=shared['proposals'][0]
    if ([n['row'] for n in p['nodes']]!=[1,2,3] or len(p['members'])!=6 or
            [e['source_row'] for e in p['ports'] if e['consumer_row']==3]!=[1,1,2]):
        raise QualificationError('shared producer/ordered repeated ports changed')
    receipts.append(dict(case='shared_producer_and_ordered_repeated_ports',result=shared))
    conflict=packet(3,forms[3],[[1,forms[1]],[1,forms[2]]])
    r=invoke(conflict)
    if r['proposals']:
        raise QualificationError('one row cannot supply conflicting literal formulas')
    receipts.append(dict(case='conflicting_shared_source_abstention',result=r))
    r=invoke(root,available_producers=lambda row,formula:iter(()))
    if r['proposals']:
        raise QualificationError('open port acquired authority')
    receipts.append(dict(case='open_receptors_are_diagnostic_only',result=r))
    r=invoke(root,limits=dict(per_call_work=1))
    if r['status']!='ABSTAIN_BOUNDED_PREFIX' or r['proposals']:
        raise QualificationError('private quota did not abstain')
    receipts.append(dict(case='private_work_quota_abstention',result=r))
    exact=ValueError('delegated qualification tick sentinel')
    def fail():
        raise exact
    caught=None
    try:
        invoke(root,callback=fail)
    except BaseException as error:
        caught=error
    if caught is not exact:
        if caught is not None:
            raise caught
        raise QualificationError('delegated ValueError origin was lost')
    receipts.append(dict(case='delegated_callback_exact_origin',exact_object_propagated=True))
    return receipts


def run_cases(*,planner_module,fresh_context,source_epoch,source_guard,check):
    """One controlled qualification; full search remains a separate future arm.

    fresh_context(check=...,source_guard=...) returns model, Graph, aggregate,
    row_requirements, model_guard and custody. It performs all ordinary fresh
    compiler/inventory Native admission and retains the COMPLETE model/records;
    model_guard independently enforces that caller custody. No cached Native
    acceptance is conferred by this harness or by a boolean custody receipt.
    Root owns transport close/reap and the whole measured/serialization gate.
    """
    if planner_module.VERSION!=PLANNER_VERSION or type(source_epoch) is not dict:
        raise QualificationError('exact frozen planner/current Source epoch')
    for f in (fresh_context,source_guard,check):
        if not callable(f):
            raise QualificationError('required charged/context authority')
    check();source_guard()
    cases=_logical_cases(planner_module,check)
    ctx=fresh_context(check=check,source_guard=source_guard)
    model=ctx['model'];Graph=ctx['Graph'];model_guard=ctx['model_guard']
    if not callable(model_guard):
        raise QualificationError('whole caller Model custody guard required')
    if model.compiled['status']!='complete' or model.inventory['status']!='native_accepted':
        raise QualificationError('partial inventory cannot supply qualification context')
    check();model_guard();source_guard()
    planner=planner_module.ReceptorClosurePlanner(model,source_epoch=source_epoch,
        source_guard=source_guard,check=check,aggregate=ctx['aggregate'],
        row_requirements=ctx['row_requirements'])
    identity=planner.identity_record()
    root=model.initial();rg=Graph(model,root)
    before=_snapshot(root,rg,check)
    state=root.copy();graph=rg.copy();prefix=[];branch_calls=0;validated=0
    for position in range(MAX_SCHEDULER_PREFIX):
        check();model_guard();source_guard()
        kind,point,keys=graph.decision(state)
        row=dict(position=position,kind=kind,point=None if point is None else list(point),
                 alternatives=[list(k) for k in keys],planner=None)
        if kind=='branch':
            original=_snapshot(state,graph,check)
            items,receipt=planner(state,graph,point)
            if _encoded(original)!=_encoded(_snapshot(state,graph,check)):
                raise QualificationError('planner changed current complete state/graph')
            for item in items:
                check();actual=ctx['aggregate'](model,item['members'],state)
                if actual!={k:item[k] for k in ('members','pending','aggregate_sha256','new_occupancy','new_marks')}:
                    raise QualificationError('actual current t/m union mismatch')
            branch_calls+=1;validated+=len(items)
            row['planner']=dict(items=items,receipt=receipt)
        prefix.append(row)
        if kind not in ('forced','branch'):
            break
        # Generic canonical public step; no preferred theorem/member/route.
        if not keys:
            raise QualificationError('nonterminal scheduler without original keys')
        chosen=keys[0];row['canonical_test_key']=list(chosen)
        child=state.copy();cg=graph.copy()
        cg.update(model,child,child.place(model.placement(chosen)))
        state,graph=child,cg
    if _encoded(before)!=_encoded(_snapshot(root,rg,check)):
        raise QualificationError('copy/prefix discarded state failed exact root restoration')
    # The deliberately failing Source guard must precede all model access.
    exact=ValueError('delegated qualification Source guard sentinel')
    def fail_guard():
        raise exact
    caught=None
    try:
        planner_module.ReceptorClosurePlanner(model,source_epoch=source_epoch,
            source_guard=fail_guard,check=check,aggregate=ctx['aggregate'],
            row_requirements=ctx['row_requirements'])
    except BaseException as error:
        caught=error
    if caught is not exact:
        if caught is not None:
            raise caught
        raise QualificationError('Source guard error origin was lost')
    check();model_guard();source_guard()
    result=dict(schema=RESULT_SCHEMA,version=VERSION,status='QUALIFICATION_PREFIX_RETURNED',
        logical_cases=cases,identity=identity,current_context_custody=ctx['custody'],
        complete_model_record_reference='Caller retains full outputs.model and exact Native/compiler/inventory records; no shortened digest authority.',
        initial_snapshot=before,scheduler_prefix=prefix,branch_calls=branch_calls,
        reconstructed_items=validated,root_restored_literal=True,source_guard_exact_error=True,
        coverage=dict(constructor=identity['setup']['status'],
            actual_genuine_branch='EXERCISED' if branch_calls else 'NOT_REACHED_IN_DECLARED_PREFIX',
            nonempty_actual_multirow='EXERCISED' if validated else 'NOT_OBSERVED',
            whole_search_seam='UNTESTED_SEPARATE_DISABLED_ENABLED_RUN_REQUIRED',
            Native_proof='NOT_A_PROOF_RUN',
            fallback='Logical own-quota abstention and unchanged candidate alternatives retained; whole-search fallback remains untested.'),
        scope='Finite plumbing/actual point prefix qualification only. Synthetic fixtures are not proof routes. No proof, speed, memory or learning claim.')
    check()
    raw=_encoded(result)
    check()
    if len(raw)>MAX_METADATA_BYTES:
        raise QualificationError('whole qualification output exceeds original 128MiB cap')
    return result
