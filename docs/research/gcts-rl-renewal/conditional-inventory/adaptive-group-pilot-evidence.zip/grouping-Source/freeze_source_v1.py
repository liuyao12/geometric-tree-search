import ast, hashlib, json
from pathlib import Path
D=Path(__file__).parent
P=Path('/private/tmp/gcts-inventory-batching-ROOT-source-20261018')
def pin(p):
 b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def nodes(p):
 return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
checks=[]
for name,parent,new,renames,changed in [
 ('registry','semantic_inventory_oracle_v2.py','semantic_inventory_oracle_v3.py',{'check_inventory':'_check_inventory_modes_v2_parent'},set()),
 ('driver','inventory_certification_receiver_driver_v2.py','inventory_certification_receiver_driver_v3.py',{'_inventory_record_join':'_inventory_record_join_v2_parent'},{'run_receiver'})]:
 a=nodes(P/parent);b=nodes(D/new)
 for k,v in a.items():
  target=renames.get(k,k)
  if k in changed:continue
  if target!=k:
   n=next(x for x in ast.parse((D/new).read_bytes()).body if isinstance(x,ast.FunctionDef) and x.name==target);n.name=k;bv=ast.dump(n,include_attributes=False)
  else:bv=b[target]
  checks.append(dict(component=name,callable=k,unchanged_ast=v==bv));assert v==bv,(name,k)
 code=(D/new).read_bytes();compile(code,str(D/new),'exec')
 checks.append(dict(component=name,compile_without_evaluation=True))
 # No execution/import of either scientific module occurs here.
contract=dict(schema='adaptive-group-inventory-Source-contract-v1',status='SOURCE_ONLY_UNEXECUTED',
 parent_registry=pin(P/'semantic_inventory_oracle_v2.py'),parent_driver=pin(P/'inventory_certification_receiver_driver_v2.py'),
 sources=[pin(D/'semantic_inventory_oracle_v3.py'),pin(D/'inventory_certification_receiver_driver_v3.py')],
 old_modes='bulk and dependency_closures delegate preserved v2 callable bodies; defaults remain bulk',
 new_mode='adaptive_groups',epoch='semantic-family-receiver-source-epoch-v5-adaptive-inventory-groups',
 policy=dict(initial_group='all original definition names, or empty',closure='complete transitive closure in original inventory order',
 split='only Native unknown_space_budget with >1 target; floor midpoint; left child first',
 stop='rejected, step UNKNOWN, singleton/empty space UNKNOWN, or aggregate exhaustion',
 cap=5000000000,charged='every request including failed parents; exact residual allowance',
 authority='complete original definitions/interfaces only; no partial prefix activates search; fresh full final Native gate mandatory'),
 explicit_limits=['No measured intermediate group performance','No claim that grouping fits unchanged cap','No source runtime tests yet','No new theorem, GCTS/RL advantage or plane result','Third mode not coupled to a cold launcher yet'],
 planned_pilot='At most one freshly declared complete case002 pilot before deciding whether to spend further effort on grouping. No old invocation retry; no recursive-planner factor in that pilot.',
 science_imports=0,science_evaluations=0,checks=checks)
for file,data in [('Source-contract-v1.json',contract),('author-static-audit-v1.json',dict(schema='adaptive-groups-author-static-audit-v1',findings=[],checks=checks,scientific_evaluations=0))]:
 p=D/file;assert not p.exists();p.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
print(json.dumps({'contract':pin(D/'Source-contract-v1.json'),'audit':pin(D/'author-static-audit-v1.json'),'sources':contract['sources'],'checks':len(checks)}))
