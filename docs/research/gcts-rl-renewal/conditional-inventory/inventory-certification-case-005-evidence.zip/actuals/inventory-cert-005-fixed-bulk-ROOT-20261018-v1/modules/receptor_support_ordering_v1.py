"""Pure bounded AND-support potential. This is ordering metadata, never proof.

Only the standard library is imported. The protected caller supplies completed
native-admitted inputs and valid complete-row projections. We independently
check strict-prior literal row requirements before crediting any projected
formula. No Model, graph, command evaluator, native query or solver is called.
"""
import hashlib
import json

VERSION = 'receptor-and-support-ordering-v1'
STRATEGY = 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1'
GRAPH_SCHEMA = 'receptor-and-support-graph-v1'
RANK_SCHEMA = 'receptor-and-support-ranking-v1'
DEFAULT_WORK_LIMIT = 200000


class SupportDataError(ValueError):
    pass


class _OwnStop(Exception):
    def __init__(self, owner):
        self.owner = owner
        super().__init__('support_ordering_work_budget')


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def _sha(value):
    return hashlib.sha256(_json(value)).hexdigest()


def _copy(value, check, counts):
    # Intake/receipt ownership is charged to the caller's absolute clock.
    # The private work quota below counts graph/projection/relaxation operations,
    # separately from these disclosed finite builtin-copy node visits.
    check()
    counts['copy_nodes'] += 1
    if type(value) is dict:
        if any(type(k) is not str for k in value):
            raise SupportDataError('builtin string-key dictionaries required')
        return {k: _copy(v, check, counts) for k, v in value.items()}
    if type(value) in (list, tuple):
        return [_copy(v, check, counts) for v in value]
    if value is None or type(value) in (str, int, bool, float):
        # JSON rejects nonfinite floats; no callback exception is caught here.
        _json(value)
        return value
    raise SupportDataError('strict builtin input packets required')


class _Work:
    def __init__(self, check, limit, counts):
        if not callable(check):
            raise SupportDataError('protected caller check required')
        if type(limit) is not int or not 0 <= limit <= DEFAULT_WORK_LIMIT:
            raise SupportDataError('support work limit must be in0..200000')
        self.check, self.limit, self.counts = check, limit, counts

    def step(self, kind):
        self.check()
        if self.counts['work'] >= self.limit:
            raise _OwnStop(self)
        self.counts['work'] += 1
        self.counts[kind] = self.counts.get(kind, 0) + 1


def build_support_graph(*, spec, compiled, inventory, check,
                        work_limit=DEFAULT_WORK_LIMIT):
    """Return all literal hyperedges once, or an unusable partial graph.

    The graph's formula abstraction may conflate row capacity, sharing and
    scopes; positive costs are not an admissible lower bound. Every exported
    block edge is retained. An edge outside the root formula grammar is marked
    inactive for scoring, rather than silently made a root command.
    """
    counts = {'work': 0, 'copy_nodes': 0}
    w = _Work(check, work_limit, counts)
    projection = _copy(dict(spec=spec, compiled={k: v for k, v in compiled.items()
                                              if k not in ('seconds',)},
                            inventory={k: inventory[k] for k in
                                       ('status', 'definitions', 'interfaces', 'native_blocks')}),
                       check, counts)
    s, c, inv = projection['spec'], projection['compiled'], projection['inventory']
    if c['status'] != 'complete' or inv['status'] != 'native_accepted':
        raise SupportDataError('complete compiler and full registry required')
    if s.get('assumptions') or s.get('blocks') or s['theory']['schemas']:
        raise SupportDataError('closed root without supplied assumptions/blocks/schemas required')
    if c['basis'] != c['catalog']['basis'] or c['variables'] != c['catalog']['variables']:
        raise SupportDataError('full literal compiler linkage')
    names = [d['name'] for d in inv['definitions']]
    if len(set(names)) != len(names):
        raise SupportDataError('duplicate registry definition')
    definitions = dict(zip(names, inv['definitions']))
    if (len(set(inv['interfaces'])) != len(inv['interfaces']) or
            any(n not in definitions for n in inv['interfaces']) or
            [d['definition'] for d in inv['definitions']] != inv['native_blocks']):
        raise SupportDataError('full ordered registry/native linkage')
    formula_records, formula_ids, edges = [], {}, []
    basis_words = {_json(f) for f in c['basis']}
    if len(basis_words) != len(c['basis']) or _json(s['target']) not in basis_words:
        raise SupportDataError('unique basis containing target required')

    def formula_id(formula):
        w.step('formula_visits')
        word = _json(formula)
        if word not in formula_ids:
            identifier = len(formula_records)
            formula_ids[word] = identifier
            formula_records.append(dict(formula_id=identifier, formula=formula,
                                        literal_preimage=word.decode('utf-8'),
                                        in_root_basis=word in basis_words))
        return formula_ids[word]

    def edge(rule, output, premises, provenance):
        w.step('edges_considered')
        output_id = formula_id(output)
        ordered = [formula_id(f) for f in premises]
        active = _json(output) in basis_words and all(_json(f) in basis_words for f in premises)
        edges.append(dict(edge_id=len(edges), rule=rule, conclusion=output_id,
                          ordered_premises=ordered, positive_row_cost=1,
                          active_in_root_formula_grammar=active,
                          inactive_reason=None if active else 'FORMULA_OUTSIDE_ROOT_BASIS',
                          provenance=provenance))

    status, reason = 'COMPLETE', None
    try:
        for f in c['basis']:
            formula_id(f)
        for name in sorted(s['theory']['axioms']):
            w.step('axiom_visits')
            f = s['theory']['axioms'][name]
            if _json(f) in basis_words:
                edge('axiom', f, [], dict(name=name, exact_declared_formula=f))
        for index, f in enumerate(c['tautologies']):
            edge('tautology', f, [], dict(admitted_tautology_index=index,
                                         compiler_queries=c['queries']))
        for index, command in enumerate(c['admitted_schemes']):
            if command['rule'] not in ('instantiate', 'eq_subst'):
                raise SupportDataError('unexpected admitted zero-read scheme')
            edge(command['rule'], command['formula'], [],
                 dict(admitted_scheme_index=index, exact_command=command,
                      zero_read_licence_only=True, compiler_queries=c['queries']))
        variables = set(c['variables'])
        for index, f in enumerate(c['basis']):
            w.step('basis_rule_visits')
            if f[0] == 'eq' and f[1] == f[2]:
                edge('refl', f, [], dict(basis_index=index))
            if f[0] == 'imp':
                edge('mp', f[2], [f[1], f],
                     dict(implication_basis_index=index,
                          ordered_roles=['antecedent', 'implication']))
            if f[0] == 'all' and f[1] in variables:
                edge('generalize', f, [f[2]],
                     dict(universal_basis_index=index, variable=f[1],
                          root_context=c['catalog']['root_context'],
                          actual_prior_body_required=True))
        for mode, name in enumerate(inv['interfaces'], 1):
            d = definitions[name]
            edge('block', d['definition']['conclusion'], d['definition']['premises'],
                 dict(interface_name=name, interface_mode=mode,
                      exact_definition_record=d,
                      native_definition_index=names.index(name),
                      exported_interface_only=True))
    except _OwnStop as stopped:
        if stopped.owner is not w:
            raise
        status, reason = 'UNKNOWN_WORK_BUDGET', 'support_graph_work_budget'
    check()
    preimage = dict(input_projection=projection, formulas=formula_records, edges=edges)
    return dict(schema=GRAPH_SCHEMA, version=VERSION, strategy=STRATEGY,
                status=status, reason=reason, graph_preimage=preimage,
                graph_sha256=_sha(preimage), target_formula=s['target'],
                target_formula_id=formula_ids.get(_json(s['target'])),
                counts=counts, work_limit=work_limit,
                logical_authority=False, admissible_lower_bound=False,
                native_proof_accepted=False, candidate_pruning=False)


def _justified(rows, w):
    """Check literal strict-prior row references, without accepting commands."""
    indexed = {}
    for packet in rows:
        w.step('row_packets')
        row = packet['row']
        if type(row) is not int or row < 0 or type(packet['requirements']) is not list:
            raise SupportDataError('complete row packet fields')
        if row in indexed:
            old = indexed[row]
            if old['formula'] != packet['formula'] or old['requirements'] != packet['requirements']:
                raise SupportDataError('conflicting row projections')
        else:
            indexed[row] = packet
    known, trace = {}, []
    for row, packet in sorted(indexed.items()):
        w.step('rows_checked')
        missing = []
        for position, requirement in enumerate(packet['requirements']):
            w.step('ordered_requirements')
            if type(requirement) is not list or len(requirement) != 2:
                raise SupportDataError('ordered literal requirement pair')
            source, wanted = requirement
            if type(source) is not int or not 0 <= source < row:
                raise SupportDataError('strict-prior row reference required')
            if source not in known or known[source] != wanted:
                missing.append(position)
        if not missing:
            known[row] = packet['formula']
        trace.append(dict(row=row, justified=not missing,
                          missing_requirement_positions=missing))
    return known, trace


def _potential(graph, seed_ids, w):
    preimage = graph['graph_preimage']
    costs = [None for _ in preimage['formulas']]
    origins = [None for _ in costs]
    for identifier in seed_ids:
        w.step('seed_assignments')
        costs[identifier], origins[identifier] = 0, dict(kind='CURRENT_JUSTIFIED_FACT')
    changed = True
    while changed:
        changed = False
        for edge in preimage['edges']:
            w.step('relaxation_edge_visits')
            if not edge['active_in_root_formula_grammar']:
                continue
            values = []
            for source in edge['ordered_premises']:
                w.step('relaxation_ordered_ports')
                values.append(costs[source])
            if any(value is None for value in values):
                continue
            value = 1 + sum(values)  # Repeated ordered ports remain repeated costs.
            output = edge['conclusion']
            if costs[output] is None or value < costs[output]:
                costs[output] = value
                origins[output] = dict(kind='HYPEREDGE', edge_id=edge['edge_id'])
                changed = True
                w.counts['relaxation_improvements'] = w.counts.get('relaxation_improvements', 0) + 1
    return costs, origins


def rank_support_options(*, graph, known_rows, options, check,
                         work_limit=DEFAULT_WORK_LIMIT):
    """Return a full option permutation; incomplete scoring means identity.

    Rows must be completed, caller-validated command/guard/input projections.
    An option is {'option_id': builtin provenance, 'rows': [complete rows]}.
    Partial/random items use rows=[] rather than invented conclusions. Every
    repeated option is retained. Exact newly-justified output sets may share
    one relaxation computation; all option IDs/rows and mappings are saved.
    """
    counts = {'work': 0, 'copy_nodes': 0}
    w = _Work(check, work_limit, counts)
    if type(options) is not list or type(known_rows) is not list:
        raise SupportDataError('row/option lists required')
    owned_rows = _copy(known_rows, check, counts)
    owned_options = _copy(options, check, counts)
    if (graph.get('schema') != GRAPH_SCHEMA or graph.get('version') != VERSION or
            graph.get('strategy') != STRATEGY or
            graph.get('graph_sha256') != _sha(graph['graph_preimage'])):
        raise SupportDataError('exact current support graph required')
    order = list(range(len(owned_options)))
    receipt = dict(schema=RANK_SCHEMA, version=VERSION, strategy=STRATEGY,
                   status='STABLE_FALLBACK', reason=None,
                   graph_sha256=graph['graph_sha256'], known_rows=owned_rows,
                   options=owned_options, order=order,
                   base_justification=[], base_seed_formula_ids=[], base_costs=[],
                   distinct_output_scores=[], option_scores=[],
                   counts=counts, work_limit=work_limit,
                   logical_authority=False, admissible_lower_bound=False,
                   candidate_pruning=False, complete_option_multiplicity=True)
    if graph['status'] != 'COMPLETE':
        receipt['reason'] = 'incomplete_support_graph'
        check()
        return receipt
    formulas = graph['graph_preimage']['formulas']
    by_word = {_json(record['formula']): record['formula_id'] for record in formulas}
    target = graph['target_formula_id']
    try:
        known, justification = _justified(owned_rows, w)
        seed_ids = sorted({by_word[_json(f)] for f in known.values() if _json(f) in by_word})
        receipt['base_justification'] = justification
        receipt['base_seed_formula_ids'] = seed_ids
        base_costs, base_origins = _potential(graph, seed_ids, w)
        receipt['base_costs'] = [dict(formula_id=i, cost=v, origin=base_origins[i])
                                 for i, v in enumerate(base_costs)]
        base_target = base_costs[target]
        cache = {}
        for index, option in enumerate(owned_options):
            w.step('options_checked')
            if type(option['rows']) is not list:
                raise SupportDataError('option complete rows required')
            projected, trace = _justified(owned_rows + option['rows'], w)
            projected_ids = sorted({by_word[_json(f)] for f in projected.values() if _json(f) in by_word})
            added = tuple(identifier for identifier in projected_ids if identifier not in seed_ids)
            if added not in cache:
                w.step('distinct_output_sets')
                costs, origins = _potential(graph, projected_ids, w)
                after = costs[target]
                score_id = len(receipt['distinct_output_scores'])
                record = dict(score_id=score_id, added_formula_ids=list(added),
                              seed_formula_ids=projected_ids,
                              target_cost_before=base_target, target_cost_after=after,
                              marginal_reduction=(base_target - after if base_target is not None and after is not None else None),
                              makes_target_potential_finite=base_target is None and after is not None,
                              costs=[dict(formula_id=i, cost=v, origin=origins[i]) for i, v in enumerate(costs)])
                receipt['distinct_output_scores'].append(record)
                cache[added] = score_id
            score_id = cache[added]
            receipt['option_scores'].append(dict(option_index=index, score_id=score_id,
                                                  projected_justification=trace))
        # A common base makes lower after-cost exactly greater marginal gain.
        # No potential is a stable tie, not exclusion or a negative proof.
        score_by_option = {p['option_index']: receipt['distinct_output_scores'][p['score_id']]
                           for p in receipt['option_scores']}
        order = sorted(order, key=lambda i: (score_by_option[i]['target_cost_after'] is None,
                                             score_by_option[i]['target_cost_after'] or 0, i))
        if sorted(order) != list(range(len(owned_options))):
            raise SupportDataError('ordering must preserve all option multiplicity')
        receipt.update(status='SCORED', order=order)
    except _OwnStop as stopped:
        if stopped.owner is not w:
            raise
        receipt['reason'] = 'support_ranking_work_budget'
        # Full input order remains; partial scores are observations, inoperative.
    check()
    return receipt
