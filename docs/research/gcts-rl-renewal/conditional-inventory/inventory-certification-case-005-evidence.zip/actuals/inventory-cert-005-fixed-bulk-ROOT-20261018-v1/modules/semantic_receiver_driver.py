"""Fresh finite quantified semantic-family receiver, injected implementations.

No imported scientific modules, target proof, preferred family or row route.
The caller owns executable custody, the bounded native factory and whole-run
resource enforcement. This file adds a receiver and post-result observations;
it does not alter the logical palette, point engine, Join, or SMT encoding.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile

VERSION = 'semantic-family-inventory-certification-driver-v2'
RESULT_SCHEMA = 'semantic-family-fresh-receiver-result-v1'
RECEIPT_SCHEMA = 'semantic-family-fresh-receiver-output-receipt-v1'
SOURCE_EPOCH_SCHEMA = 'semantic-family-receiver-source-epoch-v4-inventory-certification'
OUTPUT_CAP_BYTES = 128 * 1024 * 1024
POLICY_SHA256 = 'f5f0c22121f4c503db319fe6e01c4c3a146ac9db9deb7e2ccec0aab1a2f32161'
POLICY_BYTES = 4502
DEPENDENCY_PINS = {'base_compiler': ('d1c4afa10d58abbcf473cb3da8ee8768c974dd05d03ea00b988d574b2441af5a', 11060), 'family_miner': ('8b839081400efbc600079f4164e4564ab3ca4dfe4d52aa791d5182855e0540ad', 7196), 'family_model': ('f65eb38269db74ff5db0d9eb2096a38d7f07bbd6a579aa564acc692f84e4437c', 6472), 'family_search': ('35443c958f2115efa18cc923fb4a4f1070e6e03ccf1d1adf2bb56ce1f7bab28b', 15936), 'family_registry': ('2010ca7cb6f3da0734efe03e5be0f7e166b7e4d5939078dea0451361cf5890f3', 12626), 'point_smt': ('6bcb3fb60529f6888836a1ca0c613b772cea192c9549620f968dbdf7cb9be74a', 4593), 'symbolic_control': ('740319d243cc2fd2eefe1d7ef1611d8bcfe6f0ff70a2ce2ed72771e78f64a391', 26238), 'support_ordering': ('18cf90ebd75d746db3eb251eaffa92cd6a25432b70f34653b57f3d58ef5d8adc', 16868)}

MODEL_STORAGE_PINS = {
    'ordinary': ('f65eb38269db74ff5db0d9eb2096a38d7f07bbd6a579aa564acc692f84e4437c', 6472),
    'literal_interned': ('fb37663b4c0c3de4e9f3c28564678af833857f7ebe761cd83275d62f123b9a8e', 4311),
}


class DriverDataError(ValueError):
    pass


class OutputCapExceeded(RuntimeError):
    pass


class _DeadlineStop(Exception):
    def __init__(self, owner):
        self.owner = owner
        super().__init__('receiver cooperative work deadline')


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def _owned(value):
    return json.loads(_json(value))


def _sha(value):
    return hashlib.sha256(_json(value)).hexdigest()


def _receiver_input(receiver_spec, boundary):
    """Owned literal input from the caller's pinned declaration selection.

    This checks the data envelope only. Existing syntax/native admission and
    _closed_receiver remain authoritative for the declared logical context.
    """
    boundary.check(full=True)
    fields = {'id', 'title', 'theory', 'target', 'length',
              'instantiation_rounds', 'scope'}
    if type(receiver_spec) is not dict or set(receiver_spec) != fields:
        raise DriverDataError('exact ordinary receiver specification fields required')
    if (type(receiver_spec['id']) is not str or not receiver_spec['id'] or
            any(type(receiver_spec[k]) is not str for k in ('title', 'scope'))):
        raise DriverDataError('literal receiver ID/title/scope strings required')
    if (type(receiver_spec['length']) is not int or receiver_spec['length'] != 12 or
            type(receiver_spec['instantiation_rounds']) is not int or
            receiver_spec['instantiation_rounds'] != 2):
        raise DriverDataError('this frozen input profile requires twelve rows and two syntax rounds')
    theory = receiver_spec['theory']
    if (type(theory) is not dict or
            set(theory) != {'functions', 'predicates', 'axioms', 'schemas'} or
            any(type(theory[k]) is not dict for k in ('functions', 'predicates', 'axioms')) or
            type(theory['schemas']) is not list or theory['schemas']):
        raise DriverDataError('ordinary theory signature/axioms and empty schemas required')
    selection = boundary.epoch.get('receiver_selection')
    if (type(selection) is not dict or
            set(selection) != {'schema', 'receiver_id', 'spec'} or
            selection['schema'] != 'closed-quantified-receiver-selection-v1' or
            type(selection['receiver_id']) is not str or
            selection['receiver_id'] != receiver_spec['id']):
        raise DriverDataError('explicit current declaration receiver selection required')
    literal = _json(receiver_spec)
    if _json(selection['spec']) != literal:
        raise DriverDataError('full receiver input/declaration selection mismatch')
    # JSON reconstruction gives the scientific pipeline its own builtin data.
    owned = json.loads(literal)
    boundary.check(full=True)
    if _json(receiver_spec) != literal:
        raise DriverDataError('receiver input changed during selection custody')
    return owned, literal


class _Boundary:
    def __init__(self, *, source_epoch, source_guard, tick, now, deadline):
        if type(source_epoch) is not dict or source_epoch.get('schema') != SOURCE_EPOCH_SCHEMA:
            raise DriverDataError('explicit receiver Source epoch required')
        if (type(source_epoch.get('model_storage')) is not str or
                source_epoch['model_storage'] not in MODEL_STORAGE_PINS):
            raise DriverDataError('explicit ordinary/literal_interned Model storage required')
        if type(source_epoch.get('search_ordering')) is not str or source_epoch['search_ordering'] not in ('legacy', 'and_support'):
            raise DriverDataError('explicit legacy/and_support Source-epoch ordering required')
        if not isinstance(source_epoch.get('sources'), dict) or not isinstance(source_epoch.get('native_inputs'), dict):
            raise DriverDataError('complete Source and native-input maps required')
        if not all(callable(f) for f in (source_guard, tick, now)):
            raise DriverDataError('caller custody, clock and work callbacks required')
        if type(deadline) not in (int, float) or not math.isfinite(deadline):
            raise DriverDataError('finite absolute monotonic work deadline required')
        self.epoch = source_epoch
        self.frozen = _json(source_epoch)
        self.guard = source_guard
        self.tick = tick
        self.now = now
        self.deadline = deadline
        self.last = None

    def observe(self):
        value = self.now()
        if type(value) not in (int, float) or not math.isfinite(value):
            raise DriverDataError('invalid monotonic clock value')
        if self.last is not None and value < self.last:
            raise DriverDataError('monotonic clock went backwards')
        self.last = value
        return value

    def check(self, full=False):
        self.tick()
        if full:
            self.guard()
            if _json(self.epoch) != self.frozen:
                raise DriverDataError('Source epoch changed')
        value = self.observe()
        if value >= self.deadline:
            raise _DeadlineStop(self)
        return value

    def remaining(self):
        return self.deadline - self.check()


def _input_custody(modules, policy_bytes, boundary):
    boundary.check(full=True)
    if type(modules) is not dict or set(modules) != set(DEPENDENCY_PINS):
        raise DriverDataError('exact injected implementation roles required')
    selected_pins = dict(DEPENDENCY_PINS)
    selected_pins['family_model'] = MODEL_STORAGE_PINS[boundary.epoch['model_storage']]
    pins = {}
    for role, (wanted_sha, wanted_bytes) in selected_pins.items():
        boundary.check()
        path = Path(modules[role].__file__).resolve()
        raw = path.read_bytes()
        actual = hashlib.sha256(raw).hexdigest()
        if actual != wanted_sha or len(raw) != wanted_bytes:
            raise DriverDataError('changed injected implementation: ' + role)
        pins[role] = dict(path=str(path), sha256=actual, bytes=len(raw))
    if type(policy_bytes) is not bytes or len(policy_bytes) != POLICY_BYTES or hashlib.sha256(policy_bytes).hexdigest() != POLICY_SHA256:
        raise DriverDataError('exact full four-family policy bytes required')
    policy = json.loads(policy_bytes)
    library = policy['library']
    if type(library) is not list or len(library) != 4:
        raise DriverDataError('complete four-family library required')
    ids = [f['id'] for f in library]
    if len(set(ids)) != 4:
        raise DriverDataError('duplicate source family')
    before = set()
    for family in library:
        if any(dep not in before for dep in family['dependencies']):
            raise DriverDataError('source dependency order')
        before.add(family['id'])
    boundary.check(full=True)
    return policy, pins


def _model_identity(record):
    return _sha({k: v for k, v in record.items() if k != 'compile_seconds'})


def _compiler_semantics(record):
    """Every returned non-timing field, including the full syntax catalog."""
    return {k: v for k, v in record.items() if k != 'seconds'}


def _record_join(records, index, request, boundary):
    """Literal native record linkage, never a substitute for native checking."""
    boundary.check(full=True)
    if type(index) is not int or not 0 <= index < len(records):
        raise DriverDataError('native record index')
    record = records[index]
    if record['id'] != index or _json(record['request']) != _json(request) or record['request_sha256'] != _sha(request):
        raise DriverDataError('native record literal request join')
    return dict(record_id=index, request_sha256=record['request_sha256'],
                result_status=record['result']['status'], literal_request_matched=True)


def _compile_record_joins(compiled, records, spec, boundary):
    ids = compiled['queries']
    if type(ids) is not list or any(type(i) is not int for i in ids) or len(set(ids)) != len(ids):
        raise DriverDataError('compiler native query IDs')
    catalog = compiled['catalog']
    expected = [(dict(rule='tautology', formula=['imp', ['bot'], ['bot']]), 'first_order_theory_admission')]
    expected.extend((dict(rule='tautology', formula=f), 'first_order_tautology') for f in catalog['basis'])
    expected.extend((c, 'first_order_scheme') for c in catalog['schemes'])
    if len(ids) > len(expected) or compiled['status'] == 'complete' and len(ids) != len(expected):
        raise DriverDataError('compiler query prefix completeness')
    joined = []
    for position, index in enumerate(ids):
        boundary.check()
        if not 0 <= index < len(records):
            raise DriverDataError('compiler query index')
        command, purpose = expected[position]
        request = dict(protocol='gcts-fol-1', theory=spec['theory'], blocks=[],
                       proof=[command], target=command['formula'])
        if records[index]['purpose'] != purpose:
            raise DriverDataError('compiler query purpose')
        joined.append(_record_join(records, index, request, boundary))
    if not ids or compiled['theory_query'] != ids[0]:
        raise DriverDataError('compiler theory admission query')
    return dict(queries=joined, theory_query=compiled['theory_query'],
                scope='Full current request preimages and IDs, not native re-evaluation. Returned incomplete compiler packets remain incomplete.')


def _inventory_bulk_record_join_parent(inventory, records, spec, boundary):
    taut = ['imp', ['bot'], ['bot']]
    request = dict(protocol='gcts-fol-1', theory=spec['theory'], blocks=inventory['native_blocks'],
                   proof=[dict(rule='tautology', formula=taut)], target=taut)
    joined = _record_join(records, inventory['query'], request, boundary)
    if inventory['status'] == 'native_accepted' and joined['result_status'] != 'accepted':
        raise DriverDataError('native inventory acceptance status join')
    return joined



def _inventory_record_join(inventory, records, spec, boundary, certification_mode):
    if certification_mode == 'bulk':
        return _inventory_bulk_record_join_parent(inventory, records, spec, boundary)
    if certification_mode != 'dependency_closures':
        raise DriverDataError('explicit inventory certification mode')
    boundary.check(full=True)
    fields = {'status', 'query', 'queries', 'certification', 'seconds'}
    original = {k:v for k,v in inventory.items() if k not in fields}
    cert = inventory.get('certification')
    if (type(cert) is not dict or cert.get('schema') != 'native-inventory-dependency-closure-certification-v1'
            or cert.get('version') != 'native-inventory-exact-dependency-closures-v2'
            or cert.get('mode') != certification_mode
            or cert.get('inventory_sha256') != _sha(original)
            or cert.get('theory_sha256') != _sha(spec['theory'])
            or type(cert.get('aggregate_micro_step_limit')) is not int
            or cert['aggregate_micro_step_limit'] != 5*10**9):
        raise DriverDataError('complete original inventory/theory/cap certificate')
    definitions = inventory['definitions']
    blocks = inventory['native_blocks']
    if type(definitions) is not list or type(blocks) is not list:
        raise DriverDataError('literal complete inventory lists')
    if blocks != [d['definition'] for d in definitions]:
        raise DriverDataError('complete ordered definition bodies')
    names = []
    seen = set()
    by_name = {}
    for d in definitions:
        boundary.check()
        name = d['name']
        if type(name) is not str or name in seen or d['definition']['name'] != name:
            raise DriverDataError('unique current definition identity')
        for line in d['definition']['proof']:
            if line['rule'] == 'block' and line['name'] not in seen:
                raise DriverDataError('strict prior Native dependency')
        names.append(name);seen.add(name);by_name[name] = d['definition']
    if (cert.get('all_original_definition_names') != names
            or cert.get('all_original_interfaces') != inventory['interfaces']
            or any(n not in seen for n in inventory['interfaces'])
            or len(set(inventory['interfaces'])) != len(inventory['interfaces'])):
        raise DriverDataError('whole original definition/interface coverage')
    plans = []
    # Deliberately independent DFS over the literal bodies, rather than calling
    # the registry planner being checked.
    for name in names:
        wanted = set();pending = [name]
        while pending:
            boundary.check()
            n = pending.pop()
            if n in wanted:
                continue
            wanted.add(n)
            pending.extend(line['name'] for line in by_name[n]['proof']
                           if line['rule'] == 'block')
        plans.append(dict(definition=name,names=[n for n in names if n in wanted]))
    if not plans:
        plans = [dict(definition=None,names=[])]
    if cert.get('planned_requests') != plans:
        raise DriverDataError('every exact transitive dependency closure')
    receipts = cert.get('receipts')
    if type(receipts) is not list or not receipts or len(receipts)>len(plans):
        raise DriverDataError('nonempty serial receipt prefix')
    ids = [r['query'] for r in receipts]
    if (any(type(i) is not int for i in ids)
            or ids != list(range(len(records)-len(ids),len(records)))
            or inventory.get('query') is not None
            or inventory.get('queries') != ids):
        raise DriverDataError('fresh complete serial registration query suffix')
    used = 0;accepted = set();joined = [];last_status = None
    taut = ['imp', ['bot'], ['bot']]
    for ordinal,(r,plan) in enumerate(zip(receipts,plans)):
        boundary.check()
        remaining = 5*10**9-used
        if remaining <= 0:
            raise DriverDataError('no request after aggregate budget exhaustion')
        if (r.get('ordinal') != ordinal or type(r['ordinal']) is not int
                or r.get('definition') != plan['definition']
                or r.get('closure_names') != plan['names']
                or r.get('assigned_micro_step_limit') != remaining
                or type(r['assigned_micro_step_limit']) is not int
                or r.get('aggregate_consumed_before') != used
                or type(r['aggregate_consumed_before']) is not int):
            raise DriverDataError('exact ordered plan and shared step allowance')
        request = dict(protocol='gcts-fol-1',theory=spec['theory'],
                       blocks=[by_name[n] for n in plan['names']],
                       proof=[dict(rule='tautology',formula=taut)],target=taut)
        q = records[r['query']]
        if q['purpose'] != 'check_generated_lemma_definition_closure':
            raise DriverDataError('current closure request purpose')
        current = _record_join(records,r['query'],request,boundary)
        steps = q['result'].get('micro_steps');status = q['result']['status']
        if (type(steps) is not int or not 0<=steps<=remaining
                or status not in ['accepted','rejected','unknown_space_budget','unknown_step_budget']
                or r.get('consumed_micro_steps') != steps
                or type(r['consumed_micro_steps']) is not int
                or r.get('aggregate_consumed_after') != used+steps
                or type(r['aggregate_consumed_after']) is not int
                or r.get('request_sha256') != _sha(request)
                or r.get('result_status') != status):
            raise DriverDataError('current Native outcome and exact step accounting')
        used += steps
        joined.append(current);last_status=status
        if status == 'accepted':
            accepted.update(plan['names'])
        elif ordinal+1 != len(receipts):
            raise DriverDataError('no continuation after rejected/unknown query')
    complete = (len(receipts)==len(plans) and last_status=='accepted'
                and accepted==set(names))
    if complete:
        expected_status='native_accepted';stop=None
    elif last_status=='rejected':
        expected_status='native_rejected';stop='rejected'
    elif last_status in ['unknown_space_budget','unknown_step_budget']:
        expected_status='unknown_native_inventory';stop=last_status
    elif last_status=='accepted' and used==5*10**9 and len(receipts)<len(plans):
        expected_status='unknown_native_inventory';stop='aggregate_registration_micro_step_budget'
    else:
        raise DriverDataError('incomplete acceptance is not inventory authority')
    if (inventory['status'] != expected_status or cert.get('complete') is not complete
            or cert.get('stop_reason') != stop
            or type(cert.get('aggregate_consumed_micro_steps')) is not int
            or cert['aggregate_consumed_micro_steps'] != used
            or cert.get('accepted_definition_names') != [n for n in names if n in accepted]):
        raise DriverDataError('all-or-none full inventory authority and provenance')
    return dict(mode=certification_mode,queries=joined,complete=complete,
                full_original_inventory=complete,aggregate_consumed_micro_steps=used,
                aggregate_micro_step_limit=5*10**9,status=expected_status,
                scope='Independent exact per-closure Native transcript joins and '
                      'whole original inventory coverage. Partial accepted bodies '
                      'never authorize a reduced search inventory; final whole '
                      'proof Native acceptance remains separate.')


def _closed_receiver(spec, boundary):
    """Check only the declared closed syntax, not theorem validity."""
    def term_names(value):
        boundary.check()
        if value[0] == 'var':
            return {value[1]}
        if value[0] == 'fun':
            return set().union(*(term_names(t) for t in value[2]))
        raise DriverDataError('receiver term syntax')

    def formula_names(value):
        boundary.check()
        if value[0] == 'all':
            return formula_names(value[2]) - {value[1]}
        if value[0] in ('imp', 'and', 'or', 'not'):
            return set().union(*(formula_names(f) for f in value[1:]))
        if value[0] == 'pred':
            return set().union(*(term_names(t) for t in value[2]))
        if value[0] == 'eq':
            return term_names(value[1]) | term_names(value[2])
        if value == ['bot']:
            return set()
        raise DriverDataError('receiver formula syntax')

    free = {name: sorted(formula_names(formula)) for name, formula in spec['theory']['axioms'].items()}
    target_free = sorted(formula_names(spec['target']))
    if any(free.values()) or target_free or spec['theory']['schemas'] or spec.get('assumptions') or spec.get('blocks'):
        raise DriverDataError('this receiver requires closed theory and target, no root assumptions or supplied blocks')
    return dict(status='OBSERVED_CLOSED_DECLARATION_SYNTAX', axiom_free_variables=free,
                target_free_variables=target_free, root_assumptions=[], supplied_blocks=[],
                theorem_proved=False)


def _state_record(state):
    return dict(totals=sorted(state.totals.items()), marks=sorted(state.marks.items()),
                generations=sorted(state.generations.items()), roots=sorted(state.roots.items()),
                selected=sorted(state.selected), order=list(state.order),
                tile_generations=list(state.tile_generations),
                allowed_points=sorted(state.allowed_points))


def _references(command, index, definitions, summaries, assumptions):
    """Structural references only; the native checker remains logical authority."""
    rule = command['rule']
    if rule == 'mp':
        refs = [command['antecedent'], command['implication']]
    elif rule == 'generalize':
        refs = [command['source']]
    elif rule == 'instantiate':
        # A native UI command produces an implication licence, not its body.
        # The universal argument is syntax; its use as a fact needs a later MP.
        refs = []
    elif rule == 'block':
        name = command['name']
        if name not in definitions or name not in summaries:
            raise DriverDataError('unknown or forward block in observer')
        inputs = command['inputs']
        if type(inputs) is not list or len(inputs) != len(definitions[name]['premises']):
            raise DriverDataError('block observer input arity')
        refs = list(inputs)
    elif rule == 'assumption':
        port = command['index']
        if type(port) is not int or not 0 <= port < len(assumptions) or command['formula'] != assumptions[port]:
            raise DriverDataError('observer assumption provenance')
        refs = []
    elif rule in ('axiom', 'tautology', 'refl', 'distribute', 'eq_subst', 'induction'):
        refs = []
    else:
        raise DriverDataError('unsupported native rule in observer')
    if any(type(ref) is not int or not 0 <= ref < index for ref in refs):
        raise DriverDataError('observer strict-prior reference')
    if rule == 'block':
        return [refs[p] for p in summaries[command['name']]['essential_assumption_indices']], refs
    return refs, refs


def _scope_summary(proof, target, assumptions, definitions, summaries, boundary):
    if type(proof) is not list or not proof or proof[-1]['formula'] != target:
        raise DriverDataError('observer final target')
    edges = []
    ordered = []
    all_cost = 0
    for j, command in enumerate(proof):
        boundary.check()
        refs, full_refs = _references(command, j, definitions, summaries, assumptions)
        if command['rule'] == 'block':
            definition = definitions[command['name']]
            if [proof[k]['formula'] for k in full_refs] != definition['premises'] or command['formula'] != definition['conclusion']:
                raise DriverDataError('observer literal block interface')
            all_cost += summaries[command['name']]['all_recursive_primitive_commands']
        elif command['rule'] != 'assumption':
            all_cost += 1
        edges.append(refs)
        ordered.append(full_refs)
    reached = set()
    pending = [len(proof) - 1]
    while pending:
        boundary.check()
        j = pending.pop()
        if j not in reached:
            reached.add(j)
            pending.extend(edges[j])
    ports = sorted({proof[j]['index'] for j in reached if proof[j]['rule'] == 'assumption'})
    primitive_cost = sum(summaries[proof[j]['name']]['essential_recursive_primitive_commands']
                         if proof[j]['rule'] == 'block' else 0 if proof[j]['rule'] == 'assumption' else 1
                         for j in reached)
    rule_counts = {}
    all_rule_counts = {}
    for j, command in enumerate(proof):
        boundary.check()
        rule = command['rule']
        counts = summaries[command['name']]['all_recursive_primitive_rule_counts'] if rule == 'block' else {} if rule == 'assumption' else {rule: 1}
        for name, count in counts.items():
            all_rule_counts[name] = all_rule_counts.get(name, 0) + count
        if j in reached:
            counts = summaries[command['name']]['essential_recursive_primitive_rule_counts'] if rule == 'block' else {} if rule == 'assumption' else {rule: 1}
            for name, count in counts.items():
                rule_counts[name] = rule_counts.get(name, 0) + count
    if sum(rule_counts.values()) != primitive_cost or sum(all_rule_counts.values()) != all_cost:
        raise DriverDataError('recursive primitive count conservation')
    return dict(essential_rows=sorted(reached), essential_assumption_indices=ports,
                essential_ordered_references=[dict(row=j, references=edges[j], all_declared_references=ordered[j]) for j in sorted(reached)],
                essential_recursive_primitive_commands=primitive_cost,
                all_recursive_primitive_commands=all_cost,
                essential_recursive_primitive_rule_counts=dict(sorted(rule_counts.items())),
                all_recursive_primitive_rule_counts=dict(sorted(all_rule_counts.items())),
                essential_block_rows=[j for j in sorted(reached) if proof[j]['rule'] == 'block'])


def _proof_observation(proof, target, inventory, library, boundary):
    definitions = {}
    summaries = {}
    meta = {d['name']: d for d in inventory['definitions']}
    families = {f['id']: f for f in library}
    if len(meta) != len(inventory['definitions']):
        raise DriverDataError('duplicate ground definition metadata')
    for definition in inventory['native_blocks']:
        boundary.check()
        name = definition['name']
        if name in definitions:
            raise DriverDataError('observer duplicate definition')
        if name not in meta or _json(meta[name]['definition']) != _json(definition) or meta[name]['family'] not in families:
            raise DriverDataError('ground metadata/native definition join')
        summary = _scope_summary(definition['proof'], definition['conclusion'], definition['premises'], definitions, summaries, boundary)
        definitions[name] = definition
        summaries[name] = summary
    if set(definitions) != set(meta):
        raise DriverDataError('complete ground metadata/native definitions')
    root = _scope_summary(proof, target, [], definitions, summaries, boundary)
    if root['essential_assumption_indices']:
        raise DriverDataError('open root assumptions are not allowed')
    calls = []
    quantifiers = []

    def collect(lines, summary, path):
        for row in summary['essential_rows']:
            boundary.check()
            command = lines[row]
            if command['rule'] in ('instantiate', 'generalize'):
                references = next(r for r in summary['essential_ordered_references'] if r['row'] == row)
                quantifiers.append(dict(scope_path=_owned(path), row=row, command=_owned(command),
                                        references=_owned(references),
                                        source_formula=_owned(lines[command['source']]['formula']) if command['rule'] == 'generalize' else None,
                                        scope_assumptions=_owned(definitions[path[-1]['name']]['premises']) if path else [],
                                        zero_input_implication_licence=command['rule'] == 'instantiate',
                                        root_primitive=not path))
        for row in summary['essential_block_rows']:
            boundary.check()
            name = lines[row]['name']
            m = meta[name]
            family = families[m['family']]
            arguments = m['arguments']
            donor = [['pred', atom, []] for atom in family['donor_atoms']]
            compound = [i for i, a in enumerate(arguments) if isinstance(a, list) and a and a[0] in ('imp', 'and', 'or', 'not', 'all')]
            call_path = path + [dict(row=row, name=name)]
            calls.append(dict(path=call_path, root_row=call_path[0]['row'], name=name,
                              family=m['family'], level=m['level'], arguments=_owned(arguments),
                              nonidentity=arguments != donor, compound_argument_indices=compound,
                              inputs=_owned(lines[row]['inputs']),
                              essential_input_indices=summaries[name]['essential_assumption_indices'],
                              primitive_use=summaries[name]['essential_recursive_primitive_commands']))
            collect(definitions[name]['proof'], summaries[name], call_path)

    collect(proof, root, [])
    instantiate = [o for o in quantifiers if o['command']['rule'] == 'instantiate']
    generalize = [o for o in quantifiers if o['command']['rule'] == 'generalize']
    counts = root['essential_recursive_primitive_rule_counts']
    if len(instantiate) != counts.get('instantiate', 0) or len(generalize) != counts.get('generalize', 0):
        raise DriverDataError('quantifier occurrence/recursive count join')
    return dict(status='OBSERVED_AFTER_FRESH_NATIVE_ACCEPTANCE', root=root,
                essential_calls=calls,
                essential_quantifier_occurrences=quantifiers,
                essential_instantiate_count=len(instantiate),
                essential_generalize_count=len(generalize),
                quantified_reasoning_success=bool(instantiate and generalize),
                ground_definition_summaries=summaries,
                primitive_cost_scope='Structural recursive use counts after removing assumption rows. Shared earlier rows count once per scope, repeated block invocations unfold separately. This is not an inlined certificate, a point occupancy expansion, a universal family theorem or independent logical checking.',
                essentiality_scope='References of each actual block body final line determine which assumption ports reach the output. All declared ports are still validated. UI is a zero-read implication licence; UG reads its strict-prior source. Actual reached UI/UG commands inside recursively essential block bodies also count; opaque universal formulas and unused UI rows do not. No open root assumptions.')


def _key(value):
    if not isinstance(value, (list, tuple)) or len(value) != 4 or any(type(v) is not int for v in value):
        raise DriverDataError('invalid positional placement key')
    return tuple(value)


def _aggregate_observation(item, prefix, placements, initial, boundary):
    totals = {tuple(p): v for p, v in initial['totals']}
    marks = {tuple(p): v for p, v in initial['marks']}
    selected = set()
    allowed = {tuple(p) for p in initial['allowed_points']}
    for key in prefix:
        boundary.check()
        if key in selected:
            raise DriverDataError('duplicate winning placement')
        selected.add(key)
        candidate = placements[key]
        for p, v in candidate['occupancy']:
            p = tuple(p)
            if p not in allowed or totals.get(p, 0) + v > 12:
                raise DriverDataError('winning prefix capacity')
            totals[p] = totals.get(p, 0) + v
        for p, v in candidate['marks']:
            p = tuple(p)
            if p in marks and marks[p] != v:
                raise DriverDataError('winning prefix mark agreement')
            marks[p] = v
    members = sorted({_key(k) for k in item['members']})
    new_totals = {}
    new_marks = {}
    pending = []
    added = 0
    for key in members:
        boundary.check()
        if key in selected:
            continue
        pending.append(key)
        candidate = placements[key]
        for p, v in candidate['occupancy']:
            p = tuple(p)
            if p not in allowed or totals.get(p, 0) + new_totals.get(p, 0) + v > 12:
                raise DriverDataError('hint aggregate capacity')
            new_totals[p] = new_totals.get(p, 0) + v
        for p, v in candidate['marks']:
            p = tuple(p)
            if p in marks and marks[p] != v or p in new_marks and new_marks[p] != v:
                raise DriverDataError('hint aggregate mark agreement')
            if p not in marks and p not in new_marks:
                added += 1
            new_marks[p] = v
    expected = dict(members=members, pending=pending,
                    aggregate_sha256=_sha(dict(totals=sorted(new_totals.items()), marks=sorted(new_marks.items()))),
                    new_occupancy=sum(new_totals.values()), new_marks=added)
    if _json(expected) != _json({k: item[k] for k in expected}):
        raise DriverDataError('literal hint aggregate mismatch')
    return expected


def _winning_hint_links(search, model_record, initial, proof_observation, proof, boundary):
    if 'tree' not in search:
        return dict(status='NOT_APPLICABLE_NO_GCTS_TREE', links=[], strong_family_hint_use=False,
                    changed_order_family_hint_use=False)
    placements = {_key(p['key']): p for p in model_record['placements']}
    chosen = [_key(k) for k in search['placements']]
    if len(set(chosen)) != len(chosen):
        raise DriverDataError('duplicate selected placement')
    selected = set(chosen)
    hints = {h['id']: h for h in search['hints']}
    events = {e['id']: e for e in search['events']}
    root_calls = {c['root_row']: c for c in proof_observation['essential_calls'] if len(c['path']) == 1}
    node = search['tree']
    links = []
    active_id = None
    for depth, key in enumerate(chosen):
        boundary.check()
        prefix = chosen[:depth]
        if node['kind'] not in ('forced', 'branch'):
            raise DriverDataError('noncontinuation on winning path')
        if node['hint_in'] != active_id:
            raise DriverDataError('winning hint continuity')
        review = node['review']
        if review['phase'] not in ('eligible', 'waiting'):
            active_id = None
        trace = review
        if 'hint_start' in node:
            if node['kind'] != 'branch' or active_id is not None:
                raise DriverDataError('hint did not start at a free branch')
            active_id = node['hint_start']
            hint = hints[active_id]
            event = events[node['policy_event']]
            if [_key(k) for k in hint['chosen']] != prefix or [_key(k) for k in event['chosen']] != prefix or hint['point'] != node['point'] or event['point'] != node['point']:
                raise DriverDataError('winning hint source context')
            if _json(event['items'][event['index']]) != _json(hint['item']):
                raise DriverDataError('winning chosen event item')
            _aggregate_observation(hint['item'], prefix, placements, initial, boundary)
            trace = node['start_review']
        preferred = {_key(k) for k in trace['eligible']} if active_id is not None else set()
        census = next((c for c in node['census'] if c['point'] == node['point']), None)
        if census is None:
            raise DriverDataError('selected point missing from full census')
        original = sorted(_key(k) for k in census['keys'])
        ordered = original if node['kind'] == 'forced' else [k for k in original if k in preferred] + [k for k in original if k not in preferred]
        if [_key(k) for k in node['alternatives']] != ordered:
            raise DriverDataError('winning alternatives order')
        children = [c for c in node['children'] if _key(c['key']) == key]
        if len(children) != 1 or key not in ordered:
            raise DriverDataError('actual selected path child')
        child = children[0]
        if child['role'] != ('member' if key in preferred else 'base'):
            raise DriverDataError('preferred selection provenance')
        if active_id is not None and key in preferred:
            item = hints[active_id]['item']
            row = key[0]
            call = root_calls.get(row)
            if item['kind'] == 'lemma' and call is not None:
                members = [_key(k) for k in item['members']]
                guards = [placements[k] for k in members if k[0] == row and k[1] == 1]
                if len(guards) != 1:
                    raise DriverDataError('lemma hint exact call guard')
                command = guards[0]['command']
                matches = command['rule'] == 'block' and command['name'] == call['name'] and command['formula'] == proof[row]['formula']
                full_members_selected = all(k in selected for k in members)
                port_sources = [placements[k]['source'] for k in sorted(members) if k[0] == row and k[1] >= 2 and placements[k]['kind'] == 'lemma_input']
                exact_ports = port_sources == proof[row]['inputs']
                if matches:
                    links.append(dict(path_depth=depth, key=key, row=row, hint_id=active_id,
                                      hint_kind=item['kind'], name=call['name'], family=call['family'],
                                      arguments=call['arguments'], level=call['level'],
                                      nonidentity=call['nonidentity'], compound_argument_indices=call['compound_argument_indices'],
                                      full_hint_members_on_winning_path=full_members_selected,
                                      exact_ordered_input_sources=exact_ports,
                                      selection_kind=node['kind'], original_order=original,
                                      preferred_order=ordered, changed_original_order=ordered != original,
                                      primitive_use=call['primitive_use']))
        node = child['tree']
    if node['kind'] != 'empty' or node['children']:
        raise DriverDataError('winning path does not end at complete region')
    good = [l for l in links if l['nonidentity'] and l['full_hint_members_on_winning_path'] and l['exact_ordered_input_sources']]
    return dict(status='OBSERVED_WINNING_LITERAL_PATH', links=links,
                strong_family_hint_use=bool(good),
                changed_order_family_hint_use=any(l['changed_original_order'] for l in good),
                scope='Same essential nonidentity ground instance, a validated lemma-row hint, and actual preferred selected constituents with full hinted row members and exact ordered ports. Compound argument indices are observational, not a requirement. Root versus nested body use is separate. Order change is separate and does not establish benefit. No level-two claim unless that actual essential instance is recorded.')


def _atomic_output(path, value, boundary):
    path = Path(path).resolve()
    serialization_started = boundary.check(full=True)
    if not path.parent.is_dir() or path.exists():
        raise DriverDataError('new output path in an existing directory required')
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.partial', dir=path.parent)
    pending = bytearray()
    size = 0
    digest = hashlib.sha256()
    published = False
    try:
        with os.fdopen(fd, 'wb') as stream:
            encoder = json.JSONEncoder(sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)
            for part in encoder.iterencode(value):
                pending.extend(part.encode('utf-8'))
                if len(pending) >= 65536:
                    boundary.check()
                    size += len(pending)
                    if size > OUTPUT_CAP_BYTES:
                        raise OutputCapExceeded('full result exceeds128MiB; no truncated proof result published')
                    digest.update(pending)
                    stream.write(pending)
                    pending.clear()
            pending.extend(b'\n')
            boundary.check()
            size += len(pending)
            if size > OUTPUT_CAP_BYTES:
                raise OutputCapExceeded('full result exceeds128MiB; no truncated proof result published')
            digest.update(pending)
            stream.write(pending)
            stream.flush()
            os.fsync(stream.fileno())
        serialized = boundary.observe()
        precommit = boundary.check(full=True)
        if path.exists():
            raise DriverDataError('output appeared before atomic publication')
        os.replace(temporary, path)
        published = True
        return dict(path=str(path), sha256=digest.hexdigest(), bytes=size,
                    cap_bytes=OUTPUT_CAP_BYTES, complete=True, atomic=True,
                    serialization_started_monotonic=serialization_started,
                    payload_serialized_monotonic=serialized,
                    publication_preflight_monotonic=precommit,
                    serialization_to_preflight_seconds=precommit - serialization_started)
    finally:
        if not published:
            Path(temporary).unlink(missing_ok=True)


def _symbolic_point_projection(spec, compiled, inventory, model, search, point_smt, boundary):
    """Literal producer/grammar/model joins; no symbolic search or logical oracle."""
    boundary.check(full=True)
    grammar = search['grammar']
    if grammar['spec'] != spec or _json(grammar['compiler']) != _json(_compiler_semantics(compiled)):
        raise DriverDataError('symbolic assertion/full compiled-language join')
    expected_inventory = {k: inventory[k] for k in ('definitions', 'interfaces', 'native_blocks')}
    if _json(grammar['inventory']) != _json(expected_inventory):
        raise DriverDataError('symbolic complete inventory join')
    if not search['root_path_restored']:
        raise DriverDataError('symbolic prefix stack not restored')
    complete = grammar['preparation_complete']
    if complete:
        if (_json(grammar['rows']) != _json(model.domains) or
                grammar['interface_order'] != inventory['interfaces'] or
                grammar['mode_ids'] != model.mode or grammar['required_interface_arity'] != model.arity or
                search['grammar_sha256'] != _sha(grammar)):
            raise DriverDataError('symbolic full row/mode/arity/grammar projection')
    elif search['proof'] is not None:
        raise DriverDataError('unfinished symbolic grammar cannot supply a proof')
    if search['proof'] is None:
        if search['placements']:
            raise DriverDataError('symbolic UNKNOWN must not supply operative placements')
        return dict(status='NO_OPERATIVE_PROOF', complete_grammar_joined=complete,
                    root_path_restored=True, scope='Returned partial metadata only; no whole-region or proof acceptance.')
    selected = [tuple(k) for k in search['placements']]
    region = point_smt.verify_selected(model, selected)
    decoded = model.decode(selected)
    if _json(decoded) != _json(search['proof']):
        raise DriverDataError('symbolic projected point-row/literal proof join')
    boundary.check(full=True)
    return dict(status='VERIFIED_SYMBOLIC_TO_COMMON_POINT_PROJECTION',
                complete_grammar_joined=True, root_path_restored=True,
                selected_placements=len(selected), decoded_rows=len(decoded), region=region,
                scope='Common complete point model retained in all arms. Exact whole selected t/m region and literal row decoding; native mathematical acceptance remains separate. This is not standalone no-point-model cost or GCTS scheduler equivalence.')


def run_receiver(*, receiver_spec, mode, search_ordering, inventory_certification_mode, policy_bytes, modules, oracle_factory, source_epoch,
                 source_guard, tick, now, work_deadline, closure_deadline, closure_tick,
                 output_path, progress_observer=None):
    """Run only when Root authorizes an actual and provides a bounded factory.

    factory(*,work_deadline,tick,source_guard,now) must return an oracle exposing
    records/request/query/close/transport_receipt. receiver_spec is required
    ordinary JSON data selected by exact ID from the pinned declaration and
    joined to the full Source-epoch selection; no theorem fallback is supplied.
    Constructor errors must reap
    its partial child internally. close() must reap before returning or raising.
    Caller callbacks/errors propagate; only this driver's own cooperative stage
    deadline produces an UNKNOWN. Full UNKNOWN serialization may use the explicit
    metadata-only closure window. Output caps or other serialization errors are
    never salvaged into a partial proof result.
    """
    if mode not in ('fixed', 'symbolic'):
        raise DriverDataError('declared fixed/symbolic mechanism-control mode')
    if type(search_ordering) is not str or search_ordering not in ('legacy', 'and_support'):
        raise DriverDataError('mandatory explicit legacy/and_support ordering')
    if source_epoch.get('search_ordering') != search_ordering:
        raise DriverDataError('caller/Source-epoch ordering mismatch')
    if (type(inventory_certification_mode) is not str or
            inventory_certification_mode not in ('bulk','dependency_closures') or
            source_epoch.get('inventory_certification_mode') != inventory_certification_mode):
        raise DriverDataError('explicit current caller/Source-epoch inventory mode')
    symbolic_strategy = ('NOVEL_BACKWARD_PRIORITY_DFS_V1' if search_ordering == 'legacy'
                         else 'ACYCLIC_RECEPTOR_SUPPORT_POTENTIAL_V1')
    if not callable(oracle_factory) or progress_observer is not None and not callable(progress_observer):
        raise DriverDataError('factory/progress callback')
    if type(closure_deadline) not in (int, float) or not math.isfinite(closure_deadline) or closure_deadline <= work_deadline or not callable(closure_tick):
        raise DriverDataError('later finite closure deadline and metadata-only closure tick required')
    boundary = _Boundary(source_epoch=source_epoch, source_guard=source_guard,
                         tick=tick, now=now, deadline=work_deadline)
    result = dict(schema=RESULT_SCHEMA, version=VERSION, mode=mode, search_ordering=search_ordering,
                  status='NOT_STARTED', stage='input', declaration=_owned(receiver_spec),
                  inventory_certification_mode=inventory_certification_mode,
                  receiver_id=(receiver_spec.get('id') if type(receiver_spec) is dict else None),
                  receiver_input_qualified=False,
                  source_epoch=_owned(source_epoch), outputs={}, records=[],
                  native_proof_accepted=False, family_hint_success=False,
                  quantified_reasoning_success=False,
                  ROOT_resource_accepted=False,
                  limits=dict(attempts=5000, attempt_unit=('proof_row_extension' if mode == 'symbolic' else 'base_point_placement' if mode != 'z3' else None),
                              counter_comparability='Symbolic prefix extensions and GCTS tile placements are distinct units; use success, total cold time and observed resources for cross-method comparison.',
                              search_ordering=search_ordering, symbolic_strategy=symbolic_strategy,
                              search_seconds=30, proposal_limit=24,
                              proposal_checks=2048, seed=64000, compile_queries=512,
                              compile_micro_steps=10**9, native_micro_steps=5*10**9,
                              inventory_registration_aggregate_micro_steps=5*10**9,
                              inventory_certification_mode=inventory_certification_mode,
                              instantiation_rounds=2,
                              input_arity_policy='MAX_PREMISE_LENGTH_OVER_ALL_EXPORTED_ADMITTED_INTERFACES',
                              families_enabled=True,
                              output_bytes=OUTPUT_CAP_BYTES,
                              work_deadline=work_deadline, closure_deadline=closure_deadline),
                  stage_intervals=[], work_window_complete=False,
                  semantic_projection=dict(model=dict(path='outputs.model', exclude=['compile_seconds']),
                                           compiler=dict(path='outputs.compile', exclude=['seconds']),
                                           inventory=dict(path='outputs.register', include=['definitions', 'interfaces', 'native_blocks']),
                                           initial_state=dict(path='initial_state', include='all literal fields'),
                                           scope='All remaining model fields are semantic, including domains, every mark and metadata, arity, mode IDs, conflicts, roots, encoding and scope. Original full records/timings are also retained.'),
                  scope='Predeclared closed quantified structural cases: same twelve-row grammar policy, compiler, full admitted library and complete point model across methods for each selected case. Symbolic search receives only logical packets and compiler, constructs no point graph, and returns keys for charged common-model whole-region/decode and native gates. Its chronological order is a specialized control, not the GCTS scheduler. Different internal operation units, no held-out/general/dedicated-prover or standalone no-point-model cost claim. No new RL, nested family reuse, all-FOL or primitive Wang completion.')
    oracle = None

    def progress(phase):
        if progress_observer is not None:
            progress_observer(dict(schema='semantic-receiver-small-progress-v1', phase=phase,
                                   status=result['status'], mode=mode, search_ordering=search_ordering,
                                   native_records=len(oracle.records) if oracle is not None else 0,
                                   completed_outputs=sorted(result['outputs'])))

    def stage(name, action):
        result['stage'] = name
        started = boundary.check(full=True)
        value = action()
        result['stage_intervals'].append(dict(stage=name, started_monotonic=started,
                                              returned_monotonic=boundary.observe()))
        result['outputs'][name] = value
        progress(name)
        boundary.check(full=True)
        return value

    try:
        try:
            policy, module_pins = _input_custody(modules, policy_bytes, boundary)
            result['policy'] = policy
            result['policy_pin'] = dict(sha256=POLICY_SHA256, bytes=POLICY_BYTES)
            result['module_pins'] = module_pins
            library = _owned(policy['library'])
            spec, original_receiver_input = _receiver_input(receiver_spec, boundary)
            if _json(result['declaration']) != original_receiver_input:
                raise DriverDataError('receiver input changed during initial custody')
            result['receiver_selection'] = _owned(boundary.epoch['receiver_selection'])
            result['receiver_input_qualified'] = True
            result['declaration_closedness'] = _closed_receiver(spec, boundary)
            original_spec = _json(spec)
            original_library = _json(library)
            stage('before_oracle', lambda: dict(work_deadline=work_deadline, remaining_seconds=boundary.remaining()))
            oracle = oracle_factory(work_deadline=work_deadline, tick=tick,
                                    source_guard=source_guard, now=now)
            if not isinstance(oracle.records, list):
                raise DriverDataError('full mutable native record list required')
            compiled = stage('compile', lambda: modules['base_compiler'].compile_guards(
                spec, oracle, limit=10**9, queries=512))
            stage('compile_record_joins', lambda: _compile_record_joins(compiled, oracle.records, spec, boundary))
            if compiled['status'] != 'complete':
                result['status'] = compiled['status']
            else:
                inventory = stage('specialize', lambda: modules['family_miner'].specialize(library, compiled['basis']))
                inventory = stage('register', lambda: modules['family_registry'].check_inventory(spec, inventory, oracle, limit=5*10**9, mode=inventory_certification_mode))
                stage('inventory_record_join', lambda: _inventory_record_join(inventory, oracle.records, spec, boundary, inventory_certification_mode))
                if inventory['status'] != 'native_accepted':
                    result['status'] = inventory['status']
                else:
                    result['stage'] = 'model'
                    model_started = boundary.check(full=True)
                    model = modules['family_model'].Model(spec, compiled, inventory)
                    model_record = model.record()
                    initial = _state_record(model.initial())
                    result['stage_intervals'].append(dict(stage='model', started_monotonic=model_started,
                                                          returned_monotonic=boundary.observe()))
                    result['outputs']['model'] = model_record
                    result['initial_state'] = initial
                    result['model_identity_sha256'] = _model_identity(model_record)
                    result['compiled_semantics_sha256'] = _sha(_compiler_semantics(compiled))
                    result['inventory_semantics_sha256'] = _sha({k: inventory[k] for k in ('definitions', 'interfaces', 'native_blocks')})
                    progress('model')
                    boundary.check(full=True)
                    seconds = min(30, boundary.remaining())
                    if mode == 'symbolic':
                        search = stage('search', lambda: modules['symbolic_control'].search_symbolic(
                            spec=spec, compiled=compiled, inventory=inventory,
                            compiler=modules['base_compiler'], attempts=5000, seconds=seconds,
                            strategy=symbolic_strategy, support_ordering=modules['support_ordering']))
                        stage('symbolic_point_projection', lambda: _symbolic_point_projection(
                            spec, compiled, inventory, model, search, modules['point_smt'], boundary))
                    elif mode == 'z3':
                        search = stage('search', lambda: modules['point_smt'].solve(model, seconds=seconds))
                    else:
                        search = stage('search', lambda: modules['family_search'].search(
                            model, mode, attempts=5000, seconds=seconds,
                            proposal_limit=24, proposal_checks=2048, seed=64000,
                            stochastic=False, weights=None, support_ordering=search_ordering))
                    after_record = model.record()
                    if _model_identity(after_record) != result['model_identity_sha256']:
                        raise DriverDataError('candidate model changed during search')
                    result['model_after_identity_sha256'] = _model_identity(after_record)
                    result['root_restoration'] = dict(status='NOT_APPLICABLE_STATELESS_CONTROL' if mode in ('z3', 'symbolic') else 'OBSERVED',
                                                      root_restored=None if mode in ('z3', 'symbolic') else search['root_restored'],
                                                      engine_root_sha256=search.get('root_state_sha256'))
                    if mode not in ('z3', 'symbolic') and not search['root_restored']:
                        raise DriverDataError('point root state/graph not restored')
                    result['status'] = search['status']
                    if search['proof'] is not None:
                        proof = search['proof']
                        request = dict(protocol='gcts-fol-1', theory=spec['theory'],
                                       blocks=modules['family_miner'].used_definitions(inventory, proof),
                                       proof=proof, target=spec['target'])
                        result['outputs']['final_request'] = _owned(request)
                        native = stage('final_native', lambda: oracle.request(request, 5*10**9, 'fresh_quantified_receiver_final'))
                        native_id = native['id']
                        if type(native_id) is not int or not 0 <= native_id < len(oracle.records) or _json(oracle.records[native_id]) != _json(native) or _json(native['request']) != _json(request) or native['request_sha256'] != _sha(request):
                            raise DriverDataError('fresh final native record/request binding')
                        if native['result']['status'] == 'rejected':
                            raise DriverDataError('selected proof rejected by unchanged whole native checker')
                        if native['result']['status'] != 'accepted':
                            result['status'] = 'unknown_native_verification'
                        else:
                            result['native_proof_accepted'] = True
                            observation = stage('essential_ancestry', lambda: _proof_observation(proof, spec['target'], inventory, library, boundary))
                            result['quantified_reasoning_success'] = observation['quantified_reasoning_success']
                            links = stage('winning_hint_links', lambda: _winning_hint_links(search, model_record, initial, observation, proof, boundary))
                            result['family_hint_success'] = result['quantified_reasoning_success'] and links['strong_family_hint_use']
                            result['status'] = 'native_proof_discovered'
            if (_json(spec) != original_spec or _json(library) != original_library or
                    _json(receiver_spec) != original_receiver_input):
                raise DriverDataError('receiver input, working spec or complete library changed')
            result['scientific_stopped_monotonic'] = boundary.check(full=True)
            result['work_window_complete'] = True
        except _DeadlineStop as stopped:
            if stopped.owner is not boundary:
                raise
            result['status'] = 'unknown_receiver_work_deadline'
            result['family_hint_success'] = False
            result['quantified_reasoning_success'] = False
            result['native_proof_accepted'] = False
            result['work_window_complete'] = False
            result['scientific_stop_observed_monotonic'] = boundary.last
            result['deadline_scope'] = 'Own cooperative stage/observer stop; returned stages retained. Not a negative proof result or guaranteed mid-operation interrupt.'
    except BaseException as primary:
        if oracle is not None:
            try:
                oracle.close()
            except BaseException as cleanup:
                if hasattr(primary, 'add_note'):
                    primary.add_note('oracle cleanup also raised: ' + type(cleanup).__name__)
        raise
    else:
        closure_started = boundary.observe()
        if oracle is not None:
            oracle.close()
            result['transport_receipt'] = _owned(oracle.transport_receipt())
            result['records'] = _owned(oracle.records)
        closure = _Boundary(source_epoch=source_epoch, source_guard=source_guard,
                            tick=closure_tick, now=now, deadline=closure_deadline)
        closure.last = boundary.last
        result['closure_started_monotonic'] = closure_started
        result['oracle_closed_monotonic'] = closure.observe()
        result['stage'] = 'atomic_output'
        progress('closed_and_reaped')
        if result['status'] == 'unknown_receiver_work_deadline':
            descriptor = _atomic_output(output_path, result, closure)
        else:
            try:
                descriptor = _atomic_output(output_path, result, boundary)
            except _DeadlineStop as stopped:
                if stopped.owner is not boundary:
                    raise
                result['status'] = 'unknown_receiver_work_deadline'
                result['native_proof_accepted'] = False
                result['family_hint_success'] = False
                result['quantified_reasoning_success'] = False
                result['work_window_complete'] = False
                result['scientific_stop_observed_monotonic'] = boundary.last
                result['deadline_scope'] = 'Work endpoint reached during closure/serialization. Complete earlier data retained only as UNKNOWN within the total closure endpoint; no proof-success admission.'
                closure.last = boundary.last
                descriptor = _atomic_output(output_path, result, closure)
        return dict(schema=RECEIPT_SCHEMA, version=VERSION, mode=mode, search_ordering=search_ordering,
                    receiver_id=result['receiver_id'],
                    receiver_input_qualified=result['receiver_input_qualified'],
                    status=result['status'], native_proof_accepted=result['native_proof_accepted'],
                    family_hint_success=result['family_hint_success'],
                    quantified_reasoning_success=result['quantified_reasoning_success'],
                    output=descriptor, ROOT_resource_accepted=False,
                    transport_receipt=result.get('transport_receipt'))
