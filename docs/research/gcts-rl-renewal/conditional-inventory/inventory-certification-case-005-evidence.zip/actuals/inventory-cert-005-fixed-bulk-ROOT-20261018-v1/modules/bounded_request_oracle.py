"""Prospective bounded persistent native transport; no logical rules here.

Root injects the unchanged RequestOracle module and exact native/code paths.
Root alone seals runtime custody and starts Python in its owned process group.
Authored/compiled as Source only; no native or scientific evaluation by author.
"""
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import selectors
import select
import signal
import stat
import subprocess

VERSION = 'semantic-family-bounded-request-oracle-transport-v1'
RECEIPT_SCHEMA = 'semantic-family-native-transport-receipt-v1'
LIMITS = {'ready_bytes':256, 'reply_bytes':65536, 'stderr_bytes':65536,
          'stdout_total_bytes':16777216, 'binary_file_bytes':67108864,
          'queries':100000, 'cleanup_reserve_seconds':30,
          'normal_quit_grace_seconds':1, 'terminate_grace_seconds':1,
          'maximum_cleanup_seconds':10, 'poll_seconds':0.05}


class NativeTransportError(ValueError):
    pass


class NativeTransportUnfinished(TimeoutError):
    pass


class NativeTransportCleanupUnfinished(NativeTransportUnfinished):
    def __init__(self, receipt, original_error=None):
        super().__init__('exact native child not observed reaped; no admission')
        self.transport_receipt = receipt
        self.original_error = original_error


def _need(ok, message):
    if not ok:
        raise NativeTransportError(message)


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),
                      ensure_ascii=False,allow_nan=False).encode('utf8')


def make_request_oracle_factory(*, request_oracle_module, deadline, tick, source_guard, now):
    """Return the original-constructor class with fixed absolute work deadline.

    Root's driver-facing factory binds native inputs and invokes this maker:
    factory(*,work_deadline,tick,source_guard,now) -> constructed oracle.
    The coherent prospective policy is work180/overall210/1GiB. Cleanup may use
    only the absolute work deadline plus30 reserve, never a renewed work clock.
    Parent and persistent CPP peaks are separately captured; this module emits
    CPP wait4 data, not the final aggregate resource admission.
    """
    _need(type(deadline) in (int,float) and math.isfinite(deadline), 'finite absolute deadline')
    _need(callable(tick) and callable(source_guard) and callable(now), 'fixed injected callbacks')
    base = request_oracle_module.RequestOracle
    base_initial = base.initial
    writer = request_oracle_module.write_micro_input
    request_digest = request_oracle_module.digest
    closure_deadline = deadline + LIMITS['cleanup_reserve_seconds']

    class BoundedRequestOracle(base):
        def __init__(self, micro, initial, executable, code, directory):
            self.micro=micro;self.template=initial;self.directory=Path(directory);self.records=[]
            self.process=None;self._pid=None;self._pgid=None;self._reaped=False;self._wait_status=None
            self._wait_usage=None;self._closed=False;self._constructor_completed=False;self._busy=False
            self._selector=None;self._streams={};self._stdout=bytearray();self._stderr=bytearray()
            self._stdout_total=0;self._stderr_total=0;self._stdout_eof=False;self._stderr_eof=False
            self._cleanup_errors=[];self._signals=[];self._request_stages=[];self._ready=None
            self._parent_pid=os.getpid();self._parent_pgid=os.getpgrp()
            self._executable=str(executable);self._code=str(code)
            self._work_deadline=deadline;self._closure_deadline=closure_deadline
            try:
                self._check_work()
                _need(self._parent_pid==self._parent_pgid, 'Root Python must lead its exact owned process group')
                _need(self.directory.is_absolute() and self.directory==self.directory.resolve(), 'owned absolute native directory')
                _need(self.directory.is_dir(), 'Root creates the private native directory before transport')
                for name in ('input.bin','output.bin'):
                    path=str(self.directory/name)
                    _need(not any(c.isspace() for c in path) and '\x00' not in path, 'whitespace-free native protocol paths')
                self._selector=selectors.DefaultSelector()
                self.process=subprocess.Popen([self._executable,self._code],stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True,bufsize=0)
                self._pid=self.process.pid;self._pgid=os.getpgid(self._pid)
                _need(self._pgid==self._parent_pgid, 'persistent native inherits the exact owned Python process group')
                for label in ('stdin','stdout','stderr'):
                    stream=getattr(self.process,label);self._streams[label]=stream
                    os.set_blocking(stream.fileno(),False)
                for label in ('stdout','stderr'):
                    self._selector.register(self._streams[label],selectors.EVENT_READ,label)
                ready=self._read_line(LIMITS['ready_bytes'])
                expected=['READY',str(len(micro['rows'])),*[str(micro[n]) for n in ('start','accept','reject','space')]]
                _need(ready.decode('ascii').split()==expected, 'exact fixed native READY header')
                self._ready=ready.decode('ascii');self._check_work();self._constructor_completed=True
            except BaseException as error:
                self._cleanup(error, constructor=True)
                raise

        def _check_work(self):
            tick();source_guard()
            if now()>=self._work_deadline:
                raise NativeTransportUnfinished('original absolute semantic work deadline unfinished')

        def _remaining(self, end, working):
            if working:self._check_work()
            remaining=end-now()
            if remaining<=0:
                raise NativeTransportUnfinished('bounded native transport deadline unfinished')
            return remaining

        def _capture_wait(self):
            if self._pid is None or self._reaped:return self._reaped
            pid,status,usage=os.wait4(self._pid,os.WNOHANG)
            if pid:
                _need(pid==self._pid, 'wait4 names the exact persistent native child')
                self._reaped=True;self._wait_status=status
                self._wait_usage={'ru_maxrss':usage.ru_maxrss,'ru_utime':usage.ru_utime,
                    'ru_stime':usage.ru_stime,'ru_minflt':usage.ru_minflt,'ru_majflt':usage.ru_majflt}
                self.process.returncode=os.waitstatus_to_exitcode(status)
            return self._reaped

        def _read_available(self, label):
            stream=self._streams[label]
            try:raw=os.read(stream.fileno(),65536)
            except BlockingIOError:return
            if not raw:
                if label=='stdout':self._stdout_eof=True
                else:self._stderr_eof=True
                try:self._selector.unregister(stream)
                except KeyError:pass
                return
            if label=='stderr':
                self._stderr_total+=len(raw)
                if self._stderr_total>LIMITS['stderr_bytes']:
                    raise NativeTransportUnfinished('whole native stderr exceeds finite cap; no truncation accepted')
                self._stderr.extend(raw)
            else:
                self._stdout_total+=len(raw)
                if self._stdout_total>LIMITS['stdout_total_bytes']:
                    raise NativeTransportUnfinished('whole native stdout exceeds finite cap; no truncation accepted')
                self._stdout.extend(raw)
                if len(self._stdout)>LIMITS['reply_bytes']:
                    raise NativeTransportUnfinished('whole native reply exceeds finite cap; no truncation accepted')

        def _step(self, end, working=True):
            if working:
                remaining=self._remaining(end,working)
            else:
                remaining=end-now()
                if remaining<=0:return False
            events=self._selector.select(min(LIMITS['poll_seconds'],remaining))
            writable=False
            for key,mask in events:
                if key.data=='stdin':writable=True
                else:self._read_available(key.data)
            self._capture_wait()
            if working:self._check_work()
            return writable

        def _send(self, raw, end, working=True):
            _need(type(raw) is bytes, 'finite owned native request bytes')
            self._remaining(end,working)
            stream=self._streams['stdin'];offset=0
            self._selector.register(stream,selectors.EVENT_WRITE,'stdin')
            try:
                while offset<len(raw):
                    self._remaining(end,working)
                    try:n=os.write(stream.fileno(),raw[offset:])
                    except BlockingIOError:n=0
                    _need(n>=0, 'nonnegative native pipe write')
                    if n:offset+=n
                    else:self._step(end,working)
            finally:
                try:self._selector.unregister(stream)
                except KeyError:pass
            if working:self._check_work()

        def _read_line(self, cap):
            while True:
                self._check_work()
                if b'\n' in self._stdout:
                    index=self._stdout.index(10)
                    _need(index+1<=cap, 'whole bounded native line')
                    line=bytes(self._stdout[:index]);del self._stdout[:index+1]
                    _need(not self._stdout, 'no unsolicited extra native reply bytes')
                    return line
                if len(self._stdout)>=cap:
                    raise NativeTransportUnfinished('whole native line exceeds cap; no partial JSON accepted')
                _need(not self._stdout_eof, 'native stdout ended before complete reply')
                self._step(self._work_deadline)

        def initial(self, request):
            self._check_work()
            answer=base_initial(self,request)
            self._check_work()
            return answer

        def _file_hash(self,path):
            fd=os.open(str(path),os.O_RDONLY|os.O_NOFOLLOW)
            try:
                info=os.fstat(fd)
                _need(stat.S_ISREG(info.st_mode) and info.st_size<=LIMITS['binary_file_bytes'], 'whole finite native binary file')
                digest=hashlib.sha256();total=0
                while True:
                    self._check_work();raw=os.read(fd,65536)
                    if not raw:break
                    total+=len(raw)
                    _need(total<=LIMITS['binary_file_bytes'], 'no native binary growth beyond finite cap')
                    digest.update(raw)
                _need(total==info.st_size, 'whole native file EOF/size unchanged')
                return digest.hexdigest()
            finally:os.close(fd)

        def request(self, request, limit=5*10**9, purpose='semantic_inventory'):
            self._check_work()
            _need(not self._closed and not self._busy and len(self.records)<LIMITS['queries'], 'open serial finite native request stream')
            _need(type(limit) is int and 0<limit<=5*10**9 and type(purpose) is str, 'original bounded native request limit and purpose')
            self._busy=True;stage={'ordinal':len(self._request_stages),'stage':'STARTED','purpose':purpose,'limit':limit}
            self._request_stages.append(stage)
            try:
                began=now();request=copy.deepcopy(request);initial=self.initial(request)
                stage['request_sha256']=request_digest(request)
                inp=self.directory/'input.bin';out=self.directory/'output.bin'
                writer(initial,inp);self._check_work();stage['input_sha256']=self._file_hash(inp)
                # No stale output can stand in for a later native query.
                if out.exists():out.unlink()
                wire=(str(inp)+' '+str(out)+' '+str(limit)+'\n').encode('utf8')
                self._send(wire,self._work_deadline);stage['stage']='SENT'
                reply=self._read_line(LIMITS['reply_bytes']);stage['stage']='REPLY_RETURNED'
                result=json.loads(reply);self._check_work()
                _need(type(result) is dict, 'native response is the original whole JSON object')
                output_sha=self._file_hash(out);stage['output_sha256']=output_sha
                record=dict(id=len(self.records),request=request,query_target='fixed_assertion',
                    request_sha256=request_digest(request),input_sha256=stage['input_sha256'],
                    output_sha256=output_sha,result=result,seconds=now()-began,purpose=purpose)
                self._check_work();self.records.append(record);stage['stage']='COMPLETED';stage['record_id']=record['id']
                return record
            finally:self._busy=False

        def query(self, spec, proof, final, limit):
            if not final:raise NativeTransportError('semantic inventory uses only declared fixed query targets')
            return self.request(dict(protocol='gcts-fol-1',theory=spec['theory'],
                blocks=spec.get('blocks',[]),proof=proof,target=spec['target']),limit)

        def _signal(self, signum):
            if self._pid is None or self._reaped:return
            try:os.kill(self._pid,signum)
            except ProcessLookupError:pass
            self._signals.append(signum)

        def _wait_until(self, end):
            while not self._capture_wait():
                remaining=end-now()
                if remaining<=0:return False
                # No stream error can prevent exact wait4 cleanup after KILL.
                select.select([],[],[],min(LIMITS['poll_seconds'],remaining))
            return True

        def _attach(self, error, receipt):
            try:setattr(error,'native_transport_receipt',receipt)
            except (AttributeError,TypeError):pass

        def _cleanup(self, original_error=None, constructor=False):
            if self._closed:
                if original_error is not None:self._attach(original_error,self.transport_receipt())
                return
            primary=original_error
            try:
                if primary is None:
                    try:source_guard()
                    except BaseException as error:primary=error
                if self._pid is not None and not self._reaped:
                    end=min(now()+LIMITS['maximum_cleanup_seconds'],self._closure_deadline)
                    if primary is None and self._selector is not None and 'stdin' in self._streams:
                        try:
                            grace=min(now()+LIMITS['normal_quit_grace_seconds'],end)
                            self._send(b'quit\n',grace,working=False);self._wait_until(grace)
                        except BaseException as error:
                            primary=error;self._cleanup_errors.append(type(error).__name__+': '+str(error))
                    if not self._reaped:
                        self._signal(signal.SIGTERM)
                        try:self._wait_until(min(now()+LIMITS['terminate_grace_seconds'],end))
                        except BaseException as error:
                            if primary is None:primary=error
                            self._cleanup_errors.append(type(error).__name__+': '+str(error))
                    if not self._reaped:
                        self._signal(signal.SIGKILL)
                        try:self._wait_until(end)
                        except BaseException as error:
                            if primary is None:primary=error
                            self._cleanup_errors.append(type(error).__name__+': '+str(error))
            except BaseException as error:
                if primary is None:primary=error
                self._cleanup_errors.append(type(error).__name__+': '+str(error))
                self._signal(signal.SIGKILL)
                try:self._capture_wait()
                except BaseException as second:self._cleanup_errors.append(type(second).__name__+': '+str(second))
            finally:
                if self._reaped and self._selector is not None:
                    for label in ('stdout','stderr'):
                        if label not in self._streams:continue
                        try:
                            while not (self._stdout_eof if label=='stdout' else self._stderr_eof):
                                old=self._stdout_total if label=='stdout' else self._stderr_total
                                self._read_available(label)
                                new=self._stdout_total if label=='stdout' else self._stderr_total
                                if old==new and not (self._stdout_eof if label=='stdout' else self._stderr_eof):break
                        except BaseException as error:
                            if primary is None:primary=error
                            self._cleanup_errors.append(type(error).__name__+': '+str(error))
                if self._selector is not None:
                    try:self._selector.close()
                    except BaseException as error:
                        if primary is None:primary=error
                # Constructor may fail between Popen and stream registration.
                if self.process is not None:
                    for label in ('stdin','stdout','stderr'):
                        stream=getattr(self.process,label,None)
                        if stream is not None:
                            try:stream.close()
                            except BaseException as error:
                                if primary is None:primary=error
                self._closed=True
            receipt=self.transport_receipt()
            if self._pid is not None and not self._reaped:
                raise NativeTransportCleanupUnfinished(receipt,primary) from primary
            if primary is None:
                try:source_guard()
                except BaseException as error:primary=error
            if primary is None and self._stdout:
                primary=NativeTransportError('unsolicited native stdout remains after final reply')
            if primary is None and self._pid is not None and self.process.returncode!=0:
                primary=NativeTransportError('native child exited nonzero after exact wait4')
            if primary is not None:
                self._attach(primary,receipt)
                if original_error is None:raise primary

        def close(self):
            self._cleanup()

        def transport_receipt(self):
            receipt={'schema':RECEIPT_SCHEMA,'version':VERSION,'parent_pid':self._parent_pid,
                'parent_pgid':self._parent_pgid,'native_pid':self._pid,'native_pgid':self._pgid,
                'same_owned_process_group':self._pgid==self._parent_pgid if self._pgid is not None else None,
                'constructor_completed':self._constructor_completed,'closed':self._closed,'all_reaped':self._reaped,
                'native_exit_code':self.process.returncode if self.process is not None else None,
                'wait4_status':self._wait_status,'wait4_usage':self._wait_usage,
                'native_high_water_bytes':self._wait_usage['ru_maxrss'] if self._wait_usage is not None else None,
                'ru_maxrss_unit':'bytes on declared Darwin runtime; Root must gate platform',
                'work_deadline':self._work_deadline,'closure_deadline':self._closure_deadline,
                'limits':dict(LIMITS),'ready':self._ready,'stdout_bytes':self._stdout_total,
                'stderr_bytes':self._stderr_total,'stderr_utf8':bytes(self._stderr).decode('utf8',errors='replace'),
                'stderr_hex':bytes(self._stderr).hex(),'stderr_complete':self._stderr_eof and len(self._stderr)==self._stderr_total,
                'stdout_eof':self._stdout_eof,'stdout_pending_bytes':len(self._stdout),
                'termination_signals':list(self._signals),'cleanup_errors':list(self._cleanup_errors),
                'request_stages':copy.deepcopy(self._request_stages),'complete_records':len(self.records),
                'CPP_self_reported_peak_is_resource_authority':False,'aggregate_resource_accepted':False,
                'logical_proof_accepted':False,'scientific_acceptance':False}
            return json.loads(_canonical(receipt))

    return BoundedRequestOracle
