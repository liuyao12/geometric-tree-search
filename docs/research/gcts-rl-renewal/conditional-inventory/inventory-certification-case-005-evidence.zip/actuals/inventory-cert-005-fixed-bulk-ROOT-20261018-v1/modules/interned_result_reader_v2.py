"""Lossless in-memory sharing for complete canonical result JSON.

This module does not execute proof rules, regenerate markings, skip candidates,
or replace raw-file custody. It returns only ordinary dict/list/tuple/scalars.
The caller retains the full original bytes and checks their declared hash/EOF.
"""
import json

VERSION = 'literal-result-json-immutable-interning-v2'
MAX_BYTES = 134217728

class ResultReadError(ValueError):
    pass

def _integer(value):
    return type(value) is int

class _Interner:
    def __init__(self, checkpoint):
        self.checkpoint = checkpoint
        self.points = {}
        self.pairs = {}
        self.vectors = {}
        self.keys = {}
        self.objects = 0
        self.pair_occurrences = 0
        self.vector_occurrences = 0
        self.key_occurrences = 0
        self.checkpoints = 0

    def observe(self):
        self.checkpoint()
        self.checkpoints += 1

    def point(self, value):
        key = tuple(value)
        return self.points.setdefault(key, key)

    def key(self, value):
        key = tuple(value)
        self.key_occurrences += 1
        return self.keys.setdefault(key, key)

    def pair_vector(self, value):
        # Unrecognized values are retained literally; malformed proof data is
        # still the caller/checker's concern. Never conflate bool and integer.
        if type(value) is not list or not all(
            type(e) is list and len(e) == 2 and
            type(e[0]) is list and len(e[0]) == 2 and
            all(_integer(c) for c in e[0]) and _integer(e[1])
            for e in value
        ):
            return value
        entries = []
        for p, v in value:
            pair = (self.point(p), v)
            entries.append(self.pairs.setdefault(pair, pair))
        vector = tuple(entries)
        self.pair_occurrences += len(vector)
        self.vector_occurrences += 1
        return self.vectors.setdefault(vector, vector)

    def object(self, pairs):
        self.objects += 1
        if self.objects % 256 == 0:
            self.observe()
        value = {}
        for name, item in pairs:
            if name in value:
                raise ResultReadError('duplicate JSON object field')
            value[name] = item
        # These full fields remain present and ordered. Sharing changes only
        # Python container identity, never coordinates, values, or assignments.
        for name in ('marks', 'new_marks'):
            if name in value:
                value[name] = self.pair_vector(value[name])
        if ('key' in value and type(value['key']) is list and
            len(value['key']) == 4 and all(_integer(c) for c in value['key'])):
            value['key'] = self.key(value['key'])
        if ('keys' in value and type(value['keys']) is list and
            all(type(k) is list and len(k) == 4 and
                all(_integer(c) for c in k) for k in value['keys'])):
            value['keys'] = [self.key(k) for k in value['keys']]
        return value

    def record(self):
        return dict(version=VERSION, objects=self.objects,
                    pair_occurrences=self.pair_occurrences,
                    unique_points=len(self.points), unique_pairs=len(self.pairs),
                    vector_occurrences=self.vector_occurrences,
                    unique_vectors=len(self.vectors),
                    key_occurrences=self.key_occurrences,
                    unique_keys=len(self.keys), checkpoints=self.checkpoints,
                    scope='Container sharing counts, not measured allocation or RAM savings.')

def _constant(value):
    raise ResultReadError('nonfinite JSON constant')

def decode_result(raw, *, checkpoint):
    """Decode every field. Canonical JSON encoding is the literal inverse.

    Domain: bounded strict UTF-8 JSON with distinct object fields and finite
    numbers, as produced by the frozen result writer. Lists in recognized exact
    marking-pair fields and candidate-key fields may become immutable tuples.
    Missing fields stay missing; explicit integer zero stays assigned zero.
    There is no claim of preemption while the stdlib scans one large JSON value.
    """
    if type(raw) is not bytes or len(raw) > MAX_BYTES:
        raise ResultReadError('bounded raw bytes required')
    if not callable(checkpoint):
        raise ResultReadError('caller checkpoint required')
    pool = _Interner(checkpoint)
    pool.observe()
    text = raw.decode('utf8')
    data = json.loads(text, object_pairs_hook=pool.object,
                      parse_constant=_constant)
    pool.observe()
    stats = pool.record()
    # Neither the dictionaries nor this interner escape through the result.
    return data, stats
