"""Versioned quantified factored grammar with checked formula-family commands.

The root has closed theory axioms and no open assumptions. Each block retains
its actual ordered premises and needs whole native admission before use.
"""
import collections,copy,math,time
from certificate_boundary_search import canonical
from quantified_receptors_v1 import domains,CATALOG_SCHEMA,VERSION as COMPILER_VERSION,TERM_POLICY,ROOT_CONTEXT
from native_receptor_points import assignment
from semantic_receptor_points import Model as Factored,center,mode_point,input_point

VERSION = 'quantified-initial-binder-family-points-v2-derived-arity'

class Model(Factored):
    def __init__(self,spec,compiled,inventory,arity=None,families=True):
        if (compiled.get('catalog',{}).get('schema')!=CATALOG_SCHEMA or
                compiled['catalog'].get('producer_version')!=COMPILER_VERSION or
                compiled['catalog'].get('term_policy')!=TERM_POLICY or
                compiled['catalog'].get('root_context')!=ROOT_CONTEXT):
            raise ValueError('wrong quantified compiler catalog or root scope')
        if compiled['status']!='complete' or inventory['status']!='native_accepted':raise ValueError('unfinished admission is not authority')
        defs={d['name']:d for d in inventory['definitions']}
        admitted_interfaces=[defs[n] for n in inventory['interfaces']]
        required_arity=max([len(d['definition']['premises']) for d in admitted_interfaces]+[0])
        arity_policy='DERIVED_ALL_ADMITTED_INTERFACES' if arity is None else 'EXPLICIT_COVERS_ALL_ADMITTED_INTERFACES'
        if arity is None:
            arity=required_arity
        elif type(arity) is not int or arity<required_arity:
            raise ValueError('explicit arity must cover every admitted interface')
        self.required_interface_arity=required_arity;self.arity_policy=arity_policy
        self.spec=spec;self.compiled=compiled;self.inventory=inventory;self.arity=arity;self.families_enabled=families
        self.metrics=collections.Counter();self.dependencies=collections.defaultdict(set);self.cache={};self.align_cache={};self.metadata={};self.conflicts=[]
        self.interfaces=admitted_interfaces if families else []
        self.mode={d['name']:i+1 for i,d in enumerate(self.interfaces)};self.mode_names={v:k for k,v in self.mode.items()}
        self.domains=[];began=time.perf_counter();tauts={canonical(f) for f in compiled['tautologies']};schemes={canonical(c) for c in compiled['admitted_schemes']}
        for j in range(spec['length']):
            for role in range(2+arity):self.align_cache[center(j,role)]=[]
            rows=domains(spec,compiled['catalog'],j)
            formulas=[spec['target']] if j+1==spec['length'] else compiled['basis']
            rows += [dict(rule='block',formula=f,name=d['name']) for f in formulas for d in self.interfaces]
            rows.sort(key=lambda c:(c['rule'],canonical(c['formula']),canonical(c)));self.domains.append(rows)
            for k,c in enumerate(rows):
                f=c['formula'];r=c['rule'];mode=self.mode[c['name']] if r=='block' else 0
                entries=assignment(j,'command',c)+assignment(j,'formula',f)+[(mode_point(j),mode)]
                self.add((j,0,k,0),entries,c,[],'command');req=[]
                if r=='mp':
                    for v,imp in enumerate(compiled['basis']):
                        if imp[0]=='imp' and imp[2]==f:
                            wanted=[(c['antecedent'],imp[1]),(c['implication'],imp)]
                            self.add((j,1,k,v),entries+[e for i,a in wanted for e in assignment(i,'formula',a)],c,wanted,'guard')
                    continue
                if r=='axiom':valid=spec['theory']['axioms'][c['name']]==f
                elif r=='refl':valid=f[0]=='eq' and f[1]==f[2]
                elif r=='tautology':valid=canonical(f) in tauts
                elif r=='generalize':
                    valid=f[0]=='all' and f[1]==c['variable']
                    if valid:req=[(c['source'],f[2])]
                elif r=='block':valid=defs[c['name']]['definition']['conclusion']==f
                else:valid=canonical(c) in schemes
                if valid:self.add((j,1,k,0),entries+[e for i,a in req for e in assignment(i,'formula',a)],c,req,'guard')
            for r in range(arity):
                self.add((j,2+r,0,0),[(mode_point(j),0),(input_point(j,r),-1)],None,[],'unused_input',input=r,mode=0,source=None)
                for d in self.interfaces:
                    mode=self.mode[d['name']];premises=d['definition']['premises']
                    if r>=len(premises):self.add((j,2+r,mode,0),[(mode_point(j),mode),(input_point(j,r),-1)],None,[],'unused_input',input=r,mode=mode,source=None)
                    else:
                        for source in range(j):
                            req=[(source,premises[r])]
                            self.add((j,2+r,mode,source+1),[(mode_point(j),mode),(input_point(j,r),source)]+assignment(source,'formula',premises[r]),None,req,'lemma_input',input=r,mode=mode,source=source)
        self.compile_seconds=time.perf_counter()-began
        for p in self.align_cache:self.align_cache[p]=tuple(self.align_cache[p])
    def record(self):
        r=super().record();r.update(implementation_version=VERSION,compiler_version=COMPILER_VERSION,
            arity_policy=self.arity_policy,required_interface_arity=self.required_interface_arity,
            syntax_catalog_schema=CATALOG_SCHEMA,term_policy=TERM_POLICY,root_context=ROOT_CONTEXT,
            complete_words=math.prod(map(len,self.domains)),initial_marks=sorted(self.initial().marks.items()),families_enabled=self.families_enabled,
            scope='Default input-role arity is the maximum premise count of all admitted interfaces; explicit arity must cover all, including disabled-family controls. Versioned quantified adapter with exactly two UI rounds over target-free subterms plus every initial binder variable; later alpha names do not grow the term pool. Closed theory axioms and no open root assumptions. Every actual block requires native checking. First-order plus checked-family adapter. C/G and all declared input roots exist in every lane, including unused fillers in the primitive grammar. Enabling families changes the candidate inventory; ordering controls preserve that inventory. Full word markings, strict earlier input receptors, translation-only fixed roles and exact unit occupancy.')
        return r
