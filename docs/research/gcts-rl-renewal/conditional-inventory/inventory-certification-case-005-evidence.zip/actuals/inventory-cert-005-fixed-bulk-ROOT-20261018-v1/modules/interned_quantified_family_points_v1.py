"""Exact immutable literal interning at the factored Model.add storage boundary.

No point IDs, hashes, prefix matching, shortened words or reduced inventory.
Inherited record() is the ordinary full logical model record. Storage provenance
is separate in storage_record(); no memory improvement is asserted by Source.
"""
from quantified_family_points_v2 import Model as OrdinaryModel, VERSION as LOGICAL_MODEL_VERSION
from semantic_receptor_points import center
from native_receptor_points import merge
from turtle import CAPACITY, Placement

VERSION = 'quantified-family-points-exact-literal-interning-v1'
STORAGE_SCHEMA = 'quantified-point-literal-storage-observation-v1'


class Model(OrdinaryModel):
    def __init__(self, spec, compiled, inventory, arity=None, families=True):
        # These indexes contain immutable literal objects already retained by
        # placements, not duplicate literal buffers or state/legality receipts.
        self._literal_points = {}
        self._literal_pairs = {}
        self._literal_sequences = {}
        super().__init__(spec, compiled, inventory, arity=arity, families=families)

    def _point(self, point):
        if type(point) is not tuple or any(type(v) is not int for v in point):
            raise TypeError('interned point storage requires literal integer tuples')
        prior = self._literal_points.get(point)
        if prior is None:
            self._literal_points[point] = point
            return point
        return prior

    def _pair(self, pair):
        point, value = pair
        if type(value) is not int:
            raise TypeError('interned point storage requires exact integer values')
        literal = (self._point(point), value)
        prior = self._literal_pairs.get(literal)
        if prior is None:
            self._literal_pairs[literal] = literal
            return literal
        return prior

    def _sequence(self, entries):
        literal = tuple(self._pair(pair) for pair in entries)
        prior = self._literal_sequences.get(literal)
        if prior is None:
            self._literal_sequences[literal] = literal
            return literal
        return prior

    def add(self,key,entries,command,requirements,kind,**extra):
        marks=merge(entries)
        if marks is None:self.conflicts.append(dict(key=key,reason='internally unequal markings'));return
        if key in self.cache:raise ValueError('duplicate placement')
        p=center(key[0],key[1]);tile=Placement(key,self._sequence(((p,CAPACITY),)),self._sequence(marks),())
        self.cache[key]=tile;self.metadata[key]=dict(slot=key[0],kind=kind,command=command,requirements=requirements,**extra)
        self.align_cache[p].append(key)
        for q,_ in tile.occupancy+tile.marks:self.dependencies[q].add(key)

    def ordinary_placement(self, key):
        """Full inverse ordinary value; no ID table or native decoder required.

        Construct fresh outer point/pair/sequence tuples. Integers and keys are
        immutable values. This method does not touch cache/incidence/state.
        """
        placement = self.placement(key)
        occupancy = tuple((tuple(v for v in p), value) for p, value in placement.occupancy)
        marks = tuple((tuple(v for v in p), value) for p, value in placement.marks)
        vertices = tuple(tuple(v for v in p) for p in placement.vertices)
        return Placement(tuple(v for v in placement.key), occupancy, marks, vertices)

    def storage_record(self):
        """Fresh observation only: no live-size or memory-savings claim."""
        return dict(schema=STORAGE_SCHEMA, implementation_version=VERSION,
                    logical_model_version=LOGICAL_MODEL_VERSION,
                    coordinate_literals=len(self._literal_points),
                    point_value_literals=len(self._literal_pairs),
                    assignment_sequences=len(self._literal_sequences),
                    placements=len(self.cache),
                    ordinary_record_unchanged=True,
                    scope='Full integer point/pair/sequence equality. Dictionary hashes index full literal keys; collisions still require exact tuple equality. Pools are construction storage, never pruning, degree or rollback authority. Memory and complete output costs require separate measured evidence.')
