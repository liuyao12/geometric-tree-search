Saved records and Source only. No Python entrypoints executed by this package builder.
External pinned runtime binaries are referenced in plans but not redistributed.
Authored fixtures are checker tests, not proof discoveries.
