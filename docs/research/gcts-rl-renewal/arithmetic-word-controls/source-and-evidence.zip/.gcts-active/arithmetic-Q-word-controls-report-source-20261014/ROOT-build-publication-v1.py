"""Package saved control records for the existing public reader. No science calls."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
PUB = Path('/private/tmp/gcts-family-router-publish-20261010')
SOURCE = Path(__file__).resolve().parent
PROGRESS = ROOT / '.gcts-active/arithmetic-Q-independent-word-controls-progress-20261014'
ROUTE = Path('docs/research/gcts-rl-renewal/arithmetic-word-controls')
OUT = PUB / ROUTE


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    return pin(path)


def collect(value, records):
    if type(value) is dict:
        if set(value) == {'path', 'sha256', 'bytes'}:
            p = Path(value['path'])
            p = p if p.is_absolute() else ROOT / p
            actual = pin(p)
            assert actual['bytes'] == value['bytes'] and actual['sha256'] == value['sha256']
            records[actual['path']] = actual
        else:
            for child in value.values():
                collect(child, records)
    elif type(value) is list:
        for child in value:
            collect(child, records)


def main(disposition_path):
    disposition_path = Path(disposition_path).resolve()
    d = read(disposition_path)
    assert d['author_identity'] == '/root' and d['actual_invocations'] == 1
    assert d['ROOT_controls_qualified'] is True and d['resource14_accepted'] is True
    assert not OUT.exists() and not (ROOT / ROUTE).exists()
    worker_plan = read(PROGRESS / 'worker-plan-v1.json')
    owner_plan = read(PROGRESS / 'replay-plan-v1.json')
    fixtures = read(worker_plan['inputs']['complete_fixtures']['path'])
    result = read(d['controls']['path'])
    assert len(fixtures['fixtures']) == len(result['results']) == 68
    assert [f['id'] for f in fixtures['fixtures']] == [a['id'] for a in result['results']]
    OUT.mkdir()
    for src, dest in (('reader-v2.html', 'reader.html'), ('readers-v2.js', 'readers.js'), ('styles-v2.css', 'styles.css')):
        shutil.copyfile(SOURCE / src, OUT / dest)
    evidence = []
    records = {}
    direct = [('ROOT qualified control disposition', disposition_path, 'ROOT-disposition.json'),
        ('All 68 literal authored fixtures', Path(worker_plan['inputs']['complete_fixtures']['path']), 'complete-fixtures.json'),
        ('All actual outcomes and complete word certificates', Path(d['controls']['path']), 'complete-results.json'),
        ('Independent saved reconciliation', Path(d['saved_record_review']['path']), 'independent-saved-review.json'),
        ('Full resource decision and 14 predicates', Path(d['resource_qualification']['path']), 'resource-decision.json'),
        ('Genuine caller observation', Path(d['actual_caller']['path']), 'actual-caller.json'),
        ('Owned terminal record', Path(d['owner_terminal']['path']), 'owned-terminal.json'),
        ('Owned postwrite costs', Path(d['owner_postwrite']['path']), 'owned-postwrite.json'),
        ('Independent worker evidence', Path(d['worker_evidence']['path']), 'worker-evidence.json'),
        ('Complete worker receipt', Path(d['worker_receipt']['path']), 'worker-receipt.json'),
        ('Worker postwrite checkpoint', Path(d['worker_postwrite']['path']), 'worker-postwrite.json'),
        ('Actual leaf plan and whole raw closure', PROGRESS / 'worker-plan-v1.json', 'worker-plan.json'),
        ('Actual owner plan and whole raw closure', PROGRESS / 'replay-plan-v1.json', 'owner-plan.json')]
    for label, path, name in direct:
        record = pin(path)
        shutil.copyfile(path, OUT / name)
        evidence.append(dict(label=label, href=name, sha256=record['sha256'], bytes=record['bytes']))
        records[record['path']] = record
        collect(read(path), records)
    collect([worker_plan, owner_plan, d], records)
    cost = d['cost']
    packet = dict(schema='ROOT-unrelated-word-controls-display-packet-v1', status='complete',
        records=[dict(fixture=f, actual=a) for f, a in zip(fixtures['fixtures'], result['results'])],
        costs=[
            dict(label='Inner result checkpoint', clock_scope='Before the final guard; not a complete phase measurement',
                seconds=cost['inner_elapsed_before_final_guard_seconds'], peak_bytes=None,
                includes='Cold preflight, source/fixture loading, all controls and result serialization through the saved checkpoint.', href='worker-evidence.json'),
            dict(label='Worker receipt checkpoint', clock_scope='After receipt write; later postwrite record, stdout and final checks remain',
                seconds=cost['worker_after_receipt_write_seconds'], peak_bytes=None,
                includes='Complete result and evidence plus the saved receipt write.', href='worker-postwrite.json'),
            dict(label='Complete owned lifecycle', clock_scope='One owner clock; postwrite terminal observation',
                seconds=cost['owned_postwrite_seconds'], peak_bytes=cost['owned_peak_bytes'],
                includes='Cold worker, full controls, all writes, final checks, owned observer, cleanup and reaping.', href='owned-postwrite.json'),
            dict(label='Genuine caller observation', clock_scope='One Date.now isolate from tool request to observed terminal',
                seconds=cost['caller_seconds'], peak_bytes=None, finish_reserve_seconds=1,
                includes='Includes actual tool lifecycle; separate finishing reserve is added for the caller gate.', href='actual-caller.json')],
        prior_failures=[dict(label='Unactivated worker v1 review', status='Source-negative; no scientific run',
            scope='Immediate nested caller guard gap, preserved and repaired by operative v2.', href='source-negative.json'),
            dict(label='Contract v2 metadata', status='Historical illustrative argv typo; no actual activation',
                scope='Contract v3 changes only the worker argv path; executable Source and limits remain unchanged.', href='historical-contract.json')],
        evidence=evidence,
        authority=dict(resource_accepted=True, reconciled_controls_accepted=True,
            Q_target_proof_discovered=False, native_accepted=False, full24_accepted=False,
            full_trajectory_accepted=False, full_PA_accepted=False, induction_accepted=False,
            GCTS_RL_advantage_established=False),
        call_metrics=dict(cases_completed=68, API_started=76, API_returned=22, API_exceptions=54),
        authorship=[dict(label='Suite and cold worker construction', identity='/root/hilbert_advice_controls'),
            dict(label='Independent mathematical semantics; saved-only word-control reconciliation', identity='/root/hilbert_ordering_diagnosis'),
            dict(label='Independent Source review; baseline integration implementation proposal', identity='/root/arithmetic_induction'),
            dict(label='Actual activation, resource closure, scoped admission and publication', identity='/root')],
        ROOT_disposition=pin(disposition_path), complete_resource_predicates=read(d['resource_qualification']['path'])['predicates'],
        scope='These are authored checker mechanics controls, not searched theorem proofs or a calculus soundness theorem. Earlier finite catalogue admission is separately recorded in Notebook161.')
    for src, dest in [('.gcts-active/arithmetic-Q-independent-word-controls-worker-review-source-20261014/typed-Source-review-v1.json', 'source-negative.json'),
                      ('.gcts-active/arithmetic-Q-independent-word-controls-worker-source-20261014/source-contract-v2.json', 'historical-contract.json')]:
        shutil.copyfile(ROOT / src, OUT / dest)
        records[str((ROOT / src).resolve())] = pin(ROOT / src)
    packet_pin = write(OUT / 'display-packet-v1.json', packet)
    design = ROOT / '.gcts-active/arithmetic-Q-first-proof-integration-design-source-20261014'
    for name in ('handoff-v1.json', 'integration-design-v1.json', 'proof-point-agreement-v1.json'):
        records[str(design / name)] = pin(design / name)
    for name in ('reader.html', 'readers.js', 'styles.css', 'reader-v2.html', 'readers-v2.js', 'styles-v2.css', 'ROOT-build-publication-v1.py'):
        records[str(SOURCE / name)] = pin(SOURCE / name)
    external = [record for p, record in records.items() if ROOT not in Path(p).parents]
    workspace = [record for p, record in sorted(records.items()) if ROOT in Path(p).parents]
    archive_path = OUT / 'source-and-evidence.zip'
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for record in workspace:
            archive.write(record['path'], str(Path(record['path']).relative_to(ROOT)))
        archive.writestr('README.txt', 'Saved records and Source only. No Python entrypoints executed by this package builder.\nExternal pinned runtime binaries are referenced in plans but not redistributed.\nAuthored fixtures are checker tests, not proof discoveries.\n')
    evidence.append(dict(label='Complete Source and saved evidence ZIP', href=archive_path.name,
        sha256=pin(archive_path)['sha256'], bytes=pin(archive_path)['bytes']))
    # Append the archive link after construction; its bytes are not a recursive input.
    (OUT / 'display-packet-v1.json').unlink()
    packet_pin = write(OUT / 'display-packet-v1.json', packet)
    write(OUT / 'provenance.json', dict(schema='ROOT-word-controls-publication-provenance-v1',
        packet=packet_pin, workspace_records=workspace, external_runtime_references=external,
        archive=pin(archive_path), source_calls=0, scientific_calls=0, mathematical_admission_issued=False))
    shutil.copytree(OUT, ROOT / ROUTE)
    print(json.dumps(dict(route=str(OUT), packet=packet_pin, archive=pin(archive_path),
        workspace_source_entries=len(workspace), external_runtime_references=len(external))), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 2
    main(sys.argv[1])
