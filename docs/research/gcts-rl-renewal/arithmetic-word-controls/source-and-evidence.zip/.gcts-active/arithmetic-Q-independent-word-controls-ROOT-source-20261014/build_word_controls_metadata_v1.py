"""Root metadata construction only. No project imports or scientific calls."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / '.gcts-active/arithmetic-Q-independent-word-controls-progress-20261014'
AUTHOR = '/root/hilbert_advice_controls'
SCOPE = 'unrelated-six-rule-words-and-nonlogical-Boundary-controls-no-Q-search'
LIMITS = dict(whole_seconds=60, peak_bytes=536870912, caller_seconds=90, control_seconds=20)
AUDITOR_PEER = ROOT / '.gcts-active/arithmetic-Q-independent-mathematical-audit-review-source-20261014/independent-Q-typed-Source-review-v1.json'


def pin(path, relative=False):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    assert path == path.resolve() and path.is_file() and not path.is_symlink()
    before = path.stat()
    h, length = hashlib.sha256(), 0
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(65536), b''):
            h.update(block)
            length += len(block)
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    name = str(path.relative_to(ROOT)) if relative and ROOT in path.parents else str(path)
    return dict(path=name, sha256=h.hexdigest(), bytes=length)


def read(path):
    path = Path(path)
    record = pin(path)
    raw = path.read_bytes()
    assert len(raw) <= 2 * 1048576 and len(raw) == record['bytes']
    assert hashlib.sha256(raw).hexdigest() == record['sha256']
    def unique(pairs):
        result = {}
        for name, value in pairs:
            assert name not in result
            result[name] = value
        return result
    result = json.loads(raw, object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    assert pin(path) == record
    return result


def write(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.write('\n')
    return pin(path)


def collect(closure, value):
    # Visit literal pin objects in decoded named roots; never decode their files.
    if type(value) is dict:
        if set(value) == {'path', 'sha256', 'bytes'}:
            actual = pin(value['path'])
            assert actual['sha256'] == value['sha256'] and actual['bytes'] == value['bytes']
            assert actual['path'] not in closure or closure[actual['path']] == actual
            closure[actual['path']] = actual
        else:
            for child in value.values():
                collect(closure, child)
    elif type(value) is list:
        for child in value:
            collect(closure, child)


def review_gate(value, *, schema, scope, author, sources, contract):
    assert value['schema'] == schema and value['scope'] == scope
    assert value['author_identity'] == author and value['reviewer_identity'] != author
    assert value['source_only'] is True and value['source_review_passed'] is True
    assert value['all_checks_passed'] is True and type(value['scientific_calls']) is int
    assert value['scientific_calls'] == 0 and value['sources'] == sources
    assert value['source_contract'] == contract


def main(peer_path, contract_path, constructor_review_path):
    peer_path, contract_path, constructor_review_path = (
        Path(p).resolve() for p in (peer_path, contract_path, constructor_review_path))
    peer, contract, constructor_review = (read(p) for p in (
        peer_path, contract_path, constructor_review_path))
    assert contract['schema'] == 'unrelated-Q-word-control-cold-worker-Source-contract-v1'
    assert pin(contract_path)['sha256'] == '39b0556401a629f661df2ecf963a3099eaa132040f122e88c3a6d5cdca86c571'
    sources, abi, owned = contract['sources'], contract['leaf_ABI'], contract['owner_ABI']
    inputs = dict(contract['inputs'], worker_contract=pin(contract_path))
    assert set(sources) == {'worker', 'control_callable', 'independent_semantics', 'master'}
    assert set(inputs) == {'complete_fixtures', 'suite_contract', 'auditor_contract', 'worker_contract'}
    assert abi['field_count'] == 11 and owned['field_count'] == 10 and owned['argv_count'] == 6
    assert abi['stage'] == owned['stage'] == 'replay' and owned['scope'] == SCOPE
    assert abi['limits'] == owned['limits'] == LIMITS and abi['fresh_namespace'] == str(DEST)
    assert owned['argv'][2] == sources['worker']['path']
    assert not DEST.exists()
    review_gate(peer, schema='unrelated-Q-word-control-cold-worker-Source-review-v1',
        scope='unrelated-Q-word-control-cold-worker-Source', author=AUTHOR,
        sources=sources, contract=pin(contract_path))
    assert constructor_review['schema'] == 'ROOT-word-controls-metadata-constructor-Source-review-v1'
    assert constructor_review['author_identity'] == '/root' and constructor_review['reviewer_identity'] != '/root'
    assert constructor_review['source_only'] is True and constructor_review['source_review_passed'] is True
    assert constructor_review['all_checks_passed'] is True and type(constructor_review['scientific_calls']) is int
    assert constructor_review['scientific_calls'] == 0 and constructor_review['source'] == pin(__file__)
    assert constructor_review['worker_contract'] == pin(contract_path)
    suite_peer_pin = contract['existing_suite_Source_review']
    assert pin(suite_peer_pin['path']) == suite_peer_pin
    suite_peer, auditor_peer = read(suite_peer_pin['path']), read(AUDITOR_PEER)
    review_gate(suite_peer, schema='unrelated-six-rule-word-boundary-controls-Source-review-v1',
        scope='complete-unrelated-six-rule-word-and-nonlogical-Boundary-controls-Source', author=AUTHOR,
        sources={k: sources[k] for k in ('control_callable', 'independent_semantics', 'master')},
        contract=inputs['suite_contract'])
    review_gate(auditor_peer, schema='independent-Q-mathematical-auditor-Source-review-v1',
        scope='complete-finite-Q-catalogue-primitive-domain-and-word-checker-Source',
        author='/root/hilbert_ordering_diagnosis',
        sources={'independent_auditor': sources['independent_semantics'], 'master': sources['master']},
        contract=inputs['auditor_contract'])
    suite_contract = read(inputs['suite_contract']['path'])
    fixture = read(inputs['complete_fixtures']['path'])
    assert len(fixture['fixtures']) == 68 and len({f['id'] for f in fixture['fixtures']}) == 68
    assert sum(f['api'] == 'check_primitive_word' for f in fixture['fixtures']) == 56
    assert sum(f['api'] == 'Boundary' for f in fixture['fixtures']) == 12
    fixture_value_hash = hashlib.sha256(json.dumps(fixture, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf8')).hexdigest()
    assert fixture_value_hash == '843e5df6871092074574ab04e1961b4acfb7b0dd70f9423dcdbfd5ef863dc36e'
    assert suite_contract['fixture_count'] == 68 and suite_contract['word_fixture_count'] == 56
    assert suite_contract['nonlogical_boundary_fixture_count'] == 12
    runtime = abi['allowed_runtime']
    assert set(runtime) == {'binary', 'resource_extension', 'python_version', 'platform'}
    assert runtime['python_version'] == [3, 9, 6] and runtime['platform'] == 'darwin'
    named = [(contract_path, contract), (peer_path, peer), (constructor_review_path, constructor_review),
        (Path(suite_peer_pin['path']), suite_peer), (AUDITOR_PEER, auditor_peer),
        (Path(inputs['suite_contract']['path']), suite_contract),
        (Path(inputs['complete_fixtures']['path']), fixture)]
    closure = {}
    for path, value in named:
        collect(closure, [pin(path), value])
    collect(closure, [sources, inputs, runtime, pin(__file__)])
    # Independent auditor contract and all findings/ancestors stay raw leaves.
    DEST.mkdir()
    copied = {}
    for role, name in (('owner', 'run_owned_bridge_v2.py'), ('closer', 'close_stage_decision_v1.py')):
        original = owned[role]
        assert pin(original['path']) == original
        shutil.copyfile(original['path'], DEST / name)
        copied[role] = pin(DEST / name)
        assert copied[role]['sha256'] == original['sha256'] and copied[role]['bytes'] == original['bytes']
    root_review = dict(schema='unrelated-Q-word-control-cold-worker-Source-review-v1',
        author_identity=AUTHOR, reviewer_identity='/root', source_only=True,
        source_review_passed=True, all_checks_passed=True, scientific_calls=0,
        mathematical_acceptance=False, runtime_acceptance=False,
        source_contract=pin(contract_path), sources=sources,
        scope='unrelated-Q-word-control-cold-worker-Source',
        independent_review=pin(peer_path), suite_independent_review=suite_peer_pin,
        auditor_independent_review=pin(AUDITOR_PEER),
        metadata_constructor=pin(__file__), constructor_independent_review=pin(constructor_review_path),
        owner=copied['owner'], closer=copied['closer'],
        whole_current_worker_suite_and_contract_read=True,
        unchanged_previously_read_independent_semantics_and_master_reauthenticated=True,
        checks=['Exact current four Sources, corrected contract, current distinct typed reviews and full fixture census.',
            'Only worker, suite and independent semantics execute; no Q producer/graph/preparation/route import.',
            'Original code/default/closure/helper/clock seals before and after all delegated checks and writes.',
            'Literal68 fixture order, full original Gamma including unused occurrences, strict-prior ports and exact target.',
            'Private toy boundary mutations restored finally; actual production guard is never mutable.',
            'Shared20 includes preflight through full result serialization; 55/500 worker within60/512 owner and90 caller.',
            'Leaf11/owner10/argv6, whole raw closure and byte-identical owner/closer; no prefix accepted on failure.'],
        scope_limits=['Source and metadata only; no actual mechanics, resource or mathematical admission.',
            'Authored test words are not discovered proofs, and rejection does not establish falsehood.',
            'No Q target search, point graph, rank/pruning, full board/trajectory, PA/induction or RL qualification.'])
    root_review_pin = write(DEST / 'ROOT-source-review-v1.json', root_review)
    collect(closure, [root_review, root_review_pin, copied])
    assert len(closure) <= 256
    leaf_path, owner_path = DEST / 'worker-plan-v1.json', DEST / 'replay-plan-v1.json'
    output = DEST / 'word-controls-output-v1'
    leaf = dict(schema=abi['schema'], stage='replay', activation=abi['activation'],
        outdir=str(output), sources=sources, inputs=inputs,
        source_review=dict(ROOT=root_review_pin, worker_independent=pin(peer_path),
            suite_independent=suite_peer_pin, auditor_independent=pin(AUDITOR_PEER)),
        limits=LIMITS, allowed_runtime=runtime, source_cache_gate=abi['cache_gate'],
        raw_closure=[closure[k] for k in sorted(closure)])
    assert set(leaf) == set(abi['fields']) and len(leaf) == 11
    leaf_pin = write(leaf_path, leaf)
    collect(closure, leaf_pin)
    def lexical(record):
        return pin(record['path'], relative=True)
    argv = [runtime['binary']['path'], '-B', sources['worker']['path'],
        'ROOT-unrelated-Q-word-controls', str(leaf_path), str(owner_path)]
    owner = dict(schema=owned['schema'], stage='replay', runtime_binary=lexical(runtime['binary']),
        worker=str(Path(sources['worker']['path']).relative_to(ROOT)), argv=argv,
        worker_receipt=str((output / 'Q-unrelated-word-controls-result-v1.json').relative_to(ROOT)),
        limits=LIMITS, closure=[lexical(closure[k]) for k in sorted(closure)],
        ROOT_source_review=lexical(root_review_pin), scope=SCOPE)
    assert set(owner) == set(owned['fields']) and len(owner) == 10 and len(argv) == 6
    owner_pin = write(owner_path, owner)
    for record in closure.values():
        assert pin(record['path']) == record
    result = dict(schema='ROOT-word-controls-metadata-construction-v1',
        metadata_execution_only=True, project_imports=0, scientific_calls=0,
        worker_plan=leaf_pin, owner_plan=owner_pin, source_contract=pin(contract_path),
        named_metadata_roots=[pin(p) for p, value in named], raw_closure_count=len(closure),
        leaf_raw_closure_count=len(leaf['raw_closure']),
        literal_owner_command=[runtime['binary']['path'], '-B', copied['owner']['path'], owner_pin['path']],
        actual_execution_accepted=False, mathematical_admission=False, discovered_target_proofs=0)
    print(json.dumps(write(DEST / 'ROOT-construction-v1.json', result)), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 4
    main(*sys.argv[1:])
