"""Unexecuted cold worker for the exact unrelated word/Boundary control suite.

Only this worker, the frozen suite and independent semantics execute as project
Source. No producer, Q preparation/model, graph, proof donor or rank is loaded.
ROOT supplies actual plans/reviews and owned/caller custody in a future phase.
"""
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import resource
import sys
import time
import types

ROOT=Path(__file__).resolve().parents[2]
SCHEMA='ROOT-unrelated-Q-word-controls-worker-plan-v1'
SCOPE='unrelated-six-rule-words-and-nonlogical-Boundary-controls-no-Q-search'
COMMAND='ROOT-unrelated-Q-word-controls'
AUTHOR='/root/hilbert_advice_controls'
LIMITS=dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)
MAX_METADATA=2*1048576
RECEIPT='Q-unrelated-word-controls-result-v1.json'
PROGRESS=ROOT/'.gcts-active/arithmetic-Q-independent-word-controls-progress-20261014'
SOURCE_ROLES={'worker','control_callable','independent_semantics','master'}
SEMANTICS={'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-mathematical-audit-source-20261014/independent_Q_semantics_v1.py', 'sha256': '1717c716842886935c838a825b9c088810935acf101943e15eba6c5af7aec1c3', 'bytes': 46514}
SUITE={'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-word-controls-source-20261014/unrelated_word_and_boundary_controls_v1.py', 'sha256': '4aeb339a444675421b043f687d298825a122a13210caa9e7c3eec29d6da65bab', 'bytes': 17637}
MASTER={'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9', 'bytes': 21657}
FIXTURE={'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-word-controls-source-20261014/complete-fixtures-v1.json', 'sha256': 'b12b2504310d1ce5f11d6d737fccb5e8165a3c54202b66442ad75988373bbe5e', 'bytes': 150938}
SUITE_CONTRACT={'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-word-controls-source-20261014/source-contract-v1.json', 'sha256': '9a05ffd364fde921914ae1156ad4598c295ff429c3a846c9b3cbb79daff0b1e6', 'bytes': 8774}
AUDITOR_CONTRACT={'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-mathematical-audit-source-20261014/source-contract-v1.json', 'sha256': 'de26586799af2c8143fe744590dc2d76789836735342a8d6b582583d3b870e51', 'bytes': 16116}

def need(value, label):
    if not value:
        raise ValueError(label)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def pin(path):
    path = Path(path)
    need(path.is_absolute() and str(path.resolve()) == str(path) and not path.is_symlink(), 'canonical ABS pin')
    h = hashlib.sha256(); count = 0; before = path.stat()
    with path.open('rb') as stream:
        for raw in iter(lambda: stream.read(65536), b''):
            h.update(raw); count += len(raw)
    after = path.stat()
    need((before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size) ==
         (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size), 'whole stable raw bytes')
    return dict(path=str(path), sha256=h.hexdigest(), bytes=count)


def verify(record):
    need(type(record) is dict and set(record) == {'path','sha256','bytes'}
         and type(record['bytes']) is int and record['bytes'] >= 0
         and type(record['sha256']) is str and len(record['sha256']) == 64
         and all(c in '0123456789abcdef' for c in record['sha256'])
         and pin(record['path']) == record, 'typed canonical full pin')
    return record


def parse(raw):
    def unique(pairs):
        result = {}
        for name, value in pairs:
            need(name not in result, 'duplicate JSON field'); result[name] = value
        return result
    return json.loads(raw, object_pairs_hook=unique,
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError('nonfinite JSON '+token)))


def read(record, maximum=MAX_METADATA):
    verify(record)
    with Path(record['path']).open('rb') as stream:
        raw = stream.read(maximum+1)
        need(len(raw) <= maximum and stream.read(1) == b'', 'whole bounded raw buffer, no prefix')
    need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
         'parse the authenticated same raw buffer')
    value = parse(raw); verify(record); return value


def normalize(record):
    path = Path(record['path']); actual = path if path.is_absolute() else ROOT/path
    return dict(record, path=str(actual))


def value_state(value):
    """Detect ordinary namespace/default mutation without accepting origin claims."""
    if value is None or type(value) in (str, int, bool, float, list, dict, tuple):
        try: return canonical(value)
        except (TypeError, ValueError): pass
    return None


def executable_state(module, *, class_roots=()):
    state = []; namespaces = []; mros = []; seen_classes = set()
    def keys(owner):
        return tuple(k for k in vars(owner) if not k.startswith('__') and k != '_NEXT_CAPSULE')
    def add(owner, name, value):
        if isinstance(value, (staticmethod, classmethod)): value = value.__func__
        code = value.__code__ if inspect.isfunction(value) else None
        defaults = (value_state(value.__defaults__), value_state(value.__kwdefaults__)) if code else None
        closure = tuple((cell.cell_contents, value_state(cell.cell_contents))
                        for cell in (value.__closure__ or ())) if code else None
        state.append((owner, name, value, code, defaults, closure, value_state(value)))
        if isinstance(value, property):
            # The descriptor object can stay unchanged while its getter code mutates.
            for accessor in ('fget', 'fset', 'fdel'):
                add(value, accessor, getattr(value, accessor))
    def record_class(value):
        # Generated methods may dispatch through super() or a captured base_type.
        # Preserve every actual MRO class/method, not just that class object's ID.
        for parent in value.__mro__:
            if parent is object or parent in seen_classes: continue
            seen_classes.add(parent); mros.append((parent, parent.__mro__))
            namespaces.append((parent, keys(parent)))
            for field, child in vars(parent).items():
                if field not in ('__dict__', '__weakref__'): add(parent, field, child)
    namespaces.append((module, keys(module)))
    for name, value in vars(module).items():
        if name.startswith('__') or name == '_NEXT_CAPSULE': continue
        add(module, name, value)
        if isinstance(value, type) and value.__module__ == module.__name__:
            record_class(value)
    for value in class_roots:
        need(isinstance(value, type), 'actual generated endpoint class')
        record_class(value)
    return namespaces, state, mros


def unchanged_executable(state):
    namespaces, records, mros = state
    for owner, original_mro in mros:
        need(owner.__mro__ == original_mro and all(a is b for a, b in zip(owner.__mro__, original_mro)),
             'compiled generated endpoint inheritance changed')
    for owner, names in namespaces:
        need(tuple(k for k in vars(owner) if not k.startswith('__') and k != '_NEXT_CAPSULE') == names,
             'compiled namespace gained or lost bindings')
    for owner, name, original, code, defaults, closure, data in records:
        actual = getattr(owner, name) if isinstance(owner, property) else vars(owner).get(name)
        if isinstance(actual, (staticmethod, classmethod)): actual = actual.__func__
        need(actual is original, 'compiled namespace/function identity changed')
        if code is not None:
            need(actual.__code__ is code and
                 (value_state(actual.__defaults__), value_state(actual.__kwdefaults__)) == defaults,
                 'compiled executable/defaults changed; co_filename is insufficient')
            current = actual.__closure__ or ()
            need(len(current) == len(closure) and all(cell.cell_contents is old and value_state(cell.cell_contents) == text
                 for cell, (old, text) in zip(current, closure)), 'compiled source closure changed')
        if data is not None: need(value_state(actual) == data, 'compiled source constant changed')


def json_blockable(value):
    # A C-json block is a bounded existing subtree: at most512 scalar/container
    # visits,32768 total string characters and4096 bits per integer. This test
    # retains references only; oversized containers are streamed recursively.
    stack=[value];visits=0;characters=0
    while stack:
        child=stack.pop();visits+=1
        if visits>512:return False
        if type(child) is str:
            characters+=len(child)
            if characters>32768:return False
        elif type(child) is int:
            if child.bit_length()>4096:return False
        elif child is None or type(child) in (bool,float):pass
        elif type(child) is dict:
            if len(child)>512:return False
            for name,item in child.items():
                if type(name) is not str:return False
                stack.append(name);stack.append(item)
                if len(stack)>512:return False
        elif type(child) in (list,tuple):
            if len(child)>512:return False
            stack.extend(child)
            if len(stack)>512:return False
        else:return False
    return True


def json_chunks(value):
    # Full canonical JSON: C blocks only for bounded existing subtrees. No full
    # model/state copy, JSON string or UTF-8 buffer is constructed here.
    if json_blockable(value):
        yield canonical(value)
    elif type(value) is dict:
        yield '{'
        for index,name in enumerate(sorted(value)):
            need(type(name) is str,'literal JSON object keys')
            if index:yield ','
            yield canonical(name)+':'
            yield from json_chunks(value[name])
        yield '}'
    elif type(value) in (list,tuple):
        yield '['
        for start in range(0,len(value),32):
            block=value[start:start+32]
            if start:yield ','
            if json_blockable(block):yield canonical(block)[1:-1]
            else:
                for offset,item in enumerate(block):
                    if offset:yield ','
                    yield from json_chunks(item)
        yield ']'
    else:yield canonical(value)


def function_state(fn):
    need(inspect.isfunction(fn), 'actual Python function endpoint')
    return (fn, fn.__code__, id(fn.__defaults__), tuple(id(v) for v in fn.__defaults__ or ()),
        id(fn.__kwdefaults__), tuple((k,id(v)) for k,v in sorted((fn.__kwdefaults__ or {}).items())),
        tuple((id(cell),id(cell.cell_contents)) for cell in fn.__closure__ or ()))


def source_cache_guard(sources, modules, anchors):
    # RAW producer ledger is deliberately excluded from this executable map.
    expected={p['path']:p for p in sources.values() if p['path'].endswith('.py')}
    seen=[]
    for name,module in list(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if type(file) is not str:
            continue
        lexical=Path(file)
        if not lexical.is_absolute():
            lexical=ROOT/lexical
        if not str(lexical).startswith(str(ROOT)+os.sep):
            continue
        path=str(lexical.resolve())
        need(path in expected and not path.endswith(('.pyc','.pyo')), 'only worker/auditor local execution, no producer/cache import')
        need(name==__name__ or any(module is value for value in modules.values()), 'exact raw-loaded module object')
        verify(expected[path]); seen.append(expected[path])
    need(all(modules[role] is anchors[role] and sys.modules.get(modules[role].__name__) is modules[role]
        for role in modules), 'original compiled module namespaces')
    return sorted({p['path']:p for p in seen}.values(),key=lambda p:p['path'])


def value_digest(value, tick):
    # Whole canonical data seal, no second preparation parse or full JSON copy.
    # The caller seals its original nested tick before handing it here. Seal
    # that actual object too: do not invoke a mutable tick/global state helper.
    state_function=function_state; state_code=state_function.__code__
    state_anchor=state_function(state_function)
    tick_function=tick; tick_anchor=state_function(tick_function)
    clock_function=time.perf_counter; usage_function=resource.getrusage
    h=hashlib.sha256(); since_boundary=0
    if function_state is not state_function or state_function.__code__ is not state_code or \
            time.perf_counter is not clock_function or resource.getrusage is not usage_function:
        raise ValueError('original input-seal state/clock endpoint changed')
    if state_function(state_function)!=state_anchor or tick is not tick_function or state_function(tick_function)!=tick_anchor:
        raise ValueError('original input-seal tick code/default/closure changed')
    tick_function()
    if function_state is not state_function or state_function.__code__ is not state_code or \
            time.perf_counter is not clock_function or resource.getrusage is not usage_function:
        raise ValueError('input-seal state/clock endpoint changed during callback')
    if state_function(state_function)!=state_anchor or tick is not tick_function or state_function(tick_function)!=tick_anchor:
        raise ValueError('input-seal tick changed during callback')
    for chunk in json_chunks(value):
        raw=chunk.encode('utf8')
        need(len(raw)<=4*1048576, 'bounded canonical data-seal chunk')
        h.update(raw); since_boundary+=len(raw)
        if since_boundary>=65536:
            if function_state is not state_function or state_function.__code__ is not state_code or \
                    time.perf_counter is not clock_function or resource.getrusage is not usage_function:
                raise ValueError('original input-seal state/clock endpoint changed')
            if state_function(state_function)!=state_anchor or tick is not tick_function or state_function(tick_function)!=tick_anchor:
                raise ValueError('original input-seal tick code/default/closure changed')
            tick_function()
            if function_state is not state_function or state_function.__code__ is not state_code or \
                    time.perf_counter is not clock_function or resource.getrusage is not usage_function:
                raise ValueError('input-seal state/clock endpoint changed during callback')
            if state_function(state_function)!=state_anchor or tick is not tick_function or state_function(tick_function)!=tick_anchor:
                raise ValueError('input-seal tick changed during callback')
            since_boundary=0
    if function_state is not state_function or state_function.__code__ is not state_code or \
            time.perf_counter is not clock_function or resource.getrusage is not usage_function:
        raise ValueError('original input-seal state/clock endpoint changed')
    if state_function(state_function)!=state_anchor or tick is not tick_function or state_function(tick_function)!=tick_anchor:
        raise ValueError('original input-seal tick code/default/closure changed')
    tick_function()
    if function_state is not state_function or state_function.__code__ is not state_code or \
            time.perf_counter is not clock_function or resource.getrusage is not usage_function:
        raise ValueError('input-seal state/clock endpoint changed during callback')
    if state_function(state_function)!=state_anchor or tick is not tick_function or state_function(tick_function)!=tick_anchor:
        raise ValueError('input-seal tick changed during callback')
    return h.hexdigest()


def authenticate_named(value, closure):
    # Walk raw pins in an already named parsed input only. Never decode ancestors.
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:
            record=normalize(value); verify(record)
            need(closure.get(record['path'])==record, 'every named-reader raw pin explicitly closed')
            return
        for child in value.values():
            authenticate_named(child,closure)
    elif type(value) is list:
        for child in value:
            authenticate_named(child,closure)


def raw_buffer(record):
    verify(record)
    path=Path(record['path']); before=path.stat(); raw=path.read_bytes(); after=path.stat()
    need((before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size)==
         (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size)
         and len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256'],
         'one stable full authenticated execution buffer')
    return raw


def load_buffer(record, raw, name):
    need(type(raw) is bytes and len(raw)==record['bytes']
         and hashlib.sha256(raw).hexdigest()==record['sha256'], 'execute the verified buffer, not pyc/cache')
    need(name not in sys.modules, 'fresh explicit raw module namespace')
    module=types.ModuleType(name)
    module.__file__=record['path']; module.__package__=''; module.__loader__=None
    sys.modules[name]=module
    exec(compile(raw,record['path'],'exec',dont_inherit=True,optimize=0),module.__dict__)
    need(module.__file__==record['path'] and module.__name__==name, 'unchanged explicit raw module origin')
    return module


def preflight(plan_path, owner_path):
    plan_pin,owner_pin=pin(plan_path),pin(owner_path)
    plan,owner=read(plan_pin),read(owner_pin)
    fields={'schema','stage','activation','outdir','sources','inputs','source_review','limits',
            'allowed_runtime','source_cache_gate','raw_closure'}
    need(type(plan) is dict and set(plan)==fields and plan['schema']==SCHEMA
         and plan['stage']=='replay' and canonical(plan['limits'])==canonical(LIMITS),
         'exact frozen11-field unrelated-word leaf')
    need(canonical(plan['activation'])==canonical(dict(schema='ROOT-unrelated-Q-word-controls-activation-v1',
         author_identity='/root',ROOT_owned_once_only=True,scope=SCOPE,source_review_not_mathematical_admission=True,
         Q_target_searches=0,rank_computations=0,native_queries=0,RL_updates=0)), 'ROOT once-only narrow controls activation')
    sources=plan['sources']
    need(type(sources) is dict and set(sources)==SOURCE_ROLES
         and sources['worker']==pin(Path(__file__).resolve()) and sources['control_callable']==SUITE
         and sources['independent_semantics']==SEMANTICS and sources['master']==MASTER, 'exact four raw roles')
    inputs=plan['inputs']
    need(type(inputs) is dict and set(inputs)=={'complete_fixtures','suite_contract','auditor_contract','worker_contract'}
         and inputs['complete_fixtures']==FIXTURE and inputs['suite_contract']==SUITE_CONTRACT
         and inputs['auditor_contract']==AUDITOR_CONTRACT, 'small named inputs only; no Q preparation or donor')
    need(plan['source_cache_gate']==dict(executed_roles=['worker','control_callable','independent_semantics'],
         raw_only_roles=['master'],allow_project_bytecode=False,execute_or_compile_producer_sources=False,
         temporary_mutation_scope='invented callbacks/ephemeral Boundary only; production guard never mutable'),
         'explicit exact execution/nonexecution/mutation scope')
    need(plan_path.parent==owner_path.parent==PROGRESS and plan_path.name=='worker-plan-v1.json'
         and owner_path.name=='replay-plan-v1.json', 'fresh fixed flat once-only namespace')
    output=Path(plan['outdir'])
    need(output.is_absolute() and output==output.resolve() and output==PROGRESS/'word-controls-output-v1'
         and not output.exists(), 'exclusive output, no resume or rescue')
    closure={}
    need(type(plan['raw_closure']) is list and len(plan['raw_closure'])<=256, 'bounded explicit worker raw closure')
    for record in plan['raw_closure']:
        verify(record); need(record['path'] not in closure,'unique canonical worker closure')
        closure[record['path']]=record
    need(list(closure)==sorted(closure),'canonical sorted worker closure')
    reviews=plan['source_review']
    need(type(reviews) is dict and set(reviews)=={'ROOT','worker_independent','suite_independent','auditor_independent'},
         'four genuine typed Source slots, never fabricated pending pass')
    for record in [*sources.values(),*inputs.values(),*reviews.values()]:
        verify(record); need(closure.get(record['path'])==record,'all direct sources/fixtures/contracts/reviews closed')
    runtime=plan['allowed_runtime']
    need(type(runtime) is dict and set(runtime)=={'binary','resource_extension','python_version','platform'}
         and runtime['python_version']==[3,9,6] and runtime['platform']=='darwin'
         and list(sys.version_info[:3])==[3,9,6] and sys.platform=='darwin' and sys.flags.optimize==0,
         'original frozen canonical CLT runtime')
    for role in ('binary','resource_extension'):
        verify(runtime[role]); need(closure.get(runtime[role]['path'])==runtime[role],'complete actual runtime origin')
    need(str(Path(sys.executable).resolve())==runtime['binary']['path']
         and str(Path(resource.__file__).resolve())==runtime['resource_extension']['path'], 'actual executable/resource')
    argv=[runtime['binary']['path'],'-B',sources['worker']['path'],COMMAND,str(plan_path),str(owner_path)]
    need(type(owner) is dict and set(owner)=={'schema','stage','runtime_binary','worker','argv','worker_receipt',
         'limits','closure','ROOT_source_review','scope'} and owner['schema']=='ROOT-guard-native-owned-plan-v1'
         and owner['stage']=='replay' and canonical(owner['limits'])==canonical(LIMITS)
         and owner['scope']==SCOPE and owner['argv']==argv, 'unchanged generic10 ABI and exactly six argv')
    need(normalize(owner['runtime_binary'])==runtime['binary']
         and normalize(owner['ROOT_source_review'])==reviews['ROOT']
         and reviews['ROOT']['path']==str(PROGRESS/'ROOT-source-review-v1.json'), 'exact ROOT/runtime binding')
    need((ROOT/owner['worker']).resolve()==Path(sources['worker']['path'])
         and (ROOT/owner['worker_receipt']).resolve()==output/RECEIPT, 'literal worker/final receipt paths')
    owner_closure={}
    for raw in owner['closure']:
        record=normalize(raw); verify(record)
        need(record['path'] not in owner_closure,'unique normalized owner closure')
        owner_closure[record['path']]=record
    for record in [*closure.values(),plan_pin]:
        need(owner_closure.get(record['path'])==record,'owner closes complete worker inputs and exact leaf')
    for name,sha,length in [('run_owned_bridge_v2.py','2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656',14639),
                            ('close_stage_decision_v1.py','9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf',4752)]:
        copied=pin(PROGRESS/name)
        need(copied['sha256']==sha and copied['bytes']==length and closure.get(copied['path'])==copied,
             'unchanged byte-identical generic owner/closer in actual flat namespace')
    for role,record in reviews.items():
        review=read(record); authenticate_named(review,closure)
        need(review.get('source_only') is True and review.get('source_review_passed') is True
             and review.get('all_checks_passed') is True and type(review.get('scientific_calls')) is int
             and review['scientific_calls']==0 and type(review.get('reviewer_identity')) is str,
             'genuine completed Source-only assessment')
        if role=='auditor_independent':
            need(review.get('author_identity')=='/root/hilbert_ordering_diagnosis'
                 and review['reviewer_identity']!='/root/hilbert_ordering_diagnosis'
                 and review.get('schema')=='independent-Q-mathematical-auditor-Source-review-v1'
                 and review.get('scope')=='complete-finite-Q-catalogue-primitive-domain-and-word-checker-Source'
                 and review.get('sources')=={'independent_auditor':SEMANTICS,'master':MASTER}
                 and review.get('source_contract')==AUDITOR_CONTRACT, 'exact independent checker Source review')
        elif role=='suite_independent':
            need(review.get('author_identity')==AUTHOR and review['reviewer_identity']!=AUTHOR
                 and review.get('schema')=='unrelated-six-rule-word-boundary-controls-Source-review-v1'
                 and review.get('scope')=='complete-unrelated-six-rule-word-and-nonlogical-Boundary-controls-Source'
                 and review.get('sources')=={'control_callable':SUITE,'independent_semantics':SEMANTICS,'master':MASTER}
                 and review.get('source_contract')==SUITE_CONTRACT, 'exact whole suite Source review')
        else:
            need(review.get('author_identity')==AUTHOR and review['reviewer_identity']!=AUTHOR
                 and review.get('schema')=='unrelated-Q-word-control-cold-worker-Source-review-v1'
                 and review.get('scope')=='unrelated-Q-word-control-cold-worker-Source'
                 and review.get('sources')==sources and review.get('source_contract')==inputs['worker_contract'],
                 'exact new cold-worker Source review')
    # Only new worker and suite contracts are parsed here. Auditor contract is
    # an authenticated raw specification leaf; do not decode its Q ancestry.
    contract=read(inputs['worker_contract']); suite_contract=read(inputs['suite_contract'])
    authenticate_named(contract,closure); authenticate_named(suite_contract,closure)
    need(contract['schema']=='unrelated-Q-word-control-cold-worker-Source-contract-v1'
         and contract['sources']==sources and contract['inputs']['complete_fixtures']==FIXTURE
         and contract['inputs']['suite_contract']==SUITE_CONTRACT
         and contract['inputs']['auditor_contract']==AUDITOR_CONTRACT, 'current exact cold wrapper Source contract')
    need(suite_contract['schema']=='unrelated-six-rule-word-boundary-control-Source-contract-v1'
         and suite_contract['sources']=={'control_callable':SUITE,'independent_semantics':SEMANTICS,'master':MASTER}
         and suite_contract['inputs']=={'complete_literal_fixtures':FIXTURE}
         and suite_contract['fixture_count']==68 and suite_contract['word_fixture_count']==56
         and suite_contract['nonlogical_boundary_fixture_count']==12, 'entire frozen unrelated suite specification')
    return plan,owner,output,plan_pin,owner_pin,closure


def main():
    original_clock,original_usage=time.perf_counter,resource.getrusage
    began=original_clock(); deadline=began+20
    need(len(sys.argv)==4 and sys.argv[1]==COMMAND,'literal unrelated control invocation')
    plan_path,owner_path=(Path(p) for p in sys.argv[2:])
    need(all(p.is_absolute() and p==p.resolve() for p in (plan_path,owner_path)),'canonical actual plan paths')
    own=sys.modules[__name__]; own_module_code=inspect.currentframe().f_back.f_code
    validator_names=('need','canonical','pin','verify','parse','read','normalize','value_state','executable_state',
        'unchanged_executable','json_blockable','json_chunks','function_state','source_cache_guard','value_digest',
        'authenticate_named','raw_buffer','load_buffer','preflight')
    validators={name:(globals()[name],globals()[name].__code__) for name in validator_names}
    original_state=function_state; original_state_code=function_state.__code__
    own_state=executable_state(own); states=[]; modules={}; module_anchors={}; origins={}; entries={}; guards={}
    plan=None; output=None; receipt_path=None; artifacts=[]; partial=[]; serialization=[]

    def direct_own():
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original production clock/resource endpoint changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original own callback-state helper changed')
        for name,(function,code) in validators.items():
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError('original own loader/rejection/writer validator changed')
        unchanged_executable(own_state)
    guards['direct_own']=function_state(direct_own)

    def source_guard():
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('own state helper changed before guard')
        for name,(function,code) in validators.items():
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError('own validator changed before guard delegation')
        if function_state(direct_own)!=guards['direct_own']:
            raise ValueError('original direct production guard changed')
        if 'save' in guards and function_state(guards['writer_function'])!=guards['save']:
            raise ValueError('original output writer code/default/closure changed')
        direct_own()
        for state in states:
            unchanged_executable(state)
        if plan is not None:
            source_cache_guard(plan['sources'],modules,module_anchors)
        for role,(module,name,file) in origins.items():
            need(modules[role] is module and module.__name__==name and module.__file__==file
                 and sys.modules.get(name) is module, 'exact compiled module origin/object')
        for role,(name,function,anchor) in entries.items():
            need(vars(modules[role]).get(name) is function and function_state(function)==anchor
                 and function.__globals__ is vars(modules[role]), 'actual compiled effective entry')
        need(original_clock()-began<55 and original_usage(resource.RUSAGE_SELF).ru_maxrss<500*1048576,
             'whole55/500 under unchanged60/512 owned envelope')
    guards['source_guard']=function_state(source_guard)

    def invoke_guard():
        # The actual production guard/shim is never a mutation-test subject.
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('own predicate changed before production callback')
        for name,(function,code) in validators.items():
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError('own validator changed before production callback')
        if function_state(source_guard)!=guards['source_guard']:
            raise ValueError('original production callback code/default/closure changed')
        source_guard()
        if function_state(source_guard)!=guards['source_guard']:
            raise ValueError('production callback changed during delegation')
    guards['invoke_guard']=function_state(invoke_guard)

    def boundary(inner=False):
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('own state predicate changed before outer boundary')
        for name,(function,code) in validators.items():
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError('own validator changed before outer shim')
        if function_state(invoke_guard)!=guards['invoke_guard']:
            raise ValueError('original outer shim code/default/closure changed')
        invoke_guard()
        if inner and original_clock()>=deadline:
            raise TimeoutError('whole unrelated-word controls exceed shared20; no prefix')
    guards['boundary']=function_state(boundary)

    def checked(inner=False):
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('own state predicate changed before checked boundary')
        for name,(function,code) in validators.items():
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError('own validator changed before checked boundary')
        if function_state(boundary)!=guards['boundary']:
            raise ValueError('original effective boundary changed')
        boundary(inner)
    guards['checked']=function_state(checked)
    checked_function=checked; checked_anchor=guards['checked']

    def save(name,value,inner=False):
        need(Path(name).name==name and name.endswith('.json'),'exclusive output basename')
        path=output/name; partial.append(str(path)); start=original_clock(); size=0; maximum=0
        with path.open('xb') as stream:
            for chunk in json_chunks(value):
                if function_state is not original_state or function_state.__code__ is not original_state_code:
                    raise ValueError('own validator changed before output')
                for key,(function,code) in validators.items():
                    if globals().get(key) is not function or function.__code__ is not code:
                        raise ValueError('own writer helper changed')
                if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
                    raise ValueError('original clock/resource before checked delegation changed')
                if function_state is not original_state or function_state.__code__ is not original_state_code:
                    raise ValueError('original state helper before checked delegation changed')
                for checked_name,(checked_validator,checked_code) in validators.items():
                    if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                        raise ValueError('original validator before checked delegation changed')
                if checked is not checked_function or original_state(checked_function)!=checked_anchor:
                    raise ValueError('saved checked function/code/default/closure before delegation changed')
                checked_function(inner); raw=chunk.encode('utf8'); size+=len(raw); maximum=max(maximum,len(raw))
                need(size<=MAX_METADATA and len(raw)<=1048576 and stream.write(raw)==len(raw),
                     'whole bounded complete output, no certified prefix')
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(inner); record=pin(path); artifacts.append(record); partial.remove(str(path))
        serialization.append(dict(file=record,bytes=size,maximum_chunk_bytes=maximum,
            inclusive_seconds=original_clock()-start,inside_shared20=inner))
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(inner); return record
    guards['writer_function']=save
    guards['save']=function_state(save)

    def inner_checked_tick():
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(True)
    inner_tick_function=inner_checked_tick; inner_tick_anchor=function_state(inner_checked_tick)

    try:
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(True)
        plan,owner,output,plan_pin,owner_pin,closure=preflight(plan_path,owner_path)
        # Filling these declared module/context cells is the single setup phase;
        # no guard code/default/closure change or post-load reseal is permitted.
        guards['source_guard']=function_state(source_guard)
        guards['invoke_guard']=function_state(invoke_guard)
        guards['boundary']=function_state(boundary)
        guards['checked']=function_state(checked)
        guards['save']=function_state(save)
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(True); output.mkdir()
        buffers={role:raw_buffer(plan['sources'][role]) for role in ('worker','control_callable','independent_semantics')}
        expected_own_code=compile(buffers['worker'],plan['sources']['worker']['path'],'exec',dont_inherit=True,optimize=0)
        need(own_module_code==expected_own_code and own_module_code.co_filename==plan['sources']['worker']['path'],
             'actual interpreted whole worker code equals authenticated Source buffer')
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        if inner_checked_tick is not inner_tick_function or original_state(inner_tick_function)!=inner_tick_anchor:
            raise ValueError('original complete input-seal tick changed before delegation')
        fixture=read(FIXTURE); fixture_seal=value_digest(fixture,inner_tick_function)
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(True)
        for role in ('independent_semantics','control_callable'):
            module=load_buffer(plan['sources'][role],buffers[role],'Q_unrelated_'+role+'_v1')
            modules[role]=module; module_anchors[role]=module
            origins[role]=(module,module.__name__,module.__file__); states.append(executable_state(module))
        entry=modules['control_callable'].run_unrelated_word_controls
        entries['control_callable']=('run_unrelated_word_controls',entry,function_state(entry))
        # Module tables/entry records are predeclared mutable setup containers;
        # their object identities stay fixed. No anchor is resealed after any
        # project Source buffer has executed.
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(True)
        result=entry(semantics_module=modules['independent_semantics'],fixture_document=fixture,
            expected_semantics_source=SEMANTICS,expected_fixture_source=FIXTURE,
            source_guard=invoke_guard,deadline=deadline)
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(True)
        need(result['schema']=='unrelated-six-rule-word-boundary-controls-result-v1'
             and result['completed'] is True and result['all_checks_passed'] is True
             and len(result['results'])==68 and [r['id'] for r in result['results']]==[f['id'] for f in fixture['fixtures']]
             and all(r['all_checks_passed'] is True for r in result['results']), 'entire68-case result in literal order')
        need(sum(f['api']=='check_primitive_word' for f in fixture['fixtures'])==56
             and sum(f['api']=='Boundary' for f in fixture['fixtures'])==12, '56 words/12 explicit NONLOGICAL controls')
        for flag in ('Q_target_proof_discovered','current_point_union_accepted','catalogue_admitted','pruning_admitted',
                     'full24_accepted','native_accepted','full_trajectory_accepted','induction_accepted','full_PA_accepted',
                     'ROOT_resource_accepted','partial_result_returned'):
            need(result[flag] is False,'no stronger scientific acceptance')
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        if inner_checked_tick is not inner_tick_function or original_state(inner_tick_function)!=inner_tick_anchor:
            raise ValueError('original complete input-seal tick changed before delegation')
        need(value_digest(fixture,inner_tick_function)==fixture_seal,'whole original literal fixture input unchanged')
        if function_state(save)!=guards['save']:
            raise ValueError('original owned result writer changed')
        result_pin=save('Q-unrelated-word-controls-provisional-v1.json',result,True)
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function(True); inner_seconds=original_clock()-began
        evidence=dict(schema='cold-unrelated-Q-word-controls-evidence-v1',sources=plan['sources'],inputs=plan['inputs'],
            worker_plan=plan_pin,owner_plan=owner_pin,result=result_pin,fixture_value_sha256=fixture_seal,
            complete_fixture_cases=68,logical_word_controls=56,NONLOGICAL_boundary_controls=12,
            actual_call_tape=result['call_tape'],executed_raw_project_source_ledger=source_cache_guard(plan['sources'],modules,module_anchors),
            executed_buffers={role:plan['sources'][role] for role in buffers},worker_whole_code_buffer_equality=True,
            production_callback_never_mutated=True,temporary_mutations='only invented suite callback/ephemeral Boundary; restored finally',
            producer_Source_modules_executed=0,large_Q_preparation_parses=0,inner_seconds_before_final_guard=inner_seconds,
            serialization_records_before_evidence=list(serialization),ROOT_resource_accepted=False,
            Q_target_proofs=0,Q_target_searches=0,rank_computations=0,native_queries=0,RL_runs=0)
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function()
        evidence_pin=save('Q-unrelated-word-controls-evidence-v1.json',evidence)
        receipt_path=output/RECEIPT
        receipt=dict(schema='cold-unrelated-Q-word-controls-receipt-v1',stage='replay',stage_completed=True,
            status='completed_unrelated_word_controls_pending_ROOT',worker_plan=plan_pin,owner_plan=owner_pin,
            controls=result_pin,evidence=evidence_pin,all_direct_children_terminal_and_reaped=True,
            direct_children_peak_sum_bytes=0,complete_fixture_cases=68,logical_word_controls=56,NONLOGICAL_boundary_controls=12,
            resource_acceptance_issued=False,ROOT_mathematical_admission_issued=False,Q_target_searches=0,Q_target_proofs=0,
            rank_computations=0,native_queries=0,RL_runs=0,native_accepted=False,full24_accepted=False,
            full_trajectory_accepted=False,full_PA_accepted=False,worker_elapsed_before_receipt_seconds=original_clock()-began,
            worker_SELF_peak_before_receipt_bytes=original_usage(resource.RUSAGE_SELF).ru_maxrss,
            output_closure_before_receipt=list(artifacts),serialization_records_before_receipt=list(serialization))
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function()
        receipt_pin=save(RECEIPT,receipt)
        post=dict(schema='cold-unrelated-Q-word-controls-postwrite-v1',receipt=receipt_pin,controls=result_pin,evidence=evidence_pin,
            elapsed_seconds_after_receipt_write=original_clock()-began,
            peak_SELF_bytes_after_receipt_write=original_usage(resource.RUSAGE_SELF).ru_maxrss,
            resource_acceptance_issued=False,ROOT_mathematical_admission_issued=False,
            scope='Receipt write included; final postwrite record/console/exit remain within55/500 and owner60/512.')
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function()
        post_pin=save('Q-unrelated-word-controls-postwrite-v1.json',post)
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function()
        print(canonical(dict(stage_completed=True,receipt=receipt_pin,postwrite=post_pin,
            worker_elapsed_after_writes_seconds=original_clock()-began,
            worker_SELF_peak_after_writes_bytes=original_usage(resource.RUSAGE_SELF).ru_maxrss,
            resource_acceptance_issued=False,ROOT_mathematical_admission_issued=False)),flush=True)
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource before checked delegation changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state helper before checked delegation changed')
        for checked_name,(checked_validator,checked_code) in validators.items():
            if globals().get(checked_name) is not checked_validator or checked_validator.__code__ is not checked_code:
                raise ValueError('original validator before checked delegation changed')
        if checked is not checked_function or original_state(checked_function)!=checked_anchor:
            raise ValueError('saved checked function/code/default/closure before delegation changed')
        checked_function()
    except BaseException as error:
        # Later code/clock/writer/console failure revokes the success latch.
        if receipt_path is not None and receipt_path.exists():
            receipt_path.rename(output/'Q-unrelated-word-controls-result-withdrawn-v1.json')
        if output is not None and output.exists():
            failure=dict(schema='cold-unrelated-Q-word-controls-failure-v1',stage='replay',stage_completed=False,
                status='UNKNOWN_incomplete_unrelated_controls',error=dict(type=type(error).__name__,message=str(error)[:512]),
                provisional_artifacts=artifacts,partial_paths=partial,accepted_prefix=False,
                resource_acceptance_issued=False,ROOT_mathematical_admission_issued=False)
            with (output/'failure-v1.json').open('xb') as stream:
                stream.write((canonical(failure)+'\n').encode('utf8'))
        raise


if __name__=='__main__':
    main()


