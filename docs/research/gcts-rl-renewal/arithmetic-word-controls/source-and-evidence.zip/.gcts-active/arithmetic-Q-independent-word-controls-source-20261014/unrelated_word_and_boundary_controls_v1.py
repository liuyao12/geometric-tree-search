"""Unexecuted SOURCE: complete unrelated six-rule and Boundary controls.

The whole literal array is a control declaration, not theorem discovery or a Q
proof route. ROOT must supply a reviewed cold raw-byte worker and genuine owned
resource custody. This callable does not load modules or authenticate them by
co_filename/hash claims. No producer catalogue, point graph or donor is used.
"""
import hashlib
import json
import math
import time
import types

VERSION = "unrelated-six-rule-word-boundary-controls-v1"
SEMANTICS_VERSION = "independent-complete-finite-Q-semantics-v1"
SEMANTICS_SOURCE = {
    "path": "/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-mathematical-audit-source-20261014/independent_Q_semantics_v1.py",
    "sha256": "1717c716842886935c838a825b9c088810935acf101943e15eba6c5af7aec1c3",
    "bytes": 46514}
FIXTURE_SOURCE = {
    "path": "/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-word-controls-source-20261014/complete-fixtures-v1.json",
    "sha256": "b12b2504310d1ce5f11d6d737fccb5e8165a3c54202b66442ad75988373bbe5e",
    "bytes": 150938}
FIXTURE_VALUE_SHA256 = "843e5df6871092074574ab04e1961b4acfb7b0dd70f9423dcdbfd5ef863dc36e"


def need(ok, message):
    if not ok:
        raise ValueError(message)


def plain(value):
    kind = type(value)
    if value is None or kind in (str, int, bool):
        return
    if kind is float:
        need(math.isfinite(value), "finite literal data")
        return
    if kind is list:
        for child in value:
            plain(child)
        return
    need(kind is dict, "plain literal JSON; no object hooks")
    for key, child in value.items():
        need(type(key) is str, "literal string object key")
        plain(child)


def canonical(value):
    plain(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def sha(value):
    return hashlib.sha256(canonical(value).encode("utf8")).hexdigest()


def function_state(fn):
    need(type(fn) is types.FunctionType, "exact Python guard/checker function")
    return (fn, fn.__code__, id(fn.__defaults__), tuple(id(x) for x in fn.__defaults__ or ()),
            id(fn.__kwdefaults__), tuple(sorted((k, id(v)) for k, v in (fn.__kwdefaults__ or {}).items())),
            tuple((id(cell), id(cell.cell_contents)) for cell in fn.__closure__ or ()))


def data_state(value):
    kind = type(value)
    if kind is dict:
        return ("dict", tuple(sorted((data_state(k), data_state(v)) for k, v in value.items())))
    if kind in (list, tuple):
        return (kind.__name__, tuple(data_state(x) for x in value))
    if kind in (set, frozenset):
        return (kind.__name__, tuple(sorted(data_state(x) for x in value)))
    if value is None or kind in (str, int, float, bool):
        return (kind.__name__, value)
    return ("object-identity", kind, id(value))


def module_state(module):
    """All module globals and Python class/MRO/property code roots.

    Native runtime/stdlib origins and the runner's own complete effective source
    endpoints must be independently sealed by the cold caller, not this record.
    """
    records = []
    for name, value in sorted(vars(module).items()):
        if type(value) is types.FunctionType:
            records.append((name, "function", function_state(value), id(value.__globals__)))
        elif isinstance(value, type) and value.__module__ == module.__name__:
            members = []
            for owner in value.__mro__:
                for member, descriptor in sorted(vars(owner).items()):
                    item = descriptor
                    if type(item) in (staticmethod, classmethod):
                        item = item.__func__
                    if type(item) is types.FunctionType:
                        state = ("function", function_state(item), id(item.__globals__))
                    elif type(item) is property:
                        state = ("property", id(item), tuple(function_state(fn) if fn else None
                                 for fn in (item.fget, item.fset, item.fdel)))
                    else:
                        state = data_state(item)
                    members.append((owner, member, state))
            records.append((name, "class", value, tuple(members)))
        else:
            records.append((name, data_state(value)))
    return tuple(records)


class Gate:
    """Whole shared real clock with anchored validators and delegated guard."""

    def __init__(self, module, source_guard, deadline):
        need(type(module) is types.ModuleType, "admitted actual semantics module object")
        need(type(deadline) in (int, float) and math.isfinite(deadline), "finite absolute outer deadline")
        self.module, self.deadline, self.guard = module, deadline, source_guard
        self.clock = time.perf_counter
        self._helpers = tuple((name, globals()[name], globals()[name].__code__)
                              for name in ("need", "plain", "canonical", "sha", "function_state",
                                           "data_state", "module_state"))
        self._state_fn, self._module_fn = function_state, module_state
        self.anchor = self._state_fn(source_guard)
        self.module_anchor = self._module_fn(module)
        self.guard_calls = 0
        self.check()

    def check(self):
        # These direct checks precede invoking any current validator or callback.
        for name, function, code in self._helpers:
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError("own control validator identity/code changed")
            if function.__defaults__ is not None or function.__kwdefaults__ is not None or function.__closure__ is not None:
                raise ValueError("own control validator defaults/closure changed")
        if time.perf_counter is not self.clock:
            raise ValueError("original real clock endpoint changed")
        if self.clock() >= self.deadline:
            raise TimeoutError("whole unrelated controls unresolved at deadline")
        if self._state_fn(self.guard) != self.anchor:
            raise ValueError("outer caller guard code/default/closure changed")
        if self._module_fn(self.module) != self.module_anchor:
            raise ValueError("semantics module globals/class/MRO/property/code changed")
        self.guard()
        self.guard_calls += 1
        # Revalidate the helper code and clock before using either after return.
        for name, function, code in self._helpers:
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError("own control validator changed during callback")
            if function.__defaults__ is not None or function.__kwdefaults__ is not None or function.__closure__ is not None:
                raise ValueError("own control validator defaults/closure changed during callback")
        if time.perf_counter is not self.clock:
            raise ValueError("real clock endpoint changed during callback")
        if self._state_fn(self.guard) != self.anchor or self._module_fn(self.module) != self.module_anchor:
            raise ValueError("caller or semantics binding changed during callback")
        if self.clock() >= self.deadline:
            raise TimeoutError("whole unrelated controls final boundary unresolved")


def boundary_case(module, wire, deadline, measured_call):
    """Explicitly NONLOGICAL invented callback mutations, restored finally."""
    token = object()

    def callback(marker=token, *, keyword=token):
        if token is marker and keyword is token:
            return None
        return None

    def replacement(marker=token, *, keyword=token):
        if token is marker and keyword is token:
            return False
        return False

    original_code, original_defaults, original_kwdefaults = callback.__code__, callback.__defaults__, callback.__kwdefaults__
    original_cells = tuple(cell.cell_contents for cell in callback.__closure__ or ())
    operation = wire["operation"]
    kwargs = {"source_guard": callback, "deadline": deadline}
    if operation == "expired_deadline":
        kwargs["deadline"] = time.perf_counter() - 1.0
    elif operation == "invalid_deadline":
        kwargs["deadline"] = wire["deadline_literal"]
    if "maximum_visits" in wire:
        kwargs["maximum_visits"] = wire["maximum_visits"]
    boundary = None
    try:
        boundary = measured_call("Boundary.__init__", module.Boundary, **kwargs)
        if operation == "callback_code":
            callback.__code__ = replacement.__code__
        elif operation == "callback_defaults":
            callback.__defaults__ = (object(),)
        elif operation == "callback_kwdefaults":
            callback.__kwdefaults__ = {"keyword": object()}
        elif operation == "callback_closure":
            need(callback.__closure__, "invented callback has an actual closure")
            callback.__closure__[0].cell_contents = object()
        elif operation == "callback_identity":
            boundary.guard = replacement
        if operation == "visit_exhaustion":
            count = wire["tick_count"]
            need(type(count) is int and count == 2, "literal bounded tick control")
            for _ in range(count):
                measured_call("Boundary.tick", boundary.tick)
        else:
            measured_call("Boundary.check", boundary.check)
        return {"nonlogical_boundary_completed": True}
    finally:
        callback.__code__, callback.__defaults__, callback.__kwdefaults__ = original_code, original_defaults, original_kwdefaults
        for cell, value in zip(callback.__closure__ or (), original_cells):
            cell.cell_contents = value
        if boundary is not None:
            boundary.guard = callback


def check_word_record(record, fixture):
    """Saved full certificate fields against literal input/expectation data."""
    need(type(record) is dict and record.get("schema") == "independent-Q-primitive-word-certificate-v1"
         and record.get("completed") is True and record.get("original_Gamma_target_sequent_accepted") is True,
         "complete arbitrary-word certificate, no prefix")
    wire, expected = fixture["wire"], fixture["expected"]
    for name, original in (("original_ordered_Gamma", wire["original_Gamma"]),
                           ("parameters", wire["parameters"]), ("target", wire["target"]),
                           ("consumed_original_occurrence_indices", expected["consumed_original_occurrence_indices"]),
                           ("essential_rows", expected["essential_rows"])):
        need(canonical(record[name]) == canonical(original), "literal original occurrence/target/ancestry: " + name)
    need(record["theory_sha256"] == sha(wire["theory"]) and record["commands_sha256"] == sha(wire["commands"]),
         "complete original theory/word hashes")
    rows = record["rows"]
    need(type(rows) is list and len(rows) == len(wire["commands"]), "all commanded rows retained")
    for ordinal, (row, command, refs) in enumerate(zip(rows, wire["commands"], expected["ordered_prior_rows"])):
        need(type(row) is dict and set(row) == {"row", "rule", "formula_sha256", "ordered_prior_rows"}
             and type(row["row"]) is int and row["row"] == ordinal and row["rule"] == command["rule"]
             and row["formula_sha256"] == sha(command["formula"])
             and canonical(row["ordered_prior_rows"]) == canonical(refs), "full ordered row formula/ports")
    for flag in ("native_accepted", "full24_accepted", "current_state_point_union_accepted",
                 "full_trajectory_accepted", "induction_accepted", "full_PA_accepted",
                 "universal_compiler_accepted", "ROOT_resource_accepted"):
        need(record[flag] is False, "tiny word control does not grant stronger authority")


def run_unrelated_word_controls(*, semantics_module, fixture_document,
                               expected_semantics_source, expected_fixture_source,
                               source_guard, deadline):
    """Future callable only: all literal cases, one clock, no semantic model.

    The worker must authenticate both complete raw buffers and this callable;
    the exact expected pin arguments merely close the declared API. No Source
    claim, fake module or code filename is an admitted load by itself.
    """
    began = time.perf_counter()
    gate = Gate(semantics_module, source_guard, deadline)
    need(canonical(expected_semantics_source) == canonical(SEMANTICS_SOURCE)
         and canonical(expected_fixture_source) == canonical(FIXTURE_SOURCE), "exact declared Source/fixture pins")
    need(semantics_module.VERSION == SEMANTICS_VERSION, "exact independent checker protocol")
    checker = semantics_module.check_primitive_word
    need(type(checker) is types.FunctionType and checker.__globals__ is vars(semantics_module),
         "actual checker in the admitted module namespace")
    plain(fixture_document)
    original_document_text = canonical(fixture_document)
    need(sha(fixture_document) == FIXTURE_VALUE_SHA256, "whole literal fixture value, no subset/extra case")
    fixtures = json.loads(original_document_text)
    need(type(fixtures) is dict and fixtures["schema"] == "complete-unrelated-six-rule-word-fixture-declaration-v1"
         and type(fixtures["fixtures"]) is list and fixtures["fixtures"], "entire literal fixture declaration")
    ids = [f["id"] for f in fixtures["fixtures"]]
    need(len(set(ids)) == len(ids), "all unique fixture identities")
    results, call_tape = [], []

    def guarded_source():
        gate.check()

    def measured_call(label, function, **kwargs):
        gate.check()
        entry = {"call_index": len(call_tape), "API": label, "started": True,
                 "returned": False, "raised": None, "seconds": None}
        call_tape.append(entry)
        start = time.perf_counter()
        try:
            result = function(**kwargs)
            entry["returned"] = True
            return result
        except (ValueError, semantics_module.Unresolved) as error:
            entry["raised"] = type(error).__name__
            raise
        finally:
            entry["seconds"] = time.perf_counter() - start
            gate.check()

    for literal_fixture in fixtures["fixtures"]:
        gate.check()
        fixture = json.loads(canonical(literal_fixture))
        preimage = canonical(fixture)
        expected = fixture["expected"]
        result, error_type, message = None, None, None
        try:
            if fixture["api"] == "check_primitive_word":
                wire = fixture["wire"]
                result = measured_call("check_primitive_word", checker, **wire,
                                       source_guard=guarded_source, deadline=deadline, maximum_visits=5000000)
            else:
                need(fixture["api"] == "Boundary", "declared exact control API")
                result = boundary_case(semantics_module, fixture["wire"], deadline, measured_call)
        except (ValueError, semantics_module.Unresolved) as error:
            error_type, message = type(error).__name__, str(error)
        gate.check()
        need(canonical(fixture) == preimage, "fixture/theory/Gamma/word data unchanged after actual call")
        if expected["status"] == "accept":
            need(error_type is None, "declared positive control failed: " + fixture["id"])
            if fixture["api"] == "check_primitive_word":
                check_word_record(result, fixture)
        else:
            need(error_type == expected["exception"] and expected["message_contains"] in (message or ""),
                 "declared rejection mechanism differs: " + fixture["id"])
            need(result is None, "rejected control has no certificate/prefix")
        results.append({"id": fixture["id"], "category": fixture["category"], "api": fixture["api"],
            "expected": expected, "all_checks_passed": True, "error_type": error_type,
            "message": message, "complete_positive_record": result,
            "literal_fixture_sha256": sha(literal_fixture)})
    need(canonical(fixture_document) == original_document_text, "original whole caller fixture data unchanged")
    record = {"schema": "unrelated-six-rule-word-boundary-controls-result-v1", "completed": True,
        "all_checks_passed": True, "fixture_source": FIXTURE_SOURCE, "semantics_source": SEMANTICS_SOURCE,
        "fixture_value_sha256": FIXTURE_VALUE_SHA256, "results": results, "call_tape": call_tape,
        "actual_started_calls": len(call_tape), "actual_returned_calls": sum(x["returned"] for x in call_tape),
        "actual_exception_calls": sum(x["raised"] is not None for x in call_tape),
        "call_unit": "actual API invocations; nested inclusive durations must not be added to whole wall time",
        "elapsed_seconds_before_final_hash_and_guard": time.perf_counter() - began,
        "Q_target_proof_discovered": False, "target_searches": 0, "rank_computations": 0,
        "current_point_union_accepted": False, "catalogue_admitted": False, "pruning_admitted": False,
        "full24_accepted": False, "native_accepted": False, "full_trajectory_accepted": False,
        "induction_accepted": False, "full_PA_accepted": False, "RL_runs": 0,
        "ROOT_resource_accepted": False, "partial_result_returned": False}
    record["result_value_sha256"] = sha(record)
    canonical(record)
    gate.check()
    return record
