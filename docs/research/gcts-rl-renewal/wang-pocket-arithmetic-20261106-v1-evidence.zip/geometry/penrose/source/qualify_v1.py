"""Replay mandatory Penrose pocket cuts and the pooled area control."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cases_v1 import frozen
from cavity_audit_v1 import normalized,verify_cut
from cavity_experiment_v1 import load_cases
from cavity_pilot_v1 import sealed
from geometry_v1 import Penrose, add
from check_v1 import contact


def read(path):
    return json.loads((ROOT/path).read_text())


def main():
    g=Penrose()
    rows={r["id"]:r for r in load_cases()}
    search=read("data/cavity-search-v1.json")
    pilot=read("data/cavity-pilot-v1.json")
    qualified=[]
    for name,case,template in (
        ("penrose-regular","fixed-sealed-0",pilot["witness"]["cavities"][0]),
        ("penrose-concave","fixed-concave-0",pilot["alternative"]["examples"][0]["cycle"])
    ):
        event=next(e for e in search["proof"]["learned_events"] if e["case"]==case)
        verify_cut(g,rows[case],event)
        assert normalized(frozen(event["cycle"]))==normalized(frozen(template))
        qualified.append(dict(id=name,source=case,cycle=template,display_cycle=event["cycle"],
                              display_tiles=[g.poly(t) for t in frozen(event["path"])],area_twice=event["area_twice"],
                              status="CHECKED_REQUIRED_PENROSE_POCKET"))
    controls=pilot["witness"]
    a,b=frozen(controls["patches"])
    left,right=frozen(controls["cavities"])
    assert all(contact(x,y) for x in a for y in b)
    area=add(sealed(g,a,left),sealed(g,b,right))
    assert g.counts(area)==tuple(controls["joint_mass"])
    qualified.append(dict(id="penrose-pooled-control",cycles=(left,right),area_twice=area,
                          status="CHECKED_SEPARATE_POCKETS"))
    print(json.dumps(qualified))


if __name__=="__main__":
    main()
