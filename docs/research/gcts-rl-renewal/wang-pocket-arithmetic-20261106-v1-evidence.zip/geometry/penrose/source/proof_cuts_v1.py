"""Require a checked arithmetic record on each Penrose cavity cut."""
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
PILOT=ROOT.parents[1]
sys.path.insert(0,str(ROOT/"source"))
sys.path.append(str(PILOT/"source"))
from boundary_search_v1 import Inventory
from cavity_experiment_v1 import load_cases, run
from cavity_marks_v1 import CavityBank
from geometry_v1 import Penrose
from logical_projection_v1 import verify
from pocket_arithmetic_v1 import statement


class ProofBank(CavityBank):
    def __init__(self):
        super().__init__()
        self.lemmas={}
        self.uses=[]

    def cut(self,region,core,frontier,path,case,stats):
        if not super().cut(region,core,frontier,path,case,stats):
            return False
        event=self.events[-1]
        area=event["area_twice"]
        coordinate=next(i for i,x in enumerate(area) if x>0 and x%2)
        claim=statement(2,area[coordinate])
        label=claim["id"]
        reused=label in self.lemmas
        if not reused:
            raw=(PILOT/"data"/f"{label}-logical-v1.json").read_bytes()
            receipt=verify(claim,json.loads(raw))
            self.lemmas[label]=dict(sha256=sha256(raw).hexdigest(),receipt=receipt)
        self.uses.append(dict(case=case,coordinate=coordinate,lemma=label,reuse=reused,
                              area_twice=area,mark=event["mark"]))
        return True


def main():
    previous=json.loads((ROOT/"data/cavity-search-v1.json").read_text())
    expected={r["id"]:r["arms"]["learned"] for r in previous["results"]}
    g=Penrose()
    inv=Inventory(g)
    bank=ProofBank()
    matched=[]
    for case in load_cases():
        result=run(g,inv,case,bank)
        assert json.loads(json.dumps(result))==expected[case["id"]]
        matched.append(case["id"])
    assert json.loads(json.dumps(bank.events))==previous["proof"]["learned_events"]
    assert len(bank.lemmas)==1 and len(bank.uses)==20
    assert sum(e["reuse"] for e in bank.uses)==19
    print(json.dumps(dict(status="CHECKED_ARITHMETIC_AT_SEARCH_CUTS",matched=matched,
                          lemmas=bank.lemmas,uses=bank.uses)))


if __name__=="__main__":
    main()
