"""Replay the sealed Turtle core before importing its area."""
from collections import defaultdict
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model, load
from collar_audit_v1 import Audit, exposed, freeze
from golden_geometry_v1 import area2


def signed(edges):
    return sum(x*v-y*u for (x,y),(u,v) in edges)


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    audit=Audit(model)
    result=freeze(load("data/strip-receiver-two-v1.json"))
    branch,=tuple(b for b in result["branches"] if len(b["incoming"])==18)
    witness=branch["cap_obstructions"][0]
    tiles=tuple(sorted(t for p in witness["pieces"] for t in p))
    assert len(tiles)==len(set(tiles))
    buckets=defaultdict(list)
    pairs=0
    for i,(g,x,y) in enumerate(tiles):
        a,b,c,d=audit.box[g]
        keys=[(u,v) for u in range((a+x)//8,(b+x)//8+1)
              for v in range((c+y)//8,(d+y)//8+1)]
        earlier=set().union(*(buckets[key] for key in keys))
        for j in earlier:
            assert not audit.overlap(tiles[i],tiles[j])
        pairs+=len(earlier)
        for key in keys:
            buckets[key].append(i)
    boundary=exposed(model.poly(t) for t in tiles)
    cycles=witness["cycles"]
    assert all(all(c[i-1][1]==p for i,(p,q) in enumerate(c)) for c in cycles)
    assert boundary=={edge for c in cycles for edge in c} and len(boundary)==sum(map(len,cycles))
    assert len({p for p,q in boundary})==len(boundary)==len({q for p,q in boundary})
    assert sum(signed(c)>0 for c in cycles)==1
    hole=next(c for c in cycles if signed(c)<0)
    assert -signed(hole)%area2(model.polygons[0])
    rim=set(hole)
    neighbors=[poly for t in tiles for poly in (model.poly(t),) if exposed([poly])&rim]
    assert rim<=set().union(*(exposed([poly]) for poly in neighbors))
    print(json.dumps(dict(status="CHECKED_SEALED_TURTLE",tiles=len(tiles),tested_pairs=pairs,
        cycle=[a for a,b in hole],display_tiles=neighbors,tile_area_twice=area2(model.polygons[0]),
        pocket_area_twice=-signed(hole))))


if __name__=="__main__":
    main()
