"""Render checked geometric inputs and Wang arithmetic records."""
from html import escape
import json
from math import cos,pi,sin,sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from proof_views_v1 import clause, explanation, formula, math, window_svg
from boundary_kernel_v1 import build


def read(path):
    return json.loads((ROOT/path).read_text())


def table(headers,rows):
    heads="".join(f"<th>{h}</th>" for h in headers)
    body="".join(f'<tr><th scope="row">{a}</th>'+"".join(f"<td>{b}</td>" for b in rest)+"</tr>"
                 for a,*rest in rows)
    return f'<div class="table"><table><thead><tr>{heads}</tr></thead><tbody>{body}</tbody></table></div>'


def pocket(kind,row,title):
    def project(point):
        if kind=="turtle":
            x,y=point
            return x+y/2,-sqrt(3)*y/2
        return (sum(x*cos(2*pi*i/5) for i,x in enumerate(point)),
                -sum(x*sin(2*pi*i/5) for i,x in enumerate(point)))

    shapes=[(tuple(map(project,t)),"rim-tile") for t in row["display_tiles"]]
    shapes.append((tuple(map(project,row.get("display_cycle",row["cycle"]))),"pocket"))
    x,y=zip(*(p for shape,_ in shapes for p in shape))
    l,b=min(x),min(y)
    w,h=max(x)-l,max(y)-b
    p=.14*max(w,h)
    view=f"{l-p:.4f} {b-p:.4f} {w+2*p:.4f} {h+2*p:.4f}"
    polygons=[]
    for points,kind in shapes:
        coords=" ".join(f"{a:.4f},{c:.4f}" for a,c in points)
        polygons.append(f'<polygon points="{coords}" class="{kind}"/>')
    return (f'<figure><svg class="frame" role="img" aria-label="{title}" viewBox="{view}">'
            f'{"".join(polygons)}</svg><figcaption>{title}</figcaption></figure>')


def proof_view(title,original,bundle):
    hypotheses="".join(f"<li>{math(formula(x))}</li>" for x in original["premises"])
    rows=[]
    for i,(line,call) in enumerate(zip(bundle["proof"]["lines"],bundle["calls"],strict=True),1):
        fragment=bundle["records"][call["fragment"]]
        code=escape(fragment["prefix"]+"\n"+fragment["word"])
        rows.append((i,explanation(line),math(clause(line["clause"])),
                     f'<details><summary>Record</summary><code class="record">{code}</code></details>'))
    details=f'<details><summary>Read all {len(rows)} lines</summary>'+table(
        ("Line","Reading","Formula","Boundary and record"),rows)+"</details>"
    return (f'<div class="proof"><h3>{title}</h3><p class="goal">Goal {math(formula(original["goal"]))}</p>'
            f'<details><summary>Original assumptions</summary><ol>{hypotheses}</ol></details>{details}</div>')


def main():
    geometry=read("data/geometry-binding-v1.json")
    raw=(("turtle",geometry["turtle"],"Turtle cavity"),
         ("penrose",geometry["penrose"][0],"Regular Penrose cavity"),
         ("penrose",geometry["penrose"][1],"Concave Penrose cavity"))
    pockets='<div class="pockets">'+"".join(pocket(*row) for row in raw)+"</div>"
    spine=read("data/arithmetic-spine-summary-v1.json")
    cases=((2,1),(2,3),(5,9))
    proofs=[]
    sizes=[]
    for (a,b),row in zip(cases,spine,strict=True):
        key=row["case"]
        original=read(f"input/coefficient-{a}-{b}.json")
        bundle=read(f"data/{key}-logical-v1.json")
        proofs.append(proof_view(f"Coefficient {b} in steps of {a}",original,bundle))
        sizes.append((f"{a} and {b}",f'{(ROOT/"data"/row["artifact"]).stat().st_size:,}',
                      f'{(ROOT/"data"/f"{key}-logical-v1.json").stat().st_size:,}'))
    lemmas=table(("Multiplier","Coefficient","Ground instances selected","Proof lines"),
        [(a,b,s["search"]["selected"],s["receipt"]["fragment_calls"]) for (a,b),s in zip(cases,spine,strict=True)])
    source=read("data/peano-spine-2-1-v1.json")
    trace=source["traces"][source["calls"][-1]["fragment"]]
    machine=build().compile()
    assert machine.digest()==source["machine_sha256"]
    frame=dict(prefix=trace["prefix"],word=trace["word"],padding=0,trace=trace["fragment"])
    svg,caption=window_svg(machine,frame,(trace["steps"]-5,trace["head"]))
    tiles=f"<figure>{svg}<figcaption>{caption}</figcaption></figure>"
    residue=[]
    for key,title in (("turtle-pocket","Turtle residue"),("penrose-regular","Regular Penrose residue"),
                      ("penrose-concave","Concave Penrose residue")):
        residue.append(proof_view(title,read(f"input/{key}-fol-v1.json"),read(f"data/{key}-records-v1.json")))
    sizes=table(("Multiplier and coefficient","Full JSON bytes","Logical record JSON bytes"),sizes)
    text=(ROOT/"publication/notebook-v1.html").read_text()
    for name,value in dict(POCKETS=pockets,LEMMA_TABLE=lemmas,TILES=tiles,PROOFS="".join(proofs),SIZES=sizes,
                           RESIDUE_PROOFS="".join(residue)).items():
        text=text.replace(f"%%{name}%%",value)
    assert "%%" not in text
    (ROOT/"report/wang-pocket-arithmetic-20261106-v1.html").write_text(text)


if __name__=="__main__":
    main()
