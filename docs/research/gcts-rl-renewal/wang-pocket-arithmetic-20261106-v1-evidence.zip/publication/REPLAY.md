# Replay the sealed-pocket proof notebook

Use Python 3.10 or newer with assertions enabled. The recorded replay used Python 3.12 and the standard library.

```sh
python3 -I -S -B publication/replay_v1.py
```

The replay verifies the pinned Turtle and Penrose boundary witnesses in isolated geometry modules. It then reconstructs the finite residue formulas, searches for their proofs, checks a countermodel of the pooled-area argument, searches for the first-order successor lemmas, and independently checks the resulting Wang fragments. It exports the compact records, replays the earlier Penrose search with a proof attached to each cut, exercises the public command line, and regenerates the notebook. The full replay can take several minutes.

To verify a compact proof without rebuilding its transition witness, run:

```sh
python3 -I -S -B source/logical_records_cli_v1.py verify input/coefficient-5-9.json data/area-coefficient-5-9-logical-v1.json
```

To check the full sparse Wang transitions on the same proof, run:

```sh
python3 -I -S -B source/shared_wang_v1.py verify input/coefficient-5-9.json data/peano-spine-5-9-v1.json
```

The compact mode checks the original formula, dependency graph and decoded proof records. The full mode additionally replays the local transitions of the shared translation-only Wang palette. The two modes have separate certificate formats.

The browser audit uses `node publication/check_v1.cjs` with Playwright and Chromium.
