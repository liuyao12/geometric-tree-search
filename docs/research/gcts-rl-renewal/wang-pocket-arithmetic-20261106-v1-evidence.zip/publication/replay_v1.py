"""Rebuild the exact geometry bindings, Wang certificates and HTML reader."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]
STEM="wang-pocket-arithmetic-20261106-v1"
STAGES=("source/pocket_arithmetic_v1.py","source/bind_geometry_v1.py","source/area_residue_wang_v1.py",
        "source/area_residue_audit_v1.py","source/arithmetic_spine_v1.py","source/logical_projection_v1.py",
        "source/spine_transfer_v1.py","source/run_proof_cuts_v1.py","source/records_cli_audit_v1.py","publication/render_v1.py")
EXAMPLES=("turtle-pocket","penrose-regular","penrose-concave")
PAIRS=((2,1),(2,3),(5,9))
OUTPUTS=tuple(f"input/coefficient-{a}-{b}.json" for a,b in PAIRS)+tuple(
    f"input/{name}-fol-v1.json" for name in (*EXAMPLES,"penrose-pooled-control"))+tuple(
    f"data/{name}-{kind}-v1.json" for name in EXAMPLES for kind in ("wang","records"))+tuple(
    f"data/peano-spine-{a}-{b}-v1.json" for a,b in PAIRS)+tuple(
    f"data/area-coefficient-{a}-{b}-logical-v1.json" for a,b in PAIRS)+tuple(
    f"data/{name}-v1.json" for name in ("geometry-binding","residue-summary","residue-audit",
      "arithmetic-spine-summary","logical-projection","spine-transfer","proof-cuts","records-cli"))+(
    f"report/{STEM}.html",)


def pin(raw):
    return dict(bytes=len(raw),sha256=sha256(raw).hexdigest())


def sources():
    lookup={p.stem:p for directory in ("source","publication") for p in (ROOT/directory).glob("*.py")}
    queue=[ROOT/p for p in STAGES]+[ROOT/"source/logical_records_cli_v1.py"]
    seen=set()
    while queue:
        path=queue.pop()
        if path in seen:
            continue
        seen.add(path)
        for entry in ast.walk(ast.parse(path.read_text())):
            if isinstance(entry,ast.Import):
                queue.extend(lookup[n.name] for n in entry.names if n.name in lookup)
            elif isinstance(entry,ast.ImportFrom) and entry.module in lookup:
                queue.append(lookup[entry.module])
    return sorted(str(p.relative_to(ROOT)) for p in seen)


def inputs():
    geometry=sorted(str(p.relative_to(ROOT)) for p in (ROOT/"geometry").rglob("*")
                    if p.is_file() and p.suffix in (".py",".json"))
    return tuple(sources())+tuple(geometry)+tuple(f"input/{name}-v1.json" for name in
       ("geometry-pins","measured-pockets","tactic-policy"))+("publication/notebook-v1.html",)


def main():
    with TemporaryDirectory() as scratch:
        clean=Path(scratch)
        for d in ("data","input","source","publication","report"):
            (clean/d).mkdir()
        for path in inputs():
            (clean/path).parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(ROOT/path,clean/path)
        for stage in STAGES:
            subprocess.run([sys.executable,"-I","-S","-B",stage],cwd=clean,check=True)
        receipt={}
        for path in OUTPUTS:
            raw=(clean/path).read_bytes()
            assert raw==(ROOT/path).read_bytes(),path
            receipt[path]=pin(raw)
    value=dict(status="MATCHED_CLEAN_REPLAY",python=list(sys.version_info[:3]),outputs=receipt,stages=STAGES)
    (ROOT/"publication/replay-v1.json").write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")
    print("Matched",len(receipt),"generated artifacts byte for byte.",flush=True)


if __name__=="__main__":
    main()
