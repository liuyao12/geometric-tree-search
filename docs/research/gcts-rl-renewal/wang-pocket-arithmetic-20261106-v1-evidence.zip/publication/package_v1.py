"""Pin the notebook and package its complete geometry and proof evidence."""
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0,str(Path(__file__).resolve().parent))
from replay_v1 import OUTPUTS, ROOT, STEM, inputs, pin


def load(name):
    return json.loads((ROOT/name).read_text())


def save(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")


def main():
    report=ROOT/"report"
    replay=load("publication/replay-v1.json")
    assert set(replay["outputs"])==set(OUTPUTS)
    for name,expected in replay["outputs"].items():
        assert pin((ROOT/name).read_bytes())==expected
    summary=f"report/{STEM}-results.json"
    science=("geometry-binding","residue-summary","residue-audit","arithmetic-spine-summary",
             "logical-projection","spine-transfer","proof-cuts","records-cli")
    save(summary,dict(schema="WANG-POCKET-ARITHMETIC-RESULTS-v1",replay=replay,
         reader=load("publication/browser-v1.json"),inputs=load("input/geometry-pins-v1.json"),
         **{name.replace("-","_"):load(f"data/{name}-v1.json") for name in science}))
    names=list((*inputs(),*OUTPUTS,summary))
    names.extend(str(p.relative_to(ROOT)) for p in sorted((ROOT/"data").glob("*.log")))
    names.extend(f"publication/{name}" for name in ("REPLAY.md","replay_v1.py","replay-v1.json",
          "browser-v1.json","package_v1.py","check_v1.cjs","tile-window-v1.png"))
    archive=report/f"{STEM}-evidence.zip"
    pins={}
    with ZipFile(archive,"w") as bundle:
        for name in names:
            path=ROOT/name
            raw=path.read_bytes()
            if path.suffix!=".png":
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)",raw),name
            assert name not in pins
            pins[name]=pin(raw)
            item=ZipInfo(name,(2026,11,6,0,0,0))
            item.external_attr=0o100644<<16
            bundle.writestr(item,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {p:pin(bundle.read(p)) for p in bundle.namelist()}==pins
    assets={p.name:pin(p.read_bytes()) for p in (report/f"{STEM}.html",ROOT/summary,archive)}
    save(f"report/{STEM}-manifest.json",dict(schema="WANG-POCKET-ARITHMETIC-MANIFEST-v1",
                                            assets=assets,archive_entries=pins))
    print(json.dumps(dict(assets=assets,entries=len(pins)),indent=2))


if __name__=="__main__":
    main()
