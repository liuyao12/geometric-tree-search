const assert=require("node:assert/strict");
const path=require("node:path");
const {pathToFileURL}=require("node:url");
const fs=require("node:fs");

async function main(){
  const {chromium}=require(process.env.GCTS_PLAYWRIGHT||"playwright");
  const browser=await chromium.launch({executablePath:process.env.GCTS_CHROME,
    args:["--disable-breakpad","--disable-background-networking"]});
  try {
    const page=await browser.newPage({viewport:{width:1180,height:900}});
    const issues=[];
    page.on("pageerror",error=>issues.push(error.message));
    const local=pathToFileURL(path.join(__dirname,"../report/wang-pocket-arithmetic-20261106-v1.html")).href;
    const result=await page.goto(process.argv[2]||local,{waitUntil:"commit",timeout:60000});
    if(process.argv[2]) assert.equal(result.status(),200);
    await page.waitForFunction(()=>document.querySelector("#lemmas mjx-container"),null,{timeout:60000});
    assert.equal(await page.locator("#tiles .wang-cell").count(),45);
    assert.equal(await page.locator("#geometry figure").count(),3);
    assert.equal(await page.locator("#proofs .proof").count(),6);
    assert.equal(await page.locator("#proofs tbody tr").count(),366);
    await page.locator("#proofs .proof").first().locator("summary", {hasText:"Read all"}).click();
    await page.locator("#proofs tbody tr").first().locator("summary").click();
    assert(await page.locator("#proofs tbody tr").first().locator("code").last().isVisible());
    if(!process.argv[2]) await page.locator("#tiles figure").screenshot({path:path.join(__dirname,"tile-window-v1.png")});
    await page.setViewportSize({width:390,height:844});
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(),0);
    assert.deepEqual(issues,[]);
    const receipt={status:"CHECKED_POCKET_ARITHMETIC_READER",pockets:3,proofs:6,lines:366,wangSquares:45,
      mobileNoOverflow:true,mathTypeset:true};
    fs.writeFileSync(path.join(__dirname,process.argv[2]?"browser-live-v1.json":"browser-v1.json"),
      JSON.stringify(receipt,null,2)+"\n");
    console.log(JSON.stringify(receipt));
  }finally{await browser.close();}
}

main().catch(error=>{console.error(error);process.exitCode=1;});
