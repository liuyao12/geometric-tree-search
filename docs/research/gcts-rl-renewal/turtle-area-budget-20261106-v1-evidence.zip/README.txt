Move the turtle boundary while keeping the tile count

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/area_study_v1.py
  python3 -I -S -B publication/render_v1.py

The first command reruns all requests, checks the frontier and cutoff,
and compares the leaf-clipping control. Add --build to regenerate its
data. The second command regenerates the notebook. The included atlas rule
and model are the inputs from the certified turtle boundary study.
The manifest gives SHA-256 for each included input and result.
