"""Render the movable-boundary study and selectable exact-cover examples."""
from fractions import Fraction
import json
from math import sqrt
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from area_study_v1 import load

NAME = "turtle-area-budget-20261106-v1"
TITLE = "Move the turtle boundary while keeping the tile count"
LABELS = {
    "parallelogram": "Small parallelogram",
    "concave-notch": "Concave notch",
    "two-holes": "Two interior holes",
    "diagonal-strip": "Diagonal strip",
    "medium-window": "Medium window",
    "wide-window": "Wide window",
    "distant-window": "Distant window",
    "empty-budget": "Zero tiles",
    "interior-budget": "Five interior tiles",
    "padding-budget": "Thirteen tiles with padding",
}
VIEWS = ("two-holes", "concave-notch", "parallelogram")


def math(value):
    return r"\(" + value + r"\)"


def ratio(value, tile_area):
    r = Fraction(value, tile_area)
    return math(str(r.numerator) if r.denominator == 1 else rf"\frac{{{r.numerator}}}{{{r.denominator}}}")


def draw(p):
    x, y = p
    return x + y / 2, -sqrt(3) * y / 2


def points(ring):
    return " ".join(f"{x:.3f},{y:.3f}" for x, y in map(draw, ring))


def view(atlas, row):
    out = row["result"]
    level, turn = out["root"]
    atlas.h.ensure(level)
    root = (("T", level), turn, (0, 0))
    selected = {p for path in out["selected"] for p in atlas.tiles(atlas.at(root, path))}
    tiles = {}
    for path, mark, _ in out["frontier"]:
        if mark != "E":
            for p in atlas.tiles(atlas.at(root, path)):
                assert p not in tiles
                tiles[p] = mark == "F"
    assert selected <= tiles.keys()
    polys = {p: atlas.h.model.poly(p) for p in tiles}
    coordinates = [draw(v) for poly in [row["outer"], *polys.values()] for v in poly]
    low = [min(q) - 2 for q in zip(*coordinates)]
    high = [max(q) + 2 for q in zip(*coordinates)]
    viewbox = " ".join(f"{q:.3f}" for q in (*low, high[0] - low[0], high[1] - low[1]))
    rings = [points(r) for r in (row["outer"], *row["holes"])]
    boundary = " ".join("M" + r + "Z" for r in rings)
    lines = []
    for p in sorted(tiles):
        shape = "full" if tiles[p] else "kept" if p in selected else "skipped"
        lines.append(f'<polygon class="{shape}" points="{points(polys[p])}"/>')
    tag = row["name"]
    visible = "" if tag == VIEWS[0] else " hidden"
    ranked = out["target_count"]
    inside = sum(tiles.values())
    outside = len(tiles)
    count = f'<p class="mode-count" data-inner="{inside}" data-outer="{outside}" data-ranked="{ranked}"></p>'
    return (f'<article class="window" data-name="{tag}"{visible}>'
            f'<svg viewBox="{viewbox}" role="img" aria-label="{LABELS[tag]} with whole turtle tiles">'
            f'<path class="backdrop" d="{boundary}"/><g>{"".join(lines)}</g><path class="boundary" d="{boundary}"/>'
            f'</svg>{count}</article>')


def main():
    data = json.loads((ROOT / "data/area-study-v1.json").read_text())
    atlas = load()
    rows = {r["name"]: r for r in data["requests"]}
    table = []
    for name, row in rows.items():
        o = row["result"]
        c = o["stats"]
        leaf = f'{row["leaf_control"]["clipped"]:,}' if row["leaf_control"] else "—"
        err = ratio(Fraction(*o["error"]), o["tile_area"])
        table.append(f'<tr><th scope="row">{LABELS[name]}</th><td>{o["target_count"]:,}</td>'
                     f'<td>{c.get("cut", 0):,}</td><td>{row["audit"]["selected_records"]:,}'
                     f'</td><td>{c["clipped"]:,}</td><td>{leaf}</td><td>{err}</td></tr>')
    wide = rows["wide-window"]
    values = dict(title=TITLE, stem=NAME, table="".join(table),
                  cutoff=ratio(Fraction(wide["audit"]["min_selected"]), atlas.area),
                  rejected=ratio(Fraction(wide["audit"]["max_rejected"]), atlas.area),
                  options="".join(f'<option value="{n}">{LABELS[n]}</option>' for n in VIEWS),
                  views="".join(view(atlas, rows[n]) for n in VIEWS))
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    head = head.replace("</style>", """
.control{margin:1rem 0}.window[hidden]{display:none}
.window svg{width:100%;max-height:34rem;background:#f8fbfc}
.window polygon{stroke:#5b736d;stroke-width:.14;stroke-linejoin:round}
.window .full{fill:#80c09d}.window .kept{fill:#96cbe1}.window .skipped{fill:#ecc693;display:none}
#viewer[data-mode=inner] .kept{display:none}#viewer[data-mode=outer] .skipped{display:block}
.window .boundary{fill:none;stroke:#714813;stroke-width:.44;stroke-dasharray:1.1 .7;stroke-linejoin:round}
.window .backdrop{fill:#f2e8da;fill-rule:evenodd}.mode-count{font-weight:650}
.key{display:flex;flex-wrap:wrap;gap:.8rem}.key span:before{content:"";display:inline-block;width:1rem;height:.8rem;margin-right:.3rem;border:1px solid #5b736d}
.key .in:before{background:#80c09d}.key .cut:before{background:#96cbe1}.key .extra:before{background:#ecc693}
</style>""")
    body = (ROOT / "publication/area-body-v1.html").read_text()
    for key, value in values.items():
        body = body.replace("%%" + key.upper() + "%%", value)
    assert "%%" not in body
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
