const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/turtle-area-budget-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#proof mjx-container").first().waitFor();
      const visible = page.locator(".window:visible");
      assert.equal(await visible.locator("polygon:visible").count(), 140);
      assert.equal(await visible.locator(".boundary").evaluate(node => node.getBBox().width > 0), true);
      await page.selectOption("#mode", "inner");
      assert.equal(await visible.locator("polygon:visible").count(), 93);
      await page.selectOption("#mode", "outer");
      assert.equal(await visible.locator("polygon:visible").count(), 181);
      await page.selectOption("#shape", "concave-notch");
      await page.selectOption("#mode", "ranked");
      assert.equal(await visible.locator("polygon:visible").count(), 78);
      assert.match(await visible.locator(".mode-count").textContent(), /78 whole tiles/);
      assert.equal(await page.locator("#comparison tbody tr").count(), 10);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth), width);
      assert.deepEqual(errors, []);
      console.log("Verified", width, "px, both holes and cover switching.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
