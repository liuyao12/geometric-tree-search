"""Verify frontier coverage and the score threshold with separate geometry."""
from collections import Counter
from fractions import Fraction

from area_rank_v1 import cross, rect_of
from geometry_v1 import pairs
from triangle_geometry_v1 import area2
from window_v1 import squared_norm


def determinant(a, b):
    return a[0] * b[1] - a[1] * b[0]


def delta(a, b):
    return a[0] - b[0], a[1] - b[1]


def line_crossing(a, b, c, d):
    u, v, gap = delta(b, a), delta(d, c), delta(c, a)
    scale = determinant(u, v)
    if not scale:
        return None
    s, t = determinant(gap, v), determinant(gap, u)
    if scale < 0:
        scale, s, t = -scale, -s, -t
    if 0 <= s <= scale and 0 <= t <= scale:
        f = Fraction(s, scale)
        return a[0] + f * u[0], a[1] + f * u[1]
    return None


def hull_side(points):
    stack = []
    for p in points:
        while len(stack) >= 2 and cross(stack[-2], stack[-1], p) <= 0:
            stack.pop()
        stack.append(p)
    return stack[:-1]


def intersection(a, b):
    """Convex intersection vertices from containment and edge intersections."""
    edges_a, edges_b = tuple(pairs(a)), tuple(pairs(b))
    points = {p for p in a if all(cross(x, y, p) >= 0 for x, y in edges_b)}
    points.update(p for p in b if all(cross(x, y, p) >= 0 for x, y in edges_a))
    points.update(p for x, y in edges_a for u, v in edges_b
                  if (p := line_crossing(x, y, u, v)) is not None)
    order = sorted(points)
    if len(order) < 3:
        return 0
    hull = hull_side(order) + hull_side(reversed(order))
    return area2(hull) if len(hull) >= 3 else 0


def verify(atlas, region, result):
    level, turn = result["root"]
    root = (("T", level), turn, (0, 0))
    atlas.h.ensure(level)
    assert level >= 5 and level % 2 and turn == (6 if ((level - 1) // 2) % 2 else 0)
    assert all(squared_norm(p) < atlas.h.disk(level)**2 for p in region.outer)
    assert (result["region_area"], result["tile_area"]) == (region.area, atlas.area)
    frontier = {tuple(path): (mark, Fraction(*score)) for path, mark, score in result["frontier"]}
    assert len(frontier) == len(result["frontier"])
    verified = {}
    counts = Counter()
    pending = [((), root)]
    while pending:
        path, ref = pending.pop()
        if path not in frontier:
            assert ref[0] is not None
            pending.extend(((*path, i), child) for i, child in enumerate(atlas.children(ref)))
            continue
        mark, score = frontier[path]
        if ref[0] is None:
            area = region.overlap(atlas.triangles(ref), intersection)
            assert area == score
        elif not (mark == "E" and any(hi <= low or high <= lo for (lo, hi), (low, high) in
                                      zip(atlas.box(ref), region.bounds, strict=True))):
            assert mark in ("F", "E")
            a, b, c, d = rect_of(atlas.box(ref))
            area = region.overlap(((a, b, c), (a, c, d)), intersection)
            assert area == (area2((a, b, c, d)) if mark == "F" else 0)
        assert mark == ("E" if score == 0 else "F" if score == atlas.area else "C")
        assert 0 <= score <= atlas.area
        count = atlas.count(ref)
        verified[path] = count, score
        counts[{"F": "full", "E": "empty", "C": "cut"}[mark]] += count
    assert verified.keys() == frontier.keys()
    assert all(result["stats"].get(key, 0) == counts[key] for key in ("full", "empty", "cut"))
    assert sum(size * score for size, score in verified.values()) == region.area
    assert sum(size for size, _ in verified.values()) == atlas.count(root)

    selected = sorted(map(tuple, result["selected"]))
    for a, b in zip(selected, selected[1:]):
        assert a != b[:len(a)]
    used = Counter()
    for path in selected:
        parent = next((path[:i] for i in range(len(path) + 1) if path[:i] in verified), None)
        assert parent is not None
        assert all(type(i) is int and i >= 0 for i in path)
        used[parent] += atlas.count(atlas.at(root, path))
    assert sum(used.values()) == result["target_count"]
    assert all(used[path] <= count for path, (count, _) in verified.items())
    included = [score for path, (_, score) in verified.items() if used[path]]
    rejected = [score for path, (count, score) in verified.items() if count > used[path]]
    if included:
        assert min(included) >= max(rejected, default=Fraction(0))
    score = sum(used[path] * value for path, (_, value) in verified.items())
    assert score == Fraction(*result["intersection"])
    assert region.area + atlas.area * result["target_count"] - 2 * score == Fraction(*result["error"])
    return dict(frontier_records=len(verified), selected_records=len(selected),
                min_selected=str(min(included)) if included else None,
                max_rejected=str(max(rejected, default=Fraction(0))))
