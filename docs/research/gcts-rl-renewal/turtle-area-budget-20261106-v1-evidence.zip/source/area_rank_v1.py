"""Exact fixed-count selection from the certified nested Turtle atlas."""
from collections import Counter
from fractions import Fraction
from itertools import combinations

from cluster_v1 import mat
from geometry_v1 import pairs
from golden_geometry_v1 import add
from triangle_geometry_v1 import area2, overlap, triangulate, validate_polygon, _segments_meet
from window_v1 import bounds, rectangle, touches


def cross(a, b, p):
    return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])


def inside(ring, p):
    """Parity at a point off the boundary, with a half-open ray convention."""
    x, y = p
    return sum((a[1] <= y < b[1] and cross(a, b, (x, y)) > 0) or
               (b[1] <= y < a[1] and cross(a, b, (x, y)) < 0)
               for a, b in pairs(ring)) % 2 == 1


def rect_of(box):
    (x0, x1), (y0, y1) = box[:2]
    return rectangle(x0, y0, x1 - x0, y1 - y0)


def intersects_rect(edge, box, corners):
    a, b, axes = edge
    if any(hi < lo2 or hi2 < lo for (lo, hi), (lo2, hi2) in zip(axes, box)):
        return False
    values = [cross(a, b, p) for p in corners]
    return min(values) <= 0 <= max(values)


def separated(a, b):
    return all(not _segments_meet(x, y, u, v) for x, y in pairs(a) for u, v in pairs(b))


class Region:
    def __init__(self, outer, holes=()):
        self.rings = tuple(tuple(validate_polygon(r)) for r in (outer, *holes))
        assert all(type(v) is int for r in self.rings for p in r for v in p)
        self.outer, *self.holes = self.rings
        if any(not separated(self.outer, h) or not inside(self.outer, h[0]) for h in self.holes):
            raise ValueError("Each hole must be strictly inside the outer ring")
        if any(not separated(a, b) or inside(a, b[0]) or inside(b, a[0])
               for a, b in combinations(self.holes, 2)):
            raise ValueError("Holes must be disjoint and unnested")
        self.bounds = bounds(self.outer)
        self.area = area2(self.outer) - sum(area2(h) for h in self.holes)
        self.edges = tuple((a, b, bounds((a, b))[:2]) for r in self.rings for a, b in pairs(r))
        self.targets = [(1 if i == 0 else -1, t, bounds(t))
                        for i, r in enumerate(self.rings) for t in triangulate(r)]

    def classify(self, box):
        if not touches(box, self.bounds):
            return "E"
        corners = rect_of(box)
        if any(intersects_rect(edge, box, corners) for edge in self.edges):
            return "M"
        p = corners[0]
        return "F" if inside(self.outer, p) and not any(inside(h, p) for h in self.holes) else "E"

    def overlap(self, subject, area):
        total = Fraction(0)
        for t in subject:
            tbox = bounds(t)
            for sign, u, box in self.targets:
                if touches(tbox, box):
                    total += sign * area(t, u)
        return total


def clipping(a, b):
    r = overlap(a, b)
    return Fraction(*r["witness"]["area2"]) if r["overlap"] else 0


class Atlas:
    def __init__(self, hierarchy):
        self.h = hierarchy
        self.area = area2(hierarchy.model.polygons[0])

    def root(self, region, count):
        level, turn = self.h.root(region.outer)
        while self.h.nodes["T", level].count < count:
            level += 2
            turn = self.h.model.compose[6, turn]
            self.h.ensure(level)
        return (("T", level), turn, (0, 0))

    def count(self, ref):
        return self.h.nodes[ref[0]].count if ref[0] else 1

    def box(self, ref):
        key, turn, pos = ref
        if key:
            return self.h.placed_bounds(self.h.nodes[key].bounds, turn, pos)
        return self.h.placed_bounds(self.h.primitive[turn], 0, pos)

    def tiles(self, ref):
        if ref[0] is None:
            yield (ref[1], *ref[2])
        else:
            for child in self.children(ref):
                yield from self.tiles(child)

    def children(self, ref):
        key, g, pos = ref
        node = self.h.nodes[key]
        if node.children:
            return tuple(((label, n), self.h.model.compose[g, h],
                          add(mat(self.h.model.groups[g], shift), pos))
                         for label, n, h, shift in node.children)
        return tuple((None, h, add((x, y), pos)) for h, x, y in
                     (self.h.model.action(g, tile) for tile in node.tiles))

    def at(self, root, path):
        ref = root
        for i in path:
            ref = self.children(ref)[i]
        return ref

    def triangles(self, ref):
        return tuple(tuple(add(v, ref[2]) for v in t) for t in self.h.triangles[ref[1]])


def frontier(atlas, root, region, bulk=True):
    stats = Counter()
    stops = []
    pending = [((), root)]
    while pending:
        path, ref = pending.pop()
        stats["visited"] += 1
        box = atlas.box(ref)
        mark = region.classify(box) if bulk else ("M" if touches(box, region.bounds) else "E")
        if mark == "M" and ref[0] is not None:
            pending.extend(((*path, i), child) for i, child in reversed(tuple(enumerate(atlas.children(ref)))))
            continue
        if mark == "M":
            stats["clipped"] += 1
            score = region.overlap(atlas.triangles(ref), clipping)
            assert 0 <= score <= atlas.area
            mark = "E" if not score else "F" if score == atlas.area else "C"
        else:
            score = atlas.area if mark == "F" else Fraction(0)
        count = atlas.count(ref)
        stats[{"F": "full", "E": "empty", "C": "cut"}[mark]] += count
        stops.append((path, ref, mark, Fraction(score)))
    assert sum(stats[k] for k in ("full", "empty", "cut")) == atlas.count(root)
    assert sum(atlas.count(ref) * score for _, ref, _, score in stops) == region.area
    return stops, dict(stats)


def take(atlas, path, ref, wanted):
    size = atlas.count(ref)
    if wanted == size:
        yield path
        return
    for i, child in enumerate(atlas.children(ref)):
        n = min(wanted, atlas.count(child))
        yield from take(atlas, (*path, i), child, n)
        wanted -= n
        if not wanted:
            return
    raise AssertionError("Tile count exceeded the cluster")


def choose(atlas, stops, wanted):
    order = sorted(stops, key=lambda row: (-row[3], row[0]))
    selected, total = [], Fraction(0)
    for path, ref, _, score in order:
        if not wanted:
            break
        count = min(wanted, atlas.count(ref))
        selected.extend(take(atlas, path, ref, count))
        wanted -= count
        total += count * score
    assert not wanted
    return sorted(selected), total


def fraction(x):
    return [x.numerator, x.denominator]


def solve(atlas, region, wanted=None, bulk=True):
    if wanted is None:
        wanted = (2 * region.area + atlas.area) // (2 * atlas.area)
    if type(wanted) is not int or wanted < 0:
        raise ValueError("Tile count must be a nonnegative integer")
    root = atlas.root(region, wanted)
    stops, stats = frontier(atlas, root, region, bulk)
    selected, intersection = choose(atlas, stops, wanted)
    return dict(root=[root[0][1], root[1]], target_count=wanted, tile_area=atlas.area,
                region_area=region.area, intersection=fraction(intersection),
                error=fraction(region.area + wanted * atlas.area - 2 * intersection),
                selected=selected, stats=stats,
                frontier=[(path, mark, fraction(score)) for path, _, mark, score in stops])
