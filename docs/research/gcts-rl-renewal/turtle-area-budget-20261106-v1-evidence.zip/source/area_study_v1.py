"""Run the exact area-budget solver, a leaf-clipping control and certificate audit."""
from fractions import Fraction
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from area_audit_v1 import verify
from area_rank_v1 import Atlas, Region, fraction, solve
from geometry_v1 import Turtle
from window_v1 import Hierarchy, rectangle

def read(name):
    return json.loads((ROOT / "input" / (name + "-v1.json")).read_text())


def load():
    geometry = Turtle(read("exact-point-model"))
    coord = read("coordinate")
    prod = read("recovered-production")
    assert read("bridge")["status"] == "CHECKED_COEFFICIENTWISE_GOLDEN_HEX_CONJUGACY"
    assert read("plane-replay")["nested_odd_levels"]
    return Atlas(Hierarchy(geometry.model, coord["rule"], prod["alphabet"]))


def translate(ring, dx, dy):
    return tuple((x + dx, y + dy) for x, y in ring)


def requests():
    origin = rectangle(-4, -5, 8, 10)
    notch = ((-26, -18), (24, -18), (24, -5), (5, 0), (5, 23), (-26, 23))
    ring = rectangle(-34, -23, 68, 46)
    holes = (rectangle(-18, -7, 12, 16), ((10, -12), (23, -8), (12, 9)))
    mid = rectangle(-136, -103, 272, 206)
    wide = rectangle(-880, -660, 1760, 1320)
    slit = ((0, -12), (640, 308), (632, 324), (-8, 4))
    far = translate(rectangle(-40, -33, 80, 66), 10**6, -10**6)
    return (
        ("parallelogram", origin, (), None, True),
        ("concave-notch", notch, (), None, True),
        ("two-holes", ring, holes, None, True),
        ("diagonal-strip", slit, (), None, True),
        ("medium-window", mid, (), None, True),
        ("wide-window", wide, (), None, False),
        ("distant-window", far, (), None, True),
        ("empty-budget", origin, (), 0, True),
        ("interior-budget", ring, holes, 5, True),
        ("padding-budget", origin, (), 13, True),
    )


def study():
    atlas = load()
    rows = []
    for name, outer, holes, wanted, compare in requests():
        region = Region(outer, holes)
        ranked = solve(atlas, region, wanted)
        audit = verify(atlas, region, ranked)
        expected = None
        if compare:
            leaf = solve(atlas, region, wanted, bulk=False)
            assert all(ranked[k] == leaf[k] for k in ("target_count", "error", "intersection"))
            expected = leaf["stats"]
        diff_in = region.area - ranked["stats"].get("full", 0) * atlas.area
        diff_out = (ranked["stats"].get("full", 0) + ranked["stats"].get("cut", 0)) * atlas.area - region.area
        assert diff_in >= 0 and diff_out >= 0
        rows.append(dict(name=name, outer=outer, holes=holes, result=ranked, audit=audit,
                         leaf_control=expected, inner_error=diff_in, outer_error=diff_out))
        print(name, ranked["target_count"], ranked["stats"].get("clipped", 0),
              expected and expected.get("clipped", 0), audit["selected_records"], flush=True)
    first = rows[0]
    sample = first["result"]
    selected = set(sample["selected"])
    scores = {path: Fraction(*q) for path, mark, q in sample["frontier"] if mark == "C"}
    drop = max(sorted(selected), key=scores.__getitem__)
    add = min(sorted(scores.keys() - selected), key=scores.__getitem__)
    assert scores[drop] > scores[add]
    forged_total = Fraction(*sample["intersection"]) - scores[drop] + scores[add]
    worse = dict(sample, selected=sorted((selected - {drop}) | {add}), intersection=fraction(forged_total),
                 error=fraction(sample["region_area"] + sample["target_count"] * atlas.area - 2 * forged_total))
    wrong = dict(sample, intersection=fraction(Fraction(*sample["intersection"]) + 1))
    for tampered in (wrong, worse):
        try:
            verify(atlas, Region(first["outer"]), tampered)
        except AssertionError:
            pass
        else:
            raise AssertionError("Altered overlap or inferior selection passed the audit")
    return dict(requests=rows, altered_overlap_rejected=True, inferior_equal_count_selection_rejected=True)


def main():
    if not __debug__:
        raise RuntimeError("Certificate checks require assertions")
    body = json.dumps(study(), sort_keys=True, separators=(",", ":")) + "\n"
    path = ROOT / "data/area-study-v1.json"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body


if __name__ == "__main__":
    main()
