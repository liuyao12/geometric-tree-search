"""Search unknown certificate strings, then build and check accepting Wang frames."""

from collections import deque
import gzip
import hashlib
import json
from pathlib import Path
from random import Random
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def read(name):
    return json.loads((ROOT/name).read_bytes())


def pin(path):
    data=path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def save(name,value):
    with (ROOT/name).open("x") as f:
        json.dump(value,f,sort_keys=True,separators=(",",":"))
        f.write("\n")


def digest(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(",",":")).encode()).hexdigest()


def frozen():
    spec=read("protocol-v1.json")
    assert spec["schema"]=="Fixed-Wang-unary-Horn-frozen-v1"
    assert spec["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in spec["pins"].items())
    return spec


def reference(case,lines):
    if not lines or lines[0] not in case["facts"]:
        return "fact_bad"
    for left,right in zip(lines,lines[1:]):
        amount=right[1]-left[1]
        if not any((i,j)==(left[0],right[0]) and amount=={"A":0,"I":1,"D":-1}[rule]
                   for rule,i,j in case["rules"]):
            return "step_bad"
    return "accept" if lines[-1]==case["goal"] else "goal_bad"


def case_objects(c):
    return {**c,"facts":tuple(map(tuple,c["facts"])),"rules":tuple(map(tuple,c["rules"])),"goal":tuple(c["goal"])}


def native(case):
    started=time.perf_counter()
    domain=set(map(tuple,case["domain"]))
    q=deque((f,) for f in case["facts"] if f in domain)
    seen={p[-1] for p in q}
    visits=0
    while q:
        path=q.popleft()
        visits+=1
        p,n=path[-1]
        if path[-1]==case["goal"]:
            return dict(status="FOUND",proof=path,visits=visits,seconds=time.perf_counter()-started)
        if len(path)==case["max_lines"]:
            continue
        for kind,a,b in case["rules"]:
            if a!=p:
                continue
            next_atom=(b,n+{"A":0,"I":1,"D":-1}[kind])
            if next_atom in domain and next_atom not in seen:
                seen.add(next_atom)
                q.append((*path,next_atom))
    return dict(status="BOUNDED_EXHAUSTED",proof=None,visits=visits,seconds=time.perf_counter()-started)


def word_for(kernel,case,proof):
    prefix=kernel.problem(case["facts"],case["rules"],case["goal"])
    text=kernel.proof(proof)
    assert len(text)<=case["certificate_cells"]
    return prefix+text.ljust(case["certificate_cells"],"_")+"$",len(prefix)


class MachineRunner:
    def __init__(self,machine,tiles):
        self.next={(r["state"],r["read"]):(r["next"],r["write"],r["move"]) for r in machine["transitions"]}
        self.states=machine
        self.cell=tiles.cell

    def run(self,word,limit,retain=False):
        tape=list(word)
        head=steps=0
        state=self.states["start"]
        configs=[] if retain else None
        while True:
            if retain:
                configs.append(tuple(self.cell(a,state if i==head else None) for i,a in enumerate(tape)))
            if state=="accept" or state.endswith("_bad"):
                # Failure states take one stationary transition into reject.
                return state,steps,configs
            if steps>=limit:
                return "STEP_LIMIT",steps,configs
            assert 0<=head<len(tape)
            state,tape[head],move=self.next[state,tape[head]]
            head+=move
            steps+=1


def search(kernel,runner,case,limit,use_marks):
    started=time.perf_counter()
    q=deque([()])
    notes=[]
    marks={}
    fact_marks={}
    proof=None
    trials=skips=steps_total=0
    truncated=None
    while q and proof is None:
        path=q.popleft()
        for atom in map(tuple,case["domain"]):
            candidate=(*path,atom)
            key=(path[-1],atom) if path else atom
            field=marks if path else fact_marks
            if use_marks and key in field:
                notes.append(dict(lines=candidate,kind="MARK",origin=field[key]))
                skips+=1
                continue
            if trials>=limit["trials"] or time.perf_counter()-started>=limit["seconds"]:
                truncated="SEARCH_LIMIT"
                break
            text,_=word_for(kernel,case,candidate)
            state,steps,_=runner.run(text,limit["steps"])
            trials+=1
            steps_total+=steps
            notes.append(dict(lines=candidate,kind="MACHINE",state=state,steps=steps))
            if state=="STEP_LIMIT":
                truncated=state
                break
            if state=="accept":
                proof=candidate
                break
            if state=="goal_bad" and len(candidate)<case["max_lines"]:
                q.append(candidate)
            if use_marks and state==("step_bad" if path else "fact_bad"):
                field.setdefault(key,len(notes)-1)
        if truncated:
            break
    return dict(status="FOUND" if proof else "UNKNOWN" if truncated else "BOUNDED_EXHAUSTED",
                proof=proof,trials=trials,mark_hits=skips,steps=steps_total,
                marks=len(marks)+len(fact_marks),stop=truncated,
                seconds=time.perf_counter()-started,events=notes)


def audit_search(case,result):
    events=result["events"]
    for i,entry in enumerate(events):
        lines=entry["lines"]
        expect=reference(case,lines)
        if len(lines)>1:
            assert reference(case,lines[:-1])=="goal_bad"
        if entry["kind"]=="MACHINE":
            assert entry["state"] in {expect,"STEP_LIMIT"}
        else:
            assert 0<=entry["origin"]<i and expect==("step_bad" if len(lines)>1 else "fact_bad")
            origin=events[entry["origin"]]
            assert origin["kind"]=="MACHINE" and origin["state"]==expect and origin["lines"][-2:]==lines[-2:]
    assert result["trials"]==sum(e["kind"]=="MACHINE" for e in events)
    assert result["mark_hits"]==sum(e["kind"]=="MARK" for e in events)
    if result["proof"]:
        assert reference(case,result["proof"])=="accept"


def frame(kernel,tiles,palette,runner,case,proof,limit):
    word,plen=word_for(kernel,case,proof)
    state,steps,configs=runner.run(word,limit,retain=True)
    assert state=="accept"
    boundary,grid=tiles.build_frame(palette,word,plen,configs)
    receipt=tiles.verify_frame(palette,boundary,grid)
    decoded=''.join(t[2][1][-1] for t in grid[0][1:-1])
    assert decoded==word and decoded[:plen]==kernel.problem(case["facts"],case["rules"],case["goal"])
    assert reference(case,proof)=="accept" and receipt["steps"]==steps
    used=sorted({t for row in grid for t in row},key=digest)
    ordinal={t:i for i,t in enumerate(used)}
    hashes=[digest(t) for t in used]
    assert len(set(hashes))==len(hashes)
    evidence=dict(case=case["id"],machine_sha256=digest(palette.machine),proof=proof,word=word,
        prefix_length=plen,boundary=boundary,receipt=receipt,
        types=[dict(sha256=h,edges=t) for h,t in zip(hashes,used)],
        cells=[[ordinal[t] for t in row] for row in grid])
    return evidence,grid


def qualification(kernel,runner,machine,tiles,limits,cases):
    import deterministic_tm_wang_v1 as inherited
    tiny=dict(schema=machine["schema"],symbols=["x","_"],states=["q","ok","no"],start="q",
        blank="_",accept="ok",reject="no",input_alphabet=["x"],transitions=[
            dict(state="q",read="x",next="ok",write="x",move=0),
            dict(state="q",read="_",next="no",write="_",move=0)])
    material=inherited.compile_palette(tiny,check=lambda:None)
    symbolic=tiles.Palette(tiny)
    def tup(x):
        return tuple(map(tup,x)) if type(x) is list else x
    for t in material["tiles"]:
        edges=tuple(tup(json.loads(material["colors"][t[k]])) for k in ("north","east","south","west"))
        assert symbolic.allows(edges)
    rng=Random(99217)
    checks=0
    for case in cases:
        for _ in range(64):
            proof=tuple(tuple(rng.choice(case["domain"])) for _ in range(rng.randint(1,case["max_lines"])))
            word,_=word_for(kernel,case,proof)
            assert runner.run(word,limits["steps"])[0]==reference(case,proof)
            checks+=1
    malformed=("!","P:y","P:y;!P:;","P:X;!","P:;_!","P:;!x")
    prefix=kernel.problem(((0,0),),(),(0,0))
    for item in malformed:
        assert runner.run(prefix+item+"$",limits["steps"])[0]=="syntax_bad"
    large=dict(facts=((31,11),),rules=(("I",31,32),),goal=(32,12),certificate_cells=110)
    word,_=word_for(kernel,large,((31,11),(32,12)))
    assert runner.run(word,limits["steps"])[0]=="accept"
    return dict(status="PASS",synthetic_explicit_tile_types=len(material["tiles"]),
        random_certificate_checks=checks,malformed=len(malformed),large_unary_ids=True)


def write_gzip(name,value):
    with (ROOT/name).open("xb") as raw:
        with gzip.GzipFile(fileobj=raw,mode="wb",filename="",mtime=0) as stream:
            stream.write((json.dumps(value,sort_keys=True,separators=(",",":"))+"\n").encode())


def main():
    spec=frozen()
    sys.path.insert(0,str(ROOT/"source"))
    import kernel_v1 as kernel
    import tiles_v1 as tiles
    machine=kernel.build()
    save("data/machine-v1.json",machine)
    cases=[case_objects(c) for c in read("input/cases-v1.json")]
    limits=spec["limits"]
    runner=MachineRunner(machine,tiles)
    palette=tiles.Palette(machine)
    checked=qualification(kernel,runner,machine,tiles,limits,cases)
    save("data/qualification-v1.json",checked)
    print(json.dumps(checked),flush=True)
    outcomes=[]
    traces=[]
    frames=[]
    for i,case in enumerate(cases):
        methods={}
        for use in ((False,True) if i%2==0 else (True,False)):
            name="memo" if use else "plain"
            result=search(kernel,runner,case,limits,use)
            start=time.perf_counter()
            audit_search(case,result)
            result["assurance_seconds"]=time.perf_counter()-start
            traces.append(dict(case=case["id"],method=name,result=result))
            methods[name]={k:v for k,v in result.items() if k!="events"}
        control=native(case)
        assert methods["plain"]["status"]==methods["memo"]["status"]==control["status"]
        assert methods["plain"]["proof"]==methods["memo"]["proof"]
        evidence=None
        if methods["plain"]["proof"]:
            evidence,grid=frame(kernel,tiles,palette,runner,case,methods["plain"]["proof"],limits["steps"])
            if not frames:
                malformed=[row[:] for row in grid]
                t=malformed[0][2]
                malformed[0][2]=(("input","fixed","_"),*t[1:])
                try:
                    tiles.verify_frame(palette,evidence["boundary"],malformed)
                except AssertionError:
                    evidence["fixed_context_mutation_rejected"]=True
                else:
                    raise AssertionError("tampered fixed input was accepted")
            frames.append(evidence)
        row=dict(case=case,methods=methods,native=control,frame=None if evidence is None else evidence["receipt"])
        outcomes.append(row)
        print(json.dumps(dict(case=case["id"],methods=methods,frame=row["frame"])),flush=True)
    write_gzip("data/search-traces-v1.json.gz",traces)
    write_gzip("data/accepting-frames-v1.json.gz",frames)
    frozen()
    files={name:pin(ROOT/name) for name in (
        "data/machine-v1.json","data/search-traces-v1.json.gz","data/accepting-frames-v1.json.gz",
        "data/qualification-v1.json","protocol-v1.json")}
    save("data/summary-v1.json",dict(status="CHECKED_FIXED_HORN_WANG_COHORT",machine_sha256=digest(machine),
        states=len(machine["states"]),symbols=len(machine["symbols"]),transition_rows=len(machine["transitions"]),
        qualification=checked,outcomes=outcomes,files=files))


if __name__=="__main__":
    main()
