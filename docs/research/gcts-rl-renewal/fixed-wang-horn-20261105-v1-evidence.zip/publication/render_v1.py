"""Audit saved frames and show the exact tile row that commits each proof line."""

import gzip
import hashlib
from html import escape
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/"attempt-v2"
STEM="fixed-wang-horn-20261105-v1"


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":")).encode()).hexdigest()


def uncompress(path):
    with gzip.open(path,"rt") as stream:
        return json.load(stream)


def audit():
    result=read(RUN/"data/summary-v1.json")
    assert result["status"]=="CHECKED_FIXED_HORN_WANG_COHORT"
    for n,v in result["files"].items():
        assert pin(RUN/n)==v
    for folder in (ROOT,RUN):
        protocol=read(folder/"protocol-v1.json")
        assert all(pin(folder/n)==v for n,v in protocol["pins"].items())
    machine=read(RUN/"data/machine-v1.json")
    assert machine==read(ROOT/"data/machine-v1.json") and digest(machine)==result["machine_sha256"]
    assert result["qualification"]["large_unary_steps"]>100000
    traces=uncompress(RUN/"data/search-traces-v1.json.gz")
    by_trace={(r["case"],r["method"]):r["result"] for r in traces}
    cases=read(RUN/"input/cases-v1.json")
    assert [r["case"] for r in result["outcomes"]]==cases and len(traces)==8
    for row in result["outcomes"]:
        for name,method in row["methods"].items():
            trace=by_trace[row["case"]["id"],name]
            assert {k:v for k,v in trace.items() if k!="events"}==method
            assert len(trace["events"])==method["trials"]+method["mark_hits"]
    frames=uncompress(RUN/"data/accepting-frames-v1.json.gz")
    assert len(frames)==3 and frames[0]["fixed_context_mutation_rejected"]
    for row in frames:
        outcome=next(r for r in result["outcomes"] if r["case"]["id"]==row["case"])
        assert outcome["frame"]==row["receipt"] and outcome["methods"]["memo"]["proof"]==row["proof"]
        assert row["machine_sha256"]==result["machine_sha256"]
        assert all(digest(t["edges"])==t["sha256"] for t in row["types"])
        assert len(row["cells"])==row["receipt"]["rows"] and len(row["boundary"])==row["receipt"]["columns"]
        row["commits"]=commits(row,machine)
    return result,frames


def commits(frame,machine):
    grid,types=frame["cells"],[t["edges"] for t in frame["types"]]
    expected=[i+1 for i,a in enumerate(frame["word"]) if i>=frame["prefix_length"] and a=="P"]
    first=''.join(types[i][2][1][-1] for i in grid[0][1:-1])
    assert first==frame["word"]
    found=[]
    for y,row in enumerate(grid):
        assert len(row)==len(frame["boundary"])
        for x,i in enumerate(row):
            n,e,s,w=types[i]
            assert n==(frame["boundary"][x] if y==0 else types[grid[y-1][x]][2])
            assert w==(["outer","left"] if x==0 else types[row[x-1]][1])
            if x==len(row)-1:
                assert e==["outer","right"]
            if y==len(grid)-1:
                assert s==["outer","bottom"]
            if (n[0]=="configuration" and n[1][0]=="head"
                    and n[1][1].endswith("-at-current") and n[1][2]=="C"):
                assert s==["configuration",["symbol","V"]]
                found.append(dict(row=y,column=x,type=frame["types"][i]["sha256"]))
    assert [r["column"] for r in found]==expected
    assert len(found)==len(frame["proof"])
    return found


def math(content):
    return r"\("+escape(content)+r"\)"


def term(n):
    return "0" if n==0 else r"S(0)" if n==1 else "S^{"+str(n)+"}(0)"


def pred(i, argument):
    return "P_{"+str(i)+"}("+argument+")"


def atom(p):
    return math(pred(p[0],term(p[1])))


def formula(rule):
    kind,i,j=rule
    x="S(x)" if kind=="D" else "x"
    y="S(x)" if kind=="I" else "x"
    return math(r"\forall x\,("+pred(i,x)+r"\to "+pred(j,y)+")")


def reason(case,proof,index):
    a=proof[index]
    if index==0:
        return f'Use context fact {case["facts"].index(a)+1}.'
    b=proof[index-1]
    n,kind=next((i,k) for i,(k,p,q) in enumerate(case["rules"],1)
                if p==b[0] and q==a[0] and a[1]-b[1]=={"A":0,"I":1,"D":-1}[k])
    arg=a[1] if kind=="D" else b[1]
    return f'Instantiate rule {n} at {math(term(arg))} and apply it to line {index}.'


def color(c):
    label=c[0]
    base={"configuration":145,"old-pair":34,"input":205,"frame":210,"cap":285}.get(label,222)
    if label=="configuration" and c[1][0]=="head":
        base=286
    shade=int(digest(c)[:4],16)%28-14
    return f'hsl({base+shade} 53% 72%)'


def window(frame,commit):
    x,y=commit["column"],commit["row"]
    grid,types=frame["cells"],frame["types"]
    left=max(0,x-2)
    right=min(x+3,len(grid[0]))
    top=max(0,y-1)
    bottom=min(y+2,len(grid))
    size=46
    body=[]
    for yy in range(top,bottom):
        for xx in range(left,right):
            tile=types[grid[yy][xx]]
            dx,dy=(xx-left)*size,(yy-top)*size
            a,b,c,d=(0,0),(size,0),(size,size),(0,size)
            center=(size/2,size/2)
            body.append(f'<g transform="translate({dx} {dy})"><title>Row {yy}, column {xx}. '
                        f'Type {tile["sha256"]}</title>')
            for edge,u,v in zip(tile["edges"],(a,b,c,d),(b,c,d,a)):
                points=' '.join(f'{i},{j}' for i,j in (u,v,center))
                body.append(f'<polygon points="{points}" fill="{color(edge)}"></polygon>')
            n=tile["edges"][0]
            text=n[1][-1] if n[0]=="configuration" else "·"
            body.append(f'<text x="23" y="28" text-anchor="middle">{escape(text)}</text>')
            border="#672b78" if (xx,yy)==(x,y) else "#f9f7ee"
            width=2.8 if (xx,yy)==(x,y) else 1
            body.append(f'<rect width="46" height="46" fill="none" stroke="{border}" stroke-width="{width}"></rect></g>')
    return (f'<svg viewBox="0 0 {(right-left)*size} {(bottom-top)*size}" role="img" '
            f'aria-label="Actual Wang squares around computation row {y}">' + ''.join(body)+'</svg>')


def table(headers,rows):
    return ('<div class="scroll"><table><thead><tr>'+''.join(f'<th scope="col">{x}</th>' for x in headers)
            +'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{x}</td>' for x in row)+'</tr>' for row in rows)
            +'</tbody></table></div>')


def proof_reader(frame,case):
    rows=[]
    examples=[]
    for i,(a,commit) in enumerate(zip(frame["proof"],frame["commits"],strict=True)):
        rows.append([i+1,atom(a),reason(case,frame["proof"],i),commit["row"],commit["column"]])
        examples.append(f'<figure><figcaption>Line {i+1} · row {commit["row"]}</figcaption>'
                        +window(frame,commit)+'</figure>')
    facts=' '.join(f'<li>{atom(p)}</li>' for p in case["facts"])
    rules=' '.join(f'<li>{formula(r)}</li>' for r in case["rules"])
    return (f'<details><summary>{case["id"]} · {escape(case["name"])} · {atom(case["goal"])}</summary>'
            f'<div class="context"><div><h3>Facts</h3><ol>{facts}</ol></div>'
            f'<div><h3>Quantified rules</h3><ol>{rules}</ol></div></div>'
            +table(("Line","Formula","Justification","Wang row","Column"),rows)
            +'<div class="figures">'+''.join(examples)+'</div></details>')


def render(result,frames):
    cases={x["case"]["id"]:x["case"] for x in result["outcomes"]}
    rows=[]
    for item in result["outcomes"]:
        a,b=item["methods"]["plain"],item["methods"]["memo"]
        f=item["frame"]
        rows.append([item["case"]["id"],escape(item["case"]["name"]),
            "Checked proof" if f else "Bounded exhaustion",a["trials"],b["trials"],b["mark_hits"],
            f'{a["seconds"]:.5f}',f'{b["seconds"]:.5f}',f'{item["native"]["seconds"]:.7f}',
            f'{f["tiles"]:,}' if f else "—"])
    q=result["qualification"]
    return HEAD+f'''
<section id="comparison"><h2>Certificate search and a direct control</h2>
<p>Both searches enumerate unknown proof records within the same bounds. The fixed machine
checks each attempted prefix. A valid prefix can extend when only its goal comparison fails.
The memoized method reuses an earlier checked rejection for the same pair of consecutive atoms
in the same context. An independent evaluator checked every trial and reuse.</p>
{table(("Case","Problem","Outcome","Plain trials","Memo trials","Reused failures","Plain s","Memo s","Direct s","Wang squares"),rows)}
<p>Direct search traverses the Horn rules and deduplicates reachable atoms. It is a separate
control. Timings for the two certificate searches exclude the subsequent tableau checks.
The bounded exhaustion covers only the declared atoms and line limit.</p>
</section>
<section id="reader"><h2>Read the checked proof lines</h2>
<p>Each listed row is the computation row where the head commits that proof record.
Violet highlights the exact square. Green and violet encode north and south configuration
colors. Amber marks the east and west neighborhood colors. Matching uses the full color
identifier. The figures show local windows of the much larger tableaux.</p>
{''.join(proof_reader(f,cases[f["case"]]) for f in frames)}
</section>
<section id="scope"><h2>The fixed verifier</h2>
<p>One transition table has {result["states"]} states, {result["symbols"]} symbols,
and {result["transition_rows"]:,} transition rows. An exact membership rule specifies
its finite palette. The archive lists every tile type used in the accepted rectangles.
Each square is placed by translation and checked by its four edge colors. The top boundary
fixes the context and goal and leaves the certificate cells free. The bottom cap requires
the unique accepting head.</p>
<p>Qualification compared {q["synthetic_explicit_tile_types"]} explicitly constructed tile
types against membership, checked {q["random_certificate_checks"]} generated certificates
against typed logic, and rejected {q["malformed"]} malformed strings and a fixed-input tile
mutation. A long unary control took {q["large_unary_steps"]:,} steps. The first attempt
stopped at 100,000 during that qualification. The completed attempt used a separate limit
for the long control and kept the original theorem-search limits.</p>
<p>The current grammar covers ground facts and quantified unary implications with
the same argument, a successor, or a predecessor. The branch choices and learned failure
marks live on the certificate records. The fixed machine propagates each selected input
and produces a checked Wang frame for an accepting certificate. General first-order
proofs and RL guidance remain open.</p>
</section>
'''+END


HEAD=r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fixed Wang verifier for quantified Horn chains</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{color-scheme:light;--ink:#17362f;--rule:#cbd9cd;--paper:#f6f4eb}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,sans-serif}
main{max-width:1120px;margin:auto;padding:24px}header{padding:24px 0;max-width:840px}
h1{font:clamp(2.1rem,5vw,3.9rem)/1.08 Georgia,serif;margin:.45em 0}
h2{font:1.75rem/1.15 Georgia,serif;margin:0 0 .55em}h3{font-size:1rem}
a{color:#176852}.eyebrow{font-size:.8rem;letter-spacing:.12em;text-transform:uppercase}
section{background:#fffdfa;border:1px solid var(--rule);border-radius:12px;padding:18px;margin-bottom:18px}
.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:.88rem}
td,th{text-align:left;vertical-align:top;padding:7px;border-bottom:1px solid var(--rule)}
details{padding:10px 0;border-top:1px solid var(--rule)}summary{cursor:pointer;font-weight:650}
.context,.figures{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,205px),1fr));gap:12px}
figure{margin:10px 0;background:#edf5ee;padding:9px;border-radius:8px}
figcaption{font-size:.85rem;font-weight:650}svg{display:block;width:100%;height:133px;font:14px monospace}
</style></head><body><main>
<header><p class="eyebrow">GCTS research · symbolic deduction</p>
<h1>One Wang palette for quantified Horn chains</h1>
<p>A fixed verifier checked three proofs found from their contexts and goals. The proof
reader shows their formulas and the actual local tiles that commit each line.</p>
<p><a href="#comparison">Search comparison</a> · <a href="#reader">Read the proofs</a> ·
<a href="#evidence">Evidence archive</a></p></header>
'''


END=f'''<section id="evidence"><h2>Experiment records</h2>
<p><a href="{STEM}-evidence.zip">Full evidence archive</a> ·
<a href="{STEM}-manifest.json">Archive manifest</a> ·
<a href="{STEM}-results.json">Audited results and row mappings</a> ·
<a href="conditional-inventory/fixed-wang-construction-v1.html">Earlier fixed-Wang construction</a> ·
<a href="penrose-vertex-guards-20261105-v1.html">Previous research milestone</a></p>
</section></main></body></html>
'''


def main():
    result,frames=audit()
    with (ROOT/"report"/(STEM+".html")).open("x") as f:
        f.write(render(result,frames))
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:
        compact=[{k:v for k,v in fr.items() if k not in ("cells","types")} for fr in frames]
        json.dump(dict(status="PASS_SAVED_WANG_EVIDENCE_AUDIT",summary=result,frames=compact),f,
                  sort_keys=True,separators=(",",":"))
        f.write("\n")


if __name__=="__main__":
    main()
