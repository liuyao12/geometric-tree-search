Fixed Wang verifier for unary Horn chains

Open report/fixed-wang-horn-20261105-v1.html. The attempt-v2 directory
contains the completed frozen experiment, its executable transition table,
full accepted rectangles, search records, and independent checks. Root data
retains the first qualification stop and exact diagnostic cutoff. No proof
search ran in that first process.

In a separate extracted copy, preserve the archived data. Create an empty
attempt-v2/data directory and run the pinned Python with:

    python -I -S -B attempt-v2/source/run_v1.py

The runtime and inputs are pinned in attempt-v2/protocol-v1.json. Each
accepting frame uses a compact local type dictionary. Its keys are hashes
of the four full edge colors. The complete fixed finite palette is
specified intensionally by the qualified framed-Wang construction.
Rendering the archived evidence with publication/render_v1.py yields a
formula and English reason for each accepted proof record, linked to the
exact computation row and column that commits it.
