# A fixed Wang verifier for unary Horn chains

The input language uses unary predicates with arbitrary nonnegative indices
and ground terms of the form \(S^n0\). A context supplies ground facts and
rules of these three forms.

\[
\forall x\,(P_i(x)\to P_j(x)),\qquad
\forall x\,(P_i(x)\to P_j(Sx)),\qquad
\forall x\,(P_i(Sx)\to P_j(x)).
\]

The certificate is a chain of atoms. Its first atom must be a context fact.
Each later atom must follow from the previous one by a valid instance of a
context rule. The last atom must equal the fixed goal. Predicate IDs and
successor counts use unary tape fields of unrestricted length. The machine
checks the grammar before validating the chain. All comparisons consume and
restore exact unit tokens. A distinct failure state identifies the stage.

Use the same finite single-head transition table for every input. The earlier
qualified framed construction defines the finite palette by local edge
relations. Use an intensional palette because materializing every unused
type is unnecessary. Each type is fully determined by its edge colors and
allows translations only. Verify every used type, every boundary and adjacent
edge, and every global transition of each accepted frame. Check the fixed
machine against independent typed logic, malformed input controls and a
synthetic explicit palette. Mutating a fixed input color must fail.

Freeze four problems, a finite domain and a line limit for each. The search
enumerates unknown proof records in breadth-first order. For each trial the
fixed tape machine propagates the deterministic computation. A valid prefix
whose goal comparison fails can be extended. In the marking arm, a verified
first-line or transition failure can prevent repeating the identical check
in the same context. Its origin must precede reuse. In both arms the
positive outcome is emitted as a full framed Wang witness. An independent
typed evaluator checks every executed trial and memoized exclusion after
search. A conventional state-deduplicated Horn traversal is a separate
control over the same domain and line limit.

Caps are 100,000 machine steps per candidate, 2,000 executed candidates per
method and 15 search seconds per method. Absence of a bounded proof is
reported at its exact scope. The comparison isolates failure reuse in the
bounded certificate search. It is a verifier for this inference fragment.
General first-order proof verification, universal computation and learned
RL ranking remain separate research objectives.
