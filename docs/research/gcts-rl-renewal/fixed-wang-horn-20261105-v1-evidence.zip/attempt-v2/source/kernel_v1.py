"""Assemble a fixed single-tape kernel for quantified unary Horn chains."""

SYMBOLS=list(">:;|!_FxyAGIDPXYCV$")+["TF","TA","TI","TD"]
ALPHABET=list("Pxy:;!_")
HALTS=("accept","reject")
FAILURES=("syntax_bad","fact_bad","step_bad","goal_bad")


class Assembler:
    def __init__(self):
        self.table={}
        self.count=0

    def state(self,label):
        self.count+=1
        return f"{self.count:03d}-{label}"

    def put(self,q,a,n,w=None,m=0):
        assert (q,a) not in self.table and a in SYMBOLS
        self.table[q,a]=(n,a if w is None else w,m)

    def scan(self,start,stop,exit,move=1):
        for a in SYMBOLS:
            if a in stop:
                self.put(start,a,exit)
            elif a not in ">$":
                self.put(start,a,start,m=move)

    def left(self,start,exit):
        for a in SYMBOLS:
            self.put(start,a,exit if a==">" else start,m=1 if a==">" else -1)

    def seek(self,start,mark,exit):
        scan=self.state("seek-"+mark)
        self.left(start,scan)
        self.scan(scan,{mark},exit)

    def field(self,start,mark,field,exit):
        at=self.state("at-"+mark)
        self.seek(start,mark,at)
        if field=="x":
            self.put(at,mark,exit,m=1)
            return
        first=self.state("skip-first")
        self.put(at,mark,first,m=1)
        for a in "xX":
            self.put(first,a,first,m=1)
        self.put(first,":",exit,m=1)

    def restore(self,start,exit):
        sweep=self.state("restore")
        self.left(start,sweep)
        for a in SYMBOLS:
            if a=="$":
                self.put(sweep,a,exit)
            elif a!=">":
                self.put(sweep,a,sweep,w=a.lower() if a in "XY" else a,m=1)

    def compare(self,start,a,fa,b,fb,extra,yes,no):
        """Compare lengths, optionally requiring one extra unit on a named side."""
        loop=self.state("compare-loop")
        seek_b=self.state("match-second")
        seen_a=self.state("first-unconsumed")
        seen_b=self.state("second-unconsumed")
        done_a=self.state("finish-first")
        finish_b=self.state("finish-second")
        good,bad=self.state("compare-good"),self.state("compare-bad")
        if extra:
            atom,field=(a,fa) if extra=="left" else (b,fb)
            first=self.state("remove-one-unit")
            self.field(start,atom,field,first)
            self.put(first,field,loop,w=field.upper())
            self.put(first,":" if field=="x" else ";",bad)
        else:
            loop=start
        self.field(loop,a,fa,seen_a)
        self.put(seen_a,fa.upper(),seen_a,m=1)
        self.put(seen_a,fa,seek_b,w=fa.upper())
        self.put(seen_a,":" if fa=="x" else ";",done_a)
        self.field(seek_b,b,fb,seen_b)
        self.put(seen_b,fb.upper(),seen_b,m=1)
        self.put(seen_b,fb,loop,w=fb.upper())
        self.put(seen_b,":" if fb=="x" else ";",bad)
        self.field(done_a,b,fb,finish_b)
        self.put(finish_b,fb.upper(),finish_b,m=1)
        self.put(finish_b,fb,bad)
        self.put(finish_b,":" if fb=="x" else ";",good)
        self.restore(good,yes)
        self.restore(bad,no)

    def parser(self,begin):
        ctx,goal,end,proof,again,pad=(self.state(x) for x in
            ("context","goal","separator","first-proof","after-proof","padding"))
        first,second,gx,gy,px,py=(self.state(x) for x in
            ("ctx-x","ctx-y","goal-x","goal-y","proof-x","proof-y"))
        self.put("start",">",ctx,m=1)
        for a in "FAID":
            self.put(ctx,a,first,m=1)
        self.put(ctx,"G",goal,m=1)
        self.put(goal,"x",gx,m=1)
        self.put(goal,":",gy,m=1)
        for a,b,c in ((first,second,ctx),(gx,gy,end),(px,py,again)):
            self.put(a,"x",a,m=1)
            self.put(a,":",b,m=1)
            self.put(b,"y",b,m=1)
            self.put(b,";",c,m=1)
        self.put(end,"|",proof,m=1)
        self.put(proof,"P",px,m=1)
        self.put(again,"P",px,m=1)
        self.put(again,"!",pad,m=1)
        self.put(pad,"_",pad,m=1)
        self.put(pad,"$",begin)

    def machine(self):
        states=sorted({q for q,_ in self.table}|{v[0] for v in self.table.values()}|set(HALTS)|set(FAILURES))
        rows=[]
        for q in states:
            if q in HALTS:
                continue
            for a in SYMBOLS:
                n,w,m=self.table.get((q,a),("reject" if q in FAILURES else "syntax_bad",a,0))
                rows.append(dict(state=q,read=a,next=n,write=w,move=m))
        return dict(schema="deterministic-one-tape-machine-v1",symbols=SYMBOLS,states=states,
                    blank="_",start="start",accept="accept",reject="reject",
                    input_alphabet=ALPHABET,transitions=rows)


def build():
    a=Assembler()
    begin,mark,facts,scan_f,steps,scan_s,commit,prev,at_prev=(a.state(x) for x in
        ("find-first-proof","mark-current","facts","scan-facts","steps","scan-steps","commit","drop-previous","at-previous"))
    a.parser(begin)
    a.seek(begin,"P",mark)
    a.put(mark,"P",facts,w="C")
    a.left(facts,scan_f)
    a.left(steps,scan_s)
    for scan,types,bad in ((scan_f,"F","fact_bad"),(scan_s,"AID","step_bad")):
        for c in SYMBOLS:
            if c=="G":
                a.put(scan,c,bad)
            elif c not in ">$" and c not in types:
                a.put(scan,c,scan,m=1)
        for kind in types:
            trial="T"+kind
            first,second,success,failure,yes,no=(a.state(x) for x in
                ("test-first","test-second","restore-success","restore-failure","pass","retry"))
            a.put(scan,kind,first,w=trial)
            a.seek(success,trial,yes)
            a.put(yes,trial,commit if kind=="F" else prev,w=kind)
            a.seek(failure,trial,no)
            a.put(no,trial,scan,w=kind,m=1)
            if kind=="F":
                a.compare(first,trial,"x","C","x",None,second,failure)
                a.compare(second,trial,"y","C","y",None,success,failure)
            else:
                third=a.state("test-argument")
                a.compare(first,trial,"x","V","x",None,second,failure)
                a.compare(second,trial,"y","C","x",None,third,failure)
                a.compare(third,"V","y","C","y",{"I":"right","D":"left"}.get(kind),success,failure)
    a.seek(prev,"V",at_prev)
    a.put(at_prev,"V",commit,w="P")
    current,walk,next_line,goal,goal_y=(a.state(x) for x in
        ("at-current","walk-current","next-line","test-goal-predicate","test-goal-argument"))
    a.seek(commit,"C",current)
    a.put(current,"C",walk,w="V",m=1)
    for c in "x:y":
        a.put(walk,c,walk,m=1)
    a.put(walk,";",next_line,m=1)
    a.put(next_line,"P",steps,w="C")
    a.put(next_line,"!",goal)
    a.compare(goal,"G","x","V","x",None,goal_y,"goal_bad")
    a.compare(goal_y,"G","y","V","y",None,"accept","goal_bad")
    return a.machine()


def record(tag,a,b):
    assert type(a) is type(b) is int and min(a,b)>=0
    return tag+"x"*a+":"+"y"*b+";"


def problem(facts,rules,goal):
    return ">"+''.join(record("F",*p) for p in facts)+''.join(record(k,a,b) for k,a,b in rules)+record("G",*goal)+"|"


def proof(lines):
    return ''.join(record("P",*p) for p in lines)+"!"
