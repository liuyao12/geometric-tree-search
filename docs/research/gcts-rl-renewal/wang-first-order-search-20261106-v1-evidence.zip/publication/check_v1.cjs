const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-first-order-search-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 220);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("section.proof").count(), 11);
    assert.equal(await page.locator("section.proof > .table tbody tr").count(), 108);
    assert.equal(await page.locator(".lifted tbody tr").count(), 86);
    assert.equal(await page.locator(".wang-cell").count(), 495);
    assert.equal(await page.locator("#marking .atom-card dd").count(), 4);
    const factoring = page.locator("#factoring-to-universal");
    await factoring.locator(".lifted > summary").click();
    assert.equal(await factoring.locator(".lifted tbody tr:visible").count(), 4);
    assert.equal(await factoring.locator(".lifted tbody").getByText("Factor literals", { exact: false }).count(), 1);
    await factoring.locator(":scope > .table td details summary").first().click();
    await factoring.locator(":scope > .table td details code").first().waitFor();
    const geometry = page.locator("#hilbert-incidence-uniqueness");
    assert.equal(await geometry.locator(".wang-cell:visible").count(), 45);
    if (!process.argv[2]) {
      await page.locator("#marking .mark-grid").screenshot({ path: path.join(__dirname, "mark-v1.png") });
      await factoring.locator(".lifted").screenshot({ path: path.join(__dirname, "factoring-v1.png") });
      await geometry.locator("figure").screenshot({ path: path.join(__dirname, "wang-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_FIRST_ORDER_WANG_READER", proofs: 11, groundLines: 108,
      liftedLines: 86, wangCells: 495, mobileNoOverflow: true, math: await page.locator("mjx-container").count() };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
