"""Render decoded proof lines and exact windows in the Wang certificates."""
import gzip
from hashlib import sha256
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
import decode_v1 as decoder
from sparse_frame_v1 import FixedPalette, Sweeps
import tiles_v1 as til

CODE_NAME = {"zero": "0", "S": "S", "I": "I", "P": "P", "Q": "Q", "R": "R",
             "a": "a", "b": "b", "p": "p", "D": r"\operatorname{Distinct}",
             "ell": r"\ell", "Halt": r"\mathrm{Halt}"}


def math(value):
    return r"\(" + escape(value) + r"\)"


def symbol(name):
    if name in CODE_NAME:
        return CODE_NAME[name]
    if name.startswith("ell") and name[3:].isdigit():
        return r"\ell_{" + name[3:] + "}"
    if name.startswith("?"):
        tail = name[1:]
        if tail[-1:].isdigit():
            base = tail.rstrip("0123456789")
            return rf"\mathrm{{{base}}}_{{{tail[len(base):]}}}"
        return tail
    if name.startswith("$type:"):
        return r"\operatorname{" + name.split(":")[1] + "}"
    for prefix, letter in (("inhabitant", "c"), ("witness", "w"), ("At", "q")):
        if name.startswith(prefix):
            return f"{letter}_{{{name[len(prefix):]}}}"
    assert name.replace("_", "").isalnum()
    return r"\mathrm{" + name.replace("_", r"\_") + "}"


def expression(term, neg=False):
    if isinstance(term, str):
        return symbol(term)
    head, *args = term
    if head.startswith("="):
        return expression(args[0]) + (r"\ne " if neg else "=") + expression(args[1])
    value = symbol(head)
    if args:
        value += "(" + ",".join(map(expression, args)) + ")"
    return (r"\neg " if neg else "") + value


def formula(node):
    tag, *args = node
    if tag == "atom":
        return expression(args)
    if tag == "not":
        x, = args
        return expression(x[1:], True) if x[0] == "atom" else r"\neg\left(" + formula(x) + r"\right)"
    if tag in ("all", "exists"):
        name, sort, body = args
        quant = r"\forall " if tag == "all" else r"\exists "
        return quant + symbol(name) + r"{:}" + symbol(sort) + r"\," + formula(body)
    a, b = args
    op = {"implies": r"\Rightarrow", "and": r"\land", "or": r"\lor", "iff": r"\Leftrightarrow"}[tag]
    return r"\left(" + formula(a) + op + " " + formula(b) + r"\right)"


def clause(row):
    return r"\lor ".join(expression(a, not p) for p, a in row) if row else r"\bot"


def explanation(line):
    if line["rule"] == "G":
        label = line["source"]
        source = f'boundary clause <code>{escape(label)}</code>'
        bindings = [math(symbol(x) + r"\mapsto " + expression(t)) for x, t in line["bindings"].items()]
        return f"Instantiate {source} with " + ", ".join(bindings) + "." if bindings else f"Copy {source}."
    a, b = line["left"]+1, line["right"]+1
    return f"Resolve lines {a} and {b} on {math(expression(line['pivot']))}."


def load_frame(name):
    with gzip.open(ROOT/name, "rt") as stream:
        return json.load(stream)


def frame_window(machine, evidence, target, center):
    chars, _ = machine.input(evidence["prefix"], evidence["word"], evidence["padding"])
    tape = Sweeps(machine, chars)
    palette = FixedPalette(machine)
    q, h, time = machine.start, 0, 0
    x0 = max(0, min(center-4, len(chars)-9))
    rows = []

    def old(i):
        if i < 0:
            return til.L
        if i == len(chars):
            return til.R
        return til.cell(tape.symbols[tape.data[i]], q if i == h else None)

    def step(nxt, write, move):
        cols = []
        for i in range(x0, x0+9):
            after = til.cell(tape.symbols[write if i == h else tape.data[i]],
                             nxt if i == h+move else None)
            cols.append(palette.local(old(i-1), old(i), old(i+1), after))
        return cols

    for event in evidence["trace"]:
        length = event[0] if len(event) == 2 else 1
        if time + length <= target or time >= target+5:
            if time >= target+5:
                break
            if len(event) == 2:
                h += length * event[1]
            else:
                q, write, move = event
                tape.write(h, write)
                h += move
            time += length
            continue
        if len(event) == 2:
            move = event[1]
            first, last = max(0, target-time), min(length, target+5-time)
            h += first*move
            for _ in range(first, last):
                rows.append(step(q, tape.data[h], move))
                h += move
            h += (length-last)*move
        else:
            nxt, write, move = event
            rows.append(step(nxt, write, move))
            tape.write(h, write)
            q, h = nxt, h+move
        time += length
    assert len(rows) == 5
    for j, row in enumerate(rows):
        for i, t in enumerate(row):
            assert not i or row[i-1][1] == t[3]
            assert not j or rows[j-1][i][2] == t[0]
    return rows, x0+1


def color(edge):
    value = json.dumps(edge, separators=(",", ":"))
    digest = sha256(value.encode()).digest()
    hue = int.from_bytes(digest[:2], "big") % 360
    carrying_head = '"head"' in value
    lightness = (54 if carrying_head else 80) + digest[2] % 10
    return f"hsl({hue} 60% {lightness}%)"


def window_svg(machine, evidence, commit):
    time, center = commit
    rows, x = frame_window(machine, evidence, time, center)
    parts = ['<svg role="img" class="frame" viewBox="0 0 324 180" aria-label="Exact window in the Wang transition rectangle">']
    triangles = ("0,0 36,0 18,18", "36,0 36,36 18,18", "36,36 0,36 18,18", "0,36 0,0 18,18")
    for j, row in enumerate(rows):
        for i, tile in enumerate(row):
            n, e, s, w = tile
            mark = n[1][0] == "head"
            data = n[1][-1]
            label = "H" if mark else data if len(data) == 1 else "·"
            edges = f"N {n} / E {e} / S {s} / W {w}"
            parts.append(f'<g class="wang-cell" transform="translate({36*i} {36*j})"><title>{escape(edges)}</title>')
            parts.extend(f'<polygon points="{p}" fill="{color(c)}"/>' for p, c in zip(triangles, tile, strict=True))
            parts.append('<rect width="36" height="36" fill="none" stroke="#536778" stroke-width=".7"/>')
            if mark:
                parts.append('<rect class="head" x="1" y="1" width="34" height="34" fill="none" stroke="#24334e" stroke-width="2"/>')
            parts.append(f'<text x="18" y="21" text-anchor="middle">{escape(label)}</text></g>')
    parts.append("</svg>")
    return "".join(parts), f"Actual Wang rows {time+1:,}–{time+5:,}, columns {x:,}–{x+8:,}."


def proof_section(statement, proof, machine, title, key):
    evidence = load_frame(proof["artifact"])
    decoded = decoder.read(evidence["prefix"], evidence["word"])
    slots = {}
    for call in proof["attachments"]:
        recipe = call["recipe"]
        name = "Discharge " + recipe.split("-")[1] if isinstance(recipe,str) else f"Chain {recipe}"
        for i in range(call["first"],call["last"]+1):
            slots[i] = name
    rows = []
    for i, (line, raw, commit) in enumerate(zip(proof["lines"], decoded, proof["commits"], strict=True), 1):
        formula_text = math(clause(line["clause"]))
        use = slots.get(i-1)
        style = ('discharge' if use.startswith("Discharge") else 'chain') if use else ''
        label = f'<span class="badge {style}">{use}</span> ' if use else ''
        rows.append(f'<tr><th scope="row">{i}</th><td>{label}{explanation(line)}</td><td>{formula_text}</td>'
                    f'<td><details><summary>Row {commit[0]+1:,}</summary><code>{escape(raw["raw"])}</code></details></td></tr>')
    premises = "".join(f'<li>{math(formula(p))}</li>' for p in statement["premises"])
    show_premises = f'<details><summary>Original hypotheses</summary><ul>{premises}</ul></details>' if premises else ""
    fixed = "".join(f'<li><code>{escape(r["id"])}</code> {math(clause(r["clause"]))}</li>' for r in proof["source_clauses"])
    index = min(slots) if slots else len(decoded)-1
    svg, label = window_svg(machine, evidence, proof["commits"][index])
    shown = " open" if key == "hilbert-incidence-uniqueness" else ""
    return f'''<section id="{key}" class="proof">
<h2>{escape(title)}</h2>
<p class="goal">Goal {math(formula(statement["goal"]))}</p>
{show_premises}
<details><summary>Fixed source clauses</summary><p>Free variables in these clauses are universally quantified. The source clauses include the denied goal and any required sort or equality clauses.</p><ul>{fixed}</ul></details>
<div class="table"><table><thead><tr><th>Line</th><th>Reading</th><th>Clause</th><th>Tile row and raw record</th></tr></thead>
<tbody>{"".join(rows)}</tbody></table></div>
<details{shown}><summary>View the Wang squares at proof line {index+1}</summary>
<figure>{svg}<figcaption>{label} The outlined square carries the machine head. Hover over a square for its four exact colors.</figcaption></figure></details>
</section>'''


