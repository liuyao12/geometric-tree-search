"""Render paired search controls, term receptors, and decoded proof rectangles."""
from collections import defaultdict
from html import escape
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"publication"))
from proof_views_v1 import clause, expression, math, proof_section, symbol
from boundary_kernel_v1 import build

STEM="wang-first-order-search-20261106-v1"
NAMES={
    "factoring-to-universal":"A universal conclusion by factoring",
    "proof-by-cases":"Proof by cases",
    "iterate-depth-8":"An existential conclusion at term depth eight",
    "exists-map":"Existential image under implication",
    "incidence-existence":"Existence of an incident point and line",
    "peano-nonzero-successor":"The second Peano successor is nonzero",
    "hilbert-incidence-uniqueness":"Hilbert incidence uniqueness",
    "tptp-tutorial-capital":"TPTP capital exercise",
    "tptp-tutorial-family":"TPTP family exercise",
    "tptp-tutorial-family-mutation":"TPTP family mutation",
    "receiver-clash":"Rigid-clash receiver",
    "receiver-alias":"Repeated-variable receiver",
    "occurs-check-control":"Cyclic binding control",
    "quantifier-swap-control":"Quantifier swap control",
}


def load(path):
    return json.loads((ROOT/path).read_text())


def table_row(name,*columns):
    raw="".join(f'<td>{escape(str(v))}</td>' for v in columns)
    return f'<tr><th scope="row">{escape(name)}</th>{raw}</tr>'


def offer_text(run):
    result=run["status"]
    n=min(20_000,run["counts"].get("offers",0))
    suffix={"PROVED":"","BOUNDED":" · bound","SATURATED_WITHOUT_REFUTATION":" · no refutation"}[result]
    return f"{n:,}{suffix}"


def nodes_view(proof):
    rows=[]
    ground=defaultdict(set)
    for event in proof["events"]:
        if event["line"] is not None:
            ground[event["node"]].add(event["line"]+1)
    for i,node in enumerate(proof["lifted"]):
        op=node["kind"]
        if op=="source":
            origin=f'Source <code>{escape(node["schema"])}</code>'
        else:
            a,b=node["sites"]
            if op=="factor":
                parent,=node["parents"]
                origin=f"Factor literals {a+1} and {b+1} of line {parent+1}"
            else:
                left,right=node["parents"]
                origin=f"Resolve lines {left+1} and {right+1}"
            origin+=" on "+math(expression(node["pivot"]))
        links=[]
        for j,mapping in enumerate(node["maps"]):
            if not mapping:
                continue
            substitutions=", ".join(symbol(v)+r"\mapsto "+expression(t) for v,t in sorted(mapping.items()))
            label="Source" if op=="source" else f'Line {node["parents"][j]+1}'
            links.append(f"<div>{label} {math(substitutions)}</div>")
        subst="".join(links) or "—"
        where=", ".join(map(str,sorted(ground[i]))) or "—"
        rows.append(f'<tr><th scope="row">{i+1}</th><td>{origin}</td><td>{math(clause(node["clause"]))}</td>'
                    f'<td>{subst}</td><td>{where}</td></tr>')
    return f'''<details class="lifted"><summary>Open the lifted derivation</summary>
<p>Each clause’s variables have their own scope. The mappings put parent literals in the conclusion’s scope. A ground line can serve more than one lifted step.</p>
<div class="table"><table><thead><tr><th>Line</th><th>Inference</th><th>Clause with variables</th><th>Parent substitutions</th><th>Ground lines</th></tr></thead><tbody>{"".join(rows)}</tbody></table></div></details>
<h3 class="ground-label">Ground proof rows on the Wang tape</h3>'''


def selected_pair(study):
    case=next(c for c in study["cases"] if c["id"]=="receiver-alias")
    mark,a,b,_=next(v for v in case["arms"]["size-marked"]["marks"] if v[0][0]=="alias")
    _,side,p,q,r=mark
    assert side==1 and not r
    def at(atom,path):
        for i in path:
            atom=atom[i+1]
        return atom
    def card(title,term,css):
        rows="".join(f'<dt><code>{".".join(str(i+1) for i in path)}</code></dt>'
                     f'<dd><span class="badge {css}">{math(expression(at(term,path)))}</span></dd>'
                     for path in (p,q))
        return f'<div class="atom-card"><h3>{title}</h3><p>{math(expression(term))}</p><dl>{rows}</dl></div>'
    x,y=at(a,p),at(a,q)
    v=at(b,p)
    return '<div class="mark-grid">'+card("Positive atom",a,"red")+card("Atom in the negative literal",b,"chain")+f'''</div>
<p>The addresses count arguments starting at one. The negative literal uses {math(expression(v))} at both positions. Its two proposed bindings would be {math(expression(x))} and {math(expression(y))}. Their distinct constant symbols rule out a syntactic unifier.</p>'''


def bars(records):
    entries=[]
    counts=records["arms"]
    a=counts["plain"]["unifications"]
    for mode,label in (("plain","Plain"),("memo","Exact memo"),("marks","Learned marks")):
        n=counts[mode]["unifications"]
        css=" marked" if mode=="marks" else ""
        entries.append(f'<div class="bar-row"><span>{label}</span><div class="bar-track"><div class="bar{css}" '
                       f'style="width:{100*n/a:.2f}%"></div></div><strong>{n}</strong></div>')
    return "".join(entries)


def main():
    study=load("data/search-v1.json")
    cohort=load("input/cohort-v1.json")
    frames=load("data/frames-v1.json")
    audit=load("data/audit-v1.json")
    memo=load("data/memo-v1.json")
    timings=load("data/timing-v1.json")
    machine=build().compile()
    assert machine.digest()==frames["machine_sha256"]
    index={r["id"]:r for r in frames["frames"]}
    results,proofs,links,comparison=[],[],[],[]
    for case,row in zip(cohort["holdout"],study["cases"],strict=True):
        key=case["id"]
        assert key==row["id"]
        name=NAMES[key]
        arms=row["arms"]
        selected=arms[row["selected_policy"]]
        proof=row.get("proof")
        results.append(table_row(name,offer_text(arms["size"]),offer_text(arms["goal"]),offer_text(selected),
                                 len(proof["lifted"]) if proof else "—",len(proof["lines"]) if proof else "—"))
        if proof:
            f={**proof,**index[key],"attachments":[]}
            section=proof_section(case,f,machine,name,key)
            section=section.replace('<div class="table">',nodes_view(proof)+'<div class="table">',1)
            proofs.append(section)
            links.append(f'<a href="#{key}">{escape(name)}</a>')
    chart=None
    for x,y in zip(memo["comparisons"],timings["cases"],strict=True):
        key,order=x["id"],x["order"]
        assert key==y["id"] and order==y["order"]
        arms=x["arms"]
        vals=[arms[m]["unifications"] for m in ("plain","memo","marks")]
        ms=[f'{y["medians"][m]/1000:.2f}' for m in ("plain","memo","marks")]
        label="smallest first" if order=="size" else "goal-directed"
        comparison.append(table_row(f"{NAMES[key]} · {label}",*vals,arms["marks"]["mark_tests"],*ms))
        if key=="receiver-alias" and order=="size":
            chart=bars(x)
    assert len(proofs)==len(frames["frames"])==len(audit["cases"])
    template=(ROOT/"publication/notebook-v1.html").read_text()
    replacements=dict(STEM=STEM,MARK=selected_pair(study),CHART=chart,MEMO="".join(comparison),
                      RESULTS="".join(results),PROOFS="\n".join(proofs),LINKS="".join(links),
                      TRAIN=str(len(study["episodes"])),LIFTED=str(sum(audit["lifted"].values())),
                      GROUND=str(audit["ground"]),FRAMES=str(len(proofs)))
    for key,value in replacements.items():
        template=template.replace("%%"+key+"%%",value)
    assert "%%" not in template
    (ROOT/"report"/f"{STEM}.html").write_text(template)


if __name__=="__main__":
    main()
