# Replay the lifted Wang proof search

Use Python 3.12 and its standard library. From an extracted archive root,
preserve the supplied evidence and run the following commands.

    mv data archived-data
    mkdir data
    python3.12 -I -S -B source/lifted_cases_v1.py
    python3.12 -I -S -B source/lifted_experiment_v1.py
    python3.12 -I -S -B source/lifted_frames_v1.py
    python3.12 -I -S -B source/lifted_audit_v1.py
    python3.12 -I -S -B source/lifted_memo_v1.py

The first two scripts freeze the statements, train the exclusion bank
and ranker, and run the paired search. The third builds the fixed
translation-only Wang palette and emits accepting rectangles. The audit
independently checks the lifted substitutions, normalized boundary,
ground rules, compressed Wang traces, and finite countermodels. It can
also run directly against the supplied evidence. The last script runs
the exact-cache comparison and records separate wall-clock trials.

Compare deterministic scientific outputs with `publication/replay-v1.json`.
To recreate the published HTML byte for byte, restore
`archived-data/timing-v1.json` into `data` and run
`python3.12 -I -S -B publication/render_v1.py`.

The browser test uses Node, Playwright, Chrome and MathJax. Set
`GCTS_CHROME` and `GCTS_PLAYWRIGHT` for custom installations and run
`node publication/check_v1.cjs`.

The two first-order tutorial statements and the mutated conjecture
are adapted from the TPTP first-order tutorial at
https://tptp.org/UserDocs/TPTPWorldTutorial/LogicFOF.html.
