"""Compile first-order refutations into the established translation-only Wang palette."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from boundary_kernel_v1 import build
from herbrand_v1 import frozen
import front_v1 as front
import herbrand_v1 as fol
from lifted_experiment_v1 import ROOT, load, save
from sparse_frame_v1 import execute, verify
from study_v1 import Certificate, guarded, write_gzip

EXPECTED="3d97b22704bf8da27992d74dfb897c312da9274d0cb6298ef447498a7db2c4b6"
CAP=120_000_000_000


def restore(case,lines):
    normal,_=front.clausify(case,1024)
    f,p,clauses=fol.signature(normal)
    sources,guards=guarded(clauses,f,normal["sorts"])
    b=Certificate(sources,f,p,normal["sorts"],guards)
    for row in lines:
        if row["rule"]=="G":
            i=b.instance(row["source"],{v:frozen(t) for v,t in row["bindings"].items()})
        else:
            assert row["rule"]=="R"
            i=b.resolve(row["left"],row["right"],frozen(row["pivot"]))
        assert tuple(b.lines[i]["clause"])==frozen(row["clause"])
    assert not b.lines[-1]["clause"]
    return b


def main():
    machine=build().compile()
    assert machine.digest()==EXPECTED
    study=load("data/search-v1.json")
    cohort=load("input/cohort-v1.json")
    outputs=[]
    for spec,case in zip(cohort["holdout"],study["cases"],strict=True):
        assert spec["id"]==case["id"]
        proof=case.get("proof")
        if proof is None:
            continue
        b=restore(spec,proof["lines"])
        prefix,word=b.prefix(),b.words()
        raw=execute(machine,prefix,word,1,CAP)
        if raw["status"]!="ACCEPT":
            raise ValueError((spec["id"],raw["status"],raw["steps"]))
        receipt=verify(machine,prefix,word,1,raw["trace"],CAP)
        assert len(raw["commits"])==len(b.lines)
        name=f"data/{spec['id']}-frame-v1.json.gz"
        write_gzip(ROOT/name,dict(prefix=prefix,word=word,padding=1,trace=raw["trace"],
                                 machine_sha256=EXPECTED))
        outputs.append(dict(id=spec["id"],artifact=name,receipt=receipt,commits=raw["commits"]))
        print(spec["id"],"lines",len(b.lines),"steps",receipt["steps"],flush=True)
    save("data/frames-v1.json",dict(status="ACCEPTED_FIXED_WANG_FRAMES",machine_sha256=EXPECTED,
                                   frames=outputs))


if __name__=="__main__":
    main()
