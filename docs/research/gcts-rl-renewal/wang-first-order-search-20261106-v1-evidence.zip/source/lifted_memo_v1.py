"""Compare trained addresses with an ordinary exact cache of failed atom pairs."""
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from herbrand_v1 import frozen
from lifted_experiment_v1 import LIMITS, load, save
from lifted_prover_v1 import Prover

LABELS=("iterate-depth-8","receiver-clash","receiver-alias")
MODES=("plain","memo","marks")


def main():
    study=load("data/search-v1.json")
    cohort=load("input/cohort-v1.json")
    bank=tuple(frozen(d["mark"]) for d in study["donors"])
    comparisons,timings=[],[]
    for case in cohort["holdout"]:
        if case["id"] not in LABELS:
            continue
        for order in ("size","goal"):
            arms={}
            elapsed={mode:[] for mode in MODES}
            baseline=None
            for i in range(18):
                cycle=i%len(MODES)
                for mode in (*MODES[cycle:],*MODES[:cycle]):
                    start=perf_counter_ns()
                    engine=Prover(case,order=order,marks=bank if mode=="marks" else (),
                                  memo=mode=="memo",**LIMITS)
                    outcome,root=engine.run()
                    elapsed[mode].append((perf_counter_ns()-start)//1000)
                    assert outcome=="PROVED"
                    proof=engine.proof(root)
                    if baseline is None:
                        baseline=proof
                    assert proof==baseline
                    counts=dict(engine.counts)
                    assert arms.setdefault(mode,counts)==counts
            prior=next(r for r in study["cases"] if r["id"]==case["id"])["arms"]
            assert arms["plain"]==prior[order]["counts"]
            assert arms["marks"]==prior[order+"-marked"]["counts"]
            assert arms["plain"]["unifications"]-arms["memo"]["unifications"]==arms["memo"].get("exact_memo_skips",0)
            comparisons.append(dict(id=case["id"],order=order,arms=arms))
            timings.append(dict(id=case["id"],order=order,samples=elapsed,
                                medians={m:median(v) for m,v in elapsed.items()}))
    save("data/memo-v1.json",dict(status="CHECKED_EXACT_MEMO_COMPARISONS",comparisons=comparisons))
    save("data/timing-v1.json",dict(status="LOCAL_PROOF_SEARCH_TIMINGS",trials=18,cases=timings))


if __name__=="__main__":
    main()
