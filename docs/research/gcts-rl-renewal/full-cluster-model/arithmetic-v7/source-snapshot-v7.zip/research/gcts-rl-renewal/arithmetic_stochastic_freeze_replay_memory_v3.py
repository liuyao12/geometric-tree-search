"""Freeze a loading-only v3 repair; no search, training, native or full replay.

Only the separately bounded seven pure decoder helpers are locally executable.
The six actual full replays require an exact root-authored activation receipt.
"""
import ast
import datetime
import hashlib
import json
import time
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'.gcts-active/stochastic-replay-memory-20261011'
OLD=ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011/execution-v2'
RSS=512*1024*1024
HISTORICAL=18.112109042
V1_HELPERS=44.927988292
V2_HELPERS=11.562686832999999
V2_EVALUATION=38.059562
CHARGED=112.662346167


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()


def rel(path):
    return str(path.relative_to(ROOT))


def save(path,value):
    with path.open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')
    return sha(path)


def main():
    began=time.perf_counter()
    if (OUT/'review-package-v3.json').exists():raise ValueError('immutable repair freeze exists')
    original_path=OLD/'evaluation/independent-audit-plan.json'
    original=json.loads(original_path.read_bytes())
    sources=dict(json.loads((OUT/'evaluation-plan-v2.json').read_bytes())['source_sha256'])
    for name in ('arithmetic_stochastic_replay_memory_v3.py',
                 'arithmetic_stochastic_worker_replay_memory_v3.py',
                 'arithmetic_stochastic_fixture_replay_memory_v3.py',
                 'arithmetic_stochastic_owner_replay_memory_v3.py',
                 'arithmetic_stochastic_freeze_replay_memory_v3.py',
                 'commutativity_cluster_intern_v3.py','commutativity13_json.py'):
        path=ROOT/'research/gcts-rl-renewal'/name
        sources[rel(path)]=sha(path)
    for path,digest in sources.items():
        if sha(ROOT/path)!=digest:raise ValueError('old frozen semantic source changed '+path)
        ast.parse((ROOT/path).read_text(),filename=path)
    inputs=dict(original['input_sha256'])
    for path in (original_path,OLD/'evaluation/independent-audit.json',
                 OLD/'evaluation/base-r1-audit.json',ROOT/'docs/basic-tiling-algorithm.md',
                 OUT/'review-package-v1.json',OUT/'evaluation-plan-v1.json',OUT/'source-snapshot-v1.zip',
                 OUT/'helper-plan-v1.json',OUT/'helpers-v1/phase-receipt.json',
                 OUT/'review-package-v2.json',OUT/'evaluation-plan-v2.json',OUT/'source-snapshot-v2.zip',
                 OUT/'helper-plan-v2.json',OUT/'helpers-v2/phase-receipt.json',OUT/'evaluation-v2/phase-receipt.json'):
        inputs[rel(path)]=sha(path)
    for path,digest in inputs.items():
        if sha(ROOT/path)!=digest:raise ValueError('old frozen input changed '+path)
    old_unknown=json.loads((OLD/'evaluation/independent-audit.json').read_bytes())
    if old_unknown['status']!='unknown_independent_phase_resource_budget':
        raise ValueError('retain actual historical resource unknown')
    if abs(old_unknown['seconds_before_final_phase_receipt_write']-HISTORICAL)>1e-10:
        raise ValueError('retain exact historical audit cost')
    v1_helpers=json.loads((OUT/'helpers-v1/phase-receipt.json').read_bytes())
    if v1_helpers['seconds_before_phase_receipt_write']!=V1_HELPERS or v1_helpers['status']!='unknown_or_failed_loading_worker_gate':
        raise ValueError('retain exact failed v1 helper phase')
    v2_helpers=json.loads((OUT/'helpers-v2/phase-receipt.json').read_bytes())
    v2_evaluation=json.loads((OUT/'evaluation-v2/phase-receipt.json').read_bytes())
    if v2_helpers['seconds_before_phase_receipt_write']!=V2_HELPERS or v2_helpers['status']!='passed_complete_loading_value_correspondence_helpers':
        raise ValueError('retain exact passed v2 helper phase')
    if v2_evaluation['seconds_before_phase_receipt_write']!=V2_EVALUATION or v2_evaluation['status']!='unknown_loading_phase_resource_budget' or v2_evaluation['cumulative_audit_seconds_before_phase_receipt_write']!=CHARGED:
        raise ValueError('retain exact v2 memory unknown and cumulative clock')
    helpers=OUT/'helpers-v3';evaluation=OUT/'evaluation-v3'
    helpers.mkdir();evaluation.mkdir()
    helper_sources={p:h for p,h in sources.items() if Path(p).name in (
        'arithmetic_stochastic_replay_memory_v1.py','arithmetic_stochastic_replay_memory_v2.py',
        'arithmetic_stochastic_replay_memory_v3.py','arithmetic_stochastic_fixture_replay_memory_v3.py',
        'arithmetic_stochastic_owner_replay_memory_v3.py','arithmetic_stochastic_freeze_replay_memory_v3.py')}
    helper_jobs=[];pairs=[];helper_inputs={rel(ROOT/'docs/basic-tiling-algorithm.md'):inputs[rel(ROOT/'docs/basic-tiling-algorithm.md')]}
    def helper(job,mode,trace=None):
        plan=dict(job=job,mode=mode,seconds=25,rss_bytes=RSS,
                  source_sha256=helper_sources,input_sha256={},output_path=rel(helpers/(job+'.json')),
                  searches=0,training_episodes=0,native_queries=0,graph_replays=0)
        if trace is not None:
            plan['trace_path']=rel(trace);plan['input_sha256'][rel(trace)]=sha(trace)
            helper_inputs[rel(trace)]=sha(trace)
        path=helpers/(job+'-plan.json');digest=save(path,plan)
        helper_jobs.append(dict(job=job,plan_path=rel(path),plan_sha256=digest,
                               output_path=plan['output_path'],lifecycle_seconds=30))
    helper('synthetic-controls','controls')
    for job,trace in (('effect-pilot',OLD/'effect/effect-pilot-search.json.gz'),
                      ('train-01',OLD/'training/train-01-search.json.gz'),
                      ('train-08',OLD/'training/train-08-search.json.gz')):
        a,b=job+'-reference',job+'-repaired'
        helper(a,'reference',trace);helper(b,'repaired',trace);pairs.append([a,b])
    helper_plan=dict(status='frozen_before_pure_loading_helpers',kind='helpers',seconds=180,rss_bytes=RSS,
        historical_failed_audit_seconds=CHARGED,requires_root_activation=False,
        source_sha256=helper_sources,input_sha256=helper_inputs,jobs=helper_jobs,correspondence_pairs=pairs,
        worker_source='research/gcts-rl-renewal/arithmetic_stochastic_fixture_replay_memory_v3.py',
        worker_pass_status='passed_complete_loading_value_helper',output_path=rel(helpers/'phase-receipt.json'),
        scope='Seven complete positive synthetic values, nine fail-closed scope/parser controls, seven exact compact byte checks, assigned-zero mutation and three noncompact lexical controls; three full501-node ordinary/repaired value pairs, BOTH reference and repaired receive complete exact original byte comparison; fingerprints are original compact bytes, not sorted canonical traversal. Pure decoding only, no graph/search/training/native execution.',
        clock='180s full helper owner phase;25s internal/30s owned lifetime each; actual phase cost subtracted from original780s evaluation audit, retained112.662346167s original+v1helpers+v2helpers+v2evaluation charged once.')
    helper_path=OUT/'helper-plan-v3.json';helper_digest=save(helper_path,helper_plan)
    jobs=[]
    for old_job in original['jobs']:
        old_path=ROOT/old_job['plan_path'];inputs[rel(old_path)]=sha(old_path)
        plan=json.loads(old_path.read_bytes())
        plan['source_sha256']=sources
        plan['output_path']=rel(evaluation/(old_job['job']+'-audit.json'))
        plan['loading_only_repair']='Complete interned trace followed by exact full original compact byte comparison before unchanged graph/policy/math replay. No field/node/event/census omitted.'
        path=evaluation/(old_job['job']+'-plan.json');digest=save(path,plan)
        jobs.append(dict(job=old_job['job'],plan_path=rel(path),plan_sha256=digest,
                         output_path=plan['output_path'],lifecycle_seconds=120))
    eval_plan=dict(status='frozen_before_root_review_and_actual_six_replays',kind='evaluation',
        seconds=780-CHARGED,rss_bytes=RSS,original_cumulative_audit_seconds=780,
        historical_failed_audit_seconds=CHARGED,requires_root_activation=True,
        helper_receipt_path=helper_plan['output_path'],helper_plan_sha256=helper_digest,
        source_sha256=sources,input_sha256=inputs,jobs=jobs,
        worker_source='research/gcts-rl-renewal/arithmetic_stochastic_worker_replay_memory_v3.py',
        worker_pass_status='passed_complete_actual_graph_rng_and_policy_replay',
        output_path=rel(evaluation/'phase-receipt.json'),
        semantic_model_sha256='b131949034b0e396ab885a5a94b870f12d1443e2bdc5df0550963ec0e0698c11',
        unchanged='All original root independent engine/policy/math sources and original job inputs retained byte-identically. Only load implementation, complete loading byte-correspondence gate, new output paths and lifetime wrapper differ.',
        complete_gate='All six trace values receive full byte correspondence before unchanged full graph/event/feature/RNG/hint/fallback/rollback checks. Any mismatch, resource unknown, missing artifact or failed job stops remaining jobs; unknown and unexecuted labels preserved.',
        budgets='Original780s minus112.662346167s earlier inclusive audit/helper phases and measured complete helper phase.115s internal120s full lifecycle per actualworker unchanged,512MiB conservative fresh-worker plus owner kernel peak. No audit restart or increase; source writing/preparation separately disclosed.',
        root_activation='Controlled sole-owner route requires activation-v3.json authorizing exact plan and passed helper receipt hashes. The pure worker CLI is technically callable directly; root ownership governs actual execution.',
        queries=dict(searches=0,training_episodes=0,native_queries=0))
    eval_path=OUT/'evaluation-plan-v3.json';eval_digest=save(eval_path,eval_plan)
    zip_path=OUT/'source-snapshot-v3.zip'
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(sources):archive.write(ROOT/path,path)
    start=json.loads((OUT/'authoring-start.json').read_bytes())
    current=datetime.datetime.now(datetime.timezone.utc)
    began_utc=datetime.datetime.strptime(start['utc_start'],'%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=datetime.timezone.utc)
    paths=[helper_path,eval_path,zip_path,OUT/'authoring-start.json']+[ROOT/j['plan_path'] for j in helper_jobs+jobs]
    package=dict(status='frozen_source_ready_loading_only_review_package',
        helper_plan=dict(path=rel(helper_path),sha256=helper_digest),
        evaluation_plan=dict(path=rel(eval_path),sha256=eval_digest),
        sources=sources,inputs=inputs,files=[dict(path=rel(p),sha256=sha(p),bytes=p.stat().st_size) for p in paths],
        ast_parse_count=len(sources),source_preparation_seconds_before_package_write=time.perf_counter()-began,
        authoring_calendar_interval_seconds=(current-began_utc).total_seconds(),
        authoring_scope='UTC elapsed since explicit source-writing marker, includes waits/interleaved work; not CPU effort. Earlier reading/design uninstrumented and unknown. Stored perf_counter marker not cross-process comparable on this host and not used as elapsed measurement.',
        prior_phases_preserved=[dict(path=rel(OLD/'evaluation/independent-audit.json'),sha256=sha(OLD/'evaluation/independent-audit.json'),seconds=HISTORICAL),dict(path=rel(OUT/'helpers-v1/phase-receipt.json'),sha256=sha(OUT/'helpers-v1/phase-receipt.json'),seconds=V1_HELPERS),dict(path=rel(OUT/'helpers-v2/phase-receipt.json'),sha256=sha(OUT/'helpers-v2/phase-receipt.json'),seconds=V2_HELPERS),dict(path=rel(OUT/'evaluation-v2/phase-receipt.json'),sha256=sha(OUT/'evaluation-v2/phase-receipt.json'),seconds=V2_EVALUATION)],
        actual_full_evaluation_replays_executed=0,searches=0,training_episodes=0,native_queries=0,
        prospective_feasibility='V2 all501-helper values passed and fullbase5001-node byte/graph audit completed but fullowner551485440B exceeded512MiB by14614528B. V3 reduces the entire-tape-string peak via recursive hierarchy read plus bounded ordinary-field lexical scans followed by one standard JSONDecoder call. Same strict reduction, tuple sharing and exact unchanged V2 full-byte gate; all fields preserved.32Mi-character ordinary field cap and2MiB reducer partial-token cap are explicit resource unknowns, not omissions. All-six feasibility remains unresolved until actual complete independent replay.')
    save(OUT/'review-package-v3.json',package)
    print(json.dumps(dict(status=package['status'],helper_plan_sha256=helper_digest,
        evaluation_plan_sha256=eval_digest,review_package_sha256=sha(OUT/'review-package-v3.json'),
        preparation_seconds_before_package_write=package['source_preparation_seconds_before_package_write'])),flush=True)


if __name__=='__main__':main()
