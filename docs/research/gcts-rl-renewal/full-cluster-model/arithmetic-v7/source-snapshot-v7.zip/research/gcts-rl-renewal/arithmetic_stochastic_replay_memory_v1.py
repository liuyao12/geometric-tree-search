"""Loading-only, value-preserving shared four-integer arrays for object roots.

Derived from the pinned commutativity_cluster_intern_v3 streaming decoder.
The graph/policy/math auditor consumes every original decoded field unchanged.
Strict integer grammar avoids turning invalid leading-zero JSON into valid JSON.
Reserved-prefix collisions and non-object roots fail closed; original trace
files are read only, and all temporary reduced files live in the new folder.
"""
import gzip
import hashlib
import json
import re
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEMP = ROOT/'.gcts-active/stochastic-replay-memory-20261011/decoder-temp'
INT = rb'-?(?:0|[1-9]\d*)'
TOKEN = re.compile(rb'(?P<string>"(?:[^"\\]|\\.)*")|(?P<partial>"(?:[^"\\]|\\.)*(?:\\)?$)|\[\s*(?P<a>'+INT+rb')\s*,\s*(?P<b>'+INT+rb')\s*,\s*(?P<c>'+INT+rb')\s*,\s*(?P<d>'+INT+rb')\s*\]')
_STATISTICS = []


def statistics():
    return list(_STATISTICS)


def exact_compact_bytes(path, value):
    """Compare every byte of the original gzip member with its decoded value.

    This is deliberately scoped to the pinned compact UTF-8 JSON protocol,
    not arbitrary lexical JSON. Tuple arrays serialize exactly as list arrays.
    No sorted keys, skipped fields, copied tree or complete output string.
    Duplicate keys, lexical negative integer zero and other normalization that
    loses original bytes fail closed even if ordinary JSON value agrees.
    """
    began = time.perf_counter()
    original_hash, emitted_hash = hashlib.sha256(), hashlib.sha256()
    byte_count, chunks, buffered, pieces = 0, 0, 0, []
    encoder = json.JSONEncoder(ensure_ascii=False, separators=(',', ':'))
    with gzip.open(path, 'rb') as original:
        def compare(parts):
            nonlocal byte_count, chunks
            emitted = ''.join(parts).encode('utf-8')
            actual = original.read(len(emitted))
            original_hash.update(actual); emitted_hash.update(emitted)
            if actual != emitted:
                first = next((i for i, (a, b) in enumerate(zip(actual, emitted)) if a != b), min(len(actual), len(emitted)))
                raise ValueError('complete compact JSON byte mismatch at offset %d' % (byte_count+first))
            byte_count += len(emitted); chunks += 1

        for piece in encoder.iterencode(value):
            pieces.append(piece); buffered += len(piece)
            if buffered >= 65536:
                compare(pieces); pieces, buffered = [], 0
        if pieces:
            compare(pieces)
        if original.read(1):
            raise ValueError('complete compact JSON original has trailing bytes')
    return dict(status='passed_complete_original_compact_json_byte_correspondence',
        seconds=time.perf_counter()-began, bytes=byte_count, chunks=chunks,
        original_uncompressed_sha256=original_hash.hexdigest(), emitted_sha256=emitted_hash.hexdigest(),
        scope='Every frozen original UTF-8 byte compared with full insertion-order JSONEncoder.iterencode(decoded value), tuple/list arrays normalized by JSON. No omitted key, field, node, event or census; no whole original inflation or whole reserialization.')


def load(path):
    path = Path(path)
    began = time.perf_counter()
    if path.suffix != '.gz':
        with path.open('rt') as stream:
            result = json.load(stream)
        if not isinstance(result, dict):
            raise ValueError('declared object-root loading scope')
        _STATISTICS.append(dict(path=str(path), seconds=time.perf_counter()-began,
                               kind='ordinary_small_object_json', shared_arrays=0))
        return result
    TEMP.mkdir(exist_ok=True)
    arrays, indexes, input_bytes, occurrences, strings = [], {}, 0, 0, 0
    with tempfile.TemporaryFile('w+b', dir=TEMP) as reduced:
        with gzip.open(path, 'rb') as source:
            pending = b''
            while True:
                part = source.read(65536)
                input_bytes += len(part)
                eof = not part
                data = pending+part
                last = 0
                for match in TOKEN.finditer(data):
                    if match.group('partial') is not None:
                        break
                    reduced.write(data[last:match.start()])
                    if match.group('string') is not None:
                        original = match.group('string')
                        if json.loads(original).startswith('#'):
                            raise ValueError('reserved interning string collision')
                        strings += 1
                        reduced.write(original)
                    else:
                        key = tuple(int(match.group(name)) for name in ('a','b','c','d'))
                        index = indexes.get(key)
                        if index is None:
                            index = len(arrays)
                            indexes[key] = index
                            arrays.append(key)
                        occurrences += 1
                        reduced.write(('"#%d"' % index).encode())
                    last = match.end()
                pending = data[last:]
                if eof:
                    reduced.write(pending)
                    break
                if len(pending) > 2097152:
                    raise ValueError('unknown_decoder_long_token_resource_budget')
        reduced_bytes = reduced.tell()
        reduced.seek(0)

        def restore(value):
            if isinstance(value, str) and value.startswith('#'):
                index = int(value[1:])
                if str(index) != value[1:] or not 0 <= index < len(arrays):
                    raise ValueError('invalid reversible array reference')
                return arrays[index]
            if isinstance(value, list):
                return [restore(x) if not isinstance(x, dict) else x for x in value]
            return value

        def hook(obj):
            return {key: restore(value) for key, value in obj.items()}

        result = json.load(reduced, object_hook=hook)
    if not isinstance(result, dict):
        raise ValueError('declared object-root loading scope')
    _STATISTICS.append(dict(path=str(path), kind='streamed_reversible_four_integer_array_sharing',
        seconds=time.perf_counter()-began, original_uncompressed_bytes=input_bytes,
        reduced_temporary_json_bytes=reduced_bytes, shared_arrays=len(arrays),
        array_occurrences=occurrences, quoted_strings_checked=strings,
        scope='Complete JSON value preserved, tuple/list JSON equivalence; Python json duplicate-key last-wins semantics unchanged. No original field/census/event omitted.'))
    return result
