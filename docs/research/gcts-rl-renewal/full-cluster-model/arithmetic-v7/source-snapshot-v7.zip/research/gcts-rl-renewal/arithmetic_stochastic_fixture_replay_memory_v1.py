"""Fresh bounded decoder-value controls, never graph replay or proof search."""
import argparse
import gzip
import hashlib
import json
import resource
import signal
import tempfile
import time
from pathlib import Path
from arithmetic_stochastic_replay_memory_v1 import load, statistics, exact_compact_bytes

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'.gcts-active/stochastic-replay-memory-20261011'


def digest(value):
    h, parts, size, count = hashlib.sha256(), [], 0, 0
    for part in json.JSONEncoder(sort_keys=True, separators=(',', ':'), ensure_ascii=False).iterencode(value):
        parts.append(part);size += len(part)
        if size >= 65536:
            raw = ''.join(parts).encode();h.update(raw);count += len(raw)
            parts, size = [], 0
    raw = ''.join(parts).encode();h.update(raw)
    return dict(sha256=h.hexdigest(), bytes=count+len(raw))


def controls():
    numeric = dict(integer=[0,-1,2147483648,999999999999999999], signed_zero=[-0,0,0,0],
        floats=[1.0,2,3,4], scientific=[1e-30,1e30,-0.0,3.141592653589793],
        booleans=[True,False,1,0], nested=[[[1,2,3,4]], {'inside': [1,2,3,4]}],
        null=None, roots={'point': [0,0]}, state={'assigned_zero': 0})
    rows = [('numeric-nested',json.dumps(numeric).encode()),
            ('strings-escapes-unicode',json.dumps(dict(text='literal[1,2,3,4]', quoted='\\\"[5,6,7,8]',
                unicode='é λ 😀', escaped='line\n\t slash\\ end', tokens=['command:0:0:abc','port:1:0:-2:none'])).encode()),
            ('chunk-quoted-boundary',json.dumps(dict(text='A'*65532+'\\\"[1,2,3,4]',
                long_array=[[i,i+1,i+2,i+3] for i in range(2000)], after=[1,2,3,4])).encode()),
            ('duplicate-key-last-wins',b'{"a":[1,2,3,4],"a":[5,6,7,8],"nested":{"x":0,"x":1},"a\\u0072r":[9,10,11,12],"arr":[13,14,15,16]}'),
            ('shared-arrays-identity',json.dumps(dict(repeat=[[1,2,3,4]]*20000)).encode())]
    receipts, byte_receipts = [], []
    OUT.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=OUT) as temp:
        folder = Path(temp)
        for index,(name,raw) in enumerate(rows):
            file = folder/('%02d.json.gz' % index);file.write_bytes(gzip.compress(raw,mtime=0))
            expected, actual = json.loads(raw), load(file)
            a,b = digest(expected),digest(actual)
            if a != b:
                raise ValueError('complete synthetic JSON value mismatch '+name)
            if name == 'shared-arrays-identity' and actual['repeat'][0] is not actual['repeat'][-1]:
                raise ValueError('shared array storage not implemented')
            receipts.append(dict(name=name,canonical=a,input_sha256=hashlib.sha256(raw).hexdigest(),
                                 compressed_sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
            compact=json.dumps(expected,ensure_ascii=False,separators=(',',':')).encode('utf-8')
            compact_file=folder/('%02d-compact.json.gz' % index)
            compact_file.write_bytes(gzip.compress(compact,mtime=0))
            decoded=load(compact_file)
            byte_receipts.append(dict(name=name,correspondence=exact_compact_bytes(compact_file,decoded)))
            if name=='numeric-nested':
                decoded['state']['assigned_zero']=1
                try:exact_compact_bytes(compact_file,decoded)
                except ValueError:pass
                else:raise ValueError('exact byte gate failed to reject changed assigned zero')
        negatives = [
            ('reserved-value',b'{"value":"#0"}'),('reserved-key',b'{"#0":"value"}'),
            ('escaped-reserved',b'{"value":"\\u00230"}'),('escaped-reserved-key',b'{"\\u00230":0}'),('leading-zero',b'{"a":[01,2,3,4]}'),
            ('negative-leading-zero',b'{"a":[-01,2,3,4]}'),('nonobject-root',b'[1,2,3,4]'),
            ('scalar-root',b'"text"'),('truncated-json',b'{"a":[1,2,3,4]')]
        rejected = []
        for index,(name,raw) in enumerate(negatives):
            file=folder/('negative-%d.json.gz' % index);file.write_bytes(gzip.compress(raw,mtime=0))
            try:load(file)
            except (ValueError,TypeError,IndexError):rejected.append(name)
            else:raise ValueError('scope/malformed fixture accepted '+name)
        lexical_rejected=[]
        for index,(name,raw) in enumerate([('duplicate-key',b'{"a":0,"a":1}'),('negative-integer-zero',b'{"a":[-0,0,0,0]}'),('whitespace',b'{"a": [1,2,3,4]}')]):
            file=folder/('lexical-%d.json.gz' % index);file.write_bytes(gzip.compress(raw,mtime=0))
            decoded=load(file)
            try:exact_compact_bytes(file,decoded)
            except ValueError:lexical_rejected.append(name)
            else:raise ValueError('lexical mismatch silently accepted '+name)
    return dict(status='passed_complete_synthetic_loading_value_controls',positive=receipts,
        compact_byte_correspondence=byte_receipts,byte_gate_mutants_rejected=['changed-assigned-zero'],lexical_noncompact_rejected=lexical_rejected,
        rejected=rejected,duplicate_key_semantics='Python json last value wins, including equivalent escaped keys.',
        root_scope='Object-root artifacts only. Reserved# strings/keys rejected for compressed artifacts, malformed leading-zero arrays remain rejected.',
        searches=0,training_episodes=0,native_queries=0,graph_replays=0)


def timeout(*_):
    raise TimeoutError('decoder helper internal wall ceiling')


def main(plan_path):
    began=time.perf_counter();plan=json.loads(plan_path.read_bytes());output=ROOT/plan['output_path']
    if output.exists():raise ValueError('immutable helper output exists')
    result=dict(status='running_loading_value_helper',job=plan['job'],mode=plan['mode'],
                plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),searches=0,training_episodes=0,native_queries=0,graph_replays=0)
    signal.signal(signal.SIGALRM,timeout);signal.setitimer(signal.ITIMER_REAL,plan['seconds'])
    try:
        for p,h in {**plan['source_sha256'],**plan['input_sha256']}.items():
            with (ROOT/p).open('rb') as stream:
                sha=hashlib.sha256()
                for block in iter(lambda:stream.read(1048576),b''):sha.update(block)
            if sha.hexdigest()!=h:raise ValueError('frozen loading helper pin '+p)
        if plan['mode']=='controls':result['controls']=controls()
        else:
            path=ROOT/plan['trace_path']
            if plan['mode']=='reference':
                with gzip.open(path,'rt') as stream:value=json.load(stream)
            elif plan['mode']=='repaired':
                value=load(path)
                result['complete_original_trace_byte_correspondence']=exact_compact_bytes(path,value)
            else:raise ValueError('declared decoder helper mode')
            result['canonical']=digest(value)
            result['observation']=value['observation']
            result['nodes']=value['search']['metrics']['nodes']
            result['events']=len(value['search']['events'])
            result['weights_sha256']=value['search']['weights_sha256']
        result['status']='passed_complete_loading_value_helper'
    except Exception as exc:
        result.update(status='failed_or_unknown_loading_value_helper',failure_type=type(exc).__name__,failure=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        result.update(seconds_before_receipt_write=time.perf_counter()-began,
                      kernel_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,loading=statistics())
        if result['seconds_before_receipt_write']>plan['seconds'] or result['kernel_peak_rss_bytes']>plan['rss_bytes']:
            result['status']='unknown_loading_value_helper_resource_budget'
        with output.open('x') as stream:stream.write(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',required=True)
    main(Path(parser.parse_args().plan))
