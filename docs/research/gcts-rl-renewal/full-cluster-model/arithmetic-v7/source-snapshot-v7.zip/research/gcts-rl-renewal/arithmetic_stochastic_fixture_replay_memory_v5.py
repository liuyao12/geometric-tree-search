"""Fresh bounded decoder-value controls, never graph replay or proof search."""
import argparse
import copy
import gzip
import hashlib
import json
import resource
import signal
import tempfile
import time
from pathlib import Path
from arithmetic_stochastic_replay_memory_v5 import load, load_trace, statistics, exact_compact_bytes

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'.gcts-active/stochastic-replay-memory-v5-20261011'


def digest(value):
    # Synthetic bounded generic objects only. Actual traces use full original
    # compact-byte fingerprint, not redundant sorted scalar traversal.
    raw=json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')
    return dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))


def controls():
    numeric = dict(integer=[0,-1,2147483648,999999999999999999], signed_zero=[-0,0,0,0],
        floats=[1.0,2,3,4], scientific=[1e-30,1e30,-0.0,3.141592653589793],
        booleans=[True,False,1,0], nested=[[[1,2,3,4]], {'inside': [1,2,3,4]}],
        null=None, roots={'point': [0,0]}, state={'assigned_zero': 0})
    rows = [('numeric-nested',json.dumps(numeric).encode()),
            ('strings-escapes-unicode',json.dumps(dict(text='literal[1,2,3,4]', quoted='\\\"[5,6,7,8]',
                unicode='é λ 😀', escaped='line\n\t slash\\ end', tokens=['command:0:0:abc','port:1:0:-2:none'])).encode()),
            ('chunk-quoted-boundary',json.dumps(dict(text='A'*65532+'\\\"[1,2,3,4]',
                long_array=[[i,i+1,i+2,i+3] for i in range(2000)], after=[1,2,3,4])).encode()),
            ('duplicate-key-last-wins',b'{"a":[1,2,3,4],"a":[5,6,7,8],"nested":{"x":0,"x":1},"a\\u0072r":[9,10,11,12],"arr":[13,14,15,16]}'),
            ('shared-arrays-identity',json.dumps(dict(repeat=[[1,2,3,4]]*20000)).encode())]
    # Deliberately varied special-field positions test all fields in order,
    # rather than presupposing children/tree/search are last in the mapping.
    leaf={'after':1,'children':[],'before':0,'nested':{'unicode':'é','point':[1,2,3,4]}}
    branch={'later':2,'children':[{'post':0,'tree':leaf,'pre':'x'}],'earlier':3}
    synthetic={'last':0,'search':{'after':True,'tree':branch,'before':None},'first':'end'}
    rows.append(('trace-hierarchy-key-order',json.dumps(synthetic,ensure_ascii=False,separators=(',',':')).encode('utf-8')))
    rows.append(('ordinary-field-multichunk-container',json.dumps(dict(pad='x'*65500,value=12345678901234567890,items=[{'brackets':'[}]\"','point':[i,i+1,i+2,i+3]} for i in range(5000)]),ensure_ascii=False,separators=(',',':')).encode('utf-8')))
    pair_value={'pair':[17,-9],'nested':{'pair':[17,-9]},'different':[17,-8],
        'zero':[0,0], 'boolean':[True,False], 'float':[17.0,-9.0],
        'mixed':[17,'-9'], 'four':[17,-9,17,-9], 'repeat':[[17,-9]]*20000}
    rows.append(('trace-only-two-integer-type-and-alias',json.dumps(pair_value,ensure_ascii=False,separators=(',',':')).encode('utf-8')))
    rows.append(('pair-string-escape-and-boundary',json.dumps({'pad':'x'*65528,
        'points':[[0,0],[-1,2147483648],[999999999999999999,-999999999999999999]],
        'text':'[17,-9] and \\"[17,-9]','after':[[17,-9],[17,-9]]},ensure_ascii=False,separators=(',',':')).encode('utf-8')))
    receipts, byte_receipts = [], []
    OUT.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=OUT) as temp:
        folder = Path(temp)
        for index,(name,raw) in enumerate(rows):
            file = folder/('%02d.json.gz' % index);file.write_bytes(gzip.compress(raw,mtime=0))
            expected, actual = json.loads(raw), load_trace(file)
            a,b = digest(expected),digest(actual)
            if a != b:
                raise ValueError('complete synthetic JSON value mismatch '+name)
            if name == 'shared-arrays-identity' and actual['repeat'][0] is not actual['repeat'][-1]:
                raise ValueError('shared array storage not implemented')
            if name=='trace-only-two-integer-type-and-alias':
                if type(actual['pair']) is not list or type(actual['nested']['pair']) is not list:
                    raise ValueError('two-integer value must preserve plain-list type')
                if actual['pair'] is not actual['nested']['pair'] or actual['pair'] is not actual['repeat'][-1]:
                    raise ValueError('trace pair storage not shared across fields')
                if actual['pair'] is actual['different'] or type(actual['four']) is not tuple:
                    raise ValueError('two/four arities or unequal values conflated')
                if not (type(actual['boolean']) is list and type(actual['boolean'][0]) is bool
                        and type(actual['float']) is list and type(actual['float'][0]) is float
                        and type(actual['mixed']) is list and type(actual['mixed'][1]) is str):
                    raise ValueError('uncertain nonliteral-integer pairs must remain ordinary')
                if expected['pair'] is expected['nested']['pair']:
                    raise ValueError('ordinary reference unexpectedly aliases')
                # Value/type/index/iteration comparisons are preserved. This
                # intentionally does NOT certify mutation compatibility.
                if actual['pair']!=expected['pair'] or list(actual['pair'])!=expected['pair']:
                    raise ValueError('read-only pair consumer disagreement')
                if actual['pair']==tuple(expected['pair']):
                    raise ValueError('type-sensitive tuple mutant did not distinguish')
                reference_mutant, repaired_mutant=copy.deepcopy(expected),copy.deepcopy(actual)
                reference_mutant['pair'][0]=999
                repaired_mutant['pair'][0]=999
                if reference_mutant['nested']['pair'][0]!=17 or repaired_mutant['nested']['pair'][0]!=999:
                    raise ValueError('alias-sensitive mutating consumer negative control lost distinction')
                # Out-of-scope model/catalog/etc uses the unchanged loader. Its
                # ordinary pair lists retain distinct mutable storage.
                ordinary=load(file)
                if type(ordinary['pair']) is not list or ordinary['pair'] is ordinary['nested']['pair']:
                    raise ValueError('two-integer sharing escaped trace-only scope')
            receipts.append(dict(name=name,canonical=a,input_sha256=hashlib.sha256(raw).hexdigest(),
                                 compressed_sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
            compact=json.dumps(expected,ensure_ascii=False,separators=(',',':')).encode('utf-8')
            compact_file=folder/('%02d-compact.json.gz' % index)
            compact_file.write_bytes(gzip.compress(compact,mtime=0))
            decoded=load_trace(compact_file)
            byte_receipts.append(dict(name=name,correspondence=exact_compact_bytes(compact_file,decoded)))
            if name=='numeric-nested':
                decoded['state']['assigned_zero']=1
                try:exact_compact_bytes(compact_file,decoded)
                except ValueError:pass
                else:raise ValueError('exact byte gate failed to reject changed assigned zero')
        negatives = [
            ('reserved-value',b'{"value":"#0"}'),('reserved-key',b'{"#0":"value"}'),
            ('escaped-reserved',b'{"value":"\\u00230"}'),('escaped-reserved-key',b'{"\\u00230":0}'),('leading-zero',b'{"a":[01,2,3,4]}'),
            ('negative-leading-zero',b'{"a":[-01,2,3,4]}'),('pair-leading-zero',b'{"a":[01,2]}'),('pair-negative-leading-zero',b'{"a":[-01,2]}'),('nonobject-root',b'[1,2,3,4]'),
            ('scalar-root',b'"text"'),('truncated-json',b'{"a":[1,2,3,4]'),
            ('reserved-two-reference',b'{"a":"#2:0"}'),
            ('reserved-malformed-reference',b'{"a":"#2:01"}')]
        rejected = []
        for index,(name,raw) in enumerate(negatives):
            file=folder/('negative-%d.json.gz' % index);file.write_bytes(gzip.compress(raw,mtime=0))
            try:load_trace(file)
            except (ValueError,TypeError,IndexError):rejected.append(name)
            else:raise ValueError('scope/malformed fixture accepted '+name)
        lexical_rejected=[]
        for index,(name,raw) in enumerate([('duplicate-key',b'{"a":0,"a":1}'),('negative-integer-zero',b'{"a":[-0,0,0,0]}'),('pair-negative-integer-zero',b'{"a":[-0,0]}'),('whitespace',b'{"a": [1,2,3,4]}')]):
            file=folder/('lexical-%d.json.gz' % index);file.write_bytes(gzip.compress(raw,mtime=0))
            decoded=load_trace(file)
            try:exact_compact_bytes(file,decoded)
            except ValueError:lexical_rejected.append(name)
            else:raise ValueError('lexical mismatch silently accepted '+name)
    return dict(status='passed_complete_synthetic_loading_value_controls',positive=receipts,
        compact_byte_correspondence=byte_receipts,byte_gate_mutants_rejected=['changed-assigned-zero'],lexical_noncompact_rejected=lexical_rejected,
        pair_type_controls=dict(plain_list_preserved=True,tuple_mutant_distinguished=True,
            alias_sensitive_mutating_consumer_distinguished=True,sharing_only_saved_trace=True,
            consumer_scope='Only pinned read-only saved-trace consumers may use load_trace; the mutating-consumer control intentionally fails equivalence.'),
        rejected=rejected,duplicate_key_semantics='Python json last value wins, including equivalent escaped keys.',
        root_scope='Object-root artifacts only. Reserved# strings/keys rejected for compressed artifacts, malformed leading-zero arrays remain rejected.',
        searches=0,training_episodes=0,native_queries=0,graph_replays=0)


def timeout(*_):
    raise TimeoutError('decoder helper internal wall ceiling')


def main(plan_path):
    began=time.perf_counter();plan=json.loads(plan_path.read_bytes());output=ROOT/plan['output_path']
    if output.exists():raise ValueError('immutable helper output exists')
    result=dict(status='running_loading_value_helper',job=plan['job'],mode=plan['mode'],
                plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),searches=0,training_episodes=0,native_queries=0,graph_replays=0)
    signal.signal(signal.SIGALRM,timeout);signal.setitimer(signal.ITIMER_REAL,plan['seconds'])
    try:
        for p,h in {**plan['source_sha256'],**plan['input_sha256']}.items():
            with (ROOT/p).open('rb') as stream:
                sha=hashlib.sha256()
                for block in iter(lambda:stream.read(1048576),b''):sha.update(block)
            if sha.hexdigest()!=h:raise ValueError('frozen loading helper pin '+p)
        if plan['mode']=='controls':result['controls']=controls()
        else:
            path=ROOT/plan['trace_path']
            if plan['mode']=='reference':
                with gzip.open(path,'rt') as stream:value=json.load(stream)
            elif plan['mode']=='repaired':value=load_trace(path)
            else:raise ValueError('declared decoder helper mode')
            result['complete_original_trace_byte_correspondence']=exact_compact_bytes(path,value)
            gate=result['complete_original_trace_byte_correspondence']
            result['canonical']=dict(sha256=gate['original_uncompressed_sha256'],bytes=gate['bytes'],protocol='full_original_compact_JSON_fingerprint_v2_not_sorted_canonical')
            result['observation']=value['observation']
            result['nodes']=value['search']['metrics']['nodes']
            result['events']=len(value['search']['events'])
            result['weights_sha256']=value['search']['weights_sha256']
        result['status']='passed_complete_loading_value_helper'
    except Exception as exc:
        result.update(status='failed_or_unknown_loading_value_helper',failure_type=type(exc).__name__,failure=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        result.update(seconds_before_receipt_write=time.perf_counter()-began,
                      kernel_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,loading=statistics())
        if result['seconds_before_receipt_write']>plan['seconds'] or result['kernel_peak_rss_bytes']>plan['rss_bytes']:
            result['status']='unknown_loading_value_helper_resource_budget'
        with output.open('x') as stream:stream.write(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',required=True)
    main(Path(parser.parse_args().plan))
