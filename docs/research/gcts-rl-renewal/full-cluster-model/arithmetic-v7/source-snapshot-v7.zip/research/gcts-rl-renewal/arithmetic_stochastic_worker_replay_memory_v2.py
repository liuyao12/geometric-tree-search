"""One prospectively frozen actual observation replay, never proof search."""
import argparse
import gc
import hashlib
import json
import resource
import signal
import time
from pathlib import Path
from arithmetic_stochastic_independent_audit import (tree, learning_update,
    model_binding, families, need, near, sha)

from arithmetic_stochastic_replay_memory_v2 import load, statistics, exact_compact_bytes

ROOT = Path(__file__).resolve().parents[2]


def timeout(*_):
    raise TimeoutError('independent replay wall gate')


def main(plan_path):
    began = time.perf_counter()
    plan = json.loads(plan_path.read_bytes())
    output = ROOT / plan['output_path']
    need(not output.exists(), 'single-execution audit output')
    result = dict(status='checking_complete_actual_trace', job=plan['job'],
                  plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
                  searches=0, training_episodes=0, native_queries=0)
    signal.signal(signal.SIGALRM, timeout)
    signal.setitimer(signal.ITIMER_REAL, plan['seconds'])
    try:
        for path, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
            need(hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == h, 'exact independent freeze ' + path)
        experiment = load(ROOT / plan['experiment_plan'])
        job = next(j for j in experiment['observations'] if j['id'] == plan['job'])
        lifetime = load(ROOT / plan['lifetime_path'])
        need(lifetime['status'] == 'passed_complete_observation_lifetime_gate'
             and lifetime['worker_terminal_and_reaped'] and lifetime['remaining_owned_pids'] == [], 'producer lifetime gate')
        # Decode the potentially large trace before the full literal model.
        raw = load(ROOT / plan['trace_path'])
        result['complete_original_trace_byte_correspondence'] = exact_compact_bytes(ROOT / plan['trace_path'], raw)
        need(raw['observation'] == job and raw['case'] == experiment['case'], 'exact prospective case/job')
        need(raw['native_queries'] == 0 and raw['complete_model_sha256'] == experiment['complete_model_sha256'], 'common complete model binding')
        record = load(ROOT / plan['model_path'])
        catalog = load(ROOT / plan['catalog_path'])
        model_binding(raw['case'], catalog, record['model'])
        model = record['model']
        roots = sorted(model['roots'])
        literal_binding = dict(schema='exact-scalar-point-model-v1', length=13,
            required_points=[dict(point=p, generation=0) for p in roots],
            initial=dict(roots=[[p, 0] for p in roots], generations=[[p, 0] for p in roots],
                         marks=sorted(model['initial_marks']), totals=[], allowed_points=roots),
            placements=sorted(model['placements'], key=lambda p: p['key']),
            injective_catalog=model['catalog'], inference_rules=model['inference_rules'],
            rule_modes=[i + 1 if rule['premises'] else 0 for i, rule in enumerate(model['inference_rules'])],
            row_domains=record['row_domains'], arity=2, capacity=12, registry_sha256=model['registry_sha256'])
        need(sha(literal_binding) == experiment['complete_model_sha256'], 'independently reconstructed complete binding digest')
        need(len(model['placements']) == 19848 and len(roots) == 52
             and len(model['inference_rules']) == 153, 'unchanged complete finite language')
        del literal_binding
        need(raw['search']['mode'] == job['mode'] and raw['search']['seed'] == job['seed'], 'actual lane/seed')
        need(raw['search']['limits'] == dict(attempts=job['attempts'], seconds=job['search_seconds'],
             proposal_limit=24, proposal_checks=2048, rss_bytes=experiment['rss_bytes']), 'equal declared search limits')
        registry = load(ROOT / plan['registry_path'])
        need(len(registry['definitions']) == 94, 'all native admitted inventory definitions')
        need({d['name']: d for d in catalog['definitions']} ==
             {d['name']: d['definition'] for d in registry['definitions']}, 'exact admitted source definitions')
        result['tree'] = tree(raw['case'], record['model'], raw['search'], families(catalog))
        if job['phase'] == 'effect':
            need(result['tree']['executed_changed_first_branches'] > 0, 'actually visited changed legal first action')
        if job['phase'] == 'training':
            transition = load(ROOT / plan['transition_path'])
            need(transition['episode'] == job['episode'] and transition['seed'] == job['seed']
                 and transition['search_sha256'] == hashlib.sha256((ROOT / plan['trace_path']).read_bytes()).hexdigest(), 'training transition binding')
            if job['episode'] == 1:
                need(raw['search']['weights'] == {} and transition['update']['baseline_before'] == 0., 'fresh first training policy')
            else:
                previous = load(ROOT / plan['previous_transition_path'])
                need(raw['search']['weights'] == previous['weights_after']
                     and transition['update']['baseline_before'] == previous['baseline_after'], 'full consecutive policy chain')
            result['learning'] = learning_update(raw['search'], transition)
            result['weights_after_sha256'] = sha(transition['weights_after'])
        elif job['mode'] == 'trained':
            policy = load(ROOT / plan['policy_path'])
            gate = load(ROOT / plan['training_audit_path'])
            need(gate['status'] == 'passed_complete_training_graph_rng_and_updates'
                 and gate['weights_sha256'] == sha(policy['weights'])
                 and raw['search']['weights'] == policy['weights'], 'audited frozen evaluation policy')
        result['status'] = 'passed_complete_actual_graph_rng_and_policy_replay'
        result['scope'] = 'Every actual node/full universe/census/scheduler/base fallback/hint/rollback/feature/RNG/action and applicable complete learning update. No native acceptance or held-out theorem evidence.'
    except Exception as exc:
        result.update(status='failed_or_unknown_independent_replay', failure_type=type(exc).__name__, failure=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        result.update(seconds_before_receipt_write=time.perf_counter() - began,
                      kernel_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                      loading_only_repair_statistics=statistics())
        if result['seconds_before_receipt_write'] > plan['seconds'] or result['kernel_peak_rss_bytes'] > plan['rss_bytes']:
            result['status'] = 'unknown_independent_replay_resource_budget'
        output.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({k: v for k, v in result.items() if k not in ('learning',)}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    main(Path(parser.parse_args().plan))
