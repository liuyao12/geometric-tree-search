"""V2 loading path with read-only trace-only two-integer plain-list sharing.

No claim that every integer pair is a coordinate. The saved observation is
read-only throughout the pinned consumer call graph. Pair sharing changes
aliasing, therefore it is deliberately unavailable to other model/catalog/
registry/transition/policy loads. The unchanged V2 original-byte gate must
precede every full semantic replay. This is not a general mutation-compatible
JSON loader or a strict parser for arbitrary adversarial JSON.
"""
import gzip
import json
import re
import tempfile
import time
from pathlib import Path
from arithmetic_stochastic_replay_memory_v1 import load, statistics as old_statistics
from arithmetic_stochastic_replay_memory_v2 import exact_compact_bytes

ROOT = Path(__file__).resolve().parents[2]
TEMP = ROOT / '.gcts-active/stochastic-replay-memory-v5-20261011/decoder-temp'
INT = rb'-?(?:0|[1-9]\d*)'
TOKEN = re.compile(
    rb'(?P<string>"(?:[^"\\]|\\.)*")|'
    rb'(?P<partial>"(?:[^"\\]|\\.)*(?:\\)?$)|'
    rb'\[\s*(?P<a4>'+INT+rb')\s*,\s*(?P<b4>'+INT+
    rb')\s*,\s*(?P<c4>'+INT+rb')\s*,\s*(?P<d4>'+INT+rb')\s*\]|'
    rb'\[\s*(?P<a2>'+INT+rb')\s*,\s*(?P<b2>'+INT+rb')\s*\]')
_STATISTICS = []


def statistics():
    return old_statistics() + list(_STATISTICS)


def load_trace(path):
    """Complete object-root saved observation, for pinned read-only consumers.

    Other artifacts MUST use the unchanged imported ``load`` function. A pair
    remains a Python list; only identical literal integer pairs share storage.
    Tuple four-key behavior is inherited from V2. Full byte correspondence is
    a separate mandatory gate, so lexical normalizations fail closed there.
    """
    began = time.perf_counter()
    path = Path(path)
    if path.suffix != '.gz':
        raise ValueError('trace sharing requires the pinned compressed trace scope')
    TEMP.mkdir(exist_ok=True)
    four, four_at, two, two_at = [], {}, [], {}
    input_bytes, four_occurrences, two_occurrences, strings = 0, 0, 0, 0
    with tempfile.TemporaryFile('w+b', dir=TEMP) as reduced:
        with gzip.open(path, 'rb') as source:
            pending = b''
            while True:
                part = source.read(65536)
                input_bytes += len(part)
                eof = not part
                data, last = pending + part, 0
                for match in TOKEN.finditer(data):
                    if match.group('partial') is not None:
                        break
                    reduced.write(data[last:match.start()])
                    if match.group('string') is not None:
                        original = match.group('string')
                        if json.loads(original).startswith('#'):
                            raise ValueError('reserved interning string collision')
                        strings += 1
                        reduced.write(original)
                    elif match.group('a4') is not None:
                        key = tuple(int(match.group(name)) for name in ('a4', 'b4', 'c4', 'd4'))
                        index = four_at.get(key)
                        if index is None:
                            index = len(four)
                            four_at[key] = index
                            four.append(key)
                        four_occurrences += 1
                        reduced.write(('"#4:%d"' % index).encode())
                    else:
                        key = tuple(int(match.group(name)) for name in ('a2', 'b2'))
                        index = two_at.get(key)
                        if index is None:
                            index = len(two)
                            two_at[key] = index
                            two.append(list(key))
                        two_occurrences += 1
                        reduced.write(('"#2:%d"' % index).encode())
                    last = match.end()
                pending = data[last:]
                if eof:
                    reduced.write(pending)
                    break
                if len(pending) > 2097152:
                    raise ValueError('unknown_decoder_long_token_resource_budget')
        reduced_bytes = reduced.tell()
        reduced.seek(0)

        def restore(value):
            if isinstance(value, str) and value.startswith('#'):
                if value.startswith('#4:'):
                    table = four
                elif value.startswith('#2:'):
                    table = two
                else:
                    raise ValueError('invalid reversible array reference arity')
                word = value[3:]
                index = int(word)
                if str(index) != word or not 0 <= index < len(table):
                    raise ValueError('invalid reversible array reference index')
                return table[index]
            if isinstance(value, list):
                # Nested dictionaries have already been restored by the hook.
                # Each reference is returned directly, without copying its
                # shared list; no restored list escapes to a mutating consumer.
                return [restore(item) if not isinstance(item, dict) else item for item in value]
            return value

        def hook(obj):
            return {key: restore(value) for key, value in obj.items()}

        result = json.load(reduced, object_hook=hook)
    if not isinstance(result, dict):
        raise ValueError('declared object-root loading scope')
    _STATISTICS.append(dict(path=str(path), kind='v2_trace_only_four_tuple_two_plain_list_sharing',
        seconds=time.perf_counter()-began, original_uncompressed_bytes=input_bytes,
        reduced_temporary_json_bytes=reduced_bytes, shared_four_arrays=len(four),
        four_array_occurrences=four_occurrences, shared_two_integer_lists=len(two),
        two_integer_list_occurrences=two_occurrences, quoted_strings_checked=strings,
        scope='Complete saved observation only; every two-integer replacement is a plain list read-only by the pinned consumers. Generic value sharing, not coordinate semantics. Other artifacts retain V2 loader. Full original-byte and unchanged semantic gates remain required.'))
    return result
