"""Freeze V7 sources/diffs/plans using stdlib source inspection only.

No trace or model is inflated; no decoder/helper/graph code is imported.
Root plus independent source review and exact activation precede dispatch.
"""
import ast
import datetime
import difflib
import hashlib
import json
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/stochastic-replay-memory-v7-20261011'
PRIOR = ROOT / '.gcts-active/stochastic-replay-memory-20261011'
V5 = ROOT / '.gcts-active/stochastic-replay-memory-v5-20261011'
V6 = ROOT / '.gcts-active/stochastic-replay-memory-v6-20261011'
ORIGINAL = ROOT / '.gcts-active/arithmetic-stochastic-clusters-20261011/execution-v2'
SCIENCE = 'research/gcts-rl-renewal/arithmetic_stochastic_independent_audit.py'
SCIENCE_V7 = 'research/gcts-rl-renewal/arithmetic_stochastic_independent_audit_replay_memory_v7.py'
RSS = 512 * 1024 * 1024
CHARGED = 354.124656251
REMAINING = 425.875343749
NAMES = (
    'arithmetic_stochastic_replay_memory_v7.py',
    'arithmetic_stochastic_independent_audit_replay_memory_v7.py',
    'arithmetic_stochastic_worker_replay_memory_v7.py',
    'arithmetic_stochastic_fixture_replay_memory_v7.py',
    'arithmetic_stochastic_owner_replay_memory_v7.py',
    'arithmetic_stochastic_freeze_replay_memory_v7.py')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def rel(path):
    return str(path.relative_to(ROOT))


def save(path, value):
    with path.open('x') as output:
        output.write(json.dumps(value, indent=2) + '\n')
    return sha(path)


def scientific_transform(text):
    # Both values have completed their entire last scientific check/use.
    return text.replace(
        "        need(same(node['census'], census) and node['state_sha256'] == state_pin(state), 'complete literal graph/state')",
        "        need(same(node['census'], census) and node['state_sha256'] == state_pin(state), 'complete literal graph/state')\n        del census").replace(
        '            item = items[chosen]\n',
        '            item = items[chosen]\n            del event, vectors, scores, mixed, soft, work, feature_work, items\n')


def worker_transform(text):
    text = text.replace('from arithmetic_stochastic_independent_audit import',
        'from arithmetic_stochastic_independent_audit_replay_memory_v7 import').replace(
        'from arithmetic_stochastic_replay_memory_v5 import load, load_trace, statistics, exact_compact_bytes',
        'from arithmetic_stochastic_replay_memory_v7 import (load, load_trace, statistics,\n    exact_compact_bytes, store_binding, close_trace)')
    text = text.replace('    result = dict(status=', '    raw = None\n    result = dict(status=', 1)
    text = text.replace("raw = load_trace(ROOT / plan['trace_path'])",
        "raw = load_trace(ROOT / plan['trace_path'], ROOT / plan['trace_store_path'])")
    text = text.replace("        result['status'] = 'passed_complete_actual_graph_rng_and_policy_replay'",
        "        result['complete_read_only_spool_binding'] = store_binding(raw)\n        result['status'] = 'passed_complete_actual_graph_rng_and_policy_replay'")
    return text.replace('        signal.setitimer(signal.ITIMER_REAL, 0)\n        result.update(',
        "        try:\n            if raw is not None:\n                close_trace(raw)\n        except Exception as exc:\n            result.update(status='failed_or_unknown_independent_replay',\n                          cleanup_failure=type(exc).__name__ + ' : ' + str(exc))\n        signal.setitimer(signal.ITIMER_REAL, 0)\n        result.update(")


def diff(path, old_path, new_path):
    content = ''.join(difflib.unified_diff(old_path.read_text().splitlines(True),
        new_path.read_text().splitlines(True), fromfile=rel(old_path), tofile=rel(new_path)))
    with path.open('x') as output:
        output.write(content)
    return dict(path=rel(path), sha256=sha(path), bytes=path.stat().st_size)


def consumer_review(sources, science_diff, worker_diff):
    paths = [SCIENCE, SCIENCE_V7, 'research/gcts-rl-renewal/arithmetic_stochastic_worker_replay_memory_v7.py',
        'research/gcts-rl-renewal/commutativity_cluster_audit.py',
        'research/gcts-rl-renewal/induction_receptors_audit.py',
        'research/gcts-rl-renewal/audit_semantic_inventory.py',
        'research/gcts-rl-renewal/audit_native_inventory_policy.py',
        'research/gcts-rl-renewal/audit_native_receptor_points.py',
        'research/gcts-rl-renewal/audit_certificate_boundary.py',
        'research/gcts-rl-renewal/audit_tree_kernel.py',
        'research/gcts-rl-renewal/stochastic_policy_math_audit.py',
        'research/gcts-rl-renewal/arithmetic_stochastic_replay_memory_v7.py']
    inspected = []
    for path in paths:
        text = (ROOT / path).read_text()
        tree = ast.parse(text, filename=path)
        relevant = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in (
                    'type', 'isinstance', 'list', 'dict', 'tuple', 'copy', 'deepcopy', 'packed', 'same', 'near'):
                relevant.append(dict(line=node.lineno, kind='type_materialization_or_value_comparison', code=ast.get_source_segment(text, node)))
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in (
                    'append', 'extend', 'pop', 'clear', 'update', 'setdefault', 'copy', 'deepcopy', 'items', 'values', 'keys'):
                relevant.append(dict(line=node.lineno, kind='method_for_manual_alias_review', code=ast.get_source_segment(text, node)))
            elif isinstance(node, ast.Compare) and any(isinstance(op, (ast.Is, ast.IsNot)) for op in node.ops):
                relevant.append(dict(line=node.lineno, kind='identity_for_manual_review', code=ast.get_source_segment(text, node)))
            elif isinstance(node, (ast.Assign, ast.AugAssign, ast.Delete)):
                relevant.append(dict(line=node.lineno, kind='assignment_or_lifetime_for_manual_review', code=ast.get_source_segment(text, node)))
        inspected.append(dict(path=path, sha256=sources[path], source_review_sites=sorted(relevant, key=lambda item: (item['line'], item['kind']))))
    return dict(status='source_only_disk_proxy_consumer_argument_awaiting_independent_review',
        source_sha256={path: sources[path] for path in paths}, inspected_sites=inspected,
        exact_scientific_diff=science_diff, exact_worker_diff=worker_diff,
        proxy_scope=[
            dict(container='root/search/node/child mappings', uses='getitem, get, membership, iteration or len; root case/observation/scalars and search weights/metrics/proof/limits remain ordinary fields.', observations='No isinstance(dict), type(dict), whole mapping packed/json dump, deepcopy, mutation or mutable identity observation in the pinned scientific replay. Serialized-value checks operate on ordinary subfields.'),
            dict(container='search.events/search.hints', uses='event index, len, and iteration for learning_update; each event/hint materializes as an ordinary dict, every feature vector as ordinary dict/list.', observations='No slice or full list materialization. near sees original ordinary dict/list/float types, never lazy event collection.'),
            dict(container='node.children', uses='truthiness, len, enumerate and child key/role/tree lookups.', observations='No type(list) or mutable identity checks, no list(children), slicing, deepcopy or write. Each saved child is a mapping proxy whose tree is another mapping proxy.'),
            dict(container='all other nested values', uses='standard JSON dict/list/scalars; existing strict integer4 arrays normalize to tuples and strict integer2 arrays retain plain-list type, sharing only bounded cache values.', observations='Formula/API list equality remains list equality for pairs. Bool/float/mixed arrays remain ordinary. Nontrace loader is unchanged V1. Read-only sharing is not mutation/identity equivalent for arbitrary clients.')],
        scientific_lifetime_argument=[
            dict(deletion='census', after='The complete literal graph/state need() finishes. This expected census is not read again; all domains/state/node checks remain present.', scope='Fresh expected data only; saved node census decoded for the comparison is discarded normally.'),
            dict(deletion='event, vectors, scores, mixed, soft, work, feature_work, items', after='All exact proposal/features/work/weights/state/exploration/softmax/epsilon-mixture/RNG/index/domain checks and all counter updates completed; item=items[chosen] binds selected item first.', scope='Only selected item survives in validated hint. None of the eight deleted names is read in subsequent code; alternatives and active hints use the selected item, domains and fresh state. Same operations/order/RNG/math before deletion.')],
        checks_preserved=[
            'Exact source/input freezes and producer lifetime status/reap checks.',
            'Every original compact JSON byte and EOF, preserving key/field order, numbers/strings/types/empty containers, every tree node/child/event/hint.',
            'Complete literal model digest,13rows/19848placements/52roots/153interfaces,94definition registry and exact definitions.',
            'Every saved full census and state digest, global dead/forced/earliest-generation scheduler, complete base fallback.',
            'Every hint inherit/start/retire/wait/eligibility, legal placed candidate and all children/unknown causes; strict rollback terminal state.',
            'Full proposal identity/order/work/features/extended marking dependencies, probability mathematics, one seeded RNG draw/index per event.',
            'Exact complete counters, event/hint exhaustion, decoded proof word, applicable training update and trained-policy provenance.',
            'Complete immutable spool digest before/after semantic replay, close/cache cleanup in owned lifecycle, unchanged115/120s and conservative512MiB gates.'],
        storage_bounds=dict(read_characters=65536, ordinary_field_including_read_ahead_characters=4194304,
            output_chunk_hard_bytes=65536, mapping_key_bytes=4096, mapping_fields=256,
            hierarchy_depth=192, sqlite_page_cache_kib=1024, mmap_bytes=0,
            temporary_storage='FILE', spool_bytes=268435456,
            disk_check='After every256 writes and at seal; one batch overshoot possible, unknown if exceeded.',
            cache_entries=dict(four_integer_tuple=32768, two_integer_plain_list=4096, string_key=4096),
            cache_overflow='Retain ordinary equivalent value, never prune/omit a field or semantic candidate.'),
        structural_depth_argument='Full13-row scalar model has52 required unit-capacity points; each admittedplacement covers at leastone fresh requiredpoint, so a legal path has at most52placements. Root/search/node starts atdepth2 and each child descent adds3(node childrenarray,childmapping,childtree), hence maximum158.192 safely covers the complete unchanged boundary, unlike prospectiveV6limit128. No mathematical census is narrowed.',
        memory_argument='Trace hierarchy and all event/census records are disk-backed, not all inflated in Python. Python trace descriptors/caches do not grow with total trace nodes/events; recursive adapter references grow with bounded depth. Each ordinary field and its C-json output is bounded, but Python decoded object overhead, unchanged complete graph/model/features and allocator behavior still require actual owned512MiB measurement. No absolute proof all jobs fit.',
        disk_and_cleanup='Exclusive per-job persistent directory; complete/partial SQLite files preserved even on unknown. All creation/index/hash/byte/read costs charged inside worker lifetime. Connection close/cache clearing precede receipt timer; no external/spawned worker. Root owns final evidence integration/deletion, no automatic unmeasured bulk cleanup.',
        limitations='Read-only proxy scope only, not a general dict/list substitute. Reserved#strings/keys and malformed/noncompact/deduplicated lexical JSON fail before math. No claim strict arbitrary JSON parser, adversarial unbounded fields or identity/mutation equivalence. Synthetic controls and allsix fresh complete-byte+logical replays remain prospective.',
        scientific_loads=0, helpers=0, semantic_replays=0, searches=0, training_episodes=0, native_queries=0)


def main():
    began = time.perf_counter()
    if (OUT / 'review-package-v7.json').exists():
        raise ValueError('immutable V7 package exists')
    prior = json.loads((V6 / 'evaluation-plan-v6.json').read_bytes())
    original_path = ORIGINAL / 'evaluation/independent-audit-plan.json'
    original = json.loads(original_path.read_bytes())
    sources = dict(prior['source_sha256'])
    for name in NAMES:
        path = ROOT / 'research/gcts-rl-renewal' / name
        sources[rel(path)] = sha(path)
    for path, expected in sources.items():
        if sha(ROOT / path) != expected:
            raise ValueError('unchanged frozen source ' + path)
        ast.parse((ROOT / path).read_text(), filename=path)
    old_science, new_science = (ROOT / SCIENCE).read_text(), (ROOT / SCIENCE_V7).read_text()
    if scientific_transform(old_science) != new_science:
        raise ValueError('exact permitted two lifetime-only scientific additions')
    # Removing precisely the two additions recovers every original AST node.
    stripped = new_science.replace('        del census\n', '').replace(
        '            del event, vectors, scores, mixed, soft, work, feature_work, items\n', '')
    if stripped != old_science or ast.dump(ast.parse(stripped)) != ast.dump(ast.parse(old_science)):
        raise ValueError('every original acceptance/mathematical operation preserved')
    old_worker = ROOT / 'research/gcts-rl-renewal/arithmetic_stochastic_worker_replay_memory_v5.py'
    new_worker = ROOT / 'research/gcts-rl-renewal/arithmetic_stochastic_worker_replay_memory_v7.py'
    if worker_transform(old_worker.read_text()) != new_worker.read_text():
        raise ValueError('exact V7 worker loading/binding/cleanup-only change')
    science_diff = diff(OUT / 'scientific-lifetime-only-v7.diff', ROOT / SCIENCE, ROOT / SCIENCE_V7)
    worker_diff = diff(OUT / 'worker-loading-only-v7.diff', old_worker, new_worker)
    review_path = OUT / 'consumer-use-review-v7.json'
    save(review_path, consumer_review(sources, science_diff, worker_diff))
    inputs = dict(prior['input_sha256'])
    history_paths = [original_path, ROOT / 'docs/basic-tiling-algorithm.md', review_path,
        OUT / 'authoring-start.json', OUT / 'scientific-lifetime-only-v7.diff', OUT / 'worker-loading-only-v7.diff']
    phases = []
    initial = ORIGINAL / 'evaluation/independent-audit.json'
    history = [initial] + [PRIOR / kind / 'phase-receipt.json' for kind in (
        'helpers-v1', 'helpers-v2', 'evaluation-v2', 'helpers-v3', 'evaluation-v3', 'helpers-v4', 'evaluation-v4')]
    history += [V5 / 'helpers-v5/phase-receipt.json', V5 / 'evaluation-v5/phase-receipt.json',
        V5 / 'evaluation-v5/phase-receipt-attempt-02.json']
    for path in history:
        receipt = json.loads(path.read_bytes())
        key = 'seconds_before_final_phase_receipt_write' if path == initial else 'seconds_before_phase_receipt_write'
        phases.append(dict(path=rel(path), sha256=sha(path), seconds=receipt[key], status=receipt['status'],
            conservative_owner_plus_worker_peak_bytes=receipt.get('conservative_owner_plus_worker_peak_bytes')))
        history_paths.append(path)
    if abs(sum(p['seconds'] for p in phases) - CHARGED) > 1e-8 or CHARGED + REMAINING != 780:
        raise ValueError('all preserved original-inclusive audit/helper costs')
    for name in ('review-package-v5.json', 'evaluation-plan-v5.json', 'helper-plan-v5.json',
            'evaluation-plan-v5-attempt-02.json', 'source-snapshot-v5.zip', 'source-verification-v5.json',
            'consumer-use-review-v5.json', 'next-discovery-benchmark-source-only-v1.json',
            'next-discovery-inventory-provenance-v1.json'):
        history_paths.append(V5 / name)
    for name in ('review-package-v6.json', 'helper-plan-v6.json', 'evaluation-plan-v6.json',
            'source-snapshot-v6.zip', 'source-verification-v6.json', 'consumer-use-review-v6.json',
            'scientific-lifetime-only-v6.diff', 'worker-loading-only-v6.diff', 'authoring-start.json'):
        history_paths.append(V6 / name)
    independent = ROOT / '.gcts-active/stochastic-replay-v5-independent-20261011'
    for name in ('source-ready-review-v5.json', 'helper-terminal-review-v5.json', 'actual-terminal-review-v5.json'):
        history_paths.append(independent / name)
    for path in history_paths:
        inputs[rel(path)] = sha(path)
    for path, expected in inputs.items():
        if sha(ROOT / path) != expected:
            raise ValueError('unchanged frozen input/history ' + path)
    helper_dir, evaluation_dir = OUT / 'helpers-v7', OUT / 'evaluation-v7'
    helper_dir.mkdir()
    evaluation_dir.mkdir()
    helper_names = set(NAMES) - {'arithmetic_stochastic_worker_replay_memory_v7.py',
        'arithmetic_stochastic_independent_audit_replay_memory_v7.py'}
    helper_names.add('arithmetic_stochastic_replay_memory_v1.py')
    helper_sources = {p: h for p, h in sources.items() if Path(p).name in helper_names}
    helper_inputs = {rel(review_path): sha(review_path), 'docs/basic-tiling-algorithm.md': inputs['docs/basic-tiling-algorithm.md']}
    helpers, pairs = [], []

    def helper(job, mode, trace=None):
        job_inputs = {rel(review_path): sha(review_path)}
        plan = dict(job=job, mode=mode, seconds=25, rss_bytes=RSS,
            source_sha256=helper_sources, input_sha256=job_inputs,
            output_path=rel(helper_dir / (job + '.json')),
            searches=0, training_episodes=0, native_queries=0, graph_replays=0)
        if trace is not None:
            plan['trace_path'] = rel(trace)
            job_inputs[rel(trace)] = sha(trace)
            helper_inputs[rel(trace)] = sha(trace)
        if mode == 'repaired':
            plan['trace_store_path'] = rel(helper_dir / (job + '-complete-spool'))
        path = helper_dir / (job + '-plan.json')
        digest = save(path, plan)
        helpers.append(dict(job=job, plan_path=rel(path), plan_sha256=digest,
            output_path=plan['output_path'], lifecycle_seconds=30))

    helper('synthetic-controls', 'controls')
    for name, trace in (('effect-pilot', ORIGINAL / 'effect/effect-pilot-search.json.gz'),
            ('train-01', ORIGINAL / 'training/train-01-search.json.gz'),
            ('train-08', ORIGINAL / 'training/train-08-search.json.gz')):
        a, b = name + '-reference', name + '-repaired'
        helper(a, 'reference', trace)
        helper(b, 'repaired', trace)
        pairs.append([a, b])
    helper_plan = dict(status='frozen_source_only_before_root_and_independent_review', kind='helpers',
        seconds=180, rss_bytes=RSS, historical_failed_audit_seconds=CHARGED,
        requires_root_activation=True, root_activation_path=rel(OUT / 'helper-activation-v7.json'),
        source_sha256=helper_sources, input_sha256=helper_inputs, jobs=helpers, correspondence_pairs=pairs,
        worker_source='research/gcts-rl-renewal/arithmetic_stochastic_fixture_replay_memory_v7.py',
        worker_pass_status='passed_complete_loading_value_helper', output_path=rel(helper_dir / 'phase-receipt.json'),
        scope='Nine complete synthetic values including legal52-placement depth158 plus allfields/types/order/empty-container/alias controls,15 malformed/reserved/noncompact/depth-ceiling failures and duplicate-key compatibility. Three complete501-node ordinary/repaired loading pairs each receive full compact original byte comparison; no mathematical graph replay.',
        budgets='25s internal30s owned/helper,180s total helper phase,512MiB conservative owner+fresh-child. Whole measured helper phase charged once to original780s, never reset. Any failure/unknown stops; unexecuted preserved.')
    helper_path = OUT / 'helper-plan-v7.json'
    helper_digest = save(helper_path, helper_plan)
    jobs = []
    for old in original['jobs']:
        old_path = ROOT / old['plan_path']
        inputs[rel(old_path)] = sha(old_path)
        plan = json.loads(old_path.read_bytes())
        plan['source_sha256'] = sources
        plan['input_sha256'] = {**plan['input_sha256'], rel(review_path): sha(review_path),
            science_diff['path']: science_diff['sha256'], worker_diff['path']: worker_diff['sha256']}
        plan['output_path'] = rel(evaluation_dir / (old['job'] + '-audit.json'))
        plan['trace_store_path'] = rel(evaluation_dir / (old['job'] + '-complete-spool'))
        plan['loading_only_repair'] = 'Complete SQLite-indexed saved hierarchy/events/hints with bounded ordinary values; every original compact byte and all scientific checks remain mandatory; new sciencecopy adds exactly2last-use Delete statements.'
        path = evaluation_dir / (old['job'] + '-plan.json')
        digest = save(path, plan)
        jobs.append(dict(job=old['job'], plan_path=rel(path), plan_sha256=digest,
            output_path=plan['output_path'], lifecycle_seconds=120))
    evaluation_plan = dict(status='frozen_source_only_before_root_review_helpers_and_dispatch', kind='evaluation',
        seconds=REMAINING, rss_bytes=RSS, original_cumulative_audit_seconds=780,
        historical_failed_audit_seconds=CHARGED, requires_root_activation=True,
        root_activation_path=rel(OUT / 'activation-v7.json'), helper_receipt_path=helper_plan['output_path'],
        helper_plan_sha256=helper_digest, source_sha256=sources, input_sha256=inputs, jobs=jobs,
        worker_source='research/gcts-rl-renewal/arithmetic_stochastic_worker_replay_memory_v7.py',
        worker_pass_status='passed_complete_actual_graph_rng_and_policy_replay',
        output_path=rel(evaluation_dir / 'phase-receipt.json'),
        semantic_model_sha256='b131949034b0e396ab885a5a94b870f12d1443e2bdc5df0550963ec0e0698c11',
        full_language=dict(rows=13, placements=19848, required_points=52, interfaces=153, admitted_definitions=94),
        complete_gate='AllsixFRESH complete original-byte gates, full logical/graph/RNG/policy checks, immutable spool bindings and conservative owned512MiB/120s gates. V5qualifiedbase remains historical, not silently reused. All original5001nodes and all events/censuses/children preserved; no native or search query.',
        budgets='Original780s minus354.124656251s already charged:425.875343749before future helper phase. All6fresh actual115s internal120s owned,512MiB unchanged; helperphase inclusive subtracts once. Reserve120s before each dispatch; six worstcase lifecycles exceed remaining, so completion is prospective and any late reservation stop unknown.',
        memory_and_disk='Fixed1MiBSQLite cache/mmap0/FILEtemp, bounded4Mi-character ordinaryfield/read-ahead,64KiB output chunks,192hierarchy depth and bounded32768/4096/4096sharing caches. Spool256MiB each, one256write-batch disk overshoot possible; no wholetrace Python collection. Actual owned peak still decisive, no hard OS total-memory guarantee.',
        owner_authority='Root alone dispatches after source and independentreview. Owner exact activation and prerequisitepins enforced; workerCLI technically callable, not inaccessible. No rerun of existing jobs or overwrite of old evidence.',
        cleanup_and_clock='All child imports/hash/spoolcreation/full-byte/decode/graph/policy/final-spoolhash/connectionclose/cacheclear/receiptserialization are inside owned freshworker lifetime. Phaseclock includes parenthash/dispatch/worker/outputreads/assembly up to final phase receiptwrite; excludes final write and separately disclosed sourceauthoring/preparation. Complete and failedpartial spools/stdout/stderr/receipts persist.',
        queries=dict(searches=0, training_episodes=0, native_queries=0))
    eval_path = OUT / 'evaluation-plan-v7.json'
    eval_digest = save(eval_path, evaluation_plan)
    verification = dict(status='passed_source_only_ast_exact_two_delete_and_worker_diff_pins',
        source_count=len(sources), input_count=len(inputs), scientific_diff=science_diff, worker_diff=worker_diff,
        exact_scientific_assertions='New scientificsource minus precisely2addedDelete statements is byteidentical and ASTidentical to unchanged root library; every acceptance/math/counter/RNG/recursion statement retained in original order.',
        scientific_loads=0, fixtures_executed=0, helpers=0, full_replays=0,
        searches=0, training_episodes=0, native_queries=0,
        scope='Source AST and hash/diff verification only; pending source/consumer review, future synthetic/full-reference/actualbytes/semantic/resource gates.')
    verify_path = OUT / 'source-verification-v7.json'
    save(verify_path, verification)
    archive_path = OUT / 'source-snapshot-v7.zip'
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(sources):
            archive.write(ROOT / path, path)
        for path in (review_path, OUT / 'scientific-lifetime-only-v7.diff', OUT / 'worker-loading-only-v7.diff'):
            archive.write(path, rel(path))
    now = datetime.datetime.now(datetime.timezone.utc)
    start = datetime.datetime.fromisoformat(json.loads((OUT / 'authoring-start.json').read_bytes())['utc_start'])
    paths = [helper_path, eval_path, archive_path, review_path, verify_path, OUT / 'authoring-start.json',
        OUT / 'scientific-lifetime-only-v7.diff', OUT / 'worker-loading-only-v7.diff']
    paths += [ROOT / job['plan_path'] for job in helpers + jobs]
    package = dict(status='frozen_source_ready_v7_disk_backed_complete_replay_candidate',
        helper_plan=dict(path=rel(helper_path), sha256=helper_digest),
        evaluation_plan=dict(path=rel(eval_path), sha256=eval_digest),
        consumer_argument=dict(path=rel(review_path), sha256=sha(review_path), disposition='awaiting_root_and_independent_review'),
        source_sha256=sources, input_sha256=inputs,
        files=[dict(path=rel(path), sha256=sha(path), bytes=path.stat().st_size) for path in paths],
        prior_inclusive_phases_preserved=phases, original_audit_seconds=780,
        charged_seconds=CHARGED, remaining_seconds_before_helpers=REMAINING,
        source_preparation_seconds_before_package_write=time.perf_counter() - began,
        source_authoring_calendar_interval_seconds=(now - start).total_seconds(),
        authoring_scope='Calendar interval since writing marker, including sourceinspection/waits; not CPU effort. Earlier design/inspection unknown/uninstrumented. Source-only freezer preparation separately measured. No actual trace/model/decoder/helper/census/graph inflation or execution.',
        source_only_v6_preserved='V6proposed128depthlimit was identified before any helper/scientificdispatch as insufficient for full52-placement path. All V6sources/plans/sourcecosts preserved; V7changes structural ceiling to justified192 and adds exact boundary/controlfixtures. Scientificcaps and remainingoriginalaudit unchanged.',
        observed='V5base-r1 passedowned441925632B; untrained-r1 fullvalues/math completed butowned626147328B UNKNOWN; fourunexecuted. Preserve prior354.124656251s and all old evidence.',
        prospective='Disk adapter removes totaltrace-sized Python storage and releases verifiedrecursiveframe temporaries. Savings/perfieldsize/disk/time/actualRSS and allsix feasibility remain unknown until reviewed dispatch; no allocation cause or completepass assumed.',
        exact_next_command='PYTHONPYCACHEPREFIX=/private/tmp/gcts-native-wang-pycache python3 research/gcts-rl-renewal/arithmetic_stochastic_owner_replay_memory_v7.py --plan ' + rel(helper_path),
        no_dispatch=True, helper_runs=0, scientific_loads=0, semantic_replays=0,
        searches=0, training_episodes=0, native_queries=0,
        fallback='Stop with exact failed/unknown/unexecuted counts if any source/byte/semantic/wall/memory/disk/remainingbudget gate fails; no schema weakening, cap widening, new proof/target/training/native or silent reuse.')
    package_path = OUT / 'review-package-v7.json'
    save(package_path, package)
    print(json.dumps(dict(status=package['status'], package_sha256=sha(package_path),
        helper_plan_sha256=helper_digest, evaluation_plan_sha256=eval_digest,
        preparation_seconds=package['source_preparation_seconds_before_package_write'],
        source_authoring_calendar_seconds=package['source_authoring_calendar_interval_seconds'])), flush=True)


if __name__ == '__main__':
    main()
