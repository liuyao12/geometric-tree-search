"""V7 read-only, disk-backed saved traces; no search or scientific execution.

Only the declared root/search/tree/children/events/hints containers are lazy.
Every other value is ordinary standard JSON, with bounded read-only array
sharing. Complete compact-byte correspondence is mandatory before replay.
The adapter is deliberately scoped to the pinned consumer, not arbitrary
Python dict/list clients. Spools are exclusive, persistent evidence files.
"""
import collections.abc
import gzip
import hashlib
import json
import re
import sqlite3
import time
from pathlib import Path

from arithmetic_stochastic_replay_memory_v1 import load

READ_CHARS = 65536
EMIT_BYTES = 65536
FIELD_CHARS = 4 * 1024 * 1024
KEY_BYTES = 4096
MAX_FIELDS = 256
MAX_DEPTH = 192
SPOOL_BYTES = 256 * 1024 * 1024
FOUR_CACHE = 32768
PAIR_CACHE = 4096
KEY_CACHE = 4096
STRUCT = re.compile(r'(?P<string>"(?:[^"\\]|\\.)*")|(?P<partial>"(?:[^"\\]|\\.)*(?:\\)?$)|(?P<bracket>[\[\]{}])')
STRING = re.compile(r'"(?:[^"\\]|\\.)*"')
DELIMITER = re.compile(r'[,\]}\s]')
_STORES = []


def hash_file(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


class FieldReader:
    """Lexical boundaries only; standard JSON validates every ordinary value.

    Every captured field has a hard character ceiling including read-ahead.
    No entire tape string or hierarchy is ever assembled here.
    """
    def __init__(self, stream):
        self.stream = stream
        self.buffer, self.position, self.eof = '', 0, False
        self.maximum_buffer_characters = 0
        self.raw_fields = 0
        self.maximum_field_characters = 0

    def fill(self):
        if self.position:
            self.buffer = self.buffer[self.position:]
            self.position = 0
        part = self.stream.read(READ_CHARS)
        self.eof = not part
        self.buffer += part
        self.maximum_buffer_characters = max(self.maximum_buffer_characters, len(self.buffer))
        if len(self.buffer) > FIELD_CHARS:
            raise ValueError('unknown_v7_ordinary_field_character_resource_budget')
        return bool(part)

    def peek(self):
        while True:
            while self.position < len(self.buffer) and self.buffer[self.position] in ' \r\n\t':
                self.position += 1
            if self.position < len(self.buffer):
                return self.buffer[self.position]
            if self.eof:
                return ''
            self.fill()

    def consume(self, token):
        if self.peek() != token:
            raise ValueError('V7 hierarchy delimiter ' + repr(token))
        self.position += 1

    def raw(self):
        first = self.peek()
        if not first:
            raise ValueError('missing complete ordinary JSON field')
        if self.position:
            self.buffer = self.buffer[self.position:]
            self.position = 0
        end = None
        if first in '[{':
            depth, scan = 0, 0
            while end is None:
                last = scan
                for match in STRUCT.finditer(self.buffer, scan):
                    if match.group('partial') is not None:
                        last = match.start()
                        break
                    if match.group('bracket') is not None:
                        depth += 1 if match.group('bracket') in '[{' else -1
                        if depth == 0:
                            end = match.end()
                            break
                    last = match.end()
                if end is not None:
                    break
                if self.eof:
                    raise ValueError('truncated ordinary JSON container')
                scan = last
                self.fill()
        elif first == '"':
            while True:
                match = STRING.match(self.buffer)
                if match is not None:
                    end = match.end()
                    break
                if self.eof:
                    raise ValueError('truncated ordinary JSON string')
                self.fill()
        else:
            while True:
                match = DELIMITER.search(self.buffer)
                if match is not None:
                    end = match.start()
                    break
                if self.eof:
                    end = len(self.buffer)
                    break
                self.fill()
        result = self.buffer[:end].encode('utf-8')
        self.position = end
        self.raw_fields += 1
        self.maximum_field_characters = max(self.maximum_field_characters, end)
        return result


class TraceStore:
    """One read-only SQLite spool, bounded caches and per-field decoding.

    Persistent DB includes every ordinary field BLOB and hierarchy reference.
    SQLite page cache is 1MiB, mmap disabled; no Python descriptor collection.
    Size checks every256 stored fields and at seal can overshoot by one batch;
    any excess is unknown. All costs are inside the owning worker lifetime.
    """
    def __init__(self, path):
        self.path = Path(path)
        self.path.mkdir(exist_ok=False)
        self.database = self.path / 'complete-trace.sqlite3'
        self.connection = sqlite3.connect(str(self.database))
        self.connection.execute('PRAGMA cache_size=-1024')
        self.connection.execute('PRAGMA mmap_size=0')
        self.connection.execute('PRAGMA temp_store=FILE')
        self.connection.execute('PRAGMA journal_mode=DELETE')
        self.connection.execute('CREATE TABLE containers(id INTEGER PRIMARY KEY, kind TEXT NOT NULL, count INTEGER NOT NULL)')
        self.connection.execute('CREATE TABLE fields(parent INTEGER NOT NULL, key TEXT NOT NULL, ordinal INTEGER NOT NULL, kind TEXT NOT NULL, ref INTEGER, raw BLOB, PRIMARY KEY(parent,key))')
        self.connection.execute('CREATE UNIQUE INDEX field_order ON fields(parent,ordinal)')
        self.connection.execute('CREATE TABLE entries(parent INTEGER NOT NULL, position INTEGER NOT NULL, kind TEXT NOT NULL, ref INTEGER, raw BLOB, PRIMARY KEY(parent,position))')
        self.next_id = 0
        self.four, self.pairs, self.keys = {}, {}, {}
        self.metrics = dict(kind='V7_complete_disk_backed_saved_trace',
            standard_value_decodes=0, container_count=0, stored_fields=0, stored_entries=0,
            maximum_ordinary_raw_bytes=0, maximum_ordinary_compact_bytes=0,
            four_occurrences=0, pair_occurrences=0, spool_maximum_bytes=0,
            sqlite_version=sqlite3.sqlite_version, sqlite_page_cache_kib=1024,
            sqlite_mmap_bytes=0, sqlite_temporary_storage='FILE',
            source='not yet sealed', store_path=str(self.path))
        self.closed = False
        self.sealed = False
        _STORES.append(self)

    def container(self, kind):
        ident = self.next_id
        self.next_id += 1
        self.connection.execute('INSERT INTO containers VALUES(?,?,0)', (ident, kind))
        self.metrics['container_count'] += 1
        return ident

    def disk_gate(self):
        # Preserve completed batches on failure and bound dirty-page lifetime.
        # No pending transaction is shared with a scientific consumer.
        if not self.sealed:
            self.connection.commit()
        size = sum(p.stat().st_size for p in self.path.iterdir() if p.is_file())
        self.metrics['spool_maximum_bytes'] = max(size, self.metrics['spool_maximum_bytes'])
        if size > SPOOL_BYTES:
            raise ValueError('unknown_v7_spool_disk_resource_budget')

    def record(self, parent, key, ordinal, descriptor):
        kind, ref, raw = descriptor
        self.connection.execute('INSERT INTO fields VALUES(?,?,?,?,?,?) ON CONFLICT(parent,key) DO UPDATE SET kind=excluded.kind,ref=excluded.ref,raw=excluded.raw',
                                (parent, key, ordinal, kind, ref, raw))
        self.metrics['stored_fields'] += 1
        if self.metrics['stored_fields'] % 256 == 0:
            self.disk_gate()

    def entry(self, parent, position, descriptor):
        kind, ref, raw = descriptor
        self.connection.execute('INSERT INTO entries VALUES(?,?,?,?,?)', (parent, position, kind, ref, raw))
        self.metrics['stored_entries'] += 1
        if self.metrics['stored_entries'] % 256 == 0:
            self.disk_gate()

    def finish(self, ident, count):
        self.connection.execute('UPDATE containers SET count=? WHERE id=?', (count, ident))

    def share_key(self, key):
        if key.startswith('#'):
            raise ValueError('reserved interning string collision')
        if len(self.keys) < KEY_CACHE:
            return self.keys.setdefault(key, key)
        return self.keys.get(key, key)

    def normalize(self, value):
        if isinstance(value, str):
            if value.startswith('#'):
                raise ValueError('reserved interning string collision')
            return value
        if isinstance(value, list):
            if len(value) == 4 and all(type(x) is int for x in value):
                key = tuple(value)
                self.metrics['four_occurrences'] += 1
                if len(self.four) < FOUR_CACHE:
                    return self.four.setdefault(key, key)
                return self.four.get(key, key)
            if len(value) == 2 and all(type(x) is int for x in value):
                key = tuple(value)
                self.metrics['pair_occurrences'] += 1
                if len(self.pairs) < PAIR_CACHE:
                    return self.pairs.setdefault(key, value)
                return self.pairs.get(key, value)
            return [self.normalize(x) for x in value]
        if isinstance(value, dict):
            return {self.share_key(k): self.normalize(v) for k, v in value.items()}
        return value

    def decode(self, raw):
        self.metrics['standard_value_decodes'] += 1
        self.metrics['maximum_ordinary_raw_bytes'] = max(self.metrics['maximum_ordinary_raw_bytes'], len(raw))
        return self.normalize(json.loads(raw))

    def value(self, descriptor):
        kind, ref, raw = descriptor
        if kind == 'ordinary':
            return self.decode(raw)
        if kind == 'mapping':
            return DiskMapping(self, ref)
        if kind == 'array':
            return DiskSequence(self, ref)
        raise ValueError('invalid declared spool descriptor')

    def seal(self, source, reader):
        self.connection.commit()
        self.connection.execute('PRAGMA query_only=ON')
        self.disk_gate()
        self.sealed = True
        self.metrics.update(source=str(source), original_compressed_sha256=hash_file(source),
            reader_maximum_buffer_characters=reader.maximum_buffer_characters,
            reader_maximum_field_characters=reader.maximum_field_characters,
            lexical_raw_fields=reader.raw_fields,
            sealed_database_sha256=hash_file(self.database),
            sealed_database_bytes=self.database.stat().st_size)

    def final_binding(self):
        if not self.sealed or self.closed:
            raise ValueError('complete sealed spool required')
        actual = hash_file(self.database)
        if actual != self.metrics['sealed_database_sha256']:
            raise ValueError('read-only complete spool changed during replay')
        self.metrics.update(final_database_sha256=actual,
            shared_four_values=len(self.four), shared_pair_values=len(self.pairs), shared_keys=len(self.keys),
            disk_descriptor_semantics='All hierarchy fields and ordinary JSON BLOBs retained in insertion order; no full tree/events or descriptors retained in Python. All ordinary fields decoded and checked by complete byte gate before math replay.')
        return dict(path=str(self.database), sha256=actual, bytes=self.database.stat().st_size,
                    read_only=True, full_original_byte_gate_required=True)

    def close(self):
        if not self.closed:
            began = time.perf_counter()
            if not self.sealed:
                self.connection.commit()
                self.metrics['partial_database_sha256'] = hash_file(self.database)
                self.metrics['partial_database_bytes'] = self.database.stat().st_size
            self.connection.close()
            self.closed = True
            self.four.clear()
            self.pairs.clear()
            self.keys.clear()
            self.metrics.update(close_seconds=time.perf_counter() - began,
                temporary_cleanup='SQLite connection closed and caches cleared; complete spool and any failed partial spool preserved as task evidence, no deletion or hidden cleanup.')


class DiskMapping(collections.abc.Mapping):
    def __init__(self, store, ident):
        self.store, self.ident = store, ident

    def __getitem__(self, key):
        row = self.store.connection.execute('SELECT kind,ref,raw FROM fields WHERE parent=? AND key=?', (self.ident, key)).fetchone()
        if row is None:
            raise KeyError(key)
        return self.store.value(row)

    def __iter__(self):
        cursor = self.store.connection.execute('SELECT key FROM fields WHERE parent=? ORDER BY ordinal', (self.ident,))
        for row in cursor:
            yield self.store.share_key(row[0])

    def __len__(self):
        return self.store.connection.execute('SELECT count FROM containers WHERE id=?', (self.ident,)).fetchone()[0]

    def __contains__(self, key):
        return self.store.connection.execute('SELECT 1 FROM fields WHERE parent=? AND key=?', (self.ident, key)).fetchone() is not None


class DiskSequence(collections.abc.Sequence):
    def __init__(self, store, ident):
        self.store, self.ident = store, ident

    def __len__(self):
        return self.store.connection.execute('SELECT count FROM containers WHERE id=?', (self.ident,)).fetchone()[0]

    def __getitem__(self, index):
        if not isinstance(index, int):
            raise TypeError('saved-trace sequence integer access only; no materializing slices')
        if index < 0:
            index += len(self)
        row = self.store.connection.execute('SELECT kind,ref,raw FROM entries WHERE parent=? AND position=?', (self.ident, index)).fetchone()
        if row is None:
            raise IndexError(index)
        return self.store.value(row)

    def __iter__(self):
        # Do not keep a SELECT of every BLOB alive while its values are decoded.
        for position in range(len(self)):
            yield self[position]


class SpoolReader:
    def __init__(self, reader, store):
        self.reader, self.store = reader, store

    def mapping(self, context, depth):
        if depth > MAX_DEPTH:
            raise ValueError('unknown_v7_hierarchy_depth_resource_budget')
        r, s = self.reader, self.store
        r.consume('{')
        ident, count = s.container('mapping'), 0
        if r.peek() == '}':
            r.consume('}')
            return 'mapping', ident, None
        while True:
            raw_key = r.raw()
            if len(raw_key) > KEY_BYTES:
                raise ValueError('unknown_v7_key_resource_budget')
            key = json.loads(raw_key)
            if not isinstance(key, str):
                raise ValueError('mapping key must be a string')
            key = s.share_key(key)
            r.consume(':')
            if context == 'root' and key == 'search':
                descriptor = self.mapping('search', depth + 1)
            elif context in ('search', 'child') and key == 'tree':
                descriptor = self.mapping('node', depth + 1)
            elif context == 'node' and key == 'children':
                descriptor = self.array('children', depth + 1)
            elif context == 'search' and key in ('events', 'hints'):
                descriptor = self.array('ordinary', depth + 1)
            else:
                descriptor = 'ordinary', None, r.raw()
            previous = s.connection.execute('SELECT ordinal FROM fields WHERE parent=? AND key=?', (ident, key)).fetchone()
            ordinal = previous[0] if previous is not None else count
            s.record(ident, key, ordinal, descriptor)
            if previous is None:
                count += 1
            if count > MAX_FIELDS:
                raise ValueError('unknown_v7_mapping_field_resource_budget')
            if r.peek() == '}':
                r.consume('}')
                s.finish(ident, count)
                return 'mapping', ident, None
            r.consume(',')

    def array(self, context, depth):
        if depth > MAX_DEPTH:
            raise ValueError('unknown_v7_hierarchy_depth_resource_budget')
        r, s = self.reader, self.store
        r.consume('[')
        ident, count = s.container('array'), 0
        if r.peek() == ']':
            r.consume(']')
            return 'array', ident, None
        while True:
            descriptor = self.mapping('child', depth + 1) if context == 'children' else ('ordinary', None, r.raw())
            s.entry(ident, count, descriptor)
            count += 1
            if r.peek() == ']':
                r.consume(']')
                s.finish(ident, count)
                return 'array', ident, None
            r.consume(',')


def load_trace(path, spool_path):
    began = time.perf_counter()
    store = TraceStore(spool_path)
    try:
        with gzip.open(path, 'rt', encoding='utf-8', newline='') as source:
            reader = FieldReader(source)
            descriptor = SpoolReader(reader, store).mapping('root', 0)
            if reader.peek():
                raise ValueError('trailing JSON after complete declared object root')
            store.seal(path, reader)
        store.metrics['creation_and_seal_seconds'] = time.perf_counter() - began
        return store.value(descriptor)
    except BaseException:
        store.metrics['creation_unknown_or_failure_seconds'] = time.perf_counter() - began
        store.close()
        raise


def _ordinary_bytes(value, store):
    encoded = json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if store is not None:
        store.metrics['maximum_ordinary_compact_bytes'] = max(store.metrics['maximum_ordinary_compact_bytes'], len(encoded))
    for offset in range(0, len(encoded), EMIT_BYTES):
        yield encoded[offset:offset + EMIT_BYTES]


def compact_chunks(value, store=None):
    """Preserve all fields and insertion order; every yielded chunk <=64KiB.

    Disk field/event decoding and its C-json output are bounded by FIELD_CHARS,
    not one64KiB token. Only hierarchy punctuation is emitted recursively.
    The ordinary-reference path uses exactly the same compact protocol.
    """
    if isinstance(value, DiskMapping):
        store = value.store
    if isinstance(value, (DiskMapping, dict)):
        yield b'{'
        for index, key in enumerate(value):
            if index:
                yield b','
            yield from _ordinary_bytes(key, store)
            yield b':'
            entry = value[key]
            if key in ('search', 'tree', 'children', 'events', 'hints'):
                yield from compact_chunks(entry, store)
            else:
                yield from _ordinary_bytes(entry, store)
            del entry
        yield b'}'
    elif isinstance(value, (DiskSequence, list, tuple)):
        yield b'['
        for index, entry in enumerate(value):
            if index:
                yield b','
            if isinstance(entry, (DiskMapping, DiskSequence, dict)):
                yield from compact_chunks(entry, store)
            else:
                yield from _ordinary_bytes(entry, store)
            del entry
        yield b']'
    else:
        yield from _ordinary_bytes(value, store)


def exact_compact_bytes(path, value):
    began = time.perf_counter()
    original, emitted = hashlib.sha256(), hashlib.sha256()
    length, maximum = 0, 0
    # Coalesce tiny hierarchy punctuation without retaining a full node/tree.
    pending = bytearray()
    with gzip.open(path, 'rb') as source:
        def compare(block):
            nonlocal length, maximum
            actual = source.read(len(block))
            if actual != block:
                raise ValueError('complete original compact-byte mismatch at ' + str(length))
            original.update(actual)
            emitted.update(block)
            length += len(block)
            maximum = max(maximum, len(block))
        for block in compact_chunks(value):
            if len(block) > EMIT_BYTES:
                raise ValueError('V7 hard output chunk bound')
            if len(pending) + len(block) > EMIT_BYTES:
                compare(bytes(pending))
                pending.clear()
            pending.extend(block)
        if pending:
            compare(bytes(pending))
        if source.read(1):
            raise ValueError('uncompared trailing original byte')
    return dict(status='passed_complete_original_compact_byte_correspondence',
        original_uncompressed_sha256=original.hexdigest(), decoded_compact_sha256=emitted.hexdigest(),
        bytes=length, maximum_compared_chunk_bytes=maximum,
        seconds=time.perf_counter() - began,
        scope='Complete ordered compact UTF-8 bytes including every ordinary field, node, child, event, hint, key and empty container; no field exclusion or whole-tape inflation. Only frozen standard compact object-root traces are supported.')


def store_binding(value):
    if not isinstance(value, DiskMapping):
        raise TypeError('declared disk-backed root required')
    return value.store.final_binding()


def close_trace(value):
    if isinstance(value, DiskMapping):
        value.store.close()


def statistics():
    return [dict(store.metrics) for store in _STORES]
