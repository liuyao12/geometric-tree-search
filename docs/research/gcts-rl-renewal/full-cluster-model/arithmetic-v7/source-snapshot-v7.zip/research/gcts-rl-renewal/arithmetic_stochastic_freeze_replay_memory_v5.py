"""Freeze a source-only V5 trace sharing gate; no scientific decoding/execution."""
import ast
import datetime
import hashlib
import json
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/stochastic-replay-memory-v5-20261011'
PRIOR = ROOT / '.gcts-active/stochastic-replay-memory-20261011'
ORIGINAL = ROOT / '.gcts-active/arithmetic-stochastic-clusters-20261011/execution-v2'
RSS = 512 * 1024 * 1024
CHARGED = 226.66065275
REMAINING = 553.33934725
NEW_NAMES = (
    'arithmetic_stochastic_replay_memory_v5.py',
    'arithmetic_stochastic_worker_replay_memory_v5.py',
    'arithmetic_stochastic_fixture_replay_memory_v5.py',
    'arithmetic_stochastic_owner_replay_memory_v5.py',
    'arithmetic_stochastic_freeze_replay_memory_v5.py')


def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            result.update(chunk)
    return result.hexdigest()


def rel(path):
    return str(path.relative_to(ROOT))


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
    return sha(path)


def main():
    began = time.perf_counter()
    if (OUT / 'review-package-v5.json').exists():
        raise ValueError('immutable V5 review package already exists')
    prior_plan = json.loads((PRIOR / 'evaluation-plan-v4.json').read_bytes())
    original_path = ORIGINAL / 'evaluation/independent-audit-plan.json'
    original = json.loads(original_path.read_bytes())
    sources = dict(prior_plan['source_sha256'])
    for name in NEW_NAMES:
        path = ROOT / 'research/gcts-rl-renewal' / name
        sources[rel(path)] = sha(path)
    for path, digest in sources.items():
        if sha(ROOT / path) != digest:
            raise ValueError('unchanged frozen semantic source ' + path)
        ast.parse((ROOT / path).read_text(), filename=path)
    review_path = OUT / 'consumer-use-review-v5.json'
    review = json.loads(review_path.read_bytes())
    for path, digest in review['source_sha256'].items():
        if sources.get(path) != digest:
            raise ValueError('consumer argument exact source closure ' + path)
    # Only the import plus the one saved-trace load call differs from V2.
    old_worker = (ROOT / 'research/gcts-rl-renewal/arithmetic_stochastic_worker_replay_memory_v2.py').read_text()
    expected_worker = old_worker.replace(
        'from arithmetic_stochastic_replay_memory_v2 import load, statistics, exact_compact_bytes',
        'from arithmetic_stochastic_replay_memory_v5 import load, load_trace, statistics, exact_compact_bytes').replace(
        "raw = load(ROOT / plan['trace_path'])", "raw = load_trace(ROOT / plan['trace_path'])")
    actual_worker = (ROOT / 'research/gcts-rl-renewal/arithmetic_stochastic_worker_replay_memory_v5.py').read_text()
    if actual_worker != expected_worker:
        raise ValueError('loading-only worker exact permitted diff')
    inputs = dict(prior_plan['input_sha256'])
    prior_paths = [original_path, ROOT / 'docs/basic-tiling-algorithm.md', review_path,
                   OUT / 'authoring-start.json', PRIOR / 'next-loader-strategy-v1.json']
    prior_phases = []
    original_receipt = ORIGINAL / 'evaluation/independent-audit.json'
    for path in [original_receipt] + [PRIOR / kind / 'phase-receipt.json' for kind in (
        'helpers-v1', 'helpers-v2', 'evaluation-v2', 'helpers-v3', 'evaluation-v3',
        'helpers-v4', 'evaluation-v4')]:
        receipt = json.loads(path.read_bytes())
        key = 'seconds_before_final_phase_receipt_write' if path == original_receipt else 'seconds_before_phase_receipt_write'
        prior_phases.append(dict(path=rel(path), sha256=sha(path), seconds=receipt[key],
                                 status=receipt['status'],
                                 conservative_owner_plus_worker_peak_bytes=receipt.get('conservative_owner_plus_worker_peak_bytes')))
        prior_paths.append(path)
    if abs(sum(item['seconds'] for item in prior_phases) - CHARGED) > 1e-8:
        raise ValueError('preserved cumulative original audit/helper cost')
    if CHARGED + REMAINING != 780:
        raise ValueError('unchanged original cumulative audit envelope')
    for name in ('review-package-v4.json', 'evaluation-plan-v4.json', 'helper-plan-v4.json',
                 'source-snapshot-v4.zip', 'source-verification-v4.json'):
        prior_paths.append(PRIOR / name)
    for path in prior_paths:
        inputs[rel(path)] = sha(path)
    for path, digest in inputs.items():
        if sha(ROOT / path) != digest:
            raise ValueError('unchanged original input/history ' + path)
    helper_dir, eval_dir = OUT / 'helpers-v5', OUT / 'evaluation-v5'
    helper_dir.mkdir()
    eval_dir.mkdir()
    helper_names = set(NEW_NAMES) - {'arithmetic_stochastic_worker_replay_memory_v5.py'}
    helper_names.update(('arithmetic_stochastic_replay_memory_v1.py', 'arithmetic_stochastic_replay_memory_v2.py'))
    helper_sources = {p: h for p, h in sources.items() if Path(p).name in helper_names}
    helper_inputs = {rel(review_path): sha(review_path),
                     'docs/basic-tiling-algorithm.md': inputs['docs/basic-tiling-algorithm.md']}
    helper_jobs, pairs = [], []

    def helper(job, mode, trace=None):
        job_inputs = {rel(review_path): sha(review_path)}
        plan = dict(job=job, mode=mode, seconds=25, rss_bytes=RSS,
                    source_sha256=helper_sources, input_sha256=job_inputs,
                    output_path=rel(helper_dir / (job + '.json')),
                    searches=0, training_episodes=0, native_queries=0, graph_replays=0)
        if trace is not None:
            plan['trace_path'] = rel(trace)
            job_inputs[rel(trace)] = sha(trace)
            helper_inputs[rel(trace)] = sha(trace)
        path = helper_dir / (job + '-plan.json')
        digest = save(path, plan)
        helper_jobs.append(dict(job=job, plan_path=rel(path), plan_sha256=digest,
                                output_path=plan['output_path'], lifecycle_seconds=30))

    helper('synthetic-controls', 'controls')
    for name, trace in (('effect-pilot', ORIGINAL / 'effect/effect-pilot-search.json.gz'),
                        ('train-01', ORIGINAL / 'training/train-01-search.json.gz'),
                        ('train-08', ORIGINAL / 'training/train-08-search.json.gz')):
        a, b = name + '-reference', name + '-repaired'
        helper(a, 'reference', trace)
        helper(b, 'repaired', trace)
        pairs.append([a, b])
    helper_plan = dict(status='frozen_source_only_before_independent_review_and_root_dispatch',
        kind='helpers', seconds=180, rss_bytes=RSS, historical_failed_audit_seconds=CHARGED,
        requires_root_activation=True, root_activation_path=rel(OUT / 'helper-activation-v5.json'),
        source_sha256=helper_sources, input_sha256=helper_inputs, jobs=helper_jobs,
        correspondence_pairs=pairs,
        worker_source='research/gcts-rl-renewal/arithmetic_stochastic_fixture_replay_memory_v5.py',
        worker_pass_status='passed_complete_loading_value_helper',
        output_path=rel(helper_dir / 'phase-receipt.json'),
        scope='Nine complete synthetic values/byte gates, thirteen fail-closed scope/parser controls, four lexical normalization controls, assigned-zero byte mutant, plain-list type/tuple mutant and alias-sensitive mutating-consumer distinction. All three ordinary/repaired501-node pairs receive full unchanged V2 compact byte comparison. No semantic graph, training, search or native work.',
        clock='25s internal30s owned per helper,180s owner phase; complete helper phase charged once to original780s, preserving226.66065275s prior charge. No dispatch until exact root helper activation after independent source review.')
    helper_path = OUT / 'helper-plan-v5.json'
    helper_digest = save(helper_path, helper_plan)
    jobs = []
    for old_job in original['jobs']:
        old_path = ROOT / old_job['plan_path']
        inputs[rel(old_path)] = sha(old_path)
        plan = json.loads(old_path.read_bytes())
        plan['source_sha256'] = sources
        plan['input_sha256'] = {**plan['input_sha256'], rel(review_path): sha(review_path)}
        plan['output_path'] = rel(eval_dir / (old_job['job'] + '-audit.json'))
        plan['loading_only_repair'] = 'V2 loader retained for all nontrace artifacts; trace-only plain-list pair sharing plus existing tuple4 sharing; unchanged complete V2 original byte gate and all independent semantic replay checks.'
        path = eval_dir / (old_job['job'] + '-plan.json')
        digest = save(path, plan)
        jobs.append(dict(job=old_job['job'], plan_path=rel(path), plan_sha256=digest,
                         output_path=plan['output_path'], lifecycle_seconds=120))
    eval_plan = dict(status='frozen_source_only_before_independent_review_helpers_and_root_dispatch',
        kind='evaluation', seconds=REMAINING, rss_bytes=RSS,
        original_cumulative_audit_seconds=780, historical_failed_audit_seconds=CHARGED,
        requires_root_activation=True, root_activation_path=rel(OUT / 'activation-v5.json'),
        helper_receipt_path=helper_plan['output_path'], helper_plan_sha256=helper_digest,
        source_sha256=sources, input_sha256=inputs, jobs=jobs,
        worker_source='research/gcts-rl-renewal/arithmetic_stochastic_worker_replay_memory_v5.py',
        worker_pass_status='passed_complete_actual_graph_rng_and_policy_replay',
        output_path=rel(eval_dir / 'phase-receipt.json'),
        semantic_model_sha256='b131949034b0e396ab885a5a94b870f12d1443e2bdc5df0550963ec0e0698c11',
        full_language=dict(rows=13, placements=19848, required_points=52, interfaces=153, admitted_definitions=94),
        unchanged='Every original independent graph/scheduler/fallback/hint/rollback/feature/RNG/update source and job input remains byte-identical. Complete trace fields and every actual node/event/full census preserved. Only saved-trace loading changes; all other loads use V2/V1 unchanged.',
        complete_gate='All six individually passed complete original-byte gates and semantic replays plus conservative owned lifecycle gates are required. Any failure, unknown, missing receipt, resource overshoot or incomplete job stops the phase, retaining attempted/failed/unexecuted counts.',
        budgets='115s internal120s owned actual per job,512MiB owner+freshworker kernel peak, original780s minus226.66065275s prior inclusive charges and measured future helper phase.553.33934725s before helpers. Owner reserves120s before each job; six worst-case lifecycles do not fit, so allsix completion remains unresolved. No widening/reset.',
        authority='Only root may dispatch either phase after independent source review; owner requires exact root activation and byte-pinned prerequisites. Worker CLI is technically callable directly, so this is controlled owner execution rather than an inaccessible standalone executable.',
        queries=dict(searches=0, training_episodes=0, native_queries=0))
    eval_path = OUT / 'evaluation-plan-v5.json'
    eval_digest = save(eval_path, eval_plan)
    verification = dict(status='passed_source_only_ast_pins_and_exact_worker_diff',
        parsed_sources=len(sources), verified_input_pins=len(inputs), consumer_source_pins=len(review['source_sha256']),
        worker_diff='Only V5 loader import and raw=load_trace(...); every other worker byte unchanged from V2.',
        exact_original_byte_gate_sha256=sources['research/gcts-rl-renewal/arithmetic_stochastic_replay_memory_v2.py'],
        fixtures_executed=0, scientific_loads=0, censuses=0, semantic_replays=0,
        searches=0, training_episodes=0, native_queries=0,
        scope='Static syntax and exact source/input hash validation only. Nonmutation argument and prospective controls require independent review; this does not pass a decoder/semantic/resource gate.')
    verify_path = OUT / 'source-verification-v5.json'
    save(verify_path, verification)
    archive_path = OUT / 'source-snapshot-v5.zip'
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(sources):
            archive.write(ROOT / path, path)
        archive.write(review_path, rel(review_path))
    current = datetime.datetime.now(datetime.timezone.utc)
    started = datetime.datetime.fromisoformat(json.loads((OUT / 'authoring-start.json').read_bytes())['utc_start'])
    paths = [helper_path, eval_path, archive_path, review_path, verify_path, OUT / 'authoring-start.json']
    paths += [ROOT / job['plan_path'] for job in helper_jobs + jobs]
    package = dict(status='frozen_source_ready_v5_trace_only_list_sharing_review_package',
        helper_plan=dict(path=rel(helper_path), sha256=helper_digest),
        evaluation_plan=dict(path=rel(eval_path), sha256=eval_digest),
        consumer_argument=dict(path=rel(review_path), sha256=sha(review_path), disposition='awaiting_independent_source_review'),
        sources=sources, inputs=inputs,
        files=[dict(path=rel(path), sha256=sha(path), bytes=path.stat().st_size) for path in paths],
        prior_inclusive_phases_preserved=prior_phases,
        original_audit_seconds=780, charged_seconds=CHARGED, remaining_seconds_before_helpers=REMAINING,
        source_preparation_seconds_before_package_write=time.perf_counter()-began,
        source_authoring_calendar_interval_seconds=(current-started).total_seconds(),
        authoring_scope='Calendar interval since source-writing marker, including interleaved inspection/waits; not CPU effort. Earlier inspection/design time uninstrumented and unknown. Freezer preparation measured separately; no scientific helper/census/replay performed.',
        feasibility='V2 observed551485440B combined was14614528B above unchanged512MiB; V4 observed723189760B. Trace-only repeated-pair storage is a prospective reduction with unknown occurrence counts, savings, time and actual peak. No allocation cause established from earlier peaks. No acceptance or comparative policy gain inferred.',
        actual_dispatches=0, scientific_loads=0, censuses=0, helpers=0, graph_replays=0,
        searches=0, training_episodes=0, native_queries=0,
        fallback_if_unresolved='Stop with exact unknown/unexecuted accounting. Any future full streaming census or semantic streaming design needs a separately frozen source/budget/review gate; no easier target or new search/training/native execution.')
    package_path = OUT / 'review-package-v5.json'
    save(package_path, package)
    print(json.dumps(dict(status=package['status'], package_sha256=sha(package_path),
        helper_plan_sha256=helper_digest, evaluation_plan_sha256=eval_digest,
        preparation_seconds=package['source_preparation_seconds_before_package_write'])), flush=True)


if __name__ == '__main__':
    main()
