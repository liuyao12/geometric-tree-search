"""Loading-only v4: streamed hierarchy with explicit per-load dictionary-key sharing.

The strict v1 reversible reduction and v2 complete-byte gate remain pinned.
No complete reduced tape string is inflated. Every ordinary field is decoded
by Python's standard JSONDecoder once, after lexical boundary detection. Dictionary keys are explicitly interned across those calls; only
the search/tree/children mapping hierarchy is read recursively outside it.
"""
import gzip
import io
import json
import re
import tempfile
import time
from pathlib import Path
from arithmetic_stochastic_replay_memory_v1 import TOKEN
from arithmetic_stochastic_replay_memory_v2 import exact_compact_bytes

ROOT=Path(__file__).resolve().parents[2]
TEMP=ROOT/'.gcts-active/stochastic-replay-memory-20261011/decoder-temp-v3'
STRUCT=re.compile(r'(?P<string>"(?:[^"\\]|\\.)*")|(?P<partial>"(?:[^"\\]|\\.)*(?:\\)?$)|(?P<bracket>[\[\]{}])')
STRING=re.compile(r'"(?:[^"\\]|\\.)*"')
DELIMITER=re.compile(r'[,\]}\s]')
_STATISTICS=[]


def statistics():return list(_STATISTICS)


class HierarchyReader:
    def __init__(self,stream,restore,hook,intern_key):
        self.stream,self.restore=stream,restore
        self.intern_key=intern_key
        self.decoder=json.JSONDecoder(object_hook=hook)
        self.buffer,self.position,self.eof='',0,False
        self.maximum_buffer_characters=0;self.standard_value_decodes=0;self.hierarchy_mappings=0

    def fill(self):
        if self.position:
            self.buffer=self.buffer[self.position:];self.position=0
        part=self.stream.read(65536)
        self.eof=not part;self.buffer+=part
        self.maximum_buffer_characters=max(self.maximum_buffer_characters,len(self.buffer))
        if len(self.buffer)>33554432:
            raise ValueError('unknown_streaming_ordinary_field_32Mi_character_resource_budget')
        return bool(part)

    def peek(self):
        while True:
            while self.position<len(self.buffer) and self.buffer[self.position] in ' \r\n\t':self.position+=1
            if self.position<len(self.buffer):return self.buffer[self.position]
            if self.eof:return ''
            self.fill()

    def consume(self,token):
        if self.peek()!=token:raise ValueError('hierarchy JSON delimiter '+repr(token))
        self.position+=1

    def ordinary(self):
        first=self.peek()
        if not first:raise ValueError('missing complete ordinary JSON field')
        # Compact consumed prefix before tracking incremental lexical positions.
        if self.position:self.buffer=self.buffer[self.position:];self.position=0
        end=None
        if first in '[{':
            depth,scan=0,0
            while end is None:
                last=scan
                for match in STRUCT.finditer(self.buffer,scan):
                    if match.group('partial') is not None:
                        last=match.start();break
                    if match.group('bracket') is not None:
                        depth+=1 if match.group('bracket') in '[{' else -1
                        if depth==0:end=match.end();break
                    last=match.end()
                if end is not None:break
                if self.eof:raise ValueError('truncated ordinary JSON container')
                scan=last;self.fill()
        elif first=='"':
            while True:
                match=STRING.match(self.buffer)
                if match is not None:end=match.end();break
                if self.eof:raise ValueError('truncated ordinary JSON string')
                self.fill()
        else:
            while True:
                match=DELIMITER.search(self.buffer)
                if match is not None:end=match.start();break
                if self.eof:end=len(self.buffer);break
                self.fill()
        value,decoded_end=self.decoder.raw_decode(self.buffer[:end])
        if decoded_end!=end:raise ValueError('ordinary JSON lexical boundary mismatch')
        self.position=end;self.standard_value_decodes+=1
        return self.restore(value)

    def mapping(self,special):
        self.consume('{');value={};self.hierarchy_mappings+=1
        if self.peek()=='}':self.consume('}');return value
        while True:
            key=self.ordinary()
            if not isinstance(key,str):raise ValueError('JSON mapping string key required')
            key=self.intern_key(key)
            self.consume(':')
            value[key]=special[key]() if key in special else self.ordinary()
            token=self.peek()
            if token=='}':self.consume('}');return value
            self.consume(',')

    def children(self):
        self.consume('[');result=[]
        if self.peek()==']':self.consume(']');return result
        while True:
            result.append(self.mapping({'tree':self.node}))
            if self.peek()==']':self.consume(']');return result
            self.consume(',')

    def node(self):return self.mapping({'children':self.children})
    def search(self):return self.mapping({'tree':self.node})
    def root(self):
        result=self.mapping({'search':self.search})
        if self.peek():raise ValueError('trailing JSON after complete object root')
        return result


def load(path):
    path=Path(path);began=time.perf_counter()
    if path.suffix!='.gz':
        with path.open('rt') as stream:result=json.load(stream)
        if not isinstance(result,dict):raise ValueError('declared object-root loading scope')
        _STATISTICS.append(dict(path=str(path),seconds=time.perf_counter()-began,kind='ordinary_small_object_json',shared_arrays=0))
        return result
    TEMP.mkdir(exist_ok=True)
    arrays,indexes,input_bytes,occurrences,strings=[],{},0,0,0
    dictionary_keys={};dictionary_key_occurrences=0
    with tempfile.TemporaryFile('w+b',dir=TEMP) as reduced:
        with gzip.open(path,'rb') as source:
            pending=b''
            while True:
                part=source.read(65536);input_bytes+=len(part);eof=not part;data=pending+part;last=0
                for match in TOKEN.finditer(data):
                    if match.group('partial') is not None:break
                    reduced.write(data[last:match.start()])
                    if match.group('string') is not None:
                        original=match.group('string')
                        if json.loads(original).startswith('#'):raise ValueError('reserved interning string collision')
                        strings+=1;reduced.write(original)
                    else:
                        key=tuple(int(match.group(name)) for name in ('a','b','c','d'))
                        index=indexes.get(key)
                        if index is None:index=len(arrays);indexes[key]=index;arrays.append(key)
                        occurrences+=1;reduced.write(('"#%d"' % index).encode())
                    last=match.end()
                pending=data[last:]
                if eof:reduced.write(pending);break
                if len(pending)>2097152:raise ValueError('unknown_decoder_long_token_resource_budget')
        reduced_bytes=reduced.tell();reduced.seek(0)
        def restore(value):
            if isinstance(value,str) and value.startswith('#'):
                index=int(value[1:])
                if str(index)!=value[1:] or not 0<=index<len(arrays):raise ValueError('invalid reversible array reference')
                return arrays[index]
            if isinstance(value,list):return [restore(x) if not isinstance(x,dict) else x for x in value]
            return value
        def intern_key(key):
            nonlocal dictionary_key_occurrences
            if not isinstance(key,str):raise ValueError('dictionary key sharing only applies to strings')
            dictionary_key_occurrences+=1
            return dictionary_keys.setdefault(key,key)
        def hook(obj):return {intern_key(key):restore(value) for key,value in obj.items()}
        with io.TextIOWrapper(reduced,encoding='utf-8',newline='') as text:
            reader=HierarchyReader(text,restore,hook,intern_key);result=reader.root()
            metrics=dict(maximum_buffer_characters=reader.maximum_buffer_characters,
                standard_value_decodes=reader.standard_value_decodes,hierarchy_mappings=reader.hierarchy_mappings)
    _STATISTICS.append(dict(path=str(path),kind='complete_hierarchy_streamed_standard_JSON_with_per_load_dictionary_key_and_array_sharing',
        seconds=time.perf_counter()-began,original_uncompressed_bytes=input_bytes,
        reduced_temporary_json_bytes=reduced_bytes,shared_arrays=len(arrays),array_occurrences=occurrences,
        quoted_strings_checked=strings,dictionary_key_occurrences=dictionary_key_occurrences,
        shared_dictionary_keys=len(dictionary_keys),**metrics,
        scope='All root/search/tree/children keys and ordinary field values preserved in insertion order. Per-load key table reuses equal string key objects across ordinary-value decodes and hierarchy mappings; values are unchanged. Ordinary values parsed once by standard JSONDecoder; duplicate keys retain Python last-wins semantics. Complete frozen actual bytes separately checked with unchanged v2 gate. Maximum ordinary field buffer32Mi characters, unresolved if exceeded; no strict universal JSON parser claim.'))
    return result
