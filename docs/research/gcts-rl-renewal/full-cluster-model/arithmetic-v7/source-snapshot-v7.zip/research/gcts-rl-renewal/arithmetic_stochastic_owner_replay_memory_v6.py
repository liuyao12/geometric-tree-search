"""Sole-owner bounded helper/replay workers; no searches, training or native work."""
import argparse
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'.gcts-active/stochastic-replay-memory-v6-20261011'


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()


def write_new(path,value):
    with path.open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')


def main(plan_path):
    began=time.perf_counter();plan=json.loads(plan_path.read_bytes());destination=ROOT/plan['output_path']
    if destination.exists():raise ValueError('immutable phase receipt exists')
    result=dict(status='checking_loading_helpers' if plan['kind']=='helpers' else 'checking_loading_only_complete_evaluation_replay',
        plan_sha256=sha(plan_path),kind=plan['kind'],observations=[],attempted=[],failed=[],
        unexecuted=[job['job'] for job in plan['jobs']],searches=0,training_episodes=0,native_queries=0)
    spent_helpers=0.;max_child_peak=0
    try:
        for p,h in {**plan['source_sha256'],**plan['input_sha256']}.items():
            if sha(ROOT/p)!=h:raise ValueError('frozen replay phase pin '+p)
        if plan['requires_root_activation']:
            activation=json.loads((ROOT/plan['root_activation_path']).read_bytes())
            if activation['status']!='authorized_by_root_after_independent_review' or activation['plan_sha256']!=sha(plan_path):
                raise ValueError('root independent review and exact activation required')
            for p,h in activation['prerequisite_sha256'].items():
                if sha(ROOT/p)!=h:raise ValueError('exact root prerequisite '+p)
        if plan['kind']=='evaluation':
            helper_path=ROOT/plan['helper_receipt_path'];relative=str(helper_path.relative_to(ROOT))
            if activation['prerequisite_sha256'].get(relative)!=sha(helper_path):
                raise ValueError('root exact helper prerequisite required')
            helpers=json.loads(helper_path.read_bytes())
            if helpers['status']!='passed_complete_loading_value_correspondence_helpers':
                raise ValueError('all complete loading value helpers must pass before full evaluation replay')
            if helpers['plan_sha256']!=plan['helper_plan_sha256']:
                raise ValueError('same exact frozen helper plan')
            spent_helpers=helpers['seconds_before_phase_receipt_write']
            for p,h in activation['prerequisite_sha256'].items():
                if sha(ROOT/p)!=h:raise ValueError('exact root prerequisite '+p)
        envelope=plan['seconds']-spent_helpers
        for job in plan['jobs']:
            remaining=envelope-(time.perf_counter()-began)
            if remaining<job['lifecycle_seconds']:
                result['status']='unknown_phase_reservation_budget';break
            path=ROOT/job['plan_path']
            if sha(path)!=job['plan_sha256']:raise ValueError('frozen exact job plan')
            output=ROOT/job['output_path'];folder=output.parent
            stdout=folder/(job['job']+'-stdout.txt');stderr=folder/(job['job']+'-stderr.txt')
            lifetime_path=folder/(job['job']+'-lifetime.json')
            job_plan=json.loads(path.read_bytes())
            store=ROOT/job_plan['trace_store_path'] if 'trace_store_path' in job_plan else None
            if any(p.exists() for p in (output,stdout,stderr,lifetime_path)) or (store is not None and store.exists()):
                raise ValueError('single execution refuses existing job artifact '+job['job'])
            result['attempted'].append(job['job']);result['unexecuted'].remove(job['job'])
            started=time.perf_counter();child=None;terminal=None;usage=None;failure=None
            with stdout.open('xb') as a,stderr.open('xb') as b:
                try:
                    child=subprocess.Popen([sys.executable,str(ROOT/plan['worker_source']),'--plan',str(path)],
                        cwd=ROOT,stdout=a,stderr=b,start_new_session=True)
                    while True:
                        waited,status,usage=os.wait4(child.pid,os.WNOHANG)
                        if waited:
                            terminal=os.waitstatus_to_exitcode(status);child.returncode=terminal;break
                        if time.perf_counter()-started>=job['lifecycle_seconds']:
                            failure='full_worker_lifecycle_timeout'
                            # This is our unreaped, directly owned pure worker.
                            os.kill(child.pid,signal.SIGKILL)
                            _,status,usage=os.wait4(child.pid,0)
                            terminal=os.waitstatus_to_exitcode(status);child.returncode=terminal;break
                        time.sleep(min(.05, max(0., job['lifecycle_seconds']-(time.perf_counter()-started))))
                except Exception as exc:
                    failure=type(exc).__name__+': '+str(exc)
                finally:
                    if child is not None and terminal is None:
                        try:os.kill(child.pid,signal.SIGKILL)
                        except ProcessLookupError:pass
                        _,status,usage=os.wait4(child.pid,0)
                        terminal=os.waitstatus_to_exitcode(status);child.returncode=terminal
            seconds=time.perf_counter()-started
            receipt=None
            try:
                if output.exists():
                    receipt=json.loads(output.read_bytes())
                    if not isinstance(receipt,dict):raise ValueError('worker receipt must be an object')
                else:failure=failure or 'missing_worker_receipt'
            except Exception as exc:failure=failure or 'malformed_worker_receipt '+str(exc)
            child_peak=usage.ru_maxrss if usage is not None else 0
            max_child_peak=max(max_child_peak,child_peak)
            conservative=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss+child_peak
            passed=bool(terminal==0 and failure is None and receipt is not None
                and receipt.get('status')==plan['worker_pass_status'] and seconds<=job['lifecycle_seconds']
                and conservative<=plan['rss_bytes'])
            lifetime=dict(job=job['job'],status='passed_owned_loading_worker_lifetime' if passed else 'unknown_or_failed_owned_loading_worker_lifetime',
                worker_pid=child.pid if child else None,exit_code=terminal,terminal_and_reaped=child is not None and terminal is not None,
                failure=failure,full_worker_seconds=seconds,kernel_fresh_worker_peak_bytes=child_peak,
                kernel_owner_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                conservative_owner_plus_worker_peak_bytes=conservative,
                wall_overshoot_seconds=max(0,seconds-job['lifecycle_seconds']),memory_overshoot_bytes=max(0,conservative-plan['rss_bytes']),
                receipt_sha256=sha(output) if output.exists() else None,
                enforcement='Sole wait4 owner of fresh pure worker; bounded wall then kill/reap only unreaped direct child, stdout/stderr preserved. Independent fresh-child kernel and owner peaks after exit; retrospective512MiB, no hard OS cap or RSS sampler claim.',
                scope='Workers have no subprocess/engine/training/native execution path; persistent exclusive complete or partial SQLite spools only, no descendant process claim; creation, decode, byte comparison, replay, final binding and connection/cache cleanup inside full child lifetime.')
            write_new(lifetime_path,lifetime)
            result['observations'].append(dict(lifetime=lifetime,receipt=receipt))
            if not passed:
                result['failed'].append(job['job']);result['status']='unknown_or_failed_loading_worker_gate';break
        else:
            if plan['kind']=='helpers':
                by={item['receipt']['job']:item['receipt'] for item in result['observations']}
                for pair in plan['correspondence_pairs']:
                    a,b=by[pair[0]],by[pair[1]]
                    if a['canonical']!=b['canonical'] or a['observation']!=b['observation'] or a['nodes']!=b['nodes'] or a['events']!=b['events'] or a['weights_sha256']!=b['weights_sha256']:
                        raise ValueError('complete original/repaired JSON-value correspondence '+str(pair))
                result['status']='passed_complete_loading_value_correspondence_helpers'
            else:result['status']='passed_complete_loading_only_six_evaluation_replays'
    except Exception as exc:
        result.update(status='failed_or_unknown_loading_phase',failure_type=type(exc).__name__,failure=str(exc))
    elapsed=time.perf_counter()-began;peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss+max_child_peak
    result.update(seconds_before_phase_receipt_write=elapsed,helper_phase_seconds_already_charged=spent_helpers,
        historical_failed_audit_seconds=plan['historical_failed_audit_seconds'],
        cumulative_audit_seconds_before_phase_receipt_write=plan['historical_failed_audit_seconds']+spent_helpers+elapsed,
        original_cumulative_audit_seconds=780,phase_remaining_seconds=plan['seconds']-spent_helpers,
        conservative_owner_plus_worker_peak_bytes=peak,
        source_preparation_and_receipt_clock_scope='Includes phase input streaming hashes/dispatch/pure worker lifecycles/assembly up to final receipt write; excludes final receipt write and source-authoring time.')
    if elapsed+spent_helpers>plan['seconds'] or peak>plan['rss_bytes']:
        result['status']='unknown_loading_phase_resource_budget'
    write_new(destination,result)
    print(json.dumps({k:v for k,v in result.items() if k!='observations'}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',required=True)
    main(Path(parser.parse_args().plan))
