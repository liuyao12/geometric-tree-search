"""Loading-only v2: exact C-node streaming, original loader unchanged.

Independently implemented from the compact insertion-order JSON specification.
No producer import, engine call, complete tree copy or complete output string.
All dictionary fields are emitted exactly once in their original order, with
only the nested search/tree/children hierarchy traversed outside C json.dumps.
"""
import gzip
import hashlib
import json
import time
from arithmetic_stochastic_replay_memory_v1 import load, statistics


def _encoded(value):
    return json.dumps(value,ensure_ascii=False,separators=(',',':')).encode('utf-8')


def _mapping(value,special):
    if not isinstance(value,dict):raise ValueError('declared trace mapping required')
    yield b'{'
    pending={};emitted=False
    for key,item in value.items():
        if key not in special:
            pending[key]=item;continue
        if pending:
            if emitted:yield b','
            yield _encoded(pending)[1:-1]
            emitted=True;pending={}
        if emitted:yield b','
        yield _encoded(key)+b':'
        yield from special[key](item)
        emitted=True
    if pending:
        if emitted:yield b','
        yield _encoded(pending)[1:-1]
    yield b'}'


def _children(value):
    if not isinstance(value,list):raise ValueError('declared children array required')
    yield b'['
    for index,child in enumerate(value):
        if index:yield b','
        yield from _mapping(child,{'tree':_node})
    yield b']'


def _node(value):
    yield from _mapping(value,{'children':_children})


def _search(value):
    yield from _mapping(value,{'tree':_node})


def segments(value):
    if not isinstance(value,dict):raise ValueError('declared object-root serialization scope')
    yield from _mapping(value,{'search':_search})


def exact_compact_bytes(path,value):
    began=time.perf_counter();a,b=hashlib.sha256(),hashlib.sha256();count,chunks,largest=0,0,0
    with gzip.open(path,'rb') as original:
        for emitted in segments(value):
            actual=original.read(len(emitted));a.update(actual);b.update(emitted)
            if actual!=emitted:
                first=next((i for i,(x,y) in enumerate(zip(actual,emitted)) if x!=y),min(len(actual),len(emitted)))
                raise ValueError('complete C-node compact JSON byte mismatch at offset%d' % (count+first))
            count+=len(emitted);chunks+=1;largest=max(largest,len(emitted))
        if original.read(1):raise ValueError('complete compact JSON original has trailing bytes')
    return dict(status='passed_complete_original_compact_json_byte_correspondence',seconds=time.perf_counter()-began,
        bytes=count,chunks=chunks,largest_emitted_chunk_bytes=largest,
        original_uncompressed_sha256=a.hexdigest(),emitted_sha256=b.hexdigest(),
        scope='Every original byte compared against independent full insertion-order C-json grouped fields plus exact nested search/tree/children stream. All fields emitted once, tuple/list arrays JSON equivalent. No complete original inflation, full tree copy or complete output string; chunk size is measured, not a claimed hard cap.')
