"""Prospective V6 loading-only controls; no graph/search/training/native call."""
import argparse
import copy
import gzip
import hashlib
import json
import resource
import signal
import sqlite3
import tempfile
import time
from pathlib import Path

from arithmetic_stochastic_replay_memory_v6 import (load, load_trace, statistics,
    exact_compact_bytes, store_binding, close_trace, DiskMapping, DiskSequence,
    FieldReader, FOUR_CACHE, PAIR_CACHE, KEY_CACHE)

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/stochastic-replay-memory-v6-20261011'


def digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    return dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def bounded_materialize(value):
    """Synthetic bounded fixtures only; actual trace helpers never call this."""
    if isinstance(value, DiskMapping):
        return {key: bounded_materialize(value[key]) for key in value}
    if isinstance(value, DiskSequence):
        return [bounded_materialize(entry) for entry in value]
    return value


def controls():
    rows = [
        ('numeric-zero-types', dict(integer=[0, -1, 2147483648, 999999999999999999],
            floats=[1.0, 2, 3, 4], scientific=[1e-30, 1e30, -0.0, 3.141592653589793],
            booleans=[True, False, 1, 0], null=None, state={'assigned_zero': 0},
            nested=[[[1, 2, 3, 4]], {'inside': [1, 2, 3, 4]}])),
        ('strings-escaped-unicode', dict(text='literal[1,2,3,4]', quoted='\\"[5,6,7,8]',
            unicode='é λ 😀', escaped='line\n\t slash\\ end',
            tokens=['command:0:0:abc', 'port:1:0:-2:none'])),
        ('chunk-string-boundary', dict(text='A' * 65532 + '\\"[1,2,3,4]',
            long_array=[[i, i + 1, i + 2, i + 3] for i in range(2000)], after=[1, 2, 3, 4])),
        ('field-multichunk-container', dict(pad='x' * 65500,
            items=[{'brackets': '[}]"', 'point': [i, i + 1, i + 2, i + 3]} for i in range(5000)])),
        ('trace-only-pair-type-alias', dict(pair=[17, -9], nested={'pair': [17, -9]},
            different=[17, -8], zero=[0, 0], boolean=[True, False], floats=[17.0, -9.0],
            mixed=[17, '-9'], four=[17, -9, 17, -9], repeat=[[17, -9]] * 20000)),
        ('cache-overflow-retains-values', dict(keys={str(i): [i, -i] for i in range(KEY_CACHE + PAIR_CACHE + 1)},
            four=[[i, 2, 3, 4] for i in range(FOUR_CACHE + 1)])),
    ]
    leaf = {'after': 1, 'children': [], 'before': 0, 'nested': {'unicode': 'é', 'point': [1, 2, 3, 4]}, 'census': []}
    branch = {'later': 2, 'children': [{'post': 0, 'tree': leaf, 'pre': 'x'}], 'earlier': 3}
    rows.append(('every-hierarchy-field-order', {'last': 0, 'search': {
        'after': True, 'tree': branch, 'events': [{'z': 0, 'features': [{'zero': 0.}], 'a': []}],
        'hints': [{'empty': {}, 'members': [[1, 2, 3, 4]]}], 'before': None}, 'first': 'end'}))
    rows.append(('all-empty-containers', {'search': {'events': [], 'tree': {'children': []}, 'hints': []},
        'empty_array': [], 'empty_object': {}, 'empty_string': ''}))
    receipts, negatives, mutations = [], [], []
    with tempfile.TemporaryDirectory(dir=OUT) as temp:
        folder = Path(temp)

        def decoded(index, raw):
            file = folder / (index + '.json.gz')
            file.write_bytes(gzip.compress(raw, mtime=0))
            return file, load_trace(file, folder / (index + '-store'))

        for index, (name, expected) in enumerate(rows):
            compact = json.dumps(expected, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
            file, actual = decoded('positive-' + str(index), compact)
            try:
                gate = exact_compact_bytes(file, actual)
                if digest(expected) != digest(bounded_materialize(actual)):
                    raise ValueError('complete synthetic normalized value mismatch ' + name)
                if name == 'trace-only-pair-type-alias':
                    pair = actual['pair']
                    if type(pair) is not list or pair is not actual['nested']['pair'] or pair is not actual['repeat'][-1]:
                        raise ValueError('plain-list read-only pair sharing not preserved')
                    if pair is actual['different'] or type(actual['four']) is not tuple:
                        raise ValueError('unequal values or two/four arities conflated')
                    if type(actual['boolean'][0]) is not bool or type(actual['floats'][0]) is not float or type(actual['mixed'][1]) is not str:
                        raise ValueError('uncertain nonliteral pairs normalized')
                    if pair != expected['pair'] or pair == tuple(expected['pair']):
                        raise ValueError('plain-list type-sensitive negative control')
                    changed_reference = copy.deepcopy(expected)
                    changed_reference['pair'][0] = 999
                    pair[0] = 999
                    if changed_reference['nested']['pair'][0] != 17 or actual['nested']['pair'][0] != 999:
                        raise ValueError('alias-sensitive mutating-consumer distinction lost')
                    try:
                        exact_compact_bytes(file, actual)
                    except ValueError:
                        mutations.append('mutating_shared_list_is_not_supported')
                    else:
                        raise ValueError('byte gate accepted consumer-corrupted pair')
                    pair[0] = 17
                    ordinary = load(file)
                    if type(ordinary['pair']) is not list or ordinary['pair'] is ordinary['nested']['pair']:
                        raise ValueError('trace sharing leaked into other artifact loader')
                if name == 'every-hierarchy-field-order':
                    node = actual['search']['tree']
                    child = node['children'][0]
                    event = actual['search']['events'][0]
                    if not (isinstance(node, DiskMapping) and isinstance(node['children'], DiskSequence)
                            and isinstance(child, DiskMapping) and type(event) is dict):
                        raise ValueError('declared proxy versus ordinary-field types')
                    if list(node) != list(expected['search']['tree']) or list(child) != list(expected['search']['tree']['children'][0]):
                        raise ValueError('hierarchy insertion order')
                    if list(actual['search']['events']) != expected['search']['events'] or len(node['children']) != 1:
                        raise ValueError('saved consumer index/len/iter values')
                    try:
                        node['kind'] = 'mutant'
                    except TypeError:
                        mutations.append('proxy_write_rejected')
                    else:
                        raise ValueError('read-only proxy unexpectedly mutable')
                    try:
                        actual.store.connection.execute("UPDATE containers SET count=0")
                    except sqlite3.OperationalError:
                        mutations.append('query_only_database_write_rejected')
                    else:
                        raise ValueError('read-only spool unexpectedly mutable')
                    original = expected
                    variants = []
                    zero = copy.deepcopy(original); zero['search']['events'][0]['z'] = 1; variants.append(('event-assigned-zero', zero))
                    omit = copy.deepcopy(original); del omit['search']['tree']['nested']; variants.append(('node-field-omitted', omit))
                    omit = copy.deepcopy(original); omit['search']['tree']['children'] = []; variants.append(('child-omitted', omit))
                    omit = copy.deepcopy(original); omit['search']['events'] = []; variants.append(('event-omitted', omit))
                    kind = copy.deepcopy(original); kind['search']['events'][0]['a'] = {}; variants.append(('empty-container-type', kind))
                    order = copy.deepcopy(original); order['search'] = dict(reversed(list(order['search'].items()))); variants.append(('field-order-changed', order))
                    for label, variant in variants:
                        try:
                            exact_compact_bytes(file, variant)
                        except ValueError:
                            mutations.append(label)
                        else:
                            raise ValueError('complete byte gate accepted mutant ' + label)
                binding = store_binding(actual)
                receipts.append(dict(name=name, complete_bytes=gate, canonical=digest(expected), spool=binding))
            finally:
                close_trace(actual)

        failures = [
            ('reserved-value', b'{"value":"#0"}'), ('escaped-reserved-key', b'{"\\u00230":0}'),
            ('escaped-reserved-value', b'{"value":"\\u00230"}'), ('leading-zero', b'{"a":[01,2,3,4]}'),
            ('negative-leading-zero', b'{"a":[-01,2]}'), ('nonobject-root', b'[1,2,3,4]'),
            ('scalar-root', b'"text"'), ('truncated', b'{"a":[1,2,3,4]'),
            ('duplicate-key', b'{"a":0,"a":1}'), ('escaped-duplicate-key', b'{"arr":0,"a\\u0072r":1}'),
            ('duplicate-special-tree', b'{"search":{"tree":{"children":[]},"tree":{"children":[]}}}'),
            ('negative-integer-zero', b'{"a":[-0,0]}'), ('noncompact-whitespace', b'{"a": [1,2]}'),
            ('trailing-bytes', b'{"a":0}x')]
        for index, (name, raw) in enumerate(failures):
            value = None
            try:
                file, value = decoded('negative-' + str(index), raw)
                exact_compact_bytes(file, value)
            except (ValueError, TypeError, IndexError, sqlite3.Error):
                negatives.append(name)
            else:
                raise ValueError('malformed/reserved/noncompact control accepted ' + name)
            finally:
                if value is not None:
                    close_trace(value)
        # This raw decoder compatibility fixture is distinct from byte gating:
        # duplicate keys must remain last-wins, with first insertion position.
        raw = b'{"z":0,"a":[1,2],"a":[3,4],"end":1}'
        file, value = decoded('duplicate-last-wins', raw)
        try:
            if bounded_materialize(value) != json.loads(raw) or list(value) != list(json.loads(raw)):
                raise ValueError('standard duplicate-key last-wins/order compatibility')
        finally:
            close_trace(value)
    return dict(status='passed_complete_synthetic_disk_loading_controls', positive=receipts,
        rejected=negatives, mutations_rejected=mutations,
        duplicate_key_semantics='Standard JSON last value wins, first key insertion retained; full byte gate rejects duplicate lexical fields.',
        scope='Bounded synthetic only; every field/type/order/empty-container checks, meaningful alias and field-omission controls. Proxies intentionally fail dict/list type and mutation equivalence outside inspected read-only consumers.',
        searches=0, training_episodes=0, native_queries=0, graph_replays=0)


def timeout(*_):
    raise TimeoutError('V6 loading helper internal wall ceiling')


def main(plan_path):
    began = time.perf_counter()
    plan = json.loads(plan_path.read_bytes())
    output = ROOT / plan['output_path']
    if output.exists():
        raise ValueError('immutable helper output exists')
    result = dict(status='running_loading_value_helper', job=plan['job'], mode=plan['mode'],
        plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(), searches=0,
        training_episodes=0, native_queries=0, graph_replays=0)
    value = None
    signal.signal(signal.SIGALRM, timeout)
    signal.setitimer(signal.ITIMER_REAL, plan['seconds'])
    try:
        for path, expected in {**plan['source_sha256'], **plan['input_sha256']}.items():
            h = hashlib.sha256()
            with (ROOT / path).open('rb') as source:
                for block in iter(lambda: source.read(1048576), b''):
                    h.update(block)
            if h.hexdigest() != expected:
                raise ValueError('exact V6 helper source/input pin ' + path)
        if plan['mode'] == 'controls':
            result['controls'] = controls()
        else:
            path = ROOT / plan['trace_path']
            if plan['mode'] == 'reference':
                with gzip.open(path, 'rt') as source:
                    value = json.load(source)
            elif plan['mode'] == 'repaired':
                value = load_trace(path, ROOT / plan['trace_store_path'])
            else:
                raise ValueError('declared helper mode')
            gate = exact_compact_bytes(path, value)
            result['complete_original_trace_byte_correspondence'] = gate
            result['canonical'] = dict(sha256=gate['original_uncompressed_sha256'], bytes=gate['bytes'],
                protocol='full_original_compact_JSON_fingerprint_v6_not_sorted_canonical')
            result['observation'] = value['observation']
            result['nodes'] = value['search']['metrics']['nodes']
            result['events'] = len(value['search']['events'])
            result['weights_sha256'] = value['search']['weights_sha256']
            if plan['mode'] == 'repaired':
                result['complete_read_only_spool_binding'] = store_binding(value)
        result['status'] = 'passed_complete_loading_value_helper'
    except Exception as exc:
        result.update(status='failed_or_unknown_loading_value_helper', failure_type=type(exc).__name__, failure=str(exc))
    finally:
        try:
            if value is not None:
                close_trace(value)
        except Exception as exc:
            result.update(status='failed_or_unknown_loading_value_helper',
                cleanup_failure=type(exc).__name__ + ': ' + str(exc))
        signal.setitimer(signal.ITIMER_REAL, 0)
        result.update(seconds_before_receipt_write=time.perf_counter() - began,
            kernel_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            loading=statistics())
        if result['seconds_before_receipt_write'] > plan['seconds'] or result['kernel_peak_rss_bytes'] > plan['rss_bytes']:
            result['status'] = 'unknown_loading_value_helper_resource_budget'
        with output.open('x') as stream:
            stream.write(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    main(Path(parser.parse_args().plan))
