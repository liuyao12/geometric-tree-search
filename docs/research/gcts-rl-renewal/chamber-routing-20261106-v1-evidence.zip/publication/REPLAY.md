# Replay the chamber routing study

Extract the archive and run this command with CPython 3.12.

```sh
python3.12 -I -S -B publication/replay_v1.py
```

The replay builds the new outlines from the pinned donor geometries, retrains the policy, evaluates the frozen schedules, audits the exact covers and refutations, and rebuilds the reader. It compares five deterministic outputs byte for byte. The before and after timing receipts are retained as inputs.

To time the final implementation again, run the following command from a separate extracted copy.

```sh
python3.12 -I -S -B source/routing_timing_v1.py
```

The experiment uses only exact geometry for placement and checking. Its policy sees coarse shape features and search progress. The reported work score assigns four units to a node, two to a tile test, four to a join test, five to a proposal containment check, twenty to a separator check and one for each complete group of twenty receptor tests. Elapsed times are measured separately.
