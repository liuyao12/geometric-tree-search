"""Package the checked routing study and its deterministic replay inputs."""
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
from replay_v1 import OUTPUTS, ROOT, STEM, TIMING, inputs


def read(name):
    return json.loads((ROOT / name).read_text())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def pin(raw):
    return dict(bytes=len(raw), sha256=sha256(raw).hexdigest())


def main():
    replay = read("publication/replay-v1.json")
    assert set(replay["sha256"]) == set(OUTPUTS)
    assert set(replay["timing_sha256"]) == set(TIMING)
    assert all(pin((ROOT / name).read_bytes())["sha256"] == digest
               for name, digest in (replay["sha256"] | replay["timing_sha256"]).items())
    browser = read("publication/browser-v1.json")
    assert browser["status"] == "CHECKED_ROUTING_READER"
    experiment = read("data/routing-experiment-v1.json")
    condensed = {}
    for name, family in experiment["systems"].items():
        condensed[name] = [dict(id=r["id"], kind=r["kind"], arms={
            arm: {k: outcome[k] for k in ("status", "counts", "work", "decisions")} for arm, outcome in r["arms"].items()
        }) for r in family["cases"]]
    result = f"report/{STEM}-results.json"
    save(result, dict(schema="CHAMBER-ROUTING-RESULTS-v1", cases=condensed, replay=replay, browser=browser,
                      audit=read("data/routing-audit-v1.json"), timing=read(TIMING[0]), timing_before=read(TIMING[1]),
                      training=read("data/routing-policy-v1.json")))
    paths = (*inputs(), *OUTPUTS, result, "publication/REPLAY.md", "publication/check_v1.cjs",
             "publication/browser-v1.json", "publication/replay-v1.json")
    archive = ROOT / f"report/{STEM}-evidence.zip"
    manifest = {}
    with ZipFile(archive, "w") as bundle:
        for name in paths:
            raw = (ROOT / name).read_bytes()
            assert name not in manifest, name
            assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), name
            manifest[name] = pin(raw)
            member = ZipInfo(name, (2026, 11, 6, 0, 0, 0))
            member.external_attr = 0o100644 << 16
            bundle.writestr(member, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {name: pin(bundle.read(name)) for name in bundle.namelist()} == manifest
    files = (archive, ROOT / result, ROOT / f"report/{STEM}.html")
    save(f"report/{STEM}-manifest.json", dict(schema="CHAMBER-ROUTING-MANIFEST-v1",
        archive_entries=manifest, assets={path.name: pin(path.read_bytes()) for path in files}))
    print(f"Packaged {len(manifest)} evidence files.")


if __name__ == "__main__":
    main()
