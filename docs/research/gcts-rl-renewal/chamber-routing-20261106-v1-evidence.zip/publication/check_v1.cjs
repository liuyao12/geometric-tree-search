const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"],
  });
  try {
    const page = await browser.newPage({ viewport: { width: 1120, height: 900 } });
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const file = pathToFileURL(path.join(__dirname, "../report/chamber-routing-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || file, { waitUntil: "commit" });
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForSelector("#registration mjx-container");
    assert.equal(await page.locator("#routing .flow div").count(), 3);
    assert.equal(await page.locator("#routing tbody tr").count(), 2);
    assert.equal(await page.locator("#registration figure svg").count(), 2);
    assert.equal(await page.locator("#registration .bridge").count(), 1);
    assert.equal(await page.locator("#comparison tbody tr").count(), 70);
    assert.equal(await page.locator("#comparison .bar").count(), 12);
    assert.equal(await page.locator("#replay tbody tr").count(), 2);
    assert.equal(await page.locator("#replay a").count(), 3);
    await page.locator("#comparison details>summary").first().click();
    assert.equal(await page.locator("#comparison details tbody tr:visible").count(), 6);
    if (!process.argv[2]) await page.locator("#registration").screenshot({path:path.join(__dirname,"pose-view-v1.png")});
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.deepEqual(errors, []);
    const receipt = {status:"CHECKED_ROUTING_READER", diagrams:2, comparisonRows:70, timeBars:12,
      mathTypeset:true, mobileNoOverflow:true};
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
    console.log(JSON.stringify(receipt));
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
