"""Regenerate the frozen routing experiment in a clean directory."""
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from subprocess import run
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
STEM = "chamber-routing-20261106-v1"
MODULES = ("boundary_search", "cases", "chamber_audit", "chamber_cases", "chamber_check", "chamber_experiment",
           "chambers", "check", "clipping", "cluster", "geometry", "model", "triangle_geometry",
           "routing_cases", "routing_policy", "routing_experiment", "routing_audit", "routing_timing")
TIMING = ("data/routing-timing-v1.json", "data/routing-timing-before-v1.json")
OUTPUTS = ("input/routing-cases-v1.json", "data/routing-policy-v1.json", "data/routing-experiment-v1.json",
           "data/routing-audit-v1.json", f"report/{STEM}.html")
STAGES = ("source/routing_cases_v1.py", "source/routing_policy_v1.py", "source/routing_experiment_v1.py",
          "source/routing_audit_v1.py", "publication/render_v1.py")


def inputs():
    publication = tuple(sorted(str(p.relative_to(ROOT)) for p in (ROOT / "publication").glob("*.py")))
    return (*(f"source/{name}_v1.py" for name in MODULES), *publication,
            "input/chamber-origins-v1.json", "input/chambers-v1.json", "input/exact-point-model-v1.json",
            "publication/notebook-v1.html", *TIMING)


def main():
    with TemporaryDirectory() as temp:
        clean = Path(temp)
        for name in (*inputs(), *OUTPUTS):
            (clean / name).parent.mkdir(parents=True, exist_ok=True)
        for name in inputs():
            copyfile(ROOT / name, clean / name)
        for name in STAGES:
            run((sys.executable, "-I", "-S", "-B", name), cwd=clean, check=True)
        hashes = {}
        for name in OUTPUTS:
            raw = (clean / name).read_bytes()
            assert raw == (ROOT / name).read_bytes(), name
            hashes[name] = sha256(raw).hexdigest()
    timing = {name: sha256((ROOT / name).read_bytes()).hexdigest() for name in TIMING}
    receipt = dict(status="CHECKED_CLEAN_REPLAY", sha256=hashes, timing_sha256=timing)
    (ROOT / "publication/replay-v1.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
    print(f"Matched {len(hashes)} outputs byte for byte.")


if __name__ == "__main__":
    main()
