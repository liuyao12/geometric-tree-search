"""Render measured routes and an exact transported chamber."""
from collections import Counter
from html import escape
import json
from math import cos, pi, sin, sqrt
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from chamber_cases_v1 import geometry
from chamber_check_v1 import frozen
from chambers_v1 import pose_ring
from routing_experiment_v1 import ARMS
from routing_policy_v1 import cases

STEM = "chamber-routing-20261106-v1"
LABELS = dict(plain="Uninterrupted ordinary", receptor="Immediate receptor", prefix2="Two nodes, then receptor",
              prefix8="Eight nodes, then receptor", learned="Learned router",
              **{"receptor-translate": "Immediate receptor, translations only"})


def load(name):
    return frozen(json.loads((ROOT / f"data/routing-{name}-v1.json").read_text()))["systems"]


def table(headers, rows):
    heads = "".join(f'<th scope="col">{h}</th>' for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{value}</td>" for value in row) + "</tr>" for row in rows)
    return f'<div class="table"><table><thead><tr>{heads}</tr></thead><tbody>{body}</tbody></table></div>'


def to_xy(point):
    if len(point) == 2:
        return point[0] + point[1] / 2, -sqrt(3) * point[1] / 2
    return (sum(v * cos(2 * pi * i / 5) for i, v in enumerate(point)),
            -sum(v * sin(2 * pi * i / 5) for i, v in enumerate(point)))


def figure(shapes, caption):
    coordinates = [tuple(map(to_xy, ring)) for _, ring in shapes]
    xs, ys = zip(*(point for ring in coordinates for point in ring))
    x, y = min(xs), min(ys)
    width, height = max(xs) - x, max(ys) - y
    margin = max(width, height) * .08
    viewbox = f"{-margin:.5f} {-margin:.5f} {width + 2*margin:.5f} {height + 2*margin:.5f}"
    drawn = []
    for (style, _), vertices in zip(shapes, coordinates, strict=True):
        points = " ".join(f"{a-x:.5f},{b-y:.5f}" for a, b in vertices)
        drawn.append(f'<polygon class="{style}" points="{points}"/>')
    return (f'<figure><svg viewBox="{viewbox}" role="img" aria-label="{escape(caption, quote=True)}">'
            f'{"".join(drawn)}</svg><figcaption>{escape(caption)}</figcaption></figure>')


def transport_example(experiment):
    g = geometry("turtle")
    family = experiment[g.kind]
    row = next(r for r in family["cases"] if r["id"] == "turtle-route-test-12")
    fixture = next(r for r in cases()[g.kind] if r["id"] == row["id"])
    answer = row["arms"]["receptor"]
    event = next(e for e in answer["splits"] if e["outcome"] == "positive")
    index, turn, offset = next((i, t, p) for i, t, p in event["parts"] if t and i < len(family["library"]))
    record = family["library"][index]
    cover = record["result"]["patch"]
    original = [("chamber", g.poly(tile)) for tile in cover]
    original.append(("outer", record["ring"]))
    receiver = [("chamber", g.poly(g.shift(g.turn(tile, turn), offset))) for tile in cover]
    receiver.append(("outer", pose_ring(g, record["ring"], turn, offset)))
    receiver.extend(("bridge", g.poly(tile)) for tile in event["path"])
    receiver.extend(("outer", ring) for ring in fixture["rings"])
    return '<div class="grid">' + figure(original, "A checked cover in the canonical chamber.") + figure(
        receiver, "The same cover in a new Turtle outline. The amber tile separates the chambers.") + "</div>"


def summary_rows(requests, arm):
    answers = [r["arms"][arm] for r in requests]
    return (sum(a["status"] != "BOUNDED" for a in answers), sum(a["counts"]["nodes"] for a in answers),
            sum(a["work"] for a in answers), sum(a["counts"].get("nonidentity_reuse_hits", 0) for a in answers))


def main():
    training, experiment, timing, before, audit = (
        load(name) for name in ("policy", "experiment", "timing", "timing-before", "audit"))
    training_rows, results, groups, details, checks, optimized = [], [], [], [], [], []
    for name, system in experiment.items():
        requests = system["cases"]
        train = training[name]
        actions = Counter(a for episode in train["episodes"] for _, a in episode["decisions"])
        selected = Counter(a for row in requests for _, a in row["arms"]["learned"]["decisions"])
        training_rows.append((name.title(), len(train["episodes"]), LABELS[train["champion"]],
                              actions["continue"], actions["probe"], actions["receptor"],
                              selected["continue"], selected["probe"], selected["receptor"]))
        local = []
        maximum = max(median(v["test_ns"]) for v in timing[name].values())
        for arm in ARMS:
            label = LABELS[arm]
            measured = median(timing[name][arm]["test_ns"])
            bar = f'{measured/1e6:.1f}<span aria-hidden="true" class="bar" style="width:{100*measured/maximum:.2f}%"></span>'
            results.append((name.title(), label, *summary_rows(requests, arm), bar))
            if arm in ("plain", "receptor", "learned"):
                optimized.append((name.title(), label, f'{median(before[name][arm]["test_ns"])/1e6:.1f}',
                                  f"{measured/1e6:.1f}"))
            for kind in ("grafted", "control"):
                subset = [row for row in requests if row["kind"] == kind]
                groups.append((name.title(), kind.title(), label, *summary_rows(subset, arm)))
        for row in requests:
            local.append((row["id"], row["kind"], *(f'{row["arms"][a]["status"].lower()} · '
                f'{row["arms"][a]["counts"]["nodes"]}' for a in ARMS)))
        details.append(f'<h3>{name.title()}</h3>' + table(("Request", "Kind", *(LABELS[a] for a in ARMS)), local))
        receipt = audit[name]["checks"]
        checks.append((name.title(), receipt["checked_routing_actions"], receipt["identical_resumptions"],
                       receipt["rejected_wrong_turn"], receipt["compaction_reference_checks"],
                       receipt["orbit_roundtrips"], receipt.get("site_checks", 0),
                       sum(r.get("checked_options", 0) for r in audit[name]["geometry"].values())))
    fields = dict(TRAINING=table(("System", "Training episodes", "Best training schedule", "Train continue",
        "Train probe", "Train receptor", "Test continue", "Test probe", "Test receptor"), training_rows),
        SUMMARY=table(("System", "Arm", "Decided of 14", "Nodes", "Work score", "Nonidentity reuse hits",
                       "Test batch, ms"), results),
        GROUPS=table(("System", "Outline", "Arm", "Decided", "Nodes", "Work score", "Nonidentity reuse hits"), groups),
        OPTIMIZATION=table(("System", "Arm", "Before, ms", "After, ms"), optimized),
        CASES="".join(details),
        AUDIT=table(("System", "Actions checked", "Identical resumptions", "Wrong poses rejected",
                    "Boundary reference checks", "Pose round trips", "Turtle site comparisons",
                    "Placement options checked"), checks),
        FIGURES=transport_example(experiment))
    notebook = (ROOT / "publication/notebook-v1.html").read_text()
    for name, value in fields.items():
        notebook = notebook.replace(f"%%{name}%%", value)
    assert "%%" not in notebook
    (ROOT / f"report/{STEM}.html").write_text(notebook)


if __name__ == "__main__":
    main()
