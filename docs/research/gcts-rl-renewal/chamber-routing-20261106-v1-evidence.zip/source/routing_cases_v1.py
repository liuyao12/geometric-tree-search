"""Freeze disjoint training and receiver outlines before policy training."""
import json
from pathlib import Path
from random import Random
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cases_v1 import frozen, patch_ring, rhomb_grid
from chamber_cases_v1 import geometry, graft, translate
from chamber_experiment_v1 import read_cases, write
from chambers_v1 import Library, pose_ring


def source_rooms(g):
    data = json.loads((ROOT / "input/chamber-origins-v1.json").read_text())[g.kind]
    common = data[0]
    if g.kind == "turtle":
        panels = tuple(frozen(part[0]) for part in common["training"])
        panels += tuple(frozen(rings[0]) for label, rings in common["fixed"]
                        if label in ("crop", "parallelogram"))
        failures = (frozen(common["donor"][0]), frozen(common["movable"][0][1][0]))
        controls = [(label, frozen(rings)) for label, rings in common["fixed"]]
        controls.extend((f"historical-{label}", frozen(rings)) for label, rings in common["movable"])
        controls.extend((f"panel-{i}", (r,)) for i, r in enumerate(panels))
        controls.append(("negative-donor", (failures[0],)))
    else:
        panels = tuple(patch_ring(g, rhomb_grid(x, y, turn))[0]
                       for x, y, turn in ((2, 2, 1), (3, 2, 2), (2, 3, 1),
                                          (4, 3, 2), (4, 4, 1), (5, 3, 2), (6, 3, 1)))
        failures = (frozen(common["donor"][0]),)
        failures += tuple(frozen(r["rings"][0]) for r in data[1]["cascade"] if len(r["rings"]) == 1)
        controls = [(label, frozen(rings)) for label, rings in common["fixed"]]
        for i, (x, y, turn) in enumerate(((2, 3, 2), (3, 3, 1), (4, 3, 3), (4, 4, 2),
                                         (5, 3, 1), (6, 4, 2), (5, 4, 1), (6, 3, 2))):
            rings = patch_ring(g, rhomb_grid(x, y, turn, ((x-1, y-1),)))
            assert rings
            controls.append((f"grid-{i}", rings))
        controls.extend((f"obstruction-{i}", (r,)) for i, r in enumerate(failures))
    return panels, failures, controls


def create(name, donors):
    rng = Random(91331 if name == "turtle" else 716133)
    g = geometry(name)
    canonical = Library(poses=True)
    panels, failures, controls = source_rooms(g)
    known = {canonical.register(g, row["rings"][0])[0] for row in donors}
    output = []

    def append(partition, kind, rings, parts=(), origin=None):
        form, _, _ = canonical.register(g, rings[0])
        if form in known:
            return False
        index = len(output)
        offset = tuple((index + 100) * (97 + 11*j) * (-1)**j for j in range(len(g.zero)))
        output.append(dict(id=f"{name}-route-{partition}-{index:02d}", partition=partition, kind=kind,
                           rings=tuple(translate(ring, offset) for ring in rings),
                           expected_parts=tuple(translate(ring, offset) for ring in parts), origin=origin))
        known.add(form)
        return True

    rng.shuffle(controls)
    for partition, graft_count, control_count in (("train", 8, 4), ("test", 10, 4)):
        built = 0
        for _ in range(80):
            first = rng.choice(failures if built % 3 else panels)
            second = rng.choice(panels)
            first, second = (pose_ring(g, ring, rng.choice(g.turns), g.zero) for ring in (first, second))
            if canonical.register(g, first)[0] == canonical.register(g, second)[0]:
                continue
            try:
                outer, _, _, parts = graft(g, first, second, rng.randrange(len(g.bases)))
            except ValueError:
                continue
            if append(partition, "grafted", (outer,), parts):
                built += 1
                if built == graft_count:
                    break
        assert built == graft_count, (name, partition, built)
        built = 0
        while controls and built < control_count:
            label, rings = controls.pop()
            turn = rng.choice(g.turns)
            posed = tuple(pose_ring(g, ring, turn, g.zero) for ring in rings)
            built += append(partition, "control", posed, origin=label)
        assert built == control_count, (name, partition, built)
    return output


def main():
    inherited = read_cases()
    data = {name: create(name, rows) for name, rows in inherited.items()}
    write("input/routing-cases-v1.json", data)
    print({name: len(rows) for name, rows in data.items()})


if __name__ == "__main__":
    main()
