"""Build connected fixed boundaries from independently selected chambers."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cases_v1 import frozen, fuse, patch_ring, rhomb_grid
from chambers_v1 import normalized, split_rings
from geometry_v1 import Penrose, Turtle, add, area, check_rings, pairs, rings_from_edges, sub


def geometry(name):
    if name == "turtle":
        return Turtle(json.loads((ROOT / "input/exact-point-model-v1.json").read_text()))
    assert name == "penrose"
    return Penrose()


def edges(g, ring):
    return frozenset(e for a, b in pairs(ring) for e in g.atomize(a, b))


def translate(ring, offset):
    return tuple(add(p, offset) for p in ring)


def simple(g, outline):
    if outline is None:
        return None
    rings = rings_from_edges(outline)
    if rings is None or len(rings) != 1:
        return None
    try:
        check_rings(g, rings)
    except AssertionError:
        return None
    return rings[0]


def anchors(g, ring, boundary):
    dirs = {}
    for a, b in edges(g, ring):
        dirs.setdefault(sub(b, a), []).append(a)
    return tuple(sorted({sub(b, p) for a, b in boundary for p in dirs.get(sub(a, b), ())}))


def graft(g, first, second, start=0):
    """Join two separated chambers with one tile and retain the exact split."""
    bases = g.bases[start:] + g.bases[:start]
    one, two = edges(g, first), edges(g, second)
    for bridge in bases:
        contour = g.boundary(bridge)
        for a in anchors(g, first, contour):
            local_a = frozenset((add(p, a), add(q, a)) for p, q in one)
            front = fuse(contour, local_a)
            if simple(g, front) is None:
                continue
            for b in anchors(g, second, contour):
                local_b = frozenset((add(p, b), add(q, b)) for p, q in two)
                if len(local_a | local_b) != len(local_a) + len(local_b):
                    continue
                pocket = split_rings(g, local_a | local_b)
                if not pocket or len(pocket) != 2:
                    continue
                outer = simple(g, fuse(front, local_b))
                if outer is None:
                    continue
                expected = add(add(area(first, g.cross), area(second, g.cross)), area(g.poly(bridge), g.cross))
                if area(outer, g.cross) != expected:
                    continue
                shared = frozenset(contour) & edges(g, outer)
                if not shared:
                    continue
                a_form, _ = normalized(first)
                b_form, _ = normalized(second)
                assert {normalized(r)[0] for r in pocket} == {a_form, b_form}
                return outer, bridge, min(shared), pocket
    raise ValueError("No bridge graft found")


def create(name):
    data = json.loads((ROOT / "input/chamber-origins-v1.json").read_text())[name]
    old = data[0]
    g = geometry(name)
    if name == "turtle":
        positive = tuple(frozen(rings[0]) for rings in old["training"])
        positive += tuple(frozen(rings[0]) for label, rings in old["fixed"] if label in ("crop", "parallelogram"))
        negative = (frozen(old["donor"][0]), frozen(old["movable"][0][1][0]))
    else:
        positive = tuple(patch_ring(g, rhomb_grid(cols, rows, width))[0]
                         for cols, rows, width in ((2, 2, 1), (3, 2, 2), (2, 3, 1),
                                                   (4, 3, 2), (4, 4, 1), (5, 3, 2)))
        negative = (frozen(old["donor"][0]),)
        negative += tuple(frozen(row["rings"][0]) for row in data[1]["cascade"] if len(row["rings"]) == 1)
    menu = []
    for i in range(14):
        cold = i in (0, 1, 2, 3)
        want_negative = i % 3 != 1
        first = negative[(i // 3) % len(negative)] if want_negative else positive[i % 2]
        second = positive[2 + i % (len(positive) - 2)]
        outer, bridge, port, parts = graft(g, first, second, i % len(g.bases))
        offset = tuple((i + 2) * (71 + 37*j) * (-1)**j for j in range(len(g.zero)))
        # Held-out requests alternate a prescribed bridge and a free first
        # placement. The nominated port proposes a search direction only.
        fixed_bridge = cold or i % 2 == 0
        menu.append(dict(id=f"{name}-chambers-{i:02d}", split="train" if cold else "test",
                         rings=(translate(outer, offset),),
                         seed=(g.shift(bridge, offset),) if fixed_bridge else (),
                         port=None if fixed_bridge else translate(port, offset),
                         known_parts=tuple(translate(r, offset) for r in parts),
                         candidate_bridge=g.shift(bridge, offset),
                         expected_seeded="NEGATIVE" if want_negative else "POSITIVE"))
    return menu


def main():
    result = {name: create(name) for name in ("turtle", "penrose")}
    (ROOT / "input/chambers-v1.json").write_text(json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")
    for name, rows in result.items():
        print(name, len(rows), sum(bool(row["seed"]) for row in rows), flush=True)


if __name__ == "__main__":
    main()
