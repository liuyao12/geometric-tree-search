"""Verify recorded decisions and reject malformed chamber references."""
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from chamber_audit_v1 import Audit
from chamber_cases_v1 import geometry
from chamber_experiment_v1 import read_cases, write
from chambers_v1 import normalized, split_rings


def frozen(value):
    if isinstance(value, list):
        return tuple(map(frozen, value))
    if isinstance(value, dict):
        return {k: frozen(v) for k, v in value.items()}
    return value


def check_one(audit, row, answer):
    audit.result(row["rings"], row["seed"], answer)
    for event in answer["splits"]:
        assert event["path"][:len(row["seed"])] == row["seed"]
        audit.join(row["rings"], event)
    proposal = answer.get("proposal")
    if proposal:
        assert not row["seed"]
        boundary, _ = audit.state(row["rings"], ())
        tile, edge = proposal["tile"], proposal["edge"]
        assert edge in boundary and tile in audit.options(edge)
        if "other" in proposal:
            assert proposal["other"] != edge and proposal["other"] in boundary
            assert tile in audit.options(proposal["other"]) and proposal["donor"] != row["id"]
        assert audit.contained(row["rings"], tile)
        parts = split_rings(audit.g, audit.cut(boundary, tile))
        assert parts and any(index is not None for index in proposal["known"])
        for part, index in zip(parts, proposal["known"], strict=True):
            if index is not None:
                assert audit.chamber(index)["ring"] == normalized(part)[0]
        audit.counts["checked_port_proposals"] += 1


def rejects(audit, row, answer):
    try:
        audit.result(row["rings"], row["seed"], answer)
    except (AssertionError, KeyError, TypeError, ValueError):
        return
    raise AssertionError("Corrupt proof accepted")


def main():
    data = frozen(json.loads((ROOT / "data/chambers-v1.json").read_text()))
    ports = frozen(json.loads((ROOT / "data/chambers-port-v1.json").read_text()))
    cases = read_cases()
    results = {}
    for name, system in data["systems"].items():
        g = geometry(name)
        rows = {row["id"]: row for row in cases[name]}
        receipts = {}
        for mode, library in system["library"].items():
            audit = Audit(g, library)
            for index in range(len(library)):
                audit.chamber(index)
            for result in system["cases"]:
                check_one(audit, rows[result["id"]], result["arms"][mode])
            for result in system["unhinted"]:
                if mode in result:
                    check_one(audit, rows[result["id"]], result[mode])
            receipts[mode] = dict(audit.counts)
            if mode == "split":
                continue
            for result in system["cases"]:
                answer = deepcopy(result["arms"][mode])
                proof = answer.get("proof", {})
                if proof.get("kind") == "split":
                    proof["anchor"] = tuple(a + 17 for a in proof["anchor"])
                    rejects(audit, rows[result["id"]], answer)
                    receipts[mode]["bad_translation_rejected"] = True
                    break
                if mode == "direct" and proof.get("kind") == "branch" and proof["choices"]:
                    proof["choices"] = proof["choices"][:-1]
                    rejects(audit, rows[result["id"]], answer)
                    receipts[mode]["omitted_option_rejected"] = True
                    break
        assert receipts["direct"]["omitted_option_rejected"]
        assert receipts["reuse"]["bad_translation_rejected"]
        auto = ports["systems"][name]
        for arm, library in auto["library"].items():
            audit = Audit(g, library)
            for index in range(len(library)):
                audit.chamber(index)
            for result in auto["cases"]:
                check_one(audit, {**rows[result["id"]], "seed": ()}, result["arms"][arm])
            receipts["port_" + arm] = dict(audit.counts)
        results[name] = receipts
        print(name, receipts, flush=True)
    write("data/chambers-audit-v1.json", dict(status="CHECKED_CHAMBER_COVERS_AND_EXHAUSTION", systems=results))


if __name__ == "__main__":
    main()
