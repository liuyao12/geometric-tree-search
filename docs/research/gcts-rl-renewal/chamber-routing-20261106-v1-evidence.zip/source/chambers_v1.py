"""Split exact residual boundaries and reuse checked local covers or refutations."""
from collections import Counter, defaultdict
from functools import cmp_to_key, lru_cache
from itertools import combinations

from boundary_search_v1 import Inventory, Region, remove
from cluster_v1 import mat
from geometry_v1 import add, area, chain, check_rings, compact_corners, intersects, mul, pairs, rings_from_edges, sub
from model_v1 import rotate


@lru_cache(maxsize=10000)
def valid_cycle(g, ring):
    try:
        check_rings(g, (ring,))
    except AssertionError:
        return False
    return True


@lru_cache(maxsize=10000)
def projection_limits(g, ring, ray):
    key = cmp_to_key(lambda a, b: g.sign(sub(a, b)))
    values = [g.cross(ray, p) for p in ring]
    return min(values, key=key), max(values, key=key)


def separated(g, a, b):
    for axis in (g.unit, g.transverse):
        lo, hi = projection_limits(g, a, axis)
        other_lo, other_hi = projection_limits(g, b, axis)
        if g.sign(sub(other_lo, hi)) > 0 or g.sign(sub(lo, other_hi)) > 0:
            return True
    return False


def split_rings(g, edges):
    """Accept only disjoint positive simple cycles with no boundary contact."""
    rings = rings_from_edges(edges)
    if rings is None or len(rings) < 2:
        return None
    return tuple(rings) if disjoint_cycles(g, rings) else None


def disjoint_cycles(g, rings):
    axes = g.cross, g.sign, g.unit, g.transverse
    if not all(valid_cycle(g, normalized(ring)[0]) for ring in rings):
        return False
    for a, b in combinations(rings, 2):
        if separated(g, a, b):
            continue
        a, b = compact_corners(g, a), compact_corners(g, b)
        if g.wind(a, b[0], 1) != 0 or g.wind(b, a[0], 1) != 0:
            return False
        if any(intersects(p, q, r, s, *axes) for p, q in pairs(a) for r, s in pairs(b)):
            return False
    return True


def normalized(ring):
    i = ring.index(min(ring))
    anchor = ring[i]
    return tuple(sub(p, anchor) for p in (*ring[i:], *ring[:i])), anchor


def pose_point(g, point, turn):
    return mat(g.model.groups[turn], point) if g.kind == "turtle" else rotate(point, turn)


def pose_ring(g, ring, turn, offset):
    vertices = tuple(add(pose_point(g, p, turn), offset) for p in ring)
    if g.kind == "turtle":
        (a, b), (c, d) = g.model.groups[turn]
        if a*d - b*c < 0:
            return vertices[::-1]
    return vertices


@lru_cache(maxsize=12000)
def orbit_form(g, local):
    candidates = []
    for turn in g.turns:
        form, anchor = normalized(pose_ring(g, local, turn, g.zero))
        if g.kind == "turtle":
            inverse = next(i for i in g.turns if g.model.compose[i, turn] == 0)
        else:
            inverse = (-turn) % 10
        candidates.append((form, inverse, pose_point(g, anchor, inverse)))
    return min(candidates)


class Bound(Exception):
    pass


class Cursor:
    """Pause just before visiting the next search node."""
    def __init__(self, steps):
        self.steps = steps
        self.result = None
        self.advance_one()

    def advance_one(self):
        try:
            next(self.steps)
        except StopIteration as finished:
            self.result = finished.value

    def advance(self, count):
        for _ in range(count):
            if self.result is not None:
                break
            self.advance_one()
        return self.result


class Library:
    def __init__(self, poses=False):
        self.index = {}
        self.records = []
        self.receptors = defaultdict(dict)
        self.poses = poses

    def register(self, g, ring):
        local, anchor = normalized(ring)
        if not self.poses:
            return local, 0, anchor
        form, turn, shift = orbit_form(g, local)
        return form, turn, add(anchor, shift)

    def add(self, ring, result, case):
        index = len(self.records)
        self.records.append(dict(ring=ring, result=result, donor=case))
        self.index[ring] = index
        return index

    def learn_port(self, g, tile, boundary, case):
        """Record two separated exterior contacts of a separating tile."""
        matched = tuple(e for e in g.boundary(tile) if e in boundary)
        incoming = {b for _, b in matched}
        starts = tuple(e for e in matched if e[0] not in incoming)
        origin = min(g.poly(tile))
        local = g.shift(tile, mul(-1, origin))
        for first, second in combinations(starts, 2):
            local_edges = tuple(tuple(sub(p, origin) for p in edge) for edge in (first, second))
            for turn in g.turns:
                posed = g.turn(local, turn)
                contour = set(g.boundary(posed))
                transform = (lambda p: mat(g.model.groups[turn], p)) if g.kind == "turtle" else (
                    lambda p: rotate(p, turn))
                e, f = (tuple(map(transform, edge)) for edge in local_edges)
                e = e if e in contour else e[::-1]
                f = f if f in contour else f[::-1]
                assert e in contour and f in contour
                for (a, b), (c, d) in ((e, f), (f, e)):
                    rule = (sub(c, a), sub(d, a), g.shift(posed, mul(-1, a)))
                    self.receptors[sub(b, a)].setdefault(rule, case)


class Search:
    def __init__(self, geometry, library, *, mode="direct", limit=3000, inspect=4,
                 auto_port=False, case=""):
        assert mode in ("direct", "split", "reuse")
        self.g = geometry
        self.inventory = Inventory(geometry)
        self.library = library
        self.mode = mode
        self.limit = limit
        self.inspect = inspect
        self.case = case
        assert auto_port in (False, "scan", "receptor")
        self.auto_port = auto_port
        self.stats = Counter()
        self.splits = []
        self.proposal = None

    def solve(self, rings, seed=(), port=None):
        try:
            result = self.root(Region(self.g, rings), seed, port, split=self.mode != "direct")
        except Bound:
            result = dict(status="BOUNDED")
        return {**result, "counts": dict(self.stats), "splits": self.splits, "proposal": self.proposal}

    def root(self, region, seed, port, *, split):
        cursor = self.start(region, seed, port, split=split)
        result = cursor.advance(self.limit)
        if result is None:
            raise Bound
        return result

    def start(self, region, seed=(), port=None, *, split=True):
        return Cursor(self.root_iter(region, seed, port, split=split))

    def root_iter(self, region, seed, port, *, split):
        if region.counts is None:
            return dict(status="NEGATIVE", proof={"kind": "area"})
        edges, occupied, remaining = region.edges, frozenset(), region.counts
        for tile in seed:
            assert region.block(tile, occupied) is None
            edges = remove(edges, self.g.boundary(tile))
            occupied = region.extend(occupied, (tile,))
            remaining = sub(remaining, self.g.mass(tile))
        assert all(x >= 0 for x in remaining)
        preferred = None
        if self.auto_port and split and not seed and port is None and self.library.index:
            self.proposal = self.propose_receptor(region) if self.auto_port == "receptor" else self.propose_port(region)
            if self.proposal:
                port, preferred = self.proposal["edge"], self.proposal["tile"]
        return (yield from self.visit(region, edges, occupied, seed, remaining, port, split, preferred))

    def propose_port(self, region):
        """Propose a bridge that exposes an already known chamber."""
        touches = defaultdict(list)
        for edge in sorted(region.edges):
            for tile, in self.inventory.at(edge):
                touches[tile].append(edge)
        self.stats["portal_poses"] += len(touches)
        for tile, matched in sorted(touches.items(), key=lambda item: (-len(item[1]), item[0])):
            if len(matched) < 2:
                break
            incoming = {b for _, b in matched}
            if sum(a not in incoming for a, _ in matched) < 2:
                continue
            edge = min(matched, key=lambda e: (self.inventory.direction_count(e), e))
            proposal = self.confirm_port(region, edge, tile)
            if proposal:
                return proposal
        return None

    def propose_receptor(self, region):
        offers = {}
        for a, b in sorted(region.edges):
            for (c, d, tile), donor in self.library.receptors.get(sub(b, a), {}).items():
                self.stats["receptor_tests"] += 1
                other = add(c, a), add(d, a)
                if other in region.edges:
                    posed = self.g.shift(tile, a)
                    offers.setdefault(posed, ((a, b), other, donor))
        self.stats["portal_poses"] += len(offers)
        def boundary_matches(tile):
            return -sum(e in region.edges for e in self.g.boundary(tile)), tile

        for tile in sorted(offers, key=boundary_matches):
            edge, other, donor = offers[tile]
            proposal = self.confirm_port(region, edge, tile)
            if proposal:
                return {**proposal, "other": other, "donor": donor}
        return None

    def confirm_port(self, region, edge, tile):
        self.stats["portal_containment_checks"] += 1
        if region.exterior(tile) is not None or any(n < 0 for n in sub(region.counts, self.g.mass(tile))):
            return None
        self.stats["portal_split_checks"] += 1
        pieces = rings_from_edges(remove(region.edges, self.g.boundary(tile)))
        if pieces and len(pieces) > 1:
            sizes = {len(form) for form in self.library.index}
            known = tuple(self.library.index.get(self.library.register(self.g, r)[0]) if len(r) in sizes else None
                          for r in pieces)
            if any(index is not None for index in known) and disjoint_cycles(self.g, pieces):
                self.stats["portal_hits"] += 1
                return dict(edge=edge, tile=tile, known=known)
        return None

    def visit(self, region, edges, occupied, path, remaining, port, split, preferred=None):
        yield
        self.stats["nodes"] += 1
        if not edges:
            assert not any(remaining)
            return dict(status="POSITIVE", patch=path)
        if split:
            rings = split_rings(self.g, edges)
            if rings:
                out = yield from self.split(region, rings, edges, occupied, path, remaining)
                if out is not None:
                    return out
        ranked = sorted(edges, key=lambda e: (self.inventory.direction_count(e), e))
        if port is not None:
            assert port in edges
            ranked = [port]
        best = None
        for edge in ranked[:self.inspect]:
            options = []
            for tile, in self.inventory.at(edge):
                self.stats["tile_tests"] += 1
                guard = region.block(tile, occupied)
                left = sub(remaining, self.g.mass(tile))
                if guard:
                    outcome = "outside" if region.exterior(tile) else "conflict"
                else:
                    outcome = "mass" if any(x < 0 for x in left) else None
                options.append((tile, outcome, left))
            legal = sum(block is None for _, block, _ in options)
            if best is None or legal < best[0]:
                best = legal, edge, options
            if legal <= 1:
                break
        _, edge, options = best
        if preferred is not None:
            options.sort(key=lambda item: item[0] != preferred)
        choices = []
        for tile, block, left in options:
            if block is not None:
                choices.append((tile, block))
                continue
            boundary = self.g.boundary(tile)
            state = yield from self.visit(region, remove(edges, boundary), region.extend(occupied, (tile,)),
                                          (*path, tile), left, None, split)
            if state["status"] == "POSITIVE":
                return state
            choices.append((tile, state["proof"]))
        return dict(status="NEGATIVE", proof=dict(kind="branch", edge=edge, choices=choices))

    def split(self, region, rings, edges, occupied, path, remaining):
        assert sum(self.g.sign(area(r, self.g.cross)) for r in rings) == len(rings)
        self.stats["splits"] += 1
        self.stats["chambers"] += len(rings)
        if self.mode == "reuse" and len(path) == 1:
            self.library.learn_port(self.g, path[0], region.edges, self.case)
        ranked = sorted(rings, key=lambda ring: (len(ring), ring))
        resolved = []
        added = []
        for ring in ranked:
            form, turn, anchor = self.library.register(self.g, ring)
            index = self.library.index.get(form) if self.mode == "reuse" else None
            if index is None:
                self.stats["isolated_searches"] += 1
                result = yield from self.root_iter(Region(self.g, (form,)), (), None, split=False)
                index = self.library.add(form, result, self.case)
            else:
                self.stats["reuse_hits"] += 1
                if turn:
                    self.stats["nonidentity_reuse_hits"] += 1
                if self.library.records[index]["donor"] != self.case:
                    self.stats["cross_request_hits"] += 1
                result = self.library.records[index]["result"]
            resolved.append((index, turn, anchor))
            if result["status"] == "NEGATIVE":
                event = dict(path=path, parts=resolved, outcome="negative")
                self.splits.append(event)
                return dict(status="NEGATIVE", proof=dict(kind="split", record=index, turn=turn, anchor=anchor))
            added.extend(self.g.shift(self.g.turn(tile, turn), anchor) for tile in result["patch"])

        # Isolated covers omit exterior contacts. A failed join leaves the
        # original search tree available at this state.
        left = remaining
        for tile in added:
            self.stats["join_tests"] += 1
            if region.block(tile, occupied) is not None:
                self.stats["join_fallbacks"] += 1
                self.splits.append(dict(path=path, parts=resolved, outcome="fallback"))
                return None
            occupied = region.extend(occupied, (tile,))
            left = sub(left, self.g.mass(tile))
        assert not any(left) and chain(self.g, added) == edges
        self.splits.append(dict(path=path, parts=resolved, outcome="positive"))
        return dict(status="POSITIVE", patch=(*path, *added))
