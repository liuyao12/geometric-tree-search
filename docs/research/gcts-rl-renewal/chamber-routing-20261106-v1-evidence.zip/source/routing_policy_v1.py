"""Learn how to allocate a fixed node budget between direct and receptor search."""
from collections import Counter, defaultdict
from copy import deepcopy
from fractions import Fraction
import json
from pathlib import Path
from random import Random
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from boundary_search_v1 import Region
from chamber_check_v1 import frozen
from chamber_experiment_v1 import LIMIT, read_cases, write
from chambers_v1 import Library, Search
from geometry_v1 import sub

STATIC = ("plain", "receptor", "prefix2", "prefix8")
WEIGHTS = dict(nodes=4, tile_tests=2, join_tests=4, portal_containment_checks=5, portal_split_checks=20)


def cases():
    return frozen(json.loads((ROOT / "input/routing-cases-v1.json").read_text()))


def donors(g, poses=True):
    bank = Library(poses=poses)
    for row in read_cases()[g.kind]:
        if row["split"] == "train":
            Search(g, bank, mode="reuse", limit=LIMIT, case=row["id"]).solve(row["rings"], row["seed"])
    return bank


def work(counts):
    return (sum(counts.get(key, 0)*value for key, value in WEIGHTS.items())
            + counts.get("receptor_tests", 0)//20)


def reward(result):
    benefit = 12000 if result["status"] != "BOUNDED" else -12000
    return benefit - min(9000, work(result["counts"]))


def possible(state):
    return ("continue", "receptor", "probe") if state[1] == 2 else ("continue", "receptor")


def context(g, region, engine):
    reflex = sum(g.sign(g.cross(sub(b, a), sub(c, b))) < 0 for ring in region.rings
                 for i, b in enumerate(ring) for a, c in ((ring[i-1], ring[(i+1) % len(ring)]),))
    return (g.kind, engine.stats["nodes"], sum(region.counts) > 12, reflex > 5, bool(engine.stats["splits"]))


def fixed(arm, state):
    if arm == "prefix2":
        return "receptor"
    if arm == "prefix8":
        return "probe" if state[1] == 2 else "receptor"
    raise ValueError(arm)


def run(g, bank, row, arm, choose=None):
    """A continuation retains its exact DFS stack. Switching charges both paths."""
    region = Region(g, row["rings"])
    initial = Search(g, bank, mode="reuse", auto_port="receptor" if arm == "receptor" else False,
                     case=row["id"])
    cursor = initial.start(region)
    engines = [initial]
    decisions = []
    if arm in ("plain", "receptor"):
        outcome = cursor.advance(LIMIT)
    else:
        outcome = cursor.advance(2)
        while outcome is None:
            state = context(g, region, initial)
            action = choose(state) if arm == "learned" else fixed(arm, state)
            assert action in possible(state)
            decisions.append((state, action))
            left = LIMIT - initial.stats["nodes"]
            if action == "probe":
                outcome = cursor.advance(6)
            elif action == "continue":
                outcome = cursor.advance(left)
                break
            else:
                cursor.steps.close()
                second = Search(g, bank, mode="reuse", auto_port="receptor", case=row["id"])
                engines.append(second)
                outcome = second.start(region).advance(left)
                break
    counts = Counter()
    for engine in engines:
        counts.update(engine.stats)
    assert counts["nodes"] <= LIMIT
    return {**(outcome or dict(status="BOUNDED")), "counts": dict(counts), "decisions": decisions,
            "splits": [e for engine in engines for e in engine.splits],
            "proposals": [engine.proposal for engine in engines if engine.proposal]}


class Policy:
    def __init__(self):
        self.specific = defaultdict(Counter)
        self.backoff = defaultdict(Counter)

    @staticmethod
    def mean(bank, action):
        n = bank[action, "n"]
        return Fraction(bank[action, "sum"], n) if n else Fraction(-30000)

    def best(self, state):
        options = possible(state)
        local = self.specific[state]
        family = self.backoff[state[:2]]
        return max(options, key=lambda a: self.mean(local if local[a, "n"] >= 3 else family, a))

    def update(self, decisions, result):
        gain = reward(result)
        for state, action in reversed(decisions):
            for bank in (self.specific[state], self.backoff[state[:2]]):
                bank[action, "n"] += 1
                bank[action, "sum"] += gain
            gain = gain * 9 // 10

    def data(self):
        def encode(bank):
            return [dict(state=s, values={a: [c[a, "n"], c[a, "sum"]] for a in possible(s)})
                    for s, c in sorted(bank.items()) if c]
        return dict(specific=encode(self.specific), backoff=encode(self.backoff))

    @classmethod
    def load(cls, data):
        policy = cls()
        for name in ("specific", "backoff"):
            bank = getattr(policy, name)
            for row in data[name]:
                state = tuple(row["state"])
                for a, (n, total) in row["values"].items():
                    bank[state][a, "n"] = n
                    bank[state][a, "sum"] = total
        return policy


def train(g, base, rows):
    policy = Policy()
    rng = Random(914314 if g.kind == "turtle" else 327221)
    episodes = []
    for epoch in range(8):
        batch = list(rows)
        rng.shuffle(batch)
        for row in batch:
            def explore(state):
                return rng.choice(possible(state)) if rng.randrange(4) == 0 else policy.best(state)

            outcome = run(g, deepcopy(base), row, "learned", explore)
            policy.update(outcome["decisions"], outcome)
            episodes.append(dict(epoch=epoch, case=row["id"], decisions=outcome["decisions"],
                                 status=outcome["status"], work=work(outcome["counts"]),
                                 reward=reward(outcome)))
    static = {arm: sum(reward(run(g, deepcopy(base), row, arm)) for row in rows) for arm in STATIC}
    champion = max(STATIC, key=static.__getitem__)
    return dict(policy=policy.data(), episodes=episodes, static_reward=static, champion=champion,
                training_ids=[r["id"] for r in rows], weights=WEIGHTS)


def main():
    from chamber_cases_v1 import geometry
    data = {}
    for name, rows in cases().items():
        g = geometry(name)
        data[name] = train(g, donors(g), [row for row in rows if row["partition"] == "train"])
        print(name, data[name]["champion"], data[name]["static_reward"], flush=True)
    write("data/routing-policy-v1.json", dict(status="FROZEN_TRAINED_ROUTING", systems=data))


if __name__ == "__main__":
    main()
