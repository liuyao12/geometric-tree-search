"""Author exact donor outlines and held-out finite boundary queries."""
from itertools import combinations
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))

from boundary_search_v1 import Inventory, Region
from geometry_v1 import (Penrose, Turtle, add, area, chain, check_rings,
                         mul, pairs, rings_from_edges, sub)
import model_v1 as penrose

def frozen(value):
    return tuple(map(frozen,value)) if isinstance(value,list) else value


def load(name):
    return json.loads((ROOT/name).read_text())


def patch_ring(g,patch):
    cycles=rings_from_edges(chain(g,patch))
    if cycles is None:
        return None
    cycles.sort(key=lambda r:-g.sign(area(r,g.cross)))
    if sum(g.sign(area(r,g.cross))>0 for r in cycles)!=1:
        return None
    try:
        check_rings(g,cycles)
    except AssertionError:
        return None
    return tuple(cycles)


def neighbors(g,patch,n):
    first=min(patch)
    selected=[first]
    todo=set(patch)-{first}
    while len(selected)<n:
        boundary=chain(g,selected)
        for t in sorted(todo):
            if any((b,a) in boundary for a,b in g.boundary(t)):
                if patch_ring(g,(*selected,t)) is not None:
                    selected.append(t)
                    todo.remove(t)
                    break
        else:
            raise ValueError("No further connected tile")
    return tuple(selected)


def rhomb_grid(cols,rows,width=2,omit=()):
    u,v=penrose.DIRECTIONS[0],penrose.DIRECTIONS[width]
    return tuple(penrose.rhomb(add(mul(i,u),mul(j,v)),0,width)
                 for i in range(cols) for j in range(rows) if (i,j) not in omit)


def zonogon(g):
    rays=tuple(penrose.DIRECTIONS[k] for k in (0,1,3))
    point=g.zero
    vertices=[]
    for ray in (*rays,*(mul(-1,v) for v in rays)):
        vertices.append(point)
        point=add(point,ray)
    assert point==g.zero
    return (tuple(vertices),)


def relocate(g,rings,delta):
    return tuple(tuple(add(p,delta) for p in r) for r in rings)


def root_failure(g,inv,ring):
    r=Region(g,ring)
    if r.counts is None:
        return None
    roots=sorted(r.edges,key=lambda e:(inv.direction_count(e),e))
    for edge in roots:
        options=inv.at(edge)
        if all(r.exterior(t) is not None for (t,) in options):
            return edge
    return None


def perturb(g,good,inv):
    """Find a unit-direction, equal-area outline with an empty edge receptor."""
    base=good[0]
    edits=[]
    for i in range(1,len(base)-1):
        a,b,c=base[i-1:i+2]
        if not g.sign(g.cross(sub(b,a),sub(c,b))):
            continue
        d=sub(add(a,c),b)
        if d in base:
            continue
        change=sub(add(g.cross(a,d),g.cross(d,c)),add(g.cross(a,b),g.cross(b,c)))
        edits.append((i,d,change))
    for (i,p,u),(j,q,v) in combinations(edits,2):
        if j-i<2 or p==q or add(u,v)!=(0,)*len(u):
            continue
        moved=list(base)
        moved[i],moved[j]=p,q
        try:
            rejected=root_failure(g,inv,(tuple(moved),))
        except (ValueError,AssertionError):
            continue
        if rejected:
            return (tuple(moved),),rejected
    raise AssertionError(f"No same-area negative donor for {g.kind}")


def fuse(a,b):
    result=set(a)
    for e in b:
        if e[::-1] in result:
            result.remove(e[::-1])
        elif e not in result:
            result.add(e)
        else:
            return None
    return frozenset(result)


def add_ear(g,inv,good,bad,failed_edge):
    """Preserve the donor obstruction while changing a distant part of the ring."""
    g_region,b_region=(Region(g,r) for r in (good,bad))
    common=g_region.edges&b_region.edges
    original_guards=tuple(b_region.exterior(t) for t, in inv.at(failed_edge))
    assert original_guards and all(original_guards)
    for e in sorted(common,reverse=True):
        for t, in inv.at(e[::-1]):
            candidate=chain(g,(t,))
            if failed_edge in candidate or failed_edge[::-1] in candidate:
                continue
            rows=[]
            for original in (g_region,b_region):
                merged=fuse(original.edges,candidate)
                cycles=rings_from_edges(merged) if merged is not None else None
                if cycles is None or len(cycles)!=1:
                    break
                rings=tuple(cycles)
                try:
                    region=Region(g,rings)
                except (ValueError,AssertionError):
                    break
                expected=add(original.counts,g.mass(t))
                if region.counts!=expected:
                    break
                rows.append(rings)
            if len(rows)==2:
                updated=Region(g,rows[1])
                if failed_edge in updated.edges and all(updated.blocked(w,frozenset())
                                                         for w in original_guards):
                    return tuple(rows),t
    raise AssertionError("No distant boundary change")


def penrose_pair(g,inv):
    # A balanced unit-step outline selected for an exposed-edge obstruction.
    bad=(((0,0,0,1),(1,0,0,1),(1,0,0,0),(1,0,-1,0),
          (1,0,-1,-1),(0,0,-1,-1),(0,0,0,-1),(0,0,0,0)),)
    region=Region(g,bad)
    edge=root_failure(g,inv,bad)
    assert edge and region.counts==(1,1)
    core=sorted({t for e in region.edges for t, in inv.at(e) if region.exterior(t) is None})
    for t in core:
        for e in g.boundary(t):
            for u, in inv.at(e[::-1]):
                if add(g.mass(t),g.mass(u))==region.counts and penrose.legal_contact(t,u):
                    good=patch_ring(g,(t,u))
                    if good is not None:
                        try:
                            pair,ear=add_ear(g,inv,good,bad,edge)
                        except AssertionError:
                            continue
                        return bad,edge,pair,ear
    raise AssertionError("No compatible Penrose boundary pair")


def create():
    turtle=Turtle(load("input/exact-point-model-v1.json"))
    p=Penrose()
    geometries={"turtle":turtle,"penrose":p}
    data={row["id"]:frozen(row["patch"]) for row in load("input/growth-v1.json")["levels"]}
    t1,p1,t2=(data[k] for k in ("T1","P1","T2"))
    turtle_pairs=[neighbors(turtle,t1,2),neighbors(turtle,p1,3)]
    penrose_pairs=[rhomb_grid(2,1),rhomb_grid(2,1,1),rhomb_grid(2,2,2,((1,1),))]
    learned={
        "turtle":[patch_ring(turtle,patch) for patch in (*turtle_pairs,t1)],
        "penrose":[patch_ring(p,patch) for patch in penrose_pairs],
    }
    by_kind={}
    for name,g in geometries.items():
        if name=="turtle":
            hole=next(t for t in p1 if patch_ring(g,tuple(x for x in p1 if x!=t)) is not None
                      and len(patch_ring(g,tuple(x for x in p1 if x!=t)))==2)
            fixed=[
                ("parallelogram",patch_ring(g,p1)),
                ("hole",patch_ring(g,tuple(x for x in p1 if x!=hole))),
                ("crop",patch_ring(g,neighbors(g,t2,12))),
                ("large",patch_ring(g,t2)),
            ]
            motif=patch_ring(g,t1)
            delta=(11,-8)
        else:
            fixed=[
                ("concave",patch_ring(g,rhomb_grid(4,3,2,((3,2),(2,2),(3,1))))),
                ("hole",patch_ring(g,rhomb_grid(4,4,2,((1,1),)))),
                ("mixed-zonogon",zonogon(g)),
                ("large",patch_ring(g,rhomb_grid(8,7,2,((2,2),(2,3),(3,2),(3,3),(7,6),(6,6),(7,5))))),
            ]
            delta=(6,-3,0,2)
        inv=Inventory(g)
        if name=="turtle":
            negative,edge=perturb(g,motif,inv)
            (good,bad),ear=add_ear(g,inv,motif,negative,edge)
        else:
            negative,edge,(good,bad),ear=penrose_pair(g,inv)
        assert all(r is not None for _,r in fixed)
        family=[("moved-negative",relocate(g,bad,delta)),("moved-positive",relocate(g,good,delta))]
        by_kind[name]=dict(training=learned[name],fixed=fixed,donor=negative,
                          donor_edge=edge,movable=family,translated_anchor=delta,added_tile=g.shift(ear,delta))
    return geometries,by_kind


if __name__=="__main__":
    _,cases=create()
    (ROOT/"input/cases-v1.json").write_text(json.dumps(cases,sort_keys=True,separators=(",",":"))+"\n")
    for name,d in cases.items():
        print(name,[(k,len(v),len(v[0])) for k,v in d["fixed"]],d["donor_edge"])
