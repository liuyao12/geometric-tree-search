"""Verify route decisions and all transported chamber evidence independently of search."""
from bisect import bisect_right
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from chamber_audit_v1 import Audit
from chamber_cases_v1 import edges, geometry
from chamber_check_v1 import frozen
from chamber_experiment_v1 import LIMIT, write
from chambers_v1 import Library, pose_ring, split_rings
from geometry_v1 import add, area, check_rings, dot_between, intersects, lattice_sites, mul, pairs, sub
from routing_experiment_v1 import load_policy
from routing_policy_v1 import Policy, cases, fixed, work


def proposals(audit, register, rings, offers):
    boundary, _ = audit.state(rings, ())
    for offer in offers:
        tile, edge = offer["tile"], offer["edge"]
        assert edge in boundary and tile in audit.options(edge)
        other = offer["other"]
        assert other != edge and other in boundary and tile in audit.options(other)
        assert audit.contained(rings, tile)
        split = split_rings(audit.g, audit.cut(boundary, tile))
        assert split and any(i is not None for i in offer["known"])
        for ring, index in zip(split, offer["known"], strict=True):
            if index is not None:
                record = audit.chamber(index)
                form, turn, anchor = register.register(audit.g, ring)
                assert form == record["ring"]
                assert edges(audit.g, pose_ring(audit.g, form, turn, anchor)) == edges(audit.g, ring)
        audit.counts["checked_proposals"] += 1


def split_nodes(proof):
    if proof["kind"] == "split":
        yield proof
    elif proof["kind"] == "branch":
        for _, choice in proof["choices"]:
            if isinstance(choice, dict):
                yield from split_nodes(choice)


def rejects_bad_turn(audit, rings, original):
    answer = deepcopy(original)
    for node in split_nodes(answer.get("proof", {"kind": "area"})):
        turn = node["turn"]
        for other in audit.g.turns:
            if turn == other:
                continue
            node["turn"] = other
            try:
                audit.result(rings, (), answer)
            except AssertionError:
                return True
            node["turn"] = turn
    return False


def atomized_validation(g, rings):
    """Reference validator using every edge of the original polygon."""
    axes = g.cross, g.sign, g.unit, g.transverse
    for i, ring in enumerate(rings):
        assert len(ring) >= 3 and len(ring) == len(set(ring))
        assert g.sign(area(ring, g.cross)) == (1 if not i else -1)
        segments = tuple(pairs(ring))
        for (j, (a, b)), (k, (c, d)) in combinations(enumerate(segments), 2):
            if k == j + 1 or j == 0 and k == len(segments) - 1:
                u, v = sub(b, a), sub(d, c)
                assert g.sign(g.cross(u, v)) or not dot_between(u, v, *axes)
            else:
                assert not intersects(a, b, c, d, *axes)
        if i:
            assert g.wind(rings[0], ring[0], 1) == 1
        for j, other in enumerate(rings[:i]):
            assert all(not intersects(a, b, c, d, *axes)
                       for a, b in segments for c, d in pairs(other))
            if j:
                assert g.wind(other, ring[0], 1) == g.wind(ring, other[0], 1) == 0


def point_scan(g, rings):
    """Reference enumeration tests each sampling site in the bounding box."""
    scale = g.model.scale
    x, y = zip(*rings[0])
    sides = [(mul(scale, a), mul(scale, b)) for r in rings for a, b in pairs(r)]
    residues = {}
    for u, v in g.model.residues:
        residues.setdefault(v, []).append(u)
    out = set()
    for j in range(min(y), max(y)):
        for v, row in residues.items():
            height = scale*j + v
            crossed = Counter()
            for (a,b), (c,d) in sides:
                if min(b,d) <= height < max(b,d):
                    hit = Fraction(a*(d-b) + (height-b)*(c-a), d-b)
                    crossed[hit] += 1 if d > b else -1
            points = sorted(crossed)
            suffix = [0]*(len(points)+1)
            for k in reversed(range(len(points))):
                suffix[k] = suffix[k+1] + crossed[points[k]]
            for i in range(min(x),max(x)):
                for u in row:
                    point = scale*i + u
                    k = bisect_right(points,point)
                    assert not k or points[k-1] != point
                    if suffix[k]:
                        assert suffix[k] == 1
                        out.add((point,height))
    return frozenset(out)


def geometry_controls(g, rows):
    def accepted(test, rings):
        try:
            test(g, rings)
            return True
        except AssertionError:
            return False

    fixtures = [row["rings"] for row in rows]
    a, b = mul(4, g.unit), mul(3, g.transverse)
    valid = (g.zero, g.unit, a, add(a, b), b)
    reversed_run = (g.zero, mul(3, g.unit), mul(2, g.unit), a, add(a, b), b)
    bow = (g.zero, mul(2, g.transverse), a, add(a, b))
    fixtures.extend(((valid,), (reversed_run,), (bow,), (valid + (g.unit,),)))
    for rings in fixtures:
        assert accepted(check_rings, rings) == accepted(atomized_validation, rings)
    assert accepted(check_rings, (valid,))
    assert all(not accepted(check_rings, shape) for shape in fixtures[-3:])
    orbit_checks = 0
    library = Library(poses=True)
    for row in rows:
        ring = row["rings"][0]
        form, _, _ = library.register(g, ring)
        for turn in g.turns:
            moved = pose_ring(g, ring, turn, mul(17, g.transverse))
            expected, inverse, offset = library.register(g, moved)
            assert expected == form and edges(g, pose_ring(g, form, inverse, offset)) == edges(g, moved)
            orbit_checks += 1
    site_checks = 0
    if g.kind == "turtle":
        for row in rows:
            assert lattice_sites(g, row["rings"]) == point_scan(g, row["rings"])
            site_checks += 1
    return dict(compaction_reference_checks=len(fixtures), orbit_roundtrips=orbit_checks, site_checks=site_checks)


def main():
    cohort = {name: {r["id"]: r for r in rows} for name, rows in cases().items()}
    run = frozen(json.loads((ROOT / "data/routing-experiment-v1.json").read_text()))
    training = load_policy()
    output = {}
    for name, family in run["systems"].items():
        g = geometry(name)
        policy = Policy.load(training[name]["policy"])
        audits = {"pose": Audit(g, family["library"]), "translation": Audit(g, family["translation_library"])}
        base = {k: audit.library for k, audit in audits.items()}
        base_checked = {}
        for key, audit in audits.items():
            for i in range(len(audit.library)):
                audit.chamber(i)
            base_checked[key] = audit.checked.copy()
        checks = Counter()
        for row in family["cases"]:
            fixture = cohort[name][row["id"]]
            learned, plain = (row["arms"][arm] for arm in ("learned", "plain"))
            if not any(action == "receptor" for _, action in learned["decisions"]):
                keys = ("status", "proof", "patch", "counts", "splits", "records")
                assert all(learned.get(k) == plain.get(k) for k in keys)
                checks["identical_resumptions"] += 1
            for arm, answer in row["arms"].items():
                key = "translation" if arm == "receptor-translate" else "pose"
                audit = audits[key]
                audit.library = (*base[key], *answer["records"])
                audit.checked = base_checked[key].copy()
                for index in range(len(base[key]), len(audit.library)):
                    audit.chamber(index)
                assert answer["counts"]["nodes"] <= LIMIT and work(answer["counts"]) == answer["work"]
                for state, action in answer["decisions"]:
                    assert action == (policy.best(state) if arm == "learned" else fixed(arm, state))
                    checks["checked_routing_actions"] += 1
                audit.result(fixture["rings"], (), answer)
                for event in answer["splits"]:
                    audit.join(fixture["rings"], event)
                proposals(audit, Library(poses=key == "pose"), fixture["rings"], answer["proposals"])
                if not checks["rejected_wrong_turn"] and key == "pose":
                    recorded = audit.counts.copy()
                    checks["rejected_wrong_turn"] += rejects_bad_turn(audit, fixture["rings"], answer)
                    audit.counts = recorded
        assert checks["rejected_wrong_turn"] == 1, name
        checks.update(geometry_controls(g, tuple(cohort[name].values())))
        output[name] = dict(checks=checks, geometry={k: a.counts for k, a in audits.items()})
        print(name, output[name], flush=True)
    write("data/routing-audit-v1.json", dict(status="CHECKED_ROUTED_COVERS_AND_REFUTATIONS", systems=output))


if __name__ == "__main__":
    main()
