"""Run the frozen policy and matched registration and routing controls."""
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from chamber_cases_v1 import geometry
from chamber_experiment_v1 import write
from routing_policy_v1 import Policy, STATIC, cases, donors, run, work

ARMS = (*STATIC, "learned", "receptor-translate")


def load_policy():
    return json.loads((ROOT / "data/routing-policy-v1.json").read_text())["systems"]


def compare(g, base, row, arm, policy):
    bank = deepcopy(base)
    answer = run(g, bank, row, "receptor" if arm == "receptor-translate" else arm, policy.best)
    assert len(bank.records) >= len(base.records)
    return {**answer, "work": work(answer["counts"]), "records": bank.records[len(base.records):]}


def main():
    trained = load_policy()
    output = {}
    for name, rows in cases().items():
        g = geometry(name)
        base = donors(g)
        translation = donors(g, poses=False)
        report = []
        policy = Policy.load(trained[name]["policy"])
        for row in rows:
            if row["partition"] != "test":
                continue
            assert row["id"] not in trained[name]["training_ids"]
            arms = {a: compare(g, translation if a == "receptor-translate" else base, row, a, policy)
                    for a in ARMS}
            decisions = {a["status"] for a in arms.values()} - {"BOUNDED"}
            assert len(decisions) <= 1, (row["id"], decisions)
            report.append(dict(id=row["id"], kind=row["kind"], arms=arms))
            print(row["id"], [(a, r["status"], r["counts"]["nodes"], r["work"]) for a, r in arms.items()],
                  flush=True)
        output[name] = dict(cases=report, library=base.records, translation_library=translation.records)
    write("data/routing-experiment-v1.json", dict(status="FROZEN_POLICY_RECEIVER_COMPARISON", systems=output))


if __name__ == "__main__":
    main()
