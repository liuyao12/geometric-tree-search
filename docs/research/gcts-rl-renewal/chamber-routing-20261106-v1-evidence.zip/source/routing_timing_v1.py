"""Measure the same fixed-budget runs with training and cloning outside the clock."""
from copy import deepcopy
import json
from pathlib import Path
import sys
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from chamber_cases_v1 import geometry
from chamber_experiment_v1 import write
from model_v1 import clear_geometry
from routing_experiment_v1 import ARMS, load_policy
from routing_policy_v1 import Policy, cases, donors, run, work

REPEATS = 5


def main():
    training = load_policy()
    experiment = json.loads((ROOT / "data/routing-experiment-v1.json").read_text())["systems"]
    results = {}
    for name, requests in cases().items():
        test = [row for row in requests if row["partition"] == "test"]
        table = {arm: {"test_ns": [], "donor_ns": []} for arm in ARMS}
        for repeat in range(REPEATS):
            for arm in ARMS[repeat:] + ARMS[:repeat]:
                clear_geometry()
                g = geometry(name)
                began = perf_counter_ns()
                bank = donors(g, poses=arm != "receptor-translate")
                table[arm]["donor_ns"].append(perf_counter_ns() - began)
                copies = [deepcopy(bank) for _ in test]
                model = Policy.load(training[name]["policy"])
                began = perf_counter_ns()
                outcomes = [run(g, memory, row, "receptor" if arm == "receptor-translate" else arm, model.best)
                            for memory, row in zip(copies, test, strict=True)]
                table[arm]["test_ns"].append(perf_counter_ns() - began)
                expected = [row["arms"][arm] for row in experiment[name]["cases"]]
                signature = [(o["status"], o["counts"]["nodes"], work(o["counts"])) for o in outcomes]
                assert signature == [(o["status"], o["counts"]["nodes"], o["work"]) for o in expected]
        results[name] = table
    write("data/routing-timing-v1.json", dict(repeats=REPEATS, systems=results))


if __name__ == "__main__":
    main()
