"""Run matched atlas-free searches with and without chamber transfer."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cases_v1 import frozen
from chamber_cases_v1 import geometry
from chambers_v1 import Library, Search

LIMIT = 250
MODES = ("direct", "split", "reuse")


def write(path, value):
    (ROOT / path).write_text(json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n")


def read_cases():
    return {name: [{k: frozen(v) for k, v in row.items()} for row in rows] for name, rows in
            json.loads((ROOT / "input/chambers-v1.json").read_text()).items()}


def solve(g, bank, row, mode, port=True):
    search = Search(g, bank, mode=mode, limit=LIMIT, case=row["id"])
    return search.solve(row["rings"], row["seed"], row["port"] if port else None)


def main():
    results = {}
    for name, cases in read_cases().items():
        g = geometry(name)
        banks = {m: Library() for m in MODES}
        table = []
        for row in cases:
            answers = {mode: solve(g, banks[mode], row, mode) for mode in MODES}
            decisions = {r["status"] for r in answers.values()} - {"BOUNDED"}
            assert len(decisions) <= 1, (row["id"], decisions)
            if row["seed"] or row["expected_seeded"] == "POSITIVE":
                assert decisions <= {row["expected_seeded"]}
            table.append(dict(id=row["id"], arms=answers))
            print(row["id"], [(m, a["status"], a["counts"].get("nodes", 0),
                              a["counts"].get("cross_request_hits", 0)) for m, a in answers.items()], flush=True)
        unhinted = []
        for row in [r for r in cases if not r["seed"]][:4]:
            direct = solve(g, banks["direct"], row, "direct", port=False)
            reuse = solve(g, banks["reuse"], row, "reuse", port=False)
            expected = next(item for item in table if item["id"] == row["id"])["arms"]
            decisions = {r["status"] for r in (*expected.values(), direct, reuse)} - {"BOUNDED"}
            assert len(decisions) <= 1
            unhinted.append(dict(id=row["id"], direct=direct, reuse=reuse))
        results[name] = dict(cases=table, library={m: banks[m].records for m in MODES}, unhinted=unhinted)
    write("data/chambers-v1.json", dict(status="MATCHED_ATLAS_FREE_CHAMBERS", limit=LIMIT, systems=results))


if __name__ == "__main__":
    main()
