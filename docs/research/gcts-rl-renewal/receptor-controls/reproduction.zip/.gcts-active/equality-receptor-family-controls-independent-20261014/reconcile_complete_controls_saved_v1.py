"""Whole saved JSON/hash consistency only; no project/semantic/Graph calls."""
import ast
from collections import Counter
import gzip
import hashlib
import json
import time
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/equality-receptor-family-controls-independent-20261014'
ACTUAL=ROOT/'.gcts-active/equality-receptor-family-controls-progress-v2-20261014'


def pin(path,spelling=None):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    h=hashlib.sha256();length=0;before=path.stat()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(65536),b''):h.update(block);length+=len(block)
    after=path.stat()
    if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
        raise ValueError('raw file changed during metadata read')
    return dict(path=spelling if spelling is not None else str(path),sha256=h.hexdigest(),bytes=length)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def save(name,value):
    path=HERE/name
    with path.open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')
    return pin(path)


def key(value):
    if not (type(value) is list and len(value)==3 and type(value[0]) is int and type(value[1]) is int
            and 0<=value[1]<24 and type(value[2]) is list and all(type(ref) is int and 0<=ref<value[1] for ref in value[2])):
        raise ValueError('invalid saved strict-prior key')
    return value[0],value[1],tuple(value[2])


def saved_integer_points(keys,fixed,recorded_values):
    """Field consistency from recorded codes only; no catalogue or point oracle.

    Does not derive or license any formula code. Verifies saved full-key row
    multiplicity, ordered offsets and mark reference counts by plain integers.
    """
    totals=[0]*24;values={};counts={};seen=set();occupied=set()
    def assign(x,y,v):
        if not all(type(a) is int for a in (x,y,v)):raise ValueError('noninteger saved point')
        p=(x,y)
        if p in values and values[p]!=v:raise ValueError('conflicting saved mark')
        values[p]=v;counts[p]=counts.get(p,0)+1
    for x,y,v in fixed:assign(x,y,v)
    for supplied in keys:
        k=key(supplied)
        if k in seen:continue
        seen.add(k);_,row,refs=k
        if row in occupied:raise ValueError('two distinct positive supports in saved row')
        occupied.add(row);totals[row]=1
        local={(1,row):recorded_values[1,row]}
        for port,ref in enumerate(refs):
            v=recorded_values[1,ref]
            if (1,ref) in local and local[1,ref]!=v:raise ValueError('aliased saved input disagreement')
            local[1,ref]=v;local[2+port,row]=ref-row
        for (x,y),v in local.items():assign(x,y,v)
    return dict(totals=totals,t=[[0,r,v] for r,v in enumerate(totals) if v],
                m=[[*p,v] for p,v in sorted(values.items())],marks=[[*p,v,counts[p]] for p,v in sorted(values.items())])


def main():
    began=time.perf_counter();checks=[];mismatches=[];refs=[];roots=[]
    def check(value,label):
        checks.append(dict(name=label,passed=bool(value)))
        if not value:mismatches.append(label)
    def scan(value):
        if isinstance(value,dict):
            if set(value)=={'path','sha256','bytes'}:
                refs.append(value);check(pin(value['path'],value['path'])==value,'whole raw pin '+value['path'])
            for x in value.values():scan(x)
        elif isinstance(value,list):
            for x in value:scan(x)
    def document(path):
        path=Path(path);path=path if path.is_absolute() else ROOT/path
        raw=path.read_bytes();roots.append(dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
        def unique(pairs):
            value={}
            for name,item in pairs:
                if name in value:raise ValueError('duplicate JSON key')
                value[name]=item
            return value
        value=json.loads(raw,object_pairs_hook=unique,parse_constant=lambda token:(_ for _ in ()).throw(ValueError(token)))
        scan(value);return value
    leaf=document(ACTUAL/'worker-plan-v1.json');owned=document(ACTUAL/'replay-plan-v1.json')
    manifest=document(ACTUAL/'ROOT-controls-input-manifest-v1.json')
    worker=document(ACTUAL/'worker-output-v1/actual-family-controls-result-v1.json')
    evidence=document(worker['evidence']['path']);controls=document(worker['controls']['path'])
    owner=document(ACTUAL/'replay-owner-v1/ROOT-terminal-v1.json')
    provisional=document(ACTUAL/'replay-owner-v1/provisional-terminal-v1.json')
    post=document(ACTUAL/'replay-owner-v1/post-write-observation-v1.json')
    tool=document(ACTUAL/'replay-actual-tool-observations-v1.json');decision=document(ACTUAL/'replay-ROOT-final-decision-v1.json')
    launch=document(ACTUAL/'replay-owner-v1/launch-v1.json')
    root_review=document(leaf['reviews']['ROOT']['path']);peer_review=document(leaf['reviews']['independent']['path'])
    failed=document(HERE/'family-controls-failed-actual-saved-findings-v1.json')
    library=document(leaf['inputs']['candidate_library']['path'])
    seal_path=ACTUAL/'ROOT-actual-family-controls-disposition-v1.json'
    seal=document(seal_path) if seal_path.exists() else None
    limits=dict(caller_seconds=90,control_seconds=20,peak_bytes=536870912,whole_seconds=60)
    check(leaf['limits']==owned['limits']==owner.get('limits',limits)==post['limits']==decision['limits']==limits,'all original owned and inner caps unchanged')
    check(len(leaf)==11 and len(owned)==10 and len(leaf['sources'])==20,'strict eleven leaf/ten owner/twenty roles')
    check(len(leaf['closure'])==183 and len(owned['closure'])==184,'whole current raw closure sizes183/184')
    check(leaf['sources']==evidence['sources']==root_review['sources']==peer_review['sources'],'source ledger current exact twenty raw-role map')
    check(peer_review['source_review_passed'] is True and peer_review['source_only'] is True
          and peer_review['scientific_calls']==0 and peer_review['author_identity']=='/root/hilbert_advice_controls'
          and peer_review['reviewer_identity']=='/root/arithmetic_induction','actual current Source review genuine distinct roles')
    check(worker['worker_plan']==evidence['worker_plan']==pin(ACTUAL/'worker-plan-v1.json')
          and worker['owner_plan']==evidence['owner_plan']==pin(ACTUAL/'replay-plan-v1.json'),'worker/evidence literal once-only actual plans')
    check(worker['controls']==evidence['controls'] and worker['stage_completed'] is True
          and controls['completed'] is True,'whole completed saved controls and evidence authenticated')
    check(evidence['inputs']==leaf['inputs'],'all actual direct extraction/control inputs retained')
    check(owned['argv']==launch['argv'] and len(owned['argv'])==6
          and owned['argv'][0]==leaf['runtime']['binary']['path'] and owned['argv'][1]=='-B'
          and owned['argv'][2]==leaf['sources']['worker']['path'] and owned['argv'][3]=='ROOT-real-I2-Incident-family-controls'
          and owned['argv'][4]==str(ACTUAL/'worker-plan-v1.json') and owned['argv'][5]==str(ACTUAL/'replay-plan-v1.json'),
          'same command, runtime, selected successor and actual plans, no restart')
    check(leaf['scope']==owned['scope']=='actual-family-ground-domain-control-no-search-no-admission'
          and leaf['ROOT_owned_once_only'] is True,'controls-only experiment scope retained')
    check(manifest['ROOT_controls_authorized'] is True and manifest['scientific_episode_activation'] is False,
          'explicit Root grant limited to controls, not scientific receiver')
    check(manifest['library']==leaf['inputs']['candidate_library'] and manifest['audit']==leaf['inputs']['independent_audit']
          and manifest['extraction_disposition']==leaf['inputs']['ROOT_extraction_disposition'],'original candidate/audit/extraction seal unchanged')
    check(controls['source_control_request_count']==27 and controls['actual_check_count']==106
          and controls['actual_check_count']==sum(len(c['full_controls']['tests']) for c in controls['case_controls'])
          and controls['request_count_is_not_pass_count'] is True,'actual106 ordered checks, not27request definitions')
    cases=['fresh-i2-CD-vw-direct','fresh-i2-CD-vw-incidence-transport']
    check(controls['all_case_ids']==[c['instance_id'] for c in controls['case_controls']]==[r['instance_id'] for r in manifest['recipients']]==cases,
          'both complete current recipients in frozen sequential order')
    check(controls['all_actual_bindings']==evidence['actual_control_bindings'],'full case graph/source bindings identical in both outputs')
    allowed_ledger={canonical(p) for p in leaf['sources'].values()}
    ledger=evidence['exact_executed_project_source_ledger']
    check(len(ledger)==14 and len({p['path'] for p in ledger})==14 and all(canonical(p) in allowed_ledger for p in ledger),
          'fourteen actually loaded source roots including worker, raw allowlist not arbitrary closure')
    closure={p['path']:p for p in leaf['closure']}
    check(all(closure.get(p['path'])==p for p in evidence['named_consumed_metadata_pins'])
          and len(evidence['named_consumed_metadata_pins'])==147,'entire named actual147 metadata reads in current raw closure')
    observed_cases=[];all_list_entries=0;stored_instances=0;returned_proposals=0
    for c,recipient,binding in zip(controls['case_controls'],manifest['recipients'],controls['all_actual_bindings']):
        label=c['instance_id'];f=c['full_controls'];q=document(recipient['qualification']['path'])
        auth=document(recipient['controls_admission']['path']);header=document(q['catalog']['path'])
        registry=recipient['family_registry_binding'];inventory=recipient['expected_inventory_binding']
        check(c['qualification']==recipient['qualification'] and c['controls_admission']==recipient['controls_admission']
              and c['family_registry_binding']==registry,'whole current q/admission/registry '+label)
        check(len(q)==11 and q['instance_id']==header['instance_id']==label
              and q['declaration_profile']=='hilbert-fresh-guarded-I2-cohort-static-v1','exact accepted static context and eleven-field q '+label)
        check(auth['scientific_episode_activation'] is False and auth['controls_scope']=='real-ground-instance-and-domain-controls-only'
              and auth['ROOT_library_admitted'] is False and auth['schema_universally_validated'] is False
              and auth['implementation']==leaf['sources']['family_advice'] and auth['recipient_qualification']==recipient['qualification'],
              'controls-only source-bound receiver authorization '+label)
        preimage={k:v for k,v in registry.items() if k not in ('advice_registry_epoch','library_admission')}
        check(digest(preimage)==registry['advice_registry_epoch']==auth['registry_preimage_sha256'],'complete acyclic registry digest '+label)
        check(binding['complete_inventory_binding']==inventory and inventory['registered_whole_descriptor_count']==0
              and inventory['qualified_dimensions']==header['dimensions'] and header['bodies']==header['complete_cluster_inventory']==[],
              'empty complete body inventory and full24 catalogue unchanged '+label)
        check(binding['consumer_source_binding_sha256']==digest(q['expected_consumer_source_binding'])
              and len(q['expected_consumer_source_binding']['source_records'])==7,'current seven-role full consumer binding '+label)
        fixed=header['boundary']['fixed_exterior_m']+header['boundary']['fixed_target_m']
        original_gamma=header['context']['ordered_local_premises']
        check(len(f['tests'])==53 and len(set(f['tests']))==53 and f['completed'] is True,'all53 complete ordered unique test labels '+label)
        check(all(f[k] is True for k in ('real_pending_reader_case_exercised','real_forced_case_exercised','real_dead_case_exercised',
              'literal_complete_domain_EOF_measured','exact_root_rollback_checked','nonlogical_exclusion_fixture','no_proof_search_episode')),
              'all mandatory actually completed control and rollback scope flags '+label)
        check(all(f[k] is False for k in ('repeated_equal_Gamma_case_exercised','aliased_MP_input_case_exercised','actual_zero_mark_case_exercised',
              'fixture_trajectory_is_master_conforming','full_trajectory_accepted','actual_selected_target_endpoint_issued','scientific_consumer_activation',
              'inventory_admission','full24_board_accepted')),'unexercised or unaccepted scopes never promoted '+label)
        check(f['actual_master_conforming_executor_steps']==3 and f['instrumented_placements']==1,'actual executor steps versus one debug placement '+label)
        check(f['all_current_receptor_requests']==len(f['all_rejected_groundings'])+len(f['all_checked_ground_instances'])==2,
              'all actual initial equality/Incident/family pair requests resolved '+label)
        observations=f['observations'];check([o['label'] for o in observations]==['initial','marked-pending-reader-fixture','nonlogical-forced-key-exclusion-fixture'],
              'whole initial/pending/dead saved observation sequence '+label)
        initial=observations[0]['source_state'];initial_order=initial['order']
        check(len(initial_order)==3 and [k[1] for k in initial_order]==[0,1,2]
              and all(k[2]==[] for k in initial_order),'all original occurrence seeds preserved '+label)
        initial_values={(x,y):v for x,y,v,n in initial['marks']}
        initial_points=saved_integer_points(initial_order,fixed,initial_values)
        check(initial_points['totals']==initial['totals'] and initial_points['marks']==initial['marks'],
              'saved initial complete fixed marks/positive row/refcounts integer consistency '+label)
        for index,o in enumerate(observations):
            state=o['source_state'];decision_row=o['decision'];kind,row,count,generation=decision_row
            check(state['catalog_identity_sha256']==binding['catalog_identity_sha256'] and state['model_epoch']==binding['model_epoch']
                  and state['runtime_authority_sha256']==binding['runtime_authority_sha256'],'each whole saved state exact graph binding '+label+'/'+o['label'])
            check(len(state['domains'])==len(state['totals'])==len(state['roots'])==len(state['excluded'])==24
                  and [d['row'] for d in state['domains']]==list(range(24)),'all24 frontier/domain/exclusion slots retained '+label+'/'+o['label'])
            empty=[i for i,total in enumerate(state['totals']) if total==0]
            dead=[i for i in empty if state['domains'][i]['count']==0];forced=[i for i in empty if state['domains'][i]['count']==1]
            expected_kind='dead' if dead else 'forced' if forced else 'branch'
            expected_row=min(dead) if dead else min(forced) if forced else min(empty,key=lambda i:(state['roots'][i],state['domains'][i]['count'],i))
            check(kind==expected_kind and row==expected_row and count==state['domains'][row]['count']
                  and generation==state['roots'][row],'saved global dead/forced/earliest-generation decision fields '+label+'/'+o['label'])
            check([k[1] for k in state['order']]==[i for i,v in enumerate(state['totals']) if v],
                  'snapshot selected support versus totals '+label+'/'+o['label'])
            check(all(type(v) is int and type(n) is int and n>0 for x,y,v,n in state['marks'])
                  and len({(x,y) for x,y,v,n in state['marks']})==len(state['marks']),
                  'all assigned marks/refcounts retained, absence differs from assigned zero '+label+'/'+o['label'])
            if kind=='dead':
                check(o['preferred_keys']==[] and 'selection' not in o and state['excluded'][row]==observations[1]['complete_canonical_domain_keys'],
                      'nonlogical sole-key exclusion makes saved global dead, no advice or EOF claim '+label)
                check(state['order']==observations[1]['source_state']['order'] and state['marks']==observations[1]['source_state']['marks']
                      and state['totals']==observations[1]['source_state']['totals'],'dead fixture changes exclusion not selected physical union '+label)
                continue
            canonical_keys=o['complete_canonical_domain_keys'];ordered_keys=o['complete_preferred_domain_keys'];preferred=o['preferred_keys'];s=o['selection']
            canonical_ids=[key(k) for k in canonical_keys];ordered_ids=[key(k) for k in ordered_keys];preferred_ids=[key(k) for k in preferred]
            all_list_entries+=len(canonical_keys)+len(ordered_keys)
            check(o['literal_domain_EOF_measured'] is True and len(canonical_ids)==len(ordered_ids)==count
                  and len(set(canonical_ids))==len(set(ordered_ids))==count and Counter(canonical_ids)==Counter(ordered_ids),
                  'complete EOF cardinality/full-key identity/multiplicity '+label+'/'+o['label'])
            check(canonical_ids==sorted(canonical_ids) and all(k[1]==row and 0<=k[0]<header['dimensions']['primitive_license_count'] for k in canonical_ids),
                  'entire canonical recipe/prior-reference order at chosen row '+label+'/'+o['label'])
            check(len(set(preferred_ids))==len(preferred_ids) and set(preferred_ids)<=set(canonical_ids)
                  and ordered_ids==preferred_ids+[k for k in canonical_ids if k not in set(preferred_ids)],
                  'exact preferred prefix plus every canonical fallback once '+label+'/'+o['label'])
            check(s['preferred_count']==len(preferred) and s['decision']==decision_row and s['complete_canonical_fallback_retained'] is True
                  and s['proposal_pool_is_not_base_domain'] is True and s['proposal_pool_capped'] is False,
                  'proposal pools never replace complete domain count '+label+'/'+o['label'])
            check(all(s[k] is False for k in ('target_used_for_ranking','learned_marking','pruning','macro_executed','inventory_admission','independent_target_certificate_issued'))
                  and s['RNG_draws']==0,'deterministic advice no RL/target/constraint/proof endpoint inference '+label+'/'+o['label'])
            if kind=='forced':
                check(preferred==[] and s['forced_advice_empty'] is True and s['requests_started']==0
                      and s['preferred_cluster_proposals']==[] and s['selected_domain_membership'] is None,
                      'real global forced retains empty advice and complete forced key '+label)
            else:
                member=s['selected_domain_membership']
                check(member['completed'] is True and member['partial_results_returned'] is False
                      and member['batch_key_count']==member['legal_count']==member['exact_predicate_queries']==len(preferred)
                      and member['binding']['decision']==decision_row and member['binding']['catalog_identity_sha256']==binding['catalog_identity_sha256'],
                      'full returned preferred membership receipt bound to chosen snapshot '+label)
                returned_proposals+=len(s['preferred_cluster_proposals'])

        expected_instance_fields=[]
        for i,instance in enumerate(f['all_checked_ground_instances']+observations[0]['selection']['preferred_cluster_proposals']):
            commands=instance['commands'];primitive=instance['primitive_keys'];p=instance['literal_points']
            label_i=label+'/stored-or-proposal-'+str(i)
            check(instance['completed'] is True and instance['independent_ground_check']['original_ground_sequent_accepted'] is True
                  and instance['independent_ground_check']['rows']==len(commands)==len(primitive),'saved completed original-Gamma host ground acceptance '+label_i)
            check(instance['exact_original_ordered_Gamma']==original_gamma and commands[:3]==[dict(rule='assumption',index=j,formula=formula) for j,formula in enumerate(original_gamma)],
                  'entire original indexed ambient Gamma retained exactly '+label_i)
            check(primitive[:3]==initial_order and instance['new_primitive_keys']==primitive[3:]
                  and instance['ordered_receptor_keys']==[initial_order[1],initial_order[2]],'strict original receptor order and ancestry indices '+label_i)
            check(len({key(k) for k in primitive})==len(primitive) and [k[1] for k in primitive]==list(range(len(commands))),
                  'full placement identity occurrence and ordered primitive command rows '+label_i)
            deps=[]
            for row,command in enumerate(commands):
                references=[] if command['rule']!='mp' else [command['antecedent'],command['implication']]
                check(references==primitive[row][2] and all(type(j) is int and 0<=j<row for j in references),
                      'ordered strict-prior command/point references '+label_i+'/'+str(row))
                deps.append(references)
            todo=[len(commands)-1];ancestors=set()
            while todo:
                j=todo.pop()
                if j not in ancestors:ancestors.add(j);todo.extend(deps[j])
            consumed=sorted(commands[j]['index'] for j in ancestors if commands[j]['rule']=='assumption')
            check(consumed==instance['consumed_original_occurrence_indices'] and consumed==[1,2],
                  'actual declared dependency consumption separate from retained unused Gamma0 '+label_i)
            check(instance['conclusion']==commands[-1]['formula'] and instance['root_receptor_row']==primitive[-1][1]
                  and instance['source_state_sha256']==digest(initial),'saved conclusion/root/source-state complete digest '+label_i)
            values={(x,y):v for x,y,v in p['m']}
            expected=saved_integer_points(primitive,fixed,values)
            check(p==expected and instance['whole_current_point_union']==saved_integer_points(initial_order+primitive,fixed,values),
                  'every complete point/mark/reference-count/current-fixed union saved integer relation '+label_i)
            check(saved_integer_points(primitive+primitive,fixed,values)==expected,'shared identical full keys counted once, not per cluster copy '+label_i)
            check(instance['library_binding']==manifest['library'] and instance['library_payload_sha256']==digest(library)
                  and instance['family_id'] in {item['family_id'] for item in library['families']},'actual original candidate family/library binding '+label_i)
            check(instance['primitive_source_body_count']==0 and all(instance[k] is False for k in ('ROOT_inventory_admitted','actual_selected_target_accepted',
                  'full24_board_accepted','macro_executed','native_accepted','original_Gamma_target_accepted')),
                  'provisional transport result not target/full24/native/library acceptance '+label_i)
            expected_instance_fields.append(dict(family_id=instance['family_id'],commands=len(commands),positive_points=len(p['t']),
                assigned_mark_points=len(p['m']),consumed_occurrences=consumed,source_state_sha256=instance['source_state_sha256']))
        stored_instances+=len(f['all_checked_ground_instances'])
        pending=observations[1]['source_state'];values={(x,y):v for x,y,v,n in pending['marks']}
        pending_expected=saved_integer_points(pending['order'],fixed,values)
        check(pending_expected['marks']==pending['marks'] and pending_expected['totals']==pending['totals'],
              'complete saved pending-reader physical constraint union '+label)
        check(3 not in [k[1] for k in pending['order']] and any(x==1 and y==3 for x,y,v,n in pending['marks']),
              'pending prerequisite mark is constraint without an occupied logical source '+label)
        metrics=f['family_metrics']
        check(metrics['ground_checks_started']==metrics['ground_checks_completed']==metrics['ground_checks_accepted']==2
              and metrics['instance_calls_completed']==2 and metrics['instance_calls_started']==12,
              'actual successful and rejected calls distinct from stored family/proof counts '+label)
        for prefix in ('current_point','embedding_point','final_point'):
            check(metrics[prefix+'_calls_started']==metrics[prefix+'_calls_completed'],'all recorded '+prefix+' calls completed '+label)
        observed_cases.append(dict(instance_id=label,tests=len(f['tests']),initial_chosen_domain=observations[0]['decision'][2],
            forced_domain=observations[1]['decision'][2],initial_preferred=len(observations[0]['preferred_keys']),
            stored_ground_instances=len(f['all_checked_ground_instances']),returned_proposals=len(observations[0]['selection']['preferred_cluster_proposals']),
            saved_instances=expected_instance_fields,coverage_flags={k:v for k,v in f.items() if isinstance(v,bool)},
            control_call_seconds=c['control_call_seconds'],metrics=metrics,
            EOF_witnesses=[dict(label=o['label'],canonical_sha256=digest(o['complete_canonical_domain_keys']),preferred_order_sha256=digest(o['complete_preferred_domain_keys']),
                entries=len(o['complete_canonical_domain_keys'])) for o in observations if 'complete_canonical_domain_keys' in o]))

    check(worker['stage_completed'] is True and worker['stage']==owner['stage']==owned['stage']=='replay'
          and worker['all_direct_children_terminal_and_reaped'] is True and worker['direct_children_peak_sum_bytes']==0,'complete functional child closure and generic replay-stage ABI')
    ledger=json.loads(gzip.decompress((ROOT/owner['ownership_ledger']['path']).read_bytes()))
    check(len(ledger['samples'])==owner['sampled_observations']==143 and ledger['leftovers']=={} and owner['owned_leftovers']==[],
          'whole143 sample ledger with no observed task-owned leftovers')
    for index,s in enumerate(ledger['samples']):
        rss=sum(row['rss_bytes'] for row in s['owned_rows'].values())
        check(rss==s['owned_rss_bytes'] and s['combined_bytes']==s['ROOT_peak_bytes']+rss+s['observer_peak_bytes']
              and all(row['birth']==ledger['final_retained_births'][pid] for pid,row in s['owned_rows'].items()),
              'whole sampled own/worker/observer integer sum and same-PID birth '+str(index))
    conservative=max([owner['ROOT_peak_bytes']+owner['worker_kernel_peak_bytes']+owner['direct_children_peak_sum_bytes']+owner['observer_peak_bytes']]
                     +[s['combined_bytes'] for s in ledger['samples']])
    check(conservative==owner['peak_bytes']==60801024 and post['peak_bytes']==60997632,'kernel plus complete sample maxima and postwrite peak exact')
    check(owner['resource_gate_accepted'] is True and owner['all_direct_children_terminal_and_reaped'] is True and owner['worker_returncode']==0
          and owner['cleanup_errors']==[] and owner['error'] is None and owner['cancelled'] is False,'complete actual saved owned worker/reap closure')
    check(owner==provisional and pin(ACTUAL/'replay-owner-v1/ROOT-terminal-v1.json')['sha256']==pin(ACTUAL/'replay-owner-v1/provisional-terminal-v1.json')['sha256'],
          'accepted terminal is exact provisional byte identity')
    print_record=json.loads(tool['terminal']['output'].strip().splitlines()[-1]);caller=(tool['terminal_observed_ms']-tool['started_ms'])/1000
    check(caller==decision['caller_elapsed_seconds']==23.5 and post['elapsed_seconds']==18.122334334
          and controls['inner_complete_seconds']==evidence['inner_complete_seconds']==17.956941584,
          'exact enclosing caller/owned/inner costs, scopes not additive')
    check(len(tool['chunks'])==5 and all(c.get('session_id')==18313 for c in tool['chunks'][:-1])
          and all('exit_code' not in c for c in tool['chunks'][:-1]) and tool['chunks'][-1]['exit_code']==0,
          'same authoritative initial handle plus all terminal polls in one isolate')
    predicates=dict(actual_tool_terminal=tool['terminal'].get('exit_code')==0,caller_clock_bound=0<=caller+1<=limits['caller_seconds'],
        owner_terminal_link_present=(ACTUAL/'replay-owner-v1/ROOT-terminal-v1.json').exists(),owner_gate=owner['resource_gate_accepted'] is True,
        post_write_gate=post['resource_gate_accepted'] is True,cancelled_at_final_print_false=print_record['cancelled_at_final_print'] is False,
        final_print_gate=print_record['resource_gate_accepted'] is True,stage_identity=owner['stage']==worker['stage']==owned['stage'],
        worker_complete=worker['stage_completed'] is True,all_worker_direct_children_closed=worker['all_direct_children_terminal_and_reaped'] is True,
        all_owner_direct_children_closed=owner['all_direct_children_terminal_and_reaped'] is True,no_owned_leftovers=owner['owned_leftovers']==[],
        complete_post_closure_unchanged=decision['mismatches']==[],post_write_exact_terminal=post['terminal']==pin(ACTUAL/'replay-owner-v1/ROOT-terminal-v1.json',post['terminal']['path']))
    check(predicates==decision['predicates'] and len(predicates)==14 and all(predicates.values())
          and decision['ROOT_final_accepted'] is True,'all14 final saved predicates reconstructed without calling owner/closer')
    check(controls['inventory_admission'] is False and controls['scientific_consumer_activation'] is False and controls['target_proofs_accepted'] is False
          and controls['full24_board_accepted'] is False and controls['RL_episodes']==controls['training_updates']==0,
          'whole controls output cannot activate science, theorem, full24 or RL')
    check(failed['actual_status']=='UNKNOWN_incomplete_real_family_controls' and failed['accepted_partial_prefix'] is False
          and failed['resource_observations']['owned_post_seconds']==1.604088667 and failed['resource_observations']['caller_seconds']==5.682,
          'previous failed attempt/status/cost retained, no rescue or replacement')
    if seal is not None:
        check(seal.get('ROOT_complete_scoped_controls_accepted') is True
              and seal['actual_controls']==worker['controls'] and seal['actual_evidence']==worker['evidence']
              and seal['actual_receipt']==pin(ACTUAL/'worker-output-v1/actual-family-controls-result-v1.json')
              and seal['actual_control_checks']==106 and seal['successful_control_cases']==2,
              'Root limited actual controls disposition exact saved artifacts and counts, not agent authority')
        check(all(seal[k] is False for k in ('scientific_search_activation','ROOT_library_admitted','inventory_admission',
              'target_proofs_accepted','full24_board_accepted','schema_universally_validated'))
              and seal['RL_episodes']==seal['training_updates']==0,'Root seal preserves all unsupported mathematical/scientific scopes')
        for recorded,c in zip(seal['cases'],controls['case_controls']):
            f=c['full_controls']
            check(recorded['instance_id']==c['instance_id'] and recorded['qualification']==c['qualification']
                  and recorded['checked_tests']==len(f['tests']) and recorded['initial_ground_expansions']==len(f['all_checked_ground_instances'])
                  and recorded['all_checked_commands']==[i['commands'] for i in f['all_checked_ground_instances']]
                  and recorded['ground_checks_completed']==f['family_metrics']['ground_checks_completed'],
                  'Root literal complete proof-command projection, not invented witness '+c['instance_id'])
    finding=save('family-controls-complete-actual-saved-findings-v1.json',dict(schema='independent-complete-real-family-controls-saved-findings-v1',
        reviewer_identity='/root/arithmetic_induction',author_identity='/root/hilbert_advice_controls',
        review_scope='Whole saved JSON/raw source closure and numeric field/dependency consistency only; no scientific semantic replay.',
        all_checks_passed=not mismatches,mismatches=mismatches,scientific_calls=0,project_imports=0,semantic_replays=0,
        mathematical_authority_issued=False,resource_authority_issued=False,ROOT_authority_issued=False,inventory_admission=False,scientific_consumer_activation=False,
        saved_complete_controls=True,actual_check_count=controls['actual_check_count'],actual_cases=2,source_request_count=27,
        stored_instances=stored_instances,returned_proposals=returned_proposals,full_EOF_list_entries_checked=all_list_entries,
        observed_cases=observed_cases,sources=leaf['sources'],actual_resource_predicates=predicates,
        actual_costs=dict(inner_complete_seconds=controls['inner_complete_seconds'],owned_post_seconds=post['elapsed_seconds'],caller_seconds=caller,
            postwrite_conservative_peak_bytes=post['peak_bytes'],scope='Inclusive clocks overlap; no sum of nested phases.'),
        prior_failed_reconciliation=pin(HERE/'family-controls-failed-actual-saved-findings-v1.json'),
        preserved_failed_cost=dict(owned_post_seconds=1.604088667,caller_seconds=5.682,observed_peak_bytes=58195968,status='UNKNOWN_incomplete_real_family_controls'),
        Root_disposition=pin(seal_path) if seal is not None else None,
        limitations=['Saved-only reconciliation does not rerun the original independent GroundChecker, Graph, endpoint guards, scheduler or rollback.',
            'Integer point reconstruction uses saved formula-code values, not an independently executed catalogue/licence derivation.',
            'Full chosen-domain EOF lists are compared in entirety; this does not constitute a new full24 dynamic domain oracle.',
            'Pending/direct-placement/temporary-exclusion fixtures remain nonlogical and not a complete master-conforming trajectory.',
            'Repeated-Gamma, aliased MP ports, actual-zero marks and successful second-chain coverage remain unexercised; prospective native descriptor mutation requests also remain unrun.',
            'Current checks qualify only controls on these two already checked contexts; scientific receiver/advice admission and matched searches remain separate.'],
        evidence_roots=roots,raw_pin_occurrences=len(refs),raw_pin_identity_count=len({(p['path'],p['sha256'],p['bytes']) for p in refs}),
        checks=checks,check_count=len(checks),metadata_helper_seconds_before_serialization=time.perf_counter()-began,
        helper_cost_scope='Saved-only helper timing, not a full process total or scientific worker cost.'))
    handoff=save('family-controls-complete-actual-saved-handoff-v1.json',dict(schema='independent-complete-real-family-controls-saved-handoff-v1',
        findings=finding,helper=pin(Path(__file__)),all_checks_passed=not mismatches,mismatches=mismatches,scientific_calls=0,
        saved_actual_check_count=106,saved_actual_cases=2,scope='Raw saved evidence consistency only, no semantic/resource/ROOT authority or scientific admission.'))
    print(json.dumps(dict(findings=finding,handoff=handoff,check_count=len(checks),mismatches=mismatches),sort_keys=True))


if __name__=='__main__':
    main()
