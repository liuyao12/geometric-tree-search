"""Independent Source/raw metadata review only. Never imports project modules."""
import ast
import hashlib
import json
import symtable
import builtins
import time
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/equality-receptor-family-controls-independent-20261014'
PACKET=ROOT/'.gcts-active/equality-receptor-family-controls-source-20261014'

def pin(p):
    raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    p=HERE/name
    with p.open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
    return pin(p)

def main():
    began=time.perf_counter();checks=[];mismatches=[];refs=[]
    def check(ok,label):
        checks.append({'name':label,'passed':bool(ok)})
        if not ok:mismatches.append(label)
    def scan(v):
        if isinstance(v,dict):
            if set(v)=={'path','sha256','bytes'}:
                p=Path(v['path']);p=p if p.is_absolute() else ROOT/p
                actual=pin(p);actual['path']=v['path'];refs.append(v)
                check(actual==v,'raw pin '+v['path'])
            for x in v.values():scan(x)
        elif isinstance(v,list):
            for x in v:scan(x)
    handoff=json.loads((PACKET/'handoff-v2.json').read_bytes());scan(handoff)
    contract=json.loads((PACKET/'source-contract-v2.json').read_bytes());scan(contract)
    current=Path(handoff['worker']['path']);old=PACKET/'actual_Incident_family_controls_worker_v1.py'
    raw=current.read_text();a,b=ast.parse(old.read_bytes()),ast.parse(raw);compile(b,str(current),'exec')
    mechanism=Path(handoff['mechanism']['path']);ctree=ast.parse(mechanism.read_bytes());compile(ctree,str(mechanism),'exec')
    def constants(tree):
        out={}
        for n in tree.body:
            if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):out[n.targets[0].id]=n.value
        return out
    assignments=constants(b);frozen=ast.literal_eval(assignments['FROZEN_SOURCES'])
    sources=dict(frozen,worker=pin(current));scan(sources)
    check(len(sources)==20,'selected actual current twenty raw roles')
    check(sources['worker']['sha256']=='020c1a3379607a9a13193fc1800175a121f4d060d268788579999c385f8c9e70','actual selected V2 worker, not stale source_review_ABI history')
    check(contract['entrypoint']['worker']==sources['worker'],'current entrypoint worker pin correct')
    historical_worker=contract['source_review_ABI']['sources']['worker']
    check(historical_worker==pin(old),'contract review_ABI retained older V1 identity is known history')
    check({k:v for k,v in contract['source_review_ABI']['sources'].items() if k!='worker'}==frozen,'review ABI all nineteen nonworker pins unchanged')
    da={n.name:n for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    db={n.name:n for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    check(set(da)==set(db),'no new helper/validator definitions in endpoint V2 delta')
    changed=[]
    for name in da:
        if ast.dump(da[name],include_attributes=False)!=ast.dump(db[name],include_attributes=False):changed.append(name)
    check(changed==['main'],'only worker main endpoint captures/comparisons change')
    check({k:ast.dump(v,include_attributes=False) for k,v in constants(a).items()}==
          {k:ast.dump(v,include_attributes=False) for k,v in constants(b).items()},'all frozen constants/role maps/budgets unchanged from V1')
    check(handoff['mechanism']==pin(mechanism) and handoff['mechanism']['sha256']=='70187b4ad5b0a733dedae6b9ac0f9cf20bc398fe83d96fdf17ba522c20cf8583','entire controls callable unchanged')
    for label,tree in (('worker',b),('mechanism',ctree)):
        source=current.read_text() if label=='worker' else mechanism.read_text()
        table=symtable.symtable(source,label,'exec');defined={s.get_name() for s in table.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
        defined|=set(dir(builtins))|{'__file__','__name__','__builtins__'}
        missing=set();pending=[table]
        while pending:
            t=pending.pop();pending.extend(t.get_children())
            for s in t.get_symbols():
                if s.is_global() and s.is_referenced() and s.get_name() not in defined:missing.add(s.get_name())
        check(not missing,label+' syntax/global bindings without import')
    for token in ('closed_methods = family.method_state(closed)','graph_methods = family.method_state(graph)',
                  'catalog_methods = family.method_state(graph.catalog)','authority_methods = family.method_state(authority)',
                  'controller_methods = family.method_state(control)'):
        check(token in raw,'capture effective endpoint '+token)
    check(all(token in raw for token in ('family.method_state(closed) == closed_methods','family.method_state(graph) == graph_methods',
        'family.method_state(graph.catalog) == catalog_methods','family.method_state(authority) == authority_methods',
        'family.method_state(control) == controller_methods')),'each effective object method/MRO/property snapshot checked in full callback')
    check(all(token in raw for token in ('function_signature(callback_fn) != callback_anchor','function_signature(invoke_guard) != invoke_anchor',
        'unchanged_executable is not guard_fn','guard_fn.__code__ is not guard_code','original callback changed during delegation')),
        'direct own validator/anchored callback/shim guards precede delegated use')
    check(ast.literal_eval(assignments['INPUT_ROLES'])=={'candidate_library','independent_audit','ROOT_extraction_disposition','control_manifest','control_request_specification'},'exact five direct input roles')
    check(contract['ABI']['leaf_count']==11 and contract['ABI']['owner_count']==10
        and len(contract['entrypoint']['argv'])==6,'strict eleven leaf/ten generic owner/six argv')
    check(contract['limits']=={'control_seconds':20,'whole_seconds':60,'peak_bytes':536870912,'caller_seconds':90},'shared20/owned60/512/caller90 unchanged')
    check('plan[\'scope\']==SCOPE' in raw and "admission['controls_scope'] == 'real-ground-instance-and-domain-controls-only'" in raw
        and "admission['scientific_episode_activation'] is False" in raw,'worker requires separate controls-only scope')
    check("seal['ROOT_advice_admission'] is False" in raw and "seal['ROOT_library_admitted'] is False" in raw,
        'original extraction seal explicitly cannot substitute for control authority')
    check("manifest['ROOT_controls_authorized'] is True" in raw and "manifest['scientific_episode_activation'] is False" in raw,
        'future Root explicit controls manifest required; worker never issues it')
    bindings=json.loads((ROOT/'.gcts-active/equality-receptor-family-I2-recipient-source-20261014/I2-recipient-bindings-v1.json').read_bytes());scan(bindings)
    current_recipient_metadata=[]
    for item in bindings['recipients']:
        header=json.loads(Path(item['catalog']['path']).read_bytes());gamma=header['context']['ordered_local_premises']
        check(gamma[1]==['eq',['fun','u',[]],['fun','v',[]]] and gamma[2]==['pred','Incident',[['fun','A',[]],['fun','u',[]]]],
            'current initial selected receptor syntax, no invented hypothesis '+item['instance_id'])
        current_recipient_metadata.append({'instance_id':item['instance_id'],'catalog':item['catalog'],
            'initial_equality_occurrence':1,'initial_Incident_occurrence':2,'positive_scope':'slot1 current transport grounding is structurally available; no actual instance checked by reviewer.'})
    code=mechanism.read_text()
    check('for item in session.families():' in code and 'for equality in eqs:' in code and 'for phi in phis:' in code,
        'all initial actual complete selected receptor/family combinations scanned')
    check('state[\'order\']+instance[\'primitive_keys\']' in code and "patch == instance['literal_points']" in code
        and "whole == instance['whole_current_point_union']" in code,'independent integer literal current+fixed point/refcount comparisons planned')
    check('base_keys == reference_keys' in code and 'len(set(base_keys)) == decision.count' in code
        and 'tuple(preferred) + tuple(k for k in base_keys if k not in set(preferred))' in code,
        'entire selected domain EOF/cardinality/canonical fallback compared, no shortlist degree')
    check('actual == master_reference' in code and "preferred == () and record['forced_advice_empty'] is True" in code,
        'global master decision and forced-empty advice controls')
    check('graph._apply_legal(reader_key)' in code and 'graph.exclude_failed_child(force_keys[0])' in code
        and 'fixture_trajectory_is_master_conforming=False' in code and 'nonlogical_exclusion_fixture=True' in code,
        'pending/forced/dead fixtures explicitly specialized nonlogical interventions')
    check('exact_root_rollback_checked' in code and 'final whole graph/domain/mark/generation rollback' in code,
        'complete final rollback checked even on exception')
    check(all(k in code for k in ('repeated_equal_Gamma_case_exercised=False','aliased_MP_input_case_exercised=False','actual_zero_mark_case_exercised=False')),
        'unexercised repeated Gamma/MP aliases/actual zero never labelled passed')
    check('second ET-chain' in contract['conformance_scope']['unexercised'],'second-chain noncoverage explicitly retained in contract')
    dfs=Path(sources['streamed_dfs']['path']).read_text()
    scope_gap='scientific_episode_activation' not in dfs and 'controls_scope' not in dfs
    check(scope_gap and 'Future cold search worker must reject controls-only scope' in contract['authorization_scope']['scientific_library_admission'],
        'scientific receiving scope gate remains explicit future prerequisite, not controls qualification')
    adequacy={
        'controls_source_eligible_after_genuine_ROOT_plans':not mismatches,
        'sufficient_to_activate_scientific_family_search':False,
        'limitations':['This is a same-author new control arithmetic path with unchanged independent GroundChecker, not a distinct-author semantic replay.',
          'Only initial current2 recipient receptor combinations and a few actual point states are exercised. Whole catalogue licensing/current q/static domain authority remain separately pinned inputs.',
          'Complete EOF at the selected point is checked; global degrees are taken from the original graph. This is not a fresh independent full24-row dynamic domain oracle.',
          'The pending/off-scheduler placement and sole-key exclusion are labelled debug fixtures. They establish mechanical state-machine coverage only, not a conforming proof trajectory or proved pruning.',
          'Repeated equal Gamma, actual-zero marking, aliased MP inputs and successful second-family chain are unexercised. Future admissions must preserve these missing controls or add separately authorized cases.',
          'Current scientific search_episode/registry do not inspect controls-only scope; future cold scientific receiver must reject such grants and require actual controls disposition plus full current Source/metadata/runtime authority.',
          'A controls pass admits no universal family schema, inventory, native proof, target proof, full24 board, trajectory, RL or speed benefit.'],
        'metadata_correction':'Contract source_review_ABI retains V1 worker raw identity; this review deliberately selects exact V2 entrypoint020c1a and constructs the actual twenty-role map from V2 literal FROZEN_SOURCES plus actual worker. No author file was altered.'}
    typed={'schema':'independent-current-I2-family-controls-source-review-v1','scope':'actual-two-I2-family-ground-domain-controls',
        'source_only':True,'source_review_passed':not mismatches,'scientific_calls':0,
        'author_identity':'/root/hilbert_advice_controls','reviewer_identity':'/root/arithmetic_induction',
        'sources':sources,'selected_worker':pin(current),'callable':pin(mechanism),
        'source_contract':pin(PACKET/'source-contract-v2.json'),'future_actual_control_acceptance':False,
        'scientific_consumer_activation':False,'inventory_admission':False,'universal_schema_accepted':False,
        'conditions':adequacy}
    findings=save('family-controls-source-findings-v1.json',dict(typed,all_checks_passed=not mismatches,mismatches=mismatches,
        checks=checks,raw_references=refs,current_recipient_metadata=current_recipient_metadata,
        whole_scope_reviewed=['Entire callable70187b and workerV1+V2 effective endpoint delta.','All20 literal/raw source/input/review/registry ABI and unchanged generic owner+closer life-cycle/source contract.',
            'Exact c8 receiver/current fixture16/two accepted q static semantics, original Gamma, empty BodyAuthority+Controller inventory and separate finite advice registry.',
            'Source/guard/module/MRO/property/effective method/callback/shim closure, cold code/input allowlists, counters/failure/clock/output/no-prefix semantics.'],
        metadata_helper_seconds_before_outputs=time.perf_counter()-began))
    review=save('family-controls-typed-source-review-v1.json',dict(typed,findings=findings))
    handoff_pin=save('family-controls-source-review-handoff-v1.json',{
        'schema':'independent-current-I2-family-controls-source-review-handoff-v1','findings':findings,'review':review,
        'source_review_passed':not mismatches,'source_only':True,'scientific_calls':0,
        'scope':'Current controls-only preactivation Source, not scientific library activation.'})
    print(json.dumps({'handoff':handoff_pin,'review':review,'findings':findings,'checks':len(checks),'mismatches':mismatches},sort_keys=True))

if __name__=='__main__':main()
