"""Saved-only JSON/hash/AST reconciliation. No project import or scientific call."""
import ast
import gzip
import hashlib
import json
import time
from pathlib import Path

ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE = ROOT/'.gcts-active/equality-receptor-family-controls-independent-20261014'
ACTUAL = ROOT/'.gcts-active/equality-receptor-family-controls-progress-20261014'
STDLIB_ABC = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/lib/python3.9/_collections_abc.py')


def raw_pin(path, spelling=None):
    path = Path(path)
    path = path if path.is_absolute() else ROOT/path
    h = hashlib.sha256(); size = 0
    before = path.stat()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            h.update(block); size += len(block)
    after = path.stat()
    if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns) != (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
        raise ValueError('file changed during raw read')
    return dict(path=spelling if spelling is not None else str(path), sha256=h.hexdigest(), bytes=size)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def save(name,value):
    path=HERE/name
    with path.open('x') as stream:
        json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False); stream.write('\n')
    return raw_pin(path)


def main():
    began=time.perf_counter(); checks=[]; mismatches=[]; references=[]; raw_roots=[]
    def check(value,label):
        checks.append(dict(name=label,passed=bool(value)))
        if not value:mismatches.append(label)
    def scan(value):
        if isinstance(value,dict):
            if set(value)=={'path','sha256','bytes'}:
                references.append(value)
                check(raw_pin(value['path'],value['path'])==value,'whole raw pin '+value['path'])
            for child in value.values():scan(child)
        elif isinstance(value,list):
            for child in value:scan(child)
    def document(path):
        path=Path(path); path=path if path.is_absolute() else ROOT/path
        raw=path.read_bytes(); pin=dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
        raw_roots.append(pin)
        def unique(pairs):
            result={}
            for key,value in pairs:
                if key in result:raise ValueError('duplicate JSON key '+key)
                result[key]=value
            return result
        value=json.loads(raw,object_pairs_hook=unique,parse_constant=lambda token:(_ for _ in ()).throw(ValueError(token)))
        scan(value); return value

    leaf=document(ACTUAL/'worker-plan-v1.json')
    owned=document(ACTUAL/'replay-plan-v1.json')
    manifest=document(ACTUAL/'ROOT-controls-input-manifest-v1.json')
    root_source=document(ACTUAL/'ROOT-source-review-v1.json')
    peer_source=document(HERE/'family-controls-typed-source-review-v1.json')
    launch=document(ACTUAL/'replay-owner-v1/launch-v1.json')
    owner=document(ACTUAL/'replay-owner-v1/provisional-terminal-v1.json')
    post=document(ACTUAL/'replay-owner-v1/post-write-observation-v1.json')
    tool=document(ACTUAL/'replay-actual-tool-observations-v1.json')
    decision=document(ACTUAL/'replay-ROOT-final-decision-v1.json')
    failure=document(ACTUAL/'ROOT-actual-family-controls-failure-disposition-v1.json')
    expected_limits=dict(caller_seconds=90,control_seconds=20,peak_bytes=536870912,whole_seconds=60)
    check(len(leaf)==11 and len(owned)==10,'strict eleven-field leaf and ten-field generic owner')
    check(leaf['scope']==owned['scope']=='actual-family-ground-domain-control-no-search-no-admission','controls scope separate from science search')
    check(leaf['ROOT_owned_once_only'] is True and owned['stage']=='replay','one owned controls attempt, generic transport stage replay')
    check(leaf['limits']==owned['limits']==post['limits']==decision['limits']==expected_limits,'all twenty/sixty/512MiB/ninety caps unchanged')
    check(len(leaf['sources'])==20 and leaf['sources']==root_source['sources']==peer_source['sources'],'whole exact twenty-source epoch')
    check(root_source['source_review_passed'] is True and peer_source['source_review_passed'] is True
          and root_source['scientific_calls']==peer_source['scientific_calls']==0,'prior genuine Source-only reviews retained, not actual pass')
    check(peer_source['author_identity']=='/root/hilbert_advice_controls'
          and peer_source['reviewer_identity']=='/root/arithmetic_induction','worker author and reviewer distinct')
    check(len(leaf['closure'])==177 and len(owned['closure'])==178,'complete saved closure sizes, no census narrowing')
    check(owned['argv']==launch['argv'] and len(owned['argv'])==6
          and owned['argv'][0]==leaf['runtime']['binary']['path'] and owned['argv'][1]=='-B'
          and owned['argv'][2]==leaf['sources']['worker']['path']
          and owned['argv'][3]=='ROOT-real-I2-Incident-family-controls'
          and owned['argv'][4]==str(ACTUAL/'worker-plan-v1.json')
          and owned['argv'][5]==str(ACTUAL/'replay-plan-v1.json'),'literal selected worker/runtime/command and same two actual plans')
    check(leaf['owner_plan_path']==str(ACTUAL/'replay-plan-v1.json')
          and leaf['output_directory']==str(ACTUAL/'worker-output-v1'),'flat anchors and literal exclusive output namespace')
    check(manifest['ROOT_controls_authorized'] is True and manifest['scientific_episode_activation'] is False,'explicit real controls-only Root grant')
    check(manifest['library']==leaf['inputs']['candidate_library'] and manifest['audit']==leaf['inputs']['independent_audit']
          and manifest['extraction_disposition']==leaf['inputs']['ROOT_extraction_disposition'],'accepted extraction artifacts preserved without advice search admission')
    case_ids=['fresh-i2-CD-vw-direct','fresh-i2-CD-vw-incidence-transport']
    check([r['instance_id'] for r in manifest['recipients']]==case_ids,'two original current recipient order, first failed before second completed')
    case_metadata=[]
    for recipient in manifest['recipients']:
        q=document(recipient['qualification']['path']); auth=document(recipient['controls_admission']['path'])
        header=document(q['catalog']['path']); registry=recipient['family_registry_binding']; inventory=recipient['expected_inventory_binding']
        check(len(q)==11 and q['instance_id']==recipient['instance_id']==header['instance_id'],'whole original eleven-field q/header '+recipient['instance_id'])
        check(q['declaration_profile']=='hilbert-fresh-guarded-I2-cohort-static-v1','original static profile '+recipient['instance_id'])
        check(auth['recipient_qualification']==recipient['qualification'] and auth['implementation']==leaf['sources']['family_advice']
              and auth['controls_scope']=='real-ground-instance-and-domain-controls-only' and auth['scientific_episode_activation'] is False
              and auth['ROOT_library_admitted'] is False and auth['schema_universally_validated'] is False,'exact scoped advice authorization, no universal/science library '+recipient['instance_id'])
        check(registry['recipient_qualification']==recipient['qualification'] and registry['library_admission']==recipient['controls_admission']
              and registry['library_source']==manifest['library'] and registry['extraction_audit']==manifest['audit']
              and registry['family_implementation']==leaf['sources']['family_advice'],'current registry exact input/source/admission bindings '+recipient['instance_id'])
        preimage={key:value for key,value in registry.items() if key not in ('library_admission','advice_registry_epoch')}
        check(hashlib.sha256(canonical(preimage).encode()).hexdigest()==registry['advice_registry_epoch']==auth['registry_preimage_sha256'],
              'acyclic complete family registry preimage '+recipient['instance_id'])
        check(inventory['registered_whole_descriptor_count']==registry['primitive_source_body_count']==auth['primitive_source_body_count']==0
              and header['bodies']==header['complete_cluster_inventory']==[],'empty primitive body inventory retained '+recipient['instance_id'])
        check(inventory['qualified_dimensions']==header['dimensions'],'complete original dimensions retained '+recipient['instance_id'])
        check(len(q['expected_consumer_source_binding']['source_records'])==7,'all seven explicit current consumer raw roles '+recipient['instance_id'])
        case_metadata.append(dict(instance_id=recipient['instance_id'],qualification=recipient['qualification'],controls_admission=recipient['controls_admission'],
            registry_preimage_sha256=registry['advice_registry_epoch'],original_Gamma=header['context']['ordered_local_premises'],
            complete_preparation_dimensions=header['dimensions'],completed_controls=False,complete_controls_census=None))

    source_trees={}
    for role,record in leaf['sources'].items():
        if record['path'].endswith('.py'):
            source_trees[role]=ast.parse(Path(record['path']).read_bytes(),filename=record['path'])
    worker_text=Path(leaf['sources']['worker']['path']).read_text()
    mechanism_text=Path(leaf['sources']['mechanism_controls']['path']).read_text()
    family_text=Path(leaf['sources']['family_advice']['path']).read_text()
    dynamic_text=Path(leaf['sources']['dynamic_graph_adapter']['path']).read_text()
    owner_source=ACTUAL/'run_owned_bridge_v2.py'; close_source=ACTUAL/'close_stage_decision_v1.py'
    check(raw_pin(owner_source)['sha256']=='2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656','literal pinned generic owner source unchanged')
    check(raw_pin(close_source)['sha256']=='9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf','literal pinned saved closer source unchanged')
    ast.parse(owner_source.read_bytes());ast.parse(close_source.read_bytes());abc_tree=ast.parse(STDLIB_ABC.read_bytes())
    stdlib_pin=raw_pin(STDLIB_ABC); raw_roots.append(stdlib_pin)
    check('class RecipeMetadataView(Sequence):' in dynamic_text,'actual indexed metadata view inherits stdlib Sequence')
    check('__class_getitem__ = classmethod(GenericAlias)' in STDLIB_ABC.read_text()
          and 'GenericAlias = type(list[int])' in STDLIB_ABC.read_text(),'Python3.9 source declares inherited classmethod over GenericAlias type, not Python function')
    check('function = descriptor.__func__' in family_text and 'guard_state(function)' in family_text
          and "type(guard) is types.FunctionType" in family_text,'function-only effective-method seal rejects nonfunction descriptor payload')
    check('self._recipe_methods = method_state(recipes)' in family_text
          and 'advice = family.GoalDependencyAdvice(graph, view, deadline=deadline, family_session=session)' in mechanism_text,'exact constructor failure chain is source bound')
    check('finally:\n        graph.rollback(root)' in mechanism_text and "outcome['exact_root_rollback_checked'] = True" in mechanism_text,
          'rollback is prospective failure-finally code; no completed saved rollback receipt inferred')
    check(worker_text.index('outcomes.append(')>worker_text.index("modules['mechanism_controls'].run_controls(")
          and worker_text.index('output.mkdir()')>worker_text.index('outcomes.append('),'publication requires complete case return and complete sequential cases')
    stderr_path=ACTUAL/'replay-owner-v1/stderr-v1.txt'; stdout_path=ACTUAL/'replay-owner-v1/stdout-v1.txt'
    stderr=stderr_path.read_text(); stdout=stdout_path.read_bytes()
    check(stderr.endswith('ValueError: production delegated validator is exact function\n'),'actual retained nonexact-function rejection')
    for fragment in ('actual_Incident_family_controls_worker_v2.py", line 447','actual_Incident_family_controls_v1.py", line 121',
                     'equality_receptor_family_I2_v2.py", line 825','equality_receptor_family_I2_v2.py", line 127',
                     'equality_receptor_family_I2_v2.py", line 93'):
        check(fragment in stderr,'actual traceback source frame '+fragment)
    check(stdout==b'','worker success stdout absent')
    output=Path(leaf['output_directory']); worker_receipt=ROOT/owned['worker_receipt']; terminal_path=ACTUAL/'replay-owner-v1/ROOT-terminal-v1.json'
    check(not output.exists() and not worker_receipt.exists(),'exclusive worker output directory and whole controls receipt absent')
    check(not terminal_path.exists() and owner['worker_receipt'] is None and decision['worker'] is None,'no accepted owner terminal or worker alias')
    ledger_path=ROOT/owner['ownership_ledger']['path']
    ledger=json.loads(gzip.decompress(ledger_path.read_bytes()));scan(ledger)
    check(len(ledger['samples'])==owner['sampled_observations']==12,'entire twelve-sample ownership ledger retained')
    check(ledger['leftovers']=={} and owner['owned_leftovers']==[] and owner['cleanup_errors']==[]
          and owner['all_direct_children_terminal_and_reaped'] is True,'actual saved direct child reap and no observed leftovers, no observer cleanup error')
    check(owner['worker_returncode']==failure['worker_returncode']==1 and owner['error'] is None,'worker failure distinguishes owner supervisor error')
    check(ledger['kernel_worker_peak_bytes']==owner['worker_kernel_peak_bytes']==40321024,'same child wait4 maximum recorded')
    for number,sample in enumerate(ledger['samples']):
        rows=sample['owned_rows']; rss=sum(row['rss_bytes'] for row in rows.values())
        check(rss==sample['owned_rss_bytes'] and sample['combined_bytes']==sample['ROOT_peak_bytes']+rss+sample['observer_peak_bytes'],
              'retained owned-row integer memory sum '+str(number))
        check(all(row['birth']==ledger['final_retained_births'][pid] for pid,row in rows.items()),'saved same-PID birth identity '+str(number))
    computed_peak=max([owner['ROOT_peak_bytes']+owner['worker_kernel_peak_bytes']+owner['direct_children_peak_sum_bytes']+owner['observer_peak_bytes']]
                      +[s['combined_bytes'] for s in ledger['samples']])
    check(computed_peak==owner['peak_bytes']==58146816,'full owner plus disjoint worker/observer kernel peak and sampled maxima')
    check(owner['max_sampled_owned_rss_bytes']==max(s['owned_rss_bytes'] for s in ledger['samples']),'sampled worker maximum exact')
    check(owner['resource_gate_accepted'] is False and owner['cancelled'] is False and post['resource_gate_accepted'] is False
          and post['terminal'] is None,'failed worker prevents accepted conditional owner gate, no limit rescue')
    check(owner['elapsed_before_write_seconds']+2<60 and owner['peak_bytes']+8388608<536870912
          and post['elapsed_seconds']==1.604088667 and post['peak_bytes']==58195968,'saved observed within-limit envelope, no complete-stage resource acceptance')
    caller_seconds=(tool['terminal_observed_ms']-tool['started_ms'])/1000
    check(caller_seconds==decision['caller_elapsed_seconds']==failure['caller_seconds']==5.682,'genuine one-isolate caller request-to-terminal wall clock')
    check(len(tool['chunks'])==2 and tool['chunks'][0]['session_id']==37172
          and 'exit_code' not in tool['chunks'][0] and tool['chunks'][-1]['exit_code']==0
          and tool['chunks'][-1]['observed_ms']==tool['terminal_observed_ms'],'initial live handle plus final same-owned invocation terminal observation')
    print_record=json.loads(tool['terminal']['output'].strip().splitlines()[-1])
    check(print_record['resource_gate_accepted'] is False and print_record['terminal'] is None
          and print_record['elapsed_seconds']==post['elapsed_seconds'] and print_record['peak_bytes']==post['peak_bytes'],
          'complete terminal print matches failed postwrite values')
    reconstructed=dict(actual_tool_terminal=tool['terminal'].get('exit_code')==0,
        caller_clock_bound=0<=caller_seconds+1<=owned['limits']['caller_seconds'],owner_terminal_link_present=terminal_path.exists(),
        owner_gate=owner['resource_gate_accepted'] is True,post_write_gate=post['resource_gate_accepted'] is True,
        cancelled_at_final_print_false=print_record.get('cancelled_at_final_print') is False,
        final_print_gate=print_record.get('resource_gate_accepted') is True,stage_identity=False,worker_complete=False,
        all_worker_direct_children_closed=False,all_owner_direct_children_closed=owner['all_direct_children_terminal_and_reaped'] is True,
        no_owned_leftovers=owner['owned_leftovers']==[],complete_post_closure_unchanged=not decision['mismatches'],post_write_exact_terminal=False)
    check(reconstructed==decision['predicates'] and len(reconstructed)==14,'independent saved-only fourteen-predicate reconstruction, missing receipt remains failure')
    check(decision['ROOT_final_accepted'] is False and decision['status']=='UNKNOWN_complete_stage_qualification','final stage remains UNKNOWN, not accepted reaping evidence')
    check(failure['status']=='UNKNOWN_incomplete_real_family_controls' and failure['ROOT_complete_controls_accepted'] is False
          and failure['scientific_code_activated'] is True and failure['completed_control_cases']==0 and failure['accepted_partial_prefix'] is False
          and failure['actual_cold_invocations']==1,'ROOT typed failure retains actual activation and zero completed cases/no partial prefix')
    check(failure['owned_post_seconds']==post['elapsed_seconds'] and failure['conditional_observed_peak_bytes']==post['peak_bytes'],
          'ROOT failure preserves exact observed cost/peak provenance')
    check(failure['mathematical_target_acceptance'] is False and failure['target_searches']==0 and failure['RL_episodes']==0
          and failure['inventory_admission'] is False and failure['scientific_search_activation'] is False,'no theorem/search/RL/inventory/science admission from failed controls')

    checklist=save('saved-reconciliation-checklist-v1.json',dict(schema='saved-only-real-family-controls-reconciliation-checklist-v1',
        reviewer_identity='/root/arithmetic_induction',source_only=True,scientific_calls=0,
        owner=raw_pin(owner_source),saved_closer=raw_pin(close_source),current_source_review=raw_pin(HERE/'family-controls-typed-source-review-v1.json'),
        responsibilities=['Authenticate whole leaf/owner/source/input/review/current q/registry/admission bytes and explicit scope without executing project methods.',
            'Compare complete saved case/root/control/call/EOF/current union/rollback records only if genuinely produced; absent coverage remains absent.',
            'Reconcile all fourteen saved owned/caller predicates, direct-child wait4 records, birth-filtered owned samples, postwrite receipts and real tool terminal; do not replace a failed gate with clean reaping.',
            'Distinguish declared tests from completed tests, real current-domain checks from specialized nonlogical fixtures, and unrecorded partial progress from successful completion.',
            'Keep whole caller and enclosing owned/inner clocks inclusive; overlapping component spans are not additive pipeline costs.'],
        limits=expected_limits,authority=dict(mathematical_acceptance=False,resource_acceptance=False,ROOT_authority=False),
        limitations=['Raw saved-data and source consistency only; no independent semantic/physical replay or whole-host process observer.',
            'Runtime observer and kernel maximum records remain trusted components of the owned-source chain; no hard OS aggregate cap.',
            'Controls-only authorization does not activate a scientific receiver; future scientific cold worker must reject this scope.',
            'Repeated Gamma, aliased MP ports, actual zero markings and successful second-chain coverage remain unexercised unless a later actual stage records them.']))
    facts=dict(schema='independent-saved-failed-real-family-controls-findings-v1',reviewer_identity='/root/arithmetic_induction',
        worker_author_identity='/root/hilbert_advice_controls',review_scope='raw saved failure/closure/provenance plus static source explanation, no replay',
        all_checks_passed=not mismatches,mismatches=mismatches,scientific_calls=0,project_imports=0,semantic_replays=0,
        mathematical_authority_issued=False,resource_authority_issued=False,inventory_admission=False,scientific_consumer_activation=False,
        actual_status='UNKNOWN_incomplete_real_family_controls',complete_controls_accepted=False,accepted_partial_prefix=False,
        actual_invocations=1,completed_control_cases=0,complete_control_census=None,partial_ground_check_count=None,
        cases=case_metadata,source_map=leaf['sources'],checklist=checklist,
        saved_resource_predicates=reconstructed,resource_observations=dict(owned_post_seconds=post['elapsed_seconds'],caller_seconds=caller_seconds,
            postwrite_conservative_peak_bytes=post['peak_bytes'],worker_exit_code=owner['worker_returncode'],owner_tool_exit_code=tool['terminal']['exit_code'],
            observed_reaped=True,observed_owned_leftovers=[],complete_owned_resource_accepted=False,
            clock_scope='Inclusive scopes overlap; do not sum caller, owner or scientific component clocks.'),
        failure_explanation=dict(observed='Retained traceback rejects nonexact FunctionType in method_state(view) during first GoalDependencyAdvice constructor.',
            static_support='RecipeMetadataView inherits Sequence; pinned Python3.9 stdlib Iterable declares classmethod(GenericAlias), whose descriptor payload is a type rather than a Python function. The family MRO scan passes every such payload to its function-only guard.',
            specific_descriptor_recorded_by_worker=False,stdlib_source=stdlib_pin,
            boundary='The actual traceback does not record descriptor name or partial kernel-call count. No additional constructor/control calls were made by this reviewer.'),
        limitations=['No complete worker receipt, controls/evidence payload or accepted owner link exists.',
            'Exception-finally rollback source is present, but no completed saved rollback/census receipt is claimed.',
            'Both current q/admission records are preparatory metadata; second recipient controls did not complete.',
            'Source-pass prior to activation remains its historical prospective finding; this actual compatibility failure is additive and requires reviewed successor before any new attempt.'],
        evidence_roots=raw_roots,raw_pin_occurrences=len(references),unique_raw_pin_identities=len({(r['path'],r['sha256'],r['bytes']) for r in references}),
        static_ast_source_count=len(source_trees)+3,checks=checks,check_count=len(checks),
        metadata_helper_seconds_before_serialization=time.perf_counter()-began,
        helper_cost_scope='Authoring and saved-only metadata helper cost, not a scientific worker/search/checker or full process total.')
    receipt=save('family-controls-failed-actual-saved-findings-v1.json',facts)
    handoff=save('family-controls-failed-actual-saved-handoff-v1.json',dict(schema='independent-saved-failed-controls-handoff-v1',
        findings=receipt,checklist=checklist,helper=raw_pin(Path(__file__)),all_checks_passed=not mismatches,mismatches=mismatches,
        scientific_calls=0,actual_status=facts['actual_status'],ROOT_complete_controls_accepted=False,
        scope='Saved-only reconciliation, no mathematical/resource/ROOT authority or scientific activation.'))
    print(canonical(dict(findings=receipt,handoff=handoff,checklist=checklist,check_count=len(checks),mismatches=mismatches)))


if __name__=='__main__':
    main()
