"""Independent raw-byte/AST/source review; no project imports or calls."""
import ast
import copy
import difflib
import hashlib
import json
import time
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/equality-receptor-family-controls-independent-20261014'
PACKET=ROOT/'.gcts-active/equality-receptor-family-Sequence-guard-source-20261014'


def pin(path):
    path=Path(path); raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))


def save(name,value):
    path=HERE/name
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    return pin(path)


def definitions(tree):
    return {node.name:node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}


def constants(tree):
    return {node.targets[0].id:node.value for node in tree.body if isinstance(node,ast.Assign)
            and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)}


def dump(value):
    return ast.dump(value,include_attributes=False)


def main():
    began=time.perf_counter();checks=[];mismatches=[];refs=[]
    def check(value,label):
        checks.append(dict(name=label,passed=bool(value)))
        if not value:mismatches.append(label)
    def scan(value):
        if isinstance(value,dict):
            if set(value)=={'path','sha256','bytes'}:
                path=Path(value['path']);path=path if path.is_absolute() else ROOT/path
                actual=pin(path);actual['path']=value['path'];refs.append(value)
                check(actual==value,'exact raw pin '+value['path'])
            for item in value.values():scan(item)
        elif isinstance(value,list):
            for item in value:scan(item)
    def document(path):
        value=json.loads(Path(path).read_bytes());scan(value);return value
    handoff=document(PACKET/'handoff-v3.json')
    contract=document(PACKET/'source-contract-v3.json')
    conformance=document(PACKET/'source-conformance-v1.json')
    diagnosis=document(PACKET/'failed-control-source-diagnosis-v1.json')
    old_review=document(HERE/'family-controls-typed-source-review-v1.json')
    prior_findings=document(HERE/'family-controls-source-findings-v1.json')
    failed_findings=document(HERE/'family-controls-failed-actual-saved-findings-v1.json')
    sources=contract['sources'];scan(sources)
    check(sources==contract['source_review_ABI']['sources'] and len(sources)==20,'current contract/review exact twenty source roles, not stale predecessor ABI')
    changed_roles=[role for role in sources if sources[role]!=old_review['sources'][role]]
    check(sorted(changed_roles)==['family_advice','final_certificate','worker'],'three and only three raw source binding changes')
    check(old_review['source_only'] is True and old_review['source_review_passed'] is True
          and prior_findings['all_checks_passed'] is True,'completed inherited whole worker/mechanism Source review retained')
    check(failed_findings['all_checks_passed'] is True and failed_findings['actual_status']=='UNKNOWN_incomplete_real_family_controls'
          and failed_findings['accepted_partial_prefix'] is False,'actual failed compatibility evidence retained separately, not accepted')
    check(diagnosis['failed_actual_scope']['owned_post_seconds']==1.604088667
          and diagnosis['failed_actual_scope']['caller_seconds']==5.682
          and diagnosis['failed_actual_scope']['observed_peak_bytes']==58195968,'full failed attempt cost charged in new Source provenance')

    family_new=Path(sources['family_advice']['path']);family_old=Path(old_review['sources']['family_advice']['path'])
    worker_new=Path(sources['worker']['path']);worker_old=Path(old_review['sources']['worker']['path'])
    checker_new=Path(sources['final_certificate']['path']);checker_old=Path(old_review['sources']['final_certificate']['path'])
    old_family_tree=ast.parse(family_old.read_bytes());new_family_tree=ast.parse(family_new.read_bytes())
    old_worker_tree=ast.parse(worker_old.read_bytes());new_worker_tree=ast.parse(worker_new.read_bytes())
    old_checker_tree=ast.parse(checker_old.read_bytes());new_checker_tree=ast.parse(checker_new.read_bytes())
    for label,old,new,expected in [('family',old_family_tree,new_family_tree,['method_state']),
                                  ('worker',old_worker_tree,new_worker_tree,[]),('final_checker',old_checker_tree,new_checker_tree,[])]:
        a,b=definitions(old),definitions(new)
        check(set(a)==set(b),'same complete definition set '+label)
        changed=[name for name in a if dump(a[name])!=dump(b[name])]
        check(changed==expected,'only declared callable delta '+label)
    af,bf=constants(old_family_tree),constants(new_family_tree)
    check(set(bf)-set(af)=={'_NATIVE_GENERIC_ALIAS','_ITERABLE_CLASS_GETITEM'}
          and all(dump(af[name])==dump(bf[name]) for name in af),'all prior family constants/donor/training/receiver metadata unchanged plus two native identity anchors')
    imports=[node for node in new_family_tree.body if isinstance(node,ast.ImportFrom) and node.module=='collections.abc']
    check(len(imports)==1 and [(x.name,x.asname) for x in imports[0].names]==[('Iterable','_StdlibIterable')],
          'single explicit trusted stdlib Iterable import, no new project module import')
    check(dump(bf['_NATIVE_GENERIC_ALIAS'])==dump(ast.parse('type(list[int])',mode='eval').body)
          and dump(bf['_ITERABLE_CLASS_GETITEM'])==dump(ast.parse("vars(_StdlibIterable)['__class_getitem__']",mode='eval').body),
          'native payload and exact descriptor captured before future external calls')
    check(dump(definitions(old_family_tree)['guard_state'])==dump(definitions(new_family_tree)['guard_state']),
          'delegated Python guard exact FunctionType/code/default/kwdefault/closure guard unchanged')
    aw,bw=constants(old_worker_tree),constants(new_worker_tree)
    check(set(aw)==set(bw) and [name for name in aw if dump(aw[name])!=dump(bw[name])]==['FROZEN_SOURCES'],
          'worker only raw source-map constant changes, all limits/input/output/runtime/authority unchanged')
    frozen=ast.literal_eval(bw['FROZEN_SOURCES'])
    check(dict(frozen,worker=pin(worker_new))==sources,'literal worker nineteen inherited roles plus self equals new whole twenty map')
    ac,bc=constants(old_checker_tree),constants(new_checker_tree)
    check(set(ac)==set(bc) and [name for name in ac if dump(ac[name])!=dump(bc[name])]==['FAMILY_SOURCE'],
          'final checker only family raw source literal changes')
    check(ast.literal_eval(bc['FAMILY_SOURCE'])==sources['family_advice'],'final checker resolves same repaired family, no mechanism transplant')
    for label,old,new,name in [('worker',old_worker_tree,new_worker_tree,'FROZEN_SOURCES'),
                              ('checker',old_checker_tree,new_checker_tree,'FAMILY_SOURCE')]:
        normalized=copy.deepcopy(new)
        for node in normalized.body:
            if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id==name:
                node.value=copy.deepcopy(constants(old)[name])
        check(dump(normalized)==dump(old),'entire normalized module AST exact '+label)
    normalized=copy.deepcopy(new_family_tree)
    normalized.body=[node for node in normalized.body if not (isinstance(node,ast.ImportFrom) and node.module=='collections.abc')
        and not (isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)
                 and node.targets[0].id in ('_NATIVE_GENERIC_ALIAS','_ITERABLE_CLASS_GETITEM'))]
    normalized.body=[copy.deepcopy(definitions(old_family_tree)['method_state']) if isinstance(node,ast.FunctionDef) and node.name=='method_state' else node
                     for node in normalized.body]
    check(dump(normalized)==dump(old_family_tree),'entire family AST exact after removing native anchors and reversing one reviewed guard method')
    family_text=family_new.read_text();old_family_text=family_old.read_text()
    new_method=ast.get_source_segment(family_text,definitions(new_family_tree)['method_state'])
    old_method=ast.get_source_segment(old_family_text,definitions(old_family_tree)['method_state'])
    inverse=family_text.replace('from collections.abc import Iterable as _StdlibIterable\n\n_NATIVE_GENERIC_ALIAS = type(list[int])\n_ITERABLE_CLASS_GETITEM = vars(_StdlibIterable)[\'__class_getitem__\']\n','',1).replace(new_method,old_method,1)
    check(inverse==old_family_text,'whole family raw byte inverse restores exact original, no hidden textual changes')
    patch_pairs=[('family-v2-to-v3.patch',family_old,family_new),('control-worker-v2-to-v3.patch',worker_old,worker_new),
                 ('final-checker-v3-to-v4.patch',checker_old,checker_new)]
    for name,old,new in patch_pairs:
        actual=''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old),tofile=str(new)))
        check((PACKET/name).read_text()==actual,'full independent literal patch correspondence '+name)
    method=new_method
    required_native_tokens=("owner is _StdlibIterable and name == '__class_getitem__'",'type(descriptor) is classmethod',
        'descriptor is _ITERABLE_CLASS_GETITEM','descriptor.__func__ is _NATIVE_GENERIC_ALIAS','types.GenericAlias is _NATIVE_GENERIC_ALIAS',
        'function is _NATIVE_GENERIC_ALIAS',"vars(_StdlibIterable).get(name) is _ITERABLE_CLASS_GETITEM")
    for token in required_native_tokens:check(token in method,'native exception exact anchor '+token)
    check(method.index("if owner is _StdlibIterable and name == '__class_getitem__':")<method.index('if isinstance(descriptor, property):'),
          'reserved native slot rejected before property/function dispatch or initial endpoint cache')
    for token in ("need(name not in namespace, 'no ordinary instance method shadow: '+name)",
                  'type(effective) is types.MethodType and effective.__self__ is receiver',
                  "effective.__func__ is function, 'same effective method'",'tuple(guard_state(f) for f in functions)',
                  'if type(function) is types.FunctionType:',"executable = ('stdlib-Iterable-GenericAlias-identity', _NATIVE_GENERIC_ALIAS)"):
        check(token in method,'unchanged effective Python/property or exact native identity boundary '+token)
    check('effective(' not in method and 'function(' not in method,'native typing helper is inspected, never invoked by guard')
    check('all project validators and Python accessors remain strict' in method,
          'exception scope excludes other native wrappers and delegated project validators')
    worker_text=worker_new.read_text()
    check('for name, value in vars(module).items():' in worker_text and 'add(module, name, value)' in worker_text
          and "actual is original, 'compiled namespace/function identity changed'" in worker_text,
          'cold executable snapshot retains newly captured native/Iterable/descriptor globals as identity-bound module values')
    check(contract['limits']==dict(caller_seconds=90,control_seconds=20,peak_bytes=536870912,whole_seconds=60),
          'unchanged shared20/owned60/512MiB/caller90')
    check(contract['ABI']['leaf_count']==11 and contract['ABI']['owner_count']==10 and len(contract['entrypoint']['argv'])==6
          and contract['ABI']['source_roles']==20,'strict eleven leaf/ten owner/six argv/twenty raw roles unchanged')
    check(contract['entrypoint']['worker']==sources['worker'] and contract['entrypoint']['callable']['source']==sources['mechanism_controls'],
          'entrypoint selected current worker and unchanged full mechanism')
    check(contract['source_review_ABI']['scope']=='actual-two-I2-family-ground-domain-controls'
          and contract['source_review_ABI']['author_identity']=='/root/hilbert_advice_controls','required typed Source review scope and actual author')
    check(contract['authorization_scope']['scientific_library_admission'].startswith('Still absent.'),
          'control pass cannot grant scientific finite advice activation')
    check(contract['regression_requests_executed']==0 and handoff['tests_executed']==0 and handoff['scientific_calls']==0,
          'prospective native mutation controls are unexecuted, not reported actual passes')
    check(sources['certificate']==old_review['sources']['certificate'] and sources['logical_oracle']==old_review['sources']['logical_oracle']
          and sources['streamed_dfs']==old_review['sources']['streamed_dfs'] and sources['mechanism_controls']==old_review['sources']['mechanism_controls'],
          'reader/kernel/scheduler/advice composition/control bodies unchanged; empty inventory and fallback scope inherited')

    finding=save('family-controls-sequence-source-findings-v1.json',dict(schema='independent-Sequence-native-guard-source-findings-v1',
        author_identity='/root/hilbert_advice_controls',reviewer_identity='/root/arithmetic_induction',scope='actual-two-I2-family-ground-domain-controls',
        source_only=True,source_review_passed=not mismatches,all_checks_passed=not mismatches,mismatches=mismatches,
        scientific_calls=0,project_imports=0,source_function_calls=0,tests_executed=0,actual_controls_accepted=False,
        mathematical_authority_issued=False,resource_authority_issued=False,scientific_consumer_activation=False,inventory_admission=False,
        sources=sources,handoff=pin(PACKET/'handoff-v3.json'),contract=pin(PACKET/'source-contract-v3.json'),
        inherited_review=pin(HERE/'family-controls-typed-source-review-v1.json'),inherited_whole_findings=pin(HERE/'family-controls-source-findings-v1.json'),
        preserved_failed_reconciliation=pin(HERE/'family-controls-failed-actual-saved-findings-v1.json'),
        preserved_failed_cost=dict(owned_post_seconds=1.604088667,caller_seconds=5.682,observed_peak_bytes=58195968,
            complete_controls_accepted=False,accepted_partial_prefix=False,partial_ground_check_count=None,clock_scopes_overlap=True),
        changed_source_roles=changed_roles,changed_family_definition='method_state',worker_definitions_unchanged=True,checker_definitions_unchanged=True,
        assessment=['The sole non-Python exception requires the captured stdlib Iterable owner/name/classmethod/descriptor/native payload and exact effective bound receiver/function; every other nonfunction wrapped endpoint rejects.',
            'Reserved descriptor replacement is checked before cache capture; Python function/property/code/default/closure and ordinary method shadow tests retain their original implementation.',
            'All extraction/ground receptor expansion/original-Gamma/current fixed point union/full fallback/global scheduler/rollback semantic callables are identical.',
            'New q/control-only admission/registry/source epochs must be rebuilt by ROOT for these exact pins; no previously activated epoch may be transplanted.',
            'Prior prospective Source assessment did not establish compatibility. Actual V2 constructor failure remains UNKNOWN and its entire cost is preserved.'],
        limitations=['Source-only conditional disposition, not an actual constructor/controls or native/mathematical acceptance.',
            'New prospective native slot/property/payload/alias/shadow mutation controls have not run.',
            'Inherited controls remain scoped to current two recipient contexts; repeated Gamma, aliased MP ports, actual-zero markings and successful second-chain checks remain unexercised.',
            'Scientific receiver must separately reject controls-only scope and require its own genuine actual controls/admission gate. Current scientific cold integration is pending.'],
        raw_pin_occurrences=len(refs),raw_pin_identity_count=len({(x['path'],x['sha256'],x['bytes']) for x in refs}),
        checks=checks,check_count=len(checks),metadata_helper_seconds_before_serialization=time.perf_counter()-began))
    typed=save('family-controls-sequence-typed-source-review-v1.json',dict(schema='independent-real-family-controls-source-review-v1',
        scope='actual-two-I2-family-ground-domain-controls',source_only=True,source_ready=True,source_review_passed=not mismatches,
        all_checks_passed=not mismatches,mismatches=mismatches,scientific_calls=0,project_imports=0,tests_executed=0,
        author_identity='/root/hilbert_advice_controls',reviewer_identity='/root/arithmetic_induction',sources=sources,
        findings=finding,contract=pin(PACKET/'source-contract-v3.json'),handoff=pin(PACKET/'handoff-v3.json'),
        conditional_scope='Exact narrow Source repair only. No actual controls completion, finite advice scientific admission, mathematical or resource authority.',
        inherited_source_review=pin(HERE/'family-controls-typed-source-review-v1.json'),
        preserved_failed_actual_reconciliation=pin(HERE/'family-controls-failed-actual-saved-findings-v1.json')))
    out=save('family-controls-sequence-source-review-handoff-v1.json',dict(schema='independent-Sequence-native-guard-source-review-handoff-v1',
        typed_review=typed,findings=finding,helper=pin(Path(__file__)),all_checks_passed=not mismatches,mismatches=mismatches,
        scientific_calls=0,source_only=True,source_review_passed=not mismatches))
    print(json.dumps(dict(typed_review=typed,findings=finding,handoff=out,check_count=len(checks),mismatches=mismatches),sort_keys=True))


if __name__=='__main__':
    main()
