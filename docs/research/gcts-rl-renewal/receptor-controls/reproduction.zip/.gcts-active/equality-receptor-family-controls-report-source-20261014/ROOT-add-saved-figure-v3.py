"""Saved display Source only; no semantic code import or call."""
from pathlib import Path
import json,hashlib,difflib,zipfile
root=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');pub=Path('/private/tmp/gcts-family-router-publish-20261010');src=root/'.gcts-active/equality-receptor-family-controls-report-source-20261014';out=pub/'docs/research/gcts-rl-renewal/receptor-controls'
p=out/'viewer.js';old=p.read_text()
function=r'''function drawGroundRows(rows) {
  const y = row => 35 + row * 52;
  const height = y(Math.max(...rows.map(row=>row.physical_row))) + 40;
  const parts = [`<svg class="diagram" viewBox="0 0 350 ${height}" role="img" aria-label="Six actual saved point-tile placements and their ordered remote formula reads">`];
  rows.forEach(row => row.ordered_prior_rows.forEach((ref,port) => {
    const color=port===0?'#16887e':'#8861aa', x=205+port*65;
    parts.push(`<path d="M ${x} ${y(row.physical_row)} V ${y(ref)} H 145" fill="none" stroke="${color}" stroke-width="2"/><path d="M 145 ${y(row.physical_row)} H ${x}" fill="none" stroke="${color}" stroke-width="2"/><circle cx="${x}" cy="${y(row.physical_row)}" r="5" fill="${color}"/>`);
  }));
  rows.forEach(row => {
    const cy=y(row.physical_row), color=row.command.rule==='assumption'?'#2472ac':'#16887e';
    parts.push(`<text x="10" y="${cy+4}" font-family="system-ui,sans-serif" font-size="12" fill="#586575">${escapeText(row.label)}</text><rect x="95" y="${cy-22}" width="44" height="44" fill="white" stroke="${color}" stroke-width="2"/><circle cx="117" cy="${cy}" r="4" fill="#364250"/><circle cx="145" cy="${cy}" r="5" fill="#2472ac"/>`);
  });
  parts.push('</svg>');
  return `<figure id="ground-geometry">${parts.join('')}<figcaption>Actual saved primitive placements. Blue points carry formula codes; green and purple links follow the ordered prior-row reads. Squares illustrate unit point supports; horizontal spacing is schematic. This ground expansion was checked, with no macro execution or completed board.</figcaption></figure>`;
}
'''
s=old.replace('function renderGroundRows(rows) {',function+'function renderGroundRows(rows) {')
s=s.replace('return rows.map(row => `<article class="line"><h3>', 'return drawGroundRows(rows) + rows.map(row => `<article class="line"><h3>',1)
s=s.replace('original_Gamma_occurrences:row.original_Gamma_occurrences', 'dependency_consumed_original_Gamma:row.original_Gamma_occurrences')
p.write_text(s)
patch=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='previous-viewer.js',tofile='selected-viewer.js'))
(src/'ROOT-reader-figure-delta-v3.patch').write_text(patch)
p=out/'reader.html';s=p.read_text().replace('<div id="ground-rows">', '<p>The full original hypotheses are retained. The conclusion consumes original occurrence indices <code>1</code> and <code>2</code>; occurrence <code>0</code> remains in the displayed commands without contributing to the conclusion. This is one body reused in two contexts, not two new theorem discoveries.</p>\n    <div id="ground-rows">')
p.write_text(s)
def pin(p):
 b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
m=out/'source-archive-manifest.json';v=json.loads(m.read_bytes())
for a in v['members']:
 if a['archive_path'].startswith('PUBLIC/'):
  a.update(pin(Path(a['path'])))
for p in (src/'ROOT-add-saved-figure-v3.py',src/'ROOT-reader-figure-delta-v3.patch'):
 v['members'].append(dict(archive_path=str(p.relative_to(root)),**pin(p)))
# Regenerate complete archive, preserving every earlier frozen member and README.
with zipfile.ZipFile(out/'reproduction.zip') as z:readme=z.read('README.txt')
with zipfile.ZipFile(out/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for a in v['members']:
  b=Path(a['path']).read_bytes();assert len(b)==a['bytes'] and hashlib.sha256(b).hexdigest()==a['sha256'];z.writestr(a['archive_path'],b)
 z.writestr('README.txt',readme)
m.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
files=[p for p in out.iterdir() if p.is_file()]+[pub/'docs/research/gcts-rl-renewal/index.html']
v=dict(schema='ROOT-notebook158-task-publication-manifest-v3',files=[dict(relative=str(p.relative_to(pub)),**pin(p)) for p in sorted(files)],actual_cold_invocations=2,actual_control_census_complete=True,scientific_calls=0)
(src/'ROOT-notebook158-task-manifest-v3.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(files=len(files),saved_figure=True,scientific_calls=0)))
