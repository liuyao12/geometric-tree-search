"""ROOT saved-evidence presentation/archive only; no scientific code import."""
import hashlib, json, shutil, zipfile
from pathlib import Path
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
PUB=Path('/private/tmp/gcts-family-router-publish-20261010')
SRC=ROOT/'.gcts-active/equality-receptor-family-controls-report-source-20261014'
OUT=PUB/'docs/research/gcts-rl-renewal/receptor-controls'
OLD=ROOT/'.gcts-active/equality-receptor-family-controls-progress-20261014'
NEW=ROOT/'.gcts-active/equality-receptor-family-controls-progress-v2-20261014'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def cost(label,value,unit='',scope='Saved observed cost; nested clocks are not added.'):
 return dict(label=label,value=value,unit_latex=unit,scope=scope)
def term(v):
 assert v[0] in ('fun','var')
 name=v[1].replace('_',r'\_')
 return r'\mathrm{'+name+'}'+('('+','.join(term(a) for a in v[2])+')' if v[0]=='fun' and v[2] else '')
def formula(v):
 if v[0]=='pred':return r'\operatorname{'+v[1]+'}('+','.join(term(a) for a in v[2])+')'
 if v[0]=='eq':return term(v[1])+'='+term(v[2])
 if v[0]=='not':return r'\neg\bigl('+formula(v[1])+r'\bigr)'
 if v[0] in ('imp','and','or'):
  return r'\bigl('+formula(v[1])+{'imp':r'\to ','and':r'\land ','or':r'\lor '}[v[0]]+formula(v[2])+r'\bigr)'
 raise ValueError('Unsupported saved display formula')
def words(v):
 if v[0]=='pred':
  names=[a[1] for a in v[2]]
  if v[1]=='Point':return names[0]+' is a point'
  if v[1]=='Line':return names[0]+' is a line'
  if v[1]=='Incident':return names[0]+' is incident with '+names[1]
 if v[0]=='eq':return v[1][1]+' equals '+v[2][1]
 if v[0]=='not':return 'it is not the case that '+words(v[1])
 if v[0]=='and':return words(v[1])+' and '+words(v[2])
 if v[0]=='imp':return 'if ('+words(v[1])+'), then ('+words(v[2])+')'
 raise ValueError('Unsupported saved English display formula')
def attempt(p,version):
 d=read(p/'replay-ROOT-final-decision-v1.json');o=read(p/'replay-owner-v1/provisional-terminal-v1.json');post=read(p/'replay-owner-v1/post-write-observation-v1.json')
 accepted=d['ROOT_final_accepted'];err=(p/'replay-owner-v1/stderr-v1.txt').read_text()
 return dict(label=version,version=version,status='Complete scoped controls' if accepted else 'UNKNOWN: incomplete controls',owned_seconds=post['elapsed_seconds'],caller_seconds=d['caller_elapsed_seconds'],peak_MiB=post['peak_bytes']/1048576,completed_cases=2 if accepted else 0,explanation='Both current-recipient controls completed; no scientific search activated.' if accepted else err.strip().splitlines()[-1],saved_scope=dict(ROOT_final_accepted=accepted,predicates=d['predicates'],all_owner_direct_children_terminal_and_reaped=o['all_direct_children_terminal_and_reaped'],owned_leftovers=o['owned_leftovers'],accepted_partial_prefix=False,searches=0,RL_episodes=0))
def main():
 assert not OUT.exists();OUT.mkdir()
 packet=read(SRC/'summary.source.json');packet['attempts']=[attempt(OLD,'Worker V2 / receiver V2')]
 has_new=(NEW/'replay-ROOT-final-decision-v1.json').exists()
 if has_new:packet['attempts'].append(attempt(NEW,'Worker V3 / receiver guard V3'))
 latest=NEW if has_new else OLD
 d=read(latest/'replay-ROOT-final-decision-v1.json');accepted=d['ROOT_final_accepted']
 packet['actual_control_census_complete']=accepted;packet['ROOT_resource_closed']=accepted
 packet['ground_rows']=[];packet['costs']=[]
 for a in packet['attempts']:
  packet['costs'] += [cost(a['version']+' · cold owned lifetime',a['owned_seconds'],r'\mathrm{s}'),cost(a['version']+' · caller interval',a['caller_seconds'],r'\mathrm{s}','Observed before separate one-second caller finish margin.'),cost(a['version']+' · conditional observed peak',a['peak_MiB'],r'\mathrm{MiB}','Pinned owner/observer/worker accounting; no hard OS cap or whole-host completeness claim.')]
 packet['control_results']=[cost('Actual cold invocations',len(packet['attempts']),scope='Separate reviewed source versions; failed attempts retained.'),cost('Complete recipient controls',2 if accepted else 0,scope='No accepted partial prefix.'),cost('Complete resource/stage gate','Accepted' if accepted else 'UNKNOWN',scope='All fourteen saved predicates required.'),cost('Scientific family-search episodes',0,scope='Controls-only grants do not activate search.'),cost('RL episodes',0,scope='No training or learned policy in these controls.')]
 if accepted:
  controls=read(NEW/'worker-output-v1/actual-family-controls-v1.json');assert controls['completed'] and len(controls['case_controls'])==2
  packet['control_results'].append(cost('Actual control checks',controls['actual_check_count'],scope='Mandatory mechanical and ground-instance cases; not theorem discoveries.'))
  packet['lead']='The fresh guard successor completed both finite recipient controls, including complete chosen-domain fallback, pending reads, forced/dead fixtures, distant markings and exact rollback. The initial constructor failure and all costs remain below. Family search, inventory admission and performance comparisons remain unactivated.'
  packet['status_text']='Both scoped receiver controls passed; scientific search comparison remains pending.'
  packet['costs'].append(cost('Successful shared inner controls',controls['inner_complete_seconds'],r'\mathrm{s}','Input loading, static qualification, graph construction and both case calls before final census guards; output serialization remains in the enclosing owned clock.'))
  first=controls['case_controls'][0]['full_controls']['all_checked_ground_instances'][0]
  second=controls['case_controls'][1]['full_controls']['all_checked_ground_instances'][0]
  assert first['commands']==second['commands'] and first['primitive_keys']==second['primitive_keys']
  marks={(x,y):m for x,y,m in first['literal_points']['m']}
  for index,(command,key) in enumerate(zip(first['commands'],first['primitive_keys'])):
   recipe,row,refs=key
   points=[[1,row,marks[1,row]]]+[[1,ref,marks[1,ref]] for ref in refs]+[[2+port,row,ref-row] for port,ref in enumerate(refs)]
   rule=command['rule']
   reason='Retain original hypothesis occurrence '+str(command['index'])+'.' if rule=='assumption' else 'Use the licensed equality-substitution instance.' if rule=='eq_subst' else 'Apply modus ponens to local lines '+str(command['antecedent']+1)+' and '+str(command['implication']+1)+'.'
   packet['ground_rows'].append(dict(label='Local line '+str(index+1),formula_latex=formula(command['formula']),formula_english=words(command['formula'])+'.',derivation_english=reason,origin_scope='Same saved fresh ground body in both current contexts. Its conclusion is incidence with v; neither original target was searched or accepted in these controls.',command=command,physical_row=row,ordered_prior_rows=refs,t=[[0,row,1]],m=points,original_Gamma_occurrences=first['consumed_original_occurrence_indices'],recipe=recipe))
  shutil.copyfile(NEW/'worker-output-v1/actual-family-controls-v1.json',OUT/'controls.json')
 else:
  packet['lead']='Actual receiver-control attempts are preserved below. The latest attempt remains incomplete; no control census or usable prefix is accepted. The defects and costs are recorded before further source work.'
  packet['status_text']='Actual controls remain UNKNOWN; no completed census or admitted library.'
 shutil.copyfile(OLD/'ROOT-actual-family-controls-failure-disposition-v1.json',OUT/'first-failure.json')
 shutil.copyfile(latest/'replay-ROOT-final-decision-v1.json',OUT/'resource-qualification.json')
 shutil.copyfile(latest/'ROOT-actual-family-controls-disposition-v1.json' if accepted else OLD/'ROOT-actual-family-controls-failure-disposition-v1.json',OUT/'qualification.json')
 saved_review=ROOT/'.gcts-active/equality-receptor-family-controls-independent-20261014/family-controls-failed-actual-saved-findings-v1.json'
 shutil.copyfile(saved_review,OUT/'failed-saved-review.json')
 if accepted:
  shutil.copyfile(ROOT/'.gcts-active/equality-receptor-family-controls-independent-20261014/family-controls-complete-actual-saved-findings-v1.json',OUT/'complete-saved-review.json')
 for name in ('reader.html','reader.css','viewer.js','workflow.svg'):shutil.copyfile(SRC/name,OUT/name)
 js=(OUT/'viewer.js').read_text().replace("fetch('summary.source.json')","fetch('summary.json')").replace("No actual ground-row packet is attached.","No complete ground-row display is attached at this checkpoint; inspect the raw controls and earlier donor reader.")
 (OUT/'viewer.js').write_text(js)
 html=(OUT/'reader.html').read_text().replace('The actual record, when attached.','What the actual record establishes.').replace('This page reserves the record of those controls; it does not turn source review into an executed experiment.','This page records the actual controls and their limits. Source review, runtime controls and proof discovery retain separate records.').replace('No new geometry RL episode, policy update, search-speed advantage, prover superiority or universal proof palette is established by this scaffold.','These controls establish no new geometry RL episode, policy update, search-speed advantage, prover superiority or universal proof palette.').replace('The pending packet is informational presentation data, not an activation or scientific admission schema.','The packet is saved presentation data, not an activation or scientific admission schema.')
 (OUT/'reader.html').write_text(html)
 svg=(OUT/'workflow.svg').read_text().replace('All results remain pending','Fresh ground checks required');(OUT/'workflow.svg').write_text(svg)
 records={};external={}
 def add(p,expected=None):
  p=Path(p);p=p if p.is_absolute() else ROOT/p
  a=pin(p)
  if expected:assert a['sha256']==expected['sha256'] and a['bytes']==expected['bytes']
  if ROOT not in p.parents:external[str(p)]=a;return
  records[str(p.relative_to(ROOT))]=a
 for progress in (OLD,NEW) if has_new else (OLD,):
  for r in read(progress/'worker-plan-v1.json')['closure']:add(r['path'],r)
  for p in progress.rglob('*'):
   if p.is_file():add(p)
 named_folders=('equality-receptor-family-Sequence-guard-source-20261014','equality-receptor-family-controls-independent-20261014','equality-receptor-family-controls-metadata-independent-20261014','equality-receptor-family-controls-ROOT-source-20261014','equality-receptor-family-controls-report-source-20261014')
 for folder in named_folders:
  for p in (ROOT/'.gcts-active'/folder).glob('*'):
   if p.is_file():add(p)
 archive_manifest=dict(schema='Notebook158-exact-source-archive-v1',members=[dict(archive_path=k,**v) for k,v in sorted(records.items())],runtime_hash_references=list(external.values()),presentation_only=True,scientific_calls=0)
 write(OUT/'source-archive-manifest.json',archive_manifest)
 with zipfile.ZipFile(OUT/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,p in sorted(records.items()):
   raw=Path(p['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==p['sha256'];z.writestr(name,raw)
  z.writestr('README.txt','Notebook158 retained cold records and exact Sources. Both namespaces are immutable historical attempts. Source-only readiness is distinct from activated controls. Reproduction requires a fresh namespace and requalification of absolute Source/input/runtime paths; never rerun a once-only plan in place. Runtime binaries are hash references, not bundled. Mechanical pending/forced/dead fixtures are nonlogical interventions. No theorem discovery, scientific family search, inventory admission, universal schema, RL or performance advantage is established by these control records.\n')
 packet['evidence_links']=[dict(label='Scoped ROOT control disposition',href='qualification.json'),dict(label='All fourteen resource predicates',href='resource-qualification.json'),dict(label='Preserved first failure',href='first-failure.json'),dict(label='Independent saved-failure review',href='failed-saved-review.json'),dict(label='Sources, named inputs and all actual attempts',href='reproduction.zip'),dict(label='Exact archive hashes',href='source-archive-manifest.json')]
 if accepted:packet['evidence_links'].insert(0,dict(label='Complete actual controls',href='controls.json'))
 if accepted:packet['evidence_links'].insert(1,dict(label='Independent complete saved-evidence review',href='complete-saved-review.json'))
 packet['provenance']=[pin(OUT/'qualification.json'),pin(OUT/'first-failure.json')]
 write(OUT/'summary.json',packet)
 hub=PUB/'docs/research/gcts-rl-renewal/index.html';s=hub.read_text().replace('RESEARCH NOTEBOOK · 157','RESEARCH NOTEBOOK · 158')
 panel='''<section class="panel" id="receptor-controls">
  <p class="eyebrow">NOTEBOOK 158 · PARALLEL DEVELOPMENT AND ACTUAL RECEIVER CONTROLS</p>
  <h2>Check the lemma receiver before measuring reuse.</h2>
  <p>Separate agents prepare receptor integration, arithmetic quantification and independent review/display; ROOT coordinates actual activation, shared measurements and publication. The control record preserves the initial inherited-interface failure and any reviewed successor result. Controls alone establish no proof-search or RL advantage.</p>
  <p><a href="receptor-controls/reader.html?v=n158#results">Inspect actual outcomes, all attempt costs and the four work streams</a>.</p>
</section>
'''
 s=s.replace('<section class="panel" id="receptor-extraction">',panel+'<section class="panel" id="receptor-extraction">',1)
 s=s.replace('Notebook157 completes candidate extraction and independent ground auditing; current receiver integration remains source work.','Notebook157 completed candidate extraction and independent ground auditing; Notebook158 records actual receiver controls and retained failures.')
 hub.write_text(s)
 files=[p for p in OUT.iterdir() if p.is_file()]+[hub]
 write(SRC/'ROOT-notebook158-task-manifest-v1.json',dict(schema='ROOT-notebook158-task-publication-manifest-v1',files=[dict(relative=str(p.relative_to(PUB)),**pin(p)) for p in sorted(files)],actual_cold_invocations=len(packet['attempts']),actual_control_census_complete=accepted,archive_members=len(records),scientific_calls=0))
 print(json.dumps(dict(output=str(OUT),files=len(files),archive_members=len(records),archive_bytes=(OUT/'reproduction.zip').stat().st_size,actual_control_census_complete=accepted)))
if __name__=='__main__':main()
