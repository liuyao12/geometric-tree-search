/* Saved presentation only. No scientific implementation, authority or tests. */
'use strict';
const byId = id => document.getElementById(id);
const escapeText = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const math = value => `\\(${escapeText(value)}\\)`;
const pending = text => `<p class="pending">${escapeText(text)}</p>`;
function safeLink(value) {
  const url = new URL(value, location.href);
  if (url.origin !== location.origin || !['http:', 'https:'].includes(url.protocol)) throw Error('Evidence link must stay on the report origin');
  return escapeText(url.href);
}
function shownValue(row) {
  if (row.value === null || row.value === undefined) return 'Unavailable';
  if (typeof row.value !== 'number' || !Number.isFinite(row.value)) return escapeText(row.value);
  return math(`${row.value}${row.unit_latex ? `\\,${row.unit_latex}` : ''}`);
}
function table(rows, heading) {
  if (!rows.length) return pending(`${heading}: pending attachment.`);
  return `<table><thead><tr><th>Saved scope</th><th>Recorded result</th><th>Qualification</th></tr></thead><tbody>${rows.map(row => `<tr><td>${escapeText(row.label)}</td><td>${shownValue(row)}</td><td>${escapeText(row.scope || '')}</td></tr>`).join('')}</tbody></table>`;
}
function renderAttempts(rows) {
  if (!rows.length) return pending('Saved attempt records have not been attached.');
  const number = (value, unit = '') => value === null || value === undefined ? 'Pending' : math(`${value}${unit ? `\\,${unit}` : ''}`);
  const overview = `<table><thead><tr><th>Version</th><th>Status</th><th>Whole owned</th><th>Caller</th><th>Observed peak</th><th>Completed cases</th></tr></thead><tbody>${rows.map(row => `<tr><td>${escapeText(row.version)}</td><td>${escapeText(row.status)}</td><td>${number(row.owned_seconds, '\\mathrm{s}')}</td><td>${number(row.caller_seconds, '\\mathrm{s}')}</td><td>${number(row.peak_MiB, '\\mathrm{MiB}')}</td><td>${number(row.completed_cases)}</td></tr>`).join('')}</tbody></table>`;
  return overview + rows.map(row => `<details><summary>${escapeText(row.label)}</summary><p>${escapeText(row.explanation || '')}</p><pre>${escapeText(JSON.stringify(row.saved_scope || {}, null, 2))}</pre></details>`).join('');
}
function renderGroundRows(rows) {
  if (!rows.length) return pending('No actual ground-row packet is attached.');
  return rows.map(row => `<article class="line"><h3>${escapeText(row.label)}</h3><div class="formula">${math(row.formula_latex)}</div><p>${escapeText(row.formula_english)}</p><p>${escapeText(row.derivation_english)}</p><p class="muted">${escapeText(row.origin_scope)}</p><details><summary>Exact saved command, point values and ordered reads</summary><pre>${escapeText(JSON.stringify({command:row.command, physical_row:row.physical_row, ordered_prior_rows:row.ordered_prior_rows, t:row.t, m:row.m, original_Gamma_occurrences:row.original_Gamma_occurrences}, null, 2))}</pre></details></article>`).join('');
}
async function typeset() {
  if (window.MathJax?.startup?.promise) {
    await MathJax.startup.promise;
    await MathJax.typesetPromise([document.querySelector('main')]);
  }
}
async function main() {
  // Only ROOT-supplied saved display data are attached; no new scientific calls.
  const response = await fetch('summary.source.json');
  if (!response.ok) throw Error(`Display packet HTTP ${response.status}`);
  const packet = await response.json();
  if (packet.schema !== 'Notebook158-saved-display-packet-v1' || packet.notebook !== 158 || packet.presentation_only !== true) throw Error('Unexpected display packet');
  if (!['pending','actual'].includes(packet.display_state)) throw Error('Unknown display state');
  if (packet.display_state === 'pending') {
    byId('status').textContent = 'SOURCE scaffold. Actual control records and measured values are pending attachment.';
    byId('result-lead').textContent = packet.lead;
    await typeset();
    return;
  }
  // These are saved ROOT presentation fields, never fresh checker acceptance.
  for (const field of ['control_results','costs','attempts','ground_rows','evidence_links']) if (!Array.isArray(packet[field])) throw Error(`Missing whole display array: ${field}`);
  byId('status').textContent = packet.status_text || 'Saved actual records attached. Each outcome retains its own scope.';
  byId('result-lead').textContent = packet.lead;
  byId('control-results').innerHTML = table(packet.control_results, 'Control outcomes');
  byId('control-costs').innerHTML = table(packet.costs, 'Measured costs');
  byId('attempt-records').innerHTML = renderAttempts(packet.attempts);
  byId('ground-rows').innerHTML = renderGroundRows(packet.ground_rows);
  byId('evidence-links').innerHTML = packet.evidence_links.length ? `<p>${packet.evidence_links.map(row => `<a href="${safeLink(row.href)}">${escapeText(row.label)}</a>`).join(' · ')}</p>` : pending('No frozen evidence links have been attached.');
  await typeset();
}
main().catch(error => { byId('status').textContent = `Display unavailable: ${error.message}. No runtime result is inferred.`; });
