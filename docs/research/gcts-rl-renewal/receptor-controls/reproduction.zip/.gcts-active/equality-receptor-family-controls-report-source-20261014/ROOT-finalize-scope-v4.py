"""ROOT saved presentation scope correction, no scientific calls."""
from pathlib import Path
import json,hashlib,zipfile
root=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');pub=Path('/private/tmp/gcts-family-router-publish-20261010');src=root/'.gcts-active/equality-receptor-family-controls-report-source-20261014';out=pub/'docs/research/gcts-rl-renewal/receptor-controls'
p=out/'summary.json';v=json.loads(p.read_bytes());v['scope']='Both actual control attempts, including the accepted finite successor and its checked intermediate ground consequence. No declared-target proof, search, native, full-board, full-trajectory, universal-family, inventory, RL or comparative-performance acceptance. The display and saved-evidence reviews perform no fresh semantic replay.';p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def pin(p):
 b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
m=out/'source-archive-manifest.json';a=json.loads(m.read_bytes())
for record in a['members']:
 if record['archive_path'].startswith('PUBLIC/'):record.update(pin(Path(record['path'])))
a['members'].append(dict(archive_path=str(Path(__file__).relative_to(root)),**pin(Path(__file__))))
with zipfile.ZipFile(out/'reproduction.zip') as z:readme=z.read('README.txt')
with zipfile.ZipFile(out/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for record in a['members']:
  b=Path(record['path']).read_bytes();assert len(b)==record['bytes'] and hashlib.sha256(b).hexdigest()==record['sha256'];z.writestr(record['archive_path'],b)
 z.writestr('README.txt',readme)
m.write_text(json.dumps(a,indent=2,sort_keys=True)+'\n')
files=[p for p in out.iterdir() if p.is_file()]+[pub/'docs/research/gcts-rl-renewal/index.html']
v=dict(schema='ROOT-notebook158-task-publication-manifest-v5',files=[dict(relative=str(p.relative_to(pub)),**pin(p)) for p in sorted(files)],actual_cold_invocations=2,actual_control_census_complete=True,scientific_calls=0)
(src/'ROOT-notebook158-task-manifest-v5.json').write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(public_files=len(files),archive_members=len(a['members']),scope_corrected=True,scientific_calls=0)))
