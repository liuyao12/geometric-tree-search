"""ROOT metadata/control authorization only; never calls project functions."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
PROGRESS=ROOT/'.gcts-active/equality-receptor-family-controls-progress-v2-20261014'
SOURCE=ROOT/'.gcts-active/equality-receptor-family-controls-source-20261014'


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(value):return hashlib.sha256(canonical(value).encode()).hexdigest()
def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    assert path.resolve()==path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def constants(path):
    result={}
    for n in ast.parse(Path(path).read_bytes()).body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            try:result[n.targets[0].id]=ast.literal_eval(n.value)
            except (ValueError,TypeError):pass
    return result


class Raw:
    def __init__(self):self.records={}
    def add(self,record):
        path=Path(record['path']);path=path if path.is_absolute() else ROOT/path
        actual=dict(record,path=str(path));assert set(actual)=={'path','sha256','bytes'} and pin(path)==actual
        assert str(path) not in self.records or self.records[str(path)]==actual
        self.records[str(path)]=actual;return actual
    def walk(self,value):
        if isinstance(value,dict):
            if {'path','sha256','bytes'}<=set(value):self.add({k:value[k] for k in ('path','sha256','bytes')})
            for item in value.values():self.walk(item)
        elif isinstance(value,list):
            for item in value:self.walk(item)
    def document(self,record):
        record=self.add(record);raw=Path(record['path']).read_bytes()
        assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
        if record['path'].endswith('.gz'):raw=gzip.decompress(raw)
        value=json.loads(raw);self.walk(value);return value
    def save(self,path,value):
        with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
        return self.add(pin(path))


def main():
    assert len(sys.argv)==3 and not PROGRESS.exists()
    PROGRESS.mkdir();raw=Raw()
    worker_path=Path(sys.argv[2]).resolve()
    assert worker_path.parent==SOURCE and worker_path.name=='actual_Incident_family_controls_worker_v3.py'
    worker=constants(worker_path)
    sources=dict(worker['FROZEN_SOURCES'],worker=pin(worker_path))
    assert len(sources)==20
    peerpin=raw.add(pin(Path(sys.argv[1]).resolve()));peer=raw.document(peerpin)
    assert peer['source_review_passed'] is True and peer['source_only'] is True and peer['scientific_calls']==0
    assert peer['sources']==sources and peer['author_identity']=='/root/hilbert_advice_controls' and peer['reviewer_identity']!='/root/hilbert_advice_controls'
    runtime_all=json.loads((ROOT/'.gcts-active/hilbert-next-owned-progress-20261013/ROOT-source-review-v1.json').read_bytes())['runtime']
    for field in ('executable','resource_ext','posix_ext','observer'):raw.add(runtime_all[field])
    runtime=dict(binary=runtime_all['executable'],resource_extension=runtime_all['resource_ext'],python_version=[3,9,6],platform='darwin')
    for name in ('run_owned_bridge_v2.py','close_stage_decision_v1.py'):
        original=ROOT/'.gcts-active/equality-receptor-family-extraction-progress-20261014'/name
        (PROGRESS/name).write_bytes(original.read_bytes());raw.add(pin(PROGRESS/name))
    raw.document(pin(ROOT/'.gcts-active/equality-receptor-family-controls-progress-20261014/ROOT-actual-family-controls-failure-disposition-v1.json'))
    rootpin=raw.save(PROGRESS/'ROOT-source-review-v1.json',dict(schema='ROOT-real-family-controls-source-review-v1',
        source_only=True,source_review_passed=True,scientific_calls=0,reviewer_identity='/root',sources=sources,
        scope=worker['SCOPE'],scientific_episode_activation=False,
        source_assessment=['Prior V2 worker/mechanism whole-read; complete fresh Source delta and exact selected20-role peer review required. Runtime construction successor follows preserved failure, not a retry of unchanged Source.',
            'Current consumer novel registry and inventory gates read; nested DFS and overlay methods retain independent Source AST review.',
            'Effective instance/generated class/global/code/raw closure and original callback/shim guards precede registry and all Ground calls.',
            'Controls-only authorization grants freshly checked finite grounding, not scientific search or universal family validity.',
            'Required real forced/dead/pending and full chosen-domain EOF coverage fails closed; debug exclusions and physical reader fixtures are nonlogical.',
            'Repeated Gamma, actual zero, alias MP and successful second-chain coverage unexercised; no blanket receiver/whole-trajectory qualification.',
            'Previous activated Source failure preserved in named raw closure; no accepted partial prefix or proof count inferred.'],
        independent_worker_review=peerpin,runtime=runtime_all,master=sources['master']))
    raw.walk(sources)
    family=constants(sources['family_advice']['path']);reader=constants(sources['certificate']['path'])
    bindings=raw.document(family['I2_RECIPIENT_BINDINGS_PIN'])
    for name in ('fixture','static_profile','ROOT_static_disposition'):raw.document(bindings[name])
    raw.walk(family['UPSTREAM_SOURCE_PINS']);raw.walk(family['DONOR_SOURCE_PINS']);raw.add(family['TRAINING_SPEC_PIN'])
    for record in reader['HILBERT_UPSTREAM_REVIEWS'].values():raw.document(record)
    cb_roles=('streamed_overlay','streamed_dfs','streamed_proposal','features31','policy_math','proof_observer','family_advice')
    recipients=[]
    for item in bindings['recipients']:
        folder=PROGRESS/item['instance_id'];folder.mkdir()
        base=raw.document(item['original_qualification']);header=raw.document(base['catalog'])
        docs={}
        for category in ('producer','independent'):
            for field in ('plan','receipt','evidence','ROOT_decision'):
                docs[category,field]=raw.document(base[category][field])
            raw.document(docs[category,'plan']['source_review'])
            ownerplan=raw.document(docs[category,'ROOT_decision']['plan'])
            owner=raw.document(docs[category,'ROOT_decision']['owner'])
            raw.document(owner['ownership_ledger'])
        g=dict(schema='sealed-compact-dynamic-graph-binding-v2',model_epoch=docs['independent','evidence']['initial_graph_small_state']['model_epoch'],
            context_id=header['context_id'],formula_registry_sha256=header['formula_registry_sha256'],authority_epoch=header['authority']['epoch'],
            catalog_header_pin=base['catalog'],catalog_identity_sha256=digest(dict(header=base['catalog'],streams=header['streams'],codec=header['codec'])),
            complete_catalog_stream_pins=header['streams'],boundary_sha256=digest(dict(height=24,roots=[0]*24,
                fixed_marks=sorted(header['boundary']['fixed_exterior_m']+header['boundary']['fixed_target_m']),
                initial_selected=[[i,r,[]] for r,i in enumerate(header['assumption_recipe_indices'])])),
            source_bindings_sha256=digest(header['source_bindings']),runtime_source_bindings=[dict(role=r,**sources[r]) for r in sorted(
                ('point_core','compact_graph','compact_decoder','dynamic_graph_adapter','dynamic_lifecycle_adapter'))],
            marking_version='injective-formula-ordered-mp-offset-v1',orientation='identity',
            primitive_identity_relation='exact_original_complete_recipe_preimages_and_index_order',native_accepted=False,engine_authority_activated=False)
        assert digest(g)==base['expected_consumer_source_binding']['graph_binding_sha256']
        consumer=dict(schema='ROOT-whole-streamed-consumer-source-binding-v1',graph_binding_sha256=digest(g),
            source_records=[dict(role=r,**sources[r]) for r in sorted(cb_roles)],ROOT_source_review_pin=rootpin,independent_source_review_pin=peerpin)
        q=dict(base,expected_consumer_source_binding=consumer);qpin=raw.save(folder/'qualified-context-v1.json',q)
        body_records=[qpin]+[sources[r] for r in sorted(sources)]
        epoch=digest(dict(graph=g,sources=body_records,bodies=[],version='whole-compact-cluster-lifecycle-v2'))
        inventory=dict(schema='ROOT-whole-compact-search-inventory-binding-v1',model_epoch=g['model_epoch'],
            catalog_identity_sha256=g['catalog_identity_sha256'],runtime_authority_sha256=digest(g),original_body_authority_epoch=epoch,
            whole_group_authority_epoch=epoch,original_source_body_inventory_sha256=digest([]),complete_descriptor_registry_sha256=digest([]),
            registered_whole_descriptor_count=0,qualified_dimensions=header['dimensions'])
        registry=dict(schema='ROOT-I2-finite-Incident-advice-registry-binding-v1',instance_id=q['instance_id'],recipient_qualification=qpin,
            family_implementation=sources['family_advice'],library_source=worker['ACTUAL_INPUTS']['candidate_library'],
            training_spec=family['TRAINING_SPEC_PIN'],extraction_audit=worker['ACTUAL_INPUTS']['independent_audit'],
            model_binding={k:inventory[k] for k in ('model_epoch','catalog_identity_sha256','runtime_authority_sha256')},
            consumed_source_epoch=digest(dict(consumer_binding=consumer,complete_inventory_binding=inventory,compact_graph_binding=g)),primitive_source_body_count=0)
        registry_epoch=digest(registry)
        admission=dict(schema=family['ADMISSION_SCHEMA'],library=registry['library_source'],implementation=sources['family_advice'],
            ROOT_advice_library_accepted=True,advice_only=True,primitive_source_body_count=0,theory_sha256=digest(header['context']['theory']),
            schema_universally_validated=False,upstream_sources=family['UPSTREAM_SOURCE_PINS'],donor_sources=family['DONOR_SOURCE_PINS'],
            recipient_qualification=qpin,training_spec=family['TRAINING_SPEC_PIN'],extraction_audit=registry['extraction_audit'],
            registry_preimage_sha256=registry_epoch,controls_scope='real-ground-instance-and-domain-controls-only',
            scientific_episode_activation=False,ROOT_extraction_disposition=worker['ACTUAL_INPUTS']['ROOT_extraction_disposition'],
            ROOT_library_admitted=False,scope='Only this fixed candidate/current context may undergo real ground/domain controls; no scientific search activation.')
        apin=raw.save(folder/'ROOT-controls-only-admission-v1.json',admission)
        registry.update(advice_registry_epoch=registry_epoch,library_admission=apin)
        recipients.append(dict(instance_id=q['instance_id'],qualification=qpin,controls_admission=apin,
            family_registry_binding=registry,expected_inventory_binding=inventory))
    manifest=raw.save(PROGRESS/'ROOT-controls-input-manifest-v1.json',dict(schema='ROOT-two-I2-finite-family-controls-input-manifest-v1',
        ROOT_controls_authorized=True,scientific_episode_activation=False,library=worker['ACTUAL_INPUTS']['candidate_library'],
        audit=worker['ACTUAL_INPUTS']['independent_audit'],extraction_disposition=worker['ACTUAL_INPUTS']['ROOT_extraction_disposition'],recipients=recipients))
    inputs=dict(worker['ACTUAL_INPUTS'],control_manifest=manifest);raw.walk(inputs)
    limits=dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)
    op=PROGRESS/'replay-plan-v1.json';wp=PROGRESS/'worker-plan-v1.json';out=PROGRESS/'worker-output-v1'
    leaf=dict(schema=worker['SCHEMA'],ROOT_owned_once_only=True,scope=worker['SCOPE'],sources=sources,inputs=inputs,runtime=runtime,
        reviews={'ROOT':rootpin,'independent':peerpin},closure=[raw.records[k] for k in sorted(raw.records)],limits=limits,
        owner_plan_path=str(op),output_directory=str(out))
    assert len(leaf)==11
    lp=raw.save(wp,leaf)
    def relative(record):
        p=Path(record['path'])
        return dict(record,path=str(p.relative_to(ROOT)) if ROOT in p.parents else str(p))
    owner=dict(schema='ROOT-guard-native-owned-plan-v1',stage='replay',runtime_binary=runtime['binary'],
        worker=str(Path(sources['worker']['path']).relative_to(ROOT)),
        argv=[runtime['binary']['path'],'-B',sources['worker']['path'],worker['COMMAND'],str(wp),str(op)],
        worker_receipt=str((out/'actual-family-controls-result-v1.json').relative_to(ROOT)),limits=limits,
        closure=[relative(raw.records[k]) for k in sorted(raw.records)],ROOT_source_review=relative(rootpin),scope=worker['SCOPE'])
    assert len(owner)==10
    ownerpin=raw.save(op,owner)
    print(json.dumps(dict(progress=str(PROGRESS),worker_plan=lp,owner_plan=ownerpin,leaf_fields=11,owner_fields=10,
        raw_source_roles=20,raw_closure_paths=len(leaf['closure']),scientific_calls=0,scientific_episode_activation=False)))


if __name__=='__main__':main()
