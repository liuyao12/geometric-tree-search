Fixed Wang verifier for two-counter runs

Open report/fixed-wang-two-counter-20261105-v1.html. The frozen protocol
records the input programs, exact sources, pinned runtime and caps.

In a separate extracted copy, preserve the original evidence. Create an
empty data directory and use the pinned Python to run:

    python -I -S -B source/run_v1.py

The archived frames give complete initial rows and sparse changes to every
subsequent row. A type dictionary stores each square's four exact colors.
Replaying the deltas reconstructs the complete rectangles without a
per-case palette. The report renderer audits their local edge agreements
and maps each proof record to the exact square that commits it.

The separate publication/compiler-audit-v1.py checks the instruction
compiler against the direct CM2 definition over a declared finite sample.
Its scope and receipt are included. Recorded timings can vary.
