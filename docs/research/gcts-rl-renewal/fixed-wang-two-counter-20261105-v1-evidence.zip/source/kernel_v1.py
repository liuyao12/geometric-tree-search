"""Assemble a fixed verifier for two-counter Horn chains."""

OPS="IDKLMN"
SYMBOLS=list(">:;|!_FxyzGPXYZCV$"+OPS)+["T"+a for a in "F"+OPS]
ALPHABET=list("Pxyz:;!_")
HALTS=("accept","reject")
FAILURES=("syntax_bad","fact_bad","step_bad","goal_bad")
END={"x":":","y":":","z":";"}


class Assembler:
    def __init__(self):
        self.table={}
        self.count=0

    def state(self,label):
        self.count+=1
        return f"{self.count:03d}-{label}"

    def put(self,q,a,n,w=None,m=0):
        assert (q,a) not in self.table and a in SYMBOLS
        self.table[q,a]=(n,a if w is None else w,m)

    def scan(self,start,stop,exit,move=1):
        for a in SYMBOLS:
            if a in stop:
                self.put(start,a,exit)
            elif a not in ">$":
                self.put(start,a,start,m=move)

    def left(self,start,exit):
        for a in SYMBOLS:
            self.put(start,a,exit if a==">" else start,m=1 if a==">" else -1)

    def seek(self,start,mark,exit):
        scan=self.state("seek-"+mark)
        self.left(start,scan)
        self.scan(scan,{mark},exit)

    def field(self,start,mark,field,exit):
        at=self.state("at-"+mark)
        self.seek(start,mark,at)
        earlier="xyz"[: "xyz".index(field)]
        stages=[self.state("skip-"+a) for a in earlier]+[exit]
        self.put(at,mark,stages[0],m=1)
        for i,a in enumerate(earlier):
            q=stages[i]
            for c in (a,a.upper()):
                self.put(q,c,q,m=1)
            self.put(q,":",stages[i+1],m=1)

    def restore(self,start,exit):
        sweep=self.state("restore")
        self.left(start,sweep)
        for a in SYMBOLS:
            if a=="$":
                self.put(sweep,a,exit)
            elif a!=">":
                self.put(sweep,a,sweep,w=a.lower() if a in "XYZ" else a,m=1)

    def compare(self,start,a,fa,b,fb,extra,yes,no):
        """Compare lengths, optionally requiring one extra unit on a named side."""
        loop=self.state("compare-loop")
        seek_b=self.state("match-second")
        seen_a=self.state("first-unconsumed")
        seen_b=self.state("second-unconsumed")
        done_a=self.state("finish-first")
        finish_b=self.state("finish-second")
        good,bad=self.state("compare-good"),self.state("compare-bad")
        if extra:
            atom,field=(a,fa) if extra=="left" else (b,fb)
            first=self.state("remove-one-unit")
            self.field(start,atom,field,first)
            self.put(first,field,loop,w=field.upper())
            self.put(first,END[field],bad)
        else:
            loop=start
        self.field(loop,a,fa,seen_a)
        self.put(seen_a,fa.upper(),seen_a,m=1)
        self.put(seen_a,fa,seek_b,w=fa.upper())
        self.put(seen_a,END[fa],done_a)
        self.field(seek_b,b,fb,seen_b)
        self.put(seen_b,fb.upper(),seen_b,m=1)
        self.put(seen_b,fb,loop,w=fb.upper())
        self.put(seen_b,END[fb],bad)
        self.field(done_a,b,fb,finish_b)
        self.put(finish_b,fb.upper(),finish_b,m=1)
        self.put(finish_b,fb,bad)
        self.put(finish_b,END[fb],good)
        self.restore(good,yes)
        self.restore(bad,no)

    def require_zero(self,start,mark,field,yes,no):
        at=self.state("test-zero-"+field)
        self.field(start,mark,field,at)
        self.put(at,END[field],yes)
        self.put(at,field,no)

    def parser(self,begin):
        ctx,end,proof,again,pad=(self.state(x) for x in
            ("context","separator","first-proof","after-proof","padding"))
        def fields(label,dest,rule=False):
            qx,qy,qz=(self.state(label+"-"+k) for k in "xyz")
            for state,k,next in ((qx,"x",qy),(qy,"y",qz),(qz,"z",dest)):
                if k!="z" or not rule:
                    self.put(state,k,state,m=1)
                self.put(state,END[k],next,m=1)
            return qx
        first=fields("fact",ctx)
        rule=fields("rule",ctx,True)
        goal=fields("goal",end)
        px=fields("proof",again)
        self.put("start",">",ctx,m=1)
        self.put(ctx,"F",first,m=1)
        for a in OPS:
            self.put(ctx,a,rule,m=1)
        self.put(ctx,"G",goal,m=1)
        self.put(end,"|",proof,m=1)
        self.put(proof,"P",px,m=1)
        self.put(again,"P",px,m=1)
        self.put(again,"!",pad,m=1)
        self.put(pad,"_",pad,m=1)
        self.put(pad,"$",begin)

    def machine(self):
        states=sorted({q for q,_ in self.table}|{v[0] for v in self.table.values()}|set(HALTS)|set(FAILURES))
        rows=[]
        for q in states:
            if q in HALTS:
                continue
            for a in SYMBOLS:
                n,w,m=self.table.get((q,a),("reject" if q in FAILURES else "syntax_bad",a,0))
                rows.append(dict(state=q,read=a,next=n,write=w,move=m))
        return dict(schema="deterministic-one-tape-machine-v1",symbols=SYMBOLS,states=states,
                    blank="_",start="start",accept="accept",reject="reject",
                    input_alphabet=ALPHABET,transitions=rows)


def build():
    a=Assembler()
    begin,mark,facts,scan_f,steps,scan_s,commit,prev,at_prev=(a.state(x) for x in
        ("find-first-proof","mark-current","facts","scan-facts","steps","scan-steps","commit","drop-previous","at-previous"))
    a.parser(begin)
    a.seek(begin,"P",mark)
    a.put(mark,"P",facts,w="C")
    a.left(facts,scan_f)
    a.left(steps,scan_s)
    for scan,types,bad in ((scan_f,"F","fact_bad"),(scan_s,OPS,"step_bad")):
        for c in SYMBOLS:
            if c=="G":
                a.put(scan,c,bad)
            elif c not in ">$" and c not in types:
                a.put(scan,c,scan,m=1)
        for kind in types:
            trial="T"+kind
            first,second,success,failure,yes,no=(a.state(x) for x in
                ("test-first","test-second","restore-success","restore-failure","pass","retry"))
            a.put(scan,kind,first,w=trial)
            a.seek(success,trial,yes)
            a.put(yes,trial,commit if kind=="F" else prev,w=kind)
            a.seek(failure,trial,no)
            a.put(no,trial,scan,w=kind,m=1)
            if kind=="F":
                third=a.state("test-second-counter")
                a.compare(first,trial,"x","C","x",None,second,failure)
                a.compare(second,trial,"y","C","y",None,third,failure)
                a.compare(third,trial,"z","C","z",None,success,failure)
            else:
                third,fourth=(a.state(s) for s in ("test-counter-0","test-counter-1"))
                arguments=third
                if kind in "KN":
                    arguments=a.state("test-zero-branch")
                    a.require_zero(arguments,"V","y" if kind=="K" else "z",third,failure)
                a.compare(first,trial,"x","V","x",None,second,failure)
                a.compare(second,trial,"y","C","x",None,arguments,failure)
                a.compare(third,"V","y","C","y",{"I":"right","D":"left"}.get(kind),fourth,failure)
                a.compare(fourth,"V","z","C","z",{"L":"right","M":"left"}.get(kind),success,failure)
    a.seek(prev,"V",at_prev)
    a.put(at_prev,"V",commit,w="P")
    current,walk,next_line,goal,goal_y,goal_z=(a.state(x) for x in
        ("at-current","walk-current","next-line","test-goal-predicate","test-goal-0","test-goal-1"))
    a.seek(commit,"C",current)
    a.put(current,"C",walk,w="V",m=1)
    for c in "x:yz":
        a.put(walk,c,walk,m=1)
    a.put(walk,";",next_line,m=1)
    a.put(next_line,"P",steps,w="C")
    a.put(next_line,"!",goal)
    a.compare(goal,"G","x","V","x",None,goal_y,"goal_bad")
    a.compare(goal_y,"G","y","V","y",None,goal_z,"goal_bad")
    a.compare(goal_z,"G","z","V","z",None,"accept","goal_bad")
    return a.machine()


def record(tag,a,b,c):
    assert type(a) is type(b) is type(c) is int and min(a,b,c)>=0
    return tag+"x"*a+":"+"y"*b+":"+"z"*c+";"


def problem(facts,rules,goal):
    return ">"+''.join(record("F",*p) for p in facts)+''.join(record(k,a,b,0) for k,a,b in rules)+record("G",*goal)+"|"


def proof(lines):
    return ''.join(record("P",*p) for p in lines)+"!"
