"""Find bounded CM2 certificates using the fixed Wang local rule."""

from collections import deque
from functools import lru_cache
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def pin(path):
    b=path.read_bytes()
    return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def load(path):
    return json.loads((ROOT/path).read_bytes())


def write(path,data):
    with (ROOT/path).open("x") as f:
        json.dump(data,f,sort_keys=True,separators=(",",":"))
        f.write("\n")


def compressed(path,data):
    with (ROOT/path).open("xb") as raw:
        with gzip.GzipFile(fileobj=raw,mode="wb",filename="",mtime=0) as f:
            f.write((json.dumps(data,sort_keys=True,separators=(",",":"))+"\n").encode())


def canonical(data):
    return json.dumps(data,sort_keys=True,separators=(",",":"))


def digest(data):
    return hashlib.sha256(canonical(data).encode()).hexdigest()


def freeze():
    p=load("protocol-v1.json")
    assert p["schema"]=="Fixed-CM2-Wang-frozen-v1" and p["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in p["pins"].items())
    return p


def compile_context(case):
    program=case["program"]
    h=len(program)
    rules=[]
    for p,row in enumerate(program):
        assert row[0] in ("inc","dec") and row[1] in (0,1)
        c=row[1]
        if row[0]=="inc":
            assert len(row)==2
            rules.append(("IL"[c],p,p+1))
        else:
            assert len(row)==3 and type(row[2]) is int and row[2]>=0
            rules.extend((("DM"[c],p,min(row[2],h)),("KN"[c],p,p+1)))
    rules.extend((("D",h,h),("K",h,h+1),("M",h+1,h+1),("N",h+1,h+2)))
    p,a,b=case["initial"]
    assert all(type(v) is int and v>=0 for v in (p,a,b))
    assert max(a,b)<=case["counter_cap"]
    return {**case,"fact":(min(p,h),a,b),"goal":(h+2,0,0),"rules":rules,
            "certificate_cells":case["max_lines"]*(4+h+2+2*case["counter_cap"])+1}


def actual_step(case,record):
    p,a,b=record
    h=len(case["program"])
    if p==h:
        return (p,a-1,b) if a else (p+1,a,b)
    if p==h+1:
        return (p,a,b-1) if b else (p+1,a,b)
    if p>=h+2:
        return None
    instruction=case["program"][p]
    c=instruction[1]
    counter=[a,b]
    if instruction[0]=="inc":
        counter[c]+=1
        p+=1
    elif counter[c]==0:
        p+=1
    else:
        counter[c]-=1
        p=min(instruction[2],h)
    return (p,*counter)


def reference(case,proof):
    if proof[0]!=case["fact"]:
        return "fact_bad"
    if any(actual_step(case,a)!=b for a,b in zip(proof,proof[1:])):
        return "step_bad"
    return "accept" if proof[-1]==case["goal"] else "goal_bad"


def native(case):
    seen={}
    sequence=[]
    p=case["fact"]
    while p not in seen and len(sequence)<case["max_lines"]:
        if max(p[1:])>case["counter_cap"]:
            break
        seen[p]=len(sequence)
        sequence.append(p)
        if p==case["goal"]:
            return dict(status="FOUND",proof=sequence,cycle=None)
        p=actual_step(case,p)
    cycle=None if p not in seen else dict(first=seen[p],repeat=len(sequence),record=p)
    return dict(status="BOUNDED_EXHAUSTED",proof=None,cycle=cycle)


def candidates(case,prefix):
    if not prefix:
        return (case["fact"],)
    _,a,b=prefix[-1]
    neighbors=sorted({(a,b),(a+1,b),(a-1,b),(a,b+1),(a,b-1)})
    cap=case["counter_cap"]
    return [(p,i,j) for p in range(case["goal"][0]+1) for i,j in neighbors
            if 0<=i<=cap and 0<=j<=cap]


class Local:
    def __init__(self,machine,tiles):
        self.tiles=tiles
        self.palette=tiles.Palette(machine)
        self.types=set()

    @lru_cache(maxsize=150000)
    def neighborhood(self,a,b,c,d,e):
        old=(a,b,c,d,e)
        positions=tuple(i for i in (1,2,3) if old[i][0]!="wall")
        row=[self.palette.core(*old[i-1:i+2]) for i in positions]
        for t in row:
            if t not in self.types:
                assert self.palette.allows(t)
                self.types.add(t)
        assert all(l[1]==r[3] for l,r in zip(row,row[1:]))
        new=tuple(t[2][1] for t in row)
        i,=[i for i,x in enumerate(new) if x[0]=="head"]
        return positions[0]-2,new,positions[i]-2,new[i][1]

    def run(self,word,cap):
        t=self.tiles
        tape=[t.L,t.L]+[t.cell(a,"start" if i==0 else None) for i,a in enumerate(word)]+[t.R,t.R]
        head=2
        state="start"
        for steps in range(cap+1):
            if state=="accept" or state.endswith("_bad"):
                return state,steps
            if steps==cap:
                return "LIMIT",steps
            offset,new,move,state=self.neighborhood(*tape[head-2:head+3])
            first=head+offset
            tape[first:first+len(new)]=new
            head+=move
        raise AssertionError("finite step loop")


def word(kernel,case,proof):
    prefix=kernel.problem((case["fact"],),case["rules"],case["goal"])
    cert=kernel.proof(proof)
    assert len(cert)<=case["certificate_cells"]
    return prefix+cert.ljust(case["certificate_cells"],"_")+"$",len(prefix)


def search(kernel,local,case,limit,memoized):
    start=time.perf_counter()
    pending=deque([()])
    marks={}
    events=[]
    trials=hits=steps=0
    accepted=None
    stop=None
    while pending and accepted is None and stop is None:
        prefix=pending.popleft()
        for atom in candidates(case,prefix):
            candidate=(*prefix,atom)
            key=(prefix[-1],atom) if prefix else None
            if memoized and key in marks:
                events.append(dict(lines=candidate,kind="MARK",origin=marks[key]))
                hits+=1
                continue
            if trials>=limit["trials"] or time.perf_counter()-start>=limit["seconds"]:
                stop="SEARCH_LIMIT"
                break
            state,n=local.run(word(kernel,case,candidate)[0],limit["steps"])
            trials+=1
            steps+=n
            events.append(dict(lines=candidate,kind="WANG",verdict=state,steps=n))
            if state=="LIMIT":
                stop=state
                break
            if state=="accept":
                accepted=candidate
                break
            if state=="goal_bad" and len(candidate)<case["max_lines"]:
                pending.append(candidate)
            if memoized and state=="step_bad" and key is not None:
                marks.setdefault(key,len(events)-1)
    return dict(status="FOUND" if accepted else "UNKNOWN" if stop else "BOUNDED_EXHAUSTED",
                proof=accepted,trials=trials,mark_hits=hits,steps=steps,learned=len(marks),
                seconds=time.perf_counter()-start,events=events,stop=stop)


def audit(case,run):
    for i,row in enumerate(run["events"]):
        lines=row["lines"]
        if len(lines)>1:
            assert reference(case,lines[:-1])=="goal_bad"
        state=reference(case,lines)
        if row["kind"]=="WANG":
            assert row["verdict"] in (state,"LIMIT")
        else:
            assert 0<=row["origin"]<i and state=="step_bad"
            origin=run["events"][row["origin"]]
            assert origin["kind"]=="WANG" and origin["verdict"]==state
            assert origin["lines"][-2:]==lines[-2:]
    assert sum(r["kind"]=="WANG" for r in run["events"])==run["trials"]
    assert sum(r["kind"]=="MARK" for r in run["events"])==run["mark_hits"]


def qualifies(kernel,local,cap):
    effect={"I":(1,0),"D":(-1,0),"K":(0,0),"L":(0,1),"M":(0,-1),"N":(0,0)}
    count=0
    outcomes={"accept":0,"step_bad":0}
    for tag,(da,db) in effect.items():
        for a,b,c,d in product(range(2),repeat=4):
            fact=(0,a,b)
            goal=(1,c,d)
            ctx=kernel.problem((fact,),((tag,0,1),),goal)
            data=ctx+kernel.proof((fact,goal))+"$"
            expected=("accept" if (c-a,d-b)==(da,db)
                      and (tag!="K" or a==0) and (tag!="N" or b==0) else "step_bad")
            state,_=local.run(data,cap)
            assert state==expected,(tag,a,b,c,d,state)
            count+=1
            outcomes[state]+=1
    ctx=kernel.problem(((0,0,0),),(),(0,0,0))
    for item in ("!","P:;!","P::;!P::;","P:X:;!","P::;!x"):
        assert local.run(ctx+item+"$",cap)[0]=="syntax_bad"
    return dict(status="PASS",all_instruction_controls=count,accepted_controls=outcomes["accept"],
                rejected_controls=outcomes["step_bad"],malformed=5)


def main():
    spec=freeze()
    limits=spec["limits"]
    sys.path.insert(0,str(ROOT/"source"))
    import kernel_v1 as kernel
    import tiles_v1 as tiles
    from frame_v1 import certify
    machine=kernel.build()
    write("data/machine-v1.json",machine)
    local=Local(machine,tiles)
    qualification=qualifies(kernel,local,limits["steps"])
    write("data/qualification-v1.json",qualification)
    print(json.dumps(qualification),flush=True)
    cases=[compile_context(x) for x in load("input/programs-v1.json")]
    traces=[]
    frames=[]
    rows=[]
    for index,case in enumerate(cases):
        methods={}
        for name in (("plain","memo") if index%2==0 else ("memo","plain")):
            Local.neighborhood.cache_clear()
            tiles.Palette.core.cache_clear()
            model=Local(machine,tiles)
            run=search(kernel,model,case,limits,name=="memo")
            audit(case,run)
            traces.append(dict(case=case["id"],method=name,run=run))
            methods[name]={k:v for k,v in run.items() if k!="events"}
            print(json.dumps(dict(case=case["id"],method=name,**methods[name])),flush=True)
        control=native(case)
        assert all(r["status"] in (control["status"],"UNKNOWN") for r in methods.values())
        found=[r["proof"] for r in methods.values() if r["proof"]]
        evidence=None
        if found:
            proof=tuple(control["proof"])
            assert all(p==proof for p in found)
            selected,prefix=word(kernel,case,proof)
            evidence=certify(tiles,machine,case,proof,selected,prefix,limits)
            frames.append(evidence)
            print(json.dumps(dict(case=case["id"],frame=evidence["receipt"])),flush=True)
        rows.append(dict(case=case,methods=methods,native=control,frame=None if evidence is None else evidence["receipt"]))
    compressed("data/search-v1.json.gz",traces)
    compressed("data/frames-v1.json.gz",frames)
    freeze()
    files={n:pin(ROOT/n) for n in ("protocol-v1.json","data/machine-v1.json","data/qualification-v1.json",
                                  "data/search-v1.json.gz","data/frames-v1.json.gz")}
    write("data/summary-v1.json",dict(status="CHECKED_FIXED_CM2_WANG_COHORT",machine_sha256=digest(machine),
        states=len(machine["states"]),symbols=len(machine["symbols"]),qualification=qualification,
        outcomes=rows,files=files))


if __name__=="__main__":
    main()
