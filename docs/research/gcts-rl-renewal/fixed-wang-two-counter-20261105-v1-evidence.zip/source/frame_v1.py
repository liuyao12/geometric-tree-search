"""Build, check, and delta-encode every square of an accepting frame."""

import hashlib
import json
import time


def certify(tiles,machine,case,proof,word,prefix,limits):
    started=time.perf_counter()
    palette=tiles.Palette(machine)
    cfg=tuple(tiles.cell(a,"start" if i==0 else None) for i,a in enumerate(word))
    descriptors=[("input","head",word[0])]+[
        ("input","fixed",a) if i<prefix or i==len(word)-1 else ("input","free")
        for i,a in enumerate(word[1:],1)]
    boundary=[("top","left"),*descriptors,("top","right")]
    W=len(boundary)
    rows=[]
    types=[]
    registry={}
    previous=None
    old_ids=[-1]*W
    commits=[]
    total=0

    def push(row,bottom=False):
        nonlocal previous,total
        assert len(row)==W and row[0][3]==tiles.OL and row[-1][1]==tiles.OR
        changes=[]
        for x,t in enumerate(row):
            if t not in registry:
                assert palette.allows(t)
                registry[t]=len(types)
                encoded=json.dumps(t,separators=(",",":"),sort_keys=True).encode()
                types.append(dict(sha256=hashlib.sha256(encoded).hexdigest(),edges=t))
            ordinal=registry[t]
            if ordinal!=old_ids[x]:
                changes.append((x,ordinal))
                old_ids[x]=ordinal
            n,e,s,w=t
            assert n==(boundary[x] if previous is None else previous[x][2])
            assert w==(tiles.OL if x==0 else row[x-1][1])
            if bottom:
                assert s==tiles.OB
            if (n[0]=="configuration" and n[1][0]=="head"
                    and n[1][1].endswith("-at-current") and n[1][2]=="C"):
                assert s==tiles.cfg(tiles.cell("V"))
                commits.append(dict(row=len(rows),column=x,tile=ordinal))
        rows.append(changes)
        total+=W
        assert total<=limits["max_frame_squares"]
        previous=row

    top=[(("top","left"),tiles.LINK,tiles.FL,tiles.OL),
         *(palette.top(n,c) for n,c in zip(descriptors,cfg)),
         (("top","right"),tiles.OR,tiles.FR,tiles.LINK)]
    assert ''.join(t[2][1][-1] for t in top[1:-1])==word
    push(top)
    for steps in range(limits["steps"]+1):
        state,=[c[1] for c in cfg if c[0]=="head"]
        if state=="accept":
            break
        assert not state.endswith("_bad") and steps<limits["steps"]
        row=palette.step(cfg)
        successor=tuple(t[2][1] for t in row[1:-1])
        assert successor==palette.from_config(cfg)
        push(row)
        cfg=successor
    push(palette.cap(cfg),bottom=True)
    assert len(rows)==steps+2
    assert [x["column"] for x in commits]==[i+1 for i,a in enumerate(word) if i>=prefix and a=="P"]
    assert len(commits)==len(proof)
    return dict(case=case["id"],encoding="Full rows as sparse replacements of previous row, first row complete",
        proof=proof,word=word,prefix_length=prefix,boundary=boundary,
        commits=commits,types=types,row_deltas=rows,
        receipt=dict(status="CHECKED_FULL_FRAME",steps=steps,rows=len(rows),columns=W,
                     squares=total,used_types=len(types),seconds=time.perf_counter()-started))
