# Two-counter extension of the fixed verifier

Status is design after the unary experiment. The implemented palette and its
certificates retain the unary scope.

Use predicates \(P_p(x,y)\) for machine configurations. The predicate index
records the program position. The two term arguments encode counter values
with successor terms. A rule for incrementing the first counter maps
\(P_p(x,y)\) to \(P_{p+1}(Sx,y)\). A conditional decrement at position \(p\)
with nonzero branch \(q\) uses these two rules.

\[
P_p(Sx,y)\to P_q(x,y),\qquad P_p(0,y)\to P_{p+1}(0,y).
\]

Use the corresponding rules for the second counter. Universally close all
rules. Translate each out-of-program destination to a distinct halt label.
At halt, two fresh cleanup labels decrease the counters to zero and then
derive a new goal \(P_{\mathrm{accept}}(0,0)\). This makes exact ground goal
matching sufficient. From a single starting fact, ordinary chain derivations
before cleanup correspond step for step to the deterministic computation.
Neither nonzero branch can fire on zero, and each zero branch requires zero.

This is an inferred reduction using the CM2 instruction set, whose exact
halting scope is Definition 2 and Theorem 6 of the source below. The next
implementation would check both counters and zero branches on its fixed tape
table, then compile and verify actual positive and tampered executions. It
would still need a compiled general first-order proof checker to test source
theorems beyond this instruction language.

[Dudenhefner, Certified Decision Procedures for Two-Counter Machines](https://doi.org/10.4230/LIPIcs.FSCD.2022.16)
