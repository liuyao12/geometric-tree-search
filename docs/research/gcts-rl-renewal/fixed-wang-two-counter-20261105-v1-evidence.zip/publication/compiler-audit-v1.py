"""Check the frozen CM2-to-rule compiler against the direct definition."""

from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from run_v1 import compile_context, freeze, pin, write


def enabled(rules,p,a,b):
    result=[]
    for tag,source,dest in rules:
        if source!=p:
            continue
        if tag=="I":
            result.append((dest,a+1,b))
        elif tag=="D" and a:
            result.append((dest,a-1,b))
        elif tag=="K" and not a:
            result.append((dest,a,b))
        elif tag=="L":
            result.append((dest,a,b+1))
        elif tag=="M" and b:
            result.append((dest,a,b-1))
        elif tag=="N" and not b:
            result.append((dest,a,b))
    return result


def expected(program,p,a,b):
    n=len(program)
    if p==n:
        return [(n,a-1,b)] if a else [(n+1,0,b)]
    if p==n+1:
        return [(n+1,a,b-1)] if b else [(n+2,a,0)]
    if p==n+2:
        return []
    row=program[p]
    values=[a,b]
    direction=row[1]
    target=p+1
    if row[0]=="inc":
        values[direction]+=1
    elif values[direction]>0:
        values[direction]-=1
        target=row[2]
    return [(min(n,target),*values)]


def main():
    freeze()
    programs=configurations=0
    for n in range(4):
        choices=[("inc",c) for c in range(2)]+[
            ("dec",c,q) for c in range(2) for q in range(n+2)]
        for program in product(choices,repeat=n):
            compiled=compile_context(dict(program=program,initial=[n+1,0,0],max_lines=3,counter_cap=2))
            assert compiled["fact"]==(n,0,0) and compiled["goal"]==(n+2,0,0)
            programs+=1
            for p,a,b in product(range(n+3),range(3),range(3)):
                assert enabled(compiled["rules"],p,a,b)==expected(program,p,a,b)
                configurations+=1
    result=dict(status="PASS_BOUNDED_COMPILER_AUDIT",programs=programs,configurations=configurations,
        source=pin(Path(__file__)),compiler=pin(ROOT/"source/run_v1.py"),
        scope="All program lists up to three instructions using jump targets through one past the halt label. Test all in-program and cleanup labels at counter values zero through two.")
    write("publication/compiler-audit-v1.json",result)
    print(json.dumps(result),flush=True)


if __name__=="__main__":
    main()
