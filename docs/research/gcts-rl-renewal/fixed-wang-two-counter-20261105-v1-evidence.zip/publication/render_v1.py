"""Audit saved frames and show the exact tile row that commits each proof line."""

import gzip
import hashlib
from html import escape
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
STEM="fixed-wang-two-counter-20261105-v1"


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":")).encode()).hexdigest()


def uncompress(path):
    with gzip.open(path,"rt") as stream:
        return json.load(stream)


def audit():
    result=read(ROOT/"data/summary-v1.json")
    assert result["status"]=="CHECKED_FIXED_CM2_WANG_COHORT"
    for n,v in result["files"].items():
        assert pin(ROOT/n)==v
    protocol=read(ROOT/"protocol-v1.json")
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    machine=read(ROOT/"data/machine-v1.json")
    assert digest(machine)==result["machine_sha256"]
    assert result["qualification"]["all_instruction_controls"]==96
    traces=uncompress(ROOT/"data/search-v1.json.gz")
    by_trace={(r["case"],r["method"]):r["run"] for r in traces}
    cases=read(ROOT/"input/programs-v1.json")
    assert len(traces)==8 and len(by_trace)==8
    assert [{k:r["case"][k] for k in c} for c,r in zip(cases,result["outcomes"],strict=True)]==cases
    for row in result["outcomes"]:
        for name,method in row["methods"].items():
            trace=by_trace[row["case"]["id"],name]
            assert {k:v for k,v in trace.items() if k!="events"}==method
            assert len(trace["events"])==method["trials"]+method["mark_hits"]
    frames=uncompress(ROOT/"data/frames-v1.json.gz")
    assert len(frames)==3
    for row in frames:
        outcome=next(r for r in result["outcomes"] if r["case"]["id"]==row["case"])
        assert outcome["frame"]==row["receipt"] and outcome["methods"]["memo"]["proof"]==row["proof"]
        assert all(digest(t["edges"])==t["sha256"] for t in row["types"])
        assert len(row["row_deltas"])==row["receipt"]["rows"] and len(row["boundary"])==row["receipt"]["columns"]
        row["cells"]=window_rows(row)
    return result,frames


def window_rows(frame):
    types=[t["edges"] for t in frame["types"]]
    height=frame["receipt"]["rows"]
    W=frame["receipt"]["columns"]
    expected=[i+1 for i,a in enumerate(frame["word"]) if i>=frame["prefix_length"] and a=="P"]
    requested={0}
    for c in frame["commits"]:
        requested.update(range(max(0,c["row"]-1),min(height,c["row"]+2)))
    visible={}
    row=[-1]*W
    found=[]
    previous=None
    for y,changes in enumerate(frame["row_deltas"]):
        last=-1
        for x,ordinal in changes:
            assert last<x<W and 0<=ordinal<len(types)
            row[x]=ordinal
            last=x
        if y==0:
            assert len(changes)==W
            assert ''.join(types[i][2][1][-1] for i in row[1:-1])==frame["word"]
        for x,i in enumerate(row):
            n,e,s,w=types[i]
            assert n==(frame["boundary"][x] if y==0 else types[previous[x]][2])
            assert w==(["outer","left"] if x==0 else types[row[x-1]][1])
            if x==len(row)-1:
                assert e==["outer","right"]
            if y==height-1:
                assert s==["outer","bottom"]
            if (n[0]=="configuration" and n[1][0]=="head"
                    and n[1][1].endswith("-at-current") and n[1][2]=="C"):
                assert s==["configuration",["symbol","V"]]
                found.append(dict(row=y,column=x,tile=i))
        if y in requested:
            visible[y]=row[:]
        previous=row[:]
    assert [r["column"] for r in found]==expected
    assert len(found)==len(frame["proof"]) and found==frame["commits"]
    assert frame["receipt"]["squares"]==W*height
    return visible


def math(content):
    return r"\("+escape(content)+r"\)"


def term(n):
    return "0" if n==0 else r"S(0)" if n==1 else "S^{"+str(n)+"}(0)"


def pred(i, a, b):
    return "P_{"+str(i)+"}("+a+","+b+")"


def atom(p):
    return math(pred(p[0],term(p[1]),term(p[2])))


def formula(rule):
    kind,i,j=rule
    arguments={
        "I":("x","y","S(x)","y"),"D":("S(x)","y","x","y"),"K":("0","y","0","y"),
        "L":("x","y","x","S(y)"),"M":("x","S(y)","x","y"),"N":("x","0","x","0")}
    x,y,u,v=arguments[kind]
    bound=r"\forall y\," if kind=="K" else r"\forall x\," if kind=="N" else r"\forall x\forall y\,"
    return math(bound+"("+pred(i,x,y)+r"\to "+pred(j,u,v)+")")


def reason(case,proof,index):
    a=proof[index]
    if index==0:
        h=len(case["program"])
        return ("Use the initial fact at the halt label." if case["initial"][0]>=h
                else "Use the program’s initial configuration.")
    b=proof[index-1]
    kind_for_delta={(1,0):"I",(-1,0):"D",(0,1):"L",(0,-1):"M"}
    delta=(a[1]-b[1],a[2]-b[2])
    n,kind=next((i,k) for i,(k,p,q) in enumerate(case["rules"],1)
                if p==b[0] and q==a[0] and (k==kind_for_delta.get(delta)
                   or (delta==(0,0) and ((k=="K" and b[1]==0) or (k=="N" and b[2]==0)))))
    act={"I":"Increment the first counter","D":"Decrement the first counter",
         "K":"Take the first counter’s zero branch","L":"Increment the second counter",
         "M":"Decrement the second counter","N":"Take the second counter’s zero branch"}
    return f'{act[kind]} by applying rule {n} to line {index}.'


def color(c):
    label=c[0]
    base={"configuration":145,"old-pair":34,"input":205,"frame":210,"cap":285}.get(label,222)
    if label=="configuration" and c[1][0]=="head":
        base=286
    shade=int(digest(c)[:4],16)%28-14
    return f'hsl({base+shade} 53% 72%)'


def window(frame,commit):
    x,y=commit["column"],commit["row"]
    grid,types=frame["cells"],frame["types"]
    left=max(0,x-2)
    right=min(x+3,len(grid[0]))
    top=max(0,y-1)
    bottom=min(y+2,frame["receipt"]["rows"])
    size=46
    body=[]
    for yy in range(top,bottom):
        for xx in range(left,right):
            tile=types[grid[yy][xx]]
            dx,dy=(xx-left)*size,(yy-top)*size
            a,b,c,d=(0,0),(size,0),(size,size),(0,size)
            center=(size/2,size/2)
            body.append(f'<g transform="translate({dx} {dy})"><title>Row {yy}, column {xx}. '
                        f'Type {tile["sha256"]}</title>')
            for edge,u,v in zip(tile["edges"],(a,b,c,d),(b,c,d,a)):
                points=' '.join(f'{i},{j}' for i,j in (u,v,center))
                body.append(f'<polygon points="{points}" fill="{color(edge)}"></polygon>')
            n=tile["edges"][0]
            text=n[1][-1] if n[0]=="configuration" else "·"
            body.append(f'<text x="23" y="28" text-anchor="middle">{escape(text)}</text>')
            border="#672b78" if (xx,yy)==(x,y) else "#f9f7ee"
            width=2.8 if (xx,yy)==(x,y) else 1
            body.append(f'<rect width="46" height="46" fill="none" stroke="{border}" stroke-width="{width}"></rect></g>')
    return (f'<svg viewBox="0 0 {(right-left)*size} {(bottom-top)*size}" role="img" '
            f'aria-label="Actual Wang squares around computation row {y}">' + ''.join(body)+'</svg>')


def table(headers,rows):
    return ('<div class="scroll"><table><thead><tr>'+''.join(f'<th scope="col">{x}</th>' for x in headers)
            +'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{x}</td>' for x in row)+'</tr>' for row in rows)
            +'</tbody></table></div>')


def proof_reader(frame,case):
    rows=[]
    examples=[]
    for i,(a,commit) in enumerate(zip(frame["proof"],frame["commits"],strict=True)):
        rows.append([i+1,atom(a),reason(case,frame["proof"],i),commit["row"],commit["column"]])
        examples.append(f'<figure><figcaption>Line {i+1} · row {commit["row"]}</figcaption>'
                        +window(frame,commit)+'</figure>')
    facts=f'<li>{atom(case["fact"])}</li>'
    rules=' '.join(f'<li>{formula(r)}</li>' for r in case["rules"])
    return (f'<details><summary>{case["id"]} · {escape(case["name"])} · {atom(case["goal"])}</summary>'
            f'<div class="context"><div><h3>Facts</h3><ol>{facts}</ol></div>'
            f'<div><h3>Quantified rules</h3><ol>{rules}</ol></div></div>'
            +table(("Line","Formula","Justification","Wang row","Column"),rows)
            +'<div class="figures">'+''.join(examples)+'</div></details>')


def render(result,frames):
    cases={x["case"]["id"]:x["case"] for x in result["outcomes"]}
    rows=[]
    for item in result["outcomes"]:
        a,b=item["methods"]["plain"],item["methods"]["memo"]
        f=item["frame"]
        rows.append([item["case"]["id"],escape(item["case"]["name"]),
            "Checked halt" if f else "Bounded exhaustion",a["trials"],b["trials"],b["mark_hits"],
            f'{a["seconds"]:.3f}',f'{b["seconds"]:.3f}',
            f'{f["squares"]:,}' if f else "—"])
    q=result["qualification"]
    cycle=result["outcomes"][-1]["native"]["cycle"]
    assert cycle and cycle["repeat"]-cycle["first"]==3
    return HEAD+fr'''
<section id="comparison"><h2>Search for the execution certificates</h2>
<p>Both searches enumerate candidate records within the same counter and line bounds.
The first record is the initial fact. Every later guess picks a program label and changes
at most one counter by one unit. Sparse propagation checks the local Wang types near the head.
An independent CM2 interpreter checked every verdict and each reuse of a failed pair.</p>
{table(("Case","Program","Outcome","Plain trials","Memo trials","Reused failures","Plain s","Memo s","Wang squares"),rows)}
<p>In the last case the direct interpreter confirmed a three-step cycle returning to
{atom(cycle["record"])}. The tile searches exhausted their declared bounds. Search time
covers local propagation and candidate selection. Full-frame verification is timed separately
in the archived results.</p>
</section>
<section id="reader"><h2>Read the checked proof lines</h2>
<p>Each listed row is the computation row where the head commits that proof record.
Violet highlights the exact square. Green and violet encode north and south configuration
colors. Amber marks the east and west neighborhood colors. Matching uses the full color
identifier. The figures show local windows of the much larger tableaux.</p>
{''.join(proof_reader(f,cases[f["case"]]) for f in frames)}
</section>
<section id="scope"><h2>Why the same palette covers the instruction language</h2>
<p>One transition table has {result["states"]} states, {result["symbols"]} symbols,
and a fixed local membership rule for its finite palette. The archive gives every tile
used in the accepting rectangles. It stores exact changes from the preceding row.
Each square is placed by translation and checked by its four edge colors. The top boundary
fixes the compiled program, initial configuration and goal, leaving the certificate
cells free. The bottom cap requires the unique accepting head.</p>
<p>At program position \(p\), the atom \(P_p(x,y)\) records the two counter
terms. The rule for a first-counter increment is
\(\forall x\forall y\,(P_p(x,y)\to P_{{p+1}}(S(x),y))\).
A first-counter decrement instruction with jump destination \(q\) uses</p>
<p class="scroll">\[
\forall x\forall y\,(P_p(S(x),y)\to P_q(x,y)),\qquad
\forall y\,(P_p(0,y)\to P_{{p+1}}(0,y)).
\]</p>
<p>The second-counter rules exchange the argument roles. From the single initial fact,
each implication before the halt label is the corresponding CM2 step. Only an
out-of-program position enters cleanup. Cleanup empties both counters and reaches
the designated zero-counter goal. Conversely, every halt yields a finite chain,
an accepting verifier computation and a finite rectangle once its certificate
width and time height are large enough.</p>
<p>Thus the unbounded framed tiling question for this palette inherits CM2 halting
via this reduction. The source defines the exact instruction convention and gives
its halting theorem. <a href="https://doi.org/10.4230/LIPIcs.FSCD.2022.16">Dudenhefner,
Definition 2 and Theorem 6</a>.</p>
<p>Qualification exercised {q["all_instruction_controls"]} instruction controls and
{q["malformed"]} malformed strings. The four experiments use explicit search caps.
Their checked executions demonstrate the encoding. Translation of a general first-order
proof checker into this instruction language remains open.</p>
</section>
'''+END


HEAD=r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fixed Wang verifier for two-counter computations</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{color-scheme:light;--ink:#17362f;--rule:#cbd9cd;--paper:#f6f4eb}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,sans-serif}
main{max-width:1120px;margin:auto;padding:24px}header{padding:24px 0;max-width:840px}
h1{font:clamp(2.1rem,5vw,3.9rem)/1.08 Georgia,serif;margin:.45em 0}
h2{font:1.75rem/1.15 Georgia,serif;margin:0 0 .55em}h3{font-size:1rem}
a{color:#176852}.eyebrow{font-size:.8rem;letter-spacing:.12em;text-transform:uppercase}
section{background:#fffdfa;border:1px solid var(--rule);border-radius:12px;padding:18px;margin-bottom:18px}
.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:.88rem}
td,th{text-align:left;vertical-align:top;padding:7px;border-bottom:1px solid var(--rule)}
details{padding:10px 0;border-top:1px solid var(--rule)}summary{cursor:pointer;font-weight:650}
.context,.figures{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,205px),1fr));gap:12px}
figure{margin:10px 0;background:#edf5ee;padding:9px;border-radius:8px}
figcaption{font-size:.85rem;font-weight:650}svg{display:block;width:100%;height:133px;font:14px monospace}
</style></head><body><main>
<header><p class="eyebrow">GCTS research · symbolic deduction</p>
<h1>One Wang palette for two-counter runs</h1>
<p>The search found three execution certificates from programs and starting states.
The reader shows the quantified rules, the ground proof lines and the actual squares
that commit them.</p>
<p><a href="#comparison">Search comparison</a> · <a href="#reader">Read the proofs</a> ·
<a href="#evidence">Evidence archive</a></p></header>
'''


END=f'''<section id="evidence"><h2>Experiment records</h2>
<p><a href="{STEM}-evidence.zip">Full evidence archive</a> ·
<a href="{STEM}-manifest.json">Archive manifest</a> ·
<a href="{STEM}-results.json">Audited results and row mappings</a> ·
<a href="fixed-wang-horn-20261105-v1.html#reader">Earlier unary Horn proof reader</a></p>
</section></main></body></html>
'''


def main():
    result,frames=audit()
    with (ROOT/"report"/(STEM+".html")).open("x") as f:
        f.write(render(result,frames))
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:
        compact=[{k:v for k,v in fr.items() if k not in ("cells","types","row_deltas")} for fr in frames]
        json.dump(dict(status="PASS_SAVED_CM2_WANG_EVIDENCE_AUDIT",summary=result,frames=compact),f,
                  sort_keys=True,separators=(",",":"))
        f.write("\n")


if __name__=="__main__":
    main()
