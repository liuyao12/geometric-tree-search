# A fixed Wang verifier for two-counter computations

Each proof atom records a program position and two successor counts. A
typed CM2 program becomes a context of universally quantified Horn
rules. Increment changes one count and advances the instruction pointer.
Conditional decrement has a positive-counter rule that decrements and
jumps and a separate zero rule that advances. Out-of-program destinations
map to a single halt label. Two fresh cleanup labels empty both counters
and derive one exact ground goal. The initial configuration is the sole
ground fact. The instruction convention follows Definition 2 of the
source below.

Before cleanup, valid chains from the fact correspond to machine steps.
Cleanup has no path back into the original program. Consequently a chain
to the designated goal exists precisely when the original machine halts.
The bounded experiment checks four declared examples. Its bounds leave
other computations open. A compiler for arbitrary first-order proof
checking into this machine language is a separate deliverable.

The frozen machine checks the grammar and every counter relation.
It uses one tape table for all inputs, including their free certificate
slots. The qualified framed-Wang construction gives a fixed finite
palette intensionally. The search uses the local Wang rule near the unique
head on every candidate step. Headless cells retain their old
configuration, with neighboring colors prescribed by the old row.

The first record is the context fact. Each subsequent candidate ranges
over all in-bound labels and all counter changes of at most one unit in
one counter. This syntactic superset includes every legal inference
within the bounds. Both arms use the same candidate order. The marking
arm may skip a pair of consecutive records only after its exact
same-context transition failure has been checked by the tile machine.
An independent program interpreter checks all trial verdicts and reused
rejections. Direct simulation is a separate outcome control.

Test all six instruction variants on counter values zero and one.
Check malformed strings. Build all squares of each accepted rectangle,
verify the boundary, local equality, type membership and every global
machine transition, then store exact row deltas. Include the tile that
commits each logical record. Use one alternating-order run per method.
The four cases and all time and space limits are frozen before execution.

[Dudenhefner, Certified Decision Procedures for Two-Counter Machines](https://doi.org/10.4230/LIPIcs.FSCD.2022.16)
