Peano arithmetic with reusable Wang proofs

From the archive root, run these commands with Python 3.12.

    python3 -I -S -B source/mul_study_v1.py
    python3 -I -S -B source/mul_wang_v1.py
    python3 -I -S -B publication/render_v1.py

The first command repeats the search and checks the induction obligations.
The second replays the saved fixed-palette Wang certificates and verifies the
bindings to their decoded formulas. Add --build to regenerate those traces.
The third renders the report from the checked data.

The exact input and the returned proof object for each E attempt are saved in
data/e-control-v1.json. With E 3.5.5 available, the comparison can be rerun using
python3 -I -S -B source/e_control_v1.py /path/to/eprover. E uses a CPU time
limit in addition to the processed-clause limit.
