const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/wang-multiplication-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#square-of-a-sum .rewrite mjx-container").first().waitFor();
      assert.equal(await page.locator(".proof").count(), 13);
      assert.equal(await page.locator("#results tbody tr").count(), 13);
      assert.equal(await page.locator("#square-of-a-sum .rewrites > li").count(), 6);
      assert.equal(await page.locator("#tile-display use").count(), 45);
      const before = await page.locator("#tile-display").innerHTML();
      await page.locator("#square-of-a-sum .records summary").first().click();
      await page.locator("#square-of-a-sum .open-tiles:visible").first().click();
      assert.notEqual(await page.locator("#tile-display").innerHTML(), before);
      assert.equal(await page.locator("#tile-display use").count(), 45);
      assert.match(await page.locator("#tile-caption").innerText(), /Square of a sum, record 1/);
      await page.locator('#results tbody a[href="#binomial-product"]').click();
      await page.locator("#binomial-product[open]").waitFor();
      assert.equal(await page.locator("#binomial-product[open] .rewrites > li").count(), 3);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      const layout = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        sections: [...document.querySelectorAll("main > section")].filter(node =>
          node.scrollWidth > node.clientWidth + 4).map(node => node.id),
      }));
      assert.deepEqual(layout, { width, sections: [] });
      assert.deepEqual(errors, []);
      await page.locator("#wang-squares").screenshot({ path: "publication/wang-squares-" + width + ".png" });
      console.log("Verified", width, "px, 13 theorem readers, formula rendering, and selectable Wang windows.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
