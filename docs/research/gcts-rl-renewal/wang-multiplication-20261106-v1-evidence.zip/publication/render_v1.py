"""Render a line-by-line arithmetic notebook with verified Wang tile windows."""
import gzip
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "source", "wang/source")]
from boundary_kernel_v1 import build
from e_control_v1 import solved
from mul_cases_v1 import AXIOMS, CASES
from mul_study_v1 import workload_total
from proof_views_v1 import frame_window, math, tile_svg

NAME = "wang-multiplication-20261106-v1"
TITLE = "Peano arithmetic with reusable Wang proofs"
LABELS = {
    "add-zero-right": "Add zero on the right", "add-successor-right": "Add a successor on the right",
    "multiply-zero-right": "Multiply by zero on the right",
    "multiply-successor-right": "Multiply by a successor on the right",
    "add-zero-left": "Add zero on the left", "add-successor-left": "Add a successor on the left",
    "addition-commutes": "Addition commutes", "addition-associates": "Addition associates",
    "multiply-zero-left": "Multiply by zero on the left", "multiply-one-right": "Multiply by one",
    "multiply-successor-left": "Multiply a successor on the left", "multiplication-commutes": "Multiplication commutes",
    "left-distributivity": "Left distributivity", "right-distributivity": "Right distributivity",
    "multiplication-associates": "Multiplication associates", "binomial-product": "Binomial product",
    "square-of-a-sum": "Square of a sum", "induction-hypothesis": "Induction hypothesis",
}


def read(name):
    return json.loads((ROOT / name).read_text())


def expression(term, variables, enclosing=0):
    if isinstance(term, str):
        return term[1:]
    head, *args = term
    if head == "zero":
        return "0"
    if head.startswith("parameter"):
        return variables[int(head[9:])][1:]
    if head == "S":
        return "S(" + expression(args[0], variables) + ")"
    if head == "=Nat":
        return expression(args[0], variables) + "=" + expression(args[1], variables)
    op, rank = {"plus": ("+", 1), "times": (r"\times ", 2)}[head]
    result = expression(args[0], variables, rank) + op + expression(args[1], variables, rank+1)
    return "(" + result + ")" if enclosing > rank else result


def equality(terms, variables):
    return math(expression(("=Nat", *terms), variables))


def theorem(eq):
    return math(r"\forall " + ",".join(v[1:] for v in eq.variables) + r"\quad "
                + expression(("=Nat", eq.left, eq.right), eq.variables))


def clause(literals, variables):
    return math(r"\lor ".join(expression(atom, variables).replace("=", r"\ne ", 1) if not sign
                              else expression(atom, variables) for sign, atom in literals) or r"\bot")


def tag(name):
    if name == "induction-hypothesis":
        return "assumption"
    return "lemma" if name in {eq.name for eq in CASES} else "axiom"


def rule(name):
    text = LABELS.get(name, name.replace("-", " ").removesuffix(" Nat"))
    layer = tag(name)
    if name in LABELS and layer == "lemma":
        return f'<a class="badge {layer}" href="#{name}">{escape(text)}</a>'
    if name in LABELS:
        return f'<span class="badge {layer}">{escape(text)}</span>'
    return f'<span class="badge kernel">{escape(text)}</span>'


def windows(bank):
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    panes = []
    for number, (key, evidence) in enumerate(bank["traces"].items()):
        start = evidence["steps"]-5
        trace = dict(prefix=evidence["prefix"], word=evidence["word"], padding=0, trace=evidence["fragment"])
        tiles, first = frame_window(machine, trace, start, evidence["head"])
        ids, uses = {}, []
        for y, row in enumerate(tiles):
            for x, tile in enumerate(row):
                j = ids.setdefault(tile, len(ids))
                uses.append(f'<use href="#wang-{number}-{j}" x="{36*x}" y="{36*y}"/>')
        defs = "".join(tile_svg(t, f"{number}-{j}") for t, j in ids.items())
        panes.append(f'<template id="tile-{key}"><figure><svg role="img" aria-label="Nine by five window of '
                     f'checked Wang squares" viewBox="0 0 324 180"><defs>{defs}</defs>{"".join(uses)}</svg>'
                     f'<figcaption>Verifier rows {start+1:,} to {start+5:,}, tape columns {first:,} to {first+8:,}. '
                     f'Point to a square for its exact edge labels.</figcaption></figure></template>')
    return "".join(panes)


def records(bundle, eq, segment):
    lines = []
    for i in segment:
        row = bundle["proof"][i]
        if row["rule"] == "G":
            text = "Instantiate " + rule(row["source"])
        else:
            text = f'Resolve lines {row["left"]+1} and {row["right"]+1}'
        lines.append(f'<li value="{i+1}">{text} gives {clause(row["clause"], eq.variables)}. '
                     f'<a class="open-tiles" data-key="{bundle["calls"][i]}" href="#wang-squares">View squares</a></li>')
    return '<details class="records"><summary>Read the corresponding Wang records</summary><ol>' + "".join(lines) + "</ol></details>"


def show_proof(eq, item, wang):
    selected = " open" if eq.name == "square-of-a-sum" else ""
    contents = []
    proof = item["proof"]
    mode = "Direct proof" if proof["induction"] is None else (
        "Induction on " + math(proof["induction"][1:]))
    for attempt in proof["phases"]:
        phase = attempt["phase"]
        outcome, bundle = item["audited"][phase], wang[phase]
        lines = []
        for line, segment in zip(outcome["lines"], bundle["segments"][:-1], strict=True):
            place = "at the highlighted expression" if line["path"] else "to the whole expression"
            before = expression(line["before"], eq.variables)
            if line["path"]:
                before = focused(line["before"], eq.variables, line["path"])
            after = expression(line["after"], eq.variables)
            direction = " in reverse" if line["side"] else ""
            lines.append(f'<li><div class="rewrite">{math(before + "=" + after)}</div>'
                         f'<div>Apply {rule(line["rule"])}{direction} {place}.</div>'
                         + records(bundle, eq, segment) + '</li>')
        hypothesis = ("<p>Assume " + equality(outcome["ih"], eq.variables) + " for this step.</p>"
                      if outcome["ih"] else "")
        contents.append(f'<h4>{phase.capitalize()}</h4>{hypothesis}<p>Show '
                        f'{equality((outcome["left"], outcome["right"]), eq.variables)}.</p>'
                        f'<ol class="rewrites">{"".join(lines)}</ol>'
                        + records(bundle, eq, bundle["segments"][-1]))
    imports = ", ".join(rule(n) for n in item["imports"]) or "Peano equations and equality"
    return (f'<details class="proof" id="{eq.name}"{selected}><summary>{LABELS[eq.name]}</summary>'
            f'<p>{theorem(eq)}</p><p>{mode}. Uses {imports}.</p>' + "".join(contents) + "</details>")


def focused(term, variables, path, enclosing=0):
    if not path:
        return r"{\color{teal}\underbrace{" + expression(term, variables, enclosing) + "}}"
    head, *args = term
    i, *rest = path
    if head == "S":
        return "S(" + focused(args[0], variables, rest) + ")"
    op, rank = {"plus": ("+", 1), "times": (r"\times ", 2)}[head]
    fields = [focused(t, variables, rest, rank+j) if i == j+1 else expression(t, variables, rank+j)
              for j, t in enumerate(args)]
    result = op.join(fields)
    return "(" + result + ")" if enclosing > rank else result


def main():
    result = read("data/arithmetic-v1.json")
    control = read("data/e-control-v1.json")
    assert control["square_followup"]["status"] == "Unsatisfiable"
    wang = read("wang/data/arithmetic-proof-v1.json")
    receipt = read("wang/data/arithmetic-receipt-v1.json")
    bank = json.loads(gzip.decompress((ROOT / "wang/data/arithmetic-bank-v1.json.gz").read_bytes()))
    examples = "".join(show_proof(e, result[e.name]["inventory"], wang[e.name]) for e in CASES)
    table = []
    for eq in CASES:
        a = result[eq.name]
        e = control["cases"][eq.name]
        flags = (a["axioms"]["proof"] is not None, a["inventory"]["proof"] is not None,
                 solved(e["axioms"]), solved(e["inventory"]))
        cells = "".join("<td>Found</td>" if flag else "<td>Unsolved</td>" for flag in flags)
        table.append(f'<tr><th scope="row"><a href="#{eq.name}">{LABELS[eq.name]}</a></th>{cells}</tr>')
    modes = [result[eq.name]["inventory"] for eq in CASES]
    unindexed = [result[eq.name]["unindexed"] for eq in CASES]
    matched, scanned = (workload_total(rows, "matches") for rows in (modes, unindexed))
    axioms = "".join(f"<li>{LABELS[e.name]} gives {theorem(e)}.</li>" for e in AXIOMS)
    default = wang["square-of-a-sum"]["direct"]["calls"][-1]
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE).replace("</style>", """
h4{margin-bottom:.3rem}.rewrites>li{padding:.45rem .25rem;border-bottom:1px solid #d6e3e9}
.rewrite,.records ol{overflow:auto}.badge{display:inline-block;padding:.04rem .35rem;border-radius:.25rem}
.axiom{background:#dceaff;color:#17477a}.lemma{background:#d8efea;color:#17594d}
.assumption{background:#ffe8ce;color:#743f08}.kernel{background:#ede5f7;color:#503479}
#wang-squares figure{max-width:36rem}.wide{overflow:auto}
</style>""")
    page = f"""
<body><main><header><p class="kicker">GCTS research notebook · 6 November 2026</p>
<h1>{TITLE}</h1>
<p>A rewrite search found 13 equational theorems from four recursive equations and induction.
The proof of the square-of-a-sum identity uses the binomial product, which in turn uses both
distributive laws. Every obligation has a line-by-line reading and a checked Wang certificate.</p>
<nav><a href="#results">Search comparison</a><a href="#reader">Read the proofs</a>
<a href="#wang-squares">Inspect Wang tiles</a><a href="#replay">Replay</a></nav></header>
<section id="results"><h2>What changed when lemmas were available?</h2>
<div class="flows"><div><strong>13 of 13</strong>Rewrite search with the inventory</div>
<div><strong>5 of 13</strong>The same search from axioms</div>
<div><strong>12 of 13</strong>E with the same inventory</div></div>
<p>Both provers tried the direct obligation first, then induction on variables ordered
by their role in the recursive equations. The inventory provided the same earlier, checked
theorems to both. Its target order was chosen by hand. The steps and their dependencies were found by search.</p>
<div class="table wide" tabindex="0" role="region" aria-label="Proof search results"><table><thead><tr>
<th scope="col">Theorem</th><th scope="col">Rewrite, axioms</th><th scope="col">Rewrite, inventory</th>
<th scope="col">E, axioms</th><th scope="col">E, inventory</th>
</tr></thead><tbody>{"".join(table)}</tbody></table></div>
<p>Rewrite search could expand up to 700 terms per obligation and bounded intermediate term sizes.
E 3.5.5 ran in automatic mode with up to 700 processed clauses and one CPU second per obligation.
With 20,000 processed clauses and five CPU seconds, E also found the direct proof of the
square-of-a-sum identity. The bounds count different work. <a href="https://github.com/eprover/eprover">E prover source</a></p>
<p>Routing an equality rule by the head symbol at the current subterm reduced match attempts from
{scanned:,} to {matched:,}. The exact same terms were expanded and the same proofs were returned.
The filter depends on the local subterm and uses a fixed rule.</p>
<div class="flows" aria-label="Example of nested theorem reuse">
<div><strong><a href="#left-distributivity">Distributivity</a></strong>Uses addition associativity</div>
<div><strong><a href="#binomial-product">Binomial product</a></strong>Uses both distributive laws</div>
<div><strong><a href="#square-of-a-sum">Square of a sum</a></strong>Uses the binomial product and commutativity</div>
</div></section>
<section id="reader"><h2>Proofs the search found</h2>
<p>Every variable shown in an obligation is an arbitrary natural number. The green underbrace locates the subterm being rewritten.
Color distinguishes {rule("add-zero-right")} as an axiom, {rule("addition-associates")} as a previously
proved lemma, {rule("induction-hypothesis")} as a local assumption, and {rule("transitive-Nat")} as an equality operation.</p>
<details><summary>Read the four recursive equations</summary><ul>{axioms}</ul></details>
{examples}
</section>
<section id="wang-squares"><h2>Inspect the Wang squares</h2>
<p>The square tiles have fixed north, east, south and west edges. Adjacent edges carry identical labels.
Darker edges carry verifier-head state. These are windows of the checked computation for a logical record.
The separate colors in the proof reader identify where a rule comes from.</p>
<p id="tile-caption">Showing the final record of the square-of-a-sum proof.</p>
<div id="tile-display"></div>
{windows(bank)}
<p>The same translation-only tile palette replayed {receipt["logical_records"]} logical records across
{receipt["obligations"]} obligations, using {receipt["unique_fragments"]} distinct compact inputs.
A separate checker binds each compact name to its exact formula and combines the base and successor
cases under natural-number induction. It rejected a corrupted subterm location and a proof with a withheld lemma.</p>
</section>
<section id="replay"><h2>Evidence and scope</h2>
<p><a href="{NAME}-evidence.zip">Download the evidence and replay code</a>.
The archive includes the exact E inputs and its returned proof objects.</p>
<p>This pilot tests a fixed rewrite policy and equality in Peano arithmetic. It measures lemma
reuse and indexed matching, with RL and wider first-order search outside this run.</p></section></main>
<script>
const show = (key) => document.getElementById("tile-display").replaceChildren(
  document.getElementById("tile-" + key).content.cloneNode(true));
show("{default}");
document.querySelectorAll("a.open-tiles").forEach(link => link.addEventListener("click", () => {{
  show(link.dataset.key);
  const number = link.closest("li").value;
  const theorem = link.closest(".proof").querySelector("summary").textContent;
  document.getElementById("tile-caption").textContent = theorem + ", record " + number + ".";
}}));
function openProof() {{
  const target = document.getElementById(location.hash.slice(1));
  if (target?.matches("details.proof")) target.open = true;
}}
openProof();
addEventListener("hashchange", openProof);
</script></body></html>
"""
    (ROOT / "report" / (NAME + ".html")).write_text(head + page)


if __name__ == "__main__":
    main()
