"""Compare E auto on the same direct and induction obligations."""
import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mul_cases_v1 import AXIOMS, CASES, induction_order, obligations
from mul_study_v1 import DATA


def term(t):
    if isinstance(t, str):
        return t[1:].upper()
    head, *args = t
    head = head.lower()
    return head + "(" + ",".join(map(term, args)) + ")" if args else head


def equation(left, right):
    return f"{term(left)} = {term(right)}"


def input_for(rules, left, right):
    rows = [f"cnf({rule.name.replace('-', '_')},axiom,{equation(rule.left, rule.right)})."
            for rule in rules]
    rows.append(f"cnf(negated_goal,negated_conjecture,{term(left)} != {term(right)}).")
    return "\n".join(rows) + "\n"


def run_phase(command, phase, problem):
    run = subprocess.run(command, input=problem, capture_output=True, text=True, timeout=10)
    statuses = re.findall(r"(?m)^[#%] SZS status (\w+)", run.stdout)
    assert statuses, (run.returncode, run.stderr, run.stdout[-500:])
    status = statuses[-1]
    object_ = re.search(r"(?ms)^[#%] SZS output start[^\n]*\n(.*?)^[#%] SZS output end", run.stdout)
    proof = object_[1].splitlines() if object_ else []
    if status in ("Unsatisfiable", "Theorem"):
        assert proof
    return dict(phase=phase, status=status, problem=problem, proof=proof)


def compare(executable):
    command = [executable, "--auto", "--tstp-format", "--proof-object", "--cpu-limit=1",
               "--processed-clauses-limit=700"]
    version = subprocess.check_output([executable, "--version"], text=True).strip()
    out = {}
    for i, eq in enumerate(CASES):
        out[eq.name] = {}
        for label, library in (("axioms", ()), ("inventory", CASES[:i])):
            attempts = []
            for variable in (None, *induction_order(eq)):
                phases = []
                for phase, (left, right), ih in obligations(eq, variable):
                    given = (*AXIOMS, *library, *((ih,) if ih else ()))
                    problem = input_for(given, left, right)
                    phases.append(run_phase(command, phase, problem))
                    if phases[-1]["status"] not in ("Unsatisfiable", "Theorem"):
                        break
                attempts.append(dict(induction=variable, phases=phases))
                if phases[-1]["status"] in ("Unsatisfiable", "Theorem"):
                    break
            out[eq.name][label] = attempts
    extended = [*command[:-2], "--cpu-limit=5", "--processed-clauses-limit=20000"]
    problem = out["square-of-a-sum"]["inventory"][0]["phases"][0]["problem"]
    return dict(version=version, options=command[1:], cases=out,
                square_followup=dict(options=extended[1:], **run_phase(extended, "direct", problem)))


def solved(attempts):
    last = attempts[-1]
    needed = 1 if last["induction"] is None else 2
    return (len(last["phases"]) == needed and
            all(row["status"] in ("Theorem", "Unsatisfiable") for row in last["phases"]))


if __name__ == "__main__":
    result = compare(sys.argv[1])
    (DATA / "e-control-v1.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    for label in ("axioms", "inventory"):
        print(label, [name for name, modes in result["cases"].items() if solved(modes[label])])
