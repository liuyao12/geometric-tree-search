"""Replayable whole-shell actions and a learned ordering for bounded growth."""

from collections import Counter, deque
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from catalogue_v1 import rooted_contacts
from cluster_v1 import Model, load, pin, save
from grammar_v1 import CENTRE, Grammar
from shell_v1 import unpack


class Policy:
    def __init__(self):
        self.weights = [0.0]*6
        self.mean = 0.0
        self.updates = 0

    def order(self, choices, mode, randomizer, trace):
        def score(f):
            return sum(a*b for a,b in zip(self.weights,f,strict=True))

        if mode == "HEURISTIC":
            return sorted(choices,key=lambda j: (choices[j][0], choices[j][1], -choices[j][4], j))
        if mode == "RANDOM":
            return randomizer.sample(sorted(choices),len(choices))
        if mode == "FROZEN_RL":
            return sorted(choices,key=lambda j: (-score(choices[j]), j))
        ids = sorted(choices)
        if len(ids)<2:
            return ids
        scores = [score(choices[j]) for j in ids]
        factors = [math.exp(s-max(scores)) for s in scores]
        total = sum(factors)
        pick = randomizer.choices(ids,factors,k=1)[0]
        expected = [sum(choices[j][i]*f for j,f in zip(ids,factors,strict=True))/total
                    for i in range(len(self.weights))]
        trace.append([a-b for a,b in zip(choices[pick],expected,strict=True)])
        ids.remove(pick)
        return [pick,*sorted(ids,key=lambda j: (-score(choices[j]),j))]

    def update(self, trace, result, lr):
        reward = 1.0/(1+result["visits"]/40) if result["status"]=="POSITIVE" else -0.15
        advantage = reward-self.mean
        self.mean += 0.1*advantage
        before = self.weights[:]
        if trace:
            for i,vector in enumerate(zip(*trace,strict=True)):
                self.weights[i] = max(-3,min(3,self.weights[i]+lr*advantage*sum(vector)/len(trace)))
            self.updates += 1
        return dict(reward=reward, advantage=advantage, stochastic_choices=len(trace),
                    before=before, after=self.weights[:])


class Growth:
    def __init__(self, grammar, projections, contacts):
        self.grammar = grammar
        self.model = grammar.model
        self.kinds = set(grammar.inventory)
        self.projections = projections
        self.contacts = contacts

    @lru_cache(maxsize=10000)
    def links(self, j, p):
        g,x,y = p
        return {(h,x+a,y+b):r for r in self.grammar.roles[j]
                for h,a,b in (self.model.action(g,r),)}

    def front(self, chosen, depth):
        distances = {CENTRE:0}
        pending = deque([CENTRE])
        while pending:
            p = pending.popleft()
            level = distances[p]
            if p not in chosen or level == depth:
                continue
            for q in self.links(chosen[p],p):
                if q not in distances:
                    distances[q] = level+1
                    pending.append(q)
        return {p:d for p,d in distances.items() if p not in chosen}

    def candidates(self, p, patch, chosen):
        allowed = self.kinds.copy()
        for q,i in chosen.items():
            role = self.links(i,q).get(p)
            if role is not None:
                allowed &= self.projections[i,role]
        for j in sorted(allowed):
            star = self.grammar.at(j,p)
            if not self.grammar.compatible(patch,star):
                continue
            if all(q not in chosen or chosen[q] in self.projections[j,r]
                   for q,r in self.links(j,p).items()):
                yield j,star

    def features(self, j, p, star, patch, chosen, depth):
        links = self.links(j,p)
        open_links = [r for q,r in links.items() if q not in chosen]
        return (len(star-patch)/8, len(open_links)/8, len(star&patch)/8, depth/5,
                sum(len(self.projections[j,r]) for r in open_links)/32,
                sum(q[0]>=6 for q in star-patch)/8)

    def run(self, root, depth, limits, policy, mode, rng):
        begun = time.perf_counter()
        visits = 0
        choices_seen = 0
        trace = []
        found = None
        largest = 0

        def visit(patch,chosen):
            nonlocal visits, choices_seen, found, largest
            if visits>=limits["visits"] or time.perf_counter()-begun>=limits["seconds"]:
                return dict(status="UNKNOWN")
            visits += 1
            largest = max(largest,len(patch))
            front = self.front(chosen,depth)
            if not front:
                found = sorted(chosen.items())
                return dict(status="POSITIVE")
            trial = None
            for p in sorted(front,key=lambda q:(front[q],q)):
                candidates = dict(self.candidates(p,patch,chosen))
                if trial is None or len(candidates)<len(trial[1]):
                    trial = p,candidates
                if not candidates:
                    break
            p, candidates = trial
            choices_seen += len(candidates)>1
            scores = {j:self.features(j,p,star,patch,chosen,front[p]) for j,star in candidates.items()}
            children = []
            for j in policy.order(scores,mode,rng,trace):
                next_chosen = {**chosen,p:j}
                child = visit(patch|candidates[j],next_chosen)
                children.append((j,child))
                if child["status"]!="NEGATIVE":
                    return dict(status=child["status"],anchor=p,children=children)
            return dict(status="NEGATIVE",anchor=p,children=children)

        tree = visit(self.grammar.inventory[root],{CENTRE:root})
        return dict(status=tree["status"],tree=tree,witness=found,visits=visits,
                    multi_action_nodes=choices_seen,largest=largest,seconds=time.perf_counter()-begun),trace

    def verify_positive(self, root, depth, witness):
        chosen = dict(witness)
        assert len(chosen)==len(witness) and chosen[CENTRE]==root
        assert set(chosen.values())<=self.kinds
        patch = set()
        for p,j in chosen.items():
            g,x,y = p
            for h,a,b in self.grammar.inventory[j]:
                k,u,v = self.model.action(g,(h,a,b))
                patch.add((k,x+u,y+v))
        samples = set()
        for p in patch:
            support = set(self.model.support(p))
            assert len(support)==240 and samples.isdisjoint(support)
            samples.update(support)
        adjacent = {}
        for g,x,y in patch:
            relative = {(k,x+u,y+v) for h,a,b in self.contacts
                        for k,u,v in (self.model.action(g,(h,a,b)),)}
            adjacent[g,x,y] = relative & patch
        distances = {CENTRE:0}
        pending = deque([CENTRE])
        while pending:
            p = pending.popleft()
            if distances[p]==depth:
                continue
            for q in adjacent[p]:
                if q not in distances:
                    distances[q] = distances[p]+1
                    pending.append(q)
        assert set(distances)==set(chosen)
        for p,j in chosen.items():
            g,x,y = p
            actual = set()
            for role in self.grammar.roles[j]:
                k,u,v = self.model.action(g,role)
                q = k,x+u,y+v
                actual.add(q)
                if q in chosen:
                    assert chosen[q] in self.projections[j,role]
            assert actual==adjacent[p]
        return dict(status="VERIFIED",assigned=len(chosen),tiles=len(patch),
                    placement_set=sorted(patch),distances=dict(Counter(distances.values())))


def prepare():
    data = load("input/exact-point-model-v1.json")
    model = Model(data)
    root_data = load("input/catalogue-v1.json")
    summary = load("input/grammar-summary-v1.json")
    raw = load("input/grammar-results-v1.json")
    kinds = summary["retained"]
    assert len(kinds)==25 and kinds==raw["rounds"][-1]["active"]
    assert not raw["rounds"][-1]["rejected"]
    inventory = {i:frozenset(map(tuple,root_data[i]["shape"])) for i in kinds}
    projections = {}
    for row in raw["interfaces"]:
        assert all(r["checked"]["status"]=="VERIFIED" for r in row["candidates"])
        projections[row["shell"],tuple(row["anchor"])] = {
            r["neighbor"] for r in row["candidates"] if r["raw"]["status"]=="POSITIVE"}
    assert len(projections)==141 and sum(map(len,projections.values()))==222
    contacts = unpack(ROOT/"input/contact-catalogue-v1.json.gz")
    assert contacts["model"]==data
    return Growth(Grammar(model,inventory),projections,rooted_contacts(model,contacts)),kinds


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==h for n,h in protocol["pins"].items())
    engine,kinds = prepare()
    kinds.sort(key=lambda i:hashlib.sha256(f"shell-action-root-v1:{i}".encode()).digest())
    train,test = kinds[:protocol["train_count"]],kinds[protocol["train_count"]:]
    policy = Policy()
    rng = random.Random(protocol["seed"])
    results = []
    qualification,_ = engine.run(train[0],1,protocol["limits"],policy,"HEURISTIC",rng)
    assert qualification["status"]=="POSITIVE"
    assert engine.verify_positive(train[0],1,qualification["witness"])["status"]=="VERIFIED"
    print(json.dumps(dict(stage="QUALIFIED",root=train[0])),flush=True)
    for iteration in range(protocol["rounds"]):
        for root in train:
            depth = protocol["train_depths"][iteration%len(protocol["train_depths"])]
            raw,trace = engine.run(root,depth,protocol["limits"],policy,"TRAIN",rng)
            checked = engine.verify_positive(root,depth,raw["witness"]) if raw["witness"] else None
            update = policy.update(trace,raw,protocol["learning_rate"])
            results.append(dict(phase="training",mode="TRAIN",root=root,depth=depth,
                                raw=raw,checked=checked,update=update))
        print(json.dumps(dict(stage="TRAIN",round=iteration+1,updates=policy.updates,
                              weights=policy.weights)),flush=True)
    frozen = policy.weights[:]
    arms = protocol["evaluation_arms"]
    index = 0
    for depth in protocol["test_depths"]:
        for root in test:
            for mode in arms[index%len(arms):]+arms[:index%len(arms)]:
                seed = protocol["seed"]+10000+100*depth+root
                raw,_ = engine.run(root,depth,protocol["limits"],policy,mode,random.Random(seed))
                checked = engine.verify_positive(root,depth,raw["witness"]) if raw["witness"] else None
                results.append(dict(phase="evaluation",mode=mode,root=root,depth=depth,raw=raw,checked=checked))
            index += 1
        print(json.dumps(dict(stage="TEST",depth=depth,cases=index)),flush=True)
    assert frozen==policy.weights
    data = {}
    for mode in [*arms,"TRAIN"]:
        rows = [r for r in results if r["mode"]==mode]
        data[mode] = dict(status=dict(Counter(r["raw"]["status"] for r in rows)),
                          visits=sum(r["raw"]["visits"] for r in rows),
                          multi_action_nodes=sum(r["raw"]["multi_action_nodes"] for r in rows),
                          seconds=sum(r["raw"]["seconds"] for r in rows),
                          max_tiles=max(r["checked"]["tiles"] if r["checked"] else 0 for r in rows))
    save("data/results-v1.json",results)
    report = dict(status="CHECKED_SHELL_ACTION_RL_EXPERIMENT",train=train,test=test,weights=frozen,
                  updates=policy.updates,methods=data,
                  scope="Whole shell actions add every member simultaneously. Positive witnesses are independently checked by atom occupancy and exact contact-graph closure. Bounded or internally exhausted outcomes without a verified witness establish no plane-level conclusion.")
    save("data/summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__ == "__main__":
    main()
