"""Check the inferred Golden Hex translations by cancellation of exact boundaries."""

from collections import Counter, defaultdict
from fractions import Fraction
from itertools import pairwise
import json
from math import isqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model,inside,load,mat,pin,save
from golden_geometry_v1 import add,area2,cover,strip,sub,support,transform,words
from triangle_geometry_v1 import _segments_meet


def axial(u,v):
    assert (v-u)%2==0
    return u,(v-u)//2


def center(model,patch):
    points=[p for t in patch for p in model.poly(t)]
    totals=tuple(map(sum,zip(*points)))
    assert all(n%len(points)==0 for n in totals)
    return tuple(n//len(points) for n in totals)


def signed(ring):
    return sum(x*v-y*u for (x,y),(u,v) in pairwise((*ring,ring[0])))


def norm(q):
    x,y=q
    return x*x+x*y+y*y


def ball(ring):
    if not inside((0,0),tuple(pairwise((*ring,ring[0])))):
        return 0
    radii=[]
    for a,b in pairwise((*ring,ring[0])):
        d=sub(b,a)
        twice=norm(add(a,d))-norm(a)-norm(d)
        if 0 < -twice < 2*norm(d):
            radii.append(norm(a)-Fraction(twice*twice,4*norm(d)))
        else:
            radii.append(Fraction(min(norm(a),norm(b))))
    distance=min(radii)
    return isqrt(distance.numerator//distance.denominator)


def check_ring(ring):
    assert len(ring)==len(set(ring)) and signed(ring)>0
    buckets=defaultdict(list)
    for a,b in pairwise((*ring,ring[0])):
        xmin,xmax=sorted((a[0],b[0]))
        ymin,ymax=sorted((a[1],b[1]))
        # Use inclusive cells so exact touching or crossing cannot evade the filter.
        for x in range(xmin,xmax+1):
            for y in range(ymin,ymax+1):
                for c,d in buckets[x,y]:
                    if a not in (c,d) and b not in (c,d):
                        assert not _segments_meet(a,b,c,d),(a,b,c,d)
                buckets[x,y].append((a,b))


def primitive(ring):
    from math import gcd
    if signed(ring)<0:
        ring=ring[::-1]
    for a,b in pairwise((*ring,ring[0])):
        dx,dy=sub(b,a)
        g=gcd(dx,dy)
        assert g
        d=(dx//g,dy//g)
        for _ in range(g):
            q=add(a,d)
            yield a,q
            a=q


def join_boundaries(model,children):
    """The winding of the resulting simple ring certifies exact coverage."""
    chain=Counter()
    for ring,turn,shift in children:
        placed=tuple(add(mat(model.groups[turn],p),shift) for p in ring)
        for a,b in primitive(placed):
            lo,hi=sorted((a,b))
            chain[lo,hi]+=1 if a==lo else -1
    outgoing={}
    for (a,b),k in chain.items():
        if not k:
            continue
        assert abs(k)==1
        if k<0:
            a,b=b,a
        assert a not in outgoing
        outgoing[a]=b
    start=min(outgoing)
    ring=[start]
    a=outgoing.pop(start)
    while a!=start:
        ring.append(a)
        a=outgoing.pop(a)
    assert not outgoing
    check_ring(ring)
    return tuple(ring)


def compose(model,children):
    ring=join_boundaries(model,[(ring,g,shift) for _,ring,g,shift in children])
    tiles=[t for patch,_,g,shift in children for t in transform(model,patch,g,shift)]
    assert len(tiles)==len(set(tiles)) and signed(ring)==len(tiles)*area2(model.polygons[0])
    return tuple(sorted(tiles)),ring


def from_tiles(model,patch):
    return compose(model,[(((g,0,0),),model.polygons[g],0,(x,y)) for g,x,y in patch])


def t_children(model,level,L,H):
    rows=[("T",level-1,0,axial(-2*L,2*L)),("T",level-1,0,axial(0,-4*L)),
          ("T",level-1,0,axial(2*L,2*L))]
    left=axial(-L,H)
    rows.extend(("P",level-1,model.compose[g,3],mat(model.groups[g],left)) for g in (0,3,4))
    if level>=3:
        rows.append(("T",level-2,6,(0,0)))
    return rows


def p_children(level,L,M,K,H):
    U,V=5*L-2*K-7,3*L-3
    rows=[("P",level-1,4,axial(-L-M,-3*K)),("P",level-1,4,axial(L+M,3*K)),
          ("P",level-1,3,(0,0)),("P",level-1,0,axial(-L-K,3*M)),("P",level-1,0,axial(L+K,-3*M)),
          ("S",level,0,axial(-U,-V)),("S",level,6,axial(U,V))]
    if level>=2:
        rows.extend((("T",level-1,6,axial(-3*L,-L-2*K)),("T",level-1,0,axial(3*L,L+2*K))))
    if level>=3:
        rows.extend((("T",level-2,0,axial(-L,H)),("T",level-2,6,axial(L,-H))))
    return rows


def main():
    p=load("growth-protocol-v1.json")
    assert p["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/name)==digest for name,digest in p["pins"].items())
    model=Model(load("input/exact-point-model-v1.json"))
    ref={row["name"]:tuple(map(tuple,row["patch"])) for row in load("data/recovery-v1.json")["levels"]}
    bases={}
    for name in ("P0","T1"):
        t=transform(model,ref[name],0,sub((0,0),center(model,ref[name])))
        bases[name]=from_tiles(model,t)[1]
    # Local word checks use the exact same orientation and offset templates.
    pair_cert={}
    for word in ("00","01","10","11"):
        t=strip(word)
        pair_cert[word]=len(support(model,t))==480
    assert all(pair_cert.values())
    alphabet=words(2*p["maximum"])
    library={(name[0],int(name[1])):(transform(model,ref[name],0,sub((0,0),center(model,ref[name]))),ring)
             for name,ring in bases.items()}
    output=[]
    for n in range(1,p["maximum"]+1):
        L,M,K=map(lambda k:len(alphabet[k]),(2*n,2*n-1,2*n-2))
        H=M-K
        t=strip(alphabet[2*n])
        library["S",n]=from_tiles(model,t)
        for kind in ("T","P"):
            rows=t_children(model,n,L,H) if kind=="T" else p_children(n,L,M,K,H)
            if (kind,n) not in library:
                library[kind,n]=compose(model,[( *library[label,k],g,shift) for label,k,g,shift in rows])
            patch,ring=library[kind,n]
            name=f"{kind}{n}"
            prior=name in ref
            if prior:
                assert patch==transform(model,ref[name],0,sub((0,0),center(model,ref[name]))),name
            result=dict(id=name,tiles=len(patch),boundary_vertices=len(ring),disk_radius=ball(ring),
                        source="REFERENCE" if prior else "PREDICTION")
            print(json.dumps(result,sort_keys=True),flush=True)
            output.append(dict(**result,children=rows if name!="T1" else [],ring=ring,patch=patch))
    save("data/growth-v1.json",dict(status="CHECKED_EXACT_GOLDEN_HEX_GROWTH",pairs=pair_cert,levels=output))


if __name__=="__main__":
    main()
