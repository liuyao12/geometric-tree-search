"""Recover a four-rhomb model and verify the Turtle-to-Rhombille bridge."""

from collections import Counter, defaultdict
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))

from actions_v1 import prepare
from cluster_v1 import bounds, edges, inside, load, mat, pin, save
from compound_v1 import polarity
from triples_v1 import replay_patch

DIRECTIONS = ((2,0), (0,2), (-2,2), (-2,0), (0,-2), (2,-2))


def add(a, b):
    return a[0]+b[0], a[1]+b[1]


def sub(a, b):
    return a[0]-b[0], a[1]-b[1]


def norm(p):
    x, y = p
    return x*x+x*y+y*y


def cross(a, b):
    return a[0]*b[1]-a[1]*b[0]


def area2(p):
    return sum(cross(a, b) for a, b in edges(p))


def edge(a, b):
    return tuple(sorted((a, b)))


def reduced(ring):
    ring = list(ring)
    changed = True
    while changed:
        changed = False
        for i, b in enumerate(ring):
            a, c = ring[i-1], ring[(i+1)%len(ring)]
            if cross(sub(b, a), sub(c, b)) == 0:
                del ring[i]
                changed = True
                break
    return tuple(ring)


def key(ring):
    return min(ring[i:]+ring[:i] for i in range(len(ring)))


def union_boundary(rings):
    directed = set()
    for ring in rings:
        assert area2(ring) > 0
        for a, b in edges(ring):
            assert (a, b) not in directed
            if (b, a) in directed:
                directed.remove((b, a))
            else:
                directed.add((a, b))
    return directed


def trace(boundary):
    next_point = dict(boundary)
    assert len(next_point) == len(boundary)
    first = min(next_point)
    ring = [first]
    while (q := next_point[ring[-1]]) != first:
        assert q not in ring
        ring.append(q)
    assert len(ring) == len(boundary)
    return tuple(ring)


def color(p):
    return (p[0]-p[1]) % 6


def midpoint(a, b):
    x, y = add(a, b)
    assert x % 2 == y % 2 == 0
    return x//2, y//2


def grid(region, anchor):
    """Generate the Rhombille grid by merging triangles across non-center edges."""
    x0, x1, y0, y1 = bounds(region)
    ax, ay = anchor
    d = color(anchor)
    halves = defaultdict(list)
    for x in range(x0-(x0-ax)%2-6, x1+8, 2):
        for y in range(y0-(y0-ay)%2-6, y1+8, 2):
            a, b, c, p = (x,y), (x+2,y), (x,y+2), (x+2,y+2)
            for t in ((a,b,c), (p,c,b)):
                seam = tuple(sorted(q for q in t if color(q) != d))
                assert len(seam) == 2
                halves[seam].append(t)
    rhombs = {}
    for k, triangles in halves.items():
        if len(triangles) != 2:
            continue
        rhomb = trace(union_boundary(triangles))
        assert len(rhomb) == 4 and area2(rhomb) == 8
        assert all(norm(sub(b, a)) == 4 for a, b in edges(rhomb))
        assert midpoint(rhomb[0], rhomb[2]) == midpoint(rhomb[1], rhomb[3])
        rhombs[k] = (rhomb, triangles)
    return rhombs


def footprint_candidates(outline):
    parity = Counter((x%2, y%2) for x, y in outline)
    odd, count = parity.most_common(1)[0]
    assert count == 7 and parity.most_common(2)[1][1] < count
    contour = tuple((x, y) for x, y in outline if (x%2, y%2) == odd)
    invalid, = [(a, b) for a, b in edges(contour) if norm(sub(b, a)) != 4]
    a, b = invalid
    join = contour.index(a)+1
    for v in sorted(add(a, d) for d in DIRECTIONS if norm(sub(add(a, d), b)) == 4):
        ring = contour[:join]+(v,)+contour[join:]
        if area2(ring) != 32:
            continue
        for anchor in ring[:2]:
            if all((color(p) == color(anchor)) != (color(q) == color(anchor))
                   for p, q in edges(ring)):
                yield ring, anchor


def recover(outline):
    hits = []
    attempts = Counter()
    for ring, anchor in footprint_candidates(outline):
        attempts["footprints"] += 1
        rhombs = grid(ring, anchor)
        scaled = edges(tuple((3*x,3*y) for x,y in ring))
        selected = []
        for polygon, triangles in rhombs.values():
            centers3 = [(sum(p[0] for p in t), sum(p[1] for p in t)) for t in triangles]
            include = [inside(t, scaled) for t in centers3]
            assert include[0] == include[1]
            if include[0]:
                selected.append(polygon)
        assert len(selected) == 4 and union_boundary(selected) == set(edges(ring))
        outer = defaultdict(list)
        for polygon, _ in rhombs.values():
            center = midpoint(polygon[0], polygon[2])
            for a, b in edges(polygon):
                outer[edge(a,b)].append((polygon in selected, center))
        choices = []
        for a, b in edges(ring):
            candidates = dict(outer[edge(a,b)])
            assert set(candidates) == {False, True}
            choices.append((a, candidates))
        for black in combinations(range(len(ring)), 2):
            attempts["edge_colorings"] += 1
            original = tuple(p for i, (a, options) in enumerate(choices)
                             for p in (a, options[i in black]))
            if key(reduced(original)) != key(reduced(outline)):
                continue
            outer_colors = {edge(a,b): "black" if i in black else "red"
                            for i, (a,b) in enumerate(edges(ring))}
            arrangements = []
            for hexes in combinations(selected, 3):
                center = set.intersection(*(set(h) for h in hexes))
                if len(center) != 1:
                    continue
                (h,) = center
                border = trace(union_boundary(hexes))
                if len(border) != 6 or not all(norm(sub(v, h)) == 4 for v in border):
                    continue
                (red,) = [r for r in selected if r not in hexes]
                sides = {edge(a, b) for a, b in edges(red)}
                shared = sides & {edge(a, b) for a, b in edges(border)}
                if len(shared) == 1 and all(outer_colors[e] == "red" for e in sides-shared):
                    arrangements.append((h, red, tuple(sorted(hexes))))
            (h, red, hexes), = arrangements
            removed = [sum(outer_colors.get(edge(a,b)) == "black" for a,b in edges(r))
                       for r in selected]
            assert max(removed) <= 1
            hits.append(dict(footprint=ring, grid_anchor=anchor, center=h, red_rhomb=red,
                             hex_rhombs=hexes, rings=selected, colors=outer_colors,
                             removed_per_rhomb=sorted(removed)))
    hit, = hits
    return hit, dict(attempts)


class Bridge:
    def __init__(self, engine):
        self.engine = engine
        self.model = engine.model
        self.base, self.attempts = recover(self.model.polygons[0])

    def point(self, pose, p):
        g, x, y = pose
        return add(mat(self.model.groups[g], p), (x,y))

    def pose(self, t):
        rings = [tuple(self.point(t, p) for p in r) for r in self.base["rings"]]
        exterior = {edge(self.point(t,a),self.point(t,b)): k
                    for (a,b), k in self.base["colors"].items()}
        red = frozenset(self.point(t,p) for p in self.base["red_rhomb"])
        return rings, exterior, red

    def phase(self, t):
        x,y = self.point(t, self.base["grid_anchor"])
        return x%2, y%2, color((x,y))

    def phase_certificate(self, active):
        rows = []
        for j in sorted(active):
            for t in self.engine.grammar.roles[j]:
                assert self.phase(t) == self.phase((0,0,0))
                rows.append((j, t))
        return rows

    def extract(self, record, depth):
        placement = [tuple(p) for p in record["checked"]["placement_set"]]
        phase = {self.phase(p) for p in placement}
        assert len(phase) == 1
        used = {}
        for t in placement:
            rings, exterior, red = self.pose(t)
            for ring in rings:
                key = frozenset(ring)
                assert key not in used
                used[key] = (t, exterior, "red" if key == red else "hex")
        vertices = tuple(p for r in used for p in r)
        anchor = self.point(placement[0], self.base["grid_anchor"])
        grid_rhombs = {frozenset(p): p for p, _ in grid(vertices, anchor).values()}
        assert used.keys() <= grid_rhombs.keys()
        edge_cells = defaultdict(list)
        for k, polygon in grid_rhombs.items():
            for a, b in edges(polygon):
                edge_cells[edge(a,b)].append(k)
        colors = Counter()
        holes = []
        for s, cells in edge_cells.items():
            if len(cells) != 2 or not all(k in used for k in cells):
                continue
            a, b = (used[k] for k in cells)
            if a[0] == b[0]:
                continue
            colors[tuple(sorted((a[1][s], b[1][s])))] += 1
        assert not colors[("red","red")]
        for cell, polygon in grid_rhombs.items():
            if cell in used:
                continue
            sides = [edge(a,b) for a,b in edges(polygon)]
            adjacent = [next((c for c in edge_cells[s] if c != cell), None) for s in sides]
            if all(k in used and used[k][1][s] == "red" for k,s in zip(adjacent,sides,strict=True)):
                holes.append(polygon)
        return dict(root=record["root"], depth=depth, phase=next(iter(phase)),
                    placements=placement, occupied=[(grid_rhombs[k], v[0], v[2])
                                                    for k,v in sorted(used.items(),key=lambda p: sorted(p[0]))],
                    complete_holes=sorted(holes), seam_colors=[(k,n) for k,n in sorted(colors.items())])


def summary(bank):
    color_counts = Counter()
    for r in bank:
        color_counts.update(dict(r["seam_colors"]))
    return dict(patches=len(bank), turtles=sum(len(r["placements"]) for r in bank),
                rhombs=sum(len(r["occupied"]) for r in bank),
                holes=sum(len(r["complete_holes"]) for r in bank),
                seam_colors={"/".join(k):n for k,n in sorted(color_counts.items())})


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == v for n,v in protocol["pins"].items())
    engine, _ = prepare()
    retained = load("input/closure-results-v1.json")["rounds"][-1]
    active = set(retained["active"])
    engine.kinds = active
    bridge = Bridge(engine)
    phase = bridge.phase_certificate(active)
    result = dict(model={**bridge.base,"colors":sorted(bridge.base["colors"].items())},
                  attempts=bridge.attempts, phase_certificate=phase, banks={})
    for name, depth, bank in (("original",8,retained["records"]),
                              ("deeper",10,load("input/holdout-v1.json"))):
        rows = []
        for rec in bank:
            checked = replay_patch(engine, rec, depth)
            assert checked["placement_set"] == sorted(map(tuple, rec["checked"]["placement_set"]))
            rows.append(bridge.extract(rec, depth))
        result["banks"][name] = rows
    report = dict(status="CHECKED_EXACT_TURTLE_RHOMBILLE_BRIDGE",
                  edge_search=bridge.attempts, phase_contacts=len(phase),
                  phases=sorted({r["phase"] for bank in result["banks"].values() for r in bank}),
                  banks={k:summary(v) for k,v in result["banks"].items()})
    save("data/bridge-results-v1.json", result)
    save("data/bridge-summary-v1.json", report)
    print(json.dumps(report,sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
