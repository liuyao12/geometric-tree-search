"""Exact consistency of tile-centred Turtle shell receptors."""

from collections import Counter
from functools import lru_cache
from itertools import combinations
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, load, pin, save

CENTRE = (0, 0, 0)


class Grammar:
    def __init__(self, model, inventory):
        self.model = model
        self.inventory = inventory
        self.roles = {i: tuple(p for p in s if p != CENTRE) for i, s in inventory.items()}
        self.domains = {}
        for i, roles in self.roles.items():
            for p in roles:
                self.domains[i, p] = tuple(j for j in inventory if self.compatible(inventory[i], self.at(j, p)))

    @lru_cache(maxsize=8192)
    def at(self, kind, p):
        g, x, y = p
        return frozenset((h, x+a, y+b) for h,a,b in
                         (self.model.action(g,t) for t in self.inventory[kind]))

    @lru_cache(maxsize=4096)
    def support(self, p):
        return frozenset(self.model.support(p))

    @lru_cache(maxsize=250000)
    def overlap(self, g, h, x, y):
        return not self.support((g,0,0)).isdisjoint(self.support((h,x,y)))

    def compatible(self, a, b):
        common = a & b
        return not any(self.overlap(g,h,u-x,v-y) for g,x,y in a-common for h,u,v in b-common)

    def domain(self, kind, anchor, active, occupied, pin_role=None):
        allowed = self.domains[kind,anchor]
        if pin_role and anchor == pin_role[0]:
            allowed = (pin_role[1],) if pin_role[1] in allowed else ()
        return [j for j in allowed if j in active and self.compatible(occupied,self.at(j,anchor))]

    def search(self, kind, active, limits, pin_role=None):
        start = time.perf_counter()
        visits = 0
        witness = None

        def visit(todo, patch, taken):
            nonlocal visits, witness
            if visits >= limits["visits"] or time.perf_counter()-start >= limits["seconds"]:
                return dict(status="UNKNOWN")
            visits += 1
            if not todo:
                witness = taken
                return dict(status="POSITIVE")
            p, choices = min(((p,self.domain(kind,p,active,patch,pin_role)) for p in todo),
                             key=lambda t: (len(t[1]), t[0]))
            children = []
            for j in choices:
                child = visit(tuple(q for q in todo if q != p), patch|self.at(j,p), (*taken,(p,j)))
                children.append((j,child))
                if child["status"] != "NEGATIVE":
                    return dict(status=child["status"],anchor=p,children=children)
            return dict(status="NEGATIVE",anchor=p,children=children)

        tree = visit(self.roles[kind],self.inventory[kind],())
        return dict(status=tree["status"],tree=tree,witness=witness,visits=visits,
                    seconds=time.perf_counter()-start)

    def verify(self, kind, active, raw, pin_role=None):
        # Rebuild absolute placement support. No domain or overlap caches from search.
        @lru_cache(maxsize=2048)
        def sites(p):
            return frozenset(self.model.support(p))

        def place(p, j):
            g,x,y = p
            return {(u,x+a,y+b) for h,s,t in self.inventory[j]
                    for u,a,b in (self.model.action(g,(h,s,t)),)}

        def admits(patch, new):
            extra = new-patch
            filled = set().union(*(sites(t) for t in patch))
            added = set().union(*(sites(t) for t in extra))
            return len(added)==240*len(extra) and filled.isdisjoint(added)

        if raw["status"] == "UNKNOWN":
            return dict(status="BOUNDED")
        if raw["status"] == "POSITIVE":
            choices = dict(raw["witness"])
            assert set(choices) == set(self.roles[kind]) and len(choices) == len(raw["witness"])
            assert not pin_role or choices[pin_role[0]] == pin_role[1]
            assert set(choices.values()) <= active
            patch = set(self.inventory[kind])
            for p,j in sorted(choices.items()):
                next_shell = place(p,j)
                assert admits(patch,next_shell)
                patch |= next_shell
            return dict(status="VERIFIED",tiles=sorted(patch))
        count = 0

        def verify_node(node, todo, patch):
            nonlocal count
            count += 1
            assert node["status"] == "NEGATIVE"
            p = node["anchor"]
            assert p in todo
            children = dict(node["children"])
            allowed = (pin_role[1],) if pin_role and p == pin_role[0] else sorted(active)
            candidates = {j: place(p,j) for j in allowed}
            legal = {j:s for j,s in candidates.items() if j in active and admits(patch,s)}
            assert legal.keys() == children.keys() and len(children) == len(node["children"])
            for j,s in legal.items():
                verify_node(children[j],todo-{p},patch|s)

        verify_node(raw["tree"],set(self.roles[kind]),set(self.inventory[kind]))
        assert count == raw["visits"]
        return dict(status="VERIFIED",nodes=count)


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == h for n,h in protocol["pins"].items())
    catalogue = load("input/catalogue-v1.json")
    previous = load("input/second-ring-v1.json")
    model = Model(load("input/exact-point-model-v1.json"))
    inventory = {}
    for row in previous:
        assert row["checked"]["status"] == "VERIFIED"
        if row["raw"]["status"] == "POSITIVE":
            i = row["shell"]
            shell = frozenset(map(tuple,row["seed"]))
            assert shell == frozenset(map(tuple,catalogue[i]["shape"]))
            assert CENTRE in shell
            for p,q in combinations(shell,2):
                assert set(model.support(p)).isdisjoint(model.support(q))
            inventory[i] = shell
    assert len(inventory) == 37
    grammar = Grammar(model,inventory)
    active = set(inventory)
    rounds = []
    while True:
        rejected = set()
        records = []
        for i in sorted(active):
            raw = grammar.search(i,active,protocol["limits"])
            checked = grammar.verify(i,active,raw)
            if raw["status"] == "NEGATIVE":
                assert checked["status"] == "VERIFIED"
                rejected.add(i)
            records.append(dict(shell=i,raw=raw,checked=checked))
        rounds.append(dict(active=sorted(active),rejected=sorted(rejected),records=records))
        print(json.dumps(dict(round=len(rounds),retained=len(active)-len(rejected),removed=len(rejected),
                              bounded=sum(r["raw"]["status"]=="UNKNOWN" for r in records))),flush=True)
        if not rejected:
            break
        active -= rejected
        assert active

    interfaces = []
    for i in sorted(active):
        for p in grammar.roles[i]:
            candidates = []
            for j in grammar.domains[i,p]:
                if j not in active:
                    continue
                raw = grammar.search(i,active,protocol["limits"],(p,j))
                checked = grammar.verify(i,active,raw,(p,j))
                candidates.append(dict(neighbor=j,raw=raw,checked=checked))
            interfaces.append(dict(shell=i,anchor=p,candidates=candidates))
    status = Counter(c["raw"]["status"] for row in interfaces for c in row["candidates"])
    save("data/results-v1.json",dict(rounds=rounds,interfaces=interfaces))
    summary = dict(status="CHECKED_JOINT_SHELL_GRAMMAR",initial=len(inventory),retained=sorted(active),
                   interface_roles=len(interfaces),interface_candidates=dict(status),
                   rounds=[dict(active=len(r["active"]),removed=len(r["rejected"]),
                                outcomes=dict(Counter(x["raw"]["status"] for x in r["records"]))) for r in rounds],
                   scope="Every surviving witness is one simultaneous assignment of compatible first shells to the neighbors of a central first shell. Iterated removal is necessary for full-plane extension, while retained cases remain finite witnesses.")
    save("data/summary-v1.json",summary)
    print(json.dumps(summary,sort_keys=True),flush=True)


if __name__ == "__main__":
    main()
