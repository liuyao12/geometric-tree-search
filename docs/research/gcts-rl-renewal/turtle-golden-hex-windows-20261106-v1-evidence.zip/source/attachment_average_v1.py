"""Certify linear obstructions to periodic refinements of local attachment rules."""

from collections import defaultdict
from fractions import Fraction
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from attachment_solver_v1 import collect
from phase_owner_v1 import OwnerGeometry
from rhombille_v1 import Bridge, ROOT, load, pin, prepare, save


def add_scaled(a,b,scale):
    for k,v in b.items():
        a[k]=a.get(k,Fraction(0))+scale*v
        if not a[k]:
            del a[k]


def equations(demands,keys):
    rows=[]
    for demand in demands:
        c=defaultdict(Fraction)
        rhs=Fraction(1)
        for key,positive in demand:
            c[keys[key]]+=1 if positive else -1
            rhs-=not positive
        rows.append(({i:v for i,v in c.items() if v},rhs))
    return rows


def prove(rows):
    pivots={}
    for i,(source,rhs) in enumerate(rows):
        c=source.copy()
        recipe={i:Fraction(1)}
        while c:
            k=min(c)
            a=c[k]
            if k not in pivots:
                pivots[k]=({j:v/a for j,v in c.items()},rhs/a,{j:v/a for j,v in recipe.items()})
                break
            row,value,trace=pivots[k]
            add_scaled(c,row,-a)
            add_scaled(recipe,trace,-a)
            rhs-=a*value
        else:
            if rhs:
                return {j:v/rhs for j,v in recipe.items()}
    return None


def replay(rows,recipe):
    c={}
    rhs=Fraction(0)
    for i,weight in recipe.items():
        row,value=rows[i]
        add_scaled(c,row,weight)
        rhs+=weight*value
    assert not c and rhs==1


def main():
    p=load("average-protocol-v1.json")
    assert p["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==d for n,d in p["pins"].items())
    engine,_=prepare()
    geometry=OwnerGeometry(Bridge(engine))
    out=[]
    for radius in p["radii"]:
        demands,keys,_,_=collect(geometry,radius)
        rows=equations(demands,keys)
        proof=prove(rows)
        if proof:
            replay(rows,proof)
        summary=dict(radius=radius,variables=len(keys),demands=len(demands),
                     certificate_rows=len(proof or {}),inconsistent=bool(proof))
        out.append(dict(summary=summary,demands=demands,keys=list(keys),
                        certificate=[(i,str(w)) for i,w in sorted((proof or {}).items())]))
        print(json.dumps(summary,sort_keys=True),flush=True)
    save("data/attachment-average-v1.json",dict(status="CHECKED_RATIONAL_ATTACHMENT_OBSTRUCTIONS",runs=out))


if __name__=="__main__":
    main()
