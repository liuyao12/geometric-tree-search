"""Search exact threefold clusters and bound ambiguities by local shell replay."""

from collections import Counter, defaultdict
from functools import lru_cache
from itertools import combinations
import json
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))

from atlas_v1 import partition
from actions_v1 import CENTRE, Policy, prepare
from closure_v1 import Audit
from cluster_v1 import load, pin, save
from compound_v1 import graph, polarity
from local_v1 import apply

class Study:
    def __init__(self, engine, active, omitted, role):
        self.engine = engine
        self.model = engine.model
        self.audit = Audit(engine)
        self.active = active
        self.signs, self.special, _ = polarity(engine)
        self.omitted = omitted
        self.role = role
        self.rotations = tuple(g for g in sorted(self.model.groups) if g and
            self.model.compose[self.model.compose[g, g], g] == 0)
        assert len(self.rotations) == 2 and self.model.compose[role[0], role[0]] == 0
        self.core_roles = tuple(p for i, p in enumerate(engine.grammar.roles[self.special])
                                if i != omitted)
        self.bases = {
            "core": frozenset((CENTRE, *self.core_roles)),
            "pair": frozenset((CENTRE, role)),
            "single": frozenset((CENTRE,)),
        }

    def move(self, poses, group, x=0, y=0):
        return frozenset((g, u+x, v+y) for p in poses
                         for g, u, v in (self.model.action(group, p),))

    @lru_cache(maxsize=10000)
    def neighbors(self, p):
        return frozenset(apply(self.engine, p, r) for r in self.engine.contacts)

    def support(self, pieces):
        atoms = set().union(*(self.audit.support(p) for p in pieces))
        assert len(atoms) == 240*len(pieces)
        return atoms

    def normalize(self, group):
        frames = []
        for g in sorted(self.model.groups):
            turned = [self.move(pieces, g) for pieces in group]
            x, y = min((x, y) for pieces in turned for _, x, y in pieces)
            frames.append(tuple(sorted(tuple(sorted((h, u-x, v-y) for h, u, v in pieces))
                                       for pieces in turned)))
        return min(frames)

    def rooted(self, base):
        """Enumerate every contact triangle of rigid copies cycled by a rotation."""
        contact = set().union(*(self.neighbors(p) for p in base))
        atoms = self.support(base)
        found = {}
        for r in self.rotations:
            rotated = self.move(base, r)
            shifts = {(x-u, y-v) for g, x, y in contact for h, u, v in rotated if g == h}
            for x, y in sorted(shifts):
                second = self.move(base, r, x, y)
                third = self.move(second, r, x, y)
                assert self.move(third, r, x, y) == base
                if not third & contact:
                    continue
                b, c = self.support(second), self.support(third)
                if atoms & b or atoms & c or b & c:
                    continue
                key = tuple(sorted(tuple(sorted(q)) for q in (base, second, third)))
                found[key] = (r, x, y)
        return dict(sorted(found.items()))

    def force(self, kind, macros):
        """Necessary shell assignments for these complete prescribed macro pieces."""
        forced = {}
        for pieces in sorted(macros):
            frame = None
            if kind == "core":
                frames = [p for p in pieces if
                          {p, *(apply(self.engine, p, r) for r in self.core_roles)} == set(pieces)]
                frame, = frames
            for p in pieces:
                assert p not in forced
                forced[p] = ("special" if p == frame else
                             "owned" if kind == "core" else "unowned")
        return forced

    def check(self, kind, macros):
        """Exhaust a finite necessary CSP or return a compatible local witness."""
        forced = self.force(kind, macros)
        patch = set(forced)
        occupied = self.support(patch)

        def domain(p, assignment, patch, occupied):
            candidates = {self.special} if forced[p] == "special" else self.active-{self.special}
            for j, add, atoms in self.audit.legal(p, assignment, patch, occupied, candidates):
                links = self.audit.transform(p, j)
                if not self.neighbors(p) & patch <= links.keys():
                    continue
                if forced[p] == "unowned":
                    opposite = (q for q in links if self.signs[p[0]] != self.signs[q[0]])
                    if any(p == apply(self.engine, q, r) for q in opposite for r in self.core_roles):
                        continue
                if any(add & self.neighbors(q) - self.audit.transform(q, k).keys()
                       for q, k in assignment.items()):
                    continue
                yield j, add, atoms

        nodes = 0

        def visit(assignment, patch, occupied):
            nonlocal nodes
            nodes += 1
            if forced.keys() <= assignment.keys():
                return sorted(assignment.items()), None
            p, options = min(((p, list(domain(p, assignment, patch, occupied)))
                              for p in sorted(forced.keys()-assignment.keys())),
                             key=lambda item: len(item[1]))
            children = []
            for j, add, atoms in options:
                witness, failure = visit({**assignment, p:j}, patch | add, occupied | atoms)
                if witness is not None:
                    return witness, None
                children.append([j, failure])
            return None, [p, children]

        witness, failure = visit({}, patch, occupied)
        return dict(witness=witness, failure=failure, visits=nodes)

    def certificate(self, kind):
        base = self.bases[kind]
        rows = []
        for motif, rotation in self.rooted(base).items():
            rows.append(dict(motif=motif, rotation=rotation, shape=self.normalize(motif),
                             **self.check(kind, set(motif))))
        collisions = []
        for (i, a), (j, b) in combinations(enumerate(rows), 2):
            if a["witness"] is None or b["witness"] is None:
                continue
            union = set(a["motif"]) | set(b["motif"])
            partial = set()
            reason = None
            for macro in sorted(union):
                support = self.support(macro)
                if support & partial:
                    reason = "overlap"
                    break
                partial.update(support)
            res = dict(status="GEOMETRIC_OVERLAP") if reason else self.check(kind, union)
            collisions.append(dict(left=i, right=j, **res))
        return dict(kind=kind, motifs=rows, collisions=collisions)

    def extract(self, record, maximum_depth):
        # The older atlas defines a fixed depth-six guard. This audit applies
        # the same two-ring margin at either declared input depth.
        parts, owner, _, adjacent = partition(
            self.engine, record, self.omitted, self.role, self.special, self.signs)
        _, levels = graph(self.engine, set(adjacent))
        guard = {p for p, (_, pieces, _) in parts.items() if
                 max(levels[q] for q in pieces) <= maximum_depth-2}
        contacts = {p: {owner[q] for t in pieces for q in adjacent[t] if q in owner}-{p}
                    for p, (_, pieces, _) in parts.items()}
        triangles, motifs = Counter(), []
        uses = Counter()
        for a in sorted(guard):
            kind = parts[a][0]
            for b in sorted(contacts[a] & guard):
                if a >= b or parts[b][0] != kind:
                    continue
                for c in sorted(contacts[a] & contacts[b] & guard):
                    if b >= c or parts[c][0] != kind:
                        continue
                    triangles[kind] += 1
                    family = (a, b, c)
                    rotation = self.cycle(parts, family)
                    if rotation is None:
                        continue
                    uses.update(family)
                    ring = set().union(*(contacts[p] for p in family))-set(family)
                    profile = dict(Counter(parts[q][0] for q in sorted(ring))) if ring <= guard else None
                    motifs.append(dict(kind=kind, family=family, rotation=rotation,
                                       shape=self.normalize([parts[p][1] for p in family]),
                                       profile=profile))
        return dict(root=record["root"], triangles=dict(triangles), motifs=motifs,
                    reused_macros=sum(n > 1 for n in uses.values()),
                    parts={p: parts[p][:2] for p in guard})

    def cycle(self, parts, family):
        a, b, c = family
        for r in self.rotations:
            g, x, y = self.model.action(r, a)
            for h, u, v in parts[b][2]:
                if g != h:
                    continue
                dx, dy = u-x, v-y
                if (self.move(parts[a][1], r, dx, dy) == parts[b][1] and
                        self.move(parts[b][1], r, dx, dy) == parts[c][1]):
                    assert self.move(parts[c][1], r, dx, dy) == parts[a][1]
                    return r, dx, dy
        return None


def measure(rows):
    return dict(patches=len(rows),
                reused_macros=sum(r["reused_macros"] for r in rows),
                guarded_clusters=dict(sum((Counter(t for t, _ in r["parts"].values()) for r in rows), Counter())),
                motifs=dict(Counter(m["kind"] for r in rows for m in r["motifs"])),
                fully_guarded_contacts=dict(Counter(m["kind"] for r in rows for m in r["motifs"]
                                                    if m["profile"] is not None)),
                shapes={kind: len({m["shape"] for r in rows for m in r["motifs"] if m["kind"] == kind})
                        for kind in ("core", "pair", "single")})


def replay_patch(engine, record, depth):
    raw = record["raw"]
    if raw["status"] != "POSITIVE":
        return None
    witness = [(tuple(p), j) for p, j in raw["witness"]]
    return engine.verify_positive(record["root"], depth, witness)


def flat_tree(tree):
    result = []
    queue = [tree]
    for node in queue:
        data = {k: v for k, v in node.items() if k != "children"}
        if "children" in node:
            data["children"] = []
            for shell, child in node["children"]:
                data["children"].append((shell, len(queue)))
                queue.append(child)
        result.append(data)
    return result


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/name) == value for name, value in protocol["pins"].items())
    engine, _ = prepare()
    closure = load("input/closure-results-v1.json")["rounds"][-1]
    engine.kinds = set(closure["active"])
    bank = closure["records"]
    assert len(bank) == len(engine.kinds) == 20 and not closure["removed"]
    for record in bank:
        replay = replay_patch(engine, record, 8)
        assert replay["placement_set"] == sorted(map(tuple, record["checked"]["placement_set"]))
    local = load("input/local-rule-results-v1.json")
    audit = []
    studies = []
    for item in local:
        if not item["uniform"]:
            continue
        omitted = item["summary"]["omitted"]
        role, = map(tuple, item["uniform"][0])
        study = Study(engine, engine.kinds, omitted-1, role)
        studies.append(study)
        certificates = [study.certificate(kind) for kind in study.bases]
        original = [study.extract(record, 8) for record in bank]
        audit.append(dict(omitted=omitted, role=role, certificates=certificates,
                          original=original))
        print(json.dumps(dict(omitted=omitted, original=measure(original),
            certificates=[(c["kind"], len(c["motifs"]),
                           sum(r["witness"] is not None for r in c["motifs"]),
                           sum(r.get("witness") is not None for r in c["collisions"]))
                          for c in certificates])), flush=True)
    depth = protocol["holdout"]["depth"]
    held = []
    for root in protocol["holdout"]["roots"]:
        assert root in engine.kinds
        raw, _ = engine.run(root, depth, protocol["holdout"]["limits"], Policy(),
                            "RANDOM", random.Random(protocol["holdout"]["seed"]+root))
        record = dict(root=root, raw=raw)
        checked = replay_patch(engine, record, depth)
        if raw["status"] == "NEGATIVE":
            checked = Audit(engine).verify(root, depth, raw, engine.kinds)
        raw["flat_tree"] = flat_tree(raw.pop("tree"))
        held.append(dict(**record, checked=checked))
        print(json.dumps(dict(holdout_root=root, status=raw["status"], visits=raw["visits"])), flush=True)
    save("data/holdout-v1.json", held)
    summary = []
    for row, study in zip(audit, studies, strict=True):
        row["holdout"] = [study.extract(r, depth) for r in held if r["raw"]["status"] == "POSITIVE"]
        for cert in row["certificates"]:
            kind = cert["kind"]
            observed = {m["shape"] for p in row["original"]+row["holdout"]
                        for m in p["motifs"] if m["kind"] == kind}
            survivors = {r["shape"] for r in cert["motifs"] if r["witness"] is not None}
            assert observed <= survivors
            cert["observed_shapes"] = sorted(observed)
        result = dict(omitted=row["omitted"], role=row["role"],
                      original=measure(row["original"]), holdout=measure(row["holdout"]),
                      local=[dict(kind=c["kind"], rooted_candidates=len(c["motifs"]),
                                  local_survivors=sum(m["witness"] is not None for m in c["motifs"]),
                                  tested_collisions=len(c["collisions"]),
                                  possible_collisions=sum(r.get("witness") is not None for r in c["collisions"]),
                                  survivor_shapes=len({m["shape"] for m in c["motifs"] if m["witness"] is not None}),
                                  observed_shapes=len(c["observed_shapes"])) for c in row["certificates"]])
        summary.append(result)
        for record in row["original"]+row["holdout"]:
            record["parts"] = [(p, t, sorted(pieces)) for p, (t, pieces) in sorted(record["parts"].items())]
    save("data/results-v1.json", audit)
    report = dict(status="CHECKED_TURTLE_SECOND_LAYER_TRIPLES", rules=summary,
                  holdout_status=dict(Counter(r["raw"]["status"] for r in held)))
    save("data/summary-v1.json", report)
    print(json.dumps(report, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
