"""Discover and test macro partitions from exact ordinary-tile parallelograms."""

from collections import Counter, defaultdict
from itertools import combinations
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from actions_v1 import prepare
from cluster_v1 import load, pin, save
from compound_v1 import graph, polarity
from shell_v1 import boundary


def minus(a,b):
    return a[0]-b[0],a[1]-b[1]


def parallel(a,b):
    return a[0]*b[1]==a[1]*b[0]


def parallelogram(segments):
    edges=defaultdict(set)
    for a,b in segments:
        edges[a].add(b)
        edges[b].add(a)
    if any(len(n)!=2 for n in edges.values()):
        return None
    start=min(edges)
    order=[start]
    old,p=start,min(edges[start])
    while p!=start:
        if p in order:
            return None
        order.append(p)
        q,=edges[p]-{old}
        old,p=p,q
    if len(order)!=len(edges):
        return None
    corners=[q for i,q in enumerate(order)
             if not parallel(minus(q,order[i-1]),minus(order[(i+1)%len(order)],q))]
    if len(corners)!=4:
        return None
    a,b,c,d=corners
    if minus(b,a)!=minus(c,d) or minus(d,a)!=minus(c,b):
        return None
    return corners


def symmetric(sites):
    dx=min(x for x,y in sites)+max(x for x,y in sites)
    dy=min(y for x,y in sites)+max(y for x,y in sites)
    return (dx,dy) if all((dx-x,dy-y) in sites for x,y in sites) else None


def catalogue(engine,signs):
    root=(0,0,0)
    result={}
    exact=[]
    for p in engine.contacts:
        if signs[p[0]]<0:
            continue
        outer=parallelogram(boundary([engine.model.poly(root),engine.model.poly(p)]))
        if outer:
            exact.append(p)
        support=set(engine.model.support(root))|set(engine.model.support(p))
        centre=symmetric(support)
        if centre is not None:
            result[p]=centre
    return result,exact


def matching(required,candidates,optional,limit):
    start=time.perf_counter()
    visits=0
    witness=None
    dead=set()

    def visit(left,busy,rows):
        nonlocal visits,witness
        if visits>=limit["visits"] or time.perf_counter()-start>=limit["seconds"]:
            return "BOUNDED"
        visits+=1
        key=frozenset(left),frozenset(busy-left)
        if key in dead:
            return "EXHAUSTED"
        if not left:
            witness=rows
            return "WITNESS"
        def choices(p):
            options=[(p,q) for q in sorted(candidates[p]-busy)]
            return options+([(p,)] if p in optional else [])
        _,options=min(((p,choices(p)) for p in sorted(left)),key=lambda t:len(t[1]))
        for selection in options:
            status=visit(left-set(selection),busy|set(selection),(*rows,selection))
            if status!="EXHAUSTED":
                return status
        dead.add(key)
        return "EXHAUSTED"
    status=visit(required,set(),())
    return dict(status=status,visits=visits,witness=witness)


def partition(engine,signs,special,rootrow,choices,omitted,threshold,limit):
    witness={tuple(p):j for p,j in rootrow["raw"]["witness"]}
    patch=set(map(tuple,rootrow["checked"]["placement_set"]))
    adjacent,levels=graph(engine,patch)
    owners={}
    cores=[]
    root_frame=signs[0]*(-1 if rootrow["root"]==special else 1)
    assert all(signs[p[0]]*(-1 if j==special else 1)==root_frame for p,j in witness.items())
    for p,j in sorted(witness.items()):
        if j!=special:
            continue
        g,x,y=p
        members={p}
        for i,r in enumerate(engine.grammar.roles[special]):
            if i==omitted:
                continue
            h,a,b=engine.model.action(g,r)
            q=h,x+a,y+b
            assert q in adjacent[p] and signs[q[0]]==root_frame
            members.add(q)
        assert len(members)==4 and not members&owners.keys()
        owners.update({q:p for q in members})
        cores.append(sorted(members))
    remainder={p for p in patch-owners.keys() if signs[p[0]]==root_frame}
    required={p for p in remainder if levels[p]<=6}
    optional={p for p in required if len({owners[q] for q in adjacent[p] if q in owners})>=threshold}
    edges={}
    for p in remainder:
        g,x,y=p
        outgoing={(h,x+a,y+b) for h,a,b in (engine.model.action(g,r) for r in choices)}
        edges[p]=outgoing&remainder
    assert all(p in edges[q] for p,neighbors in edges.items() for q in neighbors)
    raw=matching(required,edges,optional,limit)
    if raw["witness"] is not None:
        filled=set(owners)
        for row in raw["witness"]:
            assert filled.isdisjoint(row) and set(row)<=remainder
            if len(row)==1:
                assert row[0] in optional
            else:
                assert len(row)==2 and row[0] in edges[row[1]]
                assert symmetric(set().union(*(engine.model.support(t) for t in row))) is not None
            filled.update(row)
        assert required<=filled
        supports=[set(engine.model.support(p)) for p in filled]
        assert len(set().union(*supports))==240*len(filled)
    return dict(root=rootrow["root"],omitted=omitted+1,threshold=threshold,required=len(required),
                eligible_singles=len(optional),unsupported=sum(not edges[p] and p not in optional for p in required),
                cores=cores,raw=raw)


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    engine,_=prepare()
    signs,special,_=polarity(engine)
    choices,exact=catalogue(engine,signs)
    closure=load("input/closure-results-v1.json")
    roots=closure["rounds"][-1]["records"]
    assert len(roots)==20 and all(row["checked"]["status"]=="VERIFIED" for row in roots)
    rows=[]
    stats=[]
    for threshold in protocol["thresholds"]:
        for omitted in range(4):
            found=[partition(engine,signs,special,r,choices,omitted,threshold,protocol["limits"]) for r in roots]
            rows.extend(found)
            stats.append(dict(threshold=threshold,omitted=omitted+1,outcomes=dict(Counter(
                r["raw"]["status"] for r in found)),directly_unsupported=sum(r["unsupported"] for r in found)))
    save("data/results-v1.json",rows)
    report=dict(status="CHECKED_FOUR_TILE_CORE_MACRO_PARTITIONS",
                exact_parallelogram_contacts=exact,
                central_contacts=[dict(contact=p,twice_centre=v) for p,v in choices.items()],
                cases=len(rows),by_rule=stats,
                scope="Finite patch partition with four-tile special cores, centrally symmetric ordinary pairs, and singles admitted by the number of distinct adjacent cores. An observed finite witness does not establish a repeating macro rule.")
    save("data/summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
