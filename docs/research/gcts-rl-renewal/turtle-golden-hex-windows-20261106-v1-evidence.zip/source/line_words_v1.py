"""Decode line words from unmarked tilings and search short gap substitutions."""

from collections import Counter
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from rhombille_v1 import Bridge, color, load, pin, polarity, prepare, save


def cube(anchor, point):
    x, y = point
    a, b = anchor
    assert (x-a)%2 == (y-b)%2 == 0
    u, v = (x-a)//2, (y-b)//2
    residue = (u-v)%3
    assert residue in (1, 2)
    layer = residue-3
    j, rest = divmod(layer-u+v, 3)
    assert rest == 0
    return u+j, j, j-v


def project(anchor, coords):
    x, y = anchor
    i, j, k = coords
    return x+2*(i-j), y+2*(j-k)


def rhomb_variables(anchor, ring):
    p, q = (cube(anchor, point) for point in ring if color(point) != color(anchor))
    axis, = [i for i in range(3) if p[i] != q[i]]
    assert abs(p[axis]-q[axis]) == 1 and {sum(p), sum(q)} == {-2,-1}
    shared = tuple((j,p[j]) for j in ((axis+1)%3, (axis+2)%3))
    return axis, (p, q), shared


def decode(bridge, record, frame, signs):
    anchor = bridge.base["grid_anchor"]
    line = {}
    for t in record["placements"]:
        point = bridge.point(t, bridge.base["center"])
        c = cube(anchor, point)
        bit = int(signs[t[0]] != frame)
        assert project(anchor, c) == point
        for axis, k in enumerate(c):
            old = line.setdefault((axis,k), bit)
            assert old == bit
    words = []
    for axis in range(3):
        indexes = sorted(k for a,k in line if a == axis)
        assert indexes == list(range(indexes[0], indexes[-1]+1))
        word = "".join(str(line[axis,k]) for k in indexes)
        words.append(dict(axis=axis, start=indexes[0], word=word))
    comparisons = Counter()
    cells = [(r,kind) for r,_,kind in record["occupied"]]
    cells.extend((r,"hole") for r in record["complete_holes"])
    for r, actual in cells:
        _, _, shared = rhomb_variables(anchor, r)
        if not all(key in line for key in shared):
            comparisons[actual,"unresolved"] += 1
            continue
        p, q = (line[key] for key in shared)
        red_order = (0,1) if frame == 1 else (1,0)
        predicted = "hex" if p == q else "red" if (p,q) == red_order else "hole"
        assert predicted == actual
        comparisons[actual,"matched"] += 1
    return dict(root=record["root"], words=words, frame=frame,
                checks=[(k,n) for k,n in sorted(comparisons.items())])


def gap_word(word):
    ones = [i for i, b in enumerate(word) if b == "1"]
    return tuple(j-i for i,j in zip(ones,ones[1:]))


def language(morphism, iterations):
    words = ["S","L"]
    for _ in range(iterations):
        words = ["".join(morphism[c] for c in w) for w in words]
    return words


def matches(target, generated):
    return any(target in w or target[::-1] in w for w in generated)


def fit_morphisms(train, deeper, iterations):
    choices = ["S", "L", "SS", "SL", "LS", "LL"]
    result = []
    for short, long in product(choices, repeat=2):
        morphism = dict(S=short, L=long)
        # For two symbols, primitivity holds when each reaches the other and
        # at least one production also retains its own symbol.
        if not ("L" in short and "S" in long and ("S" in short or "L" in long)):
            continue
        gen = language(morphism, iterations)
        result.append(dict(morphism=morphism, train=sum(matches(w, gen) for w in train),
                           deeper=sum(matches(w, gen) for w in deeper), factors=list(gen)))
    return result


def slope_bounds(word):
    pre = [0]
    for bit in word:
        pre.append(pre[-1]+int(bit))
    lower = max(Fraction(pre[j]-pre[i]-1, j-i) for j in range(1,len(pre)) for i in range(j))
    upper = min(Fraction(pre[j]-pre[i]+1, j-i) for j in range(1,len(pre)) for i in range(j))
    return lower, upper


def main():
    protocol = load("line-protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == v for n,v in protocol["pins"].items())
    engine, _ = prepare()
    bridge = Bridge(engine)
    signs, special, _ = polarity(engine)
    rows = {bank:[decode(bridge, r, -1 if r["root"] == special else 1, signs) for r in cases]
            for bank,cases in load("data/bridge-results-v1.json")["banks"].items()}
    words = {bank:[w["word"] for r in cases for w in r["words"]] for bank,cases in rows.items()}
    gaps = {k:[gap_word(w) for w in v] for k,v in words.items()}
    assert set(n for bank in gaps.values() for w in bank for n in w) == {3,4}
    encoded = {k:["".join("S" if n == 3 else "L" for n in w) for w in v] for k,v in gaps.items()}
    morphisms = fit_morphisms(encoded["original"], encoded["deeper"], protocol["iterations"])
    result = {}
    for bank, bank_words in words.items():
        label_counts = Counter()
        for r in rows[bank]:
            label_counts.update(dict(r["checks"]))
        line_bounds = [slope_bounds(w) for w in bank_words]
        lo = max(lower for lower,_ in line_bounds)
        hi = min(upper for _,upper in line_bounds)
        result[bank] = dict(line_words=len(bank_words), gaps=dict(Counter(n for w in gaps[bank] for n in w)),
                            slope_bounds=[str(lo), str(hi)], slope_interval_nonempty=lo<hi,
                            length_range=[min(map(len,bank_words)),max(map(len,bank_words))],
                            colors=[(kind,state,n) for (kind,state),n in sorted(label_counts.items())])
    data = dict(status="CHECKED_RHOMBILLE_LINE_WORDS", banks=result,
                morphisms=[{k:v for k,v in r.items() if k!="factors"} for r in morphisms])
    save("data/line-results-v1.json", dict(decoded=rows, words=encoded, morphisms=morphisms))
    save("data/line-summary-v1.json", data)
    print(json.dumps(data,sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
