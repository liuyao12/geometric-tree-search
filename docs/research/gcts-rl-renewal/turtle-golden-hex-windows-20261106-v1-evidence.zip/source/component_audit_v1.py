"""Exhaust local obstructions to the infinite Turtle matching graph."""

from bisect import bisect_left, bisect_right
from collections import Counter
from fractions import Fraction
from itertools import accumulate, product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from matching_graph_v1 import graph, length, words
from mechanical_v1 import ALPHA, Q, intervals
from phase_owner_v1 import OwnerGeometry, patterns
from rhombille_v1 import Bridge, load, pin, prepare, save

ORIGIN=(0,0,0)


def phase_cells(layer, radius):
    domains=intervals(radius)
    lows=[lo for lo,_,_ in domains]
    highs=[hi for _,hi,_ in domains]
    target=ALPHA*layer
    planes=[(target+Q(band),band) for band in range(-target.floor(),3-target.floor())]
    for (a0,a1,a),(b0,b1,b) in product(domains,repeat=2):
        lo,hi=a0+b0,a1+b1
        for plane,band in planes:
            first=bisect_right(highs,plane-hi)
            last=bisect_left(lows,plane-lo)
            for _,_,c in domains[first:last]:
                yield (a,b,c),band


def offsets(geometry):
    table={}
    for layer in (-2,-1):
        base=(0,0,layer)
        for p,band in patterns(layer,3):
            state,selected=geometry.context(base,p,3,band)
            steps=[]
            if selected(base):
                for red in geometry.hex_options(base,state):
                    a,b=geometry.red_choices(red,state)
                    assert base in (a,b)
                    other=b if a==base else a
                    steps.append(tuple(x-y for x,y in zip(other,base,strict=True)))
                assert steps and len(set(steps))==len(steps)
            assert all(length(step)<=2 for step in steps)
            table[layer,p,band]=tuple(sorted(steps))
    return table


class View:
    def __init__(self, layer, pattern, band, radius, table):
        self.layer,self.pattern,self.band=layer,pattern,band
        self.radius,self.table=radius,table
        self.prefix=tuple(tuple(accumulate(bits,initial=0)) for bits in pattern)
        self.cache={}

    def steps(self, v):
        if v in self.cache:
            return self.cache[v]
        layer=self.layer+sum(v)
        starts=[self.radius+n for n in v]
        assert all(3<=i<=2*self.radius-3 for i in starts)
        local=tuple(bits[i-3:i+4] for i,bits in zip(starts,self.pattern,strict=True))
        band=self.band-sum(a[i]-a[self.radius] for a,i in zip(self.prefix,starts,strict=True))
        result=self.table[layer,local,band]
        self.cache[v]=result
        return result

    def neighbors(self,v):
        return [tuple(x+y for x,y in zip(v,step,strict=True)) for step in self.steps(v)]


def component(view, cap):
    queue=[ORIGIN]
    seen={ORIGIN}
    for v in queue:
        for other in view.neighbors(v):
            if other not in seen:
                seen.add(other)
                queue.append(other)
                if len(seen)>cap:
                    return None
    return sorted(seen)


def cycle_ball(view, depth):
    queue=[(ORIGIN,0)]
    parents={ORIGIN:None}
    for v,d in queue:
        for other in view.neighbors(v):
            if other in parents:
                if parents[v]!=other and parents[other]!=v:
                    return (v,other)
            elif d<depth:
                parents[other]=v
                queue.append((other,d+1))
    return None


def compare_graph(geometry,table,radius,intercepts):
    sites,edges,incident=graph(geometry,radius,intercepts)
    floors=words(radius,intercepts)
    checked=0
    for v in sites:
        if length(v)>radius-3:
            continue
        p=tuple(tuple(f[k+j+1]-f[k+j] for j in range(-3,4)) for f,k in zip(floors,v,strict=True))
        band=-sum(f[k] for f,k in zip(floors,v,strict=True))
        view=View(sum(v),p,band,3,table)
        nexts={tuple(x+y for x,y in zip(v,step,strict=True)) for step in view.steps(ORIGIN)}
        assert nexts=={other for edge in incident[v] for other in edges[edge] if other!=v}
        checked+=1
    return checked


def main():
    p=load("component-protocol-v1.json")
    assert p["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==d for n,d in p["pins"].items())
    for layer,radius in product((-2,-1),(3,6)):
        assert set(phase_cells(layer,radius))==set(patterns(layer,radius))
    engine,_=prepare()
    geometry=OwnerGeometry(Bridge(engine))
    table=offsets(geometry)
    compared=compare_graph(geometry,table,18,list(map(Fraction,p["intercepts"])))
    runs=[]
    for cap in p["caps"]:
        radius=2*cap+3
        all_cells=Counter()
        selected=Counter()
        finite=[]
        cycles=[]
        for layer in (-2,-1):
            for pattern,band in phase_cells(layer,radius):
                all_cells[layer]+=1
                view=View(layer,pattern,band,radius,table)
                if not view.steps(ORIGIN):
                    continue
                selected[layer]+=1
                closed=component(view,cap)
                short=cycle_ball(view,cap//2)
                if closed:
                    finite.append(dict(layer=layer,band=band,pattern=pattern,component=closed))
                if short:
                    cycles.append(dict(layer=layer,band=band,pattern=pattern,edge=short))
        run=dict(cap=cap,radius=radius,phase_cells=dict(all_cells),selected=dict(selected),finite=finite,cycles=cycles)
        runs.append(run)
        print(json.dumps(dict(run,finite=len(finite),cycles=len(cycles)),sort_keys=True),flush=True)
    save("data/component-v1.json",dict(status="CHECKED_EXACT_TURTLE_PHASE_COMPONENT_BOUNDS",
         stencils=len(table),selected_stencils=sum(bool(v) for v in table.values()),direct_graph_checks=compared,runs=runs))


if __name__=="__main__":
    main()
