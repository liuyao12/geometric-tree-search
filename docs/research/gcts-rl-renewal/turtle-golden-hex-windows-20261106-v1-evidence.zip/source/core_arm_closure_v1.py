"""Check whether two transferred third-layer stencils can share a core."""

from itertools import combinations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from extend_v1 import Collar
from receptors_v1 import Study, block, load, move, pin, prepare, save, support
from local_v1 import apply


class MixedCollar(Collar):
    def __init__(self, study, groups, depth):
        self.study = study
        self.engine = study.engine
        self.kind = "mixed"
        self.depth = depth
        self.enforce_single = False
        self.forced = {}
        self.singles = set()
        for kind, parts in groups:
            if kind == "single triple":
                self.singles.update(support((kind, parts)))
                roles = study.force("single", parts)
            else:
                assert kind == "core"
                roles = study.force(kind, parts)
            assert self.forced.keys().isdisjoint(roles)
            self.forced.update(roles)

    def domain(self, p, assigned, state):
        for j in super().domain(p, assigned, state):
            links = {**state[0], p:self.engine.links(j, p)}
            if any((q := apply(self.engine, tile, self.study.role)) in links[tile]
                   and q in links and not self.has_owner(q, links[q])
                   for tile in self.singles & links.keys()):
                continue
            yield j


def decode(raw):
    kind, pieces = raw
    return block(kind, [tuple(map(tuple, part)) for part in pieces])


def bank_stencils(records):
    return {(decode(a["pattern"][0]), tuple(decode(arm) for arm, _ in a["pattern"][1]))
            for record in records for a in record["attachments"]
            if a["label"] == ["single triple", "core"]}


def root_stencils(study, types):
    rooted = set()
    for seed, arms in sorted(types):
        for g in study.model.groups:
            s = move(study, seed, g)
            a = [move(study, arm, g) for arm in arms]
            for part in a:
                center, = [p for p, label in study.force("core", part[1]).items()
                           if label == "special"]
                h, x, y = center
                if h == 0:
                    rooted.add((move(study, s, 0, -x, -y),
                                tuple(sorted(move(study, arm, 0, -x, -y) for arm in a))))
    return sorted(rooted)


def main():
    protocol = load("core-arm-protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == v for n, v in protocol["pins"].items())
    engine, _ = prepare()
    active = set(load("input/closure-results-v1.json")["rounds"][-1]["active"])
    study = Study(engine, active, 0, (6, 0, 0))
    search, = [r for r in load("data/results-v1.json") if r["rule"] == 1]
    types = bank_stencils(search["original"]) & bank_stencils(search["holdout"])
    assert len(types) == 2
    rooted = root_stencils(study, types)
    cases = []
    for (i, (seed, a)), (j, (other, b)) in combinations(enumerate(rooted), 2):
        if seed == other:
            continue
        groups = set(a) | set(b) | {seed, other}
        atoms = [study.support(support(g)) for g in groups]
        if len(set.union(*atoms)) < sum(map(len, atoms)):
            cases.append(dict(left=i, right=j, geometry="OVERLAP", checks=[]))
            continue
        checks = []
        for depth in protocol["depths"]:
            collar = MixedCollar(study, groups, depth)
            raw = collar.run(protocol["node_limit"])
            if raw["status"] == "LOCAL_WITNESS":
                collar.verify_witness(raw["witness"])
            elif raw["status"] == "EXCLUDED":
                collar.verify(raw["tree"], {})
            checks.append(dict(depth=depth, **raw))
            if raw["status"] != "LOCAL_WITNESS":
                break
        cases.append(dict(left=i, right=j, geometry="COMPATIBLE", checks=checks))
    results = dict(types=sorted(types), rooted=rooted, collision_cases=cases)
    save("data/core-arm-closure-v1.json", results)
    counts = [[c["geometry"], [(r["depth"], r["status"], r["visits"]) for r in c["checks"]]]
              for c in cases]
    print(json.dumps(dict(types=len(types), rooted=len(rooted), collision_cases=counts)), flush=True)


if __name__ == "__main__":
    main()
