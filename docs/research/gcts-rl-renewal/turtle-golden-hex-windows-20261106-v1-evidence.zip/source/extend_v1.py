"""Replay rooted motif screens and extend all survivors by complete shell layers."""

from collections import Counter
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))

from triples_v1 import Study, prepare, apply, load, pin, save


class Collar:
    def __init__(self, study, kind, motifs, depth, enforce_single=False):
        self.study = study
        self.engine = study.engine
        self.kind = kind
        self.forced = study.force(kind, set(motifs))
        self.depth = depth
        self.enforce_single = enforce_single

    def frontier(self, assigned):
        seen = set(self.forced)
        front = seen.copy()
        for _ in range(self.depth):
            front = {q for p in front if p in assigned
                     for q in self.engine.links(assigned[p], p)}-seen
            seen.update(front)
        return seen-assigned.keys()

    def state(self, assigned):
        links = {p: self.engine.links(j, p) for p, j in assigned.items()}
        patch = set(self.forced) | {q for link in links.values() for q in link}
        return links, patch, self.study.support(patch)

    def has_owner(self, p, links):
        opposite = (q for q in links if self.study.signs[q[0]] != self.study.signs[p[0]])
        return any(apply(self.engine, q, r) == p for q in opposite for r in self.study.core_roles)

    def domain(self, p, assigned, state):
        links, patch, occupied = state
        active = self.study.active
        special = self.study.special
        forced = self.forced.get(p)
        if forced:
            active = {special} if forced == "special" else active-{special}
        for j in sorted(active):
            candidate = self.engine.links(j, p)
            if not self.study.neighbors(p) & patch <= candidate.keys():
                continue
            if forced == "unowned" and self.has_owner(p, candidate):
                continue
            if any((q in candidate and k not in self.engine.projections[j, candidate[q]]) or
                   (p in links[q] and j not in self.engine.projections[k, links[q][p]])
                   for q, k in assigned.items()):
                continue
            add = candidate.keys()-patch
            if any(add & (self.study.neighbors(q)-link.keys()) for q, link in links.items()):
                continue
            if not occupied.isdisjoint(self.study.support(add)):
                continue
            if self.kind == "single" and self.enforce_single:
                prospective = {**links, p: candidate}
                if any((q := apply(self.engine, tile, self.study.role)) in prospective[tile]
                       and q in prospective and not self.has_owner(q, prospective[q])
                       for tile in self.forced.keys() & prospective.keys()):
                    continue
            yield j

    def run(self, limit):
        visits = 0

        def visit(assigned):
            nonlocal visits
            if visits >= limit:
                return dict(status="BOUNDED")
            visits += 1
            open_nodes = self.frontier(assigned)
            if not open_nodes:
                return dict(status="LOCAL_WITNESS", witness=sorted(assigned.items()))
            state = self.state(assigned)
            p, choices = min(((p, list(self.domain(p, assigned, state))) for p in sorted(open_nodes)),
                             key=lambda item: (len(item[1]), item[0]))
            children = []
            for j in choices:
                sub = visit({**assigned, p:j})
                if sub["status"] != "EXCLUDED":
                    return sub
                children.append([j, sub["tree"]])
            return dict(status="EXCLUDED", tree=[p, children])

        return dict(**visit({}), visits=visits)

    def verify(self, tree, assigned):
        anchor, children = tree
        assert anchor in self.frontier(assigned)
        assert tuple(self.domain(anchor, assigned, self.state(assigned))) == tuple(j for j, _ in children)
        for j, child in children:
            self.verify(child, {**assigned, anchor:j})

    def verify_witness(self, witness):
        pending = dict(witness)
        assert len(pending) == len(witness)
        assigned = {}
        while remaining := self.frontier(assigned):
            p = min(remaining)
            j = pending.pop(p)
            assert j in self.domain(p, assigned, self.state(assigned))
            assigned[p] = j
        assert not pending


def decode(value):
    return tuple(tuple(tuple(p) for p in macro) for macro in value)


def replay(collar, evidence):
    if evidence.get("witness") is not None:
        collar.verify_witness([(tuple(p), j) for p, j in evidence["witness"]])
    else:
        def decode_tree(node):
            p, branches = node
            return tuple(p), [[j, decode_tree(child)] for j, child in branches]
        collar.verify(decode_tree(evidence["failure"]), {})


def main():
    protocol = load("extension-protocol-v1.json")
    assert all(pin(ROOT/n) == v for n, v in protocol["pins"].items())
    assert protocol["runtime"] == pin(Path(sys.executable))
    engine, _ = prepare()
    active = set(load("input/closure-results-v1.json")["rounds"][-1]["active"])
    all_rows, summary = [], []
    for case in load("data/results-v1.json"):
        study = Study(engine, active, case["omitted"]-1, tuple(case["role"]))
        kinds = []
        for cert in case["certificates"]:
            kind = cert["kind"]
            motifs = [decode(row["motif"]) for row in cert["motifs"]]
            assert set(study.rooted(study.bases[kind])) == set(motifs)
            outcomes = []
            for i, (motif, old) in enumerate(zip(motifs, cert["motifs"], strict=True)):
                replay(Collar(study, kind, motif, 0), old)
                if old["witness"] is not None:
                    outcomes.append((str(i), set(motif)))
            collisions = []
            for pair in cert["collisions"]:
                i, j = pair["left"], pair["right"]
                union = set(motifs[i]) | set(motifs[j])
                if pair.get("status") == "GEOMETRIC_OVERLAP":
                    atoms = [study.support(part) for part in union]
                    assert len(set.union(*atoms)) < sum(map(len, atoms))
                    continue
                replay(Collar(study, kind, union, 0), pair)
                if pair["witness"] is not None:
                    collisions.append((f"{i}/{j}", union))
            complete = []
            for key, union in outcomes+collisions:
                checks = []
                for depth in protocol["depths"]:
                    collar = Collar(study, kind, union, depth, enforce_single=True)
                    result = collar.run(protocol["node_limit"])
                    if result["status"] == "EXCLUDED":
                        collar.verify(result["tree"], {})
                    if result["status"] == "LOCAL_WITNESS":
                        collar.verify_witness(result["witness"])
                    checks.append(dict(depth=depth, **result))
                    if result["status"] == "EXCLUDED":
                        break
                complete.append(dict(case=key, poses=sorted(union), checks=checks))
            row = dict(kind=kind, replayed=len(motifs)+len(cert["collisions"]),
                       cases=complete)
            kinds.append(row)
            print(json.dumps(dict(rule=case["omitted"], kind=kind,
                outcomes={r["case"]: [(k["depth"], k["status"], k["visits"]) for k in r["checks"]]
                          for r in complete})), flush=True)
        all_rows.append(dict(rule=case["omitted"], kinds=kinds))
        summary.append(dict(rule=case["omitted"], kinds=[
            dict(kind=k["kind"], replayed=k["replayed"],
                 shapes=dict(Counter(r["checks"][-1]["status"] for r in k["cases"] if "/" not in r["case"])),
                 collisions=dict(Counter(r["checks"][-1]["status"] for r in k["cases"] if "/" in r["case"])))
            for k in kinds]))
    save("data/extension-results-v1.json", all_rows)
    save("data/extension-summary-v1.json", dict(status="CHECKED_EXTENDED_COLLARS", rules=summary))


if __name__ == "__main__":
    main()
