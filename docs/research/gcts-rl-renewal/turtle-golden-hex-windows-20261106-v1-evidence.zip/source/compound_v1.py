"""Certify a handedness receptor and test four exact compound pairings."""

from collections import Counter, defaultdict, deque
import json
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from actions_v1 import CENTRE, Policy, prepare
from cluster_v1 import load, pin, save


def determinant(m):
    return m[0][0]*m[1][1]-m[0][1]*m[1][0]


def polarity(engine):
    signs = {g:determinant(m) for g,m in engine.model.groups.items()}
    assert set(signs.values())=={-1,1}
    family = engine.grammar.roles
    special, = [i for i,roles in family.items() if roles and all(signs[g]<0 for g,_,_ in roles)]
    assert all(sum(signs[g]<0 for g,_,_ in roles)<=1 for i,roles in family.items() if i!=special)
    projected = 0
    for (i,(g,x,y)),neighbors in engine.projections.items():
        for j in neighbors:
            assert signs[g]==(-1 if (i==special)!=(j==special) else 1)
            projected += 1
    assert projected == 222
    return signs,special,projected


def graph(engine, patch):
    adjacent = {}
    for p in patch:
        g,x,y = p
        possible = {(h,x+a,y+b) for h,a,b in
                    (engine.model.action(g,t) for t in engine.contacts)}
        adjacent[p] = possible & patch
    levels = {CENTRE:0}
    queue = deque([CENTRE])
    while queue:
        p = queue.popleft()
        for q in adjacent[p]:
            if q not in levels:
                levels[q] = levels[p]+1
                queue.append(q)
    assert levels.keys()==adjacent.keys()
    return adjacent,levels


def quotient(engine, chosen, graph, levels, depth, special, role):
    owner = {p:p for p in graph}
    pairs = []
    for p,i in chosen.items():
        if i!=special:
            continue
        g,x,y = p
        h,a,b = engine.model.action(g,role)
        q = h,x+a,y+b
        assert q in graph[p]
        assert owner[q]==q and owner[p]==p
        assert q not in chosen or chosen[q]!=special
        owner[q]=p
        pairs.append((p,q))
    groups = defaultdict(set)
    for p,q in owner.items():
        groups[q].add(p)
    for p in groups:
        assert len(groups[p]) in (1,2)
    degrees = Counter()
    labels = []
    for p,pieces in sorted(groups.items()):
        if max(levels[q] for q in pieces)>depth-2:
            continue
        neighbors = {owner[q] for tile in pieces for q in graph[tile]}-{p}
        degrees[len(neighbors)] += 1
        labels.append(dict(owner=p,pieces=sorted(pieces),neighbors=sorted(neighbors)))
    return dict(pairs=pairs,interior=labels,degrees=dict(degrees))


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    engine,kinds = prepare()
    signs,special,checked = polarity(engine)
    roles = engine.grammar.roles[special]
    assert len(roles)==4
    past = load("input/action-summary-v1.json")
    test = set(past["test"])
    policy=Policy()
    policy.weights=past["weights"][:]
    results = []
    degree_counts = [Counter() for _ in roles]
    balanced = 0
    for depth in protocol["depths"]:
        for index,i in enumerate(sorted(kinds)):
            arms = protocol["arms"] if i in test else ["HEURISTIC"]
            shift = index%len(arms)
            for mode in arms[shift:]+arms[:shift]:
                seed=protocol["seed"]+1000*depth+i
                raw,_ = engine.run(i,depth,protocol["limits"],policy,mode,random.Random(seed))
                row=dict(root=i,depth=depth,mode=mode,raw=raw)
                if raw["status"]=="POSITIVE":
                    witness=engine.verify_positive(i,depth,raw["witness"])
                    chosen=dict(raw["witness"])
                    frames={signs[p[0]]*(-1 if j==special else 1) for p,j in chosen.items()}
                    assert len(frames)==1
                    adjacent,levels=graph(engine,set(witness["placement_set"]))
                    combos=[quotient(engine,chosen,adjacent,levels,depth,special,r) for r in roles]
                    if mode=="HEURISTIC":
                        for c,local in zip(degree_counts,combos,strict=True):
                            c.update(local["degrees"])
                        balanced += 1
                    row.update(checked=witness,quotients=combos)
                else:
                    row.update(checked=None,quotients=None)
                results.append(row)
        print(json.dumps(dict(depth=depth,methods=dict(Counter(
            r["mode"]+"_"+r["raw"]["status"] for r in results if r["depth"]==depth)))),flush=True)
    assert policy.weights==past["weights"]
    arms={}
    for mode in protocol["arms"]:
        cases=[r for r in results if r["mode"]==mode and r["root"] in test]
        arms[mode]=dict(status=dict(Counter(r["raw"]["status"] for r in cases)),
                        visits=sum(r["raw"]["visits"] for r in cases),
                        seconds=sum(r["raw"]["seconds"] for r in cases),
                        largest=max(r["checked"]["tiles"] if r["checked"] else 0 for r in cases))
    save("data/results-v1.json",results)
    report=dict(status="CHECKED_HAND_AND_COMPOUND_RECEPTORS",special=special,roles=roles,
                projected_polarities=checked,arms=arms,heuristic_patches=balanced,
                degrees=[dict(c) for c in degree_counts],
                scope="A grammar-consistent full tiling would have a single handedness frame on each connected component. The special shell has four opposite-hand neighbors. Every other shell has at most one. Each rule pairs the special center to a fixed role with no overlap. Degree profiles are observations on certified finite collars only.")
    save("data/summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
