"""Check induced geometric neighborhoods across all exact phase cells."""

from collections import Counter
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from component_audit_v1 import ORIGIN, ROOT, View, offsets, phase_cells
from matching_graph_v1 import length
from phase_owner_v1 import OwnerGeometry
from rhombille_v1 import Bridge, load, pin, prepare, save


def inspect(view, extent):
    queue=[ORIGIN]
    parent={ORIGIN:None}
    exits=False
    cycle=None
    for v in queue:
        for u in view.neighbors(v):
            if length(u)>extent:
                exits=True
            elif u not in parent:
                parent[u]=v
                queue.append(u)
            elif parent[v]!=u and parent[u]!=v:
                cycle=(v,u)
    return exits,cycle,len(queue)


def main():
    plan=load("box-protocol-v1.json")
    assert plan["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==d for n,d in plan["pins"].items())
    engine,_=prepare()
    table=offsets(OwnerGeometry(Bridge(engine)))
    reports=[]
    for extent in plan["extents"]:
        phases,selected=Counter(),Counter()
        roots=visited=0
        examples=[]
        radius=extent+3
        for layer in (-2,-1):
            for pattern,band in phase_cells(layer,radius):
                phases[layer]+=1
                view=View(layer,pattern,band,radius,table)
                if not view.steps(ORIGIN):
                    continue
                selected[layer]+=1
                exits,cycle,n=inspect(view,extent)
                roots+=1
                visited+=n
                if not exits or cycle:
                    examples.append(dict(layer=layer,band=band,pattern=pattern,
                                         closed=not exits,cycle=cycle,component_size_in_box=n))
        report=dict(extent=extent,phase_radius=radius,phase_cells=dict(phases),selected=dict(selected),
                    visited_vertices=visited,root_views=roots,examples=examples)
        reports.append(report)
        print(json.dumps(dict(report,examples=len(examples)),sort_keys=True),flush=True)
    save("data/component-box-v1.json",dict(status="CHECKED_EXACT_TURTLE_GEOMETRIC_BOXES",runs=reports))


if __name__=="__main__":
    main()
