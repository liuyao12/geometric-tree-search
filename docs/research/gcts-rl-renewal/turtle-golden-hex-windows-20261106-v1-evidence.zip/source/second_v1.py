"""Check simultaneous boundary extensions of first-shell receptors."""

from collections import Counter
from functools import lru_cache
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from catalogue_v1 import rooted_contacts, segment_masks
from cluster_v1 import Model, edges, load, pin, save
from shell_v1 import boundary, cover_intervals, unpack


def solve(masks,supports,width,limit):
    cells=[tuple(i for i,m in enumerate(masks) if m&(1<<q)) for q in range(width)]
    conflict=[sum(1<<i for i,(n,s) in enumerate(zip(masks,supports,strict=True)) if m&n or a&s)
              for m,a in zip(masks,supports,strict=True)]
    started=time.perf_counter()
    count=0
    witness=None

    def visit(missing,excluded,selected):
        nonlocal count,witness
        if count>=limit["visits"] or time.perf_counter()-started>=limit["seconds"]:
            return dict(status="UNKNOWN")
        count+=1
        if not missing:
            witness=selected
            return dict(status="POSITIVE")
        q,choices=min(((q,[i for i in cell if not excluded&(1<<i)])
                       for q,cell in enumerate(cells) if missing&(1<<q)),key=lambda t:len(t[1]))
        children=[]
        for i in choices:
            child=visit(missing^masks[i],excluded|conflict[i],(*selected,i))
            children.append((i,child))
            if child["status"]!="NEGATIVE":
                return dict(status=child["status"],atom=q,children=children)
        return dict(status="NEGATIVE",atom=q,children=children)

    tree=visit((1<<width)-1,0,())
    return dict(status=tree["status"],tree=tree,witness=witness,visits=count,
                seconds=time.perf_counter()-started)


def verify(raw,masks,supports,width):
    required=set(range(width))
    covered=[{q for q in required if m&(1<<q)} for m in masks]
    if raw["status"]=="UNKNOWN":
        return dict(status="BOUNDED")
    if raw["status"]=="POSITIVE":
        taken=set()
        filled=set()
        for i in raw["witness"]:
            assert not (covered[i]&taken or supports[i]&filled)
            taken.update(covered[i])
            filled.update(supports[i])
        assert taken==required
        return dict(status="VERIFIED",tiles=len(raw["witness"]))
    count=0
    def visit(node,missing,filled):
        nonlocal count
        count+=1
        q=node["atom"]
        assert node["status"]=="NEGATIVE" and q in missing
        children=dict(node["children"])
        legal={i for i,(c,s) in enumerate(zip(covered,supports,strict=True))
               if q in c and c<=missing and s.isdisjoint(filled)}
        assert legal==children.keys() and len(children)==len(node["children"])
        for i in sorted(legal):
            visit(children[i],missing-covered[i],filled|supports[i])
    visit(raw["tree"],required,set())
    assert count==raw["visits"]
    return dict(status="VERIFIED",nodes=count)


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/name)==v for name,v in protocol["pins"].items())
    data=load("input/exact-point-model-v1.json")
    model=Model(data)
    source=unpack(ROOT/"input/contact-catalogue-v1.json.gz")
    assert source["model"]==data
    contacts=rooted_contacts(model,source)
    assert len(contacts)==82
    catalogue=load("input/catalogue-v1.json")
    assert len(catalogue)==242
    @lru_cache(maxsize=3500)
    def support(p):
        return frozenset(model.support(p))
    @lru_cache(maxsize=3500)
    def polygon(p):
        return model.poly(p)
    counts=Counter()
    details=[]
    for i,row in enumerate(catalogue):
        if row["status"]!="NO_GAP":
            continue
        placements=list(map(tuple,row["shape"]))
        occupied=set().union(*(support(p) for p in placements))
        eligible=set()
        for g,x,y in placements:
            for relative in contacts:
                h,a,b=model.action(g,relative)
                p=(h,a+x,b+y)
                if support(p).isdisjoint(occupied):
                    eligible.add(p)
        keys=sorted(eligible)
        assert len(keys)==row["eligible_new_contacts"]
        outer=boundary([polygon(p) for p in placements])
        assert json.loads(json.dumps(outer))==row["outer_segments"]
        masks,width=segment_masks(outer,[polygon(p) for p in keys])
        supports=[support(p) for p in keys]
        raw=solve(masks,supports,width,protocol["limits"])
        checked=verify(raw,masks,supports,width)
        if raw["status"]=="POSITIVE":
            chosen=[keys[j] for j in raw["witness"]]
            assert len(set().union(*(support(p) for p in placements+chosen)))==240*(len(placements)+len(chosen))
            added=[(j,a,b) for j,p in enumerate(chosen) for a,b in edges(polygon(p))]
            assert all(not cover_intervals(edge,added)[1] for edge in outer)
            checked["witness"]=chosen
        counts[raw["status"]]+=1
        if row["observations"]:
            counts[f"observed_{raw['status']}"]+=1
        details.append(dict(shell=i,seed=placements,observations=row["observations"],width=width,
                            keys=keys,raw=raw,checked=checked))
    assert len(details)==50
    save("data/results-v1.json",details)
    result=dict(status="CHECKED_SIMULTANEOUS_SECOND_RING",counts=dict(counts),
                scope="A positive adds disjoint primitive neighbors covering every exposed segment of the first shell. No claim that the new boundary extends again or tiles the plane.")
    save("data/summary-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
