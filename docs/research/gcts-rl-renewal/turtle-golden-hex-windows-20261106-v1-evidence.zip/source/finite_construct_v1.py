"""Build literal Turtle placements by rooting finite red-attachment trees."""

from fractions import Fraction
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from matching_graph_v1 import graph, length, shape_sites, words
from phase_owner_v1 import OwnerGeometry
from line_words_v1 import project
from rhombille_v1 import (Bridge, add, edge, edges, grid, key, load, midpoint,
                          pin, prepare, reduced, save, trace, union_boundary)


def wedge_catalogue(bridge):
    base=bridge.base
    lookup={}
    for ring,_ in grid(base["footprint"],base["grid_anchor"]).values():
        for a,b in edges(ring):
            lookup.setdefault(edge(a,b),[]).append((ring,a,b))
    triangles=[]
    selected=set()
    for ring in base["rings"]:
        m=midpoint(ring[0],ring[2])
        for a,b in edges(ring):
            side=edge(a,b)
            if base["colors"].get(side)!="black":
                triangles.append((a,b,m))
                selected.add((tuple(sorted(ring)),side))
    for s,c in base["colors"].items():
        if c=="red":
            (other,a,b),=[(r,p,q) for r,p,q in lookup[s] if r not in base["rings"]]
            triangles.append((a,b,midpoint(other[0],other[2])))
            selected.add((tuple(sorted(other)),s))
    assert len(selected)==len(triangles)==20
    assert key(reduced(trace(union_boundary(triangles))))==key(reduced(bridge.model.polygons[0]))
    return sorted(selected)


def orient(vertices,edges,incident,radius):
    remaining=set(vertices)
    matches={}
    roots=[]
    while remaining:
        p=min(remaining)
        component=[p]
        remaining.remove(p)
        for v in component:
            for e in incident[v]:
                (w,)=set(edges[e])-{v}
                if w in remaining:
                    remaining.remove(w)
                    component.append(w)
        root=max(component,key=lambda v:(length(v),v))
        assert length(root)>=radius-2
        roots.append(root)
        seen={root}
        queue=[root]
        used=set()
        for p in queue:
            for e in sorted(incident[p]):
                if e in used:
                    continue
                used.add(e)
                (q,)=set(edges[e])-{p}
                assert q not in seen
                seen.add(q)
                matches[q]=e
                queue.append(q)
        assert len(seen)==len(component)
    assert len(matches)==len(edges) and set(matches.values())==edges.keys()
    return matches,roots


def generate(geometry, matches, floors):
    bridge=geometry.bridge
    base=(0,0,-2)
    anchor=geometry.anchor
    red_shapes={geometry.endpoints[rid][0]:geometry.rings[rid]
                for rid in geometry.at_cube[base]}
    center_shifts={g:bridge.point((g,0,0),bridge.base["center"]) for g in bridge.model.groups}
    result=[]
    for site,(i,j,k,axis) in sorted(matches.items()):
        center=project(anchor,site)
        source=project(anchor,(i,j,k))
        source0=project(anchor,base)
        offset=(source[0]-source0[0],source[1]-source0[1])
        target={add(p,offset) for p in red_shapes[axis]}
        digits={f[v+1]-f[v] for f,v in zip(floors,site,strict=True)}
        bit,=digits
        choices=[]
        for g in sorted(bridge.model.groups):
            if geometry.signs[g]!=(-1 if bit else 1):
                continue
            u,v=center_shifts[g]
            t=(g,center[0]-u,center[1]-v)
            if bridge.phase(t)==bridge.phase((0,0,0)) and (
                    {bridge.point(t,p) for p in bridge.base["red_rhomb"]}==target):
                choices.append(t)
        t,=choices
        result.append(t)
    assert len(set(result))==len(result)
    return result,red_shapes


def coverage(geometry, placement, red_shapes, target_radius):
    bridge=geometry.bridge
    base0=project(geometry.anchor,(0,0,-2))
    transformed={}
    for g in bridge.model.groups:
        pose=(g,0,0)
        transformed[g]=[(tuple(sorted(bridge.point(pose,p) for p in cell)),
                         edge(*(bridge.point(pose,p) for p in side)))
                        for cell,side in wedge_catalogue(bridge)]
    occupied=set()
    for g,x,y in placement:
        delta=x,y
        for ring,side in transformed[g]:
            slot=(tuple(sorted(add(p,delta) for p in ring)),edge(*(add(p,delta) for p in side)))
            assert slot not in occupied
            occupied.add(slot)
    target=[]
    for site in shape_sites(target_radius,-2):
        w=project(geometry.anchor,site)
        delta=w[0]-base0[0],w[1]-base0[1]
        for poly in red_shapes.values():
            ring=tuple(add(p,delta) for p in poly)
            k=tuple(sorted(ring))
            assert all((k,edge(a,b)) in occupied for a,b in edges(ring))
            target.append(ring)
    assert len({tuple(sorted(r)) for r in target})==len(target)
    return target,len(occupied)


def main():
    protocol=load("finite-construct-protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    offsets=list(map(Fraction,protocol["intercepts"]))
    engine,_=prepare()
    geometry=OwnerGeometry(Bridge(engine))
    summary=[]
    for n in protocol["radii"]:
        start=time.perf_counter()
        vertices,links,incident=graph(geometry,n,offsets)
        matched,roots=orient(vertices,links,incident,n)
        placement,red_shapes=generate(geometry,matched,words(n,offsets))
        target,occupied=coverage(geometry,placement,red_shapes,n-protocol["guard"])
        report=dict(radius=n,target_radius=n-protocol["guard"],turtles=len(placement),
                    covered_rhombs=len(target),checked_wedges=occupied,tree_roots=len(roots),
                    seconds=round(time.perf_counter()-start,4))
        summary.append(report)
        save(f"data/constructed-{n}-v1.json",dict(summary=report,roots=roots,
             placement=placement,target_rhombs=target))
        print(json.dumps(report,sort_keys=True),flush=True)
    save("data/construct-summary-v1.json",dict(status="CHECKED_FINITE_TURTLE_CONSTRUCTION",
        runs=summary, scope="Every target rhomb wedge is covered exactly once. Matched Turtle tiles may extend beyond the target. The bounded matching proof applies to the checked radii."))


if __name__=="__main__":
    main()
