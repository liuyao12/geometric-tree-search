"""Search for third-layer rotation receptors on checked second-layer quotients."""

from collections import Counter, defaultdict
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))

from atlas_v1 import contact_segments
from triples_v1 import Study, load, pin, prepare, save


def block(kind, parts):
    return kind, tuple(sorted(tuple(sorted(part)) for part in parts))


def support(value):
    return frozenset(p for part in value[1] for p in part)


def move(study, value, g, x=0, y=0):
    kind, parts = value
    return block(kind, (study.move(part, g, x, y) for part in parts))


def quotient(study, record):
    parts = {tuple(anchor): tuple(tuple(p) for p in poses)
             for anchor, _, poses in record["parts"]}
    primitives = {tuple(anchor): kind for anchor, kind, _ in record["parts"]}
    used = set()
    items, seeds = [], []
    for motif in record["motifs"]:
        child = set(map(tuple, motif["family"]))
        assert not used & child
        used.update(child)
        a = block(motif["kind"]+" triple", [parts[p] for p in child])
        assert move(study, a, *motif["rotation"]) == a
        if motif["profile"] is not None:
            seeds.append((len(items), motif["rotation"]))
        items.append(a)
    items.extend(block(primitives[p], [parts[p]]) for p in sorted(parts.keys()-used))
    owner = {p: i for i, a in enumerate(items) for p in support(a)}
    assert len(owner) == sum(len(ps) for ps in parts.values())
    graph = [{owner[q] for p in support(a) for q in study.neighbors(p) if q in owner}-{i}
             for i, a in enumerate(items)]
    assert all(i in graph[j] for i, ns in enumerate(graph) for j in ns)
    return items, graph, seeds


def repeated(study, items, graph):
    triangles, cycles = Counter(), Counter()
    for a, first in enumerate(items):
        kind = first[0]
        origin = min(support(first))
        for b in sorted(graph[a]):
            if b <= a or items[b][0] != kind:
                continue
            for c in sorted(graph[a] & graph[b]):
                if c <= b or items[c][0] != kind:
                    continue
                triangles[kind] += 1
                options = []
                for r in study.rotations:
                    g, x, y = study.model.action(r, origin)
                    options.extend((r, u-x, v-y) for h, u, v in support(items[b]) if g == h)
                if any(move(study, first, *action) == items[b] and
                       move(study, items[b], *action) == items[c] for action in options):
                    cycles[kind] += 1
    return dict(triangles), dict(cycles)


def boundary(study, a, b):
    contacts = set()
    for p in support(a):
        for q in support(b) & study.neighbors(p):
            edges = contact_segments(study.model.poly(p), study.model.poly(q))
            assert edges
            contacts.update(edges)
    assert contacts
    return contacts


def normalize(study, seed, arms, interfaces):
    forms = []
    for g, matrix in sorted(study.model.groups.items()):
        turned = move(study, seed, g)
        x, y = min((x, y) for _, x, y in support(turned))
        center = move(study, turned, 0, -x, -y)
        neighbors = []
        for a, seam in zip(arms, interfaces, strict=True):
            edge = []
            for pair in seam:
                points = tuple(sorted((matrix[0][0]*u+matrix[0][1]*v-x,
                                       matrix[1][0]*u+matrix[1][1]*v-y) for u, v in pair))
                edge.append(points)
            neighbors.append((move(study, a, g, -x, -y), tuple(sorted(edge))))
        forms.append((center, tuple(sorted(neighbors))))
    return min(forms)


def orbit_stencils(study, items, graph, seeds):
    reverse = {item: i for i, item in enumerate(items)}
    assert len(reverse) == len(items)
    attachment = []
    for i, action in seeds:
        seen = set()
        for j in sorted(graph[i]):
            if j in seen:
                continue
            first = items[j]
            second = move(study, first, *action)
            third = move(study, second, *action)
            assert move(study, third, *action) == first
            b, c = reverse.get(second), reverse.get(third)
            if len({j, b, c}) != 3 or not {b, c} <= graph[i]:
                continue
            seen.update((j, b, c))
            arms = [items[k] for k in (j, b, c)]
            seams = [boundary(study, items[i], a) for a in arms]
            pattern = normalize(study, items[i], arms, seams)
            attachment.append(dict(seed=i, arms=(j, b, c), pattern=pattern,
                                   label=(items[i][0], items[j][0]), action=action))
    return attachment


def analyze(study, record):
    items, graph, seeds = quotient(study, record)
    triangles, cycles = repeated(study, items, graph)
    attachments = orbit_stencils(study, items, graph, seeds)
    conflicts = []
    for (i, a), (j, b) in combinations(enumerate(attachments), 2):
        if a["seed"] == b["seed"]:
            assert not set(a["arms"]) & set(b["arms"])
            continue
        overlap = {a["seed"], *a["arms"]} & {b["seed"], *b["arms"]}
        if overlap:
            conflicts.append((i, j, sorted(overlap)))
    return dict(root=record["root"], blocks=items, triangles=triangles, cycles=cycles,
                complete_first_layer_rings=len(seeds), attachments=attachments, conflicts=conflicts)


def measure(rows):
    return dict(patches=len(rows), blocks=sum(len(r["blocks"]) for r in rows),
                triangles=dict(sum((Counter(r["triangles"]) for r in rows), Counter())),
                cycles=dict(sum((Counter(r["cycles"]) for r in rows), Counter())),
                eligible_seeds=sum(r["complete_first_layer_rings"] for r in rows),
                attachments=dict(Counter("/".join(a["label"]) for r in rows for a in r["attachments"])),
                exact_stencils=len({a["pattern"] for r in rows for a in r["attachments"]}),
                conflicts=sum(len(r["conflicts"]) for r in rows))


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == v for n, v in protocol["pins"].items())
    engine, _ = prepare()
    active = set(load("input/closure-results-v1.json")["rounds"][-1]["active"])
    rows, summaries = [], []
    for case in load("input/results-v1.json"):
        rule = case["omitted"]
        study = Study(engine, active, rule-1, tuple(case["role"]))
        banks = {k: [analyze(study, r) for r in case[k]] for k in ("original", "holdout")}
        pattern_sets = [{a["pattern"] for r in bank for a in r["attachments"]} for bank in banks.values()]
        summary = dict(rule=rule, overlap_of_pattern_banks=len(set.intersection(*pattern_sets)),
                       **{k: measure(v) for k, v in banks.items()})
        rows.append(dict(rule=rule, **banks))
        summaries.append(summary)
        print(json.dumps(summary, sort_keys=True), flush=True)
    save("data/results-v1.json", rows)
    save("data/summary-v1.json", dict(status="CHECKED_FINITE_THIRD_LAYER_RECEPTORS", rules=summaries,
        scope="One-ring attachment of guarded second-layer blocks around fully collared triple seeds. Counts are finite and omit contacts to unclassified fringe blocks. Distinct-seed conflicts preclude simultaneous grouping under the unrestricted rule wherever witnessed."))


if __name__ == "__main__":
    main()
