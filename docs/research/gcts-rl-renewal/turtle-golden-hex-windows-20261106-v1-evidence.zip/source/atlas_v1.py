"""Extract exact macro interface types after the deterministic local partition."""

from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from actions_v1 import prepare
from cluster_v1 import edges, load, mat, pin, save
from compound_v1 import graph, polarity
from local_v1 import apply
from shell_v1 import collinear


def contact_segments(a,b):
    result=set()
    for p,q in edges(a):
        axis=0 if p[0]!=q[0] else 1
        for r,s in edges(b):
            if not (collinear(p,q,r) and collinear(p,q,s)):
                continue
            lo=max(min(p[axis],q[axis]),min(r[axis],s[axis]))
            hi=min(max(p[axis],q[axis]),max(r[axis],s[axis]))
            if lo>=hi:
                continue
            def point(k):
                t=Fraction(k-p[axis],q[axis]-p[axis])
                xy=[x+t*(y-x) for x,y in zip(p,q,strict=True)]
                assert all(c.denominator==1 for c in xy)
                return tuple(map(int,xy))
            result.add(tuple(sorted((point(lo),point(hi)))))
    return result


def partition(engine,root,omitted,role,special,signs):
    assignment={tuple(p):j for p,j in root["raw"]["witness"]}
    patch=set(map(tuple,root["checked"]["placement_set"]))
    adjacent,levels=graph(engine,patch)
    parts={}
    owner={}
    for p,j in assignment.items():
        if j!=special:
            continue
        pieces={p,*[apply(engine,p,r) for i,r in enumerate(engine.grammar.roles[special]) if i!=omitted]}
        assert len(pieces)==4 and pieces<=patch and pieces.isdisjoint(owner)
        owner.update({q:p for q in pieces})
        parts[p]=("core",pieces,(p,))
    for p,j in sorted(assignment.items()):
        if p in owner:
            continue
        assert j!=special
        q=apply(engine,p,role)
        if q in adjacent[p] and q not in owner:
            assert signs[p[0]]==signs[q[0]] and apply(engine,q,role)==p
            pieces={p,q}
            parts[p]=("pair",pieces,(p,q))
        else:
            pieces={p}
            parts[p]=("single",pieces,(p,))
        owner.update({q:p for q in pieces})
    guard={p for p in parts if max(levels[q] for q in parts[p][1])<=6}
    assert {p for p,l in levels.items() if l<=6}<=owner.keys()
    return parts,owner,guard,adjacent


def interfaces(engine,parts,owner,guard,adjacent):
    model=engine.model
    inverses={g:next(j for j in model.groups if model.compose[g,j]==0) for g in model.groups}
    contacts=defaultdict(set)
    for p in guard:
        for a in parts[p][1]:
            for b in adjacent[a]:
                q=owner.get(b)
                if q in guard and p!=q:
                    seg=contact_segments(model.poly(a),model.poly(b))
                    assert seg
                    contacts[p,q].update(seg)
    assert all(contacts[q,p]==v for (p,q),v in contacts.items())
    for (p,q),segments in contacts.items():
        variants=[]
        for (g,x,y),(h,u,v) in product(parts[p][2],parts[q][2]):
            inv=inverses[g]
            trans=mat(model.groups[inv],(u-x,v-y))
            relative=model.compose[inv,h],*trans
            normalized=tuple(sorted(tuple(sorted(mat(model.groups[inv],(a-x,b-y)) for a,b in edge))
                                    for edge in segments))
            variants.append((relative,normalized))
        relative,normalized=min(variants)
        yield parts[p][0],parts[q][0],relative,normalized


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    engine,_=prepare()
    signs,special,_=polarity(engine)
    source=load("input/local-rule-results-v1.json")
    closure=load("input/closure-results-v1.json")["rounds"][-1]["records"]
    assert len(closure)==20
    results=[]
    for variant in source:
        if not variant["uniform"]:
            continue
        omitted=variant["summary"]["omitted"]
        (role,)=map(tuple,variant["uniform"][0])
        atlas=Counter()
        types=Counter()
        for root in closure:
            parts,owner,guard,adjacent=partition(engine,root,omitted-1,role,special,signs)
            types.update(parts[p][0] for p in guard)
            atlas.update(interfaces(engine,parts,owner,guard,adjacent))
        items=[dict(source=a,target=b,pose=rel,segments=seg,count=c)
               for (a,b,rel,seg),c in sorted(atlas.items())]
        summary=dict(omitted=omitted,role=role,clusters=dict(types),exact_directed_interface_types=len(items),
                     contacts=sum(atlas.values()),by_pair=dict(Counter(f"{r['source']}/{r['target']}" for r in items)))
        results.append(dict(summary=summary,interfaces=items))
        print(json.dumps(summary,sort_keys=True),flush=True)
    assert len(results)==2
    save("data/results-v1.json",results)
    report=dict(status="CHECKED_FINITE_MACRO_INTERFACE_ATLAS",rules=[r["summary"] for r in results],
                scope="Exact contact segments in both directions from 20 depth-eight tilings, with a depth-six guard. This is a finite macro interface inventory, not an exhaustive plane atlas.")
    save("data/summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
