"""Extract exact reusable shell shapes from independently accepted Turtle patches."""

from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model, edges, load, pin, save


def collinear(a,b,p):
    return (b[0]-a[0])*(p[1]-a[1])==(b[1]-a[1])*(p[0]-a[0])


def cover_intervals(edge,others):
    a,b = edge
    axis = 0 if a[0]!=b[0] else 1
    start,end = sorted((a[axis],b[axis]))
    hits = []
    neighbors = set()
    for i,c,d in others:
        if not (collinear(a,b,c) and collinear(a,b,d)):
            continue
        lo,hi = sorted((c[axis],d[axis]))
        x,y = max(start,lo),min(end,hi)
        if x<y:
            hits.append((x,y))
            neighbors.add(i)
    missing = []
    current = start
    for x,y in sorted(hits):
        if x>current:
            missing.append((current,x))
        current=max(current,y)
    if current<end:
        missing.append((current,end))
    return axis,missing,neighbors


def boundary(polys):
    remaining = []
    for i,poly in enumerate(polys):
        others = [(j,c,d) for j,p in enumerate(polys) if j!=i for c,d in edges(p)]
        for a,b in edges(poly):
            axis,miss,_ = cover_intervals((a,b),others)
            for lo,hi in miss:
                def point_at(q):
                    t=Fraction(q-a[axis],b[axis]-a[axis])
                    x,y=(Fraction(u)+t*(v-u) for u,v in zip(a,b,strict=True))
                    assert x.denominator==y.denominator==1
                    return int(x),int(y)
                remaining.append(tuple(sorted((point_at(lo),point_at(hi)))))
    return tuple(sorted(remaining))


def sign(matrix):
    a,b = matrix
    return a[0]*b[1]-a[1]*b[0]


def extract(model,placements):
    s = [set(model.support(p)) for p in placements]
    assert len(set().union(*s))==sum(map(len,s))==240*len(placements)
    polys = [model.poly(p) for p in placements]
    groups = model.groups
    inverted = {g:next(h for h in groups if model.compose[g,h]==0) for g in groups}
    hands = Counter(sign(groups[g]) for g,x,y in placements)
    result = []
    for i,poly in enumerate(polys):
        other_edges = [(j,c,d) for j,p in enumerate(polys) if j!=i for c,d in edges(p)]
        neighbors = set()
        for e in edges(poly):
            _,uncovered,contributors = cover_intervals(e,other_edges)
            if uncovered:
                break
            neighbors.update(contributors)
        else:
            g,x,y = placements[i]
            inverse = inverted[g]
            normal = [(0,0,0)]
            for j in neighbors:
                h,a,b = placements[j]
                normal.append(model.action(inverse,(h,a-x,b-y)))
            tag = tuple(sorted(normal))
            assert len(tag)==len(neighbors)+1
            hand = sign(groups[g])
            result.append(dict(center=i,members=sorted({i,*neighbors}),tag=tag,
                              neighbors=len(neighbors),minority=hands[hand]<hands[-hand],
                              opposite=sum(sign(groups[h])<0 for h,_,_ in tag)))
    return result


def unpack(path):
    with gzip.open(path,"rt") as stream:
        return json.load(stream)


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    root=ROOT/"input/donor"
    index=unpack(root/"data/results-v1.json.gz")
    model=Model(load("input/exact-point-model-v1.json"))
    records = {}
    donors = defaultdict(set)
    statistics = {}
    for part in ("training","evaluation"):
        counts = Counter()
        rows=[]
        for entry in index[part]:
            file=root/entry["run_file"]
            assert pin(file)==entry["run_pin"]
            run=unpack(file)
            assert entry["status"]==run["status"]==run["search"]["status"]=="POSITIVE"
            assert run["assurance"]["patch"]["status"]=="VERIFIED"
            placements = list(map(tuple,run["search"]["placements"]))
            clusters = extract(model,placements)
            if part=="training":
                for row in clusters:
                    donors[row["tag"]].add(entry["case_id"])
            counts.update(["patches"])
            counts["placements"] += len(placements)
            counts["surrounded"] += len(clusters)
            counts["minority_surrounded"] += sum(c["minority"] for c in clusters)
            counts["patches_with_shell"] += bool(clusters)
            for row in clusters:
                counts[f"neighbor_{row['neighbors']}"] += 1
            rows.append(dict(case=entry["case_id"],lane=entry["lane"] if part=="evaluation" else run["lane"],
                             placements=placements,clusters=clusters))
        statistics[part]=dict(counts)
        records[part]=rows
    assert not ({x["case"] for x in records["training"]}&{x["case"] for x in records["evaluation"]})
    accepted={tag:cases for tag,cases in donors.items() if len(cases)>=protocol["minimum_distinct_training_cases"]}
    catalog=[]
    for key,cases in sorted(accepted.items()):
        polys=[model.poly(p) for p in key]
        catalog.append(dict(tag=key,training_cases=sorted(cases),outer_segments=boundary(polys)))
    validation=Counter()
    for patch in records["evaluation"]:
        live=[row for row in patch["clusters"] if row["tag"] in accepted]
        validation["covered_shells"]+=len(live)
        validation["covered_minority_shells"]+=sum(c["minority"] for c in live)
        validation["patches_with_reusable_shell"]+=bool(live)
        for i,row in enumerate(live):
            for other in live[i+1:]:
                validation["pairs"]+=1
                validation["pairs_share_primitive"]+=not set(row["members"]).isdisjoint(other["members"])
    save("data/shell-records-v1.json",records)
    save("data/catalogue-v1.json",catalog)
    result=dict(status="CHECKED_TILE_FRAME_SHELL_DISCOVERY",distinct_training_signatures=len(donors),
                admitted=len(catalog),counts=statistics,evaluation=dict(validation),
                scope="Completely surrounded primitive centers in saved finite patches. Shells are exact local macro candidates. No forced-shell theorem, layer substitution or plane-tiling claim.")
    save("data/summary-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
