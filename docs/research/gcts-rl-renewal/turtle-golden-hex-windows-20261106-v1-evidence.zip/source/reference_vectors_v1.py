"""Snap the published Figure 2 and Figure 4 linework to an exact lattice."""

import hashlib
import json
from pathlib import Path
from statistics import median
import sys

import pdfplumber

ROOT = Path(__file__).resolve().parents[1]
BOXES = {
    "P0": (169, 51, 205, 72), "P1": (179, 72, 240, 109),
    "P2": (194, 112, 330, 177), "P3": (230, 184, 389, 259),
    "T1": (65, 88, 94, 112), "T2": (68, 111, 151, 183),
    "T3": (106, 159, 221, 260),
}


def vectors(page, name, box):
    x0, y0, x1, y1 = box
    rows = []
    fills = []
    for c in page.curves:
        if not (c["stroke"] or c["fill"]) or not all(item[0] in ("m", "l", "h") for item in c["path"]):
            continue
        if sum(item[0]=="m" for item in c["path"]) != 1:
            continue
        if not (x0 <= c["x0"] <= c["x1"] <= x1 and y0 <= c["top"] <= c["bottom"] <= y1):
            continue
        if name == "T3" and c["bottom"] < 182 and c["x1"] < 151:
            continue
        if name == "word" and not (c["width"] > 20 and c["top"] < 455):
            continue
        if len(c["pts"]) >= 3:
            (rows if c["stroke"] else fills).append((c["pts"], c["fill"] or c["path"][-1][0] == "h"))
    return rows+fills


def snap(rows, pitch):
    x0, y0 = rows[0][0][0]
    result = {}
    errors = []
    for raw, closed in rows:
        floats = [((x-x0)/pitch, (y-y0)*3**.5/(2*pitch)-(x-x0)/(2*pitch)) for x,y in raw]
        points = tuple((round(x),round(y)) for x,y in floats)
        error = max(max(abs(x-i),abs(y-j)) for (x,y),(i,j) in zip(floats,points,strict=True))
        if error >= .12:
            continue
        if closed and points[0] != points[-1]:
            points += points[:1]
        if len(set(points)) < 3:
            continue
        result[points] = True
        errors.append(error)
    return dict(paths=list(result),accepted=len(result),observed=len(rows),max_error=round(max(errors),6))


def main():
    path = Path(sys.argv[1])
    with pdfplumber.open(path) as pdf:
        page = pdf.pages[4]
        cases = {name:snap(vectors(page,name,box),.625 if name.endswith("3") else 1.25)
                 for name,box in BOXES.items()}
        word = vectors(page,"word",(115,452,323,487))
        pitch = median((max(x for x,_ in a)-min(x for x,_ in a))/5 for a,_ in word)
        cases["word"] = snap(word,pitch)
    receipt = dict(source="https://doi.org/10.1007/s00454-025-00717-6",figures=[2,4],
                   pdf_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),cases=cases)
    with (ROOT / "input/figure-vectors-v1.json").open("x") as out:
        json.dump(receipt,out,separators=(",",":"),sort_keys=True)
        out.write("\n")
    for name,row in cases.items():
        print(name,row["accepted"],row["observed"],row["max_error"])


if __name__ == "__main__":
    main()
