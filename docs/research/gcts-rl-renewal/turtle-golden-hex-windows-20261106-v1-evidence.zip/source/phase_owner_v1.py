"""Resolve competing uniform cube centers by their exact integer phase."""

from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from mechanical_v1 import ALPHA, Q, LocalGeometry, intervals
from rhombille_v1 import Bridge, load, pin, prepare, save


def patterns(total, radius, beta=Q()):
    target = ALPHA*total+beta
    for domains in product(intervals(radius), repeat=3):
        lo = sum((a for a,_,_ in domains), Q())
        hi = sum((b for _,b,_ in domains), Q())
        for n in range(-target.floor(), 3-target.floor()):
            if lo < target+Q(n) < hi:
                yield tuple(bit for _,_,bit in domains), n


class OwnerGeometry(LocalGeometry):
    def context(self, base, pattern, radius, height):
        word, kind, _ = self.state(base,pattern,radius)

        def change(axis, offset):
            if offset<0:
                return -sum(pattern[axis][i+radius] for i in range(offset,0))
            return sum(pattern[axis][i+radius] for i in range(offset))

        @lru_cache(maxsize=None)
        def selected(site):
            digits = word(site)
            if digits == (1,1,1):
                return True
            if digits != (0,0,0):
                return False
            band = height-sum(change(i,n-base[i]) for i,n in enumerate(site))
            assert sum(site) in (-2,-1)
            return (sum(site),band) in {(-2,2),(-1,1)}

        @lru_cache(maxsize=None)
        def owners(rid):
            return tuple(sorted(site for site in self.endpoints[rid][1] if selected(site)))

        return (word, kind, owners), selected

    def verify_owner_case(self, base, pattern, radius, height):
        state, selected = self.context(base,pattern,radius,height)
        word, kind, owners = state
        red_degrees, hex_degrees = [], []
        if sum(base) == -2:
            for rid in self.at_cube[base]:
                if len(owners(rid)) != int(kind(rid)=="hex"):
                    return "rhomb ownership", None, None
                for seam, k in self.neighbors(rid):
                    if len(owners(k)) != int(kind(k)=="hex"):
                        return "neighbor ownership", None, None
                    left, a = self.side(rid,seam,state)
                    right, b = self.side(k,seam,state)
                    if a is not None and a == b:
                        if left is not None or right is not None:
                            return "hex interior", None, None
                    elif {left,right} not in ({"red","black"},{"red","hole"}):
                        return "edge colors", None, None
                if kind(rid) == "red":
                    candidates = self.red_choices(rid,state)
                    red_degrees.append(len(candidates))
                    if len(candidates)!=2 or len(set(candidates))!=2:
                        return "red degree", None, None
        if selected(base):
            options = self.hex_options(base,state)
            if not options:
                return "hex degree", None, None
            hex_degrees.append(len(options))
        return None, red_degrees, hex_degrees


def screen(geometry, radius, beta):
    failures, reds, hexes, cases = Counter(), Counter(), Counter(), Counter()
    example = {}
    for layer in (-2,-1):
        base = (0,0,layer)
        for p,height in patterns(layer,radius,beta):
            cases[layer] += 1
            reason,r,h = geometry.verify_owner_case(base,p,radius,height)
            if reason:
                failures[reason] += 1
                example.setdefault(reason,dict(layer=layer,pattern=p,height=height))
                continue
            reds.update(r)
            hexes.update(h)
    return dict(radius=radius,beta=beta.wire(),cases=dict(cases),failures=dict(failures),examples=example,
                red_degrees=dict(reds),hex_degrees=dict(hexes))


def main():
    protocol = load("phase-owner-protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == v for n,v in protocol["pins"].items())
    engine, _ = prepare()
    geometry = OwnerGeometry(Bridge(engine))
    rows = [screen(geometry,protocol["radius"],Q(Fraction(a),Fraction(b)))
            for a,b in protocol["phase_sums"]]
    save("data/phase-owner-v1.json",dict(status="CHECKED_PHASE_SELECTED_HEX_OWNERS",trials=rows))
    for row in rows:
        print(json.dumps({k:v for k,v in row.items() if k!="examples"},sort_keys=True),flush=True)


if __name__ == "__main__":
    main()
