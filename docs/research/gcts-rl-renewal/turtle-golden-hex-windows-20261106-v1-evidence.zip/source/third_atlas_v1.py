"""Measure exact boundary contacts after the checked third-layer contraction."""

from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from core_arm_closure_v1 import decode
from receptors_v1 import Study, block, boundary, load, normalize, pin, prepare, save, support


def contract(record, templates):
    items = [decode(a) for a in record["blocks"]]
    by_seed = defaultdict(set)
    for att in record["attachments"]:
        p = att["pattern"]
        key = decode(p[0]), tuple(decode(a) for a, _ in p[1])
        if key in templates:
            by_seed[att["seed"]].update(att["arms"])
    owners = set()
    contracted = []
    for i, arms in sorted(by_seed.items()):
        ids = {i, *arms}
        assert owners.isdisjoint(ids)
        owners.update(ids)
        assert items[i][0] == "single triple" and all(items[j][0] == "core" for j in arms)
        contracted.append(block("third-layer group", (p for j in ids for p in items[j][1])))
    contracted.extend(item for i, item in enumerate(items) if i not in owners)
    all_poses = {p for b in items for p in support(b)}
    assert {p for b in contracted for p in support(b)} == all_poses
    assert sum(len(support(b)) for b in contracted) == len(all_poses)
    return contracted, len(by_seed)


def measure(study, record, templates):
    items, total = contract(record, templates)
    owner = {p: i for i, a in enumerate(items) for p in support(a)}
    graph = [{owner[q] for p in support(a) for q in study.neighbors(p) if q in owner}-{i}
             for i, a in enumerate(items)]
    contacts = Counter()
    rings = defaultdict(Counter)
    for i, a in enumerate(items):
        assert all(i in graph[j] for j in graph[i])
        if a[0] != "third-layer group":
            continue
        neighbors = [items[j] for j in sorted(graph[i])]
        seams = [boundary(study, a, b) for b in neighbors]
        contacts.update(normalize(study, a, [b], [s]) for b, s in zip(neighbors, seams, strict=True))
        center, stencil = normalize(study, a, neighbors, seams)
        rings[center][stencil] += 1
    return contacts, rings, total


def main():
    protocol = load("third-atlas-protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == v for n, v in protocol["pins"].items())
    engine, _ = prepare()
    active = set(load("input/closure-results-v1.json")["rounds"][-1]["active"])
    study = Study(engine, active, 0, (6, 0, 0))
    rule, = [r for r in load("data/results-v1.json") if r["rule"] == 1]
    closure = load("data/core-arm-closure-v1.json")
    assert all(c["geometry"] == "OVERLAP" or c["checks"][-1]["status"] == "EXCLUDED"
               for c in closure["collision_cases"])
    templates = {(decode(s), tuple(map(decode, arms))) for s, arms in closure["types"]}
    banks = {}
    summary = {}
    for k in ("original", "holdout"):
        contact, rings, count = Counter(), defaultdict(Counter), 0
        for r in rule[k]:
            c, s, n = measure(study, r, templates)
            contact.update(c)
            for key, profiles in s.items():
                rings[key].update(profiles)
            count += n
        banks[k] = dict(contacts=sorted(contact.items()),
                        rings=[(g, sorted(r.items())) for g, r in sorted(rings.items())])
        summary[k] = dict(contracted=count, directed_contacts=sum(contact.values()),
                          contact_types=len(contact), center_shapes=len(rings),
                          guarded_profiles=sorted(len(rs) for rs in rings.values()))
    result = dict(status="CHECKED_FINITE_THIRD_LAYER_ATLAS", banks=summary,
                  scope="Only contacts between blocks with known membership inside the two-ring guard. Profiles at the guard boundary can be partial.")
    save("data/third-atlas-v1.json", banks)
    save("data/third-atlas-summary-v1.json", result)
    print(json.dumps(result,sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
