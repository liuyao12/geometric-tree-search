"""Synthesize an exact finite red-rhomb attachment rule, or retain its conflict."""

from collections import Counter
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from phase_owner_v1 import OwnerGeometry, patterns
from rhombille_v1 import Bridge, load, pin, prepare, save


def floor_change(pattern, wide, axis, shift):
    offsets = range(shift,0) if shift<0 else range(shift)
    return (-1 if shift<0 else 1)*sum(pattern[axis][j+wide] for j in offsets)


def signature(geometry, rid, base, pattern, wide, band, narrow):
    axis, ends, _ = geometry.endpoints[rid]
    origin, = [p for p in ends if sum(p)==-2]
    offsets = [j-k for j,k in zip(origin,base,strict=True)]
    words = []
    for i,d in enumerate(offsets):
        assert -wide <= d-narrow <= d+narrow <= wide
        words.append(pattern[i][wide+d-narrow:wide+d+narrow+1])
    local_band = band-sum(floor_change(pattern,wide,i,d) for i,d in enumerate(offsets))
    return axis, local_band, tuple(words)


def collect(geometry, radius):
    wide = radius+2
    demands = set()
    all_red_keys = set()
    shapes = Counter()
    for layer in (-2,-1):
        base=(0,0,layer)
        for pattern,band in patterns(layer,wide):
            state, selected = geometry.context(base,pattern,wide,band)
            _, kind, _ = state
            if layer == -2:
                for rid in geometry.at_cube[base]:
                    if kind(rid)=="red":
                        all_red_keys.add(signature(geometry,rid,base,pattern,wide,band,radius))
            if not selected(base):
                continue
            options = geometry.hex_options(base,state)
            request = []
            for rid in options:
                targets = geometry.red_choices(rid,state)
                assert len(targets)==2 and base in targets
                request.append((signature(geometry,rid,base,pattern,wide,band,radius),targets.index(base)))
            assert 1<=len(request)<=3 and len(set(request))==len(request)
            demands.add(tuple(sorted(request)))
            shapes[len(request)] += 1
    assert {k for r in demands for k,_ in r} == all_red_keys
    ordered = {k:i+1 for i,k in enumerate(sorted(all_red_keys))}
    clauses = set()
    for req in demands:
        literals = tuple(ordered[key]*(1 if value else -1) for key,value in req)
        clauses.add(literals)
        for i,p in enumerate(literals):
            for q in literals[i+1:]:
                clauses.add((-p,-q))
    return sorted(demands), ordered, sorted(clauses), dict(shapes)


def solve(clauses, limit):
    nodes = 0
    def descend(assigned):
        nonlocal nodes
        nodes += 1
        if nodes>limit:
            return "BOUNDED", None
        while True:
            remaining = []
            unit = None
            for clause in clauses:
                if any(assigned.get(abs(l))==(l>0) for l in clause):
                    continue
                left = [l for l in clause if abs(l) not in assigned]
                if not left:
                    return "UNSAT", {"clause":clause, "assignment":sorted(assigned.items())}
                if len(left)==1:
                    unit = left[0]
                    break
                remaining.append(left)
            if unit is None:
                break
            assigned[abs(unit)] = unit>0
        if not remaining:
            return "SAT", assigned
        choices = Counter(abs(l) for c in remaining for l in c)
        p = max(choices, key=lambda k:(choices[k],-k))
        failures = []
        for bit in (False,True):
            status, cert = descend({**assigned,p:bit})
            if status!="UNSAT":
                return status,cert
            failures.append(cert)
        return "UNSAT", {"variable":p, "children":failures}
    status,certificate=descend({})
    return status,certificate,nodes


def main():
    protocol = load("attachment-protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == v for n,v in protocol["pins"].items())
    engine,_ = prepare()
    geometry=OwnerGeometry(Bridge(engine))
    results=[]
    for radius in protocol["radii"]:
        demands,keys,clauses,shapes=collect(geometry,radius)
        status,proof,visits=solve(clauses,protocol["node_limit"])
        row=dict(radius=radius,status=status,visits=visits,variables=len(keys),clauses=len(clauses),
                 demands=len(demands),demand_sizes=shapes)
        print(json.dumps(row,sort_keys=True),flush=True)
        if status=="SAT":
            assert all(sum(proof.get(keys[k],False)==bool(v) for k,v in requirement)==1
                       for requirement in demands)
            row["rule"]=[(k,int(proof.get(i,False))) for k,i in keys.items()]
        results.append(dict(summary=row, demands=demands, keys=list(keys), clauses=clauses, proof=proof))
        if status=="SAT":
            break
    save("data/attachment-v1.json",dict(status="CHECKED_RED_ATTACHMENT_SEARCH",runs=results))


if __name__=="__main__":
    main()
