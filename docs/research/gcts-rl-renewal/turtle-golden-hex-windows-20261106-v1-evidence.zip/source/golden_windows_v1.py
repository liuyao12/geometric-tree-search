"""Check large patch boundaries and expand only the branches meeting a window."""

from collections import Counter
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import sys
from time import perf_counter

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model,bounds,load,mat,pin,save
from golden_geometry_v1 import add,area2,polygon_points,strip,sub,support,transform,unit_segments,words
from golden_growth_v1 import ball,center,from_tiles,join_boundaries,norm,p_children,signed,t_children
from golden_seams_v1 import predict
from triangle_geometry_v1 import polygon_overlap


@dataclass
class Record:
    ring: tuple
    size: int
    box: tuple
    steps: tuple = ()
    tiles: tuple = ()


def box_ring(box):
    a,b,c,d=box
    return ((a,c),(b,c),(b,d),(a,d))


def overlaps(a,b):
    return max(a[0],b[0]) < min(a[1],b[1]) and max(a[2],b[2]) < min(a[3],b[3])


def coordinate_box(model,box,g,offset):
    return bounds(add(mat(model.groups[g],p),offset) for p in box_ring(box))


def expand(model,library,key,window):
    hits=[]
    stats=Counter()
    frame=box_ring(window)
    boxes={g:bounds(p) for g,p in model.polygons.items()}

    def visit(key,g,offset):
        node=library[key]
        stats["checked_clusters"]+=1
        if not overlaps(coordinate_box(model,node.box,g,offset),window):
            stats["pruned_clusters"]+=1
            return
        if node.tiles:
            for tile in transform(model,node.tiles,g,offset):
                h,x,y=tile
                stats["checked_leaf_boxes"]+=1
                if not overlaps(coordinate_box(model,boxes[h],0,(x,y)),window):
                    continue
                stats["exact_tile_window_tests"]+=1
                if polygon_overlap(model.poly(tile),frame)["overlap"]:
                    hits.append(tile)
        else:
            for kind,n,turn,shift in node.steps:
                visit((kind,n),model.compose[g,turn],add(mat(model.groups[g],shift),offset))

    visit(key,0,(0,0))
    return tuple(sorted(hits)),dict(stats)


def main():
    p=load("window-protocol-v1.json")
    assert p["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==d for n,d in p["pins"].items())
    model=Model(load("input/exact-point-model-v1.json"))
    recovered={r["name"]:tuple(map(tuple,r["patch"])) for r in load("data/recovery-v1.json")["levels"]}
    saved={r["id"]:r for r in load("data/growth-v1.json")["levels"]}
    labels={(r["role"],r["context"]):tuple(tuple(map(tuple,e)) for e in r["edges"])
            for r in load("data/seams-v1.json")["labels"]}
    library={}
    for name in ("P0","T1"):
        key=name[0],int(name[1])
        tiles=transform(model,recovered[name],0,sub((0,0),center(model,recovered[name])))
        _,ring=from_tiles(model,tiles)
        library[key]=Record(ring,len(tiles),bounds(ring),tiles=tiles)
    sequence=words(2*p["level"]+1)
    sizes=[]
    for n in range(1,p["level"]+1):
        L,M,K=(len(sequence[i]) for i in (2*n,2*n-1,2*n-2))
        tiles,ring=from_tiles(model,strip(sequence[2*n]))
        library["S",n]=Record(ring,len(tiles),bounds(ring),tiles=tiles)
        for kind in ("T","P"):
            key=kind,n
            if key not in library:
                rows=t_children(model,n,L,M-K) if kind=="T" else p_children(n,L,M,K,M-K)
                ring=join_boundaries(model,[(library[label,k].ring,g,s) for label,k,g,s in rows])
                count=sum(library[label,k].size for label,k,_,_ in rows)
                assert signed(ring)==count*area2(model.polygons[0])
                library[key]=Record(ring,count,bounds(ring),steps=rows)
            data=library[key]
            exact=set(unit_segments((*data.ring,data.ring[0])))
            assert exact==set().union(*predict(model,kind,n,sequence,labels))
            name=f"{kind}{n}"
            if name in saved:
                assert data.ring==tuple(map(tuple,saved[name]["ring"]))
                assert data.size==saved[name]["tiles"]
            receipt=dict(kind=kind,level=n,size=data.size,boundary_edges=len(exact),disk_radius=ball(data.ring),
                         ring_sha256=sha256(json.dumps(data.ring,separators=(",",":")).encode()).hexdigest())
            sizes.append(receipt)
            print(json.dumps(receipt,sort_keys=True),flush=True)
    windows=[]
    for kind,n,window in p["windows"]:
        key=kind,n
        assert max(map(norm,box_ring(window)))<ball(library[key].ring)**2
        start=perf_counter()
        poses,stats=expand(model,library,key,window)
        elapsed=perf_counter()-start
        target=polygon_points(model,(*box_ring(window),box_ring(window)[0]))
        assert target<=support(model,poses)
        assert all(not target.isdisjoint(model.support(t)) for t in poses)
        ref=saved.get(f"{kind}{n}")
        if ref:
            brute=tuple(sorted(t for t in map(tuple,ref["patch"]) if not target.isdisjoint(model.support(t))))
            assert poses==brute
        result=dict(kind=kind,level=n,window=window,root_tiles=library[key].size,window_tiles=len(poses),
                    target_atoms=len(target),counts=stats,seconds=elapsed,literal_comparison=bool(ref),poses=poses)
        windows.append(result)
        print(json.dumps({k:v for k,v in result.items() if k!="poses"},sort_keys=True),flush=True)
    save("data/windows-v1.json",dict(status="CHECKED_LAZY_GOLDEN_HEX_WINDOWS",sizes=sizes,windows=windows))


if __name__=="__main__":
    main()
