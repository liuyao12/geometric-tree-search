"""Exact local certification for a three-word Rhombille coloring."""

from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache, total_ordering
from itertools import product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from line_words_v1 import project, rhomb_variables
from rhombille_v1 import (Bridge, add, edge, edges, grid, load, pin, polarity,
                          prepare, save, trace, union_boundary)


@total_ordering
@dataclass(frozen=True)
class Q:
    """The exact value a+b*(5-sqrt(5))/10."""
    a: Fraction = Fraction(0)
    b: Fraction = Fraction(0)

    def __add__(self, other):
        return Q(self.a+other.a, self.b+other.b)

    def __sub__(self, other):
        return Q(self.a-other.a, self.b-other.b)

    def __mul__(self, n):
        return Q(self.a*n, self.b*n)

    def sign(self):
        p, q = 10*self.a+5*self.b, -self.b
        if not p or not q or (p>0)==(q>0):
            return (p+q>0)-(p+q<0)
        return (1 if p>0 else -1) if p*p>5*q*q else (1 if q>0 else -1)

    def __lt__(self, other):
        return (self-other).sign() < 0

    def floor(self):
        n = int(self.a+self.b*Fraction(1,4))
        while self < Q(n):
            n -= 1
        while self >= Q(n+1):
            n += 1
        return n

    def residue(self):
        return self-Q(self.floor())

    def wire(self):
        return str(self.a), str(self.b)


ALPHA = Q(0,1)


@lru_cache(maxsize=None)
def intervals(radius):
    thresholds = sorted({Q(), Q(1), *[(ALPHA*-j).residue() for j in range(-radius,radius+2)]})
    rows = []
    for a,b in zip(thresholds,thresholds[1:]):
        sample = (a+b)*Fraction(1,2)
        bits = tuple((sample+ALPHA*(j+1)).floor()-(sample+ALPHA*j).floor()
                     for j in range(-radius,radius+1))
        rows.append((a,b,bits))
    return rows


def patterns(total, radius, beta):
    target = (ALPHA*total+beta).residue()
    for domains in product(intervals(radius), repeat=3):
        lo = sum((a for a,_,_ in domains), Q())
        hi = sum((b for _,b,_ in domains), Q())
        if any(lo < target+Q(i) < hi for i in range(3)):
            yield tuple(bit for _,_,bit in domains)


class LocalGeometry:
    def __init__(self, bridge):
        self.bridge = bridge
        self.anchor = bridge.base["grid_anchor"]
        self.signs, _, _ = polarity(bridge.engine)
        self.hexagon = trace(union_boundary(bridge.base["hex_rhombs"]))
        self.rings = [p for p,_ in grid(((-24,-24),(24,24)),self.anchor).values()]
        self.endpoints = {}
        self.rim = defaultdict(list)
        self.at_cube = defaultdict(list)
        for k,r in enumerate(self.rings):
            axis, ends, shared = rhomb_variables(self.anchor, r)
            self.endpoints[k] = axis, ends, shared
            for site in ends:
                self.at_cube[site].append(k)
            for a,b in edges(r):
                self.rim[edge(a,b)].append(k)

    @lru_cache(maxsize=None)
    def palette(self, site, bit):
        center = project(self.anchor, site)
        result = []
        for g in sorted(self.bridge.model.groups):
            if self.signs[g] != (-1 if bit else 1):
                continue
            px,py = self.bridge.point((g,0,0), self.bridge.base["center"])
            t = (g,center[0]-px,center[1]-py)
            if self.bridge.phase(t) != self.bridge.phase((0,0,0)):
                continue
            mapping = {edge(self.bridge.point(t,a),self.bridge.point(t,b)):
                       self.bridge.base["colors"].get(edge(a,b),"black") for a,b in edges(self.hexagon)}
            result.append(mapping)
        assert len(result)==3 and all(result[0]==r for r in result)
        return result[0]

    def neighbors(self, rid):
        for a,b in edges(self.rings[rid]):
            seam = edge(a,b)
            other, = set(self.rim[seam])-{rid}
            yield seam, other

    def state(self, base, pattern, radius):
        def bit(axis, index):
            offset = index-base[axis]
            assert -radius<=offset<=radius, (axis,index,base)
            return pattern[axis][offset+radius]

        @lru_cache(maxsize=None)
        def word(site):
            return tuple(bit(i,n) for i,n in enumerate(site))

        @lru_cache(maxsize=None)
        def kind(rid):
            _,_,shared = self.endpoints[rid]
            p,q = (bit(*item) for item in shared)
            return "hex" if p==q else "red" if (p,q)==(0,1) else "hole"

        @lru_cache(maxsize=None)
        def owners(rid):
            return tuple(sorted(site for site in self.endpoints[rid][1] if len(set(word(site)))==1))

        return word, kind, owners

    def side(self, rid, seam, state):
        word, kind, owners = state
        label = kind(rid)
        if label != "hex":
            assert not owners(rid)
            return label, None
        owner, = owners(rid)
        return self.palette(owner,word(owner)[0]).get(seam), owner

    def red_choices(self, rid, state):
        _, kind, _ = state
        assert kind(rid) == "red"
        return tuple(sorted(owner for s,k in self.neighbors(rid)
                            for color, owner in (self.side(k,s,state),)
                            if color == "black" and owner is not None))

    def hex_options(self, site, state):
        word, kind, _ = state
        assert len(set(word(site))) == 1
        palette = self.palette(site,word(site)[0])
        return tuple(sorted({rid for s,c in palette.items() if c=="black"
                             for rid in self.rim[s] if kind(rid)=="red"}))

    def verify_case(self, base, pattern, radius):
        state = self.state(base,pattern,radius)
        word, kind, owners = state
        red_degrees, hex_degrees = [], []
        if sum(base) == -2:
            # One representative per orientation of Rhombille cell.
            for rid in self.at_cube[base]:
                if len(owners(rid)) != int(kind(rid)=="hex"):
                    return "rhomb ownership", None, None
                for seam, k in self.neighbors(rid):
                    if len(owners(k)) != int(kind(k)=="hex"):
                        return "neighbor ownership", None, None
                    left, a = self.side(rid,seam,state)
                    right, b = self.side(k,seam,state)
                    if a is not None and a == b:
                        if left is not None or right is not None:
                            return "hex interior", None, None
                    elif {left,right} != {"red","black"} and not (
                            left=="red" and right=="hole" or left=="hole" and right=="red"):
                        return "edge colors", None, None
                if kind(rid) == "red":
                    candidates = self.red_choices(rid,state)
                    red_degrees.append(len(candidates))
                    if len(candidates)!=2 or len(set(candidates))!=2:
                        return "red degree", None, None
        if len(set(word(base))) == 1:
            options = self.hex_options(base,state)
            if not options:
                return "hex degree", None, None
            hex_degrees.append(len(options))
        return None, red_degrees, hex_degrees


def screen(geometry, beta, radius):
    failures = Counter()
    example = {}
    reds, hexes, states = Counter(), Counter(), Counter()
    for layer in (-2,-1):
        base = (0,0,layer)
        for p in patterns(layer,radius,beta):
            states[layer] += 1
            reason,r,h = geometry.verify_case(base,p,radius)
            if reason:
                failures[reason] += 1
                example.setdefault(reason,dict(layer=layer,pattern=p))
                continue
            reds.update(r)
            hexes.update(h)
    return dict(beta=beta.wire(),radius=radius,states=dict(states),failures=dict(failures),
                examples=example,red_degrees=dict(reds),hex_degrees=dict(hexes))


def main():
    protocol = load("mechanical-protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == v for n,v in protocol["pins"].items())
    engine, _ = prepare()
    geometry = LocalGeometry(Bridge(engine))
    trials = [screen(geometry,Q(Fraction(a),Fraction(b)),protocol["radius"])
              for a,b in protocol["phase_sums"]]
    result = dict(status="CHECKED_FINITE_PHASE_ENUMERATION",alpha=ALPHA.wire(),trials=trials)
    save("data/mechanical-v1.json",result)
    for row in trials:
        print(json.dumps({k:v for k,v in row.items() if k!="examples"},sort_keys=True),flush=True)


if __name__ == "__main__":
    main()
