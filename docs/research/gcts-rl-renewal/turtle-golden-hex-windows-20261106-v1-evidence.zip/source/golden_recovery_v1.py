"""Recover cluster placements from exact observations of unmarked Turtle patches."""

from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model,load,pin,save
from golden_geometry_v1 import area2,cover,loops,matches,perimeter,strip,sub,support,transform,words


def embeddings(model,prototype,observations,fraction):
    by_group=defaultdict(list)
    for g,x,y in observations:
        by_group[g].append((x,y))
    results={}
    for turn in model.groups:
        oriented=transform(model,prototype,turn)
        votes=Counter(sub(q,(x,y)) for g,x,y in oriented for q in by_group[g])
        for shift,count in votes.items():
            if count >= len(oriented)*fraction:
                patch=transform(model,oriented,0,shift)
                results.setdefault(patch,dict(turn=turn,shift=shift,votes=count))
    return results


def assemble(model,known,recipes,threshold,paths):
    assert len(set(known))==len(known)
    observed=set(known)
    occupied=support(model,known)
    options={}
    for label,count,prototype in recipes:
        candidates=embeddings(model,prototype,known,threshold)
        for patch in matches(model,prototype,paths):
            candidates.setdefault(patch,dict(source="closed contour",votes=len(observed.intersection(patch))))
        options[label]=[]
        for patch,pose in sorted(candidates.items()):
            unknown=set(patch)-observed
            inferred=support(model,sorted(unknown))
            if not occupied.intersection(inferred):
                options[label].append(dict(label=label,patch=patch,pose=pose,seen=frozenset(patch)&observed,
                                           support=support(model,patch)))
    result=[]
    calls=0
    limits={label:count for label,count,_ in recipes}
    ranked=[row for label in options for row in options[label]]
    by_seen={t:[i for i,row in enumerate(ranked) if t in row["seen"]] for t in observed}
    assert all(by_seen.values())

    def search(left, used, taken, counts):
        nonlocal calls
        calls+=1
        if not left:
            missing=Counter({k:v-counts[k] for k,v in limits.items() if counts[k]<v})
            additions=[]
            if missing:
                partial=tuple(t for i in taken for t in ranked[i]["patch"])
                rings=loops(model,partial)
                if len(rings)!=sum(missing.values())+1:
                    return
                for ring in rings[1:]:
                    choices=[(label,patch) for label,_,recipe in recipes if missing[label]
                             for patch in matches(model,recipe,(ring,))]
                    if len(choices)!=1:
                        return
                    label,patch=choices[0]
                    fillings,domains,checks=cover(model,ring)
                    assert patch in fillings
                    additions.append(dict(label=label,patch=patch,
                                           pose=dict(source="enclosed gap",votes=0,domains=domains,calls=checks)))
                    missing[label]-=1
            result.append((tuple(sorted(taken)),additions))
            return
        def legal(i):
            row=ranked[i]
            return counts[row["label"]]<limits[row["label"]] and not used.intersection(row["support"])
        viable=[]
        for tile in sorted(left):
            choices=[i for i in by_seen[tile] if legal(i)]
            if not choices:
                return
            if not viable or len(choices)<len(viable):
                viable=choices
                if len(viable)==1:
                    break
        for i in viable:
            row=ranked[i]
            name=row["label"]
            counts[name]+=1
            search(left-row["seen"],used|row["support"],(*taken,i),counts)
            counts[name]-=1

    search(observed,set(),(),Counter())
    selections=[]
    for solution,additions in result:
        chosen=[{k:ranked[i][k] for k in ("label","patch","pose")} for i in solution]+additions
        patch=tuple(sorted(t for row in chosen for t in row["patch"]))
        assert observed<=set(patch)
        assert len(support(model,patch))==len(patch)*240
        ring,=loops(model,patch)
        assert area2(ring)==len(patch)*area2(model.polygons[0])
        selections.append(dict(patch=patch,children=chosen))
    return selections,{k:len(v) for k,v in options.items()},calls


def main():
    plan=load("protocol-v1.json")
    assert plan["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/k)==v for k,v in plan["pins"].items())
    model=Model(load("input/exact-point-model-v1.json"))
    source=load("input/figure-vectors-v1.json")
    paths={k:[tuple(map(tuple,ring)) for ring in v["paths"]] for k,v in source["cases"].items()}
    ready={}
    levels=[]
    for name in ("P0","T1"):
        solutions,poses,branches=cover(model,paths[name][0])
        patch,=solutions
        ready[name]=patch
        levels.append(dict(name=name,patch=patch,pose_candidates=poses,calls=branches,children=[],
                           observations=0,notes="Silhouette only."))
    figure_word=tuple(sorted((p[0] for p in matches(model,((0,0,0),),paths["word"])),key=lambda q:q[1]))
    word="00100010010"
    expected=tuple(sorted(transform(model,strip(word),0,sub(figure_word[0][1:],strip(word)[0][1:])),
                          key=lambda q:q[1]))
    assert expected==figure_word
    seq=words(6)
    for n in (2,4,6):
        ready[f"S{n}"]=strip(seq[n])
        support(model,ready[f"S{n}"])
    for name,child_terms in plan["recipes"].items():
        recipes=[(child,count,ready[child]) for child,count in child_terms]
        known=tuple(p[0] for p in matches(model,((0,0,0),),paths[name]))
        solutions,domains,calls=assemble(model,known,recipes,Fraction(*plan["threshold"][name]),paths[name])
        row=dict(name=name,observations=len(known),solutions=len(solutions),domains=domains,calls=calls)
        print(json.dumps(row),flush=True)
        if len(solutions)!=1:
            raise AssertionError((name,row))
        row.update(solutions[0])
        ready[name]=row["patch"]
        levels.append(row)
    save("data/recovery-v1.json",dict(status="CHECKED_GOLDEN_HEX_RECOVERY",levels=levels,
         word=dict(letters=word,prototype=strip(word),observed=figure_word),standard_words=seq))


if __name__=="__main__":
    main()
