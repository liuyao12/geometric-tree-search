"""Search for a deterministic disjoint macro partition from the shell atlas."""

from collections import Counter, defaultdict
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from actions_v1 import CENTRE, prepare
from closure_v1 import Audit
from cluster_v1 import load, pin, save
from compound_v1 import polarity
from partition_v1 import catalogue


def apply(engine,p,r):
    g,x,y=p
    h,u,v=engine.model.action(g,r)
    return h,x+u,y+v


def contexts(engine,audit,collars,signs,special,roles,omitted,minimum):
    inside=[]
    present=0
    for record in collars:
        for number,recorded in enumerate(record["collars"]):
            chosen={tuple(p):j for p,j in recorded["witness"]}
            root=chosen[CENTRE]
            frame=-1 if root==special else 1
            def owner(p,j):
                if j==special:
                    return p
                neighbors=audit.transform(p,j)
                options=[q for q in neighbors if signs[q[0]]!=frame]
                assert len(options)<=1
                for q in options:
                    core={apply(engine,q,r) for i,r in enumerate(engine.grammar.roles[special])
                          if i!=omitted}
                    if p in core:
                        return q
                return None
            ownership={p:owner(p,j) for p,j in chosen.items()}
            if ownership[CENTRE] is not None:
                present+=1
                continue
            options=[]
            for r in roles:
                q=apply(engine,CENTRE,r)
                if q not in chosen or ownership[q] is not None:
                    continue
                assert q!=CENTRE and apply(engine,q,r)==CENTRE
                other=chosen[q]
                key=min(root,other),max(root,other),r
                options.append((r,key))
            touching=len({q for p,q in ownership.items() if p!=CENTRE and q is not None})
            inside.append(dict(root=root,index=number,options=options,single=touching>=minimum,
                               adjacent_cores=touching))
    return inside,present


def uniform_rules(rows,roles):
    valid=[]
    for bits in range(1<<len(roles)):
        chosen={r for i,r in enumerate(roles) if bits&(1<<i)}
        if all((count:=sum(r in chosen for r,_ in row["options"]))<=1 and (count or row["single"])
               for row in rows):
            valid.append(sorted(chosen))
    return sorted(valid,key=lambda r:(len(r),r))


def typed_rule(rows,limit):
    all_domains=[{key for _,key in row["options"]} for row in rows]
    required=[d for row,d in zip(rows,all_domains,strict=True) if not row["single"]]
    conflicts=defaultdict(set)
    for domain in all_domains:
        for key in domain:
            conflicts[key].update(domain-{key})
    started=time.perf_counter()
    visits=0
    witness=None
    def visit(chosen,excluded):
        nonlocal visits,witness
        if visits>=limit["visits"] or time.perf_counter()-started>=limit["seconds"]:
            return "BOUNDED"
        visits+=1
        open_sets=[d-excluded for d in required if not d&chosen]
        if not open_sets:
            witness=sorted(chosen)
            return "WITNESS"
        options=min(open_sets,key=lambda d:(len(d),sorted(d)))
        for key in sorted(options):
            status=visit(chosen|{key},excluded|conflicts[key])
            if status!="EXHAUSTED":
                return status
        return "EXHAUSTED"
    status=visit(set(),set())
    return dict(status=status,visits=visits,witness=witness)


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==h for n,h in protocol["pins"].items())
    engine,_=prepare()
    signs,special,_=polarity(engine)
    roles,exact=catalogue(engine,signs)
    assert not exact and len(roles)==11
    audit=Audit(engine)
    closure=load("input/closure-results-v1.json")
    assert sum(len(r["collars"]) for r in closure["collars"])==66
    results=[]
    summaries=[]
    for omitted in range(4):
        rows,owned=contexts(engine,audit,closure["collars"],signs,special,sorted(roles),omitted,protocol["minimum"])
        uniform=uniform_rules(rows,sorted(roles))
        typed=typed_rule(rows,protocol["limits"])
        if typed["witness"] is not None:
            witness=set(typed["witness"])
            assert all((hits:=sum(key in witness for _,key in row["options"]))<=1 and (hits or row["single"])
                       for row in rows)
        result=dict(omitted=omitted+1,owned_contexts=owned,unowned=len(rows),
                    uniform_rules=len(uniform),minimal_uniform=len(uniform[0]) if uniform else None,
                    typed_status=typed["status"],typed_pairs=len(typed["witness"]) if typed["witness"] else None,
                    options=dict(Counter(len(r["options"]) for r in rows)))
        results.append(dict(contexts=rows,uniform=uniform,typed=typed,summary=result))
        summaries.append(result)
        print(json.dumps(result,sort_keys=True),flush=True)
    save("data/results-v1.json",results)
    report=dict(status="CHECKED_LOCAL_MACRO_PARTITION_RULES",collars=66,configurations=summaries,
                scope="A verified rule uses at most one reciprocal pair on each unowned ordinary tile and permits a single only at the declared distinct-core count. The 66 exact collars include every local configuration of a plane tiling with the necessary inventory. This gives a first macro partition conditional on a plane tiling, with no recursive substitution claim.")
    save("data/summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
