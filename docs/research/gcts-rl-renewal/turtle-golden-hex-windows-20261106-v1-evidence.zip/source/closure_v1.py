"""Independent proof replay for depth exclusions and finite receptor closure."""

from collections import Counter, defaultdict
from functools import lru_cache
import json
from pathlib import Path
import random
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from actions_v1 import CENTRE, Policy, prepare
from cluster_v1 import load, pin, save
from compound_v1 import polarity


class Audit:
    def __init__(self,engine):
        self.engine=engine
        self.model=engine.model
        self.inventory=engine.grammar.inventory
        self.projections=engine.projections

    @lru_cache(maxsize=6000)
    def transform(self,p,j):
        g,x,y=p
        m=self.model.groups[g]
        return {(self.model.compose[g,h], x+m[0][0]*u+m[0][1]*v, y+m[1][0]*u+m[1][1]*v):(h,u,v)
                for h,u,v in self.inventory[j] if (h,u,v)!=CENTRE}

    @lru_cache(maxsize=4096)
    def support(self,p):
        g,x,y=p
        s=self.model.scale
        return frozenset((u+s*x,v+s*y) for u,v in self.model.atoms[g])

    def legal(self,anchor,assignment,patch,occupied,active):
        candidates=set(active)
        for p,j in assignment.items():
            role=self.transform(p,j).get(anchor)
            if role is not None:
                candidates &= self.projections[j,role]
        for j in sorted(candidates):
            roles=self.transform(anchor,j)
            if any(p in assignment and assignment[p] not in self.projections[j,role]
                   for p,role in roles.items()):
                continue
            add=roles.keys()-patch
            samples=set().union(*(self.support(t) for t in add))
            assert len(samples)==240*len(add)
            if occupied.isdisjoint(samples):
                yield j,add,samples

    def demanded(self,assignment,depth):
        seen={CENTRE}
        front={CENTRE}
        for _ in range(depth):
            front=set().union(*(self.transform(p,assignment[p]) for p in front if p in assignment))-seen
            seen |= front
        return seen-assignment.keys()

    def verify(self,root,depth,raw,active):
        assert raw["status"]=="NEGATIVE" and root in active
        count=0

        def visit(node,assignment,patch,occupied):
            nonlocal count
            count+=1
            p=tuple(node["anchor"])
            assert node["status"]=="NEGATIVE" and p in self.demanded(assignment,depth)
            children=dict(node["children"])
            domain={j:(pieces,samples) for j,pieces,samples in self.legal(p,assignment,patch,occupied,active)}
            assert set(domain)==set(children) and len(children)==len(node["children"])
            for j,(pieces,samples) in domain.items():
                visit(children[j],{**assignment,p:j},patch|pieces,occupied|samples)
        patch=set(self.inventory[root])
        occupied=set().union(*(self.support(p) for p in patch))
        assert len(occupied)==240*len(patch)
        visit(raw["tree"],{CENTRE:root},patch,occupied)
        assert count==raw["visits"]
        return dict(status="VERIFIED",nodes=count)

    def all_collars(self,root,active,limit):
        begun=time.perf_counter()
        count=0
        positive=[]

        def visit(assignment,patch,occupied):
            nonlocal count
            if count>=limit["visits"] or time.perf_counter()-begun>=limit["seconds"]:
                return False
            count+=1
            demanded=self.demanded(assignment,1)
            if not demanded:
                positive.append(sorted(assignment.items()))
                return True
            p,domain=min(((p,list(self.legal(p,assignment,patch,occupied,active))) for p in sorted(demanded)),
                         key=lambda t:len(t[1]))
            for j,pieces,samples in domain:
                if not visit({**assignment,p:j},patch|pieces,occupied|samples):
                    return False
            return True
        patch=set(self.inventory[root])
        occupied=set().union(*(self.support(p) for p in patch))
        complete=visit({CENTRE:root},patch,occupied)
        assert len(positive)==len({tuple(p) for p in positive})
        return dict(status="EXHAUSTED" if complete else "BOUNDED",visits=count,witnesses=positive)


def macro_local(audit, assignment, frame, sign, role):
    def partner(p):
        g,x,y=p
        h,u,v=audit.model.action(g,role)
        return h,x+u,y+v

    def is_special(p):
        return sign[p[0]]!=frame

    root_neighbors = set(audit.transform(CENTRE,assignment[CENTRE]))
    if is_special(CENTRE):
        pieces={CENTRE,partner(CENTRE)}
        assert pieces-{CENTRE}<=root_neighbors
    else:
        minority = [p for p in root_neighbors if is_special(p) and partner(p)==CENTRE]
        assert len(minority)<=1
        pieces={CENTRE,*minority}
    neighbors = set().union(*(audit.transform(p,assignment[p]) for p in pieces))-pieces
    contracted = sum(partner(p) in neighbors for p in neighbors if is_special(p))
    return dict(pieces=sorted(pieces),primitive_neighbors=sorted(neighbors),
                internal_pairs=contracted,degree=len(neighbors)-contracted)


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    engine,kinds=prepare()
    audit=Audit(engine)
    signs,special,_=polarity(engine)
    active=set(kinds)
    initial=[]
    deep=load("input/deep-results-v1.json")
    for row in deep:
        if row["raw"]["status"]=="NEGATIVE":
            checked=audit.verify(row["root"],row["depth"],row["raw"],active)
            initial.append(dict(root=row["root"],depth=row["depth"],mode=row["mode"],checked=checked))
    eliminated={r["root"] for r in initial}
    assert len(initial)==18 and len(eliminated)==5 and special not in eliminated
    active-=eliminated
    rounds=[]
    policy=Policy()
    while True:
        engine.kinds=active.copy()
        remove=set()
        records=[]
        for i in sorted(active):
            raw,_=engine.run(i,protocol["depth"],protocol["limits"],policy,"HEURISTIC",random.Random(i))
            if raw["status"]=="POSITIVE":
                checked=engine.verify_positive(i,protocol["depth"],raw["witness"])
            elif raw["status"]=="NEGATIVE":
                checked=audit.verify(i,protocol["depth"],raw,active)
                remove.add(i)
            else:
                checked=dict(status="BOUNDED")
            records.append(dict(root=i,raw=raw,checked=checked))
        rounds.append(dict(active=sorted(active),removed=sorted(remove),records=records))
        print(json.dumps(dict(round=len(rounds),retained=len(active)-len(remove),
                              statuses=dict(Counter(r["raw"]["status"] for r in records)))),flush=True)
        if not remove:
            break
        active-=remove
        assert active
    collars=[]
    counts=[Counter() for _ in range(4)]
    total=0
    for i in sorted(active):
        res=audit.all_collars(i,active,protocol["collar_limits"])
        assert res["status"]=="EXHAUSTED"
        frame=-1 if i==special else 1
        notes=[]
        for witness in res["witnesses"]:
            assignment=dict(witness)
            assert all(signs[p[0]]*(-1 if j==special else 1)==frame for p,j in witness)
            result=[macro_local(audit,assignment,frame,signs,role) for role in engine.grammar.roles[special]]
            for counter,entry in zip(counts,result,strict=True):
                counter[entry["degree"]]+=1
            notes.append(dict(witness=witness,compounds=result))
        total+=len(notes)
        collars.append(dict(root=i,visits=res["visits"],collars=notes))
    save("data/results-v1.json",dict(deep_replays=initial,rounds=rounds,collars=collars))
    summary=dict(status="CHECKED_DEEP_SHELL_AND_COMPOUND_CLOSURE",deep_replays=len(initial),
                 deep_replay_nodes=sum(r["checked"]["nodes"] for r in initial),
                 first_eliminated=sorted(eliminated),retained=sorted(active),
                 rounds=[dict(active=len(r["active"]),removed=r["removed"],
                              outcomes=dict(Counter(x["raw"]["status"] for x in r["records"]))) for r in rounds],
                 complete_local_collars=total,exact_degree_distributions=[dict(c) for c in counts],
                 scope="Every eliminated kind has a checked finite obstruction under a necessary shell inventory. All compatible one-layer collar assignments of the retained inventory are exhausted. Exact degree counts constrain any plane tiling but do not establish its existence or any substitution.")
    save("data/summary-v1.json",summary)
    print(json.dumps(summary,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
