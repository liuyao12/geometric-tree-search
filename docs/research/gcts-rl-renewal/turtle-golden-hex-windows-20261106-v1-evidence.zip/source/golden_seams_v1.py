"""Learn finite Turtle seam labels and predict complete held-out boundaries."""

from collections import Counter
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model,load,mat,pin,save
from golden_geometry_v1 import add,perimeter,strip,sub,transform,unit_segments,words
from golden_growth_v1 import axial


def move_edge(edge,matrix,shift):
    return tuple(sorted(add(mat(matrix,p),shift) for p in edge))


def receptors(model,kind,n,sequence):
    h=sequence[2*n+1][:-2]
    if kind=="T":
        start=(2*len(h)-3,2)
        return [("T",h,model.compose[g,6],mat(model.groups[g],start)) for g in (0,3,4)]
    L,K=len(sequence[2*n]),len(sequence[2*n-2])
    U,V=5*L-2*K-7,3*L-3
    d="01"+sequence[2*n][:-2]+"10"
    a,b=-3*L+2*K+2,3*L-K-1
    return [("H",h,0,axial(-U,-V)),("H",h,6,axial(U,V)),("D",d,3,(a,b)),("D",d,9,(-a,-b))]


def contract_parts(model,word):
    context="^"+word+"$"
    for i,tile in enumerate(strip(word)):
        yield context[i:i+3],(4*i,-2*i),perimeter(model,(tile,))


def learn(model,bank,training,sequence):
    labels={}
    for n in training:
        for kind in ("T","P"):
            actual=bank[kind,n]
            recovered=set()
            for role,word,g,shift in receptors(model,kind,n,sequence):
                matrix=model.groups[g]
                outside=perimeter(model,strip(word))
                contact={e for e in outside if move_edge(e,matrix,shift) in actual}
                for context,offset,edges in contract_parts(model,word):
                    selected=frozenset(tuple(sub(p,offset) for p in e) for e in edges&contact)
                    key=role,context
                    if key in labels:
                        assert labels[key]==selected
                    labels[key]=selected
                recovered.update(move_edge(e,matrix,shift) for e in contact)
            assert recovered==actual
    return labels


def predict(model,kind,n,sequence,labels,mutate=False):
    generated=[]
    for j,(role,word,g,shift) in enumerate(receptors(model,kind,n,sequence)):
        if mutate and j==0:
            shift=add(shift,(0,1))
        matrix=model.groups[g]
        context="^"+word+"$"
        e=set()
        for i in range(len(word)):
            offset=(4*i,-2*i)
            for edge in labels[role,context[i:i+3]]:
                e.add(move_edge(tuple(add(p,offset) for p in edge),matrix,shift))
        generated.append(e)
    return generated


def main():
    p=load("seam-protocol-v1.json")
    assert p["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/name)==value for name,value in p["pins"].items())
    model=Model(load("input/exact-point-model-v1.json"))
    growth=load("data/growth-v1.json")
    patches={r["id"]:tuple(map(tuple,r["patch"])) for r in growth["levels"]}
    geometry={}
    for case in growth["levels"]:
        kind,n=case["id"][0],int(case["id"][1:])
        ring=tuple(map(tuple,case["ring"]))
        geometry[kind,n]=set(unit_segments((*ring,ring[0])))
    sequence=words(2*max(p["test"])+1)
    labels=learn(model,geometry,p["train"],sequence)
    assert len(labels)==18
    outputs=[]
    for n in p["train"]+p["test"]:
        for kind in ("T","P"):
            actual=geometry[kind,n]
            masks=predict(model,kind,n,sequence,labels)
            union=set().union(*masks)
            assert union==actual
            control=set().union(*predict(model,kind,n,sequence,labels,mutate=True))
            errors=len(control^actual)
            assert errors
            row=dict(kind=kind,level=n,edges=len(actual),labels=len(labels),components=list(map(len,masks)),
                     shared=sum(map(len,masks))-len(union),mutated_difference=errors,
                     phase="FIT" if n in p["train"] else "TEST")
            outputs.append(row)
            print(json.dumps(row,sort_keys=True),flush=True)
    assert set(transform(model,patches["T1"],6))<set(patches["T3"])
    assert set(transform(model,patches["T3"],6))<set(patches["T5"])
    save("data/seams-v1.json",dict(status="CHECKED_EXACT_WORD_BOUNDARIES",cases=outputs,
          labels=[dict(role=k[0],context=k[1],edges=sorted(v)) for k,v in sorted(labels.items())],
          nesting=["T1","rotated T3","T5"]))


if __name__=="__main__":
    main()
