"""Generate matching graphs on growing finite regions of the infinite phase model."""

from collections import Counter, defaultdict
from fractions import Fraction
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from mechanical_v1 import ALPHA, Q
from phase_owner_v1 import OwnerGeometry
from rhombille_v1 import Bridge, load, pin, prepare, save


def length(v):
    return max(map(abs,v))


def shape_sites(n, layer):
    for i in range(-n,n+1):
        for j in range(-n,n+1):
            k=layer-i-j
            if abs(k)<=n:
                yield i,j,k


def words(n, offsets):
    return [{i:(ALPHA*i+Q(a)).floor() for i in range(-n-7,n+8)} for a in offsets]


def graph(geometry, n, offsets):
    floors = words(n,offsets)
    radius = 3
    base=(0,0,-2)
    vertices=set()
    incident=defaultdict(set)
    edges={}
    for site in shape_sites(n,-2):
        shift=tuple(x-y for x,y in zip(site,base,strict=True))
        pattern=tuple(tuple(floor[k+i+1]-floor[k+i] for i in range(-radius,radius+1))
                      for k,floor in zip(site,floors,strict=True))
        band=-sum(floor[k] for k,floor in zip(site,floors,strict=True))
        state,_=geometry.context(base,pattern,radius,band)
        _,kind,_=state
        for rid in geometry.at_cube[base]:
            if kind(rid)!="red":
                continue
            ends=tuple(tuple(x+y for x,y in zip(p,shift,strict=True))
                       for p in geometry.red_choices(rid,state))
            assert len(ends)==2 and ends[0]!=ends[1]
            key=(*site, geometry.endpoints[rid][0])
            edges[key]=ends
            for p in ends:
                incident[p].add(key)
                vertices.add(p)
    for layer in (-2,-1):
        for p in shape_sites(n,layer):
            digits=[f[k+1]-f[k] for k,f in zip(p,floors,strict=True)]
            band=-sum(f[k] for k,f in zip(p,floors,strict=True))
            if digits==[1,1,1] or digits==[0,0,0] and (layer,band) in {(-2,2),(-1,1)}:
                vertices.add(p)
    return vertices,edges,incident


def component_audit(vertices,edges,incident,radius):
    closed, open_count = Counter(), Counter()
    components=[]
    seen=set()
    for v in sorted(vertices):
        if v in seen:
            continue
        visited=[v]
        seen.add(v)
        used=set()
        for p in visited:
            for e in sorted(incident[p]):
                used.add(e)
                for q in edges[e]:
                    if q not in seen:
                        seen.add(q)
                        visited.append(q)
        whole=all(length(p)<=radius-3 for p in visited)
        counts=closed if whole else open_count
        excess=len(used)-len(visited)
        counts[excess] += 1
        if excess>0 or whole and excess!=0:
            components.append(dict(whole=whole,hexes=sorted(visited),red_edges=sorted(used)))
    return dict(closed=dict(closed),open=dict(open_count),counterexamples=components)


def main():
    protocol=load("matching-graph-protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    offsets=list(map(Fraction,protocol["intercepts"]))
    assert sum(offsets)==0 and all(v.denominator>1 for v in offsets)
    engine,_=prepare()
    geometry=OwnerGeometry(Bridge(engine))
    rows=[]
    for radius in protocol["radii"]:
        vertices,edges,incident=graph(geometry,radius,offsets)
        audit=component_audit(vertices,edges,incident,radius)
        summary=dict(radius=radius,hexes=len(vertices),red_edges=len(edges),closed=audit["closed"],
                     open=audit["open"],counterexamples=len(audit["counterexamples"]))
        print(json.dumps(summary,sort_keys=True),flush=True)
        rows.append(dict(summary=summary,audit=audit))
        if audit["counterexamples"]:
            # Keep the complete bounded graph for independent replay.
            rows[-1].update(vertices=sorted(vertices),edges=sorted(edges.items()))
            break
    save("data/matching-graph-v1.json",dict(status="CHECKED_FINITE_RED_MATCHING_GRAPHS",rows=rows))


if __name__=="__main__":
    main()
