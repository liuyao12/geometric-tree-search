const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 900 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/turtle-golden-hex-windows-20261106-v1.html")).href;
    const result = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(result.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length === 35);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("svg").count(), 8);
    assert.equal(await page.locator("#recovery .focus polygon.tile").count(), 594);
    assert.equal(await page.locator("#seams path.seam").count(), 7);
    assert.equal(await page.locator("#windows .window").count(), 3);
    const counts = await page.locator("#windows figure").evaluateAll(nodes => nodes.map(n => n.querySelectorAll(".tile").length));
    assert.deepEqual(counts, [51, 36, 35]);
    await page.locator("#seams summary").click();
    assert.equal(await page.locator("#seams tbody tr:visible").count(), 18);
    assert.deepEqual(errors, []);
    if (!process.argv[2]) {
      await page.locator("#recovery .focus").screenshot({ path: path.join(__dirname, "assembly-v1.png") });
      await page.locator("#windows .gallery").screenshot({ path: path.join(__dirname, "windows-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    const receipt = { status: "CHECKED_GOLDEN_HEX_READER", formulas: 35, figures: 8,
      assemblyTiles: 594, windowTiles: counts, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(e => { console.error(e); process.exitCode = 1; });
