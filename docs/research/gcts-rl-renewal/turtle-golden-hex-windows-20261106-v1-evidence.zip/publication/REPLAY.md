# Reproduce the Golden Hex recovery

Use the interpreter pinned in the four protocols. The scientific replay
needs only the Python standard library. In a fresh extracted copy move the
supplied data directory aside and create a new one.

    mv data archived-data
    mkdir data
    "$GCTS_PYTHON" -I -S -B source/golden_recovery_v1.py
    "$GCTS_PYTHON" -I -S -B source/golden_growth_v1.py
    "$GCTS_PYTHON" -I -S -B source/golden_seams_v1.py
    "$GCTS_PYTHON" -I -S -B source/golden_windows_v1.py

The first three scientific outputs reproduced byte for byte. The window
output agrees after excluding per-query wall time. The coverage
checker uses the exact lattice cell arrangement independently of the
recursive pruning.

The snapped vector data adapts Figures 2 and 4 of Shigeki Akiyama and
Yoshiaki Araki, *An Alternative Proof for an Aperiodic Monotile*,
Discrete & Computational Geometry 74, 771–792 (2025).
The source is licensed under CC BY 4.0. We isolated paths and rounded
their vertices to axial lattice coordinates. The extraction source records
the crop bounds and tolerance.

https://doi.org/10.1007/s00454-025-00717-6

https://creativecommons.org/licenses/by/4.0/

The independent Rhombille audit inputs are historical receipts from the
separate matching-graph run. They do not enter the Golden Hex growth
or window checks.
