"""Render the exact Golden Hex recovery and lazy window certificates."""

from html import escape
import json
from math import sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model,load
from golden_geometry_v1 import words
from golden_seams_v1 import predict

STEM="turtle-golden-hex-windows-20261106-v1"
SOURCE="https://doi.org/10.1007/s00454-025-00717-6"


def math(s):
    return r"\("+escape(s)+r"\)"


def notation(kind,n):
    return math((r"\Pi" if kind=="P" else "T")+"_{"+str(n)+"}")


def table(headers,rows):
    th="".join(f'<th scope="col">{escape(h)}</th>' for h in headers)
    tr="".join("<tr>"+"".join(f"<td>{value}</td>" for value in row)+"</tr>" for row in rows)
    return f'<div class="scroll"><table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table></div>'


def plot(model,label,patch=(),*,boundary=(),regions=(),seams=(),outline=(),height=385):
    colors=("#9bbfae","#b4a6cc","#de9b62","#88b7d7","#b9c77f")
    zones={tuple(t):i for i,group in enumerate(regions) for t in group}
    data=[(tuple(t),model.poly(t)) for t in map(tuple,patch)]
    points={p for _,ring in data for p in ring}|set(outline)|set(boundary)
    points.update(p for group in seams for e in group for p in e)
    plane={p:(p[0]*sqrt(3)/2,p[0]/2+p[1]) for p in points}
    x0=min(x for x,_ in plane.values())
    x1=max(x for x,_ in plane.values())
    y0=min(y for _,y in plane.values())
    y1=max(y for _,y in plane.values())
    scale=min(565/(x1-x0),(height-34)/(y1-y0))

    def point(p):
        x,y=plane[p]
        return 300+scale*(x-(x0+x1)/2),height/2+scale*(y-(y0+y1)/2)

    def coordinates(vertices):
        return " ".join(f"{x:.2f},{y:.2f}" for x,y in map(point,vertices))

    pieces=[]
    for tile,ring in data:
        fill=colors[zones[tile]%len(colors)] if tile in zones else colors[1 if tile[0]>=6 else 0]
        pieces.append(f'<polygon class="tile" points="{coordinates(ring)}" fill="{fill}"></polygon>')
    if outline:
        pieces.append(f'<polygon class="silhouette" points="{coordinates(outline)}"></polygon>')
    for j,edge_set in enumerate(seams):
        path=[]
        for a,b in sorted(edge_set):
            x,y=point(a)
            u,v=point(b)
            path.append(f"M{x:.2f},{y:.2f}L{u:.2f},{v:.2f}")
        pieces.append(f'<path class="seam" stroke="{colors[j%len(colors)]}" d="{"".join(path)}"></path>')
    if boundary:
        pieces.append(f'<polygon class="window" points="{coordinates(boundary)}"></polygon>')
    return (f'<svg viewBox="0 0 600 {height}" role="img" aria-label="{escape(label)}">'
            f'<title>{escape(label)}</title>{"".join(pieces)}</svg>')


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    recovery=load("data/recovery-v1.json")
    growth=load("data/growth-v1.json")
    seams=load("data/seams-v1.json")
    windows=load("data/windows-v1.json")
    replay=load("publication/replays-v1.json")
    originals={r["name"]:r for r in recovery["levels"]}
    three=originals["T3"]
    zones=[[t for child in three["children"] if child["label"]==label for t in child["patch"]]
           for label in ("T2","P2","T1")]
    tri=plot(model,"Level three triangle colored by the child cluster",three["patch"],regions=zones,height=555)
    bases=[]
    for key in ("P0","T1"):
        row=originals[key]
        bases.append(f'<figure>{plot(model,key+" recovered from its outline",row["patch"],height=255)}'
                     f'<figcaption>{notation(key[0],int(key[1]))} · {len(row["patch"])} Turtles · '
                     f'{row["pose_candidates"]} candidate placements inside the outline.</figcaption></figure>')
    label_table={(r["role"],r["context"]):tuple(tuple(map(tuple,e)) for e in r["edges"]) for r in seams["labels"]}
    alphabet=words(11)
    borders=[]
    for kind in ("T","P"):
        layers=predict(model,kind,3,alphabet,label_table)
        borders.append(f'<figure>{plot(model,"Learned word masks on "+kind+"3",seams=layers,height=320)}'
                       f'<figcaption>{notation(kind,3)} · Each color traces a side receptor.</figcaption></figure>')
    window_views=[]
    for row in windows["windows"][2:]:
        xmin,xmax,ymin,ymax=row["window"]
        box=((xmin,ymin),(xmax,ymin),(xmax,ymax),(xmin,ymax))
        name=notation(row["kind"],row["level"])
        label=f'{row["window_tiles"]} Turtles cover the requested window'
        window_views.append(f'<figure>{plot(model,label,row["poses"],boundary=box,height=330)}'
                            f'<figcaption>{name} · {escape(label)}. Dashed outline is the request.</figcaption></figure>')
    growth_table=table(("Patch","Tiles","Boundary edges","Certified disk radius","Stage"),
        [(notation(r["kind"],r["level"]),f'{r["size"]:,}',f'{r["boundary_edges"]:,}',r["disk_radius"],
          "Reference" if r["level"]<=3 else "Checked extrapolation") for r in windows["sizes"]])
    query_table=table(("Patch","Tiles emitted","Clusters tested","Leaf boxes tested","Query ms"),
        [(notation(r["kind"],r["level"]),r["window_tiles"],r["counts"]["checked_clusters"],
          r["counts"]["checked_leaf_boxes"],f'{1000*r["seconds"]:.1f}') for r in windows["windows"]])
    box=load("input/component-box-v1.json")["runs"][-1]
    average=load("input/attachment-average-v1.json")["runs"][-1]["summary"]
    summary=dict(status="CHECKED_TURTLE_GOLDEN_HEX",shapes=windows["sizes"],
                 windows=[{k:v for k,v in row.items() if k!="poses"} for row in windows["windows"]],
                 seam_labels=len(seams["labels"]),recovery=[{k:v for k,v in row.items() if k not in ("patch","children")}
                      for row in recovery["levels"]],reference=SOURCE,clean_replay=replay,
                 rhombille=dict(coordinate_extent=box["extent"],phase_cells=sum(box["phase_cells"].values()),
                     periodic_local_window=average["radius"]))
    (ROOT/"report"/(STEM+"-results.json")).write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n")
    page=rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Recovering the Golden Hex Turtle rule and tiling windows</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
body{{margin:0;background:#f8f7f1;color:#223830;font:1rem/1.55 system-ui,sans-serif}}
main{{max-width:1060px;margin:auto;padding:1rem clamp(1rem,4vw,2.75rem) 3rem}}
h1{{font-size:clamp(2rem,5vw,3.2rem);line-height:1.12;margin:.5rem 0}}h2{{margin-top:2.5rem}}
a{{color:#21604f}}nav{{display:flex;gap:.6rem 1.1rem;flex-wrap:wrap}}
.eyebrow{{font-size:.8rem;font-weight:750;letter-spacing:.08em;text-transform:uppercase}}header{{padding:1.35rem 0}}
.gallery{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,245px),1fr));gap:1rem}}
figure{{margin:0}}figcaption{{color:#355448;font-size:.93rem}}
svg{{width:100%;display:block;border:1px solid #ccdbd1;border-radius:.55rem;background:#fcfdfa}}
.tile{{stroke:#33483f;stroke-width:.65}}.seam{{fill:none;stroke-width:2.1}}
.silhouette{{fill:#d8e6dc;stroke:#33483f;stroke-width:1.4}}.window{{fill:none;stroke:#172e27;stroke-width:2;stroke-dasharray:6 4}}
.scroll{{overflow:auto}}table{{width:100%;border-collapse:collapse}}td,th{{text-align:left;padding:.45rem .55rem;border-bottom:1px solid #cedcd2}}
th{{background:#e5eee5}}.focus{{max-width:650px;margin:auto}}
</style></head><body><main>
<header><p class="eyebrow">GCTS research notebook · November 2026</p>
<h1>Recovering the Golden Hex Turtle rule and tiling windows</h1>
<p>Exact unmarked Turtle search recovered two base clusters from their outlines. The recovered placements reproduce the published reference through level three. The same rule generated and checked larger finite patches through level nine, then filled small windows by expanding only the relevant branches.</p>
<nav aria-label="On this page"><a href="#recovery">Recover the clusters</a><a href="#seams">Learn the seams</a><a href="#windows">Inspect the windows</a><a href="#scope">Plane proof</a><a href="#evidence">Evidence</a></nav></header>
<section id="recovery"><h2>Recover the smallest clusters from unmarked tiles</h2>
<div class="gallery">{''.join(bases)}</div>
<p>The only geometric input for these two searches was the closed outline snapped to the \(A_2\) lattice. Each outline had one exact filling after all contained Turtle placements were enumerated. Akiyama and Araki’s Figure 2 supplied the outlines and child counts for the later reference tests. <a href="{SOURCE}">Golden Hex construction, Section 3</a></p>
<figure class="focus">{tri}<figcaption>The reconstructed \(T_3\). Green marks three triangular children, lavender marks three parallelogram children, and amber marks the six-Turtle center recovered by solving the enclosed gap.</figcaption></figure>
<p>Rigid matching against partial tile outlines and exact nonoverlap recovered the seven reference patches. The level-three parallelogram had 723 visible tile contours and a checked 834-tile reconstruction. The upper-level assembly uses the published child multiplicities. Its lattice translations were inferred from the recovered placements.</p>
</section>
<section id="seams"><h2>Give each cluster a word boundary</h2>
<div class="gallery">{''.join(borders)}</div>
<p>A seam strip places its \(i\)-th Turtle at \((4i,-2i)\) in axial coordinates, with a fixed orientation and offset for each letter. The central words come from the Sturmian slope \(\alpha=(5-\sqrt{{5}})/10\). The fitted edge labels depend on the current letter and its two neighbors, with special symbols at the ends. <a href="{SOURCE}">Sturmian words and seam construction</a></p>
<p>Eighteen labels learned on levels one through three predicted every edge of both cluster families at levels four and five. They also agreed with the independent signed boundary sums through level nine. A one-unit shift of a side failed in every test.</p>
<p>Each child’s oriented boundary contributes its winding number. Exact cancellation removes shared edges. If the remaining ring is simple and positively oriented, its winding is one in the interior and zero outside. The child interiors therefore have disjoint coverage of that ring. This check uses the child boundaries and counts at every stage.</p>
<details><summary>Show exact patch sizes and contained disks</summary>{growth_table}</details></section>
<section id="windows"><h2>Expand only the clusters that reach a requested window</h2>
<div class="gallery">{''.join(window_views)}</div>
<p>Each dashed parallelogram is a fixed coverage request. Turtles may extend across its edges. The search descends through the cluster inventory, prunes disjoint bounding boxes, and tests exact polygon intersections at the leaves. An independent arrangement-of-cells check verifies each window. Two level-four controls also agree with enumeration of every tile in the parent.</p>
{query_table}
<p>The largest certified parent contains 84,859,170 Turtles, represented by its recipes and a boundary of 168,744 edges. Its window query emitted 35 tiles. Query time excludes library certification and the separate coverage check. The clean replay took {replay["wall_seconds"]["windows"]:.1f} seconds for the entire window phase, including library certification and all five checks.</p></section>
<section id="scope"><h2>Separate the reference theorem from the finite checks</h2>
<p>Akiyama and Araki prove that the Golden Hex construction yields arbitrarily large tiled disks. The implementation checks the inferred coordinate rule through level nine. Its three checked odd triangular levels nest after the alternating half-turn. A proof of the inferred boundary identity for all levels remains to be mechanized. <a href="{SOURCE}">Golden Hex existence theorem</a></p>
<p>The separate Rhombille matching construction has exact checks of all 48,672 phase cells for coordinate radius 48. The checked neighborhoods contain no closed component or cycle. Rational linear certificates also rule out phase-window attachment rules through radius 12, including periodic coordinate refinements. The matching graph’s global structure remains open. <a href="turtle-rhombille-matching-20261105-v1.html">Rhombille matching notebook</a></p></section>
<section id="evidence"><h2>Replay the experiments</h2>
<p><a href="{STEM}-results.json">Machine-readable results</a> · <a href="{STEM}-evidence.zip">Full reproduction archive</a> · <a href="{STEM}-manifest.json">File hashes</a></p>
<p>The archive credits the published vector data and includes the exact outlines, recovered placements, boundary rules, witness windows, and replay sources.</p>
</section></main></body></html>"""
    (ROOT/"report"/(STEM+".html")).write_text(page)


if __name__=="__main__":
    main()
