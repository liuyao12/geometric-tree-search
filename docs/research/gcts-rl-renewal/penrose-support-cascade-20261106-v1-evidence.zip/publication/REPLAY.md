# Replaying the Penrose support-cascade notebook

From the extracted archive root, run the clean replay with CPython 3.12.

```sh
python3.12 -I -S -B publication/replay_v1.py
```

The replay generates the exact support cascades and transfer cases, reruns the fixed and movable search arms and the routing bandit, reconstructs the full Wang certificate and the compact proof records, and regenerates the HTML. It compares ten outputs with the retained copies byte for byte. It uses the archived timing receipt to reproduce the HTML. The timing experiment can be repeated separately and produces machine-dependent measurements.

```sh
python3.12 -I -S -B source/cascade_timing_v1.py
```

To check just the logical certificate and the underlying Wang transitions, run the following commands from `wang`.

```sh
python3.12 -I -S -B source/logical_records_cli_v1.py verify input/cascade-v1.json data/cascade-records-v1.json
python3.12 -I -S -B source/shared_wang_v1.py verify input/cascade-v1.json data/cascade-wang-v1.json
```

The geometric proof binder separately checks the transported witnesses and the original symbolic statement for each receiver. The compact checker and full Wang checker operate on the symbolic statement. The HTML typesets its formulas with MathJax.
