const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {pathToFileURL} = require("node:url");

async function main() {
  const {chromium} = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"]});
  try {
    const page = await browser.newPage({viewport: {width: 1120, height: 900}});
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/penrose-support-cascade-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, {waitUntil: "commit"});
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForSelector("#proof mjx-container");
    assert.equal(await page.locator("#receiver option").count(), 8);
    assert.equal(await page.locator("#atom option").count(), 28);
    assert.equal(await page.locator("#proof tbody tr").count(), 131);
    assert.equal(await page.locator("#tile-view .wang-cell").count(), 45);
    await page.locator("#receiver").selectOption("7");
    await page.locator("#atom").selectOption("X28");
    assert.equal(await page.locator("#receiver-view .atom:visible").count(), 1);
    assert(await page.locator('#receiver-view [data-atom="X28"]').isVisible());
    assert.equal(await page.locator("#receiver-view .ear").count(), 1);
    await page.locator('button[data-line="1"]').click();
    assert.equal(await page.locator("#selected-line").textContent(), "Proof line 1");
    assert.equal(await page.locator("#tile-view .wang-cell").count(), 45);
    await page.locator('button[data-line="131"]').click();
    assert.equal(await page.locator("#selected-line").textContent(), "Proof line 131");
    assert.equal(await page.locator("#scope .solution").count(), 21);
    assert.equal(await page.locator("#runtime tbody tr").count(), 8);
    assert.equal(await page.locator("#routing tbody tr").count(), 5);
    assert.equal(await page.locator("#movable tbody tr").count(), 3);
    assert.equal(await page.locator("#movable figure").count(), 2);
    assert.equal(await page.locator("#tile-view .wang-cell title").count(), 45);
    await page.locator("#receptors").screenshot({path: path.join(__dirname, "receptor-view-v1.png")});
    await page.locator("#tiles").screenshot({path: path.join(__dirname, "tile-view-v1.png")});
    await page.setViewportSize({width: 390, height: 844});
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.deepEqual(errors, []);
    const result = {status: "CHECKED_CASCADE_READER", bindings: 8, rhombAtoms: 28, proofLines: 131,
      selectedWangSquares: 45, positiveControlTiles: 21, mathTypeset: true, mobileNoOverflow: true};
    fs.writeFileSync(path.join(__dirname, "browser-v1.json"), JSON.stringify(result, null, 2) + "\n");
    console.log(JSON.stringify(result));
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
