"""Replay the Penrose receptor experiment in an empty directory."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
STEM = "penrose-support-cascade-20261106-v1"
STAGES = ("source/cascade_experiment_v1.py", "source/cascade_wang_v1.py",
          "source/cascade_transfer_v1.py", "source/cascade_runtime_v1.py",
          "source/cascade_movable_v1.py", "source/route_bandit_v1.py", "publication/render_v1.py")
OUTPUTS = ("data/cascade-experiment-v1.json", "data/transfer-v1.json", "wang/input/cascade-v1.json",
           "wang/data/cascade-receipt-v1.json", "wang/data/cascade-records-v1.json",
           "wang/data/cascade-wang-v1.json", "data/cascade-runtime-v1.json",
           "data/cascade-movable-v1.json", "data/route-bandit-v1.json", f"report/{STEM}.html")


def inputs():
    sources = sorted(str(p.relative_to(ROOT)) for d in ("source", "wang/source", "publication")
                     for p in (ROOT / d).glob("*.py"))
    return (*sources, "publication/notebook-v1.html", "data/cascade-timing-v1.json")


def main():
    retained = inputs()
    hashes = {}
    with TemporaryDirectory() as temp:
        clean = Path(temp)
        for path in (*retained, *OUTPUTS):
            (clean / path).parent.mkdir(parents=True, exist_ok=True)
        for path in retained:
            shutil.copyfile(ROOT / path, clean / path)
        for path in STAGES:
            subprocess.run([sys.executable, "-I", "-S", "-B", path], cwd=clean, check=True)
        for path in OUTPUTS:
            expected, actual = (ROOT / path).read_bytes(), (clean / path).read_bytes()
            assert actual == expected, path
            hashes[path] = sha256(actual).hexdigest()
    receipt = {"status": "CHECKED_CLEAN_REPLAY", "sha256": hashes}
    (ROOT / "publication/replay-v1.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
    print("Matched", len(hashes), "outputs byte for byte.")


if __name__ == "__main__":
    main()
