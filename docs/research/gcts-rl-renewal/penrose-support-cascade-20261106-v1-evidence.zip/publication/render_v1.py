"""Render geometric bindings and exact Wang windows for the cascade proof."""
from html import escape
import json
from math import cos, pi, sin
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
sys.path.insert(0, str(ROOT / "publication"))
sys.path.append(str(ROOT / "wang/source"))
from boundary_kernel_v1 import build
from cascade_wang_v1 import frozen
from geometry_v1 import Penrose, add, sub
from model_v1 import rotate
from proof_views_v1 import clause, explanation, formula, frame_window, math, tile_svg

STEM = "penrose-support-cascade-20261106-v1"


def read(path):
    return json.loads((ROOT / path).read_text())


def project(p):
    return (sum(x * cos(2*pi*i/5) for i, x in enumerate(p)),
            -sum(x * sin(2*pi*i/5) for i, x in enumerate(p)))


def figure(g, row, root, ear, label):
    def posed(p):
        return add(rotate(p, row["turn"]), row["offset"])

    shapes = [(ring, "ring", "") for ring in row["rings"]]
    shapes.extend((g.poly(tile), "solution", "") for tile in row.get("cover", ()))
    shapes.extend((tuple(tuple(v / den for v in p) for p in poly), "core", "")
                  for den, poly in row.get("core", ()))
    if row["kind"] == "edited":
        shapes.append((g.poly(tuple(sorted(map(posed, ear)))), "ear", ""))
    shapes.extend((g.poly(tile), "atom", f' data-atom="{name}" style="display:none"')
                  for name, tile in row["atoms"].items())
    if root:
        shapes.append((tuple(map(posed, root)), "root", ""))
    drawn = [(tuple(map(project, shape)), kind, attrs) for shape, kind, attrs in shapes]
    x, y = zip(*(p for shape, _, _ in drawn for p in shape))
    dx, dy = max(x) - min(x), max(y) - min(y)
    pad = .08 * max(dx, dy)
    box = f"{min(x)-pad:.5f} {min(y)-pad:.5f} {dx+2*pad:.5f} {dy+2*pad:.5f}"
    content = []
    for shape, kind, attrs in drawn:
        points = " ".join(f"{a:.5f},{b:.5f}" for a, b in shape)
        tag = "polyline" if kind == "root" else "polygon"
        content.append(f'<{tag} points="{points}" class="{kind}"{attrs}/>')
    return (f'<figure><svg role="img" aria-label="{label}" class="frame" viewBox="{box}">'
            f'{"".join(content)}</svg><figcaption>{label}</figcaption></figure>')


def table(rows, headings=("Line", "Read", "Clause", "Proof tiles and record")):
    heads = "".join(f'<th scope="col">{name}</th>' for name in headings)
    body = "".join("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows)
    return f'<div class="table"><table><thead><tr>{heads}</tr></thead><tbody>{body}</tbody></table></div>'


LABELS = {"donor-edits": "Donor-family edits", "new-family-1": "Other outline family A",
          "new-family-3": "Other outline family B", "known-covers": "Known-cover controls"}


def runtime_tables(runtime, timing):
    totals = runtime["totals"]
    rows = []
    for name, label in LABELS.items():
        arms = totals[name]
        base = arms["baseline"]
        scan, indexed, adapt, fresh = (arms[key] for key in ("scan", "indexed", "adaptive", "depth-two"))
        rows.append((label, base["requests"], base.get("positive", 0),
                     f'{scan.get("anchors",0):,} / {indexed.get("anchors",0):,}',
                     indexed["cuts"], adapt["cuts"], fresh["cuts"]))
    comparison = table(rows, ("Cohort", "Requests", "Verified covers", "Scan / indexed anchors",
                              "Indexed cuts", "Adaptive cuts", "Fresh propagation cuts"))
    rows = []
    for name, label in LABELS.items():
        arms = timing["runtime"][name]
        values = tuple(f'{median(r["runtime_ns"] for r in arms[key])/1e6:,.1f}'
                       for key in ("baseline", "scan", "indexed", "adaptive", "depth-two"))
        rows.append((label, *values))
    measures = table(rows, ("Eight requests", "Unmarked", "Scan", "Indexed", "Adaptive", "Fresh propagation"))
    admission = median(timing["admission_ns"])/1e6
    sample = set(timing["sampled"])
    hits = sum(r["id"] in sample and r["family"] == "donor-edits" and
               r["arms"]["adaptive"]["origin"] == "reused" for r in runtime["results"])
    replay = median(r.get("independent_replay_ns",0) for r in timing["runtime"]["donor-edits"]["adaptive"])/1e6
    caption = ("<h3>Timing pilot</h3><p>Median batch time in milliseconds across three repeats. "
               "Each batch used the eight smallest shape hashes in its cohort and started each request with "
               "cold geometry caches. It includes exact positive verification and the placement fallback. "
               "The theorem was already admitted. The adaptive arm reused it on "
               f"{hits} of the eight sampled donor-family requests. Its additional independent replay "
               f"took a median of {replay:.1f} milliseconds across that batch. One compact admission took "
               f"a median of {admission:.1f} milliseconds.</p>")
    return comparison, caption + measures


def movable_views(g, data, root):
    rows = []
    for row in data["cases"]:
        a, b = (row["outcomes"][name] for name in ("area", "proof"))
        rows.append((row["case"].capitalize(), a["status"], a["counts"]["nodes"],
                     b["status"], b["counts"]["nodes"]))
    optional = data["optional"]
    rows.append(("Optional pocket", "—", "—", optional["outcome"]["status"],
                 optional["outcome"]["counts"]["nodes"]))
    results = table(rows, ("Movable query", "Area arm", "Visits", "Wang theorem arm", "Visits"))
    left = data["cases"][0]
    turn, anchor = left["event"]["binding"]
    offset = sub(anchor, rotate(root[0], turn))
    required = figure(g, dict(kind="movable", turn=turn, offset=offset, rings=(left["cycle"],),
        core=left["core"], cover=left["frame"], atoms={}), root, None,
        "The core surrounds the entire sealed pocket")
    open_view = figure(g, dict(kind="movable", turn=0, offset=g.zero, rings=(optional["cycle"],),
        core=optional["core"], cover=optional["outcome"]["patch"], atoms={}), None, None,
        "The optional pocket stays empty in the checked cover")
    return results + f'<div class="grid">{required}{open_view}</div>'


def routing_table(data):
    work_names = ("placement", "fresh", "new_exterior", "centers")
    methods = ("plain", "renew", "propagate", "learned")

    def summary(totals):
        return tuple(f'{sum(totals[k].get(w,0) for w in work_names):,} / {totals[k].get("bounded",0)}'
                     for k in methods)

    shape = data["reports"][:3]
    combined = {k: {w: sum(r["totals"][k].get(w,0) for r in shape) for w in (*work_names, "bounded")}
                for k in methods}
    rows = [("Three shape folds", *summary(combined))]
    rows.extend((LABELS[r["name"]], *summary(r["totals"])) for r in data["reports"][3:])
    return table(rows, ("Held-out cohort", "Plain work / bounded", "Renew work / bounded",
                        "Fresh propagation work / bounded", "Learned work / bounded"))


def main():
    g = Penrose()
    study = read("data/cascade-experiment-v1.json")
    specimen = min(study["examples"], key=lambda row: len(row["proof"]["nodes"]))
    root = frozen(specimen["proof"]["root"])
    transfers = frozen(read("data/transfer-v1.json"))
    receivers, frames = [], []
    for i, row in enumerate(transfers["cases"]):
        label = f'{"Edited boundary" if row["kind"]=="edited" else "Original shape"}, pose {i // 2 + 1}'
        receivers.append(f'<option value="{i}">{label}</option>')
        rendered = figure(g, row, root, transfers["ear"], label)
        frames.append(f'<template id="receiver-{i}">{rendered}</template>')
    atoms = "".join(f'<option value="{name}">{name}</option>' for name in transfers["cases"][0]["atoms"])

    source = read("wang/input/cascade-v1.json")
    bundle = read("wang/data/cascade-wang-v1.json")
    rows, windows, palette = [], [], {}
    machine = build().compile()
    assert machine.digest() == bundle["machine_sha256"]
    for i, (line, call) in enumerate(zip(bundle["proof"]["lines"], bundle["calls"], strict=True), 1):
        trace = bundle["traces"][call["fragment"]]
        frame = dict(prefix=trace["prefix"], word=trace["word"], padding=0, trace=trace["fragment"])
        time = trace["steps"] - 5
        active, start = frame_window(machine, frame, time, trace["head"])
        values = [palette.setdefault(t, len(palette)) for r in active for t in r]
        caption = f"Actual Wang rows {time+1:,}–{time+5:,}, columns {start:,}–{start+8:,}."
        windows.append((values, caption))
        record = escape(trace["prefix"] + "\n" + trace["word"])
        detail = (f'<button type="button" data-line="{i}">Tiles for line {i}</button>'
                  f'<details><summary>Boundary record</summary><code>{record}</code></details>')
        rows.append((i, explanation(line), math(clause(line["clause"])), detail))
    assert len(rows) == 131
    hypotheses = "<ol>" + "".join(f"<li>{math(formula(p))}</li>" for p in source["premises"]) + "</ol>"
    edits = transfers["single_tile_edits"]
    covers = [row for row in edits if row["baseline"] == "POSITIVE"]
    reused = [row for row in edits if row["reused"]]
    work = {k: f'{sum(row["counts"].get(k,0) for row in reused):,}'
            for k in ("nodes", "placement_checks")}
    witness = covers[0]
    cover_view = figure(g, dict(**witness, kind="edited", turn=0, offset=g.zero, atoms={}),
                        None, witness["tile"], "A one-rhomb edit that admits an exact cover")
    runtime, timing = runtime_tables(read("data/cascade-runtime-v1.json"), read("data/cascade-timing-v1.json"))
    movable = movable_views(g, frozen(read("data/cascade-movable-v1.json")), root)
    routing = routing_table(read("data/route-bandit-v1.json"))
    fields = dict(RECEIVERS="".join(receivers), RECEIVER_VIEW="", ATOMS=atoms, RECEIVER_FRAMES="".join(frames),
                  TILE_VIEW="", TILE_DATA=json.dumps(windows, separators=(",", ":")),
                  TILE_DEFS="".join(tile_svg(t, i) for t, i in palette.items()),
                  GOAL=math(formula(source["goal"])),
                  HYPOTHESES=hypotheses, PROOF=table(rows), EDIT_VIEW=cover_view,
                  EDIT_COUNT=len(edits), EDIT_REUSE=len(reused), EDIT_POSITIVE=len(covers),
                  BASELINE_NODES=work["nodes"], BASELINE_PLACEMENTS=work["placement_checks"],
                  RUNTIME=runtime, TIMING=timing, MOVABLE=movable, ROUTING=routing)
    html = (ROOT / "publication/notebook-v1.html").read_text()
    for name, value in fields.items():
        html = html.replace(f"%%{name}%%", str(value))
    assert "%%" not in html
    (ROOT / f"report/{STEM}.html").write_text(html)


if __name__ == "__main__":
    main()
