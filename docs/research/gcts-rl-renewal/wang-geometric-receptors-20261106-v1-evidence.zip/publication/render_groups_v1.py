"""Render the shared geometric lemma and its checked Wang squares."""

import gzip
from html import escape
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from proof_presentation import ROOT, STYLE, math, strip, wang

STEM = "wang-geometric-receptors-20261106-v1"
SYMBOLS = ("R", "X_1", "X_2", "G_1", "G_2")


def literal(value):
    return (r"\neg " if value < 0 else "") + SYMBOLS[abs(value)-1]


def clause(row):
    return math(r" \lor ".join(map(literal, row)) if row else r"\bot")


def read(name):
    return json.loads((ROOT / "data" / name).read_bytes())


def main():
    groups = read("group-v1.json")
    local = read("geometry-wang-v1.json")
    with gzip.open(ROOT / "data" / "group-wang-route-v1.json.gz", "rt") as stream:
        saved = json.load(stream)
    palette = wang.palette()
    assert wang.digest(palette) == local["palette"] == groups["receipt"]["palette_sha256"]
    proof = groups["proof"]
    words = ("The first blocker excludes every placement in the first group.",
             "The second blocker excludes every placement in the second group.",
             "The receptor requires a placement from one of the two groups.",
             "The first group is excluded, so a placement in the second group is required.",
             "The second group is also excluded. The three assumptions are incompatible.")
    assert [row["clause"] for row in proof] == [[-4],[-5],[4,5],[5],[]]
    premises = "".join(f"<li>{clause(row)}</li>" for row in groups["premises"])
    derived = []
    for i, (row, explanation) in enumerate(zip(proof,words,strict=True)):
        squares=strip(saved["circuit"],saved["certificate"],f"line{i}:positive",palette)
        reason=f'Resolve lines {row["left"]+1} and {row["right"]+1} on {math(literal(row["pivot"]))}.'
        derived.append(f'<tr><th scope="row">{len(groups["premises"])+i+1}</th><td>{clause(row["clause"])}<p>{reason} {escape(explanation)}</p>'
                       f'<details><summary>Show the associated Wang squares</summary>{squares}</details></td></tr>')
    variants=[]
    for case in local["cases"]:
        if not case["artifact"]:
            continue
        artifact=case["artifact"]
        variants.append(f'<tr><td>{case["id"]}</td><td>{len(case["options"])}</td>'
                        f'<td>{len(case["results"]["MARKED"]["proof"])}</td><td>{artifact["receipt"]["cells"]:,}</td>'
                        f'<td>{artifact["route"]["receipt"]["cells"]:,}</td></tr>')
    page=rf"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>One Wang lemma for Penrose and Turtle marks</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}
.proof-table{{table-layout:fixed}}.proof-table tr>:first-child{{width:3.5rem}}.proof-table .strip{{overflow:auto}}
</style></head><body><main>
<header><p class="eyebrow">GCTS proof notebook · November 2026</p>
<h1>One Wang lemma for Penrose and Turtle marks</h1>
<p>Three Penrose contexts and 156 Turtle certificates bind to the same five-step resolution derivation. The Turtle certificates contain 34 distinct required-and-excluded patterns. All the Wang certificates use the same 100 translation-only square types as the earlier propositional and first-order proof readers.</p>
<nav aria-label="On this page"><a href="#binding">Geometric binding</a><a href="#reader">Read the proof</a><a href="#cost">Checker size</a></nav></header>
<section id="binding"><h2>Assign placements to two blocker groups</h2>
<p>Write \(R\) for the obligation to cover a receptor. A Penrose receptor requires one rhomb along a directed edge. A Turtle receptor requires one tile covering a point atom. The exact source checker enumerates the legal placements and assigns each to a group \(G_i\) whose corresponding blocker \(X_i\) excludes it.</p>
<p>For the unrestricted Penrose edge, the two groups have three placements and one placement. In the Turtle tests, every required atom has 240 lattice placements. A second enumeration from exact polygon bounds and point-in-polygon tests agrees with the indexed atom inventory. In each context there is a placement restored by dropping either blocker alone. Reversing the Penrose edge gives a checked positive control.</p>
<p>The Wang rectangle receives the resulting clauses. The geometry admission supplies the complete placement sets and checks the binding of the group symbols. The rectangle checks the logical derivation from those clauses.</p></section>
<section id="reader"><h2>Read the same proof for either geometry</h2>
<p>Lines 1 through 3 are the geometry clauses. Lines 4 through 6 assume that the receptor is required and both blockers apply.</p><ol>{premises}</ol>
<div class="key"><span><span class="swatch" style="background:#68a98f"></span>Vertical transfer</span><span><span class="swatch" style="background:#ce8750"></span>Gate role</span><span><span class="swatch" style="background:#ad87c3"></span>Horizontal bus</span></div>
<table class="proof-table"><thead><tr><th>Line</th><th>Formula, reading and squares</th></tr></thead><tbody>{''.join(derived)}</tbody></table>
<p>The contradiction yields the reusable mark \(\neg R\lor\neg X_1\lor\neg X_2\). Each expandable strip shows seven actual squares from a machine row that reads part of that logical line.</p></section>
<section id="cost"><h2>Check the proof after search supplies its route</h2>
<p>The first checker leaves the parent indices, pivots and resolvents open. The smaller checker uses the parent indices and pivots supplied by search as circuit parameters. It still checks the pivot signs, every resolvent and the final empty clause. Independent ribbon verification checks the edges and tile coverage of each compiled rectangle.</p>
<div class="scroll"><table><thead><tr><th>Case</th><th>Placement options</th><th>Resolution steps</th><th>Open route squares</th><th>Supplied route squares</th></tr></thead>
<tbody>{''.join(variants)}<tr><td>Shared two-group lemma</td><td>Two groups</td><td>5</td><td>{groups["receipt"]["cells"]:,}</td><td>{groups["route"]["cells"]:,}</td></tr></tbody></table></div>
<p>These are virtual square counts. The ribbon checker verifies repeated transport without expanding each square. All one-bit changes to the supplied-route resolvents were rejected. Plain and marked resolution both found the three ungrouped refutations, and variable elimination tried fewer pivots in all three.</p></section>
<section id="evidence"><h2>Evidence</h2><p><a href="{STEM}-evidence.zip">Download exact bindings, proof rows, Wang certificates, and replay sources</a>.</p></section>
</main></body></html>"""
    (ROOT / "report" / (STEM + ".html")).write_text(page)


if __name__ == "__main__":
    main()
