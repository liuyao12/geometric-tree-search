# Reproduce the shared geometric lemma

Extract the archive. Use the interpreter pinned in both protocols and
move the archived data directory aside before replaying.

    mv data original-data
    mkdir data
    "$GCTS_PYTHON" -I -S -B source/geometry_wang_v1.py
    "$GCTS_PYTHON" -I -S -B source/receptor_groups_v1.py

The two runs regenerate the geometry admissions, the resolution proofs,
the Wang certificates and their independent checking receipts. The clean
replay agreed byte for byte with the archived scientific outputs.
