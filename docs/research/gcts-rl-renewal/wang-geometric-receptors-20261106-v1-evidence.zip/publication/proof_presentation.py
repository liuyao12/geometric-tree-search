"""Build the quantified Wang proof reader from checked rectangle data."""

import gzip
from html import escape
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import fixed_palette_v1 as wang
from resolution_v1 import load, pin

STEM="fixed-wang-quantified-origins-20261105-v1"
OLD="fixed-wang-ground-resolution-20261105-v1.html"

TITLES={
    "exists-map":"Existence transfers along an implication",
    "incidence-existence":"An incident line exists",
    "nested-choice":"Use one witness for every last argument",
    "quantifier-duality":"Negating a universal quantifier",
    "peano-nonzero-successor":"A double successor differs from zero",
    "hilbert-incidence-uniqueness":"A line through two distinct points is unique",
    "shadowed-existential":"An existential binder shadows an outer variable",
}


def math(s):
    return r"\("+escape(s)+r"\)"


def term(t):
    if isinstance(t,str):
        name=t.removeprefix("?")
        if name.startswith("v") and name[1:].isdigit():
            return r"x_{"+name[1:]+"}"
        return name
    f,*args=t
    head={"zero":"0","ell":r"\ell"}.get(f,f if len(f)==1 else r"\mathrm{"+f.replace("_",r"\_")+"}")
    return head+r"\left("+", ".join(map(term,args))+r"\right)" if args else head


def atom(value):
    p,*args=value
    if p.startswith("="):
        a,b=map(term,args)
        return a+"="+b
    return term(value)


def formula(node):
    tag,*xs=node
    if tag=="atom":
        return atom(xs)
    if tag=="not":
        if xs[0][0]=="atom" and xs[0][1].startswith("="):
            a,b=map(term,xs[0][2:])
            return a+r"\ne "+b
        return r"\neg\bigl("+formula(xs[0])+r"\bigr)"
    if tag in ("all","exists"):
        v,s,body=xs
        return (r"\forall " if tag=="all" else r"\exists ")+term(v)+r"{:}\mathrm{"+s+r"}\;"+formula(body)
    op={"and":r"\land","or":r"\lor","implies":r"\to","iff":r"\leftrightarrow"}[tag]
    a,b=map(formula,xs)
    return r"\bigl("+a+" "+op+" "+b+r"\bigr)"


def clause(ids,atoms):
    return r" \lor ".join(literal(i>0,atoms[abs(i)-1]) for i in ids) or r"\bot"


def literal(positive,value):
    if not positive and value[0].startswith("="):
        a,b=map(term,value[1:])
        return a+r"\ne "+b
    return ("" if positive else r"\neg ")+atom(value)


def square(tile):
    text=f"Tile {tile['id']}. North {tile['N']}. East {tile['E']}. South {tile['S']}. West {tile['W']}."
    def paint(op,bit):
        if op=="CROSS":
            return ("#dee9e1","#68a98f")[bit]
        return ("#eacba0","#ce8750")[bit]
    colors=[paint(*tile["N"]),("#ded7eb","#ad87c3")[tile["E"]],
            paint(*tile["S"]),("#ded7eb","#ad87c3")[tile["W"]]]
    triangles=["0,0 40,0 20,20","40,0 40,40 20,20","40,40 0,40 20,20","0,40 0,0 20,20"]
    parts="".join(f'<polygon points="{p}" fill="{c}"></polygon>' for p,c in zip(triangles,colors,strict=True))
    return f'<svg class="tile" viewBox="0 0 40 40" role="img" aria-label="{escape(text)}">{parts}<text x="20" y="24" text-anchor="middle">{tile["id"]}</text></svg>'


def strip(circuit,cert,prefix,palette):
    columns={i for i,r in enumerate(circuit["inputs"]) if r["name"].startswith(prefix)}
    y,x=next((j,min(columns&set(g))) for j,g in enumerate(circuit["gates"]) if columns&set(g))
    start=max(0,x-2)
    end=min(len(circuit["inputs"])+len(circuit["gates"]),start+7)
    tiles=[palette["tiles"][wang.tile_at(circuit,cert,i,y)] for i in range(start,end)]
    return (f'<div class="strip" data-count="{len(tiles)}">'+"".join(map(square,tiles))+
            f'</div><p class="coord">Machine row {y+1}, columns {start+1}–{end}. Squares are shown in placement order.</p>')


def panel(row,palette):
    original,out=row["original"],row["outcome"]
    identifier=original["id"]
    with gzip.open(ROOT/"data"/(identifier+"-source-wang-v1.json.gz"),"rt") as f:
        rect=json.load(f)
    c,cert=rect["circuit"],rect["certificate"]
    source=strip(c,cert,"source1-clause1:literal",palette)
    atoms=out["atoms"]
    lines=[]
    for i,(premise,origin) in enumerate(zip(out["premises"],out["premise_sources"],strict=True)):
        env=origin["substitution"]
        values=", ".join(math(term(v)+r"\mapsto "+term(t)) for v,t in sorted(env.items()))
        expl=f'Use clause <code>{escape(origin["schema"])}</code>'
        expl+=f" with {values}." if values else "."
        lines.append((clause(premise,atoms),expl,f"premise{i}:positive"))
    for j,r in enumerate(out["proof"]):
        expl=f'Resolve lines {r["left"]+1} and {r["right"]+1} on '+math(atom(atoms[r["pivot"]-1]))+"."
        lines.append((clause(r["clause"],atoms),expl,f"line{j}:"))
    rows=[]
    for i,(statement,words,prefix) in enumerate(lines,1):
        rows.append(f'<tr><th scope="row">{i}</th><td>{math(statement)}</td><td>{words}'
                    f'<details><summary>Show associated Wang squares</summary>{strip(c,cert,prefix,palette)}</details></td></tr>')
    binders=[]
    for b in row["binders"]:
        label="Universal parameter" if b["universal"] else "Fresh witness"
        binders.append(f'<li>{label} {math(term(b["term"]))} for binder {math(term(b["name"]))} in sort '
                       f'{math(r"\mathrm{"+b["sort"]+"}")}.</li>')
    origins=[]
    for s in row["compiled"]["clauses"]:
        n,_=row["origin_routes"][s["id"]]
        source_label=f"Premise {n+1}" if n<len(original["premises"]) else "Negated conclusion"
        statement=r" \lor ".join(literal(p,a) for p,a in s["clause"]) or r"\bot"
        origins.append(f'<li>{source_label}, <code>{escape(s["id"])}</code>. {math(statement)}</li>')
    given="<ol>"+"".join(f'<li><div class="scroll">{math(formula(p))}</div></li>' for p in original["premises"])+"</ol>" if original["premises"] else "<p>The statement is closed and has no separate premises.</p>"
    return f"""<article class="proof" id="case-{identifier}">
<h3>{TITLES[identifier]}</h3>
<p><strong>Given</strong></p>{given}
<p><strong>Conclusion</strong></p><div class="scroll">{math(formula(original["goal"]))}</div>
<details><summary>Binders and source clauses</summary><ul>{"".join(binders)}</ul><ul>{"".join(origins)}</ul>{source}</details>
<div class="scroll"><table><thead><tr><th>Line</th><th>Clause</th><th>Reading and squares</th></tr></thead><tbody>{"".join(rows)}</tbody></table></div>
</article>""",len(lines)


STYLE="""
*{box-sizing:border-box}body{margin:0;background:#f6f5ef;color:#263b33;font-family:system-ui,-apple-system,sans-serif;line-height:1.55}
main{max-width:1040px;margin:auto;padding:2rem clamp(1rem,4vw,3.2rem) 4rem}header{border-bottom:1px solid #bbcbbd;padding:1.2rem 0 1rem}
h1,h2,h3{font-family:Georgia,serif;line-height:1.12}h1{font-size:clamp(2.4rem,7vw,4.45rem);margin:.22em 0;max-width:16ch}
h2{font-size:clamp(1.7rem,4vw,2.55rem)}h3{font-size:1.45rem}section{margin-top:2.3rem}p{max-width:74ch}a{color:#1b5a48}
.eyebrow{font-weight:750;letter-spacing:.09em;text-transform:uppercase;font-size:.8rem}nav{display:flex;gap:.5rem 1.25rem;flex-wrap:wrap}
.proof{border:1px solid #c5d1c7;background:#fffefa;padding:clamp(.7rem,2vw,1.15rem);border-radius:.8rem;margin-top:1rem}
select{background:white;color:inherit;padding:.4rem;border:1px solid #91a99a;border-radius:.35rem;font:inherit;max-width:100%}
.scroll{overflow:auto}table{width:100%;border-collapse:collapse}td,th{padding:.55rem .65rem;border-bottom:1px solid #cbd5cc;text-align:left;vertical-align:top}
thead th{background:#e4eee5}.strip{display:flex;gap:2px;margin-top:.5rem}.tile{width:38px;min-width:27px;border:1px solid #40554a}
.tile text{font-size:11px;fill:#243831;font-weight:700}.coord{font-size:.83rem;color:#425d50;margin:.35rem 0}
summary{cursor:pointer;color:#285f4e;font-weight:650}details{padding:.35rem .1rem}.callout{border-left:4px solid #3a816b;background:#e5eee6;padding:.2rem .9rem}
code{font-size:.88em;overflow-wrap:anywhere}[hidden]{display:none!important}.key{display:flex;gap:.45rem 1rem;flex-wrap:wrap;font-size:.91rem}
.swatch{display:inline-block;width:.85rem;height:.85rem;border-radius:.18rem;margin-right:.25rem}
@media(max-width:550px){main{padding-top:.7rem}td,th{padding:.45rem}.tile{width:31px}}
"""


def render(summary,panels):
    choices="".join(f'<option value="{k}"{" selected" if k=="peano-nonzero-successor" else ""}>{v}</option>'
                    for k,v in TITLES.items())
    methods={"shortest":"Shortest clause","marked":"Shortest with marks","learned":"Frozen learned ranking with marks","eliminate":"Variable elimination"}
    totals=summary["comparison"]["totals"]
    rows="".join("<tr>"+"".join(f"<td>{v}</td>" for v in (label,*[totals[k][m] for m in ("proved","selected","pivots","marks")]))+"</tr>"
                 for k,label in methods.items())
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quantified proofs in one Wang palette</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}</style></head><body><main>
<header><p class="eyebrow">GCTS proof notebook · First-order logic · November 2026</p>
<h1>Quantified proofs in one Wang palette</h1>
<p>Seven automatically found proofs use the same 100 square tile types. The rectangle checks clause origins, typed ground instances and resolution. The examples include Peano arithmetic and symbolic Hilbert incidence.</p>
<nav aria-label="On this page"><a href="#reader">Read the proofs</a><a href="#origin">Source checks</a><a href="#comparison">Search comparison</a><a href="#evidence">Evidence</a></nav></header>
<section id="reader"><h2>Read each proof line</h2>
<p>Choose a statement and expand a line to see squares from the actual checked rectangle. Each displayed strip is a machine row that reads a bit associated with that line. A logical line can require many such rows.</p>
<div class="key"><span><span class="swatch" style="background:#68a98f"></span>Vertical transfer</span><span><span class="swatch" style="background:#ce8750"></span>Vertical gate role</span><span><span class="swatch" style="background:#ad87c3"></span>Horizontal bus</span></div>
<p><label>Statement <select id="case-menu">{choices}</select></label></p>{''.join(panels)}
<p>The squares have fixed north, east, south and west ports. Each strip uses translations in the certificate grid. The two shades in each color family show the bit carried by the port.</p></section>
<section id="origin"><h2>Connect each clause to a source formula</h2>
<ol><li>The syntax encoder reads closed typed formulas, tracks lexical scope, and pushes the sign of the refutation into each connective. For an existential it gives the fresh function the effective universal arguments in scope.</li>
<li>The rectangle checks the reported binder kind, sort and dependency set against the compiled syntax. It reads a source selector and conjunction choices. A disjunction joins both selected clauses. The resulting literal bitmap must match the clause admitted by the ground-instantiation stage.</li>
<li>Typed term matches admit each concrete premise. The same rectangle checks the parent indices, pivot and exact resolvent at each line. The final clause must be empty.</li></ol>
<div class="callout"><p><strong>Forgery control.</strong> The invalid entailment \(\forall x\,P(x)\models\forall x\,Q(x)\) would admit a resolution refutation if its negated conclusion were replaced by \(\neg P(c)\). The resolution-only checker accepts that fabricated pair of clauses. The source-aware rectangle rejects the same witness at its acceptance boundary.</p></div>
<p>The source encoder, equality schemas and the bounded ground alphabet are part of the compiled boundary. The squares verify the supplied origin choices and dependencies under that boundary. The finite interpretation tests check the predicate-only examples separately. The quantifier-order control has a two-element countermodel with \(R(x,y)\) interpreted as equality.</p>
<p>TPTP likewise distinguishes clausification, including equisatisfiable Skolemization, from the later inferences on clauses. <a href="https://tptp.org/UserDocs/QuickGuide/Derivations.html">TPTP derivation conventions</a></p></section>
<section id="comparison"><h2>What changed proof search?</h2>
<div class="scroll"><table><thead><tr><th>Search</th><th>Proved</th><th>Selections</th><th>Pivot attempts</th><th>Checked marks</th></tr></thead><tbody>{rows}</tbody></table></div>
<p>Every arm saw the same grounded inputs, with depths fixed by the earlier proof run. The marked arms certify tautological pairs and subsumed resolvents. The plain given-clause arm exhausted its budget on one case. The frozen policy trained on synthetic Horn chains. It chose slightly fewer clauses than marked shortest-first and attempted slightly more pivots. Variable elimination had the fewest pivot attempts in this sample. Selections mean variables for elimination and clauses for the other arms.</p></section>
<section id="evidence"><h2>Inspect or replay the evidence</h2>
<ul><li><a href="{STEM}-results.json">Machine-readable proof and comparison summary</a></li><li><a href="{STEM}-evidence.zip">Full archive with original formulas, certificates and source</a></li><li><a href="{STEM}-manifest.json">SHA-256 manifest</a></li><li><a href="{OLD}">Previous ground-proof notebook</a></li></ul></section>
</main><script>
const menu=document.getElementById("case-menu");
function choose(){{for(const panel of document.querySelectorAll(".proof"))panel.hidden=panel.id!=="case-"+menu.value;}}
menu.addEventListener("change",choose);choose();
</script></body></html>"""


def main():
    data=load("data/results-v1.json")
    cases=[r for r in data["cases"] if "rectangle" in r]
    palette=wang.palette()
    page_panels=[panel(c,palette) for c in cases]
    summary=dict(status="CHECKED_QUANTIFIED_WANG_READER",source=load("data/summary-v1.json"),
                 comparison=load("data/comparison-v1.json")["result"],
                 qualification=load("data/qualification-v1.json"),
                 cases=[dict(id=c["original"]["id"],lines=n,gates=c["gates"],rectangle=c["rectangle"],
                             mutations=c["mutations"])
                        for c,(_,n) in zip(cases,page_panels,strict=True)])
    html=render(summary,[x for x,_ in page_panels])
    with (ROOT/"report"/(STEM+".html")).open("x") as f:
        f.write(html)
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:
        json.dump(summary,f,indent=2,sort_keys=True)


if __name__=="__main__":
    main()
