const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function check() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1100, height: 900 } });
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const file = path.join(__dirname, "../report/wang-geometric-receptors-20261106-v1.html");
    const result = await page.goto(process.argv[2] || pathToFileURL(file).href);
    if (process.argv[2]) assert.equal(result.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length === 20);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    const details = page.locator("#reader tbody details");
    assert.equal(await details.count(), 5);
    for (let i = 0; i < 5; i++) {
      await details.nth(i).locator("summary").click();
      assert.equal(await details.nth(i).locator("svg.tile:visible").count(), 7);
    }
    assert.deepEqual(errors, []);
    if (!process.argv[2]) await page.locator("#reader table").screenshot({ path: path.join(__dirname, "proof-v1.png") });
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    const receipt = { status: "CHECKED_READER", proofRows: 5, tiles: 35, formulas: 20, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
check().catch(error => { console.error(error); process.exitCode = 1; });
