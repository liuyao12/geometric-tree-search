"""Compare lazy exact contact, transferred guards, and learned placement order."""

import gzip
import hashlib
import json
from pathlib import Path
import random
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
from learn_v1 import ROOT,pin,read,save,verify
from penrose_sat_v1 import geometry,replay,solve,split,transfer
from region_v1 import author_cases
import check_v1 as independent
import model_v1 as model


def exact(x):
    return tuple(map(exact,x)) if isinstance(x,list) else x


def donor_rows():
    summary=read("data/learning-summary-v1.json")
    assert all(pin(ROOT/name)==value for name,value in summary["files"].items())
    with gzip.open(ROOT/"data/contact-certificates-v1.json.gz","rt") as stream:
        rows=json.load(stream)
    return [{**r,"root":exact(r["root"]),"other":exact(r["other"]),
             **({"domain":[(exact(a),mask) for a,mask in r["domain"]]} if "domain" in r else {})} for r in rows]


def fixture(name,scale,turns,kind):
    u,v=model.DIRECTIONS[turns],model.DIRECTIONS[(turns+2)%10]
    seed=model.rhomb(model.ZERO,turns,2)
    points={tuple(i*a+j*b for a,b in zip(u,v,strict=True)) for i in range(-scale,scale+1)
            for j in range(-scale,scale+1)
            if kind=="full" or (kind=="comb" and (i%2==0 or j<=0)) or
            (kind=="slant" and abs(i+j)<=scale+1)}
    return dict(id=name,target=sorted(points|set(seed)),seeds=[seed],family=kind)


def by_footprint(world,donors):
    # A transported obstruction must have a genuine source proof and land
    # on a target vertex. The independent arithmetic rechecks the footprint.
    donor=set(donors)
    for c,point in world["known"].items():
        a,b=sorted(world["tiles"][abs(v)-1] for v in c)
        anchor=a[0]
        x,y=(tuple(independent.minus(p,anchor) for p in t) for t in (a,b))
        assert (x,y,independent.minus(point,anchor)) in donor and point in world["target"]


def evidence(world,r,known):
    for (i,j),_ in r["geometry"]:
        a,b=(world["tiles"][abs(k)-1] for k in (i,j))
        assert not independent.contact(a,b)
    if r["status"]=="NEGATIVE":
        base=world["clauses"]+list(known)+[tuple(c) for c,_ in r["geometry"]]
        replay(base,r["cuts"])
        assert r["cuts"][-1]==()
    return True


def run():
    plan=read("geometry-protocol-v1.json")
    verify(plan)
    deps=Path(sys.argv[1])
    assert all(pin(deps/k)==h for k,h in read("wang-protocol-v1.json")["pysat_files"].items())
    sys.path.insert(0,str(deps))
    from pysat.solvers import Solver
    independent.qualify(model)
    rules,holdouts=split(donor_rows())
    def prepare(case):
        w=geometry(exact(case["target"]),exact(case["seeds"]))
        w["known"]=transfer(w,rules)
        by_footprint(w,rules)
        return w
    train=[fixture(f"T{i+1:02}",scale,turn,kind) for i,(scale,turn,kind) in enumerate(plan["train"])]
    earlier=[dict(id=r["id"],target=r["points"],seeds=r["seeds"],family=r["family"])
             for r in author_cases() if r["id"] in plan["prior_test"]]
    fresh=[fixture(f"N{i+1:02}",scale,turn,kind) for i,(scale,turn,kind) in enumerate(plan["fresh"])]
    negatives=[dict(id=f"H{i+1:02}",target=sorted({model.ZERO,*a,*b}),seeds=[a,b],family="held-contact")
               for i,(a,b) in enumerate(holdouts[:plan["held_pairs"]])]
    test=earlier+fresh+negatives
    initial=plan["weights"]
    weights=initial[:]
    rng=random.Random(plan["seed"])
    rewards=[]
    average=.1
    for i in range(plan["episodes"]):
        case=train[i%len(train)]
        world=prepare(case)
        r=solve(world,world["known"],plan["train_budget"],weights,rng=rng,audit=False)
        count=r["counts"]
        cost=count.get("decisions",0)+5*count.get("models",0)+len(r["geometry"])
        reward=1/(1+cost/80) if r["status"]=="POSITIVE" else -.2
        delta=reward-average
        average=.9*average+.1*reward
        grad=r.pop("gradients")
        if grad:
            for j,g in enumerate(zip(*grad,strict=True)):
                weights[j]=max(-3.,min(3.,weights[j]+plan["rate"]*delta*sum(g)/len(g)))
        rewards.append(dict(case=case["id"],status=r["status"],cost=cost,reward=reward,
                            choices=len(grad),weights=weights[:]))
        print(json.dumps(dict(episode=i,case=case["id"],status=r["status"],cost=cost),sort_keys=True),flush=True)
    tests=[]
    for case in test:
        model.clear_geometry()
        start=time.monotonic()
        world=prepare(case)
        setup=time.monotonic()-start
        rows=[]
        for label,known,score,options in (
            ("plain",{},initial,{}),("guarded",world["known"],initial,{}),
            ("learned",world["known"],weights,{}),("random",world["known"],initial,
                                                  dict(rng=random.Random(9901),randomized=True)),
            ("glucose",world["known"],initial,dict(solver=Solver))):
            r=solve(world,known,plan["test_budget"],score,**options)
            r.pop("gradients")
            assert case["family"]!="held-contact" or r["status"]!="POSITIVE"
            start=time.monotonic()
            checked=evidence(world,r,known)
            r.update(mode=label,independent=checked,assurance_seconds=time.monotonic()-start)
            rows.append(r)
        tests.append(dict(case=case,results=rows,inventory=world["tiles"],base=len(world["clauses"]),
                          warm=len(world["known"]),setup_seconds=setup))
        print(json.dumps(dict(id=case["id"],targets=len(case["target"]),tiles=len(world["tiles"]),warm=len(world["known"]),
                              arms=[(r["mode"],r["status"],r["counts"].get("decisions",0),len(r["geometry"]),
                                     r["counts"].get("models",0),len(r["cuts"])) for r in rows]),
                         sort_keys=True),flush=True)
    save("data/lazy-contact-v1.json",dict(status="CHECKED_PENROSE_LAZY_CONTACT",initial=initial,learned=weights,
                                         training=rewards,cases=tests,oriented_donor_rules=len(rules),
                                         held_out_orbits=len(holdouts)))


if __name__=="__main__":
    run()
