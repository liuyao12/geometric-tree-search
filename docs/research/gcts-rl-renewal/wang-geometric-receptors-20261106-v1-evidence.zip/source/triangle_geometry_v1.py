"""Exact simple-polygon geometry, independent of point-capacity authoring.

Inert stdlib-only Source. Inputs use axial two-dimensional coordinates; an
invertible linear drawing map preserves positive-area overlap. Integers stay
integers until an intersection requires a Fraction. No epsilon is used.
Boundary-only contact is legal. Polygons have one simple boundary and no holes.
"""
from fractions import Fraction

VERSION = 'TURTLE-INDEPENDENT-EAR-SAT-GEOMETRY-v1'


def _number(value):
    if type(value) not in (int, Fraction):
        raise ValueError('Coordinates must be native int or Fraction, not bool/float')
    return value


def _points(value):
    if type(value) not in (list, tuple):
        raise ValueError('Expected a point sequence')
    result = []
    for point in value:
        if type(point) not in (list, tuple) or len(point) != 2:
            raise ValueError('Expected two-dimensional points')
        result.append((_number(point[0]), _number(point[1])))
    if len(result) > 1 and result[-1] == result[0]:
        result.pop()  # One explicit closing vertex is accepted.
    return result


def _cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])


def _signed_area2(points):
    return sum(a[0]*b[1]-a[1]*b[0]
               for a, b in zip(points, points[1:]+points[:1]))


def area2(poly):
    """Signed doubled area in input coordinates; no Euclidean A2 area claim."""
    return _signed_area2(_points(poly))


def _on_segment(a, b, p):
    return (_cross(a, b, p) == 0 and min(a[0], b[0]) <= p[0] <= max(a[0], b[0])
            and min(a[1], b[1]) <= p[1] <= max(a[1], b[1]))


def _segments_meet(a, b, c, d):
    ab_c, ab_d = _cross(a, b, c), _cross(a, b, d)
    cd_a, cd_b = _cross(c, d, a), _cross(c, d, b)
    if ab_c*ab_d < 0 and cd_a*cd_b < 0:
        return True
    return ((ab_c == 0 and _on_segment(a, b, c))
            or (ab_d == 0 and _on_segment(a, b, d))
            or (cd_a == 0 and _on_segment(c, d, a))
            or (cd_b == 0 and _on_segment(c, d, b)))


def _strip_straight(points):
    """Remove only straight 180-degree vertices, never a retraced spike."""
    points = list(points)
    changed = True
    while changed and len(points) >= 3:
        changed = False
        for i, b in enumerate(points):
            a, c = points[i-1], points[(i+1) % len(points)]
            if _cross(a, b, c) != 0:
                continue
            dot = (b[0]-a[0])*(c[0]-b[0])+(b[1]-a[1])*(c[1]-b[1])
            if dot <= 0:
                raise ValueError('Collinear backtracking or zero-length edge')
            del points[i]
            changed = True
            break
    return points


def validate_polygon(poly):
    """Return a CCW simple boundary with straight vertices removed.

    Nonadjacent crossings, touching and repeated vertices are rejected.
    Adjacent edges may share only their common endpoint. An open ring or one
    repeated closing vertex is accepted. The original object is not mutated.
    """
    points = _points(poly)
    n = len(points)
    if n < 3 or len(set(points)) != n:
        raise ValueError('A polygon needs at least three distinct vertices')
    for i, b in enumerate(points):
        a, c = points[i-1], points[(i+1) % n]
        if _cross(a, b, c) == 0:
            dot = (b[0]-a[0])*(c[0]-b[0])+(b[1]-a[1])*(c[1]-b[1])
            if dot <= 0:
                raise ValueError('Adjacent edges overlap or retrace')
    for i in range(n):
        a, b = points[i], points[(i+1) % n]
        for j in range(i+1, n):
            if j == i+1 or (i == 0 and j == n-1):
                continue
            if _segments_meet(a, b, points[j], points[(j+1) % n]):
                raise ValueError('Nonadjacent polygon edges intersect or touch')
    points = _strip_straight(points)
    twice = _signed_area2(points)
    if len(points) < 3 or twice == 0:
        raise ValueError('Degenerate polygon')
    if twice < 0:
        points = points[:1]+list(reversed(points[1:]))
    return points


def _inside_closed_triangle(p, a, b, c):
    return _cross(a, b, p) >= 0 and _cross(b, c, p) >= 0 and _cross(c, a, p) >= 0


def triangulate(poly):
    """Deterministic exact ear triangulation of a nonconvex simple polygon.

    Every returned triangle is strictly CCW. Zero-area triangles are never
    returned. Collinear vertices may also be removed from the remaining
    boundary after a cut; that does not alter its region.
    """
    points = validate_polygon(poly)
    original_area2 = _signed_area2(points)
    remaining, triangles = list(points), []
    while len(remaining) > 3:
        remaining = _strip_straight(remaining)
        if len(remaining) <= 3:
            break
        n = len(remaining)
        for i, b in enumerate(remaining):
            a, c = remaining[i-1], remaining[(i+1) % n]
            if _cross(a, b, c) <= 0:
                continue
            if any(_inside_closed_triangle(p, a, b, c)
                   for j, p in enumerate(remaining) if j not in ((i-1) % n, i, (i+1) % n)):
                continue
            triangles.append((a, b, c))
            del remaining[i]
            break
        else:
            raise ArithmeticError('No exact ear found after simple-polygon validation')
    if len(remaining) != 3 or _cross(*remaining) <= 0:
        raise ArithmeticError('Degenerate triangulation remainder')
    triangles.append(tuple(remaining))
    if sum(_cross(*triangle) for triangle in triangles) != original_area2:
        raise ArithmeticError('Triangulation area identity failed')
    return triangles


def _triangle(value):
    points = _points(value)
    if len(points) != 3 or len(set(points)) != 3:
        raise ValueError('Expected three distinct triangle vertices')
    turn = _cross(*points)
    if turn == 0:
        raise ValueError('Degenerate triangle')
    if turn < 0:
        points[1], points[2] = points[2], points[1]
    return tuple(points)


def _strict_sat(a, b):
    # A weak separator also counts as disjoint interiors: touching is legal.
    for triangle in (a, b):
        for p, q in zip(triangle, triangle[1:]+triangle[:1]):
            axis = (p[1]-q[1], q[0]-p[0])
            pa = [axis[0]*v[0]+axis[1]*v[1] for v in a]
            pb = [axis[0]*v[0]+axis[1]*v[1] for v in b]
            if max(pa) <= min(pb) or max(pb) <= min(pa):
                return False
    return True


def positive_overlap(triA, triB):
    """Strict positive-area triangle overlap, using exact SAT projections."""
    return _strict_sat(_triangle(triA), _triangle(triB))


def _dedup_ring(points):
    result = []
    for p in points:
        if not result or p != result[-1]:
            result.append(p)
    if len(result) > 1 and result[0] == result[-1]:
        result.pop()
    return result


def _clip(subject, clip_triangle):
    """Sutherland-Hodgman clipping against three closed CCW half-planes."""
    points = list(subject)
    for a, b in zip(clip_triangle, clip_triangle[1:]+clip_triangle[:1]):
        if not points:
            break
        output, previous = [], points[-1]
        before = _cross(a, b, previous)
        for current in points:
            after = _cross(a, b, current)
            if (before >= 0) != (after >= 0):
                ratio = Fraction(before)/(before-after)
                output.append((previous[0]+ratio*(current[0]-previous[0]),
                               previous[1]+ratio*(current[1]-previous[1])))
            if after >= 0:
                output.append(current)
            previous, before = current, after
        points = _dedup_ring(output)
    return points


def _encoded_number(value):
    rational = Fraction(value)
    return [rational.numerator, rational.denominator]


def encode_points(points):
    """JSON-native coordinates: each scalar is [numerator,positive denominator]."""
    return [[_encoded_number(x), _encoded_number(y)] for x, y in _points(points)]


def _witness(a, b):
    points = _clip(a, b)
    if len(points) < 3 or _signed_area2(points) <= 0:
        raise ArithmeticError('Strict SAT and rational clipping disagree')
    points = _strip_straight(points)
    start = min(range(len(points)), key=lambda i: points[i])
    points = points[start:]+points[:start]
    return dict(intersection=encode_points(points), area2=_encoded_number(_signed_area2(points)),
                coordinate_system='input axial coordinates',
                scope='Exact convex intersection of the two witness triangles')


def overlap(triA, triB):
    """JSON-native decision and positive rational triangle-intersection witness."""
    a, b = _triangle(triA), _triangle(triB)
    if not _strict_sat(a, b):
        return dict(overlap=False, witness=None)
    return dict(overlap=True, witness=_witness(a, b))


def triangulations_overlap(trianglesA, trianglesB):
    """First positive triangle-pair witness; supplied covers are caller-owned."""
    a = [_triangle(t) for t in trianglesA]
    b = [_triangle(t) for t in trianglesB]
    for i, left in enumerate(a):
        for j, right in enumerate(b):
            if _strict_sat(left, right):
                return dict(overlap=True, witness=dict(_witness(left, right), triangle_indices=[i, j]))
    return dict(overlap=False, witness=None)


def polygon_overlap(polyA, polyB):
    """Simple polygon interiors overlap iff some triangulation pair overlaps.

    A positive witness is the full intersection of one triangle pair, not the
    full intersection or total overlap area of the original nonconvex polygons.
    """
    return triangulations_overlap(triangulate(polyA), triangulate(polyB))
