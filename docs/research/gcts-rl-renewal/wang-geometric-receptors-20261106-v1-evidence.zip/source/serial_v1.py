"""A serial proof-shape restriction on the same open Wang rectangle."""

import json
from itertools import product
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from benchmark_v1 import compile_case, custom, decode, external, prop


def select_word(columns,integer):
    assert 0<=integer<1<<len(columns)
    return [(i+1)*(1 if integer>>k&1 else -1) for k,i in enumerate(columns)]


def serial(fields,premises):
    assert len(fields)+1==premises
    result=[]
    for i,(left,right,*_) in enumerate(fields):
        older=0 if i==0 else premises+i-1
        fresh=i+1
        a=select_word(left,older)+select_word(right,fresh)
        b=select_word(left,fresh)+select_word(right,older)
        for x,y in product(a,b):
            if x!=-y:
                result.append(tuple(dict.fromkeys((x,y))))
    return sorted(set(result))


def main():
    protocol=prop.load("serial-protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    full=prop.load("protocol-v1.json")
    dep=Path(sys.argv[1])
    assert all(prop.pin(dep/n)==v for n,v in full["pysat_files"].items())
    sys.path.insert(0,str(dep))
    problems={r["id"]:r for r in prop.load("input/cases-v1.json")+prop.load("input/new-cases-v1.json")
              +prop.load("input/tutorial-cases-v1.json")["cases"]+[prop.load("input/forgery-v1.json")]}
    palette=prop.wang.palette()
    results=[]
    for spec in protocol["cases"]:
        name=spec["id"]
        c,base,prefix,fields,functions=compile_case(problems[name],spec,full)
        cnf=base+serial(fields,spec["premises"])
        rows=[]
        for mode in ("activity","cadical195","glucose4"):
            if mode=="activity":
                result,bits,_=custom(c,cnf,protocol["limits"],mode)
            else:
                result,bits=external(c,cnf,[],protocol["external_conflicts"],mode)
            if bits is not None:
                proof=decode(bits,prefix,fields,functions)
                m=spec["premises"]
                assert all({row["left"],row["right"]}=={0 if i==0 else m+i-1,i+1}
                           for i,row in enumerate(proof["proof"]))
                cert=prop.wang.certificate(c,bits,palette)
                check=prop.independent_wang.verify(c,cert,palette)
                assert check["status"]=="VERIFIED"
                prop.compressed(f"data/{name}-{mode}-serial-wang-v1.json.gz",dict(circuit=c,certificate=cert))
                result.update(proof=proof,rectangle=check)
            rows.append(result)
        record=dict(id=name,spec=spec,gates=len(c["gates"]),extra_clauses=len(cnf)-len(base),
                    circuit_sha256=prop.wang.digest(c),results=rows)
        results.append(record)
        print(json.dumps(dict(id=name,extra_clauses=record["extra_clauses"],
            outcomes={r["mode"]:(r["status"],r["counts"],round(r["seconds"],4)) for r in rows}),
            sort_keys=True),flush=True)
    prop.save("data/serial-v1.json",results)


if __name__=="__main__":
    main()
