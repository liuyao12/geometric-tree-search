"""Qualify the Vampire guide's quantified Agatha example for the next bank."""

import json
from pathlib import Path
import sys
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from ground_control_v1 import Derivation
from origin_v1 import Source
from serial_blocks_v1 import catalog, prop
from transfer_experiment_v1 import replay_logic
from itertools import product


def source():
    a, b, c = [(s,) for s in ("agatha", "butler", "charles")]
    x, y = "?x", "?y"

    def at(p, *ts):
        return ["atom", p, *ts]

    def no(p):
        return ["not", p]

    def every(v, p):
        return ["all", v, "U", p]

    def exists(v, p):
        return ["exists", v, "U", p]

    def implies(p, q):
        return ["implies", p, q]

    eq = lambda u, v: at("=U", u, v)
    lives = lambda u: at("lives", u)
    killed = lambda u, v: at("killed", u, v)
    hates = lambda u, v: at("hates", u, v)
    richer = lambda u, v: at("richer", u, v)
    return dict(id="agatha-vampire-guide", sorts=["U"], equality=True,
                functions={t[0]:[[], "U"] for t in (a, b, c)},
                predicates={"lives":["U"], "hates":["U","U"], "killed":["U","U"], "richer":["U","U"]},
                premises=[exists(x, ["and", lives(x), killed(x,a)]), *[lives(t) for t in (a,b,c)],
                          every(x, implies(lives(x), ["or", eq(x,a), ["or", eq(x,b), eq(x,c)]])),
                          every(x, every(y, implies(killed(x,y), hates(x,y)))),
                          every(x, every(y, implies(killed(x,y), no(richer(x,y))))),
                          every(x, implies(hates(a,x), no(hates(c,x)))),
                          every(x, implies(no(eq(x,b)), hates(a,x))),
                          every(x, implies(no(richer(x,a)), hates(b,x))),
                          every(x, implies(hates(a,x), hates(b,x))),
                          every(x, exists(y, no(hates(x,y)))), no(eq(a,b))],
                goal=killed(a,a),
                source="https://vprover.github.io/vampireGuide/docs/tutorial/intro/#example-who-killed-agatha-puz0011")


def main():
    protocol = prop.load("protocol-v1.json")
    deps = Path(sys.argv[1])
    assert all(prop.pin(deps / k) == v for k, v in protocol["pysat_files"].items())
    sys.path.insert(0, str(deps))
    from pysat.solvers import Solver
    original = source()
    instance = Source(original).clauses(protocol["cnf_limit"])
    functions, predicates, schemas = fol.signature(instance)
    results = []
    for depth in (0, 1, 2):
        terms = fol.ground_terms(instance, functions, depth, protocol["max_terms"])
        if terms is None:
            break
        atoms = sorted((name, *args) for name, sorts in predicates.items()
                       for args in product(*(terms[s] for s in sorts)))
        all_terms = sorted({t for values in terms.values() for t in values})
        term_ids = {t: i for i, t in enumerate(all_terms)}
        types = {s: [term_ids[t] for t in values] for s, values in terms.items()}
        bank = catalog(SimpleNamespace(atoms=atoms, terms=all_terms, schemas=schemas, types=types))
        assert bank
        derivation = Derivation(bank)
        empty = derivation.refute(frozenset())
        unit_refutation = empty is not None
        clauses = [sorted(derivation.clauses[i]) for i in derivation.active]
        with Solver(name="glucose4", bootstrap_with=clauses, with_proof=True) as s:
            s.conf_budget(12000)
            status = s.solve_limited()
            trace = s.get_proof() if status is False else []
            counts = s.accum_stats()
        if status is False and empty is None:
            for line in trace:
                if line.startswith("d"):
                    continue
                lits = list(map(int, line.split()))
                assert lits.pop() == 0
                clause = frozenset(lits)
                if any(-v in clause for v in clause):
                    continue
                node = derivation.refute(clause)
                assert node is not None
                if not derivation.clauses[node]:
                    empty = node
                    break
            if empty is None:
                empty = derivation.refute(frozenset())
            assert empty is not None
        row = dict(depth=depth, atoms=len(atoms), terms=len(terms["U"]), admissions=len(bank),
                   unit_refutation=unit_refutation, sat=status, counts=counts)
        if empty is not None:
            origins, premises, proof = derivation.support(empty, bank)
            replay_logic(premises, proof, bank)
            row["proof"] = dict(atoms=atoms, origins=origins, premises=premises, proof=proof)
        print(json.dumps({k:v for k,v in row.items() if k!="proof"}, sort_keys=True),flush=True)
        results.append(row)
        if empty is not None:
            break
    prop.save("data/agatha-v1.json",dict(source=original,results=results))


if __name__ == "__main__":
    main()
