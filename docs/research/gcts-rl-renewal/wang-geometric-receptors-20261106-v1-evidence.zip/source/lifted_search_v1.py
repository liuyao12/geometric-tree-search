"""Search with checked lifted recipes and replay only their source derivations."""

from collections import Counter
import random
import time

from backjump_v1 import BoundarySearch
from ground_control_v1 import Derivation
from model_ground_v1 import Instantiator
from propagated_cuts_v1 import Replay
from serial_blocks_v1 import prop


def priority(o):
    return len(o.result),len(o.steps),o.result,o.leaves,o.recipe


def run(schemas,terms,atoms,offers,mode,plan):
    source={}
    active={}
    cuts=[]
    counts=Counter()
    turns=[]
    models=None
    status="BOUNDED"
    by_head={}
    for o in sorted(offers,key=priority):
        by_head.setdefault(o.result,o)
    candidates=list(by_head.values())
    if mode=="shuffle":
        random.Random(plan["shuffle_seed"]).shuffle(candidates)
    if mode=="eager":
        active={o.result:o for o in candidates}
    start=time.monotonic()
    fields=[dict(name=a[0]) for a in atoms]
    for _ in range(plan["rounds"]):
        primitive=[tuple(prop.literals(r)) for r in source]
        cnf=primitive+list(active)+cuts
        step=BoundarySearch(cnf,len(atoms),len(atoms),plan["sat"],"activity",fields)
        result,bits=step.run()
        counts.update(step.stats)
        audit=Replay(primitive+list(active)+cuts)
        for c in step.ordered:
            assert audit.refute(c)
            audit.add(c)
        cuts.extend(step.ordered)
        if result=="UNSAT":
            status="REFUTED"
            break
        if result=="BOUNDED":
            break
        check=Instantiator(schemas,terms,atoms,bits,plan["probes"])
        additions=check.find(source,plan["source_batch"])
        counts["source_probes"]+=check.probes
        if not additions:
            if not check.bounded:
                status="GROUND_MODEL"
                models=bits
            break
        chosen=[]
        if mode in {"demand","shuffle"}:
            truth={i if bit else -i for i,bit in enumerate(bits,1)}
            for offer in candidates:
                if offer.result in active:
                    continue
                counts["recipe_checks"]+=1
                if mode=="shuffle" or not truth.intersection(offer.result):
                    chosen.append(offer)
                if len(chosen)==plan["lemma_batch"]:
                    break
            active.update((o.result,o) for o in chosen)
        turns.append(dict(source=len(additions),new_recipes=len(chosen),cuts=len(step.ordered)))
        source.update(additions)
    return dict(status=status,counts=dict(counts),cuts=cuts,turns=turns,seconds=time.monotonic()-start,
                source=source,active=list(active.values()),model=models)


def expand(run,full):
    opaque=run["source"].copy()
    for offer in run["active"]:
        opaque.setdefault(prop.mask(offer.result),offer)
    d=Derivation(opaque)
    for cut in run["cuts"]:
        i=d.refute(frozenset(cut))
        assert i is not None and d.clauses[i]<=frozenset(cut)
    empty=d.refute(frozenset())
    assert empty is not None
    origins,premises,proof=d.support(empty,opaque)
    primitive={}
    recipes=set()
    for origin,row in zip(origins,premises,strict=True):
        if isinstance(origin,dict):
            primitive[prop.mask(row)]=origin
        else:
            recipes.add(origin)
            for leaf in origin.leaves:
                m=prop.mask(leaf)
                primitive[m]=full[m]
    expanded=Derivation(primitive)
    annotations={}
    refs=[]
    for origin,row in zip(origins,premises,strict=True):
        if isinstance(origin,dict):
            refs.append(expanded.known[frozenset(row)])
            continue
        nodes=[expanded.known[frozenset(r)] for r in origin.leaves]
        for a,b,p,claim in origin.steps:
            before=len(expanded.clauses)
            i=expanded.add_resolution(nodes[a],nodes[b],p)
            assert expanded.clauses[i]==frozenset(claim)
            if i==before:
                annotations[i]=origin
            nodes.append(i)
        refs.append(nodes[-1])
    for line in proof:
        i=expanded.add_resolution(refs[line["left"]],refs[line["right"]],line["pivot"])
        assert expanded.clauses[i]==frozenset(line["clause"])
        refs.append(i)
    assert not expanded.clauses[refs[-1]]
    used=set()
    pending=[refs[-1]]
    while pending:
        i=pending.pop()
        if i in used:
            continue
        used.add(i)
        if i in expanded.steps:
            pending.extend(expanded.steps[i][:2])
    return expanded.support(refs[-1],primitive),{annotations[i] for i in used if i in annotations},recipes
