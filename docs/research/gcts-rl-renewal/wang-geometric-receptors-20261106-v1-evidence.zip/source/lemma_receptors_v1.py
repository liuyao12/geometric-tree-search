"""Extract checked resolution clusters and fit them to typed clause receptors."""

from collections import Counter, defaultdict
from dataclasses import dataclass


def signed(mapping, lit):
    return mapping[abs(lit)] if lit > 0 else -mapping[-lit]


def ordered(row):
    return tuple(sorted(row, key=lambda lit: (abs(lit), lit < 0)))


@dataclass(frozen=True)
class Pattern:
    types: tuple
    leaves: tuple
    steps: tuple


def ancestors(proof, node):
    leaves = len(proof["premises"])
    pending = [node]
    visited = set()
    while pending:
        i = pending.pop()
        if i in visited:
            continue
        visited.add(i)
        if i >= leaves:
            step = proof["proof"][i - leaves]
            pending.extend((step["left"], step["right"]))
    return sorted(visited)


def extract(proof, types, low, high):
    base = proof["premises"]
    count = len(base)
    rows = [*base, *(s["clause"] for s in proof["proof"])]
    for root in range(count, len(rows)):
        support = ancestors(proof, root)
        leaves = [i for i in support if i < count]
        steps = [i for i in support if i >= count]
        if not low <= len(steps) <= high or not rows[root]:
            continue
        positions = {i: j for j, i in enumerate(support)}
        mapping = {}
        for i in leaves:
            for lit in ordered(rows[i]):
                mapping.setdefault(abs(lit), len(mapping) + 1)
        interfaces = tuple(ordered(signed(mapping, lit) for lit in rows[i]) for i in leaves)
        recipe = []
        for i in steps:
            s = proof["proof"][i - count]
            recipe.append((positions[s["left"]], positions[s["right"]], mapping[s["pivot"]],
                           ordered(signed(mapping, lit) for lit in rows[i])))
        yield Pattern(tuple(types[i - 1] for i in mapping), interfaces, tuple(recipe)), root


def atom_types(problem, atoms):
    return tuple((name.startswith("="), tuple(problem["predicates"].get(name, (name[1:],) * 2)))
                 for name, *_ in atoms)


@dataclass(frozen=True)
class Offer:
    pattern: int
    leaves: tuple
    steps: tuple
    mapping: tuple

    @property
    def result(self):
        return self.steps[-1][3]


def shape(row, types):
    return tuple(sorted((lit > 0, types[abs(lit) - 1]) for lit in row))


def fit(patterns, bank, target_types, max_trials, max_offers):
    buckets = defaultdict(list)
    for row in sorted(bank):
        buckets[shape(row, target_types)].append(row)
    offers = {}
    trials = 0
    complete = True
    for i, pattern in enumerate(patterns):
        candidates = [buckets[shape(row, pattern.types)] for row in pattern.leaves]
        if not all(candidates):
            continue
        order = sorted(range(len(candidates)), key=lambda j: (len(candidates[j]), j))

        def bind_receptors(at, mapping, used):
            nonlocal trials, complete
            if at == len(order):
                leaves = tuple(ordered(signed(mapping, lit) for lit in row) for row in pattern.leaves)
                steps = tuple((a, b, mapping[p], ordered(signed(mapping, lit) for lit in row))
                              for a, b, p, row in pattern.steps)
                offer = Offer(i, leaves, steps, tuple(mapping[j] for j in range(1, len(mapping) + 1)))
                if offer.result not in bank:
                    offers.setdefault((offer.result, tuple(sorted(leaves))), offer)
                return
            receptor = order[at]

            def bind_literals(lits, remaining, env, assigned):
                nonlocal trials, complete
                if not lits:
                    bind_receptors(at + 1, env, assigned)
                    return
                lit, *rest = lits
                for v in remaining:
                    if trials >= max_trials or len(offers) >= max_offers:
                        complete = False
                        return
                    trials += 1
                    if (lit > 0) != (v > 0) or pattern.types[abs(lit) - 1] != target_types[abs(v) - 1]:
                        continue
                    a, b = abs(lit), abs(v)
                    current = env.get(a)
                    if current is not None and current != b or current is None and b in assigned:
                        continue
                    bind_literals(rest, tuple(x for x in remaining if x != v),
                                  env if current else {**env, a: b}, assigned | {b})
                    if not complete:
                        return

            for target in candidates[receptor]:
                bind_literals(pattern.leaves[receptor], target, mapping, used)
                if not complete:
                    break

        bind_receptors(0, {}, set())
        if not complete:
            break
    return list(offers.values()), dict(trials=trials, complete=complete, offers=len(offers))


def verify(offer, bank):
    rows = [frozenset(row) for row in offer.leaves]
    if any(ordered(row) not in bank for row in rows):
        return False
    for a, b, p, expected in offer.steps:
        if not (0 <= a < len(rows) and 0 <= b < len(rows) and p > 0):
            return False
        if p not in rows[a] or -p not in rows[b]:
            return False
        joined = (rows[a] - {p}) | (rows[b] - {-p})
        if joined != frozenset(expected) or any(-lit in joined for lit in joined):
            return False
        rows.append(joined)
    return bool(offer.steps)
