"""Extract and transport a replayable forbidden pair with a directed receptor."""

from itertools import pairwise

import check_v1 as checker
import model_v1 as model
from envelope_v1 import domains, pair_cuts, prove
from propagated_cuts_v1 import Replay


def move(p, turn, offset):
    return model.add(model.rotate(p, turn), offset)


def tile_move(tile, turn, offset):
    return tuple(sorted(move(p, turn, offset) for p in tile))


def canonical(port, seeds):
    a, b = port
    turn = model.DIRECTIONS.index(model.sub(b, a))
    offset = model.rotate(model.sub(model.ZERO, a), -turn)
    return tuple(sorted(tile_move(tile, -turn, offset) for tile in seeds))


def guards(port, seeds, options):
    assert len(seeds) == 2 and checker.contact(*seeds)
    assert set(options) <= set(domains((), (port,))[("port", *port)])
    blockers = {}
    for tile in options:
        failures = tuple(i for i, seed in enumerate(seeds)
                         if tile != seed and not checker.contact(tile, seed))
        if not failures:
            return None
        blockers[tile] = failures
    return blockers


def learn(boundary, seeds, solver):
    learned = {}
    trials = []
    for port in pairwise((*boundary, boundary[0])):
        available = domains((), (port,))[("port", *port)]
        all_tiles = tuple(sorted(set(seeds) | set(available)))
        ids = {t: i for i, t in enumerate(all_tiles, 1)}
        base = [tuple(ids[t] for t in available), *pair_cuts(all_tiles)]
        yes, cuts = prove(base, solver, [ids[t] for t in seeds])
        trials.append(dict(port=port, status="POSITIVE" if yes else "NEGATIVE"))
        if yes:
            continue
        assert cuts == [()]
        singles = [prove(base, solver, (ids[t],)) for t in seeds]
        assert all(yes for yes, _ in singles)
        blockers = guards(port, seeds, available)
        assert blockers is not None
        # The portable certificate uses only the receptor and its blocking contacts.
        core = [tuple(ids[t] for t in available)]
        core.extend((-ids[t], -ids[seeds[i]]) for t, rows in blockers.items() for i in rows)
        cut = tuple(-ids[t] for t in seeds)
        assert Replay(core).refute(cut)
        key = canonical(port, seeds)
        learned.setdefault(key, dict(port=port, seeds=seeds, tiles=all_tiles,
            core=core, cut=cut, witnesses=[[all_tiles[i-1] for i in result] for _, result in singles],
            blockers=list(blockers.items())))
    assert learned
    return learned, trials


def transfer(world, templates):
    cuts, records = {}, []
    ids = world["ids"]
    for key, allowed in world["domains"].items():
        if key[0] != "port":
            continue
        _, a, b = key
        turn = model.DIRECTIONS.index(model.sub(b, a))
        for pattern in templates:
            seeds = tuple(tile_move(t, turn, a) for t in pattern)
            if not all(t in ids for t in seeds):
                continue
            blockers = guards((a, b), seeds, allowed)
            assert blockers is not None
            cut = tuple(sorted(-ids[t] for t in seeds))
            if cut in world["base_pairs"] or cut in cuts:
                continue
            local = [world["obligations"][key]]
            local.extend((-ids[t], -ids[seeds[i]]) for t, rows in blockers.items() for i in rows)
            assert Replay(local).refute(cut)
            cuts[cut] = (a, b)
            records.append(dict(port=(a, b), seeds=seeds, domain=allowed, local=local, cut=cut,
                                blockers=list(blockers.items())))
    return cuts, records
