"""Generate typed source instances in response to newly settled unit clauses."""

from collections import Counter, defaultdict, deque
from itertools import product

from in_grid_v1 import pattern_match


class Demand:
    def __init__(self, schemas, terms, predicates, cap):
        self.schemas = schemas
        self.terms = terms
        self.domains = {s:set(xs) for s,xs in terms.items()}
        self.predicates = predicates
        self.cap = cap
        self.counts = Counter()
        self.known = {}
        self.rows = []
        self.reasons = []
        self.facts = defaultdict(dict)
        self.queue = deque()
        self.triggers = defaultdict(list)
        self.instances = set()
        self.root = None
        self.bounded = False
        for i, schema in enumerate(schemas):
            clause = schema["clause"]
            for head in range(len(clause)):
                for trigger, (positive, term) in enumerate(clause):
                    if head != trigger:
                        self.triggers[not positive, term[0]].append((i, head, trigger))

    def insert(self, row, reason):
        if row not in self.known:
            self.known[row] = len(self.rows)
            self.rows.append(row)
            self.reasons.append(reason)
        return self.known[row]

    def resolve(self, a, b, pivot):
        left,right = self.rows[a],self.rows[b]
        assert (True,pivot) in left and (False,pivot) in right
        row = (left - {(True,pivot)}) | (right - {(False,pivot)})
        return self.insert(row,("resolve",a,b,pivot))

    def unit(self, node):
        row = self.rows[node]
        if not row:
            self.root = node
            return
        (sign, atom), = row
        bucket = self.facts[sign,atom[0]]
        if atom not in bucket:
            bucket[atom] = node
            self.queue.append((sign, atom))
            self.counts["units"] += 1
        opposite = self.facts[not sign,atom[0]].get(atom)
        if opposite is not None:
            left,right = (node,opposite) if sign else (opposite,node)
            self.root = self.resolve(left,right,atom)

    def check_budget(self):
        if self.counts["bindings"] + self.counts["candidate_instances"] >= self.cap:
            self.bounded = True
        return self.root is not None or self.bounded

    def unify(self, schema, pattern, atom, env):
        self.counts["bindings"] += 1
        new = env.copy()
        if all(pattern_match(p,t,new) for p,t in zip(pattern[1:],atom[1:],strict=True)) and all(
                value in self.domains[schema["variables"][v]] for v,value in new.items()):
            return new
        return None

    def instantiate(self, index, head, env):
        schema = self.schemas[index]
        order = tuple(sorted(schema["variables"]))
        remaining = tuple(v for v in order if v not in env)
        for items in product(*(self.terms[schema["variables"][v]] for v in remaining)):
            if self.check_budget():
                return
            self.counts["candidate_instances"] += 1
            bound = {**env, **dict(zip(remaining,items,strict=True))}
            key = (index, tuple(bound[v] for v in order))
            if key in self.instances:
                continue

            def ground(t):
                return bound[t] if isinstance(t,str) else (t[0],*map(ground,t[1:]))

            literals = [(sign,ground(t)) for sign,t in schema["clause"]]
            if any(any(t not in self.domains[s] for t,s in zip(atom[1:],self.predicates[atom[0]],strict=True))
                   for _,atom in literals):
                continue
            row = frozenset(literals)
            if any((not positive,atom) in row for positive,atom in row):
                continue
            target = literals[head] if head is not None else None
            blockers = sorted(row - {target})
            if any(atom not in self.facts[not sign,atom[0]] for sign,atom in blockers):
                continue
            self.instances.add(key)
            if target is not None and target[1] in self.facts[target[0],target[1][0]]:
                continue
            self.counts["admitted_instances"] += 1
            node = self.insert(row,("source",schema["id"],bound))
            for sign,atom in blockers:
                unit = self.facts[not sign,atom[0]][atom]
                a,b = (node,unit) if sign else (unit,node)
                node = self.resolve(a,b,atom)
            self.unit(node)

    def join(self, i, head, blockers, env):
        if self.check_budget():
            return
        if not blockers:
            self.instantiate(i,head,env)
            return
        schema = self.schemas[i]
        raw = schema["clause"]
        k = min(blockers,key=lambda j:len(self.facts[not raw[j][0],raw[j][1][0]]))
        sign,pattern = raw[k]
        pending = tuple(j for j in blockers if j != k)
        # Same-polarity literals of the same predicate may coincide with the
        # surviving literal after substitution. The exact row check decides.
        if (sign,pattern[0]) == (raw[head][0],raw[head][1][0]):
            self.join(i,head,pending,env)
        for atom in tuple(self.facts[not sign,pattern[0]]):
            if self.check_budget():
                return
            binding = self.unify(schema,pattern,atom,env)
            if binding is not None:
                self.join(i,head,pending,binding)

    def run(self):
        for i,schema in enumerate(self.schemas):
            literals = schema["clause"]
            if len({(sign,t[0]) for sign,t in literals}) <= 1:
                self.instantiate(i,0 if literals else None,{})
        while self.queue and not self.check_budget():
            sign,atom = self.queue.popleft()
            self.counts["events"] += 1
            for i,head,trigger in self.triggers[sign,atom[0]]:
                if self.check_budget():
                    break
                schema = self.schemas[i]
                binding = self.unify(schema,schema["clause"][trigger][1],atom,{})
                if binding is not None:
                    rest = tuple(k for k in range(len(schema["clause"])) if k not in (head,trigger))
                    self.join(i,head,rest,binding)
        return "REFUTED" if self.root is not None else "BOUNDED" if self.bounded else "UNIT_FIXED_POINT"

    def proof(self):
        pending = [self.root]
        used = set()
        while pending:
            node = pending.pop()
            if node in used:
                continue
            used.add(node)
            rule = self.reasons[node]
            if rule[0] == "resolve":
                pending.extend(rule[1:3])
        source = sorted(n for n in used if self.reasons[n][0] == "source")
        steps = sorted(used - set(source))
        atoms = sorted({atom for n in used for _,atom in self.rows[n]})
        ids = {a:i+1 for i,a in enumerate(atoms)}
        indices = {n:i for i,n in enumerate(source + steps)}

        def literals(n):
            row = self.rows[n]
            return [ids[a] for a in atoms if (True,a) in row] + [-ids[a] for a in atoms if (False,a) in row]

        return dict(atoms=atoms, origins=[dict(schema=self.reasons[n][1],substitution=self.reasons[n][2]) for n in source],
                    premises=[literals(n) for n in source],
                    proof=[dict(left=indices[self.reasons[n][1]],right=indices[self.reasons[n][2]],
                                pivot=ids[self.reasons[n][3]],clause=literals(n)) for n in steps])
