"""Transfer candidate proof-boundary cuts between successor theorem rectangles."""

from copy import deepcopy
import json
from pathlib import Path
import random
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from propagated_cuts_v1 import CutSearch, Replay
from open_wang_v1 import clauses, decode, layout, prop


def import_cuts(cnf, donor_names, recipient_ids, marks):
    replay=Replay(cnf)
    seen=set()
    accepted=[]
    missing=rejected=0
    for mark in marks:
        try:
            translated=tuple(sorted((recipient_ids[donor_names[abs(l)]]*(1 if l>0 else -1)
                                    for l in mark["clause"]),key=abs))
        except KeyError:
            missing+=1
            continue
        if translated in seen:
            continue
        seen.add(translated)
        if replay.refute(translated):
            replay.add(translated)
            accepted.append(translated)
        else:
            rejected+=1
    return accepted,dict(missing=missing,rejected=rejected,accepted=len(accepted))


def main():
    protocol=prop.load("transfer-protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    inherited=prop.load("protocol-v1.json")
    original,=[r for r in prop.load("input/new-cases-v1.json") if r["id"]=="peano-nonzero-successor"]
    donor,=[r for r in prop.load("data/propagation-results-v1.json") if r["id"]==original["id"]]
    base,_,_,_,_=layout(original,donor["boundary"],inherited)
    assert prop.wang.digest(base)==donor["circuit_sha256"]
    marks=next(r["marks"] for r in donor["results"] if r["mode"]=="propagate")
    names={i:r["name"] for i,r in enumerate(base["inputs"],1)}
    palette=prop.wang.palette()
    results=[]
    for depth in protocol["depths"]:
        problem=deepcopy(original)
        problem["id"]=f"peano-successor-{depth}"
        t=["zero"]
        for _ in range(depth):
            t=["S",t]
        problem["goal"]=["not",["atom","=Nat",t,["zero"]]]
        bound=dict(depth=depth,premises=2,resolutions=1)
        c,fixed,prefix,fields,functions=layout(problem,bound,inherited)
        cnf=clauses(c,fixed)
        targets={r["name"]:i for i,r in enumerate(c["inputs"],1) if i-1 not in fixed and r["value"] is None}
        learned,counts=import_cuts(cnf,names,targets,marks)
        shuffled=list(targets.values())
        random.Random(protocol["seed"]+depth).shuffle(shuffled)
        sham,sham_counts=import_cuts(cnf,names,dict(zip(targets,shuffled,strict=True)),marks)
        output=[]
        for mode,cuts,stats in (("cold",[],{}),("mapped",learned,counts),("shuffled",sham,sham_counts)):
            start=time.perf_counter()
            s=CutSearch(cnf,len(c["inputs"])+len(c["gates"]),len(c["inputs"]),
                        protocol["limits"],True)
            s.ordered.extend(cuts)
            s.nogoods.update(cuts)
            status,bits=s.run()
            sec=time.perf_counter()-start
            replay=Replay(cnf)
            for cut in s.ordered:
                assert replay.refute(cut)
                replay.add(cut)
            proof=None
            if status=="SAT":
                proof=decode(bits,prefix,fields,functions)
                rect=prop.wang.certificate(c,bits,palette)
                assert prop.independent_wang.verify(c,rect,palette)["status"]=="VERIFIED"
            output.append(dict(mode=mode,status=status,stats=dict(s.stats),import_counts=stats,
                               seed_cuts=cuts,certified_cuts=s.ordered,seconds=sec,proof=proof))
        results.append(dict(id=problem["id"],gates=len(c["gates"]),methods=output))
        print(json.dumps(dict(id=problem["id"],modes={r["mode"]:(r["status"],r["stats"],r["import_counts"])
                   for r in output}),sort_keys=True),flush=True)
    prop.save("data/transfer-v1.json",results)


if __name__=="__main__":
    main()
