"""Qualify schema-to-schema attachments without a prepared ground bank."""

from dataclasses import asdict
from itertools import product
import json
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from atom_slice_v1 import slice_proof
from context_experiment_v1 import tree
from in_grid_v1 import Prefix
from lifted_experiment_v1 import certificate,lookup
from lifted_recipe_v1 import Recipe,unify,verify
from lifted_search_v1 import expand,run
from schematic_receivers_v1 import align
from serial_blocks_v1 import catalog,prop


def main():
    plan=prop.load("schematic-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    former=prop.load("data/lifted-v1.json")
    recipes=[Recipe(*(tree(r[k]) for k in ("types","leaves","steps"))) for r in former["recipes"]]
    rules=prop.load("lifted-protocol-v1.json")
    palette=prop.wang.palette()
    reports=[]
    for case in former["cases"]:
        name=case["id"]
        source,normal,(functions,predicates,schemas)=lookup(case["source"],rules["normalization"])
        terms=fol.ground_terms(normal,functions,0,rules["term_limit"])
        atoms=sorted((p,*ts) for p,sorts in predicates.items() for ts in product(*(terms[s] for s in sorts)))
        begin=time.monotonic()
        offers,leaves,alignments,counts=align(recipes,schemas,functions,terms,atoms,plan["match"])
        match_seconds=time.monotonic()-begin
        assert all(verify(o,leaves) for o in offers)
        fol.verify_instances(schemas,list(leaves.values()),[prop.literals(r) for r in leaves],atoms,functions)
        if "Line" in terms:
            assert not unify(("?v",),(terms["Line"][0],),{},{"?v":"Point"},functions)
        r=run(schemas,terms,atoms,offers,"demand",rules["search"])
        assert r["status"]==next(v["status"] for v in case["results"] if v["mode"]=="cold")
        out=dict(id=name,source=case["source"],status=r["status"],counts=counts,search=r["counts"],
                 activated=len(r["active"]),rounds=r["turns"],alignments=alignments,
                 time=dict(matching=match_seconds,search=r["seconds"]),primitive_leaves=len(leaves),
                 placements=[asdict(o) for o in offers])
        if r["status"]=="REFUTED":
            (origins,premises,proof),contributors,used=expand(r,leaves)
            fol.verify_instances(schemas,origins,premises,atoms,functions)
            prop.verify_resolution(premises,proof)
            out["proof"]=slice_proof(dict(atoms=atoms,origins=origins,premises=premises,proof=proof))
            out["used_outputs"]=[asdict(o) for o in sorted(used,key=repr)]
            if name in plan["export"]:
                out["rectangle"],out["rectangle_file"]=certificate(
                    source,functions,schemas,terms,out["proof"],palette,f"{name}-schematic")
        # Exhaustive grounding is used after discovery as an independent audit.
        full=catalog(Prefix(schemas,terms,atoms,[],[]))
        assert leaves.keys()<=full.keys()
        found={(o.result,tuple(sorted(o.leaves))) for o in offers if prop.mask(o.result) not in full}
        control={(tuple(o["steps"][-1][3]),tuple(sorted(map(tuple,o["leaves"])))) for o in case["offers"]}
        assert found<=control
        out["comparison"]=dict(shared=len(found),reference=len(control),missing=len(control-found),
                               existing_source_outputs=len(offers)-len(found))
        if r["status"]=="GROUND_MODEL":
            truth={i if v else -i for i,v in enumerate(r["model"],1)}
            assert all(truth.intersection(prop.literals(row)) for row in full)
        print(json.dumps(dict(id=name,outcome=out["status"],match=counts,comparison=out["comparison"],
                              decisions=out["search"].get("decisions",0),activated=out["activated"],
                              used=len(out.get("used_outputs",())),verified="rectangle" in out),
                         sort_keys=True),flush=True)
        reports.append(out)
    prop.save("data/schematic-v1.json",reports)


if __name__=="__main__":
    main()
