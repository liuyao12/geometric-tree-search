"""Check a supplied resolution route without dynamic selection circuits."""

import fixed_palette_v1 as wang
from resolution_v1 import mask


def compile_route(n, premises, proof):
    assert type(n) is int and n >= 1 and proof
    assert all(type(v) is int and 1 <= abs(v) <= n
               for clause in (*premises, *(row["clause"] for row in proof)) for v in clause)
    inputs = [dict(name="zero",value=0),dict(name="one",value=1)]
    bits = [0,1]
    fields = []
    for i,row in enumerate(proof):
        claims = []
        for label,value in zip(("positive","negative"),mask(row["clause"]),strict=True):
            start = len(inputs)
            inputs.extend(dict(name=f"line{i}:{label}:{k}",value=None) for k in range(n))
            bits.extend((value>>k)&1 for k in range(n))
            claims.append(list(range(start,start+n)))
        fields.append(claims)
    builder = wang.Builder(inputs)
    known = [tuple(builder.const_word(x,n) for x in mask(c)) for c in premises]
    checks = []
    for row,(cp,cn) in zip(proof,fields,strict=True):
        l,r,p = row["left"],row["right"],row["pivot"]-1
        assert all(type(x) is int for x in (l,r,row["pivot"]))
        assert 0<=l<len(known) and 0<=r<len(known) and 0<=p<n
        lp,ln = known[l]
        rp,rn = known[r]
        checks.extend((lp[p],rn[p]))
        for k in range(n):
            positive = rp[k] if k==p else builder.OR(lp[k],rp[k])
            negative = ln[k] if k==p else builder.OR(ln[k],rn[k])
            checks.extend((builder.EQ(cp[k],positive),builder.EQ(cn[k],negative),
                           builder.NOT(builder.AND(cp[k],cn[k]))))
        known.append((cp,cn))
    checks.extend(builder.NOT(x) for row in known[-1] for x in row)
    return builder.finish(builder.all(checks)),bits,fields
