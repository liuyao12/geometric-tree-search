"""Compare checked clause moves with eager and proof-only materialization."""

import json
from pathlib import Path
import random
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from context_experiment_v1 import tree
from lazy_lemmas_v1 import LazySearch
from lemma_receptors_v1 import Offer, ordered, verify
from lemma_search_v1 import Search
from marked_lemma_pilot_v1 import audit
from transfer_experiment_v1 import catalog, compile_case, decode, prop, replay_logic
from wired_replay_v1 import Source, compile_wired


def main():
    plan = prop.load("lazy-protocol-v1.json")
    assert prop.pin(Path(sys.executable)) == plan["runtime"]
    assert all(prop.pin(Path(k)) == p for k, p in plan["pins"].items())
    config = prop.load("protocol-v1.json")
    inputs = {r["id"]: r for r in prop.load("input/new-cases-v1.json")}
    output = []
    for case in prop.load("prior/context-v1.json"):
        name = case["id"]
        _, _, prefix, _, fn = compile_case(inputs[name], dict(depth=0, premises=2, resolutions=1), config)
        admitted = {row: o for row, o in catalog(prefix).items() if not row[0] & row[1]}
        lib = next(lib for lib in case["libraries"] if lib["library"] == "two-layer")
        offers = [Offer(**{k:tree(v) for k,v in o.items()}) for o in lib["offers"]]
        bank = {ordered(prop.literals(r)) for r in admitted}
        start = time.monotonic()
        assert all(verify(o, bank) for o in offers)
        validation = dict(steps=sum(len(o.steps) for o in offers), seconds=time.monotonic() - start)
        runs = []
        for mode in ("seeded", "receptor"):
            for kernel in (Search, LazySearch):
                s = kernel(admitted, offers, mode, plan["limits"], rng=random.Random(0), marking=True)
                status, root = s.run()
                elapsed = time.monotonic() - s.started
                checked = audit(s)
                record = dict(mode=mode, kernel=kernel.__name__, status=status, stats=dict(s.stats),
                              seconds=elapsed, checked=checked)
                if root is not None:
                    if kernel is LazySearch:
                        (origins, premises, proof), proof_work = s.expand_proof(root)
                        record["proof_work"] = proof_work
                    else:
                        origins, premises, proof = s.d.support(root, admitted)
                    replay_logic(premises, proof, admitted)
                    record["proof"] = dict(origins=origins, premises=premises, proof=proof, atoms=prefix.atoms)
                    if kernel is LazySearch and mode == "receptor" and name in plan["certificates"]:
                        p = Source(inputs[name])
                        p.clauses(config["cnf_limit"])
                        prefix.origins, prefix.premises, prefix.rows = origins, premises, []
                        circuit, bits, fields = compile_wired(prefix, p, proof)
                        assert decode(bits, prefix, fields, fn) == record["proof"]
                        palette = prop.wang.palette()
                        cert = prop.wang.certificate(circuit, bits, palette)
                        record["rectangle"] = prop.independent_wang.verify(circuit, cert, palette)
                        assert record["rectangle"]["status"] == "VERIFIED"
                        prop.compressed(f"data/{name}-lazy-wang-v1.json.gz", dict(circuit=circuit, certificate=cert))
                runs.append(record)
        output.append(dict(id=name, library_validation=validation, results=runs))
        print(json.dumps(dict(id=name,validation=validation, runs=[(r["mode"],r["kernel"],r["status"],
                    r["stats"].get("pairs",0),r["stats"].get("macro_replays",0),r.get("proof_work",{}),
                    r.get("rectangle",{}).get("status")) for r in runs]),sort_keys=True),flush=True)
    prop.save("data/lazy-v1.json", output)


if __name__ == "__main__":
    main()
