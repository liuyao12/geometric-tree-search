"""Treat verified lemma outputs as single moves until a proof uses them."""

from ground_control_v1 import Derivation
from lemma_search_v1 import Search


class LazySearch(Search):
    def __init__(self, admitted, *args, **kwargs):
        self.admitted = admitted
        self.claims = {}
        super().__init__(admitted, *args, **kwargs)

    def place(self, offer):
        result = frozenset(offer.result)
        self.stats["activated"] += 1
        if result not in self.d.known:
            node = len(self.d.clauses)
            self.d.known[result] = node
            self.d.clauses.append(result)
            self.claims[node] = offer
            self.macro[node] = offer
            self.stats["inserted_claims"] += 1
        self.enqueue(self.d.known[result])

    def expand_proof(self, root):
        expanded = Derivation(self.admitted)
        resolved = {i: i for i in range(len(expanded.premises))}
        replays = used = 0

        def open_node(i):
            nonlocal replays, used
            if i in resolved:
                return resolved[i]
            if i in self.claims:
                offer = self.claims[i]
                indices = [expanded.known[frozenset(row)] for row in offer.leaves]
                for a, b, p, row in offer.steps:
                    j = expanded.add_resolution(indices[a], indices[b], p)
                    assert expanded.clauses[j] == frozenset(row)
                    indices.append(j)
                    replays += 1
                used += 1
                j = indices[-1]
            else:
                a, b, p = self.d.steps[i]
                j = expanded.add_resolution(open_node(a), open_node(b), p)
            assert expanded.clauses[j] == self.d.clauses[i]
            resolved[i] = j
            return j

        out = open_node(root)
        return expanded.support(out, self.admitted), {"used_claims":used, "proof_replays":replays}
