"""Exact Turtle point authoring and periodic boundary-arrangement carrier.

No markings, tiling witness, polygon predicate in a search engine, or old
scientific imports. Geometry authors the finite point data and qualifies it.
All computational coordinates are rational axial coordinates.
"""
from fractions import Fraction as F
from itertools import permutations
from math import gcd,lcm

CAPACITY=12
RAYS=((1,0),(3,1),(1,1),(0,1),(-1,1),(-3,1),(-1,0),(-3,-1),(-1,-1),(0,-1),(1,-1),(3,-1))

def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area2(poly):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(poly,poly[1:]+poly[:1]))
def edges(poly):return zip(poly,poly[1:]+poly[:1])
def on_segment(p,a,b):return cross(a,b,p)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
def inside(p,poly):
    winding=0
    for a,b in edges(poly):
        if on_segment(p,a,b):return False
        if a[1]<=p[1]<b[1] and cross(a,b,p)>0:winding+=1
        elif b[1]<=p[1]<a[1] and cross(a,b,p)<0:winding-=1
    return winding!=0

def primitive(a,b):
    k=gcd(abs(a),abs(b));assert k
    a,b=a//k,b//k
    return (-a,-b) if a<0 or a==0 and b<0 else (a,b)

def groups():
    result=[]
    for sign in (1,-1):
        for perm in permutations(range(3)):
            def apply(x,y):
                v=(x,y,-x-y);return sign*v[perm[0]],sign*v[perm[1]]
            p,q=apply(1,0),apply(0,1)
            result.append(dict(id=len(result),permutation=list(perm),sign=sign,matrix=[[p[0],q[0]],[p[1],q[1]]]))
    return result

def transform(point,matrix):
    x,y=point;return matrix[0][0]*x+matrix[0][1]*y,matrix[1][0]*x+matrix[1][1]*y
def transform_poly(poly,matrix):return [transform(p,matrix) for p in poly]
def moved(poly,shift):return [(x+shift[0],y+shift[1]) for x,y in poly]
def matrix_product(a,b):return [[sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2)] for i in range(2)]

def group_checks(gs):
    matrices=[g['matrix'] for g in gs];assert len({tuple(sum(m,[])) for m in matrices})==12
    def norm(p):return p[0]*p[0]+p[0]*p[1]+p[1]*p[1]
    for m in matrices:
        assert abs(m[0][0]*m[1][1]-m[0][1]*m[1][0])==1
        assert all(norm(transform(p,m))==norm(p) for p in ((1,0),(0,1),(1,1)))
        assert any(matrix_product(m,n)==[[1,0],[0,1]] for n in matrices)
        assert all(matrix_product(m,n) in matrices for n in matrices)
    return dict(elements=12,integer_unimodular=True,A2_metric_preserved=True,closure_and_inverses=True)

def ray(v):
    u,w=2*v[0]+v[1],v[1];k=gcd(abs(u),abs(w));assert k
    return RAYS.index((u//k,w//k))

def vertex_units(poly):
    orientation=1 if area2(poly)>0 else -1;assert area2(poly)!=0
    units=[]
    for i,p in enumerate(poly):
        prev,nxt=poly[i-1],poly[(i+1)%len(poly)]
        incoming=ray((prev[0]-p[0],prev[1]-p[1]));outgoing=ray((nxt[0]-p[0],nxt[1]-p[1]))
        value=(orientation*(incoming-outgoing))%12;assert 0<value<12
        units.append(value)
    return units

def angular_field(poly):
    assert all(type(x) is int and type(y) is int for x,y in poly)
    vertices=dict(zip(poly,vertex_units(poly)));field={}
    for x in range(min(p[0] for p in poly),max(p[0] for p in poly)+1):
        for y in range(min(p[1] for p in poly),max(p[1] for p in poly)+1):
            p=x,y
            value=vertices.get(p)
            if value is None:value=6 if any(on_segment(p,a,b) for a,b in edges(poly)) else 12 if inside(p,poly) else 0
            if value:field[p]=value
    return field

def clean_convex(poly):
    points=[]
    for p in poly:
        p=tuple(p)
        if not points or p!=points[-1]:points.append(p)
    if len(points)>1 and points[0]==points[-1]:points.pop()
    changed=True
    while changed and len(points)>2:
        changed=False
        for i,p in enumerate(points):
            if cross(points[i-1],p,points[(i+1)%len(points)])==0:
                del points[i];changed=True;break
    if len(points)<3 or area2(points)==0:return ()
    if area2(points)<0:points.reverse()
    start=min(range(len(points)),key=lambda i:points[i])
    return tuple(points[start:]+points[:start])

def clip(poly,a,b,k,side):
    result=[]
    for prev,cur in edges(list(poly)):
        fp=side*(a*prev[0]+b*prev[1]-k);fc=side*(a*cur[0]+b*cur[1]-k)
        if (fp>=0)!=(fc>=0):
            t=F(fp,fp-fc);result.append((prev[0]+t*(cur[0]-prev[0]),prev[1]+t*(cur[1]-prev[1])))
        if fc>=0:result.append(cur)
    return clean_convex(result)

def normal_action(n,m):
    a,b=m[0];c,d=m[1];det=a*d-b*c
    return primitive((n[0]*d-n[1]*c)//det,(-n[0]*b+n[1]*a)//det)

def arrangement(poly,gs):
    normals={(1,0),(0,1)}
    for g in gs:
        transformed=transform_poly(poly,g['matrix'])
        for a,b in edges(transformed):normals.add(primitive(b[1]-a[1],a[0]-b[0]))
    # Include the complete orbit of grid-wall normals before square clipping.
    normals={normal_action(n,g['matrix']) for n in normals for g in gs}
    assert all(normal_action(n,g['matrix']) in normals for n in normals for g in gs)
    cells=[((F(0),F(0)),(F(1),F(0)),(F(1),F(1)),(F(0),F(1)))]
    cuts=[]
    for a,b in sorted(normals):
        values=(0,a,b,a+b)
        for k in range(min(values)+1,max(values)):
            cuts.append([a,b,k]);next_cells=[]
            for cell in cells:
                for side in (-1,1):
                    part=clip(cell,a,b,k,side)
                    if part:next_cells.append(part)
            cells=sorted(set(next_cells));assert len(cells)<=4096
    assert sum(area2(list(cell)) for cell in cells)==2
    samples=[(sum(p[0] for p in cell)/len(cell),sum(p[1] for p in cell)/len(cell)) for cell in cells]
    assert len(set(samples))==len(samples)
    assert all(0<x<1 and 0<y<1 for x,y in samples)
    assert all((a*x+b*y).denominator!=1 for a,b in normals for x,y in samples)
    scale=lcm(*(v.denominator for p in samples for v in p))
    residues=[(int(x*scale),int(y*scale)) for x,y in samples]
    actions=[]
    for g in gs:
        permutation=[];shifts=[]
        for p in samples:
            x,y=transform(p,g['matrix']);ix,iy=x//1,y//1;reduced=x-ix,y-iy
            assert reduced in samples
            permutation.append(samples.index(reduced));shifts.append([int(ix),int(iy)])
        assert len(set(permutation))==len(samples)
        actions.append(dict(group=g['id'],sample_permutation=permutation,integer_shifts=shifts))
    occupancy={}
    for x in range(min(p[0] for p in poly),max(p[0] for p in poly)):
        for y in range(min(p[1] for p in poly),max(p[1] for p in poly)):
            for q in samples:
                p=q[0]+x,q[1]+y
                if inside(p,poly):occupancy[int(p[0]*scale),int(p[1]*scale)]=12
    angular={(x*scale,y*scale):u for (x,y),u in angular_field(poly).items()}
    assert not set(angular).intersection(occupancy)
    return dict(normals=sorted(normals),cuts=cuts,cells=cells,samples=samples,scale=scale,residues=residues,
                group_actions=actions,occupancy=occupancy,angular=angular,combined={**angular,**occupancy})

def excess(a,b,shift=(0,0),scale=1):
    dx,dy=shift[0]*scale,shift[1]*scale;bad=[]
    for (x,y),u in b.items():
        p=x+dx,y+dy;total=a.get(p,0)+u
        if total>12:bad.append([p[0],p[1],total])
    return sorted(bad)

def field_rows(field):return [[x,y,u] for (x,y),u in sorted(field.items())]
def encode_point(p):return [[F(v).numerator,F(v).denominator] for v in p]
def encode_poly(poly):return [encode_point(p) for p in poly]
def canonical_polygon(poly):
    # The corner cleanup also preserves concave vertices: only collinear
    # consecutive entries are removed. Simple-boundary validation is separate.
    return clean_convex(poly)
