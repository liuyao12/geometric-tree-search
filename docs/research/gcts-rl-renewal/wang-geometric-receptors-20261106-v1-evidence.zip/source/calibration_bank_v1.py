"""Write a deterministic bank whose positive controls require decisions."""

import hashlib
from itertools import combinations
import json
from pathlib import Path
import sys


def neg(lit):
    return "not", lit


def atom(name):
    return "atom", name, ("a",)


def disjunction(*lits):
    result = lits[-1]
    for item in reversed(lits[:-1]):
        result = "or", item, result
    return result


def colored(nodes, closed):
    p = [atom(f"color{i}") for i in range(nodes)]
    edges = list(zip(p[:-1], p[1:], strict=True))
    if closed:
        edges.append((p[-1], p[0]))
    return [(u, v) for u, v in edges] + [(neg(u), neg(v)) for u, v in edges]


def pigeon(pigeons, holes):
    v = [[atom(f"pigeon{p}hole{h}") for h in range(holes)] for p in range(pigeons)]
    return v + [(neg(v[a][h]), neg(v[b][h])) for h in range(holes)
                for a, b in combinations(range(pigeons), 2)]


def case(name, family, clauses, theorem):
    symbols = sorted({(lit[1] if lit[0] == "atom" else lit[1][1]) for row in clauses for lit in row})
    guard = atom("claim")
    return dict(id=name, sorts=["U"], functions={"a": [[], "U"]},
                predicates={n: ["U"] for n in [*symbols, "claim"]}, equality=False,
                premises=[disjunction(guard, *row) for row in clauses], goal=guard,
                calibration=dict(family=family, expected="REFUTED" if theorem else "GROUND_MODEL"))


def put(path, payload):
    with Path(path).open("x") as stream:
        stream.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def pin(path):
    data = Path(path).read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    cases = []
    for size in (3, 5, 7):
        cases.extend((
            case(f"odd-cycle-{size}", "two-coloring", colored(size, True), True),
            case(f"broken-cycle-{size}", "two-coloring", colored(size, False), False),
        ))
    for holes in (2, 3):
        cases.extend((
            case(f"pigeonhole-{holes + 1}-{holes}", "pigeonhole", pigeon(holes + 1, holes), True),
            case(f"pigeonhole-{holes}-{holes}", "pigeonhole", pigeon(holes, holes), False),
        ))
    # Preserve the source bank unchanged and add cases in the file used for
    # additional input. The ground harness only runs the explicit new schedule.
    original = Path("input/new-cases-v1.json")
    original.rename(original.with_name("new-cases-at-parent-v1.json"))
    put(original, cases)
    protocol = json.loads(Path("protocol-at-parent-v1.json").read_bytes())
    protocol["benchmark"] = [dict(id=r["id"], depth=0, premises=2, resolutions=1) for r in cases]
    put("protocol-v1.json", protocol)
    inputs = [*sorted(Path("source").glob("*.py")), *sorted(Path("input").glob("*.json")), Path("protocol-v1.json")]
    put("ground-control-protocol-v1.json", dict(
        schema="Wang-nonunit-calibration-ground-control-v1", conflicts=12000, rows_cap=36,
        runtime=pin(sys.executable), pins={str(path): pin(path) for path in inputs},
        scope="Every condition is guarded by the same target atom. The opposite target reveals a standard odd-cycle or pigeonhole instance. Positive and negative cases use the same finite ground depth. The initial rectangle is only a way to obtain the typed admission bank. The learned proof size determines the checked rectangle."))


if __name__ == "__main__":
    main()
