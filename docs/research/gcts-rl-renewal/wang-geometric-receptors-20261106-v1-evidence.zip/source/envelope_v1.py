"""Exact directed edge and full vertex obligations in a convex envelope."""

from collections import Counter
from itertools import combinations, pairwise
from math import log1p

import check_v1 as checker
import model_v1 as model
from penrose_polygon_v1 import cross, inside
from propagated_cuts_v1 import Replay


def domains(vertices, ports):
    required = {}
    for p in vertices:
        local = model.incident(p)
        assert checker.corners(p) == local
        for sector in range(10):
            required[("sector", p, sector)] = tuple(sorted(t for t, mask in local.items() if mask & (1 << sector)))
    for a, b in ports:
        ray = model.sub(b, a)
        assert ray in model.DIRECTIONS
        tiles = tuple(sorted(t for t in model.incident(a) if b in t and
                             all(model.sign(*cross(ray, model.sub(p, a))) >= 0 for p in t)))
        direction = checker.minus(b, a)
        independent = tuple(sorted(t for t in checker.corners(a) if b in t and
                                   all(checker.order(checker.imaginary_normal(direction, checker.minus(p, a)), (0, 0)) >= 0 for p in t)))
        assert tiles == independent and len(tiles) == 4
        required[("port", a, b)] = tiles
    return required


def contains(poly, tile):
    primary = all(inside(poly, p) for p in tile)
    independent = all(checker.order(checker.imaginary_normal(checker.minus(b, a), checker.minus(p, a)), (0, 0)) >= 0
                      for a, b in pairwise((*poly, poly[0])) for p in tile)
    assert primary == independent
    return primary


def compile_world(vertices, ports, envelope, seeds=()):
    if envelope:
        for a, b in pairwise((*envelope, envelope[0])):
            assert all(checker.order(checker.imaginary_normal(checker.minus(b, a), checker.minus(p, a)), (0, 0)) > 0
                       for p in envelope if p not in (a, b))
    original = domains(vertices, ports)
    allowed = {t: not envelope or contains(envelope, t)
               for t in {t for values in original.values() for t in values} | set(seeds)}
    required = {key: tuple(t for t in values if allowed[t]) for key, values in original.items()}
    tiles = tuple(sorted({t for values in required.values() for t in values} | set(seeds)))
    ids = {t: i for i, t in enumerate(tiles, 1)}
    main = {key: tuple(ids[t] for t in values) for key, values in required.items()}
    primary = tuple(dict.fromkeys(main.values()))
    exclusivity = {(-i, -j) for clause in primary for i, j in combinations(clause, 2)}
    seed_cuts = [(ids[t],) for t in seeds] + [(-ids[t],) for t in seeds if not allowed[t]]
    incidence = Counter(i for clause in primary for i in clause)
    seed_points = {p for t in seeds for p in t}
    features = {i: (log1p(incidence[i])/5, len(set(t).intersection(vertices))/4,
                    len(set(t) & seed_points)/4, 1.) for t, i in ids.items()}
    return dict(tiles=tiles, ids=ids, domains=required, raw=original, obligations=main,
                seed_cuts=seed_cuts, clauses=list(primary)+sorted(exclusivity)+seed_cuts,
                primary=primary, target=vertices, seeds=seeds, features=features, base_pairs=exclusivity)


def pair_cuts(tiles):
    for (i, a), (j, b) in combinations(enumerate(tiles, 1), 2):
        if not model.legal_contact(a, b):
            assert not checker.contact(a, b)
            yield (-i, -j)
        else:
            assert checker.contact(a, b)


def validate(world, selected, envelope, seeds):
    assert set(seeds) <= selected
    assert not envelope or all(contains(envelope, t) for t in selected)
    assert all(checker.contact(a, b) for a, b in combinations(sorted(selected), 2))
    assert all(len(selected.intersection(values)) == 1 for values in world["raw"].values())


def prove(cnf, solver, assumptions=()):
    base = [*cnf, *((v,) for v in assumptions)]
    with solver(name="glucose4", bootstrap_with=base, with_proof=True) as oracle:
        if oracle.solve():
            return True, [v for v in oracle.get_model() if v > 0]
        cuts = [tuple(map(int, line.split()[:-1])) for line in oracle.get_proof() if not line.startswith("d")]
    if not cuts or cuts[-1]:
        cuts.append(())
    replay = Replay(base)
    for cut in cuts:
        assert replay.refute(cut), cut
        replay.add(cut)
    return False, cuts
