"""Compile exact cyclotomic sectors and learn geometric cuts from models."""

from collections import Counter
import hashlib
import math
import random
import time
from itertools import combinations

from backjump_v1 import BoundarySearch
from propagated_cuts_v1 import Replay
import check_v1 as independent
import model_v1 as model


def geometry(target,seeds):
    target=tuple(sorted(set(target)))
    incident={p:model.incident(p) for p in target}
    tiles=tuple(sorted({t for xs in incident.values() for t in xs}|set(seeds)))
    ids={t:i for i,t in enumerate(tiles,1)}
    primary={}
    negative=set()
    extent=Counter()
    for p,star in incident.items():
        for j in range(10):
            clause=tuple(sorted(ids[t] for t,mask in star.items() if mask&(1<<j)))
            assert clause
            primary.setdefault(clause,(p,j))
            negative.update((-a,-b) for a,b in combinations(clause,2))
            extent.update(clause)
    for p in target:
        assert independent.corners(p)==incident[p]
    cnf=list(primary)+sorted(negative)+[(ids[t],) for t in seeds]
    nodes={v:(math.log1p(extent[v])/5, sum(p in target for p in t)/4,
              len(set(t)&{p for s in seeds for p in s})/4, len(t)/4)
           for t,v in ids.items()}
    return dict(target=target,seeds=tuple(seeds),tiles=tiles,ids=ids,clauses=cnf,primary=tuple(primary),
                features=nodes,base_pairs=negative)


def rotated_pair(a,b):
    return {model.pair_key(tuple(sorted(model.rotate(p,k) for p in a)),
                           tuple(sorted(model.rotate(p,k) for p in b)),model.ZERO) for k in range(10)}


def split(rows):
    trained=set()
    holdouts={}
    for row in rows:
        if row["status"]!="NEGATIVE":
            continue
        a,b=row["root"],row["other"]
        independent.replay(row,a,b)
        turns=rotated_pair(a,b)
        orbit=min(turns)
        digest=hashlib.sha256(repr(orbit).encode()).digest()
        if int.from_bytes(digest[:2],"big")%3:
            trained.update(turns)
        else:
            holdouts.setdefault(orbit,(a,b))
    assert trained and holdouts
    assert all(not trained.intersection(rotated_pair(a,b)) for a,b in holdouts.values())
    return trained,list(holdouts.values())


def transfer(world,rules):
    ids=world["ids"]
    cuts={}
    for a,b,witness in sorted(rules):
        for point in world["target"]:
            offset=model.sub(point,witness)
            x=tuple(model.add(p,offset) for p in a)
            y=tuple(model.add(p,offset) for p in b)
            if x in ids and y in ids:
                i,j=sorted((ids[x],ids[y]))
                clause=(-i,-j)
                if clause not in world["base_pairs"]:
                    cuts.setdefault(clause,point)
    return cuts


class GeometrySearch(BoundarySearch):
    def __init__(self,cnf,world,limits,weights,rng=None,randomized=False):
        size=len(world["tiles"])
        super().__init__(cnf,size,size,limits,"activity",[dict(name="tile")]*size)
        self.primary=world["primary"]
        self.shape=world["features"]
        self.geometry_weights=weights
        self.randomized=randomized
        self.rng=rng
        self.gradients=[]
        self.place=False

    def choose(self):
        options=None
        for clause in self.primary:
            if any(self.val[v]>0 for v in clause):
                continue
            available=[v for v in clause if self.val[v]==0]
            assert available
            if options is None or len(available)<len(options):
                options=available
        self.place=options is not None
        if not self.place:
            return next((v for v in self.order if not self.val[v]),None)
        options=sorted(options)
        if self.randomized:
            return self.rng.choice(options)
        features=[(*self.shape[v][:3],math.log1p(self.signal[v]),v/max(1,self.inputs)) for v in options]
        scores=[sum(w*x for w,x in zip(self.geometry_weights,f,strict=True)) for f in features]
        if self.rng is None or len(options)==1:
            return options[scores.index(max(scores))]
        peak=max(scores)
        probs=[math.exp(v-peak) for v in scores]
        i=self.rng.choices(range(len(options)),weights=probs)[0]
        total=sum(probs)
        self.gradients.append([f-sum(p*x[j] for p,x in zip(probs,features,strict=True))/total
                               for j,f in enumerate(features[i])])
        return options[i]

    def branch(self,v):
        return v if self.place else -v


def verify_witness(world,indices):
    selected=[world["tiles"][i-1] for i in indices]
    assert set(world["seeds"])<=set(selected)
    assert all(independent.contact(a,b) for a,b in combinations(selected,2))
    for p in world["target"]:
        occupied=0
        for tile in selected:
            mask=independent.corners(p).get(tile,0)
            assert not occupied&mask
            occupied|=mask
        assert occupied==model.FULL
    return selected


def replay(cnf,cuts):
    checked=Replay(cnf)
    for c in cuts:
        assert checked.refute(c),c
        checked.add(c)


def solve(world,known,limits,weights,*,rng=None,randomized=False,solver=None,audit=True):
    learned=[]
    geometric={}
    gradients=[]
    counts=Counter()
    initial=world["clauses"]+list(known)
    status="BOUNDED"
    proof=None
    start=time.monotonic()
    for _ in range(limits["rounds"]):
        if time.monotonic()-start>=limits["seconds"]:
            break
        cnf=[*initial,*geometric,*learned]
        if solver is None:
            search=GeometrySearch(cnf,world,limits["sat"],weights,rng,randomized)
            outcome,bits=search.run()
            cuts=search.ordered
            gradients.extend(search.gradients)
            counts.update(search.stats)
        else:
            with solver(name="glucose4",bootstrap_with=cnf,with_proof=True) as s:
                s.conf_budget(limits["sat"]["marks"])
                answer=s.solve_limited()
                outcome={True:"SAT",False:"UNSAT",None:"BOUNDED"}[answer]
                counts.update(s.accum_stats())
                bitset=set(s.get_model()) if answer is True else set()
                bits=[int(v in bitset) for v in range(1,len(world["tiles"])+1)] if answer is True else None
                cuts=[tuple(map(int,line.split()[:-1])) for line in s.get_proof() if not line.startswith("d")] if answer is False else []
                if answer is False and (not cuts or cuts[-1]):
                    cuts.append(())
        if audit and cuts:
            replay(cnf,cuts)
        learned.extend(cuts)
        if outcome=="UNSAT":
            assert learned and not learned[-1]
            status="NEGATIVE"
            break
        if outcome=="BOUNDED":
            break
        counts["models"]+=1
        selected=[i for i,x in enumerate(bits,1) if x]
        rejects=[]
        for i,j in combinations(selected,2):
            a,b=world["tiles"][i-1],world["tiles"][j-1]
            counts["contact_tests"]+=1
            if not model.legal_contact(a,b):
                assert not independent.contact(a,b)
                rejects.append((-i,-j))
                if len(rejects)==limits["batch"]:
                    break
        if not rejects:
            proof=verify_witness(world,selected)
            status="POSITIVE"
            break
        for row in rejects:
            assert row not in geometric and row not in known and row not in world["base_pairs"]
            geometric[row]=counts["models"]
    return dict(status=status,counts=dict(counts),witness=proof,geometry=[(c,r) for c,r in geometric.items()],
                cuts=learned,warm=[(c,p) for c,p in known.items()],seconds=time.monotonic()-start,
                gradients=gradients)
