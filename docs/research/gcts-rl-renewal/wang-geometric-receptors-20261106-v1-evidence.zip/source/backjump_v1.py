"""Backjump using cuts on assigned Wang boundary columns."""

from collections import Counter
import heapq
import math
import time

from open_wang_v1 import Search


class BoundarySearch(Search):
    def __init__(self,cnf,count,inputs,limits,mode,fields,weights=None,rng=None):
        super().__init__(cnf,count,inputs,limits,True)
        self.mode=mode
        self.fields=fields
        self.cut_index={}
        self.positions={}
        self.levels=[0]*(count+1)
        self.trail_limits=[]
        self.signal=Counter()
        self.activity_unit=1.0
        self.weights=weights
        self.rng=rng
        self.trace=[]
        self.branch_rank={x:i for i,x in enumerate(self.order)}

    def set(self,l,reason):
        v=abs(l)
        if not self.val[v]:
            self.levels[v]=len(self.trail_limits)
        return super().set(l,reason)

    def back_level(self,level):
        if len(self.trail_limits)>level:
            self.back(self.trail_limits[level])
            del self.trail_limits[level:]

    def analyze(self,conflict):
        nodes=[abs(l) for l in self.cnf[conflict]]
        seen=set()
        leaves=[]
        while nodes:
            v=nodes.pop()
            if v in seen:
                continue
            seen.add(v)
            cause=self.reason[v]
            if cause is None:
                assert v<=self.inputs and self.levels[v]>0
                leaves.append(-self.val[v]*v)
            else:
                nodes.extend(abs(l) for l in self.cnf[cause] if abs(l)!=v)
        return tuple(sorted(leaves,key=lambda l:self.levels[abs(l)],reverse=True))

    def learn(self,cut):
        assert cut and cut not in self.cut_index
        i=len(self.cnf)
        self.cut_index[cut]=i
        self.cnf.append(cut)
        self.ordered.append(cut)
        if len(cut)==1:
            self.pairs.append(None)
        else:
            self.pairs.append([0,1])
            self.watches[cut[0]].append(i)
            self.watches[cut[1]].append(i)
        return i

    def features(self,v):
        label=self.fields[v-1]["name"]
        base=1-self.branch_rank[v]/max(1,self.inputs)
        activity=math.log1p(self.signal[v]/max(1,self.activity_unit))
        role=label.split(":")[1] if ":" in label else ""
        return (base,activity, float(role=="schema"),float(role.startswith("term")),
                float(role in ("left","right","pivot")),
                float(role in ("positive","negative")),v/max(1,self.inputs))

    def choose(self):
        candidates=[v for v in self.order if not self.val[v]]
        if not candidates:
            return None
        if self.mode=="static":
            return candidates[0]
        def key(v):
            return self.signal[v],-self.branch_rank[v]
        if self.mode=="activity":
            return max(candidates,key=key)
        assert self.mode=="learned" and self.weights is not None
        choices=heapq.nlargest(24,candidates,key=key)
        features=[self.features(v) for v in choices]
        scores=[sum(w*x for w,x in zip(self.weights,f,strict=True)) for f in features]
        if self.rng is None or len(scores)==1:
            return choices[max(range(len(scores)),key=lambda i:(scores[i],-i))]
        peak=max(scores)
        probs=[math.exp(s-peak) for s in scores]
        pick=self.rng.choices(range(len(scores)),weights=probs,k=1)[0]
        mass=sum(probs)
        average=[sum(p*f[i] for p,f in zip(probs,features,strict=True))/mass
                 for i in range(len(self.weights))]
        self.trace.append([a-b for a,b in zip(features[pick],average,strict=True)])
        return choices[pick]

    def branch(self,v):
        return -v

    def run(self):
        for l,i in self.units:
            if not self.set(l,i):
                return "UNSAT",None
        while True:
            if self.stats["decisions"]>=self.limits["nodes"] or time.monotonic()>=self.deadline:
                return "BOUNDED",None
            conflict=self.propagate()
            if conflict is not None:
                self.stats["conflicts"]+=1
                cut=self.analyze(conflict)
                if not cut:
                    self.ordered.append(())
                    return "UNSAT",None
                if len(self.ordered)>=self.limits["marks"]:
                    return "BOUNDED",None
                self.activity_unit*=1.025
                for l in cut:
                    self.signal[abs(l)]+=self.activity_unit
                level=self.levels[abs(cut[1])] if len(cut)>1 else 0
                self.stats["skipped_levels"]+=len(self.trail_limits)-level-1
                self.back_level(level)
                i=self.learn(cut)
                assert all(self.value(l)<0 for l in cut[1:]) and not self.val[abs(cut[0])]
                assert self.set(cut[0],i)
                continue
            v=self.choose()
            if v is None:
                assert all(any(self.value(l)>0 for l in c) for c in self.cnf)
                return "SAT",[int(x>0) for x in self.val[1:self.inputs+1]]
            self.stats["decisions"]+=1
            self.trail_limits.append(len(self.trail))
            assert self.set(self.branch(v),None)
