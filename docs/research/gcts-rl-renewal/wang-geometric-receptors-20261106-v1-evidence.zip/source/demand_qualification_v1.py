"""Compare lazy joins and unit closure against exhaustive typed grounding."""

from itertools import product
from pathlib import Path
import random
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from demand_ground_v1 import Demand
from model_ground_v1 import Instantiator
from serial_blocks_v1 import prop


def fixtures(rng):
    u=[("a",),("b",),("f",("a",)),("f",("b",))]
    v=[("c",),("d",)]
    terms={"U":u,"V":v}
    predicates={"P":("U",),"Q":("U","V"),"R":("V","V"),"S":("U","U")}
    definitions=[]
    for i in range(rng.randrange(4,12)):
        vars={"?x":"U","?y":"U","?z":"V"}
        choices={"U":[*u,"?x","?y",("f","?x")],"V":[*v,"?z"]}
        clause=[]
        for _ in range(rng.randrange(1,5)):
            name=rng.choice(tuple(predicates))
            atom=(name,*(rng.choice(choices[s]) for s in predicates[name]))
            clause.append((bool(rng.randrange(2)),atom))
        definitions.append(dict(id=str(i),variables=vars,clause=clause))
    return definitions,terms,predicates


def exhaustive(schemas,terms,predicates):
    clauses=set()
    for s in schemas:
        names=sorted(s["variables"])
        for values in product(*(terms[s["variables"][v]] for v in names)):
            env=dict(zip(names,values,strict=True))

            def bind(t):
                return env[t] if isinstance(t,str) else (t[0],*(bind(x) for x in t[1:]))

            row=frozenset((polarity,bind(term)) for polarity,term in s["clause"])
            if all(all(t in terms[sort] for t,sort in zip(a[1:],predicates[a[0]],strict=True))
                   for _,a in row):
                clauses.add(row)
    return clauses


def full_units(clauses):
    fixed=set()
    while True:
        added=set()
        for row in clauses:
            if fixed & row:
                continue
            unknown=[(s,a) for s,a in row if (not s,a) not in fixed]
            if not unknown:
                return "REFUTED",None
            if len(unknown)==1:
                added.update(unknown)
        if any((not sign,a) in added for sign,a in added):
            return "REFUTED",None
        if not added:
            return "UNIT_FIXED_POINT",fixed
        fixed.update(added)


def main():
    rng=random.Random(20261106)
    models=instances=0
    for _ in range(100):
        schemas,terms,predicates=fixtures(rng)
        atoms=sorted((p,*args) for p,sorts in predicates.items() for args in product(*(terms[s] for s in sorts)))
        ids={a:i+1 for i,a in enumerate(atoms)}
        bank=exhaustive(schemas,terms,predicates)
        expected,units=full_units(bank)
        demand=Demand(schemas,terms,predicates,1000000)
        assert demand.run()==expected
        if units is not None:
            assert units=={(s,a) for (s,_),bucket in demand.facts.items() for a in bucket}
        else:
            proof=demand.proof()
            prop.verify_resolution(proof["premises"],proof["proof"])
        for _ in range(4):
            bits=[rng.randrange(2) for a in atoms]
            truth={(bool(v),a) for a,v in zip(atoms,bits,strict=True)}
            expected={prop.mask(ids[a] if s else -ids[a] for s,a in row) for row in bank if not truth & row}
            lookup=Instantiator(schemas,terms,atoms,bits,1000000)
            assert set(lookup.find({},1000000))==expected and not lookup.bounded
            models+=1
            instances+=len(expected)
    prop.save("data/demand-qualification-v1.json",dict(status="PASS",typed_banks=100,models=models,
                                                      exact_violated_clauses=instances,seed=20261106))


if __name__=="__main__":
    main()
