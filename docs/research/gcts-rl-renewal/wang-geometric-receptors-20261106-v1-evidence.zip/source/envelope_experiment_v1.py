"""Compare plain and receptor-guided search under movable outer boundaries."""

import json
from pathlib import Path
import sys
from time import monotonic

sys.path.insert(0, str(Path(__file__).resolve().parent))
import model_v1 as model
from edge_receptor_v1 import learn, move, tile_move, transfer
from envelope_v1 import compile_world, validate
from learn_v1 import pin, read, save, verify
from penrose_lazy_experiment_v1 import evidence, exact
from penrose_sat_v1 import solve


def hull(x0, y0, x1, y1):
    return ((x0, y0, 0, 0), (x1, y0, 0, 0), (x1, y1, 0, 0), (x0, y1, 0, 0))


def cohort(boundary, seeds):
    zero = model.ZERO
    port = (zero, model.ONE)
    point = (1, 0, 0, -1)
    large = hull(-3, -3, 3, 3)
    yield "E01", "Original directed edge, free boundary", (), (port,), (), seeds, "NEGATIVE"
    yield "E02", "Turned copy, tight envelope", (), (port,), boundary, seeds, "NEGATIVE"
    yield "E03", "Larger envelope with a vertex target", (point,), (port,), large, seeds, "NEGATIVE"
    yield "E04", "Directed edge removed", (), (), large, seeds, "POSITIVE"
    yield "E05", "Directed edge reversed", (), (port[::-1],), large, seeds, "POSITIVE"
    yield "E06", "One seed with an optional competing rhomb", (point,), (port,), large, seeds[:1], "POSITIVE"
    yield "E07", "Smaller envelope clips placements", (point,), (port,), hull(-1, -1, 3, 3), seeds[:1], "POSITIVE"
    yield "E08", "Both placements optional", (point,), (port,), large, (), "POSITIVE"
    for side in (2, 3):
        points, ports, placed = [], [], []
        for x in range(side):
            for y in range(side):
                offset = (8*x, 8*y, 0, 0)
                turn = (3*x + 7*y) % 10
                points.append(move(point, turn, offset))
                ports.append(tuple(move(p, turn, offset) for p in port))
                placed.append(tile_move(seeds[0], turn, offset))
        yield (f"E{7+side:02d}", f"{side*side} rotated edge and vertex motifs", tuple(points), tuple(ports),
               hull(-4, -4, 8*side-4, 8*side-4), tuple(placed), "POSITIVE")


def run():
    plan = read("protocol-v1.json")
    verify(plan)
    dependency = Path(sys.argv[1])
    assert all(pin(dependency / name) == sha for name, sha in read("input/wang-protocol-v1.json")["pysat_files"].items())
    sys.path.insert(0, str(dependency))
    from pysat.solvers import Solver

    donor = read("input/polygon-pair-v1.json")
    boundary, seeds = exact(donor["boundary"]), exact(donor["seeds"])
    templates, attempts = learn(boundary, seeds, Solver)
    assert len(templates) == 1 and sum(row["status"] == "NEGATIVE" for row in attempts) == 2
    cases = []
    for (name, title, vertices, ports, hull_points, fixed, expected), (turn, offset) in zip(
            cohort(boundary, seeds), plan["motions"], strict=True):
        offset = tuple(offset)
        moved = lambda p: move(p, turn, offset)
        vertices = tuple(map(moved, vertices))
        ports = tuple(tuple(map(moved, edge)) for edge in ports)
        hull_points = tuple(map(moved, hull_points))
        fixed = tuple(tile_move(tile, turn, offset) for tile in fixed)
        started = monotonic()
        world = compile_world(vertices, ports, hull_points, fixed)
        known, receipts = transfer(world, templates)
        setup_seconds = monotonic()-started
        rows = []
        arms = [
            ("plain", {}, plan["initial"], None),
            ("marked", known, plan["initial"], None),
            ("learned", known, plan["learned"], None),
            ("glucose", {}, plan["initial"], Solver),
            ("glucose-marked", known, plan["initial"], Solver),
        ]
        for arm, marks, order, solver in arms:
            r = solve(world, marks, plan["budget"], order, solver=solver)
            assert r["status"] == expected, (name, arm, r["status"], expected)
            r.pop("gradients")
            if r["status"] == "POSITIVE":
                validate(world, set(r["witness"]), hull_points, fixed)
            assert evidence(world, r, marks)
            rows.append(dict(arm=arm, **r))
        print(json.dumps(dict(id=name, candidates=len(world["tiles"]), marks=len(known), expected=expected,
                             arms=[(r["arm"], r["counts"].get("decisions", 0), len(r["geometry"]),
                                    r["counts"].get("models", 0), round(r["seconds"], 4)) for r in rows])), flush=True)
        cases.append(dict(id=name, title=title, envelope=hull_points, vertices=vertices, ports=ports, seeds=fixed,
                          tiles=world["tiles"], cnf=world["clauses"], setup_seconds=setup_seconds,
                          marks=receipts, results=rows))
    save("data/envelope-v1.json", dict(status="CHECKED_MOVABLE_ENVELOPE", source=list(templates.values()),
                                     donor_trials=attempts, cases=cases))


if __name__ == "__main__":
    run()
