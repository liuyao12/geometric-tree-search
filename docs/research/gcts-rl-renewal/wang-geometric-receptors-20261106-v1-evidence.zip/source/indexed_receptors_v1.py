"""Fit clause receptors through signed-literal indexes and preserve extra context."""

from collections import Counter, defaultdict

from lemma_receptors_v1 import Offer, ordered, shape, signed, verify


def fit(patterns, bank, types, plan):
    context = plan["context"]
    by_shape = defaultdict(list)
    for row in sorted(bank):
        by_shape[shape(row, types)].append(row)
    counts_by_shape = {key: Counter(key) for key in by_shape}
    offers = {}
    work = Counter()
    complete = True

    for k, pattern in enumerate(patterns):
        buckets = []
        for receptor in pattern.leaves:
            sig = shape(receptor, pattern.types)
            if context == 0:
                choices = by_shape[sig]
            else:
                counts = Counter(sig)
                choices = [row for key, values in by_shape.items()
                           if len(sig) <= len(key) <= len(sig) + context and counts <= counts_by_shape[key]
                           for row in values]
            indexes = defaultdict(list)
            for row in choices:
                for lit in row:
                    indexes[lit].append(row)
            buckets.append((choices, indexes))
        if any(not choices for choices, _ in buckets):
            continue

        def emit(mapping, targets):
            leaves = tuple(targets[i] for i in range(len(pattern.leaves)))
            rows = list(map(set, leaves))
            steps = []
            for a, b, pivot, _ in pattern.steps:
                p = mapping[pivot]
                c = (rows[a] - {p}) | (rows[b] - {-p})
                if len(c) > plan["width_cap"] or any(-v in c for v in c):
                    work["rejected_recipes"] += 1
                    return
                rows.append(c)
                steps.append((a, b, p, ordered(c)))
            offer = Offer(k, leaves, tuple(steps), tuple(mapping[i] for i in range(1, len(mapping) + 1)))
            work["replayed_candidates"] += 1
            if offer.result not in bank:
                offers.setdefault((offer.result, tuple(sorted(leaves))), offer)

        def join(remaining, mapping, used, targets):
            nonlocal complete
            if not remaining:
                emit(mapping, targets)
                return
            bound = {i: tuple(signed(mapping, v) for v in pattern.leaves[i] if abs(v) in mapping)
                     for i in remaining}
            rows = {i: min((buckets[i][1].get(lit, ()) for lit in bound[i]), key=len, default=buckets[i][0])
                    for i in remaining}
            i = min(remaining, key=lambda j: (len(rows[j]), -len(bound[j]), j))
            needed = frozenset(bound[i])
            tail = tuple(j for j in remaining if j != i)
            todo = tuple(v for v in pattern.leaves[i] if abs(v) not in mapping)

            def bind(literals, pool, env, taken, row):
                nonlocal complete
                if not literals:
                    join(tail, env, taken, {**targets, i: row})
                    return
                lit, *rest = literals
                for candidate in pool:
                    if work["literal_trials"] >= plan["trials"] or len(offers) >= plan["offers"]:
                        complete = False
                        return
                    work["literal_trials"] += 1
                    key, value = abs(lit), abs(candidate)
                    if (lit > 0) != (candidate > 0) or pattern.types[key - 1] != types[value - 1]:
                        continue
                    previous = env.get(key)
                    if (previous is not None and previous != value) or (previous is None and value in taken):
                        continue
                    bind(rest, tuple(v for v in pool if v != candidate), {**env, key: value}, taken | {value}, row)
                    if not complete:
                        return

            for row in rows[i]:
                if work["row_trials"] >= plan["trials"] or len(offers) >= plan["offers"]:
                    complete = False
                    return
                work["row_trials"] += 1
                if needed.issubset(row):
                    bind(todo, tuple(v for v in row if v not in needed), mapping, used, row)
                if not complete:
                    return

        join(tuple(range(len(buckets))), {}, set(), {})
        if not complete:
            break
    return list(offers.values()), {**work, "offers": len(offers), "complete": complete}


def audit(offer, pattern, types, bank, max_context):
    mapping = {i + 1: value for i, value in enumerate(offer.mapping)}
    assert len(mapping) == len(pattern.types) == len(set(mapping.values()))
    assert tuple(types[i - 1] for i in offer.mapping) == pattern.types
    for abstract, row in zip(pattern.leaves, offer.leaves, strict=True):
        core = {signed(mapping, v) for v in abstract}
        assert core <= set(row) and len(row) - len(core) <= max_context
    for (a, b, pivot, row), (i, j, symbol, output) in zip(offer.steps, pattern.steps, strict=True):
        assert (a, b, pivot) == (i, j, mapping[symbol])
        assert {signed(mapping, v) for v in output} <= set(row)
    assert verify(offer, bank)


def compose(outer, seeds, bank):
    """Resolve a second-level cluster down to checked source interfaces."""
    recipes = [seeds[row] for row in outer.leaves if row not in bank]
    if not recipes:
        return None
    leaves = tuple(sorted({r for r in outer.leaves if r in bank} |
                          {row for offer in recipes for row in offer.leaves}))
    positions = {row: i for i, row in enumerate(leaves)}
    steps = []

    def append_recipe(offer):
        remap = [positions[row] for row in offer.leaves]
        for a, b, pivot, row in offer.steps:
            if row not in positions:
                positions[row] = len(leaves) + len(steps)
                steps.append((remap[a], remap[b], pivot, row))
            remap.append(positions[row])

    for seed in recipes:
        append_recipe(seed)
    append_recipe(outer)
    if not steps or steps[-1][3] != outer.result:
        return None
    result = Offer(outer.pattern, leaves, tuple(steps), outer.mapping)
    assert verify(result, bank)
    return result
