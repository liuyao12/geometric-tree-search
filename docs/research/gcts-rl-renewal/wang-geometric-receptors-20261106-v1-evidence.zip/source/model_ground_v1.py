"""Instantiate only source clauses violated by a finite candidate model."""

from collections import Counter, defaultdict
from itertools import product
import json
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from atom_slice_v1 import slice_proof
from backjump_v1 import BoundarySearch
from ground_marks_v1 import replay_cuts
from in_grid_v1 import Prefix, pattern_match
from origin_v1 import Source
from propagated_cuts_v1 import Replay
from serial_blocks_v1 import catalog, decode, prop
from wired_replay_v1 import compile_wired


class Instantiator:
    def __init__(self,schemas,terms,atoms,bits,max_probes):
        self.schemas=schemas
        self.terms=terms
        self.domains={s:set(xs) for s,xs in terms.items()}
        self.ids={atom:i+1 for i,atom in enumerate(atoms)}
        self.false=defaultdict(list)
        for atom,value in zip(atoms,bits,strict=True):
            self.false[not bool(value),atom[0]].append(atom)
        self.max_probes=max_probes
        self.probes=0
        self.bounded=False

    def find(self,already,limit):
        result={}
        for schema in self.schemas:
            if len(result)>=limit or self.bounded:
                break
            rows=sorted(schema["clause"],key=lambda lit:len(self.false[lit[0],lit[1][0]]))

            def join(i,env,literals):
                if len(result)>=limit or self.bounded:
                    return
                if i==len(rows):
                    row=prop.mask(literals)
                    if row in already or row in result:
                        return
                    variables=schema["variables"]
                    missing=sorted(set(variables)-env.keys())
                    for values in product(*(self.terms[variables[v]] for v in missing)):
                        result[row]=dict(schema=schema["id"],substitution={**env,**dict(zip(missing,values,strict=True))})
                        break
                    return
                sign,pattern=rows[i]
                for atom in self.false[sign,pattern[0]]:
                    if self.probes>=self.max_probes:
                        self.bounded=True
                        return
                    self.probes+=1
                    binding=env.copy()
                    if all(pattern_match(p,t,binding) for p,t in zip(pattern[1:],atom[1:],strict=True)) and all(
                            t in self.domains[schema["variables"][v]] for v,t in binding.items()):
                        n=self.ids[atom]
                        join(i+1,binding,(*literals,n if sign else -n))
                    if len(result)>=limit or self.bounded:
                        return
            join(0,{},())
        return result


def solve(schemas,terms,atoms,plan):
    bank={}
    cuts=[]
    rounds=[]
    status="BOUNDED"
    model=None
    counts=Counter()
    fields=[dict(name=atom[0]) for atom in atoms]
    for _ in range(plan["rounds"]):
        if counts["schema_probes"]>=plan["total_probes"]:
            break
        cnf=[tuple(prop.literals(r)) for r in bank]+cuts
        s=BoundarySearch(cnf,len(atoms),len(atoms),plan["sat_limits"],"activity",fields)
        result,bits=s.run()
        counts.update(s.stats)
        history=Replay([tuple(prop.literals(r)) for r in bank]+cuts)
        for cut in s.ordered:
            assert history.refute(cut)
            history.add(cut)
        cuts.extend(s.ordered)
        if result=="UNSAT":
            status="REFUTED"
            break
        if result=="BOUNDED":
            break
        ask=Instantiator(schemas,terms,atoms,bits,plan["max_probes"])
        rows=ask.find(bank,plan["batch"])
        counts["schema_probes"]+=ask.probes
        rounds.append(dict(admitted=len(rows),probes=ask.probes,checked_cuts=len(s.ordered),
                           capped=ask.bounded,source_origins=list(rows.values())))
        if not rows:
            if not ask.bounded:
                status="GROUND_MODEL"
                model=bits
            break
        bank.update(rows)
    return status,model,bank,cuts,rounds,dict(counts)


def main():
    plan=prop.load("model-ground-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    config=prop.load("protocol-v1.json")
    agatha=prop.load("prior/agatha-v1.json")["source"]
    generated=prop.load("prior/pigeonhole-model-input-v1.json")
    originals={r["id"]:r for r in [agatha,*generated,*prop.load("input/new-cases-at-parent-v1.json"),
                                  *prop.load("input/tutorial-cases-v1.json")["cases"]]}
    palette=prop.wang.palette()
    receipts=[]
    for name,depth,expected in plan["cases"]:
        source=Source(originals[name])
        normalized=source.clauses(config["cnf_limit"])
        functions,predicates,schemas=fol.signature(normalized)
        terms=fol.ground_terms(normalized,functions,depth,config["max_terms"])
        atoms=sorted((p,*ts) for p,sorts in predicates.items() for ts in product(*(terms[s] for s in sorts)))
        start=time.monotonic()
        status,model,bank,cuts,rounds,counts=solve(schemas,terms,atoms,plan)
        elapsed=time.monotonic()-start
        full=catalog(Prefix(schemas,terms,atoms,[],[]))
        assert bank.keys()<=full.keys()
        for row,o in bank.items():
            fol.verify_instances(schemas,[o],[prop.literals(row)],atoms,functions)
        assert status in {expected,"BOUNDED"}
        r=dict(id=name,depth=depth,status=status,seconds=elapsed,rounds=rounds,cuts=cuts,counts=counts,
               admitted=len(bank),full=len(full),model=model)
        if status=="GROUND_MODEL":
            true={i if bit else -i for i,bit in enumerate(model,1)}
            assert all(true.intersection(prop.literals(row)) for row in full)
        if status=="REFUTED":
            raw=replay_cuts(bank,[],cuts)
            assert raw is not None
            proof=slice_proof(dict(atoms=atoms,**raw))
            r["proof"]=proof
            if [name,depth] in plan["export"]:
                prefix=Prefix(schemas,terms,proof["atoms"],proof["origins"],proof["premises"])
                circuit,bits,fields=compile_wired(prefix,source,proof["proof"])
                assert decode(bits,prefix,fields,functions)==proof
                rect=prop.wang.certificate(circuit,bits,palette)
                r["rectangle"]=prop.independent_wang.verify(circuit,rect,palette)
                assert r["rectangle"]["status"]=="VERIFIED"
                path=f"data/{name}-d{depth}-model-ground-wang-v1.json.gz"
                prop.compressed(path,dict(circuit=circuit,certificate=rect))
                r["rectangle_file"]=path
        print(json.dumps(dict(id=name,depth=depth,status=status,rounds=len(rounds),admitted=len(bank),
                              full=len(full),cuts=len(cuts),steps=len(r.get("proof",{}).get("proof",[])),
                              verified="rectangle" in r),sort_keys=True),flush=True)
        receipts.append(r)
    prop.save("data/model-ground-v1.json",receipts)


if __name__=="__main__":
    main()
