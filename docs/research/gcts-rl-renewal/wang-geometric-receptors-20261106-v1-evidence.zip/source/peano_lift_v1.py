"""Discover a Peano donor, then apply its typed recipe to new successor terms."""

from dataclasses import asdict
from itertools import product
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from atom_slice_v1 import slice_proof
from ground_marks_v1 import replay_cuts
from in_grid_v1 import Prefix
from lifted_cases_v1 import atom
from lifted_experiment_v1 import certificate,lookup
from lifted_recipe_v1 import lift,unify,verify
from lifted_search_v1 import expand,run
from model_ground_v1 import solve
from schematic_receivers_v1 import align
from serial_blocks_v1 import catalog,prop


def successor(t,n=1):
    for _ in range(n):
        t=["S",t]
    return t


def eq(a,b):
    return atom("=Nat",a,b)


def source(n,donor=False,control=False):
    x,y="?x","?y"
    injectivity=["all",x,"Nat",["all",y,"Nat",["implies",eq(successor(x),successor(y)),eq(x,y)]]]
    a,b=[f"left{n}"],[f"right{n}"]
    premises=[injectivity]
    if donor:
        goal=["all",x,"Nat",["all",y,"Nat",["implies",eq(successor(x,n),successor(y,n)),eq(x,y)]]]
    else:
        if not control:
            premises.append(eq(successor(a,n),successor(b,n)))
        goal=eq(a,b)
    return dict(id="peano-iterated-injectivity-donor" if donor else f"peano-successor-injectivity-{n}"+("-control" if control else ""),
                sorts=["Nat"],predicates={},equality=True,
                functions={"S":[["Nat"],"Nat"],**({a[0]:[[],"Nat"],b[0]:[[],"Nat"]} if not donor else {})},
                premises=premises,goal=goal)


def compile_problem(original,depth,plan):
    s,case,(functions,predicates,schemas)=lookup(original,plan["normalization"])
    terms=fol.ground_terms(case,functions,depth,plan["terms"])
    atoms=sorted((p,*args) for p,sorts in predicates.items() for args in product(*(terms[t] for t in sorts)))
    return s,functions,schemas,terms,atoms


def main():
    plan=prop.load("peano-lift-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    donor=source(plan["donor_depth"],donor=True)
    src,functions,schemas,terms,atoms=compile_problem(donor,plan["donor_depth"],plan)
    result,_,bank,cuts,_,counts=solve(schemas,terms,atoms,plan["donor_search"])
    assert result=="REFUTED"
    donor_proof=slice_proof(dict(atoms=atoms,**replay_cuts(bank,[],cuts)))
    fol.verify_instances(schemas,donor_proof["origins"],donor_proof["premises"],donor_proof["atoms"],functions)
    recipes=list(lift(donor_proof,schemas,functions,plan["fragment"]))
    assert recipes and not unify(("?x",),(("S","?x"),),{},{"?x":"Nat"},functions)
    palette=prop.wang.palette()
    donor_check,donor_file=certificate(src,functions,schemas,terms,donor_proof,palette,donor["id"])
    results=[]
    for depth,control in plan["cases"]:
        original=source(depth,control=control)
        name=original["id"]
        src,functions,schemas,terms,atoms=compile_problem(original,depth,plan)
        offers,leaves,links,matching=align([r for _,r in recipes],schemas,functions,terms,atoms,plan["match"])
        assert all(verify(o,leaves) for o in offers)
        fol.verify_instances(schemas,list(leaves.values()),[prop.literals(r) for r in leaves],atoms,functions)
        modes=[]
        for mode in ("cold","demand","eager"):
            r=run(schemas,terms,atoms,offers if mode!="cold" else [],mode,plan["receiver_search"])
            assert r["status"]==("GROUND_MODEL" if control else "REFUTED")
            item=dict(mode=mode,status=r["status"],counts=r["counts"],admitted=len(r["source"]),
                      activated=len(r["active"]),cuts=len(r["cuts"]))
            if control:
                full=catalog(Prefix(schemas,terms,atoms,[],[]))
                truth={i if v else -i for i,v in enumerate(r["model"],1)}
                assert all(truth.intersection(prop.literals(row)) for row in full)
            else:
                (origins,premises,proof),_,used=expand(r,leaves)
                sliced=slice_proof(dict(atoms=atoms,origins=origins,premises=premises,proof=proof))
                fol.verify_instances(schemas,sliced["origins"],sliced["premises"],sliced["atoms"],functions)
                prop.verify_resolution(premises,proof)
                item.update(proof=sliced,used=[asdict(o) for o in sorted(used,key=repr)])
                if mode in plan["export"]:
                    item["rectangle"],item["rectangle_file"]=certificate(src,functions,schemas,terms,sliced,palette,f"{name}-{mode}")
            modes.append(item)
        print(json.dumps(dict(id=name,matching=matching,arms=[
            (r["mode"],r["status"],r["admitted"],r["counts"].get("decisions",0),len(r.get("used",())),
             r.get("rectangle",{}).get("status")) for r in modes]),sort_keys=True),flush=True)
        results.append(dict(id=name,source=original,matching=matching,alignments=links,results=modes))
    prop.save("data/peano-lift-v1.json",dict(donor=donor,donor_proof=donor_proof,
              donor_rectangle=donor_check,donor_rectangle_file=donor_file,donor_counts=counts,
              recipes=[dict(root=i,**asdict(r)) for i,r in recipes],cases=results))


if __name__=="__main__":
    main()
