"""Search for resolution proofs of independently reconstructed geometric cuts."""

from itertools import pairwise
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_v1 as geom
from fixed_route_v1 import compile_route
from penrose_lazy_experiment_v1 import exact
import resolution_v1 as logic


def reconstruct(port, envelope, seeds):
    a, b = port
    ray = geom.minus(b, a)
    assert ray in geom.RAYS and len(seeds) == 2 and geom.contact(*seeds)

    def left(p, start, direction):
        return geom.order(geom.imaginary_normal(direction, geom.minus(p, start)), (0, 0)) >= 0

    sides = [(p, geom.minus(q, p)) for p, q in pairwise((*envelope, envelope[0]))] if envelope else []
    assert not envelope or all(
        geom.order(geom.imaginary_normal(side, geom.minus(vertex, start)), (0, 0)) > 0
        for start, side in sides for vertex in envelope
        if vertex not in (start, geom.plus(start, side)))
    assert all(all(left(p, start, side) for p in tile for start, side in sides) for tile in seeds)
    options = tuple(sorted(t for t in geom.corners(a) if b in t and all(left(p, a, ray) for p in t)
                           and all(left(p, start, side) for p in t for start, side in sides)))
    names = tuple(sorted(set(options) | set(seeds)))
    indices = {tile:i for i,tile in enumerate(names,2)}
    # Variable 1 records the obligation to cover this oriented edge.
    cover = [-1, *[indices[t] for t in options]]
    clauses = [cover]
    for t in options:
        for s in seeds:
            if t != s and not geom.contact(t,s):
                clauses.append([-indices[t],-indices[s]])
    assumptions = [1, *[indices[t] for t in seeds]]
    return options, names, clauses, assumptions


def main():
    p = logic.load("protocol-v1.json")
    assert p["runtime"] == logic.pin(Path(sys.executable))
    assert all(logic.pin(logic.ROOT / name) == sha for name,sha in p["pins"].items())
    original = logic.load("input/envelope-v1.json")
    palette = logic.wang.palette()
    rows = []
    for c in original["cases"][:5]:
        if not c["ports"]:
            continue
        name = c["id"]
        port, envelope, seeds = exact(c["ports"][0]), exact(c["envelope"]), exact(c["seeds"])
        options, names, theory, hypotheses = reconstruct(port,envelope,seeds)
        if c["marks"]:
            source = c["marks"][0]
            assert options == exact(source["domain"])
            assert set(seeds) == set(exact(source["seeds"]))
        problem = [*theory, *[[v] for v in hypotheses]]
        results = {}
        for mode in ("PLAIN","MARKED","ELIMINATE"):
            search = logic.Search(problem,p["limits"],mode)
            status = search.eliminate(len(names)+1) if mode == "ELIMINATE" else search.given()
            assert status == ("UNSAT" if c["marks"] else "SAT")
            proof = search.proof() if status == "UNSAT" else None
            marks = logic.verify_marks(search)
            results[mode] = dict(status=status,proof=proof,marks=marks,cost=dict(search.counts))
        model = None
        artifact = None
        if c["marks"]:
            premises = [logic.literals(logic.mask(c)) for c in problem]
            proof = results["MARKED"]["proof"]
            logic.verify_resolution(premises,proof)
            circuit,bits,fields = logic.circuit(len(names)+1,premises,proof)
            cert = logic.wang.certificate(circuit,bits,palette)
            checked = logic.independent_wang.verify(circuit,cert,palette)
            assert checked["status"] == "VERIFIED"
            corrupt = bits[:]
            corrupt[fields[-1][3][0]] ^= 1
            assert logic.wang.evaluate(circuit,corrupt)[1] == 0
            assert options
            alternate, *_ = reconstruct(port[::-1],envelope,seeds)
            assert set(options) != set(alternate)
            filename = f"data/{name.lower()}-geometric-wang-v1.json.gz"
            logic.compressed(filename,dict(circuit=circuit,certificate=cert))
            artifact = dict(file=filename,**logic.pin(logic.ROOT / filename),receipt=checked,
                            rejected_mutation="Corrupt final resolvent bit")
            compact, compact_bits, compact_fields = compile_route(len(names)+1,premises,proof)
            compact_cert = logic.wang.certificate(compact,compact_bits,palette)
            compact_check = logic.independent_wang.verify(compact,compact_cert,palette)
            assert compact_check["status"] == "VERIFIED" and compact_check["cells"] < checked["cells"]
            flips = 0
            for positive,negative in compact_fields:
                for index in positive+negative:
                    altered = compact_bits[:]
                    altered[index] ^= 1
                    assert logic.wang.evaluate(compact,altered)[1] == 0
                    flips += 1
            wrong_route = [*proof[:-1],dict(proof[-1],pivot=1+proof[-1]["pivot"]%(len(names)+1))]
            forged, forged_bits, _ = compile_route(len(names)+1,premises,wrong_route)
            assert logic.wang.evaluate(forged,forged_bits)[1] == 0
            compact_name = f"data/{name.lower()}-geometric-wang-route-v1.json.gz"
            logic.compressed(compact_name,dict(circuit=compact,certificate=compact_cert))
            artifact["route"] = dict(file=compact_name,**logic.pin(logic.ROOT / compact_name),receipt=compact_check,
                                     rejected_single_bit_mutations=flips,rejected_wrong_final_pivot=True)
        else:
            model = logic.sat_control(len(names)+1,problem)
            chosen = [tile for tile,on in zip(names,model[1:],strict=True) if on]
            assert set(seeds) <= set(chosen) and len(set(options).intersection(chosen)) == 1
            assert all(geom.contact(a,b) for i,a in enumerate(chosen) for b in chosen[i+1:])
        rows.append(dict(id=name,port=port,envelope=envelope,seeds=seeds,options=options,atoms=names,
                         premises=problem,theory=theory,assumptions=hypotheses,
                         conclusion=[-v for v in hypotheses],results=results,model=model,artifact=artifact))
        print(json.dumps(dict(case=name,options=len(options),outcomes={k:v["status"] for k,v in results.items()},
                              steps=len(results["MARKED"]["proof"] or ()),checked=bool(artifact))),flush=True)
    assert len(rows)==4
    logic.save("data/geometry-wang-v1.json",dict(status="CHECKED_GEOMETRIC_MARK_IN_FIXED_WANG_PALETTE",
                                               palette=logic.wang.digest(palette),cases=rows))


if __name__ == "__main__":
    main()
