"""Use one diagonal term-depth and resource schedule for all sources."""

from itertools import product
import json
from math import prod
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from atom_slice_v1 import slice_proof
from ground_marks_v1 import replay_cuts
from in_grid_v1 import Prefix
from model_ground_v1 import solve
from origin_v1 import Source
from serial_blocks_v1 import catalog,decode,prop
from wired_replay_v1 import compile_wired


def windows(config):
    for stage in range(config["stages"]):
        for depth in range(stage+1):
            multiplier=1 << (stage-depth)
            yield stage,depth,multiplier


def main():
    plan=prop.load("fair-window-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    agatha=prop.load("prior/agatha-v1.json")["source"]
    inputs={r["id"]:r for r in [agatha,*prop.load("prior/pigeonhole-model-input-v1.json"),
                               *prop.load("input/cases-v1.json"),*prop.load("input/new-cases-at-parent-v1.json"),
                               *prop.load("input/tutorial-cases-v1.json")["cases"]]}
    palette=prop.wang.palette()
    reports=[]
    for name in plan["cases"]:
        source=Source(inputs[name])
        case=source.clauses(plan["normalization_cap"])
        functions,predicates,schemas=fol.signature(case)
        attempts=[]
        solved=None
        audited_models=set()
        for stage,depth,multiplier in windows(plan):
            window=dict(stage=stage,depth=depth,multiplier=multiplier)
            terms=fol.ground_terms(case,functions,depth,plan["terms"]*multiplier)
            if terms is None:
                attempts.append(dict(**window,status="TERM_CAP"))
                continue
            profile=tuple((s,tuple(terms[s])) for s in sorted(terms))
            if profile in audited_models:
                attempts.append(dict(**window,status="REUSED_GROUND_MODEL"))
                continue
            atom_count=sum(prod(len(terms[s]) for s in sorts) for sorts in predicates.values())
            if atom_count>plan["atoms"]*multiplier:
                attempts.append(dict(**window,status="ATOM_CAP",atoms=atom_count))
                continue
            atoms=sorted((name,*args) for name,sorts in predicates.items()
                         for args in product(*(terms[s] for s in sorts)))
            opts={**plan["base"],"rounds":plan["base"]["rounds"]*multiplier,
                  "max_probes":plan["base"]["max_probes"]*multiplier,
                  "total_probes":plan["base"]["total_probes"]*multiplier}
            opts["sat_limits"]={k:v*multiplier for k,v in plan["base"]["sat_limits"].items()}
            status,model,bank,cuts,rounds,counts=solve(schemas,terms,atoms,opts)
            attempts.append(dict(**window,status=status,atoms=len(atoms),admitted=len(bank),cuts=len(cuts),counts=counts))
            if status=="GROUND_MODEL":
                full=catalog(Prefix(schemas,terms,atoms,[],[]))
                truth={i if v else -i for i,v in enumerate(model,1)}
                assert all(truth.intersection(prop.literals(row)) for row in full)
                audited_models.add(profile)
            if status!="REFUTED":
                continue
            raw=replay_cuts(bank,[],cuts)
            assert raw is not None
            proof=slice_proof(dict(atoms=atoms,**raw))
            fol.verify_instances(schemas,proof["origins"],proof["premises"],proof["atoms"],functions)
            solved=dict(**window,proof=proof,cuts=cuts,source_rounds=rounds)
            if name in plan["export"]:
                prefix=Prefix(schemas,terms,proof["atoms"],proof["origins"],proof["premises"])
                c,bits,fields=compile_wired(prefix,source,proof["proof"])
                assert decode(bits,prefix,fields,functions)==proof
                cert=prop.wang.certificate(c,bits,palette)
                solved["rectangle"]=prop.independent_wang.verify(c,cert,palette)
                assert solved["rectangle"]["status"]=="VERIFIED"
                prop.compressed(f"data/{name}-fair-wang-v1.json.gz",dict(circuit=c,certificate=cert))
            break
        reports.append(dict(id=name,attempts=attempts,found=solved))
        print(json.dumps(dict(id=name,attempts=[(r["depth"],r["status"]) for r in attempts],
                              steps=len(solved["proof"]["proof"]) if solved else None,
                              verified=bool(solved and "rectangle" in solved)),sort_keys=True),flush=True)
    prop.save("data/fair-window-v1.json",reports)


if __name__=="__main__":
    main()
