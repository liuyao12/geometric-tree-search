"""Choose a tiling from typed hexagon recipes once macro boundaries are supplied."""

from collections import defaultdict
import json
from pathlib import Path
import sys
from time import monotonic

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_v1 as independent
import model_v1 as model
from edge_receptor_v1 import move, tile_move
from envelope_v1 import compile_world, validate
from learn_v1 import read, save, verify
from penrose_lazy_experiment_v1 import exact
from penrose_polygon_v1 import validate as check_full
from seam_experiment_v1 import compose


def alternatives(boundary, recipes, clusters, vertices, seeds):
    covers = defaultdict(dict)
    accepts = defaultdict(dict)
    tiles_by_choice = []
    for i, poly in enumerate(clusters):
        turn = model.DIRECTIONS.index(model.sub(poly[1], poly[0]))
        assert tuple(move(p, turn, poly[0]) for p in boundary) == poly
        choices = [tuple(tile_move(t, turn, poly[0]) for t in recipe) for recipe in recipes]
        tiles_by_choice.append(choices)
        local = defaultdict(lambda: [0] * len(choices))
        for j, choice in enumerate(choices):
            for tile in choice:
                accepts[tile][i] = accepts[tile].get(i, 0) | (1 << j)
                for p in tile:
                    local[p][j] |= independent.corners(p)[tile]
        for point, values in local.items():
            covers[point][i] = values

    allowed = [(1 << len(recipes))-1] * len(clusters)
    for p in vertices:
        used = 0
        for i, values in covers[p].items():
            required = 0
            for mask in values:
                required |= mask
            assert not used & required
            used |= required
            allowed[i] &= sum(1 << j for j, mask in enumerate(values) if mask == required)
        if used != model.FULL:
            return None
    for tile in seeds:
        sites = accepts[tile]
        if not sites:
            return None
        assert len(sites) == 1
        i, variants = next(iter(sites.items()))
        allowed[i] &= variants
    if not all(allowed):
        return None
    chosen = [(mask & -mask).bit_length()-1 for mask in allowed]
    selected = {t for i,j in enumerate(chosen) for t in tiles_by_choice[i][j]}
    assert len(selected) == sum(len(recipes[j]) for j in chosen)
    return chosen, allowed, selected


def main():
    plan = read("cluster-protocol-v1.json")
    verify(plan)
    donor = read("input/polygon-pair-v1.json")
    boundary, recipes = map(exact, (donor["boundary"], donor["witnesses"]))
    for recipe in recipes:
        check_full(boundary, recipe)
    results = []
    seam = read("data/seam-v1.json")
    requests = [(f"seam-{case['side']}", *(exact(case[k]) for k in
                ("clusters", "envelope", "targets", "ports", "seeds"))) for case in seam["cases"]]
    for side, stride, turn in plan["large"]:
        clusters, frame, vertices, ports, seeds, _ = compose(boundary, recipes, side, stride, turn)
        requests.append((f"sparse-{side}", clusters, frame, vertices[::3], ports, seeds))
    for name, clusters, frame, vertices, ports, seeds in requests:
        start = monotonic()
        chosen, masks, selected = alternatives(boundary, recipes, clusters, vertices, seeds)
        proposal_seconds = monotonic()-start
        world = compile_world(vertices, ports, frame, seeds)
        validate(world, selected, frame, seeds)
        checked_seconds = monotonic()-start
        stats = dict(case=name, tiles=len(selected), clusters=len(chosen), targets=len(vertices),
                     forced=sum(x.bit_count()==1 for x in masks), candidates=len(world["tiles"]),
                     proposal_seconds=proposal_seconds, checked_seconds=checked_seconds)
        print(json.dumps(stats,sort_keys=True),flush=True)
        results.append(dict(**stats, footprint=clusters, envelope=frame, vertices=vertices, ports=ports, seeds=seeds,
                            choices=chosen, domains=masks, witness=sorted(selected)))
    save("data/cluster-v1.json",dict(status="CHECKED_TYPED_MACRO_VARIANTS",cases=results))


if __name__=="__main__":
    main()
