"""Independently verify source truth tables and summarize the calibration."""

from collections import Counter
import hashlib
from itertools import product
import json
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_bytes())


def truth(node, valuation):
    operator, *args = node
    if operator == "atom":
        name, term = args
        assert term == ["a"]
        return valuation[name]
    if operator == "not":
        return not truth(args[0], valuation)
    assert operator == "or"
    return truth(args[0], valuation) or truth(args[1], valuation)


def main():
    sources = "input/new-cases-v1.json"
    grounded = "data/ground-control-v1.json"
    opened = "data/nonunit-open-v1.json"
    ground = {r["id"]: r for r in read(grounded)}
    open_rows = read(opened)
    tallies = {}
    for case in read(sources):
        symbols = sorted(case["predicates"])
        truth_counts = Counter()
        for vector in product((False, True), repeat=len(symbols)):
            valuation = dict(zip(symbols, vector, strict=True))
            if all(truth(premise, valuation) for premise in case["premises"]):
                truth_counts["premises"] += 1
                if not truth(case["goal"], valuation):
                    truth_counts["countermodels"] += 1
        expected = "GROUND_MODEL" if truth_counts["countermodels"] else "REFUTED"
        assert ground[case["id"]]["status"] == expected == case["calibration"]["expected"]
        assert truth_counts["premises"]
        tallies[case["id"]] = dict(atoms=len(symbols), valuations=1 << len(symbols),
                                  premises=truth_counts["premises"], countermodels=truth_counts["countermodels"])
    outcomes = {}
    for row in open_rows:
        for arm in row["results"]:
            outcomes.setdefault(arm["mode"], Counter())[arm["status"]] += 1
    certified = [r["id"] for r in ground.values() if r.get("rectangle", {}).get("status") == "VERIFIED"]
    receipt = dict(status="PASS", source_truth=tallies, ground_verified_wang=certified,
                   ground_outcomes=dict(Counter(r["status"] for r in ground.values())),
                   open_outcomes=outcomes,
                   digests={path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
                            for path in (sources, grounded, opened)},
                   scope="Source truth tables qualify the synthetic, single-constant formulas independently of the resolution and Wang encodings. Open grid comparisons use the discovered positive's dimensions for each pair.")
    with Path("data/calibration-receipt-v1.json").open("x") as stream:
        stream.write(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: receipt[k] for k in ("status", "ground_outcomes", "open_outcomes", "ground_verified_wang")},
                     sort_keys=True))


if __name__ == "__main__":
    main()
