"""Search a common schedule of open proof windows without theorem-specific sizes."""

from itertools import product
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from open_wang_v1 import clauses, decode, layout, prop
from propagated_cuts_v1 import CutSearch, Replay


def main():
    protocol=prop.load("window-search-protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    options=sorted(product(range(protocol["depth"]+1),range(2,protocol["premises"]+1),
                           range(1,protocol["resolutions"]+1)),
                   key=lambda row:(sum(row),row[2],row[0],row[1]))
    problems={r["id"]:r for r in prop.load("input/cases-v1.json")+prop.load("input/new-cases-v1.json")}
    palette=prop.wang.palette()
    output=[]
    for name in protocol["cases"]:
        attempts=[]
        found=None
        for d,m,n in options:
            spec=dict(depth=d,premises=m,resolutions=n)
            c,fixed,prefix,fields,functions=layout(problems[name],spec,protocol)
            cnf=clauses(c,fixed)
            s=CutSearch(cnf,len(c["inputs"])+len(c["gates"]),len(c["inputs"]),
                        protocol["limits"],True)
            status,bits=s.run()
            replay=Replay(cnf)
            for cut in s.ordered:
                assert replay.refute(cut)
                replay.add(cut)
            row=dict(spec=spec,status=status,counts=dict(s.stats),marks=s.ordered)
            attempts.append(row)
            if status=="SAT":
                proof=decode(bits,prefix,fields,functions)
                rect=prop.wang.certificate(c,bits,palette)
                verified=prop.independent_wang.verify(c,rect,palette)
                assert verified["status"]=="VERIFIED"
                found=dict(spec=spec,proof=proof,certificate=verified)
                prop.compressed(f"data/{name}-window-wang-v1.json.gz",dict(circuit=c,certificate=rect))
                break
        output.append(dict(id=name,attempts=attempts,found=found))
        print(json.dumps(dict(id=name,attempts=len(attempts),window=found["spec"] if found else None,
                              total_nodes=sum(a["counts"].get("nodes",0) for a in attempts)),sort_keys=True),
              flush=True)
    prop.save("data/window-search-v1.json",output)


if __name__=="__main__":
    main()
