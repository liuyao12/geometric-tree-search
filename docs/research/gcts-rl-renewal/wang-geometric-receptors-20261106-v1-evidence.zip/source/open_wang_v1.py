"""Find proofs by completing open fixed-palette boundary bits."""

from collections import Counter, defaultdict
from itertools import product
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from in_grid_v1 import Prefix
from origin_v1 import Source, OriginPrefix
import herbrand_v1 as fol
import resolution_v1 as prop


def layout(original, spec, protocol):
    source=Source(original)
    case=source.clauses(protocol["cnf_limit"])
    functions,predicates,schemas=fol.signature(case)
    terms=fol.ground_terms(case,functions,spec["depth"],protocol["max_terms"])
    assert terms is not None
    atoms=sorted((name,*args) for name,sorts in predicates.items()
                 for args in product(*(terms[s] for s in sorts)))
    assert atoms
    n=spec["premises"]
    schema=schemas[0]
    placeholder=dict(schema=schema["id"],substitution={v:terms[s][0] for v,s in schema["variables"].items()})
    prefix=Prefix(schemas,terms,atoms,[placeholder]*n,[[]]*n)
    origin=OriginPrefix(prefix,source)
    blank=[dict(left=0,right=0,pivot=1,clause=[])]*spec["resolutions"]
    circuit,bits,fields=prop.circuit(len(atoms),[[]]*n,blank,prefix=origin)
    assert all(circuit["inputs"][i]["value"] is None for i in origin.fields.values())
    # Only source-normalization inputs depend on the statement. All proof
    # witness inputs allocated by the placeholder remain open.
    fixed={i:bits[i] for i in origin.fields.values()}
    return circuit,fixed,prefix,fields,functions


def clauses(circuit,fixed):
    result=[]
    for i,input in enumerate(circuit["inputs"],1):
        v=input["value"]
        if i-1 in fixed:
            assert v is None
            v=fixed[i-1]
        if v is not None:
            result.append((i if v else -i,))
    for z,(a,b) in enumerate(circuit["gates"],len(circuit["inputs"])+1):
        a,b=a+1,b+1
        result.extend(tuple(dict.fromkeys(c)) for c in ((-a,-b,-z),(a,z),(b,z)))
    result.append((circuit["output"]+1,))
    return result


class Search:
    def __init__(self, cnf, count, inputs, limits, marked):
        self.cnf=cnf
        self.inputs=inputs
        self.limits=limits
        self.marked=marked
        self.val=[0]*(count+1)
        self.reason=[None]*(count+1)
        self.trail=[]
        self.cursor=0
        self.watches=defaultdict(list)
        self.pairs=[]
        self.units=[]
        self.stats=Counter()
        self.nogoods=set()
        self.ordered=[]
        self.deadline=time.monotonic()+limits["seconds"]
        weights=Counter(abs(l) for c in cnf for l in c)
        self.order=sorted(range(1,inputs+1),key=lambda x:(-weights[x],x))
        for i,c in enumerate(cnf):
            if len(c)==1:
                self.units.append((c[0],i))
                self.pairs.append(None)
                continue
            self.pairs.append([0,1])
            self.watches[c[0]].append(i)
            self.watches[c[1]].append(i)

    def value(self,l):
        return self.val[abs(l)]*(1 if l>0 else -1)

    def set(self,l,reason):
        v=abs(l)
        if self.val[v]:
            return self.value(l)>0
        self.val[v]=1 if l>0 else -1
        self.reason[v]=reason
        self.trail.append(l)
        return True

    def back(self,point):
        for l in self.trail[point:]:
            self.val[abs(l)]=0
            self.reason[abs(l)]=None
        del self.trail[point:]
        self.cursor=min(self.cursor,point)

    def propagate(self):
        while self.cursor<len(self.trail):
            false=-self.trail[self.cursor]
            self.cursor+=1
            watched=self.watches[false]
            j=0
            while j<len(watched):
                i=watched[j]
                c=self.cnf[i]
                pair=self.pairs[i]
                active=0 if c[pair[0]]==false else 1
                assert c[pair[active]]==false
                other=c[pair[1-active]]
                if self.value(other)>0:
                    j+=1
                    continue
                k=next((k for k,l in enumerate(c) if k not in pair and self.value(l)>=0),None)
                if k is not None:
                    pair[active]=k
                    self.watches[c[k]].append(i)
                    watched[j]=watched[-1]
                    watched.pop()
                    continue
                if not self.set(other,i):
                    return i
                j+=1
        return None

    def learn(self,conflict):
        pending=[abs(l) for l in self.cnf[conflict]]
        seen=set()
        decisions=[]
        while pending:
            x=pending.pop()
            if x in seen:
                continue
            seen.add(x)
            reason=self.reason[x]
            if reason is None:
                assert x<=self.inputs and self.val[x]
                decisions.append(-self.val[x]*x)
            else:
                pending.extend(abs(l) for l in self.cnf[reason] if abs(l)!=x)
        cut=tuple(sorted(decisions,key=abs))
        if cut not in self.nogoods:
            self.nogoods.add(cut)
            self.ordered.append(cut)

    def run(self):
        for l,i in self.units:
            if not self.set(l,i):
                return "UNSAT",None
        def visit():
            if self.stats["nodes"]>=self.limits["nodes"] or time.monotonic()>=self.deadline:
                return "BOUNDED",None
            self.stats["nodes"]+=1
            if self.marked and any(all(self.value(l)<0 for l in cut) for cut in self.ordered):
                self.stats["mark_hits"]+=1
                return "UNSAT",None
            conflict=self.propagate()
            if conflict is not None:
                self.stats["conflicts"]+=1
                if self.marked and len(self.ordered)<self.limits["marks"]:
                    self.learn(conflict)
                return "UNSAT",None
            p=next((v for v in self.order if not self.val[v]),None)
            if p is None:
                assert all(any(self.value(l)>0 for l in c) for c in self.cnf)
                return "SAT",[int(x>0) for x in self.val[1:self.inputs+1]]
            point=len(self.trail)
            for l in (-p,p):
                assert self.set(l,None)
                status,bits=visit()
                if status!="UNSAT":
                    return status,bits
                self.back(point)
            return "UNSAT",None
        return visit()


def independent_rup(cnf,cut):
    assignments={-l for l in cut}
    while True:
        added=set()
        for clause in cnf:
            if any(l in assignments for l in clause):
                continue
            available=[l for l in clause if -l not in assignments]
            if not available:
                return True
            if len(available)==1:
                added.add(available[0])
        if any(-l in added or -l in assignments for l in added):
            return True
        if added<=assignments:
            return False
        assignments.update(added)


def decode(bits,prefix,fields,functions):
    def word(refs):
        return sum(bits[i]<<j for j,i in enumerate(refs))
    def clause(cp,cn):
        return prop.literals((word(cp),word(cn)))
    origins=[]
    premises=[]
    for head,args,cp,cn in prefix.rows:
        s=prefix.schemas[word(head)]
        env={v:prefix.terms[word(ref)] for v,ref in zip(sorted(s["variables"]),args)}
        origins.append(dict(schema=s["id"],substitution=env))
        premises.append(clause(cp,cn))
    proof=[dict(left=word(l),right=word(r),pivot=word(p)+1,clause=clause(cp,cn))
           for l,r,p,cp,cn in fields]
    fol.verify_instances(prefix.schemas,origins,premises,prefix.atoms,functions)
    prop.verify_resolution(premises,proof)
    return dict(atoms=prefix.atoms,origins=origins,premises=premises,proof=proof)


def main():
    protocol=prop.load("protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/name)==v for name,v in protocol["pins"].items())
    cases={r["id"]:r for r in prop.load("input/cases-v1.json")+prop.load("input/new-cases-v1.json")
           +[prop.load("input/forgery-v1.json")]}
    palette=prop.wang.palette()
    results=[]
    for spec in protocol["rectangles"]:
        identifier=spec["id"]
        circuit,fixed,prefix,fields,functions=layout(cases[identifier],spec,protocol)
        cnf=clauses(circuit,fixed)
        compare=[]
        for mode in ("plain","marked"):
            start=time.perf_counter()
            s=Search(cnf,len(circuit["inputs"])+len(circuit["gates"]),len(circuit["inputs"]),
                     protocol["limits"],mode=="marked")
            status,bits=s.run()
            seconds=time.perf_counter()-start
            assert all(independent_rup(cnf,c) for c in s.ordered)
            labels=[dict(clause=c,columns=[abs(l)-1 for l in c]) for c in s.ordered]
            row=dict(mode=mode,status=status,seconds=seconds,counts=dict(s.stats),cuts=labels)
            if status=="SAT":
                row["derivation"]=decode(bits,prefix,fields,functions)
                cert=prop.wang.certificate(circuit,bits,palette)
                row["physical"]=prop.independent_wang.verify(circuit,cert,palette)
                assert row["physical"]["status"]=="VERIFIED"
                prop.compressed(f"data/{identifier}-{mode}-open-wang-v1.json.gz",
                                dict(circuit=circuit,certificate=cert))
            compare.append(row)
        report=dict(id=identifier,boundary=spec,circuit_sha256=prop.wang.digest(circuit),
                    gates=len(circuit["gates"]),proof_bits=len(circuit["inputs"])-len(fixed)-2,
                    results=compare)
        results.append(report)
        print(json.dumps(dict(id=identifier,gates=report["gates"],proof_bits=report["proof_bits"],
            modes={r["mode"]:(r["status"],r["counts"],len(r["cuts"])) for r in compare}),sort_keys=True),flush=True)
    prop.save("data/results-v1.json",results)


if __name__=="__main__":
    main()
