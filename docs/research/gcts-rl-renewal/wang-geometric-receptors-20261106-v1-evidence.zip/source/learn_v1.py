"""Exhaust and independently check the declared unmarked contact cohorts."""

from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def pin(path):
    data=path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def read(name):
    return json.loads((ROOT/name).read_bytes())


def save(name, value):
    with (ROOT/name).open("x") as stream:
        json.dump(value,stream,sort_keys=True,separators=(",",":"))
        stream.write("\n")


def verify(protocol):
    assert protocol["runtime"]==pin(Path(sys.executable))
    for name, expected in protocol["pins"].items():
        assert pin(ROOT/name)==expected,name


def main():
    protocol=read("protocol-v1.json")
    assert protocol["schema"]=="Penrose-unmarked-one-vertex-frozen-v1"
    verify(protocol)
    sys.path.insert(0,str(ROOT/"source"))
    import model_v1 as model
    import check_v1 as independent
    started=time.perf_counter()
    qualification=independent.qualify(model)
    stats={"shared":Counter(),"nearby":Counter()}
    rows=[]
    legal_seconds=check_seconds=0.0
    masks=0
    negative={}
    all_rules=set()
    for w, stratum, root, other in model.requests():
        start=time.perf_counter()
        row=model.complete(root,other) if model.legal_contact(root,other) else {"status":"ILLEGAL"}
        legal_seconds+=time.perf_counter()-start
        start=time.perf_counter()
        independent.replay(row,root,other)
        check_seconds+=time.perf_counter()-start
        stats[stratum][row["status"]]+=1
        masks+=len(row.get("failed_masks",[]))
        rows.append(dict(root_width=w,stratum=stratum,root=root,other=other,**row))
        if row["status"]=="NEGATIVE":
            assert stratum=="nearby"
            negative[(root,other)]=len(rows)-1
            for h in range(10):
                a=tuple(sorted(model.rotate(p,h) for p in root))
                b=tuple(sorted(model.rotate(p,h) for p in other))
                all_rules.add(model.pair_key(a,b,model.ZERO))
    assert len(rows)<=1760 and all(stats[s] for s in stats)
    assert stats["shared"]["NEGATIVE"]==0
    with (ROOT/"data/contact-certificates-v1.json.gz").open("xb") as raw:
        with gzip.GzipFile(fileobj=raw,mode="wb",filename="",mtime=0) as out:
            out.write((json.dumps(rows,sort_keys=True,separators=(",",":"))+"\n").encode())
    save("data/rules-v1.json",sorted(all_rules))
    sample = next((r for r in rows if r["status"]=="NEGATIVE"),None)
    if sample:
        for h in range(10):
            a=tuple(sorted(model.rotate(p,h) for p in sample["root"]))
            b=tuple(sorted(model.rotate(p,h) for p in sample["other"]))
            independent.replay(model.complete(a,b),a,b)
            assert model.complete(a,b)["status"]=="NEGATIVE"
    verify(protocol)
    result=dict(status="CHECKED_EXACT_CONTACT_COHORT",qualification=qualification,
        counts={s:dict(v) for s,v in stats.items()},requests=len(rows),negative=len(negative),
        oriented_pair_footprints=len(all_rules),failed_mask_visits=masks,
        training_seconds=legal_seconds,independent_replay_seconds=check_seconds,
        total_seconds=time.perf_counter()-started,
        sample_negative=sample,
        files={n:pin(ROOT/n) for n in ("data/contact-certificates-v1.json.gz","data/rules-v1.json","protocol-v1.json")})
    save("data/learning-summary-v1.json",result)
    print(json.dumps({k:v for k,v in result.items() if k!="sample_negative"}),flush=True)


if __name__=="__main__":
    main()
