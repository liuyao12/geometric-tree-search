"""Put the ground-instance admission predicate inside the same Wang rectangle."""

from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import herbrand_v1 as fol
import resolution_v1 as prop


def pattern_match(schema,ground,env):
    if isinstance(schema,str):
        if schema in env:
            return env[schema]==ground
        env[schema]=ground
        return True
    if schema[0]!=ground[0] or len(schema)!=len(ground):
        return False
    return all(pattern_match(a,b,env) for a,b in zip(schema[1:],ground[1:],strict=True))


class Prefix:
    def __init__(self,schemas,types,atoms,origins,premises):
        self.schemas=schemas
        self.terms=sorted({t for group in types.values() for t in group})
        self.ids={t:i for i,t in enumerate(self.terms)}
        self.types={s:[self.ids[t] for t in group] for s,group in types.items()}
        self.atoms=atoms
        self.origins=origins
        self.premises=premises
        self.rows=[]
        self.term_width=max(1,(len(self.terms)-1).bit_length())
        self.schema_width=max(1,(len(schemas)-1).bit_length())
        self.slots=max(len(s["variables"]) for s in schemas)
        self.matches=[]
        for s in schemas:
            pattern_list=[]
            for positive,pattern in s["clause"]:
                options=[]
                for k,ground in enumerate(atoms):
                    if pattern[0]!=ground[0] or len(pattern)!=len(ground):
                        continue
                    env={}
                    if all(pattern_match(p,q,env) for p,q in zip(pattern[1:],ground[1:],strict=True)):
                        options.append((k,{v:self.ids[t] for v,t in env.items()}))
                pattern_list.append((0 if positive else 1,options))
            self.matches.append(pattern_list)

    def inputs(self,fields,values):
        def word(name,width,value):
            first=len(fields)
            fields.extend(dict(name=f"{name}:{i}",value=None) for i in range(width))
            values.extend((value>>i)&1 for i in range(width))
            return list(range(first,first+width))

        names={r["id"]:i for i,r in enumerate(self.schemas)}
        n=len(self.atoms)
        for k,(origin,clause) in enumerate(zip(self.origins,self.premises,strict=True)):
            code=names[origin["schema"]]
            env={v:self.ids[fol.frozen(t)] for v,t in origin["substitution"].items()}
            slots=[env[v] for v in sorted(env)]+[0]*(self.slots-len(env))
            a,b=prop.mask(clause)
            head=word(f"premise{k}:schema",self.schema_width,code)
            args=[word(f"premise{k}:term{j}",self.term_width,x) for j,x in enumerate(slots)]
            cp=word(f"premise{k}:positive",n,a)
            cn=word(f"premise{k}:negative",n,b)
            self.rows.append((head,args,cp,cn))

    def compile(self,builder):
        checks=[]
        rows=[]
        n=len(self.atoms)
        b=builder
        for head,args,cp,cn in self.rows:
            schemas=[b.word_eq(head,b.const_word(i,self.schema_width)) for i in range(len(self.schemas))]
            codes=[[b.word_eq(arg,b.const_word(j,self.term_width)) for j in range(len(self.terms))]
                   for arg in args]
            valid=[]
            emitted=[[[] for _ in range(n)] for _ in range(2)]
            for index,(selector,source) in enumerate(zip(schemas,self.schemas,strict=True)):
                order={v:i for i,v in enumerate(sorted(source["variables"]))}
                requirements=[selector]
                for v,s in source["variables"].items():
                    requirements.append(b.any(codes[order[v]][j] for j in self.types[s]))
                for sign,options in self.matches[index]:
                    matching=[]
                    for k,env in options:
                        q=b.all(codes[order[v]][value] for v,value in env.items())
                        matching.append(q)
                        emitted[sign][k].append(b.AND(selector,q))
                    # An omitted output literal could otherwise make the clause stronger.
                    requirements.append(b.any(matching))
                valid.append(b.all(requirements))
            checks.append(b.any(valid))
            for sign,word in enumerate((cp,cn)):
                checks.extend(b.EQ(bit,b.any(emitted[sign][k])) for k,bit in enumerate(word))
            rows.append((cp,cn))
        return rows,checks


def lift(result,case,limit):
    functions,predicates,schemas=fol.signature(case)
    terms=fol.ground_terms(case,functions,result["depth"],limit)
    atoms=sorted((name,*args) for name,sorts in predicates.items()
                 for args in product(*(terms[s] for s in sorts)))
    assert len(atoms)==len(set(atoms))
    assert all(tuple(fol.inspect_term(t,{},functions) for t in atom[1:])==tuple(predicates[atom[0]])
               for atom in atoms)
    new_ids={a:i+1 for i,a in enumerate(atoms)}
    old={i+1:new_ids[fol.frozen(a)] for i,a in enumerate(result["atoms"])}
    def ref(i):
        return old[abs(i)]*(1 if i>0 else -1)
    premises=[[ref(i) for i in row] for row in result["premises"]]
    proof=[dict(left=r["left"],right=r["right"],pivot=ref(r["pivot"]),
                clause=[ref(i) for i in r["clause"]]) for r in result["proof"]]
    prop.verify_resolution(premises,proof)
    return Prefix(schemas,terms,atoms,result["premise_sources"],premises),premises,proof


def main():
    protocol=prop.load("protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    cases={r["id"]:r for r in prop.load("input/cases-v1.json")}
    ground=prop.load("input/ground-results-v1.json")
    palette=prop.wang.palette()
    results=[]
    for result in ground:
        if result["status"]!="PROVED":
            continue
        prefix,premises,proof=lift(result,cases[result["id"]],protocol["term_limit"])
        circuit,bits,_=prop.circuit(len(prefix.atoms),premises,proof,prefix=prefix)
        assert len(circuit["gates"])<=protocol["gates"]
        cert=prop.wang.certificate(circuit,bits,palette)
        checked=prop.independent_wang.verify(circuit,cert,palette)
        assert checked["status"]=="VERIFIED"
        mutations=0
        for _,_,cp,cn in prefix.rows:
            for word in (cp,cn):
                damaged=bits[:]
                damaged[word[0]]^=1
                assert prop.wang.evaluate(circuit,damaged)[1]==0
                mutations+=1
        name=f"data/{result['id']}-wang-v1.json.gz"
        prop.compressed(name,dict(circuit=circuit,certificate=cert))
        row=dict(id=result["id"],status="VERIFIED",gates=len(circuit["gates"]),inputs=len(bits),
                 premises=len(premises),schemas=len(prefix.schemas),atoms=len(prefix.atoms),
                 free_substitution_slots=prefix.slots,checked=checked,mutation_rejections=mutations,
                 artifact=dict(path=name,**prop.pin(ROOT/name)))
        results.append(row)
        print(json.dumps(row,sort_keys=True),flush=True)
    assert len(results)==4
    prop.save("data/results-v1.json",results)
    summary=dict(status="CHECKED_IN_GRID_GROUND_INSTANCE_AND_RESOLUTION",checked=len(results),
                 mutation_rejections=sum(r["mutation_rejections"] for r in results),
                 palette_sha256=prop.wang.digest(palette),
                 scope="The fixed Wang certificate checks both ground-instance admission and resolution. Clause schemas, finite term bound and typed atom catalogue are public problem inputs. General non-clausal front-end compilation and unbounded search remain separate.")
    prop.save("data/summary-v1.json",summary)
    print(json.dumps(summary,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
