"""Project failures to assignments of formula atoms, then reconstruct a proof."""

import json
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from admission_experiment_v1 import bank_for, certificate, matched
from backjump_v1 import BoundarySearch
from context_experiment_v1 import tree
from ground_control_v1 import Derivation
from lemma_receptors_v1 import Pattern, atom_types, ordered, verify
from propagated_cuts_v1 import Replay
from transfer_experiment_v1 import prop, replay_logic


def replay_cuts(base, offers, cuts):
    derivation = Derivation(base)
    for offer in offers:
        nodes = [derivation.known[frozenset(row)] for row in offer.leaves]
        for a, b, pivot, row in offer.steps:
            j = derivation.add_resolution(nodes[a],nodes[b],pivot)
            assert derivation.clauses[j] == frozenset(row)
            nodes.append(j)
    for cut in cuts:
        node = derivation.refute(frozenset(cut))
        assert node is not None and derivation.clauses[node] <= frozenset(cut)
    empty = derivation.refute(frozenset())
    if empty is not None:
        origins,premises,proof = derivation.support(empty,base)
        replay_logic(premises,proof,base)
        return dict(origins=origins,premises=premises,proof=proof)
    return None


def main():
    plan = prop.load("ground-marks-protocol-v1.json")
    assert prop.pin(Path(sys.executable)) == plan["runtime"]
    assert all(prop.pin(Path(k)) == digest for k,digest in plan["pins"].items())
    protocol = prop.load("protocol-v1.json")
    wider = prop.load("wide-context-protocol-v1.json")
    prior = {r["id"]:r for r in prop.load("data/admission-v1.json")}
    patterns = [Pattern(**{k:tree(v) for k,v in d["pattern"].items()})
                for d in prop.load("prior/transfer-v1.json")["donors"]]
    palette = prop.wang.palette()
    output = []
    for name in plan["cases"]:
        source = prior[name]["source"]
        base,atoms = bank_for(source,protocol)
        bank = {ordered(prop.literals(row)) for row in base}
        offers, stats = matched(patterns, bank, atom_types(source,atoms), wider["matching"])
        assert all(verify(o, bank) for o in offers)
        cheapest = {}
        for offer in sorted(offers,key=lambda o:(len(o.steps),o.pattern,o.leaves,o.mapping)):
            cheapest.setdefault(offer.result,offer)
        original = sorted(bank)
        fields = [dict(name=atom[0]) for atom in atoms]
        rows = []
        for mode, seeded in (("static",False),("activity",False),("activity",True)):
            added = sorted(cheapest) if seeded else []
            cnf = original + added
            start = time.monotonic()
            search = BoundarySearch(list(cnf),len(atoms),len(atoms),plan["limits"],mode,fields)
            status, model = search.run()
            elapsed = time.monotonic() - start
            assert status == "BOUNDED" or (status == "UNSAT") == prior[name]["positive"]
            independent = Replay(cnf)
            for cut in search.ordered:
                assert independent.refute(cut), cut
                independent.add(cut)
            rec = dict(mode=mode,seeded=seeded,status=status,stats=dict(search.stats),
                       cuts=search.ordered,imported=len(added),seconds=elapsed)
            if status == "UNSAT":
                proof = replay_cuts(base,[cheapest[r] for r in added],search.ordered)
                assert proof is not None
                rec["proof"] = dict(atoms=atoms,**proof)
            elif status == "SAT":
                truth = {i if bit else -i for i,bit in enumerate(model,1)}
                assert all(truth.intersection(row) for row in cnf)
                rec["model"] = model
            rows.append(rec)
        found = [r for r in rows if "proof" in r]
        if found:
            best = min(found,key=lambda r:(len(r["proof"]["proof"]),len(r["proof"]["premises"])))
            if len(best["proof"]["proof"]) <= plan["row_limit"]:
                best["rectangle"], best["rectangle_file"] = certificate(
                    source,best["proof"],protocol,"ground-cuts",palette)
        result = dict(id=name,rows=rows,library_outputs=len(cheapest),matching=stats)
        output.append(result)
        print(json.dumps(dict(id=name,library_outputs=len(cheapest),arms=[
            (r["mode"],r["seeded"],r["status"],r["stats"],len(r["cuts"]),
             len(r.get("proof",{}).get("proof",[])),r.get("rectangle",{}).get("status"))
            for r in rows]),sort_keys=True),flush=True)
    prop.save("data/ground-marks-v1.json",output)


if __name__ == "__main__":
    main()
