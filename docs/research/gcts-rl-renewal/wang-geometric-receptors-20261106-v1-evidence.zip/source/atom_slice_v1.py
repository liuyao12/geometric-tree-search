"""Compile small proof interfaces while requiring every source literal."""

from pathlib import Path
import json
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from in_grid_v1 import Prefix
from origin_v1 import OriginPrefix, Source, rejecting_rectangle
from serial_blocks_v1 import decode, prop
from wired_replay_v1 import compile_wired


def slice_proof(proof):
    used = {abs(v) for row in proof["premises"] for v in row}
    for line in proof["proof"]:
        used.add(line["pivot"])
        used.update(map(abs, line["clause"]))
    ids = {old:i+1 for i,old in enumerate(sorted(used))}

    def remap(lit):
        return ids[abs(lit)] if lit > 0 else -ids[-lit]

    return dict(atoms=[proof["atoms"][old-1] for old in sorted(used)], origins=proof["origins"],
                premises=[[remap(v) for v in row] for row in proof["premises"]],
                proof=[{**line, "pivot":ids[line["pivot"]], "clause":[remap(v) for v in line["clause"]]}
                       for line in proof["proof"]])


def verify_certificate(original, source, schemas, terms, functions, proof, palette):
    start = time.monotonic()
    prefix = Prefix(schemas, terms, list(map(fol.frozen, proof["atoms"])), proof["origins"], proof["premises"])
    circuit, bits, fields = compile_wired(prefix, source, proof["proof"])
    decoded = decode(bits, prefix, fields, functions)
    assert json.dumps(decoded, sort_keys=True) == json.dumps(proof, sort_keys=True)
    status = prop.wang.evaluate(circuit, bits)[1]
    assert status == 1
    compile_seconds = time.monotonic() - start
    damaged = bits[:]
    damaged[fields[-1][3][0]] ^= 1
    assert prop.wang.evaluate(circuit, damaged)[1] == 0
    return circuit, bits, dict(atoms=len(proof["atoms"]), gates=len(circuit["gates"]), compile_seconds=compile_seconds)


def omission_control(source, schemas, terms, atoms, origin, row, palette):
    # Compare exactly the same typed source instance against its truncated copy.
    lost = abs(row[0])
    retained = [i for i in range(1,len(atoms)+1) if i != lost]
    ids = {old:i+1 for i,old in enumerate(retained)}
    bad_row = [ids[abs(lit)] if lit > 0 else -ids[-lit] for lit in row if abs(lit) != lost]
    good = list(map(fol.frozen, atoms))
    reduced = [good[i-1] for i in retained]

    def admission(allowed, proposed):
        prefix = Prefix(schemas, terms, allowed, [origin], [proposed])
        compilation = OriginPrefix(prefix, source)
        inputs = [dict(name="zero",value=0),dict(name="one",value=1)]
        bits = [0,1]
        compilation.inputs(inputs,bits)
        b = prop.wang.Builder(inputs)
        _, checks = compilation.compile(b)
        return b.finish(b.all(checks)),bits

    c, witness = admission(good,row)
    assert prop.wang.evaluate(c,witness)[1] == 1
    c, witness = admission(reduced,bad_row)
    result = rejecting_rectangle(c,witness,palette)
    return dict(omitted_atom=atoms[lost-1],schema=origin["schema"],original_width=len(row),
                claimed_width=len(bad_row),reason=result["reason"],status=result["status"])


def main():
    plan = prop.load("atom-slice-protocol-v1.json")
    assert prop.pin(Path(sys.executable)) == plan["runtime"]
    assert all(prop.pin(Path(k)) == digest for k,digest in plan["pins"].items())
    protocol = prop.load("protocol-v1.json")
    agatha = prop.load("prior/marked-pilot/agatha-v1.json")
    r = next(row for row in agatha["results"] if "proof" in row)
    inputs = [dict(source=agatha["source"], proof=r["proof"], depth=r["depth"], discovery="ground unit propagation"),
              {**prop.load("prior/hilbert-slice-input-v1.json"), "discovery":"marked serial clause-block search"}]
    palette = prop.wang.palette()
    rows = []
    for item in inputs:
        original = item["source"]
        s = Source(original)
        normalized = s.clauses(protocol["cnf_limit"])
        functions, _, schemas = fol.signature(normalized)
        terms = fol.ground_terms(normalized, functions, item["depth"], protocol["max_terms"])
        full = item["proof"]
        sliced = slice_proof(full)
        _, _, base = verify_certificate(original,s,schemas,terms,functions,full,palette)
        c, bits, reduced = verify_certificate(original,s,schemas,terms,functions,sliced,palette)
        cert = prop.wang.certificate(c,bits,palette)
        checked = prop.independent_wang.verify(c,cert,palette)
        assert checked["status"] == "VERIFIED"
        name = original["id"]
        path = f"data/{name}-atom-slice-wang-v1.json.gz"
        prop.compressed(path,dict(circuit=c,certificate=cert))
        row_index = next(i for i,row in enumerate(sliced["premises"]) if len(row)>1)
        attack = omission_control(s,schemas,terms,sliced["atoms"],sliced["origins"][row_index],
                                  sliced["premises"][row_index],palette)
        rows.append(dict(id=name,source=original,depth=item["depth"],proof=sliced,base=base,reduced=reduced,
                         attack=attack,rectangle=checked,rectangle_file=path,discovery=item["discovery"]))
        print(json.dumps(dict(id=name,full=base,reduced=reduced,omission=attack["status"]),sort_keys=True),flush=True)
    prop.save("data/atom-slice-v1.json",rows)


if __name__ == "__main__":
    main()
