"""Discover serial Wang proofs with exact conclusion-side layers."""

from collections import Counter, defaultdict
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from serial_blocks_v1 import SerialSearch, bits_for, catalog, compile_case, decode, prop, witness


def submasks(mask):
    subset = mask
    while subset:
        yield subset
        subset = (subset - 1) & mask
    yield 0


class Suffix:
    def __init__(self, admitted, atoms, depth, max_candidates, deadline):
        self.low = (1 << atoms) - 1
        self.atoms = atoms
        self.layers = [{0: None}]
        self.candidates = 0
        self.complete = True
        indexed = defaultdict(list)
        for premise in sorted(admitted):
            packed = self.pack(premise)
            for bit in prop.bits(packed):
                positive = bit <= self.low
                opposite = bit << atoms if positive else bit >> atoms
                side = int(positive)
                pivot = (bit if positive else opposite).bit_length()
                indexed[packed ^ bit].append((opposite, (premise, side, pivot)))

        for k in range(1, depth + 1):
            previous = {}
            for target in self.layers[-1]:
                for residual in submasks(target):
                    for opposite, op in indexed.get(residual, ()):
                        mandatory = target ^ residual
                        if mandatory & opposite:
                            continue
                        for shared in submasks(residual & ~opposite):
                            if self.candidates >= max_candidates or time.monotonic() >= deadline:
                                self.complete = False
                                return
                            self.candidates += 1
                            prior = mandatory | shared | opposite
                            if prior.bit_count() <= k and not self.tautology(prior):
                                previous.setdefault(prior, (target, op))
            self.layers.append(previous)

    def pack(self, row):
        positive, negative = row
        return positive | (negative << self.atoms)

    def unpack(self, row):
        return row & self.low, row >> self.atoms

    def tautology(self, row):
        return row & (row >> self.atoms) & self.low

    @property
    def depth(self):
        return len(self.layers) - 1

    def tail(self, row):
        current = self.pack(row)
        if current not in self.layers[-1]:
            return None
        tail = []
        for layer in reversed(self.layers[1:]):
            current, operation = layer[current]
            tail.append((self.unpack(current), operation))
        assert not current
        return tail


class Joined(SerialSearch):
    def __init__(self, admitted, limits, suffix, started):
        super().__init__(admitted, limits, True)
        self.suffix = suffix
        self.started = started

    def visit(self, c, remaining):
        if remaining != self.suffix.depth:
            return super().visit(c, remaining)
        if self.counts["nodes"] >= self.limits["nodes"] or time.monotonic() - self.started >= self.limits["seconds"]:
            return "BOUNDED", None
        self.counts["nodes"] += 1
        if (c, remaining) in self.failed:
            self.counts["hits"] += 1
            return "UNSAT", None
        tail = self.suffix.tail(c)
        if tail is not None:
            self.counts["joins"] += 1
            return "SAT", tail
        self.failed[c, remaining] = "suffix-unreachable"
        return "UNSAT", None


def audit_layers(suffix, admitted):
    """Recompute every complete layer with literal sets and explicit pivots."""
    entries = []
    for row in admitted:
        signed = frozenset(prop.literals(row))
        entries.extend((pivot, signed - {pivot}) for pivot in signed)
    last = {frozenset()}
    for k, layer in enumerate(suffix.layers[1:], 1):
        exact = set()
        for target in last:
            for pivot, residual in entries:
                if not residual <= target:
                    continue
                required = (target - residual) | {-pivot}
                optional = tuple(residual - {-pivot})
                for bits in range(1 << len(optional)):
                    prior = required | {v for i, v in enumerate(optional) if (bits >> i) & 1}
                    if len(prior) <= k and all(-v not in prior for v in prior):
                        if (prior - {-pivot}) | residual == target:
                            exact.add(prior)
        observed = {frozenset(prop.literals(suffix.unpack(row))) for row in layer}
        assert observed == exact, k
        for row, (target, (premise, side, pivot)) in layer.items():
            left, right = (suffix.unpack(row), premise) if side == 0 else (premise, suffix.unpack(row))
            bit = 1 << (pivot - 1)
            assert left[0] & right[1] & bit
            assert prop.resolution(left, right, bit) == suffix.unpack(target)
        last = exact
    return last


def audit_marks(search, last):
    bank = [set(prop.literals(c)) for c in search.admitted]
    for (row, k), reason in sorted(search.failed.items(), key=lambda item: item[0][1]):
        c = set(prop.literals(row))
        if reason == "suffix-unreachable":
            assert k == search.suffix.depth and c not in last
        elif reason == "literal-capacity":
            assert len(c) > k
        elif reason == "missing-opposite":
            assert any(all(-lit not in premise for premise in bank) for lit in c)
        else:
            assert reason == "exhausted" and k > search.suffix.depth
            for premise in bank:
                for pivot in c:
                    if -pivot in premise:
                        result = (c - {pivot}) | (premise - {-pivot})
                        if all(-lit not in result for lit in result):
                            assert (prop.mask(result), k - 1) in search.failed


def main():
    from origin_v1 import Source
    plan = prop.load("suffix-protocol-v1.json")
    assert plan["runtime"] == prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT / path) == pin for path, pin in plan["pins"].items())
    full = prop.load("protocol-v1.json")
    base = prop.load("blocks-protocol-v1.json")
    problems = {r["id"]: r for r in prop.load("input/cases-v1.json") +
                prop.load("input/new-cases-v1.json") + prop.load("input/tutorial-cases-v1.json")["cases"] +
                [prop.load("input/forgery-v1.json")]}
    palette = prop.wang.palette()
    rows = []
    for spec in base["cases"]:
        name = spec["id"]
        c, _, prefix, fields, functions = compile_case(problems[name], spec, full)
        prefix.original = Source(problems[name])
        prefix.original.clauses(full["cnf_limit"])
        admitted = catalog(prefix)
        started = time.monotonic()
        depth = min(plan["depth_cap"], spec["resolutions"] - 1)
        suffix = Suffix(admitted, len(prefix.atoms), depth, plan["candidate_cap"],
                        started + plan["suffix_seconds"])
        search = Joined(admitted, base["limits"], suffix, started)
        status, trail = search.run(spec["resolutions"])
        seconds = time.monotonic() - started
        checked = audit_layers(suffix, admitted)
        audit_marks(search, checked)
        row = dict(id=name, status=status, seconds=seconds, counts=dict(search.counts),
                   layers=[len(layer) for layer in suffix.layers], target_depth=depth,
                   complete=suffix.complete, candidates=suffix.candidates,
                   marks=dict(Counter(search.failed.values())))
        print(json.dumps(row, sort_keys=True), flush=True)
        row["failures"] = [(key, value) for key, value in sorted(search.failed.items())]
        row["suffix"] = [sorted(layer.items()) for layer in suffix.layers]
        row["circuit_sha256"] = prop.wang.digest(c)
        if trail is not None:
            bits = bits_for(c, prefix, *witness(trail, admitted, spec["premises"]))
            row["proof"] = decode(bits, prefix, fields, functions)
            rect = prop.wang.certificate(c, bits, palette)
            row["rectangle"] = prop.independent_wang.verify(c, rect, palette)
            assert row["rectangle"]["status"] == "VERIFIED"
            prop.compressed(f"data/{name}-suffix-wang-v1.json.gz", dict(circuit=c, certificate=rect))
        rows.append(row)
    prop.save("data/suffix-v1.json", rows)


if __name__ == "__main__":
    main()
