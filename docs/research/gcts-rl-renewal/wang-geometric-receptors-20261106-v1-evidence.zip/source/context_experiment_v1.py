"""Compare exact, context-preserving, and two-layer receptor libraries."""

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import random
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from indexed_receptors_v1 import audit, compose, fit
from lemma_receptors_v1 import Pattern, atom_types, ordered
from lemma_search_v1 import Search
from transfer_experiment_v1 import ROOT, Source, bits_for, catalog, compile_case, decode, prop, replay_logic


def tree(x):
    return tuple(map(tree, x)) if isinstance(x, list) else x


def library(patterns, bank, types, plan):
    start = time.monotonic()
    offers, work = fit(patterns, bank, types, plan)
    work["match_seconds"] = time.monotonic() - start
    start = time.monotonic()
    for o in offers:
        audit(o, patterns[o.pattern], types, bank, plan["context"])
    work["audit_seconds"] = time.monotonic() - start
    return offers, work


def key(o):
    return o.result, tuple(sorted(o.leaves))


def main():
    plan = prop.load("context-protocol-v1.json")
    assert plan["runtime"] == prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT / p) == h for p, h in plan["pins"].items())
    protocols = prop.load("protocol-v1.json")
    dep = Path(sys.argv[1])
    assert all(prop.pin(dep / p) == h for p, h in protocols["pysat_files"].items())
    sys.path.insert(0, str(dep))
    from pysat.solvers import Solver
    previous = prop.load("data/transfer-v1.json")
    patterns = [Pattern(**{k: tree(v) for k, v in d["pattern"].items()}) for d in previous["donors"]]
    weights = previous["weights"]
    sources = {r["id"]: r for r in prop.load("input/new-cases-v1.json")}
    palette = prop.wang.palette()
    output = []
    for prior in previous["cases"]:
        name = prior["id"]
        source = sources[name]
        layout = dict(id=name, depth=0, premises=2, resolutions=1)
        _, _, prefix, _, _ = compile_case(source, layout, protocols)
        admitted = {r: o for r, o in catalog(prefix).items() if not r[0] & r[1]}
        bank = {ordered(prop.literals(c)) for c in admitted}
        types = atom_types(source, prefix.atoms)
        exact, e = library(patterns, bank, types, {**plan["matching"], "context":0})
        assert e["complete"] and prior["matching"]["complete"]
        assert {key(o) for o in exact} == {
            (tuple(o["steps"][-1][3]), tuple(sorted(map(tuple, o["leaves"])))) for o in prior["offers"]}
        flexible, f = library(patterns, bank, types, {**plan["matching"], "context":1})
        assert not f["complete"] or {key(o) for o in exact} <= {key(o) for o in flexible}
        seeds = {}
        for o in sorted(flexible, key=lambda o: (len(o.steps), o.pattern, o.leaves, o.mapping)):
            seeds.setdefault(o.result, o)
        outer, h = library(patterns, bank | seeds.keys(), types, {**plan["hierarchical"], "context":1})
        combined = {key(o): o for o in flexible}
        bridges = []
        for o in outer:
            if o.result in seeds:
                continue
            composed = compose(o, seeds, bank)
            if composed and len(composed.steps) <= plan["composed_steps"] and key(composed) not in combined:
                bridges.append(dict(outer=asdict(o), flattened=asdict(composed)))
                combined[key(composed)] = composed
        pool = [("exact", exact, e), ("flexible", flexible, f), ("two-layer", list(combined.values()), h)]
        result = dict(id=name, libraries=[], bridges=bridges)
        exported = {}
        for label, offers, work in pool:
            modes = []
            base = [list(r) for r in sorted(bank)]
            added = [list(r) for r in sorted({o.result for o in offers})]
            with Solver(name="glucose4", bootstrap_with=[*base, *added]) as s:
                s.conf_budget(plan["sat_conflicts"])
                sat = s.solve_limited()
                cnf_stats = s.accum_stats()
                model = s.get_model() if sat else None
            if model is not None:
                assert all(set(model).intersection(r) for r in [*base, *added])
            for mode in ("seeded", "receptor", "trained"):
                search = Search(admitted, offers, mode, plan["search_limits"], weights, random.Random(0))
                status, root = search.run()
                row = dict(mode=mode, status=status, stats=dict(search.stats),
                           seconds=time.monotonic() - search.started)
                if root is not None:
                    origins, premises, proof = search.d.support(root, admitted)
                    replay_logic(premises, proof, admitted)
                    used = search.used(root)
                    row["used"] = [asdict(o) for o in used]
                    row["nested_used"] = sum(any(key(o) == (tuple(b["flattened"]["steps"][-1][3]),
                                                           tuple(sorted(b["flattened"]["leaves"])))
                                                 for b in bridges) for o in used)
                    row["proof"] = dict(atoms=prefix.atoms, origins=origins, premises=premises, proof=proof)
                    if [label, name, mode] in plan["export"] and max(len(premises), len(proof)) <= plan["certificate_cap"]:
                        proof_key = hashlib.sha256(json.dumps(row["proof"],sort_keys=True).encode()).hexdigest()
                        if proof_key in exported:
                            row["rectangle_file"], row["rectangle"] = exported[proof_key]
                        else:
                            spec = {**layout, "premises":len(premises), "resolutions":len(proof)}
                            circuit, _, dest, fields, functions = compile_case(source, spec, protocols)
                            dest.original = Source(source)
                            dest.original.clauses(protocols["cnf_limit"])
                            bits = bits_for(circuit, dest, origins, premises, proof)
                            assert decode(bits, dest, fields, functions) == row["proof"]
                            cert = prop.wang.certificate(circuit, bits, palette)
                            row["rectangle"] = prop.independent_wang.verify(circuit, cert, palette)
                            assert row["rectangle"]["status"] == "VERIFIED"
                            row["rectangle_file"] = f"data/{name}-{label}-{mode}-wang-v1.json.gz"
                            prop.compressed(row["rectangle_file"], dict(circuit=circuit, certificate=cert))
                            exported[proof_key] = row["rectangle_file"], row["rectangle"]
                modes.append(row)
            result["libraries"].append(dict(library=label, offers=[asdict(o) for o in offers], matching=work,
                                            search=modes, cdcl=dict(status={True:"GROUND_MODEL",False:"REFUTED",None:"BOUNDED"}[sat],
                                                                   imported=len(added),stats=cnf_stats,model=model)))
        print(json.dumps(dict(id=name, bridges=len(bridges), libraries=[
            dict(id=l["library"], n=len(l["offers"]), matching=l["matching"], cdcl=l["cdcl"]["stats"]["conflicts"],
                 search=[(r["mode"],r["status"],r["stats"].get("pairs",0),r["stats"].get("macro_replays",0),
                          r.get("nested_used",0),len(r.get("proof",{}).get("proof",[]))) for r in l["search"]])
            for l in result["libraries"]]),sort_keys=True),flush=True)
        output.append(result)
    prop.save("data/context-v1.json", output)


if __name__ == "__main__":
    main()
