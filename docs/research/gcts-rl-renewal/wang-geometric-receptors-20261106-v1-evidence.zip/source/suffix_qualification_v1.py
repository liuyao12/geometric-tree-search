"""Compare reverse layers with exhaustive forward sets on small banks."""

from itertools import product
from pathlib import Path
import random
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from suffix_v1 import Suffix, audit_layers, prop


def main():
    rng = random.Random(261105)
    layer_count = states_checked = tainted_banks = 0
    for i in range(128):
        atoms = 1 + i % 5
        universe = [a for a in range(-atoms, atoms + 1) if a]
        bank = {frozenset(rng.sample(universe, rng.randint(0, min(4, len(universe)))))
                for _ in range(rng.randint(1, 16))}
        tainted_banks += any(-v in c for c in bank for v in c)
        rows = {prop.mask(c): None for c in bank}
        suffix = Suffix(rows, atoms, 4, 1000000, time.monotonic() + 10)
        assert suffix.complete
        audit_layers(suffix, rows)
        all_states = [frozenset(x for x in state if x)
                      for state in product(*[(0, a, -a) for a in range(1, atoms + 1)])]
        targets = {frozenset()}
        for k, layer in enumerate(suffix.layers[1:], 1):
            reached = set()
            for state in all_states:
                if len(state) > k:
                    continue
                states_checked += 1
                if any((state - {lit}) | (row - {-lit}) in targets
                       for row in bank for lit in state if -lit in row):
                    reached.add(state)
            assert reached == {frozenset(prop.literals(suffix.unpack(r))) for r in layer}, (i, k)
            layer_count += 1
            targets = reached
        capped = Suffix(rows, atoms, 4, 0, time.monotonic() + 10)
        assert all(a == b for a, b in zip(capped.layers, suffix.layers))
    prop.save("data/suffix-qualification-v1.json", dict(status="PASS", seed=261105,
        banks=128, banks_with_tautological_admissions=tainted_banks,
        exact_layers=layer_count, states_checked=states_checked))


if __name__ == "__main__":
    main()
