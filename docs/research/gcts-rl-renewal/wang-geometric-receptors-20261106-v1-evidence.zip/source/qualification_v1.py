"""Qualify source normalization independently on finite interpretations."""

from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from front_v1 import finite_qualification
from origin_v1 import Source
import resolution_v1 as prop


def main():
    proof=prop.load("data/results-v1.json")
    records=[]
    for case in proof["cases"]+[proof["forgery"]]:
        problem=case["original"]
        if problem["functions"] or problem["equality"]:
            continue
        genuine=Source(problem).clauses(5000)
        result=finite_qualification(problem,genuine)
        assert (result["refutation_formula_satisfiable_in"]==0)==(
            case["outcome"]["status"]=="PROVED" and not case["forgery"])
        records.append(dict(id=problem["id"],**result))
    prop.save("data/qualification-v1.json",records)


if __name__=="__main__":
    main()
