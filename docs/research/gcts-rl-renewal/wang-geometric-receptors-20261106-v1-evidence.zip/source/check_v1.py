"""Independent exact arithmetic, contact testing and one-point replay."""

from functools import cmp_to_key, lru_cache
from itertools import combinations

ORIGIN = (0,0,0,0)


def multiply(a,b):
    raw = [0]*5
    for i in range(4):
        for j in range(4):
            raw[(i+j)%5] += a[i]*b[j]
    return tuple(raw[i]-raw[4] for i in range(4))


def plus(a,b):
    return tuple(a[i]+b[i] for i in range(4))


def minus(a,b):
    return tuple(a[i]-b[i] for i in range(4))


def star(a):
    raw = (a[0],0,a[3],a[2],a[1])
    return tuple(x-raw[4] for x in raw[:4])


def powers():
    u = (1,0,0,0)
    for _ in range(10):
        yield u
        u = multiply(u,(0,0,0,-1))


RAYS = tuple(powers())


@lru_cache(maxsize=100000)
def corners(p):
    result = {}
    for i,j in combinations(range(len(RAYS)),2):
        gap = j-i
        if gap==5:
            continue
        if gap<5:
            first, count = i,gap
        else:
            first, count = j,10-gap
        u,v=RAYS[i],RAYS[j]
        points = tuple(sorted((p,plus(p,u),plus(p,v),plus(plus(p,u),v))))
        sector = 0
        for step in range(count):
            sector |= 1 << ((first+step)%10)
        assert points not in result
        result[points] = sector
    return result


def order(a,b):
    u,v=a[0]-b[0],a[1]-b[1]
    q=2*u+v
    if q>=0 and v>=0:
        return int(q>0 or v>0)
    if q<=0 and v<=0:
        return -1
    if q>0:
        return 1 if q*q>5*v*v else -1
    return 1 if 5*v*v>q*q else -1


SORT = cmp_to_key(order)


@lru_cache(maxsize=200000)
def imaginary_normal(direction,p):
    _,a,b,c = multiply(star(direction),p)
    return b-c,a


@lru_cache(maxsize=100000)
def hull(direction,tile):
    return sorted({imaginary_normal(direction,p) for p in tile},key=SORT)


def projection_contains(direction,face,p):
    support = hull(direction,face)
    val = imaginary_normal(direction,p)
    return order(val,support[0])>=0 and order(val,support[-1])<=0


def contact(a,b):
    return canonical_contact(*sorted((a,b)))


@lru_cache(maxsize=300000)
def canonical_contact(a,b):
    for ray in RAYS:
        A,B=hull(ray,a),hull(ray,b)
        difference = order(A[-1],B[0])
        if difference>0:
            continue
        if difference<0:
            return True
        line=A[-1]
        left=tuple(p for p in a if imaginary_normal(ray,p)==line)
        right=tuple(p for p in b if imaginary_normal(ray,p)==line)
        transverse=RAYS[(RAYS.index(ray)+2)%10]
        points={p for p in left if projection_contains(transverse,right,p)}
        points.update(p for p in right if projection_contains(transverse,left,p))
        if len(points)==0:
            return True
        if len(points)==1:
            return points <= set(left) & set(right)
        return set(left)==set(right)==points and len(points)==2
    return False


def replay(row,root,other):
    legal=contact(root,other)
    if not legal:
        assert row["status"]=="ILLEGAL"
        return
    star_tiles=corners(ORIGIN)
    mask=star_tiles[root] | star_tiles.get(other,0)
    allowed=[(t,m) for t,m in sorted(star_tiles.items()) if not mask&m
             and contact(root,t) and contact(other,t)]
    assert row["initial_mask"]==mask and row["domain"]==allowed
    possible={mask}
    for _,sector in allowed:
        possible |= {m|sector for m in possible if not m&sector}
    has_cover=1023 in possible
    assert row["status"]==("POSITIVE" if has_cover else "NEGATIVE")
    if has_cover:
        for t in row["witness"]:
            assert not mask&star_tiles[t] and contact(root,t) and contact(other,t)
            mask |= star_tiles[t]
        assert mask==1023


def qualify(model):
    assert RAYS==model.DIRECTIONS and len(set(RAYS))==10
    assert all(corners(p)==model.incident(p) for p in (ORIGIN,*RAYS))
    at_origin=corners(ORIGIN)
    for a,b in combinations(at_origin,2):
        assert contact(a,b)==model.legal_contact(a,b)==(not at_origin[a]&at_origin[b])
    assert all(not contact(t,t) and not model.legal_contact(t,t) for t in at_origin)
    return dict(orientations=10,incident_per_point=40,common_vertex_pair_checks=780)
