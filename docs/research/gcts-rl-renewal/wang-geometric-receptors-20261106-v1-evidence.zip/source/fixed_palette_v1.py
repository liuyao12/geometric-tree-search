"""Fixed translation-only Wang palette and explicit/ribbon circuit compiler.

No search policy is implemented here. Unknown circuit inputs are certificate
variables. Interior vertical operation pins are part of the instance, not
learned facts. The palette is independent of the circuit and its semantics.
"""
import hashlib
import json

OPS = ('CROSS', 'READ', 'NAND', 'NOT', 'WRITE')


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def palette():
    tiles = []
    for oi, op in enumerate(OPS):
        for n in (0, 1):
            for w in (0, 1):
                if op == 'CROSS':
                    e, s = w, n
                elif op == 'READ':
                    e, s = n, n
                elif op == 'NAND':
                    e, s = 1 - n * w, n
                elif op == 'NOT':
                    e, s = 1 - n, n
                else:
                    e, s = w, w
                for ni, following in enumerate(OPS):
                    tiles.append({'id': 5 * (4 * oi + 2 * n + w) + ni,
                                  'N': [op, n], 'S': [following, s], 'W': w, 'E': e})
    return {'schema': 'FP-fixed-Wang-palette-v1', 'tiles': tiles}


class Builder:
    """Acyclic, hash-consed NAND compiler; only wires 0/1 fold as constants."""
    def __init__(self, inputs):
        assert inputs[:2] == [{'name': 'zero', 'value': 0}, {'name': 'one', 'value': 1}]
        assert all(type(v['name']) is str and (v['value'] is None or type(v['value']) is int and v['value'] in (0, 1)) for v in inputs)
        self.inputs = [dict(v) for v in inputs]
        self.gates, self.cache = [], {}

    def nand(self, a, b):
        assert type(a) is int and type(b) is int and min(a, b) >= 0
        assert max(a, b) < len(self.inputs) + len(self.gates)
        if a == 0 or b == 0:
            return 1
        if a == b == 1:
            return 0
        key = tuple(sorted((a, b)))
        if key not in self.cache:
            self.cache[key] = len(self.inputs) + len(self.gates)
            self.gates.append(list(key))
        return self.cache[key]

    def NOT(self, a):
        return self.nand(a, a)

    def AND(self, a, b):
        return self.NOT(self.nand(a, b))

    def OR(self, a, b):
        return self.nand(self.NOT(a), self.NOT(b))

    def XOR(self, a, b):
        z = self.nand(a, b)
        return self.nand(self.nand(a, z), self.nand(b, z))

    def EQ(self, a, b):
        return 1 if a == b else self.NOT(self.XOR(a, b))

    def all(self, values):
        out = 1
        for value in values:
            out = self.AND(out, value)
        return out

    def any(self, values):
        out = 0
        for value in values:
            out = self.OR(out, value)
        return out

    def mux(self, select, a, b):
        return self.OR(self.AND(self.NOT(select), a), self.AND(select, b))

    def const_word(self, value, width):
        assert type(value) is int and 0 <= value < 1 << width
        return [(value >> k) & 1 for k in range(width)]

    def word_eq(self, a, b):
        assert len(a) == len(b)
        return self.all([self.EQ(x, y) for x, y in zip(a, b)])

    def finish(self, output):
        assert type(output) is int and 0 <= output < len(self.inputs) + len(self.gates)
        return {'schema': 'FP-NAND-circuit-v1', 'inputs': self.inputs,
                'gates': self.gates, 'output': output}


def evaluate(circuit, input_bits):
    assert len(input_bits) == len(circuit['inputs'])
    assert all(type(x) is int and x in (0, 1) for x in input_bits)
    assert all(v['value'] is None or v['value'] == bit for v, bit in zip(circuit['inputs'], input_bits))
    values = list(input_bits)
    for a, b in circuit['gates']:
        assert 0 <= min(a, b) and max(a, b) < len(values)
        values.append(1 - values[a] * values[b])
    return values[len(input_bits):], values[circuit['output']]


def roles(circuit, y):
    if y == len(circuit['gates']):
        return []
    a, b = circuit['gates'][y]
    destination = len(circuit['inputs']) + y
    if a == b:
        return [(a, 'NOT'), (destination, 'WRITE')]
    return [(min(a, b), 'READ'), (max(a, b), 'NAND'), (destination, 'WRITE')]


def north_bit(circuit, inputs, gates, x, y):
    i = len(inputs)
    return inputs[x] if x < i else gates[x-i] if x-i < y else 0


def certificate(circuit, input_bits, palette_value=None):
    palette_value = palette_value if palette_value is not None else palette()
    gate_bits, output = evaluate(circuit, input_bits)
    assert output == 1, 'A certificate is emitted only for acceptance.'
    width, rows = len(input_bits) + len(gate_bits), []
    for y in range(len(gate_bits)):
        active, ribbons, cursor, bus = [], [], 0, 0
        following = dict(roles(circuit, y + 1))
        for x, op in roles(circuit, y):
            if cursor < x:
                ribbons.append([cursor, x, bus])
            n = north_bit(circuit, input_bits, gate_bits, x, y)
            identifier = 5 * (4 * OPS.index(op) + 2 * n + bus) + OPS.index(following.get(x, 'CROSS'))
            active.append([x, identifier])
            bus = palette_value['tiles'][identifier]['E']
            cursor = x + 1
        if cursor < width:
            ribbons.append([cursor, width, bus])
        rows.append({'active': active, 'ribbons': ribbons})
    return {'schema': 'FP-ribbon-certificate-v1',
            'circuit_sha256': digest(circuit), 'palette_sha256': digest(palette_value),
            'input_bits': list(input_bits), 'gate_bits': gate_bits, 'rows': rows}


def tile_at(circuit, cert, x, y):
    row = cert['rows'][y]
    for position, identifier in row['active']:
        if position == x:
            return identifier
    for lo, hi, bus in row['ribbons']:
        if lo <= x < hi:
            n = north_bit(circuit, cert['input_bits'], cert['gate_bits'], x, y)
            following = dict(roles(circuit, y + 1)).get(x, 'CROSS')
            return 5 * (2 * n + bus) + OPS.index(following)
    raise ValueError('Certificate has an uncovered cell.')


def point_model(circuit, palette_value):
    """Complete finite placements for TINY literal GCTS qualification only.

    Center points have capacity1, t1 tiles. All tile edge ports are t0/m.
    OP and bit are distinct assigned point-components; no wildcard values.
    All target centers are roots. Entire100-type inventory at everycenter.
    """
    width = len(circuit['inputs']) + len(circuit['gates'])
    height = len(circuit['gates'])
    assert 0 < width * height <= 100
    def center(x, y):
        return 'c:%d:%d' % (x, y)
    def vertical(x, y, component):
        return 'v:%d:%d:%s' % (x, y, component)
    def horizontal(x, y):
        return 'h:%d:%d:bit' % (x, y)
    marks = []
    for y in range(height + 1):
        current = dict(roles(circuit, y))
        for x in range(width):
            marks.append([vertical(x, y, 'op'), current.get(x, 'CROSS')])
    for x in range(width):
        known = circuit['inputs'][x]['value'] if x < len(circuit['inputs']) else 0
        if known is not None:
            marks.append([vertical(x, 0, 'bit'), str(known)])
    marks.append([vertical(circuit['output'], height, 'bit'), '1'])
    marks.extend([horizontal(0, y), '0'] for y in range(height))
    placements = []
    for y in range(height):
        for x in range(width):
            for tile in palette_value['tiles']:
                m = [[vertical(x, y, 'op'), tile['N'][0]],
                     [vertical(x, y, 'bit'), str(tile['N'][1])],
                     [vertical(x, y+1, 'op'), tile['S'][0]],
                     [vertical(x, y+1, 'bit'), str(tile['S'][1])],
                     [horizontal(x, y), str(tile['W'])],
                     [horizontal(x+1, y), str(tile['E'])]]
                placements.append({'id': '%04d:%04d:%02d' % (y, x, tile['id']),
                                   't': [[center(x, y), 1]], 'm': m})
    return {'schema': 'Z-growing-point-model-v1', 'version': 'FP-finite-Wang-point-model-v1',
            'capacity': 1, 'roots': [center(x, y) for y in range(height) for x in range(width)],
            'seed': {'t': [], 'm': marks},
            'inventory': {'kind': 'EXPLICIT', 'placements': placements}}
