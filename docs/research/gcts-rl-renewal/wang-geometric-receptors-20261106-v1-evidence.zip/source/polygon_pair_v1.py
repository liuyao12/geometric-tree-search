"""Find a pair of individually extendible seeds with a shared boundary obstruction."""

from itertools import product
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_v1 as independent
from learn_v1 import pin, read, save, verify
from penrose_polygon_v1 import compile_region, search
from polygon_experiment_v1 import bank


def main():
    plan = read("polygon-pair-protocol-v1.json")
    verify(plan)
    dependency = Path(sys.argv[1])
    assert all(pin(dependency / name) == digest
               for name, digest in read("wang-protocol-v1.json")["pysat_files"].items())
    sys.path.insert(0, str(dependency))
    from pysat.solvers import Solver

    name = plan["case"]
    boundary = dict(bank())[name]
    world = compile_region(boundary, plan["vertices"])
    limits = plan["search"]
    first = search(boundary, world, (), Solver, limits)
    assert first["status"] == "POSITIVE"
    ids = {t: i for i, t in enumerate(world["tiles"], 1)}
    block = tuple(-ids[t] for t in first["witness"])
    other_world = dict(world, clauses=world["clauses"] + [block])
    second = search(boundary, other_world, (), Solver, limits)
    assert second["status"] == "POSITIVE"
    a, b = set(first["witness"]), set(second["witness"])
    attempts = []
    for left, right in product(sorted(a - b), sorted(b - a)):
        if not independent.contact(left, right):
            continue
        joint = search(boundary, world, (left, right), Solver, limits)
        attempts.append(joint["status"])
        if joint["status"] == "NEGATIVE":
            assert left in a and right in b and right not in a and left not in b
            save("data/polygon-pair-v1.json", dict(
                status="CHECKED_BOUNDARY_PAIR", case=name, boundary=boundary,
                world=world, attempts=attempts, seeds=(left, right),
                witnesses=(first["witness"], second["witness"]), joint=joint))
            return
    raise AssertionError("No checked pair obstruction")


if __name__ == "__main__":
    main()
