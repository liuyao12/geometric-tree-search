"""Compare frozen learned and initial weights in the identical frontier."""

import json
from pathlib import Path
import random
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from context_experiment_v1 import tree
from lemma_receptors_v1 import Offer
from lemma_search_v1 import Search
from transfer_experiment_v1 import catalog, compile_case, prop, replay_logic


def main():
    plan = prop.load("rank-ablation-protocol-v1.json")
    assert all(prop.pin(Path(path)) == digest for path, digest in plan["pins"].items())
    assert prop.pin(Path(sys.executable)) == plan["runtime"]
    previous = prop.load("data/transfer-v1.json")
    problems = {r["id"]: r for r in prop.load("input/new-cases-v1.json")}
    config = prop.load("protocol-v1.json")
    output = []
    for case in prop.load("data/context-v1.json"):
        name = case["id"]
        _, _, prefix, _, _ = compile_case(problems[name], dict(depth=0, premises=2, resolutions=1), config)
        bank = {row:o for row,o in catalog(prefix).items() if not row[0] & row[1]}
        for lib in case["libraries"]:
            pool = [Offer(**{k:tree(v) for k,v in o.items()}) for o in lib["offers"]]
            results = {}
            for label, weights in (("initial", plan["initial"]), ("learned", previous["weights"])):
                solver = Search(bank, pool, "trained", plan["search_limits"], weights, random.Random(0))
                status, root = solver.run()
                if root is not None:
                    _, premises, proof = solver.d.support(root, bank)
                    replay_logic(premises, proof, bank)
                results[label] = dict(status=status, stats=dict(solver.stats))
            output.append(dict(id=name, library=lib["library"], results=results))
            print(json.dumps(dict(id=name, library=lib["library"], results={
                k:(v["status"],v["stats"].get("pairs",0)) for k,v in results.items()}),
                sort_keys=True),flush=True)
    prop.save("data/rank-ablation-v1.json", output)


if __name__ == "__main__":
    main()
