"""Predeclared open Wang search with a conventional SAT control."""

from collections import Counter
import json
from pathlib import Path
import random
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from backjump_v1 import BoundarySearch
from open_wang_v1 import clauses, decode, layout, prop
from propagated_cuts_v1 import Replay


def compile_case(problem,spec,protocol):
    c,fixed,prefix,fields,funcs=layout(problem,spec,protocol)
    return c,clauses(c,fixed),prefix,fields,funcs


def custom(c,cnf,limits,mode,weights=None,rng=None):
    start=time.perf_counter()
    search=BoundarySearch(list(cnf),len(c["inputs"])+len(c["gates"]),len(c["inputs"]),
                          limits,mode,c["inputs"],weights,rng)
    status,bits=search.run()
    seconds=time.perf_counter()-start
    audit=Replay(cnf)
    for cut in search.ordered:
        assert audit.refute(cut),cut
        audit.add(cut)
    result=dict(mode=mode,status=status,seconds=seconds,counts=dict(search.stats),cuts=search.ordered)
    return result,bits,search.trace


def tutorial_problem(depth,noise,rng):
    names=[f"Q{i}" for i in range(depth+1+noise)]
    rng.shuffle(names)
    def rule(a,b):
        return ["all","?x","U",["implies",["atom",a,"?x"],["atom",b,"?x"]]]
    head,*_=names
    edges=[rule(a,b) for a,b in zip(names[:depth],names[1:depth+1],strict=True)]
    if noise>1:
        edges.extend(rule(a,b) for a,b in zip(names[depth+1:-1],names[depth+2:],strict=True))
    premises=[["atom",head,["a"]],*edges]
    rng.shuffle(premises)
    return dict(id="training",sorts=["U"],functions={"a":[[],"U"]},
                predicates={n:["U"] for n in names},equality=False,premises=premises,
                goal=["atom",names[depth],["a"]])


def train(protocol):
    t=protocol["training"]
    rng=random.Random(t["seed"])
    weights=[1.0,.8,0.0,0.0,0.0,0.0,0.0]
    average=.2
    rows=[]
    for k in range(t["episodes"]):
        d=rng.randint(1,3)
        problem=tutorial_problem(d,rng.randint(2,5),rng)
        spec=dict(depth=0,premises=d+2,resolutions=d+1)
        c,cnf,prefix,fields,funcs=compile_case(problem,spec,protocol)
        result,bits,trace=custom(c,cnf,t["limits"],"learned",weights,rng)
        if bits is not None:
            decode(bits,prefix,fields,funcs)
        score=1/(1+result["counts"].get("decisions",0)/20) if bits is not None else -.2
        advantage=score-average
        average=.9*average+.1*score
        if trace:
            for i,f in enumerate(zip(*trace,strict=True)):
                weights[i]=max(-4,min(4,weights[i]+t["rate"]*advantage*sum(f)/len(f)))
        rows.append(dict(episode=k,depth=d,reward=score,weights=weights[:],
                         status=result["status"],decisions=result["counts"].get("decisions",0),
                         checked_cuts=len(result["cuts"])))
    return weights,rows


def external(c,cnf,seed,conflicts,kind):
    from pysat.solvers import Solver
    start=time.perf_counter()
    with Solver(name=kind,bootstrap_with=cnf) as solver:
        for cut in seed:
            solver.add_clause(cut)
        solver.conf_budget(conflicts)
        status=solver.solve_limited()
        out=solver.get_model() if status is True else None
        counts=solver.accum_stats()
    elapsed=time.perf_counter()-start
    bits=None
    if out is not None:
        chosen=set(out)
        assert all(any(l in chosen for l in row) for row in cnf)
        bits=[int(i in chosen) for i in range(1,len(c["inputs"])+1)]
    return dict(mode=kind+("-seeded" if seed else ""),status={True:"SAT",False:"UNSAT",None:"BOUNDED"}[status],
                seconds=elapsed,counts=counts,seeded=len(seed)),bits


def main():
    protocol=prop.load("protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    deps=Path(sys.argv[1])
    assert all(prop.pin(deps/n)==v for n,v in protocol["pysat_files"].items())
    sys.path.insert(0,str(deps))
    import pysat
    assert pysat.__version__==protocol["pysat_version"]
    weights,history=train(protocol)
    palette=prop.wang.palette()
    problems={r["id"]:r for r in prop.load("input/cases-v1.json")+prop.load("input/new-cases-v1.json")
              +[prop.load("input/forgery-v1.json")]+prop.load("input/tutorial-cases-v1.json")["cases"]}
    rows=[]
    for spec in protocol["benchmark"]:
        name=spec["id"]
        c,cnf,prefix,fields,funcs=compile_case(problems[name],spec,protocol)
        results=[]
        seed=[]
        for mode in ("static","activity","learned","cadical195","glucose4","cadical-seeded"):
            if mode in ("static","activity","learned"):
                result,bits,_=custom(c,cnf,protocol["limits"],mode,weights)
                if mode=="activity":
                    seed=result["cuts"][:protocol["seed_limit"]]
            else:
                if mode=="cadical-seeded" and not seed:
                    continue
                result,bits=external(c,cnf,seed if mode=="cadical-seeded" else [],
                                     protocol["external_conflicts"],
                                     "cadical195" if mode=="cadical-seeded" else mode)
            if bits is not None:
                result["proof"]=decode(bits,prefix,fields,funcs)
                rectangle=prop.wang.certificate(c,bits,palette)
                receipt=prop.independent_wang.verify(c,rectangle,palette)
                assert receipt["status"]=="VERIFIED"
                result["rectangle"]=receipt
                if mode in ("activity","learned","cadical195"):
                    prop.compressed(f"data/{name}-{mode}-wang-v1.json.gz",
                                    dict(circuit=c,certificate=rectangle))
            results.append(result)
        rows.append(dict(id=name,spec=spec,gates=len(c["gates"]),cnf_clauses=len(cnf),
                         circuit_sha256=prop.wang.digest(c),results=results))
        print(json.dumps(dict(id=name,gates=len(c["gates"]),
            outcomes={r["mode"]:(r["status"],r["counts"].get("decisions",0),
                                  r["counts"].get("conflicts",0),round(r["seconds"],3)) for r in results}),
            sort_keys=True),flush=True)
    summary={}
    for row in rows:
        for r in row["results"]:
            mode=r["mode"]
            counts=summary.setdefault(mode,Counter())
            counts[r["status"]]+=1
    prop.save("data/results-v1.json",dict(palette_sha256=prop.wang.digest(palette),weights=weights,
                                        training=history,cases=rows,summary=summary))


if __name__=="__main__":
    main()
