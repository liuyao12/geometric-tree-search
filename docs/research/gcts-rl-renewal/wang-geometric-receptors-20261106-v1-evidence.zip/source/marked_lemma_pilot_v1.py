"""Check complementary-contact and subsumption marks with the same move set."""

import hashlib
import json
from pathlib import Path
import random
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from context_experiment_v1 import tree
from lemma_receptors_v1 import Offer
from lemma_search_v1 import Search
from transfer_experiment_v1 import catalog, compile_case, prop, replay_logic


def audit(s):
    rows = list(map(set, s.d.clauses))
    for i, (a, b, p) in s.d.steps.items():
        assert max(a, b) < i and p in rows[a] and -p in rows[b]
        assert (rows[a] - {p}) | (rows[b] - {-p}) == rows[i]
    for kind, a, b, *params in s.cuts:
        x, y = rows[a], rows[b]
        if kind == "pair":
            p, q = params
            assert p != q and {p, q} <= x and {-p, -q} <= y
            for lit in x:
                if -lit in y:
                    candidate = (x - {lit}) | (y - {-lit})
                    assert any(-v in candidate for v in candidate)
        else:
            assert kind == "subsumption"
            p, witness, frontier_size = params
            assert p in x and -p in y and s.enqueued_order[witness] < frontier_size
            result = (x - {p}) | (y - {-p})
            assert rows[witness] < result
    return len(s.cuts)


def main():
    plan = prop.load("marks-protocol-v1.json")
    assert prop.pin(Path(sys.executable)) == plan["runtime"]
    assert all(prop.pin(Path(k)) == p for k, p in plan["pins"].items())
    config = prop.load("protocol-v1.json")
    inputs = {r["id"]: r for r in prop.load("input/new-cases-v1.json")}
    output = []
    for case in prop.load("prior/context-v1.json"):
        name = case["id"]
        _, _, prefix, _, _ = compile_case(inputs[name], dict(depth=0, premises=2, resolutions=1), config)
        admitted = {row: o for row, o in catalog(prefix).items() if not row[0] & row[1]}
        lib = next(lib for lib in case["libraries"] if lib["library"] == "two-layer")
        offers = [Offer(**{k:tree(v) for k,v in o.items()}) for o in lib["offers"]]
        results = []
        for mode in ("cold", "seeded", "receptor"):
            for marked in (False, True):
                s = Search(admitted, offers, mode, plan["limits"], rng=random.Random(0), marking=marked)
                status, root = s.run()
                elapsed = time.monotonic() - s.started
                checks = audit(s)
                result = dict(mode=mode, marked=marked, status=status, seconds=elapsed,
                              stats=dict(s.stats), checked=checks)
                if root is not None:
                    origins, premises, proof = s.d.support(root, admitted)
                    replay_logic(premises, proof, admitted)
                    result["proof"] = dict(origins=origins, premises=premises, proof=proof, atoms=prefix.atoms)
                if s.cuts:
                    output_path = f"data/{name}-{mode}-cuts-v1.json.gz"
                    prop.compressed(output_path, dict(clauses=[sorted(c) for c in s.d.clauses],
                                                     steps=s.d.steps, marks=s.cuts, queued=s.enqueued_order))
                    result["trace"] = output_path
                results.append(result)
        output.append(dict(id=name, results=results))
        print(json.dumps(dict(id=name, modes=[(r["mode"],r["marked"],r["status"],r["stats"].get("pairs",0),
                                                 r["checked"],r["stats"].get("subset_probes",0)) for r in results]),
                         sort_keys=True),flush=True)
    prop.save("data/marks-v1.json", output)


if __name__ == "__main__":
    main()
