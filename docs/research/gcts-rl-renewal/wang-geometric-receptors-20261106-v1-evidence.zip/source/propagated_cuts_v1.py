"""Use checked boundary conflicts as propagation rules in the open Wang search."""

from collections import defaultdict, deque
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from open_wang_v1 import Search, clauses, decode, layout, prop


class Replay:
    """Independent agenda-based unit refutation on signed literal incidence."""
    def __init__(self,cnf):
        self.rows=[]
        self.index=defaultdict(list)
        self.units=[]
        for clause in cnf:
            self.add(clause)

    def add(self,clause):
        i=len(self.rows)
        self.rows.append(clause)
        for literal in clause:
            self.index[literal].append(i)
        if len(clause)==1:
            self.units.append(clause[0])

    def refute(self,cut):
        if any(not row for row in self.rows):
            return True
        assigned=set()
        queue=deque([*self.units,*[-literal for literal in cut]])
        while queue:
            x=queue.popleft()
            if x in assigned:
                continue
            if -x in assigned:
                return True
            assigned.add(x)
            for i in self.index[-x]:
                row=self.rows[i]
                if any(l in assigned for l in row):
                    continue
                remaining=[l for l in row if -l not in assigned]
                if not remaining:
                    return True
                if len(remaining)==1:
                    queue.append(remaining[0])
        return False


class CutSearch(Search):
    def cut(self,conflict):
        tasks=[abs(l) for l in self.cnf[conflict]]
        seen=set()
        projected=[]
        while tasks:
            i=tasks.pop()
            if i in seen:
                continue
            seen.add(i)
            cause=self.reason[i]
            if cause is None:
                assert i<=self.inputs
                projected.append(-i*self.val[i])
                continue
            literals=self.cnf[cause] if isinstance(cause,int) else cause
            tasks.extend(abs(l) for l in literals if abs(l)!=i)
        result=tuple(sorted(projected,key=abs))
        if result not in self.nogoods:
            self.nogoods.add(result)
            self.ordered.append(result)

    def closure(self):
        while True:
            conflict=self.propagate()
            if conflict is not None:
                self.stats["conflicts"]+=1
                if self.marked and len(self.ordered)<self.limits["marks"]:
                    self.cut(conflict)
                return False
            learned=0
            for cut in self.ordered:
                if any(self.value(l)>0 for l in cut):
                    continue
                left=[l for l in cut if self.value(l)==0]
                if not left:
                    self.stats["mark_hits"]+=1
                    return False
                if len(left)==1:
                    assert self.set(left[0],cut)
                    learned+=1
            self.stats["mark_forces"]+=learned
            if not learned:
                return True

    def run(self):
        for l,i in self.units:
            if not self.set(l,i):
                return "UNSAT",None
        def visit():
            if self.stats["nodes"]>=self.limits["nodes"] or time.monotonic()>=self.deadline:
                return "BOUNDED",None
            self.stats["nodes"]+=1
            if not self.closure():
                return "UNSAT",None
            p=next((i for i in self.order if not self.val[i]),None)
            if p is None:
                assert all(any(self.value(l)>0 for l in c) for c in self.cnf)
                return "SAT",[int(x>0) for x in self.val[1:self.inputs+1]]
            base=len(self.trail)
            for l in (-p,p):
                assert self.set(l,None)
                status,bits=visit()
                if status!="UNSAT":
                    return status,bits
                self.back(base)
            return "UNSAT",None
        return visit()


def main():
    protocol=prop.load("propagation-protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    inherited=prop.load("protocol-v1.json")
    problems={r["id"]:r for r in prop.load("input/cases-v1.json")+prop.load("input/new-cases-v1.json")
              +[prop.load("input/forgery-v1.json")]}
    palette=prop.wang.palette()
    rows=[]
    for spec in inherited["rectangles"]:
        name=spec["id"]
        circuit,fixed,prefix,fields,functions=layout(problems[name],spec,inherited)
        cnf=clauses(circuit,fixed)
        results=[]
        for mode in ("plain","propagate"):
            start=time.perf_counter()
            search=CutSearch(cnf,len(circuit["inputs"])+len(circuit["gates"]),len(circuit["inputs"]),
                             protocol["limits"],mode=="propagate")
            status,bits=search.run()
            seconds=time.perf_counter()-start
            replay=Replay(cnf)
            for cut in search.ordered:
                assert replay.refute(cut)
                replay.add(cut)
            result=dict(mode=mode,status=status,stats=dict(search.stats),seconds=seconds,
                        marks=[dict(clause=c,columns=[abs(l)-1 for l in c]) for c in search.ordered])
            if status=="SAT":
                result["derivation"]=decode(bits,prefix,fields,functions)
                rectangle=prop.wang.certificate(circuit,bits,palette)
                result["rectangle"]=prop.independent_wang.verify(circuit,rectangle,palette)
                assert result["rectangle"]["status"]=="VERIFIED"
                if mode=="propagate":
                    prop.compressed(f"data/{name}-propagated-wang-v1.json.gz",
                                    dict(circuit=circuit,certificate=rectangle))
            results.append(result)
        row=dict(id=name,boundary=spec,circuit_sha256=prop.wang.digest(circuit),results=results)
        rows.append(row)
        print(json.dumps(dict(id=name,modes={r["mode"]:(r["status"],r["stats"],len(r["marks"]))
                                            for r in results}),sort_keys=True),flush=True)
    prop.save("data/propagation-results-v1.json",rows)


if __name__=="__main__":
    main()
