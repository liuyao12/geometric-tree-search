"""Check a discovered proof with direct parent wires in the fixed Wang palette."""

import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from origin_v1 import OriginPrefix, Source
from serial_blocks_v1 import bits_for, compile_case, decode, prop


def compile_wired(prefix, source, proof):
    atoms = len(prefix.atoms)
    inputs = [dict(name="zero", value=0), dict(name="one", value=1)]
    bits = [0, 1]
    fields = []

    def boundary(name, value, width):
        positions = list(range(len(inputs), len(inputs) + width))
        inputs.extend(dict(name=f"{name}:{i}", value=None) for i in range(width))
        bits.extend((value >> i) & 1 for i in range(width))
        return positions

    for i, row in enumerate(proof):
        preceding = len(prefix.premises) + i
        assert 0 <= row["left"] < preceding and 0 <= row["right"] < preceding
        refs = max(1, (preceding - 1).bit_length())
        fixed = [[(row[key] >> j) & 1 for j in range(refs)] for key in ("left", "right")]
        p, n = prop.mask(row["clause"])
        fields.append((*fixed, boundary(f"line{i}:pivot", row["pivot"] - 1, max(1, (atoms - 1).bit_length())),
                       boundary(f"line{i}:positive", p, atoms), boundary(f"line{i}:negative", n, atoms)))
    origin = OriginPrefix(prefix, source)
    origin.inputs(inputs, bits)
    build = prop.wang.Builder(inputs)
    clauses, checks = origin.compile(build)
    for row, (_, _, pivot, cp, cn) in zip(proof, fields, strict=True):
        lp, ln = clauses[row["left"]]
        rp, rn = clauses[row["right"]]
        at = [build.word_eq(pivot, build.const_word(k, len(pivot))) for k in range(atoms)]
        checks.append(build.any(build.all((at[k], lp[k], rn[k])) for k in range(atoms)))
        for k in range(atoms):
            checks.extend((build.EQ(cp[k], build.OR(build.AND(lp[k], build.NOT(at[k])), rp[k])),
                           build.EQ(cn[k], build.OR(ln[k], build.AND(rn[k], build.NOT(at[k])))),
                           build.NOT(build.AND(cp[k], cn[k]))))
        clauses.append((cp, cn))
    checks.extend(build.NOT(x) for row in clauses[-1] for x in row)
    return build.finish(build.all(checks)), bits, fields


def main():
    plan = prop.load("wired-protocol-v1.json")
    assert all(prop.pin(Path(p)) == pin for p, pin in plan["pins"].items())
    assert prop.pin(Path(sys.executable)) == plan["runtime"]
    protocols = prop.load("protocol-v1.json")
    problems = {r["id"]: r for r in prop.load("input/new-cases-v1.json")}
    cases = {r["id"]: r for r in prop.load("data/context-v1.json")}
    palette = prop.wang.palette()
    receipts = []
    for spec in plan["cases"]:
        name, library, mode = (spec[k] for k in ("id", "library", "mode"))
        lib = next(l for l in cases[name]["libraries"] if l["library"] == library)
        row = next(r for r in lib["search"] if r["mode"] == mode)
        proof = row["proof"]
        p = problems[name]
        _, _, prefix, _, functions = compile_case(p, dict(depth=0, premises=2, resolutions=1), protocols)
        source = Source(p)
        source.clauses(protocols["cnf_limit"])
        prefix.origins, prefix.premises = proof["origins"], proof["premises"]
        prefix.rows = []
        original = proof["proof"]
        circuit, bits, fields = compile_wired(prefix, source, original)
        decoded = decode(bits, prefix, fields, functions)
        assert json.dumps(decoded, sort_keys=True) == json.dumps(proof, sort_keys=True)
        cert = prop.wang.certificate(circuit, bits, palette)
        physical = prop.independent_wang.verify(circuit, cert, palette)
        assert physical["status"] == "VERIFIED"
        bad = bits[:]
        bad[fields[-1][3][0]] ^= 1
        assert prop.wang.evaluate(circuit, bad)[1] == 0
        bad_cert = {**cert, "input_bits": bad}
        assert prop.independent_wang.verify(circuit, bad_cert, palette)["status"] != "VERIFIED"
        open_gates = None
        if spec["compare_open"]:
            layout = dict(depth=0, premises=len(proof["premises"]), resolutions=len(original))
            opened, _, op, of, fn = compile_case(p, layout, protocols)
            op.original = source
            ob = bits_for(opened, op, proof["origins"], proof["premises"], original)
            assert decode(ob, op, of, fn) == decoded
            assert prop.wang.evaluate(opened, ob)[1] == 1
            ob[of[-1][3][0]] ^= 1
            assert prop.wang.evaluate(opened, ob)[1] == 0
            open_gates = len(opened["gates"])
        filename = f"data/{name}-wired-wang-v1.json.gz"
        prop.compressed(filename, dict(circuit=circuit, certificate=cert))
        receipts.append(dict(id=name, library=library, mode=mode, proof=decoded,
                             rectangle=physical, rectangle_file=filename, gates=len(circuit["gates"]),
                             bad_final_clause="REJECTED", nested_used=row["nested_used"], open_gates=open_gates))
        print(json.dumps(dict(id=name,gates=len(circuit["gates"]),rows=len(original),
                              nested_used=row["nested_used"],status=physical["status"]),sort_keys=True),flush=True)
    prop.save("data/wired-v1.json", receipts)


if __name__ == "__main__":
    main()
