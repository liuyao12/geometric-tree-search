"""Compare exact clause search with and without marks and frozen learned ranking."""

import json
from math import exp
from pathlib import Path
import random
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import herbrand_v1 as fol
import resolution_v1 as prop


def features(row, processed):
    p,n=row
    potential=sum((p&b|n&a).bit_count() for a,b in processed)
    return (min((p|n).bit_count(),12)/12,p.bit_count()/12,n.bit_count()/12,
            min(potential,32)/32,float(not p or not n))


def ordered(problem, limits, marked, weights=None, generator=None):
    search=prop.Search(problem,limits,"MARKED" if marked else "PLAIN")
    processed=[]
    pending=set(range(search.premises))
    traces=[]
    while pending and search.budget() and (0,0) not in search.index:
        options=sorted(pending,key=lambda j:(sum(x.bit_count() for x in search.clauses[j]),j))
        i=options[0]
        if weights is not None:
            choices=options[:24]
            prior=[search.clauses[j] for j in processed]
            f=[features(search.clauses[j],prior) for j in choices]
            scores=[sum(x*w for x,w in zip(row,weights,strict=True)) for row in f]
            if generator is None:
                i=choices[max(range(len(choices)),key=lambda k:(scores[k],-k))]
            elif len(choices)>1:
                mass=[exp(s-max(scores)) for s in scores]
                chosen=generator.choices(range(len(choices)),weights=mass,k=1)[0]
                i=choices[chosen]
                scale=sum(mass)
                means=[sum(row[j]*w for row,w in zip(f,mass,strict=True))/scale for j in range(len(weights))]
                traces.append([x-y for x,y in zip(f[chosen],means,strict=True)])
        pending.remove(i)
        search.counts["selected"]+=1
        start=len(search.clauses)
        for j in processed:
            search.pair(i,j)
            if not search.budget() or (0,0) in search.index:
                break
        pending.update(range(start,len(search.clauses)))
        processed.append(i)
    status="UNSAT" if (0,0) in search.index else "SAT" if not pending else "BOUNDED"
    return search,status,traces


def train(protocol):
    rng=random.Random(protocol["training_seed"])
    weights=[0.0]*5
    average=0.0
    records=[]
    for episode in range(protocol["episodes"]):
        depth=rng.randint(3,12)
        route=rng.sample(range(1,25),depth)
        clauses=[[route[0]],[-route[-1]]]
        for a,b in zip(route,route[1:]):
            clauses.append([-a,b])
        for _ in range(16):
            a,b,c=rng.sample(range(25,70),3)
            clauses.append([(-1 if rng.getrandbits(1) else 1)*a,b,c])
        rng.shuffle(clauses)
        search,status,trace=ordered(clauses,protocol["limits"],True,weights,rng)
        prop.verify_marks(search)
        if status=="UNSAT":
            prop.verify_resolution(clauses,search.proof())
        reward=1/(1+search.counts["selected"]/10) if status=="UNSAT" else -.25
        advantage=reward-average
        average=.9*average+.1*reward
        if trace:
            for j,f in enumerate(zip(*trace,strict=True)):
                weights[j]=max(-4,min(4,weights[j]+protocol["rate"]*advantage*sum(f)/len(f)))
        records.append(dict(episode=episode,status=status,reward=reward,weights=weights[:],
                            selected=search.counts["selected"]))
    return weights,records


def evaluate(cases,protocol,weights):
    results=[]
    for case in cases:
        outcome=case["outcome"]
        if outcome["status"]!="PROVED":
            continue
        problem=case["compiled"]
        f,_,schemas=fol.signature(problem)
        depth=outcome["depth"]
        terms=fol.ground_terms(problem,f,depth,protocol["max_terms"])
        atoms,instances=fol.instances(schemas,terms,depth,protocol["max_ground"])
        assert atoms is not None
        clauses=[prop.literals(r) for r in instances]
        result=[]
        for mode in ("shortest","marked","learned","eliminate"):
            start=time.perf_counter()
            if mode=="eliminate":
                state=prop.Search(clauses,protocol["limits"],"ELIMINATE")
                status=state.eliminate(len(atoms))
            else:
                state,status,_=ordered(clauses,protocol["limits"],mode!="shortest",
                                       weights if mode=="learned" else None)
            seconds=time.perf_counter()-start
            count=prop.verify_marks(state)
            proof=state.proof() if status=="UNSAT" else None
            if proof:
                prop.verify_resolution(clauses,proof)
            result.append(dict(mode=mode,status=status,seconds=seconds,counts=dict(state.counts),
                               certified_marks=count,proof=proof))
        results.append(dict(id=problem["id"],depth=depth,clauses=len(clauses),atoms=len(atoms),methods=result))
    return results


def main():
    protocol=prop.load("comparison-protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/name)==v for name,v in protocol["pins"].items())
    weights,training=train(protocol)
    assert any(weights)
    cases=prop.load("data/results-v1.json")["cases"]
    rows=evaluate(cases,protocol,weights)
    summary={m:dict(proved=0,selected=0,pivots=0,marks=0) for m in ("shortest","marked","learned","eliminate")}
    for row in rows:
        for r in row["methods"]:
            s=summary[r["mode"]]
            s["proved"]+=r["status"]=="UNSAT"
            for k in ("selected","pivots"):
                s[k]+=r["counts"].get(k,0)
            s["marks"]+=r["certified_marks"]
    result=dict(status="CHECKED_SAME_GROUND_PROOF_SEARCH_COMPARISON",case_count=len(rows),weights=weights,
                totals=summary,
                scope="Each method sees the same entire grounded input. Depth is taken from a prior proof run. The policy is trained only on synthetic Horn chains, then frozen. Timing excludes proof and mark replay.")
    prop.save("data/comparison-v1.json",dict(result=result,training=training,cases=rows))
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
