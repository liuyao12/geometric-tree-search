"""Held-out quantified examples with relabelled and branching hypotheses."""


def atom(p,*args):
    return ["atom",p,*args]


def neg(a):
    return ["not",a]


def connect(tag,terms):
    rest=terms[-1]
    for item in reversed(terms[:-1]):
        rest=[tag,item,rest]
    return rest


def family(layers,broken=False,branch=False):
    kind="family-branch" if branch else "family-chain"
    name=f"{kind}-{layers}"+("-control" if broken else "")
    root=["matron"]
    groups=[[["first"]]]+[[[f"person{i}_{j}"] for j in range(2 if branch else 1)] for i in range(1,layers+1)]
    people=[root,*[x for row in groups for x in row]]
    premises=[atom("parent_of",root,p) for group in groups[:-1] for p in group]
    for i,(a,b) in enumerate(zip(groups[:-1],groups[1:],strict=True)):
        for j,x in enumerate(a):
            if broken and i==layers//2 and j==0:
                continue
            premises.append(connect("or",[atom("parent_of",x,y) for y in b]))
    premises.append(atom("patricide",groups[0][0]))
    premises.extend(neg(atom("patricide",y)) for y in groups[-1])
    condition=connect("and",[atom("parent_of",root,"?p"),atom("patricide","?p"),
                             atom("parent_of","?p","?n"),neg(atom("patricide","?n"))])
    goal=["exists","?p","U",["exists","?n","U",condition]]
    return dict(id=name,sorts=["U"],equality=False,
                functions={p[0]:[[],"U"] for p in people},
                predicates={"parent_of":["U","U"],"patricide":["U"]},premises=premises,goal=goal)


def geometry(axiom,size,broken=False):
    left=[[f"west{i}"] for i in range(size)]
    right=[[f"east{i}"] for i in range(size)]
    line1,line2=["firstline"],["secondline"]
    assumptions=[axiom,*[atom("I",p,line2) for p in left],*[atom("I",p,line1) for p in right]]
    for i,p in enumerate(left):
        for j,q in enumerate(right):
            if broken and i==j==0:
                continue
            assumptions.append(neg(atom("=Point",p,q)))
    assumptions.extend([connect("or",[atom("I",p,line1) for p in left]),
                        connect("or",[atom("I",q,line2) for q in right])])
    return dict(id=f"incidence-branch-{size}"+("-control" if broken else ""),
                sorts=["Point","Line"], equality=True,
                functions={**{p[0]:[[],"Point"] for p in left+right},
                           line1[0]:[[],"Line"],line2[0]:[[],"Line"]},
                predicates={"I":["Point","Line"]},premises=assumptions,
                goal=atom("=Line",line1,line2))


def cases(hilbert):
    return [family(6),family(6,broken=True),family(3,branch=True),family(3,branch=True,broken=True),
            family(5,branch=True),family(5,branch=True,broken=True),
            geometry(hilbert["premises"][0],2),geometry(hilbert["premises"][0],2,broken=True),
            geometry(hilbert["premises"][0],3),geometry(hilbert["premises"][0],3,broken=True)]
