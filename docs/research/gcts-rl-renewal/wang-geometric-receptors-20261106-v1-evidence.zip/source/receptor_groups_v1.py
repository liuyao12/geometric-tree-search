"""Check one reusable Wang lemma across Penrose and Turtle receptors."""

from functools import lru_cache
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_v1 as penrose
from cluster_v1 import Model
from fixed_route_v1 import compile_route
from geometry_wang_v1 import reconstruct
from penrose_lazy_experiment_v1 import exact
import resolution_v1 as logic
import turtle_points_v1 as turtle


def partition(placements, blocks):
    groups = [[], []]
    alternatives = [[], []]
    for placement in placements:
        choices = blocks(placement)
        assert choices
        groups[choices[0]].append(placement)
        if len(choices) == 1:
            alternatives[choices[0]].append(placement)
    assert all(alternatives)
    return groups, [choices[0] for choices in alternatives]


def turtle_bindings(source, cuts):
    model = Model(source)
    scale = model.scale
    outlines = {g:tuple((scale*x,scale*y) for x,y in poly) for g,poly in model.polygons.items()}

    @lru_cache(maxsize=None)
    def inside(point, placement):
        g,dx,dy=placement
        q=(point[0]-scale*dx,point[1]-scale*dy)
        polygon=outlines[g]
        assert not any(turtle.on_segment(q,a,b) for a,b in turtle.edges(polygon))
        return turtle.inside(q,polygon)

    @lru_cache(maxsize=None)
    def inventory(q):
        indexed=set()
        for g, atoms in model.atoms.items():
            for a,b in atoms:
                u,v=q[0]-a,q[1]-b
                if u%scale==0 and v%scale==0:
                    indexed.add((g,u//scale,v//scale))
        geometric=set()
        for g, polygon in outlines.items():
            xs,ys=zip(*polygon)
            for x in range(-((max(xs)-q[0])//scale),(q[0]-min(xs))//scale+1):
                for y in range(-((max(ys)-q[1])//scale),(q[1]-min(ys))//scale+1):
                    candidate=(g,x,y)
                    if inside(q,candidate):
                        geometric.add(candidate)
        assert indexed==geometric and len(geometric)==240
        return tuple(sorted(geometric))

    rows=[]
    for cut in cuts:
        if (len(cut["required"]),len(cut["excluded"]),cut["checked_nodes"]) != (1,2,1):
            continue
        q,=exact(cut["required"])
        excluded=exact(cut["excluded"])
        options=inventory(q)
        groups,restored=partition(options, lambda t: tuple(i for i,x in enumerate(excluded) if inside(x,t)))
        rows.append(dict(signature=cut["signature"],required=q,excluded=excluded,groups=groups,
                         restored_after_relaxing_one=restored))
    return rows


def penrose_bindings(data):
    rows=[]
    for case in data["cases"][:3]:
        port=exact(case["ports"][0])
        envelope=exact(case["envelope"])
        seeds=exact(case["seeds"])
        options,*_=reconstruct(port,envelope,seeds)
        groups,restored=partition(options,lambda t:tuple(i for i,s in enumerate(seeds)
                                                        if t!=s and not penrose.contact(t,s)))
        rows.append(dict(case=case["id"],port=port,envelope=envelope,seeds=seeds,groups=groups,
                         restored_after_relaxing_one=restored))
    return rows


def main():
    p=logic.load("group-protocol-v1.json")
    assert p["runtime"] == logic.pin(Path(sys.executable))
    assert all(logic.pin(logic.ROOT/name)==digest for name,digest in p["pins"].items())
    turtle_cases=turtle_bindings(logic.load("input/turtle-model-v1.json"),logic.load("input/turtle-cuts-v1.json"))
    penrose_cases=penrose_bindings(logic.load("input/envelope-v1.json"))
    assert len(turtle_cases)==156 and len(penrose_cases)==3
    # R, X_1, X_2, G_1, G_2. Each group witnesses at least one chosen placement.
    theory=[[-1,4,5],[-2,-4],[-3,-5]]
    assumptions=[[1],[2],[3]]
    problem=theory+assumptions
    search=logic.Search(problem,p["limits"],"MARKED")
    assert search.given()=="UNSAT"
    proof=search.proof()
    premises=[logic.literals(logic.mask(c)) for c in problem]
    logic.verify_resolution(premises,proof)
    palette=logic.wang.palette()
    circuit,bits,_=logic.circuit(5,premises,proof)
    cert=logic.wang.certificate(circuit,bits,palette)
    checked=logic.independent_wang.verify(circuit,cert,palette)
    assert checked["status"]=="VERIFIED"
    logic.compressed("data/group-wang-v1.json.gz",dict(circuit=circuit,certificate=cert))
    compact,route_bits,fields=compile_route(5,premises,proof)
    route_cert=logic.wang.certificate(compact,route_bits,palette)
    route_check=logic.independent_wang.verify(compact,route_cert,palette)
    assert route_check["status"]=="VERIFIED" and route_check["cells"]<checked["cells"]
    for index in (v for row in fields for bank in row for v in bank):
        altered=route_bits[:]
        altered[index]^=1
        assert logic.wang.evaluate(compact,altered)[1]==0
    logic.compressed("data/group-wang-route-v1.json.gz",dict(circuit=compact,certificate=route_cert))
    unique=len({(r["required"],r["excluded"]) for r in turtle_cases})
    assert unique==34
    logic.save("data/group-v1.json",dict(status="CHECKED_SHARED_RECEPTOR_LEMMA",premises=premises,proof=proof,
                                        receipt=checked,route=route_check,turtle=turtle_cases,
                                        turtle_distinct=unique,penrose=penrose_cases))
    print(json.dumps(dict(turtle=len(turtle_cases),penrose=len(penrose_cases),lines=len(proof),
                          virtual_squares=checked["cells"],route_squares=route_check["cells"])),flush=True)


if __name__ == "__main__":
    main()
