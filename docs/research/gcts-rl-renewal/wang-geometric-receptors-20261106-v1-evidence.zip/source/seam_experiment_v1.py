"""Compose certified hexagon patches and compare search across their seams."""

from itertools import combinations
import json
from pathlib import Path
import sys
from time import monotonic

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_v1 as independent
import model_v1 as model
from edge_receptor_v1 import learn, move, tile_move, transfer
from envelope_experiment_v1 import hull
from envelope_v1 import compile_world, validate
from learn_v1 import pin, read, save, verify
from penrose_lazy_experiment_v1 import evidence, exact
from penrose_polygon_v1 import validate as check_full
from penrose_sat_v1 import solve


def shift(u, v, i, j):
    return tuple(i*x+j*y for x, y in zip(u, v, strict=True))


def compose(boundary, variants, side, seed_stride, turn):
    u, v, w = model.DIRECTIONS[:3]
    along = model.add(v, w)
    across = model.sub(u, w)
    selected = set()
    placements = []
    ports = []
    seeds = []
    for i in range(side):
        for j in range(side):
            offset = shift(along, across, i, j)
            local = variants[(i+j)%len(variants)]
            poly = tuple(move(p, turn, model.rotate(offset, turn)) for p in boundary)
            tiles = {tile_move(t, turn, model.rotate(offset, turn)) for t in local}
            assert not selected.intersection(tiles)
            selected.update(tiles)
            placements.append(poly)
            ports.append((poly[0], poly[1]))
            if seed_stride and (i*side+j)%seed_stride == 0:
                seeds.append(min(tiles))
    sectors = {}
    for tile in selected:
        for p in tile:
            mask = independent.corners(p)[tile]
            assert not sectors.get(p, 0) & mask
            sectors[p] = sectors.get(p, 0) | mask
    targets = tuple(sorted(p for p, mask in sectors.items() if mask == model.FULL))
    frame = tuple(model.rotate(p, turn) for p in hull(-3*side, -3*side, 3*side, 3*side))
    assert len(targets) > len(placements)
    return placements, frame, targets, tuple(ports), tuple(seeds), selected


def run():
    plan = read("seam-protocol-v1.json")
    verify(plan)
    parent = read("protocol-v1.json")
    dependency = Path(sys.argv[1])
    assert all(pin(dependency / n) == d for n, d in read("input/wang-protocol-v1.json")["pysat_files"].items())
    sys.path.insert(0, str(dependency))
    from pysat.solvers import Solver

    donor = read("input/polygon-pair-v1.json")
    boundary, seeds, variants = map(exact, (donor["boundary"], donor["seeds"], donor["witnesses"]))
    for variant in variants:
        check_full(boundary, variant)
    templates, _ = learn(boundary, seeds, Solver)
    results = []
    for side, seed_stride, turn in plan["cases"]:
        started = monotonic()
        placements, frame, targets, ports, seeds, selected = compose(boundary, variants, side, seed_stride, turn)
        world = compile_world(targets, ports, frame, seeds)
        validate(world, selected, frame, seeds)
        adjacencies = [(i,j) for (i,a),(j,b) in combinations(enumerate(placements),2)
                       if len(set(a).intersection(b)) == 2]
        assert len(adjacencies) >= len(placements)-1
        reached={0}
        for _ in placements:
            for i,j in adjacencies:
                if i in reached or j in reached:
                    reached.update((i,j))
        assert len(reached) == len(placements)
        mark, receipts = transfer(world, templates)
        setup_seconds = monotonic()-started
        arms = [("plain", {}, parent["initial"], None), ("marked", mark, parent["initial"], None),
                ("learned", mark, parent["learned"], None), ("glucose", {}, parent["initial"], Solver),
                ("glucose-marked", mark, parent["initial"], Solver)]
        rows = []
        for label, known, weights, solver in arms:
            r = solve(world, known, plan["budget"], weights, solver=solver)
            assert r["status"] in {"POSITIVE", "BOUNDED"}
            if r["status"] == "POSITIVE":
                validate(world, set(r["witness"]), frame, seeds)
            assert evidence(world, r, known)
            r.pop("gradients")
            rows.append(dict(arm=label, **r))
        print(json.dumps(dict(side=side, turn=turn, seeds=len(seeds), targets=len(targets),
                              candidates=len(world["tiles"]), seams=len(adjacencies), marks=len(mark),
                              arms=[(r["arm"],r["status"],r["counts"].get("decisions",0),len(r["geometry"]),
                                     round(r["seconds"],4)) for r in rows])), flush=True)
        results.append(dict(side=side, turn=turn, envelope=frame, targets=targets, ports=ports, seeds=seeds,
                            composition=sorted(selected), clusters=placements, seams=adjacencies,
                            tiles=world["tiles"], cnf=world["clauses"], marks=receipts, setup_seconds=setup_seconds,
                            results=rows))
    save("data/seam-v1.json", dict(status="CHECKED_CONNECTED_MACRO_PATCHES", cases=results))


if __name__ == "__main__":
    run()
