"""Compare triggered source matching with full finite grounding."""

from itertools import product
import json
from math import prod
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from demand_ground_v1 import Demand
from ground_control_v1 import Derivation
from in_grid_v1 import Prefix
from origin_v1 import Source
from serial_blocks_v1 import catalog, decode, prop
from wired_replay_v1 import compile_wired


def alias_case(positive):
    p = lambda t: ["atom","P",t]
    q = lambda t: ["atom","Q",t]
    rule = ["all","?x","U",["all","?y","U",["or",p("?x"),["or",p("?y"),["not",q("?x")]]]]]
    return dict(id="alias-positive" if positive else "alias-control",
                sorts=["U"],functions={"a":[[],"U"],"b":[[],"U"]},
                predicates={"P":["U"],"Q":["U"]},equality=False,
                premises=[rule,q(["a" if positive else "b"])],goal=p(["a"]))


def main():
    plan=prop.load("demand-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    config=prop.load("protocol-v1.json")
    agatha=prop.load("prior/agatha-v1.json")["source"]
    originals={r["id"]:r for r in [agatha,*prop.load("input/new-cases-at-parent-v1.json"),
              *prop.load("input/cases-v1.json"),*prop.load("input/tutorial-cases-v1.json")["cases"],
              alias_case(True),alias_case(False)]}
    palette=prop.wang.palette()
    rows=[]
    for name,depth,expected in plan["cases"]:
        original=originals[name]
        src=Source(original)
        normalized=src.clauses(config["cnf_limit"])
        functions,predicates,schemas=fol.signature(normalized)
        terms=fol.ground_terms(normalized,functions,depth,config["max_terms"])
        begin=time.monotonic()
        lazy=Demand(schemas,terms,predicates,plan["budget"])
        status=lazy.run()
        elapsed=time.monotonic()-begin
        atoms=sorted((pred,*args) for pred,sorts in predicates.items()
                     for args in product(*(terms[s] for s in sorts)))
        begin=time.monotonic()
        full=catalog(Prefix(schemas,terms,atoms,[],[]))
        full={r:o for r,o in full.items() if not r[0]&r[1]}
        baseline=Derivation(full)
        root=baseline.refute(frozenset())
        full_elapsed=time.monotonic()-begin
        assert status==expected==("REFUTED" if root is not None else "UNIT_FIXED_POINT")
        if status=="UNIT_FIXED_POINT":
            facts={(sign,atom) for (sign,_),bucket in lazy.facts.items() for atom in bucket}
            for row in full:
                literals={(lit>0,atoms[abs(lit)-1]) for lit in prop.literals(row)}
                if not facts.intersection(literals):
                    assert sum((not s,a) not in facts for s,a in literals)>=2
        receipt=dict(id=name,depth=depth,status=status,counts=dict(lazy.counts),seconds=elapsed,
                     full=dict(admitted=len(full),scans=baseline.scans,seconds=full_elapsed,
                               assignments=sum(prod(len(terms[s]) for s in c["variables"].values()) for c in schemas)))
        if lazy.root is not None:
            proof=lazy.proof()
            fol.verify_instances(schemas,proof["origins"],proof["premises"],proof["atoms"],functions)
            prop.verify_resolution(proof["premises"],proof["proof"])
            receipt["proof"]=proof
            if [name,depth] in plan["export"]:
                prefix=Prefix(schemas,terms,proof["atoms"],proof["origins"],proof["premises"])
                circuit,bits,fields=compile_wired(prefix,src,proof["proof"])
                assert decode(bits,prefix,fields,functions)==proof
                rect=prop.wang.certificate(circuit,bits,palette)
                check=prop.independent_wang.verify(circuit,rect,palette)
                assert check["status"]=="VERIFIED"
                path=f"data/{name}-d{depth}-demand-wang-v1.json.gz"
                prop.compressed(path,dict(circuit=circuit,certificate=rect))
                receipt.update(rectangle=check,rectangle_file=path)
        print(json.dumps({k:v for k,v in receipt.items() if k not in ("proof","rectangle")},sort_keys=True),flush=True)
        rows.append(receipt)
    prop.save("data/demand-v1.json", rows)


if __name__=="__main__":
    main()
