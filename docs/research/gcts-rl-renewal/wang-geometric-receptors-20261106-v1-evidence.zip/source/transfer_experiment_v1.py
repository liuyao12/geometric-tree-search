"""Ablate learned clause-cluster transfer on held-out branching proofs."""

from dataclasses import asdict, replace
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from lemma_receptors_v1 import atom_types, extract, fit, ordered, verify
from lemma_search_v1 import Search, train
from origin_v1 import Source
from serial_blocks_v1 import bits_for, catalog, compile_case, decode, prop


def recipe_audit(offer, pattern, types, bank):
    mapping = offer.mapping
    assert len(mapping) == len(pattern.types) == len(set(mapping))
    assert all(0 < b <= len(types) for b in mapping)
    assert tuple(types[b - 1] for b in mapping) == pattern.types

    def ground(row):
        return {mapping[v - 1] if v > 0 else -mapping[-v - 1] for v in row}

    assert list(map(set, offer.leaves)) == [ground(row) for row in pattern.leaves]
    for (a, b, pivot, row), (i, j, symbol, output) in zip(offer.steps, pattern.steps, strict=True):
        assert (a, b, pivot) == (i, j, mapping[symbol - 1]) and set(row) == ground(output)
    assert verify(offer, bank)


def replay_logic(premises, proof, allowed):
    rows = list(map(set, premises))
    assert all(prop.mask(r) in allowed for r in rows)
    for step in proof:
        a, b, pivot = step["left"], step["right"], step["pivot"]
        assert 0 <= a < len(rows) and 0 <= b < len(rows) and pivot > 0
        assert pivot in rows[a] and -pivot in rows[b]
        expected = (rows[a] - {pivot}) | (rows[b] - {-pivot})
        assert set(step["clause"]) == expected
        rows.append(expected)
    assert rows and not rows[-1]


def main():
    plan = prop.load("transfer-protocol-v1.json")
    protocol = prop.load("protocol-v1.json")
    assert plan["runtime"] == prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT / p) == h for p, h in plan["pins"].items())
    dep = Path(sys.argv[1])
    assert all(prop.pin(dep / p) == h for p, h in protocol["pysat_files"].items())
    sys.path.insert(0, str(dep))
    from pysat.solvers import Solver
    cases = {r["id"]: r for r in prop.load("input/new-cases-v1.json")}
    prior = {r["id"]: r for r in prop.load("prior/ground-control-v1.json")}
    palette = prop.wang.palette()
    patterns = []
    donors = []
    for name in plan["donors"]:
        row = prior[name]
        file = ROOT / "prior" / f"{name}-ground-control-v1.json.gz"
        with gzip.open(file, "rt") as stream:
            saved = json.load(stream)
        check = prop.independent_wang.verify(saved["circuit"], saved["certificate"], palette)
        assert check == row["rectangle"] and check["status"] == "VERIFIED"
        types = atom_types(cases[name], row["proof"]["atoms"])
        for pattern, root in extract(row["proof"], types, *plan["cluster_steps"]):
            if pattern not in patterns:
                donors.append(dict(donor=name, root=root, pattern=asdict(pattern)))
                patterns.append(pattern)
    assert patterns
    weights, episodes = train(patterns, fit, plan["training"])
    outputs = []
    for name in plan["held_out"]:
        problem = cases[name]
        spec = dict(id=name, depth=0, premises=2, resolutions=1)
        _, _, prefix, _, _ = compile_case(problem, spec, protocol)
        admitted = {r: o for r, o in catalog(prefix).items() if not r[0] & r[1]}
        bank = {ordered(prop.literals(c)) for c in admitted}
        types = atom_types(problem, prefix.atoms)
        start = time.monotonic()
        offers, matching = fit(patterns, bank, types, plan["match_trials"], plan["match_offers"])
        matching["seconds"] = time.monotonic() - start
        start = time.monotonic()
        for offer in offers:
            recipe_audit(offer, patterns[offer.pattern], types, bank)
        if offers:
            first = offers[0]
            a, b, p, c = first.steps[-1]
            assert not verify(replace(first, steps=first.steps[:-1] + ((a, b, len(types) + 1, c),)), bank)
            assert not verify(replace(first, leaves=first.leaves[:-1] + ((len(types) + 1,),)), bank)
        matching["replay_seconds"] = time.monotonic() - start
        matching["replay_steps"] = sum(len(o.steps) for o in offers)
        modes = [(m, None) for m in ("cold", "seeded", "receptor", "trained")]
        modes.extend(("shuffled", seed) for seed in plan["sham_seeds"])
        results = []
        for mode, seed in modes:
            search = Search(admitted, offers, mode, plan["search_limits"], weights, random.Random(seed))
            status, root = search.run()
            row = dict(mode=mode, seed=seed, status=status, seconds=time.monotonic() - search.started,
                       stats=dict(search.stats))
            if root is not None:
                origins, premises, proof = search.d.support(root, admitted)
                replay_logic(premises, proof, admitted)
                row["used_offers"] = [asdict(o) for o in search.used(root)]
                row["proof"] = dict(origins=origins, premises=premises, proof=proof, atoms=prefix.atoms)
            results.append(row)
        baseline = []
        base = [list(row) for row in sorted(bank)]
        for mode, seeded in (("glucose-cold", []), ("glucose-same-library", sorted({o.result for o in offers}))):
            start = time.monotonic()
            with Solver(name="glucose4", bootstrap_with=[*base, *seeded]) as solver:
                solver.conf_budget(plan["sat_conflicts"])
                sat = solver.solve_limited()
                stats = solver.accum_stats()
                model = solver.get_model() if sat else None
            if model is not None:
                truth = set(model)
                assert all(truth.intersection(row) for row in [*base, *seeded])
            baseline.append(dict(mode=mode, imported=len(seeded), seconds=time.monotonic() - start,
                                 status={False:"REFUTED", True:"GROUND_MODEL", None:"BOUNDED"}[sat], stats=stats,
                                 model=model))
        seen = {}
        for row in results:
            if row["mode"] not in plan["export_modes"] or "proof" not in row:
                continue
            p = row["proof"]
            m, r = len(p["premises"]), len(p["proof"])
            if max(m, r) > plan["certificate_cap"] or not r:
                continue
            digest = hashlib.sha256(json.dumps(p, sort_keys=True).encode()).hexdigest()
            if digest in seen:
                row["rectangle_file"], row["rectangle"] = seen[digest]
                continue
            c, _, prefix, fields, functions = compile_case(problem, {**spec, "premises":m, "resolutions":r}, protocol)
            prefix.original = Source(problem)
            prefix.original.clauses(protocol["cnf_limit"])
            bits = bits_for(c, prefix, p["origins"], p["premises"], p["proof"])
            assert decode(bits, prefix, fields, functions) == p
            rectangle = prop.wang.certificate(c, bits, palette)
            row["rectangle"] = prop.independent_wang.verify(c, rectangle, palette)
            assert row["rectangle"]["status"] == "VERIFIED"
            path = f'data/{name}-{row["mode"]}-transfer-wang-v1.json.gz'
            prop.compressed(path, dict(circuit=c, certificate=rectangle))
            row["rectangle_file"] = path
            seen[digest] = path, row["rectangle"]
        rows = [dict(mode=r["mode"], seed=r["seed"], status=r["status"],
                     pairs=r["stats"].get("pairs", 0), replays=r["stats"].get("macro_replays", 0),
                     used=len(r.get("used_offers", ())), verified="rectangle" in r) for r in results]
        print(json.dumps(dict(id=name, matching=matching, search=rows,
                              glucose=[(r["status"], r["stats"]["conflicts"]) for r in baseline]),
                         sort_keys=True), flush=True)
        outputs.append(dict(id=name, matching=matching, offers=[asdict(o) for o in offers],
                            results=results, external=baseline))
    prop.save("data/transfer-v1.json", dict(donors=donors, training=episodes, weights=weights,
                                          cases=outputs, palette=prop.wang.digest(palette)))


if __name__ == "__main__":
    main()
