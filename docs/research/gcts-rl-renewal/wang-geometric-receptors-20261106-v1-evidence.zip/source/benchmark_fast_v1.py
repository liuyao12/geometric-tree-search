"""Run the frozen search benchmark with an independent faster cut verifier."""

import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import benchmark_v1 as bench


def audit(cnf,cuts,variables,binary):
    if not cuts:
        return 0
    lines=[f"{variables} {len(cnf)} {len(cuts)}"]
    lines.extend(" ".join(map(str,(len(c),*c))) for c in [*cnf,*cuts])
    raw=("\n".join(lines)+"\n").encode()
    proc=subprocess.run([binary],input=raw,capture_output=True,check=True,timeout=120)
    result=int(proc.stdout)
    assert result==len(cuts)
    return result


def qualify(binary):
    for cnf,cut,expected in [
        ([(1,),(-1,2)],(2,),True),
        ([(1,2)],(1,),False),
        ([(1,),(-1,)],(),True),
    ]:
        assert bench.Replay(cnf).refute(cut)==expected
        try:
            result=audit(cnf,[cut],2,binary)
        except subprocess.CalledProcessError:
            result=0
        assert bool(result)==expected


def main():
    protocol=bench.prop.load("fast-protocol-v1.json")
    binary=Path(sys.argv[2]).resolve()
    assert protocol["binary"]==bench.prop.pin(binary)
    assert all(bench.prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    qualify(binary)
    def custom(c,cnf,limits,mode,weights=None,rng=None):
        start=time.perf_counter()
        variables=len(c["inputs"])+len(c["gates"])
        s=bench.BoundarySearch(list(cnf),variables,len(c["inputs"]),limits,mode,c["inputs"],weights,rng)
        status,bits=s.run()
        seconds=time.perf_counter()-start
        start=time.perf_counter()
        audit(cnf,s.ordered,variables,str(binary))
        return dict(mode=mode,status=status,seconds=seconds,counts=dict(s.stats),
                    cuts=s.ordered,replay_seconds=time.perf_counter()-start),bits,s.trace
    bench.custom=custom
    save,compressed=bench.prop.save,bench.prop.compressed
    (ROOT/"data/fast").mkdir()
    def target(name):
        assert name.startswith("data/")
        return "data/fast/"+name.removeprefix("data/")
    bench.prop.save=lambda name,v:save(target(name),v)
    bench.prop.compressed=lambda name,v:compressed(target(name),v)
    bench.main()


if __name__=="__main__":
    main()
