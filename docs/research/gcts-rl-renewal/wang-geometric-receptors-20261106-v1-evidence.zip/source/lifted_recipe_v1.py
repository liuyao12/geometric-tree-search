"""Lift checked ground resolution fragments to typed term receptors."""

from dataclasses import dataclass
from collections import Counter, defaultdict

import herbrand_v1 as fol
from serial_blocks_v1 import prop


def rewrite(term, env):
    if isinstance(term,str):
        return rewrite(env[term],env) if term in env else term
    return (term[0],*(rewrite(x,env) for x in term[1:]))


def variables(term):
    if isinstance(term,str):
        return {term}
    return set().union(*(variables(x) for x in term[1:]))


def unify(left,right,env,types,functions):
    pending=list(zip(left,right,strict=True))
    while pending:
        a,b=(rewrite(t,env) for t in pending.pop())
        if a==b:
            continue
        if isinstance(b,str) and not isinstance(a,str):
            a,b=b,a
        if isinstance(a,str):
            if a in variables(b) or types[a]!=fol.inspect_term(b,types,functions):
                return False
            env[a]=b
        else:
            if not isinstance(b,tuple) or a[0]!=b[0] or len(a)!=len(b):
                return False
            pending.extend(zip(a[1:],b[1:],strict=True))
    return True


def order(row):
    return tuple(sorted(set(row),key=repr))


def mapped(row,env):
    return order((s,rewrite(a,env)) for s,a in row)


@dataclass(frozen=True)
class Recipe:
    types: tuple
    leaves: tuple
    steps: tuple

    @property
    def output(self):
        return self.steps[-1][3]


@dataclass(frozen=True)
class Placement:
    recipe: int
    binding: tuple
    leaves: tuple
    steps: tuple

    @property
    def result(self):
        return self.steps[-1][3]


def fragment(proof,node):
    m=len(proof["premises"])
    needed=set()
    pending=[node]
    while pending:
        n=pending.pop()
        if n in needed:
            continue
        needed.add(n)
        if n>=m:
            line=proof["proof"][n-m]
            pending.extend((line["left"],line["right"]))
    return sorted(needed)


def lift(proof,schemas,functions,maximum,parameterize=True):
    by_id={s["id"]:s for s in schemas}
    atoms=list(map(fol.frozen,proof["atoms"]))
    base=len(proof["premises"])
    concrete=[*proof["premises"],*(s["clause"] for s in proof["proof"])]

    def ground_row(i):
        return order((v>0,atoms[abs(v)-1]) for v in concrete[i])

    for root in range(base,len(concrete)):
        support=fragment(proof,root)
        if not concrete[root] or not 1<=sum(n>=base for n in support)<=maximum:
            continue
        local={}
        index={i:k for k,i in enumerate(support)}
        ty={}
        witness={}
        constants={}
        env={}
        steps=[]
        leaves=[]
        succeeded=True
        for i in support:
            if i<base:
                origin=proof["origins"][i]
                schema=by_id[origin["schema"]]
                rename={}
                for v,s in sorted(schema["variables"].items()):
                    fresh=f"?v{len(ty)}"
                    ty[fresh]=s
                    rename[v]=fresh
                    witness[fresh]=fol.frozen(origin["substitution"][v])

                def convert(term):
                    if isinstance(term,str):
                        return rename[term]
                    if len(term)==1 and parameterize:
                        if term not in constants:
                            var=f"?c{len(constants)}"
                            constants[term]=var
                            ty[var]=functions[term[0]][1]
                            witness[var]=term
                        return constants[term]
                    return (term[0],*(convert(t) for t in term[1:]))

                row=order((s,(a[0],*(convert(t) for t in a[1:]))) for s,a in schema["clause"])
                assert mapped(row,witness)==ground_row(i)
                local[i]=row
                leaves.append(row)
                continue
            rule=proof["proof"][i-base]
            li,ri=rule["left"],rule["right"]
            pivot=atoms[rule["pivot"]-1]
            lp=[rewrite(a,env) for s,a in local[li] if s and rewrite(a,witness)==pivot]
            rp=[rewrite(a,env) for s,a in local[ri] if not s and rewrite(a,witness)==pivot]
            if not lp or not rp or not all(unify(lp[0][1:],x[1:],env,ty,functions) for x in lp[1:]+rp):
                succeeded=False
                break
            symbolic=rewrite(lp[0],env)
            left,right=set(mapped(local[li],env)),set(mapped(local[ri],env))
            assert (True,symbolic) in left and (False,symbolic) in right
            row=order((left-{(True,symbolic)}) | (right-{(False,symbolic)}))
            if mapped(row,witness)!=ground_row(i):
                succeeded=False
                break
            local[i]=row
            steps.append((index[li],index[ri],symbolic,row))
        if not succeeded:
            continue
        leaves=tuple(mapped(r,env) for r in leaves)
        steps=tuple((a,b,rewrite(p,env),mapped(r,env)) for a,b,p,r in steps)
        live=sorted(set().union(*(variables(a) for row in leaves for _,a in row)))
        names={v:f"?p{i}" for i,v in enumerate(live)}
        leaf=tuple(mapped(r,names) for r in leaves)
        path=tuple((a,b,rewrite(p,names),mapped(r,names)) for a,b,p,r in steps)
        types=tuple((names[v],ty[v]) for v in live)
        if types and check_symbolic(Recipe(types,leaf,path)):
            yield root,Recipe(types,leaf,path)


def check_symbolic(recipe):
    rows=list(map(set,recipe.leaves))
    for a,b,pivot,result in recipe.steps:
        if not 0<=a<len(rows) or not 0<=b<len(rows):
            return False
        left,right=rows[a],rows[b]
        if (True,pivot) not in left or (False,pivot) not in right:
            return False
        if (left-{(True,pivot)}) | (right-{(False,pivot)}) != set(result):
            return False
        rows.append(set(result))
    return bool(recipe.steps)


def grounded(recipe,index,env,atom_ids,base):
    try:
        def bits(row):
            return tuple(prop.literals(prop.mask((1 if sign else -1)*atom_ids[rewrite(a,env)]
                                                  for sign,a in row)))
        leaves=tuple(bits(r) for r in recipe.leaves)
        steps=tuple((a,b,atom_ids[rewrite(p,env)],bits(r)) for a,b,p,r in recipe.steps)
    except KeyError:
        return None
    item=Placement(index,tuple(sorted(env.items())),leaves,steps)
    return item if verify(item,base) else None


def verify(item,base):
    rows=list(map(set,item.leaves))
    if any(prop.mask(row) not in base for row in rows):
        return False
    for a,b,pivot,result in item.steps:
        if not 0<=a<len(rows) or not 0<=b<len(rows) or pivot not in rows[a] or -pivot not in rows[b]:
            return False
        row=(rows[a]-{pivot}) | (rows[b]-{-pivot})
        if row!=set(result) or any(-v in row for v in row):
            return False
        rows.append(row)
    return bool(item.steps)


def match(recipes,atoms,base,terms,limits):
    atom_ids={a:i+1 for i,a in enumerate(atoms)}
    profiles=defaultdict(list)
    domains={s:set(t) for s,t in terms.items()}
    for mask in sorted(base):
        literals=order((v>0,atoms[abs(v)-1]) for v in prop.literals(mask))
        shape=Counter((s,a[0]) for s,a in literals)
        profiles[frozenset(shape)].append((shape,literals))
    out={}
    stats=Counter()
    bounded=False
    for index,recipe in enumerate(recipes):
        types=dict(recipe.types)
        if not types.keys() or any(s not in terms for s in types.values()):
            continue
        buckets=[]
        for row in recipe.leaves:
            shape=Counter((s,a[0]) for s,a in row)
            buckets.append([literals for counts,literals in profiles[frozenset(shape)] if counts<=shape])
        if any(not group for group in buckets):
            continue

        def search(remaining,env):
            nonlocal bounded
            if not remaining:
                stats["candidate_placements"]+=1
                item=grounded(recipe,index,env,atom_ids,base)
                if item is None:
                    stats["rejected_placements"]+=1
                elif prop.mask(item.result) not in base:
                    out.setdefault((item.result,tuple(sorted(item.leaves))),item)
                return
            i=min(remaining,key=lambda j:(len(buckets[j]),-len(set(env)&set().union(
                *(variables(a) for _,a in recipe.leaves[j]))),j))
            pending=tuple(k for k in remaining if k!=i)

            def bind(literals,ground,found):
                nonlocal bounded
                if not literals:
                    if mapped(recipe.leaves[i],found)==ground:
                        search(pending,found)
                    return
                (sign,pattern),*rest=literals
                for s,a in ground:
                    if stats["term_probes"]>=limits["probes"] or len(out)>=limits["offers"]:
                        bounded=True
                        return
                    stats["term_probes"]+=1
                    if s!=sign or a[0]!=pattern[0]:
                        continue
                    binding=found.copy()
                    if all(pmatch(p,t,binding) for p,t in zip(pattern[1:],a[1:],strict=True)) and all(
                            t in domains[types[v]] for v,t in binding.items()):
                        bind(rest,ground,binding)
                    if bounded:
                        return

            for row in buckets[i]:
                bind(recipe.leaves[i],row,env)
                if bounded:
                    return
        search(tuple(range(len(buckets))),{})
        if bounded:
            break
    return list(out.values()),dict(**stats,complete=not bounded,placements=len(out))


def pmatch(pattern,ground,env):
    if isinstance(pattern,str):
        if pattern in env:
            return env[pattern]==ground
        env[pattern]=ground
        return True
    return pattern[0]==ground[0] and len(pattern)==len(ground) and all(
        pmatch(p,t,env) for p,t in zip(pattern[1:],ground[1:],strict=True))
