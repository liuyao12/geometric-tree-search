"""Exact corner and contact model for unmarked unit rhombs."""

from functools import cmp_to_key, lru_cache

ZERO = (0, 0, 0, 0)
ONE = (1, 0, 0, 0)
SINE = ((0,0),(1,0),(0,1),(0,1),(1,0),(0,0),(-1,0),(0,-1),(0,-1),(-1,0))
FULL = (1 << 10)-1


def add(a, b):
    return tuple(x+y for x, y in zip(a,b))


def sub(a, b):
    return tuple(x-y for x, y in zip(a,b))


def zeta(a):
    w, x, y, z = a
    return -z, w-z, x-z, y-z


def rotate(p, turns):
    # A positive 36-degree rotation multiplies by minus zeta cubed.
    for _ in range((3*turns) % 5):
        p = zeta(p)
    return tuple(-x for x in p) if turns % 2 else p


DIRECTIONS = tuple(rotate(ONE,k) for k in range(10))


def rhomb(point, start, width):
    u, v = DIRECTIONS[start], DIRECTIONS[(start+width)%10]
    return tuple(sorted((point, add(point,u), add(point,v), add(point,add(u,v)))))


@lru_cache(maxsize=100000)
def incident(point):
    return {rhomb(point, k, w): sum(1 << ((k+j)%10) for j in range(w))
            for k in range(10) for w in range(1,5)}


def weights(tile):
    return tuple(incident(p)[tile].bit_count() for p in tile)


def sign(a, b):
    # Sign of a+b*phi via (2a+b)+b*sqrt(5).
    x = 2*a+b
    if x == 0 or b == 0 or (x>0) == (b>0):
        value = x or b
    else:
        value = (x*x-5*b*b)*(1 if x>0 else -1)
    return (value>0)-(value<0)


def compare(a,b):
    return sign(a[0]-b[0], a[1]-b[1])


ORDER = cmp_to_key(compare)


@lru_cache(maxsize=200000)
def project(axis, point):
    values = [SINE[(2*j-axis)%10] for j in range(4)]
    return tuple(sum(q*v[k] for q,v in zip(point,values)) for k in range(2))


@lru_cache(maxsize=100000)
def bounds(axis,tile):
    values = [project(axis,p) for p in tile]
    return min(values,key=ORDER), max(values,key=ORDER)


def legal_contact(a,b):
    return ordered_contact(*sorted((a,b)))


@lru_cache(maxsize=300000)
def ordered_contact(a,b):
    """Empty intersection, one common vertex or one full common side."""
    tight = None
    for axis in range(5):
        al, ah = bounds(axis,a)
        bl, bh = bounds(axis,b)
        c, d = compare(ah,bl), compare(bh,al)
        if c<0 or d<0:
            return True
        if c==0 or d==0:
            tight = axis, ah if c==0 else bh
    if tight is None:
        return False
    axis, value = tight
    left = {p for p in a if project(axis,p)==value}
    right = {p for p in b if project(axis,p)==value}
    other = (axis+1)%5
    span = [(min(vals,key=ORDER),max(vals,key=ORDER))
            for face in (left,right) for vals in [[project(other,p) for p in face]]]
    lo = max((s[0] for s in span),key=ORDER)
    hi = min((s[1] for s in span),key=ORDER)
    cmp = compare(lo,hi)
    if cmp>0:
        return True
    if cmp==0:
        return bool(left & right)
    return left==right and len(left)==2


def clear_geometry():
    for operation in (incident,project,bounds,ordered_contact):
        operation.cache_clear()


def requests():
    shared = set(incident(ZERO))
    nearby = set().union(*(incident(p).keys() for p in DIRECTIONS)) - shared
    for width in range(1,5):
        root = rhomb(ZERO,0,width)
        for stratum, tiles in (("shared",shared),("nearby",nearby)):
            for other in sorted(tiles):
                if other != root:
                    yield width,stratum,root,other


def complete(root, other):
    """Return exact candidate domain and a sector cover or exhausted masks."""
    corners = incident(ZERO)
    start = corners[root] | corners.get(other,0)
    options = [(t,m) for t,m in sorted(corners.items()) if not start&m
               and legal_contact(root,t) and legal_contact(other,t)]
    failed = set()

    def visit(mask):
        if mask == FULL:
            return ()
        if mask in failed:
            return None
        missing = (FULL^mask) & -(FULL^mask)
        for tile, sector in options:
            if missing&sector and not mask&sector:
                tail = visit(mask|sector)
                if tail is not None:
                    return (tile,)+tail
        failed.add(mask)
        return None

    witness = visit(start)
    return dict(initial_mask=start, domain=options, witness=witness,
                failed_masks=sorted(failed), status="NEGATIVE" if witness is None else "POSITIVE")


def pair_key(a,b,point):
    a,b = sorted((a,b))
    origin = a[0]
    return tuple(sub(p,origin) for p in a), tuple(sub(p,origin) for p in b), sub(point,origin)
