"""Conventional unit propagation and Glucose on the same finite ground bank."""

from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from serial_blocks_v1 import bits_for, catalog, compile_case, decode, prop
from origin_v1 import Source


class Derivation:
    def __init__(self, admissions):
        self.premises = sorted(admissions)
        self.clauses = [frozenset(prop.literals(c)) for c in self.premises]
        self.steps = {}
        self.active = [i for i, row in enumerate(self.clauses) if all(-v not in row for v in row)]
        self.known = {self.clauses[i]: i for i in self.active}
        self.scans = 0

    def add_resolution(self, left, right, pivot):
        if pivot < 0:
            left, right, pivot = right, left, -pivot
        a, b = self.clauses[left], self.clauses[right]
        assert pivot in a and -pivot in b
        result = (a - {pivot}) | (b - {-pivot})
        assert all(-v not in result for v in result)
        if result in self.known:
            return self.known[result]
        step = len(self.clauses)
        self.clauses.append(result)
        self.steps[step] = left, right, pivot
        self.known[result] = step
        self.active.append(step)
        return step

    def refute(self, target):
        if target in self.known:
            return self.known[target]
        true = {-v for v in target}
        trail = []
        while True:
            round_start = len(trail)
            for i in self.active:
                self.scans += 1
                clause = self.clauses[i]
                if true & clause:
                    continue
                unassigned = [v for v in clause if -v not in true]
                if not unassigned:
                    result = i
                    for lit, reason in reversed(trail):
                        if -lit in self.clauses[result]:
                            result = self.add_resolution(reason, result, lit)
                    assert self.clauses[result] <= target
                    return result
                if len(unassigned) == 1:
                    lit, = unassigned
                    true.add(lit)
                    trail.append((lit, i))
            if len(trail) == round_start:
                return None

    def support(self, root, admitted):
        used = set()
        pending = [root]
        while pending:
            node = pending.pop()
            if node in used:
                continue
            used.add(node)
            if node in self.steps:
                pending.extend(self.steps[node][:2])
        ordered = sorted(used)
        index = {node: i for i, node in enumerate(ordered)}
        origins, premises, proof = [], [], []
        for node in ordered:
            clause = prop.literals(prop.mask(self.clauses[node]))
            if node in self.steps:
                a, b, pivot = self.steps[node]
                proof.append(dict(left=index[a], right=index[b], pivot=pivot, clause=clause))
            else:
                premises.append(clause)
                origins.append(admitted[self.premises[node]])
        return origins, premises, proof


def main():
    run = prop.load("ground-control-protocol-v1.json")
    assert run["runtime"] == prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT / path) == pin for path, pin in run["pins"].items())
    protocol = prop.load("protocol-v1.json")
    dependencies = Path(sys.argv[1])
    assert all(prop.pin(dependencies / path) == pin for path, pin in protocol["pysat_files"].items())
    sys.path.insert(0, str(dependencies))
    from pysat.solvers import Solver
    problems = {r["id"]: r for r in prop.load("input/cases-v1.json") +
                prop.load("input/new-cases-v1.json") + prop.load("input/tutorial-cases-v1.json")["cases"] +
                [prop.load("input/forgery-v1.json")]}
    palette = prop.wang.palette()
    rows = []
    for spec in protocol["benchmark"]:
        problem = problems[spec["id"]]
        _, _, prefix, _, _ = compile_case(problem, spec, protocol)
        admitted = catalog(prefix)
        d = Derivation(admitted)
        started = time.monotonic()
        empty = d.refute(frozenset())
        solver_stats = {}
        raw_proof = []
        model = None
        method = "unit"
        if empty is None:
            method = "glucose4"
            ground = [sorted(d.clauses[i]) for i in d.active]
            with Solver(name=method, bootstrap_with=ground, with_proof=True) as solver:
                solver.conf_budget(run["conflicts"])
                sat = solver.solve_limited()
                solver_stats = solver.accum_stats()
                if sat is False:
                    raw_proof = solver.get_proof()
                    for line in raw_proof:
                        if line.startswith("d"):
                            continue
                        literals = [int(v) for v in line.split()]
                        assert literals.pop() == 0
                        clause = frozenset(literals)
                        if any(-v in clause for v in clause):
                            continue
                        node = d.refute(clause)
                        assert node is not None, line
                        if not d.clauses[node]:
                            empty = node
                            break
                    if empty is None:
                        empty = d.refute(frozenset())
                    assert empty is not None
                elif sat is True:
                    model = solver.get_model()
                    truth = set(model)
                    assert all(truth.intersection(clause) for clause in ground)
        elapsed = time.monotonic() - started
        row = dict(id=spec["id"], admissions=len(admitted), method=method,
                   status="REFUTED" if empty is not None else "GROUND_MODEL" if model is not None else "BOUNDED",
                   seconds=elapsed, scans=d.scans, stats=solver_stats, model=model, raw_proof=raw_proof)
        if empty is not None:
            origins, premises, proof = d.support(empty, admitted)
            layout = {**spec, "premises": len(premises), "resolutions": len(proof)}
            row["discovered_layout"] = layout
            if 0 < len(proof) <= run["rows_cap"] and len(premises) <= run["rows_cap"]:
                c, _, prefix, fields, functions = compile_case(problem, layout, protocol)
                prefix.original = Source(problem)
                prefix.original.clauses(protocol["cnf_limit"])
                bits = bits_for(c, prefix, origins, premises, proof)
                row["proof"] = decode(bits, prefix, fields, functions)
                rect = prop.wang.certificate(c, bits, palette)
                row["rectangle"] = prop.independent_wang.verify(c, rect, palette)
                assert row["rectangle"]["status"] == "VERIFIED"
                prop.compressed(f"data/{spec['id']}-ground-control-v1.json.gz", dict(circuit=c, certificate=rect))
        rows.append(row)
        print(json.dumps({k: v for k, v in row.items() if k not in {"proof", "model", "raw_proof", "rectangle"}},
                         sort_keys=True), flush=True)
    prop.save("data/ground-control-v1.json", rows)


if __name__ == "__main__":
    main()
