"""Exact convex polygon tiling by unmarked unit Penrose rhombs."""

from collections import Counter,deque
from itertools import combinations,pairwise
import time

from penrose_sat_v1 import replay
import check_v1 as independent
import model_v1 as model


def cross(p,q):
    return tuple(sum(a*b*model.SINE[(2*(j-i))%10][k]
                     for i,a in enumerate(p) for j,b in enumerate(q)) for k in range(2))


def signed_area(poly,det):
    boundary=tuple(pairwise((*poly,poly[0])))
    doubled=[det(a,b) for a,b in boundary]
    return tuple(sum(row[k] for row in doubled) for k in range(2))


def span(a,b):
    delta=model.sub(b,a)
    for ray in model.DIRECTIONS:
        i=next(k for k,x in enumerate(ray) if x)
        count,rest=divmod(delta[i],ray[i])
        if not rest and count>0 and tuple(count*x for x in ray)==delta:
            return ray,count
    return None


def tile_polygon(t):
    a=t[0]
    b,c=[p for p in t[1:] if model.sub(p,a) in model.DIRECTIONS]
    d=next(p for p in t if p not in (a,b,c))
    if model.sign(*cross(model.sub(b,a),model.sub(c,a)))<0:
        b,c=c,b
    return a,b,d,c


def thin(t):
    area=signed_area(tile_polygon(t),cross)
    assert area in {(2,0),(0,2)}
    return area==(2,0)


def inside(poly,p,det=cross):
    return all(model.sign(*det(model.sub(b,a),model.sub(p,a)))>=0
               for a,b in pairwise((*poly,poly[0])))


def inventory(poly,tile_cap,limit):
    # A connected patch of at most n edge-to-edge rhombs has at most 2n+2
    # vertices, so all of its vertices lie within 2n+1 edge hops of a corner.
    root=poly[0]
    seen={root}
    queue=deque([(root,0)])
    tiles=set()
    while queue:
        p,depth=queue.popleft()
        for t in model.incident(p):
            if t not in tiles and all(inside(poly,q) for q in t):
                tiles.add(t)
        if depth==2*tile_cap+1:
            continue
        for ray in model.DIRECTIONS:
            q=model.add(p,ray)
            if q not in seen and inside(poly,q):
                seen.add(q)
                if len(seen)>limit:
                    return None,len(seen)
                queue.append((q,depth+1))
    return tuple(sorted(tiles)),len(seen)


def exactly(clauses,items,needed,next_id):
    if needed==0:
        clauses.extend((-i,) for i in items)
        return next_id
    t=next_id
    next_id+=1
    clauses.append((t,))
    prev=[t]+[-t]*(needed+1)
    for x in items:
        new=[t]
        for k in range(1,needed+2):
            y=next_id
            next_id+=1
            a,b=prev[k],prev[k-1]
            clauses.extend(((-a,y),(-x,-b,y),(-y,a,x),(-y,a,b)))
            new.append(y)
        prev=new
    clauses.extend(((prev[needed],),(-prev[needed+1],)))
    return next_id


def validate(poly,selected):
    determinant=independent.imaginary_normal
    assert all(independent.order(determinant(model.sub(b,a),model.sub(p,a)),(0,0))>=0
               for t in selected for p in t for a,b in pairwise((*poly,poly[0])))
    assert all(independent.contact(a,b) for a,b in combinations(selected,2))
    part=[signed_area(tile_polygon(t),determinant) for t in selected]
    assert tuple(sum(x[k] for x in part) for k in range(2))==signed_area(poly,determinant)


def compile_region(poly,limit):
    for a,b in pairwise((*poly,poly[0])):
        assert all(model.sign(*cross(model.sub(b,a),model.sub(p,a)))>0 for p in poly if p not in (a,b))
    area=signed_area(poly,cross)
    assert area==signed_area(poly,independent.imaginary_normal)
    if any(v<0 or v%2 for v in area):
        return dict(status="NEGATIVE",reason="AREA_COUNTS",area_doubled=area)
    needed=tuple(v//2 for v in area)
    sides=[span(a,b) for a,b in pairwise((*poly,poly[0]))]
    if any(x is None for x in sides):
        return dict(status="NEGATIVE",reason="NONUNIT_BOUNDARY",counts=needed)
    counts=Counter()
    boundary=[]
    for (a,b),(ray,n) in zip(pairwise((*poly,poly[0])),sides,strict=True):
        counts[ray]+=n
        q=a
        for _ in range(n):
            r=model.add(q,ray)
            boundary.append(tuple(sorted((q,r))))
            q=r
        assert q==b
    if any(n!=counts[tuple(-x for x in ray)] for ray,n in counts.items()):
        return dict(status="NEGATIVE",reason="UNBALANCED_BOUNDARY",counts=needed,
                    directions=[(r,n) for r,n in sorted(counts.items())])
    tiles,sites=inventory(poly,sum(needed),limit)
    if tiles is None:
        return dict(status="BOUNDED",reason="INVENTORY_LIMIT",sites=sites)
    thin_tiles=[]
    thick_tiles=[]
    edges={}
    for i,t in enumerate(tiles,1):
        (thin_tiles if thin(t) else thick_tiles).append(i)
        ordered=tile_polygon(t)
        for a,b in pairwise((*ordered,ordered[0])):
            edges.setdefault(tuple(sorted((a,b))),[]).append(i)
    clauses=[]
    for edge in boundary:
        v=tuple(edges.get(edge,()))
        if not v:
            return dict(status="NEGATIVE",reason="UNCOVERED_BOUNDARY_EDGE",edge=edge,sites=sites,tiles=len(tiles))
        clauses.append(v)
        clauses.extend((-a,-b) for a,b in combinations(v,2))
    variable=exactly(clauses,thin_tiles,needed[0],len(tiles)+1)
    variable=exactly(clauses,thick_tiles,needed[1],variable)
    return dict(status="OPEN",sites=sites,tiles=tiles,clauses=clauses,counts=needed,variables=variable-1)


def search(poly,world,seeds,solver,limits):
    tiles=world["tiles"]
    base=world["clauses"]+[(tiles.index(t)+1,) for t in seeds]
    geometric=[]
    counts=Counter()
    start=time.monotonic()
    for _ in range(limits["rounds"]):
        if time.monotonic()-start>limits["seconds"]:
            break
        with solver(name="glucose4",bootstrap_with=base+geometric,with_proof=True) as s:
            s.conf_budget(limits["conflicts"])
            result=s.solve_limited()
            counts.update(s.accum_stats())
            if result is False:
                cuts=[tuple(map(int,line.split()[:-1])) for line in s.get_proof() if not line.startswith("d")]
                if not cuts or cuts[-1]:
                    cuts.append(())
                replay(base+geometric,cuts)
                return dict(status="NEGATIVE",reason="CHECKED_RUP",counts=dict(counts),geometry=geometric,cuts=cuts)
            if result is None:
                break
            ids=sorted(i for i in s.get_model() if 1<=i<=len(tiles))
        counts["models"]+=1
        rejected=[]
        for i,j in combinations(ids,2):
            if not model.legal_contact(tiles[i-1],tiles[j-1]):
                assert not independent.contact(tiles[i-1],tiles[j-1])
                rejected.append((-i,-j))
        if not rejected:
            chosen=[tiles[i-1] for i in ids]
            assert set(seeds)<=set(chosen)
            validate(poly,chosen)
            return dict(status="POSITIVE",reason="CHECKED_AREA_AND_CONTACT",counts=dict(counts),
                        geometry=geometric,witness=chosen)
        geometric.extend(rejected)
    return dict(status="BOUNDED",reason="SEARCH_LIMIT",counts=dict(counts),geometry=geometric)
