"""Clausify closed first-order entailments before the fixed Wang backend."""

from collections import Counter
from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import herbrand_v1 as fol
import resolution_v1 as prop
from in_grid_v1 import lift


def clausify(problem,limit):
    functions=dict(problem["functions"])
    predicates=dict(problem["predicates"])
    typed=predicates|({"="+s:[s,s] for s in problem["sorts"]} if problem["equality"] else {})
    w=0
    v=0
    trace=[]

    def parse(node,positive,scope,universals):
        nonlocal w,v
        op,*parts=node
        if op=="atom":
            name,*terms=parts
            types={symbol:sort for symbol,(term,sort) in scope.items()}
            assert tuple(fol.inspect_term(t,types,functions) for t in terms)==tuple(typed[name])
            def term(t):
                return scope[t][0] if isinstance(t,str) else (t[0],*map(term,t[1:]))
            return ("literal",positive,(name,*map(term,terms)))
        if op=="not":
            return parse(parts[0],not positive,scope,universals)
        if op in ("all","exists"):
            name,sort,body=parts
            assert sort in problem["sorts"] and name.startswith("?")
            universal=(op=="all")==positive
            if universal:
                renamed=f"?v{v}"
                v+=1
                return parse(body,positive,scope|{name:(renamed,sort)},(*universals,(renamed,sort)))
            while f"witness{w}" in functions:
                w+=1
            symbol=f"witness{w}"
            w+=1
            functions[symbol]=([s for _,s in universals],sort)
            term=(symbol,*(p for p,_ in universals))
            trace.append(dict(symbol=symbol,sort=sort,arguments=universals,eliminated=name))
            return parse(body,positive,scope|{name:(term,sort)},universals)
        left,right=parts
        if op in ("and","or"):
            connective=op if positive else ("or" if op=="and" else "and")
            return (connective,parse(left,positive,scope,universals),parse(right,positive,scope,universals))
        if op=="implies":
            return ("or" if positive else "and",
                    parse(left,not positive,scope,universals),parse(right,positive,scope,universals))
        assert op=="iff"
        connective="and" if positive else "or"
        inner="or" if positive else "and"
        return (connective,(inner,parse(left,not positive,scope,universals),parse(right,positive,scope,universals)),
                (inner,parse(right,not positive,scope,universals),parse(left,positive,scope,universals)))

    def cnf(node):
        op,*parts=node
        if op=="literal":
            return [frozenset([tuple(parts)])]
        a,b=map(cnf,parts)
        if op=="and":
            answer=a+b
        else:
            assert op=="or"
            if len(a)*len(b)>limit:
                raise ValueError("Clausification distribution limit")
            answer=[r|s for r,s in product(a,b)]
        assert len(answer)<=limit
        return list(dict.fromkeys(r for r in answer if not any((not p,t) in r for p,t in r)))

    def variables(t,required,sort):
        if isinstance(t,str):
            assert required.setdefault(t,sort)==sort
        else:
            args,out=functions[t[0]]
            assert out==sort and len(args)==len(t)-1
            for arg,s in zip(t[1:],args,strict=True):
                variables(arg,required,s)

    source=[(r,True) for r in problem["premises"]]+[(problem["goal"],False)]
    clauses=[]
    for i,(formula,polarity) in enumerate(source):
        parsed=parse(fol.frozen(formula),polarity,{},())
        for j,row in enumerate(cnf(parsed)):
            required={}
            for _,(pred,*terms) in row:
                for t,s in zip(terms,typed[pred],strict=True):
                    variables(t,required,s)
            ordered=sorted(row,key=repr)
            clauses.append(dict(id=f"formula{i+1}-clause{j+1}",variables=required,clause=ordered))
    for i,s in enumerate(problem["sorts"]):
        if not any(not args and out==s for args,out in functions.values()):
            name=f"inhabitant{i}"
            while name in functions:
                name+="_"
            functions[name]=([],s)
    case=dict(id=problem["id"],sorts=problem["sorts"],functions=functions,predicates=predicates,
              equality=problem["equality"],clauses=clauses,goal=None)
    fol.signature(case)
    return case,trace


def finite_qualification(original,compiled):
    # Exhaust the declared two-element-domain interpretations, then ask
    # whether the fresh Skolem symbols have an interpretation for each one.
    domain=(0,1)
    assert not original["functions"] and not original["equality"]
    inputs=[(p,a) for p,sorts in original["predicates"].items()
            for a in product(domain,repeat=len(sorts))]
    slots=[(f,a) for f,(sorts,_) in compiled["functions"].items() for a in product(domain,repeat=len(sorts))]
    checks=0
    matches=0
    for values in product((False,True),repeat=len(inputs)):
        pred=dict(zip(inputs,values,strict=True))
        def evaluate(node,env):
            op,*args=node
            if op=="atom":
                name,*terms=args
                return pred[name,tuple(env[t] for t in terms)]
            if op=="not":
                return not evaluate(args[0],env)
            if op in ("all","exists"):
                v,_,body=args
                aggregate=all if op=="all" else any
                return aggregate(evaluate(body,env|{v:i}) for i in domain)
            return prop.combine(op,evaluate(args[0],env),evaluate(args[1],env))
        wanted=all(evaluate(p,{}) for p in original["premises"]) and not evaluate(original["goal"],{})
        def admits(fvalues):
            fun=dict(zip(slots,fvalues,strict=True))
            for schema in compiled["clauses"]:
                variables=sorted(schema["variables"])
                for assignment in product(domain,repeat=len(variables)):
                    env=dict(zip(variables,assignment,strict=True))
                    def term(t):
                        return env[t] if isinstance(t,str) else fun[t[0],tuple(map(term,t[1:]))]
                    if not any(pred[head,tuple(map(term,args))]==sign
                               for sign,(head,*args) in schema["clause"]):
                        return False
            return True
        observed=any(admits(fvalues) for fvalues in product(domain,repeat=len(slots)))
        assert wanted==observed
        checks+=1
        matches+=observed
    return dict(two_element_interpretations=checks,refutation_formula_satisfiable_in=matches)


def main():
    protocol=prop.load("protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/name)==v for name,v in protocol["pins"].items())
    palette=prop.wang.palette()
    outcomes=[]
    for original in prop.load("input/cases-v1.json"):
        case,trace=clausify(original,protocol["cnf_limit"])
        assurance=finite_qualification(original,case)
        raw=fol.solve(case,protocol,palette)
        proof=None
        if raw["status"]=="PROVED":
            prefix,premises,lines=lift(raw,case,protocol["max_terms"])
            c,inputs,_=prop.circuit(len(prefix.atoms),premises,lines,prefix=prefix)
            assert len(c["gates"])<=protocol["gate_limit"]
            cert=prop.wang.certificate(c,inputs,palette)
            proof=prop.independent_wang.verify(c,cert,palette)
            assert proof["status"]=="VERIFIED"
            prop.compressed(f"data/{case['id']}-combined-wang-v1.json.gz",dict(circuit=c,certificate=cert))
        row=dict(id=case["id"],original=original,compiled=case,skolem=trace,qualification=assurance,
                 outcome=raw,physical=proof)
        outcomes.append(row)
        print(json.dumps(dict(id=row["id"],status=raw["status"],clauses=len(case["clauses"]),
                              grounding_depth=raw.get("depth"),qualification=assurance)),flush=True)
    prop.save("data/results-v1.json",outcomes)
    result=dict(status="CHECKED_QUANTIFIED_FRONT_END_AND_FIXED_WANG",
                outcomes=dict(Counter(r["outcome"]["status"] for r in outcomes)),
                palette_sha256=prop.wang.digest(palette),
                qualification_interpretations=sum(r["qualification"]["two_element_interpretations"] for r in outcomes),
                scope="The front end accepts closed first-order formulas with named quantifiers. The fixed grid checks ground instance admission and resolution after external clausal compilation. The bounded experiment does not establish a general performance advantage.")
    prop.save("data/summary-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
