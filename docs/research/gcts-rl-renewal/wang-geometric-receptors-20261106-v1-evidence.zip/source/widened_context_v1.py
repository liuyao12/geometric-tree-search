"""Check an exploratory wider receptor envelope on the four-hole instances."""

from pathlib import Path
import json
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from admission_experiment_v1 import bank_for, certificate, matched
from admission_policy_v1 import ACTIONS, evaluate
from context_experiment_v1 import tree
from lemma_receptors_v1 import Pattern, atom_types, ordered, verify
from marked_lemma_pilot_v1 import audit
from transfer_experiment_v1 import prop, replay_logic


def main():
    plan = prop.load("wide-context-protocol-v1.json")
    assert prop.pin(Path(sys.executable)) == plan["runtime"]
    assert all(prop.pin(Path(k)) == digest for k,digest in plan["pins"].items())
    protocol = prop.load("protocol-v1.json")
    prior = {r["id"]:r for r in prop.load("data/admission-v1.json")}
    patterns = [Pattern(**{k:tree(v) for k,v in d["pattern"].items()})
                for d in prop.load("prior/transfer-v1.json")["donors"]]
    deps = Path(sys.argv[1])
    assert all(prop.pin(deps/k) == digest for k,digest in protocol["pysat_files"].items())
    sys.path.insert(0,str(deps))
    from pysat.solvers import Solver
    palette = prop.wang.palette()
    output = []
    for name in plan["cases"]:
        source = prior[name]["source"]
        bank, atoms = bank_for(source, protocol)
        rows = {ordered(prop.literals(r)) for r in bank}
        offers, work = matched(patterns, rows, atom_types(source, atoms), plan["matching"])
        start = time.monotonic()
        assert all(verify(o, rows) for o in offers)
        validation = dict(steps=sum(len(o.steps) for o in offers), seconds=time.monotonic()-start)
        results = []
        for i, a in enumerate(ACTIONS):
            search,status,expanded,effort = evaluate(bank, offers, plan["limits"], action=i)
            assert (status != "REFUTED" or prior[name]["positive"]) and (
                   status != "EXHAUSTED" or not prior[name]["positive"])
            record = dict(action=a,status=status,work=effort,stats=dict(search.stats),checked=audit(search))
            if expanded:
                (origins,premises,proof), proof_work = expanded
                replay_logic(premises,proof,bank)
                record["proof"] = dict(atoms=atoms,origins=origins,premises=premises,proof=proof)
                record["proof_work"] = proof_work
            results.append(record)
        supports = [r for r in results if "proof" in r]
        if supports:
            best = min(supports,key=lambda r:r["work"])
            best["rectangle"], best["rectangle_file"] = certificate(source,best["proof"],protocol,"wide",palette)
        axioms = [list(row) for row in sorted(rows)]
        conclusions = [list(row) for row in sorted({o.result for o in offers})]
        with Solver(name="glucose4",bootstrap_with=axioms+conclusions) as s:
            s.conf_budget(12000)
            status = s.solve_limited()
            counts = s.accum_stats()
            if status is not None:
                assert status is (not prior[name]["positive"])
        result = dict(id=name,offers=len(offers),matched=work,validation=validation,results=results,
                      ground_control=dict(status=status,counts=counts))
        output.append(result)
        print(json.dumps(dict(id=name,offers=len(offers),matched=work,control=counts,arms=[
            (r["action"],r["status"],r["work"],r["stats"].get("pairs",0)) for r in results]),sort_keys=True),flush=True)
    prop.save("data/wide-context-v1.json",output)


if __name__ == "__main__":
    main()
