"""Select batches of checked lemma moves using proof-search rewards."""

from math import exp, log1p
import random

from lazy_lemmas_v1 import LazySearch
from lemma_receptors_v1 import ordered


ACTIONS = (0, 2, 8, 32, None)
REFERENCE = 2


class AdmissionSearch(LazySearch):
    def __init__(self, bank, offers, limits, action=REFERENCE, weights=None, shuffled=False,
                 override=None, seed=0):
        self.action = action
        self.weights_for_admission = weights
        self.shuffled_admission = shuffled
        self.override = override
        self.admission_log = []
        self.total_offers = len(offers)
        super().__init__(bank, offers, "receptor", limits, rng=random.Random(seed), marking=True)

    def activate(self, row):
        offers = self.by_anchor.pop(ordered(row), ())
        if not offers:
            return
        best = {}
        for offer in offers:
            if frozenset(offer.result) in self.d.known:
                continue
            previous = best.get(offer.result)
            if previous is None or len(offer.steps) < len(previous.steps):
                best[offer.result] = offer
        if not best:
            return
        self.stats["available_claims"] += len(best)
        self.stats["admission_windows"] += 1
        ranks = {}
        for out, offer in best.items():
            contacts = sum(bool(self.index.get(-lit)) for lit in out)
            ranks[out] = (len(out), -contacts, len(offer.steps), out)
        candidates = sorted(best, key=ranks.__getitem__)
        width, negative_contacts, _, _ = ranks[candidates[0]]
        features = (1., min(1., log1p(self.total_offers) / 9),
                    min(1., log1p(len(best)) / 6), 1 / (1 + width),
                    -negative_contacts / max(1, width),
                    min(1., self.stats["settled"] / max(1, len(self.d.premises))),
                    len(row) / (1 + len(row)))
        index = len(self.admission_log)
        action = self.action
        if self.weights_for_admission is not None:
            scores = logits(self.weights_for_admission, features)
            action = scores.index(max(scores))
        if self.override is not None and index == self.override[0]:
            action = self.override[1]
        limit = ACTIONS[action]
        if self.shuffled_admission:
            self.rng.shuffle(candidates)
        selected = candidates if limit is None else candidates[:limit]
        if self.shuffled_admission:
            selected.sort(key=ranks.__getitem__)
        self.admission_log.append(dict(anchor=ordered(row), features=features, action=action,
                                       available=len(candidates), admitted=len(selected)))
        for out in selected:
            self.place(best[out])


def logits(weights, features):
    return [sum(w * x for w, x in zip(row, features, strict=True)) for row in weights]


def initial():
    return [[.2 if a == REFERENCE and j == 0 else 0. for j in range(7)]
            for a in range(len(ACTIONS))]


def work(stats, replays=0):
    return (stats["pairs"] + (stats["subset_probes"] + 3) // 4
            + 4 * stats["inserted_claims"] + replays)


def evaluate(bank, offers, limits, **settings):
    search = AdmissionSearch(bank, offers, limits, **settings)
    status, root = search.run()
    expanded = search.expand_proof(root) if root is not None else None
    replays = expanded[1]["proof_replays"] if expanded else 0
    return search, status, expanded, work(search.stats, replays)


def collect(bank, offers, expected, limits, anchors):
    ref, status, _, cost = evaluate(bank, offers, limits)
    if not ref.admission_log:
        return [], dict(status=status, cost=cost, windows=0)
    n = len(ref.admission_log)
    points = sorted({i * (n - 1) // max(1, anchors - 1) for i in range(anchors)})
    samples = []
    for i in points:
        log = ref.admission_log[i]
        outcomes = []
        for action in range(len(ACTIONS)):
            if action == REFERENCE:
                outcome, effort = status, cost
            else:
                branch, outcome, _, effort = evaluate(bank, offers, limits, override=(i, action))
                assert branch.admission_log[i]["features"] == log["features"]
                assert branch.admission_log[i]["anchor"] == log["anchor"]
            outcomes.append(dict(status=outcome, work=effort))
        best = min((r["work"] for r in outcomes if r["status"] == expected), default=None)
        if best is not None:
            rewards = [max(-3., log1p(best) - log1p(r["work"])) if r["status"] == expected else -3.
                       for r in outcomes]
            samples.append(dict(index=i, features=log["features"], outcomes=outcomes, rewards=rewards))
    return samples, dict(status=status, cost=cost, windows=n)


def train(samples, passes, step, penalty, seed):
    base = initial()
    weights = initial()
    rng = random.Random(seed)
    trace = []
    for epoch in range(passes):
        data = samples[:]
        rng.shuffle(data)
        total = 0.
        for sample in data:
            x, rewards = sample["features"], sample["rewards"]
            scores = logits(weights, x)
            scale = max(scores)
            softmax = [exp(y - scale) for y in scores]
            norm = sum(softmax)
            probs = [y / norm for y in softmax]
            expected = sum(p * r for p, r in zip(probs, rewards, strict=True))
            total += expected
            for a, row in enumerate(weights):
                advantage = probs[a] * (rewards[a] - expected)
                for j, value in enumerate(x):
                    row[j] += step * (advantage * value - penalty * (row[j] - base[a][j]))
        trace.append(dict(epoch=epoch, expected_reward=total / len(data)))
    return weights, trace
