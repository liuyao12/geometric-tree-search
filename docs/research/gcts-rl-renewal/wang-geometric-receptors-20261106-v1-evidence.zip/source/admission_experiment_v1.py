"""Train and test an episodic policy for optional checked lemma admission."""

from collections import Counter
from dataclasses import asdict
from itertools import product
import json
from pathlib import Path
import random
import sys
import time
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from admission_policy_v1 import ACTIONS, REFERENCE, collect, evaluate, initial, train, work
from calibration_bank_v1 import atom, case, colored, neg, pigeon
from context_experiment_v1 import key, library, tree
from indexed_receptors_v1 import compose
from lazy_lemmas_v1 import LazySearch
from lemma_receptors_v1 import Offer, Pattern, atom_types, ordered, verify
from marked_lemma_pilot_v1 import audit
from transfer_experiment_v1 import Source, catalog, compile_case, decode, prop, replay_logic
from wired_replay_v1 import compile_wired


def generated(spec):
    rng = random.Random(spec["seed"])
    if spec["family"] == "cycle":
        clauses = colored(spec["size"], spec["positive"])
    else:
        clauses = pigeon(spec["size"], spec["holes"])
    for i in range(spec.get("noise", 0)):
        a, b = atom(f"unused{2*i}"), atom(f"unused{2*i+1}")
        clauses.extend(((a, b), (neg(a), neg(b))))
    original = case(spec["id"], spec["family"], clauses, spec["positive"])
    names = sorted(original["predicates"])
    labels = [f"bit{i:02}" for i in range(len(names))]
    rng.shuffle(labels)
    mapping = dict(zip(names, labels, strict=True))

    def rename(expr):
        if expr[0] == "atom":
            return ["atom", mapping[expr[1]], expr[2]]
        return [expr[0], *(rename(x) for x in expr[1:])]

    original["predicates"] = {label: ["U"] for label in labels}
    original["premises"] = [rename(x) for x in original["premises"]]
    rng.shuffle(original["premises"])
    original["goal"] = rename(original["goal"])
    return original


def bank_for(original, protocol):
    logical = Source(original).clauses(protocol["cnf_limit"])
    functions, predicates, schemas = fol.signature(logical)
    terms = fol.ground_terms(logical, functions, 0, protocol["max_terms"])
    atoms = sorted((name, *args) for name, sorts in predicates.items()
                   for args in product(*(terms[s] for s in sorts)))
    flattened = sorted({t for values in terms.values() for t in values})
    ids = {t: i for i, t in enumerate(flattened)}
    types = {sort:[ids[t] for t in values] for sort, values in terms.items()}
    prefix = SimpleNamespace(atoms=atoms, terms=flattened, schemas=schemas, types=types)
    admitted = {r:o for r,o in catalog(prefix).items() if not r[0] & r[1]}
    return admitted, atoms


def matched(patterns, rows, types, plan):
    one, one_stats = library(patterns, rows, types, plan["first"])
    seeds = {}
    for offer in sorted(one, key=lambda o: (len(o.steps), o.pattern, o.leaves, o.mapping)):
        seeds.setdefault(offer.result, offer)
    next_offers, two_stats = library(patterns, rows | seeds.keys(), types, plan["second"])
    all_offers = {key(o): o for o in one}
    for offer in next_offers:
        if offer.result in seeds:
            continue
        result = compose(offer, seeds, rows)
        if result and len(result.steps) <= plan["composed_steps"]:
            all_offers.setdefault(key(result), result)
    return list(all_offers.values()), dict(first=one_stats, second=two_stats)


def ground_control(bank, model_expected, solver):
    clauses = [list(ordered(prop.literals(r))) for r in sorted(bank)]
    with solver(name="glucose4", bootstrap_with=clauses) as s:
        s.conf_budget(12000)
        sat = s.solve_limited()
        stats = s.accum_stats()
        model = s.get_model() if sat else None
    if model is not None:
        true = set(model)
        assert all(true.intersection(c) for c in clauses)
    if sat is not None:
        assert sat is model_expected
    return dict(status={True:"GROUND_MODEL",False:"REFUTED",None:"BOUNDED"}[sat], stats=stats, model=model)


def certificate(original, proof, protocol, label, palette):
    _, _, prefix, _, functions = compile_case(original, dict(depth=0, premises=2, resolutions=1), protocol)
    source = Source(original)
    source.clauses(protocol["cnf_limit"])
    prefix.origins, prefix.premises, prefix.rows = proof["origins"], proof["premises"], []
    circuit, bits, fields = compile_wired(prefix, source, proof["proof"])
    assert decode(bits, prefix, fields, functions) == proof
    rectangle = prop.wang.certificate(circuit, bits, palette)
    check = prop.independent_wang.verify(circuit, rectangle, palette)
    assert check["status"] == "VERIFIED"
    name = f'data/{original["id"]}-{label}-admission-wang-v1.json.gz'
    prop.compressed(name, dict(circuit=circuit, certificate=rectangle))
    return check, name


def main():
    plan = prop.load("admission-protocol-v1.json")
    assert prop.pin(Path(sys.executable)) == plan["runtime"]
    assert all(prop.pin(Path(k)) == digest for k,digest in plan["pins"].items())
    protocol = prop.load("protocol-v1.json")
    deps = Path(sys.argv[1])
    assert all(prop.pin(deps/k) == digest for k,digest in protocol["pysat_files"].items())
    sys.path.insert(0, str(deps))
    from pysat.solvers import Solver
    patterns = [Pattern(**{k:tree(v) for k,v in d["pattern"].items()})
                for d in prop.load("prior/transfer-v1.json")["donors"]]
    samples, training = [], []
    for spec in plan["train"]:
        original = generated(spec)
        bank, atoms = bank_for(original, protocol)
        rows = {ordered(prop.literals(r)) for r in bank}
        types = atom_types(original, atoms)
        offers, match = matched(patterns, rows, types, plan["matching"])
        assert all(verify(o, rows) for o in offers)
        points, reference = collect(bank, offers, "REFUTED" if spec["positive"] else "EXHAUSTED",
                                    plan["train_limits"], plan["training"]["anchors"])
        samples.extend(points)
        training.append(dict(id=spec["id"], source=original, reference=reference, samples=points,
                             offers=len(offers), matching=match))
        print(json.dumps(dict(training=spec["id"], contexts=len(points), offers=len(offers)), sort_keys=True),flush=True)
    assert samples
    settings = plan["training"]
    weights, epochs = train(samples, settings["passes"], settings["step"], settings["penalty"], settings["seed"])
    prop.save("data/admission-training-v1.json", dict(weights=weights, initial=initial(), epochs=epochs, cases=training))
    known = {r["id"]:r for r in prop.load("input/new-cases-v1.json")}
    prior = {r["id"]:r for r in prop.load("prior/context-v1.json")}
    held = [(known[name], name in plan["old_positives"]) for name in plan["old_holdout"]]
    held += [(generated(spec), spec["positive"]) for spec in plan["fresh_holdout"]]
    palette = prop.wang.palette()
    output = []
    for original, positive in held:
        name = original["id"]
        bank, atoms = bank_for(original, protocol)
        rows = {ordered(prop.literals(r)) for r in bank}
        if name in prior:
            pool = next(x for x in prior[name]["libraries"] if x["library"] == "two-layer")
            offers = [Offer(**{k:tree(v) for k,v in o.items()}) for o in pool["offers"]]
            matching = dict(reused=True, **pool["matching"])
        else:
            offers, matching = matched(patterns, rows, atom_types(original, atoms), plan["matching"])
        start = time.monotonic()
        assert all(verify(o, rows) for o in offers)
        validation = dict(steps=sum(len(o.steps) for o in offers), seconds=time.monotonic()-start)
        external = ground_control(bank, not positive, Solver)
        arms = [(f"fixed-{a if a is not None else 'all'}",dict(action=i)) for i,a in enumerate(ACTIONS)]
        arms += [("initial",dict(weights=initial())),("learned",dict(weights=weights))]
        arms += [(f"shuffle-{s}",dict(action=REFERENCE,shuffled=True,seed=s)) for s in plan["shuffles"]]
        results = []
        for label, options in arms:
            search, status, expanded, effort = evaluate(bank, offers, plan["test_limits"], **options)
            assert (status != "REFUTED" or positive) and (status != "EXHAUSTED" or not positive)
            checked = audit(search)
            record = dict(arm=label,status=status,work=effort,stats=dict(search.stats),checked=checked,
                          schedule=search.admission_log, actions=dict(Counter(a["action"] for a in search.admission_log)))
            if expanded:
                (origins,premises,proof), replay = expanded
                replay_logic(premises, proof, bank)
                record["proof"] = dict(atoms=atoms,origins=origins,premises=premises,proof=proof)
                record["proof_work"] = replay
            results.append(record)
        start = time.monotonic()
        eager = LazySearch(bank, offers, "seeded", plan["test_limits"], marking=True)
        outcome, root = eager.run()
        elapsed = time.monotonic()-start
        base_record = dict(arm="eager-library",status=outcome,stats=dict(eager.stats),checked=audit(eager),seconds=elapsed)
        if root is not None:
            (origins,premises,proof), replay = eager.expand_proof(root)
            replay_logic(premises,proof,bank)
            base_record["proof_work"] = replay
        base_record["work"] = work(eager.stats, base_record.get("proof_work",{}).get("proof_replays",0))
        results.append(base_record)
        for record in results:
            if [name, record["arm"]] in plan["certificates"] and "proof" in record:
                record["rectangle"], record["rectangle_file"] = certificate(
                    original, record["proof"], protocol, record["arm"], palette)
        row = dict(id=name,positive=positive,source=original,offers=len(offers),matching=matching,validation=validation,
                   external=external,results=results)
        output.append(row)
        print(json.dumps(dict(id=name,offers=len(offers),external=external["status"],arms=[
            (r["arm"],r["status"],r["work"],r["stats"].get("pairs",0),r["stats"].get("inserted_claims",0),
             r.get("actions",{}),r.get("rectangle",{}).get("status")) for r in results]),sort_keys=True),flush=True)
    prop.save("data/admission-v1.json", output)


if __name__ == "__main__":
    main()
