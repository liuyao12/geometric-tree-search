"""Check exact convex Penrose boundaries and seeded extension controls."""

from itertools import accumulate,combinations,product
import json
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
from learn_v1 import pin,read,save,verify
import check_v1 as independent
import model_v1 as model
from penrose_polygon_v1 import compile_region,exactly,search


def polygon(steps):
    vertices=list(accumulate(steps,model.add,initial=model.ZERO))
    assert vertices.pop()==model.ZERO
    return tuple(vertices)


def zonogon(directions,sizes):
    rays=[tuple(n*v for v in model.DIRECTIONS[k]) for k,n in zip(directions,sizes,strict=True)]
    return polygon(rays+[tuple(-v for v in u) for u in rays])


def bank():
    yield "thin-rhomb-grid",zonogon((0,1),(2,2))
    yield "thick-rhomb-grid",zonogon((0,2),(2,2))
    yield "mixed-six-sides",zonogon((0,1,2),(1,1,1))
    yield "mixed-wide-six-sides",zonogon((0,1,3),(2,1,1))
    phi=(0,0,-1,-1)
    d=model.DIRECTIONS[1]
    yield "fractional-unit-side",polygon((phi,d,tuple(-v for v in phi),tuple(-v for v in d)))
    yield "unbalanced-five-sides",polygon(tuple(tuple(2*v for v in model.DIRECTIONS[k]) for k in range(0,10,2)))


def qualify(solver):
    checks=0
    for n in range(1,7):
        ids=list(range(1,n+1))
        for k in range(n+2):
            cnf=[]
            exactly(cnf,ids,k,n+1)
            with solver(name="glucose4",bootstrap_with=cnf) as s:
                for bits in product((False,True),repeat=n):
                    choices=[i if b else -i for i,b in enumerate(bits,1)]
                    assert s.solve(assumptions=choices) is (sum(bits)==k)
                    checks+=1
    return checks


def main():
    plan=read("polygon-protocol-v1.json")
    verify(plan)
    dep=Path(sys.argv[1])
    assert all(pin(dep/k)==v for k,v in read("wang-protocol-v1.json")["pysat_files"].items())
    sys.path.insert(0,str(dep))
    from pysat.solvers import Solver
    checked=qualify(Solver)
    results=[]
    for name,poly in bank():
        started=time.monotonic()
        model.clear_geometry()
        world=compile_region(poly,plan["vertices"])
        prepare=time.monotonic()-started
        report=dict(id=name,boundary=poly,setup_seconds=prepare,world=world)
        if world["status"]=="OPEN":
            r=search(poly,world,(),Solver,plan["search"])
            assert r["status"]=="POSITIVE"
            report["baseline"]=r
            if name in plan["seed_probe"]:
                candidates=[t for t in world["tiles"] if t not in r["witness"]]
                probes=[]
                for a,b in combinations(candidates,2):
                    if len(probes)>=plan["seed_trials"]:
                        break
                    if not independent.contact(a,b):
                        continue
                    rr=search(poly,world,(a,b),Solver,plan["search"])
                    probes.append(dict(seeds=(a,b),**rr))
                    if rr["status"]=="NEGATIVE":
                        break
                report["probes"]=probes
        else:
            assert name in ("fractional-unit-side","unbalanced-five-sides") and world["status"]=="NEGATIVE"
        print(json.dumps(dict(id=name,world=world["status"],reason=world.get("reason"),counts=world.get("counts"),
                              tiles=len(world.get("tiles",[])),sites=world.get("sites"),seconds=prepare,
                              probes=[(x["status"],len(x.get("geometry",[])),len(x.get("cuts",[])))
                                      for x in report.get("probes",[])]),sort_keys=True),flush=True)
        results.append(report)
    save("data/polygon-v1.json",dict(status="CHECKED_EXACT_PENROSE_POLYGONS",cardinality_checks=checked,cases=results))


if __name__=="__main__":
    main()
