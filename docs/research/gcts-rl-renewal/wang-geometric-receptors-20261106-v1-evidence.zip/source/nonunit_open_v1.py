"""Run the fixed-palette searches on the non-unit calibration bank."""

from pathlib import Path
import json
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
import benchmark_v1 as bench
from benchmark_fast_v1 import audit, qualify

prop = bench.prop


def main():
    deps, binary = map(Path, sys.argv[1:])
    protocol = prop.load("nonunit-open-protocol-v1.json")
    original = prop.load("protocol-v1.json")
    assert protocol["runtime"] == prop.pin(Path(sys.executable))
    assert all(prop.pin(Path(path)) == pin for path, pin in protocol["pins"].items())
    assert all(prop.pin(deps / path) == pin for path, pin in original["pysat_files"].items())
    assert prop.pin(binary) == protocol["binary"]
    qualify(str(binary))
    sys.path.insert(0, str(deps))
    cases = {r["id"]: r for r in prop.load("input/new-cases-v1.json")}
    weights = protocol["frozen_weights"]
    palette = prop.wang.palette()
    output = []
    for spec in protocol["schedule"]:
        name = spec["id"]
        c, cnf, prefix, fields, functions = bench.compile_case(cases[name], spec, original)
        variables = len(c["inputs"]) + len(c["gates"])
        results = []
        for mode in ("static", "activity", "learned", "cadical195", "glucose4"):
            if mode in {"static", "activity", "learned"}:
                started = time.perf_counter()
                search = bench.BoundarySearch(list(cnf), variables, len(c["inputs"]), protocol["limits"],
                                              mode, c["inputs"], weights)
                status, bits = search.run()
                elapsed = time.perf_counter() - started
                n = audit(cnf, search.ordered, variables, str(binary))
                row = dict(mode=mode, status=status, seconds=elapsed, checked_cuts=n,
                           counts=dict(search.stats), cuts=search.ordered)
            else:
                row, bits = bench.external(c, cnf, (), protocol["external_conflicts"], mode)
            if bits is not None:
                row["proof"] = bench.decode(bits, prefix, fields, functions)
                rect = prop.wang.certificate(c, bits, palette)
                row["rectangle"] = prop.independent_wang.verify(c, rect, palette)
                assert row["rectangle"]["status"] == "VERIFIED"
                prop.compressed(f"data/{name}-{mode}-nonunit-wang-v1.json.gz", dict(circuit=c, certificate=rect))
            results.append(row)
        entry = dict(id=name, layout=spec, gates=len(c["gates"]), inputs=len(c["inputs"]),
                     circuit=prop.wang.digest(c), results=results)
        output.append(entry)
        print(json.dumps(dict(id=name, gates=entry["gates"], rows={
            row["mode"]: [row["status"], row["counts"].get("decisions", 0),
                          row["counts"].get("conflicts", 0)] for row in results}), sort_keys=True), flush=True)
    prop.save("data/nonunit-open-v1.json", output)


if __name__ == "__main__":
    main()
