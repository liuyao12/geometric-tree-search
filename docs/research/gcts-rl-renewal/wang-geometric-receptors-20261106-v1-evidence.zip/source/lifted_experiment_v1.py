"""Compare typed recipe reuse on new quantified branching problems."""

from dataclasses import asdict,replace
from itertools import product
import json
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from atom_slice_v1 import slice_proof
from ground_control_v1 import Derivation
from in_grid_v1 import Prefix
from lifted_cases_v1 import cases
from lifted_recipe_v1 import lift,match,verify
from lifted_search_v1 import expand,run
from origin_v1 import Source
from serial_blocks_v1 import catalog,decode,prop
from wired_replay_v1 import compile_wired


def lookup(original,cap):
    s=Source(original)
    c=s.clauses(cap)
    return s,c,fol.signature(c)


def donor_library(proofs,originals,cap,maximum,parameterize):
    recipes=[]
    metadata=[]
    for name,proof in proofs.items():
        _,_,(functions,_,schemas)=lookup(originals[name],cap)
        for root,r in lift(proof,schemas,functions,maximum,parameterize):
            if r not in recipes:
                recipes.append(r)
                metadata.append(dict(donor=name,root=root,**asdict(r)))
    return recipes,metadata


def certificate(source,functions,schemas,terms,proof,palette,label):
    prefix=Prefix(schemas,terms,proof["atoms"],proof["origins"],proof["premises"])
    circuit,bits,fields=compile_wired(prefix,source,proof["proof"])
    assert decode(bits,prefix,fields,functions)==proof
    rect=prop.wang.certificate(circuit,bits,palette)
    checked=prop.independent_wang.verify(circuit,rect,palette)
    assert checked["status"]=="VERIFIED"
    path=f"data/{label}-lifted-wang-v1.json.gz"
    prop.compressed(path,dict(circuit=circuit,certificate=rect))
    return checked,path


def main():
    plan=prop.load("lifted-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    dep=Path(sys.argv[1])
    setup=prop.load("protocol-v1.json")
    assert all(prop.pin(dep/k)==digest for k,digest in setup["pysat_files"].items())
    sys.path.insert(0,str(dep))
    from pysat.solvers import Solver
    prior=prop.load("prior/demand-pilot/fair-window-v1.json")
    hilbert=prop.load("prior/demand-inputs/hilbert-slice-input-v1.json")["source"]
    sources={r["id"]:r for r in [hilbert,*prop.load("input/tutorial-cases-v1.json")["cases"]]}
    donors={n:next(row["found"]["proof"] for row in prior if row["id"]==n) for n in plan["donors"]}
    lifted,metadata=donor_library(donors,sources,plan["normalization"],plan["fragment"],True)
    fixed,fixed_meta=donor_library(donors,sources,plan["normalization"],plan["fragment"],False)
    assert lifted
    palette=prop.wang.palette()
    rows=[]
    for original in cases(hilbert):
        name=original["id"]
        positive=not name.endswith("-control")
        source,problem,(functions,predicates,schemas)=lookup(original,plan["normalization"])
        terms=fol.ground_terms(problem,functions,0,plan["term_limit"])
        atoms=sorted((p,*ts) for p,sorts in predicates.items()
                     for ts in product(*(terms[s] for s in sorts)))
        bank={m:o for m,o in catalog(Prefix(schemas,terms,atoms,[],[])).items() if not m[0]&m[1]}
        fixed_offers,fixed_counts=match(fixed,atoms,bank,terms,plan["match"])
        start=time.monotonic()
        offers,counts=match(lifted,atoms,bank,terms,plan["match"])
        match_seconds=time.monotonic()-start
        start=time.monotonic()
        assert all(verify(o,bank) for o in offers)
        for o in offers:
            mapping=dict(o.binding)
            assert set(mapping)==set(dict(lifted[o.recipe].types))
            assert all(fol.inspect_term(v,{},functions)==dict(lifted[o.recipe].types)[k] for k,v in mapping.items())
        if offers:
            example=offers[0]
            a,b,p,out=example.steps[-1]
            forged=replace(example,steps=example.steps[:-1]+((a,b,len(atoms)+1,out),))
            assert not verify(forged,bank)
            removed=prop.mask(example.leaves[0])
            assert not verify(example,{k:v for k,v in bank.items() if k!=removed})
        audit_seconds=time.monotonic()-start
        primitive=[prop.literals(m) for m in sorted(bank)]
        u=Derivation(bank)
        unit=u.refute(frozenset()) is not None
        with Solver(name="glucose4",bootstrap_with=primitive) as solver:
            sat=solver.solve()
            assert sat is (not positive)
            control=solver.accum_stats()
            if sat:
                truth=set(solver.get_model())
                assert all(truth.intersection(r) for r in primitive)
        results=[]
        for mode in ("cold","fixed","eager","demand","shuffle"):
            pool=[] if mode=="cold" else fixed_offers if mode=="fixed" else offers
            found=run(schemas,terms,atoms,pool,"demand" if mode=="fixed" else mode,plan["search"])
            status=found["status"]
            assert status=="BOUNDED" or (status=="REFUTED")==positive
            result=dict(mode=mode,status=status,cuts=found["cuts"],rounds=found["turns"],counts=found["counts"],
                        admitted=len(found["source"]),activated=len(found["active"]),seconds=found["seconds"])
            if status=="GROUND_MODEL":
                truth={i if bit else -i for i,bit in enumerate(found["model"],1)}
                assert all(truth.intersection(r) for r in primitive)
            if status=="REFUTED":
                (origins,premises,proof),contributing,used=expand(found,bank)
                raw=dict(atoms=atoms,origins=origins,premises=premises,proof=proof)
                fol.verify_instances(schemas,origins,premises,atoms,functions)
                prop.verify_resolution(premises,proof)
                sliced=slice_proof(raw)
                result["proof"]=sliced
                result["contributing"]=[asdict(o) for o in sorted(contributing,key=repr)]
                result["used_outputs"]=[asdict(o) for o in sorted(used,key=repr)]
                if [name,mode] in plan["export"]:
                    result["rectangle"],result["rectangle_file"]=certificate(
                        source,functions,schemas,terms,sliced,palette,f"{name}-{mode}")
            results.append(result)
        per_recipe={}
        for o in offers:
            per_recipe.setdefault(o.recipe,set()).add(o.binding)
        item=dict(id=name,source=original,atoms=atoms,full=len(bank),fixed=fixed_counts,lifted=counts,
                  seconds=dict(match=match_seconds,audit=audit_seconds),
                  bindings={i:len(b) for i,b in per_recipe.items()},unit_refutation=unit,
                  conventional=control,offers=[asdict(o) for o in offers],results=results)
        rows.append(item)
        print(json.dumps(dict(id=name,full=len(bank),fixed=fixed_counts["placements"],lifted=counts,
                             unit=unit,control=control["conflicts"],arms=[
              (r["mode"],r["status"],r["admitted"],r["activated"],r["counts"].get("decisions",0),
               len(r["cuts"]),len(r.get("used_outputs",[])),r.get("rectangle",{}).get("status"))
              for r in results]),sort_keys=True),flush=True)
    prop.save("data/lifted-v1.json",dict(recipes=metadata,fixed_recipes=fixed_meta,cases=rows,
                                       palette=prop.wang.digest(palette)))


if __name__=="__main__":
    main()
