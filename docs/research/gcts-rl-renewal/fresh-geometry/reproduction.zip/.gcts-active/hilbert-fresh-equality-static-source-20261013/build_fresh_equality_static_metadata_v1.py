"""SOURCE-only fresh equality static metadata entry: one prepare/audit pair per case.

ROOT owns execution. This builder never imports scientific modules or executes
source, grammars, catalogues, checkers, graphs, search, policies or subprocesses.
It reuses the existing generic owner/closer byte-identically. The audit plan is
created only from that case's actual complete accepted preparation disposition.
No native or historical geometric proof/result/certificate is an input.
"""
import copy
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
LEAF_PROGRESS = ROOT / '.gcts-active/hilbert-fresh-equality-static-progress-20261013'
ACTIVE_CASE_IDS = ('fresh-inc-point-chain-w', 'fresh-inc-reversed-line-chain')
PROFILE_ID = 'hilbert-first-checked-equality-cohort-static-v1'
MAX_METADATA = 64 * 1024 * 1024
LEAF_KEYS = {'schema', 'selector', 'output_directory', 'inputs', 'sources',
             'source_review', 'limits', 'ROOT_owned_once_only', 'closure'}
OWNER_KEYS = {'schema', 'stage', 'worker', 'argv', 'worker_receipt', 'limits',
              'runtime_binary', 'ROOT_source_review', 'scope', 'closure'}
REQUEST_KEYS = {'schema', 'phase', 'selector', 'progress_namespace',
                'ROOT_authorized_metadata_construction', 'ROOT_source_review'}
RESOURCE_PREDICATES = {'actual_tool_terminal', 'caller_clock_bound',
    'owner_terminal_link_present', 'owner_gate', 'post_write_gate',
    'cancelled_at_final_print_false', 'final_print_gate', 'stage_identity',
    'worker_complete', 'all_worker_direct_children_closed',
    'all_owner_direct_children_closed', 'no_owned_leftovers',
    'complete_post_closure_unchanged', 'post_write_exact_terminal'}
LEAF_LIMITS = {'whole_seconds': 60, 'peak_bytes': 536870912}
OWNER_LIMITS = {**LEAF_LIMITS, 'caller_seconds': 90}
REFERENCE_PINS = {'prepare_template': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-owned-progress-20261013/preparation-worker-plan-v1.json', 'sha256': '5bdbfe8a518df5531dda99b98a5332de9555cbf965abc6329200ae3ac0fc2c50', 'bytes': 17222}, 'audit_template': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-owned-progress-20261013/audit-worker-plan-v1.json', 'sha256': '51494f4efbace2b1b348d94fcec04c5b05afb3e91d82c3f866da668cfc5c393b', 'bytes': 24943}, 'owner_template': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-owned-progress-20261013/preparation-plan-v1.json', 'sha256': 'f0de65b0c53af0e78b897bfd16da37b57535bd3a7cf5c96fda9786f46b653a23', 'bytes': 13268}, 'ROOT_review_template': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-owned-progress-20261013/ROOT-source-review-v1.json', 'sha256': 'd5f3843f416b67d2089a38cf41d638c738d7d5a11597bc61a33f2cf5c03d18a4', 'bytes': 6676}, 'owner': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-owned-progress-20261013/run_owned_bridge_v2.py', 'sha256': '2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656', 'bytes': 14639}, 'closer': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-owned-progress-20261013/close_stage_decision_v1.py', 'sha256': '9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf', 'bytes': 4752}}
PROFILE_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-fresh-equality-static-source-20261013/static-profile-plan-v1.json', 'sha256': '91ed32762629eb127319d3710b9f7fab8d05a87226b203497d346bb6104cfbc7', 'bytes': 5565}
SOURCES = {'prepare': {'compact_engine': {'bytes': 20787, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-engine-source-20261012/compact_point_graph_v1.py', 'sha256': 'd638f7152ec7fa8293adbd8915b79de60f95d0756952bdc6bf0e40b15f549ca0'}, 'compiler': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-fresh-equality-static-source-20261013/hilbert_fresh_equality_compiler_v1.py', 'sha256': '57653bb27eaf3c4dd1e050c70ac360133f78e1f636cd1276a39a20fd64610a56', 'bytes': 46112}, 'decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'worker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-fresh-equality-static-source-20261013/hilbert_fresh_equality_prepare_worker_v1.py', 'sha256': 'cc1f05b4b18e4f570b25745a0cf3d3f7c816e4146872f36f8d7a939894acb7e3', 'bytes': 31893}}, 'audit': {'catalog_audit': {'bytes': 15171, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-independent-source-20261012/independent_compact_catalog_audit_v1.py', 'sha256': 'db4dc3b904715be3123ed1a9b22eb1ce9144c35aa00c610da94f13263e4334e8'}, 'domains': {'bytes': 7441, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-independent-source-20261012/independent_compact_domains_v1.py', 'sha256': '1b9d6b94c78f363ba20f48234dc1eb48ac9dcfa548e8f0fa1a7350699b059b34'}, 'grammar': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-fresh-equality-static-source-20261013/hilbert_fresh_equality_grammar_v1.py', 'sha256': '34322db5dc25cd3e0cc1dfa43f379f9f45107442c4f035d955b39f1e21b31db1', 'bytes': 14799}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'worker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-fresh-equality-static-source-20261013/hilbert_fresh_equality_audit_worker_v1.py', 'sha256': '7b25d902b69398d5d71c450ee9e63021df6d3b4e967b4c47b7d6e6b563d55fe6', 'bytes': 47959}}}
UPSTREAM_REVIEWS = {'compiler_person_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-literal-compiler-independent-source-20261013/source-review-v2.json', 'sha256': '0e782dd6207746fa95b5109f32beaf45036b9edfd6be226fa182c1d581598cf8', 'bytes': 51269}, 'oracle_person_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-person-review-20261013/source-review-v1.json', 'sha256': '86091bf909f486ff160fad27606ffd7f8d1945737d63218d3c68ea4986a1f7ee', 'bytes': 33603}}
REFERENCE_FIXTURE_PIN = {'bytes': 39325, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-literal-compiler-source-20261013/hilbert-next-fixtures-v1.json', 'sha256': '781d0b5139619d7c758425f198c84bbfa4176ca103f7de783d30c7249156e201'}
FIXTURE_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-fresh-equality-static-source-20261013/fresh-equality-fixtures-v1.json', 'sha256': 'b60869d015f5f60caa726864595a6293a4566ffdf04403c2499ade76987ef831', 'bytes': 43532}

def need(condition, label):
    if not condition:
        raise ValueError(label)

def canonical_path(text):
    need(type(text) is str and text, 'literal path required')
    p = Path(text)
    need(str(p) == text and not any(part in ('.', '..') for part in p.parts),
         'lexical path without traversal')
    p = p if p.is_absolute() else ROOT / p
    need(str(p.resolve()) == str(p), 'no symlink or path alias')
    return p

def normalize(record):
    need(type(record) is dict and set(record) == {'path', 'sha256', 'bytes'},
         'exact three-field raw pin')
    need(type(record['bytes']) is int and record['bytes'] >= 0
         and type(record['sha256']) is str and len(record['sha256']) == 64
         and all(c in '0123456789abcdef' for c in record['sha256']),
         'typed full SHA/length')
    return dict(record, path=str(canonical_path(record['path'])))

def raw_pin(path):
    path = canonical_path(str(path)); h = hashlib.sha256(); size = 0
    before = path.stat()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            h.update(block); size += len(block)
    after = path.stat()
    need((before.st_dev, before.st_ino, before.st_mtime_ns, before.st_size) ==
         (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_size),
         'immutable raw bytes during hashing')
    return {'path': str(path), 'sha256': h.hexdigest(), 'bytes': size}

def verify(record):
    n = normalize(record)
    need(raw_pin(n['path']) == n, 'whole raw pin differs')
    return Path(n['path'])

def unique_object(items):
    result = {}
    for key, value in items:
        need(key not in result, 'duplicate JSON key'); result[key] = value
    return result

def read(record, *, compressed=False):
    n = normalize(record); path = verify(n)
    with path.open('rb') as stream:
        raw = stream.read(MAX_METADATA + 1)
    need(len(raw) <= MAX_METADATA and len(raw) == n['bytes']
         and hashlib.sha256(raw).hexdigest() == n['sha256'],
         'same authenticated bounded JSON buffer')
    if compressed:
        import io
        with gzip.GzipFile(fileobj=io.BytesIO(raw), mode='rb') as stream:
            raw = stream.read(MAX_METADATA + 1)
            need(len(raw) <= MAX_METADATA and stream.read(1) == b'',
                 'entire bounded decoded metadata, no unread tail')
    value = json.loads(raw, object_pairs_hook=unique_object,
        parse_constant=lambda name: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    verify(n)
    return value

def write(path, value):
    with Path(path).open('xb') as stream:
        stream.write((json.dumps(value, sort_keys=True, indent=2,
            ensure_ascii=False, allow_nan=False) + '\n').encode('utf8'))
    return raw_pin(path)

def copy_raw(source, destination):
    n = normalize(source); raw = verify(n).read_bytes()
    need(len(raw) == n['bytes'] and hashlib.sha256(raw).hexdigest() == n['sha256'],
         'same source buffer before byte-identical copy')
    with Path(destination).open('xb') as stream:
        stream.write(raw)
    result = raw_pin(destination)
    need((result['sha256'], result['bytes']) == (n['sha256'], n['bytes']),
         'byte-identical namespace copy')
    return result

def add_tree(closure, value):
    """Traverse this named decoded value only; never decode pinned ancestors."""
    if type(value) is dict:
        if set(value) == {'path', 'sha256', 'bytes'}:
            n = normalize(value); verify(n)
            need(n['path'] not in closure or closure[n['path']] == n,
                 'conflicting full raw identity')
            closure[n['path']] = n
        else:
            for child in value.values():
                add_tree(closure, child)
    elif type(value) is list:
        for child in value:
            add_tree(closure, child)

def owner_spelling(record):
    n = normalize(record); path = Path(n['path'])
    # The unchanged generic owner emits ROOT-relative names for repo files.
    return dict(n, path=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT)
                else str(path))

def references():
    data = {name: read(record) for name, record in REFERENCE_PINS.items()
            if name in ('prepare_template', 'audit_template', 'owner_template', 'ROOT_review_template')}
    for record in REFERENCE_PINS.values():
        verify(record)
    for name in ('prepare_template', 'audit_template'):
        need(set(data[name]) == LEAF_KEYS and data[name]['limits'] == LEAF_LIMITS,
             'unchanged nine-field static leaf ABI')
    need(set(data['owner_template']) == OWNER_KEYS
         and data['owner_template']['limits'] == OWNER_LIMITS,
         'unchanged ten-field generic owner ABI')
    need(data['prepare_template']['inputs']['fixture'] == REFERENCE_FIXTURE_PIN
         and data['audit_template']['inputs']['fixture'] == REFERENCE_FIXTURE_PIN,
         'whole frozen reference declaration fixture')
    return data


def ROOT_review(request, refs, namespace, phase):
    record = normalize(request['ROOT_source_review']); value = read(record)
    owner = dict(REFERENCE_PINS['owner'], path=str(namespace/'run_owned_bridge_v2.py'))
    closer = dict(REFERENCE_PINS['closer'], path=str(namespace/'close_stage_decision_v1.py'))
    suffix = 'preparation' if phase == 'prepare' else 'audit'
    need(value.get('schema') == 'independent-Hilbert-next-'+suffix+'-worker-source-review-v1'
         and value.get('scope') == 'Hilbert-next-'+suffix+'-worker'
         and value.get('reviewer_identity') == '/root'
         and value.get('author_identity') == '/root/hilbert_ordering_diagnosis'
         and value.get('source_only') is True and value.get('source_ready') is True
         and value.get('source_review_passed') is True
         and value.get('scientific_acceptance') is False
         and type(value.get('scientific_calls')) is int and value['scientific_calls'] == 0,
         'genuine current different-author ROOT source review')
    need(value.get('builder_source_pin') == raw_pin(__file__)
         and value.get('owner_source_pin') == owner
         and value.get('closer_source_pin') == closer
         and value.get('sources') == SOURCES[phase]
         and value.get('inputs') == {'fixture': FIXTURE_PIN}
         and value.get('upstream_reviews') == UPSTREAM_REVIEWS
         and value.get('static_profile_id') == PROFILE_ID
         and value.get('static_profile_plan') == PROFILE_PIN
         and value.get('runtime') == refs['ROOT_review_template']['runtime'],
         'ROOT source review binds actual profile/workers/full fixture/runtime/copied supervisor')
    return record, value


def named_static_roots(closure, reviewpin, review, selector):
    add_tree(closure, reviewpin); add_tree(closure, review)
    profile = read(PROFILE_PIN)
    need(profile['profile_id'] == PROFILE_ID
         and tuple(c['id'] for c in profile['selected_cases']) == ACTIVE_CASE_IDS,
         'entire source-declared training/evaluation profile')
    add_tree(closure, PROFILE_PIN); add_tree(closure, profile)
    for record in UPSTREAM_REVIEWS.values():
        add_tree(closure, record); add_tree(closure, read(record))
    fixture = read(FIXTURE_PIN)
    add_tree(closure, FIXTURE_PIN); add_tree(closure, fixture)
    need(fixture['schema'] == 'hilbert-next-ground-theorem-fixtures-v1'
         and len(fixture['cases']) == 14
         and len([c for c in fixture['cases'] if c['id'] == selector]) == 1,
         'whole14-case fixture preserves original12 and exact fresh2, no filtered grammar')
    case = next(c for c in fixture['cases'] if c['id'] == selector)
    need(case['rows'] == 24 and len(case['hypotheses']) == 3
         and case['theory'] == 'hilbert-incidence', 'exact declared incidence context')
    declared = next(c for c in profile['selected_cases'] if c['id'] == selector)
    need(all(case[k] == declared[k] for k in ('id','split','theory','rows','hypotheses','target')),
         'profile/fixture equality of original concrete declaration')


def make_leaf(refs, phase, selector, inputs, reviewpin, closure):
    template = refs['prepare_template' if phase == 'prepare' else 'audit_template']
    leaf = copy.deepcopy(template)
    suffix = 'preparation' if phase == 'prepare' else 'audit'
    leaf.update(selector=selector, inputs=inputs, sources=SOURCES[phase], source_review=reviewpin,
        output_directory=str(LEAF_PROGRESS/(selector+'-'+suffix+'-v1')))
    path = LEAF_PROGRESS/(selector+'-'+suffix+'-worker-plan-v1.json')
    need(not path.exists() and not Path(leaf['output_directory']).exists(), 'one fresh leaf plan/output')
    add_tree(closure, {key:value for key,value in leaf.items() if key != 'closure'})
    leaf['closure'] = [closure[key] for key in sorted(closure)]
    need(set(leaf) == LEAF_KEYS and str(path) not in closure, 'exact leaf ABI/self exclusion')
    return leaf, write(path, leaf)


def make_owner(refs, namespace, phase, leaf, leafpin, reviewpin, closure):
    stage = 'preparation' if phase == 'prepare' else 'replay'
    owner = copy.deepcopy(refs['owner_template'])
    exe = owner['runtime_binary']['path']; worker = leaf['sources']['worker']['path']
    receipt = Path(leaf['output_directory'])/('preparation-result-v1.json' if phase == 'prepare'
                                             else 'audit-result-v1.json')
    owner.update(stage=stage, worker=str(Path(worker).relative_to(ROOT)),
        argv=[exe,'-B',worker,'ROOT-prepare-only' if phase == 'prepare' else 'ROOT-audit-only',leafpin['path']],
        worker_receipt=str(receipt.relative_to(ROOT)), ROOT_source_review=owner_spelling(reviewpin),
        scope='Once-only complete fresh equality evaluation static '+phase+
              '; empty inventory; no target search, proof route, grammar trim or learning.')
    add_tree(closure, leafpin); add_tree(closure, {k:v for k,v in owner.items() if k != 'closure'})
    owner['closure'] = [owner_spelling(closure[k]) for k in sorted(closure)]
    need(set(owner) == OWNER_KEYS, 'unchanged generic owner ABI')
    return write(namespace/(stage+'-plan-v1.json'), owner)


def preparation_inputs(namespace, setup, selector, closure):
    """Saved complete actual preparation only; no speculative q/model/proof."""
    decisionpin = raw_pin(namespace/'preparation-ROOT-final-decision-v1.json')
    decision = read(decisionpin)
    need(decision['schema'] == 'ROOT-fresh-catalog-stage-final-decision-v1'
         and decision['stage'] == 'preparation' and decision['ROOT_final_accepted'] is True
         and decision['status'] == 'accepted_complete_owned_stage'
         and set(decision['predicates']) == RESOURCE_PREDICATES
         and all(v is True for v in decision['predicates'].values())
         and decision['mismatches'] == [] and decision['native_accepted'] is False
         and decision['all_five_qualification'] is False and decision['limits'] == OWNER_LIMITS,
         'actual complete preparation disposition required')
    elapsed = decision['caller_elapsed_seconds']
    need(type(elapsed) in (int,float) and math.isfinite(elapsed) and elapsed >= 0
         and decision['caller_finish_reserve_seconds'] == 1 and elapsed + 1 <= 90,
         'actual caller envelope')
    need(normalize(decision['plan']) == setup['owner_plan'], 'actual own preparation plan')
    owner_plan = read(decision['plan']); leaf = read(setup['worker_plan'])
    need(leaf['selector'] == selector and leaf['sources'] == SOURCES['prepare']
         and leaf['inputs'] == {'fixture':FIXTURE_PIN}, 'actual same fresh source-qualified case')
    output = Path(leaf['output_directory'])
    inputs = {'fixture':FIXTURE_PIN, 'producer_plan':setup['worker_plan'],
        'producer_receipt':raw_pin(output/'preparation-result-v1.json'),
        'preparation_evidence':raw_pin(output/'full-preparation-evidence-v1.json.gz'),
        'catalog':raw_pin(output/'catalog-v1/catalog-v1.json'),
        'preparation_ROOT_decision':decisionpin,
        'producer_diagnostics':raw_pin(output/'producer-diagnostics-v1.jsonl')}
    receipt = read(inputs['producer_receipt'])
    need(normalize(decision['worker']) == inputs['producer_receipt']
         and normalize(receipt['plan']) == setup['worker_plan']
         and receipt['selector'] == selector and receipt['stage_completed'] is True
         and receipt['static_profile_id'] == PROFILE_ID and receipt['static_profile_plan'] == PROFILE_PIN
         and receipt['stage'] == 'preparation'
         and receipt['status'] == 'complete_pending_independent_and_ROOT_resource_gates'
         and receipt['logical_accepted'] is False and receipt['static_resource_qualified'] is False
         and receipt['all_direct_children_terminal_and_reaped'] is True
         and receipt['direct_children_peak_sum_bytes'] == 0, 'actual complete unqualified producer')
    need(normalize(receipt['full_result']) == inputs['preparation_evidence']
         and normalize(receipt['catalog']) == inputs['catalog']
         and normalize(receipt['producer_diagnostics']['trace']) == inputs['producer_diagnostics'],
         'complete actual artifact linkage')
    header = read(inputs['catalog']); evidence = read(inputs['preparation_evidence'],compressed=True)
    need(header['instance_id'] == selector and evidence['instance_id'] == selector
         and header['height'] == 24 and header['bodies'] == []
         and header['complete_cluster_inventory'] == [] and evidence['target_searches'] == 0
         and evidence['static_profile_id'] == PROFILE_ID and evidence['static_profile_plan'] == PROFILE_PIN,
         'same complete actual catalogue, empty inventory, no proof input')
    owner = read(decision['owner']); ledgerpin = owner['ownership_ledger']
    named = [(decisionpin,decision),(decision['plan'],owner_plan),(setup['worker_plan'],leaf),
             (leaf['source_review'],read(leaf['source_review'])),(inputs['producer_receipt'],receipt),
             (inputs['preparation_evidence'],evidence),(inputs['catalog'],header),
             (decision['owner'],owner),(ledgerpin,read(ledgerpin,compressed=True))]
    for record,value in named:
        add_tree(closure,record); add_tree(closure,value)
    add_tree(closure,inputs)
    return inputs,decisionpin


def build(request_path):
    requestpin = raw_pin(request_path); request = read(requestpin)
    need(type(request) is dict and set(request) == REQUEST_KEYS
         and request['schema'] == 'ROOT-fresh-equality-static-metadata-request-v1'
         and request['ROOT_authorized_metadata_construction'] is True
         and request['phase'] in ('prepare','audit') and request['selector'] in ACTIVE_CASE_IDS,
         'explicit ROOT request for exactly one source-declared fresh context')
    phase,selector = request['phase'],request['selector']
    namespace = canonical_path(request['progress_namespace'])
    need(namespace.parent == ROOT/'.gcts-active' and namespace not in (HERE,LEAF_PROGRESS)
         and namespace.name.startswith('hilbert-fresh-equality-'), 'fresh per-case same-depth supervision namespace')
    refs = references(); reviewpin,review = ROOT_review(request,refs,namespace,phase)
    closure = {}; add_tree(closure,requestpin); add_tree(closure,reviewpin);add_tree(closure,raw_pin(__file__))
    for record in REFERENCE_PINS.values(): add_tree(closure,record)
    if phase == 'prepare':
        need(not namespace.exists(), 'absent fresh preparation supervision directory')
        need(not (LEAF_PROGRESS/(selector+'-preparation-worker-plan-v1.json')).exists()
             and not (LEAF_PROGRESS/(selector+'-preparation-v1')).exists(), 'fresh case leaf destinations')
        namespace.mkdir();LEAF_PROGRESS.mkdir(exist_ok=True)
        ownerpin = copy_raw(REFERENCE_PINS['owner'],namespace/'run_owned_bridge_v2.py')
        closerpin = copy_raw(REFERENCE_PINS['closer'],namespace/'close_stage_decision_v1.py')
        localreview = copy_raw(reviewpin,namespace/'ROOT-source-review-v1.json')
        inputs = {'fixture':FIXTURE_PIN};decisionpin=None
    else:
        need(namespace.is_dir(), 'actual preparation namespace required')
        setuppin = raw_pin(namespace/'ROOT-preparation-plan-construction-v1.json');setup=read(setuppin)
        need(setup['builder_source_pin'] == raw_pin(__file__) and setup['selector'] == selector
             and setup['namespace'] == str(namespace), 'same current case metadata construction')
        ownerpin=raw_pin(namespace/'run_owned_bridge_v2.py');closerpin=raw_pin(namespace/'close_stage_decision_v1.py')
        need((ownerpin['sha256'],ownerpin['bytes']) == (REFERENCE_PINS['owner']['sha256'],REFERENCE_PINS['owner']['bytes'])
             and (closerpin['sha256'],closerpin['bytes']) == (REFERENCE_PINS['closer']['sha256'],REFERENCE_PINS['closer']['bytes']),
             'byte-identical generic owner and closer')
        need(not (namespace/'replay-plan-v1.json').exists() and not (namespace/'replay-owner-v1').exists(),
             'one fresh independent audit attempt')
        add_tree(closure,setuppin);add_tree(closure,setup)
        inputs,decisionpin=preparation_inputs(namespace,setup,selector,closure)
        localreview=copy_raw(reviewpin,namespace/'ROOT-audit-source-review-v1.json')
        priorreviewpin=raw_pin(namespace/'ROOT-source-review-v1.json')
        add_tree(closure,priorreviewpin);add_tree(closure,read(priorreviewpin))
    for record in (ownerpin,closerpin,localreview):add_tree(closure,record)
    named_static_roots(closure,localreview,review,selector)
    leaf,leafpin=make_leaf(refs,phase,selector,inputs,localreview,closure)
    ownerplanpin=make_owner(refs,namespace,phase,leaf,leafpin,localreview,dict(closure))
    stage='preparation' if phase == 'prepare' else 'replay'
    summary={'schema':'ROOT-fresh-equality-static-metadata-construction-v1','phase':phase,'selector':selector,
        'namespace':str(namespace),'static_profile_id':PROFILE_ID,'static_profile_plan':PROFILE_PIN,
        'source_only':True,'scientific_calls':0,'execution_issued':False,'qualified_context_created':False,
        'builder_source_pin':raw_pin(__file__),'request':requestpin,'ROOT_source_review':localreview,
        'worker_plan':leafpin,'owner_plan':ownerplanpin,'owner_source':ownerpin,'closer_source':closerpin,
        'actual_preparation_disposition':decisionpin,'leaf_closure_count':len(leaf['closure']),
        'literal_owner_command':[refs['owner_template']['runtime_binary']['path'],'-B',ownerpin['path'],ownerplanpin['path']],
        'literal_saved_closer_command':[refs['owner_template']['runtime_binary']['path'],'-B',closerpin['path'],stage],
        'scope':'Metadata only; ROOT owns once-only scientific dispatch, actual caller observations and independent complete qualification. No proofs, q/G, inventory or training created here.'}
    summarypin=write(namespace/('ROOT-preparation-plan-construction-v1.json' if phase=='prepare' else 'ROOT-audit-plan-construction-v1.json'),summary)
    return {'construction':summarypin,'worker_plan':leafpin,'owner_plan':ownerplanpin,
            'literal_owner_command':summary['literal_owner_command']}


if __name__ == '__main__':
    need(len(sys.argv)==2,'one explicit ROOT metadata request JSON')
    print(json.dumps(build(sys.argv[1]),sort_keys=True),flush=True)
