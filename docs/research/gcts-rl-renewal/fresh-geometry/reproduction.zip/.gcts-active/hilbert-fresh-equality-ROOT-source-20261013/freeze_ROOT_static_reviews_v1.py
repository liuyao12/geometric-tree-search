"""ROOT-authored source/pin review and request construction; no project execution."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / '.gcts-active/hilbert-fresh-equality-static-source-20261013'
PEER = ROOT / '.gcts-active/hilbert-incidence-priority-review-20261013'

def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

def verify(record):
    path = Path(record['path']); path = path if path.is_absolute() else ROOT / path
    actual = pin(path)
    assert actual['sha256'] == record['sha256'] and actual['bytes'] == record['bytes'], str(path)

def read(path):
    return json.loads(Path(path).read_bytes())

def tree_verify(value):
    if isinstance(value, dict):
        if set(value) == {'path', 'sha256', 'bytes'}:
            verify(value)
        else:
            for child in value.values(): tree_verify(child)
    elif isinstance(value, list):
        for child in value: tree_verify(child)

def write(name, value):
    path = HERE / name
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=False)
        stream.write('\n')
    return pin(path)

def main():
    handoff = read(SOURCE / 'handoff-v2.json')
    assert pin(SOURCE / 'handoff-v2.json')['sha256'] == 'c7c9dc9f0602cdc44cc346145912d6f5e94ea0a9ec5e15b5ac1a46e78418e8cf'
    tree_verify(handoff)
    original = read(ROOT / '.gcts-active/hilbert-next-owned-progress-20261013/ROOT-source-review-v1.json')
    assert pin(ROOT / '.gcts-active/hilbert-next-owned-progress-20261013/ROOT-source-review-v1.json')['sha256'] == 'd5f3843f416b67d2089a38cf41d638c738d7d5a11597bc61a33f2cf5c03d18a4'
    tree_verify(original['runtime'])
    findings_pin = pin(PEER / 'fresh-equality-static-source-findings-v1.json')
    assert findings_pin['sha256'] == '3b9ad8901c41da1aed45d8d9ce7ce7edd3c485423acd8c239db0cef2d26a7b51'
    findings = read(findings_pin['path']); tree_verify(findings)
    assert findings['all_checks_passed'] is True and findings['scientific_calls'] == 0
    assert findings['sources'] == handoff['full_source_role_maps']
    recipe = read(SOURCE / 'ROOT-request-recipe-SOURCE-v2.json')
    owner = pin(ROOT / '.gcts-active/hilbert-next-owned-progress-20261013/run_owned_bridge_v2.py')
    closer = pin(ROOT / '.gcts-active/hilbert-next-owned-progress-20261013/close_stage_decision_v1.py')
    assert (owner['sha256'], owner['bytes']) == ('2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656', 14639)
    assert (closer['sha256'], closer['bytes']) == ('9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf', 4752)
    records = []
    for selector in handoff['selected_case_ids']:
        namespace = Path(recipe['per_case_supervision_namespace_templates'][selector])
        assert namespace.parent == ROOT / '.gcts-active' and not namespace.exists()
        for phase, suffix in (('prepare', 'preparation'), ('audit', 'audit')):
            peer_path = PEER / ('fresh-equality-' + suffix + '-source-review-v1.json')
            review = copy.deepcopy(read(peer_path)); tree_verify(review)
            assert review['sources'] == handoff['full_source_role_maps'][phase]
            assert review['author_identity'] == '/root/hilbert_ordering_diagnosis'
            review['reviewer_identity'] = '/root'
            review.pop('SOURCE_only_not_ROOT_construction_review', None)
            review.pop('current_runtime_and_copied_supervisor_binding_remains_ROOT_review', None)
            review.update(runtime=original['runtime'],
                owner_source_pin=dict(owner, path=str(namespace / 'run_owned_bridge_v2.py')),
                closer_source_pin=dict(closer, path=str(namespace / 'close_stage_decision_v1.py')),
                independent_phase_SOURCE_review=pin(peer_path),
                ROOT_review_assessment='Current complete source role maps, append-only exact fresh statements, unchanged compiler/grammar callable algorithms, complete24-row domains, empty inventory, exact copied generic supervisor and current pinned runtime. Independent150-check source review retained. ROOT read the current preparation worker and metadata builder; unchanged audit algorithms are admitted from independently checked source deltas. No actual semantic/resource acceptance.',
                ROOT_source_review_provenance=pin(__file__),
                execution_authorized=False,
                scientific_acceptance=False,
                scientific_calls=0)
            review_pin = write(selector + '-' + phase + '-ROOT-source-review-v1.json', review)
            request = {'schema':'ROOT-fresh-equality-static-metadata-request-v1',
                'phase':phase, 'selector':selector, 'progress_namespace':str(namespace),
                'ROOT_authorized_metadata_construction':True, 'ROOT_source_review':review_pin}
            request_pin = write(selector + '-' + phase + '-ROOT-request-v1.json', request)
            records.append({'selector':selector,'phase':phase,'review':review_pin,'request':request_pin})
    write('ROOT-static-review-construction-v1.json', {
        'schema':'ROOT-fresh-equality-static-source-review-construction-v1',
        'source_only':True,'scientific_calls':0,'metadata_requests':records,
        'actual_plans_or_runs_created':False,'actual_qualification':False,
        'scope':'Review/requests only. Each audit builder still requires its own accepted complete actual preparation; no model or proof is generated here.'})
    print(json.dumps({'reviews':len(records),'scientific_calls':0,'actual_plans_or_runs_created':False}))

if __name__ == '__main__': main()
