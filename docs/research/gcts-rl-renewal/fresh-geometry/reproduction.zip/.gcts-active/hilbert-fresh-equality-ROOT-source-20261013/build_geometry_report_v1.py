"""Metadata-only publication assembly; saved bytes, no project/model calls."""
import copy
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PUB = Path('/private/tmp/gcts-family-router-publish-20261010')
REL = Path('docs/research/gcts-rl-renewal/fresh-geometry')
BASE = ROOT / '.gcts-active/hilbert-fresh-equality-static-progress-20261013'

def pin(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def read(path): return json.loads(Path(path).read_bytes())

def write_json(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,sort_keys=True,ensure_ascii=False);f.write('\n')

def main():
    public, deployed = ROOT/REL, PUB/REL
    assert public.is_dir() and not deployed.exists()
    original_path = HERE/'ROOT-actual-complete-static-geometry-disposition-v1.json'
    original = read(original_path)
    assert pin(original_path)['sha256']=='d87c6169a18a769a2e90b59f9809aae8dd1ebbe6324c8c39450fcd646047ed5a'
    data=copy.deepcopy(original);routes=[]
    closure={}
    def add_pin(record):
        p=Path(record['path']);p=p if p.is_absolute() else ROOT/p
        r=pin(p);assert (r['bytes'],r['sha256'])==(record['bytes'],record['sha256'])
        assert r['path'] not in closure or closure[r['path']]==r
        closure[r['path']]=r
    def add_tree(value):
        if type(value) is dict:
            if set(value)=={'path','sha256','bytes'}:add_pin(value)
            else:
                for child in value.values():add_tree(child)
        elif type(value) is list:
            for child in value:add_tree(child)
    def raw_route(source,relative,label):
        source=Path(source);r=pin(source);dest=public/relative;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f:f.write(source.read_bytes())
        assert pin(dest)['sha256']==r['sha256']
        routes.append(dict(url=str(relative),label=label,bytes=r['bytes'],sha256=r['sha256'],original=r))
        add_pin(r)
    add_tree(original);add_pin(pin(original_path))
    add_pin(pin(HERE/'ROOT-first-checked-endpoint-preregistration-v1.json'))
    add_pin(pin(HERE/'freeze_ROOT_static_reviews_v1.py'));add_pin(pin(__file__))
    raw_route(original_path,Path('static-qualification.json'),'Exact ROOT static qualification')
    for index,c in enumerate(data['cases']):
        cid=c['id'];prep=BASE/(cid+'-preparation-v1');audit=BASE/(cid+'-audit-v1');dest=Path('evidence')/cid
        label='Point-role context' if index==0 else 'Line-role context'
        for source,relative,title in [(prep/'full-preparation-evidence-v1.json.gz',dest/'preparation.json.gz','complete preparation'),(audit/'complete-independent-static-evidence-v1.json.gz',dest/'independent-audit.json.gz','complete independent audit'),(audit/'complete-independent-licenses-v1.jsonl.gz',dest/'licenses.jsonl.gz','every primitive licence'),(prep/'catalog-v1/catalog-v1.json',dest/'catalog/catalog-v1.json','complete catalogue header')]:raw_route(source,relative,label+' · '+title)
        header=read(prep/'catalog-v1/catalog-v1.json')
        for name,record in header['streams'].items():
            p=Path(record['path']);p=p if p.is_absolute() else ROOT/p
            raw_route(p,dest/'catalog'/p.name,label+' · '+name)
        stage=ROOT/('.gcts-active/hilbert-fresh-equality-'+cid+'-static-progress-20261013')
        for phase in ('preparation','replay'):
            owner=read(stage/(phase+'-plan-v1.json'))
            for record in owner['closure']:add_pin(record)
            add_pin(pin(stage/(phase+'-plan-v1.json')))
            raw_route(stage/(phase+'-ROOT-final-decision-v1.json'),dest/(phase+'-resources.json'),label+' · '+phase+' resource disposition')
            for suffix in ('actual-tool-observations-v1.json','ROOT-final-decision-v1.json'):
                p=stage/(phase+'-'+suffix);add_pin(pin(p));add_tree(read(p))
            for name in ('ROOT-terminal-v1.json','provisional-terminal-v1.json','post-write-observation-v1.json','launch-v1.json','owned-ownership-ledger-v1.json.gz','stdout-v1.txt','stderr-v1.txt'):
                p=stage/(phase+'-owner-v1')/name;add_pin(pin(p))
            leaf=read(BASE/(cid+('-preparation-worker-plan-v1.json' if phase=='preparation' else '-audit-worker-plan-v1.json')))
            add_tree(leaf)
        add_pin(pin(prep/'producer-diagnostics-v1.jsonl'))
    external=[];members=[]
    for path,record in sorted(closure.items()):
        p=Path(path)
        if not p.is_relative_to(ROOT):
            assert path.startswith('/Library/Developer/CommandLineTools/') or path=='/bin/ps'
            external.append(record);continue
        relative=p.relative_to(ROOT)
        assert '.git' not in relative.parts and (relative.parts[0] in ('.gcts-active','docs','scripts','research') or str(relative)=='AGENTS.md')
        members.append(dict(archive_name=str(relative),**record))
    text='''Exact saved geometry static study sources, inputs and capsules.

This archive is evidence and source material for independent reproduction.
Every member has a full raw hash and length in the separate manifest. The
complete original-host capsule closures are included; official runtime
binaries are not redistributed. Saved outputs and used once-only plans are
retained as evidence, rather than overwritten or restarted.

To make an independent run, establish a fresh study/output namespace and
review the source/path/runtime rebinding. These original workers and their
metadata builder use fixed paths and exclusive writes. A different host or
study namespace needs fresh source pins, source review and resource
qualification. Do not run the used capsules over the saved outputs.

The two scientific inputs contain only the exact statements and original
syntax seeds. No proof route or lemma library is supplied. All four actual
phases here are complete static catalogue/initial-point qualifications;
proof search and observer controls had not run at the report cutoff.
'''
    with zipfile.ZipFile(public/'reproduction.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for m in members:
            raw=Path(m['path']).read_bytes();assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
            z.writestr(m['archive_name'],raw)
        z.writestr('REPRODUCTION.txt',text)
    manifest={'schema':'notebook154-complete-static-source-archive-v1','members':members,'external_runtime_references':external,
        'archive':dict(pin(public/'reproduction.zip'),public_url='reproduction.zip'),'saved_capsules_are_used_once_only':True,'scientific_calls':0}
    write_json(public/'source-archive-manifest.json',manifest)
    data.update(public_artifacts=routes,exact_ROOT_disposition=pin(original_path),
        report_cutoff_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        report_scope='Complete static qualification only; current proof-search and observer runtime Sources are separate future milestones.')
    write_json(public/'summary.json',data)
    deployed.mkdir()
    for p in public.rglob('*'):
        if p.is_file():
            out=deployed/p.relative_to(public);out.parent.mkdir(parents=True,exist_ok=True)
            with out.open('xb') as f:f.write(p.read_bytes())
    base_index=PUB/'docs/research/gcts-rl-renewal/index.html';base=base_index.read_bytes()
    assert hashlib.sha256(base).hexdigest()=='29643bf6a5da2cec615813a416a4ff766fb76771315d5ce7c75c6e3b0d90dc24'
    marker=b'<section id="tm-wang-computation"'
    assert base.count(marker)==1
    panel='''<section id="fresh-geometry" class="panel">
<p class="eyebrow">NOTEBOOK 154 · COMPLETE FRESH GEOMETRY STATIC QUALIFICATION</p>
<h2>Two new symbolic geometry search contexts passed complete qualification.</h2>
<p>Both full catalogues preserve all five primitive rules, all \\(24\\) row domains and an empty inventory. Each has \\(5112\\) formulas and \\(2921\\) primitive licences. All four actual construction/audit phases passed; proof searches remain unrun at this cutoff.</p>
<p><a href="fresh-geometry/reader.html?v=n154#reader">Open both exact statements, their actual starting point tiles and all row-domain evidence</a>.</p>
<p>The next proof endpoint distinguishes a checked current-compatible proposal from selected ancestry and a completed board. No proof routes or lemma bodies are supplied.</p>
</section>
'''.encode('utf8')
    current=base.replace(marker,panel+marker,1)
    assert current.replace(panel,b'',1)==base
    with (HERE/'index-source-v1.html').open('xb') as f:f.write(current)
    files=[dict(path=str((REL/p.relative_to(public))),**{k:v for k,v in pin(p).items() if k!='path'}) for p in sorted(public.rglob('*')) if p.is_file()]
    files.append({'path':'docs/research/gcts-rl-renewal/index.html','bytes':len(current),'sha256':hashlib.sha256(current).hexdigest()})
    write_json(HERE/'ROOT-report-construction-v1.json',{'schema':'ROOT-notebook154-saved-static-report-construction-v1','scientific_calls':0,'archive_members':len(members),'external_runtime_references':external,'public_raw_routes':routes,'files':files,'ROOT_index_untouched':True,'publication_index_not_applied':True,'prior_published_index_sha256':hashlib.sha256(base).hexdigest(),'panel_inverse_reconstructs_prior_index':True})
    print(json.dumps({'public_files':len(files)-1,'archive_members':len(members),'raw_routes':len(routes),'scientific_calls':0,'publication_index_applied':False}))

if __name__=='__main__':main()
