"""SOURCE-only cold mechanical observer/DFS worker; ROOT alone invokes it.

No production q/catalogue/graph, supplied fresh proof or search activation is
consumed. Frozen real observer/DFS/GroundChecker are exercised on declared
unrelated mechanical doubles by the whole controls module. Generic owner and
closer supervise genuine caller60s/512MiB/90s; all assertions share real20s.
"""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time
import types

ROOT=Path(__file__).resolve().parents[2]
SCHEMA='ROOT-first-checked-proof-mechanical-controls-worker-plan-v1'
FIELDS={'schema','ROOT_owned_once_only','sources','runtime','reviews','closure',
        'limits','output_directory','owner_plan_path','specification'}
SOURCE_ROLES={'worker','controls','proof_observer','streamed_dfs','certificate','logical_oracle','master'}
EXECUTABLE_ROLES=('proof_observer','streamed_dfs','logical_oracle','controls')
AUTHOR='/root/hilbert_ordering_diagnosis'
FROZEN_SOURCES={'certificate': {'bytes': 64540, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/fresh_equality_context_and_final24_certificate_v3.py', 'sha256': '5d03d088c2d1b7f90e98fb7e28819ab0643b74f6786953c6107d4d2535c2377b'}, 'proof_observer': {'bytes': 29654, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/first_checked_proof_observer_v5.py', 'sha256': 'b1a43eb13af0a15b8d4a9e89a0f9a586f444b0db3a23452e27ff9ace60e4bced'}, 'streamed_dfs': {'bytes': 42024, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/compact_first_checked_proof_dfs_v11.py', 'sha256': 'a2cf1bb6d3ede1695d08f7c0d6f709bd5e9a6bc493ff06f1febe2fd4650269e4'}, 'controls': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-observer-controls-source-20261013/observer_dfs_mechanical_controls_v3.py', 'sha256': 'b03af83f7043de40a31d77d20ed47e37aa910201400e24bf0e08ca77c237bc2d', 'bytes': 32249}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}}
LIMITS=dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)
MAX_RAW_BYTES=64*1024*1024


def need(value,label):
    if not value:raise ValueError(label)


def absolute(record):
    need(type(record)is dict and set(record)=={'path','sha256','bytes'},'exact raw record fields')
    declared=Path(record['path']);path=declared if declared.is_absolute() else ROOT/declared
    need('..' not in declared.parts and path.resolve()==path and path.is_file(),'canonical current raw path')
    need(type(record['bytes'])is int and record['bytes']>=0 and type(record['sha256'])is str
         and len(record['sha256'])==64 and all(c in '0123456789abcdef' for c in record['sha256']),'typed raw identity')
    return dict(record,path=str(path))


def read_verified(record):
    record=absolute(record);path=Path(record['path']);before=path.stat()
    with path.open('rb') as stream:raw=stream.read(MAX_RAW_BYTES+1)
    after=path.stat()
    need(len(raw)<=MAX_RAW_BYTES and len(raw)==record['bytes']
         and hashlib.sha256(raw).hexdigest()==record['sha256']
         and (before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size)==
             (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size),'one entire stable authenticated buffer')
    return raw


def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    need(path.resolve()==path and (before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size)==
        (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size),'stable canonical output/source bytes')
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))


def json_pin(record):return json.loads(read_verified(record))


def load(record,name):
    record=absolute(record);raw=read_verified(record)
    module=types.ModuleType(name);module.__file__=record['path'];sys.modules[name]=module
    exec(compile(raw,record['path'],'exec'),module.__dict__)
    read_verified(record);return module


def executable_state(modules):
    """Full module bindings/functions/MRO/properties; no mutable fixture cache."""
    result=[];seen=set()
    def function(label,value):
        if isinstance(value,types.FunctionType):
            result.append((label,value,value.__code__,
                tuple(id(x) for x in (value.__defaults__ or ())),
                tuple((k,id(v)) for k,v in sorted((value.__kwdefaults__ or {}).items())),
                tuple(id(c.cell_contents) for c in (value.__closure__ or ()))))
    for role,module in sorted(modules.items()):
        result.append((role,module,id(module.__dict__),tuple((k,id(v)) for k,v in sorted(vars(module).items()) if k!='__builtins__')))
        for name,value in sorted(vars(module).items()):
            function(role+'.'+name,value)
            if not isinstance(value,type) or value in seen:continue
            seen.add(value);result.append((role+'.'+name,value,value.__mro__))
            for cls in value.__mro__:
                for key,item in sorted(vars(cls).items()):
                    if isinstance(item,property):
                        for suffix,fn in [('get',item.fget),('set',item.fset),('delete',item.fdel)]:
                            function(role+'.'+cls.__name__+'.'+key+'.'+suffix,fn)
                    elif isinstance(item,(staticmethod,classmethod)):function(role+'.'+cls.__name__+'.'+key,item.__func__)
                    else:function(role+'.'+cls.__name__+'.'+key,item)
    return tuple(result)


def cache_guard(sources,modules):
    allowed={absolute(sources[r])['path'] for r in EXECUTABLE_ROLES}|{str(Path(__file__).resolve())}
    need(sys.dont_write_bytecode,'cold no-cache worker')
    for role in EXECUTABLE_ROLES:
        path=Path(absolute(sources[role])['path']);cache=path.parent/'__pycache__'
        need(not (cache.exists() and any(cache.glob(path.stem+'.*.pyc'))),'no alternate compiled project source '+role)
    for module in tuple(sys.modules.values()):
        file=getattr(module,'__file__',None)
        if not file:continue
        path=Path(file).resolve()
        if ROOT in path.parents:need(str(path) in allowed,'explicit executable project allowlist')
    for role,module in modules.items():
        need(sys.modules.get(module.__name__) is module and module.__file__==absolute(sources[role])['path'],
             'exact originally loaded module identity '+role)


def peak():return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)


def save(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
    with path.open('xb') as stream:stream.write(raw)
    return pin(path)


def main():
    began=time.perf_counter();need(len(sys.argv)==3,'one leaf plan and its actual generic owner plan')
    plan_path=Path(sys.argv[1]).resolve();raw=plan_path.read_bytes();plan=json.loads(raw)
    plan_pin=pin(plan_path);need(hashlib.sha256(raw).hexdigest()==plan_pin['sha256'] and len(raw)==plan_pin['bytes'],'plan same authenticated buffer')
    need(set(plan)==FIELDS and plan['schema']==SCHEMA and plan['ROOT_owned_once_only'] is True,'exact SOURCE-qualified mechanical plan')
    owner_path=Path(sys.argv[2]).resolve();need(plan['owner_plan_path']==str(owner_path),'literal actual enclosing owner')
    owner=json.loads(owner_path.read_bytes())
    need(set(owner)=={'schema','stage','worker','argv','worker_receipt','limits','runtime_binary','ROOT_source_review','scope','closure'}
         and owner['schema']=='ROOT-guard-native-owned-plan-v1' and owner['stage']=='replay'
         and owner['argv']==[sys.executable,'-B',str(Path(__file__).resolve()),str(plan_path),str(owner_path)]
         and owner['limits']==plan['limits']==LIMITS,'actual unchanged flat generic owner and literal worker argv')
    need(set(plan['sources'])==SOURCE_ROLES and absolute(plan['sources']['worker'])==pin(Path(__file__).resolve()),'whole current seven-source role set')
    for role,record in FROZEN_SOURCES.items():need(absolute(plan['sources'][role])==record,'exact current frozen role '+role)
    need(set(plan['runtime'])=={'binary'} and absolute(plan['runtime']['binary'])==pin(Path(sys.executable).resolve()),'exact frozen Python binary')
    for record in plan['closure']:read_verified(record)
    closure={absolute(record)['path']:absolute(record) for record in plan['closure']}
    needed=list(plan['sources'].values())+[plan['runtime']['binary'],plan['specification']]+list(plan['reviews'].values())
    need(all(absolute(record)['path'] in closure and closure[absolute(record)['path']]==absolute(record) for record in needed),
         'whole explicit current source/specification/runtime/review closure')
    for record in plan['reviews'].values():read_verified(record)
    need(set(plan['reviews'])=={'ROOT','independent'},'actual ROOT and independent SOURCE review pins')
    root_review=json_pin(plan['reviews']['ROOT']);peer=json_pin(plan['reviews']['independent'])
    need(root_review['source_review_passed'] is True and root_review['scientific_calls']==0,'genuine prospective ROOT SOURCE review')
    need(peer['source_only'] is True and peer['source_review_passed'] is True and peer['scientific_calls']==0
         and peer['author_identity']==AUTHOR and peer['reviewer_identity']!=AUTHOR
         and peer['sources']==plan['sources'],'exact current independent full seven-role SOURCE review')
    specification=json_pin(plan['specification'])
    need(specification['schema']=='first-checked-proof-observer-generic-mechanical-specification-v1'
         and specification['scope']=='synthetic-observer-semantics-only'
         and specification['scientific_target_AST_or_qualified_context_input'] is False,'unrelated declared fixture specification only')
    directory=Path(plan['output_directory']).resolve()
    need(directory.parent==plan_path.parent and not directory.exists()
         and (ROOT/owner['worker_receipt']).resolve()==directory/'worker-receipt-v1.json','one fresh immutable owned output namespace')
    directory.mkdir();scratch=directory/'mechanical-scratch';scratch.mkdir()
    try:
        own=sys.modules[__name__]
        own_functions=tuple((name,value,value.__code__) for name,value in vars(own).items() if isinstance(value,types.FunctionType))
        original_snapshot=executable_state;original_load=load
        original_raw=read_verified;original_cache=cache_guard
        own_frozen=original_snapshot({'worker':own})
        modules={}
        for role in EXECUTABLE_ROLES:
            if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
                raise ValueError('own validator function/code changed before project load')
            modules[role]=original_load(plan['sources'][role],'_ROOT_first_proof_controls_'+role)
            if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
                raise ValueError('own validator function/code changed after project load')
        frozen=original_snapshot(modules)
        def guard():
            if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
                raise ValueError('original own validator function/code boundary')
            if original_snapshot({'worker':own})!=own_frozen:
                raise ValueError('own raw/module/MRO/property guard boundary')
            for record in plan['closure']:original_raw(record)
            original_cache(plan['sources'],modules)
            if original_snapshot(modules)!=frozen:
                raise ValueError('unchanged raw module/function/MRO/property endpoints')
        guarded_function=guard;guarded_code=guard.__code__
        if guard is not guarded_function or guard.__code__ is not guarded_code:
            raise ValueError('nested cold guard function/code changed before invocation')
        guard()
        need(modules['controls'].run_controls.__code__.co_filename==absolute(plan['sources']['controls'])['path']
             and modules['proof_observer'].FirstCheckedProofObserver.__init__.__code__.co_filename==absolute(plan['sources']['proof_observer'])['path']
             and modules['streamed_dfs'].search_episode.__code__.co_filename==absolute(plan['sources']['streamed_dfs'])['path'],
             'actual current runtime/control entrypoints source-bound')
        control_began=time.perf_counter();control_deadline=control_began+20
        result=modules['controls'].run_controls(modules['proof_observer'],modules['streamed_dfs'],modules['logical_oracle'],
            source_pins=[absolute(plan['sources'][r]) for r in EXECUTABLE_ROLES],specification=specification,
            work_directory=str(scratch),deadline=control_deadline)
        need(time.perf_counter()<control_deadline and result['completed'] is True and result['all_controls_passed'] is True,
             'whole mechanical controls complete within real aggregate20s')
        if guard is not guarded_function or guard.__code__ is not guarded_code:
            raise ValueError('nested cold guard function/code changed before return check')
        guard();result_pin=save(directory/'controls-result-v1.json',result)
        need(time.perf_counter()<control_deadline, 'complete control return/raw guard/result write within real20s')
        evidence=dict(schema='first-checked-proof-observer-mechanical-controls-evidence-v1',
            scope='synthetic-observer-semantics-only',sources=plan['sources'],specification=plan['specification'],plan=plan_pin,
            result=result_pin,control_call_seconds=time.perf_counter()-control_began,
            cold_worker_seconds_before_evidence_write=time.perf_counter()-began,peak_self_bytes=peak(),
            real_observer_DFS_GroundChecker_on_explicit_unrelated_doubles=True,
            independent_production_wire_G5_scheduler_or_complete_catalogue_qualified=False,
            synthetic_clock_delay_hooks_not_production_clock_qualification=True,
            fresh_target_proof_discovered=False,static_qualification=False,full24_accepted=False,
            native_accepted=False,full_trajectory_accepted=False,inventory_admitted=False,new_RL_training=False)
        evidence_pin=save(directory/'controls-evidence-v1.json',evidence)
        if guard is not guarded_function or guard.__code__ is not guarded_code:
            raise ValueError('nested cold guard function/code changed before evidence check')
        guard()
        need(time.perf_counter()-began<55 and peak()+12*1024*1024<=LIMITS['peak_bytes'],'leaf complete-write reserve before owner60/512')
        receipt=dict(schema='ROOT-first-checked-proof-mechanical-controls-worker-receipt-v1',stage='replay',stage_completed=True,
            all_direct_children_terminal_and_reaped=True,direct_children=0,direct_children_peak_sum_bytes=0,
            all_controls_passed=True,scope='synthetic-observer-semantics-only',sources=plan['sources'],
            mechanism_sources={r:plan['sources'][r] for r in ('proof_observer','streamed_dfs','certificate')},
            result=result_pin,evidence=evidence_pin,plan=plan_pin,control_call_seconds=evidence['control_call_seconds'],
            seconds=time.perf_counter()-began,peak_self_bytes=peak(),native_queries=0,native_replays=0,target_searches=0,
            mathematical_proofs_accepted=0,fresh_target_proof_discovered=False,new_RL_training=False)
        provisional=directory/'provisional-worker-receipt-v1.json';save(provisional,receipt)
        if guard is not guarded_function or guard.__code__ is not guarded_code:
            raise ValueError('nested cold guard function/code changed before receipt check')
        guard()
        need(time.perf_counter()-began<55 and peak()+12*1024*1024<=LIMITS['peak_bytes'],'final receipt/link clock and memory reserve')
        os.link(provisional,directory/'worker-receipt-v1.json')
    except BaseException as exc:
        failure=dict(schema='ROOT-first-checked-proof-mechanical-controls-worker-receipt-v1',stage='replay',stage_completed=False,
            all_direct_children_terminal_and_reaped=True,direct_children=0,direct_children_peak_sum_bytes=0,
            all_controls_passed=False,accepted_prefix=False,error=dict(type=type(exc).__name__,message=str(exc)),
            plan=plan_pin,seconds=time.perf_counter()-began,native_queries=0,native_replays=0,target_searches=0,
            mathematical_proofs_accepted=0,fresh_target_proof_discovered=False,new_RL_training=False)
        save(directory/'failure-worker-receipt-v1.json',failure)
        if not (directory/'worker-receipt-v1.json').exists():os.link(directory/'failure-worker-receipt-v1.json',directory/'worker-receipt-v1.json')
        raise
    print(json.dumps(dict(stage='replay',stage_completed=True,worker_receipt=pin(directory/'worker-receipt-v1.json'),
        target_searches=0,scope='synthetic-observer-semantics-only')),flush=True)


if __name__=='__main__':main()
