"""SOURCE bounded unrelated observer/DFS mechanical controls, no dispatch.

The actual frozen observer/DFS/GroundChecker modules are injected by ROOT's
cold owned worker. Point graph, reader, lifecycle, overlay and disabled-observer
are explicitly mechanical doubles; they are not a qualified production catalog
or graph. The unrelated toy signature contains only nullary ToyU/ToyT atoms.
No new scientific target, supplied fresh proof route, inventory or policy input.
"""
import copy
from dataclasses import dataclass
import gzip
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import time

VERSION='first-proof-observer-DFS-mechanical-controls-v1'


def canonical(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def digest(v):
    return hashlib.sha256(canonical(v).encode()).hexdigest()


def need(v,m):
    if not v:raise ValueError(m)


@dataclass(frozen=True,order=True)
class Key:
    recipe:int
    row:int
    refs:tuple=()
    def data(self):return [self.recipe,self.row,list(self.refs)]


@dataclass(frozen=True)
class Decision:
    kind:str
    row:object
    count:int
    generation:object


class Closed:
    def __init__(self):self.pins={}
    def verify(self,pin):
        raw=Path(pin['path']).read_bytes()
        need(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'whole toy raw licence input')
        self.pins[pin['path']]=dict(pin);return Path(pin['path'])
    def absolute(self,pin):return dict(pin,path=str(self.verify(pin).resolve()))
    def close(self):
        for pin in tuple(self.pins.values()):self.verify(pin)


class Wire:
    """Mechanical wire DOUBLE; does not claim binary/DAG codec conformance."""
    def __init__(self,header):
        self.header=header;self.data=copy.deepcopy(header['_mechanical_records']);self.count=len(self.data)
    def recipe(self,index):
        need(type(index) is int and 0<=index<self.count,'toy recipe index')
        return copy.deepcopy(self.data[index])


def licenses(closed,pin,wire,selected):
    rows=[]
    with gzip.open(closed.verify(pin),'rb') as stream:
        for line in stream:rows.append(json.loads(line))
    need(len(rows)==wire.count,'complete toy licence records')
    for i,r in enumerate(rows):
        rec=wire.recipe(i)
        need(r==dict(recipe_index=i,recipe_id=rec['id'],rule=rec['rule'],record_sha256=rec['record_sha256']),
             'every toy licence identity; not a production licensing authority')


def raw_pin(path):
    b=Path(path).read_bytes();return dict(path=str(Path(path).resolve()),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))


def executable_state(modules,classes):
    """Explicit function/code/default/closure/MRO/property identity snapshot."""
    result=[];seen=set()
    def function(label,f):
        if hasattr(f,'__code__'):
            result.append((label,f,f.__code__,
                           tuple(id(v) for v in (f.__defaults__ or ())),
                           tuple((k,id(v)) for k,v in sorted((f.__kwdefaults__ or {}).items())),
                           tuple(id(c.cell_contents) for c in (f.__closure__ or ()))))
    for label,module in sorted(modules.items()):
        result.append((label,'module',module))
        for name,value in sorted(vars(module).items()):
            if hasattr(value,'__code__'):function(label+'.'+name,value)
            if isinstance(value,type):classes.append(value)
    for cls in classes:
        if cls in seen:continue
        seen.add(cls);result.append(('class',cls,cls.__mro__))
        for base in cls.__mro__:
            for name,value in sorted(vars(base).items()):
                if isinstance(value,property):
                    for suffix,f in [('get',value.fget),('set',value.fset),('del',value.fdel)]:
                        if f is not None:function(base.__name__+'.'+name+'.'+suffix,f)
                elif isinstance(value,(staticmethod,classmethod)):function(base.__name__+'.'+name,value.__func__)
                else:function(base.__name__+'.'+name,value)
    return tuple(result)


class Guard:
    def __init__(self,modules,classes,pins):
        self.modules=modules;self.classes=list(classes);self.pins=list(pins)
        self.frozen=executable_state(modules,list(classes));self.calls=0
    def __call__(self):
        for pin in self.pins:
            need(raw_pin(pin['path'])==pin,'cold mechanical raw input/source changed')
        need(executable_state(self.modules,list(self.classes))==self.frozen,'cold code/MRO/property/object guard')
        self.calls+=1


def fixture(spec,*,early=False,forced=False,dead=False):
    """Whole tiny literal point palette, no favorable candidate selection."""
    u=['pred','ToyU',[]];t=['pred','ToyT',[]];imp=['imp',u,t]
    theory=dict(functions={},predicates={'ToyU':0,'ToyT':0},
                axioms={'toy_U':u,'toy_imp':imp,'toy_U_duplicate':u},schemas=[])
    gamma=[u,u,imp]
    recipes=[]
    for i,f in enumerate(gamma):
        recipes.append(dict(output=0 if i<2 else 1,inputs=[],premises=[],rule='assumption',
                            witness=dict(rule='assumption',index=i,formula=f)))
    recipes.append(dict(output=2,inputs=[0,1],premises=[u,imp],rule='mp',
                        witness=dict(rule='mp',antecedent=0,implication=0,formula=t)))
    for name,f,code in [('toy_U',u,0),('toy_imp',imp,1),('toy_U_duplicate',u,0)]:
        recipes.append(dict(output=code,inputs=[],premises=[],rule='axiom',
                            witness=dict(rule='axiom',name=name,formula=f)))
    for i,rec in enumerate(recipes):
        rec['index']=i;rec['record_sha256']=digest(rec);rec['id']='unrelated-toy-'+digest(rec)
    fixed=[[1,23,2]]
    if early or forced:fixed.append([1,3,2])
    if forced:fixed.append([2,3,-3])
    if dead:fixed.append([1,5,99])
    return dict(instance_id=spec['borrowed_interface_identifier_only'],height=24,bodies=[],complete_cluster_inventory=[],
        context=dict(theory=theory,ordered_local_premises=gamma),target=t,target_code=2,
        assumption_recipe_indices=[0,1,2],boundary=dict(fixed_exterior_m=[],fixed_target_m=fixed),
        dimensions=dict(logical_rows=24,formula_count=3,primitive_license_count=7,
                        non_assumption_witness_count=4,source_body_count=0),
        _mechanical_records=recipes,_scope='UNRELATED mechanical FOL/point fixture, not fresh qualified scientific context')


class Domain:
    def __init__(self,graph,decision,preferred=()):
        self.graph=graph;self.decision=decision;self.keys=list(graph.candidates(decision.row));self.preferred=tuple(preferred)
        need(all(k in self.keys for k in preferred),'only legal complete toy preference')
        self.keys=list(preferred)+[k for k in self.keys if k not in preferred]
    def __len__(self):return len(self.keys)
    def first(self):return self.keys[0]
    def descriptor(self):
        return dict(state_sha256=digest(self.graph.semantic_state()),catalog_identity_sha256=self.graph.catalog_identity_sha,
            runtime_authority_sha256=self.graph.runtime_authority_sha,
            decision=[self.decision.kind,self.decision.row,self.decision.count,self.decision.generation],
            preferred_keys=[k.data() for k in self.preferred],complete_count=len(self.keys))


class Graph:
    """Exhaustive finite point-model DOUBLE; same master decision precedence."""
    height=24;fixture=False
    def __init__(self,header):
        self.model_epoch='mechanical-model';self.catalog_identity_sha='mechanical-catalog';self.runtime_authority_sha='mechanical-runtime'
        def get_header(c):return c._header
        catalog_type=type('MechanicalGeneratedCatalog',(),{'header':property(get_header)})
        self.catalog=catalog_type();self.catalog._header=header
        self.recipes=tuple(header['_mechanical_records']);self.formulas=tuple(range(3))
        self.initial_selected=tuple(Key(i,i,()) for i in range(3));self.order=list(self.initial_selected)
        self.selected={k:i for i,k in enumerate(self.order)};self.excluded=set();self.trail=[]
        self.metrics=dict(attempts=0,backtracks=0,branches=0,forced=0);self._bound_core=None
    def _points(self,keys):
        totals=[0]*24;groups={}
        def assign(x,y,value):
            point=(x,y)
            if point in groups:
                need(groups[point][0]==value,'exact remote toy mark agreement')
                groups[point][1]+=1
            else:groups[point]=[value,1]
        for x,y,value in self.catalog.header['boundary']['fixed_target_m']:assign(x,y,value)
        for key in keys:
            rec=self.recipes[key.recipe];need(totals[key.row]==0,'unit placement identity once');totals[key.row]=1
            local={(1,key.row):rec['output']}
            for port,(ref,code) in enumerate(zip(key.refs,rec['inputs'])):
                need((1,ref) not in local or local[(1,ref)]==code,'unequal formula ports cannot alias')
                local[(1,ref)]=code;local[(2+port,key.row)]=ref-key.row
            for (x,y),value in local.items():assign(x,y,value)
        return totals,[[x,y,*groups[(x,y)]] for x,y in sorted(groups)]
    def semantic_state(self):
        totals,marks=self._points(self.order)
        return dict(schema='compact-complete-dynamic-point-state-v2',model_epoch=self.model_epoch,
            catalog_identity_sha256=self.catalog_identity_sha,runtime_authority_sha256=self.runtime_authority_sha,
            order=[k.data() for k in self.order],totals=totals,marks=marks,
            excluded=[k.data() for k in sorted(self.excluded)])
    def assert_runtime_integrity(self):self._points(self.order)
    def _candidate_matches(self,key,totals,marks):
        if (type(key.recipe)is not int or not 0<=key.recipe<len(self.recipes)
                or type(key.row)is not int or not 0<=key.row<24 or key in self.excluded
                or totals[key.row]!=0):return False
        rec=self.recipes[key.recipe]
        if len(key.refs)!=len(rec['inputs']) or any(type(r)is not int or not 0<=r<key.row for r in key.refs):return False
        local={(1,key.row):rec['output']}
        for port,(ref,code) in enumerate(zip(key.refs,rec['inputs'])):
            if (1,ref) in local and local[(1,ref)]!=code:return False
            local[(1,ref)]=code;local[(2+port,key.row)]=ref-key.row
        return all(point not in marks or marks[point]==value for point,value in local.items())
    def legal(self,key):
        totals,grouped=self._points(self.order);marks={(x,y):value for x,y,value,count in grouped}
        return self._candidate_matches(key,totals,marks)
    def candidates(self,row):
        from itertools import product
        totals,grouped=self._points(self.order);marks={(x,y):value for x,y,value,count in grouped}
        for i,rec in enumerate(self.recipes):
            for refs in product(range(row),repeat=len(rec['inputs'])):
                key=Key(i,row,tuple(refs))
                if self._candidate_matches(key,totals,marks):yield key
    def decision(self):
        rows=[r for r in range(24) if r not in {k.row for k in self.order}]
        counts={r:sum(1 for _ in self.candidates(r)) for r in rows}
        if any(n==0 for n in counts.values()):return Decision('dead',min(r for r,n in counts.items() if n==0),0,0)
        if any(n==1 for n in counts.values()):return Decision('forced',min(r for r,n in counts.items() if n==1),1,0)
        if not rows:return Decision('complete',None,0,None)
        row=min(rows,key=lambda r:(counts[r],r));return Decision('branch',row,counts[row],0)
    def ordered_domain(self,d,preferred=()):need(d==self.decision(),'fresh mandatory toy decision');return Domain(self,d,preferred)
    def checkpoint(self):return len(self.trail)
    def rollback(self,depth):
        while len(self.trail)>depth:self.order,self.excluded=self.trail.pop()
        self.selected={k:i for i,k in enumerate(self.order)}
    def step(self,key):
        kind=self.decision().kind;need(self.legal(key),'exact legal toy step')
        self.trail.append((list(self.order),set(self.excluded)));self.order.append(key)
        self.selected={k:i for i,k in enumerate(self.order)};self.metrics['attempts']+=1
        self.metrics['forced' if kind=='forced' else 'branches']+=1
    def exclude_failed_child(self,key):
        self.trail.append((list(self.order),set(self.excluded)));self.excluded.add(key)
    def point_certificate(self):return dict(scope='mechanical double only; not production full24 acceptance')


class Executor:
    def __init__(self,graph):self.graph=graph
    def step(self,key):self.graph.step(key)


class Controller:
    def __init__(self,graph,authority,groups):
        self.graph=graph;self.descriptors=();self.states=[];self.trail=[];self.root_rejected_text='[]'
        self.metrics=dict(members_checked=0,mark_checks=0)
    def resync(self,decision=None):pass


class Overlay:
    def __init__(self,control,core,features,math,weights,**kwargs):
        self.control=control;self.graph=control.graph;self.recipes=self.graph.recipes;self.active_id=None;self.trail=[]
    def semantic_state(self):return dict(controller=dict(graph=self.graph.semantic_state()))
    def checkpoint(self):return self.graph.checkpoint()
    def rollback(self,cp):self.graph.rollback(cp)
    def after_resync(self):pass
    def _feature_graph(self):return self.graph


def available_rows(graph,recipes):
    complete={};root={recipes[k.recipe]['output'] for k in graph.initial_selected}
    for k in sorted(graph.order,key=lambda k:k.row):
        rec=recipes[k.recipe]
        if all(r in complete and complete[r]==c for r,c in zip(k.refs,rec['inputs'])):complete[k.row]=rec['output']
    return dict(complete=complete,root_codes=root,distinct_nonroot_codes=set(complete.values())-root)


def checked_pin(pin):need(raw_pin(pin['path'])==pin,'exact source-bound mechanical input')


def consumer(binding,graph,core,features,math,**kwargs):
    return canonical(binding)


class DisabledObserver:
    """Explicit disabled-endpoint DOUBLE; actual observer is still exercised."""
    ACTUAL=None
    def __init__(self,*args,**kwargs):
        self.actual=self.ACTUAL(*args,**kwargs);self.construction=self.actual.construction
        self.metrics=self.actual.metrics;self.observations=self.actual.observations
    def observe(self,*args,**kwargs):
        candidate,receipt=self.actual.observe(*args,**kwargs)
        receipt=dict(receipt,accepted_target_found=False,mechanical_endpoint_disabled=True)
        return None,receipt


def run_controls(observer_module,dfs_module,kernel_module,*,source_pins,specification,work_directory,deadline):
    """Future ROOT-only execution, aggregate real20s plus cold owned60/512/90.

    Full returned episode records are retained. Test-double source identities
    are explicit, and no generated toy record qualifies a fresh science target.
    """
    began=time.perf_counter();need(deadline>began,'positive aggregate mechanical clock')
    checks=[];episodes=[];guards=[]
    def check(name,value):
        if time.perf_counter()>=deadline:raise TimeoutError('whole controls UNKNOWN; no accepted prefix')
        need(value,name);checks.append(dict(name=name,passed=True))
    def rejects(name,call,kind=ValueError):
        try:call()
        except kind:check(name,True)
        else:check(name,False)
    work=Path(work_directory);need(work.is_dir(),'ROOT-owned existing scratch directory')
    reader=SimpleNamespace(SelectedWire=Wire,ClosedInputs=Closed,licenses=licenses,parse=json.loads)
    modules={'observer':observer_module,'DFS':dfs_module,'kernel':kernel_module}
    core=SimpleNamespace(Key=Key,Decision=Decision,Executor=Executor,integer=lambda v:v if type(v)is int else (_ for _ in ()).throw(ValueError('integer')),
                         canonical=canonical,digest=digest,json=json)
    life=SimpleNamespace(core=core,Controller=Controller)
    features=SimpleNamespace(FEATURE_NAMES=tuple('f'+str(i) for i in range(31)),available_rows=available_rows)
    math=SimpleNamespace(vector=lambda v,label:dict(v),reward=lambda **kwargs:dict(mechanical_reward_only=0))
    overlay=SimpleNamespace(LearnedFamilyOverlay=Overlay,checked_pin=checked_pin,check_consumer_binding=consumer)
    authority=SimpleNamespace(bodies=(),epoch='mechanical-empty-authority')
    def make(header,label):
        graph=Graph(header);graph._bound_core=core
        path=work/(label+'-licences.jsonl.gz')
        with gzip.open(path,'xb') as stream:
            for rec in header['_mechanical_records']:
                stream.write((canonical(dict(recipe_index=rec['index'],recipe_id=rec['id'],rule=rec['rule'],record_sha256=rec['record_sha256']))+'\n').encode())
        guard=Guard(modules,[Graph,type(graph.catalog),Wire,Closed,kernel_module.GroundChecker],source_pins)
        guards.append(guard);closed=Closed()
        def source_guard():guard()
        args=dict(reader=reader,wire=None,checker_class=kernel_module.GroundChecker,closed=closed,
                  header=header,license_pin=raw_pin(path),source_guard=source_guard)
        return graph,args,guard
    def observe(graph,args,kind='actual_selected',selection=None):
        obs=observer_module.FirstCheckedProofObserver(graph,**args,deadline=deadline)
        before=digest(graph.semantic_state())
        result,receipt=obs.observe(graph.decision(),origin_kind=kind,completed_selection=selection,
                                  source_link={'mechanical_fixture':True},deadline=deadline)
        check('direct observer passive whole state',before==digest(graph.semantic_state()))
        return obs,result,receipt
    early=fixture(specification,early=True)
    graph,args,guard=make(early,'direct-valid');graph.step(Key(3,3,(1,2)))
    obs,proof,receipt=observe(graph,args)
    check('actual observer actual GroundChecker unrelated target',proof is not None and proof['origin_kind']=='actual_selected' and proof['patch']['kernel_result']['rows']==4)
    check('indexed repeated Gamma occurrence1 retained',proof['patch']['consumed_original_occurrence_indices']==[1,2])
    rejects('sealed graph endpoint replacement',lambda:setattr(obs,'graph',object()))
    rejects('sealed kernel endpoint replacement',lambda:setattr(obs,'checker_class',object()))
    rejects('raw guard detects changed disposable input',lambda:(guard.pins.append(dict(path=args['license_pin']['path'],sha256='0'*64,bytes=args['license_pin']['bytes'])),guard()))
    guard.pins.pop()
    code=observer_module.clock.__code__
    def tampered(deadline):return None
    try:
        observer_module.clock.__code__=tampered.__code__
        rejects('code-object mutation rejected before acceptance',guard)
    finally:observer_module.clock.__code__=code
    prop=type(graph.catalog).header.fget;code=prop.__code__
    def replacement(c):return c._header
    try:
        prop.__code__=replacement.__code__
        rejects('generated catalogue property code root rejected',guard)
    finally:prop.__code__=code
    for endpoint,method in [(obs.wire,'recipe'),(obs.closed,'absolute'),(obs.graph,'semantic_state')]:
        original=getattr(endpoint,method)
        setattr(endpoint,method,lambda *a,**k:None)
        try:rejects('instance method shadow '+method,lambda:obs._guard(deadline))
        finally:delattr(endpoint,method)
        check('original effective method restored '+method,getattr(endpoint,method).__func__ is original.__func__)
    # The delegated guard is an ordinary callable object in this mechanical
    # fixture; production caller supplies a raw-bound nested function.
    callable_obs=observer_module.FirstCheckedProofObserver(graph,**dict(args,source_guard=guard),deadline=deadline)
    old=Guard.__call__.__code__
    def silent(self):return None
    try:
        Guard.__call__.__code__=silent.__code__
        rejects('callable-object delegated validator no-op code rejected',lambda:callable_obs._guard(deadline))
    finally:Guard.__call__.__code__=old
    validator=obs.source_guard;old=validator.__code__
    def silent_factory(bound):
        def silent():return bound and None
        return silent
    try:
        validator.__code__=silent_factory(guard).__code__
        rejects('nested delegated validator same-object code no-op rejected',lambda:obs._guard(deadline))
    finally:validator.__code__=old
    guard()
    # Current-state conflict: standalone target proof survives, primary does not.
    graph,args,_=make(fixture(specification),'union-failure');graph.step(Key(4,3,()))
    selection={'preferred_cluster_proposals':[dict(root_row=3,primitive_keys=[Key(3,3,(1,2)).data()],commands=[{'forged':True}],target_equality=True)]}
    obs,proof,receipt=observe(graph,args,'completed_source_proposal',selection)
    check('current union rejected target is supplemental only',proof is None and receipt['census'][0]['standalone_logical_target_artifact']['patch']['kernel_result']['original_ground_sequent_accepted'] is True and receipt['census'][0]['primary_endpoint_eligible'] is False)
    graph,args,_=make(fixture(specification),'forged-flags')
    selection={'preferred_cluster_proposals':[dict(root_row=3,primitive_keys=[Key(4,3,()).data()],commands=[{'rule':'axiom','formula':['pred','ToyT',[]]}],target_equality=True)]}
    obs,proof,_=observe(graph,args,'completed_source_proposal',selection)
    check('forged proposal commands/target flag ignored',proof is None)
    graph,args,_=make(fixture(specification),'pending');graph.step(Key(3,4,(3,2)))
    obs,proof,receipt=observe(graph,args)
    check('pending prior reader is not proof',proof is None and any(c['status']=='pending_dependency_reader' for c in receipt['census']))
    bad=fixture(specification,early=True);bad['_mechanical_records'][0]['witness']['index']=1
    rec=bad['_mechanical_records'][0];rec['record_sha256']=digest(rec);rec['id']='wrong-index-toy'
    graph,args,_=make(bad,'wrong-index');graph.step(Key(3,3,(1,2)))
    rejects('wrong original occurrence index with identical formula rejected',lambda:observe(graph,args))
    records={r['index']:r for r in early['_mechanical_records']}
    state=observer_module.literal_state([],records,fixed=[[1,9,0]])
    check('assigned zero preserved separately from missing',state['m']==[[1,9,0]] and observer_module.literal_state([],records)['m']==[])
    rejects('zero and one same assigned point disagree',lambda:observer_module.literal_state([],records,fixed=[[1,9,0],[1,9,1]]))
    rejects('unequal codes cannot alias ordered read ports',lambda:observer_module.literal_state([Key(3,3,(1,1)).data()],records))
    rejects('duplicate shared primitive key cannot add t twice',lambda:observer_module.literal_state([Key(4,3,()).data(),Key(4,3,()).data()],records))
    graph,args,_=make(fixture(specification,early=True),'shared');graph.step(Key(3,3,(1,2)))
    obs,proof,_=observe(graph,args,'completed_source_proposal',{'preferred_cluster_proposals':[dict(root_row=3,primitive_keys=[Key(3,3,(1,2)).data()])]})
    check('shared current/proposed placement counted once',proof is not None and proof['prospective_current_point_union']['t'].count([0,3,1])==1 and not proof['actual_selected_target_accepted'])
    # Actual DFS prefix comparison uses only declared point-model doubles.
    def episode(header,label,enabled=True,event_ceiling=2000):
        graph,args,guard=make(header,label);control=Controller(graph,authority,[])
        expected=dfs_module.complete_inventory_binding(graph,authority,control,header['dimensions'],core)
        if enabled:om=observer_module;binding=next(p for p in source_pins if p['path']==str(Path(observer_module.__file__).resolve()))
        else:
            DisabledObserver.ACTUAL=observer_module.FirstCheckedProofObserver
            om=SimpleNamespace(VERSION=observer_module.VERSION,FirstCheckedProofObserver=DisabledObserver,
                               ProofObservationBudgetExceeded=observer_module.ProofObservationBudgetExceeded,clock=observer_module.clock)
            binding=raw_pin(__file__)
        before=digest(graph.semantic_state())
        result=dfs_module.search_episode(graph,authority,[],life,overlay,features,math,
            episode_id='unrelated-mechanical/'+label,mode='base',seed=None,weights={n:0.0 for n in features.FEATURE_NAMES},
            attempts=128,seconds=20,event_ceiling=event_ceiling,prerequisite_pins={'scope':'mechanical'},
            cold_preparation_costs={'scope':'mechanical, no production q'},qualified_dimensions=header['dimensions'],
            expected_inventory_binding=expected,consumer_binding={'scope':'mechanical-consumer-double'},
            observer_module=om,observer_source_binding=binding,observer_inputs=args)
        if time.perf_counter()>=deadline:raise TimeoutError('whole controls UNKNOWN; no accepted prefix')
        episodes.append(result)
        return result,graph,before
    enabled,graph,before=episode(fixture(specification,early=True),'enabled')
    disabled,_,_=episode(fixture(specification,early=True),'disabled',False)
    check('deliberate first proof exact root rollback',enabled['status']=='first_checked_original_Gamma_target_proof' and enabled['root_restored'] and digest(graph.semantic_state())==before)
    check('logical stop creates no exhausted exclusion',not any(e['kind']=='parent_local_exhausted_child_exclusion' for e in enabled['events']) and graph.metrics['backtracks']==0)
    kinds={'global_decision','complete_chosen_domain_order','primitive_step','branch_begin'}
    def prefix(result):
        return [{k:e[k] for k in ['kind','node','key','decision','selected_key','preferred_keys'] if k in e} for e in result['events'] if e['kind'] in kinds]
    ep=prefix(enabled);dp=prefix(disabled)
    check('disabled/enabled exact scheduler/domain/order/key prefix',dp[:len(ep)]==ep)
    check('timed actual observer return metadata binding',observer_module.verify_returned_proof(enabled)==enabled['first_checked_proof'])
    dead,_,_=episode(fixture(specification,forced=True,dead=True),'dead')
    check('global dead precedes forced and every observation',dead['status']=='exhausted_finite_marked_subtree' and dead['proof_observer']['observations']==[] and dead['attempts']==0)
    forced,_,_=episode(fixture(specification,forced=True),'forced')
    first_step=next(e for e in forced['events'] if e['kind']=='primitive_step');first_observe=next(e for e in forced['events'] if e['kind']=='passive_first_proof_observation')
    check('global forced move completed before proof observation',first_step['index']<first_observe['index'] and forced['graph_metrics']['forced']>=1)
    limited,_,_=episode(fixture(specification,early=True),'trace-budget',event_ceiling=1)
    check('trace expiry never returns partial primary',limited['status']=='unknown_trace_budget' and limited['first_checked_proof'] is None and not limited['logical_target_proof_accepted'])
    graph,args,_=make(fixture(specification),'constructor-expired')
    rejects('expired constructor grants no object',lambda:observer_module.FirstCheckedProofObserver(graph,**args,deadline=time.perf_counter()-1),observer_module.ProofObservationBudgetExceeded)
    # Final-boundary deterministic instrumentation is an explicit TIME DOUBLE,
    # not evidence of production wall clocks or raw runtime integrity. The
    # aggregate real20s deadline above remains active for every assertion.
    clock_tests=[]
    old_observer_time=observer_module.time;old_dfs_time=dfs_module.time;old_copy=dfs_module.copy
    class Clock:
        now=0.0
        def perf_counter(self):return self.now
    fake=Clock()
    try:
        observer_module.time=fake
        graph,args,_=make(fixture(specification,early=True),'late-constructor')
        class LateSeal(observer_module.FirstCheckedProofObserver):
            def __setattr__(self,name,value):
                super().__setattr__(name,value)
                if name=='_sealed' and value is True:fake.now=21.0
        rejects('constructor final seal metadata expiry withholds object',
                lambda:LateSeal(graph,**args,deadline=20),observer_module.ProofObservationBudgetExceeded)
        clock_tests.append('constructor actual __init__ with explicitly synthetic subclass seal-delay hook')
        fake.now=0.0
        graph,args,_=make(fixture(specification,early=True),'late-observation');graph.step(Key(3,3,(1,2)))
        late=observer_module.FirstCheckedProofObserver(graph,**args,deadline=20)
        class LateSink(list):
            def append(self,value):super().append(value);fake.now=21.0
        # Explicit synthetic metadata-sink injection, not an admitted runtime
        # object mutation or a claim that the production guard permits it.
        object.__setattr__(late,'observations',LateSink())
        rejects('observation final receipt append expiry returns no certificate',
            lambda:late.observe(graph.decision(),origin_kind='actual_selected',source_link={'late_sink':True},deadline=20),
            observer_module.ProofObservationBudgetExceeded)
        check('late saved receipt is explicitly incomplete with no primary',len(late.observations)==1
              and late.observations[0]['completed'] is False and late.observations[0]['accepted_target_found'] is False
              and late.observations[0]['primary_certificate_withheld_on_final_deadline'] is True)
        clock_tests.append('observation actual method with explicitly synthetic append-delay metadata sink')
        fake.now=0.0;dfs_module.time=fake
        def delayed_copy(value,*a,**k):
            answer=old_copy.deepcopy(value,*a,**k)
            if type(value)is dict and value.get('schema')=='first-checked-original-Gamma-target-primitive-patch-v1':fake.now=21.0
            return answer
        dfs_module.copy=SimpleNamespace(deepcopy=delayed_copy)
        late_result,late_graph,_=episode(fixture(specification,early=True),'late-DFS-record')
        check('DFS final proof deepcopy expiry withdraws every primary flag',late_result['status']=='unknown_search_budget'
            and late_result['first_checked_proof'] is None and late_result['logical_target_proof_accepted'] is False
            and late_result['actual_selected_target_proof_accepted'] is False
            and late_result['proof_observer']['final_return_primary_accepted'] is False
            and late_result['root_restored'] is True and not late_graph.excluded)
        clock_tests.append('actual DFS final return with explicitly synthetic time/copy proxy after proof event/rollback')
    finally:
        observer_module.time=old_observer_time;dfs_module.time=old_dfs_time;dfs_module.copy=old_copy
    for guard in guards:guard()
    check('all controls final real aggregate deadline',time.perf_counter()<deadline)
    result=dict(schema=VERSION,completed=True,all_controls_passed=True,checks=checks,check_count=len(checks),
        whole_mechanical_episodes=episodes,raw_code_guard_calls=sum(g.calls for g in guards),
        injected_real_GroundChecker=True,actual_observer_and_DFS_source_functions_exercised=True,
        graph_wire_overlay_disabled_controller_are_explicit_test_doubles=True,
        final_boundary_time_double_scopes=clock_tests,fixture_scope='unrelated nullary predicate FOL+literal row point model',
        borrowed_profile_identifier_only_no_fresh_AST_or_q=True,
        fresh_target_proof_discovered=False,static_or_full24_native_trajectory_inventory_RL_accepted=False,
        seconds=time.perf_counter()-began)
    if time.perf_counter()>=deadline:raise TimeoutError('final controls metadata expiry; no accepted prefix')
    return result
