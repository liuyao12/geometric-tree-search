"""SOURCE passive original-Gamma target observer; no dispatcher or supplied proof.

The cold current caller independently binds source/code/MRO/property and exact
reader/wire/checker/closed/graph objects. Every setup/observation is charged by
DFS's existing deadline. Returned proposed proof patches are never selected
state/full24/native/trajectory authority. No project import or author execution.
"""
import gzip
import hashlib
import json
import time
import types
from pathlib import Path

VERSION = 'passive-first-checked-original-Gamma-target-observer-v2'
PROFILE = 'hilbert-first-checked-equality-cohort-static-v1'
RECIPIENT_IDS = ('fresh-inc-point-chain-w', 'fresh-inc-reversed-line-chain')
HEIGHT = 24
RULES = ('axiom', 'instantiate', 'eq_subst', 'mp', 'assumption')

class ProofObservationBudgetExceeded(TimeoutError):
    pass

def clock(deadline):
    if time.perf_counter() >= deadline:
        raise ProofObservationBudgetExceeded('unfinished proof observation; no accepted prefix')

def need(condition, message):
    if not condition:
        raise ValueError(message)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def digest(value):
    return hashlib.sha256(canonical(value).encode('utf8')).hexdigest()

def clone(value):
    return json.loads(canonical(value))

def selected_key(value):
    need(type(value) is list and len(value) == 3 and type(value[0]) is int and value[0] >= 0
         and type(value[1]) is int and 0 <= value[1] < HEIGHT and type(value[2]) is list
         and all(type(r) is int and 0 <= r < value[1] for r in value[2]), 'exact full selected key')
    return value[0], value[1], tuple(value[2])

def literal_state(keys, records, *, fixed=()):
    """Grouped assignment list differs from miner's assignment/count maps."""
    totals = [0] * HEIGHT; assignments = []
    for entry in fixed:
        need(type(entry) is list and len(entry) == 3 and all(type(v) is int for v in entry), 'exact fixed marking')
        assignments.append(tuple(entry))
    for value in keys:
        index, row, refs = selected_key(value); record = records[index]
        need(totals[row] == 0 and len(refs) == len(record['inputs']), 'unit support and whole ordered ports')
        totals[row] = 1
        local = [(1, row, record['output'])]
        for port in range(len(refs)):
            assignment = (1, refs[port], record['inputs'][port])
            need(all(old[:2] != assignment[:2] or old[2] == assignment[2] for old in local),
                 'incompatible same-reference codes cannot alias')
            if assignment not in local:
                local.append(assignment)
            local.append((2 + port, row, refs[port] - row))
        need(all(all(type(v) is int for v in a) for a in local), 'exact integer assigned m including zero')
        assignments.extend(local)
    grouped = []
    for point in sorted({a[:2] for a in assignments}):
        values = [a[2] for a in assignments if a[:2] == point]
        need(all(v == values[0] for v in values), 'entire literal remote marking agreement')
        grouped.append([*point, values[0], len(values)])
    return dict(totals=totals, t=[[0, r, n] for r, n in enumerate(totals) if n],
                m=[[x, y, v] for x, y, v, count in grouped], marks=grouped)

def ancestry(root,selected,records,*,deadline):
    """None means actual dependency missing, including distant reads."""
    visited=set();pending=[root]
    while pending:
        clock(deadline);row=pending.pop()
        if row in visited:continue
        key=selected.get(row)
        if key is None:return None
        index,actual,refs=key;record=records[index]
        need(actual==row and len(refs)==len(record['inputs']),'all exact ordered selected ports')
        visited.add(row)
        for ref,code in zip(refs,record['inputs']):
            source=selected.get(ref)
            if source is None or ref>=row or records[source[0]]['output']!=code:return None
            pending.append(ref)
    return sorted(visited)

def proof_patch(root,rows,selected,records,header,checker_class,*,deadline):
    """Reconstruct source commands; reported proposal commands have no authority."""
    clock(deadline)
    gamma=header['context']['ordered_local_premises'];theory=header['context']['theory']
    # Every original indexed hypothesis occurrence remains present, including
    # repeated equal formulas and unused occurrences (ordinary weakening).
    all_rows=sorted(set(rows)|{0,1,2});indices={};commands=[];keys=[]
    for row in all_rows:
        clock(deadline);index,actual,refs=selected[row];record=records[index]
        command=clone(record['witness'])
        if row<3:
            need(index==header['assumption_recipe_indices'][row] and not refs
                 and record['rule']=='assumption' and command['index']==row
                 and command['formula']==gamma[row],'original indexed Gamma identity')
        elif record['rule']=='mp':
            need(all(ref in indices for ref in refs),'all strictly prior expanded proof dependencies')
            command.update(antecedent=indices[refs[0]],implication=indices[refs[1]])
        elif record['rule']=='assumption':
            occurrence=command['index']
            need(type(occurrence) is int and 0<=occurrence<len(gamma)
                 and command['formula']==gamma[occurrence],'additional placement uses original indexed hypothesis only')
        commands.append(command);indices[row]=len(commands)-1
        keys.append([index,actual,list(refs)])
    need(root==all_rows[-1],'last row is actual conclusion; original hypotheses precede it')
    conclusion=records[selected[root][0]]['witness']['formula']
    started=time.perf_counter();checked=checker_class(theory).proof(commands,gamma,conclusion)
    kernel_seconds=time.perf_counter()-started
    need(checked['original_ground_sequent_accepted'] is True
         and checked['native_accepted'] is False and checked['rows']==len(commands),
         'independent actual original-Gamma proof check')
    started=time.perf_counter()
    points=literal_state(keys,records,fixed=header['boundary']['fixed_exterior_m']+
                                             header['boundary']['fixed_target_m'])
    point_seconds=time.perf_counter()-started;clock(deadline)
    return dict(conclusion_row=root,primitive_keys=keys,commands=commands,
        exact_original_ordered_gamma=clone(gamma),conclusion=clone(conclusion),
        original_Gamma_target_sequent_accepted=conclusion==header['target'],
        kernel_result=checked,literal_points=points,
        consumed_original_occurrence_indices=sorted({records[selected[row][0]]['witness']['index']
            for row in rows if records[selected[row][0]]['rule']=='assumption'}),
        kernel_seconds=kernel_seconds,literal_point_seconds=point_seconds,
        full24_board_accepted=False,native_accepted=False,full_trajectory_accepted=False)

def endpoint_method_state(endpoint):
    """Seal effective callable lookup, including ordinary instance shadows.

    The cold caller covers raw module/class/MRO/default/closure/property code.
    This additionally covers internally constructed wire lookups before the
    first recipe cache exists, and recursive reader/closed/graph method calls.
    No bound instance may override any ordinary method from its exact MRO.
    """
    state=[]; seen=set(); namespace=getattr(endpoint, '__dict__', {})
    for owner in type(endpoint).__mro__:
        for name, descriptor in sorted(vars(owner).items()):
            if name in seen or name.startswith('__'):
                continue
            seen.add(name)
            if isinstance(descriptor, (staticmethod, classmethod)):
                function=descriptor.__func__
            elif isinstance(descriptor, types.FunctionType):
                function=descriptor
            else:
                continue
            need(name not in namespace, 'no instance-shadowed endpoint method: '+name)
            effective=getattr(endpoint, name)
            if isinstance(descriptor, staticmethod):
                need(effective is function, 'exact effective static endpoint: '+name)
            else:
                expected_self=type(endpoint) if isinstance(descriptor, classmethod) else endpoint
                need(isinstance(effective, types.MethodType)
                     and effective.__self__ is expected_self
                     and effective.__func__ is function,
                     'exact effective bound endpoint: '+name)
            state.append((name, owner, descriptor, function, function.__code__))
    return tuple(state)

class FirstCheckedProofObserver:
    """A passive endpoint; it neither ranks nor places/excludes any candidate.

    source_guard is the exact current cold-worker closure. It must authenticate
    all injected module/class/MRO/property/code/default/closure/instance roots,
    including actual type(graph.catalog), before and after this observer.
    The q/whole static authority must already have been admitted independently.
    """
    __slots__ = ('graph','reader','wire','checker_class','closed','header','license_pin',
                 'source_guard','_anchors','_method_anchors','_header_text','_records','_records_identity',
                 '_licenses','_initial_keys','_binding','metrics','observations','construction','_sealed')

    def __setattr__(self, name, value):
        if getattr(self, '_sealed', False):
            raise ValueError('sealed observer endpoints/state attributes cannot be rebound')
        object.__setattr__(self, name, value)

    def __init__(self, graph, *, reader, wire, checker_class, closed, header,
                 license_pin, source_guard, deadline):
        self._sealed=False
        started = time.perf_counter(); clock(deadline); source_guard()
        need(callable(source_guard) and isinstance(checker_class, type)
             and wire is None and type(closed) is reader.ClosedInputs,
             'exact bound endpoints; independent wire construction charged inside search')
        closed_methods=endpoint_method_state(closed)
        graph_methods=endpoint_method_state(graph)
        wire = reader.SelectedWire(header)
        wire_methods=endpoint_method_state(wire)
        clock(deadline)
        need(type(wire) is reader.SelectedWire, 'exact fresh internally constructed wire endpoint')
        need(header['instance_id'] in RECIPIENT_IDS and header['height'] == HEIGHT
             and graph.height == HEIGHT and header['bodies'] == []
             and header['complete_cluster_inventory'] == [],
             'exact fresh qualified empty-body24 context')
        need(canonical(wire.header) == canonical(header)
             and canonical(graph.catalog.header) == canonical(header)
             and len(header['context']['ordered_local_premises']) == 3,
             'same entire admitted header and indexed original Gamma')
        self.graph = graph; self.reader = reader; self.wire = wire
        self.checker_class = checker_class; self.closed = closed
        self.header = clone(header); self.license_pin = clone(license_pin)
        self.source_guard = source_guard
        self._anchors = (graph, reader, wire, checker_class, closed, source_guard,
                         type(graph), type(graph.catalog), type(wire), type(closed))
        self._method_anchors=((graph,graph_methods),(wire,wire_methods),(closed,closed_methods))
        self._header_text = canonical(header)
        self._records = {}; self._records_identity = self._records
        # Whole admitted licence census, without turning a selected subset into
        # full licensing authority. Keep compact immutable selected-match tuples.
        reader.licenses(closed, license_pin, wire, {})
        rows = []
        with gzip.open(closed.absolute(license_pin)['path'], 'rb') as stream:
            for line in stream:
                clock(deadline); value = reader.parse(line)
                need(value['recipe_index'] == len(rows), 'complete ordered licence index')
                rows.append((value['recipe_index'], value['recipe_id'],
                             value['rule'], value['record_sha256']))
        need(len(rows) == wire.count, 'complete current licencing census')
        self._licenses = tuple(rows)
        self._initial_keys = tuple(tuple([key.recipe, key.row, tuple(key.refs)])
                                   for key in graph.initial_selected)
        need(sorted(row for index,row,refs in self._initial_keys) == [0,1,2],
             'all three original indexed seed placements')
        self._binding = (graph.model_epoch, graph.catalog_identity_sha,
                         graph.runtime_authority_sha)
        self.metrics = dict(observation_calls=0, selected_origins_scanned=0,
            proposals_scanned=0, target_ancestries_checked=0,
            logical_and_point_check_seconds=0.0, complete_licence_count=len(rows))
        self.observations = []
        self._guard(deadline)
        self.construction = dict(version=VERSION, completed=True,
            whole_licences_checked=len(rows), seconds=time.perf_counter()-started,
            target_is_endpoint_only=True, ranking_placement_pruning_mutations=0,
            acceptance_scope='original-Gamma logical/finite point patch; no full24/native/trajectory')
        self._sealed=True
        clock(deadline)

    def _guard(self, deadline):
        clock(deadline)
        need(all(value is anchor for value,anchor in zip(
              (self.graph,self.reader,self.wire,self.checker_class,self.closed,self.source_guard,
               type(self.graph),type(self.graph.catalog),type(self.wire),type(self.closed)),self._anchors))
             and self._records is self._records_identity,
             'fixed original injected object/type endpoints')
        for endpoint,methods in self._method_anchors:
            need(endpoint_method_state(endpoint)==methods, 'unchanged effective endpoint method lookup/code')
        self.source_guard(); self.graph.assert_runtime_integrity()
        need(canonical(self.header) == self._header_text
             and canonical(self.wire.header) == self._header_text
             and canonical(self.graph.catalog.header) == self._header_text
             and (self.graph.model_epoch,self.graph.catalog_identity_sha,
                  self.graph.runtime_authority_sha) == self._binding,
             'unchanged complete context/model/runtime binding')
        for index,text in self._records.items():
            need(text == canonical(self.wire.recipe(index)), 'static cache still equals exact bound wire record')
        self.closed.close(); clock(deadline)

    def _recipe(self, index, deadline):
        clock(deadline)
        need(type(index) is int and 0 <= index < self.wire.count, 'complete exact recipe index')
        if index not in self._records:
            record = self.wire.recipe(index)
            need(record['index'] == index and record['rule'] in RULES
                 and len(record['inputs']) == len(record['premises'])
                 and len(record['inputs']) == (2 if record['rule'] == 'mp' else 0),
                 'complete current primitive recipe witness and ordered ports')
            need((index,record['id'],record['rule'],record['record_sha256']) == self._licenses[index],
                 'actual selected/proposed recipe matches complete admitted licence')
            self._records[index] = canonical(record)
        return json.loads(self._records[index])

    def _state(self, deadline):
        clock(deadline); state = self.graph.semantic_state()
        need(state['schema'] == 'compact-complete-dynamic-point-state-v2'
             and (state['model_epoch'],state['catalog_identity_sha256'],
                  state['runtime_authority_sha256']) == self._binding,
             'whole actual current point state')
        selected = {}; records = {}
        for value in state['order']:
            clock(deadline); index,row,refs = selected_key(value)
            need(row not in selected, 'distinct actual row placement identity')
            records[index] = self._recipe(index,deadline); selected[row] = (index,row,refs)
        need(all(selected.get(row) == (index,row,refs) for index,row,refs in self._initial_keys),
             'original indexed Gamma placements unchanged')
        fixed = self.header['boundary']['fixed_exterior_m']+self.header['boundary']['fixed_target_m']
        literal = literal_state(state['order'],records,fixed=fixed)
        need(literal['totals'] == state['totals'] and literal['marks'] == state['marks'],
             'all actual occupancy and remote assigned values/reference counts')
        clock(deadline); return state,selected,records

    def _candidate(self, root, selected, records, actual, deadline):
        rows = ancestry(root,selected,records,deadline=deadline)
        if rows is None:
            return None, 'pending_dependency_reader'
        if records[selected[root][0]]['witness']['formula'] != self.header['target'] or root < 3:
            return None, 'dependency_complete_nontarget'
        started=time.perf_counter()
        patch=proof_patch(root,rows,selected,records,self.header,self.checker_class,deadline=deadline)
        need(patch['original_Gamma_target_sequent_accepted'] is True,
             'independently checked exact original declared target')
        self.metrics['target_ancestries_checked'] += 1
        # Shared placements are identified by full key; never add their t twice.
        points=None; union_rejection=None
        try:
            union = dict(actual)
            for row,key in selected.items():
                need(row not in union or union[row] == key, 'proposal/selected full placement identity conflict')
                union[row] = key
            all_records = dict(records)
            for index,row,refs in union.values():all_records[index]=self._recipe(index,deadline)
            keys=[[index,row,list(refs)] for index,row,refs in sorted(union.values(),key=lambda k:k[1])]
            points=literal_state(keys,all_records,fixed=self.header['boundary']['fixed_exterior_m']+
                                                     self.header['boundary']['fixed_target_m'])
        except ValueError as exc:
            union_rejection=str(exc)[:512]
        # A separately checked logical/finite target ancestry remains a proof.
        # Failed larger unions never become actual selection or macro authority.
        clock(deadline); elapsed=time.perf_counter()-started
        self.metrics['logical_and_point_check_seconds'] += elapsed
        return dict(patch=patch,primary_endpoint_eligible=points is not None,
                    prospective_current_point_union=points,
                    prospective_current_point_union_accepted=points is not None,
                    prospective_current_point_union_rejection=union_rejection,
                    shared_placements_counted_once=True,check_seconds=elapsed), 'checked_original_Gamma_target_patch'

    def observe(self, decision, *, origin_kind, completed_selection=None, source_link, deadline):
        """Observe all actual origins or every retained completed proposal in order.

        Only branch/complete states after global dead/forced closure are observed.
        Proposal root/keys are selectors, not proof authority. Commands and flags
        are rebuilt from exact licensed primitives. Incomplete adviser calls are
        never passed here. No graph mutation; all data/guards charged to deadline.
        """
        started=time.perf_counter(); self._guard(deadline)
        need(origin_kind in ('actual_selected','completed_source_proposal')
             and decision == self.graph.decision() and decision.kind in ('branch','complete'),
             'passive endpoint only after mandatory global propagation')
        state,actual,records=self._state(deadline); binding=digest(state)
        census=[]; winner=None
        try:
            if origin_kind == 'actual_selected':
                need(completed_selection is None, 'selected origin does not receive proposal')
                origins=[(row,actual,dict(records)) for row in sorted(actual)]
            else:
                need(type(completed_selection) is dict,
                     'whole successfully completed advice selection required')
                proposals=completed_selection.get('preferred_cluster_proposals',[])
                need(type(proposals) is list and len(proposals)<=64,
                     'entire retained proposal set, no favorable subset')
                origins=[]
                for position,proposal in enumerate(proposals):
                    clock(deadline); chosen={row:(index,row,refs) for index,row,refs in self._initial_keys}
                    local=dict(records)
                    for value in proposal['primitive_keys']:
                        index,row,refs=selected_key(value);record=self._recipe(index,deadline)
                        need(row not in chosen or chosen[row]==(index,row,refs), 'unique proposed full row identity')
                        chosen[row]=(index,row,refs);local[index]=record
                    root=proposal.get('root_row',proposal.get('root_receptor_row'))
                    need(type(root) is int and root in chosen, 'source proposed root present in full keys')
                    origins.append((root,chosen,local))
            for position,(root,chosen,local) in enumerate(origins):
                clock(deadline)
                if origin_kind == 'actual_selected':self.metrics['selected_origins_scanned'] += 1
                else:self.metrics['proposals_scanned'] += 1
                try:
                    checked,reason=self._candidate(root,chosen,local,actual,deadline)
                except ValueError as exc:
                    if origin_kind == 'actual_selected':raise
                    checked=None;reason='rejected_complete_source_proposal: '+str(exc)[:512]
                census.append(dict(origin_index=position,root_row=root,status=reason,
                    standalone_logical_target_artifact=clone(checked) if checked is not None and not checked['primary_endpoint_eligible'] else None,
                    primary_endpoint_eligible=checked is not None and checked['primary_endpoint_eligible']))
                if checked is not None and checked['primary_endpoint_eligible'] and winner is None:
                    winner=dict(schema='first-checked-original-Gamma-target-primitive-patch-v1',
                        origin_kind=origin_kind,instance_id=self.header['instance_id'],
                        source_state_sha256=binding,source_state=clone(state),source_link=clone(source_link),
                        origin_index=position,root_row=root,**checked,
                        original_Gamma_target_sequent_accepted=True,
                        actual_selected_target_accepted=origin_kind=='actual_selected',
                        source_proposal_never_counted_as_selected=origin_kind!='actual_selected',
                        full24_board_accepted=False,native_accepted=False,full_trajectory_accepted=False,
                        universal_compiler_accepted=False,inventory_admitted=False,new_RL_training=False)
            need(digest(self.graph.semantic_state()) == binding and decision == self.graph.decision(),
                 'passive complete observer cannot change scheduler/state/rollback')
        finally:self._guard(deadline)
        clock(deadline)
        self.metrics['observation_calls'] += 1
        receipt=dict(origin_kind=origin_kind,source_state_sha256=binding,source_link=clone(source_link),
            completed=True,all_origins_scanned=len(census),census=census,
            accepted_target_found=winner is not None,seconds=time.perf_counter()-started)
        self.observations.append(receipt)
        try:
            clock(deadline)
        except ProofObservationBudgetExceeded:
            # Metadata has been stored, but this incomplete call grants no
            # completed observation or primary certificate to its caller.
            receipt.update(completed=False,accepted_target_found=False,
                           primary_certificate_withheld_on_final_deadline=True)
            raise
        return winner,receipt



def verify_returned_proof(result):
    """Metadata-only binding; never a second or uncharged logical proof check.

    The guarded owned worker supplies its whole actual newly returned result.
    Mathematical authority is the timed observer's injected GroundChecker and
    literal target-ancestry check, not these producer flags in arbitrary JSON.
    """
    need(type(result) is dict and result['schema']=='compact24-first-checked-proof-scientific-DFS-v11-source'
         and result['mode'] in ('base','seed_forward') and result['seed'] is None
         and result['rng_draws']==result['policy_choices']==result['commits']==[]
         and result['training_updates']==result['all_source_body_count']==result['registered_whole_descriptor_count']==0,
         'whole fresh guarded deterministic result and empty inventory')
    proof=result['first_checked_proof']
    if result['status']!='first_checked_original_Gamma_target_proof':
        need(proof is None and result['logical_target_proof_accepted'] is False,
             'UNKNOWN/full24 result never relabelled as first proof')
        return None
    need(type(proof) is dict and proof['schema']=='first-checked-original-Gamma-target-primitive-patch-v1'
         and proof['origin_kind'] in ('actual_selected','completed_source_proposal')
         and result['logical_target_proof_accepted'] is True and result['root_restored'] is True
         and result['trace_complete'] is True and result['point_certificate'] is None
         and proof['primary_endpoint_eligible'] is True
         and proof['prospective_current_point_union_accepted'] is True
         and type(proof['prospective_current_point_union']) is dict,
         'complete deliberately stopped logical proof scope, exact rollback, not full24')
    need(digest(proof['source_state'])==proof['source_state_sha256']
         and result['graph_states'].get(proof['source_state_sha256'])==proof['source_state'],
         'whole retained actual preobserver state binding')
    links=[event for event in result['events'] if event['kind']=='first_checked_logical_proof'
           and event['proof_sha256']==digest(proof) and event['origin_kind']==proof['origin_kind']
           and event['source_link']==proof['source_link']]
    need(len(links)==1 and links[0]['state']['overlay']['controller']['graph_state_sha256']==proof['source_state_sha256'],
         'unique complete recorded timed proof observation event')
    patch=proof['patch'];need(proof['original_Gamma_target_sequent_accepted'] is True
         and patch['original_Gamma_target_sequent_accepted'] is True
         and patch['kernel_result']['original_ground_sequent_accepted'] is True
         and patch['kernel_result']['native_accepted'] is False
         and len(patch['commands'])==patch['kernel_result']['rows'],
         'timed checker receipt and exact original Gamma patch retained')
    selected=proof['origin_kind']=='actual_selected'
    need(proof['actual_selected_target_accepted'] is selected
         and proof['source_proposal_never_counted_as_selected'] is (not selected)
         and result['actual_selected_target_proof_accepted'] is selected,
         'proposed versus actually selected provenance never conflated')
    if selected:
        need(all(key in proof['source_state']['order'] for key in patch['primitive_keys']),
             'actual selected checked patch keys all present in linked state')
    need(all(proof[k] is False for k in ('full24_board_accepted','native_accepted','full_trajectory_accepted',
         'universal_compiler_accepted','inventory_admitted','new_RL_training')),
         'no full board/native/trajectory/library/RL authority')
    return clone(proof)
