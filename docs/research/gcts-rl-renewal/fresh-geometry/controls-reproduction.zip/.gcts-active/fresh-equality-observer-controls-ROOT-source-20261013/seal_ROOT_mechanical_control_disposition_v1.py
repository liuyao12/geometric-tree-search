"""ROOT saved-resource/result metadata disposition; no proof or control replay."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROGRESS=ROOT/'.gcts-active/fresh-equality-observer-controls-progress-v3-20261013'
PEER=ROOT/'.gcts-active/hilbert-incidence-priority-review-20261013'

def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    assert path.resolve()==path
    raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def check(record):
    actual=pin(record['path']);assert actual['sha256']==record['sha256'] and actual['bytes']==record['bytes']
    return actual

def read(path):return json.loads(Path(path).read_bytes())

def main():
    leaf_path=PROGRESS/'controls-worker-plan-v1.json';leaf=read(leaf_path)
    assert pin(leaf_path)['sha256']=='804d16487a403128debe7352c3289805131a86c852022fe65d9ee0dfa2c353a5'
    decision_path=PROGRESS/'replay-ROOT-final-decision-v1.json';decision=read(decision_path)
    assert decision['ROOT_final_accepted'] is True and len(decision['predicates'])==14 and all(v is True for v in decision['predicates'].values())
    for key in ('plan','actual_tool','owner','post_write','worker'):check(decision[key])
    worker_path=PROGRESS/'replay-result-v1/worker-receipt-v1.json';worker=read(worker_path)
    assert check(decision['worker'])==pin(worker_path)
    assert worker['stage_completed'] is True and worker['all_controls_passed'] is True
    assert worker['scope']=='synthetic-observer-semantics-only' and worker['fresh_target_proof_discovered'] is False
    assert worker['mathematical_proofs_accepted']==0 and worker['target_searches']==0 and worker['new_RL_training'] is False
    assert worker['sources']==leaf['sources'] and check(worker['plan'])==pin(leaf_path)
    result_pin=check(worker['result']);result=read(result_pin['path'])
    assert result_pin['sha256']=='c14c25aed408464f35430a88474212f56dbfc36e8c738804e9a0fa0ef5b119cd'
    assert result['completed'] is True and result['all_controls_passed'] is True
    assert result['check_count']==len(result['checks'])==45 and all(c['passed'] is True for c in result['checks'])
    assert result['fresh_target_proof_discovered'] is False and result['static_or_full24_native_trajectory_inventory_RL_accepted'] is False
    evidence_pin=check(worker['evidence']);evidence=read(evidence_pin['path'])
    assert evidence['result']==result_pin and evidence['sources']==leaf['sources'] and evidence['scope']==worker['scope']
    assert evidence['control_call_seconds']<leaf['limits']['control_seconds']
    for record in leaf['closure']:check(record)
    source_review=read(leaf['reviews']['independent']['path']);check(leaf['reviews']['independent'])
    assert source_review['source_review_passed'] is True and source_review['sources']==leaf['sources']
    preactivation_pin=pin(PEER/'fresh-observer-controls-v3-preactivation-metadata-findings-v1.json')
    assert preactivation_pin['sha256']=='eb07b0c05483cfef583c5b63822f62f60b190923ae11418b12ca4f5bb6efe87d'
    preactivation=read(preactivation_pin['path'])
    assert preactivation['all_checks_passed'] is True and preactivation['scientific_calls']==0
    mechanism={r:leaf['sources'][r] for r in ('proof_observer','streamed_dfs','certificate')}
    assert worker['mechanism_sources']==mechanism
    value=dict(schema='ROOT-first-checked-proof-observer-conformance-disposition-v1',
        ROOT_final_accepted=True,all_controls_passed=True,scope='synthetic-observer-semantics-only',
        fresh_target_proof_discovered=False,sources=mechanism,result=result_pin,
        author_identity='/root',scientific_calls_in_this_metadata_seal=0,
        actual_once_only_control_attempts=1,restarts=0,checks=result['checks'],check_count=45,
        raw_guard_calls=result['raw_code_guard_calls'],control_call_seconds=evidence['control_call_seconds'],
        caller_elapsed_seconds=decision['caller_elapsed_seconds'],limits=leaf['limits'],
        resource_disposition=pin(decision_path),worker_receipt=pin(worker_path),evidence=evidence_pin,
        preactivation_review=preactivation_pin,independent_SOURCE_review=leaf['reviews']['independent'],
        ROOT_SOURCE_review=leaf['reviews']['ROOT'],provenance=pin(__file__),
        actual_runtime_source_functions_exercised=['proof_observer','streamed_dfs','logical_oracle'],
        certificate_source_authenticated_but_not_executed=True,
        production_q_G5_wire_scheduler_and_catalogue_qualified=False,
        synthetic_delay_hooks_are_not_production_clock_qualification=True,
        fresh_target_searches=0,fresh_target_proofs_discovered=0,full24_accepted=False,
        native_accepted=False,full_trajectory_accepted=False,inventory_admitted=False,new_RL_training=False,
        research_program_complete=False,
        assessment='All45 actual mechanical checks and all14 owned/caller resource predicates passed on the once-only run. The observer, DFS and independent logical checker were exercised on explicit unrelated test doubles. This admits only generic mechanical semantics for the exact three named source pins. Production catalogue/graph integration, adviser, fresh target searches and proofs remain separate.')
    destination=HERE/'ROOT-first-checked-proof-observer-conformance-disposition-v1.json'
    with destination.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(dict(disposition=pin(destination),accepted=True,actual_mechanical_checks=45,resource_checks=14,fresh_target_searches=0,scientific_calls_in_seal=0)))

if __name__=='__main__':main()
