"""ROOT prospective raw SOURCE review and metadata plans; no scientific imports."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / '.gcts-active/fresh-equality-observer-controls-source-20261013'
PEER = ROOT / '.gcts-active/hilbert-incidence-priority-review-20261013'
PROGRESS = ROOT / '.gcts-active/fresh-equality-observer-controls-progress-v3-20261013'
PYTHON = Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9')
LIMITS = dict(whole_seconds=60, peak_bytes=536870912, caller_seconds=90, control_seconds=20)

def pin(path, relative=False):
    path = Path(path)
    if not path.is_absolute(): path = ROOT / path
    assert path.resolve() == path
    before = path.stat(); raw = path.read_bytes(); after = path.stat()
    assert (before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size) == (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size)
    name = str(path.relative_to(ROOT)) if relative and ROOT in path.parents else str(path)
    return dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def verify(record):
    current = pin(record['path'])
    assert current['sha256'] == record['sha256'] and current['bytes'] == record['bytes'], record['path']
    return current

def read(path): return json.loads(Path(path).read_bytes())

def collect(value, records):
    if isinstance(value,dict):
        if set(value) == {'path','sha256','bytes'}:
            record = verify(value)
            if record['path'] in records:
                assert record == records[record['path']]
                return
            records[record['path']] = record
            # Declared current source-review pins are atomic; do not decode historical ancestor records.
        else:
            for child in value.values(): collect(child,records)
    elif isinstance(value,list):
        for child in value: collect(child,records)

def save(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    return pin(path)

def main():
    assert not PROGRESS.exists(), 'fresh immutable ROOT namespace'
    handoff_pin = pin(SOURCE/'handoff-v3.json')
    assert handoff_pin['sha256']=='9d0ef0f9c6c8df346147cb699dad849a24fc3b2e460d32bab4baac76371ccbb2'
    handoff = read(handoff_pin['path'])
    peer_pin = pin(PEER/'fresh-observer-mechanical-controls-source-findings-v3.json')
    assert peer_pin['sha256']=='9b5e60c2f9fea6f03be30190c302b63b9d3c21217d7438dec7bba7263a40c60b'
    peer = read(peer_pin['path'])
    assert peer['source_only'] is True and peer['source_review_passed'] is True and peer['scientific_calls']==0
    assert peer['sources']==handoff['sources'] and peer['concrete_blockers']==[]
    assert peer['author_identity']=='/root/hilbert_ordering_diagnosis' and peer['reviewer_identity']=='/root/hilbert_advice_controls'
    assert handoff['limits']==LIMITS and handoff['actual_controls_run'] is False
    runtime_review_pin=pin(PEER/'fresh-first-proof-runtime-source-findings-v4.json')
    assert runtime_review_pin['sha256']=='81bfb1f2d5ca43461caefb68ebe43dc73c50a5cafc8c4816e0ba90b28db572ac'
    runtime_review=read(runtime_review_pin['path'])
    assert runtime_review['source_review_passed'] is True and runtime_review['scientific_calls']==0
    runtime=read(ROOT/'.gcts-active/hilbert-next-owned-progress-20261013/ROOT-source-review-v1.json')['runtime']
    assert verify(runtime['executable'])==pin(PYTHON)
    records={}
    collect(handoff,records)
    collect(peer,records)
    collect(runtime_review,records)
    for record in [handoff_pin,peer_pin,runtime_review_pin]+list(runtime.values()):
        if isinstance(record,dict) and set(record)=={'path','sha256','bytes'}:collect(record,records)
    collect(pin(ROOT/'AGENTS.md'),records)
    collect(pin(__file__),records)
    PROGRESS.mkdir()
    for key,name in [('generic_owner','run_owned_bridge_v2.py'),('generic_closer','close_stage_decision_v1.py')]:
        source=verify(handoff[key]);destination=PROGRESS/name
        with destination.open('xb') as stream:stream.write(Path(source['path']).read_bytes())
        current=pin(destination)
        assert current['sha256']==source['sha256'] and current['bytes']==source['bytes']
        collect(current,records)
    root_review=dict(schema='ROOT-first-checked-proof-mechanical-controls-source-review-v1',
        source_only=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,
        author_identity=peer['author_identity'],reviewer_identity='/root',sources=handoff['sources'],
        specification=handoff['specification'],independent_review=peer_pin,
        current_runtime_source_review=runtime_review_pin,runtime=runtime,
        owner_source=pin(PROGRESS/'run_owned_bridge_v2.py'),closer_source=pin(PROGRESS/'close_stage_decision_v1.py'),
        provenance=pin(__file__),limits=LIMITS,
        ROOT_assessment='ROOT read the whole current cold worker and unchanged flat owner/closer. Independent whole-harness review and exact source-delta evidence bind all seven roles. Current observer5/DFSv11/helper3 pins, empty-first-cache mutation control, cold own/nested guards, literal argv, real20s controls and 60s/512MiB/caller90 reserves are prospective. No project function, control or theorem search is executed by this metadata constructor.',
        scope='Conditional generic mechanical conformance SOURCE only, on explicitly unrelated synthetic doubles. No production catalogue, q, G5, dynamic search or fresh target proof qualification.')
    root_review_pin=save(PROGRESS/'ROOT-source-review-v1.json',root_review)
    collect(root_review_pin,records)
    leaf_path=PROGRESS/'controls-worker-plan-v1.json'
    owner_path=PROGRESS/'replay-plan-v1.json'
    output=PROGRESS/'replay-result-v1'
    leaf=dict(schema='ROOT-first-checked-proof-mechanical-controls-worker-plan-v1',ROOT_owned_once_only=True,
        sources=handoff['sources'],runtime=dict(binary=pin(PYTHON)),
        reviews=dict(ROOT=root_review_pin,independent=peer_pin),closure=list(sorted(records.values(),key=lambda x:x['path'])),
        limits=LIMITS,output_directory=str(output),owner_plan_path=str(owner_path),specification=handoff['specification'])
    assert len(leaf)==10
    needed=list(leaf['sources'].values())+[leaf['runtime']['binary'],leaf['specification']]+list(leaf['reviews'].values())
    assert all(verify(record)['path'] in records and records[verify(record)['path']]==verify(record) for record in needed)
    leaf_pin=save(leaf_path,leaf)
    collect(leaf_pin,records)
    owner=dict(schema='ROOT-guard-native-owned-plan-v1',stage='replay',
        worker=str(Path(handoff['sources']['worker']['path']).relative_to(ROOT)),
        argv=[str(PYTHON),'-B',handoff['sources']['worker']['path'],str(leaf_path),str(owner_path)],
        worker_receipt=str((output/'worker-receipt-v1.json').relative_to(ROOT)),limits=LIMITS,
        runtime_binary=pin(PYTHON,True),ROOT_source_review=pin(PROGRESS/'ROOT-source-review-v1.json',True),
        scope='Once-only whole unrelated mechanical observer/DFS controls; no current scientific target, production q or G5.',
        closure=[pin(r['path'],True) for r in sorted(records.values(),key=lambda x:x['path'])])
    assert len(owner)==10
    owner_pin=save(owner_path,owner)
    save(HERE/'ROOT-plan-construction-v3.json',dict(schema='ROOT-first-checked-proof-mechanical-control-plan-construction-v3',
        source_only=True,scientific_calls=0,handoff=handoff_pin,independent_source_review=peer_pin,
        ROOT_source_review=root_review_pin,leaf=leaf_pin,owner=owner_pin,raw_closure_files=len(records),
        execution_attempts=0,progress_namespace=str(PROGRESS),scope=root_review['scope']))
    print(json.dumps(dict(scientific_calls=0,leaf=leaf_pin,owner=owner_pin,raw_closure_files=len(records))))

if __name__=='__main__':main()
