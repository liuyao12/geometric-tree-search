"""ROOT saved metadata to public HTML addendum; no search or control replay."""
import hashlib
import html
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROGRESS=ROOT/'.gcts-active/fresh-equality-observer-controls-progress-v3-20261013'
PUB=Path('/private/tmp/gcts-family-router-publish-20261010')
PUBLIC='docs/research/gcts-rl-renewal/fresh-geometry'

def pin(path):
    path=Path(path);raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def check(record):
    path=Path(record['path']);path=path if path.is_absolute() else ROOT/path
    actual=pin(path);assert actual['sha256']==record['sha256'] and actual['bytes']==record['bytes']
    return path

def read(path):return json.loads(Path(path).read_bytes())

def write(path,raw):
    with Path(path).open('xb') as stream:stream.write(raw)

def main():
    disposition_path=HERE/'ROOT-first-checked-proof-observer-conformance-disposition-v1.json'
    disposition=read(disposition_path)
    assert pin(disposition_path)['sha256']=='4eeabbf9579b636e85d72e391698f83b9c610e14ec7b4f33b5a8aae72237dab1'
    assert disposition['ROOT_final_accepted'] is True and disposition['check_count']==45
    result_path=check(disposition['result']);result=read(result_path)
    decision_path=check(disposition['resource_disposition']);decision=read(decision_path)
    assert result['all_controls_passed'] is True and all(x['passed'] is True for x in result['checks'])
    assert all(x is True for x in decision['predicates'].values()) and len(decision['predicates'])==14
    review_path=ROOT/'.gcts-active/hilbert-incidence-priority-review-20261013/fresh-observer-controls-actual-saved-metadata-findings-v1.json'
    review=read(review_path)
    assert review['scientific_calls']==0 and review['whole_saved_reconciliation_passed'] is True
    assert review['concrete_mismatches']==[] and check(review['actual_ROOT_disposition'])==disposition_path
    old_reader=PUB/PUBLIC/'reader.html';old_index=PUB/'docs/research/gcts-rl-renewal/index.html'
    assert pin(old_reader)['sha256']=='f1989ccf2904545821eb9fec36c54c6cf817919e26f09855cfdf09f20908b9f9'
    assert pin(old_index)['sha256']=='19da8a8c54932eede20f3481755a250d1963033c0a3a26baefc393b184557da7'
    report=HERE/'public-addendum-v2';report.mkdir()
    copies={'controls-qualification.json':disposition_path,'controls-result.json':result_path,
            'controls-resources.json':decision_path,'controls-independent-review.json':review_path}
    for name,path in copies.items():write(report/name,path.read_bytes())
    owner=read(PROGRESS/'replay-plan-v1.json')
    members={}
    external=[]
    for record in owner['closure']:
        path=check(record)
        if ROOT not in path.parents:
            external.append(record);continue
        members[str(path.relative_to(ROOT))]=path
    for path in list((PROGRESS/'replay-owner-v1').rglob('*'))+list((PROGRESS/'replay-result-v1').rglob('*')):
        if path.is_file():members[str(path.relative_to(ROOT))]=path
    extra=[PROGRESS/'replay-plan-v1.json',PROGRESS/'replay-actual-tool-observations-v1.json',decision_path,
           disposition_path,review_path,HERE/'seal_ROOT_mechanical_control_disposition_v1.py',Path(__file__)]
    for path in extra:members[str(path.relative_to(ROOT))]=path
    assert all(not name.startswith('.git/') and '.env' not in Path(name).name for name in members)
    archive_records=[]
    with zipfile.ZipFile(report/'controls-reproduction.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
        for name,path in sorted(members.items()):
            archive.write(path,name);archive_records.append(dict(archive_path=name,source=pin(path)))
        archive.writestr('REPRODUCTION.txt','Exact activated generic mechanical control sources, literal plans, and saved output capsules. No target theorem searches, production catalogue/graph qualification or RL result. Official host runtime files are hash-referenced and not redistributed. Paths and output namespaces retain the original host. Reproduction requires fresh namespaces, source/path/runtime rebinding and requalification; never invoke an owner against existing immutable output capsules. Some final-expiry controls use explicitly synthetic hooks. Old negative source reviews and unused metadata drafts remain in the research workspace; this archive contains the declared activated closure and its actual output.\n')
    manifest=dict(schema='ROOT-notebook154-controls-addendum-source-archive-v1',scientific_calls=0,
        scope='Activated generic synthetic observer semantics only',members=archive_records,
        external_runtime_files_not_redistributed=external,archive=pin(report/'controls-reproduction.zip'))
    write(report/'controls-source-archive-manifest.json',(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode())
    post=read(PROGRESS/'replay-owner-v1/post-write-observation-v1.json')
    check_items=''.join('<li>'+html.escape(c['name'])+' — passed.</li>' for c in result['checks'])
    section=r'''<section id="runtime-controls"><h2>The observer’s mechanical controls passed.</h2>
<p>This subsequent measured stage used the actual observer, depth-first search and independent logical checker on an explicitly unrelated toy fixture. All \(45\) checks passed in one run; all \(14\) enclosing resource predicates passed. The new geometry theorem searches remain <strong>UNSEARCHED</strong>.</p>
<p>The tests exercised indexed hypotheses, incomplete dependencies, incompatible proposal unions, assigned zero versus absent markings, altered source and callbacks, scheduling precedence, and exact rollback after a proof stop. Deliberate metadata-delay tests withdrew expired proof flags. Their clock hooks and graph, wire and controller doubles are declared; this is a mechanical test, not a production geometry search or a proof-search performance result.</p>
<table><thead><tr><th>Measured quantity</th><th>Actual</th><th>Declared bound</th></tr></thead><tbody>
<tr><td>Complete controls, return checks and result write</td><td>\(CONTROL_TIME\,\mathrm{s}\)</td><td>\(20\,\mathrm{s}\)</td></tr>
<tr><td>Owned phase, observed after terminal write</td><td>\(OWNER_TIME\,\mathrm{s}\)</td><td>\(60\,\mathrm{s}\)</td></tr>
<tr><td>Tool caller, one awaited clock interval</td><td>\(CALLER_TIME\,\mathrm{s}\)</td><td>\(90\,\mathrm{s}\)</td></tr>
<tr><td>Conservative peak</td><td>\(PEAK_MIB\,\mathrm{MiB}\)</td><td>\(512\,\mathrm{MiB}\)</td></tr>
</tbody></table>
<details><summary>Inspect every actual check</summary><ol>CHECK_ITEMS</ol></details>
<p><a href="controls-qualification.json">ROOT’s mechanical disposition</a> · <a href="controls-result.json">Whole raw result and toy trajectories</a> · <a href="controls-resources.json">All resource predicates</a> · <a href="controls-independent-review.json">Independent saved-evidence review</a> · <a href="controls-reproduction.zip">Activated sources, plans and raw capsules</a> · <a href="controls-source-archive-manifest.json">Archive hashes</a></p>
<p class="muted">The certificate helper was authenticated as a source but not executed in this test. Production catalogue, graph and adviser integration remain separate. The original static qualification summary and archive below retain their own cutoff. No new geometry theorem, complete board, native prover comparison, learned inventory or RL result is accepted here.</p></section>
'''
    for key,value in dict(CONTROL_TIME=f"{disposition['control_call_seconds']:.6f}",
        OWNER_TIME=f"{post['elapsed_seconds']:.6f}",CALLER_TIME=f"{decision['caller_elapsed_seconds']:.3f}",
        PEAK_MIB=f"{post['peak_bytes']/1048576:.2f}",CHECK_ITEMS=check_items).items():section=section.replace(key,value)
    reader=old_reader.read_text()
    before='<li>Runtime controls<span>Observer and search interface being prepared</span></li>'
    assert reader.count(before)==1
    reader=reader.replace(before,'<li class="passed">Generic mechanical controls<span>All 45 checks passed</span></li><li>Production integration<span>Source review being completed</span></li>')
    before='Its source review and actual generic controls are still required before the fresh searches.'
    assert reader.count(before)==1
    reader=reader.replace(before,'Its source review and actual generic mechanical controls have passed. Production graph, catalogue and adviser integration remain separately required before the fresh searches.')
    assert reader.count('<section id="evidence">')==1
    reader=reader.replace('<section id="evidence">',section+'<section id="evidence">')
    write(report/'reader.html',reader.encode())
    index=old_index.read_text()
    before='  <p>The next proof endpoint distinguishes a checked current-compatible proposal from selected ancestry and a completed board. No proof routes or lemma bodies are supplied.</p>'
    assert index.count(before)==1
    paragraph='\n  <p>Subsequent runtime milestone: all \\(45\\) actual generic observer controls and all \\(14\\) resource predicates passed once on unrelated mechanical fixtures. Production integration and fresh theorem searches remain pending. <a href="fresh-geometry/reader.html?v=n154-controls1#runtime-controls">Inspect the controls and exact raw evidence</a>.</p>'
    index=index.replace(before,before+paragraph)
    write(report/'index.html',index.encode())
    changed=[]
    for path in sorted(report.iterdir()):
        destination=PUB/'docs/research/gcts-rl-renewal/index.html' if path.name=='index.html' else PUB/PUBLIC/path.name
        destination.write_bytes(path.read_bytes())
        if path.name!='index.html':(ROOT/PUBLIC/path.name).write_bytes(path.read_bytes())
        changed.append(dict(path=str(destination.relative_to(PUB)),sha256=pin(path)['sha256'],bytes=path.stat().st_size))
    with zipfile.ZipFile(report/'controls-reproduction.zip') as archive:
        assert len(archive.namelist())==len(members)+1
        for item in archive_records:
            raw=archive.read(item['archive_path']);assert len(raw)==item['source']['bytes'] and hashlib.sha256(raw).hexdigest()==item['source']['sha256']
    value=dict(schema='ROOT-notebook154-controls-addendum-task-manifest-v2',scientific_calls=0,
        static_cutoff_data_unchanged=True,activated_archive_members=len(members),external_runtime_files=len(external),
        raw_files_equal_original=True,changed_files=changed,ROOT_index_untouched=True,
        disposition=pin(disposition_path),independent_saved_review=pin(review_path))
    write(HERE/'ROOT-controls-addendum-task-manifest-v2.json',(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps(dict(changed_files=len(changed),archive_project_members=len(members),scientific_calls=0,raw_files_equal_original=True)))

if __name__=='__main__':main()
