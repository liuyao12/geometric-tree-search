"""Independent narrow SOURCE endpoint/AST/raw review, no project execution."""
from pathlib import Path
import ast,builtins,hashlib,json,symtable
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');D=ROOT/'.gcts-active/fresh-equality-first-proof-runtime-source-20261013';O=Path(__file__).resolve().parent
checks=[];refs=[];files={}
def ck(v,n):
 if not v:raise AssertionError(n)
 checks.append(n)
def rd(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def scan(v):
 if type(v) is dict:
  if set(v)=={'path','sha256','bytes'}:
   p=Path(v['path']);p=p if p.is_absolute() else ROOT/p;r=pin(p);ck(type(v['bytes']) is int and r['sha256']==v['sha256'] and r['bytes']==v['bytes'],'exact raw pin '+str(p));refs.append(v);files[str(p)]=r
  for x in v.values():scan(x)
 elif type(v) is list:
  for x in v:scan(x)
def ad(x):return ast.dump(x,include_attributes=False)
def defs(p):return {x.name:x for x in ast.parse(Path(p).read_bytes()).body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
base=rd(O/'fresh-first-proof-runtime-source-findings-v2.json');h=rd(D/'handoff-v4.json');c=rd(D/'source-contract-v4.json')
roots=[D/n for n in ('handoff-v3.json','source-contract-v3.json','effective-endpoint-source-conformance-v1.json','handoff-v4.json','source-contract-v4.json','delegated-validator-source-conformance-v1.json')]
for p in roots:scan(rd(p))
ck(h['sources']==c['sources']==h['generic_control_request']['source_map'],'exact current runtime/controls source3')
ck(h['sources']['certificate']==base['sources']['certificate'] and h['sources']['streamed_dfs']==base['sources']['streamed_dfs'],'reader DFS whole raw bytes unchanged')
ck(c['endpoint_preregistration']==base['endpoint_preregistration'] and c['primary_endpoint']==json.loads(Path(base['contract']['path']).read_text())['primary_endpoint'],'preregistered originalGamma/currentpoint primary remains')
comparisons=[]
for name,added in [('effective-endpoint-source-conformance-v1.json','endpoint_method_state'),('delegated-validator-source-conformance-v1.json','source_guard_state')]:
 x=rd(D/name);a,b=defs(x['prior_source']['path']),defs(x['source']['path']);ck(set(b)-set(a)=={added} and not set(a)-set(b),'one exact new helper '+added)
 changed=[n for n in a if ad(a[n])!=ad(b[n])];ck(changed==['FirstCheckedProofObserver'],'only observer class top change '+added)
 ac={n.name:n for n in a['FirstCheckedProofObserver'].body if isinstance(n,ast.FunctionDef)};bc={n.name:n for n in b['FirstCheckedProofObserver'].body if isinstance(n,ast.FunctionDef)}
 ck(set(ac)==set(bc) and [n for n in ac if ad(ac[n])!=ad(bc[n])]==['__init__','_guard'],'only constructor guard methods '+added)
 comparisons.append(dict(parent=x['prior_source'],source=x['source'],added=added,changed_methods=['__init__','_guard'],unchanged_other_top_definitions=len(a)-1,unchanged_other_class_methods=len(ac)-2))
for role,r in h['sources'].items():
 src=Path(r['path']).read_text();tab=symtable.symtable(src,r['path'],'exec');bound=set(tab.get_identifiers())|set(dir(builtins))|{'__name__','__file__'};missing=[]
 def walk(t):
  for s in t.get_symbols():
   if s.is_referenced() and s.is_global() and s.get_name() not in bound:missing.append((t.get_name(),s.get_name()))
  for ch in t.get_children():walk(ch)
 walk(tab);ck(not missing,'static global references bound '+role)
observer=defs(h['sources']['proof_observer']['path']);cls={n.name:n for n in observer['FirstCheckedProofObserver'].body if isinstance(n,ast.FunctionDef)}
ck('endpoint_method_state' in observer and 'source_guard_state' in observer,'both endpoint helpers present')
for name in ('_recipe','_state','_candidate','observe'):
 old={n.name:n for n in defs(base['sources']['proof_observer']['path'])['FirstCheckedProofObserver'].body if isinstance(n,ast.FunctionDef)}
 ck(ad(cls[name])==ad(old[name]),'all proof/receipt/finalclock method ASTs unchanged '+name)
findings=base['findings']+[dict(name='Effective internally constructed endpoint repair',finding='Observer5 captures graph and ClosedInputs ordinary effective MRO method lookups before independent wire construction and wire methods before first licence/recipe use. It rejects ordinary instance shadows and authenticates exact receiver, defining descriptor, function and code identities at every guard. All SelectedWire methods including expand/formula_node/formula/recipe are covered. Generated catalogue MRO/property/default/closure/raw code remains captured by the reviewed cold caller; no mutable current graph state is frozen.'),dict(name='Delegated callback repair',finding='Before the first source_guard invocation, observer5 captures actual function/code/default object/keyword-default object/closure-content object identities. It directly rechecks this state after the initial call and before/after every later invocation. Same callback object with changed code cannot simply no-op the delegated snapshot. Explicit mechanical callable guards anchor their effective bound __call__ function; the production path supplies the exact admitted nested function. This does not grant authority to an arbitrary injected guard or co_filename.'),dict(name='Preserved negative evidence and scope',finding='Original runtime timing negatives and old runner instance/callback negatives remain immutable. Current V5 repair changes only observer helper/state/constructor/guard; no proof reconstruction, primary union, deadline receipt semantics, DFS engine/fallback/scheduler/rollback or independent reader/final24 algorithms changed. Actual meaningful generic controls and newly source-bound cold wrapper/q/plan admission remain pending. No production or synthetic control execution by reviewer.')]
report=dict(schema='independent-fresh-first-proof-runtime-source-findings-v3',source_only=True,source_review_passed=True,source_ready=True,all_checks_passed=True,scientific_calls=0,scientific_acceptance=False,author_identity='/root/hilbert_ordering_diagnosis',reviewer_identity='/root/hilbert_advice_controls',sources=h['sources'],source=h['sources']['proof_observer'],scope='first-checked-proof-observer',contract=pin(D/'source-contract-v4.json'),handoff=pin(D/'handoff-v4.json'),endpoint_preregistration=base['endpoint_preregistration'],prior_whole_source_review=pin(O/'fresh-first-proof-runtime-source-findings-v2.json'),prior_runner_negative=pin(O/'fresh-first-proof-runner-source-findings-v1.json'),review_source=pin(Path(__file__).resolve()),ast_comparisons=comparisons,static_assertions=len(checks),raw_audit=dict(roots=[pin(p) for p in roots],pin_references=len(refs),unique_raw_files=len(files),mismatches=0),findings=findings,concrete_blockers=[],actual_generic_controls_or_q_plans_activation_or_runtime_acceptance=False,actual_project_function_calls=0,source_ready_scope='Conditional SOURCE repair readiness only; actual closed wrapper new raw binding and actual generic controls require separate ROOT admission. No new proof/GCTS/RL/scientific authority.')
p=O/'fresh-first-proof-runtime-source-findings-v3.json'
with p.open('x') as f:json.dump(report,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
typed=dict(schema='ROOT-person-independent-primitive-source-review-v1',scope='first-checked-proof-observer',source=h['sources']['proof_observer'],source_only=True,source_ready=True,all_checks_passed=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,author_identity='/root/hilbert_ordering_diagnosis',reviewer_identity='/root/hilbert_advice_controls',findings=pin(p),sources=h['sources'],contract=pin(D/'source-contract-v4.json'),handoff=pin(D/'handoff-v4.json'),scope_limitation=report['source_ready_scope'])
t=O/'fresh-first-proof-observer-source-review-v3.json'
with t.open('x') as f:json.dump(typed,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
for a in (p,t):print(json.dumps(pin(a),sort_keys=True))
print(json.dumps(dict(rawrefs=len(refs),rawfiles=len(files),static_assertions=len(checks),scientific_calls=0)))
