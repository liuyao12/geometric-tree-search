"""Construct fixed-schema byte-copy markings between Wang strip boundaries."""
from hashlib import sha256
import json

import decode_v1 as syntax


def freeze(value):
    if isinstance(value, dict):
        return {k: freeze(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return tuple(map(freeze, value))
    return value


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def source_ports(prefix):
    assert prefix.startswith(">") and prefix.endswith(";#")
    ports = {}
    offset = 1
    for raw in syntax.records(prefix[1:-1]):
        ident, body = raw.split(":", 1)
        assert ident.startswith("C") and ident[1:] not in ports
        first = offset + len(ident) + 1
        ports[ident[1:]] = (first, first + len(body) + 1)
        offset += len(raw) + 1
    assert offset == len(prefix) - 1
    return ports


def final_port(prefix, word):
    assert word.endswith(";")
    raw = syntax.records(word)[-1]
    first = len(prefix) + len(word) - len(raw) - 1 + raw.index("/") + 1
    return first, len(prefix) + len(word)


def record(raw):
    head, body = raw.split("/", 1)
    syntax.clause(body)
    if head.startswith("G"):
        label, schema, env = head[1:].split(":", 2)
        syntax.digits(label)
        syntax.digits(schema)
        return "G", schema, env, body
    assert head.startswith("R")
    label, left, right, pivot = head[1:].split(":")
    for identifier in (label, left, right):
        syntax.digits(identifier)
    syntax.single(pivot)
    return "R", left, right, pivot, body


def compile_diagram(wire):
    source = wire["prefix"]
    roots = source_ports(source)
    words = syntax.records(wire["word"][:-1])
    outputs = []
    labels = {}
    strips = []
    for i, raw in enumerate(words):
        parsed = record(raw)
        if parsed[0] == "G":
            _, schema, env, out = parsed
            a, b = roots[schema]
            body = source[a:b - 1]
            prefix = ">C0:" + body + ";#"
            word = "G0:0:" + env + "/" + out + ";"
            parents = [("source", schema)]
            records = 1
        else:
            _, left, right, pivot, out = parsed
            ids = (labels[left], labels[right])
            a, b = (outputs[j] for j in ids)
            prefix = ">C0:" + a + ";C1:" + b + ";#"
            word = "G0:0:/" + a + ";G1:1:/" + b + ";R10:0:1:" + pivot + "/" + out + ";"
            parents = [("line", j) for j in ids]
            records = 3
        strips.append(dict(prefix=prefix, word=word, parents=parents, records=records))
        outputs.append(out)
        label = raw.split(":", 1)[0][1:]
        assert label not in labels
        labels[label] = i
    assert outputs and outputs[-1] == ""
    return dict(source=source, symbols=wire["symbols"], schema_ids=wire["schema_ids"], strips=strips)


def coordinate(port, origin, stride):
    start, end = port
    return dict(origin=[origin[0] + 1 + stride * start, origin[1]],
                glyphs=end - start, stride=stride)


def mark(source, target):
    assert source["glyphs"] == target["glyphs"]
    return dict(rule="equal-symbols", source=source, target=target)


def attach_marks(diagram, receipts, stride):
    source_ports_ = source_ports(diagram["source"])
    roots = {key: coordinate(value, (0, 0), stride) for key, value in source_ports_.items()}
    outputs = []
    marks = []
    y = 2
    for i, (strip, receipt) in enumerate(zip(diagram["strips"], receipts, strict=True)):
        origin = (0, y)
        strip["origin"] = origin
        for target, parent in zip(source_ports(strip["prefix"]).values(), strip["parents"], strict=True):
            kind, ident = parent
            assert kind == "source" or (kind == "line" and type(ident) is int and 0 <= ident < i)
            source = roots[ident] if kind == "source" else outputs[ident]
            marks.append(mark(source, coordinate(target, origin, stride)))
        outputs.append(coordinate(final_port(strip["prefix"], strip["word"]), origin, stride))
        y += receipt["rows"] + 1
    diagram["marks"] = marks
    diagram["height"] = y
    return diagram


def fingerprint(strip):
    return sha256(encoded((strip["prefix"], strip["word"], strip["records"]))).hexdigest()
