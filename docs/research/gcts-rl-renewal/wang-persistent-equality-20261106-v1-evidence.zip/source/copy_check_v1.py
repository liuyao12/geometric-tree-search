"""Check native tile strips and fixed geometric equality markings."""
from collections import Counter

import decode_v1 as syntax
from connected_frame_v1 import run
from connected_wire_v1 import closed, variables
from copy_ports_v1 import coordinate, final_port, fingerprint, freeze, mark, record, source_ports

LIMIT = 2_000_000_000
EVENTS = 2_000_000


class TileBank:
    """Cache only receipts produced by checked execution in this process."""
    def __init__(self, machine):
        self.machine = machine
        self.receipts = {}

    def get(self, strip):
        key = fingerprint(strip)
        reused = key in self.receipts
        if not reused:
            result = run(self.machine, strip["prefix"], strip["word"], LIMIT, EVENTS,
                         checked=True, records=strip["records"])
            assert result["status"] == "CHECKPOINT" and len(result["checkpoints"]) == strip["records"]
            self.receipts[key] = result
        return self.receipts[key], reused


def anchor(diagram, sources):
    """Bind only the fixed source plate to the original compiled clauses."""
    symbols = freeze(diagram["symbols"])
    assert len(set(symbols.values())) == len(symbols)

    def term(value, env, atom=False):
        if isinstance(value, str):
            assert not atom
            return env[value]
        name, *args = value
        role, *data = symbols[name]
        if role == "macro":
            assert not atom and not args and len(data) == 1 and closed(data[0])
            return data[0]
        assert role == ("predicate" if atom else "function") and data[1] == len(args)
        return data[0], *(term(t, env) for t in args)

    seen = set()
    for raw in syntax.records(diagram["source"][1:-1]):
        ident, body = raw.split(":", 1)
        assert ident.startswith("C")
        name = diagram["schema_ids"][ident[1:]]
        assert name in sources and name not in seen
        seen.add(name)
        schema = sources[name]
        env = {n: v for v, n in variables(schema).items()}
        parsed = syntax.clause(body, template=True)
        assert [(sign, term(t, env, True)) for sign, t in parsed] == list(schema["clause"])
    assert seen


def shape(strip):
    """Recognize the two local frame formats using syntax alone."""
    prefix, word = strip["prefix"], strip["word"]
    templates = source_ports(prefix)
    parsed = [record(raw) for raw in syntax.records(word)]
    if strip["records"] == 1:
        assert list(templates) == ["0"] and len(parsed) == 1 and parsed[0][:2] == ("G", "0")
        _, _, env, out = parsed[0]
        assert word == "G0:0:" + env + "/" + out + ";"
    else:
        assert strip["records"] == 3 and list(templates) == ["0", "1"] and len(parsed) == 3
        a, b = (prefix[x:y - 1] for x, y in templates.values())
        assert parsed[2][:3] == ("R", "0", "1")
        _, _, _, pivot, out = parsed[2]
        assert word == "G0:0:/" + a + ";G1:1:/" + b + ";R10:0:1:" + pivot + "/" + out + ";"
    return out


def topology(diagram, receipts, stride):
    assert diagram["strips"]
    anchors = {k: coordinate(v, (0, 0), stride) for k, v in source_ports(diagram["source"]).items()}
    produced, expected, glyphs = [], [], {}
    y = 2
    for i, (strip, receipt) in enumerate(zip(diagram["strips"], receipts, strict=True)):
        assert tuple(strip["origin"]) == (0, y)
        out = shape(strip)
        ports = source_ports(strip["prefix"])
        assert len(strip["parents"]) == len(ports)
        for port, (kind, ident) in zip(ports.values(), strip["parents"], strict=True):
            if len(ports) == 1:
                assert kind == "source" and ident in anchors
                source = anchors[ident]
            else:
                assert kind == "line" and type(ident) is int and 0 <= ident < i
                source = produced[ident]
            expected.append(mark(source, coordinate(port, (0, y), stride)))
        produced.append(coordinate(final_port(strip["prefix"], strip["word"]), (0, y), stride))
        glyphs[y] = strip["prefix"] + strip["word"] + "$"
        y += receipt["rows"] + 1
    assert out == "" and diagram["height"] == y
    assert freeze(diagram["marks"]) == freeze(expected)
    glyphs[0] = diagram["source"]

    def symbol(origin):
        x, line = origin
        assert type(x) is int and type(line) is int and x >= 1 and (x - 1) % stride == 0
        return glyphs[line][(x - 1) // stride]

    checked = 0
    for marking in diagram["marks"]:
        assert marking["rule"] == "equal-symbols"
        a, b = (marking[k] for k in ("source", "target"))
        assert a["stride"] == b["stride"] == stride and a["glyphs"] == b["glyphs"] > 0
        for j in range(a["glyphs"]):
            x, source_y = a["origin"]
            p, target_y = b["origin"]
            assert symbol((x + j * stride, source_y)) == symbol((p + j * stride, target_y))
            checked += 1
    return dict(marks=len(expected), glyph_equalities=checked, height=y)


def verify(diagram, sources, bank):
    anchor(diagram, sources)
    counts, receipts = Counter(), []
    for i, strip in enumerate(diagram["strips"]):
        shape(strip)
        result, reused = bank.get(strip)
        receipts.append(result)
        if not reused:
            counts["unique_steps"] += result["steps"]
            counts["unique_frames"] += 1
        counts["steps_without_reuse"] += result["steps"]
        counts["frames"] += 1
        if (i + 1) % 50 == 0:
            print("Checked", i + 1, "marked inference frames", flush=True)
    return dict(counts, **topology(diagram, receipts, len(bank.machine.marks) + 1))
