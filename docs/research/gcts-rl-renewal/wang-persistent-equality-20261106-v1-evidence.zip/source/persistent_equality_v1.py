"""Demand constructor instances and explain incremental ground equalities."""
from collections import defaultdict, deque
from itertools import islice, product

from demand_policy_v1 import Guided, Budget
from equality_closure_v1 import Equality
from fair_search_v1 import bind, terms
from herbrand_v1 import inspect_term


def variables(t):
    if isinstance(t, str):
        return {t}
    return set().union(*(variables(c) for c in t[1:]))


class Builder:
    def __init__(self, search):
        self.search = search

    def unguard(self, name, env):
        old = name, tuple(sorted(env.items()))
        if old in self.search.seen_instances:
            from study_v1 import grounded
            from fair_search_v1 import ordered
            return self.search.index[ordered(grounded(self.search.schemas[name], env))]
        return self.search.instance(name, env, "equality")

    def resolve(self, a, b, pivot):
        return self.search.resolve(a, b, pivot)


class Graph(Equality):
    def __init__(self, search):
        super().__init__({}, Builder(search), search.work)
        self.search = search

    def register(self, t):
        if t in self.sorts:
            return
        for child in t[1:]:
            self.register(child)
        self.search.charge("registered_terms")
        self.sorts[t] = inspect_term(t, {}, self.search.functions)
        self.parent[t] = t

    def close(self):
        while True:
            changed, seen = False, {}
            for t in tuple(self.sorts):
                if len(t) == 1:
                    continue
                self.search.charge("function_probes")
                key = (t[0], *(self.root(c) for c in t[1:]))
                u = seen.setdefault(key, t)
                if self.root(u) != self.root(t):
                    proof = self.apply("congruence-", u, t)
                    changed |= self.merge(u, t, proof)
                    self.stats["function_merges"] += 1
            if not changed:
                return


class Enhanced(Guided):
    def __init__(self, normal, goal, mode, limits, seed, weights, triggers, congruence):
        self.term_trigger = triggers
        self.use_graph = congruence and normal["equality"]
        self.graph = None
        self.observed = set()
        self.term_queue = deque()
        self.structural = defaultdict(list)
        self.clause_queue = deque()
        self.processed_units = set()
        self.dirty = False
        self.graph_dirty = False
        self.constructor_records = []
        super().__init__(normal, goal, mode, limits, seed, weights)
        for schema in self.schemas.values():
            if not schema["id"].startswith("formula"):
                continue
            patterns = set()
            for _, atom in schema["clause"]:
                for arg in atom[1:]:
                    patterns.update(t for t in terms(arg) if not isinstance(t, str) and variables(t))
            for t in sorted(patterns, key=repr):
                self.structural[t[0]].append((schema, t))
        if self.use_graph:
            self.graph = Graph(self)
        for i in range(len(self.rows)):
            self.observe(i)

    def add(self, clause, reason):
        size = len(self.rows)
        i = super().add(clause, reason)
        if i is not None and len(self.rows) > size and hasattr(self, "functions"):
            self.observe(i)
        return i

    def observe(self, i):
        clause = self.rows[i][0]
        self.clause_queue.append(i)
        if len(clause) == 1:
            self.dirty = True
        for _, atom in clause:
            for arg in atom[1:]:
                for t in terms(arg):
                    if t not in self.observed:
                        self.observed.add(t)
                        self.term_queue.append(t)
                        self.graph_dirty = True
                    if self.graph:
                        self.graph.register(t)

    def instantiate_term(self):
        if not self.term_trigger or not self.term_queue:
            return
        term = self.term_queue.popleft()
        for schema, pattern in self.structural[term[0]]:
            self.charge("constructor_probes")
            env = {}
            if not bind(pattern, term, env):
                continue
            missing = tuple(v for v in schema["variables"] if v not in env)
            choices = []
            for v in missing:
                candidates = self.seen_by_sort[schema["variables"][v]]
                choices.append(tuple(dict.fromkeys(candidates[:3] + candidates[-3:])))
            for values in islice(product(*choices), 16):
                actual = {**env, **dict(zip(missing, values, strict=True))}
                i = self.instance(schema["id"], actual, "constructor")
                if i is not None:
                    self.constructor_records.append(dict(source=schema["id"], pattern=pattern,
                                                         observed=term, bindings=actual))
                self.with_units(i)
                if () in self.index:
                    return

    def evidence(self, sign, atom, known):
        eq = self.graph
        if sign and atom[0].startswith("=") and eq.root(atom[1]) == eq.root(atom[2]):
            return eq.explain(atom[1], atom[2])
        old, proof = known[sign, eq.key(atom)]
        return eq.transport(sign, old, atom, proof)

    def equality_pass(self):
        if self.graph is None:
            return
        eq = self.graph
        changed = self.graph_dirty
        self.graph_dirty = False
        units = tuple(self.unit_ids.items())
        for (sign, atom), i in units:
            if i not in self.processed_units:
                self.processed_units.add(i)
                if sign and atom[0].startswith("="):
                    changed |= eq.merge(atom[1], atom[2], i)
        if changed:
            eq.close()
        known = {}
        for (sign, atom), i in tuple(self.unit_ids.items()):
            key = eq.key(atom)
            known.setdefault((sign, key), (atom, i))
            if not sign and atom[0].startswith("=") and eq.root(atom[1]) == eq.root(atom[2]):
                self.resolve(eq.explain(atom[1], atom[2]), i, atom)
                return
            if (not sign, key) in known:
                self.resolve(i, self.evidence(not sign, atom, known), atom)
                return
        if changed or self.dirty:
            self.clause_queue = deque(range(len(self.rows)))
            self.dirty = False

        def truth(sign, atom):
            if atom[0].startswith("=") and eq.root(atom[1]) == eq.root(atom[2]):
                return sign
            key = eq.key(atom)
            if (sign, key) in known:
                return True
            if (not sign, key) in known:
                return False
            return None

        for _ in range(32):
            if not self.clause_queue:
                return
            i = self.clause_queue.popleft()
            self.charge("equality_clause_visits")
            clause = self.rows[i][0]
            rest = []
            for sign, atom in clause:
                value = truth(sign, atom)
                if value is True:
                    break
                if value is None:
                    rest.append((sign, atom))
                    if len(rest) > 1:
                        break
            else:
                target = rest[0] if rest else None
                if target in self.unit_ids:
                    continue
                current = i
                for sign, atom in clause:
                    if (sign, atom) != target:
                        current = self.resolve(current, self.evidence(not sign, atom, known), atom)
                self.work["equality_propagations"] += 1
                if () in self.index:
                    return

    def focused(self):
        self.instantiate_term()
        if () not in self.index:
            self.equality_pass()
        if () not in self.index:
            super().focused()

    def run(self):
        result = super().run()
        if result["proof"]:
            used = {(r["source"], tuple(sorted(r["bindings"].items()))) for r in result["proof"]
                    if r["rule"] == "G"}
            result["constructor_example"] = next((r for r in self.constructor_records
                if (r["source"], tuple(sorted(r["bindings"].items()))) in used), None)
        return result
