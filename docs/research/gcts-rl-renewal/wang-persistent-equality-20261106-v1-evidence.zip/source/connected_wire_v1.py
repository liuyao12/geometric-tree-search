"""A single source-bound G/R proof word with reversible compact names."""
from collections import Counter
from itertools import count

import decode_v1 as decoder
from study_v1 import Certificate, substitute


def codes(keys):
    tokens = (f"{n:0{bits}b}" for bits in count(1) for n in range(2**bits))
    return dict(zip(keys, tokens))


def variables(row):
    return {name: f"{i:b}" for i, name in enumerate(sorted(row["variables"]))}


def all_terms(term):
    if isinstance(term, str):
        return
    yield term
    for child in term[1:]:
        yield from all_terms(child)


def closed(t):
    return not isinstance(t, str) and all(map(closed, t[1:]))


def forced(t, env):
    if isinstance(t, str) or closed(t):
        return
    yield substitute(t, env)
    for child in t[1:]:
        yield from forced(child, env)


def abbreviations(sources, proof):
    forbidden = set()
    term_counts = Counter()
    for row in proof:
        for _, a in row["clause"]:
            for t in a[1:]:
                term_counts.update(all_terms(t))
        if row["rule"] == "R":
            for t in row["pivot"][1:]:
                term_counts.update(all_terms(t))
            continue
        env = row["bindings"]
        for term in env.values():
            term_counts.update(all_terms(term))
        for _, a in sources[row["source"]]["clause"]:
            for t in a[1:]:
                forbidden.update(forced(t, env))
    return {t for t, n in term_counts.items() if len(t) > 1 and n > 1 and t not in forbidden}


class Writer:
    def __init__(self, aliases):
        self.aliases = aliases
        self.frequency = Counter()
        self.symbols = None

    def token(self, key):
        self.frequency[key] += 1
        return self.symbols[key] if self.symbols is not None else "0"

    def term(self, value, env, atom=False):
        if isinstance(value, str):
            return "%" + env[value] + ","
        if not atom and value in self.aliases:
            return "(" + self.token(("macro", value)) + ".)"
        head, *args = value
        key = ("predicate" if atom else "function", head, len(args))
        return "(" + self.token(key) + "." + "".join(self.term(x, env) for x in args) + ")"

    def clause(self, row, env):
        return "".join(("+" if s else "-") + self.term(t, env, True) for s, t in row)

    def compile(self, sources, proof):
        requests = Counter(row["source"] for row in proof if row["rule"] == "G")
        templates = {name: self.clause(sources[name]["clause"], variables(sources[name]))
                     for name in sorted(requests)}
        order = sorted(templates, key=lambda name: (-requests[name], len(templates[name]), name))
        schema_ids = codes(order)
        references = Counter(i for row in proof if row["rule"] == "R" for i in (row["left"], row["right"]))
        line_ids = codes(sorted(range(len(proof)), key=lambda i: (-references[i], i)))
        prefix = ">" + "".join(f"C{schema_ids[name]}:{templates[name]};" for name in order) + "#"
        lines = []
        for i, row in enumerate(proof):
            label = line_ids[i]
            if row["rule"] == "G":
                name = row["source"]
                bindings = "".join(f"={n}:{self.term(row['bindings'][v], {})}"
                                   for v, n in variables(sources[name]).items())
                head = f"G{label}:{schema_ids[name]}:" + bindings
            else:
                a, b = (line_ids[row[k]] for k in ("left", "right"))
                pivot = self.term(row["pivot"], {}, True)
                head = f"R{label}:{a}:{b}:{pivot}"
            lines.append(head + "/" + self.clause(row["clause"], {}) + ";")
        return prefix, "".join(lines) + "!", {v: k for k, v in schema_ids.items()}


def compact(sources, proof):
    writer = Writer(abbreviations(sources, proof))
    writer.compile(sources, proof)
    writer.symbols = codes(sorted(writer.frequency, key=lambda k: (-writer.frequency[k], repr(k))))
    prefix, word, schema_ids = writer.compile(sources, proof)
    symbols = {v: k for k, v in writer.symbols.items()}
    return dict(prefix=prefix, word=word, schema_ids=schema_ids, symbols=symbols)


def canonical(normal, sources, functions, predicates, type_ids, proof):
    b = Certificate(sources, functions, predicates, normal["sorts"], type_ids)
    b.lines = proof
    prefix = b.prefix()
    used = {b.ids[row["source"]] for row in proof if row["rule"] == "G"}
    sliced = ">" + "".join(row + ";" for i, row in enumerate(decoder.records(prefix[1:-1])) if i in used) + "#"
    word = b.words()
    return dict(canonical=(prefix, word), sliced=(sliced, word))


def audit(wire, sources, proof):
    """Expand the actual source and proof records and bind each to its checked object."""
    prefix, word, ids, symbols = (wire[k] for k in ("prefix", "word", "schema_ids", "symbols"))
    assert len(set(symbols.values())) == len(symbols)

    def expand(value, env, atom=False):
        if isinstance(value, str):
            assert not atom
            return env[value]
        name, *args = value
        role, *descriptor = symbols[name]
        if role == "macro":
            assert not atom and not args and len(descriptor) == 1 and closed(descriptor[0])
            return descriptor[0]
        assert role == ("predicate" if atom else "function") and descriptor[1] == len(args)
        return descriptor[0], *(expand(x, env) for x in args)

    def clause(row, env):
        return [(sign, expand(atom, env, True)) for sign, atom in row]

    seen = set()
    for entry in decoder.records(prefix[1:-1]):
        assert entry.startswith("C")
        wire_id, raw = entry[1:].split(":", 1)
        name = ids[wire_id]
        assert name not in seen
        seen.add(name)
        template = sources[name]
        env = {n: v for v, n in variables(template).items()}
        assert clause(decoder.clause(raw, template=True), env) == list(template["clause"])
    assert seen == {row["source"] for row in proof if row["rule"] == "G"}
    parsed = decoder.read(prefix, word)
    for actual, expected in zip(parsed, proof, strict=True):
        assert actual["rule"] == expected["rule"]
        assert clause(actual["clause"], {}) == list(expected["clause"])
        if actual["rule"] == "G":
            name = expected["source"]
            assert ids[actual["schema"]] == name
            env = {n: v for v, n in variables(sources[name]).items()}
            assert {env[x]: expand(t, {}) for x, t in actual["substitution"].items()} == expected["bindings"]
        else:
            assert all(actual[k] == expected[k] for k in ("left", "right"))
            assert expand(actual["pivot"], {}, True) == expected["pivot"]
    return len(parsed)
