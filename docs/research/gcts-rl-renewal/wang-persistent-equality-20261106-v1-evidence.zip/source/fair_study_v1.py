"""Run the fair search with and without its demand lane on fixed FOL obligations."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ("source","wang/source","wang/external/source")]
from definition_cases_v1 import mixed_swap, typed_scope
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_cases_v1 import holds
from fair_search_v1 import Search, stream
import herbrand_v1 as fol
import resolution_v1 as prop
from induction_cases_v1 import hilbert
from lifted_cases_v1 import a, all_, case, control, disjunction, exists, implies


BUDGET=600


def binary(name,n,hidden=False):
    def iterate(x):
        for _ in range(n):
            x=["f",x,["b"]]
        return x
    x="?x"
    premises=[a("P",["a"]),all_(x,implies(a("P",x),a("P",["f",x,["b"]])))]
    if hidden:
        premises.append(all_(x,implies(a("P",iterate(x)),a("Q",x))))
        goal=exists(x,a("Q",x))
    else:
        goal=a("P",iterate(["a"]))
    return case(name,{"a":0,"b":0,"f":2},{"P":1,**({"Q":1} if hidden else {})},premises,goal)


def cases():
    mixed=dict(domains={"Point":(0,1),"Line":(0,1)},functions={},predicates={"R":{(0,0),(1,1)}})
    occurs=dict(domains={"U":(0,1)},functions={"f":{(0,):1,(1,):0}},predicates={"R":{(0,1),(1,0)}})
    geo=hilbert()
    aa,cc,ll,mm=(["a"],["c"],["ell"],["m"])
    uniqueness=dict(geo,id="two-points-determine-a-line",
                    functions={**geo["functions"],"m":[[],"Line"]},
                    premises=[geo["premises"][0],["not",a("=Point",aa,cc)],
                              *(a("I",p,l) for p in (aa,cc) for l in (ll,mm))],
                    goal=a("=Line",ll,mm))
    return [(binary("binary-witness-in-goal",12),None),
            (binary("binary-witness-to-discover",7,True),None),
            (disjunction(),None),(typed_scope(),None),(uniqueness,None),(geo,None),
            (mixed_swap(),mixed),(control(),occurs)]


def enumeration_control():
    schemas=({"id":"unit","variables":{"?x":"U"}},{"id":"pair","variables":{"?x":"U","?y":"U"}})
    fn={"a":((),"U"),"b":((),"U"),"f":(("U","U"),"U")}
    source=stream(("U",),fn,schemas)
    observed=[]
    for weight in range(1,8):
        rows=[]
        while (r:=next(source)) is not None:
            rows.append(r)
        keys={(name,tuple(env.items())) for name,env in rows}
        assert len(keys)==len(rows)
        observed.append(tuple(sum(r[0]==key for r in rows) for key in ("unit","pair")))
    assert observed==[(2,0),(0,4),(4,0),(0,16),(16,0),(0,80),(80,0)]
    return observed


def batches(normal):
    """The earlier restart-by-depth strategy, under explicit finite caps."""
    functions,_,schemas=fol.signature(normal)
    attempts=[]
    for depth in range(7):
        terms=fol.ground_terms(normal,functions,depth,96)
        if terms is None:
            return dict(status="TERM_CAP",attempts=attempts)
        atoms,instances=fol.instances(schemas,terms,depth,3000)
        if instances is None:
            return dict(status="INSTANCE_CAP",attempts=attempts)
        raw=[prop.literals(pair) for pair in instances]
        engine=prop.Search(raw,dict(clauses=8000,seconds=float("inf")),"PLAIN")
        result=engine.eliminate(len(atoms))
        attempts.append(dict(depth=depth,status=result,instances=len(instances),counts=dict(engine.counts)))
        if result=="UNSAT":
            return dict(status="PROVED",attempts=attempts)
        if result=="BOUNDED":
            return dict(status="ELIMINATION_CAP",attempts=attempts)
    return dict(status="DEPTH_CAP",attempts=attempts)


def study():
    rows=[]
    for original,model in cases():
        normal,certificate=compile_case(original)
        qualification=check(original,normal,certificate)
        stats={label:Search(normal,guided).search(BUDGET) for label,guided in (("fair",False),("demand",True))}
        if model is not None:
            premises,goal=holds(original,model)
            assert all(premises) and not goal
            assert all(r["status"]=="BOUNDED" for r in stats.values())
        elif original["id"]!="between-on-the-line":
            assert stats["demand"]["status"]=="PROVED"
        rows.append(dict(original=original,normal=normal,translation=certificate,qualification=qualification,
                         runs=stats,batches=batches(normal),countermodel=model is not None))
        print(original["id"],{k:(r["status"],r["counts"]) for k,r in stats.items()},
              "batch",rows[-1]["batches"]["status"],flush=True)
    return dict(rows=rows,enumeration=enumeration_control(),round_budget=BUDGET)


def main():
    if not __debug__:
        raise RuntimeError("Proof replay requires assertions")
    result=study()
    body=json.dumps(result,sort_keys=True,separators=(",",":"))+"\n"
    path=ROOT/"data/fair-study-v1.json"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text()==body


if __name__=="__main__":
    main()
