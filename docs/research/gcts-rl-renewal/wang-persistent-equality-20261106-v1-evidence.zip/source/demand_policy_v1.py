"""Schedule exact signed-literal matches with fixed and learned policies."""
from itertools import islice
from math import exp, sqrt
from random import Random

from fair_search_v1 import Search, bind, terms

FEATURES = ("goal symbol", "negative unit", "definition symbol", "term size",
            "literal arity", "opposite unit present", "opposite clause count",
            "fully bound matches", "partially bound matches", "later in queue")
WINDOW = 12


class Budget(Exception):
    pass


def labels(node):
    if node[0] == "atom":
        return {node[1]}
    if node[0] in ("all", "exists"):
        return labels(node[-1])
    return set().union(*(labels(child) for child in node[1:]))


def scaled(n, cap):
    return min(n, cap) / cap


class Guided(Search):
    def __init__(self, normal, goal, mode, limits, seed=0, weights=(), marked=True):
        self.mode, self.limits, self.weights = mode, limits, weights
        self.marked = marked
        self.random = Random(seed)
        self.goal_symbols = labels(goal)
        self.matches = {}
        self.trajectory = []
        self.example = None
        super().__init__(normal, guided=True)

    def charge(self, key):
        if self.work[key] >= self.limits[key]:
            raise Budget(key)
        self.work[key] += 1

    def resolve(self, i, j, atom):
        if self.work["resolutions"] >= self.limits["resolutions"]:
            raise Budget("resolutions")
        return super().resolve(i, j, atom)

    def instance(self, name, env, lane):
        token = name, tuple(sorted(env.items()))
        if token not in self.seen_instances:
            self.charge("instances")
        return super().instance(name, env, lane)

    def unit_matches(self, i):
        if i not in self.matches:
            ((sign, atom),) = self.rows[i][0]
            matches = []
            for schema, pattern in self.triggers[sign, atom[0]]:
                self.charge("probes")
                env = {}
                if bind(pattern, atom, env):
                    missing = tuple(v for v in schema["variables"] if v not in env)
                    matches.append((schema, env, missing))
            self.matches[i] = matches
        return self.matches[i]

    def profile(self, i, pos):
        ((sign, atom),) = self.rows[i][0]
        opposite = not sign, atom
        matches = self.unit_matches(i) if self.marked else ()
        full = sum(not missing for _, _, missing in matches)
        size = sum(1 for arg in atom[1:] for _ in terms(arg))
        return (float(atom[0] in self.goal_symbols), float(not sign),
                float(atom[0].startswith("def_")), scaled(size, 18),
                scaled(len(atom) - 1, 4), float(self.marked and opposite in self.unit_ids),
                scaled(len(self.admitted.get(opposite, ())), 12) if self.marked else 0.0,
                scaled(full, 5), scaled(len(matches) - full, 5), pos / (WINDOW - 1))

    def next_unit(self):
        candidates = tuple(islice(self.pending_units, WINDOW))
        if self.mode == "fifo" or len(candidates) == 1:
            return super().next_unit()
        if self.mode == "random":
            pos = self.random.randrange(len(candidates))
        else:
            features = tuple(self.profile(i, j) for j, i in enumerate(candidates))
            self.work["ranked_units"] += len(features)
            scores = [fixed(row) if self.mode == "fixed" else dot(self.weights, row) for row in features]
            if self.mode == "train":
                pos = self.sample(features, scores)
            else:
                pos = max(range(len(scores)), key=scores.__getitem__)
                if pos and self.example is None:
                    self.example = dict(chosen=pos, round=self.work["rounds"], scores=scores,
                                        features=features, units=[self.rows[i][0] for i in candidates])
        self.pending_units.rotate(-pos)
        i = self.pending_units.popleft()
        self.pending_units.rotate(pos)
        return i

    def sample(self, features, scores):
        best = max(scores)
        mass = [exp(s - best) for s in scores]
        pos = self.random.choices(range(len(scores)), weights=mass)[0]
        total = sum(mass)
        self.trajectory.append(tuple(x - sum(p * v for p, v in zip(mass, col, strict=True)) / total
                                     for x, col in zip(features[pos], zip(*features), strict=True)))
        return pos

    def run(self):
        try:
            result = self.search(self.limits["rounds"])
        except Budget as exc:
            result = dict(status="BOUNDED", counts=dict(self.work), proof=None, stop=str(exc))
        if result["status"] == "BOUNDED":
            result.setdefault("stop", "rounds")
        return result


def fixed(x):
    goal, neg, definition, size, arity, opposite, count, full, partial, recent = x
    return 10 * opposite + 3 * full + 2 * goal + count - size - 0.1 * recent


def dot(a, b):
    return sum(x * y for x, y in zip(a, b, strict=True))


def train(problems, seed, limits, passes, marked):
    """Update a softmax policy from checked search success and charged search work."""
    order = Random(seed)
    weights = [0.0] * len(FEATURES)
    baseline = 0.0
    logs = []
    for _ in range(passes):
        choices = list(problems)
        order.shuffle(choices)
        solved, cost, decisions = 0, 0, 0
        for original, normal in choices:
            engine = Guided(normal, original["goal"], "train", limits, order.randrange(2**32), weights, marked)
            out = engine.run()
            won = out["status"] == "PROVED"
            effort = engine.work["resolutions"] / limits["resolutions"]
            reward = 1.0 - 0.5 * effort if won else -0.5
            solved += won
            cost += engine.work["resolutions"]
            size = len(engine.trajectory)
            decisions += size
            advantage = reward - baseline
            baseline = 0.9 * baseline + 0.1 * reward
            factor = 0.12 * advantage / sqrt(max(1, size))
            for step in reversed(engine.trajectory):
                for i, gradient in enumerate(step):
                    weights[i] += factor * gradient
                factor *= 0.985
        logs.append(dict(solved=solved, resolutions=cost, decisions=decisions))
    return dict(weights=[round(v, 10) for v in weights], passes=logs)
