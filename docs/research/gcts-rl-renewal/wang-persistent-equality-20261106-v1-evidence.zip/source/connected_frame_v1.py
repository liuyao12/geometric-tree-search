"""Replay a deterministic Wang rectangle without storing every transition."""
from hashlib import sha256
from struct import pack

from sparse_frame_v1 import FixedPalette, Sweeps, update_tiles
import tiles_v1 as tiles


def row_window(palette, tape, q, h, nxt, write, move):
    first = max(0, min(h - 4, len(tape.data) - 9))

    def before(i):
        if i < 0:
            return tiles.L
        if i >= len(tape.data):
            return tiles.R
        return tiles.cell(tape.symbols[tape.data[i]], q if i == h else None)

    row = []
    for i in range(first, first + 9):
        after = tiles.cell(tape.symbols[write if i == h else tape.data[i]], nxt if i == h + move else None)
        row.append(palette.local(before(i - 1), before(i), before(i + 1), after))
    assert all(a[1] == b[3] for a, b in zip(row, row[1:]))
    return first + 1, row


def top(palette, chars, free, initial):
    assert palette.allows((("top", "left"), tiles.LINK, tiles.FL, tiles.OL))
    assert palette.allows((("top", "right"), tiles.OR, tiles.FR, tiles.LINK))
    for i, c in enumerate(chars):
        state = initial if i == 0 else None
        pin = ("input", "head", c) if i == 0 else ("input", "free") if i in free else ("input", "fixed", c)
        assert palette.allows(palette.top(pin, tiles.cell(c, state)))


def run(machine, prefix, word, limit, events_limit, *, checked=False, padding=0, records=None):
    chars, free = machine.input(prefix, word, padding)
    tape = Sweeps(machine, chars)
    palette = FixedPalette(machine) if checked else None
    if checked:
        top(palette, chars, set(free), machine.start)
    q, h, steps, events = machine.start, 0, 0, 0
    finish = machine.names.index("finish")
    checkpoint = []
    digest = sha256() if checked else None
    active = 0
    completed = 0
    while q not in (0, 1) and steps < limit and events < events_limit:
        assert 0 <= h < len(chars)
        nxt, write, move = tape.transition(q, h)
        arrived = q != finish and nxt == finish
        if nxt == q and write == tape.data[h] and move:
            span = min(tape.sweep(q, h, move), limit - steps)
            assert span > 0 and 0 <= h + span * move < len(chars)
            if checked:
                for column in {h, h + (span - 1) * move}:
                    active += len(update_tiles(palette, tape, q, column, q, tape.data[column], move))
                digest.update(pack(">cIb", b"S", span, move))
            h += span * move
            steps += span
        else:
            if checked:
                active += len(update_tiles(palette, tape, q, h, nxt, write, move))
                digest.update(pack(">cIBb", b"T", nxt, write, move))
                if arrived:
                    column, row = row_window(palette, tape, q, h, nxt, write, move)
                    checkpoint.append(dict(step=steps + 1, column=column, row=row, trace_sha256=digest.hexdigest()))
            tape.write(h, write)
            q, h, steps = nxt, h + move, steps + 1
        events += 1
        if arrived:
            completed += 1
            if records is not None and completed == records:
                break
    at_port = records is not None and q == finish and completed == records
    status = "CHECKPOINT" if at_port else "ACCEPT" if q == 0 else "REJECT" if q == 1 else "BOUNDED"
    result = dict(status=status, steps=steps, events=events, columns=len(chars) + 2, last=machine.names[q])
    if status == "ACCEPT":
        result.update(rows=steps + 2, implied_squares=(steps + 2) * (len(chars) + 2))
        if checked:
            final = [tiles.cell(tape.symbols[c], q if i == h else None) for i, c in enumerate(tape.data)]
            cap = palette.cap(final)
            assert all(map(palette.allows, cap))
            assert all(a[1] == b[3] for a, b in zip(cap, cap[1:]))
    elif at_port:
        result.update(rows=steps + 1, implied_squares=(steps + 1) * (len(chars) + 2))
    if checked:
        result.update(checkpoints=checkpoint, trace_sha256=digest.hexdigest(), active_checks=active)
    return result
