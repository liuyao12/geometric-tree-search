"""Keep training families separate from synthetic and mathematical transfer cases."""
from random import Random

from fair_study_v1 import cases as prior
from induction_cases_v1 import arithmetic, induction


def atom(p, *args):
    return ["atom", p, *args]


def implies(a, b):
    return ["implies", a, b]


def quant(body, *variables, tag="all"):
    for name, sort in reversed(variables):
        body = [tag, name, sort, body]
    return body


def case(name, functions, predicates, premises, goal, sorts=("U",)):
    return dict(id=name, sorts=list(sorts), functions=functions, predicates=predicates,
                premises=premises, goal=goal, equality=False)


def signature(predicates, functions=("a", "b")):
    return {c: [[], "U"] for c in functions}, {p: ["U"] for p in predicates}


def ordered(seed, premises):
    result = list(premises)
    Random(seed).shuffle(result)
    return result


def chain(i):
    levels = 3 + i % 5
    s = tuple(f"X{j}" for j in range(levels + 1))
    d = tuple(f"D{j}" for j in range(levels + 1))
    funcs, preds = signature((*s, *d))
    a, b, x = ["a"], ["b"], "?x"
    branches = [*zip(s, s[1:]), *zip(d, d[1:]), *zip(s, d[1:])]
    rules = [quant(implies(atom(p, x), atom(q, x)), (x, "U")) for p, q in branches]
    facts = [atom(s[0], a), atom(s[0], b), atom(d[0], a)]
    return case(f"train-chain-{i}", funcs, preds, ordered(i, rules + facts), atom(s[-1], a))


def relation(i):
    levels = 3 + i % 4
    constants = tuple(f"c{j}" for j in range(levels + 4))
    funcs, _ = signature((), constants)
    x, y, z = "?x", "?y", "?z"
    def edge(a, b):
        return atom("E", a, b)
    rule = quant(implies(["and", edge(x, y), edge(y, z)], edge(x, z)), *((v, "U") for v in (x, y, z)))
    facts = [edge([a], [b]) for a, b in zip(constants[:levels], constants[1:levels + 1])]
    facts += [edge([constants[-1]], [b]) for b in constants[1:]]
    return case(f"train-relation-{i}", funcs, {"E": ["U", "U"]},
                ordered(i, [rule, *facts]), edge([constants[0]], [constants[levels]]))


def by_cases(i):
    levels = 2 + i % 4
    u, v = ([f"{k}{j}" for j in range(levels)] for k in "UV")
    funcs, preds = signature((*u, *v, "W", "J", "K"))
    a, x = ["a"], "?x"
    routes = [*zip(u, [*u[1:], "W"]), *zip(v, [*v[1:], "W"]), (u[0], "J"), (v[0], "K")]
    rules = [quant(implies(atom(p, x), atom(q, x)), (x, "U")) for p, q in routes]
    start = ["or", atom(u[0], a), atom(v[0], a)]
    return case(f"train-cases-{i}", funcs, preds, ordered(i, [start, *rules]), atom("W", a))


def diamond(i):
    levels = 2 + i
    p = tuple(f"A{j}" for j in range(levels + 1))
    l = tuple(f"L{j}" for j in range(levels))
    r = tuple(f"R{j}" for j in range(levels))
    funcs, preds = signature((*p, *l, *r))
    a, b, x = ["a"], ["b"], "?x"
    premises = [atom(p[0], a), atom(p[0], b), *(atom(q, b) for q in r)]
    for j in range(levels):
        rules = [implies(atom(p[j], x), atom(l[j], x)), implies(atom(p[j], x), atom(r[j], x)),
                 implies(["and", atom(l[j], x), atom(r[j], x)], atom(p[j + 1], x))]
        premises.extend(quant(rule, (x, "U")) for rule in rules)
    return case(f"test-diamond-{i}", funcs, preds, ordered(301 + i, premises), atom(p[-1], a))


def existential(i):
    levels = 2 + i
    x, t = "?x", "?t"
    a, b = ["a"], ["b"]
    funcs, preds = signature(("P", "Q", "D"))
    funcs["h"] = [["U", "U"], "U"]
    tail = x
    for _ in range(levels):
        tail = ["h", tail, b]
    premises = [atom("P", a),
                quant(implies(atom("P", x), atom("P", ["h", x, b])), (x, "U")),
                quant(implies(atom("P", tail), atom("Q", x)), (x, "U")),
                quant(implies(atom("P", x), atom("D", ["h", x, a])), (x, "U"))]
    return case(f"test-exists-{i}", funcs, preds, ordered(401 + i, premises),
                quant(atom("Q", t), (t, "U"), tag="exists"))


def typed(i):
    levels = 2 + i
    obj, site = "Object", "Site"
    u, v, w = "?u", "?v", "?w"
    funcs = {f"s{j}": [[], site] for j in range(levels + 2)}
    funcs.update(a=[[], obj], b=[[], obj])
    preds = {"At": [obj, site], "Link": [site, site], "Unused": [obj, site]}
    def at(a, b):
        return atom("At", a, b)
    route = quant(implies(["and", at(u, v), atom("Link", v, w)], at(u, w)),
                  (u, obj), (v, site), (w, site))
    a, b, start = ["a"], ["b"], ["s0"]
    premises = [at(a, start), at(b, start), route]
    premises += [atom("Link", [f"s{j}"], [f"s{j + 1}"]) for j in range(levels)]
    premises += [atom("Unused", a, [f"s{j}"]) for j in range(levels + 2)]
    return case(f"test-typed-{i}", funcs, preds, ordered(501 + i, premises),
                at(a, [f"s{levels}"]), sorts=(obj, site))


def training():
    return [fn(i) for fn in (chain, relation, by_cases) for i in range(8)]


def testing():
    synthetic = [(fn(i), None) for fn in (diamond, existential, typed) for i in range(4)]
    earlier = prior()
    geometry = [(p, m) for p, m in earlier if p["id"] in ("two-points-determine-a-line", "between-on-the-line")]
    natural = [q for p, v in zip(list(arithmetic())[:2], ("?x", "?y"), strict=True) for q in induction(p, v)]
    negative = [(p, m) for p, m in earlier if m is not None]
    return [*synthetic, *geometry, *((p, None) for p in natural), *negative]
