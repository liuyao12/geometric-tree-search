"""Compare persistent scheduling, term triggers and explained congruence."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source", "wang/external/source")]
from definitions_v1 import compile_case
from definition_check_v1 import check
from equality_cases_v1 import holds
from induction_cases_v1 import arithmetic, finite_no_induction
from fair_study_v1 import cases as earlier_controls
from persistent_equality_v1 import Enhanced

LIMITS = dict(rounds=400, resolutions=28000, instances=11000, probes=26000,
              registered_terms=3000, constructor_probes=26000, function_probes=100000,
              equality_clause_visits=30000)
ARMS = (
    ("fifo", "fifo", 0, False, False),
    ("constructors", "fifo", 0, True, False),
    ("equality", "fifo", 0, False, True),
    ("both", "fifo", 0, True, True),
    ("learned-11", "learned", 11, True, True),
    ("learned-29", "learned", 29, True, True),
    ("learned-47", "learned", 47, True, True),
)


def nested(n, p):
    for _ in range(n):
        p = ["f", p]
    return p


def additions():
    for n in (2, 5, 9):
        a, b = ["a"], ["b"]
        yield dict(id=f"congruence-nesting-{n}", sorts=["U"], equality=True,
                   functions={"a": [[], "U"], "b": [[], "U"], "f": [["U"], "U"]},
                   predicates={"P": ["U"]}, premises=[["atom", "=U", a, b], ["atom", "P", nested(n, a)]],
                   goal=["atom", "P", nested(n, b)])
    for n in (2, 5, 9):
        a = ["a"]
        yield dict(id=f"cycle-congruence-{n}", sorts=["U"], equality=True,
                   functions={"a": [[], "U"], "f": [["U"], "U"]}, predicates={},
                   premises=[["atom", "=U", a, ["f", a]]],
                   goal=["atom", "=U", a, nested(n, a)])


def study():
    prior = json.loads((ROOT / "input/demand-study-v1.json").read_text())
    models = prior["models"]["learned"]
    cases = [(row["original"], row["countermodel"]) for row in prior["test"]]
    known_controls = {p["id"]: (p, m) for p, m in earlier_controls() if m is not None}
    for source, negative in cases:
        if negative:
            expected, model = known_controls[source["id"]]
            assert source == expected
            truth, goal = holds(source, model)
            assert all(truth) and not goal
    cases.extend((source, False) for source in additions())
    wrong = next(arithmetic())
    truth, goal = holds(wrong, finite_no_induction())
    assert all(truth) and not goal
    cases.append((dict(wrong, id="recursion-without-induction"), True))
    rows = []
    for source, negative in cases:
        normal, translation = compile_case(source)
        check(source, normal, translation)
        runs = {}
        for label, policy, seed, terms, congruence in ARMS:
            weights = models[str(seed)]["weights"] if seed else ()
            engine = Enhanced(normal, source["goal"], policy, LIMITS, seed, weights, terms, congruence)
            result = engine.run()
            assert not negative or result["status"] == "BOUNDED"
            assert all(result["counts"].get(k, 0) <= v for k, v in LIMITS.items())
            if engine.graph is not None:
                classes = {}
                for term in engine.graph.sorts:
                    classes.setdefault(engine.graph.root(term), []).append(term)
                groups = [values for values in classes.values() if len(values) > 1]
                result["classes"] = sorted(groups, key=lambda vs: (-len(vs), repr(vs)))[:12]
            runs[label] = result
        rows.append(dict(original=source, normal=normal, translation=translation,
                         countermodel=negative, runs=runs))
        print(source["id"], {k:(v["status"],v["counts"].get("resolutions",0),v.get("stop"))
                             for k,v in runs.items()}, flush=True)
    return dict(limits=LIMITS, arms=ARMS, rows=rows, frozen_models=prior["models"]["learned"])


def main():
    if not __debug__:
        raise RuntimeError("Replay requires assertions")
    body = json.dumps(study(), sort_keys=True, separators=(",", ":")) + "\n"
    file = ROOT / "data/persistent-equality-v1.json"
    if "--build" in sys.argv:
        file.write_text(body)
    else:
        assert file.read_text() == body


if __name__ == "__main__":
    main()
