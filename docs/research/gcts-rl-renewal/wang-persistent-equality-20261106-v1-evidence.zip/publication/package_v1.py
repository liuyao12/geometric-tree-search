"""Package deterministic search evidence, proof receipts and the reader."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
NAME = "wang-persistent-equality-20261106-v1"
README = """Share equal terms while searching for a proof

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/equality_study_v1.py
  python3 -I -S -B source/equality_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The first command repeats all search runs and countermodel checks.
The second recompiles and replays all distinct marked diagrams. Add
--build to either command to regenerate its corresponding data file.
The last command regenerates the reader. Frozen learned policies were
trained in the earlier donor-only experiment. They are not retrained here.
The manifest gives SHA-256 for each included input and result.
"""


def contents():
    for d in ("source", "wang/source", "wang/external/source"):
        yield from (ROOT / d).glob("*.py")
    yield from (ROOT / "input").glob("*")
    yield from (ROOT / "data").glob("*.json.gz")
    yield ROOT / "data/persistent-equality-v1.json"
    for n in ("render_v1.py", "proof_views_v1.py", "group-notebook-head-v1.html",
              "equality-body-v1.html", "check_browser_v1.cjs", "package_v1.py"):
        yield ROOT / "publication" / n
    yield ROOT / "report" / (NAME+".html")


def write(zipfile, name, data):
    item = ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
    item.external_attr = 0o100644 << 16
    zipfile.writestr(item, data, ZIP_DEFLATED, 6)


def main():
    target = ROOT / "report" / (NAME+"-evidence.zip")
    manifest = {}
    with ZipFile(target, "w") as archive:
        for path in sorted(contents()):
            name = path.relative_to(ROOT).as_posix()
            body = path.read_bytes()
            write(archive, name, body)
            manifest[name] = sha256(body).hexdigest()
        write(archive, "README.txt", README.encode())
        manifest["README.txt"] = sha256(README.encode()).hexdigest()
        write(archive, "MANIFEST.json", (json.dumps(manifest, sort_keys=True)+"\n").encode())
    print(target.name, target.stat().st_size, sha256(target.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
