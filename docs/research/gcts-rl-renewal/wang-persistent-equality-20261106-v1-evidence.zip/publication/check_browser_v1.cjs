const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      await page.goto(pathToFileURL(process.cwd() + "/report/wang-persistent-equality-20261106-v1.html").href,
        { waitUntil: "load", timeout: 60000 });
      await page.locator("mjx-container").first().waitFor();
      assert.equal(await page.locator("#coverage tbody tr").count(), 7);
      assert.equal(await page.locator("#work tbody tr").count(), 10);
      assert.equal(await page.locator(".example").count(), 2);
      assert.equal(await page.locator(".steps>li").count(), 37);
      assert.ok(await page.locator(".chain .arrow").count() >= 4);
      const last = page.locator(".example").last().locator(".steps>li").last();
      assert.match(await last.locator(".formula").textContent(), /⊥/);
      await last.locator("details summary").click();
      assert.equal(await last.locator("svg use").count(), 9);
      assert.ok(await last.locator("svg use").first().evaluate(node => node.getBBox().width >= 36));
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth), width);
      assert.deepEqual(errors, []);
      if (process.env.GCTS_SCREENSHOT) {
        await page.screenshot({path:process.env.GCTS_SCREENSHOT.replace("{width}",width),fullPage:false});
      }
      console.log("Verified", width, "px, 37 proof lines, equality chains, Wang squares and result tables.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
