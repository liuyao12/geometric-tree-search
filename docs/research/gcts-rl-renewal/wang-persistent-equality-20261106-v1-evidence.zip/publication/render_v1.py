"""Render search controls and the expanded arithmetic proofs."""
from collections import defaultdict, deque
from html import escape
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "source", "wang/source")]
from copy_ports_v1 import fingerprint, freeze
from proof_views_v1 import clause, explanation, expression, formula, math, tile_svg

NAME = "wang-persistent-equality-20261106-v1"
TITLE = "Share equal terms while searching for a proof"
ORDER = ("fifo", "constructors", "equality", "both", "learned-11", "learned-29", "learned-47")
LABEL = {"fifo": "FIFO", "constructors": "Constructor matching", "equality": "Equality sharing",
         "both": "Both additions", "learned-11": "Both and learned seed 11",
         "learned-29": "Both and learned seed 29", "learned-47": "Both and learned seed 47"}
SELECTED = ("zero-left-step", "successor-left-step")


def read(path):
    p = ROOT / path
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix == ".gz" else p.read_bytes())


def count(rows, arm):
    return sum(row["runs"][arm]["status"] == "PROVED" for row in rows)


def summary(data):
    positive = [row for row in data["rows"] if not row["countermodel"]]
    old = [row for row in positive if row["original"]["id"].startswith("test-") or
           row["original"]["id"] in ("two-points-determine-a-line", "between-on-the-line",
           "zero-left-base", "zero-left-step", "successor-left-base", "successor-left-step")]
    assert len(old) == 18 and len(positive) == 24
    return "".join(f'<tr><th scope="row">{LABEL[a]}</th><td>{count(old, a)} of 18</td>'
                   f'<td>{count(positive, a)} of 24</td></tr>' for a in ORDER)


def detailed(data):
    output = []
    for row in data["rows"]:
        name = row["original"]["id"]
        if name not in SELECTED:
            continue
        for a in ("fifo", "constructors", "equality", "both", "learned-47"):
            run = row["runs"][a]
            found = run["status"] == "PROVED"
            status = "Proved" if found else "Open at " + run["stop"].replace("_", " ") + " limit"
            fields = "".join(f'<td>{run["counts"].get(k, 0):,}</td>'
                             for k in ("resolutions", "function_probes", "constructor_probes", "equality_clause_visits"))
            output.append(f'<tr><th scope="row">{escape(name)}<small>{LABEL[a]}</small></th>'
                          f'<td class="{"found" if found else "open"}">{status}</td>{fields}</tr>')
    return "".join(output)


def unit_equalities(proof):
    for i, row in enumerate(proof, 1):
        if len(row["clause"]) == 1:
            sign, atom = row["clause"][0]
            if atom[0] == "=Nat":
                yield i, sign, atom[1], atom[2]


def chain_view(proof):
    units = list(unit_equalities(proof))
    _, _, a, b = next(row for row in units if not row[1])
    graph = defaultdict(list)
    for i, sign, x, y in units:
        if sign and {x, y} != {a, b}:
            graph[x].append((y, i))
            graph[y].append((x, i))
    seen, pending = {a: None}, deque((a,))
    while b not in seen:
        x = pending.popleft()
        for y, i in graph[x]:
            if y not in seen:
                seen[y] = x, i
                pending.append(y)
    route = []
    v = b
    while v != a:
        u, line = seen[v]
        route.append((u, v, line))
        v = u
    route.reverse()
    html = [f'<div class="term">{math(expression(a))}</div>']
    for _, v, line in route:
        html.append(f'<div class="arrow">{math(r"\;=\;")}<small>record {line}</small></div>'
                    f'<div class="term">{math(expression(v))}</div>')
    return '<div class="chain" role="region" tabindex="0" aria-label="Equal terms in the searched proof">' + "".join(html) + "</div>"


def square_row(receipt, types):
    point = receipt["checkpoints"][-1]
    shapes = []
    for i, tile in enumerate(freeze(point["row"])):
        j = types.setdefault(tile, len(types))
        shapes.append(f'<use href="#wang-{j}" x="{i*36}"/>')
    return (f'<figure><svg role="img" aria-label="Nine checked Wang squares" viewBox="0 0 324 36">'
            f'{"".join(shapes)}</svg><figcaption>Local verifier row {point["step"]+1:,}. '
            f'Hover for exact edge labels.</figcaption></figure>')


def proof_view(row, expanded, bank, types):
    original = row["original"]
    proof = freeze(row["runs"]["both"]["proof"])
    steps = []
    for i, (line, strip) in enumerate(zip(proof, expanded["diagram"]["strips"], strict=True), 1):
        receipts = bank[fingerprint(strip)]
        steps.append(f'<li><div class="formula">{math(clause(line["clause"]))}</div>'
                     f'<p>{explanation(line)}</p><details><summary>Show this record’s Wang squares</summary>'
                     f'{square_row(receipts, types)}</details></li>')
    title = "Zero on the left" if original["id"] == SELECTED[0] else "Successor on the left"
    premises = "".join(f'<li>{math(formula(p))}</li>' for p in original["premises"])
    return (f'<article class="example"><h3>{title}</h3>{chain_view(proof)}'
            f'<details><summary>Read the given formulas</summary><ul class="formula">{premises}</ul>'
            f'<p class="formula">{math(formula(original["goal"]))}</p></details>'
            f'<details class="proof" open><summary>Read all {len(proof)} primitive proof records</summary>'
            f'<ol class="steps">{"".join(steps)}</ol></details></article>')


def main():
    data = read("data/persistent-equality-v1.json")
    replay = read("data/equality-diagrams-v1.json.gz")
    rows = {row["original"]["id"]: row for row in data["rows"]}
    types = {}
    examples = "".join(proof_view(rows[name], replay["proofs"][replay["calls"][name + "/both"]],
                                  replay["bank"], types) for name in SELECTED)
    example = rows["successor-left-step"]["runs"]["both"]["constructor_example"]
    assert example is not None
    bindings = "".join(f'<li>{math(expression(k) + r"\mapsto " + expression(v))}</li>'
                       for k, v in example["bindings"].items())
    values = dict(title=TITLE, stem=NAME, summary=summary(data), detail=detailed(data), examples=examples,
                  observed=math(expression(example["observed"])), pattern=math(expression(example["pattern"])),
                  bindings=bindings, runs=str(replay["successful_runs"]), distinct=str(replay["distinct_proofs"]),
                  palette='<svg class="palette" width="0" height="0" aria-hidden="true"><defs>'
                          + "".join(tile_svg(t, i) for t, i in types.items()) + "</defs></svg>")
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    head = head.replace("</style>", """
.palette{position:absolute;width:0;height:0;overflow:hidden;border:0}
td small,th small{display:block;color:#42606f}.formula{overflow:auto}
.steps li>p{overflow:auto}.steps li{padding:.4rem .15rem;border-bottom:1px solid #d5e2e7}
.example{margin-top:1.4rem}.steps figure{max-width:30rem}
.chain{display:flex;gap:.5rem;align-items:center;overflow:auto;padding:.65rem 0}
.chain .term{padding:.7rem;background:#daf0e3;border:1px solid #9dc6ae;border-radius:.3rem;flex-shrink:0}
.chain .arrow{min-width:4rem;text-align:center;flex-shrink:0}.chain small{display:block;color:#42606f}
.found{color:#14614b}.open{color:#795920}
</style>""")
    body = (ROOT / "publication/equality-body-v1.html").read_text()
    for k, v in values.items():
        body = body.replace("%%" + k.upper() + "%%", v)
    assert "%%" not in body
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
