Share equal terms while searching for a proof

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/equality_study_v1.py
  python3 -I -S -B source/equality_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The first command repeats all search runs and countermodel checks.
The second recompiles and replays all distinct marked diagrams. Add
--build to either command to regenerate its corresponding data file.
The last command regenerates the reader. Frozen learned policies were
trained in the earlier donor-only experiment. They are not retrained here.
The manifest gives SHA-256 for each included input and result.
