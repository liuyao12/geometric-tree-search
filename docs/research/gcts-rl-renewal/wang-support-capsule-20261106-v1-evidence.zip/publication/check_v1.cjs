const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {pathToFileURL} = require("node:url");

async function main() {
  const {chromium} = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"]});
  try {
    const page = await browser.newPage({viewport: {width: 1120, height: 900}});
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-support-capsule-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, {waitUntil: "commit"});
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForSelector("#binary mjx-container");
    await page.locator("#binary summary").click();
    assert.equal(await page.locator("#binary tbody tr:visible").count(), 7);
    assert.equal(await page.locator("#lemma svg use").count(), 45);
    assert.equal(await page.locator("#binary svg use").count(), 45);
    assert.equal(await page.locator("#binary .geometry circle").count(), 1);
    assert.equal(await page.locator("#proof tbody tr").count(), 19);
    assert.equal(await page.locator("#online tbody tr").count(), 3);
    assert.equal(await page.locator("#online svg .memory").count(), 3);
    assert.equal(await page.locator("#replay a").count(), 4);
    assert(await page.evaluate(() => {
      const ids = [...document.querySelectorAll("[id]")].map(e => e.id);
      return ids.length === new Set(ids).size;
    }));
    if (!process.argv[2]) await page.locator("#binary").screenshot({path: path.join(__dirname, "binary-geometry-v1.png")});
    await page.setViewportSize({width: 390, height: 844});
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.deepEqual(errors, []);
    const result = {status:"CHECKED_SCHEMA_READER", proofs:[7,19], wangSquares:[45,45],
      inventoryStreams:3, mathTypeset:true, mobileNoOverflow:true};
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(result, null, 2) + "\n");
    console.log(JSON.stringify(result));
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
