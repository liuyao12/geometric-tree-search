"""Reproduce the checked reusable-lemma results and the visual reader."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
STEM = "wang-support-capsule-20261106-v1"
STAGES = ("source/cascade_capsule_v1.py", "source/binary_schema_v1.py",
          "source/online_cascade_v1.py", "publication/render_v1.py")
SCHEMAS = ("support-schema", "binary-schema")
OUTPUTS = tuple(f"wang/input/{n}-v1.json" for n in SCHEMAS) + tuple(
    f"wang/data/{n}-{kind}-v1.json" for n in SCHEMAS for kind in ("wang", "logical")) + (
    "data/cascade-capsule-v1.json", "data/binary-schema-v1.json",
    "data/online-cascade-v1.json", f"report/{STEM}.html")


def inputs():
    sources = sorted(str(p.relative_to(ROOT)) for d in ("source", "wang/source", "publication")
                     for p in (ROOT / d).glob("*.py"))
    return (*sources, "publication/notebook-v1.html", "input/exact-point-model-v1.json",
            "input/turtle-boundaries-v1.json", "data/cascade-runtime-v1.json",
            "data/capsule-controls-v1.json", "data/online-timing-v1.json", "data/online-matched-v1.json")


def main():
    retained = inputs()
    hashes = {}
    with TemporaryDirectory() as temp:
        clean = Path(temp)
        for path in (*retained, *OUTPUTS):
            (clean / path).parent.mkdir(parents=True, exist_ok=True)
        for path in retained:
            shutil.copyfile(ROOT / path, clean / path)
        for stage in STAGES:
            subprocess.run([sys.executable, "-I", "-S", "-B", stage], cwd=clean, check=True)
        for path in OUTPUTS:
            expected, actual = (ROOT / path).read_bytes(), (clean / path).read_bytes()
            assert actual == expected, path
            hashes[path] = sha256(actual).hexdigest()
    receipt = {"status": "CHECKED_CLEAN_REPLAY", "sha256": hashes}
    (ROOT / "publication/replay-v1.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
    print("Matched", len(hashes), "outputs byte for byte.")


if __name__ == "__main__":
    main()
