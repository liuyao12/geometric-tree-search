# Replay the shared Wang inference notebook

Use CPython 3.12 from the extracted archive root.

```sh
python3.12 -I -S -B publication/replay_v1.py
```

The replay reconstructs the full and compact proof certificates, composes both lemmas, runs the three online inventory streams, and rebuilds the HTML. It checks ten outputs byte for byte against the retained copies. The timing receipts are retained as inputs for this deterministic replay.

Repeat the timing measurements separately. Wall-clock times depend on the machine.

```sh
python3.12 -I -S -B source/capsule_controls_v1.py
python3.12 -I -S -B source/online_timing_v1.py
python3.12 -I -S -B source/online_matched_v1.py
```

To check the seven-line proof independently, run the following from `wang`.

```sh
python3.12 -I -S -B source/shared_wang_v1.py verify input/binary-schema-v1.json data/binary-schema-wang-v1.json
python3.12 -I -S -B source/logical_records_cli_v1.py verify input/binary-schema-v1.json data/binary-schema-logical-v1.json
```

The composition checker verifies each logical use against the admitted lemma. The geometric binder checks each actual tile domain and exterior witness before handing its obligations to the logical checker.
