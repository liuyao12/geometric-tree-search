"""Package the verified notebook and its replay evidence."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
from replay_v1 import OUTPUTS, ROOT, STEM, inputs


def read(path):
    return json.loads((ROOT / path).read_text())


def save(path, obj):
    (ROOT / path).write_text(json.dumps(obj, sort_keys=True, indent=2) + "\n")


def pin(raw):
    return dict(bytes=len(raw), sha256=sha256(raw).hexdigest())


def main():
    replay = read("publication/replay-v1.json")
    assert set(replay["sha256"]) == set(OUTPUTS)
    assert all(pin((ROOT / p).read_bytes())["sha256"] == h for p, h in replay["sha256"].items())
    binary, four, online = (read(f"data/{name}-v1.json") for name in
                            ("binary-schema", "cascade-capsule", "online-cascade"))
    result = f"report/{STEM}-results.json"
    save(result, dict(schema="WANG-SUPPORT-CAPSULE-RESULTS-v1", replay=replay,
        browser=read("publication/browser-v1.json"),
        binary=dict(receipt=binary["receipt"], cases=Counter(r["model"] for r in binary["cases"]),
                    root_arities=binary["root_arities"], digest=binary["digest"]),
        four=dict(receipt=four["receipt"], cases=len(four["cases"]), schema=four["schema"]),
        online={**online, "results": {name: {k:v for k,v in row.items() if k!="steps"}
                                       for name,row in online["results"].items()}},
        symbolic_control=read("data/capsule-controls-v1.json")["metrics"],
        timing=read("data/online-timing-v1.json"), matched=read("data/online-matched-v1.json")))
    paths = (*inputs(), *OUTPUTS, result, "publication/REPLAY.md", "publication/check_v1.cjs",
             "publication/browser-v1.json", "publication/replay-v1.json", "publication/binary-geometry-v1.png")
    archive = ROOT / f"report/{STEM}-evidence.zip"
    manifest = {}
    with ZipFile(archive, "w") as bundle:
        for path in paths:
            raw = (ROOT / path).read_bytes()
            assert path not in manifest
            if not path.endswith(".png"):
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), path
            manifest[path] = pin(raw)
            info = ZipInfo(path, (2026, 11, 6, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {name: pin(bundle.read(name)) for name in bundle.namelist()} == manifest
    assets = [archive, ROOT / result, ROOT / f"report/{STEM}.html"]
    save(f"report/{STEM}-manifest.json",
         dict(schema="WANG-SUPPORT-CAPSULE-MANIFEST-v1", archive_entries=manifest,
              assets={path.name: pin(path.read_bytes()) for path in assets}))
    print("Packaged", len(manifest), "evidence files.")


if __name__ == "__main__":
    main()
