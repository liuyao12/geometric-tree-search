"""Render the reusable logical rule and its checked composition results."""
from collections import Counter
from html import escape
from math import sqrt
from pathlib import Path
from statistics import median
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
sys.path.insert(0, str(ROOT / "publication"))
sys.path.append(str(ROOT / "wang/source"))
from boundary_kernel_v1 import build
from cascade_wang_v1 import frozen
from geometry_v1 import Turtle
from proof_views_v1 import clause, explanation, formula, frame_window, math, tile_svg


def read(path):
    return json.loads((ROOT / path).read_text())


def rows(values):
    return "".join("<tr>" + "".join(f"<td>{value}</td>" for value in row) + "</tr>" for row in values)


def wang_view(bundle, prefix):
    machine = build().compile()
    assert machine.digest() == bundle["machine_sha256"]
    last = bundle["traces"][bundle["calls"][-1]["fragment"]]
    frame = dict(prefix=last["prefix"], word=last["word"], padding=0, trace=last["fragment"])
    window, _ = frame_window(machine, frame, last["steps"]-5, last["head"])
    palette, cells = {}, []
    for y, row in enumerate(window):
        for x, tile in enumerate(row):
            n = palette.setdefault(tile, len(palette))
            cells.append(f'<use href="#wang-{prefix}-{n}" x="{36*x}" y="{36*y}"/>')
    defs = "".join(tile_svg(tile, f"{prefix}-{n}") for tile, n in palette.items())
    return (f'<figure><svg viewBox="0 0 324 180" role="img" aria-label="Actual Wang squares">'
            f'<defs>{defs}</defs>{"".join(cells)}</svg>'
            '<figcaption>Five actual verifier transitions at the end of the shared proof.</figcaption></figure>')


def turtle_view(study):
    selected = next(r for r in study["cases"] if r["model"] == "turtle" and r["root_alternatives"] == 16)
    g = Turtle(read("input/exact-point-model-v1.json"))
    tile, witness = frozen(selected["exterior"][0])
    assert witness[0] == "site"
    scale = g.model.scale

    def project(p):
        return p[0] + p[1]/2, -sqrt(3)*p[1]/2

    shapes = [tuple(map(project, selected["ring"])), tuple(map(project, g.poly(tile))),
              tuple(map(project, selected["edge"]))]
    site = project(tuple(v/scale for v in witness[1]))
    pts = [p for shape in shapes for p in shape] + [site]
    x, y = zip(*pts)
    w, h = max(x)-min(x), max(y)-min(y)
    pad = .08 * max(w,h)
    box = f"{min(x)-pad:.5f} {min(y)-pad:.5f} {w+2*pad:.5f} {h+2*pad:.5f}"

    def points(shape):
        return " ".join(f"{a:.5f},{b:.5f}" for a,b in shape)

    dot = max(w,h)*.016
    return (f'<figure><svg viewBox="{box}" class="geometry" role="img" aria-label="Turtle receptor and an exterior site">'
            f'<polygon points="{points(shapes[0])}" class="target"/>'
            f'<polygon points="{points(shapes[1])}" class="offer"/>'
            f'<polyline points="{points(shapes[2])}" class="port"/>'
            f'<circle cx="{site[0]:.5f}" cy="{site[1]:.5f}" r="{dot:.5f}" class="excluded"/>'
            '</svg><figcaption>A Turtle option in orange reaches the red exterior site. '
            'The root domain has 16 independently enumerated placements.</figcaption></figure>')


def inventory_view(online, timing, runtime):
    labels = {"by_family": "Grouped by family", "mixed": "Mixed by shape hash",
              "reverse_mixed": "Reverse mixed order"}
    aliases = {"by_family": "grouped", "mixed": "mixed"}
    family = {r["id"]: r["family"] for r in runtime["results"]}
    baseline = online["fresh_tile_states"]
    metrics = []
    bars = ['<svg class="bars" viewBox="0 0 710 168" role="img" aria-label="Fresh support states per stream">']
    for i, (name, label) in enumerate(labels.items()):
        cohort = online["results"][name]
        states = cohort["work"]["tile_states"]
        cross = sum(s["source"] == "memory" and family[s["id"]] != family[s["donor"]]
                    for s in cohort["steps"])
        values = timing["timings"].get(aliases.get(name))
        seconds = "—" if values is None else f'{median(values["online_ns"])/1e9:.2f} / {median(values["fresh_ns"])/1e9:.2f}'
        metrics.append((label, cohort["counts"]["memory"], cohort["counts"]["fresh"], cross,
                        f"{states:,}", seconds))
        y = 17 + 50*i
        bars.append(f'<text x="10" y="{y+17}">{label}</text>')
        bars.append(f'<rect x="192" y="{y}" width="390" height="23" rx="4" class="baseline"/>')
        bars.append(f'<rect x="192" y="{y}" width="{390*states/baseline:.2f}" height="23" rx="4" class="memory"/>')
        bars.append(f'<text x="600" y="{y+17}">{states:,}</text>')
    bars.append("</svg>")
    return rows(metrics), "".join(bars), f"{baseline:,}"


def main():
    generic = read("wang/input/support-schema-v1.json")
    bundle = read("wang/data/support-schema-wang-v1.json")
    compositions = read("data/cascade-capsule-v1.json")
    controls = read("data/capsule-controls-v1.json")
    cross = read("data/binary-schema-v1.json")
    binary = read("wang/data/binary-schema-wang-v1.json")
    online, bars, fresh = inventory_view(read("data/online-cascade-v1.json"),
        read("data/online-timing-v1.json"), read("data/cascade-runtime-v1.json"))
    matched = read("data/online-matched-v1.json")
    geometry_only, with_wang = (median(matched["times"][arm])/1e9
                               for arm in ("geometry", "geometry_with_wang"))
    cross_counts = Counter(row["model"] for row in cross["cases"])
    names = {"donor-edits": "Donor-family edits", "new-family-1": "Other family A", "new-family-3": "Other family B"}
    cohort = Counter(row["family"] for row in compositions["cases"])
    metrics = rows((names[name], cohort[name], f'{x["fresh_records"]:g}', f'{x["local_steps"]:g}',
                    f'{x["fresh_ns"]/1e6:.2f}', f'{x["reuse_ns"]/1e6:.2f}', f'{x["geometry_ns"]/1e6:.2f}')
                   for name, x in controls["metrics"].items())
    hypotheses = "".join(f"<li>{math(formula(row))}</li>" for row in generic["premises"])
    proof = rows((i, explanation(r), math(clause(r["clause"])))
                 for i, r in enumerate(bundle["proof"]["lines"], 1))
    applications = sum(step["op"] == "apply" for r in compositions["cases"] for step in r["trace"]["steps"])
    binary_lines = rows((i, explanation(r), math(clause(r["clause"])))
                        for i, r in enumerate(binary["proof"]["lines"], 1))
    template = (ROOT / "publication/notebook-v1.html").read_text()
    fields = dict(METRICS=metrics, HYPOTHESES=hypotheses, PROOF=proof, WANG=wang_view(bundle, "four"),
                  TURTLE=turtle_view(cross), BINARY_WANG=wang_view(binary, "two"), BINARY_PROOF=binary_lines,
                  TURTLE_CASES=cross_counts["turtle"], PENROSE_CASES=cross_counts["penrose"],
                  APPLICATIONS=f"{applications:,}", GOAL=math(formula(generic["goal"])),
                  ONLINE=online, ONLINE_BARS=bars, FRESH_STATES=fresh,
                  GEOMETRY_ONLY=f"{geometry_only:.2f}", WITH_WANG=f"{with_wang:.2f}")
    for key, value in fields.items():
        template = template.replace(f"%%{key}%%", str(value))
    assert "%%" not in template
    (ROOT / "report/wang-support-capsule-20261106-v1.html").write_text(template)


if __name__ == "__main__":
    main()
