"""Isolate geometric reuse from the cost of carrying a symbolic certificate."""
from pathlib import Path
import json
from statistics import median
import sys
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from binary_schema_v1 import BinaryLemma
from boundary_search_v1 import Inventory
from cascade_runtime_v1 import load
from cascade_timing_v1 import clear
from cascade_wang_v1 import save
from geometry_v1 import Penrose
from online_cascade_v1 import route


def signature(batch):
    return tuple((x["id"], x["source"], x["status"], x.get("donor"), x.get("binding"))
                 for x in batch["steps"])


def main():
    g = Penrose()
    inv = Inventory(g)
    lemma = BinaryLemma(json.loads((ROOT / "wang/input/binary-schema-v1.json").read_text()),
        json.loads((ROOT / "wang/data/binary-schema-logical-v1.json").read_text()))
    rows = sorted(load("data/cascade-runtime-v1.json")["results"], key=lambda r: r["shape"])
    timings = {"geometry": [], "geometry_with_wang": []}
    for i in range(3):
        arms = (("geometry", None), ("geometry_with_wang", lemma))
        results = {}
        for name, extra in arms if i % 2 else reversed(arms):
            clear()
            start = perf_counter_ns()
            results[name] = route(g, inv, extra, rows)
            timings[name].append(perf_counter_ns() - start)
        assert signature(results["geometry"]) == signature(results["geometry_with_wang"])
        assert results["geometry"]["counts"] == results["geometry_with_wang"]["counts"]
        print("matched decisions, repeat", i + 1, flush=True)
    save("data/online-matched-v1.json", dict(status="MATCHED_GEOMETRIC_CONTROL", repeats=3,
        cases=len(rows), times=timings, counts=results["geometry"]["counts"],
        steps=results["geometry_with_wang"]["work"]["composition_steps"]))
    print({k: round(median(v)/1e9, 3) for k,v in timings.items()}, flush=True)


if __name__ == "__main__":
    main()
