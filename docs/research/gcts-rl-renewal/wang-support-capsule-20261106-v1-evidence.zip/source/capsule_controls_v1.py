"""Compare a shared inference lemma with fresh symbolic proof search."""
from collections import defaultdict
from pathlib import Path
import json
from statistics import median
import sys
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cascade_capsule_v1 import Capsule, compose, frozen, pins, problem, save
from definitions_v1 import compile_case
from fair_ground_v1 import search
from geometry_v1 import Penrose


def read(path):
    return json.loads((ROOT / path).read_text())


def duration(call):
    start = perf_counter_ns()
    value = call()
    return value, perf_counter_ns() - start


def main():
    capsule = Capsule(read("wang/input/support-schema-v1.json"),
                      read("wang/data/support-schema-logical-v1.json"))
    prior = read("data/cascade-capsule-v1.json")
    claims = {r["id"]: r for r in prior["cases"]}
    g = Penrose()
    data = frozen(read("data/cascade-runtime-v1.json"))["results"]
    checked = []
    for row in data:
        if row["id"] not in claims:
            continue
        evidence = row["arms"]["depth-two"]["proof"]
        (source, names), geometry_ns = duration(lambda: problem(g, row["rings"], evidence))
        assert pins(source) == claims[row["id"]]["source"]
        def fresh():
            normal, _ = compile_case(source)
            result = search(normal, maximum_depth=0)
            assert result["status"] == "PROVED"
            return len(result["proof"]["lines"])

        def cluster():
            combined = compose(source, names, evidence, capsule)
            return capsule.check(source, combined)

        if len(checked) % 2:
            fresh_lines, fresh_ns = duration(fresh)
            reuse_lines, reuse_ns = duration(cluster)
        else:
            reuse_lines, reuse_ns = duration(cluster)
            fresh_lines, fresh_ns = duration(fresh)
        checked.append(dict(id=row["id"], family=row["family"], geometry_ns=geometry_ns,
                            fresh_ns=fresh_ns, reuse_ns=reuse_ns, fresh_records=fresh_lines,
                            local_steps=reuse_lines, applications=sum(s["op"]=="apply" for s in claims[row["id"]]["trace"]["steps"])))
    assert len(checked) == len(claims) == 149
    grouped = defaultdict(list)
    for row in checked:
        grouped[row["family"]].append(row)
    metrics = ("geometry_ns", "fresh_ns", "reuse_ns", "fresh_records", "local_steps", "applications")
    summary = {name: {k: median(row[k] for row in rows) for k in metrics} for name, rows in grouped.items()}
    save("data/capsule-controls-v1.json", dict(status="CHECKED_FRESH_SYMBOLIC_CONTROL",
         metrics=summary, cases=checked, receipt=capsule.receipt))
    print(json.dumps(summary, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
