"""Share one symbolic elimination proof across Turtle and Penrose tile domains."""
from copy import deepcopy
from functools import reduce
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from boundary_search_v1 import Inventory, Region
from cascade_capsule_v1 import atom, denied, pins
from cascade_wang_v1 import frozen, problem, save
from definitions_v1 import compile_case
from fair_ground_v1 import search
from geometry_v1 import Penrose, Turtle, sub
from logical_projection_v1 import projection
from logical_projection_v1 import verify as verify_records
from shared_wang_v1 import attach, verify_certificate


def read(path):
    return json.loads((ROOT / path).read_text())


def theorem():
    a, b = atom("A"), atom("B")
    return dict(id="binary-support-elimination", equality=False, sorts=["U"], functions={},
                predicates={"A": [], "B": []}, premises=[["or", a, b], ["not", a]], goal=b)


def clause(parent, children):
    return reduce(lambda tail, name: ["or", atom(name), tail], reversed(children), denied(parent))


class BinaryLemma:
    def __init__(self, original, logical):
        assert original == theorem()
        self.receipt = verify_records(original, logical)
        self.digest = pins([original, logical])

    def check(self, source, certificate):
        assert certificate["lemma"] == self.digest
        established = []
        for row in certificate["steps"]:
            if row["op"] == "premise":
                index = row["index"]
                assert type(index) is int and 0 <= index < len(source["premises"])
                fact = source["premises"][index]
            else:
                assert row["op"] == "eliminate"
                i, j = row["use"]
                assert all(type(x) is int and 0 <= x < len(established) for x in (i, j))
                head, left, fact = established[i]
                assert head == "or" and established[j] == ["not", left]
            established.append(fact)
        assert established and established[-1] == source["goal"]
        return len(established)


class Composition:
    def __init__(self, lemma):
        self.premises, self.steps = [], []
        self.copied = {}
        self.lemma = lemma

    def premise(self, fact):
        key = pins(fact)
        if key not in self.copied:
            self.copied[key] = len(self.steps)
            self.steps.append(dict(op="premise", index=len(self.premises)))
            self.premises.append(fact)
        return self.copied[key]

    def discharge(self, parent, children, failures):
        left = self.premise(clause(parent, children))
        for denied_child in failures:
            self.steps.append(dict(op="eliminate", use=(left, denied_child)))
            left = len(self.steps) - 1
        return left

    def finish(self):
        source = dict(premises=self.premises, goal=denied("Cover"))
        proof = dict(lemma=self.lemma.digest, steps=self.steps)
        return source, proof


def flatten(formula):
    if formula[0] == "atom":
        return (formula[1],)
    assert formula[0] == "or"
    return (*flatten(formula[1]), *flatten(formula[2]))


def convert_premise(fact):
    if fact[0] == "not":
        assert fact[1][0] == "atom"
        return fact
    assert fact[0] == "implies" and fact[1][0] == "atom"
    return clause(fact[1][1], flatten(fact[2]))


def compose_penrose(g, rings, evidence, lemma):
    original, names = problem(g, rings, evidence)
    name = {t: symbol for symbol, t in names.items()}
    symbols = tuple(name[r["tile"]] for r in evidence["nodes"])
    builder = Composition(lemma)
    rejected = []
    for label, node in zip(symbols, evidence["nodes"], strict=True):
        if node["kind"] == "outside":
            i = builder.premise(denied(label))
        else:
            chosen = node["children"]
            i = builder.discharge(label, tuple(symbols[j] for j in chosen), tuple(rejected[j] for j in chosen))
        rejected.append(i)
    chosen = evidence["children"]
    builder.discharge("Cover", tuple(symbols[j] for j in chosen), tuple(rejected[j] for j in chosen))
    source, proof = builder.finish()
    assert source["goal"] == original["goal"]
    assert {pins(p) for p in source["premises"]} == {pins(convert_premise(p)) for p in original["premises"]}
    return original, source, proof


def penrose(lemma):
    g = Penrose()
    study = frozen(read("data/cascade-runtime-v1.json"))
    for row in study["results"]:
        arm = row["arms"]["depth-two"]
        if arm["origin"] != "cascade":
            continue
        evidence = arm["proof"]
        _, source, proof = compose_penrose(g, row["rings"], evidence, lemma)
        yield dict(model="penrose", case=row["id"], scope=row["family"], source=source,
                   proof=proof, root_alternatives=len(evidence["children"]))


def turtle_root(g, inv, region):
    for a, b in sorted(region.edges):
        edge = a, b
        expected = {g.shift(pose, sub(a, start)) for pose in g.bases
                    for start, end in g.boundary(pose) if sub(end, start) == sub(b, a)}
        declared = {tile for tile, in inv.at(edge)}
        assert declared == expected and expected
        rejected = []
        for tile in sorted(expected):
            witness = region.exterior(tile)
            if witness is None:
                break
            region.certify(tile, witness, frozenset())
            rejected.append((tile, witness))
        else:
            return edge, rejected
    return None


def turtle(lemma):
    g = Turtle(read("input/exact-point-model-v1.json"))
    inv = Inventory(g)
    data = frozen(read("input/turtle-boundaries-v1.json"))["turtle"]
    for positive in data["positives"]:
        region = Region(g, positive["rings"])
        g.verify(positive["rings"], positive["patch"])
        assert turtle_root(g, inv, region) is None
    for row in (*data["receivers"], *data["perturbations"]):
        region = Region(g, (row["ring"],))
        receptor = turtle_root(g, inv, region)
        if receptor is None:
            continue
        edge, alternatives = receptor
        builder = Composition(lemma)
        names = tuple(f"X{i + 1:02d}" for i in range(len(alternatives)))
        failures = tuple(builder.premise(denied(name)) for name in names)
        builder.discharge("Cover", names, failures)
        source, proof = builder.finish()
        yield dict(model="turtle", case=row["case"], scope="fixed-boundary",
                   source=source, proof=proof, root_alternatives=len(alternatives),
                   ring=row["ring"], edge=edge, exterior=alternatives)


def main():
    original = theorem()
    normal, translation = compile_case(original)
    result = search(normal, maximum_depth=0)
    assert result["status"] == "PROVED"
    full = attach(original, "fol", normal, translation, result["proof"])
    verify_certificate(original, full)
    compact = projection(full)
    lemma = BinaryLemma(original, compact)
    save("wang/input/binary-schema-v1.json", original)
    save("wang/data/binary-schema-wang-v1.json", full)
    save("wang/data/binary-schema-logical-v1.json", compact)
    cases = [*penrose(lemma), *turtle(lemma)]
    for row in cases:
        row["checked_steps"] = lemma.check(row["source"], row["proof"])
    wrong = deepcopy(cases[0]["proof"])
    wrong["steps"][-1]["use"] = (wrong["steps"][-1]["use"][0], 0)
    try:
        lemma.check(cases[0]["source"], wrong)
    except AssertionError:
        pass
    else:
        raise AssertionError("Wrong support failure accepted")
    counts = {model: sorted({r["root_alternatives"] for r in cases if r["model"] == model})
              for model in ("turtle", "penrose")}
    save("data/binary-schema-v1.json", dict(status="CHECKED_CROSS_PALETTE_COMPOSITION",
         receipt=lemma.receipt, digest=lemma.digest, root_arities=counts, cases=cases))
    print(lemma.receipt, len(cases), "cases", counts, flush=True)


if __name__ == "__main__":
    main()
