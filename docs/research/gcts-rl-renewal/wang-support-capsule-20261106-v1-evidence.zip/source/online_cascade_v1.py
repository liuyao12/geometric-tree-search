"""Learn an inventory from the search stream using a checked logical rule."""
from collections import Counter
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from binary_schema_v1 import BinaryLemma, compose_penrose
from boundary_search_v1 import Inventory, Region
from cascade_bank_v1 import CascadeBank, boundary_index
from cascade_runtime_v1 import load, plain
from cascade_wang_v1 import problem, save
from geometry_v1 import Penrose
from support_cascade_v1 import find

CAPACITY = 12


class LearnedMark(CascadeBank):
    def __init__(self, region, evidence, lemma):
        if lemma is None:
            original, _ = problem(region.g, region.rings, evidence)
            self.records = 0
        else:
            original, source, proof = compose_penrose(region.g, region.rings, evidence, lemma)
            self.records = lemma.check(source, proof)
        self.prepare(region, evidence, original)


def route(g, inv, lemma, rows):
    bank = {}
    offers = []
    audits = []
    for row in rows:
        region = Region(g, row["rings"])
        name = row["id"]
        work = Counter()
        index = boundary_index(region, "indexed")
        for donor, mark in reversed(bank.items()):
            work["mark_queries"] += 1
            binding, spent = mark.probe(region, "indexed", index)
            work.update(spent)
            if binding is not None:
                audits.append((row["rings"], mark, binding))
                bank[donor] = bank.pop(donor)
                answer = dict(id=name, source="memory", donor=donor, status="NEGATIVE",
                              work=work, binding=binding)
                break
        else:
            evidence, spent = find(region, inv, 2)
            work.update(spent)
            if evidence:
                mark = LearnedMark(region, evidence, lemma)
                work["composition_steps"] = mark.records
                bank[name] = mark
                if len(bank) > CAPACITY:
                    bank.pop(next(iter(bank)))
                answer = dict(id=name, source="fresh", status="NEGATIVE", work=work)
            else:
                result = plain(g, inv, region, name)
                work.update(result["counts"])
                answer = dict(id=name, source="placement", status=result["status"], work=work)
        assert answer["status"] == row["arms"]["depth-two"]["status"]
        offers.append(answer)
    for rings, mark, binding in audits:
        mark.bind(Region(g, rings), binding)
    work = Counter()
    for row in offers:
        work.update(row["work"])
    counts = Counter(row["source"] for row in offers)
    return dict(counts=counts, work=work, active=list(bank), audited=len(audits), steps=offers)


def main():
    g = Penrose()
    inv = Inventory(g)
    lemma = BinaryLemma(json.loads((ROOT / "wang/input/binary-schema-v1.json").read_text()),
        json.loads((ROOT / "wang/data/binary-schema-logical-v1.json").read_text()))
    rows = load("data/cascade-runtime-v1.json")["results"]
    orders = dict(by_family=rows, mixed=sorted(rows, key=lambda r: r["shape"]),
                  reverse_mixed=sorted(rows, key=lambda r: r["shape"], reverse=True))
    results = {name: route(g, inv, lemma, stream) for name, stream in orders.items()}
    fresh = sum(r["arms"]["depth-two"]["work"].get("tile_states",0) for r in rows)
    save("data/online-cascade-v1.json", dict(status="CHECKED_LEARNED_CASCADE_INVENTORY",
         results=results, fresh_tile_states=fresh, capacity=CAPACITY, shared=lemma.receipt))
    for name, record in results.items():
        print(name, record["counts"], "fresh states", record["work"]["tile_states"], "vs", fresh, flush=True)


if __name__ == "__main__":
    main()
