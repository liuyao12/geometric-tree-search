"""Check fresh geometry with one reusable, source-bound Wang inference lemma."""
from copy import deepcopy
from functools import reduce
from hashlib import sha256
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cascade_wang_v1 import frozen, problem, save
from definitions_v1 import compile_case
from fair_ground_v1 import search
from geometry_v1 import Penrose
from logical_projection_v1 import projection
from logical_projection_v1 import verify as verify_records
from shared_wang_v1 import attach, verify_certificate

SLOTS = ("Parent", "ChildA", "ChildB", "ChildC", "ChildD")


def atom(name):
    return ["atom", name]


def denied(name):
    return ["not", atom(name)]


def requires(parent, children):
    children = [atom(name) for name in children]
    return ["implies", atom(parent), reduce(lambda a, b: ["or", a, b], children)]


def theorem():
    parent, *children = SLOTS
    return dict(id="four-support-elimination", equality=False, sorts=["U"], functions={},
                predicates={name: [] for name in SLOTS},
                premises=[requires(parent, children), *map(denied, children)], goal=denied(parent))


def pins(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class Capsule:
    def __init__(self, source, logical):
        assert source == theorem()
        self.source = source
        self.receipt = verify_records(source, logical)
        self.digest = pins([source, logical])

    def instance(self, names):
        assert len(names) == len(SLOTS)
        bindings = dict(zip(SLOTS, names, strict=True))

        def substitute(formula):
            if formula[0] == "atom":
                return atom(bindings[formula[1]])
            return [formula[0], *map(substitute, formula[1:])]

        return tuple(map(substitute, self.source["premises"])), substitute(self.source["goal"])

    def check(self, source, certificate):
        assert certificate["capsule"] == self.digest
        facts = []
        for row in certificate["steps"]:
            if row["op"] == "premise":
                i = row["index"]
                assert type(i) is int and 0 <= i < len(source["premises"])
                fact = source["premises"][i]
            else:
                assert row["op"] == "apply" and set(row["bind"]) <= set(source["predicates"])
                expected, fact = self.instance(row["bind"])
                use = row["use"]
                assert len(use) == len(expected) and all(type(i) is int and 0 <= i < len(facts) for i in use)
                assert tuple(facts[i] for i in use) == expected
            facts.append(fact)
        assert facts and facts[-1] == source["goal"]
        return len(facts)


def compose(source, names, evidence, capsule):
    seen = {}
    steps = []

    def premise(fact):
        key = pins(fact)
        if key not in seen:
            seen[key] = len(steps)
            steps.append(dict(op="premise", index=source["premises"].index(fact)))
        return seen[key]

    def apply(parent, children):
        bindings = (parent, *(slots[j] for j in children))
        supporting = requires(parent, bindings[1:])
        deps = (premise(supporting), *(proved[j] for j in children))
        steps.append(dict(op="apply", bind=bindings, use=deps))
        return len(steps) - 1

    names = {t: p for p, t in names.items()}
    slots = tuple(names[row["tile"]] for row in evidence["nodes"])
    proved = []
    for name, row in zip(slots, evidence["nodes"], strict=True):
        proved.append(premise(denied(name)) if row["kind"] == "outside" else apply(name, row["children"]))
    apply("Cover", evidence["children"])
    return dict(capsule=capsule.digest, steps=steps)


def assert_rejects(capsule, source, cert):
    mutants = [deepcopy(cert), deepcopy(cert), deepcopy(cert)]
    mutants[0]["steps"][-1]["use"] = mutants[0]["steps"][-1]["use"][:-1]
    mutants[1]["steps"][-1]["use"] = (*mutants[1]["steps"][-1]["use"][:-1], len(cert["steps"]))
    mutants[2]["steps"][-1]["bind"] = ("Cover", *reversed(mutants[2]["steps"][-1]["bind"][1:]))
    for wrong in mutants:
        try:
            capsule.check(source, wrong)
        except AssertionError:
            continue
        raise AssertionError("A corrupted capsule application was accepted")


def main():
    generic = theorem()
    normal, translation = compile_case(generic)
    result = search(normal, maximum_depth=0)
    assert result["status"] == "PROVED"
    full = attach(generic, "fol", normal, translation, result["proof"])
    verify_certificate(generic, full)
    logical = projection(full)
    capsule = Capsule(generic, logical)
    save("wang/input/support-schema-v1.json", generic)
    save("wang/data/support-schema-wang-v1.json", full)
    save("wang/data/support-schema-logical-v1.json", logical)
    g = Penrose()
    cohort = frozen(json.loads((ROOT / "data/cascade-runtime-v1.json").read_text()))
    checked = []
    for row in cohort["results"]:
        arm = row["arms"]["depth-two"]
        if arm["origin"] != "cascade":
            continue
        evidence = arm["proof"]
        source, names = problem(g, row["rings"], evidence)
        trace = compose(source, names, evidence, capsule)
        lines = capsule.check(source, trace)
        checked.append(dict(id=row["id"], family=row["family"], source=pins(source), trace=trace, lines=lines))
        if len(checked) == 1:
            assert_rejects(capsule, source, trace)
    assert len(checked) == 149
    save("data/cascade-capsule-v1.json", dict(status="CHECKED_REUSABLE_CAPSULE", receipt=capsule.receipt,
        schema=capsule.digest, cases=checked, tampered_applications="REJECTED"))
    print(capsule.receipt, "bound to", len(checked), "freshly found cascades", flush=True)


if __name__ == "__main__":
    main()
