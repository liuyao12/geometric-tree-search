"""Apply a reusable proof to an actual sealed pocket with an optional-hole control."""
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from boundary_search_v1 import Inventory, Region
from cascade_bank_v1 import CascadeBank
from cascade_runtime_v1 import load
from cascade_wang_v1 import save
from cavity_cases_v1 import belt, connect, expanded, hull, location, move, move_cycle
from cavity_marks_v1 import CavityBank, required
from cavity_pilot_v1 import residual_faces
from check_v1 import contact
from clipping_v1 import Core
from geometry_v1 import Penrose, area, chain, pairs
from open_cases_v1 import seam_core
from open_cover_v1 import component, solve, verify


def seal(g, inv, ring):
    pocket = Region(g, (ring,))
    domains = []
    for edge in sorted(pocket.edges):
        choices = []
        for t, in inv.at(edge[::-1]):
            center = tuple(map(sum, zip(*t)))
            if g.wind(ring, center, 4) == 0 and not any(g.intrudes(a, b, t) for a, b in pocket.lines):
                choices.append(t)
        assert choices
        domains.append(tuple(choices))
    work = 0

    def search(path, pending):
        nonlocal work
        work += 1
        if work > 5000:
            return None
        if not pending:
            return path
        i = min(range(len(pending)), key=lambda j: len(pending[j]))
        for t in pending[i]:
            rest = [tuple(u for u in choices if t == u or contact(t, u))
                    for j, choices in enumerate(pending) if j != i]
            if all(rest):
                answer = search(path if t in path else (*path, t), rest)
                if answer:
                    return answer
        return None

    rim = search((), domains)
    assert rim
    patch = connect(g, inv, rim, ring)
    assert len(component(g, patch)) == len(patch)
    assert all(contact(t, u) for t, u in combinations(patch, 2))
    for t in patch:
        assert g.wind(ring, tuple(map(sum, zip(*t))), 4) == 0
        assert not any(g.intrudes(a, b, t) for a, b in pocket.lines)
    assert all(e[::-1] in chain(g, patch) for e in pocket.edges)
    return patch, work


class RequiredCascades:
    def __init__(self, bank):
        self.bank = bank
        self.events = []

    def cut(self, region, core, frontier, path, case, stats):
        g = region.g
        for ring in residual_faces(frozenset((b, a) for a, b in frontier)):
            if len(ring) < 3 or len(ring) != len(set(ring)) or g.sign(area(ring, g.cross)) <= 0:
                continue
            try:
                pocket = Region(g, (ring,))
            except AssertionError:
                continue
            # Test coverage before considering the theorem.
            if not required(region, core, ring):
                stats["cascade_optional_faces"] += 1
                continue
            binding, _ = self.bank.probe(pocket, "indexed")
            replacements = ()
            if binding is None:
                binding, replacements, _ = self.bank.repair(pocket)
            if binding:
                self.bank.bind(pocket, binding, replacements)
                assert all(e[::-1] in frontier for e in pocket.edges)
                self.events.append(dict(case=case, ring=ring, binding=binding,
                                        replacements=replacements, placed=len(path)))
                stats["cascade_cuts"] += 1
                return True
        return False


def main():
    data = load("data/cascade-experiment-v1.json")
    edits = load("data/transfer-v1.json")["single_tile_edits"]
    specimen = min(data["examples"], key=lambda row: len(row["proof"]["nodes"]))
    edit = next(r for r in edits if r["reused"])
    g = Penrose()
    inv = Inventory(g)
    bank = CascadeBank(Region(g, specimen["rings"]), specimen["proof"],
        json.loads((ROOT / "wang/input/cascade-v1.json").read_text()),
        json.loads((ROOT / "wang/data/cascade-records-v1.json").read_text()))
    envelope, _ = belt(g, 24, (1, 2, 3, 4) * 6)
    results = []
    for turn, (name, row) in zip((1, 4), (("donor", specimen), ("edited", edit)), strict=True):
        ring, = row["rings"]
        patch, frame_nodes = seal(g, inv, ring)
        delta = location(g, envelope, patch, turn)
        posed = move(g, patch, turn, delta)
        cycle = move_cycle(ring, turn, delta)
        pocket = Region(g, (cycle,))
        assert pocket.counts is not None
        core_input = (expanded(hull(g, cycle)),)
        callback = RequiredCascades(bank)
        records = {}
        for label, marks in (("area", CavityBank(learn=False)), ("proof", callback)):
            core = Core(Region(g, envelope), core_input)
            assert required(core.region, core, cycle)
            records[label] = solve(core, inv, posed[0], name, cap=len(posed) + 26, node_limit=80,
                                   initial=posed[1:], cavities=marks, order="single")
        assert records["area"]["status"] != "POSITIVE"
        assert records["proof"]["status"] == "NEGATIVE" and records["proof"]["counts"]["nodes"] == 1
        assert len(callback.events) == 1
        results.append(dict(case=name, envelope=envelope, core=core_input, frame=posed, cycle=cycle,
                            frame_nodes=frame_nodes, outcomes=records, event=callback.events[0]))
        print(name, [(k, v["status"], v["counts"]["nodes"]) for k, v in records.items()], flush=True)
    outer = Region(g, envelope)
    frontier = chain(g, posed)
    inside_edges = {(b, a) for a, b in pocket.edges}
    options = sorted(frontier - inside_edges)
    optional = None
    for edge in options:
        if not any(outer.block(t, frozenset(posed)) is None for t, in inv.at(edge[::-1])):
            continue
        try:
            core_input = (seam_core(g, envelope, edge, (Fraction(1, 32),)),)
            core = Core(outer, core_input)
        except (AssertionError, ValueError):
            continue
        assert not required(outer, core, cycle)
        callback = RequiredCascades(bank)
        result = solve(core, inv, posed[0], "optional", cap=len(posed) + 1, node_limit=30,
                       initial=posed[1:], cavities=callback, order="single")
        if result["status"] == "POSITIVE":
            verify(core, posed[0], result["patch"], result["areas"], result["boundary"], len(posed) + 1)
            assert not callback.events and result["counts"]["cascade_optional_faces"] >= 1
            optional = dict(envelope=envelope, core=core_input, frame=posed, cycle=cycle, outcome=result)
            break
    assert optional
    print("optional sealed pocket preserved", flush=True)
    save("data/cascade-movable-v1.json", dict(status="CHECKED_REQUIRED_CASCADE", cases=results, optional=optional))


if __name__ == "__main__":
    main()
