"""Train a contextual bandit on checked Penrose search-route rollouts."""
from collections import Counter, defaultdict
from math import log1p
from pathlib import Path
from random import Random
import json

ROOT = Path(__file__).resolve().parents[1]
ACTIONS = ("plain", "renew", "propagate")
ARM = {"plain": "indexed", "renew": "adaptive", "propagate": "depth-two"}
TRIALS = 15


def features(row):
    work = row["arms"]["indexed"]["work"]
    # These counters are known from the common lookup before the action is chosen.
    return (len(row["rings"]) > 1, len(row["rings"][0]) >= 19,
            work.get("line_guards", 0) >= 5,
            bool(work.get("interior_guards")), bool(work.get("center_guards")))


def episode(row, action):
    initial = row["arms"]["indexed"]
    hit = initial["origin"] == "reused"
    arm = initial if hit else row["arms"][ARM[action]]
    lookup = initial["work"]
    work = Counter(placement=arm["counts"].get("placement_checks", 0),
                   fresh=arm["work"].get("tile_states", 0),
                   new_exterior=arm["work"].get("repair_exterior", 0),
                   centers=lookup.get("center_guards", 0))
    penalty = 4000 if arm["status"] == "BOUNDED" else 0
    return arm["status"], work, -log1p(sum(work.values()) + penalty)


class Policy:
    def __init__(self, seed):
        self.random = Random(seed)
        self.sums = defaultdict(float)
        self.counts = Counter()

    def keys(self, state, action):
        return ((action,), (action, *state[:2]), (action, *state))

    def predict(self, state):
        def score(action):
            coarse, medium, fine = self.keys(state, action)
            counts = self.counts
            sums = self.sums
            base = sums.get(coarse, 0.0) / max(1, counts[coarse])
            return (base * 3 + sums.get(medium, 0.0) + 2 * sums.get(fine, 0.0)) / (
                3 + counts[medium] + 2 * counts[fine])
        return max(ACTIONS, key=score)

    def learn(self, rows):
        misses = [r for r in rows if r["arms"]["indexed"]["origin"] != "reused"]
        feedback = 0
        for i in range(TRIALS):
            visit = misses[:]
            self.random.shuffle(visit)
            for row in visit:
                state = features(row)
                if i < 3 or self.random.random() < .25:
                    action = self.random.choice(ACTIONS)
                else:
                    action = self.predict(state)
                _, _, reward = episode(row, action)
                for key in self.keys(state, action):
                    self.counts[key] += 1
                    self.sums[key] += reward
                feedback += 1
        return feedback


def best_static(rows):
    return max(ACTIONS, key=lambda a: sum(episode(r, a)[2] for r in rows))


def assess(train, test, name, seed):
    policy = Policy(seed)
    updates = policy.learn(train)
    static = best_static(train)
    runs = []
    total = {}
    for row in test:
        selected = policy.predict(features(row))
        proposals = {a: a for a in ACTIONS} | {"trained-static": static, "learned": selected}
        outcome = {}
        for label, action in proposals.items():
            status, cost, reward = episode(row, action)
            baseline_positive = row["arms"]["baseline"]["status"] == "POSITIVE"
            assert (status == "POSITIVE") == baseline_positive
            outcome[label] = dict(action=action, status=status, counts=cost, reward=reward)
            scores = total.setdefault(label, Counter())
            scores.update(cost)
            scores[status.lower()] += 1
            scores["action:" + action] += 1
        runs.append(dict(id=row["id"], state=features(row), outcomes=outcome))
    return dict(name=name, train=[r["id"] for r in train], test=[r["id"] for r in test], updates=updates,
                trained_static=static, totals=total, runs=runs)


def main():
    data = json.loads((ROOT / "data/cascade-runtime-v1.json").read_text())
    rows = data["results"]
    by_family = defaultdict(list)
    for row in rows:
        by_family[row["family"]].append(row)
    folds = [[], [], []]
    for group in by_family.values():
        for i, row in enumerate(sorted(group, key=lambda r: r["shape"])):
            folds[i % len(folds)].append(row)
    stratified = [assess([r for j, fold in enumerate(folds) if j != i for r in fold], test,
                         f"shape-fold-{i + 1}", 235 + i) for i, test in enumerate(folds)]
    family = [assess([r for r in rows if r["family"] != name], test, name, 219 + i)
              for i, (name, test) in enumerate(by_family.items())]
    assert all(set(r["train"]).isdisjoint(r["test"]) for r in (*stratified, *family))
    answer = dict(status="CHECKED_BANDIT_REPLAY", reward="negative log of exact checks plus bound penalty",
                  reports=stratified + family)
    (ROOT / "data/route-bandit-v1.json").write_text(json.dumps(answer, sort_keys=True, separators=(",", ":")) + "\n")
    for item in answer["reports"]:
        print(item["name"], {name: (sum(v[k] for k in ("placement", "fresh", "new_exterior", "centers")),
                                             v["bounded"]) for name, v in item["totals"].items()}, flush=True)


if __name__ == "__main__":
    main()
