"""Relocate a checked support proof by binding its geometric receptor."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from boundary_search_v1 import Inventory, Region, solve
from cases_v1 import fuse
from cascade_wang_v1 import frozen, problem, save
from geometry_v1 import Penrose, add, area, mul, rings_from_edges
from model_v1 import rotate
from support_cascade_v1 import find, verify


def relocated(evidence, turn, offset):
    def point(p, denominator=1):
        return add(rotate(p, turn), mul(denominator, offset))

    def line(e):
        return tuple(map(point, e))

    nodes = []
    for row in evidence["nodes"]:
        w = row["witness"]
        if row["kind"] == "outside":
            kind, *data = w
            w = ("center", point(data[0], 4)) if kind == "center" else ("line", *line(data))
        else:
            w = line(w)
        nodes.append({**row, "witness": w, "tile": tuple(sorted(map(point, row["tile"])))})
    return dict(root=line(evidence["root"]), children=evidence["children"], nodes=nodes)


def receives(region, evidence):
    return (evidence["root"] in region.edges
            and all(region.blocked(row["witness"], frozenset()) if row["kind"] == "outside"
                    else row["witness"] not in region.edges for row in evidence["nodes"]))


def add_one_tile(g, region, inventory):
    options = {t for e in region.edges for t, in inventory.at(e[::-1])}
    for tile in sorted(options):
        center = tuple(map(sum, zip(*tile)))
        if region.inside(center, 4) or any(g.intrudes(a, b, tile) for a, b in region.lines):
            continue
        joined = fuse(region.edges, g.boundary(tile))
        if joined is None:
            continue
        cycles = rings_from_edges(joined)
        if not cycles:
            continue
        cycles.sort(key=lambda ring: -g.sign(area(ring, g.cross)))
        try:
            updated = Region(g, tuple(cycles))
        except AssertionError:
            continue
        if updated.counts == add(region.counts, g.mass(tile)):
            yield updated, tile


def main():
    cohort = json.loads((ROOT / "data/cascade-experiment-v1.json").read_text())
    specimen = min(cohort["examples"], key=lambda row: len(row["proof"]["nodes"]))
    proof, rings = frozen(specimen["proof"]), frozen(specimen["rings"])
    g = Penrose()
    inventory = Inventory(g)
    source = json.loads((ROOT / "wang/input/cascade-v1.json").read_text())
    original = Region(g, rings)
    edits = []
    passed = []
    for region, tile in add_one_tile(g, original, inventory):
        applies = receives(region, proof)
        cover = None
        baseline = solve(region, inventory, "scope-control", limit=400, order="single")
        status = baseline["status"]
        if applies:
            statement, _ = problem(g, region.rings, proof)
            assert statement == source
            assert status != "POSITIVE"
            passed.append((region, tile))
        elif status == "POSITIVE":
            g.verify(region.rings, baseline["patch"])
            cover = baseline["patch"]
        edits.append(dict(tile=tile, rings=region.rings, reused=applies, baseline=status,
                          counts=baseline["counts"], cover=cover))
    assert passed and len(passed) < len(edits)
    updated, ear = passed[0]
    results = []
    for turn, offset in ((0, (0, 0, 0, 0)), (1, (8, 1, -3, 2)), (4, (-3, 6, 0, 7)),
                         (7, (2, 2, -5, 1))):
        moved = relocated(proof, turn, offset)
        for name, source_rings in (("rigid", rings), ("edited", updated.rings)):
            target = tuple(tuple(add(rotate(p, turn), offset) for p in ring) for ring in source_rings)
            receiver = Region(g, target)
            assert receives(receiver, moved)
            assert not find(receiver, inventory, 1)[0]
            statement, legends = problem(g, target, moved)
            assert statement == source
            results.append(dict(kind=name, turn=turn, offset=offset, rings=target, atoms=legends,
                                case="CHECKED_GEOMETRY_SAME_LOGICAL_STATEMENT"))
    wrong = {**proof, "children": proof["children"][:-1]}
    try:
        verify(original, wrong)
    except AssertionError:
        pass
    else:
        raise AssertionError("An incomplete root domain was accepted")
    base = next(row for row in cohort["controls"] if row["case"] == specimen["case"])
    positive = Region(g, frozen(base["rings"]))
    assert not receives(positive, proof)
    save("data/transfer-v1.json", dict(status="CHECKED_CASCADE_TRANSFER",
        ear=ear, cases=results, single_tile_edits=edits,
        dropped_root_option="REJECTED", positive="PRESERVED"))
    print(len(results), "illustrated bindings to one Wang statement,", len(passed), "of",
          len(edits), "one-tile edits preserved the guards", flush=True)


if __name__ == "__main__":
    main()
