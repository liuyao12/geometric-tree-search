"""Search a Wang proof of the proposition induced by a checked edge cascade."""
from functools import reduce
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
sys.path.append(str(ROOT / "wang/source"))
from boundary_search_v1 import Region
from geometry_v1 import Penrose
from support_cascade_v1 import verify
from definitions_v1 import compile_case
from fair_ground_v1 import search
from logical_projection_v1 import projection
from logical_projection_v1 import verify as verify_records
from shared_wang_v1 import attach, verify_certificate


def frozen(obj):
    if isinstance(obj, list):
        return tuple(map(frozen, obj))
    if isinstance(obj, dict):
        return {k: frozen(v) for k, v in obj.items()}
    return obj


def save(path, result):
    (ROOT / path).write_text(json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")


def problem(g, rings, evidence):
    region = Region(g, rings)
    verify(region, evidence)
    tiles = tuple(dict.fromkeys(row["tile"] for row in evidence["nodes"]))
    names = {tile: f"X{i + 1:02d}" for i, tile in enumerate(tiles)}
    cover = ["atom", "Cover"]
    facts = []
    node_atoms = [["atom", names[row["tile"]]] for row in evidence["nodes"]]

    def disjunction(ids):
        return reduce(lambda a, b: ["or", a, b], (node_atoms[i] for i in ids))

    for row, atom in zip(evidence["nodes"], node_atoms, strict=True):
        if row["kind"] == "outside":
            formula = ["not", atom]
        else:
            formula = ["implies", atom, disjunction(row["children"])]
        if formula not in facts:
            facts.append(formula)
    facts.append(["implies", cover, disjunction(evidence["children"])])
    source = dict(id="penrose-support-cascade", equality=False, sorts=["U"], functions={},
                  predicates={name: [] for name in ("Cover", *names.values())},
                  premises=facts, goal=["not", cover])
    return source, {name: tile for tile, name in names.items()}


def main():
    data = json.loads((ROOT / "data/cascade-experiment-v1.json").read_text())
    specimen = min(data["examples"], key=lambda row: len(row["proof"]["nodes"]))
    g = Penrose()
    source, legend = problem(g, frozen(specimen["rings"]), frozen(specimen["proof"]))
    normal, translation = compile_case(source)
    outcome = search(normal, maximum_depth=0)
    assert outcome["status"] == "PROVED"
    wang = attach(source, "fol", normal, translation, outcome["proof"])
    full = verify_certificate(source, wang)
    compact = projection(wang)
    assert verify_records(source, compact)["status"] == "CHECKED_LOGICAL_RECORDS"
    altered = {**source, "premises": source["premises"][:-1]}
    try:
        verify_records(altered, compact)
    except AssertionError:
        pass
    else:
        raise AssertionError("Wrong source accepted")
    save("wang/input/cascade-v1.json", source)
    save("wang/data/cascade-wang-v1.json", wang)
    save("wang/data/cascade-records-v1.json", compact)
    receipt = dict(status="CHECKED_PENROSE_CASCADE_WANG", case=specimen["case"], atoms=legend,
                   geometry_nodes=len(specimen["proof"]["nodes"]), proof=full,
                   attempts=outcome["attempts"], wrong_source="REJECTED")
    save("wang/data/cascade-receipt-v1.json", receipt)
    print("Checked", full["fragment_calls"], "Wang proof lines for", len(legend), "rhomb atoms", flush=True)


if __name__ == "__main__":
    main()
