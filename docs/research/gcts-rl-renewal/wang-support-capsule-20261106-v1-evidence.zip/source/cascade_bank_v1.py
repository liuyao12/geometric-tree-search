"""A checked Penrose receptor inventory with geometric anchor lookup."""
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cascade_transfer_v1 import relocated
from cascade_wang_v1 import problem, verify_records
from geometry_v1 import add, mul, sub
from model_v1 import rotate


def shift_line(edge, offset):
    return tuple(add(point, offset) for point in edge)


def boundary_index(region, mode):
    lines = set(region.lines)
    line_index, edge_index = defaultdict(list), defaultdict(list)
    if mode == "indexed":
        for a, b in sorted(lines):
            line_index[sub(b, a)].append(a)
    for a, b in sorted(region.edges):
        edge_index[sub(b, a)].append(a)
    return lines, line_index, edge_index


@dataclass(frozen=True)
class Pose:
    turn: int
    root: tuple
    lines: tuple
    interior: tuple
    centers: tuple
    leaves: tuple


class CascadeBank:
    def __init__(self, region, proof, source, logical):
        assert problem(region.g, region.rings, proof)[0] == source
        self.receipt = verify_records(source, logical)
        self.prepare(region, proof, source)

    def prepare(self, region, proof, source):
        self.proof = proof
        self.source = source
        poses = []
        for turn in range(10):
            offset = mul(-1, rotate(proof["root"][0], turn))
            placed = relocated(proof, turn, offset)
            lines, interior, centers, leaves = set(), set(), set(), []
            for row in placed["nodes"]:
                w = row["witness"]
                if row["kind"] == "unsupported":
                    interior.add(w)
                else:
                    leaves.append((row["tile"], w))
                    if w[0] == "line":
                        lines.add(w[1:])
                    else:
                        assert w[0] == "center"
                        centers.add(w[1])
            assert placed["root"][0] == region.g.zero
            poses.append(Pose(turn, placed["root"], tuple(sorted(lines)),
                              tuple(sorted(interior)), tuple(sorted(centers)), tuple(leaves)))
        self.poses = tuple(poses)

    def bind(self, region, binding, replacements=()):
        turn, anchor = binding
        offset = sub(anchor, rotate(self.proof["root"][0], turn))
        moved = relocated(self.proof, turn, offset)
        renewed = dict(replacements)
        for node in moved["nodes"]:
            if node["kind"] == "outside" and node["tile"] in renewed:
                node["witness"] = renewed[node["tile"]]
        statement, _ = problem(region.g, region.rings, moved)
        assert statement == self.source
        return moved

    def probe(self, region, mode, index=None):
        assert mode in ("scan", "indexed")
        work = Counter()
        lines, line_index, edge_index = boundary_index(region, mode) if index is None else index
        for pose in self.poses:
            roots = edge_index[pose.root[1]]
            if not roots:
                continue
            if mode == "indexed" and pose.lines:
                pivot = min(pose.lines, key=lambda e: len(line_index[sub(e[1], e[0])]))
                anchors = (sub(p, pivot[0]) for p in line_index[sub(pivot[1], pivot[0])])
            else:
                anchors = iter(roots)
            for anchor in anchors:
                work["anchors"] += 1
                if shift_line(pose.root, anchor) not in region.edges:
                    continue
                for line in pose.lines:
                    work["line_guards"] += 1
                    if shift_line(line, anchor) not in lines:
                        break
                else:
                    for edge in pose.interior:
                        work["interior_guards"] += 1
                        if shift_line(edge, anchor) in region.edges:
                            break
                    else:
                        center_offset = mul(4, anchor)
                        for point in pose.centers:
                            work["center_guards"] += 1
                            if region.inside(add(point, center_offset), 4):
                                break
                        else:
                            return (pose.turn, anchor), dict(work)
        return None, dict(work)

    def repair(self, region):
        """Reuse the theorem after rechecking its premises with new witnesses."""
        work = Counter()
        lines = set(region.lines)
        roots = defaultdict(list)
        for a, b in sorted(region.edges):
            roots[sub(b, a)].append(a)
        candidates = []
        for pose in self.poses:
            for anchor in roots[pose.root[1]]:
                work["repair_anchors"] += 1
                if any(shift_line(e, anchor) in region.edges for e in pose.interior):
                    continue
                matches = sum(shift_line(e, anchor) in lines for e in pose.lines)
                candidates.append((-matches, pose.turn, anchor, pose))
        for _, turn, anchor, pose in sorted(candidates):
            work["repair_trials"] += 1
            replacements = {}
            center_offset = mul(4, anchor)
            for tile, witness in pose.leaves:
                work["repair_guards"] += 1
                if witness[0] == "center":
                    kept = not region.inside(add(witness[1], center_offset), 4)
                else:
                    kept = shift_line(witness[1:], anchor) in lines
                if kept:
                    continue
                placed = tuple(add(p, anchor) for p in tile)
                work["repair_exterior"] += 1
                new_witness = region.exterior(placed)
                if new_witness is None:
                    break
                replacements[placed] = new_witness
            else:
                return (turn, anchor), tuple(sorted(replacements.items())), dict(work)
        return None, (), dict(work)
