"""Time fresh propagation against an online proof inventory on the same streams."""
from pathlib import Path
import json
from statistics import median
import sys
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from binary_schema_v1 import BinaryLemma
from boundary_search_v1 import Inventory
from cascade_runtime_v1 import load, run
from cascade_timing_v1 import clear
from cascade_wang_v1 import save
from geometry_v1 import Penrose
from online_cascade_v1 import route


def timed(fn):
    clear()
    start = perf_counter_ns()
    fn()
    return perf_counter_ns() - start


def main():
    g = Penrose()
    inv = Inventory(g)
    lemma = BinaryLemma(json.loads((ROOT / "wang/input/binary-schema-v1.json").read_text()),
        json.loads((ROOT / "wang/data/binary-schema-logical-v1.json").read_text()))
    rows = load("data/cascade-runtime-v1.json")["results"]
    streams = dict(grouped=rows, mixed=sorted(rows, key=lambda r: r["shape"]))
    measurements = {}
    for name, stream in streams.items():
        values = {"online_ns": [], "fresh_ns": []}

        def fresh():
            for row in stream:
                result = run(g, inv, None, row, "depth-two")
                assert result["status"] == row["arms"]["depth-two"]["status"]

        arms = (("online_ns", lambda: route(g, inv, lemma, stream)), ("fresh_ns", fresh))
        for repeat in range(3):
            for arm, fn in arms if repeat % 2 else reversed(arms):
                values[arm].append(timed(fn))
        measurements[name] = values
        print(name, {k: round(median(v)/1e9, 3) for k,v in values.items()}, flush=True)
    save("data/online-timing-v1.json", dict(status="MEASURED_ONLINE_REPLAY", repeats=3, timings=measurements))


if __name__ == "__main__":
    main()
