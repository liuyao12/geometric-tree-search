"""Find controlled Penrose regions whose edge domains fail after propagation."""
from collections import Counter
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from boundary_search_v1 import Inventory, Region, solve
from cases_v1 import patch_ring, rhomb_grid
from cavity_cases_v1 import belt
from geometry_v1 import Penrose, add, sub
from support_cascade_v1 import find, verify


def edits(g, rings):
    outer, *holes = rings
    proposals = []
    for i, b in enumerate(outer):
        a, c = outer[i - 1], outer[(i + 1) % len(outer)]
        d = sub(add(a, c), b)
        change = g.cross(sub(b, a), sub(c, b))
        if any(change) and d not in outer:
            proposals.append((i, d, change))
    candidates = []
    for (i, d, x), (j, e, y) in combinations(proposals, 2):
        if any(add(x, y)) or d == e or j - i in (1, len(outer) - 1):
            continue
        altered = list(outer)
        altered[i], altered[j] = d, e
        candidates.append((tuple(altered), *holes))
    return sorted(candidates, key=lambda r: sha256(repr(r).encode()).digest())


def make_bases(g):
    for cols, rows in product(range(3, 6), range(3, 6)):
        absent = ((cols - 1, rows - 1),)
        if max(cols, rows) >= 4:
            absent += ((1, 1),)
        tiles = rhomb_grid(cols, rows, (cols + rows) % 4 + 1, absent)
        yield f"grid-{cols}-{rows}", patch_ring(g, tiles), tiles
    for i, axes in enumerate(((1, 2, 3, 4), (1, 2, 1, 2), (4, 2, 1, 3), (3, 1, 2, 3))):
        rings, tiles = belt(g, 5, axes)
        yield f"belt-{i}", rings, tiles


def main():
    g = Penrose()
    inventory = Inventory(g)
    controls, examples = [], []
    count = Counter()
    for label, rings, patch in make_bases(g):
        assert rings
        g.verify(rings, patch)
        case = Region(g, rings)
        assert not find(case, inventory, 2)[0]
        controls.append(dict(case=label, rings=rings, patch=patch))
        for receiver in edits(g, rings)[:24]:
            try:
                region = Region(g, receiver)
            except (AssertionError, ValueError):
                count["invalid_edit"] += 1
                continue
            assert region.counts == case.counts
            direct, _ = find(region, inventory, 0)
            if direct:
                count["direct_failure"] += 1
                verify(region, direct)
                continue
            count["passes_direct"] += 1
            proof, work = find(region, inventory, 2)
            if proof is None:
                count["passes_depth_two"] += 1
                continue
            verify(region, proof)
            depth = 1 if find(region, inventory, 1)[0] else 2
            count[f"depth_{depth}"] += 1
            baseline = solve(region, inventory, label, limit=1000, order="single")
            assert baseline["status"] != "POSITIVE"
            examples.append(dict(case=label, rings=receiver, proof=proof,
                                 minimum_tested_depth=depth, work=work, baseline=baseline))
        print(label, dict(count), flush=True)
    result = dict(status="CHECKED_SUPPORT_CASCADES", counts=count, examples=examples, controls=controls)
    (ROOT / "data/cascade-experiment-v1.json").write_text(
        json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")


if __name__ == "__main__":
    main()
