"""Measure autonomous receptor lookup and exact fallbacks on held-out outlines."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from boundary_search_v1 import Inventory, Region, solve
from cascade_bank_v1 import CascadeBank
from cascade_transfer_v1 import add_one_tile
from cascade_wang_v1 import frozen, save
from geometry_v1 import Penrose, add, sub
from model_v1 import rotate
from support_cascade_v1 import find, verify

LIMIT = 400


def load(path):
    return frozen(json.loads((ROOT / path).read_text()))


def ring_pose(rings, number):
    turn = (7 * number + 3) % 10
    offset = (5 + number, -3 - 2 * number, number % 7, -number % 11)
    return tuple(tuple(add(rotate(p, turn), offset) for p in ring) for ring in rings)


def shape_key(region):
    keys = []
    for turn in range(10):
        edges = [(rotate(a, turn), rotate(b, turn)) for a, b in region.edges]
        first = min(min(e) for e in edges)
        keys.append(tuple(sorted((sub(a, first), sub(b, first)) for a, b in edges)))
    return sha256(repr(min(keys)).encode()).hexdigest()


def cases(g, inventory, data, specimen):
    cohorts = []
    known = set()

    def add_case(family, rings, expectation=None):
        key = shape_key(Region(g, rings))
        if key in known:
            return
        known.add(key)
        i = len(cohorts) + 1
        cohorts.append(dict(id=f"receiver-{i:03d}", family=family, rings=ring_pose(rings, i),
                            shape=key, expectation=expectation))

    for region, _ in add_one_tile(g, Region(g, specimen["rings"]), inventory):
        add_case("donor-edits", region.rings)
    for j, other in enumerate(data["examples"], 1):
        if other is specimen:
            continue
        for region, _ in add_one_tile(g, Region(g, other["rings"]), inventory):
            add_case(f"new-family-{j}", region.rings)
    for row in data["controls"]:
        add_case("known-covers", row["rings"], "POSITIVE")
    return cohorts


def plain(g, inventory, region, label):
    result = solve(region, inventory, label, limit=LIMIT, order="single")
    if result["status"] == "POSITIVE":
        g.verify(region.rings, result["patch"])
    return result


def run(g, inventory, bank, row, arm):
    region = Region(g, row["rings"])
    label = row["id"]
    if arm in ("scan", "indexed", "adaptive"):
        binding, work = bank.probe(region, "scan" if arm == "scan" else "indexed")
        replacements = ()
        if binding is None and arm == "adaptive":
            binding, replacements, repairs = bank.repair(region)
            work.update(repairs)
        if binding:
            return dict(status="NEGATIVE", origin="reused", binding=binding, replacements=replacements,
                        work=work, counts={})
        answer = plain(g, inventory, region, label)
        return dict(**answer, origin="search", work=work)
    if arm == "depth-two":
        proof, work = find(region, inventory, 2)
        if proof:
            verify(region, proof)
            return dict(status="NEGATIVE", origin="cascade", proof=proof, work=work, counts={})
        answer = plain(g, inventory, region, label)
        return dict(**answer, origin="search", work=work)
    assert arm == "baseline"
    return dict(**plain(g, inventory, region, label), origin="search", work={})


def main():
    g = Penrose()
    inventory = Inventory(g)
    data = load("data/cascade-experiment-v1.json")
    source = json.loads((ROOT / "wang/input/cascade-v1.json").read_text())
    logical = json.loads((ROOT / "wang/data/cascade-records-v1.json").read_text())
    specimen = min(data["examples"], key=lambda row: len(row["proof"]["nodes"]))
    bank = CascadeBank(Region(g, specimen["rings"]), specimen["proof"], source, logical)
    rows = cases(g, inventory, data, specimen)
    outcomes = []
    for row in rows:
        arms = {arm: run(g, inventory, bank, row, arm)
                for arm in ("baseline", "scan", "indexed", "adaptive", "depth-two")}
        base = arms["baseline"]["status"]
        assert all(r["status"] == base or (base == "BOUNDED" and r["status"] == "NEGATIVE")
                   for r in arms.values())
        assert (arms["scan"]["origin"] == "reused") == (arms["indexed"]["origin"] == "reused")
        for name in ("indexed", "adaptive"):
            if arms[name]["origin"] == "reused":
                bank.bind(Region(g, row["rings"]), arms[name]["binding"], arms[name]["replacements"])
        if row["expectation"] is not None:
            assert base == row["expectation"]
        outcomes.append(dict(**row, arms=arms))
    totals = {}
    for row in outcomes:
        for name, arm in row["arms"].items():
            stats = totals.setdefault(row["family"], {}).setdefault(name, Counter())
            stats["requests"] += 1
            stats[arm["status"].lower()] += 1
            stats["cuts"] += arm["origin"] != "search"
            stats.update(arm["work"])
            stats.update({k: arm["counts"].get(k, 0) for k in ("nodes", "placement_checks")})
    save("data/cascade-runtime-v1.json", dict(status="CHECKED_AUTONOMOUS_RECEPTORS",
        receipt=bank.receipt, results=outcomes, totals=totals, bound=LIMIT))
    for family, arms in totals.items():
        print(family, json.dumps(arms, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
