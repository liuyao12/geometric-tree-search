"""Measure matched requests with cold geometry caches and an admitted theorem."""
from collections import defaultdict
from pathlib import Path
from statistics import median
import json
import platform
import sys
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
import check_v1
import model_v1
from boundary_search_v1 import Inventory, Region
from cascade_bank_v1 import CascadeBank
from cascade_runtime_v1 import load, run
from cascade_wang_v1 import save
from geometry_v1 import Penrose

ARMS = ("baseline", "scan", "indexed", "adaptive", "depth-two")
TRIALS = 3
PER_FAMILY = 8


def clear():
    model_v1.clear_geometry()
    for fn in (check_v1.corners, check_v1.imaginary_normal, check_v1.hull, check_v1.canonical_contact,
               Penrose.poly, Penrose.boundary, Penrose.mass):
        fn.cache_clear()


def main():
    g = Penrose()
    inv = Inventory(g)
    data = load("data/cascade-experiment-v1.json")
    runtime = load("data/cascade-runtime-v1.json")
    specimen = min(data["examples"], key=lambda row: len(row["proof"]["nodes"]))
    source = json.loads((ROOT / "wang/input/cascade-v1.json").read_text())
    compact = json.loads((ROOT / "wang/data/cascade-records-v1.json").read_text())
    admission = []
    for _ in range(TRIALS):
        clear()
        started = perf_counter_ns()
        bank = CascadeBank(Region(g, specimen["rings"]), specimen["proof"], source, compact)
        admission.append(perf_counter_ns() - started)
    grouped = defaultdict(list)
    for row in runtime["results"]:
        grouped[row["family"]].append(row)
    cohort = [row for group in grouped.values() for row in sorted(group, key=lambda x: x["shape"])[:PER_FAMILY]]
    results = defaultdict(lambda: defaultdict(list))
    for trial in range(TRIALS):
        main = defaultdict(lambda: defaultdict(int))
        for index, row in enumerate(cohort):
            n = (index + trial) % len(ARMS)
            for arm in (*ARMS[n:], *ARMS[:n]):
                clear()
                started = perf_counter_ns()
                ans = run(g, inv, bank, row, arm)
                elapsed = perf_counter_ns() - started
                old = row["arms"][arm]
                assert ans["status"] == old["status"] and ans["origin"] == old["origin"]
                main[row["family"], arm]["runtime_ns"] += elapsed
                if ans["origin"] == "reused":
                    started = perf_counter_ns()
                    bank.bind(Region(g, row["rings"]), ans["binding"], ans["replacements"])
                    main[row["family"], arm]["independent_replay_ns"] += perf_counter_ns() - started
        for (family, arm), row in main.items():
            results[family][arm].append(dict(row))
        print("timing repeat", trial + 1, len(cohort), "requests per arm", flush=True)
    save("data/cascade-timing-v1.json", dict(status="MEASURED_RUNTIME", sampled=[r["id"] for r in cohort],
        repeats=TRIALS, admission_ns=admission, method="eight lowest shape hashes per family",
        runtime=results, system=dict(platform=platform.system(), architecture=platform.machine(),
                                    python=platform.python_version())))
    for family, timings in results.items():
        print(family, {name: round(median(r["runtime_ns"] for r in values) / 1e6, 1)
                       for name, values in timings.items()}, flush=True)


if __name__ == "__main__":
    main()
