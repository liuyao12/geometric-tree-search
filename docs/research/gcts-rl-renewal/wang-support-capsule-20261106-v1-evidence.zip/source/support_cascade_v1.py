"""Bounded support propagation for a fixed edge-to-edge rhomb cover."""
from collections import Counter
from functools import lru_cache

from check_v1 import contact, corners


def find(region, inventory, depth):
    g = region.g
    assert g.kind == "penrose"
    work = Counter()

    @lru_cache(maxsize=None)
    def unsupported(tile, budget):
        work["tile_states"] += 1
        witness = region.exterior(tile)
        if witness is not None:
            return ("outside", tile, witness)
        if budget:
            for edge in g.boundary(tile):
                if edge in region.edges:
                    continue
                children = impossible(edge[::-1], budget - 1)
                if children is not None:
                    return ("unsupported", tile, edge, children)
        return None

    def impossible(edge, budget):
        work["ports"] += 1
        children = []
        for tile, in inventory.at(edge):
            node = unsupported(tile, budget)
            if node is None:
                return None
            children.append(node)
        return tuple(children)

    for edge in sorted(region.edges):
        children = impossible(edge, depth)
        if children is not None:
            return encode(edge, children), dict(work)
    return None, dict(work)


def encode(root, children):
    nodes, ids = [], {}

    def node_id(node):
        if node not in ids:
            kind, tile, witness, *extra = node
            child_ids = tuple(map(node_id, extra[0])) if extra else ()
            ids[node] = len(nodes)
            nodes.append(dict(kind=kind, tile=tile, witness=witness, children=child_ids))
        return ids[node]

    roots = tuple(map(node_id, children))
    return dict(root=root, children=roots, nodes=nodes)


def verify(region, evidence):
    g = region.g
    checked = []
    assert g.kind == "penrose"

    def domain(edge):
        return {t for t in corners(edge[0]) if edge in g.boundary(t)}

    def closed(edge, children, previous):
        assert all(type(i) is int and 0 <= i < len(previous) for i in children)
        tiles = [previous[i] for i in children]
        assert len(tiles) == len(set(tiles)) and set(tiles) == domain(edge)

    for node in evidence["nodes"]:
        t, kind, w = node["tile"], node["kind"], node["witness"]
        assert t in corners(t[0])
        if kind == "outside":
            assert not node["children"]
            region.certify(t, w, frozenset())
        else:
            assert kind == "unsupported" and w in g.boundary(t) and w not in region.edges
            closed(w[::-1], node["children"], checked)
            assert all(contact(t, checked[i]) for i in node["children"])
        checked.append(t)
    assert evidence["root"] in region.edges
    closed(evidence["root"], evidence["children"], checked)
