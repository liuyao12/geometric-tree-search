Join proof rectangles with long-range markings

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/copy_study_v1.py
  python3 -I -S -B source/copy_verify_v1.py input/hilbert-incidence-v1.json data/hilbert-copy-certificate-v1.json.gz
  python3 -I -S -B publication/render_v1.py

The first command recompiles and replays all marked diagrams and rejects
the altered controls. Add --build to regenerate its data and standalone
example. The second command checks that example using only the statement
and marked certificate. The last command regenerates the reader.
The manifest gives SHA-256 for each included input and result.
