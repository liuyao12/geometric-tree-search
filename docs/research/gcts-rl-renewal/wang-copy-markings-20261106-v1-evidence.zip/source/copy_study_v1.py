"""Build and verify geometrically marked diagrams for previously searched proofs."""
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source")]
from boundary_kernel_v1 import build
from copy_check_v1 import TileBank, shape, topology, verify
from copy_ports_v1 import attach_marks, compile_diagram, encoded, fingerprint, freeze, record
from definition_check_v1 import check
from herbrand_v1 import signature
from native_v1 import PUBLISHED_MACHINE
from study_v1 import guarded


def read(name):
    return json.loads(gzip.decompress((ROOT / "input" / (name + "-v1.json.gz")).read_bytes()))


def negatives(machine, rows, bank):
    original = next(r for r in rows if r["original"]["id"] == "typed-shadowed-witness")
    diagram = original["diagram"]
    receipts = [bank.receipts[fingerprint(s)] for s in diagram["strips"]]
    bad = json.loads(encoded(diagram))
    bad["marks"].pop()
    cases = {"missing copy marking": (bad, receipts)}
    bad = json.loads(encoded(diagram))
    bad["marks"][0]["source"]["origin"][0] += 1
    cases["shifted source by one cell"] = bad, receipts
    bad = json.loads(encoded(diagram))
    i = next(i for i, s in enumerate(bad["strips"]) if s["records"] == 3)
    bad["strips"][i]["parents"][0] = ["line", i]
    cases["self-dependent proof line"] = bad, receipts
    bad = json.loads(encoded(diagram))
    i, strip = next((i, s) for i, s in enumerate(bad["strips"])
                    if s["records"] == 1 and record(s["word"][:-1])[2] == "")
    text = strip["prefix"][4:-2]
    changed = ("-" if text[0] == "+" else "+") + text[1:]
    strip["prefix"] = ">C0:" + changed + ";#"
    strip["word"] = "G0:0:/" + changed + ";"
    altered = receipts.copy()
    altered[i] = TileBank(machine).get(strip)[0]
    attach_marks(bad, altered, len(machine.marks) + 1)
    cases["locally valid altered assumption"] = bad, altered
    rejected = []
    for name, (bad, local_receipts) in cases.items():
        try:
            for strip in bad["strips"]:
                shape(strip)
            topology(bad, local_receipts, len(machine.marks) + 1)
        except (AssertionError, IndexError, KeyError):
            rejected.append(name)
        else:
            raise AssertionError("Invalid marked diagram accepted: " + name)
    return rejected


def study():
    prior = read("connected")
    high = read("connected-high")
    machine = build().compile()
    assert machine.digest() == PUBLISHED_MACHINE == prior["palette"]
    rows, bank = [], TileBank(machine)
    for row in prior["rows"]:
        source, normal = row["original"], row["normal"]
        check(source, normal, row["translation"])
        funcs, _, schemata = signature(normal)
        sources, _ = guarded(schemata, funcs, normal["sorts"])
        diagram = freeze(compile_diagram(freeze(row["wire"])))
        for strip in diagram["strips"]:
            shape(strip)
        receipts = [bank.get(strip)[0] for strip in diagram["strips"]]
        attach_marks(diagram, receipts, len(machine.marks) + 1)
        outcome = verify(diagram, sources, bank)
        keys = {fingerprint(s) for s in diagram["strips"]}
        outcome["unique_frames"] = len(keys)
        outcome["unique_steps"] = sum(bank.receipts[k]["steps"] for k in keys)
        connected = high["result"] if source["id"] == high["case"] else row["extended"] or row["runs"]["compact"]
        rows.append(dict(original=source, normal=normal, translation=row["translation"], proof=row["proof"],
                         diagram=diagram, receipt=outcome, connected=connected))
        print(source["id"], outcome, flush=True)
    return dict(palette=PUBLISHED_MACHINE, bank=bank.receipts, rows=rows,
                rejected=negatives(machine, rows, bank))


def main():
    if not __debug__:
        raise RuntimeError("Proof diagrams require assertions")
    result = study()
    body = encoded(result)
    path = ROOT / "data/copy-v1.json.gz"
    if "--build" in sys.argv:
        path.write_bytes(gzip.compress(body, mtime=0))
    else:
        assert gzip.decompress(path.read_bytes()) == body
    example = next(r for r in result["rows"] if r["original"]["id"] == "two-points-determine-a-line")
    example_files = (
        (ROOT / "input/hilbert-incidence-v1.json", example["original"], False),
        (ROOT / "data/hilbert-copy-certificate-v1.json.gz",
         dict(palette=result["palette"], normal=example["normal"], translation=example["translation"],
              diagram=example["diagram"]), True),
    )
    for file, value, compressed in example_files:
        raw = encoded(value)
        if "--build" in sys.argv:
            file.write_bytes(gzip.compress(raw, mtime=0) if compressed else raw)
        else:
            actual = file.read_bytes()
            assert (gzip.decompress(actual) if compressed else actual) == raw


if __name__ == "__main__":
    main()
