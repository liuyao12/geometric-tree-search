"""Replay a marked proof certificate against a separate source statement."""
import argparse
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source")]
from boundary_kernel_v1 import build
from copy_check_v1 import TileBank, verify
from definition_check_v1 import check
from herbrand_v1 import signature
from native_v1 import PUBLISHED_MACHINE
from study_v1 import guarded


def read(path):
    b = path.read_bytes()
    return json.loads(gzip.decompress(b) if path.suffix == ".gz" else b)


def main():
    if not __debug__:
        raise RuntimeError("Wang checks require assertions")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    source, cert = read(args.source), read(args.certificate)
    assert cert["palette"] == PUBLISHED_MACHINE
    check(source, cert["normal"], cert["translation"])
    functions, _, schemata = signature(cert["normal"])
    sources, _ = guarded(schemata, functions, cert["normal"]["sorts"])
    machine = build().compile()
    assert machine.digest() == PUBLISHED_MACHINE
    result = verify(cert["diagram"], sources, TileBank(machine))
    print(json.dumps(dict(status="CHECKED", **result), sort_keys=True))


if __name__ == "__main__":
    main()
