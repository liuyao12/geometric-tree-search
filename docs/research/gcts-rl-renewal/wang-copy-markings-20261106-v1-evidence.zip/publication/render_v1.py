"""Render the proof lines, copy ribbons and local Wang rows."""
from html import escape
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "publication", "wang/source")]
from copy_ports_v1 import fingerprint, freeze
from herbrand_v1 import signature
from proof_views_v1 import clause, explanation, formula, math, tile_svg
from study_v1 import guarded

NAME = "wang-copy-markings-20261106-v1"
TITLE = "Join proof rectangles with long-range markings"
EXAMPLE = "two-points-determine-a-line"
LABELS = {
    "binary-witness-in-goal": "Nested term named in the goal",
    "binary-witness-to-discover": "Existential goal with hidden terms",
    "typed-shadowed-witness": "Typed witness with shadowed variables",
    "two-points-determine-a-line": "Hilbert incidence uniqueness",
    "between-on-the-line": "Hilbert betweenness on a line",
    "zero-left-base": "Peano zero on the left, induction base",
    "zero-left-step": "Peano zero on the left, induction step",
    "closed-term-transport": "Transport a repeated closed term",
}


def glyphs(diagram, port):
    x, y = port["origin"]
    if y == 0:
        text = diagram["source"]
    else:
        strip, = (s for s in diagram["strips"] if s["origin"][1] == y)
        text = strip["prefix"] + strip["word"] + "$"
    start = (x - 1) // port["stride"]
    return text[start:start + port["glyphs"]]


def ribbon(diagram, marking, layer):
    source, target = (marking[k] for k in ("source", "target"))
    text = glyphs(diagram, source)
    assert text == glyphs(diagram, target)
    preview = text[:16]
    width = max(160, 16 * len(preview))
    shapes = []
    for i, char in enumerate(preview):
        x = 16 * i
        shapes.append(f'<path d="M{x+8} 20 L{x+8} 40" class="copy-line"/>')
        for y in (1, 41):
            shapes.append(f'<rect x="{x}" y="{y}" width="16" height="19" class="glyph"/>'
                          f'<text x="{x+8}" y="{y+14}" text-anchor="middle">{escape(char)}</text>')
    origin = source["origin"]
    dest = target["origin"]
    title = (f'Copy {len(text)} symbols from column {origin[0]} on row {origin[1]} '
             f'to column {dest[0]} on row {dest[1]}, with stride {source["stride"]}.')
    return (f'<div class="ribbon {layer}"><svg viewBox="0 0 {width} 62" role="img" aria-label="{title}">'
            f'<title>{title}</title>{"".join(shapes)}</svg>'
            f'<p>{len(text)} equal symbols, including the terminating delimiter. '
            f'Preview shows {len(preview)}.</p><details><summary>Read the complete copied text</summary>'
            f'<pre><code>{escape(text)}</code></pre></details></div>')


def tiles(receipt, types):
    point = receipt["checkpoints"][-1]
    out = []
    for i, tile in enumerate(freeze(point["row"])):
        j = types.setdefault(tile, len(types))
        out.append(f'<use href="#wang-{j}" x="{i*36}"/>')
    return (f'<figure><svg viewBox="0 0 324 36" role="img" aria-label="Nine actual local Wang squares">'
            f'{"".join(out)}</svg><figcaption>Local verifier row {point["step"] + 1:,}. '
            f'Hover over a square for its exact edge labels.</figcaption></figure>')


def case(row, bank, types):
    diagram = row["diagram"]
    original, proof = row["original"], row["proof"]
    functions, _, schemata = signature(row["normal"])
    sources, _ = guarded(schemata, functions, row["normal"]["sorts"])
    mark_at = 0
    lines = []
    for i, (line, strip) in enumerate(zip(proof, diagram["strips"], strict=True), 1):
        copies = []
        for parent in strip["parents"]:
            layer, identity = parent
            if layer == "source":
                label = "Source clause " + diagram["schema_ids"][identity]
                value = sources[diagram["schema_ids"][identity]]["clause"]
                style = "source-copy"
                heading = escape(label)
            else:
                label = f"Earlier proof line {identity + 1}"
                value = proof[identity]["clause"]
                style = "parent-copy"
                heading = f'<button class="jump" data-line="{identity+1}">{label}</button>'
            marking = diagram["marks"][mark_at]
            mark_at += 1
            copies.append(f'<div class="copied"><h4>{heading}</h4><div class="formula">{math(clause(value))}</div>'
                          + ribbon(diagram, marking, style) + "</div>")
        local = bank[fingerprint(strip)]
        key = original["id"]
        lines.append(f'<template class="line-template" data-line="{i}"><article class="line"><h3>Line {i} of {len(proof)}</h3>'
                     f'<div class="formula">{math(clause(line["clause"]))}</div><p>{explanation(line)}</p>'
                     f'<div class="grid">{"".join(copies)}</div>'
                     f'<details class="native"><summary>Inspect this inference’s Wang squares</summary>'
                     f'<p>The local rectangle stops at the fixed verification checkpoint after {strip["records"]} '
                     f'records and {local["steps"]:,} tape steps.</p>{tiles(local, types)}'
                     f'<pre><code>{escape(strip["prefix"])}\n{escape(strip["word"])}</code></pre></details></article></template>')
    assert mark_at == len(diagram["marks"])
    sources_html = "".join(f'<li>{math(formula(p))}</li>' for p in original["premises"])
    hidden = "" if original["id"] == EXAMPLE else " hidden"
    return (f'<div class="case" data-case="{original["id"]}" data-lines="{len(proof)}"{hidden}>'
            f'<details class="hypotheses"><summary>Read the hypotheses and conclusion</summary>'
            f'<ul class="formula">{sources_html}</ul><p class="formula">{math(formula(original["goal"]))}</p>'
            f'</details><div class="line-slot"></div>{"".join(lines)}</div>')


def main():
    data = json.loads(gzip.decompress((ROOT / "data/copy-v1.json.gz").read_bytes()))
    types, views, table = {}, [], []
    for row in data["rows"]:
        views.append(case(row, data["bank"], types))
        counts, prior = row["receipt"], row["connected"]
        state = f'{prior["steps"]:,}' if prior["status"] == "ACCEPT" else f'Open after {prior["steps"]:,}'
        table.append(f'<tr><th scope="row">{LABELS[row["original"]["id"]]}</th><td>{counts["frames"]}</td>'
                     f'<td>{state}</td><td>{counts["steps_without_reuse"]:,}</td>'
                     f'<td>{counts["marks"]:,}</td><td>{counts["glyph_equalities"]:,}</td></tr>')
    defs = "".join(tile_svg(t, i) for t, i in types.items())
    examples = [r for r in data["rows"] if r["original"]["id"] == EXAMPLE]
    example, = examples
    ratio = example["connected"]["steps"] / example["receipt"]["steps_without_reuse"]
    values = dict(title=TITLE, stem=NAME, table="".join(table), cases="".join(views), ratio=f"{ratio:.1f}",
                  palette='<svg class="palette" aria-hidden="true" width="0" height="0"><defs>' + defs + '</defs></svg>',
                  options="".join(f'<option value="{r["original"]["id"]}"'
                                  f'{" selected" if r["original"]["id"] == EXAMPLE else ""}>'
                                  f'{LABELS[r["original"]["id"]]}</option>' for r in data["rows"]))
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    head = head.replace("</style>", """
.palette{position:absolute;width:0;height:0;overflow:hidden;border:0}
[hidden]{display:none!important}.formula{overflow:auto}
.case .line{border-top:1px solid #cedde2;margin-top:1rem;padding-top:1rem}
.line>p{overflow:auto}
.line h3{margin:.3rem 0}.copied{min-width:0;background:#f7fafb;padding:.6rem;border-radius:.4rem}
.ribbon svg{width:100%;border:0}.ribbon .glyph{stroke:#90a8b1;stroke-width:.5}
.source-copy .glyph{fill:#d3e6f5}.source-copy .copy-line{stroke:#3578ad}
.parent-copy .glyph{fill:#d7eddd}.parent-copy .copy-line{stroke:#3a875c}
.ribbon svg text{font:12px ui-monospace,monospace}
.ribbon p{font-size:.85rem;margin:.1rem 0}.native figure{max-width:32rem}
.control{margin:.85rem 0;align-items:center}#line-select{width:5.5rem}
.control label{font-weight:650}.copy-legend{color:#31596c;font-size:.9rem}
.control select{max-width:100%;min-width:0}#proof-select{width:min(100%,26rem)}
button.jump{font-size:.9rem}.native{padding:.4rem;border:1px solid #cadde5;border-radius:.35rem;margin-top:.8rem}
</style>""")
    body = (ROOT / "publication/copy-body-v1.html").read_text()
    for key, value in values.items():
        body = body.replace("%%" + key.upper() + "%%", value)
    assert "%%" not in body
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
