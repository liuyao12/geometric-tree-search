const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      await page.goto(pathToFileURL(process.cwd() + "/report/wang-copy-markings-20261106-v1.html").href,
        { waitUntil: "load", timeout: 60000 });
      const current = page.locator(".case:visible .line-slot");
      await current.locator("mjx-container").first().waitFor();
      assert.equal(await page.locator("#proof-select option").count(), 8);
      assert.equal(await page.locator("#line-select").inputValue(), "72");
      assert.equal(await current.locator(".parent-copy").count(), 2);
      assert.match(await current.locator(".formula").first().textContent(), /⊥/);
      await current.getByText("Inspect this inference’s Wang squares").click();
      assert.equal(await current.locator(".native svg use").count(), 9);
      assert.ok(await current.locator(".native svg use").first().evaluate(node => node.getBBox().width >= 36));
      const target = await current.locator("button.jump").first().getAttribute("data-line");
      await current.locator("button.jump").first().click();
      assert.equal(await page.locator("#line-select").inputValue(), target);
      await page.selectOption("#line-select", "1");
      await current.locator("mjx-container").first().waitFor();
      assert.equal(await current.locator(".source-copy").count(), 1);
      await page.selectOption("#proof-select", "between-on-the-line");
      assert.equal(await page.locator("#line-select").inputValue(), "149");
      await page.getByRole("button", { name: "Previous", exact: true }).click();
      assert.equal(await page.locator("#line-select").inputValue(), "148");
      await page.getByRole("button", { name: "Next", exact: true }).click();
      assert.equal(await page.locator("#line-select").inputValue(), "149");
      await current.locator("mjx-container").first().waitFor();
      assert.equal(await page.locator("#comparison tbody tr").count(), 8);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth), width);
      assert.deepEqual(errors, []);
      console.log("Verified", width, "px, copy colors, parent navigation, proof lines and Wang tiles.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
