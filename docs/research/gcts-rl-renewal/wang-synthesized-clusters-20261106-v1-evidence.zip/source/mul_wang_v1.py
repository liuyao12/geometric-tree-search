"""Elaborate checked arithmetic paths into G/R fragments and replay the Wang bank."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mul_study_v1 import DATA, ROOT, checked_case
from mul_cases_v1 import AXIOMS, CASES

sys.path[:0] = [str(ROOT / "wang/external/source"), str(ROOT / "wang/source")]
from lifted_equality_ground_v1 import congruence, equality, reflexive
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from schematic_capsules_v1 import encoded, frozen
from study_v1 import Certificate


BANK = ROOT / "wang/data"


def E(a, b):
    return equality("Nat", a, b)


def elaborate(eq, row, available):
    functions = {name: (("Nat",) * arity, "Nat")
                 for name, arity in (("zero", 0), ("S", 1), ("plus", 2), ("times", 2))}
    functions.update({f"parameter{i}": ((), "Nat") for i in range(len(eq.variables))})
    sources = {}

    def schema(name, variables, *clause):
        assert name not in sources
        sources[name] = dict(id=name, variables={v: "Nat" for v in variables}, clause=clause)

    x, y, z = "?x", "?y", "?z"
    schema("reflexive-Nat", (x,), (True, E(x, x)))
    schema("symmetric-Nat", (x, y), (False, E(x, y)), (True, E(y, x)))
    schema("transitive-Nat", (x, y, z), (False, E(x, y)), (False, E(y, z)), (True, E(x, z)))
    for fn in ("S", "plus", "times"):
        lefts, rights = (tuple(f"?{side}{i}" for i in range(len(functions[fn][0]))) for side in "lr")
        guards = tuple((False, E(a, b)) for a, b in zip(lefts, rights, strict=True))
        schema("congruence-" + fn, lefts + rights, *guards, (True, E((fn, *lefts), (fn, *rights))))
    rules = {rule.name: rule for rule in available}
    for name in sorted({line["rule"] for line in row["lines"]}):
        if name == "induction-hypothesis":
            schema(name, (), (True, E(*row["ih"])))
        else:
            rule = rules[name]
            schema(name, rule.variables, (True, E(rule.left, rule.right)))
    left, right = row["left"], row["right"]
    target = E(left, right)
    schema("negated-obligation", (), (False, target))
    builder = Certificate(sources, functions, {"=Nat": ("Nat", "Nat")}, ("Nat",), {})
    segments = []
    total = None
    for line in row["lines"]:
        a, b = line["instance"]
        before, after = line["before"], line["after"]
        start = len(builder.lines)
        positive = builder.instance(line["rule"], line["bindings"])
        if line["side"]:
            symmetry = builder.instance("symmetric-Nat", {x: a, y: b})
            positive = builder.resolve(positive, symmetry, E(a, b))
            a, b = b, a
        lifted = congruence(builder, before, after, tuple(i-1 for i in line["path"]), E(a, b))
        if lifted is not None:
            guard = E(a, b)
            positive = (builder.resolve(positive, lifted, guard)
                        if (False, guard) in builder.lines[lifted]["clause"] else lifted)
        assert set(builder.lines[positive]["clause"]) == {(True, E(before, after))}
        if total is None:
            total = positive
        else:
            t = builder.instance("transitive-Nat", {x: left, y: before, z: after})
            first, second = E(left, before), E(before, after)
            total = builder.resolve(total, t, first)
            if (False, second) in builder.lines[total]["clause"]:
                total = builder.resolve(positive, total, second)
        segments.append(tuple(range(start, len(builder.lines))))
    if total is None:
        total = reflexive(builder, target)
    ending = len(builder.lines)
    builder.resolve(total, builder.instance("negated-obligation", {}), target)
    segments.append(tuple(range(ending, len(builder.lines))))
    assert builder.lines[-1]["clause"] == []
    return sources, functions, frozen(builder.lines), segments


def prepare():
    result = frozen(json.loads((DATA / "arithmetic-v1.json").read_text()))
    wires, proofs = {}, {}
    available = []
    for eq in CASES:
        found = result[eq.name]["inventory"]
        imports, audited = checked_case(eq, found["proof"], tuple(available))
        assert tuple(imports) == found["imports"]
        proofs[eq.name] = {}
        for phase, row in audited.items():
            sources, functions, proof, segments = elaborate(eq, row, (*AXIOMS, *available))
            calls = []
            for i, step in enumerate(proof):
                names, prefix, word = fragment(proof, i, sources, functions)
                parsed = decoder.read(prefix, word + "!", require_empty=False)
                match(proof, i, sources, names, parsed, prefix)
                key = fingerprint(prefix, records(word))
                wire = wires.setdefault(key, dict(prefix=prefix, word=word, example=(eq.name, phase, i+1),
                                                   uses=0, rule=step["rule"]))
                assert (prefix, word) == (wire["prefix"], wire["word"])
                wire["uses"] += 1
                calls.append(key)
            proofs[eq.name][phase] = dict(sources=sources, functions=functions, proof=proof,
                                           segments=segments, calls=calls)
        available.append(eq)
    return wires, proofs


def main():
    if not __debug__:
        raise RuntimeError("Wang replay requires assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    rebuild = parser.parse_args().build
    wires, proofs = prepare()
    bank_path, proof_path, receipt_path = (BANK / n for n in
                                          ("arithmetic-bank-v1.json.gz", "arithmetic-proof-v1.json",
                                           "arithmetic-receipt-v1.json"))
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_path.read_bytes()))
    receipt = dict(logical_records=sum(w["uses"] for w in wires.values()),
                   theorems=len(proofs), obligations=sum(map(len, proofs.values())),
                   **verify_bank(wires, bank))
    print(json.dumps(receipt, sort_keys=True), flush=True)
    if rebuild:
        bank_path.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
        proof_path.write_bytes(encoded(proofs) + b"\n")
        receipt_path.write_bytes(encoded(receipt) + b"\n")
    else:
        assert proof_path.read_bytes() == encoded(proofs) + b"\n"
        assert receipt_path.read_bytes() == encoded(receipt) + b"\n"


if __name__ == "__main__":
    main()
