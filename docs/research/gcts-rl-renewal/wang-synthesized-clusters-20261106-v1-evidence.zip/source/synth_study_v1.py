"""Compare discovered proof families with intact donor theorems and primitive moves."""
from collections import defaultdict
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from mul_cases_v1 import AXIOMS, Equality, obligations, size
from mul_study_v1 import DATA, checked_case, evaluate as instantiate
from rewrite_search_v1 import Offers, at, find, match, put, variables
from rl_cases_v1 import controls, dataset
from rl_search_v1 import CAPS, evaluate
from rl_study_v1 import inventory
from synth_v1 import Macro, common, normalized, synthesize
from receptor_index_v1 import RoutedOffers

SIZES=(8,16,32)
MODES=("primitive","whole","literal","synthesized")
QUEUE="uniform"


def direct(path):
    return dict(induction=None,phases=[dict(phase="direct",status="PROVED",path=path)])


def move_to_symbolic(eq,lines):
    def lift(t):
        if t[0].startswith("parameter"):
            return eq.variables[int(t[0][9:])]
        return (t[0],*(lift(x) for x in t[1:]))
    prefix=common([l["path"] for l in lines])
    a,b=lift(at(lines[0]["before"],prefix)),lift(at(lines[-1]["after"],prefix))
    if isinstance(a,str) or isinstance(b,str) or a==b or variables(a)!=variables(b):
        return None
    expansion=tuple((l["rule"],l["side"],l["path"][len(prefix):],
                     tuple((v,lift(t)) for v,t in sorted(l["bindings"].items()))) for l in lines)
    if any(not variables(t)<=variables(a) for *_,env in expansion for _,t in env):
        return None
    return normalized(a,b,expansion)


def validate_macro(macro,prior):
    params={v:(f"parameter{i}",) for i,v in enumerate(macro.equation.variables)}
    path=tuple((r,s,p,tuple((v,instantiate(t,params)) for v,t in env))
               for r,s,p,env in macro.expansion)
    checked_case(macro.equation,direct(path),prior)


def mine(problems,prior):
    known={r.name:r for r in (*AXIOMS,*prior)}
    base={normalized(r.left,r.right)[:2] for r in known.values()}
    raw={mode:defaultdict(list) for mode in MODES[1:]}
    received=[]
    for _,_,eq in problems:
        (_,ends,_),=obligations(eq,None)
        result=find(*ends,tuple(known.values()),cap=720,priority="balanced")
        if result["path"] is None:
            continue
        _,audit=checked_case(eq,direct(result["path"]),prior)
        lines=audit["direct"]["lines"]
        received.append(eq.name)
        full=normalized(eq.left,eq.right)[:2]
        full_steps=move_to_symbolic(eq,lines)
        if full_steps and full_steps[:2]==full and full not in base:
            raw["whole"][full].append((eq.name,full_steps[2]))
        for i in range(len(lines)):
            for j in range(i+2,min(len(lines),i+5)+1):
                chunk=lines[i:j]
                actual_prefix=common([l["path"] for l in chunk])
                before,after=at(chunk[0]["before"],actual_prefix),at(chunk[-1]["after"],actual_prefix)
                for mode, result in (("synthesized",synthesize(chunk,known)),
                                     ("literal",move_to_symbolic(eq,chunk))):
                    if result is None:
                        continue
                    a,b,recipe=result
                    if (a,b) in base:
                        continue
                    matches=False
                    for p,q in ((a,b),(b,a)):
                        env={}
                        if match(p,before,env) and put(q,env)==after:
                            matches=True
                    assert matches
                    raw[mode][a,b].append((eq.name,recipe))
    banks={}
    for mode, rows in raw.items():
        def key(pair):
            (a,b),items=pair
            return -len({name for name,_ in items}),-len(items),size(a)+size(b),repr((a,b))
        bank=[]
        for i,((a,b),offers) in enumerate(sorted(rows.items(),key=key)):
            donors=tuple(sorted({name for name,_ in offers}))
            recipe=min((p for _,p in offers),key=lambda p:(len(p),repr(p)))
            law=Equality(f"{mode}-{i+1:03}",tuple(sorted(variables(a))),a,b)
            macro=Macro(law,recipe,donors)
            validate_macro(macro,prior)
            bank.append(macro)
        banks[mode]=bank
    return banks,received


def flatten(path,bank):
    moves=[]
    catalog={m.equation.name:m for m in bank}
    for rule,side,site,bindings in path:
        if rule not in catalog:
            moves.append((rule,side,site,bindings))
            continue
        env=dict(bindings)
        recipe=catalog[rule].expansion
        if side:
            recipe=tuple((r,1-s,p,e) for r,s,p,e in reversed(recipe))
        for r,s,p,args in recipe:
            moves.append((r,s,site+p,tuple((v,instantiate(t,env)) for v,t in args)))
    return tuple(moves)


def run(problems,prior,bank,offerer=Offers):
    output=[]
    rules=(*AXIOMS,*prior,*(m.equation for m in bank))
    for split,family,eq in problems:
        result=evaluate(eq,rules,QUEUE,offerer=offerer)
        result.pop("early")
        result.pop("queues")
        if result["path"] is not None:
            expanded=flatten(result["path"],bank)
            checked_case(eq,direct(expanded),prior)
            result["expanded_path"]=expanded
            result["macro_steps"]=sum(x[0].startswith(("synthesized-","literal-","whole-")) for x in result["path"])
        output.append(dict(family=family,name=eq.name,result=result))
    return output


def measure(rows,cap):
    r=[x["result"] for x in rows]
    return sum(x["path"] is not None and x["expanded"]<=cap for x in r),sum(min(cap,x["expanded"]) for x in r)


def rank(rows):
    a,b,c=(measure(rows,cap) for cap in CAPS)
    return b[0],a[0],c[0],-b[1],-c[1]


def encode_macro(m):
    return dict(equation=vars(m.equation),expansion=m.expansion,donors=m.donors)


def study():
    groups=defaultdict(list)
    for split,family,eq in dataset():
        groups[split].append((split,family,eq))
    prior=inventory()
    banks,donors=mine(groups["train"],prior)
    print("Donor proofs",len(donors),"learned laws",{k:len(v) for k,v in banks.items()},flush=True)
    calibration={}
    selected={}
    for mode in MODES[1:]:
        lengths=sorted({min(n,len(banks[mode])) for n in SIZES})
        trials={n:run(groups["calibrate"],prior,banks[mode][:n]) for n in lengths}
        selected[mode]=max(trials,key=lambda n:(rank(trials[n]),-n))
        calibration[mode]=trials
        print(mode,"selected",selected[mode],{n:measure(r,CAPS[1]) for n,r in trials.items()},flush=True)
    test,negatives,routing={},{},{}
    for mode in MODES:
        bank=banks[mode][:selected[mode]] if mode in banks else ()
        test[mode]=run(groups["test"],prior,bank)
        routed=run(groups["test"],prior,bank,RoutedOffers)
        for plain,marked in zip(test[mode],routed,strict=True):
            a,b=plain["result"],marked["result"]
            assert all(a.get(k)==b.get(k) for k in ("path","expanded","offers","expanded_path"))
        routing[mode]=dict(plain=sum(x["result"]["matches"] for x in test[mode]),
                           marked=sum(x["result"]["matches"] for x in routed),
                           probes=sum(x["result"]["receptors"] for x in routed))
        negatives[mode]=run(controls(),prior,bank)
        assert all(x["result"]["path"] is None for x in negatives[mode])
        print(mode,[measure(test[mode],cap) for cap in CAPS],
              "proofs using a macro",sum(x["result"].get("macro_steps",0)>0 for x in test[mode]),flush=True)
    return dict(donors=donors,selected=selected,banks={k:[encode_macro(m) for m in b] for k,b in banks.items()},
                calibration=calibration,test=test,negative=negatives,routing=routing)


def main():
    if not __debug__:
        raise RuntimeError("Proof replay requires assertions")
    result=study()
    body=json.dumps(result,sort_keys=True,separators=(",",":"))+"\n"
    out=DATA/"synth-study-v1.json"
    if "--build" in sys.argv:
        out.write_text(body)
    else:
        assert out.read_text()==body


if __name__=="__main__":
    main()
