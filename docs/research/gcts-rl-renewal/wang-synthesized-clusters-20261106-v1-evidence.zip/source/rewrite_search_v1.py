"""Bidirectional term search with sound, reusable equality rewrites."""
from collections import Counter, defaultdict
from functools import lru_cache
from heapq import heappop, heappush

from mul_cases_v1 import put, size


def match(pattern, term, bindings):
    if isinstance(pattern, str):
        return bindings.setdefault(pattern, term) == term
    return len(pattern) == len(term) and pattern[0] == term[0] and all(
        match(x, y, bindings) for x, y in zip(pattern[1:], term[1:], strict=True))


def variables(term):
    return {term} if isinstance(term, str) else set().union(*(variables(t) for t in term[1:]))


def at(term, path):
    for i in path:
        term = term[i]
    return term


def replace(term, path, other):
    if not path:
        return other
    i, *tail = path
    return (*term[:i], replace(term[i], tail, other), *term[i+1:])


def positions(term, path=()):
    yield path, term
    for i, sub in enumerate(term[1:], 1):
        yield from positions(sub, (*path, i))


@lru_cache(maxsize=30000)
def distance(a, b):
    if a == b:
        return 0
    if a[0] == b[0] and len(a) == len(b):
        return sum(distance(x, y) for x, y in zip(a[1:], b[1:], strict=True))
    return 2 + abs(size(a)-size(b))


class Offers:
    def __init__(self, rules, indexed):
        self.counts = Counter()
        self.rules = []
        self.heads = defaultdict(list)
        self.indexed = indexed
        for rule in rules:
            for side, (left, right) in enumerate(((rule.left, rule.right), (rule.right, rule.left))):
                if isinstance(left, str) or not variables(right) <= variables(left):
                    continue
                spec = rule.name, side, left, right
                self.rules.append(spec)
                self.heads[left[0]].append(spec)

    def candidates(self, part):
        return self.heads.get(part[0], ()) if self.indexed else self.rules

    def at(self, term, maximum):
        for path, part in positions(term):
            for rule, side, left, right in self.candidates(part):
                self.counts["matches"] += 1
                values = {}
                if not match(left, part, values):
                    continue
                proposed = put(right, values)
                if proposed == part or size(term)-size(part)+size(proposed) > maximum:
                    continue
                self.counts["offers"] += 1
                yield replace(term, path, proposed), (rule, side, path, tuple(sorted(values.items())))


def find(left, right, rules, cap=1200, indexed=True, priority="balanced"):
    if left == right:
        return dict(status="PROVED", path=(), counts={})
    offers = Offers(rules, indexed)
    counts = offers.counts
    maximum = max(size(left), size(right)) + 8
    parents = [{left: None}, {right: None}]
    agendas = [[], []]
    starts = left, right
    serial = 0

    def put_term(side, term, depth):
        nonlocal serial
        if priority == "breadth":
            rank = depth
        elif priority == "directed":
            rank = depth + .60*distance(term, starts[1-side]) + .05*size(term)
        else:
            rank = depth + .19*distance(term, starts[1-side]) + .19*size(term)
        heappush(agendas[side], (rank, serial, depth, term))
        serial += 1

    put_term(0, left, 0)
    put_term(1, right, 0)
    middle = None
    while counts["expanded"] < cap and any(agendas):
        side = min((i for i in range(2) if agendas[i]), key=lambda i: agendas[i][0][:2])
        _, _, depth, term = heappop(agendas[side])
        counts["expanded"] += 1
        for other, step in offers.at(term, maximum):
            if other in parents[side]:
                continue
            parents[side][other] = term, step
            if other in parents[1-side]:
                middle = other
                break
            put_term(side, other, depth+1)
        if middle is not None:
            break
    if middle is None:
        return dict(status="BOUNDED" if any(agendas) else "CLOSED", path=None, counts=dict(counts))
    a, b = [], []
    term = middle
    while parents[0][term] is not None:
        term, step = parents[0][term]
        a.append(step)
    term = middle
    while parents[1][term] is not None:
        term, (rule, side, path, bindings) = parents[1][term]
        b.append((rule, 1-side, path, bindings))
    return dict(status="PROVED", path=(*reversed(a), *b), counts=dict(counts))
