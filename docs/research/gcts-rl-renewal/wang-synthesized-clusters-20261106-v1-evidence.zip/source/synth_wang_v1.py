"""Replay the selected reusable laws and all returned held-out proofs in Wang tiles."""
import gzip
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from mul_cases_v1 import AXIOMS, Equality
from mul_study_v1 import checked_case, evaluate as instantiate
from mul_wang_v1 import elaborate
from rl_cases_v1 import dataset
from rl_study_v1 import inventory
from synth_study_v1 import direct
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from schematic_capsules_v1 import encoded, frozen

BANK=ROOT/"wang/data"


def prepare(result):
    prior=inventory()
    wires,bundles={},{}
    def prove(eq,path,label):
        imports,answer=checked_case(eq,direct(path),prior)
        checked=answer["direct"]
        sources,functions,proof,segments=elaborate(eq,checked,(*AXIOMS,*prior))
        keys=[]
        for i,row in enumerate(proof):
            names,prefix,word=fragment(proof,i,sources,functions)
            parsed=decoder.read(prefix,word+"!",require_empty=False)
            match(proof,i,sources,names,parsed,prefix)
            key=fingerprint(prefix,records(word))
            wire=wires.setdefault(key,dict(prefix=prefix,word=word,example=(label,i+1),
                                           uses=0,rule=row["rule"]))
            assert (prefix,word)==(wire["prefix"],wire["word"])
            wire["uses"]+=1
            keys.append(key)
        bundles[label]=dict(equation=vars(eq),imports=imports,lines=checked["lines"],sources=sources,
                            clauses=proof,calls=keys,segments=segments)

    for mode,n in result["selected"].items():
        for item in result["banks"][mode][:n]:
            eq=Equality(**item["equation"])
            parameters={v:(f"parameter{i}",) for i,v in enumerate(eq.variables)}
            expansion=tuple((r,s,p,tuple((v,instantiate(t,parameters)) for v,t in args))
                            for r,s,p,args in item["expansion"])
            prove(eq,expansion,eq.name)
    goals={eq.name:eq for split,_,eq in dataset() if split=="test"}
    for mode,rows in result["test"].items():
        for row in rows:
            if "expanded_path" in row["result"]:
                prove(goals[row["name"]],row["result"]["expanded_path"],mode+"/"+row["name"])
    return wires,bundles


def main():
    if not __debug__:
        raise RuntimeError("Proof replay requires assertions")
    data=frozen(json.loads((ROOT/"data/synth-study-v1.json").read_text()))
    wires,bundles=prepare(data)
    rebuild="--build" in sys.argv
    bank_file=BANK/"synth-bank-v1.json.gz"
    bank=build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_file.read_bytes()))
    outcome=dict(laws=sum("/" not in k for k in bundles),test_proofs=sum("/" in k for k in bundles),
                 records=sum(w["uses"] for w in wires.values()),**verify_bank(wires,bank))
    for path,body,compressed in ((bank_file,bank,True),(BANK/"synth-proofs-v1.json.gz",bundles,True),
                                 (BANK/"synth-receipt-v1.json",outcome,False)):
        expected=encoded(body)+b"\n"
        if rebuild:
            path.write_bytes(gzip.compress(expected,mtime=0) if compressed else expected)
        else:
            raw=path.read_bytes()
            assert (gzip.decompress(raw) if compressed else raw)==expected
    print(json.dumps(outcome,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
