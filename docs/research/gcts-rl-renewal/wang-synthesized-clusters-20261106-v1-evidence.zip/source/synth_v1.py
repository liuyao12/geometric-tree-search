"""Infer composable equality schemas by unifying constraints from checked proof segments."""
from itertools import count
from dataclasses import dataclass

from mul_cases_v1 import Equality
from rewrite_search_v1 import at, replace, variables


@dataclass(frozen=True)
class Macro:
    equation: Equality
    expansion: tuple
    donors: tuple


def common(paths):
    p = min(paths)
    q = max(paths)
    i = 0
    while i < min(len(p), len(q)) and p[i] == q[i]:
        i += 1
    return p[:i]


class Constraints:
    def __init__(self):
        self.next = count()
        self.env = {}

    def fresh(self):
        return f"?local{next(self.next)}"

    def head(self, t):
        while isinstance(t, str) and t in self.env:
            t = self.env[t]
        return t

    def expand(self, t):
        t = self.head(t)
        return t if isinstance(t, str) else (t[0], *(self.expand(v) for v in t[1:]))

    def unify(self, left, right):
        left, right = self.head(left), self.head(right)
        if left == right:
            return
        if isinstance(right, str) and not isinstance(left, str):
            left, right = right, left
        if isinstance(left, str):
            assert left not in variables(self.expand(right))
            self.env[left] = right
            return
        assert left[0] == right[0] and len(left) == len(right)
        for a, b in zip(left[1:],right[1:],strict=True):
            self.unify(a,b)

    def site(self, current, witness, path):
        if not path:
            return self.head(current)
        i, *rest = path
        current = self.head(current)
        if isinstance(current, str):
            shaped = (witness[0], *(self.fresh() for _ in witness[1:]))
            self.unify(current, shaped)
            current = shaped
        assert current[0] == witness[0] and len(current) == len(witness)
        return self.site(current[i], witness[i], rest)

    def rewrite(self, current, path, term):
        if not path:
            return term
        current = self.head(current)
        i, *rest = path
        return (*current[:i], self.rewrite(current[i], rest, term), *current[i+1:])


def substitute(t, values):
    if isinstance(t,str):
        return values[t]
    return (t[0], *(substitute(a,values) for a in t[1:]))


def normalized(left,right,steps=()):
    def ordered(a,b,records):
        mapping = {}
        def visit(t):
            if isinstance(t,str):
                return mapping.setdefault(t, f"?v{len(mapping)}")
            return (t[0], *(visit(v) for v in t[1:]))
        a,b=visit(a),visit(b)
        return a,b,tuple((rule,side,path,tuple((v,substitute(t,mapping)) for v,t in env))
                         for rule,side,path,env in records)
    fwd=ordered(left,right,steps)
    rev=ordered(right,left,tuple((r,1-s,p,e) for r,s,p,e in reversed(steps)))
    return min(fwd,rev,key=lambda x: repr(x[:2]))


def synthesize(lines, rules):
    """Lift a concrete sequence to a law using the constructor constraints it actually needed."""
    prefix=common([line["path"] for line in lines])
    c=Constraints()
    initial=current=c.fresh()
    history=[]
    for line in lines:
        rule=rules[line["rule"]]
        path=line["path"][len(prefix):]
        witness=at(line["before"],prefix)
        part=c.site(current,witness,path)
        env={v:c.fresh() for v in rule.variables}
        a,b=(substitute(t,env) for t in (rule.left,rule.right))
        if line["side"]:
            a,b=b,a
        c.unify(part,a)
        current=c.rewrite(current,path,b)
        history.append((rule.name,line["side"],path,env))
    left,right=c.expand(initial),c.expand(current)
    scope=variables(left)
    if isinstance(left,str) or isinstance(right,str) or left==right or scope!=variables(right):
        return None
    steps=tuple((r,s,p,tuple(sorted((v,c.expand(t)) for v,t in env.items()))) for r,s,p,env in history)
    if any(not variables(t)<=scope for *_,env in steps for v,t in env):
        return None
    return normalized(left,right,steps)
