"""A second exact receptor at a distant constructor in each rewrite pattern."""
from collections import defaultdict
from rewrite_search_v1 import Offers


def constructors(term, path=()):
    if isinstance(term,str):
        return
    yield path,term[0]
    for i,v in enumerate(term[1:],1):
        yield from constructors(v,(*path,i))


def head_at(t,path):
    for i in path:
        if i>=len(t):
            return None
        t=t[i]
    return t[0]


class RoutedOffers(Offers):
    def __init__(self,rules,indexed):
        assert indexed
        super().__init__(rules,indexed)
        self.routes={}
        for head,specs in self.heads.items():
            paths=defaultdict(lambda:defaultdict(list))
            always=[]
            for order,spec in enumerate(specs):
                path,required=max(constructors(spec[2]),key=lambda x:(len(x[0]),x[0]))
                if not path:
                    always.append((order,spec))
                else:
                    paths[path][required].append((order,spec))
            self.routes[head]=(always,dict(paths))

    def candidates(self,part):
        default,paths=self.routes.get(part[0],((),{}))
        rows=list(default)
        for path,by_head in paths.items():
            self.counts["receptors"]+=1
            rows.extend(by_head.get(head_at(part,path),()))
        return (spec for _,spec in sorted(rows))
