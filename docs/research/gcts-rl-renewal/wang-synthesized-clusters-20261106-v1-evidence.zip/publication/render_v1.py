"""Render the controlled library experiment and concrete checked substitutions."""
import gzip
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ("source","publication","wang/source")]
from boundary_kernel_v1 import build
from mul_study_v1 import frozen
from proof_views_v1 import math,frame_window,tile_svg
from rewrite_search_v1 import match,put
from synth_study_v1 import CAPS, MODES,measure

NAME="wang-synthesized-clusters-20261106-v1"
TITLE="Proof clusters found by arithmetic search"
LABELS={"primitive":"Primitive moves","whole":"Whole donor theorems",
        "literal":"Donor-shaped clusters","synthesized":"Generalized clusters"}


def read(path,zipped=False):
    b=(ROOT/path).read_bytes()
    return frozen(json.loads(gzip.decompress(b) if zipped else b))


def term(t,variables,prec=0):
    if isinstance(t,str):
        return (r"u_{"+t[2:]+"}") if t.startswith("?v") and t[2:].isdigit() else t[1:]
    head,*args=t
    if head.startswith("parameter"):
        return term(variables[int(head[9:])],variables)
    if head=="zero":
        return "0"
    if head=="S":
        return "S("+term(args[0],variables)+")"
    op,rank={"plus":("+",1),"times":(r"\times ",2)}[head]
    body=term(args[0],variables,rank)+op+term(args[1],variables,rank+1)
    return "("+body+")" if prec>rank else body


def equality(a,b,variables):
    return math(term(a,variables)+"="+term(b,variables))


def novel(data):
    bank={m["equation"]["name"]:m for m in data["banks"]["synthesized"]}
    literal=[m["equation"] for m in data["banks"]["literal"]]
    offers=[]
    for row in data["test"]["synthesized"]:
        for i,(name,side,path,args) in enumerate(row["result"]["path"] or ()):
            if name not in bank or not any(len(t)>1 for _,t in args):
                continue
            eq=bank[name]["equation"]
            a,b=(put(eq[k],dict(args)) for k in ("left","right"))
            if side:
                a,b=b,a
            covered=False
            for e in literal:
                for u,v in ((e["left"],e["right"]),(e["right"],e["left"])):
                    env={}
                    if match(u,a,env) and put(v,env)==b:
                        covered=True
            if not covered:
                offers.append(dict(problem=row["name"],line=i+1,name=name,left=a,right=b,args=args))
    assert offers
    return offers


def trace(bundle):
    variables=bundle["equation"]["variables"]
    lines=[]
    for row, ids in zip(bundle["lines"],bundle["segments"][:-1],strict=True):
        direction=" in reverse" if row["side"] else ""
        label=row["rule"].replace("-"," ")
        span=f'{ids[0]+1}–{ids[-1]+1}'
        lines.append(f'<li><div class="mathline">{equality(row["before"],row["after"],variables)}</div>'
                     f'<span>Apply {label}{direction}.</span> <small>Wang records {span}</small></li>')
    return '<ol class="steps">'+"".join(lines)+"</ol>"


def window(bank,key):
    machine=build().compile()
    assert machine.digest()==bank["machine"]
    e=bank["traces"][key]
    end=e["steps"]
    tape=dict(prefix=e["prefix"],word=e["word"],padding=0,trace=e["fragment"])
    rows,first=frame_window(machine,tape,end-5,e["head"])
    types,uses={},[]
    for y,row in enumerate(rows):
        for x,t in enumerate(row):
            j=types.setdefault(t,len(types))
            uses.append(f'<use href="#wang-{j}" x="{36*x}" y="{36*y}"/>')
    defs="".join(tile_svg(t,i) for t,i in types.items())
    return (f'<figure><svg role="img" aria-label="45 checked Wang squares" viewBox="0 0 324 180"><defs>{defs}</defs>'
            f'{"".join(uses)}</svg><figcaption>Verifier rows {end-4:,} to {end:,} and tape columns '
            f'{first:,} to {first+8:,}. Point to a square for its exact edge labels.</figcaption></figure>')


def main():
    data=read("data/synth-study-v1.json")
    receipt=read("wang/data/synth-receipt-v1.json")
    bank=read("wang/data/synth-bank-v1.json.gz",True)
    proof=read("wang/data/synth-proofs-v1.json.gz",True)
    summary,routing=[],[]
    for mode in MODES:
        q=data["test"][mode]
        found="".join(f'<td>{measure(q,c)[0]} of {len(q)}</td>' for c in CAPS)
        summary.append(f'<tr><th scope="row">{LABELS[mode]}</th><td>{data["selected"].get(mode,0)}</td>{found}</tr>')
        r=data["routing"][mode]
        routing.append(f'<tr><th scope="row">{LABELS[mode]}</th><td>{r["plain"]:,}</td>'
                       f'<td>{r["marked"]:,}</td><td>{r["probes"]:,}</td></tr>')
    cases=novel(data)
    one=cases[0]
    formula=proof[one["name"]]["equation"]
    recipe=trace(proof[one["name"]])
    receiver=proof["synthesized/"+one["problem"]]
    variables=receiver["equation"]["variables"]
    inputs="".join(f'<li>{math(term(v,variables)+r"\mapsto "+term(t,variables))}</li>' for v,t in one["args"])
    triple=next(r for r in data["test"]["literal"] if r["family"]=="triple-factor-grid" and r["result"]["path"])
    triple_proof=proof["literal/"+triple["name"]]
    vals=dict(
        title=TITLE,stem=NAME,summary="".join(summary),routing="".join(routing),
        novel=str(len(cases)),law=equality(formula["left"],formula["right"],formula["variables"]),
        instance=equality(one["left"],one["right"],variables),bindings=inputs,recipe=recipe,
        donor_trace=trace(receiver),triple_trace=trace(triple_proof),
        macro_steps=str(len(triple["result"]["path"])),primitive_steps=str(len(triple_proof["lines"])),
        proof_count=str(receipt["test_proofs"]),laws=str(receipt["laws"]),records=f'{receipt["records"]:,}',
        squares=window(bank,proof[one["name"]]["calls"][-1]),
    )
    head=(ROOT/"publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs",TITLE)
    head=head.replace("</style>","""
.steps li{padding:.4rem .2rem;border-bottom:1px solid #d3e0e5}.mathline{overflow:auto}
#tiles figure{max-width:33rem}.receptor{padding:.7rem;background:#e6f2f1;border-radius:.35rem;overflow:auto}
</style>""")
    body=(ROOT/"publication/synth-body-v1.html").read_text()
    for k,v in vals.items():
        body=body.replace("%%"+k.upper()+"%%",v)
    assert "%%" not in body
    (ROOT/"report"/(NAME+".html")).write_text(head+body)


if __name__=="__main__":
    main()
