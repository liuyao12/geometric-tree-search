const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/wang-synthesized-clusters-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#family mjx-container").first().waitFor();
      assert.equal(await page.locator("#comparison tbody tr").count(), 4);
      assert.equal(await page.locator("#routing tbody tr").count(), 4);
      assert.match(await page.locator("#comparison tbody tr").nth(2).textContent(), /29 of 40/);
      assert.equal(await page.locator("#family .receptor").count(), 2);
      assert.equal(await page.locator("#tiles use").count(), 45);
      await page.getByText("Read the three-factor proof").click();
      assert.ok(await page.locator("#comparison .steps li:visible").count() > 7);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.deepEqual(errors, []);
      const layout = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        sections: [...document.querySelectorAll("main > section")].filter(node =>
          node.scrollWidth > node.clientWidth + 4).map(node => node.id),
      }));
      assert.deepEqual(layout, { width, sections: [] });
      await page.locator("#family").screenshot({ path: "publication/family-" + width + ".png" });
      console.log("Verified", width, "px, search comparison, proof disclosure and Wang squares.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
