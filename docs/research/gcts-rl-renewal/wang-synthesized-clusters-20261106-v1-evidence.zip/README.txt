Proof clusters found by arithmetic search

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/synth_study_v1.py
  python3 -I -S -B source/synth_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The first command repeats donor search, cluster synthesis, calibration, and
held-out evaluation, checking every primitive expansion. The second replays
the admitted laws and successful held-out runs on the fixed Wang palette.
Either accepts --build to regenerate its checked data. The last command
regenerates the proof reader. MathJax typesets its formulas.
The manifest gives SHA-256 for each included input and result.
