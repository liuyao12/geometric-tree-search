# Replay the composed Wang lemmas

Use Python 3.12 and its standard library. In an extracted copy, preserve
the supplied evidence and run these commands from the archive root.

    mv data archived-data
    mkdir data
    python3.12 -I -S -B source/lemma_cases_v1.py
    python3.12 -I -S -B source/lemma_experiment_v1.py
    python3.12 -I -S -B source/lemma_hybrid_v1.py
    python3.12 -I -S -B source/lemma_audit_v1.py
    python3.12 -I -S -B publication/render_v1.py

The first script freezes the theorem inputs. The next two scripts
construct the lemma families from searched donor proofs, run the paired
searches, and store exact compressed Wang certificates. The audit can
also run directly on the included data without repeating search. It
checks source bindings, recursively checks lemma attachments, replays
stored primitive traces and full rectangles, and validates both finite
countermodels.

Use the hashes in `publication/replay-v1.json` to compare the scientific
outputs. To qualify the HTML with MathJax and headless Chromium, set
`GCTS_CHROME` and `GCTS_PLAYWRIGHT` for custom installations and run
`node publication/check_v1.cjs`.
