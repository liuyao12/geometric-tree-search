"""Render the composed proof inventory and its exact Wang proof windows."""
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"publication"))
from proof_views_v1 import math, proof_section
from boundary_kernel_v1 import build

STEM = "wang-composed-lemmas-20261106-v1"


def read(name):
    return json.loads((ROOT/"data"/f"{name}-v1.json").read_text())


def title(statement):
    family, length = statement["id"].removesuffix("-control").rsplit("-", 1)
    if statement["expected"] == "NO_WITNESS":
        return "Peano missing premise" if family.startswith("peano") else "Incidence missing premise"
    name = "Peano injectivity" if family.startswith("peano") else "Hilbert incidence transport"
    return f"{name} ({length} links)"


def row(label, *values):
    cells = "".join(f"<td>{v:,}</td>" if isinstance(v,int) else f"<td>{escape(v)}</td>" for v in values)
    return f'<tr><th scope="row">{escape(label)}</th>{cells}</tr>'


def count(run, key):
    return run["counts"].get(key,0)


def work(run):
    return count(run,"native_steps")+count(run,"parent_steps")


def main():
    base, hybrid, audit = map(read, ("results","hybrid","audit"))
    machine = build().compile()
    assert machine.digest() == base["machine_sha256"]
    paired = {c["statement"]["id"]:c for c in hybrid["cases"]}
    tables, operations, rank, sections, jumps = [], [], [], [], []

    def include(source, proof, name, key):
        sections.append(proof_section(source, proof, machine, name, key))
        jumps.append(f'<a href="#{key}">{escape(name)}</a>')

    for cohort,name in ((base,"Chain donor"),(hybrid,"Discharge donor")):
        donor = cohort["donor"]
        include(donor["statement"],donor["proof"],name,donor["statement"]["id"])
    for case in base["cases"]:
        source = case["statement"]
        key, name = source["id"], title(source)
        direct, atomic, chain, learned = case["arms"]
        both = paired.get(key)
        checks = [count(arm,"atomic_resolutions") for arm in (direct,atomic,chain)]
        tables.append(row(name,*checks,count(both,"atomic_resolutions") if both else "—",
                          chain.get("expanded_lines") or "No witness"))
        if chain.get("proof"):
            operations.append(row(name,work(atomic),work(chain),work(both) if both else "—"))
            rank.append(row(name,count(chain,"receptor_branches"),count(learned,"receptor_branches"),
                            count(chain,"macro_invocations"),count(learned,"macro_invocations")))
            include(source,chain["proof"],name,key)
            if both:
                include(source,both["proof"],name+" with both families",key+"-composed")

    assert len(sections) == audit["frames"]
    template = (ROOT/"publication/notebook-v1.html").read_text()
    ladder = "".join(f'<span class="base-step">{math(r"A_{"+str(i)+"}"+r"\to A_{"+str(i+1)+"}")}</span>'
                     for i in range(8))
    replacements = dict(STEM=STEM,LADDER=ladder,TABLE="".join(tables),WORK="".join(operations),
                        RANK="".join(rank),PROOFS="\n".join(sections),JUMPS="".join(jumps),
                        LINES=str(audit["decoded_lines"]),FRAMES=str(audit["frames"]),
                        TRACES=str(audit["local_traces"]),CALLS=str(audit["chain_invocations"]+audit["discharge_invocations"]),
                        TRAIN=str(len(base["training"])),
                        LARGE_FRAME=f'{paired["hilbert-incidence-transport-4"]["proof"]["receipt"]["steps"]:,}')
    for key,value in replacements.items():
        template = template.replace("%%"+key+"%%",value)
    assert "%%" not in template
    (ROOT/"report"/f"{STEM}.html").write_text(template)


if __name__ == "__main__":
    main()
