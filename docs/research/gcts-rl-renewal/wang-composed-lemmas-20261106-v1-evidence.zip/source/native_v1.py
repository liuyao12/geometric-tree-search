"""Use the published Wang machine to admit individual resolution moves."""
from collections import Counter, OrderedDict
from copy import copy
from dataclasses import dataclass

from boundary_kernel_v1 import build
from sparse_frame_v1 import FixedPalette, Sweeps, update_tiles

PUBLISHED_MACHINE = "3d97b22704bf8da27992d74dfb897c312da9274d0cb6298ef447498a7db2c4b6"
CAP = 100_000_000


@dataclass
class Fragment:
    q: int
    head: int
    steps: int
    high: int
    label: str
    read: str
    events: list


class Admission:
    def __init__(self):
        self.machine = build().compile()
        assert self.machine.digest() == PUBLISHED_MACHINE
        self.sweep_table = Sweeps(self.machine, [])
        self.palette = FixedPalette(self.machine)
        self.finish = self.machine.names.index("finish")
        self.columns_per_character = len(self.machine.marks) + 1
        self.checkpoints = OrderedDict()
        self.counts = Counter()

    def tape(self, prefix, suffix):
        chars, _ = self.machine.input(prefix, suffix)
        value = copy(self.sweep_table)
        value.data = bytearray(value.codes[x] for x in chars)
        value.reverse = value.data[::-1]
        return value

    def advance(self, tape, q, h, *, record=False):
        steps, high, events = 0, -1, []
        label, read = "", ""
        while q not in (0, 1) and 0 <= h < len(tape.data) and steps < CAP:
            high = max(high, h)
            nxt, write, d = tape.transition(q, h)
            if nxt == q and write == tape.data[h] and d:
                run = tape.sweep(q, h, d)
                assert run
                high = max(high, h + (run-1)*d)
                if record:
                    events.append([run, d])
                h += run*d
                steps += run
            else:
                if nxt in (0, 1, self.finish):
                    label = self.machine.read_labels.get(q, self.machine.names[q])
                    read = tape.symbols[tape.data[h]]
                if record:
                    events.append([nxt, write, d])
                tape.write(h, write)
                q, h, steps = nxt, h+d, steps+1
                if q == self.finish:
                    break
        if steps >= CAP or not 0 <= h < len(tape.data):
            raise RuntimeError("Admission exceeded its tape or step budget")
        return Fragment(q, h, steps, high, label, read, events)

    @staticmethod
    def parent_text(left, right):
        return ">C0:"+left+";C1:"+right+";#", "G0:0:/"+left+";G1:1:/"+right+";"

    def checkpoint(self, left, right):
        key = left, right
        if key not in self.checkpoints:
            prefix, previous = self.parent_text(left, right)
            tape = self.tape(prefix, previous)
            q, h = self.machine.start, 0
            cut = (len(prefix)+len(previous))*self.columns_per_character
            events = []
            for _ in range(2):
                stage = self.advance(tape, q, h, record=True)
                q, h = stage.q, stage.head
                assert q == self.finish and max(stage.high, h) < cut
                events.extend(stage.events)
                self.counts["parent_steps"] += stage.steps
            self.checkpoints[key] = (bytes(tape.data[:cut]), q, h, events)
            self.counts["parent_checkpoints"] += 1
            if len(self.checkpoints) > 64:
                self.checkpoints.popitem(last=False)
        else:
            self.checkpoints.move_to_end(key)
            self.counts["parent_reuses"] += 1
        return self.checkpoints[key]

    def test(self, left, right, pivot, clause, *, record=False):
        prefix, previous = self.parent_text(left, right)
        suffix = "R10:0:1:"+pivot+"/"+clause+";"
        start, q, h, old = self.checkpoint(left, right)
        tape = self.tape(prefix, previous+suffix)
        assert h < len(start) and len(start) < len(tape.data)
        tape.data[:len(start)] = start
        tape.reverse = tape.data[::-1]
        stage = self.advance(tape, q, h, record=record)
        assert stage.q in (self.finish, 1)
        assert max(stage.high, stage.head) < (len(prefix)+len(previous)+len(suffix))*self.columns_per_character
        self.counts["attempts"] += 1
        self.counts["candidate_steps"] += stage.steps
        self.counts["accepted" if stage.q == self.finish else "rejected"] += 1
        if record:
            return stage, {"prefix": prefix, "word": previous+suffix, "parents": old,
                           "fragment": stage.events, "stop": stage.q, "head": stage.head,
                           "label": stage.label, "read": stage.read}
        return stage, None

    def replay(self, evidence):
        """Verify the physical traces using local squares and exact sweep ranges."""
        tape = self.tape(evidence["prefix"], evidence["word"])
        q, h, steps, fragments = self.machine.start, 0, 0, 0
        label, read = "", ""
        for event in evidence["parents"]+evidence["fragment"]:
            assert q not in (0, 1)
            if len(event) == 2:
                n, d = event
                assert d in (-1, 1) and n > 0 and 0 <= h+n*d < len(tape.data)
                assert tape.sweep(q, h, d, n) == n
                for x in {h, h+(n-1)*d}:
                    update_tiles(self.palette, tape, q, x, q, tape.data[x], d)
                h += n*d
                steps += n
            else:
                nxt, write, d = event
                assert all(type(k) is int for k in event) and d in (-1, 0, 1)
                assert 0 <= nxt < len(self.machine.names) and 0 <= write < len(tape.symbols)
                if nxt in (0, 1, self.finish):
                    label = self.machine.read_labels.get(q, self.machine.names[q])
                    read = tape.symbols[tape.data[h]]
                update_tiles(self.palette, tape, q, h, nxt, write, d)
                tape.write(h, write)
                q, h = nxt, h+d
                steps += 1
                fragments += q == self.finish
        assert q == evidence["stop"] and h == evidence["head"]
        assert (label, read) == (evidence["label"], evidence["read"])
        assert fragments == (3 if q == self.finish else 2)
        return steps
