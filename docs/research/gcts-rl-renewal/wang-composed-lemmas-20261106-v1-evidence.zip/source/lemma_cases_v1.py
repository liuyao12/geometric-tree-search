"""First-order statements and exact backward grounding for the lemma study."""
from collections import defaultdict
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import study_v1 as logic


def atom(name,*args):
    return ["atom",name,*args]


def forall(names,formula):
    for name,sort in reversed(names):
        formula=["all",name,sort,formula]
    return formula


def imply(body,head):
    body=list(body)
    left=body.pop()
    while body:
        left=["and",body.pop(),left]
    return ["implies",left,head]


def donor():
    x="?x"
    a=["a"]
    pre=forall(((x,"U"),),imply((atom("P",x),),atom("Q",x)))
    post=forall(((x,"U"),),imply((atom("Q",x),),atom("R",x)))
    return dict(id="implication-donor",sorts=["U"],functions={"a":[[],"U"]},equality=False,
                predicates={k:["U"] for k in ("P","Q","R")},premises=[atom("P",a),pre,post],
                goal=atom("R",a),depth=0,expected="PROVED")


def successors(term,n):
    for _ in range(n):
        term=["S",term]
    return term


def arithmetic(n,control=False):
    x,y="?x","?y"
    a,b=["a"],["b"]
    e=lambda u,v:atom("=Nat",u,v)
    source=forall(((x,"Nat"),(y,"Nat")),imply((e(successors(x,1),successors(y,1)),),e(x,y)))
    premises=[source]
    if not control:
        premises.append(e(successors(a,n),successors(b,n)))
    return dict(id=f"peano-injectivity-{n}"+("-control" if control else ""),sorts=["Nat"],
                functions={"a":[[],"Nat"],"b":[[],"Nat"],"S":[["Nat"],"Nat"]},
                predicates={},equality=True,premises=premises,goal=e(a,b),depth=n,
                expected="NO_WITNESS" if control else "PROVED")


def incidence(n,control=False):
    a,b,p,l,m="?a","?b","?p","?l","?m"
    i=lambda x,y:atom("I",x,y)
    d=lambda x,y:atom("D",x,y)
    e=lambda x,y:atom("=Line",x,y)
    unique=forall(((a,"Point"),(b,"Point"),(l,"Line"),(m,"Line")),
                  imply((d(a,b),i(a,l),i(b,l),i(a,m),i(b,m)),e(l,m)))
    carry=forall(((p,"Point"),(l,"Line"),(m,"Line")),imply((e(l,m),i(p,l)),i(p,m)))
    line=[["ell"+str(k)] for k in range(n+1)]
    points=[["a"],["b"],["p"]]
    a,b,p=points
    premises=[unique,carry,d(a,b),i(a,line[0]),i(b,line[0]),i(a,line[1]),i(b,line[1]),i(p,line[0])]
    for k in range(1,n):
        if not control or k!=1:
            premises.append(e(line[k],line[k+1]))
    return dict(id=f"hilbert-incidence-transport-{n}"+("-control" if control else ""),
                sorts=["Point","Line"],functions={**{x[0]:[[],"Line"] for x in line},
                                                  **{x[0]:[[],"Point"] for x in points}},
                predicates={"D":["Point","Point"],"I":["Point","Line"]},
                equality=True,premises=premises,goal=i(p,line[-1]),depth=0,
                static_join=["formula1-clause1"],
                expected="NO_WITNESS" if control else "PROVED")


def cases():
    return [donor(),*(arithmetic(n) for n in (2,4,8)),*(incidence(n) for n in (2,4)),
            arithmetic(4,True),incidence(3,True)]


def bind(pattern,ground,env):
    if isinstance(pattern,str):
        return env.setdefault(pattern,ground)==ground
    return (isinstance(ground,tuple) and pattern[0]==ground[0] and len(pattern)==len(ground)
            and all(bind(x,y,env) for x,y in zip(pattern[1:],ground[1:],strict=True)))


@dataclass(frozen=True)
class Rule:
    schema:str
    bindings:tuple
    head:tuple
    body:tuple

    @property
    def clause(self):
        return frozenset(((True,self.head),*((False,t) for t in self.body)))


class Theory:
    def __init__(self,case):
        self.case=case
        normal,_=logic.front_v1.clausify(case,1024)
        functions,predicates,all_schemas=logic.fol.signature(normal)
        # The query uses explicitly supplied axiom formulas. The native
        # verifier checks their typed normalization and the denied goal.
        self.schemas=tuple(s for s in all_schemas if s["id"].startswith("formula"))
        self.functions=functions
        self.predicates=predicates
        self.depth=case["depth"]
        self.terms=logic.fol.ground_terms(normal,functions,self.depth,256)
        assert self.terms is not None
        self.domain={s:set(ts) for s,ts in self.terms.items()}
        self.goal=logic.fol.frozen(case["goal"][1:])
        self.denial=self.schemas[-1]["id"]
        assert self.schemas[-1]["clause"]==((False,self.goal),)
        self.entries=defaultdict(list)
        extensional={}
        for row in self.schemas[:-1]:
            head,=[a for sign,a in row["clause"] if sign]
            body=tuple(a for sign,a in row["clause"] if not sign)
            self.entries[head[0]].append((row,head,body))
            extensional[head[0]]=extensional.get(head[0],True) and not (body or row["variables"])
        self.facts={k:tuple(a for _,a,_ in self.entries[k]) for k,yes in extensional.items() if yes}
        self.ground_facts={k:tuple(a for row,a,b in entries if not (b or row["variables"]))
                           for k,entries in self.entries.items()}
        prefix,ids=logic.guarded(self.schemas,functions,normal["sorts"])
        self.builder=logic.Certificate(prefix,functions,predicates,normal["sorts"],ids)

    @lru_cache(maxsize=None)
    def rules(self,goal):
        result=[]
        for row,head,body in self.entries.get(goal[0],()):
            env={}
            if not bind(head,goal,env):
                continue
            environments=[env]
            for pattern in body:
                facts=self.ground_facts if row["id"] in self.case.get("static_join",()) else self.facts
                if pattern[0] in facts:
                    possible=[]
                    for mapping in environments:
                        for fact in facts[pattern[0]]:
                            copy=mapping.copy()
                            if bind(pattern,fact,copy):
                                possible.append(copy)
                    environments=possible
            for partial in environments:
                missing=sorted(row["variables"].keys()-partial.keys())
                for values in product(*(self.terms[row["variables"][p]] for p in missing)):
                    theta={**partial,**dict(zip(missing,values,strict=True))}
                    if any(t not in self.domain[row["variables"][v]] for v,t in theta.items()):
                        continue
                    arguments=tuple(dict.fromkeys(logic.substitute(a,theta) for a in body))
                    if any(t not in self.domain[s] for a in arguments
                           for s,t in zip(self.predicates[a[0]],a[1:],strict=True)):
                        continue
                    result.append(Rule(row["id"],tuple(sorted(theta.items())),goal,arguments))
        return tuple(sorted(set(result),key=lambda r:(len(r.body),r.schema,repr(r.bindings))))

    def continuation(self,rule):
        if len(rule.body)==1:
            return rule.body[0]
        possibilities=[b for b in rule.body if b[0]==rule.head[0]]
        return possibilities[0] if len(possibilities)==1 else None


if __name__=="__main__":
    records=cases()
    (ROOT/"input/cases-v1.json").write_text(json.dumps(records,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps([r["id"] for r in records]))
