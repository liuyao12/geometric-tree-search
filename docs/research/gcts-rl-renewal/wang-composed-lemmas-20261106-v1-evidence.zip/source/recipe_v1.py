"""Learn and compose a positive proof receptor from a checked donor path."""
from dataclasses import dataclass


def unit(a):
    return frozenset(((True,a),))


def link(a,b):
    return frozenset(((False,a),(True,b)))


def conclusion(left,right,pivot):
    assert (True,pivot) in left and (False,pivot) in right
    return (left-{(True,pivot)})|(right-{(False,pivot)})


@dataclass(frozen=True)
class Recipe:
    length:int
    leaves:tuple
    steps:tuple
    child:int|None=None
    calls:tuple=()

    @property
    def output(self):
        return unit(self.length)


def specialize(row,values):
    return frozenset((p,values[x]) for p,x in row)


def attach(recipe,leaves):
    if len(leaves)!=len(recipe.leaves):
        return None
    values={}
    for expected,current in zip(recipe.leaves,leaves,strict=True):
        if len(expected)!=len(current):
            return None
        for p,x in expected:
            matches=[a for q,a in current if p==q]
            if len(matches)!=1 or values.setdefault(x,matches[0])!=matches[0]:
                return None
    if len(set(values.values()))!=len(values) or set(values)!=set(range(recipe.length+1)):
        return None
    return values


def replay(recipe,library,leaves,resolve):
    """Expand a checked invocation into primitive steps in dependency order."""
    rows=list(leaves)
    if recipe.child is None:
        for left,right,pivot,result in recipe.steps:
            rows.append(resolve(rows[left],rows[right],pivot,result))
    else:
        child=library[recipe.child]
        for indices,aliases in recipe.calls:
            args=[rows[i] for i in indices]
            rows.append(replay(child,library,args,
                               lambda l,r,p,row,a=aliases:resolve(l,r,a[p],specialize(row,a))))
    return rows[-1]


def qualify(recipe,library):
    def resolve(left,right,pivot,result):
        assert conclusion(left,right,pivot)==result
        return result
    assert replay(recipe,library,recipe.leaves,resolve)==recipe.output


def grow(search,root):
    """Recover the two-step chain from the native donor's positive proof."""
    node=root
    backward=[]
    for _ in range(2):
        rule=search.nodes[node]
        assert rule["kind"]=="resolve"
        a,b,p=rule["left"],rule["right"],rule["pivot"]
        head,=tuple(q for positive,q in rule["clause"] if positive)
        assert rule["clause"]==unit(head)
        assert search.nodes[a]["clause"]==unit(p)
        assert search.nodes[b]["clause"]==link(p,head) and search.nodes[b]["kind"]=="source"
        backward.append((b,p,head))
        node=a
    assert search.nodes[node]["kind"]=="source"
    path=list(reversed(backward))
    values=[path[0][1],*(row[2] for row in path)]
    assert len(set(values))==3
    leaves=(unit(0),link(0,1),link(1,2))
    base=Recipe(2,leaves,((0,1,0,unit(1)),(3,2,1,unit(2))))
    assert attach(base,[search.nodes[j]["clause"] for j in (node,*(r[0] for r in path))])==dict(enumerate(values))
    library={2:base}
    qualify(base,library)
    for size in (4,8):
        half=size//2
        leaves=(unit(0),*(link(i,i+1) for i in range(size)))
        left=(tuple(range(half+1)),tuple(range(half+1)))
        right=((len(leaves),*range(half+1,size+1)),tuple(range(half,size+1)))
        larger=Recipe(size,leaves,(),half,(left,right))
        qualify(larger,library)
        library[size]=larger
    return library,dict(path=values,leaves=(node,*(r[0] for r in path)),root=root)


def export(recipe):
    return dict(length=recipe.length,leaves=[sorted(x) for x in recipe.leaves],
                steps=[(a,b,p,sorted(row)) for a,b,p,row in recipe.steps],child=recipe.child,
                calls=recipe.calls)
