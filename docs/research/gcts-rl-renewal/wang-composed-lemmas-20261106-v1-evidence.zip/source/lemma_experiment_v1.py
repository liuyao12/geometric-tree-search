"""Run the native donor, receiver proofs, and a held-out ranking comparison."""
from collections import defaultdict
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
from random import Random
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from lemma_cases_v1 import Theory,atom,imply
from lemma_search_v1 import Search
from native_v1 import Admission
from recipe_v1 import attach,export,grow,qualify
from sparse_frame_v1 import execute,verify
import study_v1 as logic

FRAME_CAP=80_000_000_000
SEARCH_CAP=2500
ORDERS=("short","long")


class Bandit:
    def __init__(self):
        self.rng=Random(12119)
        self.results=defaultdict(lambda:defaultdict(list))

    def group(self,theory):
        rule_count=sum(any(not p for p,_ in r["clause"]) for r in theory.schemas[:-1])
        return "long" if max(rule_count,theory.depth)>=6 else "short"

    def choose(self,theory,train=False):
        examples=self.results[self.group(theory)]
        if train:
            unseen=[o for o in ORDERS if not examples[o]]
            if unseen:
                return unseen[0]
            if self.rng.random()<.25:
                return self.rng.choice(ORDERS)
        return min(ORDERS,key=lambda o:sum(examples[o])/len(examples[o]))

    def observe(self,theory,order,cost):
        self.results[self.group(theory)][order].append(cost)


def synthetic(n,index):
    name=lambda i: f"P{index}x{i}"
    p=lambda i:atom(name(i),["a"])
    rules=[imply((p(i),),p(i+1)) for i in range(n)]
    if index%2:
        # A disconnected incoming branch with no supporting fact.
        rules.append(imply((p(n+1),),p(n)))
    return dict(id=f"training-{index}",sorts=["U"],equality=False,depth=0,
                functions={"a":[[],"U"]},predicates={name(i):["U"] for i in range(n+2)},
                premises=[p(0),*rules],goal=p(n))


def train(library):
    policy=Bandit()
    episodes=[]
    for i,n in enumerate((1,3,5,6,7,9,4,3,7,6,2,9)):
        statement=synthetic(n,i)
        theory=Theory(statement)
        order=policy.choose(theory,True)
        s=Search(theory,library,Admission(),order=order,maximum=SEARCH_CAP)
        status,_=s.run()
        assert status=="PROVED"
        count=s.counters()
        cost=round(count.get("native_steps",0)/100000+2*count.get("receptor_branches",0)
                   +count.get("rule_attempts",0)+.5*count.get("macro_invocations",0),8)
        policy.observe(theory,order,cost)
        episodes.append(dict(id=statement["id"],length=n,order=order,counts=count,cost=cost,
                             group=policy.group(theory),statement=statement))
    return policy,episodes


def serialize(node):
    return {**node,"clause":sorted(node["clause"],key=repr)}


def frame(name,search,root,machine):
    builder,attachments=search.export(root)
    prefix,word=builder.prefix(),builder.words()
    raw=execute(machine,prefix,word,1,FRAME_CAP)
    assert raw["status"]=="ACCEPT", (name,raw["status"],raw["steps"])
    receipt=verify(machine,prefix,word,1,raw["trace"],FRAME_CAP)
    assert len(raw["commits"])==len(builder.lines)
    artifact=f"data/{name}-frame-v1.json.gz"
    logic.write_gzip(ROOT/artifact,dict(prefix=prefix,word=word,padding=1,trace=raw["trace"],
                                     machine_sha256=machine.digest()))
    return builder,dict(lines=builder.lines,source_clauses=list(builder.sources.values()),commits=raw["commits"],
                        attachments=attachments,receipt=receipt,artifact=artifact)


def check_forgery(search,builder,machine):
    call=search.nodes[search.invocations[-1]]
    template=search.library[call["recipe"]]
    leaves=[search.nodes[j]["clause"] for j in call["leaves"]]
    assert attach(template,leaves)
    wrong=list(leaves)
    wrong[1]=frozenset((not p,a) for p,a in wrong[1])
    assert attach(template,wrong) is None
    try:
        a,b=template.calls
        bad=replace(template,calls=(a,(b[0],tuple(reversed(b[1])))))
        qualify(bad,search.library)
    except AssertionError:
        nested=True
    else:
        raise AssertionError("Incorrect nested binding was accepted")
    changed=deepcopy(builder.lines)
    changed[-1]["left"]=changed[-1]["right"]
    result=execute(machine,builder.prefix(),builder.words(changed),1,FRAME_CAP)
    assert result["status"]=="REJECT"
    return dict(wrong_polarity_rejected=True,nested_alias_rejected=nested,
                altered_native_reference_rejected=True,rejection_steps=result["steps"])


def main():
    cases=json.loads((ROOT/"input/cases-v1.json").read_text())
    first,*receivers=cases
    admission=Admission()
    finder=Search(Theory(first),admission=admission,maximum=SEARCH_CAP)
    status,q=finder.run()
    assert status=="PROVED"
    _,donor_proof=frame(first["id"],finder,q,admission.machine)
    library,origin=grow(finder,q)
    policy,episodes=train(library)
    results=[]
    recordings={first["id"]:finder.traces}
    mutation=None
    for statement in receivers:
        record=[]
        name=statement["id"]
        for arm in ("conventional","atomic","lemmas","learned"):
            native=None if arm=="conventional" else Admission()
            theory=Theory(statement)
            order=policy.choose(theory) if arm=="learned" else "long"
            inventory=library if arm in ("lemmas","learned") else {}
            search=Search(theory,inventory,native,maximum=SEARCH_CAP,order=order)
            status,root=search.run()
            assert status==statement["expected"], (name,arm,status)
            row=dict(arm=arm,status=status,order=order,counts=search.counters(),
                     nodes=[serialize(n) for n in search.nodes],goal_node=root)
            if native:
                recordings[name+"/"+arm]=search.traces
            if root is not None:
                builder,attachments=search.export(root)
                row["expanded_lines"]=len(builder.lines)
                row["attachments"]=attachments
                if arm=="lemmas":
                    assert search.invocations
                    builder,proof=frame(name,search,root,native.machine)
                    row["proof"]=proof
                    if name=="peano-injectivity-4":
                        mutation=check_forgery(search,builder,native.machine)
            record.append(row)
            print(json.dumps(dict(id=name,arm=arm,status=status,order=order,counts=row["counts"],
                                  lines=row.get("expanded_lines"),
                                  frame=row.get("proof",{}).get("receipt",{}).get("steps")),sort_keys=True),flush=True)
        if statement["expected"]=="PROVED":
            assert len({a["expanded_lines"] for a in record if a["arm"]!="learned"})==1
        results.append(dict(statement=statement,arms=record))
    assert mutation is not None
    logic.write_gzip(ROOT/"data/local-traces-v1.json.gz",recordings)
    out=dict(status="CHECKED_RECURSIVE_PROOF_CLUSTERS",machine_sha256=admission.machine.digest(),
             donor=dict(statement=first,proof=donor_proof,nodes=[serialize(n) for n in finder.nodes],
                        origin=origin,counts=finder.counters()),
             recipes=[export(r) for r in library.values()],training=episodes,policy=policy.results,
             controls=mutation,cases=results,limits=dict(frame=FRAME_CAP,search=SEARCH_CAP))
    (ROOT/"data/results-v1.json").write_text(json.dumps(out,sort_keys=True,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
