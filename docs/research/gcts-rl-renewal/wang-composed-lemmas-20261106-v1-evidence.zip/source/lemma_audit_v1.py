"""Audit instantiated lemma receptors, full tile frames, and negative controls."""
from pathlib import Path
import gzip
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import decode_v1 as decoder
from lemma_cases_v1 import Theory
from lemma_experiment_v1 import FRAME_CAP
from native_v1 import Admission
from sparse_frame_v1 import verify
import study_v1 as logic


def read(path):
    return json.loads((ROOT/path).read_text())


def compressed(path):
    with gzip.open(ROOT/path,"rt") as stream:
        return json.load(stream)


def frozen(x):
    return tuple(map(frozen,x)) if isinstance(x,list) else x


def literals(row):
    return frozenset(frozen(row))


def resolve(a,b,p):
    assert (True,p) in a and (False,p) in b
    return (a-{(True,p)})|(b-{(False,p)})


def mapped(row,environment):
    return frozenset((p,environment[v]) for p,v in row)


def chain_check(recipes,amount,rows,binding):
    shape=recipes[amount]
    assert len(rows)==len(shape["leaves"]) and len(set(binding.values()))==len(binding)
    for a,b in zip(rows,shape["leaves"],strict=True):
        assert a==mapped(b,binding)
    rows=list(rows)
    if shape["child"] is None:
        for i,j,p,c in shape["steps"]:
            assert 0<=i<len(rows) and 0<=j<len(rows)
            checked=resolve(rows[i],rows[j],binding[p])
            assert checked==mapped(c,binding)
            rows.append(checked)
    else:
        for entries,aliases in shape["calls"]:
            assert all(0<=i<len(rows) for i in entries)
            sub={i:binding[v] for i,v in enumerate(aliases)}
            rows.append(chain_check(recipes,shape["child"],[rows[i] for i in entries],sub))
    assert rows[-1]=={(True,binding[amount])}
    return rows[-1]


def audit_nodes(statement,run,recipes,bank,admission,traces):
    theory=Theory(statement)
    sources={r["id"]:r for r in theory.schemas}
    rows=[]
    calls=discharges=checked=0
    for i,line in enumerate(run["nodes"]):
        rule=line["kind"]
        if rule=="source":
            src=sources[line["schema"]]
            env={v:frozen(x) for v,x in line["bindings"].items()}
            assert set(env)==set(src["variables"])
            assert all(logic.fol.inspect_term(t,{},theory.functions)==src["variables"][v] for v,t in env.items())
            result=frozenset(logic.grounded(src,env))
        elif rule=="resolve":
            a,b,p=line["left"],line["right"],frozen(line["pivot"])
            assert 0<=a<i and 0<=b<i
            result=resolve(rows[a],rows[b],p)
            if traces is not None:
                receipt=traces[str(i)]
                c=theory.builder
                words=[c.literals(sorted(cl,key=repr),{}) for cl in (rows[a],rows[b],result)]
                expected,earlier=admission.parent_text(*words[:2])
                assert receipt["prefix"]==expected
                assert receipt["word"]==earlier+"R10:0:1:"+c.token(p,{})+"/"+words[2]+";"
                assert receipt["stop"]==admission.finish and admission.replay(receipt)>0
                checked+=1
        elif rule=="invoke":
            ids=line["leaves"]
            assert all(0<=j<i for j in ids)
            result=chain_check(recipes,line["recipe"],[rows[j] for j in ids],dict(frozen(line["binding"])))
            calls+=1
        else:
            assert rule=="discharge" and len(line["units"]) in bank
            assert all(0<=j<i for j in (*line["units"],line["context"]))
            result=rows[line["context"]]
            for j,p in zip(line["units"],frozen(line["pivots"]),strict=True):
                assert rows[j]=={(True,p)}
                result=resolve(rows[j],result,p)
            discharges+=1
        assert result==literals(line["clause"])
        rows.append(result)
    if traces is not None:
        assert checked==len(traces)==run["counts"].get("atomic_resolutions",0)
    root=run.get("goal_node")
    if root is not None:
        assert rows[root]=={(True,theory.goal)}
    return calls,discharges,checked


def audit_frame(statement,proof,admission):
    data=compressed(proof["artifact"])
    assert data["machine_sha256"]==admission.machine.digest()
    builder=Theory(statement).builder
    assert builder.prefix()==data["prefix"]
    parsed=decoder.read(data["prefix"],data["word"])
    for raw,line in zip(parsed,proof["lines"],strict=True):
        assert raw["rule"]==line["rule"]
        assert raw["clause"]==decoder.clause(builder.literals(line["clause"],{}))
        if raw["rule"]=="R":
            assert all(raw[k]==line[k] for k in ("left","right"))
            assert raw["pivot"]==decoder.single(builder.token(line["pivot"],{}))
        else:
            src=builder.sources[line["source"]]
            names=builder.variable_names(src)
            assert raw["schema"]==bin(builder.ids[line["source"]])[2:]
            assert raw["substitution"]=={names[v]:decoder.single(builder.token(t,{}))
                                        for v,t in line["bindings"].items()}
    for call in proof["attachments"]:
        tag=call["recipe"]
        width=int(tag.split("-")[1]) if isinstance(tag,str) else tag
        assert call["last"]-call["first"]+1==width
        assert all(x<call["first"] for x in call["inputs"])
    assert verify(admission.machine,data["prefix"],data["word"],data["padding"],
                  data["trace"],FRAME_CAP)==proof["receipt"]
    return len(parsed)


def countermodel(case):
    if case["id"].startswith("peano-"):
        domains={"Nat":(0,1)}
        constants={"a":0,"b":1}
        def func(name,arguments):
            return 1-arguments[0] if name=="S" else constants[name]
        def relation(name,values):
            assert name=="=Nat"
            return values[0]==values[1]
    else:
        domains={"Point":(0,1,2),"Line":(0,1)}
        constants={"a":0,"b":1,"p":2,"ell0":0,"ell1":0,"ell2":1,"ell3":1}
        def func(name,arguments):
            assert not arguments
            return constants[name]
        def relation(name,values):
            x,y=values
            return y==0 if name=="I" else x!=y if name=="D" else x==y

    def term(value,env):
        if isinstance(value,str):
            return env[value]
        name,*args=value
        return func(name,[term(t,env) for t in args])

    def truth(formula,env):
        op,*args=formula
        if op=="atom":
            name,*terms=args
            return relation(name,[term(t,env) for t in terms])
        if op in ("all","exists"):
            var,sort,body=args
            return (all if op=="all" else any)(truth(body,{**env,var:x}) for x in domains[sort])
        if op=="not":
            return not truth(args[0],env)
        x,y=(truth(t,env) for t in args)
        if op=="implies":
            return not x or y
        assert op=="and"
        return x and y

    assert all(truth(f,{}) for f in case["premises"]) and not truth(case["goal"],{})
    return dict(domains=domains,constants=constants,premises_true=True,goal_false=True)


def main():
    base=read("data/results-v1.json")
    hybrid=read("data/hybrid-v1.json")
    native=Admission()
    assert base["machine_sha256"]==native.machine.digest()
    recipes={r["length"]:r for r in base["recipes"]}
    bank={r["length"]:r for r in hybrid["recipes"]}
    for amount,r in recipes.items():
        chain_check(recipes,amount,[literals(x) for x in r["leaves"]],{i:i for i in range(amount+1)})
    assert bank[2]["child"] is None and bank[4]["child"]==2
    audit={"frames":0,"decoded_lines":0,"chain_invocations":0,"discharge_invocations":0,"local_traces":0}
    witnesses={}
    tables=[(base,compressed("data/local-traces-v1.json.gz")),
            (hybrid,compressed("data/hybrid-traces-v1.json.gz"))]
    for cohort,traces in tables:
        d=cohort["donor"]
        name=d["statement"]["id"]
        work=[(d["statement"],d,traces[name])]
        for case in cohort["cases"]:
            source=case["statement"]
            if source["expected"]=="NO_WITNESS":
                witnesses[source["id"]]=countermodel(source)
            if "arms" in case:
                work.extend((source,arm,traces.get(source["id"]+"/"+arm["arm"])) for arm in case["arms"])
            else:
                work.append((source,case,traces[source["id"]]))
        for source,proof,trace in work:
            a,b,c=audit_nodes(source,proof,recipes,bank,native,trace)
            audit["chain_invocations"]+=a
            audit["discharge_invocations"]+=b
            audit["local_traces"]+=c
            if proof.get("proof"):
                audit["frames"]+=1
                audit["decoded_lines"]+=audit_frame(source,proof["proof"],native)
    assert len(witnesses)==2
    result=dict(status="AUDITED_NATIVE_AND_COMPOSED_PROOFS",**audit,countermodels=witnesses)
    (ROOT/"data/audit-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__":
    main()
