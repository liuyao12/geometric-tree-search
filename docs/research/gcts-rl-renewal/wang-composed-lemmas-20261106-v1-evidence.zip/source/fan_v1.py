"""Lift a two-unit donor to a reusable residual-clause receptor."""
from dataclasses import dataclass

from recipe_v1 import conclusion,unit


@dataclass(frozen=True)
class Discharge:
    length:int
    child:int|None


def attach_discharge(context,units):
    pivots=[]
    for row in units:
        if len(row)!=1:
            return None
        positive,pivot=next(iter(row))
        if not positive or (False,pivot) not in context or pivot in pivots:
            return None
        pivots.append(pivot)
    return tuple(pivots),context-{(False,a) for a in pivots}


def expand(recipe,bank,context,items,resolve):
    assert len(items)==recipe.length
    if recipe.child is None:
        for (node,pivot) in items:
            context=resolve(node,context,pivot)
    else:
        child=bank[recipe.child]
        n=child.length
        context=expand(child,bank,context,items[:n],resolve)
        context=expand(child,bank,context,items[n:],resolve)
    return context


def learn(search,root):
    line=search.nodes[root]
    previous=search.nodes[line["right"]]
    assert line["kind"]==previous["kind"]=="resolve"
    context=search.nodes[previous["right"]]
    assert context["kind"]=="source"
    left=(previous["left"],line["left"])
    supplied=[search.nodes[i]["clause"] for i in left]
    found=attach_discharge(context["clause"],supplied)
    assert found and found[0]==(previous["pivot"],line["pivot"]) and found[1]==line["clause"]
    bank={2:Discharge(2,None),4:Discharge(4,2)}
    for length,rule in bank.items():
        # An untouched residual clause stays arbitrary. These symbolic
        # literals include an extra negative and a positive occurrence
        # of a discharged atom, both of which must survive.
        rows=[unit(i) for i in range(length)]
        remainder=frozenset(((True,0),(True,length),(False,length+1)))
        source=remainder|{(False,i) for i in range(length)}
        assert expand(rule,bank,source,tuple((r,i) for i,r in enumerate(rows)),conclusion)==remainder
    return bank,dict(context=previous["right"],units=left,pivots=found[0],root=root)
