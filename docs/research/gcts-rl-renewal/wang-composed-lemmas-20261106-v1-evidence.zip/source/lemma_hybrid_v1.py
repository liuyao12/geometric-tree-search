"""Compose two learned receptor shapes in the same incidence proof."""
from dataclasses import asdict
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from fan_v1 import attach_discharge,learn
from lemma_cases_v1 import Theory,atom,imply
from lemma_experiment_v1 import SEARCH_CAP,frame,serialize
from lemma_search_v1 import Search
from native_v1 import Admission
from recipe_v1 import Recipe
import study_v1 as logic


def donor():
    p,q,r=(atom(t,["a"]) for t in ("P","Q","R"))
    return dict(id="discharge-donor",sorts=["U"],functions={"a":[[],"U"]},equality=False,depth=0,
                predicates={x:["U"] for x in ("P","Q","R")},premises=[p,q,imply((p,q),r)],goal=r)


class Hybrid(Search):
    def specializing(self,rule,skip,active):
        ids=[]
        for pivot in rule.body:
            if pivot==skip:
                continue
            item=self.prove(pivot,active)
            if item is None:
                return None
            ids.append((item,pivot))
        current=self.source(rule)
        while ids:
            n=max((k for k in self.fan if k<=len(ids)),default=1)
            group=ids[:n]
            del ids[:n]
            if n==1:
                current=self.resolve(group[0][0],current,group[0][1])
                continue
            leaves=[self.nodes[i]["clause"] for i,_ in group]
            shape=attach_discharge(self.nodes[current]["clause"],leaves)
            assert shape is not None
            pivots,row=shape
            assert pivots==tuple(p for _,p in group)
            if row in self.index:
                current=self.index[row]
                continue
            current=self.store(row,kind="discharge",units=tuple(i for i,_ in group),context=current,
                               pivots=pivots)
            self.stats["discharge_invocations"]+=1
            self.stats["discharge_resolutions_reused"]+=n
        return current


def frozen(x):
    return tuple(map(frozen,x)) if isinstance(x,list) else x


def recipe(row):
    return Recipe(row["length"],tuple(frozenset(map(tuple,s)) for s in row["leaves"]),
                  tuple((a,b,p,frozenset(map(tuple,result))) for a,b,p,result in row["steps"]),
                  row["child"],frozen(row["calls"]))


def main():
    baseline=json.loads((ROOT/"data/results-v1.json").read_text())
    library={row["length"]:recipe(row) for row in baseline["recipes"]}
    native=Admission()
    d=Search(Theory(donor()),admission=native,maximum=SEARCH_CAP)
    status,root=d.run()
    assert status=="PROVED"
    _,donor_proof=frame("discharge-donor",d,root,native.machine)
    bank,origin=learn(d,root)
    traces={"discharge-donor":d.traces}
    cases=[]
    for item in baseline["cases"]:
        source=item["statement"]
        name=source["id"]
        if not name.startswith("hilbert-"):
            continue
        native=Admission()
        h=Hybrid(Theory(source),library,native,maximum=SEARCH_CAP)
        h.fan=bank
        status,root=h.run()
        assert status==source["expected"]
        proof=None
        if root is not None:
            assert h.stats["macro_invocations"] and h.stats["discharge_invocations"]
            _,proof=frame(name+"-composed",h,root,native.machine)
        cases.append(dict(statement=source,status=status,nodes=[serialize(x) for x in h.nodes],
                          goal_node=root,counts=h.counters(),proof=proof))
        traces[name]=h.traces
        print(json.dumps(dict(id=name,status=status,counts=h.counters(),
                              lines=len(proof["lines"]) if proof else None),sort_keys=True),flush=True)
    logic.write_gzip(ROOT/"data/hybrid-traces-v1.json.gz",traces)
    out=dict(status="CHECKED_COMPOSITION_OF_UNLIKE_LEMMA_SHAPES",
             donor=dict(statement=donor(),proof=donor_proof,origin=origin,
                        nodes=[serialize(x) for x in d.nodes],counts=d.counters()),
             recipes=[asdict(x) for x in bank.values()],cases=cases)
    (ROOT/"data/hybrid-v1.json").write_text(json.dumps(out,sort_keys=True,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
