"""Goal-directed search with a fixed Wang checker and positive lemma receptors."""
from collections import Counter
from copy import deepcopy

from native_v1 import Admission
from fan_v1 import attach_discharge,expand
from recipe_v1 import attach,conclusion,link,replay,specialize,unit


class Bound(Exception):
    pass


class Search:
    def __init__(self,theory,library=None,admission=None,maximum=2500,order="long"):
        self.theory=theory
        self.library=library or {}
        self.admission=admission
        self.maximum=maximum
        self.order=order
        self.nodes=[]
        self.index={}
        self.stats=Counter()
        self.traces={}
        self.invocations=[]
        self.fan={}
        self.known={}
        self.failed=set()

    def store(self,clause,**info):
        if clause not in self.index:
            self.index[clause]=len(self.nodes)
            self.nodes.append(dict(clause=clause,**info))
        return self.index[clause]

    def source(self,rule):
        return self.store(rule.clause,kind="source",schema=rule.schema,bindings=dict(rule.bindings))

    def resolve(self,left,right,pivot):
        a,b=(self.nodes[i]["clause"] for i in (left,right))
        row=conclusion(a,b,pivot)
        if row in self.index:
            self.stats["known_clause"]+=1
            return self.index[row]
        self.stats["atomic_resolutions"]+=1
        if self.admission is not None:
            c=self.theory.builder
            encode=lambda cl:c.literals(sorted(cl,key=repr),{})
            stage,trace=self.admission.test(encode(a),encode(b),c.token(pivot,{}),encode(row),record=True)
            assert stage.q==self.admission.finish
            self.stats["native_steps"]+=stage.steps
        node=self.store(row,kind="resolve",left=left,right=right,pivot=pivot)
        if self.admission is not None:
            self.traces[node]=trace
        return node

    def counters(self):
        out=dict(self.stats)
        if self.admission is not None:
            out.update({k:v for k,v in self.admission.counts.items() if k.startswith("parent_")})
        return out

    def rules(self,goal):
        # A Horn rule whose own head appears in its body cannot add the head.
        return tuple(r for r in self.theory.rules(goal) if goal not in r.body
                     and all(self.theory.rules(b) for b in r.body))

    def specializing(self,rule,skip,active):
        node=self.source(rule)
        for b in rule.body:
            if b==skip:
                continue
            left=self.prove(b,active)
            if left is None:
                return None
            node=self.resolve(left,node,b)
        return node

    def routes(self,goal,n,seen):
        if n==0:
            yield ()
            return
        for rule in self.rules(goal):
            src=self.theory.continuation(rule)
            if src is None or src in seen:
                continue
            self.stats["receptor_branches"]+=1
            if self.stats["receptor_branches"]+self.stats["rule_attempts"]>self.maximum:
                raise Bound
            for prior in self.routes(src,n-1,seen|{src}):
                yield (*prior,(src,rule))

    def invoke(self,recipe,path,active):
        # The route's shared atom is a receptor. Every side condition is
        # discharged by the ordinary search before the recipe is admitted.
        anchor=path[0][0]
        start=self.prove(anchor,active)
        if start is None:
            return None
        ids=[start]
        for src,rule in path:
            index=self.specializing(rule,src,active)
            if index is None:
                return None
            assert self.nodes[index]["clause"]==link(src,rule.head)
            ids.append(index)
        leaves=[self.nodes[i]["clause"] for i in ids]
        env=attach(recipe,leaves)
        if env is None:
            self.stats["failed_receptors"]+=1
            return None
        output=specialize(recipe.output,env)
        if output in self.index:
            return self.index[output]
        result=self.store(output,kind="invoke",recipe=recipe.length,leaves=tuple(ids),
                          binding=tuple(sorted(env.items())))
        self.stats["macro_invocations"]+=1
        self.stats["internal_resolutions_reused"]+=recipe.length
        self.invocations.append(result)
        return result

    def prove(self,goal,active=frozenset()):
        if goal in self.known:
            return self.known[goal]
        if goal in active or (goal,active) in self.failed:
            return None
        active=active|{goal}
        candidates=self.rules(goal)
        for rule in candidates:
            if not rule.body:
                node=self.source(rule)
                self.known[goal]=node
                return node
        if self.library:
            for n in sorted(self.library,reverse=self.order=="long"):
                for path in self.routes(goal,n,active):
                    self.stats["offered_recipes"]+=1
                    result=self.invoke(self.library[n],path,active)
                    if result is not None:
                        self.known[goal]=result
                        return result
        for rule in candidates:
            self.stats["rule_attempts"]+=1
            if self.stats["receptor_branches"]+self.stats["rule_attempts"]>self.maximum:
                raise Bound
            src=self.theory.continuation(rule)
            # Discharge side conditions first. This also exposes the exact
            # binary implication available for a future cluster.
            right=self.specializing(rule,src,active)
            if right is None:
                continue
            if src is not None:
                left=self.prove(src,active)
                if left is None:
                    continue
                right=self.resolve(left,right,src)
            assert self.nodes[right]["clause"]==unit(goal)
            self.known[goal]=right
            return right
        self.failed.add((goal,active-{goal}))
        return None

    def run(self):
        try:
            q=self.prove(self.theory.goal)
        except Bound:
            return "BOUNDED",None
        return ("NO_WITNESS",None) if q is None else ("PROVED",q)

    def export(self,root):
        builder=deepcopy(self.theory.builder)
        proved={}
        attachments=[]

        def add(i):
            if i in proved:
                return proved[i]
            node=self.nodes[i]
            kind=node["kind"]
            if kind=="source":
                row=builder.unguard(node["schema"],node["bindings"])
            elif kind=="resolve":
                row=builder.resolve(add(node["left"]),add(node["right"]),node["pivot"])
            elif kind=="discharge":
                left=[add(j) for j in node["units"]]
                context=add(node["context"])
                clause=lambda i:frozenset(builder.lines[i]["clause"])
                inputs=[clause(j) for j in left]
                assert attach_discharge(clause(context),inputs)==(node["pivots"],node["clause"])
                recipe=self.fan[len(left)]
                first=len(builder.lines)
                row=expand(recipe,self.fan,context,tuple(zip(left,node["pivots"],strict=True)),builder.resolve)
                attachments.append(dict(root=i,recipe="discharge-"+str(recipe.length),
                                        first=first,last=row,inputs=[context,*left],binding=node["pivots"]))
            else:
                assert kind=="invoke"
                leaves=[add(j) for j in node["leaves"]]
                recipe=self.library[node["recipe"]]
                env=dict(node["binding"])
                assert attach(recipe,[frozenset(builder.lines[j]["clause"]) for j in leaves])==env
                first=len(builder.lines)
                def resolve(a,b,p,want):
                    line=builder.resolve(a,b,env[p])
                    assert frozenset(builder.lines[line]["clause"])==specialize(want,env)
                    return line
                row=replay(recipe,self.library,leaves,resolve)
                attachments.append(dict(root=i,recipe=recipe.length,first=first,last=row,
                                        inputs=leaves,binding=node["binding"]))
            assert frozenset(builder.lines[row]["clause"])==node["clause"]
            proved[i]=row
            return row

        final=add(root)
        denied=builder.instance(self.theory.denial,{})
        builder.resolve(final,denied,self.theory.goal)
        assert not builder.lines[-1]["clause"]
        return builder,attachments
