"""Independently replay donor fragments, transferred marks, and final proofs."""
from copy import deepcopy
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
import decode_v1 as decoder
import experiment_v1 as experiment
from move_search_v1 import fits, key
from native_v1 import Admission
from sparse_frame_v1 import verify
import study_v1 as fol_study


def read(path):
    with gzip.open(ROOT/"data"/path, "rt") as f:
        return json.load(f)


def frozen(x):
    return tuple(map(frozen, x)) if isinstance(x,list) else x


def audit_raw_mark(mark, literals, pivot):
    """Check every address in raw literal order, independently of search."""
    assert len(mark) == len(literals)
    for (reason, path), (sign, literal) in zip(mark, literals, strict=True):
        if reason == "sign":
            assert sign
            continue
        assert not sign
        a, b = literal, pivot
        for j in path:
            assert j > 0
            a, b = a[j], b[j]
        if reason == "name":
            assert a[0] != b[0]
        else:
            assert reason == "arity" and len(a) != len(b)


def qualification(admission):
    left, right = "+(0.(0.))", "-(0.(1.))"
    examples = [("(0.(0.))", right, False), ("(0.(0.))", right+"+(1.)", False),
                ("(0.(0.))", "", False)]
    support = []
    for pivot, output, expected in examples:
        stage, trace = admission.test(left,right,pivot,output,record=True)
        assert (stage.q == admission.finish) == expected
        assert admission.replay(trace) > stage.steps
        support.append(trace)
    assert support[0]["parents"] == support[1]["parents"] == support[2]["parents"]
    assert len({len(x["word"]) for x in support}) == len(support)
    mark = (("name", (1,)),)
    parent = frozenset(decoder.clause(right))
    pivot = decoder.single("(0.(0.))")
    assert fits(mark, parent, pivot)
    new = frozenset(decoder.clause("-(11.(11.))"))
    assert fits(mark, new, decoder.single("(11.(10.))"))
    assert not fits(mark, new, decoder.single("(11.(11.))"))
    stage, good = admission.test("+(11.(11.))","-(11.(11.))","(11.(11.))","",record=True)
    assert stage.q == admission.finish and admission.replay(good) > stage.steps
    corrupted = deepcopy(support[0])
    for event in corrupted["fragment"]:
        if len(event) == 2:
            event[1] *= -1
            break
    try:
        admission.replay(corrupted)
    except (AssertionError, ValueError):
        pass
    else:
        raise AssertionError("Corrupted fragment accepted")
    return dict(suffix_lengths=[len(x["word"]) for x in support], checkpoint_shared=True,
                renamed_mark=True, restored_pivot_admitted=True, corrupted_fragment_rejected=True)


def main():
    admission = Admission()
    outcomes = json.loads((ROOT/"data/results-v1.json").read_text())
    assert outcomes["machine_sha256"] == admission.machine.digest()
    stored = read("receptors-v1.json.gz")
    total_donors = total_hits = different = accepted = total_steps = proofs = proof_lines = 0
    for name, bank in stored.items():
        if name.endswith("/accepted"):
            assert bank["stop"] == admission.finish
            total_steps += admission.replay(bank)
            accepted += 1
            continue
        donors = bank["donors"]
        for digest, d in donors.items():
            trace = d["trace"]
            assert trace["stop"] == 1 and (trace["label"],trace["read"]) == ("right-present",";")
            assert admission.replay(trace) == d["trace_steps"]
            left, right, pivot, output = d["pair"]
            expected, earlier = admission.parent_text(left, right)
            assert trace["prefix"] == expected and trace["word"] == earlier+"R10:0:1:"+pivot+"/"+output+";"
            literals = decoder.clause(right)
            p = decoder.single(pivot)
            assert (False,p) not in literals and (True,p) in decoder.clause(left)
            audit_raw_mark(d["mark"], literals, p)
            assert digest == key([d["right"],d["pivot"]])
            total_donors += 1
            total_steps += d["trace_steps"]
        for hit in bank["hits"]:
            clause, pivot = frozen(hit["right"]), frozen(hit["pivot"])
            assert (False,pivot) not in clause
            audit_raw_mark(donors[hit["donor"]]["mark"], clause, pivot)
            assert hit["receiver"] == key([hit["right"],hit["pivot"]])
            total_hits += 1
            different += hit["receiver"] != hit["donor"]
    for row in outcomes["cases"]:
        proof = row["proof"]
        if proof is None:
            continue
        c = read(proof["artifact"])
        builder, *_ = experiment.compiled(row["case"], row["depth"])
        assert builder.prefix() == c["prefix"]
        assert c["machine_sha256"] == admission.machine.digest()
        decoded = decoder.read(c["prefix"], c["word"])
        for line, record in zip(proof["lines"], decoded, strict=True):
            assert decoder.clause(builder.literals(line["clause"], {})) == record["clause"]
            assert line["rule"] == record["rule"]
            if line["rule"] == "R":
                assert all(line[k] == record[k] for k in ("left","right"))
                assert decoder.single(builder.token(line["pivot"],{})) == record["pivot"]
        receipt = verify(admission.machine,c["prefix"],c["word"],c["padding"],c["trace"],fol_study.CAP)
        assert receipt == proof["receipt"]
        proofs += 1
        proof_lines += len(decoded)
    receipt = dict(status="CHECKED_TAPE_RECEPTOR_AUDIT", donors=total_donors, hits=total_hits,
                   different_receivers=different, admitted_example_fragments=accepted,
                   fragment_steps=total_steps, final_proofs=proofs, decoded_lines=proof_lines,
                   qualification=qualification(admission))
    (ROOT/"data"/"audit-v1.json").write_text(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
    print(json.dumps(receipt,sort_keys=True))


if __name__ == "__main__":
    main()
