"""Find refutations by proposing and admitting individual Wang fragments."""
from collections import Counter
from dataclasses import dataclass
from hashlib import sha256
import json
import random

from marker_tm_v1 import FREE


def ordered(clause):
    return tuple(sorted(clause, key=repr))


def mismatch(a, b, path=()):
    if a[0] != b[0]:
        return "name", path
    if len(a) != len(b):
        return "arity", path
    for i, (x, y) in enumerate(zip(a[1:], b[1:], strict=True), 1):
        delta = mismatch(x, y, (*path, i))
        if delta is not None:
            return delta
    return None


def project(atom, address):
    for i in address:
        if len(atom) <= i:
            return None
        atom = atom[i]
    return atom


def obstruction(parent, pivot):
    """Describe one failed receptor alignment at each literal in the parent."""
    result = []
    for sign, atom in ordered(parent):
        if sign:
            result.append(("sign", ()))
        else:
            witness = mismatch(atom, pivot)
            assert witness is not None
            result.append(witness)
    return tuple(result)


def fits(mark, parent, pivot):
    literals = ordered(parent)
    if len(mark) != len(literals):
        return False
    for (kind, path), (positive, atom) in zip(mark, literals, strict=True):
        if kind == "sign":
            if not positive:
                return False
        else:
            if positive:
                return False
            a, b = project(atom, path), project(pivot, path)
            if a is None or b is None:
                return False
            if kind == "name":
                if a[0] == b[0]:
                    return False
            elif len(a) == len(b):
                return False
    return True


def profile(parent):
    return tuple(sign for sign, _ in ordered(parent))


def key(values):
    return sha256(json.dumps(values, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class MarkBank:
    def __init__(self):
        self.receptors = {}
        self.donors = {}
        self.hits = []

    def query(self, right, pivot):
        for mark, donor in self.receptors.get(profile(right), {}).items():
            if fits(mark, right, pivot):
                self.hits.append(dict(donor=donor, receiver=key([ordered(right), pivot]),
                                      right=ordered(right), pivot=pivot))
                return True
        return False

    def add(self, right, pivot, evidence, stage, pair, replay_steps):
        mark = obstruction(right, pivot)
        assert fits(mark, right, pivot)
        bucket = self.receptors.setdefault(profile(right), {})
        if mark not in bucket:
            fingerprint = key([ordered(right), pivot])
            bucket[mark] = fingerprint
            self.donors[fingerprint] = dict(mark=mark, right=ordered(right), pivot=pivot,
                                            pair=pair, rejection_steps=stage.steps,
                                            trace_steps=replay_steps, rejection_label=stage.label,
                                            trace=evidence)


class Ranker:
    """A contextual bandit. The observed reward comes from admitted moves."""
    def __init__(self, seed, rate=.10):
        self.weights = {}
        self.rng = random.Random(seed)
        self.rate = rate
        self.updates = 0

    def features(self, left, right, pivot):
        neighbors = [a for positive, a in right if not positive and a[0] == pivot[0]]
        assert neighbors
        prefix = max(sum(x[0] == y[0] for x, y in zip(a[1:], pivot[1:])) for a in neighbors)
        return ("bias", f"left:{min(4,len(left))}", f"right:{min(4,len(right))}",
                f"children:{min(3,prefix)}", f"arity:{min(4,len(pivot)-1)}",
                f"right-candidates:{min(4,len(neighbors))}",
                f"joint:{min(3,prefix)}/{min(3,len(left))}/{min(3,len(right))}")

    def score(self, features):
        return sum(self.weights.get(x, 0.) for x in features)

    def update(self, features, reward):
        error = (reward - self.score(features))*self.rate/len(features)
        for x in features:
            self.weights[x] = self.weights.get(x, 0.) + error
        self.updates += 1


@dataclass(frozen=True)
class Move:
    left: int
    right: int
    pivot: tuple


class Search:
    def __init__(self, clauses, support, builder, *, native=None, marks=None, ranker=None, learn=False,
                 maximum=3000):
        self.clauses = list(clauses)
        self.builder = builder
        self.initial = len(clauses)
        self.index = {c: i for i, c in enumerate(clauses)}
        self.support = set(support)
        self.pending = set(support)
        self.done = set(range(len(clauses))) - set(support)
        self.selected = set()
        self.origins = {}
        self.native = native
        self.marks = marks
        self.ranker = ranker
        self.learn = learn
        self.maximum = maximum
        self.counts = Counter()
        self.probes = []
        self.example = None
        self.admissions = 0

    def proposals(self, given):
        moves = []
        for other in sorted(self.done):
            if other == given:
                continue
            for a, b in ((given, other), (other, given)):
                roots = {t[0] for positive, t in self.clauses[b] if not positive}
                for positive, atom in ordered(self.clauses[a]):
                    if positive and atom[0] in roots:
                        moves.append(Move(a, b, atom))
        def base(m):
            return len(self.clauses[m.left])+len(self.clauses[m.right]), m.left, m.right, repr(m.pivot)
        if self.ranker is None:
            return sorted(moves, key=base)
        if self.learn and self.ranker.rng.random() < .18:
            self.ranker.rng.shuffle(moves)
            return moves
        return sorted(moves, key=lambda m: (-self.ranker.score(self.features(m)), *base(m)))

    def features(self, m):
        return self.ranker.features(self.clauses[m.left], self.clauses[m.right], m.pivot)

    def probe(self, move, conclusion):
        left, right, pivot = self.clauses[move.left], self.clauses[move.right], move.pivot
        self.counts["proposals"] += 1
        if self.marks is not None and self.marks.query(right, pivot):
            self.counts["mark_hits"] += 1
            self.probes.append((move, False, "mark"))
            return False
        if self.native is None:
            self.counts["membership_checks"] += 1
            allowed = (False, pivot) in right
            self.probes.append((move, allowed, "membership"))
            return allowed
        build = self.builder
        encoded = (build.literals(ordered(left), {}), build.literals(ordered(right), {}),
                   build.token(pivot, {}), build.literals(ordered(conclusion), {}))
        record = self.marks is not None or self.example is None
        result, trace = self.native.test(*encoded, record=record)
        allowed = result.q == self.native.finish
        self.counts["native_checks"] += 1
        self.counts["native_steps"] += result.steps
        self.probes.append((move, allowed, "native"))
        if allowed:
            if self.example is None:
                self.example = trace
        else:
            assert (result.label, result.read) == ("right-present", ";"), (result.label, result.read)
            self.counts["native_rejections"] += 1
            if self.marks is not None:
                replay = self.native.replay(trace)
                self.counts["donor_replay_steps"] += replay
                self.marks.add(right, pivot, trace, result, encoded, replay)
        return allowed

    def run(self):
        if frozenset() in self.index:
            return "REFUTED", self.index[frozenset()]
        while self.pending:
            given = min(self.pending, key=lambda i: (len(self.clauses[i]), i))
            self.pending.remove(given)
            self.selected.add(given)
            self.counts["given"] += 1
            for move in self.proposals(given):
                if self.counts["proposals"] >= self.maximum:
                    return "BOUNDED", None
                end, reward = self.step(move)
                if self.learn and reward is not None:
                    self.ranker.update(self.features(move), reward)
                if end is not None:
                    return "REFUTED", end
            self.done.add(given)
        return "EXHAUSTED", None

    def step(self, move):
        a, b = self.clauses[move.left], self.clauses[move.right]
        out = frozenset((a-{(True, move.pivot)}) | (b-{(False, move.pivot)}))
        if not self.probe(move, out):
            return None, -1
        self.admissions += 1
        if any((not p,t) in out for p,t in out):
            self.counts["tautologies"] += 1
            return None, None
        if out in self.index:
            j = self.index[out]
            if j not in self.selected:
                self.pending.add(j)
            self.counts["duplicates"] += 1
            return None, None
        smaller = next((i for i, clause in enumerate(self.clauses) if clause < out), None)
        if smaller is not None:
            if smaller not in self.selected:
                self.pending.add(smaller)
            self.counts["subsumed"] += 1
            return None, None
        j = len(self.clauses)
        self.index[out] = j
        self.clauses.append(out)
        self.origins[j] = move
        self.pending.add(j)
        self.counts["derived"] += 1
        return (j if not out else None), (5 if not out else 1 if len(out) <= 1 else .25)

    def audit(self):
        for move, allowed, method in self.probes:
            left, right = self.clauses[move.left], self.clauses[move.right]
            assert (True, move.pivot) in left and allowed == ((False, move.pivot) in right)
        return len(self.probes)

    def proof(self, end):
        used = set()

        def walk(i):
            if i in used:
                return
            used.add(i)
            if i in self.origins:
                move = self.origins[i]
                walk(move.left)
                walk(move.right)

        walk(end)
        return sorted(used)
