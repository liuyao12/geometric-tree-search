"""Paired studies of native Wang move search and receptor transfer."""
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from move_search_v1 import MarkBank, Ranker, Search
from native_v1 import Admission
from sparse_frame_v1 import execute, verify
import study_v1 as fol_study

SELECT = {
    "exists-map": 0, "incidence-existence": 1, "peano-nonzero-successor": 2,
    "hilbert-incidence-uniqueness": 0, "counter-halt": 1,
}
MAXIMUM = 1800


def ladder(tag, n, binary=False, distractor=True):
    root = f"Rel{tag}"
    zero, x, seed = [f"base{tag}"], "?x", [f"parameter{tag}"]
    successor = f"step{tag}"
    foil = f"foil{tag}"
    def at(t):
        return ["atom", root, t, seed] if binary else ["atom", root, t]
    def lift(t):
        return [successor, t]
    target = zero
    for _ in range(n):
        target = lift(target)
    axioms = [at(zero), ["all", x, "U", ["implies", at(x), at(lift(x))]]]
    functions = {zero[0]: [[], "U"], successor: [["U"], "U"]}
    if binary:
        functions[seed[0]] = [[], "U"]
    if distractor:
        functions[foil] = [["U"], "U"]
        axioms.append(["all", x, "U", ["implies", at(x), at([foil,x])]])
    return dict(id=f"ladder-{tag}", sorts=["U"], functions=functions,
                predicates={root: ["U"]*(2 if binary else 1)}, premises=axioms,
                goal=at(target), equality=False)


def compiled(case, depth):
    normal, _ = fol_study.front_v1.clausify(case, 1024)
    functions, predicates, schemas = fol_study.fol.signature(normal)
    guarded, type_ids = fol_study.guarded(schemas, functions, normal["sorts"])
    builder = fol_study.Certificate(guarded, functions, predicates, normal["sorts"], type_ids)
    terms = fol_study.fol.ground_terms(normal, functions, depth, 1000)
    assert terms is not None
    _, instances = fol_study.fol.instances(schemas, terms, depth, 5000)
    assert instances is not None
    by_name = {r["id"]: r for r in schemas}
    origins = list(instances.values())
    clauses = [frozenset(fol_study.grounded(by_name[r["schema"]], r["substitution"])) for r in origins]
    assert len(clauses) == len(set(clauses))
    prefix = f"formula{len(case['premises'])+1}-"
    support = [i for i, r in enumerate(origins) if r["schema"].startswith(prefix)]
    assert support
    return builder, origins, clauses, support


def targets():
    cases = fol_study.prop.load("input/cases-v1.json") + fol_study.prop.load("input/new-cases-v1.json")
    cases.append(fol_study.counter_example())
    return [(case, SELECT[case["id"]]) for case in cases if case["id"] in SELECT] + [
        (ladder("held3", 3), 3), (ladder("held4", 4, True), 4)]


def train(machine):
    ranker = Ranker(26197)
    attempts = []
    for i in range(8):
        n = 1 + i % 3
        case = ladder(f"train{i}", n, bool(i % 2), distractor=bool(i%4))
        builder, _, clauses, support = compiled(case, n)
        runner = Search(clauses, support, builder, native=machine, ranker=ranker, learn=True,
                        maximum=250)
        status, _ = runner.run()
        runner.audit()
        attempts.append(dict(id=case["id"], status=status, counts=dict(runner.counts)))
    return ranker, attempts


def cert(name, search, root, builder, origins, machine):
    ids = {}
    for i in search.proof(root):
        if i < len(origins):
            origin = origins[i]
            ids[i] = builder.unguard(origin["schema"], origin["substitution"])
        else:
            move = search.origins[i]
            ids[i] = builder.resolve(ids[move.left], ids[move.right], move.pivot)
        assert frozenset(builder.lines[ids[i]]["clause"]) == search.clauses[i]
    assert not builder.lines[-1]["clause"]
    prefix, word = builder.prefix(), builder.words()
    run = execute(machine, prefix, word, 2, fol_study.CAP)
    assert run["status"] == "ACCEPT", (name, run)
    receipt = verify(machine, prefix, word, 2, run["trace"], fol_study.CAP)
    name_out = f"{name}-frame-v1.json.gz"
    fol_study.write_gzip(ROOT/"data"/name_out, dict(prefix=prefix, word=word, padding=2,
                      trace=run["trace"], machine_sha256=machine.digest()))
    return dict(receipt=receipt, lines=builder.lines, commits=run["commits"], artifact=name_out,
                source_clauses=list(builder.sources.values()))


def pilot():
    for case, depth in targets():
        builder, _, clauses, support = compiled(case, depth)
        run = Search(clauses, support, builder, maximum=MAXIMUM)
        status, end = run.run()
        run.audit()
        print(case["id"],len(clauses),status,dict(run.counts),
              len(run.proof(end)) if end is not None else None,flush=True)


def main():
    shared = Admission()
    ranker, training = train(shared)
    results = []
    donors = {}
    for case, depth in targets():
        builder, origins, clauses, support = compiled(case, depth)
        arms = {}
        for arm in ("membership", "plain", "marked", "ranked"):
            admission = Admission() if arm != "membership" else None
            bank = MarkBank() if arm in ("marked", "ranked") else None
            current = Search(clauses, support, builder, native=admission, marks=bank,
                             ranker=ranker if arm=="ranked" else None, maximum=MAXIMUM)
            status, end = current.run()
            audited = current.audit()
            counts = dict(current.counts)
            if admission:
                counts.update({k:v for k,v in admission.counts.items() if k.startswith("parent_")})
            row = dict(status=status, counts=counts, independently_checked=audited,
                       visited=len(current.clauses))
            if end is not None:
                row["proof_nodes"] = len(current.proof(end))
            if bank:
                different = sum(h["receiver"] != h["donor"] for h in bank.hits)
                row["marks"] = dict(total=len(bank.donors), hits=len(bank.hits), different=different)
                donors[f"{case['id']}/{arm}"] = dict(donors=bank.donors, hits=bank.hits)
            if current.example is not None and arm == "ranked":
                row["example_verified_steps"] = admission.replay(current.example)
                donors[f"{case['id']}/accepted"] = current.example
            if arm=="membership":
                reference = [m[:2] for m in current.probes]
            elif arm!="ranked":
                assert [m[:2] for m in current.probes] == reference
            if arm=="ranked" and end is not None:
                proof = cert(case["id"], current, end, deepcopy(builder), origins, admission.machine)
            elif arm=="marked" and end is not None:
                fallback = (current, end, admission.machine)
            arms[arm] = row
            print(json.dumps(dict(id=case["id"],arm=arm,**row),sort_keys=True),flush=True)
        if arms["ranked"]["status"] != "REFUTED":
            if arms["marked"]["status"] == "REFUTED":
                current,end,machine = fallback
                proof = cert(case["id"], current, end, deepcopy(builder), origins, machine)
            else:
                proof = None
        results.append(dict(id=case["id"],case=case,depth=depth,initial_clauses=len(clauses),
                            support=len(support),arms=arms,proof=proof))
    fol_study.write_gzip(ROOT/"data"/"receptors-v1.json.gz", donors)
    result = dict(status="CHECKED_WANG_MOVE_SEARCH", machine_sha256=shared.machine.digest(),
                  limits=dict(proposals=MAXIMUM), training=training, rank=dict(updates=ranker.updates,
                  weights=ranker.weights), cases=results)
    (ROOT/"data"/"results-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")


if __name__ == "__main__":
    pilot() if "--pilot" in sys.argv else main()
