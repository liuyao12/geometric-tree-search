"""A move-by-move frontier permits learned rankings to alter the proof route."""
from copy import deepcopy
from heapq import heappop, heappush
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
import experiment_v1 as experiment
from move_search_v1 import MarkBank, Ranker, Search
from native_v1 import Admission
import study_v1 as study


class Frontier(Search):
    def __init__(self, *args, policy=None, train=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.policy = policy
        self.training = train
        self.actions = []
        self.frontier = []
        self.offered = set()

    def push(self, move):
        if move in self.offered:
            return
        self.offered.add(move)
        a,b = self.clauses[move.left], self.clauses[move.right]
        features = self.policy.features(a,b,move.pivot) if self.policy else ()
        score = self.policy.score(features) if self.policy else 0
        heappush(self.frontier,(-score, len(a)+len(b),move.left,move.right,repr(move.pivot),move,features))

    def pop(self):
        if self.training and len(self.frontier)>1 and self.policy.rng.random()<.15:
            window = [heappop(self.frontier) for _ in range(min(len(self.frontier),12))]
            item = window.pop(self.policy.rng.randrange(len(window)))
            for retained in window:
                heappush(self.frontier, retained)
        else:
            item = heappop(self.frontier)
        return item[-2:]

    def run(self):
        if frozenset() in self.index:
            return "REFUTED", self.index[frozenset()]
        while self.pending or self.frontier:
            while self.pending:
                given = min(self.pending,key=lambda i:(len(self.clauses[i]),i))
                self.pending.remove(given)
                self.selected.add(given)
                self.counts["given"] += 1
                for move in self.proposals(given):
                    self.push(move)
                self.done.add(given)
            if not self.frontier:
                break
            if self.counts["proposals"] >= self.maximum:
                return "BOUNDED", None
            move, features = self.pop()
            end,reward = self.step(move)
            if self.training:
                response = 1 if end is not None else -.12 if reward == -1 else .05 if reward else -.04
                self.actions.append((features,response))
            if end is not None:
                return "REFUTED", end
        return "EXHAUSTED",None


def train(admission):
    policy = Ranker(72213,rate=.075)
    evidence = []
    for i in range(12):
        n = 1+i%3
        case = experiment.ladder(f"frontiertrain{i}",n,bool(i%2),distractor=bool(i%4))
        builder, _, clauses, support = experiment.compiled(case,n)
        run = Frontier(clauses,support,builder,native=admission,policy=policy,train=True,maximum=250)
        status,_ = run.run()
        run.audit()
        credit = 0.
        for features,reward in reversed(run.actions):
            credit = reward + .94*credit
            policy.update(features,credit)
        evidence.append(dict(id=case["id"],status=status,counts=dict(run.counts)))
    return policy,evidence


def main():
    policy, training = train(Admission())
    outcomes = []
    banks = {}
    for case,depth in experiment.targets():
        builder,origins,clauses,support = experiment.compiled(case,depth)
        arms = {}
        for label in ("plain-priority", "learned-priority"):
            native,bank = Admission(),MarkBank()
            run = Frontier(clauses,support,builder,native=native,marks=bank,
                           policy=policy if label=="learned-priority" else None,
                           maximum=experiment.MAXIMUM)
            status, end = run.run()
            audited = run.audit()
            counts = dict(run.counts)
            counts.update({k:v for k,v in native.counts.items() if k.startswith("parent_")})
            row = dict(status=status,counts=counts,independently_checked=audited)
            if end is not None:
                row["proof_nodes"] = len(run.proof(end))
                if case["id"] in ("hilbert-incidence-uniqueness","ladder-held4"):
                    row["proof"] = experiment.cert(f'frontier-{label}-{case["id"]}',run,end,deepcopy(builder),
                                                   origins,native.machine)
            arms[label] = row
            banks[f'{case["id"]}/{label}'] = dict(donors=bank.donors,hits=bank.hits)
            print(json.dumps(dict(id=case["id"],arm=label,status=status,counts=counts)),flush=True)
        outcomes.append(dict(id=case["id"],arms=arms))
    study.write_gzip(ROOT/"data"/"frontier-receptors-v1.json.gz",banks)
    result = dict(status="CHECKED_INTERLEAVED_MOVE_FRONTIER",training=training,updates=policy.updates,
                  weights=policy.weights,cases=outcomes)
    (ROOT/"data"/"frontier-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
