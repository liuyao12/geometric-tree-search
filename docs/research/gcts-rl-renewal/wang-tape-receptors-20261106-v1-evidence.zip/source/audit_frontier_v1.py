"""Check the frontier donor transfers and exported refutations."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from audit_moves_v1 import audit_raw_mark, frozen, read
import decode_v1 as decoder
import experiment_v1 as experiment
from move_search_v1 import key
from native_v1 import Admission
from sparse_frame_v1 import verify
import study_v1 as study


def main():
    admission = Admission()
    outcome = json.loads((ROOT/"data/frontier-v1.json").read_text())
    banks = read("frontier-receptors-v1.json.gz")
    targets = {case["id"]:(case,depth) for case,depth in experiment.targets()}
    donors, hits, proofs, rows = 0,0,0,0
    for name, bank in banks.items():
        for id, donor in bank["donors"].items():
            assert id == key([donor["right"],donor["pivot"]])
            trace = donor["trace"]
            assert trace["stop"] == 1 and (trace["label"],trace["read"]) == ("right-present",";")
            assert admission.replay(trace) == donor["trace_steps"]
            left,right,pivot,out = donor["pair"]
            prefix, earlier = admission.parent_text(left,right)
            assert trace["prefix"] == prefix and trace["word"] == earlier+"R10:0:1:"+pivot+"/"+out+";"
            audit_raw_mark(donor["mark"],decoder.clause(right),decoder.single(pivot))
            donors += 1
        for hit in bank["hits"]:
            assert hit["receiver"] == key([hit["right"],hit["pivot"]])
            clause,pivot = frozen(hit["right"]),frozen(hit["pivot"])
            assert (False,pivot) not in clause
            audit_raw_mark(bank["donors"][hit["donor"]]["mark"],clause,pivot)
            hits += 1
    for case in outcome["cases"]:
        for label,arm in case["arms"].items():
            bank = banks[case["id"]+"/"+label]
            assert len(bank["hits"]) == arm["counts"].get("mark_hits",0)
            assert arm["counts"]["proposals"] == arm["independently_checked"]
            proof = arm.get("proof")
            if proof:
                c = read(proof["artifact"])
                builder,*_ = experiment.compiled(*targets[case["id"]])
                assert c["prefix"] == builder.prefix() and c["machine_sha256"] == admission.machine.digest()
                for line,raw in zip(proof["lines"],decoder.read(c["prefix"],c["word"]),strict=True):
                    assert decoder.clause(builder.literals(line["clause"],{})) == raw["clause"]
                    rows += 1
                assert verify(admission.machine,c["prefix"],c["word"],c["padding"],c["trace"],
                              study.CAP) == proof["receipt"]
                proofs += 1
    result = dict(status="CHECKED_FRONTIER_CERTIFICATES",donors=donors,mark_hits=hits,proofs=proofs,lines=rows)
    (ROOT/"data/frontier-audit-v1.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(json.dumps(result,sort_keys=True))


if __name__ == "__main__":
    main()
