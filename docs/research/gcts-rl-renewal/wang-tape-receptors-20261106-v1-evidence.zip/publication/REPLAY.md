# Replay the Wang tape receptor experiment

Use Python 3.12 and its standard library. In an extracted copy, preserve
the supplied evidence and run the following commands from the archive root.

    mv data archived-data
    mkdir data
    python3.12 -I -S -B source/experiment_v1.py
    python3.12 -I -S -B source/audit_moves_v1.py
    python3.12 -I -S -B source/frontier_v1.py
    python3.12 -I -S -B source/audit_frontier_v1.py
    python3.12 -I -S -B publication/render_v1.py

The two search scripts declare all training seeds, proposal bounds, and
grounding depths. The grouped experiment compares direct membership,
plain Wang admission, marked Wang admission, and marked admission
with a frozen contextual bandit. The interleaved frontier compares
ordinary priority and a policy trained with discounted returns.

Both search scripts check the compiled machine against the published
verifier digest. The compiler metadata adds names for physical read
states and leaves all machine transitions unchanged. The two audit
scripts can also run directly against the included data without search.
They replay the donor fragments, check the stored receiver terms against
the addressed witnesses, and recheck the exported proof frames.

Use the hashes in `publication/replay-v1.json` to compare scientific
outputs. The browser qualification uses MathJax and headless Chromium.
Set `GCTS_CHROME` and `GCTS_PLAYWRIGHT` for custom installations and
run `node publication/check_v1.cjs`.
