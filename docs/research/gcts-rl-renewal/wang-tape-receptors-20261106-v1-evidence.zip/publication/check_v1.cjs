const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-tape-receptors-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 130);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("section.proof").count(), 7);
    assert.equal(await page.locator("section.proof tbody tr").count(), 67);
    assert.equal(await page.locator(".wang-cell").count(), 360);
    assert.equal(await page.locator("#receptor .wang-cell").count(), 45);
    assert.equal(await page.locator("#receptor mark").count(), 2);
    assert.equal(await page.locator("#learning svg.bars rect").count(), 4);
    const proof = page.locator("#peano-nonzero-successor");
    await proof.locator("td details summary").first().click();
    await proof.locator("td details code").first().waitFor();
    assert.equal(await proof.locator(".wang-cell:visible").count(), 45);
    if (!process.argv[2]) {
      await page.locator("#receptor").screenshot({ path: path.join(__dirname, "receptor-v1.png") });
      await page.locator("#learning figure").screenshot({ path: path.join(__dirname, "comparison-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_WANG_TAPE_SEARCH_READER", proofs: 7, records: 67,
      wangCells: 360, math: await page.locator("mjx-container").count(), mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
