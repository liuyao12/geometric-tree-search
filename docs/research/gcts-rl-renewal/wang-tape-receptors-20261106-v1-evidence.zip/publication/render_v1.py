"""Render the paired Wang move search results and a certified receptor."""
from collections import Counter
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"publication"))
from proof_views_v1 import NAMES, expression, load_frame, math, proof_section, window_svg
from boundary_kernel_v1 import build

STEM = "wang-tape-receptors-20261106-v1"


def counted(row, key):
    return row["counts"].get(key,0)


def work(row):
    return sum(counted(row,k) for k in ("native_steps","parent_steps","donor_replay_steps"))


def tape_spans(text, at):
    assert text[at] == "("
    tail = text.index(".",at+1)
    kids = []
    pos = tail+1
    while text[pos] != ")":
        node, pos = tape_spans(text,pos)
        kids.append(node)
    return (at+1, tail, kids), pos+1


def top_left_span(tree, address):
    for j in address:
        tree = tree[2][j-1]
    return tree[:2]


def literals(text):
    result = []
    pos = 0
    while pos < len(text):
        assert text[pos] in "+-"
        node, end = tape_spans(text,pos+1)
        result.append((pos,node))
        pos = end
    return result


def colored(text, span):
    a,b = span
    return escape(text[:a]) + "<mark>" + escape(text[a:b]) + "</mark>" + escape(text[b:])


def donor_view(machine, examples):
    bank = examples["hilbert-incidence-uniqueness/marked"]
    counted_hits = Counter(h["donor"] for h in bank["hits"] if h["donor"] != h["receiver"])
    addressable = [digest for digest in counted_hits
                   if any(reason == "name" and path for reason,path in bank["donors"][digest]["mark"])]
    chosen = max(addressable,key=lambda x: (counted_hits[x],x))
    sample = bank["donors"][chosen]
    i,path = next((i,path) for i,(reason,path) in enumerate(sample["mark"]) if reason == "name" and path)
    left,right,pivot,_ = sample["pair"]
    rl = literals(right)
    right_span = top_left_span(rl[i][1],path)
    pivot_span = top_left_span(tape_spans(pivot,0)[0],path)
    assert right[slice(*right_span)] != pivot[slice(*pivot_span)]
    e = sample["trace"]
    width = len(machine.marks)+1
    right0 = len(">C0:"+left+";C1:")
    pivot0 = len(e["prefix"]+"G0:0:/"+left+";G1:1:/"+right+";R10:0:1:")
    col_r, col_p = (1+width*(j+span[0]) for j,span in ((right0,right_span),(pivot0,pivot_span)))
    first_col = 1+width*(right0+rl[i][0])
    _,a = sample["right"][i]
    receivers = [h for h in bank["hits"] if h["donor"]==chosen and h["donor"]!=h["receiver"]]
    example = next((h for h in receivers if h["right"][i] != sample["right"][i] or h["pivot"] != sample["pivot"]),
                   receivers[0])
    _,next_atom = example["right"][i]
    evidence = dict(prefix=e["prefix"],word=e["word"],trace=e["parents"]+e["fragment"],padding=0)
    image,label = window_svg(machine,evidence,(sample["trace_steps"]-5,e["head"]))
    path_text = " → ".join(str(i) for i in path)
    return f'''<div class="scope">
<div>
<h3>One addressed mismatch</h3>
<p>The right parent contains {math(expression(a,True))}. The proposed pivot is {math(expression(sample["pivot"]))}. At child address <code>{path_text}</code> their symbol codes differ.</p>
<dl class="words"><dt>Right parent</dt><dd><code>{colored(right,right_span)}</code></dd><dt>Pivot</dt><dd><code>{colored(pivot,pivot_span)}</code></dd></dl>
<p class="small">The literal starts at top column {first_col:,}. The highlighted symbols start at columns {col_r:,} and {col_p:,} in this fragment. The display omits the marker slots between characters.</p>
<p>The same mark later rejects a different receiver. At that literal position the receiver contains {math(expression(next_atom,True))} and proposes pivot {math(expression(example["pivot"]))}. Every site in the original mark is checked again on the receiver.</p>
</div>
<figure>{image}<figcaption>{label} This window ends at the transition into rejection after the scan has exhausted the right parent's pivot candidates. The outlined square carries the head.</figcaption></figure>
</div>'''


def frontier_view(result):
    rows = []
    by_id = {}
    for case in result["cases"]:
        name = case["id"]
        a,b = (case["arms"][k] for k in ("plain-priority","learned-priority"))
        by_id[name] = (a,b)
        rows.append(f'<tr><th scope="row">{NAMES[name]}</th><td>{counted(a,"proposals"):,}</td>'
                    f'<td>{counted(b,"proposals"):,}</td><td>{counted(a,"native_checks"):,}</td>'
                    f'<td>{counted(b,"native_checks"):,}</td><td>{b["status"].title()}</td></tr>')
    h, k = by_id["hilbert-incidence-uniqueness"]
    c, d = by_id["counter-halt"]
    e, f = by_id["peano-nonzero-successor"]
    note = (f'The plain frontier finished Hilbert incidence uniqueness in {counted(h,"native_checks"):,} Wang checks. '
            f'The learned priority took {counted(k,"native_checks"):,}. '
            f'Learning helped the halting example, reducing its checks from {counted(c,"native_checks")} to '
            f'{counted(d,"native_checks")}. On Peano successor nonzeroness the counts rose from '
            f'{counted(e,"native_checks")} to {counted(f,"native_checks")}. '
            'The learned ordering generalized unevenly from the training episodes.')
    return "".join(rows), note, h, k


def chart(plain, marked, frontier, learned):
    values = [counted(x,"native_checks") for x in (plain,marked,frontier,learned)]
    names = ("Plain grouped", "Marked grouped", "Plain frontier", "Learned frontier")
    colors = ("#8da4b4","#337e91","#227550","#a96e28")
    svg = ['<svg class="bars" viewBox="0 0 635 159" role="img" aria-label="Wang checks on Hilbert incidence uniqueness">']
    for i,(name,n,color) in enumerate(zip(names,values,colors,strict=True)):
        y = 9+38*i
        width = 400*n/max(values)
        svg.append(f'<text x="2" y="{y+15}">{name}</text><rect x="141" y="{y}" width="{width:.2f}" '
                   f'height="22" fill="{color}" rx="3"/><text x="{149+width:.2f}" y="{y+15}">{n:,}</text>')
    svg.append("</svg>")
    return "".join(svg)


def main():
    results = json.loads((ROOT/"data"/"results-v1.json").read_text())
    audit = json.loads((ROOT/"data"/"audit-v1.json").read_text())
    frontier = json.loads((ROOT/"data"/"frontier-v1.json").read_text())
    examples = load_frame("receptors-v1.json.gz")
    machine = build().compile()
    assert machine.digest() == results["machine_sha256"]
    summaries, moves, proofs = [], [], []
    for r in results["cases"]:
        a,b,c,d = (r["arms"][k] for k in ("membership","plain","marked","ranked"))
        id = r["id"]
        summaries.append(f'<tr><th scope="row"><a href="#{id}">{NAMES[id]}</a></th>'
                         f'<td>{counted(a,"proposals"):,}</td><td>{counted(b,"native_checks"):,}</td>'
                         f'<td>{counted(c,"native_checks"):,}</td><td>{counted(d,"native_checks"):,}</td>'
                         f'<td>{c["marks"]["different"]:,}</td><td>{d["status"].title()}</td></tr>')
        moves.append(f'<tr><th scope="row">{NAMES[id]}</th><td>{work(b):,}</td><td>{work(c):,}</td>'
                     f'<td>{work(d):,}</td><td>{counted(d,"proposals"):,}</td></tr>')
        if r["proof"]:
            p = r["proof"]
            proofs.append(proof_section(dict(id=id,source=r["case"],evidence=p["artifact"],
                                            lines=p["lines"],machine={"commits":p["commits"]},
                                            source_clauses=p["source_clauses"]),machine))
    hilbert = next(r["arms"] for r in results["cases"] if r["id"]=="hilbert-incidence-uniqueness")
    plain, marked, ranked = (hilbert[k] for k in ("plain","marked","ranked"))
    delta = 100*(work(plain)-work(marked))/work(plain)
    ranked_proposals = sum(counted(r["arms"]["ranked"],"proposals") for r in results["cases"])
    baseline_proposals = sum(counted(r["arms"]["plain"],"proposals") for r in results["cases"])
    frontier_rows, frontier_note, frontier_h, learned_h = frontier_view(frontier)
    counts = dict(TRAIN=str(len(results["training"])), UPDATES=f'{results["rank"]["updates"]:,}',
                  HILBERT_SKIP=f'{marked["marks"]["hits"]:,}', HILBERT_CHECKS=f'{counted(plain,"native_checks"):,}',
                  HILBERT_WORK=f'{delta:.1f}%', RANK_HILBERT=f'{counted(ranked,"proposals"):,}',
                  RANK_ALL=f'{ranked_proposals:,}', PLAIN_ALL=f'{baseline_proposals:,}',
                  AUDIT_DONORS=f'{audit["donors"]:,}', AUDIT_HITS=f'{audit["hits"]:,}',
                  AUDIT_PROOFS=str(audit["final_proofs"]), AUDIT_LINES=str(audit["decoded_lines"]))
    text = (ROOT/"publication"/"notebook-v1.html").read_text()
    values = dict(STEM=STEM,TABLE="".join(summaries),WORK="".join(moves),PROOFS="\n".join(proofs),
                  RECEPTOR=donor_view(machine,examples),FRONTIER=frontier_rows,FRONTIER_NOTE=frontier_note,
                  CHART=chart(plain,marked,frontier_h,learned_h),**counts)
    for label,value in values.items():
        marker = "%%"+label+"%%"
        assert marker in text
        text = text.replace(marker,value)
    assert "%%" not in text
    (ROOT/"report"/f"{STEM}.html").write_text(text)


if __name__ == "__main__":
    main()
