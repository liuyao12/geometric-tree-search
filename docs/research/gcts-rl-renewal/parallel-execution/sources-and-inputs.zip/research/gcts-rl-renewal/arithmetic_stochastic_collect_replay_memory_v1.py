"""Read-only terminal receipt collection; no engine imports or trace inflation.

Freeze first, collect only through an exact root terminal-handle activation.
Package task-owned repair artifacts; older inputs remain exact referenced pins.
"""
import argparse
import ast
import hashlib
import json
import resource
import signal
import time
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'.gcts-active/stochastic-replay-memory-20261011'
COLLECT=OUT/'collector-v1'
SOURCE=Path(__file__).resolve()


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()


def rel(path):return str(path.relative_to(ROOT))


def read(path):
    if path.suffix in ('.gz','.zip'):raise ValueError('collector never inflates compressed inputs')
    value=json.loads(path.read_bytes())
    if not isinstance(value,dict):raise ValueError('receipt object required '+str(path))
    return value


def save(path,value):
    with path.open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')


def freeze():
    began=time.perf_counter()
    COLLECT.mkdir()
    ast.parse(SOURCE.read_text(),filename=str(SOURCE))
    package=read(OUT/'review-package-v1.json')
    source_pins={rel(SOURCE):sha(SOURCE)}
    input_pins={}
    for path in (OUT/'review-package-v1.json',OUT/'scope-note-v1.json',OUT/'source-verification-v1.json',
                 OUT/'helper-plan-v1.json',OUT/'evaluation-plan-v1.json'):
        input_pins[rel(path)]=sha(path)
    for item in package['files']:input_pins[item['path']]=item['sha256']
    source_pins.update(package['sources']);input_pins.update(package['inputs'])
    plan=dict(status='frozen_before_terminal_receipt_collection',source_sha256=source_pins,
        input_sha256=input_pins,seconds=120,rss_bytes=512*1024*1024,
        phases=[dict(kind='helpers',plan_path=rel(OUT/'helper-plan-v1.json'),
                     plan_sha256=sha(OUT/'helper-plan-v1.json')),
                dict(kind='evaluation',plan_path=rel(OUT/'evaluation-plan-v1.json'),
                     plan_sha256=sha(OUT/'evaluation-plan-v1.json'))],
        collector_activation_path=rel(COLLECT/'activation-v1.json'),
        output_path=rel(COLLECT/'summary-v1.json'),manifest_path=rel(COLLECT/'integration-v1.json'),
        evidence_zip_path=rel(COLLECT/'evidence-v1.zip'),
        required_activation='Root authorizes exact collector-plan SHA after all relevant owned handles are terminal; supplies exact terminal phase-receipt SHA map, terminal_handles list and authoritative_terminal_status=true. An explicitly unexecuted evaluation phase may be declared without a fabricated receipt.',
        scope='Only metadata JSON and streaming hashes/ZIP copies. No compressed input decoding, trace inflation, engine call, search, training, native query or proof assertion. Exact task-only export with original input pins referenced.',
        cost_scope='Use inclusive owner phase seconds once; do not sum component worker/search/decode/byte-check/replay times on top. Source-authoring/helper collection time separately disclosed; original18.112109042s unknown retained.',
        outcome_scope='All-six byte correspondence, complete actual graph/policy replay and terminal resource gates are separate fields. Unknown/unexecuted remain unknown/unexecuted; no policy speedup, theorem/generalization/native acceptance follows.')
    save(COLLECT/'plan-v1.json',plan)
    save(COLLECT/'freeze-receipt-v1.json',dict(status='frozen_read_only_collector',source_sha256=sha(SOURCE),
        plan_sha256=sha(COLLECT/'plan-v1.json'),seconds_before_receipt_write=time.perf_counter()-began,
        searches=0,training_episodes=0,native_queries=0,trace_inflations=0,actual_outputs_collected=0))
    print(json.dumps(dict(status='frozen_read_only_collector',plan_sha256=sha(COLLECT/'plan-v1.json'),
                         source_sha256=sha(SOURCE))),flush=True)


def phase_summary(item,activation):
    phase_plan_path=ROOT/item['plan_path'];phase_plan=read(phase_plan_path)
    if sha(phase_plan_path)!=item['plan_sha256']:raise ValueError('exact phase plan')
    phase_path=ROOT/phase_plan['output_path'];key=rel(phase_path)
    declared=activation['phases'][item['kind']]
    if declared['execution']=='unexecuted':
        if phase_path.exists():raise ValueError('unexecuted phase already has an outcome')
        return dict(kind=item['kind'],status='unexecuted',attempted=[],failed=[],
            unexecuted=[j['job'] for j in phase_plan['jobs']],records=[],seconds=None,
            complete_byte_correspondence_count=0,complete_graph_replay_count=0,complete_phase_pass=False)
    if declared['execution']!='terminal' or declared.get('receipt_sha256')!=sha(phase_path):
        raise ValueError('root exact terminal phase receipt '+key)
    phase=read(phase_path)
    if phase['plan_sha256']!=item['plan_sha256']:raise ValueError('phase receipt plan binding')
    if phase['kind']!=item['kind']:raise ValueError('phase kind')
    jobs=phase_plan['jobs'];by={o['lifetime']['job']:o for o in phase['observations']}
    names=[j['job'] for j in jobs]
    if len(by)!=len(phase['observations']):raise ValueError('duplicate observed job')
    attempted=phase['attempted'];unexecuted=phase['unexecuted']
    if set(attempted)|set(unexecuted)!=set(names) or set(attempted)&set(unexecuted):
        raise ValueError('complete attempted/unexecuted accounting')
    if set(by)!=set(attempted) or not set(phase['failed']).issubset(attempted):
        raise ValueError('terminal observation coverage')
    records=[]
    for job in jobs:
        job_plan=read(ROOT/job['plan_path'])
        if sha(ROOT/job['plan_path'])!=job['plan_sha256']:raise ValueError('exact job plan')
        record=dict(job=job['job'],phase=item['kind'])
        if job['job'] not in by:
            record.update(status='unexecuted',complete_bytes=False,complete_graph=False)
            records.append(record);continue
        observation=by[job['job']];lifetime=observation['lifetime'];worker=observation['receipt']
        lifetime_path=(ROOT/job['output_path']).parent/(job['job']+'-lifetime.json')
        if read(lifetime_path)!=lifetime:raise ValueError('phase/standalone lifetime mismatch')
        if lifetime.get('terminal_and_reaped') is not True:raise ValueError('worker must be terminal and reaped')
        output=ROOT/job['output_path']
        if worker is not None:
            if read(output)!=worker or lifetime.get('receipt_sha256')!=sha(output):
                raise ValueError('phase/standalone worker receipt mismatch')
            if worker['plan_sha256']!=job['plan_sha256']:raise ValueError('worker plan binding')
        elif output.exists():raise ValueError('missing nested worker receipt has an existing output')
        passed=lifetime['status']=='passed_owned_loading_worker_lifetime'
        byte_gate=(worker or {}).get('complete_original_trace_byte_correspondence')
        bytes_completed=bool(byte_gate and byte_gate.get('status')=='passed_complete_original_compact_json_byte_correspondence'
            and byte_gate['original_uncompressed_sha256']==byte_gate['emitted_sha256'] and byte_gate['bytes']>0)
        graph_completed=bool(worker and worker.get('status')=='passed_complete_actual_graph_rng_and_policy_replay')
        record.update(status='passed' if passed else 'unknown_or_failed',worker_status=(worker or {}).get('status'),
            worker_failure=(worker or {}).get('failure'),lifetime_status=lifetime['status'],lifetime_failure=lifetime.get('failure'),
            full_worker_seconds=lifetime['full_worker_seconds'],worker_internal_seconds=(worker or {}).get('seconds_before_receipt_write'),
            conservative_peak_bytes=lifetime['conservative_owner_plus_worker_peak_bytes'],
            memory_overshoot_bytes=lifetime['memory_overshoot_bytes'],wall_overshoot_seconds=lifetime['wall_overshoot_seconds'],
            complete_bytes=passed and bytes_completed,byte_comparison_completed_before_resource_gate=bytes_completed,
            byte_correspondence=byte_gate,complete_graph=passed and graph_completed,
            graph_replay_completed_before_resource_gate=graph_completed,tree=(worker or {}).get('tree'),
            loading_statistics=(worker or {}).get('loading_only_repair_statistics',(worker or {}).get('loading')),
            canonical=(worker or {}).get('canonical'),weights_sha256=(worker or {}).get('weights_sha256'))
        if item['kind']=='evaluation':
            trace=ROOT/job_plan['trace_path'];summary_path=Path(str(trace).replace('-search.json.gz','-summary.json'))
            expected=job_plan['input_sha256'].get(rel(summary_path))
            if expected!=sha(summary_path):raise ValueError('exact producer summary')
            producer=read(summary_path)
            record['producer']=dict(status=producer['status'],search_status=producer['search_status'],
                metrics=producer['metrics'],search_seconds=producer['search_seconds'],
                model_setup_seconds=producer['model_setup_seconds'],model_binding_seconds=producer['model_binding_seconds'],
                trace_serialization_seconds=producer['trace_serialization_seconds'],
                weights_sha256=producer['weights_sha256'],proof_rows=producer['proof_rows'],
                trace_sha256=job_plan['input_sha256'][rel(trace)])
        records.append(record)
    expected_status=('passed_complete_loading_value_correspondence_helpers' if item['kind']=='helpers'
                     else 'passed_complete_loading_only_six_evaluation_replays')
    complete=phase['status']==expected_status and len(attempted)==len(jobs) and not phase['failed']
    if complete and not all(r['status']=='passed' for r in records):raise ValueError('complete phase contains nonpassing worker')
    return dict(kind=item['kind'],status=phase['status'],attempted=attempted,failed=phase['failed'],unexecuted=unexecuted,
        records=records,seconds=phase['seconds_before_phase_receipt_write'],complete_phase_pass=complete,
        complete_byte_correspondence_count=sum(r['complete_bytes'] for r in records),
        complete_graph_replay_count=sum(r['complete_graph'] for r in records),
        conservative_peak_bytes=phase['conservative_owner_plus_worker_peak_bytes'],
        phase_receipt_sha256=sha(phase_path),phase_plan_sha256=item['plan_sha256'])


def alarm(*_):raise TimeoutError('read-only collection wall gate')


def collect():
    began=time.perf_counter();plan_path=COLLECT/'plan-v1.json';plan=read(plan_path)
    output=ROOT/plan['output_path'];manifest=ROOT/plan['manifest_path'];evidence=ROOT/plan['evidence_zip_path']
    if any(p.exists() for p in (output,manifest,evidence)):raise ValueError('immutable one-shot collection exists')
    signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,plan['seconds'])
    result=dict(status='collecting_terminal_loading_repair',plan_sha256=sha(plan_path),
        searches=0,training_episodes=0,native_queries=0,trace_inflations=0,errors=[])
    try:
        for name,h in {**plan['source_sha256'],**plan['input_sha256']}.items():
            if sha(ROOT/name)!=h:raise ValueError('frozen collector/source/input pin '+name)
        activation=read(ROOT/plan['collector_activation_path'])
        if activation['status']!='authorized_by_root_after_all_owned_handles_terminal' or activation['plan_sha256']!=sha(plan_path):
            raise ValueError('root terminal-handle collector activation')
        if activation['authoritative_terminal_status'] is not True or not isinstance(activation['terminal_handles'],list):
            raise ValueError('root authoritative process-terminal evidence required')
        phases=[phase_summary(item,activation) for item in plan['phases']]
        helper,evaluation=phases
        byte_complete=evaluation['complete_phase_pass'] and evaluation['complete_byte_correspondence_count']==6
        graph_complete=evaluation['complete_phase_pass'] and evaluation['complete_graph_replay_count']==6
        phase_cost=sum(item['seconds'] for item in phases if item['seconds'] is not None)
        result.update(status='collected_complete_terminal_loading_repair_metadata',phases=phases,
            evaluation_all_six_complete_bytes=byte_complete,evaluation_all_six_complete_graph_rng_policy_replay=graph_complete,
            verified_all_six=helper['complete_phase_pass'] and byte_complete and graph_complete,
            historical_failed_audit=dict(status='unknown_independent_phase_resource_budget',seconds=18.112109042,
                conservative_peak_bytes=1720975360,receipt_sha256='c01d34f2a071db8d760d0aaa065d0cfa3e6ea1e8e917815b4269f36fb224e9ff'),
            costs=dict(inclusive_owned_helper_and_evaluation_phase_seconds=phase_cost,
                historical_failed_seconds=18.112109042,cumulative_scientific_audit_seconds=phase_cost+18.112109042,
                original_cumulative_audit_seconds=780,component_clocks_are_nested_and_not_added=True,
                collector_cost_is_separate=True,source_preparation_is_separate=True),
            scope='Full all-six JSON byte correspondence and complete graph/RNG/features/policy replay are separately gated by terminal resource receipts. Existing six search cutoffs remain unknown; no new search, training, native query, learned marking admission, speedup or held-out theorem generalization claim.',
            terminal_activation_sha256=sha(ROOT/plan['collector_activation_path']))
    except Exception as exc:
        result.update(status='failed_or_unknown_terminal_metadata_collection',errors=[dict(type=type(exc).__name__,message=str(exc))])
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        result.update(collection_seconds_before_summary_write=time.perf_counter()-began,
                      collection_kernel_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if result['collection_seconds_before_summary_write']>plan['seconds'] or result['collection_kernel_peak_rss_bytes']>plan['rss_bytes']:
            result['status']='unknown_read_only_collection_resource_budget'
        save(output,result)
    if result['status']!='collected_complete_terminal_loading_repair_metadata':
        print(json.dumps({k:v for k,v in result.items() if k!='phases'}),flush=True);return
    paths=[path for path in OUT.rglob('*') if path.is_file() and 'decoder-temp' not in path.parts
           and path not in (manifest,evidence)]
    if any(path.suffix not in ('.json','.zip','.txt') for path in paths):raise ValueError('unexpected task-owned evidence extension')
    paths.append(SOURCE);paths=sorted(set(paths),key=rel)
    with zipfile.ZipFile(evidence,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for path in paths:archive.write(path,rel(path))
    paths.append(evidence)
    entries=[dict(path=rel(path),sha256=sha(path),bytes=path.stat().st_size) for path in sorted(paths,key=rel)]
    integration=dict(status='frozen_task_only_terminal_loading_repair_export',files=entries,
        summary_path=rel(output),evidence_zip_path=rel(evidence),
        exact_original_source_and_input_bindings=plan['input_sha256'],
        scope='Only repair task-owned new sources/plans/receipts/logs/reviews/activation and original exact source snapshot. Older original traces/model/catalog/registry are referenced by exact unchanged input hashes, not inflated or duplicated.',
        summary_sha256=sha(output),verified_all_six=result['verified_all_six'],
        collection_plus_export_seconds_before_manifest_write=time.perf_counter()-began,
        collection_plus_export_kernel_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    save(manifest,integration)
    print(json.dumps(dict(status=integration['status'],files=len(entries),manifest_path=rel(manifest),
        manifest_sha256=sha(manifest),verified_all_six=result['verified_all_six'],
        seconds_before_manifest_write=integration['collection_plus_export_seconds_before_manifest_write'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();m=parser.add_mutually_exclusive_group(required=True)
    m.add_argument('--freeze',action='store_true');m.add_argument('--collect',action='store_true')
    args=parser.parse_args();freeze() if args.freeze else collect()
