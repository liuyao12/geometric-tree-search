"""Freeze a private proposal after syntax-only enumeration; run no experiment."""
import gzip, hashlib, json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
DOC=ROOT/'docs/research/gcts-rl-renewal'
def load(p):
    raw=p.read_bytes()
    return json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw)
def file_pin(p):
    return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)

def main():
    target=HERE/'proposal-v1.json'
    if target.exists():raise ValueError('immutable proposal already exists')
    preview=load(HERE/'inventory-preview-v1.json.gz')['primary']
    checks=load(HERE/'preview-checks-v1.json')
    prior_plan=load(DOC/'hilbert_promotion_family_v3_plan.json')
    source=load(HERE/'source-schemas-v1.json')
    records=[]
    for ci,spec in enumerate(preview['cases']):
        methods=[(language,mode) for language in ['level1','promoted'] for mode in ['base','fixed','learned']]
        methods=methods[ci:]+methods[:ci]
        for language,mode in methods:
            records.append(dict(case_id=spec['id'],length=spec['length'],language=language,mode=mode,
                feature_semantics='expanded-word',repetition=1,tag=spec['id']+'-'+language+'-'+mode+'-expanded'))
    axiom_map={'I.2-uniqueness':'I.2-uniqueness'}
    command_requirements={
      'assumption':'Retain every ordered local premise, even equal or contradictory images. Preserve its integer index and require mapped formula equals mapped premises[index]. Never turn it into an undeclared global axiom.',
      'axiom':'Keep a total named axiom map on actually used source axioms; recipient[name_map[name]] must be exactly sigma(source[name]). Only I.2 is used by uniqueness; it is constant-free and maps identically. Original ground source hypotheses are already discharged into local premises in the accepted promoted source.',
      'instantiate':'Keep universal binders and variable ASTs unchanged. Map formula, universal and closed zero-arity term. Check the syntactic substitution identity commutes with sigma; no new open terms or variable renaming allowed.',
      'eq_subst':'Keep the hole variable incidenceHole unchanged; map template, formula, left and right terms uniformly. Only the actual atomic Incident(C,hole) template is in this first schema. Closed images introduce no free variables or binder capture.',
      'mp':'Preserve antecedent and implication integer indices exactly, including strict-earlier order. Homomorphic formula mapping preserves the literal implication match.',
      'block':'Map name through the dependency-name map, and keep every inputs index and its order/multiplicity unchanged. The entire mapped dependency declaration must precede the call. Match mapped ordered premises and conclusion literally, not up to logical equivalence.'}
    proposal=dict(
      version='hilbert-chain-composition-proposal-1',status='planning_only_requires_root_review',
      completed_searches=0,native_queries=0,point_models_constructed=0,transport_checker_implemented=False,
      hypothesis='The already searched two-input incidence receptor can attach twice, with an actual output from one target-ancestor cluster supplying a premise of a later cluster. A third line changes the receptive boundary rather than merely renaming an old assertion.',
      theory_and_cases=preview['cases'],inventory_status='unadmitted_syntax_preview',
      primary_parameter_order=preview['parameter_order'],primary_parameter_domains=preview['parameter_domains'],
      exact_counts=checks['primary_counts'],coincident_bindings_retained=checks['coincident_bindings_retained'],
      changed_decorated_interfaces=checks['new_decorated_interfaces'],unchanged_decorated_interfaces=checks['unchanged_decorated_prior_interfaces'],
      grounding_scope='Native logic is one-sorted with explicit Point/Line predicates. A/B range over the retained common-point role pool P,Q; C over P,Q,R; u/v over all l,m,n. This is complete within that declared finite role grammar, not an unrestricted first-order proof language. No Point(R) premise or geometric coordinate fact is supplied. No target-conditioned cone or post-result binding removal.',
      formula_basis_scope='Exactly 55 complete formula interface/axiom/target words: 36 H words, 9 line equations, 9 incidence words, and the one closed I.2. variables and ordinary schemes empty. No recursive conjunction decomposition or ad hoc logical oracle.',
      deduplication=preview['deduplication'],
      measurement=dict(schedule=records,runs=18,seed=72000,repetitions=[1],stochastic=False,
        limits=dict(attempts=8000,seconds=30,proposal_limit=24,proposal_checks=2048),
        fixed_weights=[.7,.3,1.,.8,.2,-.1,.2,.2,.4,0.],frozen_learned_weights=prior_plan['weights'],
        treatment='Within each language and boundary only proposal ordering weights change. All policies retain the same candidates, inventory, representation, roots, scheduler, seed and limits. Expanding 63 to 171 interfaces is a language comparison, not an RL improvement. No new training or statistical significance claim.',
        actual_composition_success='Independent target-ancestor audit identifies at least two level-two block calls; an output row of one is an actual named premise-source row of the later call. Merely selecting two unused macros or obtaining a one-macro-plus-primitive proof does not satisfy double composition. Do not filter search by this criterion; report the first actual proof and its dependency graph.',
        conformance='Fixed orientations and integer occupancy; C/G/two input roots all active at generation zero. Complete point/candidate graph: global dead, global forced, earliest generation branch, exact base fallback and rollback. Proposal limits restrict preference only. All actual graph trees/model-word correspondences independently replayed.',
        report='Every finite exact point result, exhaustion, search cutoff, admission/guard unknown, native whole unknown and resource ceiling retained; automatic searched command sequence readable line by line. Distinguish the symbolic guarded incidence fragment from full Hilbert Euclidean geometry and the high-level adaptation from a compiled primitive square Wang system.'),
      resource_proposal=dict(native_steps_each_preparation_request=20_000_000_000,whole_native_steps=20_000_000_000,
        native_production_seconds_ceiling=5400,
        budget_scope='All newly executed library, theory, guard and whole requests. Check actual cumulative native request elapsed time before the next request; preserve exact current-query overshoot. Never launch a native batch in this planning phase.',
        incomplete_preparation='Any unresolved interface, theory or guard stops before target search; keep all declared bindings and report unknown. Never silently reduce inventory.',
        whole_gate='Checkpoint the exact complete point tree before native whole certification. On exhausted whole native allowance retain remaining point trials; their proofs are native-unknown, not accepted. Fresh full request includes dependency closure of every actually used transformed definition.',
        model_gate='Before construction calculate the complete analytic candidate upper bound. Above 100000 report model_resource_unknown; do not sample candidates or use a shortlist for dead/forced counts.',
        search_wall_budget_nominal_seconds=18*30,
        limits_semantics='Current query/search check can overshoot its nominal wall allowance; record actual elapsed and overshoot. Native heap, parser, program and palette are unchanged.',
        peak_rss_estimate_bytes=[300*1024*1024,600*1024*1024],
        peak_rss_scope='Planning estimate, not an enforced memory ceiling or measurement. Stream independent full-word correspondence; report actual peak RSS and output serialization cost.'),
      native_admission_control=dict(requests=checks['full_route_preparation'],
        order='Fresh I.2-only six-constant theory; all 63 level-one definitions; all 108 level-two definitions, each with both actual lower dependencies; fresh recipient theory and all 55 tautology guards; only then 18 complete bounded point searches.',
        reuse='Zero byte-identical five-constant library/request reuse in the six-constant control. All 76 retained definition bodies are exact old bytes but their full theory-bound native requests change. Whole request reuse only after exact equality and actual full independent replay binding, with hash/lookup/replay provenance and costs.',
        fresh_whole_requests_maximum=18,new_native_requests_maximum_without_retries=246,
        full_replay='Every executed request including unknown: frozen program/input bytes, all output bands and micro/physical step and FNV counts. Independent logical replay is audit-only and must not determine a search choice.'),
      proposed_constant_transport=dict(status='proposal_no_new_native_admission_or_structural_certificate',
        candidate_native_preparation_minimum=checks['transport_route_native_minimum'],
        schemas=[dict(source_name=b['name'],command_count=len(b['proof']),premise_count=len(b['premises']),
                      rules=sorted(set(c['rule'] for c in b['proof']))) for b in source['blocks']],
        theorem_statement='For an accepted acyclic source declaration DAG D over signature S and closed theory T, restricted to the six actual rule forms assumption/axiom/instantiate/eq_subst/mp/block, let sigma map each declared zero-arity source constant to a declared zero-arity recipient constant, preserving predicate names/arities and all logical constructors and variables. Let recipient Tprime contain sigma(a) under a declared axiom-name map for every source axiom actually used. Let nu map every source dependency name to its complete transformed declaration in the same topological availability order. Then local derivability CheckBlock(S,T,D,Gamma,pi,A) implies CheckBlock(Sprime,Tprime,sigma_nu(D),sigma(Gamma),sigma_nu(pi),sigma(A)), conditional on a proved correspondence to the chosen logical check relation. This is preservation, not reflection for noninjective maps, and not a theorem about bounded native runtime acceptance.',
        precise_scope='Closed zero-arity constant images only. No open terms, parameter variables, quantifier closure/generalization, predicate substitution, arbitrary term replacement or new inference schema. Ground local-premise derivations are the inputs; no previously native-accepted closed universal lemma is claimed.',
        axiom_name_map=axiom_map,
        source_axiom_mapping='The accepted promoted source retains I.2 alone, and I.2 contains no source constants. Both ground hypotheses of original whole query 56 appear as ordered local assumptions in the promoted source, not retained theory axioms. Equality transport uses no theorem axiom; uniqueness and the composite dependency closure use I.2.',
        signature_checks='Map only fun-tagged zero-arity constants; verify source and recipient function declarations are arity zero, predicates Point/Line/Incident remain arities 1/1/2, variables and binders unchanged, and schemas empty. The role-sorted grammar remains a separately declared restriction. New unused constant n is a signature extension requiring the preservation bridge, not exact-byte reuse.',
        command_checks=command_requirements,
        dependency_checks='Recursively bind source receipt, full source body, transformed complete body, ordered local premises, conclusion, proof commands and dependency closure. Recompute canonical declaration names after all child names are mapped. Keep DAG order; reject missing/cyclic/forward dependencies, stale names or hash collisions. If two mapped bodies are exactly identical, record every source-to-name alias, preserve source call/reference order and premise multiplicity, and deduplicate only that complete identity.',
        capture_checks='For closed zero-arity images free(sigma(t)) is empty, so no variable can become captured. Establish sigma(phi[x:=t]) = sigma(phi)[x:=sigma(t)] for the actual closed operands in instantiate and eq_subst by structural induction. The fresh incidenceHole is a var tag, never a constant map key. Constant and variable strings need not be disjoint when AST tags/namespaces are checked; no generic string replacement.',
        noninjective_cases=['A=B: H still contains the explicit image of not(A=B), even when contradictory; all local assumptions remain.',
                            'u=v: reflexive line images remain full definitions and full source command chains.',
                            'C=A or C=B: interface atoms may coincide but references and ordered input roles stay unchanged.',
                            'Several coincidences together: no assumption erasure, target pruning or empirical guard-label transfer.'],
        proof_obligations=['Prove constant-transform well-formedness and substitution commutation on the specified AST subset.',
                          'Prove command preservation by induction on the exact source sequence, then block preservation in topological dependency order; explicitly handle integer references and ordered assumptions.',
                          'Establish a correspondence between this logical relation and the pinned native program on terminating accepted/rejected computations. Prior source acceptance is a receipt, not a general program-correctness proof.',
                          'Specify and independently validate a task-owned structural certificate checker, including full transformed-body reconstruction and corruptions of maps, axioms, dependencies, indices and templates.',
                          'Specify a separate certified_transport authority adapter with complete candidate correspondence. Existing Model requires native_accepted; do not relabel structural certificates as native_accepted or change the shared checker.',
                          'Freeze adapter/checker/producer/auditor sources and full authority/measurement amendment before trials; this proposal does not implement them.'],
        proposed_certificate_fields=['source full request SHA256 and accepted native/replay receipt pins','source DAG and theory/signature SHA256','closed constant map and axiom-name map','recipient theory/signature SHA256','ordered mapped premises/conclusions/commands and per-command source index','source-to-target block-name map and exact canonical transformed declaration hashes','topological dependency availability and deduplication aliases','checker/version/preservation-bridge pin and complete check report'],
        fresh_obligations='At minimum one fresh expanded I.2-only signature/theory request plus the recipient theory request and all 55 complete guards: 57 fresh preparation requests. Guard rejections are never transported, because noninjective maps can identify atoms and change tautology classification. Every actually searched whole request and all used transformed definitions are freshly native-checked unless that exact full request already has an independently replayed acceptance. Native parser/heap/step unknowns stay unknown.',
        genuinely_new='New cluster proof shape/commands or logical rules; new axiom dependency not mapped into recipient theory; changed signature arity or nonuniform symbols; open terms/eigenvariable/discharge conditions; altered universal theory. Removing I.2 fails the axiom mapping for uniqueness/composite even if some coincident premises are contradictory; equality-only transport has empty actual axiom dependency and can preserve into an empty theory under the proved bridge. Any level-three cluster mined from a new searched chain is new source authority, not a renaming of the old block.',
        unmeasured_work='Transport metaproof, checker/adapter design and review, source binding, all 171 transformed checks, serialization and final whole native payload/replay are charged. No measured cost or validity claim for this route. A separately native-admitted free-variable/closed-universal generic schema would add fresh bootstrap requests and a different proof obligation; the old quantified closure is heap-unknown and provides no such authority.'),
      costs=dict(preview_native_and_target_work=0,historical_source_schema_native_seconds=source['native_production_seconds'],
        historical_source_schema_native_micro_steps=source['native_micro_steps'],historical_source_schema_replay_seconds=source['source_audit']['seconds'],
        source_cost_scope='Original searched source, donor preparation, prior family admission/replays and policy training also remain charged historical provenance via the exact frozen manifests; component clocks overlap and are not summed as disjoint totals.',
        historical_rates=checks['historical_rates'],projected_new_definition_native_seconds=checks['projection_library_definition_seconds'],
        projected_guard_seconds_from_old_mean=55*checks['historical_rates']['guards']['mean_seconds'],
        estimation_scope='Approximately 71.3 minutes library definitions plus about 4.2 minutes guards, before fresh whole proofs, preparation/setup and similarly costly independent native replay. Different six-constant requests may change time, step count or heap outcome; rates are a planning estimate only.',
        transport_saving_hypothesis='Could avoid 171 fresh definition-admission requests, about 4276.5 historical-rate seconds of native production plus their independent replay. Its new certificate/trust/setup costs are currently unmeasured, and expanded whole certificate costs remain. Compare complete cold and amortized totals, not only proposal attempts.'),
      alternative_scope=dict(counts=checks['alternative_counts'],full_native_preparation=checks['full_sort_preparation'],
        role_expansion='Let all A/B/C vary over all P,Q,R. This is a distinct larger grammar, not an equivalent acceleration of the retained common-point-role grammar.',
        analytic_maximum_7row_promoted=236494,
        decision='Not the primary experiment: 453 preparation requests and a 7-row promoted model above the proposed 100000 candidate gate. Keep this count visible; do not claim unrestricted-sort completeness for the primary route.'),
      future_level_three='Only after a genuinely searched, whole-native-accepted and independently audited chain, consider promotion into a three-input receptor by mechanical local-assumption conversion with prior definitions retained. No level-three target block is supplied to this search. Under the primary role pools its potential six-parameter family would have 324 raw bindings (2 x 2 x 3 x 3 x 3 x 3); admission and deduplication require a new plan.',
      recommendation='Review the narrow constant-substitution metatheorem and its authority/correspondence contract first. If it is approved, commission the independent structural certificate/checker phase before paying for the chain batch. Preserve the complete 228-request native route as the admission control, and do not start either route from this planning artifact.',
      analytic_model_bounds=preview['analytic_model_bounds'],
      preserved_prior_exports=checks['verified_prior_exports'],
      data_dependencies=[file_pin(p) for p in [HERE/'source-schemas-v1.json',HERE/'inventory-preview-v1.json.gz',HERE/'preview-checks-v1.json',
         DOC/'hilbert_promotion_family_v3_plan.json',DOC/'first-order-families-reader-001.json',
         DOC/'hilbert_receptors_closure_result.json',DOC/'hilbert_receptors_closure_audit.json',
         DOC/'proof-boundary-001.json',DOC/'proof-boundary-microcode-001.json.gz']],
      source_pins=[file_pin(p) for p in [HERE/'hilbert_chain_planning_preview_v1.py',Path(__file__),ROOT/'docs/basic-tiling-algorithm.md',
         ROOT/'research/gcts-rl-renewal/hilbert_receptors_catalog.py',ROOT/'research/gcts-rl-renewal/hilbert_promotion_family_catalog.py',
         ROOT/'research/gcts-rl-renewal/catalog_receptor_points.py',ROOT/'research/gcts-rl-renewal/catalog_receptor_search.py',
         ROOT/'research/gcts-rl-renewal/audit_serialized_kernel.py',ROOT/'research/gcts-rl-renewal/serialized_kernel.py',
         ROOT/'research/gcts-rl-renewal/logic.py',ROOT/'research/gcts-rl-renewal/audit_proof_boundary.py']],
      native_program_sha256='877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673',
      native_micro_sha256='2f9e430b0b7034ed615d81c3e9b3978dc47ba4136686227a9b86df5779b203ac',
      quantified_closure_status=dict(status='unknown_space_budget',commands=41,micro_steps=10042321373,
        production_seconds=73.363009042,replay_seconds=74.156863875,heap_capacity=73178,
        scope='Preserved prior measured unknown, not rejected, invalid, universal interface authority or solved by this proposal.'))
    if len(records)!=18:raise ValueError('complete predeclared proposal schedule')
    target.write_text(json.dumps(proposal,indent=2)+'\n')
    print(json.dumps(dict(status=proposal['status'],proposal=file_pin(target),runs=18,new_queries=0)))

if __name__=='__main__':main()
