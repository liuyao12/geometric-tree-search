"""Private syntax/count preview; not a transport checker or trial producer.

This uses the existing ground catalog author solely to enumerate declarations.
It never instantiates a point model, invokes a native program, replays a logical
proof, labels an interface admitted, or constructs a target proof sequence.
The proposed transport metatheorem and authority adapter remain unimplemented.
"""
import collections, copy, gzip, hashlib, itertools, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SRC = ROOT / 'research/gcts-rl-renewal'
DOC = ROOT / 'docs/research/gcts-rl-renewal'
sys.path.insert(0, str(SRC))
from hilbert_receptors_catalog import F, P, axiom, condition, syntax_and_definitions
from hilbert_promotion_family_catalog import rename
from certificate_boundary_search import canonical, digest

def load(p):
    raw = p.read_bytes()
    return json.loads(gzip.decompress(raw) if p.suffix == '.gz' else raw)

def pin_file(p):
    return dict(path=str(p.relative_to(ROOT)), sha256=hashlib.sha256(p.read_bytes()).hexdigest(), bytes=p.stat().st_size)

def save(p, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode()
    p.write_bytes(gzip.compress(raw, mtime=0) if p.suffix == '.gz' else raw)

def recipient(length, common_points):
    p, q, r, l, m, n = map(F, ['P', 'Q', 'R', 'l', 'm', 'n'])
    return dict(id='three-line-chain-' + str(length), length=length,
        theory=dict(functions={s:0 for s in ['P','Q','R','l','m','n']},
            predicates=dict(Point=1, Line=1, Incident=2), schemas=[],
            axioms={'I.2-uniqueness':axiom(), 'first-common-pair':condition(p,q,l,m),
                    'second-common-pair':condition(p,q,m,n), 'initial-incidence':P('Incident',r,l)}),
        target=P('Incident',r,n), sorts=dict(point=['P','Q','R'], line=['l','m','n']),
        uniqueness_points=list(common_points))

def inventory_preview(request, common_points):
    spec = recipient(7, common_points)
    built = syntax_and_definitions(spec)
    base = built['definitions']
    byname = {d['name']:d['definition'] for d in base}
    source_dependencies, template = request['blocks'][:-1], request['blocks'][-1]
    order = ['A','B','C','u','v']
    domains = {'A':list(common_points), 'B':list(common_points), 'C':['P','Q','R'],
               'u':['l','m','n'], 'v':['l','m','n']}
    records, promoted, seen = [], [], {}
    for values in itertools.product(*(domains[k] for k in order)):
        binding = dict(zip(order, values)); mapped = {}; dependencies = []
        for original in source_dependencies:
            body = rename({k:v for k,v in original.items() if k != 'name'}, binding)
            name = 'hilbert-' + digest(body)
            if byname.get(name) != dict(name=name, **body):
                raise ValueError('syntactic dependency correspondence')
            mapped[original['name']] = name; dependencies.append(name)
        body = rename({k:v for k,v in template.items() if k != 'name'}, binding)
        for command in body['proof']:
            if command['rule'] == 'block': command['name'] = mapped[command['name']]
        word = canonical(body)
        if word not in seen:
            name = 'hilbert-promoted-' + digest(body); seen[word] = name
            promoted.append(dict(name=name, level=2, family='searched-incidence-transport',
                arguments=list(values), dependencies=dependencies, definition=dict(name=name, **body)))
        records.append(dict(binding=binding, name=seen[word], dependencies=dependencies,
                            decorated_body_sha256=hashlib.sha256(word).hexdigest()))
    counts = dict(collections.Counter(d['family'] for d in base))
    return dict(status='unadmitted_syntax_preview', parameter_order=order, parameter_domains=domains,
        basis=built['catalog']['basis'], catalog=built['catalog'], cases=[recipient(n,common_points) for n in [4,5,7]],
        base_definitions=base, promoted_definitions=promoted, binding_records=records,
        counts=dict(**counts, base=len(base), promoted=len(promoted), total=len(base)+len(promoted),
                    bindings=len(records), basis=len(built['catalog']['basis'])),
        deduplication='Only exact canonical complete decorated body identity, including premise multiplicity, proof order and dependency names.',
        scope='Complete finite role-sorted grounding grammar; no point model, logical authority, theorem proof or guard status.')

def analytic_bounds(preview):
    """Count domains and a safe guard upper bound, without constructing tiles.

    Every basis formula might receive a tautology guard for this upper bound;
    no empirical or logical guard classification is performed here.
    """
    out = []
    basis = preview['basis']; fcount = len(basis)
    for length in [4,5,7]:
        target = preview['cases'][0]['target']
        for language, definitions in [('level1', preview['base_definitions']),
                                      ('promoted', preview['base_definitions']+preview['promoted_definitions'])]:
            icount=len(definitions); command=inputs=guards=0
            for j in range(length):
                fs = [target] if j+1 == length else basis
                command += len(fs)*(icount+6+j*j)
                # Two ordinary no-input fillers, then every complete definition/source role.
                inputs += 2 + sum((len(d['definition']['premises'])*j + 2-len(d['definition']['premises'])) for d in definitions)
                guards += sum(1 for f in fs for a in preview['cases'][0]['theory']['axioms'].values() if f==a)
                guards += sum(1 for f in fs if f[0]=='eq' and f[1]==f[2])
                guards += len(fs) # All possible, but not assumed admitted, tautology guards.
                guards += sum(1 for d in definitions if d['definition']['conclusion'] in fs)
                guards += j*j*sum(1 for a in basis if a[0]=='imp' and a[2] in fs)
            out.append(dict(length=length, language=language, command_placements=command,
                input_placements=inputs, guard_upper_bound=guards,
                placement_upper_bound=command+inputs+guards,
                required_roots=length*4, meaning='Analytic pre-admission bound; no model/graph or actual guard labels.'))
    return out

def main():
    if (HERE/'inventory-preview-v1.json.gz').exists(): raise ValueError('immutable preview already exists')
    checked=[]
    for rel in ['.gcts-active/hilbert-promotion-family-20261011/final-integration-v3.json',
                '.gcts-active/hilbert-expanded-control-20261011/final-integration.json',
                '.gcts-active/hilbert-boundary-transfer-20261011/final-integration.json']:
        p=ROOT/rel; manifest=load(p)
        for r in manifest['files']:
            actual=pin_file(ROOT/r['path'])
            if actual['sha256']!=r['sha256'] or actual['bytes']!=r['bytes']:raise ValueError('prior export changed '+r['path'])
        checked.append(dict(**pin_file(p), file_count=manifest['file_count']))
    sourcep=DOC/'hilbert_promotion_family_v3_source_native.json.gz'
    source=load(sourcep)[0]; receipt=load(DOC/'hilbert_promotion_family_v3_source_audit.json')
    if source['result']['status']!='accepted' or receipt['status']!='passed' or receipt['request_sha256']!=source['request_sha256']:
        raise ValueError('exact prior acceptance/replay receipt')
    # Read-only syntax extraction, not new semantic or native verification.
    source_schemas=dict(status='exact_prior_source_snapshot_not_new_transport_authority',
        source_record_pin=pin_file(sourcep), source_request_sha256=source['request_sha256'],
        original_ground_source_request_sha256=receipt['source_request_sha256'],
        source_theory=source['request']['theory'], blocks=copy.deepcopy(source['request']['blocks']),
        native_production_seconds=source['seconds'], native_micro_steps=source['result']['micro_steps'],
        source_audit=receipt, source_audit_pin=pin_file(DOC/'hilbert_promotion_family_v3_source_audit.json'))
    save(HERE/'source-schemas-v1.json',source_schemas)
    primary=inventory_preview(source['request'],['P','Q'])
    full_sort=inventory_preview(source['request'],['P','Q','R'])
    primary['analytic_model_bounds']=analytic_bounds(primary)
    full_sort['analytic_model_bounds']=analytic_bounds(full_sort)
    if primary['counts']!=dict(**{'universal-uniqueness':36,'incidence-equality-transport':27},base=63,promoted=108,total=171,bindings=108,basis=55):
        raise ValueError('primary full finite grammar counts')
    if full_sort['counts']!=dict(**{'universal-uniqueness':81,'incidence-equality-transport':27},base=108,promoted=243,total=351,bindings=243,basis=100):
        raise ValueError('full-sort alternative counts')
    coincident=dict(same_common_points=sum(r['binding']['A']==r['binding']['B'] for r in primary['binding_records']),
        same_lines=sum(r['binding']['u']==r['binding']['v'] for r in primary['binding_records']),
        transport_point_equals_A=sum(r['binding']['C']==r['binding']['A'] for r in primary['binding_records']))
    old=load(DOC/'hilbert_promotion_family_v3_catalog.json.gz')
    oldwords={canonical(d['definition']) for d in old['definitions']}
    newwords={canonical(d['definition']) for d in primary['base_definitions']+primary['promoted_definitions']}
    if not oldwords<=newwords:raise ValueError('all old decorated interfaces retained')
    save(HERE/'inventory-preview-v1.json.gz',dict(primary=primary,full_sort_alternative=full_sort))
    native=load(DOC/'hilbert_promotion_family_v3_native.json.gz'); defs={d['name']:d for d in old['definitions']}
    cost=collections.defaultdict(list)
    for q in native:
        if q['purpose']=='family_base_admission':cost[defs[q['definition_name']]['family']].append(q)
        elif q['purpose']=='family_promoted_admission':cost['searched-incidence-transport'].append(q)
        elif q['purpose']=='recipient_tautology_guard':cost['guards'].append(q)
    historical={k:dict(queries=len(qs),production_seconds=sum(q['seconds'] for q in qs),
        mean_seconds=sum(q['seconds'] for q in qs)/len(qs),
        micro_steps=sum(q['result']['micro_steps'] for q in qs)) for k,qs in cost.items()}
    projection=sum(primary['counts'][k if k!='searched-incidence-transport' else 'promoted']*historical[k]['mean_seconds']
        for k in ['universal-uniqueness','incidence-equality-transport','searched-incidence-transport'])
    result=dict(status='syntax_count_preview_passed_only', native_queries=0, target_searches=0,
        point_models_constructed=0, structural_transport_certificates_checked=0,
        primary_counts=primary['counts'], alternative_counts=full_sort['counts'],
        coincident_bindings_retained=coincident, unchanged_decorated_prior_interfaces=len(oldwords),
        new_decorated_interfaces=len(newwords-oldwords),
        full_route_preparation=dict(library_theory=1,level1=63,promoted=108,recipient_theory=1,guards=55,total=228),
        transport_route_native_minimum=dict(library_theory=1,recipient_theory=1,guards=55,total=57,
            status='Proposed conditional route; no transport checker, preservation bridge or authority adapter implemented.'),
        full_sort_preparation=dict(library_theory=1,level1=108,promoted=243,recipient_theory=1,guards=100,total=453),
        historical_rates=historical, projection_library_definition_seconds=projection,
        rate_scope='Planning estimate from five-constant requests. Six-constant/signature/heap costs are not measured or assumed identical.',
        verified_prior_exports=checked, preview_inputs=[pin_file(p) for p in [sourcep,DOC/'hilbert_promotion_family_v3_source_audit.json',DOC/'hilbert_promotion_family_v3_catalog.json.gz',DOC/'hilbert_promotion_family_v3_native.json.gz']],
        proposed_producers_and_transport_checker='Not implemented. Counts are not an admission, theorem, graph completeness or preservation proof result.')
    save(HERE/'preview-checks-v1.json',result)
    print(json.dumps({k:result[k] for k in ['status','native_queries','target_searches','primary_counts','coincident_bindings_retained','projection_library_definition_seconds']}))

if __name__=='__main__': main()
