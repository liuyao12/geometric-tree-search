"""SOURCE/data review only; no imports or invocation of reviewed sources."""
import hashlib,itertools,json,pathlib
R=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');A=R/'.gcts-active/equality-receptor-family-broadening-design-source-20261014';O=R/'.gcts-active/equality-receptor-family-broadening-independent-20261014'
raws={};checks=[];refs=[]
def pin(p,b):return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def read(p,expected=None):
 p=pathlib.Path(p);p=p if p.is_absolute() else R/p;b=p.read_bytes()
 if expected is not None:assert len(b)==expected['bytes'] and hashlib.sha256(b).hexdigest()==expected['sha256'];refs.append(expected)
 if str(p) in raws:assert raws[str(p)]==b
 raws[str(p)]=b;return b

def walk(v):
 if isinstance(v,dict):
  if {'path','sha256','bytes'}<=set(v):read(v['path'],v);return
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)

def ck(n,v):assert v,n;checks.append(dict(check=n,passed=True))
def sha(v):return hashlib.sha256(canonical(v).encode()).hexdigest()
h=json.loads(read(A/'handoff-v3.json'));s=json.loads(read(h['source_specification']['path'],h['source_specification']));cohort=json.loads(read(h['candidate_cohort']['path'],h['candidate_cohort']));memo=read(h['memo']['path'],h['memo']).decode()
# Exact specification declared references, separately from all review references.
def pinlist(v):
 if isinstance(v,dict):
  if {'path','sha256','bytes'}<=set(v):return [v]
  return [p for x in v.values() for p in pinlist(x)]
 if isinstance(v,list):return [p for x in v for p in pinlist(x)]
 return []
sp=pinlist(s)
walk(h);walk(s);walk(cohort)
ck('current handoff exact41 references38 raw targets in specification',len(sp)==h['raw_reference_count']==41 and len({x['path'] for x in sp})==h['raw_reference_identities']==38)
ck('distinct Source author/reviewer and truthful unactivated scope',h['author_identity']==s['author_identity']=='/root/hilbert_advice_controls' and h['source_only'] is True and s['scientific_calls']==s['project_imports']==s['project_functions']==0 and s['new_inference_rules']==[] and s['actual_library_admission'] is False and s['parameterized_schema_accepted'] is False and s['RL_activated'] is False)
ck('whole recognizer language exactly two declared finite patterns',len(s['recognizers'])==2 and {x['id'] for x in s['recognizers']}=={'binary-one-hole-equality-transport','licensed-universal-instantiation-pair'} and s['recognizers'][0]['members']==3 and s['recognizers'][1]['members']==2)
ck('generic eligibility not target formula route constructor', 'eligibility never calls a target route constructor' in s['recognizers'][1]['source_language'] and 'No target formula, code, case, row or successful route participates' in memo)
ck('original occurrence and separate consumption declaration','consumed ancestry subset' in memo and 'repeated equal formulas and unused hypotheses' in memo and 'exact original ambient occurrence list and separate ancestry consumption' in s['runtime_api']['acceptance_checks'])
ck('ordered receptor multiplicity shared full key and current union declared', 'ordered_input_receptors_with_multiplicity' in s['candidate_wire']['required_family_fields'] and 'one shared full Key counted once in t aggregate' in s['runtime_api']['acceptance_checks'] and 'entire fixed exterior/target+actual selected+planned t/m union' in s['runtime_api']['acceptance_checks'])
ck('fresh licence and independent ground validation not universal schema admission', 'all concrete witnesses/premises resolved in full current independent licences' in s['runtime_api']['acceptance_checks'] and 'independent original-Gamma ground-sequent check' in s['runtime_api']['acceptance_checks'] and s['candidate_wire']['candidate_flags']=={'ROOT_inventory_admitted':False,'schema_universally_validated':False,'primitive_source_body_count':0})
ck('master scheduler fullfallback no macro pruning or addedmark',s['engine_invariants']['height']==24 and s['engine_invariants']['scheduler']=='global dead -> global forced -> earliest generation; count tie only' and s['engine_invariants']['complete_primitive_fallback'] is True and s['engine_invariants']['forced_advice']==[] and s['engine_invariants']['macro_commits'] is False and s['engine_invariants']['learned_pruning'] is False and s['engine_invariants']['new_marking_assignments'] is False)
ck('whole exact rollback and final guard/deadline retained','refcounts/generations/domains/reverse links/exclusions/selected identities/branch metadata' in s['engine_invariants']['rollback'] and 'final no-state/source/deadline change after return preparation' in s['runtime_api']['acceptance_checks'])
ck('historical I2 training is future explicit role change not admitted heldout proof','neither known I.2 target remains held out' in s['donor_policy']['proposed_new_donor'] and 'Not admitted or consumed' in s['donor_policy']['proposed_new_donor'] and 'same19 proof counts one correlated' in s['donor_policy']['correlated_duplicates'])
ck('firstchecked selected vsproposed separate fullboard native trajectory','never label it selected/full24/native/trajectory' in s['comparison']['primary'] and s['comparison']['search_limits']=={'placement_attempts':128,'inner_seconds':20,'events':2000})
ck('ordinary is witness advice not external prover','current ordinary advice is not an external prover' in s['comparison']['optional_ablations'][-1])
ck('all six candidate records are statements only and unactivated',len(cohort['cases'])==6 and all(x['status']=='source_candidate_unactivated' and x['proof_sequence_supplied'] is False and x['recipe_indices_supplied'] is False and x['actual_checked_proof'] is False and len(x['Gamma'])==3 for x in cohort['cases']))
# Syntax-only closed/free/binder/signature census; no logical validity/derivation evaluated.
def tokens(ast,bound=frozenset(),out=None):
 if out is None:out=dict(constants=set(),binders=set(),free=set(),predicates=set(),constructors=set())
 tag=ast[0];out['constructors'].add(tag)
 if tag=='var':
  if ast[1] not in bound:out['free'].add(ast[1])
 elif tag=='fun':
  if not ast[2]:out['constants'].add(ast[1])
  for x in ast[2]:tokens(x,bound,out)
 elif tag=='pred':
  out['predicates'].add(ast[1])
  for x in ast[2]:tokens(x,bound,out)
 elif tag=='all':out['binders'].add(ast[1]);tokens(ast[2],bound|{ast[1]},out)
 else:
  for x in ast[1:]:tokens(x,bound,out)
 return out
case_syntax=[]
for x in cohort['cases']:
 t=dict(constants=set(),binders=set(),free=set(),predicates=set(),constructors=set())
 for ast in x['Gamma']+[x['target']]:tokens(ast,out=t)
 ck(x['id']+'/closed exact Source ASTs',not t['free'] and t['constructors']<={'var','fun','pred','all','and','not','eq','imp'})
 case_syntax.append(dict(id=x['id'],**{k:sorted(v) for k,v in t.items()}))
# Structurally normalize constants/binders/Gamma permutation, only a data comparison.
def structural(gamma,target):
 alternatives=[]
 for perm in itertools.permutations(gamma):
  constants={};counter=[0]
  def norm(ast,bound):
   tag=ast[0]
   if tag=='fun' and not ast[2]:
    if ast[1] not in constants:constants[ast[1]]='c'+str(len(constants))
    return ['fun',constants[ast[1]],[]]
   if tag=='var':return ['var',bound.get(ast[1],'free:'+ast[1])]
   if tag in ('fun','pred'):return [tag,ast[1],[norm(a,bound) for a in ast[2]]]
   if tag=='all':
    name='b'+str(counter[0]);counter[0]+=1;inner=dict(bound);inner[ast[1]]=name;return [tag,name,norm(ast[2],inner)]
   return [tag]+[norm(a,bound) for a in ast[1:]]
  alternatives.append(canonical(dict(Gamma=[norm(a,{}) for a in perm],target=norm(target,{}))))
 return min(alternatives)
ownpath=R/'.gcts-active/equality-receptor-heldout-benchmark-design-source-20261014/benchmark-specification-v1.json';own=json.loads(read(ownpath));own_pin=pin(ownpath,raws[str(ownpath)]);owncases=own['benchmark_primary_cases']+[own['off_family_control'],own['known_replication_calibration'],own['deferred_quantified_conclusion']]+own['nonentailment_controls']+[own['occurrence_control']]
fixturepin=own['evidence_inputs']['current_fixture'];fixture=json.loads(read(fixturepin['path'],fixturepin))
oldcases=[dict(id=x['id'],Gamma=[fixture['literal_formulas'][k] for k in x['hypotheses']],target=fixture['literal_formulas'][x['target']]) for x in fixture['cases'] if x['theory']=='hilbert-incidence']
overlap=[]
for x in cohort['cases']:
 sig=structural(x['Gamma'],x['target']);overlap.append(dict(broadening_case=x['id'],own_design_syntactic_matches=[y['id'] for y in owncases if structural(y['ordered_Gamma'],y['target'])==sig],current_fixture_syntactic_matches=[y['id'] for y in oldcases if structural(y['Gamma'],y['target'])==sig],exact_statement_SHA=sha(dict(Gamma=x['Gamma'],target=x['target'])),method='constant/binder renaming plus Gamma permutation; purely syntactic, not semantic or proof equivalence'))
ck('equality3 overlap with benchmark memo disclosed',overlap[0]['own_design_syntactic_matches']==['heldout-eq-three-links'])
ck('universal implication overlap with benchmark memo disclosed',overlap[2]['own_design_syntactic_matches']==['heldout-inc-quantified-implication'])
ck('renamed donor calibration has old fixture orbit overlap','fresh-inc-point-chain-w' in overlap[3]['current_fixture_syntactic_matches'])
ck('all prospective structurally heldout whole sequents have no current fixture syntax match',all(not o['current_fixture_syntactic_matches'] for o,x in zip(overlap,cohort['cases']) if x['kind']=='prospective_structurally_held_out'))
# Guard association exact structural definition, not a proof or necessity evaluation.
x=cohort['cases'][1]
def atoms(v):return atoms(v[1])+atoms(v[2]) if v[0]=='and' else [v]
for j,g in enumerate(x['Gamma'][:2]):
 aa=atoms(g);ck('two guard'+str(j)+'/right associated9 atom signature',len(aa)==9 and [a[0] for a in aa]==['pred','pred','pred','pred','not','pred','pred','pred','pred'] and [a[1] for a in aa if a[0]=='pred']==['Point','Point','Line','Line','Incident','Incident','Incident','Incident'])
# Conceptual design: concrete executable admission remains absent by declaration.
limitations=[
 dict(id='cohort_overlap_not_independent_new_cases',priority='design_interpretation',source='candidate-cohort-v2 cases0,2',finding='Equality3-link and universal-implication+transport are constant/binder renamings (with Gamma permutation for the latter) of the independent benchmark memo. Agreement across design streams is not two additional independent target samples.',action='Choose/deduplicate one frozen prospective cohort; preserve exact original index order. Do not count these twice or train one stream on the other before a declared evaluation.'),
 dict(id='two_guard_pattern_has_prior_design_exposure',priority='design_interpretation',source='candidate-cohort-v2 case1; retained next-inc-two-uniqueness fixture',finding='The full equality-conclusion sequent is not a renamed fixture match, but its two consecutive H guards already occur in retained next-inc-two-uniqueness. Its proposed extension is equality conclusion/extra equality rather than the old Incident conclusion. No dependency-DAG orbit or actual two essential I.2 applications has been checked.',action='Claim heldout only relative to the explicitly declared donor/library ancestry. Check all retained donor-root orbits after the new training declaration; record actual consumed I.2 ancestry rather than requiring or inferring an authored route.'),
 dict(id='finite_profile_and_theory_not_frozen',priority='preregistration_prerequisite',source='candidate-cohort qualification/static_gap; comparison.fairness',finding='New lowercase nullary symbols and binder x are outside the current literal I.2 signature/role profile. Cases1/3 say no domain axioms while guarded case uses I.2. The design intentionally leaves exact theory, common finite vocabulary, binder-role pools, simultaneous rounds/equality product and cross-case seed policy for ROOT. It cannot reuse current two q records or counts.',action='Freeze exact per-case theories or one common I.2 theory, full shared fixture/signature/finite grammar and all active IDs before construction; no target/family-informed trim. Qualify the whole recipe catalogue and all24 domains independently. Preserve bounded, not FOL, completeness.'),
 dict(id='ordinary_baseline_requires_current_source_coverage',priority='implementation_prerequisite',source='comparison.lanes/fairness; raw_sources',finding='Ordinary is correctly called conventional witness advice, not a lemma cache/external prover. Its actual helper is not a separately named raw_sources role in this design map; future runtime must authenticate it and verify new equality/quantified-hypothesis/zero-Incident-seed cases retain all conventional eligible roots and full fallback. A Source description is not baseline coverage evidence.',action='Bind exact ordinary helper/source version, actual indexed recipe view and consumer epoch; add genuinely matched ordinary controls for the fresh common profile. No stronger ordinary algorithm only after seeing family outcomes.'),
 dict(id='resource_ABI_needs_exact_current_fields',priority='integration_prerequisite',source='comparison.enclosing_limits',finding='Design lists child170/supervisor175/caller180 and512MiB but omits explicit whole_seconds180 and the prospective32MiB postlude/2s owner-write/1s caller-finish reserve fields present in the actual scientific owner ABI. This is an incomplete future metadata declaration, not a resource waiver or an actual failure.',action='Retain all exact limits/reserves and genuine observed caller/postwrite scopes in future contracts/plans; do not derive whole-resource acceptance from the inner20s or count completed clocks as total.'),
 dict(id='recognizers_are_fixed_primitive_packs_not_new_lemmas',priority='attribution_limit',source='recognizers/candidate_wire',finding='Equality transport (EqSubst/MP/MP) and UI/MP pack existing rules. A meta-universal formula can make the UI family behave as a generic licensed inference pair. Fixed recognizable bodies are a declared extractor language, not autonomous discovery of unrestricted proof patterns, universal lemma admission or a new logical rule.',action='Retain donor-origin eligibility/correlation and actual fresh recipient-ground proofs for every use. No body synthesized solely from target syntax or missing donor eligibility; parameter generality remains conditional on exact current catalogue/licences/kernel/point checks.'),
 dict(id='binding_and_composition_details_still_unimplemented',priority='implementation_prerequisite',source='runtime_api; recognizers binder_policy',finding='Capture-avoiding bound/free/signature checks, alpha-normalization, meta nodes outside FOL, aliases/repeated ports, variable member counts and exact shared Keys are plausible but only specified. Current receiver root member:2 and fixed equality/Incident receptor signature cannot consume UI2-member bodies unchanged; current replace_terms is a raw nullary rewrite, not a binder-normalizer.',action='Add narrow independently reviewed typed grounding/normalization and output-member maps, with exact finite parameter domains and endpoint/code/object guards. Charge every scan/construction/final return inside20s; failed/capped/incomplete advice gives no usable prefix and never changes complete candidate domains.'),
 dict(id='training_role_and_cost_scope_remain_future',priority='activation_prerequisite',source='donor_policy; comparison.cold_vs_reused',finding='Historical I.2 winner and its replica are diagnostics only; reclassifying one as training retires both direct and companion known contexts from heldout status because their target statements/ancestry are exposed. The known certificates are correlated and remain one group. New extraction/intake/audit/library/runtime/scientific authority is absent.',action='ROOT freezes exact donor/profile readers and complete root census, independently checks whole donor/proposal/current-union linkage, and issues a new advice-only purpose admission. Preserve old library/control/negative pilot bytes. Include donor acquisition/static/extraction/receiver checking in cold costs; preregister reuse amortization.')] 
ck('no new generalization induction reflexivity or compound rule claimed',s['new_inference_rules']==[] and 'No generalization or induction action' in cohort['cases'][2]['static_gap'])
for p,b in raws.items():assert pathlib.Path(p).read_bytes()==b
ck('all directly named raw targets stable at final rehash',True)
f=dict(schema='independent-broad-receptor-family-conceptual-Source-review-v1',reviewer_identity='/root/hilbert_ordering_diagnosis',author_identity='/root/hilbert_advice_controls',scope='conceptual Source specification/raw data review only; not executable/runtime/library/mathematical admission',source_only=True,project_imports=0,project_functions=0,tests_executed=0,semantic_evaluations=0,kernel_calls=0,search_calls=0,scientific_calls=0,browser_calls=0,publication_calls=0,conceptual_design_plausible=True,material_current_AST_or_new_logical_rule_bug_found=False,target_specific_executable_proof_constructor_found=False,current_implementation_or_activation_ready=False,universally_validated_schema=False,all_raw_pins_match=True,pin_mismatch_count=0,reviewed_current_inputs=dict(handoff=pin(A/'handoff-v3.json',raws[str(A/'handoff-v3.json')]),source_specification=h['source_specification'],candidate_cohort=h['candidate_cohort'],memo=h['memo'],independent_benchmark_specification=own_pin,current_fixture=fixturepin),declared_specification_raw_reference_count=len(sp),declared_specification_raw_identities=len({x['path'] for x in sp}),review_raw_reference_count=len(refs),review_raw_target_count=len(raws),final_rehash_count=len(raws),checks=checks,check_count=len(checks),whole_relevant_reference_Source_read=['current family transport_body/extract_training intake/term/ground/FamilySession instantiate and GoalDependencyAdvice limitations','GroundChecker exact five-rule/closed substitution/atomic template/strict-prior proof scope','master point/domain/scheduler/fallback/rollback and cost/acceptance contract','whole current Source specification, memo and cohort'],syntax_census=case_syntax,cohort_comparison=overlap,conceptual_findings=limitations,raw_targets=[pin(pathlib.Path(p),b) for p,b in sorted(raws.items())],public_summary=dict(scope='Source/design only',raw_pin_mismatches=0,conceptual_design_plausible=True,new_inference_rules=False,implemented=False,admitted=False,scientific_calls=0,statement_overlap_with_other_designs=2,rename_only_calibration_excluded=True,actual_heldout_orbit_and_row_feasibility_unchecked=True,ordinary_control_and_shared_finite_profile_require_new_qualification=True,assessment='Plausible generic primitive-family broadening, with fresh recipient checking and complete fallback retained in the design. Two candidate targets overlap the independent benchmark proposal. No new family/schema/proof admission, runtime conformance, heldout advantage or RL acceptance is established.'))
p=O/'findings-v1.json';assert not p.exists();b=(json.dumps(f,indent=2,ensure_ascii=False)+'\n').encode();p.write_bytes(b);fp=pin(p,b)
hp=O/'handoff-v1.json';assert not hp.exists();hb=(json.dumps(dict(schema='independent-broadening-design-review-handoff-v1',findings=fp,source_only=True,conceptual_design_plausible=True,executable_or_scientific_admission=False,scientific_calls=0,raw_pin_mismatches=0),indent=2)+'\n').encode();hp.write_bytes(hb)
print(json.dumps(dict(findings=fp,handoff=pin(hp,hb),checks=len(checks),raw_references=len(refs),raw_targets=len(raws),overlap=overlap),indent=2))
