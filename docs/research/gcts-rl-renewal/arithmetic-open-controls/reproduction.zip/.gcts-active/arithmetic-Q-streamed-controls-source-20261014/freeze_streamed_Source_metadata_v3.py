"""Metadata-only freeze: raw hashes, ASTs, JSON and textual comparisons.

No project import, Source function call, preparation, control or fixture run.
"""
import ast
import builtins
import difflib
import hashlib
import json
from pathlib import Path
import resource
import symtable
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OLD=ROOT/'.gcts-active/arithmetic-Q-cold-controls-source-20261014'
PROTOTYPE=ROOT/'.gcts-active/arithmetic-open-generalize-implementation-source-20261014'
AUTHOR='/root/arithmetic_induction'

def pin(path):
    path=Path(path).resolve();h=hashlib.sha256();count=0
    with path.open('rb') as stream:
        for raw in iter(lambda:stream.read(65536),b''):h.update(raw);count+=len(raw)
    return dict(path=str(path),sha256=h.hexdigest(),bytes=count)

def write(name,value):
    path=HERE/name
    with path.open('x') as stream:
        if isinstance(value,str):stream.write(value)
        else:json.dump(value,stream,sort_keys=True,indent=2,ensure_ascii=False);stream.write('\n')
    return pin(path)

def assignments(source):
    tree=ast.parse(source)
    return {n.targets[0].id:ast.literal_eval(n.value) for n in tree.body
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)
        and n.targets[0].id in ('FROZEN_SOURCES','FROZEN_INPUTS','PROTOTYPE_SOURCE_PINS','SCHEMA','SCOPE','COMMAND','AUTHOR')}

def definitions(source):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body
        if isinstance(n,(ast.FunctionDef,ast.ClassDef))}

def raw_refs(value):
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:yield value
        for child in value.values():yield from raw_refs(child)
    elif type(value) is list:
        for child in value:yield from raw_refs(child)

def main():
    began=time.perf_counter();checks=[];references=[]
    metadata_only_failure=pin(HERE/'preserved-metadata-freezer-failure-v1.json')
    metadata_only_failure_v2=write('preserved-metadata-freezer-failure-v2.json',dict(schema='Source-metadata-authoring-failure-v2',
        scientific_calls=0,project_imports=0,project_function_calls=0,source=pin(HERE/'freeze_streamed_Source_metadata_v2.py'),
        error='Source comparison included necessary prepared.catalogue -> model caller ABI rewrite without its explicit inverse; no project call or final freeze occurred.'))
    def check(ok,label):
        checks.append(dict(name=label,passed=bool(ok)))
        if not ok:raise ValueError(label)
    worker_path=HERE/'arithmetic_Q_streamed_controls_worker_v6.py'
    controls_path=HERE/'arithmetic_Q_streamed_controls_v3.py'
    payload_path=HERE/'q_preparation_owned_graph_v3.py'
    worker=worker_path.read_text();controls=controls_path.read_text();payload=payload_path.read_text()
    constants=assignments(worker);sources=dict(constants['FROZEN_SOURCES'],worker=pin(worker_path));inputs=constants['FROZEN_INPUTS']
    old_contract=json.loads((OLD/'source-contract-v1.json').read_text())
    check(len(sources)==7 and len(inputs)==4,'seven current sources/four inputs, unchanged role ABI')
    check(sources['controls']==pin(controls_path) and sources['payload']==pin(payload_path),'latest selected callable pins')
    check(all(sources[r]==old_contract['sources'][r] for r in ('kernel','catalogue','point_graph','master')),
          'whole grammar/kernel/graph/master raw bytes unchanged')
    for name in ('kernel','catalogue','point_graph'):
        check(pin(sources[name]['path'])==sources[name],'unchanged '+name+' raw pin')
    for record in [*sources.values(),*inputs.values()]:
        check(pin(record['path'])==record,'direct pin '+record['path']);references.append(record)
    for role,record in inputs.items():
        doc=json.loads(Path(record['path']).read_text())
        for ref in raw_refs(doc):
            target=Path(ref['path']);target=target if target.is_absolute() else ROOT/target
            actual=pin(target);check(actual['sha256']==ref['sha256'] and actual['bytes']==ref['bytes'],
                'named input nested raw reference '+str(target));references.append(dict(ref,path=str(target.resolve())))
    for path in (worker_path,controls_path,payload_path,*[Path(sources[r]['path']) for r in ('kernel','catalogue','point_graph')]):
        source=path.read_text();ast.parse(source);symbols=symtable.symtable(source,str(path),'exec')
        defined={s.get_name() for s in symbols.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
        unknown=set()
        def visit(table):
            for s in table.get_symbols():
                if s.is_referenced() and s.is_global() and s.get_name() not in defined and s.get_name() not in vars(builtins) \
                    and s.get_name() not in ('__name__','__file__'):unknown.add(s.get_name())
            for child in table.get_children():visit(child)
        visit(symbols);check(not unknown,'AST/symbol bindings only '+path.name+' '+repr(sorted(unknown)))
    old_worker=(OLD/'arithmetic_Q_controls_worker_v3.py').read_text()
    old_controls=(OLD/'arithmetic_Q_controls_v1.py').read_text()
    old_payload=(PROTOTYPE/'q_preparation_gate_v1.py').read_text()
    ow,nw=definitions(old_worker),definitions(worker)
    common=[k for k in ow if k not in ('preflight','main')]
    check(all(ow[k]==nw[k] for k in common),'all '+str(len(common))+' original cold utility definitions AST exact')
    oc,nc=definitions(old_controls),definitions(controls)
    check(all(oc[k]==nc[k] for k in ('require','text','function_state','methods','literal_decision')),
          'original controls validators/effective methods/scheduler AST exact')
    old_domain=ast.get_source_segment(old_controls,next(n for n in ast.parse(old_controls).body if isinstance(n,ast.FunctionDef) and n.name=='literal_domains'))
    new_domain=ast.get_source_segment(controls,next(n for n in ast.parse(controls).body if isinstance(n,ast.FunctionDef) and n.name=='literal_domain_rows'))
    normalized=old_domain.replace('def literal_domains(', 'def literal_domain_rows(',1).replace('    result=[]\n','',1)
    normalized=normalized.replace('        result.append(dict(factors=factors,base_count=base,excluded_legal=removed,count=base-len(removed)))',
        '        yield dict(factors=factors,base_count=base,excluded_legal=removed,count=base-len(removed))',1).replace('    tick();return result','    tick()',1)
    check(normalized==new_domain,'independent complete domain loop byte-exact except list accumulation to yield')
    def between(s,left,right):return s[s.index(left):s.index(right,s.index(left))]
    check(between(old_controls,"    theory=declaration['theory']",'    model=prepared').replace("prepared['catalogue']['declaration']","model['declaration']",1)==
          between(controls,"    theory=declaration['theory']",'    graph=track(owned_graph)'),
          'all original capture/substitution/full-Gamma/kernel controls byte exact')
    check(between(old_controls,'    unary=next(', '    root=graph.checkpoint()')==
          between(controls,'    unary=next(', '    root=graph.checkpoint()'),
          'all actual unary footprint and strict source negatives byte exact')
    old_tiny=old_controls[old_controls.index('    # Tiny synthetic scheduling fixtures.'):]
    new_tiny=controls[controls.index('    # Tiny synthetic scheduling fixtures.'):]
    added="""        check(''.join(state_chunks(tiny))==text(tiny.semantic_state()),
              label+' complete streaming state protocol equals unchanged full scalar snapshot')
"""
    check(new_tiny.replace(added,'',1)==old_tiny,'all original nonlogical fixtures/results retained, only full stream correspondence control added')
    normalized_payload=payload.replace('def prepare_owned(', 'def prepare_only(',1).replace('return result, graph','return result',1)
    deferred="""    # Complete strict serialization is deferred to the caller's immediate
    # owned streamed preparation write. No accepted output precedes that full
    # traversal, its raw pin, and the shared deadline/Source guards.
    guard()"""
    normalized_payload=normalized_payload.replace(deferred,'    text(result);guard()',1)
    check(normalized_payload==old_payload,'whole payload inverse equals original: graph return + caller stream validation only')
    graph_source=Path(sources['point_graph']['path']).read_text()
    graph_tree=ast.parse(graph_source)
    point_class=next(n for n in graph_tree.body if isinstance(n,ast.ClassDef) and n.name=='PointGraph')
    semantic=next(n for n in point_class.body if isinstance(n,ast.FunctionDef) and n.name=='semantic_state')
    returned=next(n for n in ast.walk(semantic) if isinstance(n,ast.Return)).value
    state_keys={ast.literal_eval(k) for k in returned.keys}
    check(state_keys=={'totals','marks','order','selected_generations','roots','excluded','domains','model_epoch'},'all eight unchanged scalar state fields')
    domain_dict=next(n for n in ast.walk(returned) if isinstance(n,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='factors' for k in n.keys))
    check({ast.literal_eval(k) for k in domain_dict.keys}=={'factors','base_count','excluded_legal','count'},'all four complete factor-domain fields retained')
    check('stream.read(len(raw))==raw' in controls and "stream.read(1)==b''" in controls and "h.hexdigest()==record['sha256']" in controls,
          'whole canonical state/rollback byte comparison plus length/SHA, not digest-only')
    check("'marks':[[*p,v,graph.mark_refs[p]]" in controls and 'self.marks.get((x, y))' in graph_source,
          'all assigned markings/reference counts and unchanged zero-versus-absence graph trail')
    check('prepared=None' in worker and 'owned_graph=owned_graph' in worker and "text(result);guard()" not in payload,
          'one production graph reused; prepared initial-state copy released; no whole payload string')
    check('model=catalogue_module.prepare' in payload and 'text(result);tick(deadline);return result' in Path(sources['catalogue']['path']).read_text(),
          'original complete catalogue call and residual full model validation disclosed unchanged')
    check("name=='domains'" in controls and 'for row in range(graph.height)' in controls and 'enumerate(literal_domain_rows' in controls,
          'all rows production/oracle emitted, no shortlist or viewport')
    check("write_snapshot('Q-initial-oracle-domains-v2.json'" in controls and "write_snapshot('Q-after-one-step-oracle-domains-v2.json'" in controls,
          'both complete independent domain witnesses are caller-owned output files')
    check('complete_witness_output_closure=list(artifacts)' in worker and 'stream_output_records_before_receipt=list(serialization_records)' in worker,
          'full witness/output closure and nested serialization records extend through evidence')
    check('partial_stream_paths=partial_stream_paths' in worker and "'Q-controls-result-withdrawn-v1.json'" in worker,
          'partial output/failure retention and late receipt withdrawal')
    check('visits>512' in worker and 'characters>32768' in worker and 'child.bit_length()>4096' in worker
          and 'len(raw)<=4*1048576' in worker and 'streamed_bytes[0]<=256*1048576' in worker,
          'bounded C block traversal/write/aggregate file guard, no full nested domain array block')
    check('range(513)' in worker and 'list(range(97))' in worker and "'serializer_control_count':" not in worker,
          'six prospective generic serializer controls include nested domain fallback')
    check('LIMITS=dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)' in worker,
          'unchanged shared20/owned60/caller90/512MiB')
    patches=[]
    for old,new,name in ((PROTOTYPE/'q_preparation_gate_v1.py',payload_path,'payload-original-to-stream-v3.patch'),
        (OLD/'arithmetic_Q_controls_v1.py',controls_path,'controls-original-to-stream-v3.patch'),
        (OLD/'arithmetic_Q_controls_worker_v3.py',worker_path,'worker-original-to-stream-v6.patch')):
        patches.append(write(name,''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old),tofile=str(new)))))
    failure=pin(ROOT/'.gcts-active/arithmetic-Q-controls-progress-20261014/ROOT-actual-Q-controls-failure-disposition-v1.json')
    failed=json.loads(Path(failure['path']).read_text())
    saved_failure=pin(ROOT/'.gcts-active/arithmetic-Q-cold-controls-independent-20261014/actual-memory-failure-saved-findings-v1.json')
    for ref in raw_refs(failed):
        check(pin(ref['path'])==ref,'retained prior failure raw pin '+ref['path']);references.append(ref)
    check(failed['conditional_peak_bytes']==549044224 and failed['fixed_peak_limit_bytes']==536870912
          and failed['final_worker_receipt'] is None and failed['accepted_prefix'] is False,'prior failure remains UNKNOWN, no accepted prefix')
    diagnosis=write('Source-retention-diagnosis-v1.json',dict(schema='Q-Source-retention-diagnosis-v1',source_only=True,scientific_calls=0,
        author_identity=AUTHOR,prior_failure=failure,independent_saved_failure=saved_failure,
        observed_source_lifetimes=[
            'Old prepared retains full model and copied24-domain initial state while controls constructs a second production graph.',
            'Old initial/after snapshots retain complete production+oracle arrays and full canonical JSON strings simultaneously.',
            'Old payload text(result) and worker save construct a full preparation JSON string; save also constructs full UTF-8 buffer.',
            'New worker reuses the same complete graph, releases prepared initial copy after full owned files, emits complete oracle/state per row and compares rollback whole bytes.'
        ],measured_peak_attribution_established=False,
        previous_peak_bytes=failed['conditional_peak_bytes'],previous_owned_seconds=failed['owned_seconds'],previous_caller_seconds=failed['caller_seconds'],
        root_reported_provisional_only=dict(formula_codes=11147,recipes=16200,not_accepted=True,algorithm_uses_as_expected_counts=False),
        residual_retention=['Original catalogue full text(result) validation remains.',
            'Complete model, graph internal formula copy/recipe strings and factor domains remain.',
            'Initial full semantic_state is constructed once by unchanged payload checks, then released before controls.',
            'Per-row serialization/oracle/prod comparisons retain bounded-in-row structures; no actual successor peak or speed measured.'],
        guarantee_scope='Source lifetime change, not a proof of512MiB/20s feasibility; unchanged prospective owned gates decide actual completion.'))
    receipt=write('Source-authoring-checks-v1.json',dict(schema='Q-streamed-author-Source-checks-v1',author_identity=AUTHOR,source_only=True,
        scientific_calls=0,project_imports=0,project_function_calls=0,tests_executed=0,all_checks_passed=True,mismatches=[],
        metadata_only_failures=[metadata_only_failure,metadata_only_failure_v2],checks=checks,checks_count=len(checks),sources=sources,inputs=inputs,raw_references=references,patches=patches,
        metadata_seconds_before_receipt=time.perf_counter()-began,metadata_SELF_peak_before_receipt_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        authoring_cost_scope='Measured metadata helper only. Total interactive Source authoring wall is uninstrumented/UNKNOWN; not counted as0 and not a scientific runtime estimate.'))
    contract=dict(old_contract)
    contract.update(schema='Q-open-empty-Gamma-streamed-controls-source-contract-v1',sources=sources,inputs=inputs,conformance=receipt,
        Source_status='Frozen Source/AST/metadata only. No project functions, controls, preparation, graph, proof or actual successor plans run.',
        Source_retention_diagnosis=diagnosis,parent_source_contract=pin(OLD/'source-contract-v1.json'),
        selected_delta_patches=patches)
    contract['Source_review_ABI']=dict(old_contract['Source_review_ABI'],sources=sources)
    contract['entrypoint']=dict(old_contract['entrypoint'],worker=sources['worker'],
        argv=['exact canonical CLT runtime','-B',sources['worker']['path'],constants['COMMAND'],'ABS worker-plan path','ABS owner-plan path'],
        payload='prepare_owned(... source_guard=...,deadline=...) -> (complete_prepared_value, same_actual_graph); strict full serialization deferred to immediate caller owned stream write.',
        controls='run_controls(declaration=...,model=...,owned_graph=...,initial_record=...,initial_decision=...,kernel_module=...,graph_module=...,source_bindings=...,source_guard=...,write_snapshot=...,deadline=...)')
    contract['serialization_protocol']=dict(name='canonical-JSON-no-trailing-newline-v2',
        settings=dict(sort_keys=True,separators=[',',':'],ensure_ascii=False,allow_nan=False),
        array_values='list/tuple normalize exactly as original json.dumps; full insertion-independent sorted object keys, every field retained.',
        blocks='At most512 visits/32768 aggregate string chars/4096 bits per integer for a C block; otherwise recurse without deep copy. Every UTF-8 write block checked<=4MiB after encoding; unchanged64MiB per-file, new256MiB aggregate output guard.',
        exact_state_fields=sorted(state_keys),domain_fields=sorted(ast.literal_eval(k) for k in domain_dict.keys),
        prospective_checks='Six bounded generic JSON fixtures and three complete tiny state comparisons, unexecuted. Actual complete production initial bytes and whole root rollback compare every byte+EOF+SHA to owned full initial witness.',
        no_general_adversarial_JSON_claim=True,
        cost_records='Per-file inclusive generator/encoding/write time is nested in shared20 and owned cost, never added. Evidence/receipt/source hash reads/final prints included by current worker/generic owner/caller gates.')
    contract['output_names']=['Q-preparation-provisional-v1.json','Q-initial-state-witness-v2.json','Q-initial-oracle-domains-v2.json',
        'Q-after-one-step-state-v2.json','Q-after-one-step-oracle-domains-v2.json','Q-controls-provisional-v1.json',
        'Q-controls-evidence-v1.json','Q-controls-result-v1.json']
    contract['output_closure']='Every completed witness raw pin appears in artifacts/evidence closure. Receipt adds all earlier per-file records including evidence. Receipt self pin and final writes/print are closed by generic owned/Root caller actual records, not self-referential receipt hashes. Unknown partial files remain on disk and need actual post-terminal raw closure; no accepted prefix.'
    contract['feasibility']=dict(old_contract['feasibility'],memory_risk='Unmeasured successor. Source avoids duplicate production graph/full24 oracle/full preparation strings. Complete model and graph still coexist; actual20s/512MiB fit remains UNKNOWN.',
        source_only_retention_change=True,provisional_11147_16200_not_accepted=True)
    contract_pin=write('source-contract-v1.json',contract)
    readiness=write('Source-readiness-v1.json',dict(schema='Q-streamed-controls-Source-readiness-v1',author_identity=AUTHOR,source_only=True,
        source_ready=True,source_review_passed=False,all_author_static_checks_passed=True,scientific_calls=0,project_imports=0,
        project_function_calls=0,fixtures_executed=0,actual_successor_plan_emitted=False,actual_execution_authorized=False,
        actual_successor_peak_bytes=None,actual_successor_seconds=None,sources=sources,inputs=inputs,contract=contract_pin,
        conformance=receipt,diagnosis=diagnosis,prior_failure=failure,independent_saved_failure=saved_failure,
        remaining='Distinct-author whole Source/delta review, ROOT actual complete plans/closure and once-only timed controls; mathematical catalogue admission and theorem search remain separate unqualified gates.'))
    package=[pin(p) for p in sorted(HERE.iterdir()) if p.is_file()]
    integration=write('integration-v1.json',dict(schema='task-only-Source-integration-v1',source_only=True,scientific_calls=0,
        files=package,selected_sources=sources,selected_inputs=inputs,contract=contract_pin,readiness=readiness,
        preserved_unactivated_versions=True,private_only=True,publish_authorized=False))
    handoff=write('handoff-v1.json',dict(schema='Q-streamed-controls-Source-handoff-v1',author_identity=AUTHOR,
        source_only=True,scientific_calls=0,project_imports=0,source_function_calls=0,tests_executed=0,
        sources=sources,contract=contract_pin,readiness=readiness,integration=integration,conformance=receipt,
        prior_failure=failure,independent_saved_failure=saved_failure,reviewer_required='/root/hilbert_ordering_diagnosis',
        limits=contract['limits'],actual_successor_activation=False,actual_successor_execution=False,
        message='Same Q grammar/full24 point controls; storage-only lifetime successor. Complete witnesses/byte rollback retained. No source review or feasibility acceptance inferred from authorship.'))
    print(json.dumps(dict(handoff=handoff,integration=integration,contract=contract_pin,readiness=readiness,
        author_static_checks=len(checks),scientific_calls=0,metadata_seconds=time.perf_counter()-began)))

if __name__=='__main__':main()
