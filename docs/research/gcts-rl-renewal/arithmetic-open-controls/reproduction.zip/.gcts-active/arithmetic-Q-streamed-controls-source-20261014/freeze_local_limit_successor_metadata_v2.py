"""Metadata/AST/raw-byte freeze only; never invokes any project Source."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def pin(path):
    path=Path(path).resolve();h=hashlib.sha256();n=0
    with path.open('rb') as stream:
        for raw in iter(lambda:stream.read(65536),b''):h.update(raw);n+=len(raw)
    return dict(path=str(path),sha256=h.hexdigest(),bytes=n)

def save(name,value):
    path=HERE/name
    with path.open('x') as stream:
        if isinstance(value,str):stream.write(value)
        else:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    return pin(path)

def refs(v):
    if type(v) is dict:
        if set(v)=={'path','sha256','bytes'}:yield v
        for child in v.values():yield from refs(child)
    elif type(v) is list:
        for child in v:yield from refs(child)

def main():
    began=time.perf_counter();checks=[];raw_refs=[]
    def check(ok,label):
        checks.append(dict(name=label,passed=bool(ok)))
        if not ok:raise ValueError(label)
    old_path=HERE/'arithmetic_Q_streamed_controls_worker_v6.py';path=HERE/'arithmetic_Q_streamed_controls_worker_v7.py'
    old=old_path.read_text();new=path.read_text();old_ast=ast.parse(old);new_ast=ast.parse(new)
    normalized=new
    count={}
    for helper in ('whole_tick','inner_tick'):
        pattern=re.compile(r"^( +)if any\(globals\(\)\[name\] is not fn or fn\.__code__ is not code for name,\(fn,code\) in validators\.items\(\)\):\n"
            r"\1    raise ValueError\('original own validator changed before local limit delegation'\)\n"
            r"\1if function_signature\("+helper+r"\)!="+helper+r"_anchor or function_signature\("+helper+r"_fn\)!="+helper+r"_anchor:\n"
            r"\1    raise ValueError\('original "+helper+r" function/code/default/closure endpoint changed'\)\n"
            r"\1"+helper+r"_fn\(\)$",re.M)
        count[helper]=len(pattern.findall(normalized))
        normalized=pattern.sub(lambda m:m.group(1)+helper+'()',normalized)
        normalized=normalized.replace('    '+helper+'_fn='+helper+';'+helper+'_anchor=function_signature('+helper+'_fn)\n','',1)
    normalized=normalized.replace("        record=pin(path);artifacts.append(record);partial_stream_paths.remove(str(path))\n        whole_tick()",
        "        record=pin(path);artifacts.append(record);partial_stream_paths.remove(str(path));whole_tick()",1)
    normalized=normalized.replace("            inner_tick()\n            module=load(plan['sources'][role],'_cold_arithmetic_Q_controls_'+role)",
        "            inner_tick();module=load(plan['sources'][role],'_cold_arithmetic_Q_controls_'+role)",1)
    check(count==dict(whole_tick=5,inner_tick=3),'all eight original local-limit delegation sites protected')
    check(normalized==old,'complete inverse bytes restore exact frozen v6; no output/grammar/resource semantic change')
    def definitions(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    a,b=definitions(old_ast),definitions(new_ast)
    check(set(a)==set(b) and all(a[name]==b[name] for name in a if name!='main'),
          'all fifteen original top-level utilities/serializer/preflight definitions AST unchanged; only main local binding guard changes')
    original_contract=json.loads((HERE/'source-contract-v1.json').read_text());sources=dict(original_contract['sources'],worker=pin(path))
    for record in [*sources.values(),*original_contract['inputs'].values()]:
        check(pin(record['path'])==record,'current source/input raw pin '+record['path']);raw_refs.append(record)
    negative_dir=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-independent-20261014'
    negative=pin(negative_dir/'streamed-Q-source-findings-v1.json')
    negative_review=pin(negative_dir/'streamed-Q-typed-source-review-v1.json')
    negative_doc=json.loads(Path(negative_review['path']).read_text())
    check(negative_doc['source_only'] is True and negative_doc['source_review_passed'] is False
          and negative_doc['scientific_calls']==0 and negative_doc['sources']==original_contract['sources'],
          'genuine distinct-author v6 negative Source review retained, no actual failed successor run')
    for doc in (original_contract,negative_doc):
        for record in refs(doc):
            check(pin(record['path'])==record,'parent/negative raw closure '+record['path']);raw_refs.append(record)
    check("LIMITS=dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)" in new,
          'same20/60/90 seconds and512MiB')
    check('function_signature(whole_tick_fn)' in new and 'function_signature(inner_tick_fn)' in new,
          'full original function/code/default/kwdefault/closure-cell and content identity anchors')
    patch=save('worker-v6-to-v7-local-limit-anchors.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(old_path),tofile=str(path))))
    conformance=save('Source-authoring-checks-v2.json',dict(schema='Q-streamed-local-limit-successor-Source-checks-v2',
        author_identity='/root/arithmetic_induction',source_only=True,scientific_calls=0,project_imports=0,project_function_calls=0,
        fixtures_executed=0,all_checks_passed=True,mismatches=[],sources=sources,checks=checks,checks_count=len(checks),raw_pin_occurrences=raw_refs,
        inherited_whole_storage_source_checks=pin(HERE/'Source-authoring-checks-v1.json'),parent=pin(old_path),patch=patch,
        negative_findings=negative,negative_review=negative_review,explicit_local_limit_delegation_counts=count,
        metadata_seconds_before_write=time.perf_counter()-began,
        scope='Author metadata/AST checks only. Distinct-author current review and all actual runtime/semantic qualification remain open.'))
    contract=dict(original_contract)
    contract['sources']=sources;contract['Source_review_ABI']=dict(original_contract['Source_review_ABI'],sources=sources)
    contract['conformance']=conformance
    contract['entrypoint']=dict(original_contract['entrypoint'],worker=sources['worker'],
        argv=['exact canonical CLT runtime','-B',sources['worker']['path'],original_contract['entrypoint']['command'],'ABS worker-plan path','ABS owner-plan path'])
    contract['parent_streamed_source_contract']=pin(HERE/'source-contract-v1.json')
    contract['preserved_v6_negative_Source_review']=negative_review
    contract['local_limit_guard_delta']='Before each of five whole_tick and three inner_tick delegations, directly check original own validator functions/codes and full original local helper function/code/default/kwdefault/closure-cell+content identities, then call captured alias. Writer and final clock/reserve boundaries covered. No output/grammar/check/cap change.'
    contract['selected_delta_patches']=[*original_contract['selected_delta_patches'],patch]
    contract['source_integrity']=[*original_contract['source_integrity'],contract['local_limit_guard_delta']]
    contract_pin=save('source-contract-v2.json',contract)
    readiness=save('Source-readiness-v2.json',dict(schema='Q-streamed-controls-local-limit-Source-readiness-v2',
        author_identity='/root/arithmetic_induction',source_only=True,source_ready=True,source_review_passed=False,
        scientific_calls=0,project_imports=0,project_function_calls=0,fixtures_executed=0,
        sources=sources,inputs=contract['inputs'],contract=contract_pin,conformance=conformance,
        parent_readiness=pin(HERE/'Source-readiness-v1.json'),preserved_negative_review=negative_review,
        actual_successor_plan_emitted=False,actual_execution_authorized=False,
        remaining='Genuine typed current-worker Source review; ROOT metadata construction/saved-plan review/once-only complete timed controls. No catalogue/math/search/native admission.'))
    integration=save('integration-v2.json',dict(schema='task-only-Source-integration-v2',source_only=True,scientific_calls=0,
        files=[pin(p) for p in sorted(HERE.iterdir()) if p.is_file()],selected_sources=sources,selected_inputs=contract['inputs'],
        contract=contract_pin,readiness=readiness,preserved_v6_handoff=pin(HERE/'handoff-v1.json'),private_only=True,publish_authorized=False))
    handoff=save('handoff-v2.json',dict(schema='Q-streamed-controls-local-limit-Source-handoff-v2',author_identity='/root/arithmetic_induction',
        source_only=True,scientific_calls=0,project_imports=0,source_function_calls=0,tests_executed=0,
        sources=sources,contract=contract_pin,readiness=readiness,integration=integration,conformance=conformance,
        preserved_parent_handoff=pin(HERE/'handoff-v1.json'),negative_findings=negative,negative_review=negative_review,
        reviewer_required='/root/hilbert_ordering_diagnosis',limits=contract['limits'],actual_successor_activation=False,
        message='V7 changes only local rejection-helper bindings; whole v6 bytes and negative review preserved. Complete grammar/state/witness protocol/caps unchanged; no actual run.'))
    print(json.dumps(dict(handoff=handoff,contract=contract_pin,integration=integration,conformance=conformance,
        checks=len(checks),scientific_calls=0,metadata_seconds=time.perf_counter()-began)))

if __name__=='__main__':main()
