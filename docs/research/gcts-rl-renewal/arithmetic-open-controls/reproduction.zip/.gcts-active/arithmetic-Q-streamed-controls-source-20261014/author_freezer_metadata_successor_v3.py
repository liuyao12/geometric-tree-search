"""Metadata-only comparison-path correction, no Source execution."""
import ast
from pathlib import Path

HERE=Path(__file__).resolve().parent
source=(HERE/'freeze_streamed_Source_metadata_v2.py').read_text()
start=source.index("    metadata_only_failure=write('preserved-metadata-freezer-failure-v1.json'")
end=source.index("    def check(ok,label):",start)
source=source[:start]+"""    metadata_only_failure=pin(HERE/'preserved-metadata-freezer-failure-v1.json')
    metadata_only_failure_v2=write('preserved-metadata-freezer-failure-v2.json',dict(schema='Source-metadata-authoring-failure-v2',
        scientific_calls=0,project_imports=0,project_function_calls=0,source=pin(HERE/'freeze_streamed_Source_metadata_v2.py'),
        error='Source comparison included necessary prepared.catalogue -> model caller ABI rewrite without its explicit inverse; no project call or final freeze occurred.'))
"""+source[end:]
source=source.replace("check(between(old_controls,\"    theory=declaration['theory']\",'    model=prepared')==", "check(between(old_controls,\"    theory=declaration['theory']\",'    model=prepared').replace(\"prepared['catalogue']['declaration']\",\"model['declaration']\",1)==",1)
source=source.replace('metadata_only_failure=metadata_only_failure,checks=checks',
    'metadata_only_failures=[metadata_only_failure,metadata_only_failure_v2],checks=checks',1)
ast.parse(source)
with (HERE/'freeze_streamed_Source_metadata_v3.py').open('x') as stream:stream.write(source)
