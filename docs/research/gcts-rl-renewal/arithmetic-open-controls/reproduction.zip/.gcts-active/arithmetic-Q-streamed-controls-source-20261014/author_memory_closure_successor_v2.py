"""Text/AST/JSON only: close every streamed witness and scalar byte gate."""
import ast
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent

def pin(p):
    raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def write(name,text):
    ast.parse(text);p=HERE/name
    with p.open('x') as f:f.write(text)
    return pin(p)

def main():
    controls=(HERE/'arithmetic_Q_streamed_controls_v2.py').read_text()
    needle="""        fixture_records.append(dict(label=label,state=tiny.semantic_state(),decision=literal_decision(tiny,tiny_oracle),
"""
    replacement="""        check(''.join(state_chunks(tiny))==text(tiny.semantic_state()),
              label+' complete streaming state protocol equals unchanged full scalar snapshot')
        fixture_records.append(dict(label=label,state=tiny.semantic_state(),decision=literal_decision(tiny,tiny_oracle),
"""
    assert needle in controls;controls=controls.replace(needle,replacement,1)
    controls_pin=write('arithmetic_Q_streamed_controls_v3.py',controls)
    spec=json.loads((HERE/'controls-specification-v2.json').read_bytes());spec['current_sources']['controls']=controls_pin
    spec['schema']='arithmetic-Q-streamed-preparation-controls-specification-v3'
    spec['additional_serialization_control']='Each existing tiny scheduling fixture compares complete stream-state bytes against unchanged PointGraph.semantic_state canonical JSON. All old controls retained.'
    p=HERE/'controls-specification-v3.json'
    with p.open('x') as f:json.dump(spec,f,sort_keys=True,indent=2);f.write('\n')
    spec_pin=pin(p)
    worker=(HERE/'arithmetic_Q_streamed_controls_worker_v4.py').read_text();tree=ast.parse(worker)
    ass={n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    sources=ast.literal_eval(ass['FROZEN_SOURCES'].value);sources['controls']=controls_pin
    inputs=ast.literal_eval(ass['FROZEN_INPUTS'].value);inputs['control_specification']=spec_pin
    worker=worker.replace(ast.get_source_segment(worker,ass['FROZEN_SOURCES']),'FROZEN_SOURCES = '+repr(sources),1)
    worker=worker.replace(ast.get_source_segment(worker,ass['FROZEN_INPUTS']),'FROZEN_INPUTS = '+repr(inputs),1)
    worker=worker.replace('streamed_bytes=[0];partial_stream_paths=[]','streamed_bytes=[0];partial_stream_paths=[];serialization_records=[]',1)
    worker=worker.replace("        path=output/name;partial_stream_paths.append(str(path));count=0", "        write_began=time.perf_counter()\n        path=output/name;partial_stream_paths.append(str(path));count=0;maximum_block=0",1)
    worker=worker.replace("                count+=len(raw);streamed_bytes[0]+=len(raw)","                count+=len(raw);streamed_bytes[0]+=len(raw);maximum_block=max(maximum_block,len(raw))",1)
    worker=worker.replace("        record=pin(path);artifacts.append(record);partial_stream_paths.remove(str(path));whole_tick();return record",
        """        record=pin(path);artifacts.append(record);partial_stream_paths.remove(str(path));whole_tick()
        serialization_records.append(dict(file=record,bytes=count,maximum_block_bytes=maximum_block,
            inclusive_source_encoding_write_seconds=time.perf_counter()-write_began,
            scope='Includes generator/domain work; nested in shared20 and whole owned cost, not additive pure serialization time.'))
        return record""",1)
    needle="""        if function_signature(writer_fn)!=writer_anchor:raise ValueError('owned snapshot writer changed')"""
    replacement="""        if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):
            raise ValueError('own validator replaced before writer endpoint check')
        if function_signature(writer_fn)!=writer_anchor:raise ValueError('owned snapshot writer changed')"""
    assert needle in worker;worker=worker.replace(needle,replacement,1)
    worker=worker.replace("            prepared=prepared_pin,controls=controls_pin,inner_complete_seconds=inner_complete,",
        """            prepared=prepared_pin,controls=controls_pin,inner_complete_seconds=inner_complete,
            complete_witness_output_closure=list(artifacts),stream_output_records_before_evidence=list(serialization_records),
            all_production_graph_constructions=1,initial_copy_released_before_controls=True,
            aggregate_streamed_bytes_before_evidence=streamed_bytes[0],
            file_backed_complete_snapshot_protocol='canonical-JSON-no-trailing-newline-v2',""",1)
    # Small JSON-value fixtures exercise the serializer itself, not a theorem,
    # graph or model. Root will execute them inside the original shared20 gate.
    needle="""        prepared,owned_graph=modules['payload'].prepare_owned("""
    replacement="""        serialization_fixtures=[{},[],{'b':None,'a':[False,True,0,-0.0,10**30,'\\u03bb\\\\\\\"']},
            list(range(97)),{'nested':{'list':(None,{'empty':[],'zero':0})}}]
        for index,value in enumerate(serialization_fixtures):
            inner_tick()
            need(''.join(json_chunks(value))==canonical(value),'whole bounded JSON fixture byte correspondence')
        prepared,owned_graph=modules['payload'].prepare_owned("""
    assert needle in worker;worker=worker.replace(needle,replacement,1)
    worker=worker.replace("            all_production_graph_constructions=1,initial_copy_released_before_controls=True,",
        "            all_production_graph_constructions=1,initial_copy_released_before_controls=True,serializer_control_count=len(serialization_fixtures),",1)
    worker_pin=write('arithmetic_Q_streamed_controls_worker_v5.py',worker)
    print(json.dumps(dict(worker=worker_pin,controls=controls_pin,specification=spec_pin,scientific_calls=0,source_only=True)))

if __name__=='__main__':main()
