"""Text/AST-only narrow local rejection-helper binding successor."""
import ast
import hashlib
import json
from pathlib import Path
import re
import time

HERE=Path(__file__).resolve().parent

def pin(path):
    raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def main():
    began=time.perf_counter();old=HERE/'arithmetic_Q_streamed_controls_worker_v6.py'
    text=old.read_text()
    marker='    streamed_bytes=[0];partial_stream_paths=[];serialization_records=[]'
    assert text.count(marker)==1
    text=text.replace(marker,"    whole_tick_fn=whole_tick;whole_tick_anchor=function_signature(whole_tick_fn)\n"+marker,1)
    marker="        if time.perf_counter()>=deadline:raise TimeoutError('whole20s Q preparation/controls incomplete; no accepted prefix')\n    try:"
    assert text.count(marker)==1
    text=text.replace(marker,marker[:-len('    try:')]+"    inner_tick_fn=inner_tick;inner_tick_anchor=function_signature(inner_tick_fn)\n    try:",1)
    # Separate the two old compound call-site lines so each rejection endpoint
    # receives a direct check before delegation without altering call order.
    text=text.replace("        record=pin(path);artifacts.append(record);partial_stream_paths.remove(str(path));whole_tick()",
        "        record=pin(path);artifacts.append(record);partial_stream_paths.remove(str(path))\n        whole_tick()",1)
    text=text.replace("            inner_tick();module=load(plan['sources'][role],'_cold_arithmetic_Q_controls_'+role)",
        "            inner_tick()\n            module=load(plan['sources'][role],'_cold_arithmetic_Q_controls_'+role)",1)
    counts={}
    for helper in ('whole_tick','inner_tick'):
        pattern=re.compile(r'^( +)'+helper+r'\(\)$',re.M)
        counts[helper]=len(pattern.findall(text))
        def replacement(match):
            indent=match.group(1)
            return '\n'.join((
                indent+"if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):",
                indent+"    raise ValueError('original own validator changed before local limit delegation')",
                indent+"if function_signature("+helper+")!="+helper+"_anchor or function_signature("+helper+"_fn)!="+helper+"_anchor:",
                indent+"    raise ValueError('original "+helper+" function/code/default/closure endpoint changed')",
                indent+helper+"_fn()"))
        text=pattern.sub(replacement,text)
    assert counts=={'whole_tick':5,'inner_tick':3},counts
    ast.parse(text)
    path=HERE/'arithmetic_Q_streamed_controls_worker_v7.py'
    with path.open('x') as stream:stream.write(text)
    receipt=dict(schema='Q-local-limit-anchor-Source-authoring-v4',source_only=True,scientific_calls=0,
        project_imports=0,project_function_calls=0,tests_executed=0,parent=pin(old),worker=pin(path),
        explicit_delegation_counts=counts,metadata_authoring_seconds=time.perf_counter()-began)
    with (HERE/'local-limit-anchor-authoring-receipt-v4.json').open('x') as stream:json.dump(receipt,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(receipt))

if __name__=='__main__':main()
