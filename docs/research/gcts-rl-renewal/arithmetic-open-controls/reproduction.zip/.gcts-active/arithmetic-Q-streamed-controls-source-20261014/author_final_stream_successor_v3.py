"""Metadata/text/AST authoring only. Does not import or call project Sources."""
import ast
import hashlib
import json
from pathlib import Path
import time

HERE=Path(__file__).resolve().parent

def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def write(name,text):
    path=HERE/name
    with path.open('x') as stream:stream.write(text)
    if path.suffix=='.py':ast.parse(text)
    return pin(path)

def main():
    began=time.perf_counter()
    payload=(HERE/'q_preparation_owned_graph_v2.py').read_text()
    old='    text(result);guard()'
    new="""    # Complete strict serialization is deferred to the caller's immediate
    # owned streamed preparation write. No accepted output precedes that full
    # traversal, its raw pin, and the shared deadline/Source guards.
    guard()"""
    assert payload.count(old)==1
    payload=payload.replace(old,new,1)
    payload_pin=write('q_preparation_owned_graph_v3.py',payload)
    worker=(HERE/'arithmetic_Q_streamed_controls_worker_v5.py').read_text()
    start=worker.index('def json_chunks(value):')
    end=worker.index('\n\ndef preflight(',start)
    worker=worker[:start]+'''def json_blockable(value):
    # A C-json block is a bounded existing subtree: at most512 scalar/container
    # visits,32768 total string characters and4096 bits per integer. This test
    # retains references only; oversized containers are streamed recursively.
    stack=[value];visits=0;characters=0
    while stack:
        child=stack.pop();visits+=1
        if visits>512:return False
        if type(child) is str:
            characters+=len(child)
            if characters>32768:return False
        elif type(child) is int:
            if child.bit_length()>4096:return False
        elif child is None or type(child) in (bool,float):pass
        elif type(child) is dict:
            if len(child)>512:return False
            for name,item in child.items():
                if type(name) is not str:return False
                stack.append(name);stack.append(item)
                if len(stack)>512:return False
        elif type(child) in (list,tuple):
            if len(child)>512:return False
            stack.extend(child)
            if len(stack)>512:return False
        else:return False
    return True


def json_chunks(value):
    # Full canonical JSON: C blocks only for bounded existing subtrees. No full
    # model/state copy, JSON string or UTF-8 buffer is constructed here.
    if json_blockable(value):
        yield canonical(value)
    elif type(value) is dict:
        yield '{'
        for index,name in enumerate(sorted(value)):
            need(type(name) is str,'literal JSON object keys')
            if index:yield ','
            yield canonical(name)+':'
            yield from json_chunks(value[name])
        yield '}'
    elif type(value) in (list,tuple):
        yield '['
        for start in range(0,len(value),32):
            block=value[start:start+32]
            if start:yield ','
            if json_blockable(block):yield canonical(block)[1:-1]
            else:
                for offset,item in enumerate(block):
                    if offset:yield ','
                    yield from json_chunks(item)
        yield ']'
    else:yield canonical(value)
''' +worker[end:]
    worker=worker.replace("'function_signature','json_chunks'","'function_signature','json_blockable','json_chunks'",1)
    worker=worker.replace("            list(range(97)),{'nested':{'list':(None,{'empty':[],'zero':0})}}]",
        "            list(range(97)),{'nested':{'list':(None,{'empty':[],'zero':0})}},\n            {'domains':[{'factors':[[r,0,0,False,r] for r in range(513)],'count':0} for _ in range(2)]}]",1)
    worker=worker.replace("            evidence=evidence_pin,prepared=prepared_pin,controls=controls_pin,all_direct_children_terminal_and_reaped=True,",
        "            evidence=evidence_pin,prepared=prepared_pin,controls=controls_pin,all_direct_children_terminal_and_reaped=True,\n            stream_output_records_before_receipt=list(serialization_records),\n            aggregate_streamed_bytes_before_receipt=streamed_bytes[0],",1)
    tree=ast.parse(worker)
    assignments={n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    sources=ast.literal_eval(assignments['FROZEN_SOURCES'].value);sources['payload']=payload_pin
    spec=json.loads((HERE/'controls-specification-v3.json').read_text())
    spec['schema']='arithmetic-Q-streamed-preparation-controls-specification-v4'
    spec['current_sources']=sources
    spec['payload_serialization_delta']='Old whole text(result) is replaced by immediate caller full owned stream write and raw pin before any controls/acceptance; same final payload guard/graph-method checks and pair return. Original catalogue text(result) remains unchanged and is a residual allocation.'
    spec['serializer_controls']='Six bounded future worker fixtures, including nested large-domain layout, compare full stream bytes to canonical JSON. Three original tiny graph fixtures compare full stream state to unchanged semantic_state. No fixtures executed by author.'
    spec_pin=write('controls-specification-v4.json',json.dumps(spec,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    inputs=ast.literal_eval(assignments['FROZEN_INPUTS'].value);inputs['control_specification']=spec_pin
    worker=worker.replace(ast.get_source_segment(worker,assignments['FROZEN_SOURCES']),'FROZEN_SOURCES = '+repr(sources),1)
    worker=worker.replace(ast.get_source_segment(worker,assignments['FROZEN_INPUTS']),'FROZEN_INPUTS = '+repr(inputs),1)
    worker_pin=write('arithmetic_Q_streamed_controls_worker_v6.py',worker)
    receipt=dict(schema='Q-stream-final-source-authoring-receipt-v3',source_only=True,scientific_calls=0,
        project_imports=0,project_function_calls=0,fixtures_executed=0,worker=worker_pin,payload=payload_pin,
        specification=spec_pin,metadata_authoring_seconds=time.perf_counter()-began)
    write('final-source-authoring-receipt-v3.json',json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps(receipt))

if __name__=='__main__':main()
