"""Text-only repair of metadata freezer literal assignment selection."""
import ast
from pathlib import Path

HERE=Path(__file__).resolve().parent
source=(HERE/'freeze_streamed_Source_metadata_v1.py').read_text()
source=source.replace("'COMMAND','AUTHOR','MAX_METADATA')","'COMMAND','AUTHOR')",1)
source=source.replace("    began=time.perf_counter();checks=[];references=[]", "    began=time.perf_counter();checks=[];references=[]\n    metadata_only_failure=write('preserved-metadata-freezer-failure-v1.json',dict(schema='Source-metadata-authoring-failure-v1',\n        scientific_calls=0,project_imports=0,project_function_calls=0,source=pin(HERE/'freeze_streamed_Source_metadata_v1.py'),\n        error='ast.literal_eval rejected unused MAX_METADATA arithmetic assignment; no project call or output freeze occurred.'))",1)
source=source.replace("        tests_executed=0,all_checks_passed=True", "        tests_executed=0,all_checks_passed=True",1)
source=source.replace("        checks=checks,checks_count=len(checks)","        metadata_only_failure=metadata_only_failure,checks=checks,checks_count=len(checks)",1)
ast.parse(source)
with (HERE/'freeze_streamed_Source_metadata_v2.py').open('x') as stream:stream.write(source)
