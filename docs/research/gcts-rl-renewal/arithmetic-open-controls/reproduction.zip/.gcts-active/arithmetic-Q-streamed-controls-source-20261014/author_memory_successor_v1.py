"""Text/AST authoring only. Never imports or calls project code."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=Path(__file__).resolve().parent
OLD=ROOT/'.gcts-active/arithmetic-Q-cold-controls-source-20261014'
PROTO=ROOT/'.gcts-active/arithmetic-open-generalize-implementation-source-20261014'

def pin(path):
    raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    path=HERE/name
    with path.open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
    return pin(path)

def write(name,text):
    ast.parse(text)
    path=HERE/name
    with path.open('x') as f:f.write(text)
    return pin(path)

def main():
    payload=(PROTO/'q_preparation_gate_v1.py').read_text()
    assert payload.count('def prepare_only(')==1 and payload.count('guard();return result')==1
    payload=payload.replace('def prepare_only(', 'def prepare_owned(',1).replace('guard();return result','guard();return result, graph',1)
    payload_pin=write('q_preparation_owned_graph_v2.py',payload)
    controls=(OLD/'arithmetic_Q_controls_v1.py').read_text()
    # Turn the same complete row relation into a generator; the list wrapper
    # remains for tiny unchanged controls only.
    controls=controls.replace("VERSION='arithmetic-Q-complete-initial-domains-and-finite-controls-v1'",
        "VERSION='arithmetic-Q-streamed-complete-domain-controls-v2'",1)
    controls=controls.replace('def literal_domains(graph,*,deadline):','def literal_domain_rows(graph,*,deadline):',1)
    controls=controls.replace('    result=[]\n    def tick():','    def tick():',1)
    controls=controls.replace("        result.append(dict(factors=factors,base_count=base,excluded_legal=removed,count=base-len(removed)))\n    tick();return result",
        "        yield dict(factors=factors,base_count=base,excluded_legal=removed,count=base-len(removed))\n    tick()",1)
    new_helpers='''

def literal_domains(graph,*,deadline):
    # Tiny nonlogical fixtures only; production callers consume every row below.
    return list(literal_domain_rows(graph,deadline=deadline))


def production_domain(graph,row):
    d=graph.domains[row]
    return dict(factors=[[f.recipe,f.left,f.right,f.different,f.count] for f in d.factors],
        base_count=d.base_count,excluded_legal=[k.data() for k in d.excluded_legal],count=d.count)


def state_chunks(graph):
    # Exactly canonical(PointGraph.semantic_state()), without a full24 copy.
    small={'totals':list(graph.totals),'marks':[[*p,v,graph.mark_refs[p]] for p,v in sorted(graph.marks.items())],
        'order':[k.data() for k in graph.order],'selected_generations':[[k.data(),graph.selected[k]] for k in sorted(graph.selected)],
        'roots':list(graph.roots),'excluded':[[k.data() for k in sorted(s)] for s in graph.excluded],'model_epoch':graph.model_epoch}
    yield '{'
    for index,name in enumerate(sorted([*small,'domains'])):
        if index:yield ','
        yield text(name)+':'
        if name=='domains':
            yield '['
            for row in range(graph.height):
                if row:yield ','
                yield text(production_domain(graph,row))
            yield ']'
        else:yield text(small[name])
    yield '}'


def compare_snapshot(chunks,record):
    # Complete byte equality, not only a hash; record must be a caller-owned pin.
    from pathlib import Path
    import hashlib
    require(set(record)=={'path','sha256','bytes'},'exact owned snapshot pin')
    path=Path(record['path']);require(path.is_absolute() and path==path.resolve(),'canonical owned witness path')
    count=0;h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in chunks:
            raw=chunk.encode('utf8')
            require(stream.read(len(raw))==raw,'complete streamed state bytes match owned snapshot')
            count+=len(raw);h.update(raw)
        require(stream.read(1)==b'','no omitted state field or trailing prefix')
    require(count==record['bytes'] and h.hexdigest()==record['sha256'],'same whole snapshot bytes/pin')


def checked_domain_chunks(graph,*,deadline):
    # Every row and factor is checked before its full witness is streamed.
    yield '['
    rows=0
    for row,independent in enumerate(literal_domain_rows(graph,deadline=deadline)):
        require(independent==production_domain(graph,row),'every complete production domain equals separate literal relation')
        if row:yield ','
        yield text(independent);rows+=1
    require(rows==graph.height,'all required domains covered, never a shortlist')
    yield ']'


def current_decision_data(graph):
    d=graph.decision()
    return dict(kind=d.kind,row=d.row,count=d.count,generation=d.generation)
'''
    controls=controls.replace('\n\ndef literal_decision(',new_helpers+'\n\ndef literal_decision(',1)
    controls=controls.replace('def run_controls(*,declaration,prepared,kernel_module,graph_module,source_bindings,source_guard,deadline):',
        'def run_controls(*,declaration,model,owned_graph,initial_record,initial_decision,kernel_module,graph_module,source_bindings,source_guard,write_snapshot,deadline):',1)
    controls=controls.replace('began=time.perf_counter();anchor=function_state(source_guard);tests=[];objects=[];snapshots=[]',
        'began=time.perf_counter();anchor=function_state(source_guard);sink_anchor=function_state(write_snapshot);tests=[];objects=[];snapshots=[]',1)
    controls=controls.replace("        if function_state(source_guard)!=anchor:raise ValueError('original delegated callback changed')",
        "        if function_state(source_guard)!=anchor:raise ValueError('original delegated callback changed')\n        if function_state(write_snapshot)!=sink_anchor:raise ValueError('original owned snapshot writer changed')",1)
    controls=controls.replace("prepared['catalogue']['declaration']==declaration", "model['declaration']==declaration",1)
    block="""    model=prepared['catalogue']
    graph=track(graph_module.PointGraph(height=model['height'],formulas=model['formula_codes'],recipe_data=model['recipes'],
        context=model['context'],authority=model['authority'],fixed_marks=model['boundary']['fixed_marks'],
        roots=model['boundary']['roots'],seed_keys=(),fixture=False,source_bindings=source_bindings))
"""
    replacement="""    graph=track(owned_graph)
    check(type(graph) is graph_module.PointGraph and graph.height==model['height'] and graph.context==model['context']
          and graph.authority==model['authority'] and graph.formulas==model['formula_codes'] and graph.source_bindings==source_bindings,
          'same actual payload-owned complete production graph, no second construction')
"""
    assert block in controls;controls=controls.replace(block,replacement,1)
    block="""    state=graph.semantic_state();oracle=literal_domains(graph,deadline=deadline);guard()
    check(state==prepared['initial_state'] and oracle==state['domains'],'every full initial24 parametric domain independently reconstructed')
    check(literal_decision(graph,oracle)==prepared['initial_decision'], 'complete initial global scheduler agrees with literal reference')
    snapshots.append(dict(label='complete-original-initial',state=state,independent_domains=oracle,decision=prepared['initial_decision']))
"""
    replacement="""    compare_snapshot(state_chunks(graph),initial_record);guard()
    initial_domains=write_snapshot('Q-initial-oracle-domains-v2.json',checked_domain_chunks(graph,deadline=deadline));guard()
    check(True,'every full initial24 parametric domain independently reconstructed')
    # The domain oracle checked every row; small scalar records suffice to
    # evaluate priority without duplicating factor arrays.
    counts=[{'count':d.count} for d in graph.domains]
    check(literal_decision(graph,counts)==initial_decision, 'complete initial global scheduler agrees with literal reference')
    snapshots.append(dict(label='complete-original-initial',state=initial_record,independent_domains=initial_domains,decision=initial_decision))
"""
    assert block in controls;controls=controls.replace(block,replacement,1)
    controls=controls.replace('root=graph.checkpoint();root_text=text(graph.semantic_state());executor=track(graph_module.Executor(graph))',
        'root=graph.checkpoint();root_record=initial_record;executor=track(graph_module.Executor(graph))',1)
    block="""        after=graph.semantic_state();after_oracle=literal_domains(graph,deadline=deadline);guard()
        check(after['domains']==after_oracle,'full24 domains after one generic scheduler primitive reconstructed')
        snapshots.append(dict(label='one-canonical-scheduler-step-not-a-proof',placement=first.data(),state=after,
            independent_domains=after_oracle,decision=literal_decision(graph,after_oracle)))
"""
    replacement="""        after_record=write_snapshot('Q-after-one-step-state-v2.json',state_chunks(graph));guard()
        after_domains=write_snapshot('Q-after-one-step-oracle-domains-v2.json',checked_domain_chunks(graph,deadline=deadline));guard()
        check(True,'full24 domains after one generic scheduler primitive reconstructed')
        snapshots.append(dict(label='one-canonical-scheduler-step-not-a-proof',placement=first.data(),state=after_record,
            independent_domains=after_domains,decision=literal_decision(graph,[{'count':d.count} for d in graph.domains])))
"""
    assert block in controls;controls=controls.replace(block,replacement,1)
    controls=controls.replace("graph.rollback(root);guard();require(text(graph.semantic_state())==root_text,'complete production rollback')",
        'graph.rollback(root);guard();compare_snapshot(state_chunks(graph),root_record);guard()',1)
    controls=controls.replace("check(text(graph.semantic_state())==root_text,'exact full production marks/refcounts/generations/exclusions/domain rollback')",
        "check(True,'exact full production marks/refcounts/generations/exclusions/domain rollback')",1)
    controls_pin=write('arithmetic_Q_streamed_controls_v2.py',controls)
    sources={role:pin(PROTO/name) for role,name in [('kernel','arithmetic_q_kernel_v1.py'),('catalogue','arithmetic_q_catalog_v1.py'),('point_graph','arithmetic_q_point_graph_v1.py')]}
    sources.update(payload=payload_pin,controls=controls_pin,master=pin(ROOT/'docs/basic-tiling-algorithm.md'))
    prototype_sources=json.loads((PROTO/'source-contract-v1.json').read_bytes())['sources']
    spec_pin=save('controls-specification-v2.json',dict(schema='arithmetic-Q-streamed-preparation-controls-specification-v2',
        declaration=pin(PROTO/'Q-declaration-v1.json'),original_sources=prototype_sources,current_sources=sources,
        grammar_changed=False,target_changed=False,original_ordered_Gamma=[],scientific_calls=0,controls_run=False,
        source_controls_semantics='Every original side-condition/control and all24 relations retained. One new production-graph identity check. Full state/domain fields stored in exact owned JSON files instead of redundant inline copies.',
        source_lifetime='Retain existing payload graph; stream full preparation and initial state; release old initial-state copy before controls. Per-row complete domain equality and full streamed byte rollback, no census trimming.',
        no_actual_preparation_or_witness_reuse=True,provisional_counts_not_accepted=True))
    worker=(OLD/'arithmetic_Q_controls_worker_v3.py').read_text();worker_tree=ast.parse(worker)
    old_assign={n.targets[0].id:n for n in worker_tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    worker=worker.replace(ast.get_source_segment(worker,old_assign['FROZEN_SOURCES']), 'FROZEN_SOURCES = '+repr(sources),1)
    old_inputs=ast.literal_eval(old_assign['FROZEN_INPUTS'].value);new_inputs=dict(old_inputs,control_specification=spec_pin)
    worker=worker.replace(ast.get_source_segment(worker,old_assign['FROZEN_INPUTS']), 'FROZEN_INPUTS = '+repr(new_inputs),1)
    worker=worker.replace('INPUT_ROLES=set(FROZEN_INPUTS)','INPUT_ROLES=set(FROZEN_INPUTS)\nPROTOTYPE_SOURCE_PINS = '+repr(prototype_sources),1)
    worker=worker.replace("prior['sources']=={r:FROZEN_SOURCES[r] for r in ('kernel','catalogue','point_graph','payload')}","prior['sources']==PROTOTYPE_SOURCE_PINS",1)
    serializer='''

def json_chunks(value):
    # Exact canonical JSON protocol for pinned JSON-value objects; no full
    # model string/UTF-8 buffer. Arrays use at most32 existing item references.
    if type(value) is dict:
        yield '{'
        for index,name in enumerate(sorted(value)):
            need(type(name) is str,'literal JSON object keys')
            if index:yield ','
            yield canonical(name)+':'
            yield from json_chunks(value[name])
        yield '}'
    elif type(value) in (list,tuple):
        yield '['
        for start in range(0,len(value),32):
            if start:yield ','
            block=canonical(value[start:start+32])
            yield block[1:-1]
        yield ']'
    else:yield canonical(value)
'''
    worker=worker.replace('\n\ndef preflight(',serializer+'\n\ndef preflight(',1)
    old_save="""    def save(name,value):
        whole_tick();raw=(canonical(value)+'\\n').encode('utf8');need(len(raw)<=MAX_METADATA,'entire bounded output, no prefix')
        path=output/name
        with path.open('xb') as stream:need(stream.write(raw)==len(raw),'full output write')
        record=pin(path);artifacts.append(record);whole_tick();return record
"""
    new_save="""    streamed_bytes=[0];partial_stream_paths=[]
    def write_snapshot(name,chunks):
        need(type(name) is str and Path(name).name==name and name.endswith('.json'),'scoped owned JSON witness name')
        path=output/name;partial_stream_paths.append(str(path));count=0
        with path.open('xb') as stream:
            for chunk in chunks:
                whole_tick()
                if time.perf_counter()>=deadline:raise TimeoutError('complete output stream exceeded shared20s')
                need(type(chunk) is str,'stream literal JSON text chunks');raw=chunk.encode('utf8')
                need(len(raw)<=4*1048576,'bounded individual JSON block')
                count+=len(raw);streamed_bytes[0]+=len(raw)
                need(count<=MAX_METADATA and streamed_bytes[0]<=256*1048576,'whole per-file64MiB and aggregate256MiB output ceilings')
                need(stream.write(raw)==len(raw),'entire stream block written')
        record=pin(path);artifacts.append(record);partial_stream_paths.remove(str(path));whole_tick();return record
    def save(name,value):
        return write_snapshot(name,json_chunks(value))
"""
    assert old_save in worker;worker=worker.replace(old_save,new_save,1)
    worker=worker.replace("'source_cache_guard','function_signature')", "'source_cache_guard','function_signature','json_chunks')",1)
    worker=worker.replace("        prepared=modules['payload'].prepare_only(","        prepared,owned_graph=modules['payload'].prepare_owned(",1)
    worker=worker.replace("        controls=modules['controls'].run_controls(declaration=declaration,prepared=prepared,kernel_module=modules['kernel'],\n            graph_module=modules['point_graph'],source_bindings=plan['sources'],source_guard=invoke_fn,deadline=deadline)",
        """        initial_record=save('Q-initial-state-witness-v2.json',prepared['initial_state'])
        model=prepared['catalogue'];initial_decision=prepared['initial_decision'];prepared=None
        writer_fn=write_snapshot;writer_anchor=function_signature(writer_fn)
        controls=modules['controls'].run_controls(declaration=declaration,model=model,owned_graph=owned_graph,
            initial_record=initial_record,initial_decision=initial_decision,kernel_module=modules['kernel'],
            graph_module=modules['point_graph'],source_bindings=plan['sources'],source_guard=invoke_fn,write_snapshot=writer_fn,deadline=deadline)
        if function_signature(writer_fn)!=writer_anchor:raise ValueError('owned snapshot writer changed')""",1)
    worker=worker.replace("'provisional_artifacts':artifacts", "'provisional_artifacts':artifacts") if False else worker
    worker=worker.replace('provisional_artifacts=artifacts,accepted_prefix=False,','provisional_artifacts=artifacts,partial_stream_paths=partial_stream_paths,accepted_prefix=False,',1)
    worker_pin=write('arithmetic_Q_streamed_controls_worker_v4.py',worker)
    print(json.dumps(dict(payload=payload_pin,controls=controls_pin,worker=worker_pin,sources=sources,input_spec=spec_pin,
        source_only=True,scientific_calls=0)))

if __name__=='__main__':main()
