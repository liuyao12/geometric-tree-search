"""Independent Source/raw/AST review authoring only; no reviewed source executed."""
import ast,hashlib,json,pathlib,symtable
R=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');A=R/'.gcts-active/arithmetic-Q-streamed-controls-source-20261014';O=R/'.gcts-active/arithmetic-Q-streamed-controls-independent-20261014'
raws={};refs=[];checks=[]
def pin(p,b):return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(p,expected=None):
 p=pathlib.Path(p);p=p if p.is_absolute() else R/p;b=p.read_bytes()
 if expected is not None:assert expected['sha256']==hashlib.sha256(b).hexdigest() and expected['bytes']==len(b);refs.append(expected)
 if str(p) in raws:assert raws[str(p)]==b
 raws[str(p)]=b;return b

def doc(p,expected=None):return json.loads(read(p,expected))
def walk(v):
 if isinstance(v,dict):
  if {'path','sha256','bytes'}<=set(v):read(v['path'],v);return
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)

def ck(n,v):assert v,n;checks.append(dict(check=n,passed=True))
def defs(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def assigns(s):
 out={}
 for n in ast.parse(s).body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:out[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
 return out
h=doc(A/'handoff-v1.json');walk(h);c=doc(h['contract']['path'],h['contract']);walk(c)
for role,p in c['inputs'].items():walk(doc(p['path'],p))
for key in ('integration','readiness','conformance'):
 p=h[key];walk(doc(p['path'],p))
source_text={k:read(p['path'],p).decode() for k,p in h['sources'].items() if k!='master'}
ck('exact handoff contract review seven-role maps',h['sources']==c['sources']==c['Source_review_ABI']['sources'] and len(h['sources'])==7)
ck('four named fixed inputs and exact11/10/six argv ABI',len(c['inputs'])==4 and c['ABI']['leaf_count']==11 and c['ABI']['owner_count']==10 and len(c['entrypoint']['argv'])==6)
ck('five Source-loaded modules fixed7 whole disclosure',c['ABI']['project_modules_raw_executed']==5 and c['ABI']['source_roles']==7)
ck('exact prospective20/60/512/90 unchanged',c['limits']==h['limits']=={'caller_seconds':90,'control_seconds':20,'peak_bytes':536870912,'whole_seconds':60})
ck('same original empty Gamma and theory scope',c['scientific_scope']['original_ordered_Gamma']==[] and c['scientific_scope']['induction_supported'] is False and c['scientific_scope']['native_accepted'] is False)
oldc=doc(c['parent_source_contract']['path'],c['parent_source_contract']);oldsrc=oldc['sources']
for k in ('kernel','catalogue','point_graph','master'):
 ck('unchanged original raw role/'+k,h['sources'][k]==oldsrc[k])
ck('exact old declaration raw identity retained',c['inputs']['declaration']==oldc['inputs']['declaration'])
w=source_text['worker'];ct=source_text['controls'];pt=source_text['payload'];wa=assigns(w)
ck('actual worker exact frozen source/input maps',wa['FROZEN_SOURCES']=={k:v for k,v in h['sources'].items() if k!='worker'} and wa['FROZEN_INPUTS']==c['inputs'])
ck('actual worker originals maps separate from new payload',wa['PROTOTYPE_SOURCE_PINS']==doc(c['inputs']['prototype_source_review']['path'])['sources'])
ck('generic supervisor and closer raw unchanged',c['ABI']['owner']['sha256']=='2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656' and c['ABI']['closer']['sha256']=='9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf')
ck('same-buffer raw Source load and metadata parse',"exec(compile(raw, record['path'], 'exec'), module.__dict__)" in w and 'parse the authenticated same raw buffer' in w)
ck('strict named metadata closure no historical arbitrary interpretation','documents={role:read(record) for role,record in plan[\'inputs\'].items()}' in w and 'for document in documents.values():authenticate(document)' in w)
ck('actual own module validator raw/MRO/property snapshots',"own_state=executable_state(own)" in w and 'for state in states:guard_fn(state)' in w and "for accessor in ('fget', 'fset', 'fdel')" in w)
ck('callback and invoking shim identity/code/default/cell anchors present', 'callback_anchor=function_signature(callback_fn)' in w and 'invoke_anchor=function_signature(invoke_fn)' in w and 'tuple((id(c),id(c.cell_contents))' in w)
ck('writer endpoint anchored around controls','writer_anchor=function_signature(writer_fn)' in w and 'sink_anchor=function_state(write_snapshot)' in ct and "if function_signature(writer_fn)!=writer_anchor" in w)
ck('payload one production graph and caller pair return',pt.count('graph_module.PointGraph(')==1 and 'guard();return result, graph' in pt and 'graph=track(owned_graph)' in ct)
ck('production controls do not construct another graph','graph=track(graph_module.PointGraph' not in ct and 'same actual payload-owned complete production graph' in ct)
ck('full initial snapshot safely written before release','prepared_pin=save(\'Q-preparation-provisional-v1.json\',prepared)' in w and "initial_record=save('Q-initial-state-witness-v2.json',prepared['initial_state'])" in w and 'prepared=None' in w)
ck('payload full-string serialization removed only after caller binding','text(result);guard()' not in pt and 'owned streamed preparation write' in pt)
ck('serializer bounded existing subtrees and no full model copy','if visits>512:return False' in w and 'if characters>32768:return False' in w and 'if child.bit_length()>4096:return False' in w and 'for start in range(0,len(value),32)' in w)
ck('every chunk/perfile/aggregate ceiling with inner and reserve gates','len(raw)<=4*1048576' in w and 'count<=MAX_METADATA and streamed_bytes[0]<=256*1048576' in w and "if time.perf_counter()>=deadline:raise TimeoutError('complete output stream exceeded shared20s')" in w)
ck('full independent rows rather than full24 duplicate oracle','for row in range(graph.height):' in ct and 'yield dict(factors=factors,base_count=base,excluded_legal=removed,count=base-len(removed))' in ct and 'require(rows==graph.height' in ct)
ck('zero unary binary literal relation matches all production factors','independent==production_domain(graph,row)' in ct and "elif a==1:" in ct and "elif a==2:" in ct and "bin(left&right).count('1') if different else 0" in ct)
ck('full initial and exact rollback byte EOF SHA comparison','stream.read(len(raw))==raw' in ct and "stream.read(1)==b''" in ct and "h.hexdigest()==record['sha256']" in ct and 'graph.rollback(root);guard();compare_snapshot(state_chunks(graph),root_record);guard()' in ct)
ck('all eight production state fields represented',set(c['serialization_protocol']['exact_state_fields'])=={'domains','excluded','marks','model_epoch','order','roots','selected_generations','totals'})
ck('complete after one actual master primitive only','first=next(graph.candidates(d.row));executor.step(first);guard()' in ct and 'one-canonical-scheduler-step-not-a-proof' in ct)
ck('capture freshness/full originalGamma conditions retained','free generalization variable in unused original hypothesis rejects' in ct and 'duplicate free-context occurrences do not weaken generalization condition' in ct and 'capture-avoiding literal fresh0 result' in ct)
ck('tiny scheduler zero/exclusion fixtures explicitly nonlogical','Tiny synthetic scheduling fixtures' in ct and 'temporary unproved sole-key exclusion' in ct and 'fixture_recipes_enter_production=False' in ct)
ck('unary source point footprint distinguished from binary port','not any(p[0]==3 for p in m)' in ct and "'duplicated second unary port rejected'" in ct)
ck('whole output witness closure propagated to evidence and receipt','complete_witness_output_closure=list(artifacts)' in w and 'stream_output_records_before_receipt=list(serialization_records)' in w)
ck('partial output no-prefix and late receipt withdrawal', 'partial_stream_paths=partial_stream_paths,accepted_prefix=False' in w and "Q-controls-result-withdrawn-v1.json" in w and 'final_receipt.rename(withdrawn)' in w)
ck('actual failure preserved and no provisional counts reused',h['prior_failure']['sha256']=='2c74d3ed4d02336033ab0bd512ab5e18f16bb886454b16c9f0e0ed6e5685a219' and c['feasibility']['provisional_11147_16200_not_accepted'] is True and '11147' not in w and '16200' not in w+ct+pt)
# Compare current callable bodies with exact old source definitions; parser only.
oldw=read(oldsrc['worker']['path'],oldsrc['worker']).decode();oldct=read(oldsrc['controls']['path'],oldsrc['controls']).decode();oldpt=read(oldsrc['payload']['path'],oldsrc['payload']).decode()
wd,owd=defs(w),defs(oldw);cd,ocd=defs(ct),defs(oldct);pd,opd=defs(pt),defs(oldpt)
unchanged_worker=[k for k in owd if owd[k]==wd.get(k)];changed_worker=[k for k in owd if owd[k]!=wd.get(k)]
ck('old13 worker utility definitions exactly preserved',len(unchanged_worker)==13 and set(changed_worker)=={'preflight','main'})
ck('controls untouched primitive helpers preserved',all(cd[k]==ocd[k] for k in ('require','text','function_state','methods','literal_decision')))
ck('payload unchanged endpoint utilities',all(pd[k]==opd[k] for k in ('require','text','function_state','effective_methods')))
# Lexical global-name check only, not a code or module execution.
for role in ('worker','controls','payload'):
 tree=ast.parse(source_text[role]);symtable.symtable(source_text[role],h['sources'][role]['path'],'exec');ck('whole selected Source syntax/symbol table/'+role,True)
# Precise blocking boundary: nested helper code is not anchored by outer cell IDs.
main=next(n for n in ast.parse(w).body if isinstance(n,ast.FunctionDef) and n.name=='main');nested={n.name:n for n in ast.walk(main) if isinstance(n,ast.FunctionDef)}
ck('confirmed nested predicates outside module executable snapshot','inner_tick' in nested and 'whole_tick' in nested and 'inner_tick' not in wd and 'whole_tick' not in wd)
ck('confirmed local predicate calls no own code/default guard','inner_tick()' in ast.get_source_segment(w,nested['source_guard']) and 'function_signature(inner_tick)' not in w and 'function_signature(whole_tick)' not in w)
for p,b in raws.items():assert pathlib.Path(p).read_bytes()==b
ck('all current exact raw inputs stable at final rehash',True)
blocker=dict(id='unsealed_local_rejection_predicate_code',priority='preactivation_blocker',worker_source=h['sources']['worker'],source_guard_line=nested['source_guard'].lineno,inner_tick_line=nested['inner_tick'].lineno,whole_tick_line=nested['whole_tick'].lineno,finding='Nested inner_tick/whole_tick carry final20s and55s/500MiB rejection predicates. Own executable snapshots cover module definitions but not these local functions. Outer callback/writer/shim signatures retain each closure cell and function object identity, but not the __code__/defaults/closure state of a function contained in a cell. A same-object predicate-code substitution can therefore remove a final deadline/reserve rejection while existing callback signatures stay equal.',boundary='Per-chunk20s checks and controls guard clocks do not cover the final stream pin/hash and outer return metadata boundary after the last yielded chunk.',repair='Preserve selectedV6; additive successor captures original direct function-state anchors for both local predicates before any delegation and rejects code/default/closure identity changes before invoking them or delegating the caller/writer/guard path. Do not alter grammar, graph, mathematical controls, budgets or old failure.',execution_demonstrated=False,author_confirmed_statically=True,ROOT_pre_activation_acknowledged=True)
f=dict(schema='independent-Q-streamed-controls-Source-findings-v1',author_identity='/root/arithmetic_induction',reviewer_identity='/root/hilbert_ordering_diagnosis',scope='arithmetic-Q-complete-preparation-controls',source_only=True,source_review_passed=False,source_ready=False,all_checks_passed=False,scientific_calls=0,project_imports=0,project_functions=0,tests_executed=0,semantic_evaluations=0,current_sources=h['sources'],source_contract=h['contract'],selected_handoff=pin(A/'handoff-v1.json',raws[str(A/'handoff-v1.json')]),checks=checks,check_count=len(checks),blockers=[blocker],raw_pin_mismatch_count=0,raw_reference_count=len(refs),raw_target_count=len(raws),final_rehash_count=len(raws),worker_AST_unchanged_defs=unchanged_worker,worker_AST_changed_defs=changed_worker,controls_AST_unchanged_defs=[k for k in ocd if ocd[k]==cd.get(k)],payload_AST_unchanged_defs=[k for k in opd if opd[k]==pd.get(k)],raw_targets=[pin(pathlib.Path(p),b) for p,b in sorted(raws.items())],whole_Source_read=['worker_v6 all458 lines','controls_v3 all310 lines','payload_v3 all82 lines','whole three declared original-to-selected patches','current contract/handoff/specification/integration/readiness/conformance','unchanged original kernel/catalogue/PointGraph/declaration scope and prior typed Source review','unchanged generic10 owner/closer receipt/readsite and resource ABI'],limitations=['Source review only; no production/control/helper/parser from reviewed project code executed.','Memory lifetime improvement is plausible, not measured fit or a causal allocation attribution. Unchanged catalogue still serializes its full model internally.','Literal per-row census is a separate producer-authored algorithm, not a distinct-author mathematical catalogue/domain admission or full candidate-key EOF list.','One real scheduler primitive and exact rollback plus tiny nonlogical fixtures are conformance controls, not theorem search.','No new preparation/control counts, target proof/native/full24/trajectory/PA/induction/RL acceptance, actual q or activation.','Earlier actual memory UNKNOWN preserved; source patches never reuse provisional counts or data.'])
b=(json.dumps(f,indent=2)+'\n').encode();fp=O/'streamed-Q-source-findings-v1.json';assert not fp.exists();fp.write_bytes(b);fpin=pin(fp,b)
review=dict(schema='ROOT-person-independent-primitive-source-review-v1',scope=c['Source_review_ABI']['scope'],author_identity='/root/arithmetic_induction',reviewer_identity='/root/hilbert_ordering_diagnosis',source_only=True,source_review_passed=False,all_checks_passed=False,source_ready=False,scientific_calls=0,sources=h['sources'],source_contract=h['contract'],findings=fpin,blocking_issue=blocker['id'],mathematical_acceptance_issued=False)
b=(json.dumps(review,indent=2)+'\n').encode();rp=O/'streamed-Q-typed-source-review-v1.json';assert not rp.exists();rp.write_bytes(b)
hand=dict(schema='independent-Q-streamed-controls-review-handoff-v1',findings=fpin,typed_source_review=pin(rp,b),source_ready=False,scientific_calls=0,requires_narrow_additive_local_predicate_guard_repair=True)
b=(json.dumps(hand,indent=2)+'\n').encode();hp=O/'handoff-v1.json';assert not hp.exists();hp.write_bytes(b)
print(json.dumps(dict(findings=fpin,typed=pin(rp,rp.read_bytes()),handoff=pin(hp,b),checks=len(checks),refs=len(refs),targets=len(raws),unchanged_worker=unchanged_worker),indent=2))
