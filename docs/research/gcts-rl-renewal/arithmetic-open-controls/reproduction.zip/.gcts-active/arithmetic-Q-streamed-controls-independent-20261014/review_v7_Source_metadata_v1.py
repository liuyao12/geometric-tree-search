"""Additive independent Source/raw/AST delta review only. No reviewed code executed."""
import ast,copy,difflib,hashlib,json,pathlib,symtable
R=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');A=R/'.gcts-active/arithmetic-Q-streamed-controls-source-20261014';O=R/'.gcts-active/arithmetic-Q-streamed-controls-independent-20261014'
raws={};refs=[];checks=[]
def pin(p,b):return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(p,expected=None):
 p=pathlib.Path(p);p=p if p.is_absolute() else R/p;b=p.read_bytes()
 if expected is not None:assert expected['sha256']==hashlib.sha256(b).hexdigest() and expected['bytes']==len(b);refs.append(expected)
 if str(p) in raws:assert raws[str(p)]==b
 raws[str(p)]=b;return b

def doc(p,expected=None):return json.loads(read(p,expected))
def walk(v):
 if isinstance(v,dict):
  if {'path','sha256','bytes'}<=set(v):read(v['path'],v);return
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)

def ck(n,v):assert v,n;checks.append(dict(check=n,passed=True))
def defs(t):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(t).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
h=doc(A/'handoff-v2.json');walk(h);c=doc(h['contract']['path'],h['contract']);walk(c)
oldh=doc(h['preserved_parent_handoff']['path'],h['preserved_parent_handoff']);oldc=doc(oldh['contract']['path'],oldh['contract']);walk(oldh);walk(oldc)
negative=doc(h['negative_findings']['path'],h['negative_findings']);walk(negative)
for field in ('integration','readiness','conformance'):p=h[field];walk(doc(p['path'],p))
for p in c['inputs'].values():walk(doc(p['path'],p))
ck('exact current7 Source maps and typed author partition',h['sources']==c['sources']==c['Source_review_ABI']['sources'] and len(h['sources'])==7 and c['Source_review_ABI']['author_identity']=='/root/arithmetic_induction' and c['Source_review_ABI']['scope']=='arithmetic-Q-complete-preparation-controls')
ck('only worker Source role changes from preservedV6',[k for k in h['sources'] if h['sources'][k]!=oldh['sources'][k]]==['worker'])
for k in ('ABI','inputs','limits','controls_scope','serialization_protocol','output_names','failure_outputs','scientific_scope','runtime'):
 ck('unchanged current contract field/'+k,c[k]==oldc[k])
ck('current entry source exactly V7',c['entrypoint']['worker']==h['sources']['worker'] and c['entrypoint']['argv'][2]==h['sources']['worker']['path'])
ck('source status actual0 retained',h['source_only'] is True and h['scientific_calls']==h['project_imports']==h['source_function_calls']==h['tests_executed']==0 and h['actual_successor_activation'] is False)
ck('negative historical review truthfully preserved',negative['source_review_passed'] is False and len(negative['blockers'])==1 and h['negative_findings']['sha256']=='a0dbaa6271cdf6b16581572785e1b1c138797054bada6fe5749ca036df451b19')
v6=read(oldh['sources']['worker']['path'],oldh['sources']['worker']).decode();v7=read(h['sources']['worker']['path'],h['sources']['worker']).decode();d6=defs(v6);d7=defs(v7)
ck('all16 non-main callables exactV6 AST',len([k for k in d6 if k!='main'])==16 and all(d6[k]==d7[k] for k in d6 if k!='main'))
# Independent complete module inverse after only declared helper anchor/check/call delta.
class Inverse(ast.NodeTransformer):
 def visit_Assign(self,n):
  if any(isinstance(t,ast.Name) and t.id in ('whole_tick_fn','whole_tick_anchor','inner_tick_fn','inner_tick_anchor') for t in n.targets):return None
  return self.generic_visit(n)
 def visit_If(self,n):
  if len(n.body)==1 and isinstance(n.body[0],ast.Raise):
   e=n.body[0].exc
   if isinstance(e,ast.Call) and e.args and isinstance(e.args[0],ast.Constant) and e.args[0].value in ('original own validator changed before local limit delegation','original whole_tick function/code/default/closure endpoint changed','original inner_tick function/code/default/closure endpoint changed'):return None
  return self.generic_visit(n)
 def visit_Name(self,n):
  if n.id in ('whole_tick_fn','inner_tick_fn'):n.id=n.id[:-3]
  return n
inverse=Inverse().visit(copy.deepcopy(ast.parse(v7)))
ck('whole selected module AST inverse exactlyV6',ast.dump(inverse,include_attributes=False)==ast.dump(ast.parse(v6),include_attributes=False))
root=ast.parse(v7);main=next(n for n in root.body if isinstance(n,ast.FunctionDef) and n.name=='main');nested={n.name:n for n in ast.walk(main) if isinstance(n,ast.FunctionDef)}
ck('anchors captured before any delegated Source calls','whole_tick_fn=whole_tick;whole_tick_anchor=function_signature(whole_tick_fn)' in v7 and 'inner_tick_fn=inner_tick;inner_tick_anchor=function_signature(inner_tick_fn)' in v7)
ck('all exact local rejection helper callsite counts',sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='whole_tick_fn' for n in ast.walk(main))==5 and sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='inner_tick_fn' for n in ast.walk(main))==3)
ck('no unguarded old helper calls remain',not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('whole_tick','inner_tick') for n in ast.walk(main)))
# Each call statement is immediately preceded by direct validator and helper checks.
checked_sites=[]
def bodycheck(node):
 for name,value in ast.iter_fields(node):
  if isinstance(value,list):
   for pos,item in enumerate(value):
    if isinstance(item,ast.Expr) and isinstance(item.value,ast.Call) and isinstance(item.value.func,ast.Name) and item.value.func.id in ('whole_tick_fn','inner_tick_fn'):
     ck('direct prechecks before '+item.value.func.id+'@'+str(item.lineno),pos>=2 and isinstance(value[pos-1],ast.If) and isinstance(value[pos-2],ast.If) and 'function_signature' in ast.unparse(value[pos-1].test) and 'validators.items()' in ast.unparse(value[pos-2].test));checked_sites.append(dict(helper=item.value.func.id,line=item.lineno))
    if isinstance(item,ast.AST):bodycheck(item)
  elif isinstance(value,ast.AST):bodycheck(value)
bodycheck(main)
ck('all eight precheck boundaries exhaustively covered',len(checked_sites)==8)
ck('signature binds exact direct predicate code/default/cells','fn.__code__' in v7 and "tuple((id(c),id(c.cell_contents))" in v7)
ck('writer final pin and cold final print boundaries covered',sum('whole_tick_fn'==z['helper'] and z['line']>450 for z in checked_sites)==2 and any(z['helper']=='whole_tick_fn' and 318<z['line']<337 for z in checked_sites))
# Selected file full parse and lexical binding review only.
symtable.symtable(v7,h['sources']['worker']['path'],'exec');ck('wholeV7 parser and symbol-table inspection',True)
for k in ('kernel','catalogue','point_graph','master'):
 ck('same original mathematical or master role/'+k,h['sources'][k]==oldh['sources'][k])
ck('same payload/controls/4 named metadata inputs',h['sources']['payload']==oldh['sources']['payload'] and h['sources']['controls']==oldh['sources']['controls'] and c['inputs']==oldc['inputs'])
# Source prose count typo is descriptive; exact equality check independently covers16.
prose_note='Author conformance label says15 unchanged non-main utilities; actual selected module has16 and all16 ASTs independently match. This descriptive count does not affect executable guards or consumed maps.'
for p,b in raws.items():assert pathlib.Path(p).read_bytes()==b
ck('all current exact raw targets stable at final rehash',True)
patch=''.join(difflib.unified_diff(v6.splitlines(True),v7.splitlines(True),fromfile=oldh['sources']['worker']['path'],tofile=h['sources']['worker']['path']))
pp=O/'independent-v6-v7-complete-delta.patch';assert not pp.exists();pp.write_text(patch);patchpin=pin(pp,pp.read_bytes())
f=dict(schema='independent-Q-streamed-controls-Source-findings-v2',author_identity='/root/arithmetic_induction',reviewer_identity='/root/hilbert_ordering_diagnosis',scope=c['Source_review_ABI']['scope'],source_only=True,source_review_passed=True,source_ready=True,all_checks_passed=True,scientific_calls=0,project_imports=0,project_functions=0,tests_executed=0,semantic_evaluations=0,actual_controls_or_preparation_accepted=False,current_sources=h['sources'],source_contract=h['contract'],selected_handoff=pin(A/'handoff-v2.json',raws[str(A/'handoff-v2.json')]),preserved_negative_findings=h['negative_findings'],preserved_negative_review=h['negative_review'],whole_parent_review_scope_retained=True,parent_raw_AST_storage_controls_checks=negative['checks'][:-3],checks=checks,check_count=len(checks),blockers=[],resolved_blocker='unsealed_local_rejection_predicate_code',current_helper_boundary_sites=checked_sites,whole_inverse_AST_equal=True,all16_other_callable_ASTs_unchanged=True,complete_independent_delta=patchpin,raw_pin_mismatch_count=0,raw_reference_count=len(refs),raw_target_count=len(raws),final_rehash_count=len(raws),raw_targets=[pin(pathlib.Path(p),b) for p,b in sorted(raws.items())],descriptive_limit=prose_note,limitations=negative['limitations']+['Review is conditional Source readiness only; generic owner/closer, official runtime, actual raw plans/reviews, full witnessed output closure, all14 actual resources and distinct-author mathematical admission remain future ROOT gates.','NegativeV6 is preserved and remains unactivated. The actual earlier memory failure is unchanged and no provisional counts/output are scientific inputs to this successor.'])
b=(json.dumps(f,indent=2)+'\n').encode();fp=O/'streamed-Q-source-findings-v2.json';assert not fp.exists();fp.write_bytes(b);fpin=pin(fp,b)
review=dict(schema='ROOT-person-independent-primitive-source-review-v1',scope=c['Source_review_ABI']['scope'],author_identity='/root/arithmetic_induction',reviewer_identity='/root/hilbert_ordering_diagnosis',source_only=True,source_review_passed=True,all_checks_passed=True,source_ready=True,scientific_calls=0,sources=h['sources'],source_contract=h['contract'],findings=fpin,mathematical_acceptance_issued=False,actual_controls_or_preparation_accepted=False)
b=(json.dumps(review,indent=2)+'\n').encode();rp=O/'streamed-Q-typed-source-review-v2.json';assert not rp.exists();rp.write_bytes(b);rpin=pin(rp,b)
hand=dict(schema='independent-Q-streamed-controls-review-handoff-v2',findings=fpin,typed_source_review=rpin,source_ready=True,scientific_calls=0,preserved_negative_findings=h['negative_findings'],actual_activation=False)
b=(json.dumps(hand,indent=2)+'\n').encode();hp=O/'handoff-v2.json';assert not hp.exists();hp.write_bytes(b)
print(json.dumps(dict(findings=fpin,typed=rpin,handoff=pin(hp,b),checks=len(checks),rawrefs=len(refs),targets=len(raws)),indent=2))
