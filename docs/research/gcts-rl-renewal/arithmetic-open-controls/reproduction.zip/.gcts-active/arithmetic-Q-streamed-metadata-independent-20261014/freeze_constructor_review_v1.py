"""Independent metadata/AST review freezer; never executes ROOT constructor."""
import ast
import hashlib
import json
from pathlib import Path
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def pin(path):
    p=Path(path).resolve();h=hashlib.sha256();n=0;before=p.stat()
    with p.open('rb') as stream:
        for raw in iter(lambda:stream.read(65536),b''):h.update(raw);n+=len(raw)
    after=p.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=n)

def save(name,value):
    with (HERE/name).open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    return pin(HERE/name)

def refs(value):
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:yield value
        for v in value.values():yield from refs(v)
    elif type(value) is list:
        for v in value:yield from refs(v)

def main():
    began=time.perf_counter();checks=[];raw=[]
    def check(value,label):
        checks.append(dict(name=label,passed=bool(value)))
        if not value:raise ValueError(label)
    source=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-ROOT-source-20261014/build_Q_controls_metadata_v2.py'
    contract_path=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-source-20261014/source-contract-v1.json'
    contract=json.loads(contract_path.read_text());worker_path=Path(contract['sources']['worker']['path'])
    source_text=source.read_text();source_ast=ast.parse(source_text);worker_text=worker_path.read_text();ast.parse(worker_text)
    direct=[pin(source),pin(contract_path),contract['sources']['worker']]
    for doc in (contract,*[json.loads(Path(p['path']).read_text()) for p in contract['inputs'].values()]):
        for r in refs(doc):
            actual=pin(r['path']);check(actual==r,'exact raw metadata pin '+r['path']);raw.append(r)
    imports={n.names[0].name.split('.')[0] for n in source_ast.body if isinstance(n,ast.Import)}
    imports|={n.module for n in source_ast.body if isinstance(n,ast.ImportFrom)}
    check(imports=={'hashlib','json','pathlib','shutil','sys'},'constructor imports only five declared stdlib modules')
    check(not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('exec','eval','compile','__import__') for n in ast.walk(source_ast)),
          'no Source execution/dynamic project import in constructor')
    check('subprocess' not in source_text and 'Popen' not in source_text and 'PointGraph(' not in source_text,
          'no owner/worker/Graph/scientific activation by metadata construction')
    calls={n.targets[0].id:n.value for n in ast.walk(source_ast) if isinstance(n,ast.Assign) and len(n.targets)==1
        and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name)
        and n.value.func.id=='dict'}
    leaf_fields={k.arg for k in calls['leaf'].keywords};owner_fields={k.arg for k in calls['owner'].keywords}
    check(leaf_fields==set(contract['ABI']['leaf_fields']) and len(leaf_fields)==11,'literal leaf11 exact field ABI')
    check(owner_fields=={'schema','stage','runtime_binary','worker','argv','worker_receipt','limits','closure','ROOT_source_review','scope'},'literal owner10 exact field ABI')
    check(ast.literal_eval(next(k.value for k in calls['leaf'].keywords if k.arg=='schema'))==contract['ABI']['leaf_schema'],
          'literal worker schema matches frozen v6')
    check(ast.literal_eval(next(k.value for k in calls['owner'].keywords if k.arg=='schema'))==contract['ABI']['owner_schema'],
          'literal generic owner schema matches exact owned Source')
    check("runtime=dict(binary=runtime0['executable'],resource_extension=runtime0['resource_ext'],python_version=[3,9,6],platform='darwin')" in source_text,
          'contract runtime keys translate to strict worker runtime4')
    check("'ROOT-Q-open-empty-Gamma-preparation-controls'" in source_text and "COMMAND='ROOT-Q-open-empty-Gamma-preparation-controls'" in worker_text,
          'literal command and six argv match current leaf')
    check("owner_plan_path=str(owner_path),output_directory=str(output)" in source_text and "output/'Q-controls-result-v1.json'" in source_text,
          'current plan path/output path/receipt fields match worker final name')
    check("DEST=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-progress-20261014'" in source_text and 'ROOT=Path(__file__).resolve().parents[2]' in source_text,
          'fresh flat namespace has exact repository anchor')
    check('not DEST.exists()' in source_text and 'DEST.mkdir()' in source_text and "p.open('x')" in source_text,
          'fresh namespace and exclusive plan/review outputs')
    check("peer['sources']==sources" in source_text and "peer['author_identity']=='/root/arithmetic_induction'" in source_text
        and "peer['reviewer_identity']!='/root/arithmetic_induction'" in source_text,
          'future genuine peer exact seven-source review required before destination creation')
    check("peer['source_only'] is True" in source_text and "peer['source_review_passed'] is True" in source_text and "peer['scientific_calls']==0" in source_text,
          'Source review gate does not consume scientific/control success as authorization')
    check("named=[(contract_path,contract),(peer_path,peer)]" in source_text and "for p,value in named:collect(closure,[pin(p),value])" in source_text,
          'only explicit contract/peer/four input roots decoded; descendant records remain raw leaves')
    check("collect(closure,[sources,inputs,runtime,runtime0,pin(__file__)])" in source_text,
          'all current direct sources/input/runtime/self pins closed')
    check("closure=[closure[k] for k in sorted(closure)]" in source_text and "actual['path'] not in closure or closure[actual['path']]==actual" in source_text,
          'canonical unique sorted ABS worker closure matches literal preflight lookup')
    check('leaf_pin=write(worker_path,leaf);collect(closure,leaf_pin)' in source_text,
          'owner closes actual leaf without circular leaf self/owner pin')
    check("def lexical(record):return pin(record['path'],relative=True)" in source_text and "closure=[lexical(closure[k]) for k in sorted(closure)]" in source_text,
          'owner closure uses exact ROOT-relative spelling matching generic pin and worker normalize')
    check("ROOT_source_review=lexical(review_pin)" in source_text and "DEST/'ROOT-source-review-v1.json'" in source_text,
          'local ROOT review path spelling matches owner and leaf authentication')
    check('for record in closure.values():assert pin(record[\'path\'])==record' in source_text,
          'constructed dependency bytes revalidated after metadata output')
    generic=ROOT/'.gcts-active/equality-receptor-family-controls-progress-v2-20261014'
    owner=pin(generic/'run_owned_bridge_v2.py');closer=pin(generic/'close_stage_decision_v1.py')
    check((owner['sha256'],owner['bytes'])==(contract['ABI']['owner']['sha256'],contract['ABI']['owner']['bytes']),
          'actual selected generic owner bytes exact reviewed2df')
    check((closer['sha256'],closer['bytes'])==(contract['ABI']['closer']['sha256'],contract['ABI']['closer']['bytes']),
          'actual selected generic closer bytes exact reviewed9fe')
    owner_text=Path(owner['path']).read_text();closer_text=Path(closer['path']).read_text()
    check('ROOT = HERE.parents[1]' in owner_text and 'ROOT=HERE.parents[1]' in closer_text,
          'copied generic scripts use valid flat destination anchor')
    check("review['source_review_passed']" in owner_text and "plan['stage'] in ('translation','preparation','native','replay')" in owner_text,
          'generated preparation review/plan match generic owner admission fields')
    check("worker_receipt_path=ROOT/plan['worker_receipt']" in owner_text and "stage+'-plan-v1.json'" in closer_text,
          'receipt/stage plan names match owner/closer consumption')
    check("actual_execution_accepted=False,mathematical_catalogue_admitted=False,target_proof_accepted=False" in source_text,
          'metadata result issues no actual resource/theorem/scientific acceptance')
    check(contract['limits']==dict(control_seconds=20,whole_seconds=60,caller_seconds=90,peak_bytes=536870912),
          'fixed20/60/90/512 preserved by pass-through limits')
    check(not (ROOT/'.gcts-active/arithmetic-Q-streamed-controls-progress-20261014').exists(),
          'prospective namespace absent at review; constructor not executed by reviewer')
    findings=save('metadata-constructor-Source-findings-v1.json',dict(schema='Q-streamed-constructor-independent-Source-findings-v1',
        author_identity='/root',reviewer_identity='/root/arithmetic_induction',scope='arithmetic-Q-streamed-metadata-constructor-only',
        source_only=True,source_review_passed=True,scientific_calls=0,project_imports=0,project_function_calls=0,
        constructor_calls=0,scientific_acceptance=False,actual_plan_review_performed=False,all_checks_passed=True,mismatches=[],
        source=pin(source),current_contract=pin(contract_path),worker_ABI_reference=contract['sources']['worker'],
        sources=contract['sources'],generic_owner=owner,generic_closer=closer,checks=checks,raw_pin_occurrences=raw,
        actual_worker_Source_review_separate=True,
        pending_worker_issue='Distinct reviewer diagnosis reported unanchored nested inner_tick/whole_tick same-object code replacement in worker v6. This constructor-only finding does not grant v6 worker readiness. A future worker/contract successor requires exact updated Source review before metadata construction/activation.',
        trust_scope=['Constructor takes explicit current contract and genuine peer paths; exact caller paths/raw epoch still need ROOT saved-plan validation.',
            'Copy source paths currently have exact2df/9fe bytes. Constructor records resulting copies; this review pins selected raw parents rather than asserting an unbounded future mutable copy origin.',
            'Metadata helper uses standard JSON reads/assertions and trusted stdlib, not scientific execution. No -O invocation or independent filesystem adversary model is approved.',
            'I authored the worker. This record independently reviews only ROOT-authored constructor; it is not a distinct-author worker or semantic review.'],
        metadata_seconds_before_write=time.perf_counter()-began))
    review=save('metadata-constructor-typed-Source-review-v1.json',dict(schema='independent-Q-streamed-metadata-constructor-Source-review-v1',
        scope='arithmetic-Q-streamed-metadata-constructor-only',author_identity='/root',reviewer_identity='/root/arithmetic_induction',
        source_only=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,source=pin(source),
        current_contract=pin(contract_path),worker_ABI_reference=contract['sources']['worker'],findings=findings,
        limits='Constructor-only; worker independent Source review, actual saved metadata and actual owned/caller gates remain separate.'))
    integration=save('integration-v1.json',dict(schema='private-source-review-integration-v1',files=[pin(HERE/'freeze_constructor_review_v1.py'),findings,review],
        source_only=True,scientific_calls=0,private_only=True))
    handoff=save('handoff-v1.json',dict(schema='Q-streamed-constructor-Source-review-handoff-v1',source_only=True,scientific_calls=0,
        source_review_passed=True,author_identity='/root',reviewer_identity='/root/arithmetic_induction',review=review,
        findings=findings,integration=integration,actual_worker_readiness_granted=False,actual_metadata_constructed=False,
        pending='V6 worker local helper guard issue and genuine future peer-review prerequisite.'))
    print(json.dumps(dict(handoff=handoff,review=review,findings=findings,checks=len(checks),raw_pin_occurrences=len(raw),scientific_calls=0)))

if __name__=='__main__':main()
