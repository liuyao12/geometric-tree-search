"""Raw JSON/AST successor applicability only; no constructor/worker call."""
import ast
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-source-20261014'

def pin(path):
    raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    with (HERE/name).open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    return pin(HERE/name)

def main():
    old=json.loads((SOURCE/'source-contract-v1.json').read_text())
    current=json.loads((SOURCE/'source-contract-v2.json').read_text())
    handoff=json.loads((SOURCE/'handoff-v2.json').read_text())
    review=json.loads((HERE/'metadata-constructor-typed-Source-review-v1.json').read_text())
    constructor=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-ROOT-source-20261014/build_Q_controls_metadata_v2.py'
    text=constructor.read_text();ast.parse(text)
    checks=[]
    def check(value,label):
        checks.append(dict(name=label,passed=bool(value)))
        if not value:raise ValueError(label)
    check(pin(constructor)==review['source'],'same ROOT-authored constructor bytes')
    for key in ('ABI','schema','inputs','limits','runtime','output_names','failure_outputs','output_closure','serialization_protocol','scientific_scope'):
        check(old[key]==current[key],'unchanged contract '+key)
    check(set(current['sources'])==set(old['sources']) and len(current['sources'])==7 and len(current['inputs'])==4,
          'exact same seven source/four input roles')
    check(all(current['sources'][r]==old['sources'][r] for r in current['sources'] if r!='worker'),
          'six nonworker pins exact; worker is sole executable-map successor')
    check(current['sources']['worker']==handoff['sources']['worker']==pin(SOURCE/'arithmetic_Q_streamed_controls_worker_v7.py'),
          'actual current worker-v7 raw pin')
    check(current['Source_review_ABI']['sources']==current['sources'] and current['entrypoint']['worker']==current['sources']['worker'],
          'current exact typed review/entrypoint source map')
    check(current['entrypoint']['command']==old['entrypoint']['command'] and current['entrypoint']['argv'][3:]==old['entrypoint']['argv'][3:],
          'unchanged literal command/absolute leaf-owner argument ABI')
    check("def main(peer_path,contract_path):" in text and "sources=contract['sources'];inputs=contract['inputs'];limits=contract['limits'];runtime0=contract['runtime']" in text,
          'constructor explicitly consumes selected current contract and peer paths without stale literal worker binding')
    check("peer['sources']==sources" in text and "peer['source_review_passed'] is True" in text,
          'requires actual genuine positive current seven-map peer, not preserved negative-v6 review')
    check("DEST=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-progress-20261014'" in text
        and "owner_path=DEST/'preparation-plan-v1.json'" in text and "output=DEST/'worker-output-v1'" in text,
          'identical exclusive flat output/plan anchors')
    note=save('metadata-constructor-applicability-note-v2.json',dict(schema='Q-streamed-metadata-constructor-v2-applicability-note',
        author_identity='/root',reviewer_identity='/root/arithmetic_induction',scope='constructor-only-successor-applicability',
        source_only=True,source_review_passed=True,scientific_calls=0,project_imports=0,project_function_calls=0,
        constructor_calls=0,worker_calls=0,actual_metadata_constructed=False,actual_plan_review_performed=False,
        scientific_acceptance=False,all_checks_passed=True,mismatches=[],source=pin(constructor),
        prior_constructor_review=pin(HERE/'metadata-constructor-typed-Source-review-v1.json'),
        current_handoff=pin(SOURCE/'handoff-v2.json'),current_contract=pin(SOURCE/'source-contract-v2.json'),
        current_worker=current['sources']['worker'],current_sources=current['sources'],checks=checks,
        schemas=dict(leaf=current['ABI']['leaf_schema'],owner=current['ABI']['owner_schema'],contract=current['schema']),
        counts=dict(leaf=11,owner=10,sources=7,inputs=4,argv=6),limits=current['limits'],
        remaining='ROOT must select the exact current positive distinct-worker Source review and contract-v2 paths, then independently validate actual constructed saved plans. This note does not execute constructor, review the worker independently, or authorize/accept scientific controls.'))
    integration=save('integration-v2.json',dict(schema='private-source-review-integration-v2',source_only=True,scientific_calls=0,
        files=[pin(HERE/'freeze_constructor_applicability_v2.py'),note,pin(HERE/'handoff-v1.json'),pin(HERE/'integration-v1.json')],private_only=True))
    handoff_pin=save('handoff-v2.json',dict(schema='Q-streamed-constructor-successor-applicability-handoff-v2',
        source_only=True,scientific_calls=0,source_review_passed=True,scope='constructor-only',applicability_note=note,
        integration=integration,current_contract=pin(SOURCE/'source-contract-v2.json'),current_worker=current['sources']['worker'],
        prior_review_unchanged=pin(HERE/'metadata-constructor-typed-Source-review-v1.json'),actual_metadata_constructed=False))
    print(json.dumps(dict(handoff=handoff_pin,note=note,checks=len(checks),scientific_calls=0)))

if __name__=='__main__':main()
