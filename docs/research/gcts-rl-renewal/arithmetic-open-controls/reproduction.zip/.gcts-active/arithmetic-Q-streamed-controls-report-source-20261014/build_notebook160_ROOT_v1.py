"""Pure saved-data projection: no kernel, graph, catalogue, search or learner."""
import gzip
import hashlib
import json
import pathlib
import shutil

ROOT = pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
PUB = pathlib.Path('/private/tmp/gcts-family-router-publish-20261010')
HERE = pathlib.Path(__file__).resolve().parent
PROGRESS = ROOT / '.gcts-active/arithmetic-Q-streamed-controls-progress-20261014'
OUTPUT = PROGRESS / 'worker-output-v1'
ROUTE = pathlib.Path('docs/research/gcts-rl-renewal/arithmetic-open-controls')
DEST = PUB / ROUTE

def read(path):
    return json.loads(path.read_bytes())

def pin(path):
    body = path.read_bytes()
    return {'path':str(path),'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}

def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')

def term(value):
    if value[0] == 'var':
        return value[1]
    assert value[0] == 'fun'
    name, arguments = value[1:]
    if name == 'zero':
        assert arguments == []
        return '0'
    if name == 'succ':
        assert len(arguments) == 1
        return 'S\\bigl(' + term(arguments[0]) + '\\bigr)'
    assert name == 'add' and len(arguments) == 2
    return '\\bigl(' + term(arguments[0]) + '+' + term(arguments[1]) + '\\bigr)'

def formula(value):
    if value[0] == 'eq':
        return term(value[1]) + '=' + term(value[2])
    assert value[0] == 'all'
    return '\\forall ' + value[1] + '\\;\\bigl(' + formula(value[2]) + '\\bigr)'

old_path = ROOT / '.gcts-active/arithmetic-Q-controls-progress-20261014/ROOT-actual-Q-controls-failure-disposition-v1.json'
first = read(old_path)
current_path = PROGRESS / 'ROOT-actual-Q-streamed-controls-disposition-v1.json'
current = read(current_path)
review_path = ROOT / '.gcts-active/arithmetic-Q-streamed-controls-saved-independent-20261014/findings-v1.json'
review = read(review_path)
controls = read(OUTPUT / 'Q-controls-provisional-v1.json')
prepared = read(OUTPUT / 'Q-preparation-provisional-v1.json')
initial = read(OUTPUT / 'Q-initial-state-witness-v2.json')
after = read(OUTPUT / 'Q-after-one-step-state-v2.json')
assert current['ROOT_complete_scoped_controls_accepted'] and controls['completed']
assert controls['control_count'] == len(controls['tests']) == 36
assert len(initial['domains']) == len(after['domains']) == 24
assert initial == prepared['initial_state']
assert controls['complete_production_snapshots'][1]['decision']['kind'] == 'dead'
assert controls['complete_production_snapshots'][1]['decision']['row'] == 0
assert after['domains'][0]['count'] == 0 and after['totals'][0] == 0 and after['totals'][23] == 1
assert not current['catalogue_mathematically_admitted'] and current['target_searches'] == 0

final = dict(current)
final.update(schema='ROOT-Q-actual-complete-producer-controls-reconciled-disposition-v2',
             inherited_first_disposition=pin(current_path), independent_saved_review=pin(review_path),
             independent_saved_review_pending=False, independent_saved_reconciliation_completed=True,
             independent_mathematical_replay_performed=False)
final_path = PROGRESS / 'ROOT-actual-Q-streamed-controls-reconciled-disposition-v2.json'
assert not final_path.exists() and not DEST.exists()
write(final_path, final)
DEST.mkdir()
for name in ('reader.html','reader.css','viewer.js'):
    shutil.copyfile(HERE / name, DEST / name)
html = (DEST / 'reader.html').read_text().replace('Q streamed controls · Pending saved records','Notebook 160 · Quantified arithmetic controls')
html = html.replace('PRIVATE SOURCE SCAFFOLD · saved-data presentation only','<a href="../index.html">Research notebook</a> · NOTEBOOK 160 · <a href="../receptor-comparison/reader.html">Matched geometry comparison</a>')
html = html.replace('<h1>Q streamed controls</h1>','<h1>Quantified arithmetic now fits the calibration limits.</h1>')
cells = []
for row, (total, domain) in enumerate(zip(after['totals'], after['domains'])):
    kind = 'dead-cell' if total < 1 and domain['count'] == 0 else 'filled-cell' if total == 1 else ''
    cells.append('<div class="state-cell '+kind+'">\\(r='+str(row)+'\\)<br>\\(t='+str(total)+'\\)<br>\\(d='+str(domain['count'])+'\\)</div>')
mechanical = '<section id="mechanical"><h2>A filled target row still needs valid predecessors.</h2><p>The one recorded canonical control step placed unary generalization at \\(r=23\\), referring to the still-empty row \\(r=0\\). The resulting full graph had a global dead end at row \\(0\\). Complete rollback restored the initial state byte for byte. This is a mechanical control observation; no proof search or checked target proof ran.</p><div class="state-grid">'+''.join(cells)+'</div><p class="muted">Here \\(t\\) is saved occupancy and \\(d\\) is the full saved candidate count. Red marks an active point with degree zero; teal marks the occupied target point. The boxes arrange recorded rows for reading, and add no geometric validity test. Every row remains represented.</p><p><a href="evidence/Q-after-one-step-state-v2.json.gz">Complete after-step state</a> · <a href="evidence/Q-after-one-step-oracle-domains-v2.json.gz">Separate complete literal domain record</a></p></section>'
html = html.replace('<section id="controls">', mechanical + '\n<section id="controls">')
(DEST / 'reader.html').write_text(html)
with (DEST / 'reader.css').open('a') as stream:
    stream.write('\n.state-grid{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:.5rem}.state-cell{border:1px solid #d7dee4;border-radius:8px;padding:.5rem;min-width:0;font-size:.8rem;overflow:auto}.dead-cell{border:3px solid #a63b36;background:#fff0ed}.filled-cell{border:3px solid #16887e;background:#edf8f5}@media(max-width:760px){.state-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}\n')

def attempt(label, record, raw_path, accepted, status, inner):
    return dict(label=label,status=status,scope=record['scope'],stage_completed=accepted,
                ROOT_scoped_controls_accepted=accepted,resource_accepted=accepted,inner_seconds=inner,
                owned_postwrite_seconds=record['owned_seconds'],caller_observed_seconds=record['caller_seconds'],
                caller_finish_margin_seconds=1,peak_bytes=record['conditional_peak_bytes'],
                record_pin=pin(raw_path),evidence_href='qualification.json' if accepted else 'prior-memory-failure.json')

packet = read(HERE / 'summary.json')
packet.update(attachment_status='attached',ROOT_presentation_pin=pin(final_path),
              lead='The streamed successor completed \\(36\\) finite controls and \\(6\\) serialization fixtures with every required row retained. The observed peak was about \\(382\\,\\mathrm{MiB}\\), within the original \\(512\\,\\mathrm{MiB}\\) cap. The earlier memory failure remains attached. Mathematical catalogue admission and theorem search are the next gates.',
              status_text='Complete producer controls and owned resources accepted; independent saved reconciliation passed. Target proofs: none. Mathematical catalogue admission: pending.',
              attempts=[attempt('First cold preparation',first,old_path,False,'UNKNOWN: memory limit exceeded',None),
                        attempt('Streamed successor v7',final,final_path,True,'Complete producer controls / resources',final['inner_seconds'])],
              initial_domains=[dict(row=row,count=d['count'],raw_href='evidence/Q-initial-state-witness-v2.json.gz') for row,d in enumerate(initial['domains'])],
              initial_domains_complete=True,initial_domains_raw_href='evidence/Q-initial-oracle-domains-v2.json.gz',
              control_records=[dict(index=i,label=label,saved_outcome='passed in completed producer control return',scope='Producer-authored finite side-condition/domain/rollback/nonlogical-fixture control; no theorem or mathematical catalogue admission.',record=dict(index=i,label=label,completed_return=True),raw_href='evidence/Q-controls-provisional-v1.json') for i,label in enumerate(controls['tests'])],
              reported_control_count=36,complete_control_records_attached=True,
              control_scope_text='All saved control labels are shown. Six additional bounded serializer fixtures are recorded separately. Complete raw initial/after-step arrays and byte-exact rollback were reconciled from saved evidence; this is not an independent mathematical kernel replay.',
              unary_probe=dict(probe_kind='actual_unary_footprint_not_proof',source_fact_or_selected_claimed=False,
                               actual_controls_record_pin=pin(OUTPUT / 'Q-controls-provisional-v1.json'),unary_placement=controls['unary_placement'],
                               output_formula_latex=formula(controls['unary_placement']['command']['formula']),raw_href='evidence/Q-controls-provisional-v1.json'),
              evidence_links=[dict(href=href,label=label) for href,label in [
                  ('qualification.json','ROOT scoped completion and resource record'),
                  ('independent-saved-review.json','Independent whole saved-output reconciliation'),
                  ('evidence/Q-controls-result-v1.json','Complete worker receipt'),
                  ('evidence/Q-controls-evidence-v1.json','Source/clock/complete-witness closure'),
                  ('evidence/Q-preparation-provisional-v1.json.gz','Complete producer catalogue and initial state; mathematical admission pending'),
                  ('prior-memory-failure.json','Earlier unaccepted memory failure'),
                  ('source-rejection-v6.json','Preserved wrapper Source rejection before v7'),
                  ('benchmark-memo.html','Prospective existing-Incident transfer benchmark'),
                  ('broadening-specification.json','Separate proposed equality / universal-instantiation inventory'),
                  ('reproduction.zip','Complete task Source and saved-data reproduction package')]])
write(DEST / 'summary.json', packet)
shutil.copyfile(final_path, DEST / 'qualification.json')
shutil.copyfile(old_path, DEST / 'prior-memory-failure.json')
shutil.copyfile(review_path, DEST / 'independent-saved-review.json')
shutil.copyfile(ROOT / '.gcts-active/arithmetic-Q-streamed-controls-independent-20261014/streamed-Q-typed-source-review-v1.json',DEST / 'source-rejection-v6.json')
shutil.copyfile(ROOT / '.gcts-active/equality-receptor-heldout-benchmark-design-source-20261014/benchmark-memo-v1.html',DEST / 'benchmark-memo.html')
shutil.copyfile(ROOT / '.gcts-active/equality-receptor-family-broadening-design-source-20261014/source-specification-v2.json',DEST / 'broadening-specification.json')
(DEST / 'evidence').mkdir()
for path in sorted(OUTPUT.iterdir()):
    if path.stat().st_size > 1000000:
        with path.open('rb') as source, (DEST / 'evidence' / (path.name+'.gz')).open('wb') as target:
            with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0) as compressed:
                shutil.copyfileobj(source,compressed)
    else:
        shutil.copyfile(path, DEST / 'evidence' / path.name)
write(HERE / 'ROOT-display-projection-v1.json',dict(schema='ROOT-notebook160-saved-projection-v1',scientific_calls=0,
     source_inputs=[pin(old_path),pin(final_path),pin(review_path),pin(OUTPUT / 'Q-controls-provisional-v1.json'),pin(OUTPUT / 'Q-initial-state-witness-v2.json'),pin(OUTPUT / 'Q-after-one-step-state-v2.json')],
     actual_unary_record_exactly_copied=True,initial_rows=24,control_records=36,whole_raw_witnesses_copied=True,
     source_only_research_proposals=True,mathematical_catalogue_admitted=False,target_proofs=0))
print(json.dumps({'route':str(DEST),'controls':36,'rows':24,'target_proofs':0,'unary_probe_only':True}))
