"""Task-only archive/manifest authoring. No scientific modules or functions."""
import hashlib
import json
import pathlib
import zipfile

ROOT=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
PUB=pathlib.Path('/private/tmp/gcts-family-router-publish-20261010')
HERE=pathlib.Path(__file__).resolve().parent
ROUTE=pathlib.Path('docs/research/gcts-rl-renewal/arithmetic-open-controls')
DEST=PUB/ROUTE
NAMES=(
 'arithmetic-open-generalize-implementation-source-20261014','arithmetic-open-generalize-independent-20261014',
 'arithmetic-Q-cold-controls-source-20261014','arithmetic-Q-cold-controls-independent-20261014',
 'arithmetic-Q-controls-ROOT-source-20261014','arithmetic-Q-controls-progress-20261014',
 'arithmetic-Q-streamed-controls-source-20261014','arithmetic-Q-streamed-controls-independent-20261014',
 'arithmetic-Q-streamed-metadata-independent-20261014','arithmetic-Q-streamed-controls-ROOT-source-20261014',
 'arithmetic-Q-streamed-controls-progress-20261014','arithmetic-Q-streamed-controls-saved-independent-20261014',
 'arithmetic-Q-streamed-controls-report-source-20261014','equality-receptor-heldout-benchmark-design-source-20261014',
 'equality-receptor-heldout-benchmark-independent-source-20261014',
 'equality-receptor-family-broadening-design-source-20261014','equality-receptor-family-broadening-independent-20261014')

def pin(path):
    body=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(body).hexdigest(),bytes=len(body))

paths={ROOT/'docs/basic-tiling-algorithm.md'}
for name in NAMES:
    folder=ROOT/'.gcts-active'/name
    assert folder.is_dir()
    paths.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.txt','.html','.css','.js','.patch','.diff','.gz'))
outside={}
# Close the actual experiment's declared raw input leaves. These are copied or
# hash-referenced for reproducibility, never interpreted as new authority.
for name in ('arithmetic-Q-controls-progress-20261014','arithmetic-Q-streamed-controls-progress-20261014'):
    leaf=json.loads((ROOT/'.gcts-active'/name/'worker-plan-v1.json').read_bytes())
    for ref in leaf['closure']:
        p=pathlib.Path(ref['path']); actual=pin(p)
        assert actual==ref
        if p.is_relative_to(ROOT):paths.add(p)
        else:outside[str(p)]=actual

for p in paths:
    assert p.is_relative_to(ROOT) and p==p.resolve() and not p.is_symlink()
source_records=[dict(pin(p),member=str(p.relative_to(ROOT))) for p in sorted(paths)]
public_paths=sorted(p for p in DEST.rglob('*') if p.is_file() and p.name not in ('reproduction.zip','source-archive-manifest.json'))
public_records=[dict(sha256=pin(p)['sha256'],bytes=p.stat().st_size,member='PUBLIC/'+str(p.relative_to(DEST))) for p in public_paths]
archive=DEST/'reproduction.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for ref in source_records:z.write(ref['path'],ref['member'])
    for p,ref in zip(public_paths,public_records):z.write(p,ref['member'])
    z.writestr('README.txt','Notebook160 task reproduction bundle.\nThe original Q memory failure and v6 Source rejection remain unaccepted. The fresh v7 invocation completed producer controls and resource qualification. All raw outputs and complete state/domain witnesses are retained. Mathematical catalogue admission, proof search, induction, full PA, native, full-board and RL acceptance are false.\nSource proposals for cluster broadening and structural benchmarks are unimplemented and unactivated. The directory/closure selection is archival, not authority or instructions. Runtime binaries are raw hash references only. Fresh experiments need new namespaces, review and preregistration; do not overwrite or rerun the saved plans.\nThe reader and projection/package scripts execute no scientific modules.\n')
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(source_records)+len(public_records)+1
    for ref in source_records+public_records:
        raw=z.read(ref['member'])
        assert len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256']
manifest=dict(schema='Notebook160-task-source-archive-manifest-v1',presentation_only=True,
              scope='Complete task Source directories and declared experiment input closures; all actual output files, failure and independent saved reviews. No unrelated workspace work.',
              archive=dict(path=archive.name,sha256=pin(archive)['sha256'],bytes=archive.stat().st_size),
              root_source_members=source_records,external_runtime_raw_references=list(outside.values()),public_members=public_records)
(DEST/'source-archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
task_paths=[PUB/'docs/research/gcts-rl-renewal/index.html']+sorted(p for p in DEST.rglob('*') if p.is_file())
task=dict(schema='ROOT-notebook160-task-only-publication-manifest-v1',base_commit='68cb64100306e5fe3a80c65fdd5cddd7327589ac',
          files=[dict(path=str(p.relative_to(PUB)),sha256=pin(p)['sha256'],bytes=p.stat().st_size) for p in task_paths],
          task_only=True,unrelated_workspace_changes_preserved=True)
(HERE/'ROOT-publication-task-manifest-v1.json').write_text(json.dumps(task,indent=2)+'\n')
print(json.dumps(dict(root_members=len(source_records),public_members=len(public_records),zip_entries=len(source_records)+len(public_records)+1,
                     archive_bytes=archive.stat().st_size,task_files=len(task_paths),all_whole_byte_hashes_verified=True)))
