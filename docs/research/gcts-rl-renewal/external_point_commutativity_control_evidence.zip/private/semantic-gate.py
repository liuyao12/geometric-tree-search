"""Pre-query independent full model binding; uses the frozen independent auditor."""
import copy,hashlib,json,resource,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'research/gcts-rl-renewal'))
from external_point_commutativity_audit import reconstruct,load,need,sha,packed
OUT=Path(__file__).resolve().parent
began=time.perf_counter();plan=load(OUT/'plan.json');source=load(ROOT/plan['inputs_role']['spec']);cat=load(ROOT/plan['inputs_role']['catalog'])
for rel,pin in {**plan['sources'],**plan['inputs']}.items():need(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==pin['sha256'],'pinned input/source')
reg_hash=hashlib.sha256((ROOT/plan['inputs_role']['registry']).read_bytes()).hexdigest();hashes={}
for n in plan['lengths']:
    spec=copy.deepcopy(source['case']);spec['length']=n;point=reconstruct(spec,cat,reg_hash);actual=load(OUT/('point-'+str(n)+'.json.gz'))
    need(point==actual,'entire independent candidate/semantic reconstruction');hashes[str(n)]=sha(point['semantic'])
    if n==12:
        original=load(ROOT/plan['inputs_role']['baseline'])['model']
        for key,want in [('placements',point['placements']),('roots',point['roots']),('initial_marks',point['initial_marks']),('catalog',point['semantic']['injective_catalog']),('inference_rules',point['rules']),('domains',point['semantic']['row_domains'])]:need(original[key]==want,'same original12 '+key)
    del point,actual
peer=ROOT/'.gcts-active/commutativity13-20261011';binding=load(peer/'binding13.json.gz');peerplan=load(peer/'preflight-plan.json');summary=load(peer/'preflight-summary.json')
# The peer binding uses the agreed semantic object directly, rather than a model wrapper.
need(sha(binding)==hashes['13'],'separate13 producer exact semantic agreement')
evidence={str(p.relative_to(ROOT)):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in [peer/'binding13.json.gz',peer/'preflight-plan.json',peer/'preflight-summary.json',peer/'preflight-sources.zip']}
seconds=time.perf_counter()-began;peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
need(seconds<180 and peak<=536870912,'semantic gate resource')
result=dict(status='passed_exact_12_and_13_semantic_hash_agreement',semantic_sha256=hashes,peer_evidence=evidence,
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),auditor_source_sha256=plan['sources']['research/gcts-rl-renewal/external_point_commutativity_audit.py']['sha256'],
    scope='Entire independent plain-data reconstruction12/13, original12 preflight agreement, separate13 full semantic producer agreement; no target search or solver query.',
    seconds_before_final_write=seconds,peak_rss_bytes=peak)
(OUT/'cross-track.json').write_bytes(packed(result));print(json.dumps(result))
