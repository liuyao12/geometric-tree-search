"""One fresh audit-only child; same cumulative wall/peak gates, no solver calls."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
def packed(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def entry(p):b=p.read_bytes();return dict(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
plan=json.loads((OUT/'audit-v2-plan.json').read_bytes());costs=json.loads((OUT/'stage-costs.json').read_bytes())
for p,pin in plan['pins'].items():
    if entry(ROOT/p)!=pin:raise ValueError('audit-v2 pin '+p)
if costs['audit_seconds']!=plan['prior_charged_audit_seconds']:raise ValueError('cumulative gate changed')
remaining=180-costs['audit_seconds'];begin=time.perf_counter()
cmd=[sys.executable,str(ROOT/plan['auditor'])]
with (OUT/'audit-v2-stdout.txt').open('wb') as out,(OUT/'audit-v2-stderr.txt').open('wb') as err:
    child=subprocess.Popen(cmd,stdout=out,stderr=err);timeout=False
    try:child.wait(timeout=remaining)
    except subprocess.TimeoutExpired:timeout=True;child.kill();child.wait()
elapsed=time.perf_counter()-begin;costs['audit_seconds']+=elapsed
receipt=dict(stage='audit-v2',command=cmd,duration_seconds=elapsed,exit_code=child.returncode,timed_out=timeout,child_reaped=True,
    remaining_budget_at_start=remaining,gate='unknown_resource_or_process' if timeout or child.returncode or costs['audit_seconds']>180 else 'within_process_wall_gate',
    stdout=entry(OUT/'audit-v2-stdout.txt'),stderr=entry(OUT/'audit-v2-stderr.txt'))
costs['stages'].append(receipt);(OUT/'stage-costs.json').write_bytes(packed(costs));print(json.dumps(receipt))
