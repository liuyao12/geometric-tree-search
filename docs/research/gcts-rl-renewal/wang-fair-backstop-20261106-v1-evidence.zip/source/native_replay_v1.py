"""Replay every distinct newly searched proof with the unchanged Wang checker."""
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source'))
from backstop_v1 import UPSTREAM
from backstop_study_v1 import checked_proof
from boundary_kernel_v1 import build
from copy_check_v1 import TileBank, verify
from copy_ports_v1 import attach_marks, compile_diagram, encoded, freeze
from definition_check_v1 import check
from herbrand_v1 import signature
from native_v1 import PUBLISHED_MACHINE
from study_v1 import guarded


def replay():
    data = json.loads(gzip.decompress((ROOT / 'data/study-v1.json.gz').read_bytes()))
    machine = build().compile()
    assert machine.digest() == PUBLISHED_MACHINE
    bank = TileBank(machine)
    proofs, calls = {}, {}
    for row in data['rows']:
        check(row['original'], row['normal'], row['translation'])
        functions, _, schemas = signature(row['normal'])
        sources, _ = guarded(schemas, functions, row['normal']['sorts'])
        for arm, result in row['runs'].items():
            if result['status'] != 'PROVED':
                continue
            proof = freeze(result['proof'])
            key = sha256(encoded((row['original'], proof))).hexdigest()
            calls[row['original']['id'] + '/' + arm] = key
            if key in proofs:
                continue
            wire = checked_proof(row['normal'], proof)
            diagram = compile_diagram(wire)
            local = [bank.get(s)[0] for s in diagram['strips']]
            attach_marks(diagram, local, len(machine.marks) + 1)
            receipt = verify(diagram, sources, bank)
            proofs[key] = dict(original=row['original'], normal=row['normal'], proof=proof,
                               diagram=diagram, receipt=receipt)
            print('Verified native', row['original']['id'], arm, len(proof), 'records', flush=True)
    return dict(palette=PUBLISHED_MACHINE, proofs=proofs, calls=calls, bank=bank.receipts)


def main():
    if not __debug__:
        raise RuntimeError('Replay requires assertions')
    raw = encoded(replay())
    path = ROOT / 'data/native-v1.json.gz'
    if '--build' in sys.argv:
        path.write_bytes(gzip.compress(raw, mtime=0))
    else:
        assert gzip.decompress(path.read_bytes()) == raw


if __name__ == '__main__':
    main()
