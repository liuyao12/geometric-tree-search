"""Reject damaged advice before it can change any fair-search state."""
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source'))
from backstop_study_v1 import cases
from backstop_v1 import Backstop, UPSTREAM, proposals
from definitions_v1 import compile_case
from multi_families_v1 import propagation_families
from multi_search_v1 import MultiSearch


def snapshot(core):
    return deepcopy((core.rows, core.index, core.agenda, core.seen_instances, core.work))


def main():
    normal, _ = compile_case(next(cases()))
    prior = json.loads((UPSTREAM / 'input/prior-study-v1.json').read_text())
    limits = dict(prior['limits'], rounds=30, resolutions=1000, instances=1000)
    engine = MultiSearch(normal, next(cases())['goal'], limits, propagation_families(normal))
    assert engine.run()['status'] == 'PROVED'
    offered = proposals(engine)
    first_r = next(j for j, p in enumerate(offered) if p['rule'] == 'R')
    examples = []
    g = deepcopy(offered[0]); g['clause'] = []
    examples.append(('missing-instance-literal', [], g))
    g = deepcopy(offered[0]); g['source'] = '$unknown'
    examples.append(('unknown-source', [], g))
    g = deepcopy(offered[0]); g['id'] = -1
    examples.append(('negative-identifier', [], g))
    g = deepcopy(offered[0]); g['bindings']['?unused'] = ('a',)
    examples.append(('extra-binding', [], g))
    r = deepcopy(offered[first_r]); r['pivot'] = ('forged', ('a',))
    examples.append(('wrong-pivot', offered[:first_r], r))
    r = deepcopy(offered[first_r]); r['clause'] = []
    assert offered[first_r]['clause']
    examples.append(('missing-resolvent-literal', offered[:first_r], r))
    r = deepcopy(offered[first_r]); r['left'] = r['id']
    examples.append(('self-reference', offered[:first_r], r))
    r = deepcopy(offered[first_r]); r['right'] = max(p['id'] for p in offered) + 1
    examples.append(('forward-reference', offered[:first_r], r))
    examples.append(('duplicate-identifier', offered[:1], deepcopy(offered[0])))
    results = []
    for name, prefix, broken in examples:
        driver = Backstop(normal)
        for record in prefix:
            driver.import_record(record)
        assert driver.counts['accepted'] == len(prefix)
        before = snapshot(driver.core)
        driver.import_record(broken)
        assert driver.counts['rejected'] == 1, name
        assert snapshot(driver.core) == before, name
        results.append(name)
    # A source requiring a Point variable must reject a Line inhabitant.
    typed, _ = compile_case(list(cases())[2])
    driver = Backstop(typed)
    schema = next(s for s in driver.core.schemas.values() if len(s['variables']) == 1)
    variable, sort = next(iter(schema['variables'].items()))
    wrong = next((f,) for f, (args, out) in driver.core.functions.items() if not args and out != sort)
    before = snapshot(driver.core)
    driver.import_record(dict(id=0, rule='G', source=schema['id'], bindings={variable: wrong}, clause=[]))
    assert driver.counts['rejected'] == 1 and snapshot(driver.core) == before
    results.append('wrong-sort')
    body = json.dumps(dict(rejected_without_core_mutation=results), sort_keys=True) + '\n'
    path = ROOT / 'data/admission-controls-v1.json'
    if '--build' in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body
    print('Verified', len(results), 'rejected proposals leave the fair core unchanged')


if __name__ == '__main__':
    main()
