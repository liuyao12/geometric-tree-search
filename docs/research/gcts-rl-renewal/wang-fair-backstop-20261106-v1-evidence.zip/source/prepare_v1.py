"""Restore and authenticate the exact published upstream snapshot."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
DIGEST = 'ecbab3b143d655016475ed44ff66810ac12e652162166150d5821ff69c8ad9eb'


def ensure_upstream():
    archive = ROOT / 'input/upstream-evidence.zip'
    if sha256(archive.read_bytes()).hexdigest() != DIGEST:
        raise RuntimeError('Upstream archive hash mismatch')
    target = ROOT / 'upstream'
    with ZipFile(archive) as z:
        manifest = json.loads(z.read('MANIFEST.json'))
        if set(z.namelist()) != set(manifest) | {'MANIFEST.json'}:
            raise RuntimeError('Upstream manifest mismatch')
        for name, digest in manifest.items():
            path = Path(name)
            if path.is_absolute() or '..' in path.parts or sha256(z.read(name)).hexdigest() != digest:
                raise RuntimeError('Invalid upstream archive member')
        if not target.exists():
            target.mkdir()
            z.extractall(target)
        for name, digest in manifest.items():
            if sha256((target / name).read_bytes()).hexdigest() != digest:
                raise RuntimeError('Modified upstream file: ' + name)
    return target
