"""Exercise a fair backstop against bounded inventory advice and corrupt advice."""
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source'))
from backstop_v1 import Backstop, UPSTREAM, proposals
from connected_wire_v1 import audit, compact
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_cases_v1 import holds
from multi_search_v1 import MultiSearch
from multi_families_v1 import propagation_families
from study_v1 import guarded


def cases():
    def atom(p, t=('a',)):
        return ['atom', p, t if isinstance(t, str) else list(t)]
    def all_(v, body):
        return ['all', v, 'U', body]
    p, q, z = (atom(n) for n in 'PQR')
    base = dict(sorts=['U'], equality=False, functions={'a': [[], 'U']},
                predicates={p: ['U'] for p in 'PQR'})
    yield dict(base, id='case-split', premises=[['or', p, q], ['implies', p, z], ['implies', q, z]], goal=z)
    t = ['a']
    for _ in range(5):
        t = ['f', t]
    yield dict(base, id='recursive-witness', functions={**base['functions'], 'f': [['U'], 'U']},
               premises=[p, all_('?x', ['implies', atom('P', '?x'), atom('P', ['f', '?x'])])],
               goal=atom('P', t))
    yield dict(id='typed-existence', sorts=['Point', 'Line'], equality=False, functions={},
               predicates={'I': ['Point', 'Line']}, premises=[],
               goal=['implies', ['all', '?p', 'Point', ['exists', '?l', 'Line', ['atom', 'I', '?p', '?l']]],
                     ['exists', '?m', 'Line', ['exists', '?q', 'Point', ['atom', 'I', '?q', '?m']]]])
    yield dict(base, id='countermodel-control', premises=[p], goal=q)


def invalid_advice(normal):
    # Unknown source and missing parents are rejected without entering the core.
    return [dict(id=i, rule='G', source='$not-a-source', bindings={}, clause=[])
            if i % 2 else dict(id=i, rule='R', left=i, right=i+1, pivot=('P', ('a',)), clause=[])
            for i in range(2000)]


def checked_proof(normal, proof):
    from herbrand_v1 import signature
    functions, _, schemas = signature(normal)
    source, _ = guarded(schemas, functions, normal['sorts'])
    wire = compact(source, proof)
    assert audit(wire, source, proof) == len(proof)
    return wire


def study():
    prior = json.loads((UPSTREAM / 'input/prior-study-v1.json').read_text())
    limits = dict(prior['limits'], rounds=1, resolutions=1000, instances=1000)
    rows = []
    for original in cases():
        if original['id'] == 'countermodel-control':
            model = dict(domains={'U': (0,)}, functions={'a': {(): 0}},
                         predicates={'P': {(0,)}, 'Q': set(), 'R': set()})
            premises, goal = holds(original, model)
            assert all(premises) and not goal
        normal, translation = compile_case(original)
        check(original, normal, translation)
        cap = 600
        adviser = MultiSearch(normal, original['goal'], limits,
                              [*prior['inventory'], *propagation_families(normal)])
        adviser_result = adviser.run()
        advice = proposals(adviser)
        complete_limits = dict(limits, rounds=30)
        complete = MultiSearch(normal, original['goal'], complete_limits,
                               [*prior['inventory'], *propagation_families(normal)])
        complete_result = complete.run()
        complete_advice = proposals(complete)
        runs = {}
        for name, offered in [('fair-only', ()), ('bounded-inventory', advice),
                              ('inventory', complete_advice), ('corrupt-advice', invalid_advice(normal))]:
            result = Backstop(normal, offered).run(cap)
            if original['id'] == 'countermodel-control':
                assert result['status'] == 'BOUNDED'
            else:
                if result['status'] == 'PROVED':
                    checked_proof(normal, result['proof'])
                else:
                    assert original['id'] == 'recursive-witness' and name != 'inventory'
            runs[name] = result
        assert runs['corrupt-advice']['proof'] == runs['fair-only']['proof']
        assert runs['corrupt-advice']['counts'] == runs['fair-only']['counts']
        assert not runs['corrupt-advice']['advice'].get('accepted', 0)
        rows.append(dict(original=original, normal=normal, translation=translation, cap=cap,
                         adviser=dict(limits=limits, result=adviser_result, records=advice),
                         complete_adviser=dict(limits=complete_limits, result=complete_result, records=complete_advice), runs=runs))
        print(original['id'], 'adviser', adviser_result['status'], len(advice),
              {a:(b['status'],b['counts']['rounds'],len(b['proof'] or [])) for a,b in runs.items()}, flush=True)
    return dict(rows=rows, protocol='One mandatory fair stream/FIFO tick, then at most one checked advisory record.')


def main():
    if not __debug__:
        raise RuntimeError('Replay requires assertions')
    body = json.dumps(study(), sort_keys=True, separators=(',', ':')).encode() + b'\n'
    path = ROOT / 'data/study-v1.json.gz'
    if '--build' in sys.argv:
        path.write_bytes(gzip.compress(body, mtime=0))
    else:
        assert gzip.decompress(path.read_bytes()) == body


if __name__ == '__main__':
    main()
