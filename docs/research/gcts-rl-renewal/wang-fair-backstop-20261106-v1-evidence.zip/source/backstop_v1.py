"""Keep a persistent fair core while importing independently checked advice.

The finite adviser runs before this driver. Only its already produced records
are consumed, one at a time, after a mandatory fair tick. An exhausted adviser
therefore cannot stop, reset, reorder, or delete work in the fair lane.
"""
from collections import Counter
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
from prepare_v1 import ensure_upstream
UPSTREAM = ensure_upstream()
sys.path[:0] = [str(UPSTREAM / p) for p in ('source', 'wang/source', 'wang/external/source')]
from fair_search_v1 import Search, ordered
from herbrand_v1 import inspect_term, frozen
from study_v1 import grounded


class InvalidAdvice(ValueError):
    pass


def require(value, reason):
    if not value:
        raise InvalidAdvice(reason)


class Backstop:
    def __init__(self, normal, advice=()):
        self.core = Search(normal, guided=False)
        # Materialize a finite output, never execute an adviser during a tick.
        self.advice = tuple(advice)
        self.cursor = 0
        self.ids = {}
        self.events = []
        self.counts = Counter()

    def import_record(self, raw):
        """Accept only typed source instances and exact binary resolvents."""
        try:
            require(isinstance(raw, dict), 'record')
            ident = raw['id']
            require(type(ident) is int and ident >= 0 and ident not in self.ids, 'identifier')
            op = raw['rule']
            if op == 'G':
                schema = self.core.schemas[raw['source']]
                env = {v: frozen(t) for v, t in raw['bindings'].items()}
                require(set(env) == set(schema['variables']), 'bindings')
                require(all(inspect_term(t, {}, self.core.functions) == schema['variables'][v]
                            for v, t in env.items()), 'sort')
                clause = ordered(grounded(schema, env))
                require(clause == ordered(frozen(raw['clause'])), 'instance')
                require(not any((not s, a) in clause for s, a in clause), 'tautology')
                i = self.core.index.get(clause)
                if i is None:
                    i = self.core.instance(raw['source'], env, 'advice')
            else:
                require(op == 'R', 'rule')
                left, right = (self.ids[raw[k]] for k in ('left', 'right'))
                pivot = frozen(raw['pivot'])
                a, b = (set(self.core.rows[j][0]) for j in (left, right))
                require((True, pivot) in a and (False, pivot) in b, 'pivot')
                clause = ordered((a - {(True, pivot)}) | (b - {(False, pivot)}))
                require(clause == ordered(frozen(raw['clause'])), 'resolvent')
                require(not any((not s, t) in clause for s, t in clause), 'tautology')
                i = self.core.resolve(left, right, pivot)
            require(i is not None and self.core.rows[i][0] == clause, 'admission')
            self.ids[ident] = i
            self.counts['accepted'] += 1
            self.events.append(dict(id=ident, status='accepted', core=i, round=self.core.work['rounds']))
        except (InvalidAdvice, KeyError, TypeError, ValueError, IndexError, RecursionError) as error:
            # Every rejection above occurs before mutating the core. Inputs too
            # large for Python's recursion limit are rejected as advice only.
            self.counts['rejected'] += 1
            self.events.append(dict(status='rejected', reason=str(error), round=self.core.work['rounds']))

    def run(self, max_rounds=None):
        while () not in self.core.index:
            if max_rounds is not None and self.core.work['rounds'] >= max_rounds:
                return self.result('BOUNDED', None)
            # Even when advice remains, the fair stream and FIFO both advance.
            result = self.core.search(self.core.work['rounds'] + 1)
            if result['status'] == 'PROVED':
                return self.result('PROVED', result['proof'])
            if self.cursor < len(self.advice):
                self.import_record(self.advice[self.cursor])
                self.cursor += 1
        return self.result('PROVED', self.core.elaborate())

    def result(self, status, proof):
        return dict(status=status, counts=dict(self.core.work), advice=dict(self.counts),
                    consumed=self.cursor, total_advice=len(self.advice), events=self.events, proof=proof)


def proposals(engine):
    """Export the proposer's raw derivation DAG, not its guarded tape proof."""
    needed = set()
    if () in engine.index:
        pending = [engine.index[()]]
        while pending:
            i = pending.pop()
            if i in needed:
                continue
            needed.add(i)
            if engine.rows[i][1][0] == 'R':
                pending.extend(engine.rows[i][1][1:3])
    else:
        needed = set(range(len(engine.rows)))
    records = []
    for i in sorted(needed):
        clause, (op, *reason) = engine.rows[i]
        if op == 'G':
            name, env = reason
            record = dict(id=i, rule=op, source=name, bindings=env, clause=clause)
        else:
            left, right, pivot = reason
            record = dict(id=i, rule=op, left=left, right=right, pivot=pivot, clause=clause)
        records.append(record)
    return records
