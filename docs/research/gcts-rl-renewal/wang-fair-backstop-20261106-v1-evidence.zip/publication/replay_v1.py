"""Replay the complete backstop archive without network access or extra packages."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    if not __debug__:
        raise RuntimeError('Replay requires assertions')
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for name, digest in manifest.items():
        path = Path(name)
        assert not path.is_absolute() and '..' not in path.parts
        assert sha256((ROOT / path).read_bytes()).hexdigest() == digest, name
    tasks = ['source/backstop_study_v1.py', 'source/admission_controls_v1.py',
             'source/native_replay_v1.py', 'publication/render_v1.py']
    for task in tasks:
        subprocess.run([sys.executable, '-I', '-S', '-B', task], cwd=ROOT, check=True)
    for name, digest in manifest.items():
        assert sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    print('Verified all', len(manifest), 'archive file hashes, sixteen searches, ten rejection controls, five native diagrams and exact reader bytes')


if __name__ == '__main__':
    main()
