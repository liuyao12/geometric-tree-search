"""Explain the fair backstop and render the independently checked proof rows."""
import gzip
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source'))
from backstop_v1 import UPSTREAM
sys.path.insert(0, str(UPSTREAM / 'publication'))
from copy_ports_v1 import freeze
from copy_views_v1 import case
from proof_views_v1 import tile_svg

NAME = 'wang-fair-backstop-20261106-v1'
LABELS = {'fair-only': 'Fair core alone', 'bounded-inventory': 'One-round adviser and fair core',
          'inventory': 'Thirty-round adviser and fair core', 'corrupt-advice': 'Corrupt advice and fair core'}
CASES = {'case-split': 'Proof by cases', 'recursive-witness': 'Five recursive steps',
         'typed-existence': 'Point and line existence', 'countermodel-control': 'Non-entailment control'}


def read(name):
    path = ROOT / name
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes())


def main():
    data = read('data/study-v1.json.gz')
    native = read('data/native-v1.json.gz')
    controls = read('data/admission-controls-v1.json')
    types, readers = {}, {}
    for key, proof in native['proofs'].items():
        view = dict(proof, original=dict(proof['original'], id=key))
        readers[key] = case(view, native['bank'], types)
    rows, runs = [], {}
    for row in data['rows']:
        ident = row['original']['id']
        runs[ident] = {}
        for arm, result in row['runs'].items():
            count = result['counts']
            advice = result['advice']
            rows.append('<tr><th>'+CASES[ident]+'</th><td>'+LABELS[arm]+'</td>'
                        +f'<td>{result["status"].lower()}</td><td>{count["rounds"]:,}</td>'
                        +f'<td>{count.get("resolutions",0):,}</td>'
                        +f'<td>{advice.get("accepted",0):,} / {advice.get("rejected",0):,}</td></tr>')
            runs[ident][arm] = dict(status=result['status'], key=native['calls'].get(ident+'/'+arm),
                                   consumed=result['consumed'], offered=result['total_advice'])
    payload = json.dumps(dict(readers=readers, runs=runs), separators=(',', ':')).replace('<', '\\u003c')
    symbols = ''.join(tile_svg(tile, ident) for tile, ident in types.items())
    option_cases = ''.join(f'<option value="{k}">{v}</option>' for k,v in CASES.items())
    option_arms = ''.join(f'<option value="{k}">{v}</option>' for k,v in LABELS.items())
    adviser_rows = ''.join('<tr><th>'+CASES[row['original']['id']]+'</th>'
                           +''.join('<td>'+str(row[a]['result']['status']).lower()+'</td><td>'
                                    +str(row[a]['result']['counts'].get('resolutions',0))+'</td>'
                                    for a in ('adviser','complete_adviser'))+'</tr>' for row in data['rows'])
    body = r'''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>A fair backstop for proof-search advice</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
*{box-sizing:border-box}[hidden]{display:none!important}body{margin:0;background:#eef3f6;color:#173441;font:1rem/1.6 system-ui,sans-serif}
main{max-width:72rem;margin:auto;padding:1rem clamp(.7rem,3vw,2rem) 3rem}header,section{background:white;border:1px solid #c7d8e0;border-radius:.7rem;padding:clamp(.9rem,3vw,1.7rem);margin-bottom:1rem}
header{border-top:5px solid #207b84}h1,h2,h3,h4{line-height:1.2}h1{font-size:clamp(2rem,5vw,3.4rem);margin:.3rem 0 .7rem}h2{margin:.25rem 0 .8rem}p{margin:.4rem 0 .9rem}a,summary{color:#075c65}.kicker{font-size:.83rem;color:#3d6570;font-weight:700}.scope{border-left:4px solid #9d71bd;padding:.5rem 1rem;background:#f7f1fc}
button,select,input{font:inherit;padding:.4rem;border:1px solid #a9c1cb;border-radius:.3rem;background:white;color:inherit}button,summary{cursor:pointer}label{display:inline-flex;gap:.4rem;align-items:center;flex-wrap:wrap}.controls{display:flex;flex-wrap:wrap;gap:.7rem;margin:.5rem 0 1rem}select{max-width:100%}input{width:5rem}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}.table,.formula,pre{max-width:100%;overflow:auto}.table{border:1px solid #c7d8e0}table{width:100%;border-collapse:collapse;white-space:nowrap}th,td{border-bottom:1px solid #d7e3e8;padding:.55rem .65rem;text-align:left}th{font-weight:600}thead{background:#edf5f6}.formula{padding:.4rem 0}details{margin:.6rem 0}summary{font-weight:600}pre{padding:.7rem;background:#eff4f7;font-size:.8rem;line-height:1.4}.copied{min-width:0;padding:.6rem;border:1px solid #cbdce3;border-radius:.4rem}.copied h4{margin:.2rem 0}.ribbon svg{width:100%;max-width:27rem;height:auto}.glyph{fill:#e8f6f1;stroke:#38856f;stroke-width:.6}.parent-copy .glyph{fill:#f0eafa;stroke:#8160ae}.copy-line{stroke:#37896e;stroke-width:2}.parent-copy .copy-line{stroke:#8968ad}.ribbon text{font:12px ui-monospace,monospace;fill:#203e4a}.ribbon p,figcaption{font-size:.85rem;color:#46606c}figure{margin:1rem 0}figure svg{width:100%;max-width:38rem;height:auto}.process{display:grid;grid-template-columns:1fr 1fr;gap:1rem}.step{border:2px solid #2e8097;padding:1rem;border-radius:.45rem;background:#eff9fc}.step.advice{border-color:#8c6ab6;background:#f7f2fc}.step b{display:block}.reader-status{background:#eff5f7;padding:.6rem}.proof{border:1px solid #b8d2dc;border-radius:.5rem;padding:1rem}.small{font-size:.87rem;color:#46616b}
@media(max-width:45rem){.grid,.process{grid-template-columns:1fr}th,td{padding:.4rem}.proof{padding:.55rem}}
</style></head><body><main>
<header><p class="kicker">GCTS research notebook · 6 November 2026</p><h1>A fair backstop for proof-search advice</h1>
<p>The inventory proposer can stop at its budget while a separate fair search keeps running. Every offered step is checked before it enters the fair core. The resulting proofs use the same fixed Wang palette and long-range copy markings as the earlier notebooks.</p>
<p><a href="latest-verified-20261106-v1.html">Research results</a> · <a href="#reader">Read the discovered proofs</a> · <a href="''' + NAME + r'''-evidence.zip">Full replay archive</a></p></header>
<section><h2>Keep a mandatory search path</h2><div class="process">
<div class="step"><b>First: advance the fair core</b>Take the next typed ground instance and process the oldest queued clause against earlier clauses. Preserve its queue, term stream and proof dependencies.</div>
<div class="step advice"><b>Then: check one advisory record</b>Admit an exact source instance or a resolvent of previously admitted advisory parents. Reuse a clause already found by the core. Reject a bad record and continue the next fair tick.</div></div>
<p>The existing bounded multi-premise inventory search produces a finite list before the driver starts. It uses the previously frozen lemma inventory and the fixed propagation families. This experiment adds no newly trained policy. The interface can accept records from an RL-guided proposer, but these runs test the search guarantee rather than an RL advantage.</p>
<p>The core owns its proof state. An adviser cannot remove a clause, rewind enumeration, replace a parent, or spend the core’s round budget. The experiment still stops the core after a declared finite number of rounds.</p></section>
<section id="guarantee"><h2>What an unbounded run would guarantee</h2>
<div class="scope"><p><strong>Claim about the idealized algorithm.</strong> For a finite well-typed first-order clause boundary with nonempty sorts, the backstop with unbounded resources and a finite advisory list eventually finds an empty clause whenever that boundary is unsatisfiable. This is a mathematical argument about the algorithm; the finite experiments below do not establish the universal claim by testing.</p></div>
<ol><li>Every ground term has a finite constructor size. The typed term stream enumerates every substitution for every source schema at a finite size layer.</li>
<li>Every admitted clause has finitely many predecessors in the FIFO queue. Later advisory clauses are appended. They cannot keep an earlier clause from being processed.</li>
<li>When a clause is processed, it resolves with the already processed clauses on complementary literals. Each finite ground resolution derivation is therefore reached after finitely many ticks. Duplicate and tautological clauses do not need separate processing.</li>
<li>An unsatisfiable Skolem clause set has a finite ground refutation. This is the standard <a href="https://www.cs.cit.tum.de/fileadmin/w00cfj/tcs/2023ss/logic/10-herbrand-and-ground-resolution.pdf">ground resolution theorem</a>, not a new GCTS result. Combining it with the first three points proves the claim. Robinson’s <a href="https://web.stanford.edu/class/linguist289/robinson65.pdf">original resolution paper</a> develops refutation completeness and search principles.</li></ol>
<p>For equality, the finite boundary includes equivalence and congruence schemas for its signature. Our extension of the argument is to quotient any model of those schemas by each sort’s equality relation; congruence makes the functions and predicates well defined on the quotient. Thus ordinary predicate resolution can serve as the complete backstop for the equality encoding too.</p>
<p>Each returned proof consists of source instantiation and ground resolution records. The existing elaborator adds sort proofs and produces a Wang diagram with anchored copy links. The new driver does not introduce an additional logical rule or change the palette.</p>
<p class="small">The guarantee assumes enough storage, arithmetic range and verifier budget. The current Python program has practical limits. For an infinite recursively enumerated axiom theory, an additional fair schedule over finite axiom prefixes would be needed; this driver takes a finite boundary. General first-order provability is a semidecision problem, so an open finite run gives no non-entailment verdict.</p></section>
<section id="results"><h2>Check exhausted and corrupt advice</h2>
<p>Four statements and four schedules use the same clause boundary. Every core receives at most 600 ticks. Counts below cover the core and imported steps; adviser setup is listed separately. These are small implementation controls, not an external prover benchmark.</p>
<div class="table" tabindex="0"><table><thead><tr><th>Statement</th><th>Schedule</th><th>Result</th><th>Core ticks</th><th>Core resolutions</th><th>Advice accepted / rejected</th></tr></thead><tbody>''' + ''.join(rows) + r'''</tbody></table></div>
<p>With the typed-existence adviser stopped after one round, its eleven records were exhausted and the core still found a proof. For the recursive case, the one-round adviser and the fair core stayed open within the cap. The thirty-round allowance let the adviser find a proof after two rounds, which the core accepted in 29 checked advisory records. Search time and total work include the separate adviser; the core-tick comparison alone is not a speedup claim.</p>
<div class="table" tabindex="0"><table><thead><tr><th>Statement</th><th>One-round adviser</th><th>Its resolutions</th><th>Thirty-round adviser</th><th>Its resolutions</th></tr></thead><tbody>''' + adviser_rows + r'''</tbody></table></div>
<p>The corrupt-advice arm has exactly the same core counters and proof as the fair-only arm on every case. Ten targeted controls also show that malformed advice leaves the clause store, queue, instance set and work counters unchanged. The non-entailment control has the explicit model with one object, (P(a)) true and (Q(a)) false; every search remains open at the cap.</p>
<p>All nine successful runs were expanded. Five distinct proof diagrams passed the unchanged native checker, including their long-range symbol comparisons. The reader below displays the actual squares, copied symbols and decoded formulas.</p></section>
<section id="reader"><h2>Read the discovered proof rows</h2><div class="controls"><label>Statement <select id="case">''' + option_cases + r'''</select></label><label>Schedule <select id="arm">''' + option_arms + r'''</select></label></div>
<p id="reader-status" class="reader-status" aria-live="polite"></p><div class="controls" id="line-controls"><button id="prev">Previous line</button><label>Line <input type="number" id="line" min="1" value="1"></label><button id="next">Next line</button></div><div class="proof" id="proof"></div>
<p class="small">Squares have fixed orientation and are placed by translation. Edge colors visualize full symbolic labels. Green ribbons copy source clauses; violet ribbons copy previously proved clauses. The mathematical statement is symbolic: the Point and Line sorts do not rely on a drawn geometric configuration.</p></section>
<section><h2>Scope of the proof system</h2><p>The general formula-to-clause boundary has a separate independent Python checker. The Wang squares certify the clausal derivation, and copy markings bind its local pieces together. Thus the present end-to-end checker includes the formula boundary checker; this report does not claim that all preprocessing has been embedded in one ordinary Wang rectangle.</p>
<p>The fair core supplies a standard completeness argument. The research contribution being tested remains whether learned markings and reusable receptor families lead to useful proofs sooner. The <a href="wang-direct-hilbert-control-20261106-v1.html">clause-encoding control</a> shows why such claims need conventional baselines. This backstop makes advice dispensable for correctness and eventual discovery in the stated finite-boundary setting.</p>
<p><a href="''' + NAME + r'''-evidence.zip">Download the full evidence archive</a>. It contains the pinned upstream snapshot, exact statements, proposed records, search counters, expanded proofs, marked diagrams, native receipts, rejection controls and source. Run <code>publication/replay_v1.py</code> with Python 3.12 from a clean extraction.</p></section>
<svg width="0" height="0" aria-hidden="true"><defs>''' + symbols + r'''</defs></svg>
<script type="application/json" id="data">''' + payload + r'''</script>
<script>
const data=JSON.parse(document.getElementById('data').textContent);let current=null,line=1,queue=Promise.resolve();
const caseBox=document.getElementById('case'),armBox=document.getElementById('arm'),proof=document.getElementById('proof'),lineBox=document.getElementById('line');
function typeset(){queue=queue.catch(()=>{}).then(async()=>{if(window.MathJax?.typesetPromise){await MathJax.startup.promise;MathJax.typesetClear([proof]);await MathJax.typesetPromise([proof]);}});}
function showLine(n){if(!current)return;const max=Number(current.dataset.lines),next=Math.max(1,Math.min(max,Math.trunc(n)||1)),slot=current.querySelector('.line-slot');lineBox.value=next;lineBox.max=max;if(next===line&&slot.firstElementChild)return;line=next;slot.innerHTML=current.querySelector('.line-template[data-line="'+line+'"]').innerHTML;document.getElementById('prev').disabled=line===1;document.getElementById('next').disabled=line===max;typeset();}
function show(){const run=data.runs[caseBox.value][armBox.value];proof.replaceChildren();current=null;document.getElementById('line-controls').hidden=!run.key;document.getElementById('reader-status').textContent=run.status==='PROVED'?'Checked proof. Advisory records consumed: '+run.consumed+' of '+run.offered+'.':'Open at the 600-tick cap. No proof and no non-entailment verdict were returned.';if(!run.key){proof.textContent='This bounded run has no proof rows.';return;}proof.innerHTML=data.readers[run.key];current=proof.querySelector('.case');current.hidden=false;showLine(1);}
caseBox.addEventListener('change',show);armBox.addEventListener('change',show);lineBox.addEventListener('change',()=>showLine(Number(lineBox.value)));document.getElementById('prev').addEventListener('click',()=>showLine(line-1));document.getElementById('next').addEventListener('click',()=>showLine(line+1));proof.addEventListener('click',e=>{const b=e.target.closest('.jump');if(b)showLine(Number(b.dataset.line));});show();
</script></main></body></html>'''
    path = ROOT / 'report' / (NAME + '.html')
    if '--build' in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body
    assert len(native['calls']) == 9 and len(native['proofs']) == 5
    assert len(controls['rejected_without_core_mutation']) == 10
    print('Rendered four statements, four schedules and five native proof readers')


if __name__ == '__main__':
    main()
