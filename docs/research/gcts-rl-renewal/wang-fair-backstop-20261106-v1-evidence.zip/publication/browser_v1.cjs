const assert = require('node:assert/strict');
const fs = require('node:fs');
const {pathToFileURL} = require('node:url');
const {chromium} = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({executablePath: process.env.GCTS_CHROME, headless: true, args: ['--no-sandbox']});
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({viewport: {width, height: 900}});
      const errors = [];
      page.on('pageerror', error => errors.push(error.message));
      await page.goto(pathToFileURL(process.cwd() + '/report/wang-fair-backstop-20261106-v1.html').href, {waitUntil: 'load', timeout: 60000});
      await page.locator('.line-slot mjx-container').first().waitFor({timeout: 60000});
      assert.equal(await page.locator('#case option').count(), 4);
      assert.equal(await page.locator('#arm option').count(), 4);
      assert.equal(await page.locator('#results table').first().locator('tbody tr').count(), 16);
      const keys = await page.evaluate(() => Object.keys(data.runs));
      for (const name of keys) {
        await page.selectOption('#case', name);
        for (const arm of ['fair-only','bounded-inventory','inventory','corrupt-advice']) {
          await page.selectOption('#arm', arm);
          const run = await page.evaluate(([n,a]) => data.runs[n][a], [name,arm]);
          if (run.key) {
            await page.locator('.line-slot mjx-container').first().waitFor();
            assert.equal(await page.locator('#line-controls').isVisible(), true);
            const n = Number(await page.locator('#line').getAttribute('max'));
            await page.locator('#line').fill(String(n));
            await page.locator('#line').dispatchEvent('change');
            await page.waitForFunction(() => document.querySelector('.line-slot mjx-container')?.textContent.includes('⊥'));
            await page.locator('.line-slot details.native summary').click();
            assert.equal(await page.locator('.line-slot .native svg use').count(), 9);
            const box = await page.locator('.line-slot .native svg use').first().evaluate(n=>({
              width:n.getBBox().width, href:n.getAttribute('href'),
              target:document.querySelector(n.getAttribute('href'))?.outerHTML.slice(0,100),
              ancestors:Array.from((function*(e){while(e){yield e;e=e.parentElement}})(n)).map(e=>({tag:e.tagName,cls:e.getAttribute('class'),hidden:e.hasAttribute('hidden'),open:e.open,display:getComputedStyle(e).display,width:e.getBoundingClientRect().width})),
              definitionBox:document.querySelector(n.getAttribute('href'))?.getBBox().width
            }));
            assert.ok(box.width>=35.9, JSON.stringify({name,arm,box}));
            const jump = page.locator('.line-slot button.jump').first();
            const target = await jump.getAttribute('data-line');
            await jump.click();
            assert.equal(await page.locator('#line').inputValue(), target);
          } else {
            assert.equal(await page.locator('#line-controls').isVisible(), false);
            assert.match(await page.locator('#proof').textContent(), /no proof rows/);
          }
        }
      }
      await page.selectOption('#case', 'typed-existence');
      await page.selectOption('#arm', 'bounded-inventory');
      await page.locator('.line-slot mjx-container').first().waitFor();
      assert.equal(await page.locator('mjx-merror').count(), 0);
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth), width);
      assert.deepEqual(errors, []);
      await page.screenshot({path: `publication/preview-top-${width}.png`});
      await page.locator('#reader').scrollIntoViewIfNeeded();
      await page.screenshot({path: `publication/preview-reader-${width}.png`});
      console.log(`Verified ${width}px: sixteen states, line navigation, formulas, nine actual squares, no overflow or page errors`);
      await page.close();
    }
  } finally { await browser.close(); }
}
main().catch(error=>{console.error(error);process.exitCode=1;});
