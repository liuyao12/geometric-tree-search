GCTS Wang proof search: a fair backstop for finite advisory output

Use Python 3.12 with assertions enabled. No network or third-party package is
needed for the research replay. From the extracted archive directory run:

    python3.12 -I -S -B publication/replay_v1.py

The replay authenticates every archive file. On first use it restores the pinned
upstream evidence snapshot from input/upstream-evidence.zip, authenticating its
137 member hashes before importing the existing search and Wang checker.
It repeats sixteen search controls, ten damaged-advice tests, all five distinct
native proof diagrams and exact report generation.

Open report/wang-fair-backstop-20261106-v1.html to inspect each proof line,
its mathematical formula, copy markings and actual fixed-orientation squares.
Math rendering in the HTML uses the established MathJax CDN. This is separate
from offline mathematical certificate replay.

The driver accepts a finite list of advisory G/R records. It advances a persistent
fair core before checking at most one offered record. The example adviser is the
earlier bounded inventory search with its frozen lemma bank and fixed propagation
families. This experiment does not train a new RL policy or establish a runtime
advantage. Core work and adviser work are reported separately.

The idealized unbounded algorithm is refutation complete for a finite well-typed
first-order clause boundary with inhabited sorts. The report gives the argument
and its assumptions. The experiments use a 600-round core cap; a bounded run has
no non-entailment verdict. A countermodel separately establishes the negative
control. The original formula boundary still has a separate independent checker.
