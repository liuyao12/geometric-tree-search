# Replay the Turtle shape-only searches

Use Python 3.12 and its standard library. In an extracted copy, preserve
the results and keep the comparison file outside the input directory
until the searches have finished.

    mv data archived-data
    mkdir data
    mv input/comparison-v1.json comparison-held-back.json
    python3.12 -I -S -B source/assemble_v1.py
    python3.12 -I -S -B source/collar_experiment_v1.py
    python3.12 -I -S -B source/motif_inventory_v1.py
    mv comparison-held-back.json input/comparison-v1.json
    python3.12 -I -S -B source/collar_audit_v1.py
    python3.12 -I -S -B publication/render_v1.py

The first script exhausts the directed edge contacts and rotation
orbits. The second solves finite collars and stores complete failed
branch certificates for the exhausted runs. The third extracts
half-turn candidates from computed covers. The audit independently
checks exact intersections, transferred blocker witnesses, and
coverage. The reference comparison happens after these checks.

The comparison coordinates were reconstructed from Akiyama and
Araki's Golden Hex construction in the earlier notebook. They
represent exact placement data. The visual report renders its own
polygon diagrams from those coordinates and the computed output.

Use `publication/replay-v1.json` to compare deterministic results.
For the browser check, set `GCTS_CHROME` and `GCTS_PLAYWRIGHT` for
custom installations and run `node publication/check_v1.cjs`.
