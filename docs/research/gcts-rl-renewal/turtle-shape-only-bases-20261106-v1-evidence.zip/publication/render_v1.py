"""Render the exact Turtle seed catalogue, covers, and transferred obstruction."""
from html import escape
from math import sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from assemble_v1 import Geometry
from cluster_v1 import Model, load, mat
from collar_audit_v1 import freeze

STEM="turtle-shape-only-bases-20261106-v1"
PASTELS=("#9ed0c6","#f4d393","#c3d2ed","#b8d7a4","#e7beca","#abd8e6")
SEED="#276782"


def euclidean(p):
    x,y=p
    return x+y/2,sqrt(3)*y/2


class Diagram:
    def __init__(self,points,width=600,height=400,disk=None):
        x,y=map(list,zip(*(euclidean(p) for p in points)))
        if disk:
            center,radius=disk
            a,b=euclidean(center)
            x.extend((a-radius,a+radius))
            y.extend((b-radius,b+radius))
        self.w,self.h=width,height
        self.center=(min(x)+max(x))/2,(min(y)+max(y))/2
        self.scale=min((width-34)/(max(x)-min(x)),(height-34)/(max(y)-min(y)))

    def at(self,p):
        x,y=euclidean(p)
        u,v=self.center
        return self.w/2+(x-u)*self.scale,self.h/2-(y-v)*self.scale

    def poly(self,shape,cls,fill):
        points=" ".join(f"{a:.3f},{b:.3f}" for a,b in map(self.at,shape))
        return f'<polygon class="{cls}" points="{points}" fill="{fill}"/>'

    def lines(self,edges,cls):
        parts=[]
        for edge in sorted(edges):
            (x,y),(u,v)=map(self.at,edge)
            parts.append(f"M{x:.3f},{y:.3f}L{u:.3f},{v:.3f}")
        return f'<path class="{cls}" d="{"".join(parts)}"/>'

    def circle(self,center,radius,cls,*,pixels=False):
        x,y=self.at(center)
        r=radius if pixels else radius*self.scale
        return f'<circle class="{cls}" cx="{x:.3f}" cy="{y:.3f}" r="{r:.3f}"/>'

    def svg(self,title,content):
        return f'<svg viewBox="0 0 {self.w} {self.h}" role="img" aria-label="{escape(title)}">{content}</svg>'


def illustration(geom,patch,title,colors=None):
    colors=colors or {}
    model=geom.model
    d=Diagram([p for t in patch for p in model.poly(t)],460,300)
    content=[d.poly(model.poly(t),"tile",colors.get(t,PASTELS[i%len(PASTELS)])) for i,t in enumerate(patch)]
    content.append(d.lines(geom.boundary(patch),"outer"))
    return d.svg(title,"".join(content))


def seed_cards(geom,data,shapes):
    pair=data["selected_pair"]
    seed=data["selected_seed"]
    alt=data["alternative"]
    active=next(row for family in shapes["half_turns"] for row in family["assemblies"] if row["key"]==seed)
    colors={}
    # The two half-turn mates in each selected doublet share a placement anchor.
    for i,anchor in enumerate(sorted({t[1:] for t in seed})):
        colors.update((t,PASTELS[i]) for t in seed if t[1:]==anchor)
    assert len(active["pairs"])==3 and len(colors)==6
    cards=((pair,"Half-turn doublet","2 Turtles · 24 exposed segments",{}),
           (seed,"Most compact threefold seed","6 Turtles · 42 exposed segments",colors),
           (alt,"Other radius-ten survivor","6 Turtles · 60 exposed segments",{}))
    return "".join(f'<figure>{illustration(geom,p,t,c)}<figcaption><span class="label">{t}</span><br>{s}</figcaption></figure>'
                   for p,t,s,c in cards)


def local_mark(geom,data):
    model=geom.model
    for row in data["screened"]:
        run=row["marked"]
        if run and run["hits"]:
            hit=run["hits"][0]
            break
    else:
        raise ValueError("No transfer available")
    match=None
    for donor in data["donors"]:
        for g,m in model.groups.items():
            if m[0][0]*m[1][1]-m[0][1]*m[1][0]!=1:
                continue
            if mat(m,donor["direction"])!=hit["direction"]:
                continue
            if tuple(sorted(model.action(g,t) for t in donor["blockers"]))==hit["blockers"]:
                match=donor,g,m
                break
        if match:
            break
    donor,g,m=match
    c,b,atom=donor["cover"][0]
    ax,ay=hit["edge"][0]
    def position(tile):
        h,x,y=model.action(g,tile)
        return h,x+ax,y+ay
    q=position(c)
    blocked=position(b)
    x,y=mat(m,atom)
    sample=ax+x/model.scale,ay+y/model.scale
    patch=hit["patch"]
    points=[p for t in (*patch,q) for p in model.poly(t)]
    frame=Diagram(points,600,340)
    body=[frame.poly(model.poly(t),"tile blocker" if t==blocked else "tile",
                     "#8fbed6" if t==blocked else "#d9e7e9") for t in patch]
    body.append(frame.poly(model.poly(q),"ghost","#f2cc82"))
    body.append(frame.lines((hit["edge"],),"marked-edge"))
    body.append(frame.circle(sample,4.3,"collision",pixels=True))
    return f'''<figure class="specimen">{frame.svg("A transferred mark with one overlapping candidate", "".join(body))}
<figcaption>Donor <code>{donor["id"]}</code> supplies the mark at an edge of receiver <code>{row["id"]}</code>. The dashed polygon is one of {len(donor["cover"])} excluded neighbors. The dot is a shared occupied sample with the blue blocker. The red segment is the exposed edge.</figcaption></figure>'''


def cover_panel(geom,row,seed,highlight):
    radius=row["radius"]
    result=row["arms"]["orbit"]
    patch=result["patch"]
    num,den=result["center"]
    center=tuple(v/den for v in num)
    frame=Diagram([p for t in patch for p in geom.model.poly(t)],640,480,disk=(center,radius))
    paint={t:SEED for t in seed}
    for _,_,moves,_,generation in result["history"]:
        for tile in moves:
            paint[tile]=PASTELS[generation%len(PASTELS)]
    body=['<g class="tiles">']
    body.extend(frame.poly(geom.model.poly(t),"tile",paint[t]) for t in patch)
    body.extend(("</g>",frame.lines(result["boundary"],"outer"),'<g class="disk-layer">',
                 frame.circle(center,radius,"disk"),"</g>"))
    if highlight:
        assert set(highlight)<=set(patch)
        body.append('<g class="motif-layer">'+frame.lines(geom.boundary(highlight),"motif-edge")+'</g>')
    initial="" if radius==40 else " hidden"
    return f'''<article data-radius="{radius}" class="patch"{initial}><figure>
{frame.svg(f"Exact Turtle cover for radius {radius}", "".join(body))}
<figcaption>{len(patch):,} Turtles · {result["stats"]["states"]:,} explored states · radius {radius}</figcaption>
</figure></article>'''


def outcome(arm):
    status=arm["status"]
    if status=="COVERED":
        return f'{arm["stats"]["states"]:,} / {len(arm["patch"]):,}'
    return "Bound at 450" if status=="BOUNDED" else "Exhausted"


def table_row(name,values):
    cells="".join(f'<td class="nowrap">{escape(v)}</td>' for v in values)
    return f'<tr><th scope="row">{escape(name)}</th>{cells}</tr>'


def main():
    geom=Geometry(Model(load("input/exact-point-model-v1.json")))
    shape=freeze(load("data/assemblies-v1.json"))
    study=freeze(load("data/collars-v1.json"))
    audit=load("data/audit-v1.json")
    motifs=freeze(load("data/motifs-v1.json"))["scans"][-1]
    ref=freeze(load("input/comparison-v1.json"))
    known=geom.normalize(ref["P1"])
    rows=[r for r in motifs["shared"] if r["tiles"]==len(known)]
    lead=rows[0]
    rank=audit["parallelogram_rank"][-1]["rank"]
    recovered=rows[rank-1]
    assert recovered["key"]==known and rank==2
    motif_pictures="".join(f'<figure>{illustration(geom,row["key"],title)}<figcaption>{title} · '
                           f'{row["perimeter"]} exposed segments</figcaption></figure>'
                           for row,title in ((lead,"First-ranked eighteen-tile candidate"),
                                             (recovered,"Reference parallelogram at rank two")))
    options=[]
    panels=[]
    table=[]
    for row in study["receivers"]:
        radius=row["radius"]
        case=recovered["examples"].get(str(radius))
        options.append(f'<option value="{radius}"{" selected" if radius==40 else ""}>{radius}</option>')
        panels.append(cover_panel(geom,row,study["selected_seed"],case["patch"] if case else None))
        table.append(table_row(str(radius),[outcome(row["arms"][a]) for a in ("unit","orbit","marked","learned")]))
    comparisons=[r for r in study["screened"] if r["marked"] is not None]
    checks={k:sum(r[k]["stats"].get("placement_checks",0) for r in comparisons) for k in ("plain","marked")}
    hits=sum(r["marked"]["stats"].get("mark_hits",0) for r in comparisons)
    template=(ROOT/"publication/notebook-v1.html").read_text()
    values=dict(STEM=STEM,SEEDS=seed_cards(geom,study,shape),OPTIONS="".join(options),PATCHES="\n".join(panels),
                TABLE="".join(table),TRAIN=str(len(study["training"])),MARK=local_mark(geom,study),
                MARKS=str(len(study["donors"])),SCREEN=str(len(comparisons)),HITS=str(hits),
                PLAIN=f'{checks["plain"]:,}',MARKED=f'{checks["marked"]:,}',MOTIFS=motif_pictures,
                MOTIF_TOTAL=str(len(motifs["shared"])),P1_POP=str(len(rows)),P1_RANK="second")
    for k,v in values.items():
        template=template.replace("%%"+k+"%%",v)
    assert "%%" not in template
    (ROOT/"report"/f"{STEM}.html").write_text(template)


if __name__=="__main__":
    main()
