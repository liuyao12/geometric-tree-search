const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/turtle-shape-only-bases-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 6);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("#seeds .seed-grid svg").count(), 3);
    assert.equal(await page.locator("#patch-gallery article").count(), 5);
    assert.equal(await page.locator("#inventory .gallery svg").count(), 2);
    assert.equal(await page.locator("#marking .collision").count(), 1);
    const visible = page.locator(".patch:visible");
    assert.equal(await visible.locator("polygon.tile").count(), 330);
    assert(await visible.locator(".motif-layer").isVisible());
    if (!process.argv[2]) {
      await visible.locator("figure").screenshot({ path: path.join(__dirname, "cover-v1.png") });
      await page.locator("#marking figure").screenshot({ path: path.join(__dirname, "mark-v1.png") });
      await page.locator("#inventory .gallery").screenshot({ path: path.join(__dirname, "motifs-v1.png") });
    }
    await page.locator("#show-motif").uncheck();
    assert.equal(await visible.locator(".motif-layer:visible").count(), 0);
    await page.locator("#show-disk").uncheck();
    assert.equal(await visible.locator(".disk:visible").count(), 0);
    await page.locator("#radius").selectOption("10");
    assert.equal(await visible.locator("polygon.tile").count(), 30);
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_TURTLE_SHAPE_ONLY_READER", covers: 5, largestPatchTiles: 330,
      diskAndMotifToggles: true, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
