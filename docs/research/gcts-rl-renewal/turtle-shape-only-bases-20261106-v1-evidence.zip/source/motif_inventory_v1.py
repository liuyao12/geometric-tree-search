"""Extract larger reusable candidates from unmarked, computed collar tilings."""
from collections import defaultdict
from itertools import combinations
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, save
from collar_experiment_v1 import freeze
from cluster_v1 import Model, load

RADII=(30,40)
SIZE_LIMIT=32
PEEL_LIMITS=(3,6)


def adjacency(geom,patch):
    edges=defaultdict(set)
    for tile in patch:
        for a,b in geom.boundary((tile,)):
            edges[tuple(sorted((a,b)))].add(tile)
    graph={t:set() for t in patch}
    for tiles in edges.values():
        if len(tiles)==2:
            a,b=sorted(tiles)
            graph[a].add(b)
            graph[b].add(a)
    return graph


def component(graph,available,seed):
    pending=[seed]
    visited={seed}
    while pending:
        tile=pending.pop()
        moves=(graph[tile]&available)-visited
        pending.extend(moves)
        visited.update(moves)
    return visited


def partner(geom,tile,shift):
    out,=geom.moved((tile,),geom.rot2,shift)
    return out


def centered_components(geom,patch,graph):
    centers=defaultdict(set)
    for a,b in combinations(patch,2):
        h,x,y=geom.model.action(geom.rot2,a)
        if h==b[0]:
            centers[b[1]-x,b[2]-y].update((a,b))
    for shift,paired in sorted(centers.items()):
        rest=set(paired)
        while rest:
            region=component(graph,rest,min(rest))
            rest-=region
            if {partner(geom,t,shift) for t in region}==region:
                yield shift,tuple(sorted(region))


def expose_orbits(geom,graph,patch,shift):
    boundary=geom.boundary(patch)
    active=set(patch)
    for tile in patch:
        other=partner(geom,tile,shift)
        if tile>=other:
            continue
        ring=geom.boundary((tile,))|geom.boundary((other,))
        if not ring & boundary:
            continue
        rest=active-{tile,other}
        if rest and component(graph,rest,min(rest))==rest:
            yield (tile,other),tuple(sorted(rest))


def harvest(geom,patch,limit):
    graph=adjacency(geom,patch)
    out={}
    caps=defaultdict(int)
    for shift,base in centered_components(geom,patch,graph):
        caps[len(base)]+=1
        if len(base)>SIZE_LIMIT:
            continue
        seen=set()
        def visit(current,peels):
            if current in seen:
                return
            seen.add(current)
            if geom.ring(current):
                key=geom.normalize(current)
                out.setdefault(key,dict(shift=shift,base=base,peels=peels,patch=current))
            if len(peels)<limit:
                for pair,rest in expose_orbits(geom,graph,current,shift):
                    visit(rest,(*peels,pair))
        visit(base,())
    return out,dict(caps)


def main():
    geom=Geometry(Model(load("input/exact-point-model-v1.json")))
    results=load("data/collars-v1.json")
    patches={r["radius"]:freeze(r["arms"]["orbit"]["patch"])
             for r in results["receivers"] if r["radius"] in RADII}
    scans=[]
    for limit in PEEL_LIMITS:
        banks={}
        caps={}
        for radius,patch in patches.items():
            banks[radius],caps[radius]=harvest(geom,patch,limit)
        shared=set.intersection(*(set(bank) for bank in banks.values()))
        ranked=sorted(shared,key=lambda p:(len(p),len(geom.boundary(p)),p))
        rows=[dict(key=p,tiles=len(p),perimeter=len(geom.boundary(p)),
                   examples={r:banks[r][p] for r in RADII}) for p in ranked]
        scans.append(dict(peels=limit,counts={r:len(bank) for r,bank in banks.items()},components=caps,shared=rows))
        print("motif bank",limit,{r:len(b) for r,b in banks.items()},"shared",len(rows),flush=True)
    save("data/motifs-v1.json",dict(status="COMPUTED_SYMMETRIC_MOTIF_INVENTORY",radii=RADII,
                                    maximum=SIZE_LIMIT,scans=scans))


if __name__=="__main__":
    main()
