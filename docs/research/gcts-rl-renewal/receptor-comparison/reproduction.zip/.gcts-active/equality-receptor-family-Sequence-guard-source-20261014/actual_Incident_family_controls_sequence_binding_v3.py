"""SOURCE-only cold actual family controls; no search/automatic admission.

ROOT later supplies two fresh q/control-authorizations bound to this exact source
and the accepted candidate extraction. The current math seal is not advice
admission. No authorization or plan is produced by this leaf. Complete controls
use real modules/graphs inside one20s inner window; serialization/exit belongs
to the unchanged60s/512MiB/90s generic owned envelope.
"""
import hashlib
import importlib.util
import inspect
import json
import math
from pathlib import Path
import resource
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = 'ROOT-real-I2-Incident-family-controls-worker-plan-v1'
SCOPE = 'actual-family-ground-domain-control-no-search-no-admission'
COMMAND = 'ROOT-real-I2-Incident-family-controls'
LIMITS = dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)
MAX_METADATA = 64*1048576
AUTHOR = '/root/hilbert_advice_controls'
PROFILE = 'hilbert-fresh-guarded-I2-cohort-static-v1'
INPUT_ROLES = {'candidate_library','independent_audit','ROOT_extraction_disposition','control_manifest','control_request_specification'}
OUTPUT_NAMES = ('actual-family-controls-v1.json','actual-family-controls-evidence-v1.json','actual-family-controls-result-v1.json')
FROZEN_SOURCES = {'candidate_advice': {'bytes': 27264, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-incidence-priority-source-20261013/incidence_priority_witness_advice_v2.py', 'sha256': '3a86adba8982c406ae4a2ad3349b8ae962e52498dee38ee3ee26719b22468053'}, 'certificate': {'bytes': 64498, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-first-proof-helper-source-20261013/i2_context_and_final24_certificate_v1.py', 'sha256': 'c8fa4aeba82fcc2af9bd091fd351d72f86a24ae97cb5edd92ff558e81c23501b'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'dynamic_graph_adapter': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'dynamic_lifecycle_adapter': {'bytes': 29230, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-dynamic-source-20261012/compact_cluster_lifecycle_v2.py', 'sha256': '677c48c7aebfecf0c83c8daa8bf8e873d0be1e415906afa6687f0b9652e33719'}, 'family_advice': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/equality_receptor_family_I2_sequence_guard_v3.py', 'sha256': 'b4d20eaf6c7f5db25e7ab7a70303e7d39a733b49c2cec300b363cbc3f7fbfaa5', 'bytes': 62803}, 'features31': {'bytes': 12386, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-rl-small-source-20261012/family_graph_features_v1.py', 'sha256': '644e4cd195f98c1ca3f97c3fcba84dfdbc18765454512435702951cc6169a14b'}, 'final_certificate': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/I2_family_final24_sequence_guard_binding_v4.py', 'sha256': '10a41171c18a82e6f33d13403aae9e441a69d7fd11f065ff5497aea415f0188f', 'bytes': 70208}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'policy_math': {'bytes': 11607, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-learning-20261012/family_policy_math_v2.py', 'sha256': '61b772b45ed4523ba4c14ae4519cd9dae53c21d4dc1b1681689011707831c294'}, 'proof_observer': {'bytes': 29717, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-observer-controls-source-20261013/first_checked_proof_observer_i2_v1.py', 'sha256': 'ad2efd1b7685fe6f7baa8f3b9849baf3568c3cf67e87a85e3d0ac657d8772cdc'}, 'streamed_dfs': {'bytes': 49263, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/compact_I2_family_first_checked_proof_dfs_v12.py', 'sha256': '57e415f9822f73dcbec2f16f45564196de519476ab2b0f3fbb9097fc972d8859'}, 'streamed_overlay': {'bytes': 18348, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/I2_family_consumer_overlay_v2.py', 'sha256': 'df05db866111b8e5c86ddffb9c9a0216678d6e171c7b5f1bdde866573f87ab4b'}, 'streamed_proposal': {'bytes': 25358, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-streamed-consumers-source-20261012/compact_cluster_proposal_v2.py', 'sha256': '1d094e7f51c7607cc121a48e0bc55f4daf2cc7801701eea34a2bb552f1505b38'}, 'transport': {'bytes': 13756, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/curriculum-compact-wrapper-source-20261012/compact_static_transport_v1.py', 'sha256': '65a0b598966ae4dffdda1b770eb2d4d5b64af1bcaf6aead4281a224a4123def3'}, 'mechanism_controls': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-controls-source-20261014/actual_Incident_family_controls_v1.py', 'sha256': '70187b4ad5b0a733dedae6b9ac0f9cf20bc398fe83d96fdf17ba522c20cf8583', 'bytes': 20345}}
SOURCE_ROLES = set(FROZEN_SOURCES)|{'worker'}
ACTUAL_INPUTS = {'candidate_library': {'bytes': 85344, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/worker-output-v1/candidate-library-v1.json', 'sha256': '08e75860545d3e0248e99c36858b0ca25d1bcbb1c7ad01b3cd2d332d51149e07'}, 'independent_audit': {'bytes': 41490, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/worker-output-v1/independent-all-origin-audit-v1.json', 'sha256': '55a9e8c2a4df287da9dbc2c72c42c4b13de520e6eafb02bd61124919b5ee22be'}, 'ROOT_extraction_disposition': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/ROOT-actual-family-extraction-disposition-v1.json', 'sha256': '757606d7a20048e5a8335559c96cf1749e1ab53f900bdff593fb10beeed8a173', 'bytes': 7879}, 'control_request_specification': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/control-request-v1.json', 'sha256': '968bece73bfb8ee0ec480d654dafe5d53e2b94c48e9a90502c1ca06c6e1a4204', 'bytes': 6347}}
CASE_IDS = ('fresh-i2-CD-vw-direct','fresh-i2-CD-vw-incidence-transport')

def need(value, label):
    if not value:
        raise ValueError(label)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def pin(path):
    path = Path(path)
    need(path.is_absolute() and str(path.resolve()) == str(path) and not path.is_symlink(), 'canonical ABS pin')
    h = hashlib.sha256(); count = 0; before = path.stat()
    with path.open('rb') as stream:
        for raw in iter(lambda: stream.read(65536), b''):
            h.update(raw); count += len(raw)
    after = path.stat()
    need((before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size) ==
         (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size), 'whole stable raw bytes')
    return dict(path=str(path), sha256=h.hexdigest(), bytes=count)


def verify(record):
    need(type(record) is dict and set(record) == {'path','sha256','bytes'}
         and type(record['bytes']) is int and record['bytes'] >= 0
         and type(record['sha256']) is str and len(record['sha256']) == 64
         and all(c in '0123456789abcdef' for c in record['sha256'])
         and pin(record['path']) == record, 'typed canonical full pin')
    return record


def parse(raw):
    def unique(pairs):
        result = {}
        for name, value in pairs:
            need(name not in result, 'duplicate JSON field'); result[name] = value
        return result
    return json.loads(raw, object_pairs_hook=unique,
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError('nonfinite JSON '+token)))


def read(record, maximum=MAX_METADATA):
    verify(record)
    with Path(record['path']).open('rb') as stream:
        raw = stream.read(maximum+1)
        need(len(raw) <= maximum and stream.read(1) == b'', 'whole bounded raw buffer, no prefix')
    need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
         'parse the authenticated same raw buffer')
    value = parse(raw); verify(record); return value


def load(record, name):
    verify(record); raw = Path(record['path']).read_bytes()
    need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
         'same exact raw source execution buffer')
    spec = importlib.util.spec_from_file_location(name, record['path'])
    need(spec is not None, 'source metadata spec')
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module
    exec(compile(raw, record['path'], 'exec'), module.__dict__)
    need(str(Path(module.__file__).resolve()) == record['path'], 'bound raw source origin, no bytecode loader')
    return module


def normalize(record):
    path = Path(record['path']); actual = path if path.is_absolute() else ROOT/path
    return dict(record, path=str(actual))


def value_state(value):
    """Detect ordinary namespace/default mutation without accepting origin claims."""
    if value is None or type(value) in (str, int, bool, float, list, dict, tuple):
        try: return canonical(value)
        except (TypeError, ValueError): pass
    return None


def executable_state(module, *, class_roots=()):
    state = []; namespaces = []; mros = []; seen_classes = set()
    def keys(owner):
        return tuple(k for k in vars(owner) if not k.startswith('__') and k != '_NEXT_CAPSULE')
    def add(owner, name, value):
        if isinstance(value, (staticmethod, classmethod)): value = value.__func__
        code = value.__code__ if inspect.isfunction(value) else None
        defaults = (value_state(value.__defaults__), value_state(value.__kwdefaults__)) if code else None
        closure = tuple((cell.cell_contents, value_state(cell.cell_contents))
                        for cell in (value.__closure__ or ())) if code else None
        state.append((owner, name, value, code, defaults, closure, value_state(value)))
        if isinstance(value, property):
            # The descriptor object can stay unchanged while its getter code mutates.
            for accessor in ('fget', 'fset', 'fdel'):
                add(value, accessor, getattr(value, accessor))
    def record_class(value):
        # Generated methods may dispatch through super() or a captured base_type.
        # Preserve every actual MRO class/method, not just that class object's ID.
        for parent in value.__mro__:
            if parent is object or parent in seen_classes: continue
            seen_classes.add(parent); mros.append((parent, parent.__mro__))
            namespaces.append((parent, keys(parent)))
            for field, child in vars(parent).items():
                if field not in ('__dict__', '__weakref__'): add(parent, field, child)
    namespaces.append((module, keys(module)))
    for name, value in vars(module).items():
        if name.startswith('__') or name == '_NEXT_CAPSULE': continue
        add(module, name, value)
        if isinstance(value, type) and value.__module__ == module.__name__:
            record_class(value)
    for value in class_roots:
        need(isinstance(value, type), 'actual generated endpoint class')
        record_class(value)
    return namespaces, state, mros


def unchanged_executable(state):
    namespaces, records, mros = state
    for owner, original_mro in mros:
        need(owner.__mro__ == original_mro and all(a is b for a, b in zip(owner.__mro__, original_mro)),
             'compiled generated endpoint inheritance changed')
    for owner, names in namespaces:
        need(tuple(k for k in vars(owner) if not k.startswith('__') and k != '_NEXT_CAPSULE') == names,
             'compiled namespace gained or lost bindings')
    for owner, name, original, code, defaults, closure, data in records:
        actual = getattr(owner, name) if isinstance(owner, property) else vars(owner).get(name)
        if isinstance(actual, (staticmethod, classmethod)): actual = actual.__func__
        need(actual is original, 'compiled namespace/function identity changed')
        if code is not None:
            need(actual.__code__ is code and
                 (value_state(actual.__defaults__), value_state(actual.__kwdefaults__)) == defaults,
                 'compiled executable/defaults changed; co_filename is insufficient')
            current = actual.__closure__ or ()
            need(len(current) == len(closure) and all(cell.cell_contents is old and value_state(cell.cell_contents) == text
                 for cell, (old, text) in zip(current, closure)), 'compiled source closure changed')
        if data is not None: need(value_state(actual) == data, 'compiled source constant changed')


def preflight(plan_path, owner_path):
    plan_pin, owner_pin = pin(plan_path), pin(owner_path)
    plan = read(plan_pin,2*1048576); owner = read(owner_pin,2*1048576)
    need(set(plan)=={'schema','ROOT_owned_once_only','scope','sources','inputs','runtime',
        'reviews','closure','limits','owner_plan_path','output_directory'}
        and plan['schema']==SCHEMA and plan['ROOT_owned_once_only'] is True
        and plan['scope']==SCOPE and plan['limits']==LIMITS,
        'same strict11-field leaf and original60/512/90 stage')
    need(plan_path.parent==owner_path.parent and plan['owner_plan_path']==str(owner_path)
        and set(plan['sources'])==SOURCE_ROLES and set(plan['inputs'])==INPUT_ROLES
        and set(plan['reviews'])=={'ROOT','independent'},'whole exact source/input/review ABI')
    need({k:v for k,v in plan['sources'].items() if k!='worker'}==FROZEN_SOURCES
        and plan['sources']['worker']==pin(Path(__file__).resolve()),
        'exact current20-role executable/source set, never arbitrary raw closure')
    output=Path(plan['output_directory'])
    need(output.is_absolute() and output==output.resolve() and output.parent==plan_path.parent
        and not output.exists(),'exclusive future full output namespace')
    closure={}
    for record in plan['closure']:
        verify(record);need(record['path'] not in closure,'whole closure has unique canonical paths')
        closure[record['path']]=record
    need(list(closure)==sorted(closure),'sorted complete declared raw closure')
    for record in [*plan['sources'].values(),*plan['inputs'].values(),*plan['reviews'].values()]:
        verify(record);need(closure.get(record['path'])==record,'each direct pin closed')
    for which in ('ROOT','independent'):
        review=read(plan['reviews'][which])
        need(review.get('source_only') is True and review.get('source_review_passed') is True
            and type(review.get('scientific_calls')) is int and review['scientific_calls']==0
            and review.get('sources')==plan['sources'],'current whole SOURCE review, not acceptance')
        if which=='independent':
            need(review.get('author_identity')==AUTHOR and type(review.get('reviewer_identity')) is str
                and review['reviewer_identity']!=AUTHOR,'separate SOURCE reviewer')
    need(plan['reviews']['ROOT']['path']==str(plan_path.parent/'ROOT-source-review-v1.json'),
         'existing owner local ROOT source review')
    runtime=plan['runtime']
    need(set(runtime)=={'binary','resource_extension','python_version','platform'}
        and runtime['python_version']==[3,9,6] and runtime['platform']=='darwin'
        and list(sys.version_info[:3])==[3,9,6] and sys.platform=='darwin',
        'same frozen actual CLT runtime')
    for role in ('binary','resource_extension'):
        verify(runtime[role]);need(closure.get(runtime[role]['path'])==runtime[role],'runtime closed')
    need(str(Path(sys.executable).resolve())==runtime['binary']['path']
        and str(Path(resource.__file__).resolve())==runtime['resource_extension']['path'],
        'actual runtime and resource extension origins')
    argv=[runtime['binary']['path'],'-B',plan['sources']['worker']['path'],
          COMMAND,str(plan_path),str(owner_path)]
    need(set(owner)=={'schema','stage','runtime_binary','worker','argv','worker_receipt',
                     'limits','closure','ROOT_source_review','scope'}
        and owner['schema']=='ROOT-guard-native-owned-plan-v1'
        and owner['stage']=='replay' and owner['limits']==LIMITS and owner['argv']==argv
        and owner['scope']==SCOPE
        and normalize(owner['ROOT_source_review'])==plan['reviews']['ROOT']
        and normalize(owner['runtime_binary'])==runtime['binary']
        and normalize(dict(path=owner['worker'],sha256='',bytes=0))['path']==str(Path(__file__).resolve())
        and normalize(dict(path=owner['worker_receipt'],sha256='',bytes=0))['path']==str(output/OUTPUT_NAMES[2]),
        'unchanged exact10-field owned-stage ABI')
    owner_closure={normalize(record)['path']:normalize(record) for record in owner['closure']}
    need(len(owner_closure)==len(owner['closure'])
        and all(owner_closure.get(path)==record for path,record in closure.items())
        and owner_closure.get(str(plan_path))==plan_pin,'whole explicit owner closure')
    for record in owner_closure.values():verify(record)
    for module in tuple(sys.modules.values()):
        origin=getattr(module,'__file__',None)
        if origin and ROOT in Path(origin).resolve().parents and Path(origin).suffix=='.py':
            need(Path(origin).resolve()==Path(__file__).resolve(),'genuine cold source worker')
    return plan,output,plan_pin,owner_pin,closure,owner_closure


def source_cache_guard(sources, modules, anchors):
    """An explicit executable allowlist; evidence closure cannot authorize code."""
    allowed={record['path']:record for record in sources.values() if record['path'].endswith('.py')}
    ledger={}
    need(set(modules)==set(anchors) and all(modules[role] is value for role,value in anchors.items()),
         'original exact directly compiled module endpoints')
    for module in tuple(sys.modules.values()):
        origin=getattr(module,'__file__',None)
        if not origin:continue
        path=Path(origin).resolve()
        if ROOT not in path.parents or path.suffix!='.py':continue
        need(str(path) in allowed and str(path)==origin,'only exact disclosed executable raw paths')
        verify(allowed[str(path)]);ledger[str(path)]=allowed[str(path)]
    return [ledger[path] for path in sorted(ledger)]


def function_signature(fn):
    return (fn, fn.__code__, tuple(id(v) for v in fn.__defaults__ or ()),
            tuple((k,id(v)) for k,v in sorted((fn.__kwdefaults__ or {}).items())),
            tuple((id(c),id(c.cell_contents)) for c in fn.__closure__ or ()))



def main():
    began = time.perf_counter()
    need(len(sys.argv) == 4 and sys.argv[1] == COMMAND, 'one cold real-family control child')
    plan_path, owner_path = (Path(value) for value in sys.argv[2:])
    need(all(path.is_absolute() and path == path.resolve() for path in (plan_path, owner_path)),
         'canonical literal owned plans')
    plan, output, plan_pin, owner_pin, closure, owner_closure = preflight(plan_path, owner_path)
    need({name: plan['inputs'][name] for name in ACTUAL_INPUTS} == ACTUAL_INPUTS,
         'exact actual unadmitted extraction/audit/math seal, never replacement training')
    artifacts = []
    def whole_tick():
        need(time.perf_counter() - began < 55 and
             resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < 500 * 1048576,
             'original whole60s/512MiB enclosing reserves')
    def save(name, value):
        whole_tick(); raw = (canonical(value) + '\n').encode('utf8')
        need(len(raw) <= MAX_METADATA, 'whole bounded output; no prefix')
        path = output / name
        with path.open('xb') as stream:
            need(stream.write(raw) == len(raw), 'complete output buffer')
        record = pin(path); artifacts.append(record); whole_tick()
        return record
    own = sys.modules[__name__]
    validator_names = ('need','pin','verify','read','load','executable_state','unchanged_executable','source_cache_guard','function_signature')
    validators = {name: (globals()[name], globals()[name].__code__) for name in validator_names}
    guard_fn, guard_code = unchanged_executable, unchanged_executable.__code__
    own_state = executable_state(own)
    modules = {}; states = []
    inner_began = time.perf_counter(); deadline = inner_began + LIMITS['control_seconds']
    def inner_tick():
        whole_tick()
        if time.perf_counter() >= deadline:
            raise TimeoutError('whole20s actual-family controls incomplete; no accepted prefix')
    try:
        direct_roles = ('certificate','logical_oracle','point_core','compact_graph','compact_decoder',
            'dynamic_graph_adapter','dynamic_lifecycle_adapter','features31','policy_math',
            'streamed_dfs','streamed_overlay','family_advice','mechanism_controls')
        for role in direct_roles:
            if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):
                raise ValueError('original cold validator changed before project load')
            inner_tick()
            module = load(plan['sources'][role], '_actual_Incident_family_controls_' + role)
            modules[role] = module; states.append(executable_state(module))
            if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):
                raise ValueError('original cold validator changed after project load')
            guard_fn(own_state)
            for state in states:
                guard_fn(state)
        anchors = dict(modules)
        seal = read(ACTUAL_INPUTS['ROOT_extraction_disposition'])
        library = read(ACTUAL_INPUTS['candidate_library']); audit = read(ACTUAL_INPUTS['independent_audit'])
        need(seal['ROOT_complete_finite_extraction_and_ground_audit_accepted'] is True
             and seal['ROOT_advice_admission'] is False and seal['ROOT_library_admitted'] is False
             and seal['actual_candidate_library'] == ACTUAL_INPUTS['candidate_library']
             and seal['actual_independent_audit'] == ACTUAL_INPUTS['independent_audit']
             and seal['counts']['all_command_roots'] == 27
             and audit['schema'] == 'independent-complete-Incident-donor-root-audit-v1'
             and audit['completed'] is True and audit['all_checks_passed'] is True
             and library['ROOT_inventory_admitted'] is False
             and library['schema_universally_validated'] is False,
             'actual finite extraction scope retained; it is not session/search authority')
        request = read(ACTUAL_INPUTS['control_request_specification'])
        need(request['schema'] == 'I2-family-consumer-prospective-control-request-v1'
             and request['tests_executed'] == 0 and request['actual_runtime_acceptance'] is False,
             'request definitions are not actual control results')
        manifest = read(plan['inputs']['control_manifest'])
        need(set(manifest) == {'schema','ROOT_controls_authorized','scientific_episode_activation',
             'library','audit','extraction_disposition','recipients'}
             and manifest['schema'] == 'ROOT-two-I2-finite-family-controls-input-manifest-v1'
             and manifest['ROOT_controls_authorized'] is True
             and manifest['scientific_episode_activation'] is False
             and manifest['library'] == ACTUAL_INPUTS['candidate_library']
             and manifest['audit'] == ACTUAL_INPUTS['independent_audit']
             and manifest['extraction_disposition'] == ACTUAL_INPUTS['ROOT_extraction_disposition']
             and tuple(item['instance_id'] for item in manifest['recipients']) == CASE_IDS,
             'future ROOT controls-only manifest, never manufactured by this worker')
        core = modules['point_core']; dynamic = modules['dynamic_graph_adapter']
        reader = modules['certificate']; family = modules['family_advice']
        runtime_roles = ('point_core','compact_graph','compact_decoder','dynamic_graph_adapter','dynamic_lifecycle_adapter')
        graph_type = dynamic.make_dynamic_graph_type(core, modules['compact_graph'], modules['compact_decoder'],
            runtime_sources=[dict(role=role, **plan['sources'][role]) for role in runtime_roles])
        life = modules['dynamic_lifecycle_adapter'].make_lifecycle(core, graph_type)
        life_body_type, life_controller_type = life.BodyAuthority, life.Controller
        states.append(executable_state(dynamic, class_roots=(graph_type,)))
        states.append(executable_state(modules['dynamic_lifecycle_adapter'], class_roots=(life.BodyAuthority, life.Controller)))
        outcomes = []; consumed_pins = []; actual_bindings = []
        manifest_text = canonical(manifest); plan_text = canonical(plan)
        for recipient in manifest['recipients']:
            inner_tick()
            need(set(recipient) == {'instance_id','qualification','controls_admission',
                 'family_registry_binding','expected_inventory_binding'}, 'exact five-field current control context')
            closed = reader.ClosedInputs()
            closed_methods = family.method_state(closed)
            q = closed.json(recipient['qualification'])
            header, gamma, target, theory, license_pin, static = reader.admitted_context(closed, q)
            need(q['instance_id'] == recipient['instance_id'] == header['instance_id']
                 and q['declaration_profile'] == PROFILE and len(gamma) == 3,
                 'unchanged exact current I.2 static context and indexed original Gamma')
            graph = graph_type(header_pin=q['catalog'])
            catalog_type = type(graph.catalog)
            graph_methods = family.method_state(graph)
            catalog_methods = family.method_state(graph.catalog)
            states.append(executable_state(dynamic, class_roots=(catalog_type,)))
            for state in states:
                guard_fn(state)
            need(graph.catalog.header == header and len(graph.recipes) == header['dimensions']['primitive_license_count']
                 and len(graph.formulas) == header['dimensions']['formula_count'] and graph.height == 24
                 and header['bodies'] == header['complete_cluster_inventory'] == [],
                 'full current catalogue/Gamma/fixed boundary and empty primitive inventory')
            body_records = [recipient['qualification']] + [plan['sources'][role] for role in sorted(plan['sources'])]
            authority = life.BodyAuthority.build(graph, body_records, [])
            control = life.Controller(graph, authority, [])
            authority_methods = family.method_state(authority)
            controller_methods = family.method_state(control)
            inventory = modules['streamed_dfs'].complete_inventory_binding(graph, authority, control,
                header['dimensions'], core)
            need(inventory == recipient['expected_inventory_binding'] and authority.bodies == ()
                 and control.descriptors == (), 'actual complete empty control inventory, distinct from advice registry')
            cb = q['expected_consumer_source_binding']
            modules['streamed_overlay'].check_consumer_binding(cb, graph, core, modules['features31'], modules['policy_math'],
                dfs_function=modules['streamed_dfs'].search_episode, family_session_class=family.FamilySession)
            admission = closed.json(recipient['controls_admission'])
            need(admission['controls_scope'] == 'real-ground-instance-and-domain-controls-only'
                 and admission['scientific_episode_activation'] is False
                 and admission['extraction_audit'] == ACTUAL_INPUTS['independent_audit'],
                 'explicit controls scope; full scientific advice admission remains pending')
            graph_anchor = graph; closed_anchor = closed; header_text = canonical(header); q_text = canonical(q)
            checker = modules['logical_oracle'].GroundChecker
            source_guard = None; source_guard_code = None
            def source_guard():
                # Direct identity/code gate runs before any mutable validator.
                if (source_guard.__code__ is not source_guard_code or
                        any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()) or
                        unchanged_executable is not guard_fn or guard_fn.__code__ is not guard_code):
                    raise ValueError('cold source/validator callback substituted')
                guard_fn(own_state)
                for state in states:
                    guard_fn(state)
                need(graph is graph_anchor and type(graph) is graph_type and type(graph.catalog) is catalog_type
                     and closed is closed_anchor and type(closed) is reader.ClosedInputs
                     and core is graph._bound_core and modules['logical_oracle'].GroundChecker is checker,
                     'same graph/generated catalogue/current reader/checker endpoints')
                need(life.BodyAuthority is life_body_type and life.Controller is life_controller_type
                     and type(authority) is life_body_type and type(control) is life_controller_type
                     and family.method_state(closed) == closed_methods
                     and family.method_state(graph) == graph_methods
                     and family.method_state(graph.catalog) == catalog_methods
                     and family.method_state(authority) == authority_methods
                     and family.method_state(control) == controller_methods,
                     'unchanged effective instance methods/accessors/MRO before registry and every guard')
                need(canonical(manifest) == manifest_text and canonical(plan) == plan_text
                     and canonical(q) == q_text and canonical(header) == header_text,
                     'same complete loaded manifest/q/header/plan')
                source_cache_guard(plan['sources'], modules, anchors)
                for record in closure.values():
                    verify(record)
                for record in owner_closure.values():
                    verify(record)
                need(pin(plan_path) == plan_pin and pin(owner_path) == owner_pin, 'same literal once-only plans')
                closed.close()
                for record in closed.pins.values():
                    value = normalize(record); verify(value)
                    need(closure.get(value['path']) == value, 'every actual named metadata read is in full closure')
                graph.assert_runtime_integrity(); inner_tick()
            source_guard_code = source_guard.__code__
            callback_fn = source_guard; callback_anchor = function_signature(callback_fn)
            def invoke_guard():
                if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):
                    raise ValueError('cold validator replaced before callback delegation')
                if function_signature(callback_fn) != callback_anchor:
                    raise ValueError('original callback function/code/default/closure identities changed')
                callback_fn()
                if function_signature(callback_fn) != callback_anchor:
                    raise ValueError('original callback changed during delegation')
            invoke_fn = invoke_guard; invoke_anchor = function_signature(invoke_fn)
            if function_signature(invoke_guard) != invoke_anchor:
                raise ValueError('checked callback shim changed')
            invoke_fn()
            registry = modules['streamed_dfs'].checked_family_registry(graph, core, modules['streamed_overlay'], family,
                dict(source_guard=invoke_guard, closed=closed, header=header, license_pin=license_pin),
                cb, inventory, plan['sources']['family_advice'], recipient['controls_admission'],
                recipient['family_registry_binding'], deadline)
            if function_signature(invoke_guard) != invoke_anchor:
                raise ValueError('callback shim changed during registry gate')
            invoke_fn()
            need(registry['recipient_qualification'] == recipient['qualification']
                 and registry['library_source'] == ACTUAL_INPUTS['candidate_library'], 'real controls use exact saved candidate wire')
            call_started = time.perf_counter()
            result = modules['mechanism_controls'].run_controls(graph=graph, core=core, family=family,
                reader=reader, checker_class=checker, closed=closed, header=header, license_pin=license_pin,
                library_pin=ACTUAL_INPUTS['candidate_library'], controls_admission_pin=recipient['controls_admission'],
                implementation_pin=plan['sources']['family_advice'], source_guard=invoke_guard, deadline=deadline)
            if function_signature(invoke_guard) != invoke_anchor:
                raise ValueError('callback shim changed during complete controls')
            invoke_fn()
            need(result['completed'] is True and result['exact_root_rollback_checked'] is True
                 and result['real_pending_reader_case_exercised'] is True and result['real_forced_case_exercised'] is True
                 and result['real_dead_case_exercised'] is True and result['literal_complete_domain_EOF_measured'] is True
                 and result['scientific_consumer_activation'] is False and result['inventory_admission'] is False,
                 'whole mandatory real-family/point/domain scope; absent coverage is not passed')
            outcomes.append(dict(instance_id=q['instance_id'], qualification=recipient['qualification'],
                controls_admission=recipient['controls_admission'], family_registry_binding=registry,
                full_controls=result, control_call_seconds=time.perf_counter()-call_started))
            actual_bindings.append(dict(instance_id=q['instance_id'], model_epoch=graph.model_epoch,
                catalog_identity_sha256=graph.catalog_identity_sha, runtime_authority_sha256=graph.runtime_authority_sha,
                consumer_source_binding_sha256=core.digest(cb), complete_inventory_binding=inventory))
            consumed_pins.extend(normalize(record) for record in closed.pins.values())
        inner_complete = time.perf_counter()-inner_began
        controls = dict(schema='owned-two-current-I2-family-control-census-v1', completed=True,
            all_case_ids=list(CASE_IDS), case_controls=outcomes, original_extraction_scope_retained=True,
            source_control_request_count=len(request['requirements']), actual_check_count=sum(len(x['full_controls']['tests']) for x in outcomes),
            request_count_is_not_pass_count=True, inner_complete_seconds=inner_complete,
            all_actual_bindings=actual_bindings, primitive_source_body_count=0,
            scientific_consumer_activation=False, inventory_admission=False,
            target_proofs_accepted=False, full24_board_accepted=False, RL_episodes=0, training_updates=0)
        inner_tick()
        output.mkdir()
        controls_pin = save(OUTPUT_NAMES[0], controls)
        evidence_pin = save(OUTPUT_NAMES[1], dict(schema='owned-real-family-controls-evidence-v1',
            worker_plan=plan_pin, owner_plan=owner_pin, sources=plan['sources'], inputs=plan['inputs'],
            controls=controls_pin, exact_executed_project_source_ledger=source_cache_guard(plan['sources'], modules, anchors),
            named_consumed_metadata_pins=list({p['path']:p for p in consumed_pins}.values()),
            actual_control_bindings=actual_bindings, inner_complete_seconds=inner_complete,
            request_count_is_not_pass_count=True, scientific_consumer_activation=False,
            mathematical_target_acceptance=False, library_admission=False, resource_acceptance_issued=False))
        save(OUTPUT_NAMES[2], dict(schema='owned-real-family-controls-receipt-v1', stage='replay',
            stage_completed=True, status='complete_real_family_controls_pending_ROOT', worker_plan=plan_pin,
            owner_plan=owner_pin, evidence=evidence_pin, controls=controls_pin,
            all_direct_children_terminal_and_reaped=True, direct_children_peak_sum_bytes=0,
            worker_elapsed_before_receipt_seconds=time.perf_counter()-began,
            worker_SELF_peak_before_receipt_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scientific_consumer_activation=False, inventory_admission=False,
            target_searches=0, DFS_search_calls=0, full24_board_accepted=False,
            RL_episodes=0, training_updates=0, resource_acceptance_issued=False))
        whole_tick()
        print(canonical(dict(stage_completed=True, actual_cases=2, scientific_consumer_activation=False)), flush=True)
        whole_tick()
    except BaseException as exc:
        failure = dict(schema='owned-real-family-controls-failure-v1', stage='replay', stage_completed=False,
            status='UNKNOWN_incomplete_real_family_controls', error=dict(type=type(exc).__name__, message=str(exc)[:512]),
            worker_plan=plan_pin, owner_plan=owner_pin, partial_artifact_pins=artifacts, accepted_prefix=False,
            scientific_consumer_activation=False, inventory_admission=False, target_searches=0, RL_episodes=0)
        if output.exists():
            raw = (canonical(failure)+'\n').encode('utf8')
            if len(raw) <= 1048576:
                with (output/'failure-v1.json').open('xb') as stream:
                    stream.write(raw)
        raise


if __name__ == '__main__':
    main()
