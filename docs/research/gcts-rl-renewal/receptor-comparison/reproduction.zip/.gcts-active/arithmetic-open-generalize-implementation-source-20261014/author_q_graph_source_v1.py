"""Metadata/source-text authoring only. Never imports or calls the graph."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/arithmetic-open-generalize-implementation-source-20261014'
PARENT=ROOT/'.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py'

def pin(path):
    raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def main():
    original=PARENT.read_text();child=original[:original.index('\ndef frozen_model(')]
    old_doc=ast.parse(original).body[0];lines=original.splitlines(keepends=True)
    old_text=''.join(lines[old_doc.lineno-1:old_doc.end_lineno])
    child=child.replace(old_text,'"""SOURCE ONLY Q point-core successor: true zero/unary/binary interfaces.\n\n+Full original point dependency/scheduler/trail semantics preserved. Unary\n+generalize has one genuine prior-source mark and one ordered offset; it is not\n+encoded as binary MP. The inherited simple full-board Executor is retained for\n+point controls only, and is NOT an admitted traced first-proof search driver.\n+No old geometry model loader or native/semantic/compiler authority is retained.\n+"""\n',1)
    child=child.replace('MARKING_VERSION = "injective-formula-ordered-mp-offset-v1"',
        'MARKING_VERSION = "injective-formula-ordered-primitive-offset-Q-v1"',1)
    old='''            if len(premises) not in (0, 2):
                raise ValueError("this frozen grammar has zero or two ordered ports")
            if len(premises) == 2:
'''
    new='''            if len(premises) not in (0, 1, 2):
                raise ValueError("Q grammar has zero, unary or binary ordered ports")
            if len(premises) == 1:
                if (rule != "generalize" or type(witness.get("variable")) is not str
                        or not witness["variable"]
                        or witness["formula"] != ["all", witness["variable"], premises[0]]):
                    raise ValueError("exact unary generalization interface required")
            elif len(premises) == 2:
'''
    if child.count(old)!=1:raise ValueError('exact constructor parent anchor')
    child=child.replace(old,new,1)
    child=child.replace('elif rule == "mp" or rule not in ("axiom", "instantiate", "eq_subst", "assumption", "fixture_zero"):',
        'elif rule in ("mp", "generalize") or rule not in ("axiom", "instantiate", "eq_subst", "assumption", "fixture_zero"):',1)
    old='''            else:
                left = self._input_mask(row, recipe.inputs[0], 0)
                right = self._input_mask(row, recipe.inputs[1], 1)
'''
    new='''            elif len(recipe.inputs) == 1:
                left = self._input_mask(row, recipe.inputs[0], 0)
                count = popcount(left)
                if count:
                    factors.append(Factor(recipe.index, left, 0, False, count))
            else:
                left = self._input_mask(row, recipe.inputs[0], 0)
                right = self._input_mask(row, recipe.inputs[1], 1)
'''
    if child.count(old)!=1:raise ValueError('exact unary factor parent anchor')
    child=child.replace(old,new,1)
    child=child.replace('''            a, b = key.refs
            return bool((f.left >> a) & 1''',
        '''            if len(recipe.inputs) == 1:
                return bool((f.left >> key.refs[0]) & 1)
            a, b = key.refs
            return bool((f.left >> a) & 1''',1)
    old='''            else:
                for a in set_bits(factor.left):
                    for b in set_bits(factor.right):
'''
    new='''            elif len(recipe.inputs) == 1:
                for a in set_bits(factor.left):
                    key = Key(recipe.index, row, (a,))
                    if key not in self.excluded[row]:
                        yield key
            else:
                for a in set_bits(factor.left):
                    for b in set_bits(factor.right):
'''
    if child.count(old)!=1:raise ValueError('exact unary enumeration parent anchor')
    child=child.replace(old,new,1)
    child=child.replace('''        elif recipe.inputs:  # Explicitly nonlogical synthetic fixture only.
''','''        elif recipe.inputs and command["rule"] == "generalize":
            command.update(source=key.refs[0])
        elif recipe.inputs:  # Explicitly nonlogical synthetic fixture only.
''',1)
    path=HERE/'arithmetic_q_point_graph_v1.py'
    with path.open('x') as f:f.write(child)
    before=ast.parse(original);after=ast.parse(child);compile(after,str(path),'exec')
    originals={n.name:n for n in before.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    current={n.name:n for n in after.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    old_class=originals['PointGraph'];new_class=current['PointGraph']
    old_methods={n.name:ast.dump(n,include_attributes=False) for n in old_class.body if isinstance(n,ast.FunctionDef)}
    new_methods={n.name:ast.dump(n,include_attributes=False) for n in new_class.body if isinstance(n,ast.FunctionDef)}
    changed=[name for name in old_methods if old_methods[name]!=new_methods[name]]
    expected=['__init__','_factors','_base_legal_from_factors','candidates','decorate']
    if changed!=expected:raise ValueError('undeclared point-core method delta')
    stable={name:ast.dump(originals[name],include_attributes=False)==ast.dump(current[name],include_attributes=False)
        for name in current if name!='PointGraph'}
    if not all(stable.values()):raise ValueError('other semantic definitions changed')
    report={'schema':'Q-true-unary-point-core-static-delta-v1','parent':pin(PARENT),'source':pin(path),
        'changed_methods':changed,'unchanged_other_definition_ASTs':stable,'removed_old_profile_loader':'frozen_model',
        'unchanged_master_methods':['point_data','_input_mask','_domain','affected_rows','decision','checkpoint','_apply_legal',
            'exclude_failed_child','rollback','semantic_state','validate_cluster','candidates_with_preferences','point_certificate'],
        'scope':'Source-only arity change. Entire graph and complete domain/scheduler/rollback conformance remain unexecuted; independent exhaustive unary and empty-context checks required.',
        'source_modules_imported':0,'graph_or_checker_or_scientific_calls':0,'syntax_compile_only':True}
    with (HERE/'point-core-source-delta-v1.json').open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps({'source':pin(path),'delta':pin(HERE/'point-core-source-delta-v1.json')},sort_keys=True))

if __name__=='__main__':main()
