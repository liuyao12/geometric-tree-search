"""Metadata-only Source freezer: raw hash/AST/JSON; no project call/import."""
import ast
import builtins
import hashlib
import json
import symtable
import time
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/arithmetic-open-generalize-implementation-source-20261014'
LADDER=ROOT/'.gcts-active/arithmetic-benchmark-ladder-independent-20261013/declaration-review-v2.json'
GAP=ROOT/'.gcts-active/arithmetic-compiler-gap-design-20261013/gap-design-v1.json'

def pin(p):
    raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,v):
    p=HERE/name
    with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
    return pin(p)

def main():
    began=time.perf_counter();ladder=json.loads(LADDER.read_bytes())
    case=next(v for v in ladder['positive_cases'] if v['id']=='A1-quantified-right-one')
    grammar={'term_node_bound':3,'target_and_axiom_open_subterms':True,'instantiation_rounds':2,
        'hole_context_node_bound':2,'equality_template_other_terms':'complete_operand_pool',
        'equality_operand_pairs':'all_ordered_pairs','generalization_sources':'all_resulting_parameter_scoped_equality_atoms',
        'target_seed_is_formula_only':True}
    declaration={'schema':'arithmetic-empty-Gamma-Q-declaration-v1','theory':ladder['theory_profiles'][case['theory_profile']],
        'ordered_Gamma':case['ordered_gamma'],'target':case['target'],'parameters':['n'],'height':24,'grammar':grammar,
        'limits':{'maximum_formulas':50000,'maximum_recipes':20000,'maximum_visits':5000000}}
    declaration_pin=save('Q-declaration-v1.json',declaration)
    source_names={'kernel':'arithmetic_q_kernel_v1.py','catalogue':'arithmetic_q_catalog_v1.py',
        'point_graph':'arithmetic_q_point_graph_v1.py','payload':'q_preparation_gate_v1.py'}
    sources={k:pin(HERE/v) for k,v in source_names.items()}
    checks=[];unresolved={}
    for role,filename in source_names.items():
        raw=(HERE/filename).read_bytes();tree=ast.parse(raw);compile(tree,str(HERE/filename),'exec')
        table=symtable.symtable(raw.decode(),str(HERE/filename),'exec')
        defined={s.get_name() for s in table.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
        defined|=set(dir(builtins))|{'__name__','__file__','__builtins__'}
        missing=set();pending=[table]
        while pending:
            t=pending.pop();pending.extend(t.get_children())
            for symbol in t.get_symbols():
                if symbol.is_global() and symbol.is_referenced() and symbol.get_name() not in defined:missing.add(symbol.get_name())
        unresolved[role]=sorted(missing)
        checks.append({'role':role,'syntax_only_passed':True,'unresolved_globals':sorted(missing),
            'module_imported':False,'Source_functions_executed':0,'scientific_calls':0})
    controls=[
        {'id':'original-empty-context','kind':'source-scientific control prospective only','requirement':'No hypothesis recipes, fixed local seeds, selected placements or occupied rows. Every24 root/domain present, generation0.'},
        {'id':'unary-not-binary','requirement':'Exhaustively enumerate every declared generalize recipe/source row at tiny heights; compare literal points and complete domain counts to a separate arity0/1/2 oracle. Unary has no second offset marking.'},
        {'id':'all-full24-domains','requirement':'Separately reconstruct all24 initial legal domains from complete candidate rules. Include formula code0, assigned-zero value, exterior sentinel and every source-row offset; no sample/top-k acceptance.'},
        {'id':'open-instantiation','requirement':'Positive open parameter substitution and compound parameter terms; compare new host result with unchanged serialized/native semantics in a separately declared checker gate.'},
        {'id':'capture-conflict','requirement':'Substitution through a different binder colliding with replacement parameter must perform exact fresh0 spelling; wrong captured result rejected. Shadowed substituted binder stops free substitution.'},
        {'id':'fresh-bound-unknown','requirement':'Occupied deterministic fresh namespace beyond32 yields UNKNOWN complete preparation, not invalid theorem or partial complete catalog.'},
        {'id':'unknown-signature','requirement':'Unknown symbols/wrong arity/bool indices/nonliteral AST rejected before rule admission.'},
        {'id':'foreign-free-parameter','requirement':'Output/open operand with undeclared free parameter rejected; no hidden fresh-constant axiom.'},
        {'id':'full-Gamma-freshness','requirement':'Generalization variable free in an unused original context occurrence must be rejected; selected subset is insufficient. Duplicate ordered occurrences remain separate.'},
        {'id':'forward-source','requirement':'Self/future source of generalize or either MP port rejected. A mark on an unoccupied source row never forms checked ancestry.'},
        {'id':'typed-rule-arity','requirement':'Generalize with0/2 ports and MP with1 port rejected. Injected assumption under empty Gamma rejected.'},
        {'id':'full-fallback-and-rollback','requirement':'Independent complete graph reconstruction after placement/exclusion/rollback; exact snapshot equality of totals/marks/refcounts/generations/row domains/exclusions/order. Dead outranks forced, forced outranks branches and earliest-generation priority remains.'},
        {'id':'complete-grammar','requirement':'Separate straightforward grammar enumerator reconciles every operand/template pair, all2-round instantiation schemas, every resulting atomic generalization and every implication MP interface; no target backcone or selected induction alternative.'},
        {'id':'resource-withdrawal','requirement':'Any visit/depth/fresh/formula/recipe/deadline/memory failure preserves full receipts, yields UNKNOWN and has no usable complete model/admission/certificate prefix.'},
        {'id':'current-union-and-scopes','requirement':'Later first-proof driver must independently expand strict-prior unary/binary ancestry and preserve full original context/current+fixed point union. Logical target, actual selected, current patch, full24, native and trajectory flags remain separate.'},
        {'id':'induction-unimplemented','requirement':'nat-induction schema/rule, tautology/reflexivity/distribute/block/discharge remain rejected by Q; no claim zero-left induction is supported.'}]
    controls_pin=save('prospective-controls-v1.json',{'schema':'Q-open-empty-context-unary-controls-source-v1','executed':False,
        'author_identity':'/root/arithmetic_induction','scientific_calls':0,'controls':controls,
        'independent_control_author_required':'A different agent must construct the independent grammar/domain/side-condition controls; no golden target proof word/placements/counts here.'})
    contract={'schema':'arithmetic-open-generalize-implementation-source-contract-v1','author_identity':'/root/arithmetic_induction',
        'source_only':True,'scientific_calls':0,'Source_module_imports':0,'sources':sources,'declaration':declaration_pin,
        'master':pin(ROOT/'docs/basic-tiling-algorithm.md'),'prior_gap_design':pin(GAP),'corrected_ladder':pin(LADDER),
        'target_latex':case['latex'],'theory_scope':'Exact AZ/AS addition-recursion fragment with empty positive Gamma; not full PA. No induction schema/commands or older checked lemmas are inserted.',
        'target_scope':'An already declared arithmetic quantifier/congruence calibration case, not a held-out theorem/generalization claim or a proof discovered in this Source turn.',
        'minimality_scope':'Concrete small six-rule implementation choice, not a proof of minimal rule-set size.',
        'kernel_API':'QChecker(theory, parameters, gamma, *, deadline, maximum_visits=5000000, maximum_depth=64, maximum_fresh=32).command(command, prior) / proof(commands, target)',
        'catalogue_API':'prepare(spec, *, kernel_module, source_bindings, deadline)',
        'payload_API':'prepare_only(*, declaration, kernel_module, catalogue_module, graph_module, source_bindings, source_guard, deadline)',
        'cold_ROOT_entry_requirement':'No CLI/owner/actual plan is emitted here. ROOT can bind this callable preparation payload in a separately frozen raw-buffer cold wrapper under generic10leaf/10owner60s512MiB/caller90s, shared20s including Source loading/preparation/result transport/final guards. The wrapper and actual reviewer records remain mandatory before activation.',
        'concrete_implementation':['Restricted six-rule host checker, strict original-Gamma generalization guard and exact legacy capture-safe fresh-name substitution.',
            'Complete declared finite term/subterm/instantiation/unary-hole equality operand-pair/atomic-generalization/MP catalogue with exact identity/formula registry/source/context epochs; overflow never returns a complete prefix.',
            'New point-core source actually supports arity1 factors/candidate enumeration/base legality/decorate with one source offset; no binary slot duplication.',
            'Empty-context initial graph payload retains all24 zero occupancy roots and full factor/domain records; no assumption seed/old graph loader.',
            'All other graph scheduling/mark-only dependencies/refcounts/exclusions/rollback/cluster validation and base fallback are inherited unchanged Source bodies. Conformance remains unexecuted.'],
        'complete_grammar_scope':'Completeness only for the exact declared finite restricted grammar: terms<=3 plus parameter-scoped original target/axiom subterms,2 instantiation rounds, hole or unary-function(hole) contexts, all equality operands/directions, all resulting open equality atomic closures, all resulting implications as MP. Full FOL/theorem reachability/completeness is not asserted.',
        'arity_contract':{'axiom':0,'assumption':0,'instantiate':0,'eq_subst':0,'mp':2,'generalize':1},
        'placement_contract':'Unary placement has actual source row s<r; t(0,r)=1, formula-code marks at output/source and the first port offset s-r only. Missing second port is unconstrained, not assigned0. All mathematical display must use LaTeX in any future reader.',
        'source_inputs_excluded':['Every prior proof word, successful primitive route, search trace, policy weight or ordinary-forward witness. No old zero-left/left-successor body is an axiom/seed/proposal.'],
        'point_core_delta':pin(HERE/'point-core-source-delta-v1.json'),
        'compatibility_gaps':['Current ground codec/compact graph/classification/DFS/profile/q/observer/cold workers are unchanged and still reject this profile.',
            'The new noncompact point graph is a distinct Source prototype, not a silent unary adapter to the binary-only production DFS.',
            'Inherited simple Executor has no complete trace/first-checked logical observer and is retained only for point controls; do not use it as a production theorem-search experiment.',
            'Fresh independently traced generic first-proof driver/cold worker/current q/native whole request require separately authored/reviewed Source and actual admission.',
            'Native universal parser/checker/tile palette/heap are unchanged. New host rule syntax matches existing primitive fields but no native correspondence/whole certificate is accepted without a fresh unchanged-native gate.'],
        'later_induction_profile':'Zero-left/left-successor/associativity need separately licensed nat-induction template alternatives plus generic bounded conjunction/conditional deduction infrastructure (tautology/distribution/reflexivity as declared) and generalization of conditional steps. Q schema table is empty and rejects those commands; this Source package does not claim an induction experiment is ready.',
        'budget_unknowns':'Exact complete formula/recipe/candidate/domain counts and actual wall/peak/checker visit cost are UNKNOWN until a reviewed ROOT preparation. Maximum50000 formulas/20000 recipes/5M visits/64 depth/32 fresh suffix are profile resource gates, never proof nonexistence. No native heap/microstep expansion.',
        'prospective_controls':controls_pin,
        'source_readiness':{'implementation_written':True,'syntax_only_checked':True,'independent_review_passed':False,
            'cold_wrapper_written':False,'actual_preparation_completed':False,'graph_conformance_accepted':False,
            'proof_search_run':False,'universal_theorem_discovered':False,'native_accepted':False,'full_PA_accepted':False}}
    contract_pin=save('source-contract-v1.json',contract)
    readiness=save('source-static-readiness-v1.json',{'schema':'Q-open-generalize-source-static-readiness-v1','author_identity':'/root/arithmetic_induction',
        'sources':sources,'checks':checks,'unresolved_globals':unresolved,
        'syntax_only_passed':all(not v for v in unresolved.values()),'source_functions_called':0,'scientific_calls':0,
        'metadata_helper_elapsed_before_outputs_seconds':time.perf_counter()-began,
        'actual_counts_and_runtime':'UNKNOWN; compiler/kernel/Graph never called by author.'})
    package_files=[HERE/name for name in source_names.values()]+[HERE/'author_q_graph_source_v1.py',HERE/'point-core-source-delta-v1.json',
        HERE/'Q-declaration-v1.json',HERE/'prospective-controls-v1.json',HERE/'source-contract-v1.json',HERE/'source-static-readiness-v1.json',HERE/'freeze_source_metadata_v1.py']
    integration=save('integration-v1.json',{'schema':'Q-open-generalize-task-source-integration-v1','files':[pin(p) for p in package_files],
        'source_only':True,'scientific_calls':0,'public_files_modified':False})
    handoff=save('handoff-v1.json',{'schema':'Q-open-generalize-source-handoff-v1','author_identity':'/root/arithmetic_induction',
        'sources':sources,'contract':contract_pin,'readiness':readiness,'integration':integration,'source_only':True,'scientific_calls':0,
        'next_ROOT_action':'Assign distinct-author independent whole kernel/grammar/true-unary graph/payload Source review. If sound, author/review a small raw-buffer cold preparation/control worker under unchanged20/60/512/caller90. No search or native call is authorized by this handoff.',
        'scope':'Implemented bounded Q Source payload, with genuine empty Gamma/open substitutions/unary generalize. Cold wrapper/current independent qualification/first-proof search and induction remain explicitly unimplemented/unexecuted.'})
    print(json.dumps({'handoff':handoff,'integration':integration,'sources':sources,'syntax_only_passed':all(not v for v in unresolved.values()),'scientific_calls':0},sort_keys=True))

if __name__=='__main__':main()
