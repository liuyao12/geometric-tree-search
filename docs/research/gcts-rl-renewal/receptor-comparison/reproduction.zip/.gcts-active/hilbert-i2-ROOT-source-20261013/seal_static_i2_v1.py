"""Seal complete saved static qualifications only; no mathematical replay."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BASE = ROOT / '.gcts-active/hilbert-i2-static-progress-20261013'
SOURCE = ROOT / '.gcts-active/hilbert-i2-static-implementation-source-20261013'
CASE_IDS = ('fresh-i2-CD-vw-direct', 'fresh-i2-CD-vw-incidence-transport')
PEER = ROOT / '.gcts-active/receptor-i2-independent-implementation-review-20261013/I2-complete-saved-static-findings-v3.json'
CAP = 64 * 1024 * 1024

def pin(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def verify(record):
    p = Path(record['path']); p = p if p.is_absolute() else ROOT / p
    got = pin(p)
    assert got['bytes'] == record['bytes'] and got['sha256'] == record['sha256'], str(p)

def tree_verify(value):
    if type(value) is dict:
        if set(value) == {'path','sha256','bytes'}:
            verify(value)
        else:
            for item in value.values(): tree_verify(item)
    elif type(value) is list:
        for item in value: tree_verify(item)

def read(path, compressed=False):
    path = Path(path)
    with (gzip.open(path, 'rb') if compressed else path.open('rb')) as stream:
        data = stream.read(CAP + 1)
        assert len(data) <= CAP and stream.read(1) == b''
    def unique(items):
        result = {}
        for k,v in items:
            assert k not in result; result[k] = v
        return result
    return json.loads(data, object_pairs_hook=unique)

def main():
    assert pin(PEER)['sha256'] == '174921f1bc35d037ef1c507ca88ee68c7aeebb789e0d65e4b51a1e1aaf19d4f5'
    peer = read(PEER)
    assert peer['all_checks_passed'] is True and peer['mismatches'] == []
    assert peer['scientific_calls'] == 0 and peer['mathematical_authority'] is False and peer['resource_authority'] is False and peer['ROOT_authority'] is False
    fixture_pin = pin(SOURCE / 'i2-fixtures-v1.json')
    assert fixture_pin['sha256'] == '91fe6df2c148ddc9968c429bd5cf40fbd90f367c337feee14122a9df3bb452b5'
    fixture = read(fixture_pin['path']); profile = read(SOURCE / 'static-profile-plan-v1.json')
    assert fixture['proof_words'] == [] and tuple(c['id'] for c in profile['selected_cases']) == CASE_IDS
    cases = []
    for cid in CASE_IDS:
        prepdir, auditdir = BASE / (cid+'-preparation-v1'), BASE / (cid+'-audit-v1')
        stage = ROOT / ('.gcts-active/hilbert-i2-'+cid+'-static-progress-20261013')
        pp, ap = read(BASE / (cid+'-preparation-worker-plan-v1.json')), read(BASE / (cid+'-audit-worker-plan-v1.json'))
        pr, ar = read(prepdir/'preparation-result-v1.json'), read(auditdir/'audit-result-v1.json')
        pe, ae = read(pr['full_result']['path'], True), read(ar['full_result']['path'], True)
        h = read(prepdir/'catalog-v1/catalog-v1.json')
        for value in (pp, ap, pr, ar, pe, ae, h): tree_verify(value)
        assert pr['stage_completed'] is True and ar['stage_completed'] is True
        assert ar['logical_accepted'] is True and ar['initial_static_point_accepted'] is True
        assert ae['all_DAG_nodes_checked'] and ae['all_formulas_checked'] and ae['all_licenses_checked']
        assert ae['all_three_ordered_seed_identities_checked'] and ae['original_canonical_order_and_preimages_checked']
        assert h['dimensions'] == pr['dimensions'] == ar['dimensions'] == ae['dimensions']
        assert h['instance_id'] == cid == ae['instance_id'] == pe['instance_id']
        assert h['height'] == 24 and h['bodies'] == [] and h['complete_cluster_inventory'] == []
        assert pr['target_searches'] == ar['target_searches'] == ae['target_searches'] == 0
        assert pr['new_RL_training'] is False and ar['new_RL_training'] is False
        rows = pe['complete_initial_point_factor_streams']
        assert len(rows) == 24 and [r['row'] for r in rows] == list(range(24))
        assert rows == ae['point_audit']['complete_point_factor_streams']
        assert sum(r['count'] for r in rows) == pr['complete_initial_candidate_count'] == ar['complete_initial_candidate_count']
        assert all(r['excluded_legal'] == [] for r in rows)
        assert ar['primitive_license_checks'] == h['dimensions']['primitive_license_count']
        assert pe['initial_graph_small_state'] == ae['initial_graph_small_state']
        assert pe['initial_graph_small_state']['totals'] == [1,1,1]+[0]*21
        declarations = [c for c in fixture['cases'] if c['id'] == cid]
        assert len(declarations) == 1 and declarations[0]['rows'] == 24
        declaration = declarations[0]
        assert len(declaration['hypotheses']) == 3
        hypotheses = [fixture['literal_formulas'][key] for key in declaration['hypotheses']]
        assert [p['command']['formula'] for p in pe['initial_selected_full_placements']] == hypotheses
        assert h['target'] == fixture['literal_formulas'][declaration['target']]
        stages = []
        for phase, receipt in (('preparation', pr), ('replay', ar)):
            dpath = stage/(phase+'-ROOT-final-decision-v1.json'); decision = read(dpath)
            tree_verify(decision)
            assert decision['ROOT_final_accepted'] is True and decision['status'] == 'accepted_complete_owned_stage'
            assert len(decision['predicates']) == 14 and all(v is True for v in decision['predicates'].values())
            assert decision['mismatches'] == [] and decision['caller_elapsed_seconds']+1 <= 90
            assert decision['limits'] == {'whole_seconds':60,'peak_bytes':536870912,'caller_seconds':90}
            verify(decision['worker']); assert decision['worker']['sha256'] == pin((prepdir if phase=='preparation' else auditdir)/('preparation-result-v1.json' if phase=='preparation' else 'audit-result-v1.json'))['sha256']
            post = read(decision['post_write']['path'] if Path(decision['post_write']['path']).is_absolute() else ROOT/decision['post_write']['path'])
            stages.append({'stage':phase,'ROOT_decision':pin(dpath),'caller_elapsed_seconds':decision['caller_elapsed_seconds'],
                'owned_post_write_seconds':post['elapsed_seconds'],'conservative_peak_bytes':post['peak_bytes'],'all14_resource_predicates':True})
        cases.append({'id':cid,'declaration':declaration,'hypothesis_asts':hypotheses,'target_ast':h['target'],
            'statement_latex':next(c['latex'] for c in profile['selected_cases'] if c['id']==cid),
            'dimensions':h['dimensions'],'rule_counts':ae['logical_rule_counts'],
            'complete_initial_candidate_count':pr['complete_initial_candidate_count'],
            'initial_row_receipts':rows,'initial_state':pe['initial_graph_small_state'],
            'initial_seed_placements':pe['initial_selected_full_placements'],
            'producer':{'plan':pin(BASE/(cid+'-preparation-worker-plan-v1.json')),'receipt':pin(prepdir/'preparation-result-v1.json'),'evidence':pr['full_result'],'catalog':pr['catalog']},
            'independent':{'plan':pin(BASE/(cid+'-audit-worker-plan-v1.json')),'receipt':pin(auditdir/'audit-result-v1.json'),'evidence':ar['full_result'],'licenses':ar['complete_licenses']},
            'static_qualification_accepted':True,'proof_search_status':'UNSEARCHED','discovered_proofs':0,
            'runtime_observer_qualification':False,'resources':stages})
    result={'schema':'ROOT-accepted-fresh-geometry-complete-static-contexts-v1','author_identity':'/root',
        'case_ids':list(CASE_IDS),'cases':cases,'profile':pin(SOURCE/'static-profile-plan-v1.json'),
        'fixture':fixture_pin,'independent_saved_metadata_review':pin(PEER),
        'metadata_sealer':pin(__file__),'metadata_scientific_calls':0,'actual_scientific_stages_observed':4,
        'scientific_stage_restarts':0,'preactivation_sandbox_failures':1,'preserved_preflight_failure':pin(HERE/'ROOT-direct-preparation-preactivation-sandbox-failure-v1.json'),'all_four_complete_static_stages_accepted':True,
        'qualification_scope':'The two exact guarded I.2 finite rule catalogues and complete initial24-row point models only. All original syntax seeds, all five rules and empty inventory retained. No proof discovery, dynamic search/observer qualification, native/universal checker, learned marking, RL, comparison gain, substitution or plane-tiling acceptance.',
        'proof_searches':0,'checked_proof_certificates':0,'all_five_qualification':False,'universal_compiler_theorem':False,
        'dynamic_search_conformance':False,'goal_remains_active':True}
    path=HERE/'ROOT-actual-complete-static-geometry-disposition-v1.json'
    with path.open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True,ensure_ascii=False);stream.write('\n')
    print(json.dumps({'cases':2,'complete_static_stages':4,'discovered_proofs':0,'disposition':pin(path)}))

if __name__ == '__main__': main()
