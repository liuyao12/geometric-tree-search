"""ROOT source-review/request construction, stdlib metadata only."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / '.gcts-active/hilbert-i2-static-implementation-source-20261013'
PEER = ROOT / '.gcts-active/receptor-i2-independent-implementation-review-20261013'


def pin(path):
    path = Path(path)
    path = path if path.is_absolute() else ROOT / path
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def verify_tree(value):
    if isinstance(value, dict):
        if set(value) == {'path', 'bytes', 'sha256'}:
            actual = pin(value['path'])
            assert (actual['bytes'], actual['sha256']) == (value['bytes'], value['sha256']), value['path']
        else:
            for child in value.values():
                verify_tree(child)
    elif isinstance(value, list):
        for child in value:
            verify_tree(child)


def read(path):
    return json.loads(Path(path).read_bytes())


def save(name, value):
    path = HERE / name
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
    return pin(path)


def main():
    handoff_path = SOURCE / 'handoff-v1.json'
    assert pin(handoff_path)['sha256'] == '73c9777487a55a977f08d4c75410eaa5ecbde47e9356d6878eacf162a469c8e1'
    handoff = read(handoff_path)
    verify_tree(handoff)
    manifest = read(SOURCE / 'profile-source-manifest-v1.json')
    verify_tree(manifest)
    peer_path = PEER / 'I2-static-source-findings-v2.json'
    assert pin(peer_path)['sha256'] == 'ac9fbe2a4f08eca992f0d8627ac81545f65335bf3f2f82e9fc65fb2376444dd0'
    peer = read(peer_path)
    verify_tree(peer)
    assert peer['source_only'] and peer['source_ready'] and peer['source_review_passed']
    assert peer['scientific_calls'] == 0 and peer['scientific_acceptance'] is False
    assert peer['sources']['producer'] == manifest['producer_sources']
    assert peer['sources']['audit'] == manifest['independent_sources']
    recipe = read(SOURCE / 'ROOT-request-recipe-SOURCE-v1.json')
    original = read(ROOT / '.gcts-active/hilbert-next-owned-progress-20261013/ROOT-source-review-v1.json')
    verify_tree(original['runtime'])
    owner = pin(ROOT / '.gcts-active/hilbert-next-owned-progress-20261013/run_owned_bridge_v2.py')
    closer = pin(ROOT / '.gcts-active/hilbert-next-owned-progress-20261013/close_stage_decision_v1.py')
    assert (owner['sha256'], owner['bytes']) == ('2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656', 14639)
    assert (closer['sha256'], closer['bytes']) == ('9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf', 4752)
    records = []
    for selector in manifest['active_ids']:
        namespace = Path(recipe['per_case_supervision_namespace_templates'][selector])
        assert namespace.parent == ROOT / '.gcts-active' and not namespace.exists()
        for phase, suffix, roles in (
            ('prepare', 'preparation', manifest['producer_sources']),
            ('audit', 'audit', manifest['independent_sources']),
        ):
            review = {
                'schema': 'independent-Hilbert-next-' + suffix + '-worker-source-review-v1',
                'scope': 'Hilbert-next-' + suffix + '-worker',
                'reviewer_identity': '/root',
                'author_identity': '/root/hilbert_ordering_diagnosis',
                'source_only': True, 'source_ready': True,
                'source_review_passed': True,
                'scientific_calls': 0, 'scientific_acceptance': False,
                'execution_authorized': False,
                'sources': roles, 'inputs': {'fixture': manifest['fixture']},
                'upstream_reviews': manifest['upstream_reviews'],
                'static_profile_id': manifest['profile_id'],
                'static_profile_plan': manifest['profile'],
                'builder_source_pin': manifest['builder'],
                'owner_source_pin': dict(owner, path=str(namespace / 'run_owned_bridge_v2.py')),
                'closer_source_pin': dict(closer, path=str(namespace / 'close_stage_decision_v1.py')),
                'runtime': original['runtime'],
                'findings': pin(peer_path),
                'independent_phase_SOURCE_review': pin(peer_path),
                'source_handoff': pin(handoff_path),
                'ROOT_source_review_provenance': pin(__file__),
                'ROOT_review_assessment': 'ROOT read the whole source delta, exact profile/role manifest, current worker admission and complete metadata builder/closure path. The independent whole-five-source review establishes constant-only callable deltas and retained full construction/audit algorithms; original fourteen cases and the exact two I.2 declarations remain fixed. Current complete six-role maps, all24-row domains, original indexed Gamma, empty inventory and prospective60s/512MiB/90s resource envelopes are bound. No model, scientific control, proof search or resource-fit acceptance is produced by this review.',
            }
            review_pin = save(selector + '-' + phase + '-ROOT-source-review-v1.json', review)
            request = {
                'schema': 'ROOT-guarded-I2-static-metadata-request-v1',
                'phase': phase, 'selector': selector,
                'progress_namespace': str(namespace),
                'ROOT_authorized_metadata_construction': True,
                'ROOT_source_review': review_pin,
            }
            request_pin = save(selector + '-' + phase + '-ROOT-request-v1.json', request)
            records.append({'selector': selector, 'phase': phase, 'review': review_pin, 'request': request_pin})
    receipt = save('ROOT-static-review-construction-v1.json', {
        'schema': 'ROOT-I2-static-source-review-construction-v1',
        'source_only': True, 'scientific_calls': 0,
        'source_handoff': pin(handoff_path), 'independent_findings': pin(peer_path),
        'metadata_requests': records,
        'actual_plans_or_runs_created': False,
        'actual_qualification': False,
        'scope': 'Review and four requests only. Each later audit builder still requires its own actually accepted complete preparation and resource/caller decision.',
    })
    print(json.dumps({'reviews': len(records), 'scientific_calls': 0, 'receipt': receipt}))


if __name__ == '__main__':
    main()
