"""ROOT current SOURCE selection and metadata request; no scientific imports."""
import copy
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'.gcts-active/hilbert-i2-first-proof-metadata-source-20261014'
PEER=ROOT/'.gcts-active/hilbert-i2-first-proof-integration-review-20261014'
ARITH=ROOT/'.gcts-active/receptor-i2-independent-implementation-review-20261013'
DEST=ROOT/'.gcts-active/hilbert-i2-first-proof-progress-20261014'

def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def verify_tree(value):
    if isinstance(value,dict):
        if set(value)=={'path','sha256','bytes'}:
            current=pin(value['path']);assert current['sha256']==value['sha256'] and current['bytes']==value['bytes'],value['path']
        else:
            for child in value.values():verify_tree(child)
    elif isinstance(value,list):
        for child in value:verify_tree(child)

def read(path):return json.loads(Path(path).read_bytes())

def save(name,value):
    path=HERE/name
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    return pin(path)

def main():
    assert not DEST.exists()
    contract_path=SOURCE/'metadata-source-contract-v1.json'
    contract=read(contract_path);verify_tree(contract)
    assessment='ROOT read the whole current metadata constructor, reviewed current worker binding deltas and independently checked all37 unchanged owner/terminal callable ASTs. Current person reviews remain distinct from their actual source authors. All current I.2 static contexts, actual45 controls, preregistered endpoint,17 runtime roles,6 consumer roles, empty inventory, complete fallback and128/20/2000 plus180/175/170/512MiB gates are bound. This constructor performs raw SOURCE/JSON selection only; no project semantic function, qualification reader, Graph, model, policy, search or proof checker is called.'
    selections={
        'metadata':PEER/'I2-metadata-source-review-v1.json',
        'owner':PEER/'I2-owner-source-review-v1.json',
        'helper':ARITH/'I2-first-proof-helper-typed-source-review-v1.json',
        'worker':ARITH/'I2-first-proof-ROOT-worker-source-review-v1.json',
        'observer':ARITH/'I2-first-proof-observer-typed-source-review-v1.json',
    }
    reviews={}
    for role,path in selections.items():
        current=read(path);verify_tree(current)
        assert current['source_only'] is True and current['source_review_passed'] is True and current['scientific_calls']==0
        assert current['author_identity']!=current['reviewer_identity']
        if role in ('worker','observer'):
            reviews[role]=pin(path)
            continue
        assert current['author_identity']!='/root'
        value=copy.deepcopy(current)
        value.update(reviewer_identity='/root',independent_SOURCE_review=pin(path),ROOT_assessment=assessment,
            ROOT_review_provenance=pin(__file__),scientific_acceptance=False)
        reviews[role]=save('ROOT-'+role+'-SOURCE-review-v1.json',value)
    assert read(reviews['worker']['path'])['author_identity']=='/root'
    assert read(reviews['worker']['path'])['reviewer_identity']=='/root/arithmetic_induction'
    parent_platform_path=ROOT/'.gcts-active/hilbert-deterministic-incidence-three-lane-progress-v2-20261013/base/platform-review-v1.json'
    platform=read(parent_platform_path);verify_tree(platform)
    platform.update(worker=contract['sources']['worker'],owner=contract['owner'],
        ROOT_worker_source_review=reviews['worker'],ROOT_owner_source_review=reviews['owner'],
        ROOT_source_review_provenance=pin(__file__),prior_platform_review=pin(parent_platform_path),
        scope='ROOT Source-reviewed I.2 current cold no-child leaf and unchanged observer/wait4/closed52 owner postlude on pinned darwin3.9.6. Worker is ROOT-authored and independently reviewed by arithmetic. Owner/terminal and metadata are independently reviewed by advice-controls. Current source bindings change; lifecycle and resource algorithms remain unchanged. Prospective32MiB reserve, no actual resource admission or OS hard cap. Full caller/owner/worker boundaries must pass after each once-only lane.')
    platform_pin=save('ROOT-platform-SOURCE-review-v1.json',platform)
    request=dict(schema='ROOT-I2-first-proof-metadata-request-v1',
        ROOT_authorized_metadata_construction=True,ROOT_authorized_four_once_lanes=True,
        ROOT_source_review=reviews['metadata'],independent_source_review=pin(selections['metadata']),
        static_disposition=contract['actual_static_disposition'],worker_review=reviews['worker'],
        owner_review=reviews['owner'],helper_review=reviews['helper'],observer_review=reviews['observer'],
        consumer_ROOT_review=reviews['worker'],consumer_peer_review=reviews['worker'],
        ROOT_observer_control_disposition=contract['actual_observer_control_disposition'],
        runtime=platform['runtime'],platform_review=platform_pin,fresh_destination=str(DEST))
    assert len(request)==16
    request_pin=save('ROOT-first-proof-metadata-request-v1.json',request)
    save('ROOT-review-and-request-construction-v1.json',dict(schema='ROOT-I2-first-proof-source-selection-and-request-v1',
        scientific_calls=0,contract=pin(contract_path),reviews=reviews,
        independent_review_selections={k:pin(v) for k,v in selections.items()},
        ROOT_explicit_selection_of_independent_worker_review=True,ROOT_worker_self_review=False,
        consumer_ROOT_and_peer_fields_select_same_actual_distinct_author_review=True,
        platform=platform_pin,request=request_pin,q_or_model_created=False,proof_searches=0,
        source_only=True,scope=assessment))
    print(json.dumps(dict(request=request_pin,source_reviews=len(reviews),scientific_calls=0,q_or_model_created=False)))

if __name__=='__main__':main()
