"""Static display-only JSON/hash/HTML Source readiness, no browser/science."""
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=Path(__file__).resolve().parent
PUB=Path('/private/tmp/gcts-family-router-publish-20261010/docs/research/gcts-rl-renewal')

def pin(p):
    raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    p=HERE/name
    with p.open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
    return pin(p)

def main():
    html=(HERE/'reader.html').read_text();js=(HERE/'viewer.js').read_text();css=(HERE/'reader.css').read_text()
    packet=json.loads((HERE/'summary.json').read_bytes());checks=[]
    def check(value,label):checks.append(dict(name=label,passed=bool(value)))
    class Tags(HTMLParser):
        def __init__(self):super().__init__();self.ids=[];self.srcs=[]
        def handle_starttag(self,tag,attrs):
            a=dict(attrs)
            if 'id' in a:self.ids.append(a['id'])
            if 'src' in a:self.srcs.append(a['src'])
    tags=Tags();tags.feed(html)
    check(len(tags.ids)==len(set(tags.ids)),'unique static DOM IDs')
    check(set(['lead','status','comparison-table','cost-chart','prior-costs','trial','proof-scope','proof-view','arithmetic-status','evidence-links'])<=set(tags.ids),'all native reader containers present')
    check("inlineMath:[['\\\\(','\\\\)']]" in html and 'tex-chtml.js' in html,'established LaTeX delimiter escaping and CHTML renderer')
    check('innerHTML' not in js and 'textContent' in js,'runtime source/English/links use DOM text nodes, no raw HTML interpolation')
    check("fetch('summary.json')" in js and js.count('fetch(')==1,'only saved display packet fetched')
    check('Notebook159-saved-display-packet-v1' in js and 'presentation_only===true' in js,'explicit presentation-only schema')
    check(packet['trials']==packet['prior_costs']==packet['evidence_links']==[],'all default measured/result arrays empty pending')
    check(packet['presentation_only'] is True and packet['schema']=='Notebook159-saved-display-packet-v1','pending source packet correct schema')
    check("const lanes=['canonical','ordinary-symbolic-advice','extracted-finite-family-advice']" in js,'literal preregistered three lanes only')
    check("const cases=['fresh-i2-CD-vw-direct','fresh-i2-CD-vw-incidence-transport']" in js,'literal existing two debug contexts only')
    check('No proof rows are attached' in js and 'if(!trial.proof_rows.length)' in js,'unknown/absent proof never fabricates rows')
    check('trial.origin_kind' in js and 'trial.logical_accepted' in js and 'trial.registry_completed' in js,'saved origin/acceptance/registry displayed separately')
    check("'rect',{x:x(0)-30" in js and 'width:60,height:60' in js,'one fixed square carrier per supplied unit point row')
    check('ref-row.physical_row' in js and 'row.m.some(p=>p[0]===1&&p[1]===ref)' in js,'ordered saved reads agree with literal negative offsets and source marks before drawing')
    check('...r.m.map(p=>p[1])' in js and 'for(const [px,py,value] of row.m)' in js,'all literal marks including remote/exterior coordinates contribute to drawing bounds')
    check('foreignObject' in js and 'div.textContent=`\\\\(r=' in js,'SVG row addresses use LaTeX CHTML container, not Unicode math text')
    check('figcaption' in js and 'no combined or stacked component clocks' in js,'inclusive caller chart does not add nested clocks')
    check('not a lemma-inventory cache' in html and 'not a held-out theorem test' in html,'ordinary lane and generalization scope honestly labeled')
    check('position:sticky' in css and 'svg{' not in css,'scoped diagrams avoid global MathJax SVG resizing')
    prereg=ROOT/'.gcts-active/equality-receptor-family-six-lane-ROOT-source-20261014/ROOT-six-lane-preregistration-v1.json'
    check(pin(prereg)['sha256']=='cabd16d28e9a51e9899f5e44c244b283f90334b7478fae5df47bec0c6f8902ee','exact preregistered semantics source pin')
    schema=save('source-schema-v1.json',dict(schema='Notebook159-display-source-interface-v1',packet_schema='Notebook159-saved-display-packet-v1',presentation_only=True,
        required_packet_fields=['schema','presentation_only','lead','status_text','trials','prior_costs','arithmetic_status','evidence_links'],
        trials=dict(fields=['case','lane','status','attempts','events','search_seconds','owned_seconds','caller_seconds','peak_MiB','logical_accepted','origin_kind','registry_completed','proof_rows','evidence_href'],
            cases=['fresh-i2-CD-vw-direct','fresh-i2-CD-vw-incidence-transport'],lanes=['canonical','ordinary-symbolic-advice','extracted-finite-family-advice'],
            ordering='Saved ROOT trial order, no outcome sorting; unique(case,lane), at most six.',
            metrics='Finite nonnegative numbers, including actual0; null/absent displays Pending. No means/gains/ratios inferred.',
            acceptance='Presentation flags from ROOT packet only; never derived from status string or row presence.'),
        proof_rows=dict(fields=['formula_latex','formula_english','derivation_english','physical_row','ordered_prior_rows','t','m','command'],
            literal_points='Exact integer triples; unit support t=[[0,physical_row,1]], blue output mark and each ordered negative offset/source mark required for display consistency. No kernel/graph/recipe licensing performed.',
            math='Full formula_latex is wrapped in supported inline delimiters. Mathematical identifiers inside English must already carry LaTeX inline delimiters supplied by ROOT.',
            origin='An unselected compatible proposal is not relabeled selected or full24/native/trajectory accepted.',
            ordering='Physical rows sorted for readable display only; saved commands and ordered prior occurrences are untouched.'),
        prior_costs=dict(fields=['label','status','scope','owned_seconds','caller_seconds','peak_MiB','note','evidence_href'],
            scopes='Inclusive whole clocks, old failures and extraction/controls remain separate stages; source fields may be absent pending.'),
        evidence_links=dict(fields=['href','label'],routes='Same report-origin relative or absolute HTTP(S) URLs; browser filesystem paths rejected.'),
        arithmetic_status='Saved prose with LaTeX inline identifiers, or null to retain pending scaffold prose.',
        invocation='ROOT copies source to new public report namespace and replaces only public summary.json with reviewed saved display packet; no scientific engine imported or called by reader.',
        remaining=['Actual ROOT display-packet correspondence review.','Browser MathJax/foreignObject/square/link geometry QA with real terminal rows.','Publication and exact live-byte verification are ROOT owned.'],
        source_only=True,scientific_calls=0,measured_results_fabricated=False))
    readiness=save('Source-readiness-v1.json',dict(schema='Notebook159-source-scaffold-readiness-v1',author_identity='/root/arithmetic_induction',source_only=True,
        scientific_calls=0,project_imports=0,actual_results_loaded=0,proof_rows_fabricated=0,PUB_edits=0,publication_performed=False,
        static_checks=checks,all_checks_passed=all(x['passed'] for x in checks),
        syntax_check=dict(command='/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --check viewer.js',
            executable=pin(Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node')),exit_code=0,code_executed=False,
            last_observed_tool_seconds=0.072815208,scope='JavaScript parser only, no DOM or display data execution.'),
        style_inputs=[pin(PUB/'receptor-controls/reader.css'),pin(PUB/'receptor-controls/viewer.js')],preregistration=pin(prereg),
        schema=schema,actual_browser_QA=False,mathematical_acceptance_issued=False,resource_acceptance_issued=False,
        limitations=['This is source/pending display only; no actual six-lane outcome or proof packet has been read.',
            'SVG foreignObject MathJax row-label layout and real proof/state geometry await ROOT browser QA.',
            'Human English and LaTeX are presentation fields; raw scientific/source/certificate authority remains in linked saved artifacts.']))
    files=[pin(p) for p in sorted(HERE.iterdir()) if p.is_file()]
    manifest=save('integration-v1.json',dict(schema='Notebook159-source-display-integration-v1',files=files,source_only=True,scientific_calls=0))
    handoff=save('handoff-v1.json',dict(schema='Notebook159-source-display-handoff-v1',reader=pin(HERE/'reader.html'),viewer=pin(HERE/'viewer.js'),stylesheet=pin(HERE/'reader.css'),
        pending_packet=pin(HERE/'summary.json'),readiness=readiness,interface_schema=schema,integration=manifest,source_only=True,scientific_calls=0,
        actual_results_loaded=0,publication_performed=False,all_checks_passed=all(x['passed'] for x in checks)))
    print(json.dumps(dict(handoff=handoff,readiness=readiness,integration=manifest,all_checks_passed=all(x['passed'] for x in checks))))

if __name__=='__main__':main()
