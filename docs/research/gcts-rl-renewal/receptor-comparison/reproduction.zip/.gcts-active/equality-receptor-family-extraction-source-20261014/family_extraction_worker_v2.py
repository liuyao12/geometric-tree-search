"""SOURCE-only cold complete donor family extraction + independent audit.

ROOT alone invokes the frozen source after actual source reviews/plans. The
supervisor stage label replay denotes this read-only extraction/checking phase,
not a search replay. Only original three saved donor certificates are inputs.
No graph/recipient proof/role sort/pruning/RL/library authority is constructed.
"""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time
import types

ROOT=Path(__file__).resolve().parents[2]
AUTHOR='/root/hilbert_ordering_diagnosis'
SCHEMA='ROOT-equality-receptor-family-extraction-worker-plan-v1'
FIELDS={'schema','ROOT_owned_once_only','sources','runtime','reviews','closure',
        'limits','output_directory','owner_plan_path','training_specification'}
SOURCE_ROLES={'worker','family','auditor','reader','logical_oracle','point_core',
              'compact_decoder','compact_graph','dynamic_graph','master'}
EXECUTABLE_ROLES=('reader','logical_oracle','family','auditor')
LIMITS=dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)
MAX_RAW_BYTES=64*1024*1024
FROZEN_SOURCES = {'reader': {'bytes': 64540, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/fresh_equality_context_and_final24_certificate_v3.py', 'sha256': '5d03d088c2d1b7f90e98fb7e28819ab0643b74f6786953c6107d4d2535c2377b'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'dynamic_graph': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'family': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-I2-recipient-source-20261014/equality_receptor_family_I2_v2.py', 'sha256': 'de5f58e4fff4ac62155bffba406f10488f32be665dfa0254ebb2e3a8d421a7e3', 'bytes': 61070}, 'auditor': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-independent-source-20261014/independent_Incident_family_audit_v1.py', 'sha256': '739e25b0f7f13ce2aa103cd3404b5d623d3f0ef3068589177c39f5930d10a06c', 'bytes': 46305}}
TRAINING_SPEC_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-implementation-source-20261013/training-inputs-v1.json', 'sha256': 'de34653e96673e080c65a6c17fad3cc24cfb00ab0043fdc11c9741e6708f382c', 'bytes': 8340}


def need(value,label):
    if not value:raise ValueError(label)

def absolute(record):
    need(type(record)is dict and set(record)=={'path','sha256','bytes'},'exact raw record fields')
    declared=Path(record['path']);path=declared if declared.is_absolute() else ROOT/declared
    need('..' not in declared.parts and path.resolve()==path and path.is_file(),'canonical current raw path')
    need(type(record['bytes'])is int and record['bytes']>=0 and type(record['sha256'])is str
         and len(record['sha256'])==64 and all(c in '0123456789abcdef' for c in record['sha256']),'typed raw identity')
    return dict(record,path=str(path))

def read_verified(record):
    record=absolute(record);path=Path(record['path']);before=path.stat()
    with path.open('rb') as stream:raw=stream.read(MAX_RAW_BYTES+1)
    after=path.stat()
    need(len(raw)<=MAX_RAW_BYTES and len(raw)==record['bytes']
         and hashlib.sha256(raw).hexdigest()==record['sha256']
         and (before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size)==
             (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size),'one entire stable authenticated buffer')
    return raw

def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    need(path.resolve()==path and (before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size)==
        (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size),'stable canonical output/source bytes')
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def json_pin(record):return json.loads(read_verified(record))

def load(record,name):
    record=absolute(record);raw=read_verified(record)
    module=types.ModuleType(name);module.__file__=record['path'];sys.modules[name]=module
    exec(compile(raw,record['path'],'exec'),module.__dict__)
    read_verified(record);return module

def executable_state(modules):
    """Full module bindings/functions/MRO/properties; no mutable fixture cache."""
    result=[];seen=set()
    def function(label,value):
        if isinstance(value,types.FunctionType):
            result.append((label,value,value.__code__,
                tuple(id(x) for x in (value.__defaults__ or ())),
                tuple((k,id(v)) for k,v in sorted((value.__kwdefaults__ or {}).items())),
                tuple(id(c.cell_contents) for c in (value.__closure__ or ()))))
    for role,module in sorted(modules.items()):
        result.append((role,module,id(module.__dict__),tuple((k,id(v)) for k,v in sorted(vars(module).items()) if k!='__builtins__')))
        for name,value in sorted(vars(module).items()):
            function(role+'.'+name,value)
            if not isinstance(value,type) or value in seen:continue
            seen.add(value);result.append((role+'.'+name,value,value.__mro__))
            for cls in value.__mro__:
                for key,item in sorted(vars(cls).items()):
                    if isinstance(item,property):
                        for suffix,fn in [('get',item.fget),('set',item.fset),('delete',item.fdel)]:
                            function(role+'.'+cls.__name__+'.'+key+'.'+suffix,fn)
                    elif isinstance(item,(staticmethod,classmethod)):function(role+'.'+cls.__name__+'.'+key,item.__func__)
                    else:function(role+'.'+cls.__name__+'.'+key,item)
    return tuple(result)

def cache_guard(sources,modules):
    allowed={absolute(sources[r])['path'] for r in EXECUTABLE_ROLES}|{str(Path(__file__).resolve())}
    need(sys.dont_write_bytecode,'cold no-cache worker')
    for role in EXECUTABLE_ROLES:
        path=Path(absolute(sources[role])['path']);cache=path.parent/'__pycache__'
        need(not (cache.exists() and any(cache.glob(path.stem+'.*.pyc'))),'no alternate compiled project source '+role)
    for module in tuple(sys.modules.values()):
        file=getattr(module,'__file__',None)
        if not file:continue
        path=Path(file).resolve()
        if ROOT in path.parents:need(str(path) in allowed,'explicit executable project allowlist')
    for role,module in modules.items():
        need(sys.modules.get(module.__name__) is module and module.__file__==absolute(sources[role])['path'],
             'exact originally loaded module identity '+role)

def peak():return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)

def save(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
    with path.open('xb') as stream:stream.write(raw)
    return pin(path)

def clock(deadline):
    if time.perf_counter() >= deadline:
        raise TimeoutError('complete extraction/audit/return preparation exceeded20s; no accepted candidate prefix')


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def callback_state(function):
    # Direct identity/code/default/cell anchors before any delegated callback.
    if type(function) is not types.FunctionType:
        raise ValueError('exact cold validator function endpoint')
    return (function, function.__code__, tuple(id(v) for v in function.__defaults__ or ()),
        tuple((k, id(v)) for k, v in sorted((function.__kwdefaults__ or {}).items())),
        tuple((id(cell), id(cell.cell_contents)) for cell in function.__closure__ or ()))


def required_training_records(specification):
    # Exact named readsites only, never recursive arbitrary ancestor decoding.
    need(specification['schema']=='exact-three-equality-transport-training-inputs-v1'
         and len(specification['certificates'])==3,'unchanged exact original donor selector')
    records=[TRAINING_SPEC_PIN]
    for name in ('design','handoff','ROOT_mathematical_disposition'):
        records.append(specification[name])
    for donor in specification['certificates']:
        for name in ('certificate','result','qualification','header','licenses','resource_disposition'):
            records.append(donor[name])
        header=json_pin(donor['header'])
        records.extend(header['streams'].values())
    return records


def main():
    began=time.perf_counter()
    need(len(sys.argv)==3,'one frozen leaf plan and its enclosing flat owner plan')
    plan_path=Path(sys.argv[1]).resolve();plan_pin=pin(plan_path);plan=json_pin(plan_pin)
    need(set(plan)==FIELDS and plan['schema']==SCHEMA and plan['ROOT_owned_once_only'] is True,
         'exact10-field current extraction plan')
    owner_path=Path(sys.argv[2]).resolve();owner_pin=pin(owner_path);owner=json_pin(owner_pin)
    need(plan['owner_plan_path']==str(owner_path)
         and set(owner)=={'schema','stage','worker','argv','worker_receipt','limits','runtime_binary','ROOT_source_review','scope','closure'}
         and owner['schema']=='ROOT-guard-native-owned-plan-v1' and owner['stage']=='replay'
         and owner['argv']==[sys.executable,'-B',str(Path(__file__).resolve()),str(plan_path),str(owner_path)]
         and owner['limits']==plan['limits']==LIMITS,'unchanged flat10 owner/limits/argv')
    need(set(plan['sources'])==SOURCE_ROLES and absolute(plan['sources']['worker'])==pin(Path(__file__).resolve()),
         'exact current10 raw roles incl actual worker')
    for role,record in FROZEN_SOURCES.items():
        need(absolute(plan['sources'][role])==record,'frozen role '+role)
    need(set(plan['runtime'])=={'binary'} and absolute(plan['runtime']['binary'])==pin(Path(sys.executable).resolve()),
         'exact official runtime raw identity')
    need(absolute(plan['training_specification'])==TRAINING_SPEC_PIN,'fixed original training selector only')
    specification=json_pin(plan['training_specification'])
    need(set(plan['reviews'])=={'ROOT','independent'},'current two source reviews, not mathematical authority')
    root_review=json_pin(plan['reviews']['ROOT']);peer=json_pin(plan['reviews']['independent'])
    need(root_review['source_review_passed'] is True and root_review['scientific_calls']==0
         and root_review['sources']==plan['sources'],'actual current ROOT SOURCE review exact10 roles')
    need(peer['source_only'] is True and peer['source_review_passed'] is True and peer['scientific_calls']==0
         and peer['author_identity']==AUTHOR and peer['reviewer_identity']!=AUTHOR
         and peer['sources']==plan['sources'],'current scoped independent wrapper/source-role review')
    required=list(plan['sources'].values())+[plan['runtime']['binary']]+list(plan['reviews'].values())+required_training_records(specification)
    required_by_path={}
    for record in required:
        record=absolute(record);old=required_by_path.get(record['path'])
        need(old is None or old==record,'no conflicting named input identity')
        required_by_path[record['path']]=record
    closure={}
    for record in plan['closure']:
        normalized=absolute(record)
        need(normalized['path'] not in closure,'one exact leaf closure record per current path')
        read_verified(normalized);closure[normalized['path']]=normalized
    need(closure==required_by_path,'entire exact named current extraction closure, no arbitrary historical decode')
    owner_closure={absolute(record)['path']:absolute(record) for record in owner['closure']}
    need(all(owner_closure.get(path)==record for path,record in closure.items())
         and owner_closure.get(str(plan_path))==absolute(plan_pin),'owner contains exact full leaf/plan closure')
    directory=Path(plan['output_directory']).resolve()
    need(directory.parent==plan_path.parent and not directory.exists()
         and (ROOT/owner['worker_receipt']).resolve()==directory/'worker-receipt-v1.json',
         'one fresh immutable owned namespace and receipt identity')
    directory.mkdir();pending=directory/'provisional-output-v1';pending.mkdir()
    plan_text=canonical(plan);owner_text=canonical(owner)
    calls=dict(extraction_started=0,extraction_completed=0,independent_audit_started=0,independent_audit_completed=0)
    published=[];inner_began=None;inner_deadline=None
    try:
        own=sys.modules[__name__]
        own_functions=tuple((name,value,value.__code__) for name,value in vars(own).items() if isinstance(value,types.FunctionType))
        original_snapshot=executable_state;original_load=load;original_raw=read_verified;original_cache=cache_guard
        own_frozen=original_snapshot({'worker':own});modules={}
        inner_began=time.perf_counter();inner_deadline=inner_began+20
        for role in EXECUTABLE_ROLES:
            if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
                raise ValueError('own validator/code boundary before cold load')
            modules[role]=original_load(plan['sources'][role],'_ROOT_Incident_family_extraction_'+role)
            if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
                raise ValueError('own validator/code boundary after cold load')
            clock(inner_deadline)
        frozen=original_snapshot(modules)
        reader=modules['reader'];checker=modules['logical_oracle'].GroundChecker
        closed=reader.ClosedInputs();closed_type=type(closed)
        closed_method_state=modules['family'].method_state(closed)
        family_literals=canonical({name:getattr(modules['family'],name) for name in
            ('VERSION','LIBRARY_SCHEMA','TRAINING_SPEC_PIN','DONOR_SOURCE_PINS','UPSTREAM_SOURCE_PINS')})
        def source_guard():
            if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
                raise ValueError('original own validator function/code boundary')
            if original_snapshot({'worker':own})!=own_frozen:
                raise ValueError('own module/MRO/property boundary')
            if canonical(plan)!=plan_text or canonical(owner)!=owner_text:
                raise ValueError('exact unchanged whole current plan/owner metadata')
            original_raw(plan_pin);original_raw(owner_pin)
            for record in closure.values():original_raw(record)
            original_cache(plan['sources'],modules)
            if original_snapshot(modules)!=frozen:
                raise ValueError('exact cold module/function/MRO/property authority')
            if reader is not modules['reader'] or checker is not modules['logical_oracle'].GroundChecker:
                raise ValueError('original reader/kernel endpoints')
            if type(closed) is not closed_type or closed_type is not reader.ClosedInputs:
                raise ValueError('original ClosedInputs object/type')
            if modules['family'].method_state(closed)!=closed_method_state:
                raise ValueError('unchanged effective closed reader methods; no instance shadows')
            if canonical({name:getattr(modules['family'],name) for name in
                ('VERSION','LIBRARY_SCHEMA','TRAINING_SPEC_PIN','DONOR_SOURCE_PINS','UPSTREAM_SOURCE_PINS')})!=family_literals:
                raise ValueError('unchanged donor/receiver Source-role separation and extractor constants')
        source_guard_anchor=callback_state(source_guard)
        def invoke_guard():
            if callback_state(source_guard)!=source_guard_anchor:
                raise ValueError('exact delegated guard function/code/default/closure before invocation')
            source_guard()
            if callback_state(source_guard)!=source_guard_anchor:
                raise ValueError('exact delegated guard function/code/default/closure after invocation')
        invoke_guard_anchor=callback_state(invoke_guard)
        if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
            raise ValueError('original own validator/code before invoking callback shim')
        if callback_state(source_guard)!=source_guard_anchor or callback_state(invoke_guard)!=invoke_guard_anchor:
            raise ValueError('full original delegated guard and invoking shim authority before use')
        invoke_guard()
        for record in closure.values():closed.verify(record)
        need(modules['family'].extract_training.__code__.co_filename==plan['sources']['family']['path']
             and modules['auditor'].audit_extraction.__code__.co_filename==plan['sources']['auditor']['path'],
             'exact frozen extraction/audit APIs')
        clock(inner_deadline);calls['extraction_started']+=1;extraction_began=time.perf_counter()
        library=modules['family'].extract_training(training_spec=specification,reader=reader,
            checker_class=checker,closed=closed,source_guard=source_guard,deadline=inner_deadline)
        extraction_seconds=time.perf_counter()-extraction_began;clock(inner_deadline);calls['extraction_completed']+=1
        if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
            raise ValueError('original own validator/code before invoking callback shim')
        if callback_state(source_guard)!=source_guard_anchor or callback_state(invoke_guard)!=invoke_guard_anchor:
            raise ValueError('full original delegated guard and invoking shim authority before use')
        invoke_guard();library_text=canonical(library)
        need(library['schema']=='candidate-finite-Incident-transport-library-v1'
             and library['ROOT_inventory_admitted'] is False and library['schema_universally_validated'] is False
             and library['primitive_source_body_count']==0,'candidate wire, no body/advice/universal authority')
        calls['independent_audit_started']+=1;audit_began=time.perf_counter()
        audit=modules['auditor'].audit_extraction(training_spec=specification,library=library,reader=reader,
            checker_class=checker,closed=closed,source_guard=source_guard,deadline=inner_deadline)
        audit_seconds=time.perf_counter()-audit_began;clock(inner_deadline);calls['independent_audit_completed']+=1
        if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
            raise ValueError('original own validator/code before invoking callback shim')
        if callback_state(source_guard)!=source_guard_anchor or callback_state(invoke_guard)!=invoke_guard_anchor:
            raise ValueError('full original delegated guard and invoking shim authority before use')
        invoke_guard();need(canonical(library)==library_text,'auditor did not replace/edit producer candidate library')
        need(audit['completed'] is True and audit['all_checks_passed'] is True,
             'entire independent all-root audit completed, no favorable subset/prefix')
        library_pin=dict(save(pending/'candidate-library-v1.json',library),path=str(directory/'candidate-library-v1.json'))
        audit_pin=dict(save(pending/'independent-all-origin-audit-v1.json',audit),path=str(directory/'independent-all-origin-audit-v1.json'))
        result=dict(schema='equality-receptor-family-complete-extraction-result-v1',completed=True,
            scientific_stage='complete_original_donor_family_extraction_and_audit',training_specification=plan['training_specification'],
            candidate_library=library_pin,independent_audit=audit_pin,complete_origin_count=len(library['complete_origin_census']),
            family_count=len(library['families']),derivation_count=len(library['derivations']),calls=calls,
            extraction_call_seconds=extraction_seconds,independent_audit_call_seconds=audit_seconds,
            inner_seconds_before_return_preparation=time.perf_counter()-inner_began,
            universal_schema_validity_accepted=False,ROOT_library_admitted=False,ROOT_advice_admission=False,
            primitive_source_body_count=0,recipient_proofs=0,target_searches=0,new_RL_training=False,
            all_original_sources_and_command_roots_retained=True,accepted_prefix=False)
        result_pin=dict(save(pending/'extraction-result-v1.json',result),path=str(directory/'extraction-result-v1.json'))
        evidence=dict(schema='equality-receptor-family-complete-extraction-evidence-v1',plan=plan_pin,owner_plan=owner_pin,
            sources=plan['sources'],training_specification=plan['training_specification'],result=result_pin,
            complete_inner_limit_seconds=20,cold_worker_seconds_before_evidence=time.perf_counter()-began,peak_self_bytes=peak(),
            no_graph_construction=True,no_search_or_replay=True,only_original_three_donor_certificates=True,
            mathematical_scope='Fresh checks of retained donor ground proofs, their literal points and complete finite family/root census. No universal family theorem, library advice authority or receiver proof issued.')
        evidence_pin=save(pending/'extraction-evidence-v1.json',evidence)
        if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
            raise ValueError('original own validator/code before invoking callback shim')
        if callback_state(source_guard)!=source_guard_anchor or callback_state(invoke_guard)!=invoke_guard_anchor:
            raise ValueError('full original delegated guard and invoking shim authority before use')
        invoke_guard();closed.close();clock(inner_deadline)
        # Provisional files remain preserved on failure. No usable public
        # candidate aliases survive an unfinished inner invocation.
        for name in ('candidate-library-v1.json','independent-all-origin-audit-v1.json','extraction-result-v1.json','extraction-evidence-v1.json'):
            target=directory/name;os.link(pending/name,target);published.append(target)
        if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
            raise ValueError('original own validator/code before invoking callback shim')
        if callback_state(source_guard)!=source_guard_anchor or callback_state(invoke_guard)!=invoke_guard_anchor:
            raise ValueError('full original delegated guard and invoking shim authority before use')
        invoke_guard();clock(inner_deadline)
        complete_inner_seconds=time.perf_counter()-inner_began
        need(time.perf_counter()-began<55 and peak()+12*1024*1024<=LIMITS['peak_bytes'],
             'cold leaf return reserve inside unchanged60/512 owner')
        receipt=dict(schema='equality-receptor-family-extraction-worker-receipt-v1',stage='replay',stage_completed=True,
            scientific_stage='complete_original_donor_family_extraction_and_audit',all_direct_children_terminal_and_reaped=True,
            direct_children=0,direct_children_peak_sum_bytes=0,plan=plan_pin,sources=plan['sources'],training_specification=plan['training_specification'],
            result=pin(directory/'extraction-result-v1.json'),evidence=pin(directory/'extraction-evidence-v1.json'),
            candidate_library=pin(directory/'candidate-library-v1.json'),independent_audit=pin(directory/'independent-all-origin-audit-v1.json'),
            calls=calls,inner_complete_seconds=complete_inner_seconds,extraction_call_seconds=extraction_seconds,
            independent_audit_call_seconds=audit_seconds,seconds=time.perf_counter()-began,peak_self_bytes=peak(),
            universal_schema_validity_accepted=False,ROOT_library_admitted=False,ROOT_advice_admission=False,
            native_queries=0,native_replays=0,target_searches=0,recipient_proofs=0,new_RL_training=False)
        provisional=directory/'provisional-worker-receipt-v1.json';save(provisional,receipt)
        if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
            raise ValueError('original own validator/code before invoking callback shim')
        if callback_state(source_guard)!=source_guard_anchor or callback_state(invoke_guard)!=invoke_guard_anchor:
            raise ValueError('full original delegated guard and invoking shim authority before use')
        invoke_guard();need(time.perf_counter()-began<55 and peak()+12*1024*1024<=LIMITS['peak_bytes'],
             'final complete cold receipt/raw guard reserve')
        os.link(provisional,directory/'worker-receipt-v1.json')
    except BaseException as exc:
        for path in reversed(published):
            if path.exists():path.unlink()
        failure=dict(schema='equality-receptor-family-extraction-worker-receipt-v1',stage='replay',stage_completed=False,
            scientific_stage='complete_original_donor_family_extraction_and_audit',all_direct_children_terminal_and_reaped=True,
            direct_children=0,direct_children_peak_sum_bytes=0,accepted_prefix=False,usable_candidate_output=False,
            error=dict(type=type(exc).__name__,message=str(exc)),plan=plan_pin,calls=calls,
            inner_seconds=None if inner_began is None else time.perf_counter()-inner_began,seconds=time.perf_counter()-began,
            peak_self_bytes=peak(),universal_schema_validity_accepted=False,ROOT_library_admitted=False,ROOT_advice_admission=False,
            native_queries=0,native_replays=0,target_searches=0,recipient_proofs=0,new_RL_training=False)
        f=directory/'failure-worker-receipt-v1.json';save(f,failure)
        if not (directory/'worker-receipt-v1.json').exists():os.link(f,directory/'worker-receipt-v1.json')
        raise
    print(json.dumps(dict(stage='replay',scientific_stage='complete_original_donor_family_extraction_and_audit',
        stage_completed=True,worker_receipt=pin(directory/'worker-receipt-v1.json'),target_searches=0,ROOT_library_admitted=False)),flush=True)


if __name__=='__main__':main()
