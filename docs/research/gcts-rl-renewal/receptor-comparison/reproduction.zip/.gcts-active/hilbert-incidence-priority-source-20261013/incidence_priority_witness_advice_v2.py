"""SOURCE: target-blind conventional incidence-priority root ordering control.

No target-directed symbolic selection, supplied proof, inventory, project import,
dispatch, RNG or training. The entire admitted AND hypergraph supplies positive
additive TREE-cost witnesses. A fresh greedy point embedding can advise only
the mandatory scheduler's current branch row; complete primitive fallback stays
authoritative. Neither an absent witness nor an absent embedding prunes a key. Atomic Incident
conclusions consuming original Incident hypotheses rank first. This is a predicate-
name ordering convention, not a logical sort, relevance proof or geometric rule.
"""
from heapq import heappop, heappush
import math
import time

VERSION = 'target-blind-incidence-priority-witness-order-v2'
MAXIMUM_PREFERRED = 64


class AdviceBudgetExceeded(Exception):
    """No unfinished construction, cluster or preferred prefix is accepted."""

    def __init__(self, message, *, batch_membership=None):
        super().__init__(message)
        self.batch_membership = batch_membership


def _budget(deadline):
    if type(deadline) not in (int, float) or not math.isfinite(deadline):
        raise ValueError('finite literal same-search-clock deadline required')
    if time.perf_counter() >= deadline:
        raise AdviceBudgetExceeded('seed-forward same-search-clock budget')


def _integer(value):
    if type(value) is not int or value < 0:
        raise ValueError('nonnegative exact integer required')
    return value


def _atomic_incident(catalog, code):
    """Read only the exact admitted top node, never target or boundary data."""
    record = catalog.node_record(catalog.node_for_formula_code(code))
    return (len(record) == 3 and record[0] == 'pred' and record[1] == 'Incident'
            and type(record[2]) in (tuple, list) and len(record[2]) == 2)


def _root_priority(record, incident_codes, incident_seed_codes):
    """Stable two buckets; every original eligible root stays in the ordering."""
    return 0 if (incident_codes[record[1]]
                 and any(code in incident_seed_codes for code in record[4])) else 1


class GoalDependencyAdvice:
    """Compatible helper name; this control does not select symbolic goals.

    Cache only immutable catalogue/context/original-seed closure and witnesses.
    Complete selected dependencies, embeddings and preferences are fresh per
    call. There is no state-dependent cache, macro, admission or proof authority.
    """
    __slots__ = ('_binding', '_records', '_costs', '_choices', '_seed_recipes',
                 '_roots', '_incident_codes', '_incident_seed_codes', '_construction', '_sealed')

    def __setattr__(self, name, value):
        if getattr(self, '_sealed', False):
            raise AttributeError('immutable seed-forward catalogue/context cache')
        object.__setattr__(self, name, value)

    @staticmethod
    def _graph_binding(graph):
        # The model/catalogue identities bind the ENTIRE fixed boundary. No
        # target formula or boundary row is inspected for symbolic ranking.
        seeds = tuple((key.recipe, key.row, tuple(key.refs))
                      for key in graph.initial_selected)
        return (graph.catalog_identity_sha, graph.runtime_authority_sha,
                graph.model_epoch, graph.context_id, len(graph.recipes),
                len(graph.formulas), graph.height, seeds)

    def __init__(self, graph, recipes, *, deadline):
        started = time.perf_counter()
        _budget(deadline)
        graph.assert_runtime_integrity()
        binding = self._graph_binding(graph)
        count, formula_count, height, seeds = binding[4:]
        if len(recipes) != count or not seeds:
            raise ValueError('entire admitted catalogue and actual original seeds required')
        try:
            records = []
            dependents = [[] for _ in range(formula_count)]
            remaining = []
            ports = 0
            for index in range(count):
                _budget(deadline)
                meta = recipes[index]
                output = _integer(meta['output'])
                inputs = tuple(_integer(code) for code in meta['inputs'])
                actual = graph.recipes[index]
                if (output >= formula_count or any(code >= formula_count for code in inputs)
                        or output != actual.output or inputs != tuple(actual.inputs)):
                    raise ValueError('caller metadata differs from the whole admitted licence')
                records.append((output, inputs))
                distinct = sorted(set(inputs))
                remaining.append(len(distinct))
                for code in distinct:
                    dependents[code].append(index)
                ports += len(inputs)
            seed_recipes = {}
            seen_rows = set()
            for index, row, refs in seeds:
                _budget(deadline)
                index, row = _integer(index), _integer(row)
                if (index >= count or row >= height or row in seen_rows
                        or refs or records[index][1]):
                    raise ValueError('distinct actual zero-port original hypothesis placements required')
                seen_rows.add(row)
                key = next((k for k in graph.initial_selected if k.row == row), None)
                if (key is None or key.recipe != index or key not in graph.selected
                        or graph.totals[row] != 1
                        or graph.marks.get((1, row)) != records[index][0]):
                    raise ValueError('original hypothesis placement is not actually selected')
                code = records[index][0]
                seed_recipes[code] = min(index, seed_recipes.get(code, index))

            # All ordered ports are charged, although a repeated formula needs
            # only one settlement notification. Productive costs strictly exceed
            # EVERY input cost, so unsupported cycles cannot invent witnesses.
            costs = [None] * formula_count
            choices = [None] * formula_count
            best = [None] * formula_count
            heap = []
            for code in sorted(seed_recipes):
                best[code] = (0, -1)
                heappush(heap, (0, code, -1))
            for index, (output, inputs) in enumerate(records):
                _budget(deadline)
                if not inputs and (best[output] is None or (1, index) < best[output]):
                    best[output] = (1, index)
                    heappush(heap, (1, output, index))
            popped = fired = settled = 0
            while heap:
                _budget(deadline)
                cost, code, index = heappop(heap)
                popped += 1
                if costs[code] is not None or best[code] != (cost, index):
                    continue
                costs[code] = cost
                choices[code] = None if index == -1 else index
                settled += 1
                for recipe_index in dependents[code]:
                    _budget(deadline)
                    remaining[recipe_index] -= 1
                    if remaining[recipe_index] != 0:
                        continue
                    fired += 1
                    output, inputs = records[recipe_index]
                    if any(costs[source] is None for source in inputs):
                        raise AssertionError('AND licence fired without every ordered input')
                    proposed = 1 + sum(costs[source] for source in inputs)
                    if costs[output] is None and (best[output] is None
                            or (proposed, recipe_index) < best[output]):
                        best[output] = (proposed, recipe_index)
                        heappush(heap, (proposed, output, recipe_index))
            self._binding = binding
            self._records = tuple(records)
            self._costs = tuple(costs)
            self._choices = tuple(choices)
            self._seed_recipes = tuple(sorted(seed_recipes.items()))
            # This full formula-head scan is inside the unchanged search clock.
            # The graph's formula feature view has only constructors; use exact
            # immutable catalogue top nodes to distinguish the predicate name.
            incident_codes = []
            for code in range(formula_count):
                _budget(deadline)
                incident_codes.append(_atomic_incident(graph.catalog, code))
            self._incident_codes = tuple(incident_codes)
            self._incident_seed_codes = frozenset(code for code in seed_recipes
                                                 if incident_codes[code])
            roots = []
            for code, cost in enumerate(costs):
                _budget(deadline)
                if cost is None or cost < 2:
                    continue
                dag = self._dag(code, deadline=deadline)
                seed_codes = tuple(c for c in dag if costs[c] == 0)
                body_count = sum(costs[c] > 0 for c in dag)
                if seed_codes and body_count >= 2:
                    roots.append((cost, code, self._recipe_for(code), dag, seed_codes, body_count))
            _budget(deadline)
            self._roots = tuple(sorted(roots, key=lambda root:
                (_root_priority(root, self._incident_codes, self._incident_seed_codes), root)))
            _budget(deadline)
            construction = dict(version=VERSION, completed=True,
                control='specialized conventional incidence-priority seed-forward AND-witness ordering',
                atomic_formula_heads_scanned=formula_count,
                atomic_Incident_seed_codes=sorted(self._incident_seed_codes),
                incidence_priority_root_count=sum(_root_priority(root, self._incident_codes,
                    self._incident_seed_codes) == 0 for root in self._roots),
                every_original_eligible_root_retained=True,
                root_order='Incident conclusion plus original Incident-seed witness ancestry first; original cost/code/recipe order within both buckets',
                predicate_role_is_logical_sort=False,
                all_licenses_scanned=count, formula_count=formula_count,
                ordered_input_ports=ports, distinct_AND_dependencies=sum(map(len, dependents)),
                heap_pops=popped, nonzero_port_licenses_fired=fired,
                settled_formula_codes=settled, eligible_seed_consuming_roots=len(roots),
                cost_objective='minimum positive additive TREE cost; seed0; licence1+sum ordered input costs',
                shared_DAG_cardinality_minimized=False,
                target_consulted_for_symbolic_selection=False,
                minimum_witness_only_incomplete_advice=True,
                cache_scope='immutable catalogue/context/original-seed closure only',
                supplied_proof_input=False, inventory_admission=False,
                new_RL_training=False, learned_marking=False)
        finally:
            graph.assert_runtime_integrity()
            if self._graph_binding(graph) != binding:
                raise ValueError('catalogue/context/original seeds changed during construction')
        _budget(deadline)
        construction['seconds'] = time.perf_counter()-started
        self._construction = tuple(construction.items())
        self._sealed = True

    def construction_record(self):
        return dict(self._construction)

    def _recipe_for(self, code):
        index = self._choices[code]
        if index is None:
            index = dict(self._seed_recipes).get(code)
        if index is None:
            raise ValueError('no finite settled witness')
        return index

    def _dag(self, root, *, anchors=(), deadline):
        visited, pending = set(), [root]
        while pending:
            _budget(deadline)
            code = pending.pop()
            if code in visited:
                continue
            visited.add(code)
            if code != root and code in anchors:
                continue
            index = self._recipe_for(code)
            output, inputs = self._records[index]
            if output != code:
                raise AssertionError('witness output mismatch')
            for source in inputs:
                _budget(deadline)
                if self._costs[source] is None or self._costs[source] >= self._costs[code]:
                    raise AssertionError('positive-cost witness is not acyclic')
                pending.append(source)
        return tuple(sorted(visited, key=lambda code: (self._costs[code], code)))

    def _complete_rows(self, graph, supplied, *, deadline):
        by_row = {}
        for key in graph.selected:
            _budget(deadline)
            index, row = _integer(key.recipe), _integer(key.row)
            if index >= len(self._records) or row >= graph.height or row in by_row:
                raise ValueError('distinct selected row identities required')
            output, inputs = self._records[index]
            if (type(key) is not graph._bound_core.Key or type(key.refs) is not tuple
                    or len(key.refs) != len(inputs)
                    or any(type(ref) is not int or not 0 <= ref < row for ref in key.refs)
                    or graph.totals[row] != 1 or graph.marks.get((1, row)) != output):
                raise ValueError('selected key must retain exact ordered strict-prior point data')
            by_row[row] = key
        complete = {}
        for row, key in sorted(by_row.items()):
            _budget(deadline)
            output, inputs = self._records[key.recipe]
            if all(ref in complete and complete[ref] == code
                   for ref, code in zip(key.refs, inputs)):
                complete[row] = output
        if type(supplied) is not dict or supplied != complete:
            raise ValueError('caller must supply exact actual dependency-complete rows')
        return complete, by_row

    def _join(self, graph, key, total, marking, new_total, *, deadline, counts):
        """Read-only exact prospective union; a rejected attempt changes no union."""
        _budget(deadline)
        t, m = graph.point_data(key)
        counts['cluster_point_expansions'] += 1
        added_t, added_m = {}, {}
        for x, y, value in t:
            _budget(deadline)
            if (type(x) is not int or type(y) is not int or type(value) is not int
                    or x != 0 or not 0 <= y < graph.height or value != 1):
                raise ValueError('unchanged exact unit-row occupancy ABI required')
            point = (x, y)
            added_t[point] = added_t.get(point, 0)+value
            if total.get(point, 0)+added_t[point] > 1:
                return False
            if key not in graph.selected and graph.totals[y]+new_total.get(point, 0)+added_t[point] > 1:
                return False
        for x, y, value in m:
            _budget(deadline)
            if any(type(v) is not int for v in (x, y, value)):
                raise ValueError('exact assigned marking values required, including zero')
            point = (x, y)
            if ((point in added_m and added_m[point] != value)
                    or (point in marking and marking[point] != value)
                    or (point in graph.marks and graph.marks[point] != value)):
                return False
            added_m[point] = value
        for point, value in added_t.items():
            total[point] = total.get(point, 0)+value
            if key not in graph.selected:
                new_total[point] = new_total.get(point, 0)+value
        marking.update(added_m)
        return True

    def _embed(self, graph, root_record, complete, by_row, key_type, *, deadline, counts):
        cost, root, recipe_index, _, seed_codes, witness_body_count = root_record
        anchors = {}
        for row, code in sorted(complete.items()):
            anchors.setdefault(code, row)
        dag = self._dag(root, anchors=anchors, deadline=deadline)
        rows, planned = dict(anchors), {}
        total, marking, new_total = {}, {}, {}
        # Preserve every original indexed placement in the exact union. Only
        # actual root ancestry below counts as a consumed external receptor.
        union_keys = set()
        for key in graph.initial_selected:
            _budget(deadline)
            if key in union_keys:
                raise ValueError('duplicate original placement identity')
            if not self._join(graph, key, total, marking, new_total,
                              deadline=deadline, counts=counts):
                raise ValueError('original hypothesis union conflicts')
            union_keys.add(key)
        for code in dag:
            _budget(deadline)
            if code != root and code in anchors:
                continue
            index = self._recipe_for(code)
            _, inputs = self._records[index]
            if any(source not in rows for source in inputs):
                return None, 'no complete or planned ordered source'
            refs = tuple(rows[source] for source in inputs)
            selected_key = None
            for row in range(graph.height):
                _budget(deadline)
                if row in by_row or row in planned or any(ref >= row for ref in refs):
                    continue
                key = key_type(index, row, refs)
                counts['embedding_exact_legality_queries'] += 1
                if (graph.legal(key) and self._join(graph, key, total, marking, new_total,
                                                  deadline=deadline, counts=counts)):
                    selected_key = key
                    break
            if selected_key is None:
                return None, 'greedy strict-prior point-compatible embedding unavailable'
            rows[code] = selected_key.row
            planned[selected_key.row] = selected_key
            union_keys.add(selected_key)

        # Recover ACTUAL proposed root ancestry, including the exact selected
        # paths reused as anchors. A static seed-using witness alone must not
        # masquerade as a seed-using cluster after different selected reuse.
        all_rows = dict(by_row)
        all_rows.update(planned)
        root_key = all_rows[rows[root]]
        ancestry, pending = set(), [root_key]
        while pending:
            _budget(deadline)
            key = pending.pop()
            if key in ancestry:
                continue
            ancestry.add(key)
            output, inputs = self._records[key.recipe]
            if len(inputs) != len(key.refs):
                raise ValueError('actual ordered dependency multiplicity changed')
            for ref, code in zip(key.refs, inputs):
                _budget(deadline)
                source = all_rows.get(ref)
                if (source is None or ref >= key.row
                        or self._records[source.recipe][0] != code):
                    raise ValueError('actual cluster ancestry is not dependency complete')
                pending.append(source)
        original = set(graph.initial_selected)
        used_seeds = ancestry & original
        body_count = len(ancestry-original)
        if not used_seeds or body_count < 2:
            return None, 'actual reused ancestry is not a nontrivial seed-consuming cluster'
        for key in sorted(ancestry, key=lambda k: (k.row, k.recipe, k.refs)):
            _budget(deadline)
            if key not in union_keys:
                if key not in graph.selected or key.row not in complete:
                    raise ValueError('reused ancestry must be actually selected and complete')
                if not self._join(graph, key, total, marking, new_total,
                                  deadline=deadline, counts=counts):
                    return None, 'selected ancestry conflicts with exact cluster union'
                union_keys.add(key)
        distinct = tuple(sorted(union_keys, key=lambda k: (k.row, k.recipe, k.refs)))
        _budget(deadline)
        incident_seed_keys = tuple(sorted((key for key in used_seeds
            if self._incident_codes[self._records[key.recipe][0]]),
            key=lambda key: (key.row, key.recipe, key.refs)))
        actual_incidence_priority = bool(self._incident_codes[root] and incident_seed_keys)
        return dict(status='candidate_point_consistent_seed_forward_cluster_unchecked',
            actual_incidence_priority=actual_incidence_priority,
            actual_used_original_Incident_seed_keys=[key.data() for key in incident_seed_keys],
            symbolic_incidence_priority=_root_priority(root_record, self._incident_codes,
                self._incident_seed_codes) == 0,
            root_code=root, root_receptor_row=root_key.row,
            minimum_additive_tree_cost=cost, shared_DAG_cardinality_minimized=False,
            symbolic_witness_body_count=witness_body_count,
            symbolic_witness_seed_codes=list(seed_codes),
            actual_root_ancestry_keys=[k.data() for k in sorted(ancestry, key=lambda k: (k.row, k.recipe, k.refs))],
            actual_root_body_count=body_count,
            actual_used_original_seed_keys=[k.data() for k in sorted(used_seeds, key=lambda k: (k.row, k.recipe, k.refs))],
            primitive_keys=[k.data() for k in distinct],
            new_primitive_keys=[k.data() for k in distinct if k not in graph.selected],
            reused_selected_keys=[k.data() for k in distinct if k in graph.selected],
            aggregate_t=[[*p, value] for p, value in sorted(total.items())],
            aggregate_m=[[*p, value] for p, value in sorted(marking.items())],
            aggregate_t_counts_distinct_shared_placements_once=True,
            internal_and_current_point_checks=True,
            independent_logical_certificate_accepted=False,
            inventory_admission=False, macro_executed=False), 'point-compatible seed-forward witness'

    def preferred(self, graph, decision, *, complete_rows, key_type, deadline):
        started = time.perf_counter()
        _budget(deadline)
        graph.assert_runtime_integrity()
        if self._graph_binding(graph) != self._binding or decision != graph.decision():
            raise ValueError('same admitted context and fresh mandatory decision required')
        if decision.kind not in ('branch', 'forced') or key_type is not graph._bound_core.Key:
            raise ValueError('exact bound Key and mandatory selected domain required')
        binding = graph.membership_binding(decision)
        counts = dict(eligible_roots_scanned=0, completed_embeddings=0,
                      embedding_exact_legality_queries=0, cluster_point_expansions=0)
        keys, clusters, seen, reasons = [], [], set(), {}
        batch = None
        try:
            if decision.kind == 'branch':
                complete, by_row = self._complete_rows(graph, complete_rows, deadline=deadline)
                complete_codes = set(complete.values())
                for root_record in self._roots:
                    _budget(deadline)
                    if root_record[1] in complete_codes:
                        continue
                    counts['eligible_roots_scanned'] += 1
                    cluster, reason = self._embed(graph, root_record, complete, by_row,
                                                  key_type, deadline=deadline, counts=counts)
                    reasons[reason] = reasons.get(reason, 0)+1
                    if cluster is None:
                        continue
                    counts['completed_embeddings'] += 1
                    candidates = tuple(key_type(index, row, tuple(refs))
                        for index, row, refs in cluster['new_primitive_keys'] if row == decision.row)
                    if len(candidates) > 1:
                        raise ValueError('unit-row cluster cannot prefer multiple placements at one row')
                    if candidates and candidates[0] not in seen:
                        keys.append(candidates[0])
                        clusters.append(cluster)
                        seen.add(candidates[0])
                        if len(keys) == MAXIMUM_PREFERRED:
                            break
                # Embedding can reuse a different selected ancestry. Rank the
                # actual original-seed ancestry, retaining every gathered legal
                # preference if a symbolic priority witness loses that property.
                _budget(deadline)
                ranked = sorted(zip(keys, clusters), key=lambda item:
                    not item[1]['actual_incidence_priority'])
                keys = [key for key, cluster in ranked]
                clusters = [cluster for key, cluster in ranked]
                _budget(deadline)
                try:
                    flags, batch = graph.legal_batch(decision, tuple(keys),
                        expected_binding=binding, deadline=deadline)
                except graph.MembershipBudgetExceeded as exc:
                    raise AdviceBudgetExceeded('seed-forward exact selected-domain membership budget',
                                               batch_membership=exc.receipt) from exc
                if (type(flags) is not tuple or len(flags) != len(keys)
                        or any(type(flag) is not bool for flag in flags)
                        or batch['completed'] is not True
                        or batch['partial_results_returned'] is not False):
                    raise ValueError('complete exact membership result required')
                clusters = [cluster for cluster, flag in zip(clusters, flags) if flag]
                keys = [key for key, flag in zip(keys, flags) if flag]
            record = dict(version=VERSION,
                control='specialized conventional target-blind incidence-priority seed-forward ordering',
                incidence_priority_preferred_count=sum(cluster['actual_incidence_priority']
                    for cluster in clusters),
                actual_ancestry_priority_rechecked=True,
                nonpriority_legal_preferences_retained=True,
                predicate_role_is_logical_sort=False,
                decision=[decision.kind, decision.row, decision.count, decision.generation],
                forced_advice_empty=decision.kind == 'forced',
                preferred_count=len(keys), preferred_cluster_proposals=clusters,
                proposal_reason_counts=reasons, selected_domain_membership=batch, **counts,
                target_consulted_for_symbolic_selection=False,
                complete_canonical_fallback_retained=True,
                cluster_checks_are_independent_certificate=False,
                frontier_selection=False, pruning=False, RNG_draws=0,
                new_RL_training=False, learned_marking=False, inventory_admission=False)
        finally:
            graph.assert_runtime_integrity()
            if (self._graph_binding(graph) != self._binding
                    or graph.membership_binding(decision) != binding):
                raise ValueError('state/revision/domain/decision changed during seed-forward advice')
        _budget(deadline)
        record['seconds'] = time.perf_counter()-started
        return tuple(keys), record
