"""SOURCE ONLY distinct deterministic-advice DFS derivative, no dispatch.

This additive source adds only an explicitly admitted equality-transport advice
registry. Cold worker/owner/metadata17-role/consumer6 ABIs do not support it yet;
no runtime qualification or activation follows from these bytes. The complete
primitive BodyAuthority and Controller descriptor inventory stay empty.
Caller must supply independently qualified complete context/body/pool, the pinned
compact dynamic graph/lifecycle, unchanged core and 31 features/math, and this
package's streamed overlayV3. The seed_forward mode accepts source-bound current seed ordering or incidence-
priority ordering as distinct conventional controls; it introduces no RL inventory or pruning.
The deterministic advice lanes take the source-bound helper module plus its exact raw pin; all catalog construction/advice scans run
inside the same search deadline. BASE remains canonical in this derivative.
Advice never creates a hypothesis or changes a
domain. No producer proof is accepted; ROOT must separately admit a fresh owned
wrapper and complete independent compact trace checker before invocation.
"""
import copy
import hashlib
import math
import random
import time
from pathlib import Path

VERSION = 'compact24-I2-finite-family-first-checked-proof-scientific-DFS-v12-source'
FAMILY_VERSION = 'certificate-mined-Incident-receptor-family-I2-recipient-v2'
FAMILY_REGISTRY_SCHEMA = 'ROOT-I2-finite-Incident-advice-registry-binding-v1'
ADVICE_MODES = ('goal_advice', 'seed_forward')


class TraceCeiling(Exception):
    pass


INVENTORY_SCHEMA = 'ROOT-whole-compact-search-inventory-binding-v1'


def complete_inventory_binding(graph, authority, control, qualified_dimensions, core):
    """Reconstruct the exact whole inventory, never select or reduce it.

    ROOT supplies a separately authenticated, predeclared expected binding
    shared by every lane in this context. The helper result alone is not an
    admission or proof that the supplied pool is the full qualified grammar.
    """
    source = authority.original if hasattr(authority, 'original') else authority
    return dict(schema=INVENTORY_SCHEMA, model_epoch=graph.model_epoch,
        catalog_identity_sha256=graph.catalog_identity_sha,
        runtime_authority_sha256=graph.runtime_authority_sha,
        original_body_authority_epoch=source.epoch, whole_group_authority_epoch=authority.epoch,
        original_source_body_inventory_sha256=core.digest([[name, core.digest(core.json.loads(text))]
                                                           for name, text in source.bodies]),
        complete_descriptor_registry_sha256=core.digest([[d.identifier, d.priority, d.text]
                                                         for d in control.descriptors]),
        registered_whole_descriptor_count=len(control.descriptors),
        qualified_dimensions=copy.deepcopy(qualified_dimensions))


def search_episode(graph, authority, groups, life, overlay_module, features, policy_math, *,
                   episode_id, mode, seed, weights, attempts, seconds, event_ceiling,
                   prerequisite_pins, cold_preparation_costs, qualified_dimensions,
                   expected_inventory_binding, consumer_binding,
                   advice_module=None, advice_source_binding=None, advice_library_admission=None,
                   observer_module=None, observer_source_binding=None, observer_inputs=None,
                   family_registry_binding=None):
    """One predeclared episode; caller owns the full resource envelope.

    RNG and unique non-NULL commits are chronological and never rewound. Active
    origin/commit rolls back beside the graph/Controller/overlay. A commit's
    first chronological terminal transition determines its one retirement
    charge. Retired-first stays charged after revival; consumed-first cannot
    later earn a charge. This is frozen wording interpretation, not a new reward.
    """
    setup_started = time.perf_counter(); core = life.core
    if (type(episode_id) is not str or not episode_id
            or mode not in ('base','goal_advice','seed_forward','fixed','untrained','trained','donor')):
        raise ValueError('one exact predeclared episode and lane required')
    for value in (attempts,event_ceiling): core.integer(value)
    if (attempts < 1 or event_ceiling < 1 or type(seconds) not in (int,float)
            or not math.isfinite(seconds) or seconds <= 0):
        raise ValueError('literal positive complete episode bounds')
    if mode == 'seed_forward' and (attempts != 128 or seconds != 20 or event_ceiling != 2000):
        raise ValueError('seed_forward comparison retains the declared128/20/2000 limits')
    required_dimensions = {'logical_rows','formula_count','primitive_license_count','non_assumption_witness_count','source_body_count'}
    if set(qualified_dimensions) != required_dimensions:
        raise ValueError('independently qualified complete declared dimensions required')
    for field, value in qualified_dimensions.items():
        if type(value) is not int or value < (0 if field == 'source_body_count' else 1):
            raise ValueError('literal complete declared dimensions; source inventory may be empty for primitive discovery only')
    if qualified_dimensions['source_body_count'] == 0 and (mode not in ('base','goal_advice','seed_forward') or groups):
        raise ValueError('empty inventory permits primitive-only discovery, never learned-policy evidence')
    family_control = mode == 'seed_forward' and getattr(advice_module, 'VERSION', None) == FAMILY_VERSION
    if family_control != (family_registry_binding is not None):
        raise ValueError('family advice and its separately admitted full registry must occur together')
    if mode in ADVICE_MODES:
        if (qualified_dimensions['source_body_count'] != 0 or groups
                or advice_module is None or advice_source_binding is None):
            raise ValueError('deterministic primitive advice requires the same empty inventory')
        if (mode == 'seed_forward' and getattr(advice_module, 'VERSION', None)
                not in ('target-blind-seed-forward-witness-order-v1',
                        'target-blind-incidence-priority-witness-order-v2',
                        'deterministic-mined-incidence-family-advice-v2', FAMILY_VERSION)):
            raise ValueError('seed_forward mode requires the exact declared conventional control')
        overlay_module.checked_pin(advice_source_binding)
        origin = advice_module.GoalDependencyAdvice.__init__.__code__.co_filename
        if str(Path(origin).resolve()) != advice_source_binding['path']:
            raise ValueError('advice constructor must originate in the pinned helper source')
        finite_library = getattr(advice_module,'VERSION',None) == 'deterministic-mined-incidence-family-advice-v2'
        if finite_library or family_control:
            if mode != 'seed_forward' or type(advice_library_admission) is not dict:
                raise ValueError('finite-family control needs explicit current ROOT admission pin')
            overlay_module.checked_pin(advice_library_admission)
        elif advice_library_admission is not None:
            raise ValueError('ordinary ordering control cannot consume mined library admission')
    elif advice_module is not None or advice_source_binding is not None or advice_library_admission is not None:
        raise ValueError('other controls cannot receive candidate advice or library')
    if (mode not in ('base','seed_forward') or qualified_dimensions['source_body_count'] != 0
            or groups or (advice_library_admission is not None and not family_control)
            or observer_module is None or observer_source_binding is None
            or getattr(observer_module,'VERSION',None) != 'passive-first-checked-original-Gamma-target-observer-v2'
            or type(observer_inputs) is not dict or set(observer_inputs) != {
                'reader','wire','checker_class','closed','header','license_pin','source_guard'}):
        raise ValueError('exact fresh empty-library matched pair and passive observer inputs')
    overlay_module.checked_pin(observer_source_binding)
    if str(Path(observer_module.FirstCheckedProofObserver.__init__.__code__.co_filename).resolve()) != observer_source_binding['path']:
        raise ValueError('actual observer constructor must originate in the pinned source')
    observer_timeout = observer_module.ProofObservationBudgetExceeded
    advice_timeout = advice_module.AdviceBudgetExceeded if mode in ADVICE_MODES else ()
    source_authority = authority.original if hasattr(authority, 'original') else authority
    if (qualified_dimensions['logical_rows'] != 24 or graph.height != 24 or graph.fixture
            or len(graph.recipes) != qualified_dimensions['primitive_license_count']
            or len(graph.formulas) != qualified_dimensions['formula_count']
            or len(source_authority.bodies) != qualified_dimensions['source_body_count']
            or qualified_dimensions['non_assumption_witness_count'] != graph.catalog.header['dimensions']['non_assumption_witness_count']):
        raise ValueError('complete actual24-row model/body/license census differs from independently qualified declaration')
    if len(groups) > 64:
        raise ValueError('UNRESOLVED complete pool exceeds frozen64 capacity; do not trim or tune')
    if graph.semantic_state().get('schema') != 'compact-complete-dynamic-point-state-v2':
        raise ValueError('new separately qualified compact dynamic state required; no eager-wire relabeling')
    consumer_binding_text = overlay_module.check_consumer_binding(
        consumer_binding, graph, core, features, policy_math, dfs_function=search_episode,
        proof_observer_class=observer_module.FirstCheckedProofObserver,
        family_session_class=advice_module.FamilySession if family_control else None)
    stochastic = mode in ('donor','untrained','trained')
    if (stochastic and (type(seed) is not int or seed < 0)) or (not stochastic and seed is not None):
        raise ValueError('frozen stochastic seed or exact no-RNG control required')
    if not prerequisite_pins or not cold_preparation_costs:
        raise ValueError('explicit complete context/pool qualification and charged cost provenance')
    control = life.Controller(graph, authority, groups)
    if len(control.descriptors) != len(groups) or json_load(core,control.root_rejected_text):
        raise ValueError('all exact whole records registered; no partial pool or salvage')
    actual_inventory_binding = complete_inventory_binding(graph, authority, control, qualified_dimensions, core)
    if (type(expected_inventory_binding) is not dict
            or expected_inventory_binding.get('schema') != INVENTORY_SCHEMA
            or core.canonical(expected_inventory_binding) != core.canonical(actual_inventory_binding)):
        raise ValueError('every lane must reconstruct/register the same entire independently qualified inventory')
    frozen_weights = policy_math.vector(weights,'frozen episode weights')
    if set(frozen_weights) != set(features.FEATURE_NAMES) or len(frozen_weights) != 31:
        raise ValueError('exact31 weights including zeros required')
    if mode in ('base','goal_advice','seed_forward','fixed','untrained') and any(frozen_weights.values()):
        raise ValueError('base/fixed/untrained controls use frozen zero weights')
    overlay = overlay_module.LearnedFamilyOverlay(control,core,features,policy_math,frozen_weights,
        epsilon=0.1,temperature=1.0,maximum_descriptors=64,consumer_binding=consumer_binding)
    primitive = core.Executor(graph)
    rng = random.Random(seed) if stochastic else None
    setup_seconds = time.perf_counter()-setup_started
    registration_metrics = copy.deepcopy(control.metrics)
    graph_metrics_at_entry = copy.deepcopy(graph.metrics)
    validation_at_entry = control.metrics['members_checked']+control.metrics['mark_checks']
    begin = time.perf_counter(); deadline = begin+seconds
    events=[]; graph_states={}; policy_choices=[]; draws=[]; commits=[]
    adviser=None; advice_construction=None; advice_construction_started=None
    family_registry_record=None; family_session=None
    advice_observations=[]
    observer=None; observer_construction=None; first_checked_proof=None
    terminal_transitions=[]; first_terminal={}; retired_commit_ids=set(); consumed_commit_ids=set()
    active_commit_id=None; commit_trail=[]; node_count=0; maximum_facts=0
    fact_observations=[]; budget_observations=[]; proposal_effect_count=0
    metrics=dict(order_calls=0,logical_domain_keys_represented=0,order_seconds=0.0,
        order_descriptor_seconds=0.0,selected_key_observations=0,trace_seconds=0.0,primitive_step_seconds=0.0,
        full_fact_closure_seconds=0.0,rollback_seconds=0.0,exclusion_seconds=0.0,
        policy_prepare_choose_seconds=0.0,commit_bookkeeping_seconds=0.0,
        candidate_advice_seconds=0.0,proof_observer_seconds=0.0)

    def state():
        complete=overlay.semantic_state(); full_graph=complete['controller'].pop('graph')
        graph_sha=core.digest(full_graph)
        if graph_sha not in graph_states: graph_states[graph_sha]=full_graph
        complete['controller']['graph_state_sha256']=graph_sha
        value=dict(overlay=complete,active_commit_id=active_commit_id,
            trail_depths=dict(graph=len(graph.trail),controller=len(control.trail),
                              overlay=len(overlay.trail),commit=len(commit_trail)),
            chronological=dict(draws=len(draws),commits=len(commits),
                terminal_transitions=len(terminal_transitions),
                retired_commit_ids=sorted(retired_commit_ids),consumed_commit_ids=sorted(consumed_commit_ids)),
            maximum_fact_potential=maximum_facts)
        return value

    def event(kind,node,**fields):
        started=time.perf_counter()
        if len(events)>=event_ceiling: raise TraceCeiling('full scientific event budget; prefix never accepted')
        events.append(dict(index=len(events),kind=kind,node=node,**fields,state=state()))
        metrics['trace_seconds']+=time.perf_counter()-started

    def facts(node,reason):
        nonlocal maximum_facts
        started=time.perf_counter()
        available=features.available_rows(overlay._feature_graph(),overlay.recipes)
        potential=len(available['distinct_nonroot_codes'])
        maximum_facts=max(maximum_facts,potential)
        observation=dict(index=len(fact_observations),reason=reason,
            complete_rows=[[r,c] for r,c in sorted(available['complete'].items())],
            distinct_nonroot_codes=sorted(available['distinct_nonroot_codes']),
            root_codes=sorted(available['root_codes']),per_state_potential=potential,
            maximum_so_far=maximum_facts)
        fact_observations.append(observation)
        metrics['full_fact_closure_seconds']+=time.perf_counter()-started
        event('dependency_complete_fact_observation',node,observation=observation)

    def checked_budget(node,stage):
        # Raw provenance for the exact checked cutoff, not a mathematical
        # exhaustion reason. Event serialization may overshoot a finite check.
        elapsed=time.perf_counter()-begin
        used=graph.metrics['attempts']-start_attempts
        observation=dict(index=len(budget_observations),stage=stage,
            checked_search_elapsed_seconds=elapsed,primitive_attempts=used,
            attempt_limit=attempts,checked_search_limit_seconds=seconds,
            attempts_exhausted=used>=attempts,time_exhausted=elapsed>=seconds)
        if budget_observations and elapsed<budget_observations[-1]['checked_search_elapsed_seconds']:
            raise ValueError('monotone checked-search clock required')
        budget_observations.append(observation)
        event('checked_search_budget_observation',node,observation=observation)
        return observation

    def set_active_commit(identifier):
        nonlocal active_commit_id
        commit_trail.append(active_commit_id);active_commit_id=identifier

    def checkpoint():
        value=dict(overlay=overlay.checkpoint(),commit_trail_depth=len(commit_trail),
                   active_commit_id=active_commit_id)
        value['paired_semantic_sha256']=core.digest(dict(
            overlay=overlay.semantic_state(),active_commit_id=active_commit_id))
        return value

    def rollback(cp,node,reason,*,record=True):
        nonlocal active_commit_id
        started=time.perf_counter(); overlay.rollback(cp['overlay'])
        depth=core.integer(cp['commit_trail_depth'])
        if not 0<=depth<=len(commit_trail): raise ValueError('exact paired commit checkpoint depth')
        while len(commit_trail)>depth: active_commit_id=commit_trail.pop()
        if (active_commit_id!=cp['active_commit_id'] or core.digest(dict(
                overlay=overlay.semantic_state(),active_commit_id=active_commit_id))!=cp['paired_semantic_sha256']):
            raise ValueError('graph/hints/overlay/active origin did not roll back exactly')
        metrics['rollback_seconds']+=time.perf_counter()-started
        if record:
            event('paired_rollback',node,checkpoint=cp,reason=reason)
            facts(node,'after-paired-rollback')

    def resync(node,reason,decision=None):
        started=time.perf_counter(); prior_descriptor=overlay.active_id; origin=active_commit_id
        control.resync(decision)
        event('whole_controller_resync',node,reason=reason)
        if prior_descriptor is not None:
            if origin is None: raise ValueError('active proposal requires chronological non-NULL origin')
            hint=next(s for d,s in zip(control.descriptors,control.states) if d.identifier==prior_descriptor)
            if hint.status in ('retired','consumed'):
                first=origin not in first_terminal
                if first: first_terminal[origin]=hint.status
                if hint.status=='retired' and first: retired_commit_ids.add(origin)
                if hint.status=='consumed': consumed_commit_ids.add(origin)
                transition=dict(index=len(terminal_transitions),commit_id=origin,
                    descriptor_id=prior_descriptor,status=hint.status,reason=hint.reason,
                    first_terminal_transition=first,first_terminal_status=first_terminal[origin],
                    retirement_charge_added=hint.status=='retired' and first)
                terminal_transitions.append(transition)
                event('chronological_commit_terminal_transition',node,transition=transition)
        overlay.after_resync()
        if overlay.active_id is None and active_commit_id is not None: set_active_commit(None)
        if (overlay.active_id is None)!=(active_commit_id is None):
            raise ValueError('paired active descriptor/commit relation')
        event('overlay_after_whole_resync',node,reason=reason)
        metrics['commit_bookkeeping_seconds']+=time.perf_counter()-started

    def domain_descriptor(order):
        started=time.perf_counter(); value=order.descriptor()
        metrics['order_descriptor_seconds']+=time.perf_counter()-started
        return value

    def observe_proof(decision,node,*,origin_kind,completed_selection=None,source_link):
        nonlocal first_checked_proof
        started=time.perf_counter()
        try:
            candidate,receipt=observer.observe(decision,origin_kind=origin_kind,
                completed_selection=completed_selection,source_link=source_link,deadline=deadline)
            event('passive_first_proof_observation',node,observation=receipt)
            if candidate is not None:
                event('first_checked_logical_proof',node,origin_kind=origin_kind,
                    proof_sha256=core.digest(candidate),source_link=source_link)
                # No partial certificate escapes a trace/deadline exception.
                observer_module.clock(deadline)
                first_checked_proof=candidate
                return True
            observer_module.clock(deadline)
            return False
        finally:metrics['proof_observer_seconds']+=time.perf_counter()-started

    def order(decision,node):
        nonlocal proposal_effect_count
        started=time.perf_counter()
        if decision!=graph.decision() or decision.kind not in ('branch','forced'):
            raise ValueError('fresh mandatory global scheduler decision')
        base=graph.ordered_domain(decision)
        if len(base)!=decision.count:
            raise ValueError('full point domain is the only degree authority')
        draw_record=None; selection=None
        if stochastic:
            prepare_start=time.perf_counter(); prepared=overlay.prepare(decision)
            event('policy_prepare',node,decision=[decision.kind,decision.row,decision.count,decision.generation],
                prepared=dict(decision=prepared['decision'],menu=prepared['menu'],
                    needs_one_draw=prepared['needs_one_draw'],pool_epoch=prepared['pool_epoch'],
                    weight_sha256=prepared['weight_sha256'],prepared_state_sha256=prepared['prepared_state_sha256'],
                    complete_base_count=prepared['base_domain_descriptor']['complete_count'],
                    base_domain_descriptor=copy.deepcopy(prepared['base_domain_descriptor'])))
            draw=None
            if prepared['needs_one_draw']:
                before=core.digest(rng.getstate()); draw=rng.random(); after=core.digest(rng.getstate())
                draw_record=dict(index=len(draws),id=episode_id+'/draw/'+str(len(draws)),
                    draw=draw,rng_state_before_sha256=before,rng_state_after_sha256=after)
                draws.append(draw_record)
            ordered,selection=overlay.choose_prepared(prepared,draw)
            if selection['policy'] is not None:
                if draw_record is None: raise ValueError('exact one chronological draw per fresh selection')
                policy=copy.deepcopy(selection['policy']);policy.update(draw_record=draw_record,
                    selection_index=len(policy_choices),decision=prepared['decision'],commit_id=None)
                if selection['policy']['choice']['chosen_id']!='NULL':
                    identifier=episode_id+'/commit/'+str(len(commits))
                    commit=dict(id=identifier,index=len(commits),draw_id=draw_record['id'],
                        draw_index=draw_record['index'],descriptor_id=selection['active_descriptor_id'],
                        selection_index=len(policy_choices),decision=prepared['decision'],node=node)
                    commits.append(commit);set_active_commit(identifier);policy['commit_id']=identifier
                else: set_active_commit(None)
                policy_choices.append(policy)
                proposal_effect_count+=int(policy['commit_id'] is not None and selection['changed_first'])
            elif draw_record is not None: raise ValueError('forced/waiting continuation consumes no draw')
            event('policy_choose',node,selection=selection,draw_record=draw_record,
                active_commit_id=active_commit_id,policy_choice_index=len(policy_choices)-1 if selection['policy'] else None)
            metrics['policy_prepare_choose_seconds']+=time.perf_counter()-prepare_start
        else:
            if mode=='fixed':
                # Exactly the unchanged fixed ordering method's single resync.
                # No redundant preliminary scan is added to the fixed lane.
                ordered=control.ordered(decision)
                event('fixed_complete_order_controller_resync',node)
                overlay.after_resync();event('overlay_after_whole_resync',node,reason='fixed-control-order')
            else:
                resync(node,'base-control-order',decision);ordered=base
                if mode in ADVICE_MODES and decision.kind == 'branch':
                    advice_started=time.perf_counter()
                    record=dict(index=len(advice_observations),node=node,completed=False,
                                preferred_keys=[],selection=None)
                    try:
                        availability=features.available_rows(overlay._feature_graph(),overlay.recipes)
                        preferred, observation=adviser.preferred(graph,decision,
                            complete_rows=availability['complete'],key_type=core.Key,deadline=deadline)
                        ordered=graph.ordered_domain(decision,preferred)
                        record.update(completed=True,preferred_keys=[key.data() for key in preferred],
                                      selection=observation)
                    finally:
                        elapsed=time.perf_counter()-advice_started
                        metrics['candidate_advice_seconds']+=elapsed
                        record['total_call_seconds_including_complete_fact_closure']=elapsed
                        advice_observations.append(record)
        base_descriptor=domain_descriptor(base); ordered_descriptor=domain_descriptor(ordered)
        if (len(ordered)!=len(base)
                or base_descriptor['state_sha256']!=ordered_descriptor['state_sha256']
                or base_descriptor['catalog_identity_sha256']!=ordered_descriptor['catalog_identity_sha256']
                or base_descriptor['runtime_authority_sha256']!=ordered_descriptor['runtime_authority_sha256']
                or base_descriptor['decision']!=ordered_descriptor['decision']):
            raise ValueError('same full current primitive relation and exact fallback permutation required')
        if decision.kind=='forced' and ordered_descriptor['preferred_keys']:
            raise ValueError('global forced singleton cannot be policy modified')
        if mode in ADVICE_MODES and decision.kind=='branch' and record['completed']:
            if observe_proof(decision,node,origin_kind='completed_source_proposal',
                    completed_selection=record['selection'],source_link=dict(
                        node=node,advice_observation_index=record['index'],
                        prior_event_index=len(events)-1,decision=[decision.kind,decision.row,decision.count,decision.generation])):
                return None
        selected_key=ordered.first()
        metrics['order_calls']+=1;metrics['logical_domain_keys_represented']+=len(base)
        metrics['selected_key_observations']+=1
        metrics['order_seconds']+=time.perf_counter()-started
        event('complete_chosen_domain_order',node,
            decision=[decision.kind,decision.row,decision.count,decision.generation],
            complete_count=len(base),base_domain_descriptor=base_descriptor,
            ordered_domain_descriptor=ordered_descriptor,
            literal_full_stream_hashes_measured=False,
            selected_key=selected_key.data(),mode=mode,
            preferred_keys=copy.deepcopy(ordered_descriptor['preferred_keys']))
        return selected_key

    def step(key,node):
        start=time.perf_counter(); primitive.step(key)
        metrics['primitive_step_seconds']+=time.perf_counter()-start
        event('primitive_step',node,key=key.data())
        # Observe even a subsequently failed primitive and every forced step.
        facts(node,'after-primitive-step-before-whole-resync')
        resync(node,'after-primitive-step')

    initial=checkpoint();initial_semantic=core.digest(dict(overlay=overlay.semantic_state(),active_commit_id=active_commit_id))
    start_attempts=graph.metrics['attempts']
    def walk(parent_node=None):
        nonlocal node_count
        node=node_count;node_count+=1;cp=checkpoint()
        event('node_enter',node,parent_node=parent_node,checkpoint=cp)
        while True:
            decision=graph.decision()
            event('global_decision',node,decision=[decision.kind,decision.row,decision.count,decision.generation])
            if decision.kind=='dead':
                event('proved_global_dead',node);rollback(cp,node,'dead-subtree')
                event('node_return',node,status='exhausted_finite_marked_subtree')
                return 'exhausted_finite_marked_subtree',node
            if decision.kind=='complete':
                if observe_proof(decision,node,origin_kind='actual_selected',source_link=dict(
                        node=node,decision_event_index=len(events)-1,
                        decision=[decision.kind,decision.row,decision.count,decision.generation])):
                    event('node_return',node,status='first_checked_original_Gamma_target_proof')
                    return 'first_checked_original_Gamma_target_proof',node
                resync(node,'complete',decision)
                event('node_return',node,status='finite_exact_point_tiling')
                return 'finite_exact_point_tiling',node
            observed=checked_budget(node,'before-order')
            if observed['attempts_exhausted'] or observed['time_exhausted']:
                event('budget_unknown_no_exclusion',node,budget_observation_index=observed['index']);rollback(cp,node,'budget-unknown')
                event('node_return',node,status='unknown_search_budget')
                return 'unknown_search_budget',node
            if decision.kind=='branch' and observe_proof(decision,node,
                    origin_kind='actual_selected',source_link=dict(node=node,
                        budget_event_index=len(events)-1,
                        decision=[decision.kind,decision.row,decision.count,decision.generation])):
                event('node_return',node,status='first_checked_original_Gamma_target_proof')
                return 'first_checked_original_Gamma_target_proof',node
            key=order(decision,node)
            if first_checked_proof is not None:
                event('node_return',node,status='first_checked_original_Gamma_target_proof')
                return 'first_checked_original_Gamma_target_proof',node
            observed=checked_budget(node,'after-order')
            if observed['time_exhausted']:
                event('budget_unknown_after_order_no_exclusion',node,budget_observation_index=observed['index']);rollback(cp,node,'budget-after-order')
                event('node_return',node,status='unknown_search_budget')
                return 'unknown_search_budget',node
            if decision.kind=='forced': step(key,node);continue
            parent=checkpoint();event('branch_begin',node,key=key.data(),checkpoint=parent)
            step(key,node);status,child=walk(node)
            if status in ('finite_exact_point_tiling','first_checked_original_Gamma_target_proof'):
                event('node_return',node,status=status,child_node=child);return status,node
            rollback(parent,node,'restored-parent')
            if status.startswith('unknown_'):
                rollback(cp,node,'unknown-child-no-exclusion')
                event('node_return',node,status=status,child_node=child);return status,node
            if status!='exhausted_finite_marked_subtree':
                raise ValueError('only exhausted exact child permits parent-local exclusion')
            event('before_exhausted_child_exclusion',node,key=key.data(),child_node=child,child_status=status)
            start=time.perf_counter();graph.exclude_failed_child(key);graph.metrics['backtracks']+=1
            metrics['exclusion_seconds']+=time.perf_counter()-start
            event('parent_local_exhausted_child_exclusion',node,key=key.data(),child_node=child,child_status=status)
            resync(node,'after-proved-child-exclusion')

    trace_complete=True
    try:
        event('solve_begin',None,version=VERSION,episode_id=episode_id,mode=mode,seed=seed,
            limits=dict(attempts=attempts,seconds=seconds,events=event_ceiling))
        observer_started=time.perf_counter()
        observer=observer_module.FirstCheckedProofObserver(graph,**observer_inputs,deadline=deadline)
        observer_construction=copy.deepcopy(observer.construction)
        observer_construction['total_constructor_call_seconds']=time.perf_counter()-observer_started
        metrics['proof_observer_seconds']+=time.perf_counter()-observer_started
        if mode in ADVICE_MODES:
            advice_construction_started=time.perf_counter()
            if family_control:
                family_registry_record=checked_family_registry(graph,core,overlay_module,advice_module,
                    observer_inputs,consumer_binding,actual_inventory_binding,advice_source_binding,
                    advice_library_admission,family_registry_binding,deadline)
                family_session=advice_module.FamilySession(graph,
                    reader=observer_inputs['reader'], checker_class=observer_inputs['checker_class'],
                    closed=observer_inputs['closed'], header=observer_inputs['header'],
                    license_pin=observer_inputs['license_pin'],
                    library_pin=family_registry_record['library_source'],
                    admission_pin=advice_library_admission, implementation_pin=advice_source_binding,
                    source_guard=observer_inputs['source_guard'], deadline=deadline)
                adviser=advice_module.GoalDependencyAdvice(graph,overlay.recipes,
                    deadline=deadline,family_session=family_session)
            elif getattr(advice_module,'VERSION',None) == 'deterministic-mined-incidence-family-advice-v2':
                adviser=advice_module.GoalDependencyAdvice(graph,overlay.recipes,deadline=deadline,
                    library_admission_pin=advice_library_admission,source_binding=advice_source_binding)
            else:
                adviser=advice_module.GoalDependencyAdvice(graph,overlay.recipes,deadline=deadline)
            advice_construction=adviser.construction_record()
            advice_construction['total_construction_call_seconds']=time.perf_counter()-advice_construction_started
        facts(None,'initial-state')
        status,root_node=walk()
        if status!='finite_exact_point_tiling': rollback(initial,None,'final-root-restore')
        event('solve_return',None,status=status,root_node=root_node)
    except observer_timeout as exc:
        status='unknown_search_budget';trace_complete=False;root_node=0;first_checked_proof=None
        rollback(initial,None,'unaccepted-proof-observer-budget-cleanup',record=False)
        termination=dict(kind='proof-observer-budget',message=str(exc),events_retained=len(events),
            partial_logical_proof_accepted=False)
    except advice_timeout as exc:
        status='unknown_search_budget';trace_complete=False;root_node=0;first_checked_proof=None
        if adviser is None and advice_construction_started is not None:
            advice_construction=dict(completed=False,
                total_construction_call_seconds=time.perf_counter()-advice_construction_started)
        rollback(initial,None,'unaccepted-advice-budget-cleanup',record=False)
        termination=dict(kind='candidate-advice-budget',message=str(exc),
            events_retained=len(events),partial_advice_accepted=False)
    except TraceCeiling as exc:
        status='unknown_trace_budget';trace_complete=False;root_node=0;first_checked_proof=None
        rollback(initial,None,'unaccepted-trace-prefix-cleanup',record=False)
        termination=dict(kind='trace-ceiling',message=str(exc),events_retained=len(events))
    except Exception as exc:
        # Retain an unaccepted partial tape, chronological draws/commits and
        # the exact failure. No failed/partial trajectory may train. Cleanup
        # attempts rollback once and preserves its failure rather than retrying.
        status='unknown_infrastructure_failure';trace_complete=False;root_node=0;first_checked_proof=None
        cleanup_error=None
        try: rollback(initial,None,'unaccepted-failure-prefix-cleanup',record=False)
        except Exception as cleanup: cleanup_error=type(cleanup).__name__+': '+str(cleanup)
        termination=dict(kind='infrastructure-failure',type=type(exc).__name__,message=str(exc),
            events_retained=len(events),cleanup_error=cleanup_error)
    else: termination=dict(kind='complete-return',root_node=root_node)
    root_restored=core.digest(dict(overlay=overlay.semantic_state(),active_commit_id=active_commit_id))==initial_semantic
    if status!='finite_exact_point_tiling' and not root_restored:
        status='unknown_infrastructure_failure';trace_complete=False
        termination['root_restore_failure']='whole graph/hint/overlay/origin does not equal exact root'
    terminal=state()
    point_certificate=None
    if status=='finite_exact_point_tiling':
        try: point_certificate=graph.point_certificate()
        except Exception as exc:
            status='unknown_infrastructure_failure';trace_complete=False
            termination['point_certificate_failure']=type(exc).__name__+': '+str(exc)
    if status=='first_checked_original_Gamma_target_proof' and time.perf_counter()>=deadline:
        status='unknown_search_budget';trace_complete=False;first_checked_proof=None
        termination=dict(kind='logical-return-budget',events_retained=len(events),
                         partial_logical_proof_accepted=False)
    if status!='first_checked_original_Gamma_target_proof':first_checked_proof=None
    checks=control.metrics['members_checked']+control.metrics['mark_checks']-validation_at_entry
    counters=dict(maximum_distinct_dependency_complete_nonroot_facts=maximum_facts,logical_rows=24,
        primitive_attempts=graph.metrics['attempts']-start_attempts,attempt_limit=attempts,
        construction_validation_checks=checks,check_ceiling=10000,
        retired_commits=len(retired_commit_ids),commits=len(commits))
    provisional_reward=policy_math.reward(producer_primitive_certificate_passed=False,**counters)
    returned = dict(schema=VERSION,status=status,episode_id=episode_id,mode=mode,seed=seed,
        trace_complete=trace_complete,root_restored=root_restored,events=events,graph_states=graph_states,terminal_state=terminal,
        termination=termination,node_count=node_count,attempts=counters['primitive_attempts'],
        policy_choices=policy_choices,rng_draws=draws,
        RNG_schema='stdlib.random.Random/MT19937 pinned Python3.9; exactly one random() per fresh proposal selection',
        RNG_initial_seed=seed,RNG_terminal_state_sha256=core.digest(rng.getstate()) if rng else None,
        commits=commits,commit_terminal_transitions=terminal_transitions,
        commit_first_terminal=first_terminal,retired_commit_ids=sorted(retired_commit_ids),
        consumed_commit_ids=sorted(consumed_commit_ids),fact_observations=fact_observations,
        checked_budget_observations=budget_observations,
        reward_counters=counters,provisional_no_terminal_bonus_reward=provisional_reward,
        proposal_effect_count=proposal_effect_count,point_certificate=point_certificate,
        first_checked_proof=copy.deepcopy(first_checked_proof),
        logical_target_proof_accepted=first_checked_proof is not None,
        actual_selected_target_proof_accepted=first_checked_proof is not None and first_checked_proof['origin_kind']=='actual_selected',
        proof_observer=dict(source_binding=copy.deepcopy(observer_source_binding),
            construction=observer_construction,observations=copy.deepcopy(observer.observations) if observer else [],
            metrics=copy.deepcopy(observer.metrics) if observer else {},
            target_is_endpoint_only=True,no_ordering_or_state_mutation=True,
            first_origin_counted_only_after_complete_guards=True),
        primitive_certificate_accepted=False,independent_full_replay_accepted=False,
        immutable_weights=frozen_weights,weights_sha256=core.digest(frozen_weights),
        fixed_pool_descriptor_ids=[d.identifier for d in control.descriptors],
        registered_whole_descriptor_count=len(groups),all_source_body_count=qualified_dimensions['source_body_count'],
        qualified_dimensions=copy.deepcopy(qualified_dimensions),
        model_epoch=graph.model_epoch,group_authority_epoch=authority.epoch,
        prerequisite_pins=copy.deepcopy(prerequisite_pins),
        complete_inventory_binding=copy.deepcopy(actual_inventory_binding),
        complete_inventory_binding_sha256=core.digest(actual_inventory_binding),
        consumer_source_binding=json_load(core,consumer_binding_text),
        consumer_source_binding_sha256=core.digest(json_load(core,consumer_binding_text)),
        graph_state_schema='compact-complete-dynamic-point-state-v2',
        order_relation_schema='complete-compact-ordered-domain-descriptor-v2',
        literal_full_stream_hashes_measured=False,
        graph_metrics=copy.deepcopy(graph.metrics),graph_metrics_at_search_entry=graph_metrics_at_entry,
        lifecycle_metrics=copy.deepcopy(control.metrics),registration_lifecycle_metrics=registration_metrics,
        ordering_and_policy_metrics=metrics,cold_preparation_costs=copy.deepcopy(cold_preparation_costs),
        candidate_advice=dict(mode=mode if mode in ADVICE_MODES else None,
            source_binding=copy.deepcopy(advice_source_binding),
            library_admission_pin=copy.deepcopy(advice_library_admission),
            family_registry_binding=copy.deepcopy(family_registry_record),
            family_registry_binding_sha256=core.digest(family_registry_record) if family_registry_record is not None else None,
            family_metrics=copy.deepcopy(family_session.metrics) if family_session is not None else None,
            advice_library_is_primitive_inventory=False,
            construction=advice_construction,observations=advice_observations,
            static_cache_only=True,state_advice_recomputed=True,
            no_frontier_selection=True,no_pruning=True,
            no_learned_inventory=advice_library_admission is None,
            primitive_inventory_unchanged=True),
        controller_overlay_RNG_setup_seconds=setup_seconds,
        search_seconds_including_certificate_and_return_preparation=time.perf_counter()-begin,
        checked_deadline_overshoot_seconds=max(0.0,time.perf_counter()-deadline),
        cost_scope='Full pool construction/qualification provenance, cold registration, complete factored domain/order descriptors, actual selected-key extraction, all features/choice/gradient/trace/facts/primitive steps/rollback/exclusions and full certificate preparation. Represented candidate counts are not literal key observations or measured full-stream hashes. Enclosing owner complete serialization/exit/reap required separately.',
        native_queries=0,atomic_macro_moves=0,training_updates=0,
        claim_scope='Unqualified compact finite search candidate/UNKNOWN until a NEW independent complete compact trace/resource/symbolic audit; old eager replay cannot accept this wire. No universal palette, RL superiority or source-only speed claim')

    # Every deepcopy/reward/record field is ready before the last endpoint
    # deadline check. Positive return does no further metadata construction.
    returned['proof_observer']['final_return_primary_accepted']=returned['first_checked_proof'] is not None
    finished=time.perf_counter()
    returned['search_seconds_including_certificate_and_return_preparation']=finished-begin
    returned['checked_deadline_overshoot_seconds']=max(0.0,finished-deadline)
    if returned['status']=='first_checked_original_Gamma_target_proof' and time.perf_counter()>=deadline:
        returned.update(status='unknown_search_budget',trace_complete=False,
            first_checked_proof=None,logical_target_proof_accepted=False,
            actual_selected_target_proof_accepted=False,
            termination=dict(kind='logical-final-record-budget',events_retained=len(events),
                             partial_logical_proof_accepted=False))
        returned['proof_observer']['final_return_primary_accepted']=False
        finished=time.perf_counter()
        returned['search_seconds_including_certificate_and_return_preparation']=finished-begin
        returned['checked_deadline_overshoot_seconds']=max(0.0,finished-deadline)
    return returned


def checked_family_registry(graph, core, overlay_module, family_module, observer_inputs,
                            consumer_binding, inventory_binding, implementation_pin,
                            admission_pin, registry, deadline):
    """Check a ROOT-bound finite advice registry; never turn it into body authority.

    Caller seals executed source buffers/effective endpoints and the ROOT admission
    interpretation. This gate matches the admitted exact preimage to current q,
    model, consumer and inventory. It does not independently certify extraction
    or universal schema validity, and accepts no per-ground external authority.
    """
    fields = {'schema','instance_id','recipient_qualification','family_implementation',
        'library_source','training_spec','extraction_audit','model_binding',
        'consumed_source_epoch','primitive_source_body_count','advice_registry_epoch',
        'library_admission'}
    if (type(registry) is not dict or set(registry) != fields
            or registry['schema'] != FAMILY_REGISTRY_SCHEMA):
        raise ValueError('exact finite advice registry binding required')
    guard = observer_inputs['source_guard']
    guard()
    if time.perf_counter() >= deadline:
        raise family_module.FamilyBudgetExceeded('unfinished family registry construction')
    frozen = core.json.loads(core.canonical(registry))
    closed = observer_inputs['closed']
    for field in ('recipient_qualification','family_implementation','library_source',
                  'training_spec','extraction_audit','library_admission'):
        overlay_module.checked_pin(frozen[field]); closed.verify(frozen[field])
    current_model = dict(model_epoch=graph.model_epoch,
        catalog_identity_sha256=graph.catalog_identity_sha,
        runtime_authority_sha256=graph.runtime_authority_sha)
    source_epoch = core.digest(dict(consumer_binding=consumer_binding,
        complete_inventory_binding=inventory_binding,
        compact_graph_binding=graph.compact_graph_binding()))
    if (frozen['family_implementation'] != implementation_pin
            or frozen['library_admission'] != admission_pin
            or frozen['training_spec'] != family_module.TRAINING_SPEC_PIN
            or frozen['model_binding'] != current_model
            or frozen['consumed_source_epoch'] != source_epoch
            or type(frozen['primitive_source_body_count']) is not int
            or frozen['primitive_source_body_count'] != 0):
        raise ValueError('family source/provenance/model/source epoch or empty inventory mismatch')
    preimage = {key:value for key,value in frozen.items()
                if key not in ('library_admission','advice_registry_epoch')}
    epoch = core.digest(preimage)
    if frozen['advice_registry_epoch'] != epoch:
        raise ValueError('complete advice registry preimage differs')
    q = closed.json(frozen['recipient_qualification'])
    if (q['instance_id'] != frozen['instance_id']
            or q['expected_consumer_source_binding'] != consumer_binding
            or q['independent']['licenses'] != observer_inputs['license_pin']
            or closed.json(q['catalog']) != observer_inputs['header']):
        raise ValueError('exact current q/case/consumer/catalogue/independent licence binding required')
    family_module.validate_I2_recipient(q, observer_inputs['header'], closed, deadline=deadline)
    admission = closed.json(admission_pin)
    if (admission.get('schema') != family_module.ADMISSION_SCHEMA
            or admission.get('ROOT_advice_library_accepted') is not True
            or admission.get('advice_only') is not True
            or admission.get('schema_universally_validated') is not False
            or admission.get('library') != frozen['library_source']
            or admission.get('implementation') != implementation_pin
            or admission.get('recipient_qualification') != frozen['recipient_qualification']
            or admission.get('training_spec') != frozen['training_spec']
            or admission.get('extraction_audit') != frozen['extraction_audit']
            or admission.get('donor_sources') != family_module.DONOR_SOURCE_PINS
            or admission.get('registry_preimage_sha256') != epoch):
        raise ValueError('ROOT admission must bind this exact current finite advice preimage and old donors')
    # The caller authenticates the raw ROOT admission. It excludes its own pin
    # from the preimage to keep all raw source/authority dependencies acyclic.
    closed.close(); guard()
    if core.canonical(registry) != core.canonical(frozen):
        raise ValueError('registry argument changed during guarded construction')
    if time.perf_counter() >= deadline:
        raise family_module.FamilyBudgetExceeded('unfinished final family registry guards')
    return frozen


def json_load(core,text):
    # Uses the same JSON library already bound by the unchanged core, no parser
    # mutation and no acceptance authority inferred from a decoded payload.
    return core.json.loads(text)
