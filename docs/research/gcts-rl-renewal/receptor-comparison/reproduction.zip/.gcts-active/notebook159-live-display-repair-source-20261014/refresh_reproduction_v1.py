"""Preserve scientific ZIP members and refresh only reviewed display members."""
import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
PUB = pathlib.Path('/private/tmp/gcts-family-router-publish-20261010')
REPAIR = pathlib.Path(__file__).resolve().parent
ROUTE = pathlib.Path('docs/research/gcts-rl-renewal/receptor-comparison')
base = PUB / ROUTE
manifest_path = base / 'source-archive-manifest.json'
old_manifest = json.loads(manifest_path.read_text())
assert old_manifest == json.loads((REPAIR / 'before/source-archive-manifest.json').read_text())
archive = base / 'reproduction.zip'
archive_bytes = archive.read_bytes()
assert hashlib.sha256(archive_bytes).hexdigest() == old_manifest['archive']['sha256']
assert len(archive_bytes) == old_manifest['archive']['bytes']
before_packet = json.loads((REPAIR / 'before/summary.json').read_text())
after_packet = json.loads((base / 'summary.json').read_text())
assert before_packet['trials'] == after_packet['trials']

def ref(path, member):
    body = path.read_bytes()
    return {'member': member, 'path': str(path),
            'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}

new_manifest = dict(old_manifest)
new_manifest['schema'] = 'Notebook159-reproduction-source-archive-manifest-v2'
new_manifest['root_source_members'] = list(old_manifest['root_source_members'])
new_manifest['public_members'] = []
new_manifest['display_correction_scope'] = 'Narrow-grid sizing and phrase spacing only; all six scientific tapes and trial objects unchanged.'
extra_files = sorted(path for path in REPAIR.rglob('*') if path.is_file())
extra_refs = [ref(path, str(path.relative_to(ROOT))) for path in extra_files]
new_manifest['root_source_members'].extend(extra_refs)
temporary = base / 'reproduction-display-successor.tmp'
with zipfile.ZipFile(archive, 'r') as source, zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    assert len(source.namelist()) == len(set(source.namelist()))
    old_refs = {item['member']: item for field in ('root_source_members','public_members') for item in old_manifest[field]}
    assert set(source.namelist()) == set(old_refs) | {'README.txt'}
    for info in source.infolist():
        body = source.read(info.filename)
        if info.filename in old_refs:
            frozen = old_refs[info.filename]
            assert len(body) == frozen['bytes'] and hashlib.sha256(body).hexdigest() == frozen['sha256']
        if info.filename.startswith('PUBLIC/'):
            relative = info.filename.removeprefix('PUBLIC/')
            body = (base / relative).read_bytes()
            new_manifest['public_members'].append({'member': info.filename, 'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)})
        elif info.filename == 'README.txt':
            body += b'\nDisplay successor: narrow-screen grid sizing and phrase spacing corrected after live verification; original display Source and before/after correction records are retained. Scientific records are unchanged.\n'
        target.writestr(info, body)
    for item in extra_refs:
        assert item['member'] not in source.namelist()
        target.write(item['path'], item['member'])
with zipfile.ZipFile(temporary) as check:
    expected = {item['member']: item for field in ('root_source_members','public_members') for item in new_manifest[field]}
    assert set(check.namelist()) == set(expected) | {'README.txt'}
    assert len(check.namelist()) == len(set(check.namelist()))
    for member, item in expected.items():
        body = check.read(member)
        assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
new_bytes = temporary.read_bytes()
new_manifest['archive'] = {'path': 'reproduction.zip', 'sha256': hashlib.sha256(new_bytes).hexdigest(), 'bytes': len(new_bytes)}
temporary.replace(archive)
manifest_path.write_text(json.dumps(new_manifest, indent=2) + '\n')
publication = json.loads((ROOT / '.gcts-active/equality-receptor-family-six-lane-report-source-20261014/ROOT-publication-task-manifest-v2.json').read_text())
publication['base_commit'] = 'c4894c9bdcece7a2176ceb05879d53256d8cc098'
for item in publication['files']:
    body = (PUB / item['path']).read_bytes()
    item.update(sha256=hashlib.sha256(body).hexdigest(), bytes=len(body))
out = ROOT / '.gcts-active/equality-receptor-family-six-lane-report-source-20261014/ROOT-publication-task-manifest-v3.json'
out.write_text(json.dumps(publication, indent=2) + '\n')
print(json.dumps({'root_members':len(new_manifest['root_source_members']), 'public_members':len(new_manifest['public_members']), 'archive_bytes':len(new_bytes), 'task_files':len(publication['files']), 'all_trial_objects_exactly_equal':True}))
