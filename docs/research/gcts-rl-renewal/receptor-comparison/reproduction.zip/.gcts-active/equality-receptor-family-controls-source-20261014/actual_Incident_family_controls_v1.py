"""SOURCE-only real-family control callable; no imports or execution by author.

The cold caller provides exact actual q, graph, c8 reader, 3b6 GroundChecker,
candidate library and a future ROOT controls-only authorization. This is not a
proof-search episode. The pending-reader fixture and sole-key exclusion are
explicit mechanical interventions, never proof trajectories or proved pruning.
"""
import json
import time

VERSION = 'real-I2-Incident-family-ground-and-domain-controls-v1'


def need(value, label):
    if not value:
        raise ValueError(label)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def budget(deadline):
    if time.perf_counter() >= deadline:
        raise TimeoutError('unfinished complete family controls; no accepted prefix')


def literal_union(keys, session, fixed, *, deadline):
    """Independent arithmetic from licensed rows, with exact shared identities.

    Keys may appear in several clusters; the full key is deduplicated once.
    Ordered port occurrences remain in each primitive even when they alias.
    """
    total = [0] * 24; values = {}; counts = {}; selected = {}; seen = set()
    def assign(x, y, value):
        need(all(type(item) is int for item in (x, y, value)), 'literal integer point assignment')
        point = (x, y)
        need(point not in values or values[point] == value, 'literal remote mark conflict')
        values[point] = value; counts[point] = counts.get(point, 0) + 1
    for x, y, value in fixed:
        budget(deadline); assign(x, y, value)
    for supplied in keys:
        budget(deadline)
        need(type(supplied) is list and len(supplied) == 3 and
             type(supplied[0]) is int and type(supplied[1]) is int and
             0 <= supplied[1] < 24 and type(supplied[2]) is list and
             all(type(ref) is int and 0 <= ref < supplied[1] for ref in supplied[2]),
             'exact independent strict-prior key')
        index, row, refs = supplied; identity = (index, row, tuple(refs))
        if identity in seen:
            continue
        seen.add(identity)
        need(row not in selected, 'distinct placements cannot share positive support')
        selected[row] = identity; total[row] = 1
        record = session.record(index)
        need(len(refs) == len(record['inputs']), 'complete ordered reference multiplicity')
        local = {(1, row): record['output']}
        for port, (ref, code) in enumerate(zip(refs, record['inputs'])):
            need((1, ref) not in local or local[1, ref] == code, 'repeated input formula mismatch')
            local[1, ref] = code; local[2 + port, row] = ref - row
        for (x, y), value in local.items():
            assign(x, y, value)
    result = dict(totals=total, t=[[0, row, v] for row, v in enumerate(total) if v],
        m=[[*point, value] for point, value in sorted(values.items())],
        marks=[[*point, value, counts[point]] for point, value in sorted(values.items())])
    budget(deadline)
    return result


def master_reference(graph, *, deadline):
    budget(deadline)
    frontier = [row for row, value in enumerate(graph.totals) if value < 1]
    dead = [row for row in frontier if graph.domains[row].count == 0]
    forced = [row for row in frontier if graph.domains[row].count == 1]
    if dead:
        row = min(dead); kind = 'dead'
    elif forced:
        row = min(forced); kind = 'forced'
    elif not frontier:
        return ['complete', None, 0, None]
    else:
        row = min(frontier, key=lambda r: (graph.point_generation(r), graph.domains[r].count, r))
        kind = 'branch'
    return [kind, row, graph.domains[row].count, graph.point_generation(row)]


def run_controls(*, graph, core, family, reader, checker_class, closed, header,
                 license_pin, library_pin, controls_admission_pin,
                 implementation_pin, source_guard, deadline):
    """One bounded case; physical completion/search/library acceptance stays false."""
    began = time.perf_counter(); budget(deadline); source_guard()
    need(graph._bound_core is core and type(closed) is reader.ClosedInputs
         and graph.catalog.header == header and graph.height == 24
         and set(graph.selected) == set(graph.initial_selected), 'actual fresh original three-seed graph')
    auth = closed.json(controls_admission_pin)
    need(auth['controls_scope'] == 'real-ground-instance-and-domain-controls-only'
         and auth['scientific_episode_activation'] is False
         and auth['library'] == library_pin and auth['implementation'] == implementation_pin,
         'ROOT controls authorization cannot be mistaken for scientific activation')
    root = graph.checkpoint(); root_text = canonical(graph.semantic_state())
    tests = []; observations = []; instances = []; outcome = None
    executor = core.Executor(graph)
    steps_before = graph.metrics['attempts']; placements_before = graph.metrics['placements']
    def check(value, label):
        budget(deadline); need(value, label); tests.append(label)
    def reject(call, classes, label):
        budget(deadline)
        try:
            call()
        except classes as exc:
            tests.append(label)
            return dict(type=type(exc).__name__, message=str(exc))
        raise ValueError(label)
    try:
        session = family.FamilySession(graph, reader=reader, checker_class=checker_class,
            closed=closed, header=header, license_pin=license_pin, library_pin=library_pin,
            admission_pin=controls_admission_pin, implementation_pin=implementation_pin,
            source_guard=source_guard, deadline=deadline)
        view, _ = graph.feature_views()
        advice = family.GoalDependencyAdvice(graph, view, deadline=deadline, family_session=session)
        check(view.catalog is graph.catalog and len(view) == len(graph.recipes), 'actual complete indexed RecipeMetadataView')
        reject(lambda: family.GoalDependencyAdvice(graph, [view[i] for i in range(len(view))],
            deadline=deadline, family_session=session), ValueError, 'materialized recipe list rejected')
        state, selected, complete = session.begin_call(deadline=deadline)
        check(sorted(selected) == [0, 1, 2] and sorted(complete) == [0, 1, 2],
              'all original occurrence seeds independently dependency-complete')
        eqs = [selected[r] for r in sorted(complete) if session.record(selected[r][0])['witness']['formula'][0] == 'eq']
        phis = [selected[r] for r in sorted(complete) if session.record(selected[r][0])['witness']['formula'][:2] == ['pred', 'Incident']]
        check(bool(eqs) and bool(phis), 'current formula receptors from actual complete selected rows')
        fixed = header['boundary']['fixed_exterior_m'] + header['boundary']['fixed_target_m']
        submitted = 0; rejected_groundings = []
        for item in session.families():
            for equality in eqs:
                for phi in phis:
                    budget(deadline); submitted += 1
                    try:
                        instance = session.instantiate(family_id=item['family_id'], equality_key=equality,
                            formula_key=phi, deadline=deadline)
                    except family.NoInstance as exc:
                        rejected_groundings.append(dict(family_id=item['family_id'], equality=list(equality[:2])+[list(equality[2])],
                            phi=list(phi[:2])+[list(phi[2])], reason=str(exc)))
                        continue
                    check(instance['independent_ground_check']['original_ground_sequent_accepted'] is True
                          and instance['exact_original_ordered_Gamma'] == header['context']['ordered_local_premises']
                          and instance['primitive_keys'][:3] == state['order'][:3],
                          'whole original ordered Gamma and occurrence-specific ancestry expanded')
                    patch = literal_union(instance['primitive_keys'], session, fixed, deadline=deadline)
                    whole = literal_union(state['order']+instance['primitive_keys'], session, fixed, deadline=deadline)
                    check(patch == instance['literal_points'] and whole == instance['whole_current_point_union'],
                          'independent full literal patch/current/fixed union and mark refcounts')
                    check(literal_union(instance['primitive_keys']+instance['primitive_keys'], session, fixed,
                          deadline=deadline) == patch, 'shared full placements counted once across cluster copies')
                    check(len(instance['consumed_original_occurrence_indices']) <= 3
                          and instance['consumed_original_occurrence_indices'] == sorted(set(instance['consumed_original_occurrence_indices'])),
                          'ambient Gamma preservation distinct from actual dependency consumption')
                    instances.append(instance)
        check(bool(instances), 'at least one actually grounded current receptor family')
        sample = instances[0]
        reject(lambda: session.instantiate(family_id=sample['family_id'], equality_key=phis[0],
            formula_key=eqs[0], deadline=deadline), family.NoInstance, 'ordered equality and Incident ports cannot be swapped')
        reject(lambda: session.instantiate(family_id=sample['family_id'], equality_key=[True, 1, []],
            formula_key=list(phis[0][:2])+[list(phis[0][2])], deadline=deadline), ValueError,
            'bool recipe identity is not an integer key')
        reject(lambda: session.instantiate(family_id=sample['family_id'], equality_key=list(eqs[0][:2])+[[1]],
            formula_key=list(phis[0][:2])+[list(phis[0][2])], deadline=deadline), ValueError,
            'non-strict-prior reference rejected')
        reject(lambda: family.term(['var', 'control_var'], header['context']['theory']), ValueError,
            'unbound variable outside initial closed nullary family signature')
        reject(lambda: session.instantiate(family_id=sample['family_id'], equality_key=eqs[0],
            formula_key=phis[0], deadline=0), family.FamilyBudgetExceeded, 'expired grounding returns no instance prefix')

        def observe(label):
            decision = graph.decision()
            actual = [decision.kind, decision.row, decision.count, decision.generation]
            check(actual == master_reference(graph, deadline=deadline), 'global dead/forced/earliest-generation reference '+label)
            saved = canonical(graph.semantic_state())
            _, _, facts = session.snapshot(deadline=deadline)
            if decision.kind == 'dead':
                reject(lambda: advice.preferred(graph, decision, complete_rows=facts, key_type=core.Key,
                    deadline=deadline), ValueError, 'dead global frontier receives no family advice')
                observations.append(dict(label=label, decision=actual, source_state=graph.semantic_state(), preferred_keys=[]))
                return decision, None, None, []
            check(decision.kind in ('branch','forced'), 'actual nonempty selected point domain '+label)
            old_token = graph.membership_binding(decision)
            base = graph.ordered_domain(decision)
            preferred, record = advice.preferred(graph, decision, complete_rows=facts, key_type=core.Key, deadline=deadline)
            check(canonical(graph.semantic_state()) == saved, 'family advice leaves all point/domain/generation data unchanged '+label)
            check(type(preferred) is tuple and all(type(k) is core.Key and k.row == decision.row and graph.legal(k)
                  for k in preferred), 'every preference exact legal chosen-row key '+label)
            if decision.kind == 'forced':
                check(preferred == () and record['forced_advice_empty'] is True, 'real forced domain gets empty advice')
            ordered = graph.ordered_domain(decision, preferred)
            base_keys = tuple(base); ordered_keys = tuple(ordered)
            reference_keys = tuple(graph.candidates(decision.row))
            check(len(base_keys) == len(ordered_keys) == len(reference_keys) == decision.count
                  and base_keys == reference_keys and len(set(base_keys)) == decision.count,
                  'entire current selected domain literal EOF/cardinality '+label)
            check(ordered_keys == tuple(preferred) + tuple(k for k in base_keys if k not in set(preferred)),
                  'complete exact preferred-prefix plus canonical fallback order '+label)
            for proposal in record['preferred_cluster_proposals']:
                check(literal_union(proposal['primitive_keys'], session, fixed, deadline=deadline)
                      == proposal['literal_points'], 'every proposed expanded literal point patch '+label)
            observations.append(dict(label=label, decision=actual, source_state=graph.semantic_state(),
                preferred_keys=[k.data() for k in preferred], selection=record,
                complete_canonical_domain_keys=[k.data() for k in base_keys],
                complete_preferred_domain_keys=[k.data() for k in ordered_keys],
                literal_domain_EOF_measured=True))
            return decision, base, old_token, base_keys

        decision, old_domain, old_token, base_keys = observe('initial')
        first = graph.ordered_domain(decision, tuple(core.Key(i,r,tuple(rs)) for i,r,rs in
            observations[-1]['preferred_keys'])).first()
        check(first is not None, 'one actual scheduler first-key observation')
        executor.step(first)
        reject(old_domain.first, ValueError, 'domain token stale after real scheduler placement')
        reject(lambda: graph.legal_batch(decision, (), expected_binding=old_token, deadline=deadline),
               ValueError, 'membership token stale after real scheduler placement')
        graph.rollback(root)
        check(canonical(graph.semantic_state()) == root_text, 'whole rollback after one master-conforming primitive')
        reject(old_domain.first, ValueError, 'old domain stale after restored semantic state')
        reject(lambda: graph.legal_batch(decision, (), expected_binding=old_token, deadline=deadline),
               ValueError, 'old membership token stale after restored semantic state')
        reject(lambda: session.instantiate(family_id=sample['family_id'], equality_key=eqs[0],
            formula_key=phis[0], previous=sample, deadline=deadline), ValueError,
            'old external instance object not reusable after refreshed advice pool')

        # Actual physical graph, explicitly non-search fixture. A checked MP
        # reader is placed before its absent prerequisite solely to expose
        # remote marks. Executor rejection proves this is not a legal search
        # trajectory. No code/row/recipe route is supplied by the fixture.
        reader_key = next((core.Key(i,r,tuple(rs)) for i,r,rs in sample['new_primitive_keys']
            if session.record(i)['witness']['rule'] == 'mp' and
            any(ref not in {k.row for k in graph.selected} for ref in rs)), None)
        check(reader_key is not None and reader_key.row != graph.decision().row and graph.legal(reader_key),
              'checked instance supplies a legal pending-reader physical fixture')
        reject(lambda: executor.step(reader_key), ValueError, 'Executor forbids reader fixture bypass of master row')
        graph._apply_legal(reader_key)
        _, _, pending_facts = session.snapshot(deadline=deadline)
        check(reader_key.row not in pending_facts, 'actual selected pending reader is not a logical receptor fact')
        reject(lambda: session.instantiate(family_id=sample['family_id'], equality_key=eqs[0],
            formula_key=reader_key.data(), deadline=deadline), family.NoInstance,
            'actual pending reader cannot be used as an Incident hypothesis')
        forced, force_domain, force_token, force_keys = observe('marked-pending-reader-fixture')
        check(forced.kind == 'forced' and len(force_keys) == 1,
              'actual marked dependency exposes a genuine graph singleton; absent coverage fails closed')
        fixture_checkpoint = graph.checkpoint(); fixture_text = canonical(graph.semantic_state())
        # Nonlogical exclusion instrumentation tests the graph state machine,
        # not proved pruning. It never enters a scientific search trajectory.
        graph.exclude_failed_child(force_keys[0])
        dead, _, _, _ = observe('nonlogical-forced-key-exclusion-fixture')
        check(dead.kind == 'dead', 'global dead outranks all remaining frontier choices')
        reject(lambda: executor.step(first), ValueError, 'global dead prevents primitive placement anywhere')
        graph.rollback(fixture_checkpoint)
        check(canonical(graph.semantic_state()) == fixture_text, 'exact exclusion rollback with restored forced state')
        reject(force_domain.first, ValueError, 'forced descriptor stale after exclusion and rollback')
        reject(lambda: graph.legal_batch(forced, (), expected_binding=force_token, deadline=deadline),
               ValueError, 'forced membership token stale after exclusion and rollback')
        fresh_forced = graph.decision(); executor.step(graph.ordered_domain(fresh_forced).first())
        _, _, now_complete = session.snapshot(deadline=deadline)
        check(reader_key.row in now_complete, 'real forced prerequisite completes previously pending reader')
        graph.rollback(root)
        check(canonical(graph.semantic_state()) == root_text, 'entire reader/forced/exclusion fixture rolls back exactly')

        # A different legal current branch choice conflicts only remotely with
        # the checked reader's absent prerequisite row. No target output is used.
        initial_recipe = session.record(sample['new_primitive_keys'][0][0])
        alternate = next((key for key in base_keys if session.record(key.recipe)['output'] != initial_recipe['output']), None)
        check(alternate is not None, 'complete fallback contains a distinct licensed point assignment')
        executor.step(alternate)
        check(not graph.legal(reader_key), 'distant assigned formula mark rejects reader without support overlap')
        reject(lambda: literal_union(graph.semantic_state()['order']+[reader_key.data()], session, fixed,
            deadline=deadline), ValueError, 'independent literal distant current-mark conflict')
        graph.rollback(root)
        check(canonical(graph.semantic_state()) == root_text, 'remote-mark fixture whole rollback')
        outcome = dict(schema=VERSION, completed=True, tests=tests, observations=observations,
            all_current_receptor_requests=submitted, all_rejected_groundings=rejected_groundings,
            all_checked_ground_instances=instances, family_metrics=dict(session.metrics),
            actual_master_conforming_executor_steps=graph.metrics['attempts']-steps_before,
            instrumented_placements=graph.metrics['placements']-placements_before-(graph.metrics['attempts']-steps_before),
            real_pending_reader_case_exercised=True, real_forced_case_exercised=True,
            real_dead_case_exercised=True, literal_complete_domain_EOF_measured=True,
            fixture_trajectory_is_master_conforming=False, nonlogical_exclusion_fixture=True,
            exact_root_rollback_checked=False, repeated_equal_Gamma_case_exercised=False,
            aliased_MP_input_case_exercised=False, actual_zero_mark_case_exercised=False,
            no_proof_search_episode=True, target_searches=0, source_body_count=0,
            inventory_admission=False, scientific_consumer_activation=False,
            actual_selected_target_endpoint_issued=False, full24_board_accepted=False,
            full_trajectory_accepted=False, RL_episodes=0, training_updates=0)
    finally:
        graph.rollback(root)
        need(canonical(graph.semantic_state()) == root_text, 'final whole graph/domain/mark/generation rollback')
        graph.assert_runtime_integrity(); source_guard()
    budget(deadline)
    outcome['exact_root_rollback_checked'] = True
    outcome['complete_case_seconds_before_final_guards'] = time.perf_counter()-began
    source_guard(); budget(deadline)
    return outcome
