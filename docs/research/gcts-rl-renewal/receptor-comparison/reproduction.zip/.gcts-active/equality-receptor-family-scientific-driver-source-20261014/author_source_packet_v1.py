"""Stdlib-only SOURCE editing/AST/hash freezer. No emitted scientific module runs."""
import ast, copy, difflib, hashlib, json
from pathlib import Path
R=Path(__file__).resolve().parents[2]; D=Path(__file__).resolve().parent; AUTHOR='/root/hilbert_advice_controls'
OW=R/'.gcts-active/hilbert-i2-first-proof-ROOT-implementation-source-20261014/i2_first_proof_worker_v1.py'
OO=R/'.gcts-active/hilbert-i2-first-proof-owner-source-20261014/i2_first_proof_owner_v1.py'
OT=OO.with_name('i2_first_proof_terminal_v1.py')
OC=R/'.gcts-active/hilbert-i2-first-proof-metadata-source-20261014/leaf-source-contract-v1.json'
RC=R/'.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/source-contract-v3.json'
PLAN=R/'.gcts-active/equality-receptor-family-scientific-integration-plan-20261014/integration-plan-v1.json'
def pin(p):
 b=Path(p).read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(p):return json.loads(Path(p).read_bytes())
def write(name,v):
 p=D/name;assert not p.exists(),name;p.write_text(v if isinstance(v,str) else json.dumps(v,sort_keys=True,indent=2)+'\n');return pin(p)
def rep(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
def top(s,name,value):
 t=ast.parse(s);n=next(n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id==name for k in n.targets));lines=s.splitlines(keepends=True);return ''.join(lines[:n.lineno-1])+name+' = '+repr(value)+'\n'+''.join(lines[n.end_lineno:])
def function(s,name):
 n=next(n for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name);return ''.join(s.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
rc=read(RC); S={k:v for k,v in rc['sources'].items() if k not in ('worker','mechanism_controls')};assert len(S)==18
seal=Path(read(PLAN)['current_actual_prerequisite']['ROOT_complete_controls_disposition']['path']); CONTROL=pin(seal)
actual=rc['actual_fixed_inputs']; family_text=Path(S['family_advice']['path']).read_text();ft=ast.parse(family_text)
def literal(name):return ast.literal_eval(next(n.value for n in ft.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id==name for k in n.targets)))
DONORS=literal('DONOR_SOURCE_PINS'); UPSTREAM=literal('UPSTREAM_SOURCE_PINS'); TRAINING=literal('TRAINING_SPEC_PIN')
constants='\nROOT_COMPLETE_FAMILY_CONTROLS = '+repr(CONTROL)+'\nFROZEN_CONTROL_SOURCES = '+repr(rc['sources'])+'\nACTUAL_FAMILY_INPUTS = '+repr({k:actual[k] for k in ('candidate_library','independent_audit','ROOT_extraction_disposition')})+'\nFAMILY_TRAINING = '+repr(TRAINING)+'\nFAMILY_DONORS = '+repr(DONORS)+'\nFAMILY_UPSTREAM = '+repr(UPSTREAM)+'\nFAMILY_ADMISSION_SCHEMA = '+repr(literal('ADMISSION_SCHEMA'))+'\nFAMILY_REGISTRY_SCHEMA = \'ROOT-I2-finite-Incident-advice-registry-binding-v1\'\nSCIENTIFIC_PURPOSE = \'scientific-primitive-ordering-only\'\n'
shared='''
def scientific_variant(leaf):
    registry = leaf['family_registry_binding']
    need(leaf['mode'] in ('base','seed_forward'), 'only declared deterministic modes')
    if registry is None:
        return 'canonical' if leaf['mode'] == 'base' else 'ordinary-incidence-ordering'
    need(leaf['mode'] == 'seed_forward' and type(registry) is dict,
         'family registry only in explicit finite family lane')
    return 'finite-Incident-family-ordering'


def scientific_family_admission(leaf, admission):
    """Pure metadata scope gate; no candidate pool, checker or graph construction."""
    registry = leaf['family_registry_binding']
    fields = {'schema','instance_id','recipient_qualification','family_implementation',
        'library_source','training_spec','extraction_audit','model_binding',
        'consumed_source_epoch','primitive_source_body_count','advice_registry_epoch','library_admission'}
    need(type(registry) is dict and set(registry) == fields
         and registry['schema'] == FAMILY_REGISTRY_SCHEMA
         and registry['instance_id'] == leaf['selector']
         and registry['recipient_qualification'] == leaf['qualification']
         and registry['family_implementation'] == leaf['sources']['family_advice']
         and registry['library_source'] == ACTUAL_FAMILY_INPUTS['candidate_library']
         and registry['extraction_audit'] == ACTUAL_FAMILY_INPUTS['independent_audit']
         and registry['training_spec'] == FAMILY_TRAINING
         and type(registry['primitive_source_body_count']) is int
         and registry['primitive_source_body_count'] == 0,
         'exact current finite family registry; no injected bodies or donor target')
    epoch = digest({k:v for k,v in registry.items() if k not in ('library_admission','advice_registry_epoch')})
    need(registry['advice_registry_epoch'] == epoch, 'acyclic exact current registry preimage')
    need(type(admission) is dict and admission.get('schema') == FAMILY_ADMISSION_SCHEMA
         and admission.get('scientific_episode_activation') is True
         and admission.get('purpose') == SCIENTIFIC_PURPOSE
         and 'controls_scope' not in admission and 'ROOT_controls_authorized' not in admission
         and admission.get('ROOT_complete_controls_disposition') == ROOT_COMPLETE_FAMILY_CONTROLS
         and admission.get('ROOT_extraction_disposition') == ACTUAL_FAMILY_INPUTS['ROOT_extraction_disposition']
         and admission.get('ROOT_advice_library_accepted') is True
         and admission.get('advice_only') is True
         and admission.get('schema_universally_validated') is False
         and type(admission.get('primitive_source_body_count')) is int
         and admission['primitive_source_body_count'] == 0
         and admission.get('registry_preimage_sha256') == epoch
         and admission.get('library') == registry['library_source']
         and admission.get('implementation') == registry['family_implementation']
         and admission.get('recipient_qualification') == registry['recipient_qualification']
         and admission.get('training_spec') == FAMILY_TRAINING
         and admission.get('extraction_audit') == registry['extraction_audit']
         and admission.get('donor_sources') == FAMILY_DONORS
         and admission.get('upstream_sources') == FAMILY_UPSTREAM,
         'separate ROOT scientific-purpose advice admission; controls-only/extraction-only rejected before code loading')


def validate_execution_ledger(leaf, ledger):
    """Exact per-variant executed raw roles; baseline never executes family."""
    need(type(ledger) is list, 'whole executed-source ledger')
    expected = {p['path']:p for role,p in leaf['sources'].items()
                if role != 'master' and (role != 'family_advice' or leaf['family_registry_binding'] is not None)}
    observed = {}
    for item in ledger:
        need(type(item) is dict and set(item) == {'module_name','source_pin'}
             and type(item['module_name']) is str and item['module_name']
             and type(item['source_pin']) is dict, 'exact executed source row')
        p = item['source_pin']
        need(expected.get(p.get('path')) == p, 'no undeclared or deferred family execution')
        observed[p['path']] = p
    same(observed, expected, 'every required per-variant module actually executed; no family execution in BASE/ordinary')
'''
# The three supervisors own separate raw-read APIs. No shared project import.
controls_worker='''
def admit_complete_family_controls(inputs):
    seal = inputs.json(ROOT_COMPLETE_FAMILY_CONTROLS)
    need(seal['schema'] == 'ROOT-current-two-I2-family-controls-disposition-v1'
         and seal['ROOT_complete_scoped_controls_accepted'] is True
         and tuple(c['instance_id'] for c in seal['cases']) == RECIPIENT_IDS
         and seal['successful_control_cases'] == 2
         and seal['scientific_search_activation'] is False
         and seal['ROOT_library_admitted'] is False,
         'actual complete scoped controls prerequisite, never scientific admission by itself')
    resource = inputs.json(seal['resource_qualification'])
    need(resource['ROOT_final_accepted'] is True
         and set(resource['predicates']) == RESOURCE_PREDICATES
         and all(v is True for v in resource['predicates'].values()), 'whole genuine controls resource closure')
    receipt = inputs.json(seal['actual_receipt']); evidence = inputs.json(seal['actual_evidence'])
    need(receipt['stage_completed'] is True and receipt['controls'] == seal['actual_controls']
         and receipt['evidence'] == seal['actual_evidence']
         and evidence['sources'] == FROZEN_CONTROL_SOURCES
         and evidence['controls'] == seal['actual_controls']
         and evidence['scientific_consumer_activation'] is False,
         'whole current repaired-source control receipt/evidence')
    for value in (seal,resource,receipt,evidence): inputs.tree(value)
    return seal
'''
python_guards=function(family_text,'guard_state').replace('def guard_state(', 'def function_signature(')
methods=function(family_text,'method_state').replace('def method_state(', 'def effective_methods(').replace('guard_state(', 'function_signature(')
W=OW.read_text();W=top(W,'AUTHOR_IDENTITY',AUTHOR);W=top(W,'FROZEN_SOURCES',S)
W=top(W,'PLAN','ROOT-I2-finite-family-first-proof-plan-v1');W=top(W,'ACTIVATION','ROOT-I2-finite-family-first-proof-activation-v1');W=top(W,'RECEIPT','I2-finite-family-first-proof-worker-receipt-v1')
W=rep(W,'import inspect\n','import inspect\nimport types\nfrom collections.abc import Iterable as _StdlibIterable\n_NATIVE_GENERIC_ALIAS = type(list[int])\n_ITERABLE_CLASS_GETITEM = vars(_StdlibIterable)[\'__class_getitem__\']\n')
W=rep(W,'\n\ndef person_review(',constants+'\n'+shared+'\n'+controls_worker+'\n'+python_guards+'\n\n'+methods+'\n\ndef person_review(')
W=rep(W,"else '/root/hilbert_ordering_diagnosis')","else (AUTHOR_IDENTITY if scope == 'final-primitive-advice-pair-certificate-helper'\n                   else '/root/hilbert_ordering_diagnosis'))")
W=rep(W,"'body_source_bindings','observer_review'}","'body_source_bindings','observer_review','family_registry_binding'}")
W=rep(W,"p['sources']['certificate'], 'final-primitive-advice-pair-certificate-helper'","p['sources']['final_certificate'], 'final-primitive-advice-pair-certificate-helper'")
W=rep(W,"    expected_roles = ('streamed_overlay','streamed_dfs','streamed_proposal','features31','policy_math','proof_observer')","    expected_roles = ('streamed_overlay','streamed_dfs','streamed_proposal','features31','policy_math','proof_observer','family_advice')")
W=rep(W,"    runtime = p['runtime']","    admit_complete_family_controls(inputs)\n    variant = scientific_variant(p)\n    if p['family_registry_binding'] is not None:\n        inputs.tree(p['family_registry_binding'])\n        scientific_family_admission(p, inputs.json(p['family_registry_binding']['library_admission']))\n    runtime = p['runtime']")
W=rep(W,"'consumer_binding_sha256':digest(p['consumer_binding']),","'consumer_binding_sha256':digest(p['consumer_binding']),\n        'family_registry_binding_sha256':digest(p['family_registry_binding']),")
# Modules may not be executed merely because they appear in the common raw map.
W=rep(W,"    for role,value in p['sources'].items():\n        if role in ('worker','master'):","    variant = scientific_variant(p)\n    family_lane = p['family_registry_binding'] is not None\n    for role,value in p['sources'].items():\n        if role in ('worker','master') or (role == 'family_advice' and not family_lane):")
W=rep(W,"    cert = modules['certificate']; closed = cert.ClosedInputs()","    cert = modules['certificate']; final_cert = modules['final_certificate']\n    closed = cert.ClosedInputs(); closed_type_anchor = type(closed)\n    closed_methods = effective_methods(closed)")
W=rep(W,"    graph_seconds = time.perf_counter() - graph_started\n    module_states.append(executable_state(dynamic, class_roots=(graph_type, type(graph.catalog))))","    graph_seconds = time.perf_counter() - graph_started\n    catalog_anchor = graph.catalog; catalog_type_anchor = type(catalog_anchor)\n    graph_methods = effective_methods(graph); catalog_methods = effective_methods(catalog_anchor)\n    module_states.append(executable_state(dynamic, class_roots=(graph_type, catalog_type_anchor)))")
W=rep(W,"    life = lifecycle.make_lifecycle(core,graph_type)\n    authority", "    life = lifecycle.make_lifecycle(core,graph_type)\n    body_type_anchor, controller_type_anchor = life.BodyAuthority, life.Controller\n    module_states.append(executable_state(lifecycle, class_roots=(body_type_anchor,controller_type_anchor)))\n    authority")
W=rep(W,"    control = life.Controller(graph,authority,[])\n    actual_binding", "    control = life.Controller(graph,authority,[])\n    authority_methods = effective_methods(authority); controller_methods = effective_methods(control)\n    actual_binding")
W=rep(W,"    header_text = canonical(header)\n    def source_guard():", "    header_text = canonical(header); plan_text = canonical(p); q_text = canonical(q)\n    def source_guard():")
W=rep(W,"        if (unchanged_executable is not guard_fn or guard_fn.__code__ is not guard_code\n                or need is not need_fn or need_fn.__code__ is not need_code):\n            raise ValueError('original cold validator/rejection endpoint changed')\n        guard_fn(own_state)\n        for state in module_states:\n            guard_fn(state)\n        need(set(modules)", "        if (source_guard is not callback_anchor or source_guard.__code__ is not callback_code\n                or unchanged_executable is not guard_fn or guard_fn.__code__ is not guard_code\n                or need is not need_fn or need_fn.__code__ is not need_code):\n            raise ValueError('original cold validator/rejection endpoint changed')\n        guard_fn(own_state)\n        for state in module_states:\n            guard_fn(state)\n        need(set(modules)")
W=rep(W,"and closed is closed_anchor and type(closed) is cert.ClosedInputs", "and graph.catalog is catalog_anchor and type(graph.catalog) is catalog_type_anchor\n             and closed is closed_anchor and type(closed) is closed_type_anchor is cert.ClosedInputs")
W=rep(W,"             'exact original graph/reader/wire/checker/header endpoints, never supplied substitutes')\n        source_cache_gate(inputs,p['sources']); inputs.close(); closed.close()", "             'exact original graph/reader/wire/checker/header endpoints, never supplied substitutes')\n        need(life.BodyAuthority is body_type_anchor and life.Controller is controller_type_anchor\n             and type(authority) is body_type_anchor and type(control) is controller_type_anchor\n             and effective_methods(closed) == closed_methods\n             and effective_methods(graph) == graph_methods\n             and effective_methods(graph.catalog) == catalog_methods\n             and effective_methods(authority) == authority_methods\n             and effective_methods(control) == controller_methods\n             and canonical(p) == plan_text and canonical(q) == q_text,\n             'unchanged effective generated/class/property/method endpoints and metadata; graph data may evolve')\n        ledger = source_cache_gate(inputs,p['sources']); validate_execution_ledger(p,ledger)\n        admitted_modules = (sys.modules[__name__], *module_anchors.values())\n        for module in tuple(sys.modules.values()):\n            name = getattr(module,'__file__',None)\n            if name and Path(name).suffix == '.py' and ROOT in Path(name).resolve().parents:\n                need(any(module is item for item in admitted_modules), 'no injected/co_filename-only project module')\n        inputs.close(); closed.close()")
W=rep(W,"    def invoke_guard():\n        if (source_guard", "    def invoke_guard():\n        if invoke_guard is not invoke_anchor or invoke_guard.__code__ is not invoke_code:\n            raise ValueError('original checked callback shim identity/code changed')\n        if (source_guard")
W=rep(W,"        callback_anchor()\n    invoke_anchor", "        callback_anchor()\n        if (source_guard is not callback_anchor or callback_anchor.__code__ is not callback_code\n                or callback_anchor.__defaults__ is not callback_defaults\n                or callback_anchor.__kwdefaults__ is not callback_kwdefaults\n                or callback_anchor.__closure__ is not callback_cells\n                or any(cell.cell_contents is not value for cell,value in zip(callback_anchor.__closure__ or (),callback_values))\n                or invoke_guard is not invoke_anchor or invoke_guard.__code__ is not invoke_code):\n            raise ValueError('original callback/shim changed during delegation')\n    invoke_anchor")
W=rep(W,"proof_observer_class=observer_module.FirstCheckedProofObserver)\n    construction_seconds", "proof_observer_class=observer_module.FirstCheckedProofObserver,\n                                   family_session_class=modules['family_advice'].FamilySession if family_lane else None)\n    construction_seconds")
W=rep(W,"advice_module=modules['candidate_advice'] if p['mode'] == 'seed_forward' else None,\n        advice_source_binding=p['sources']['candidate_advice'] if p['mode'] == 'seed_forward' else None,", "advice_module=(modules['family_advice'] if family_lane else modules['candidate_advice']) if p['mode'] == 'seed_forward' else None,\n        advice_source_binding=p['sources']['family_advice' if family_lane else 'candidate_advice'] if p['mode'] == 'seed_forward' else None,\n        advice_library_admission=p['family_registry_binding']['library_admission'] if family_lane else None,\n        family_registry_binding=p['family_registry_binding'],")
W=rep(W,"license_pin=q['independent']['licenses'],source_guard=source_guard))", "license_pin=q['independent']['licenses'],source_guard=invoke_guard))")
W=rep(W,"    # Save EVERY event, state, order descriptor, error/prefix, point certificate", "    same(result['candidate_advice']['family_registry_binding'], p['family_registry_binding'], 'actual family registry equals predeclared scientific lane')\n    same(result['candidate_advice']['family_registry_binding_sha256'],\n         digest(p['family_registry_binding']) if family_lane else None, 'actual family registry digest')\n    # Save EVERY event, state, order descriptor, error/prefix, point certificate")
W=rep(W,"checked = cert.verify_saved_certificate(result_pin=result_pin,", "checked = final_cert.verify_saved_certificate(result_pin=result_pin,")
W=rep(W,"            expected_mode=p['mode'])", "            expected_mode=p['mode'],expected_variant=variant,\n            family_registry_binding=p['family_registry_binding'])")
W=rep(W,"    execution_source_ledger = source_cache_gate(inputs,p['sources']); inputs.close(); closed.close()", "    execution_source_ledger = source_cache_gate(inputs,p['sources']); validate_execution_ledger(p,execution_source_ledger)\n    inputs.close(); closed.close()")
W=rep(W,"'plan':ppin,'activation':apin,'qualification':p['qualification'],'worker':p['sources']['worker'],", "'plan':ppin,'activation':apin,'qualification':p['qualification'],'worker':p['sources']['worker'],\n        'advice_variant':variant,'family_registry_binding':p['family_registry_binding'],\n        'family_registry_binding_sha256':digest(p['family_registry_binding']),\n        'ROOT_complete_controls_disposition':ROOT_COMPLETE_FAMILY_CONTROLS,")
W=rep(W,"        transport_pin = FROZEN_SOURCES['transport']", "        if FAILURE_PHASE[0] in ('entry','metadata-admission'):\n            # Scope rejection must occur before ANY project Source execution.\n            # No success frame/prefix: owner still directly wait4-reaps exit1.\n            os._exit(1)\n        transport_pin = FROZEN_SOURCES['transport']")
W=rep(W,"# Canonical base has no advice; seed_forward uses the reviewed target-blind helper.", "# Canonical base has no advice; seed_forward uses ordinary or separately admitted family advice.") if W.count("# Canonical base has no advice; seed_forward uses the reviewed target-blind helper.")==1 else W
# Syntax only; never evaluate scientific Source.
compile(W,str(D/'I2_finite_family_first_proof_worker_v1.py'),'exec')
WP=write('I2_finite_family_first_proof_worker_v1.py',W); MAP=dict(S,worker=WP)
contract=read(OC);contract.update(schema='I2-finite-family-first-proof-leaf-source-contract-v1',author_identity=AUTHOR,source_map=MAP,sources={'worker':WP,'certificate':S['final_certificate'],'proof_observer':S['proof_observer'],'streamed_overlay':S['streamed_overlay']},selected_wrapper_version='I2-finite-family-worker-v1',advice_library_admission='Future separately ROOT-issued scientific-purpose pin, never controls-only authorization',no_mined_MF_roles=False,empty_lemma_inventory=True,role_specific_authors={'worker':AUTHOR,'owner':AUTHOR,'terminal':AUTHOR,'certificate':AUTHOR,'recipient_reader':'/root/hilbert_ordering_diagnosis','proof_observer':'/root/hilbert_ordering_diagnosis','leaf_metadata_contract':AUTHOR},ROOT_complete_controls_disposition=CONTROL,repaired_control_sources=rc['sources'],source_only=True,scientific_calls=0,execution_authorized=False,scientific_acceptance=False,predecessor_contract=pin(OC))
abi=contract['prospective_ABIs'];abi.update(worker_plan_field_count=21,worker_plan_exact_fields=sorted([*abi['worker_plan_exact_fields'],'family_registry_binding']),worker_plan_schema='ROOT-I2-finite-family-first-proof-plan-v1',activation_schema='ROOT-I2-finite-family-first-proof-activation-v1',receipt_schema='I2-finite-family-first-proof-worker-receipt-v1',consumer_role_count=7,consumer_roles=['streamed_overlay','streamed_dfs','streamed_proposal','features31','policy_math','proof_observer','family_advice'],raw_source_role_count=19)
contract['scientific_scope_gate']={'scientific_episode_activation':True,'purpose':'scientific-primitive-ordering-only','forbidden_fields':['controls_scope','ROOT_controls_authorized'],'before_project_import':True,'ROOT_complete_controls_disposition':CONTROL,'family_admission_schema':literal('ADMISSION_SCHEMA'),'registry_fields':12,'primitive_source_body_count':0,'schema_universally_validated':False}
contract['narrow_repairs']='Cold family gate/19raw7consumer21leaf and split c8 reader/final checker; exact source guards/variant ledger. No DFS/observer/point/search/scheduler/fallback/rollback code changes.'
contract['verification_scope']='SOURCE only; current controls pass is a distinct ROOT prerequisite, not scientific library admission. No Source functions/tests/science called by author.'
CP=write('leaf-source-contract-v1.json',contract)
# Owner transport/lifecycle bodies remain intact; only metadata admission/receipt checks extend.
O=OO.read_text();O=top(O,'WORKER',WP);O=top(O,'WORKER_CONTRACT',CP);O=top(O,'HELPER',S['final_certificate']);O=top(O,'EXPECTED_SOURCES',MAP);O=top(O,'SOURCE_AUTHOR',AUTHOR);O=top(O,'LEAF_SOURCE_AUTHOR',AUTHOR)
O=rep(O,'\n\ndef source_person_review(',constants+'\n'+shared+'\n\ndef source_person_review(')
O=rep(O,"else '/root/hilbert_ordering_diagnosis')", "else (SOURCE_AUTHOR if scope == 'final-primitive-advice-pair-certificate-helper'\n                   else '/root/hilbert_ordering_diagnosis'))")
O=rep(O,"contract['schema']=='fresh-equality-first-proof-leaf-source-contract-v1'", "contract['schema']=='I2-finite-family-first-proof-leaf-source-contract-v1'")
O=rep(O,"abi['worker_plan_field_count']==20", "abi['worker_plan_field_count']==21")
O=rep(O,"new20-field observer-bound plan/unchanged11-field", "new21-field family/observer-bound plan/unchanged11-field")
O=rep(O,"    same(leaf['sources'],EXPECTED_SOURCES", "    controls=read(ROOT_COMPLETE_FAMILY_CONTROLS)\n    need(controls['schema']=='ROOT-current-two-I2-family-controls-disposition-v1'\n         and controls['ROOT_complete_scoped_controls_accepted'] is True, 'actual complete scoped controls prerequisite')\n    verify_tree(controls,observed)\n    if leaf['family_registry_binding'] is not None:\n        scientific_family_admission(leaf,read(leaf['family_registry_binding']['library_admission']))\n    scientific_variant(leaf)\n    same(leaf['sources'],EXPECTED_SOURCES")
O=rep(O,"'consumer_binding_sha256':digest(leaf['consumer_binding']),'no_supplied_proof_route':True,", "'consumer_binding_sha256':digest(leaf['consumer_binding']),\n        'family_registry_binding_sha256':digest(leaf['family_registry_binding']),'no_supplied_proof_route':True,")
O=rep(O,"    for value in (EXPECTED_SOURCES,STATIC_SOURCES,WORKER_CONTRACT,leaf['source_review'],leaf['helper_review']):", "    for value in (EXPECTED_SOURCES,STATIC_SOURCES,WORKER_CONTRACT,ROOT_COMPLETE_FAMILY_CONTROLS,leaf['family_registry_binding'],leaf['source_review'],leaf['helper_review']):")
O=rep(O,"    allowed={record['path']:record for record in leaf['sources'].values()}", "    need(r['advice_variant']==scientific_variant(leaf)\n         and r['family_registry_binding']==leaf['family_registry_binding']\n         and r['family_registry_binding_sha256']==digest(leaf['family_registry_binding'])\n         and r['ROOT_complete_controls_disposition']==ROOT_COMPLETE_FAMILY_CONTROLS, 'actual declared scientific variant/current registry/control authority')\n    validate_execution_ledger(leaf,r['executed_project_source_ledger'])\n    allowed={record['path']:record for record in leaf['sources'].values()}")
compile(O,str(D/'I2_finite_family_first_proof_owner_v1.py'),'exec');OP=write('I2_finite_family_first_proof_owner_v1.py',O)
T=OT.read_text();T=top(T,'WORKER',WP);T=top(T,'WORKER_CONTRACT',CP);T=top(T,'HELPER',S['final_certificate']);T=top(T,'EXPECTED_SOURCES',MAP);T=top(T,'OWNER',OP)
T=rep(T,'\n\ndef reconcile(',constants+'\n'+shared+'\n\ndef reconcile(')
T=rep(T,"    outer=read(p['outer_terminal_contract']);platform=read(p['platform_review'])", "    controls=read(ROOT_COMPLETE_FAMILY_CONTROLS)\n    need(controls['schema']=='ROOT-current-two-I2-family-controls-disposition-v1'\n         and controls['ROOT_complete_scoped_controls_accepted'] is True, 'actual complete control prerequisite')\n    variant=scientific_variant(leaf)\n    if leaf['family_registry_binding'] is not None:\n        scientific_family_admission(leaf,read(leaf['family_registry_binding']['library_admission']))\n    outer=read(p['outer_terminal_contract']);platform=read(p['platform_review'])")
T=rep(T,"    allowed={record['path']:record for record in leaf['sources'].values()}", "    need(w['advice_variant']==variant and w['family_registry_binding']==leaf['family_registry_binding']\n         and w['family_registry_binding_sha256']==digest(leaf['family_registry_binding'])\n         and w['ROOT_complete_controls_disposition']==ROOT_COMPLETE_FAMILY_CONTROLS, 'exact returned scientific family/ordinary/canonical scope')\n    validate_execution_ledger(leaf,w['executed_project_source_ledger'])\n    allowed={record['path']:record for record in leaf['sources'].values()}")
T=rep(T,"        'scope':'Conditional single owned", "        'advice_variant':variant,'family_registry_binding_sha256':digest(leaf['family_registry_binding']),\n        'ROOT_complete_controls_disposition':ROOT_COMPLETE_FAMILY_CONTROLS,\n        'scope':'Conditional single owned")
compile(T,str(D/'I2_finite_family_first_proof_terminal_v1.py'),'exec');TP=write('I2_finite_family_first_proof_terminal_v1.py',T)
for label,old,new in [('worker',OW,Path(WP['path'])),('owner',OO,Path(OP['path'])),('terminal',OT,Path(TP['path']))]:
 write(label+'-source-delta-v1.patch',''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),new.read_text().splitlines(keepends=True),fromfile=str(old),tofile=str(new))))
print(json.dumps({'worker':WP,'contract':CP,'owner':OP,'terminal':TP},indent=2))
