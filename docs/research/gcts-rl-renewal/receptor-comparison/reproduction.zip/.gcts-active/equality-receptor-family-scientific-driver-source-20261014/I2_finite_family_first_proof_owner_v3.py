"""SOURCE ONLY cold one-shot owner/preflight for a declared advice-pair leaf.

Adapted from the explicit-observer-wait4 ROOT owner. No project import, proof
search, model, certificate verification or plan generation occurs here. ROOT
must separately freeze/review a real plan and capture its actual tool terminal.
This source's author has never imported/invoked its process or resource APIs.
"""
import time
ENTRY = time.perf_counter()
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import signal
import stat
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
VERSION = 'ROOT-compact-fresh-equality-first-proof-owner-plan-v1'
TERMINAL = 'ROOT-compact-fresh-equality-first-proof-owner-terminal-v1'
LIMITS = {'whole_seconds':180,'supervisor_seconds':175,'child_seconds':170,'peak_bytes':536870912}
SEARCH = {'attempts':128,'seconds':20,'event_ceiling':2000}
RESERVE = 33554432
WRITE_SECONDS = 2
FRAME = struct.Struct('!8sBBHQQddd')
MAX_SMALL = 1048576
MAX_OBSERVERS = 10000
MAX_SAMPLES = 10000
CANCELLED = [False]
# Metadata-only freezer fills these immutable source/person-review pins.
WORKER = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-scientific-driver-source-20261014/I2_finite_family_first_proof_worker_v3.py', 'sha256': 'ef647c46cc5fcbb7e18c9f4590076bb68cb858e9308db89ff6998be8873c318b', 'bytes': 81615}
WORKER_CONTRACT = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-scientific-driver-source-20261014/leaf-source-contract-v3.json', 'sha256': '8e75af501dd3327d84d097c7fcff06bf77822dfd575fc9a3891d2e1d6230a242', 'bytes': 26896}
# Fresh worker review is authenticated from the future ROOT-frozen leaf plan.
HELPER = {'bytes': 70208, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/I2_family_final24_sequence_guard_binding_v4.py', 'sha256': '10a41171c18a82e6f33d13403aae9e441a69d7fd11f065ff5497aea415f0188f'}
EXPECTED_SOURCES = {'candidate_advice': {'bytes': 27264, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-incidence-priority-source-20261013/incidence_priority_witness_advice_v2.py', 'sha256': '3a86adba8982c406ae4a2ad3349b8ae962e52498dee38ee3ee26719b22468053'}, 'certificate': {'bytes': 64498, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-first-proof-helper-source-20261013/i2_context_and_final24_certificate_v1.py', 'sha256': 'c8fa4aeba82fcc2af9bd091fd351d72f86a24ae97cb5edd92ff558e81c23501b'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'dynamic_graph_adapter': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'dynamic_lifecycle_adapter': {'bytes': 29230, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-dynamic-source-20261012/compact_cluster_lifecycle_v2.py', 'sha256': '677c48c7aebfecf0c83c8daa8bf8e873d0be1e415906afa6687f0b9652e33719'}, 'family_advice': {'bytes': 62803, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/equality_receptor_family_I2_sequence_guard_v3.py', 'sha256': 'b4d20eaf6c7f5db25e7ab7a70303e7d39a733b49c2cec300b363cbc3f7fbfaa5'}, 'features31': {'bytes': 12386, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-rl-small-source-20261012/family_graph_features_v1.py', 'sha256': '644e4cd195f98c1ca3f97c3fcba84dfdbc18765454512435702951cc6169a14b'}, 'final_certificate': {'bytes': 70208, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/I2_family_final24_sequence_guard_binding_v4.py', 'sha256': '10a41171c18a82e6f33d13403aae9e441a69d7fd11f065ff5497aea415f0188f'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'policy_math': {'bytes': 11607, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-learning-20261012/family_policy_math_v2.py', 'sha256': '61b772b45ed4523ba4c14ae4519cd9dae53c21d4dc1b1681689011707831c294'}, 'proof_observer': {'bytes': 29717, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-observer-controls-source-20261013/first_checked_proof_observer_i2_v1.py', 'sha256': 'ad2efd1b7685fe6f7baa8f3b9849baf3568c3cf67e87a85e3d0ac657d8772cdc'}, 'streamed_dfs': {'bytes': 49263, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/compact_I2_family_first_checked_proof_dfs_v12.py', 'sha256': '57e415f9822f73dcbec2f16f45564196de519476ab2b0f3fbb9097fc972d8859'}, 'streamed_overlay': {'bytes': 18348, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/I2_family_consumer_overlay_v2.py', 'sha256': 'df05db866111b8e5c86ddffb9c9a0216678d6e171c7b5f1bdde866573f87ab4b'}, 'streamed_proposal': {'bytes': 25358, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-streamed-consumers-source-20261012/compact_cluster_proposal_v2.py', 'sha256': '1d094e7f51c7607cc121a48e0bc55f4daf2cc7801701eea34a2bb552f1505b38'}, 'transport': {'bytes': 13756, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/curriculum-compact-wrapper-source-20261012/compact_static_transport_v1.py', 'sha256': '65a0b598966ae4dffdda1b770eb2d4d5b64af1bcaf6aead4281a224a4123def3'}, 'worker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-scientific-driver-source-20261014/I2_finite_family_first_proof_worker_v3.py', 'sha256': 'ef647c46cc5fcbb7e18c9f4590076bb68cb858e9308db89ff6998be8873c318b', 'bytes': 81615}}
STATIC_SOURCES = {'audit': {'catalog_audit': {'bytes': 15171, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-independent-source-20261012/independent_compact_catalog_audit_v1.py', 'sha256': 'db4dc3b904715be3123ed1a9b22eb1ce9144c35aa00c610da94f13263e4334e8'}, 'domains': {'bytes': 7441, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-independent-source-20261012/independent_compact_domains_v1.py', 'sha256': '1b9d6b94c78f363ba20f48234dc1eb48ac9dcfa548e8f0fa1a7350699b059b34'}, 'grammar': {'bytes': 14885, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/hilbert_i2_grammar_v1.py', 'sha256': '3d93bf6f1a970912d4a9b28433f761e91d6d91aeb08e1cc597bae28144139415'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'worker': {'bytes': 47882, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/hilbert_i2_audit_worker_v1.py', 'sha256': 'ac3d460603ae0eea3113d80c5bb63ad1dfc5bdb71ca88727fc69357a4900b2e5'}}, 'producer': {'compact_engine': {'bytes': 20787, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-engine-source-20261012/compact_point_graph_v1.py', 'sha256': 'd638f7152ec7fa8293adbd8915b79de60f95d0756952bdc6bf0e40b15f549ca0'}, 'compiler': {'bytes': 46195, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/hilbert_i2_compiler_v1.py', 'sha256': 'b6a423ab2412af99842894ac8788d167a764987a897f0ca2e974d244d6f21ced'}, 'decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'worker': {'bytes': 31822, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/hilbert_i2_prepare_worker_v1.py', 'sha256': 'b8a75aa41c786ec1003ef8d0f44a3d3b489dd4ce844b7cddfe6eaa0bb85e6336'}}}
RECIPIENT_IDS = ('fresh-i2-CD-vw-direct', 'fresh-i2-CD-vw-incidence-transport')
DECLARATION_PROFILE = 'hilbert-fresh-guarded-I2-cohort-static-v1'
SOURCE_AUTHOR = '/root/hilbert_advice_controls'
LEAF_SOURCE_AUTHOR = '/root/hilbert_advice_controls'


def need(value, label):
    if not value:
        raise ValueError(label)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def same(a,b,label):
    need(canonical(a)==canonical(b),label)


def fields(pairs):
    result={}
    for key,value in pairs:
        need(key not in result,'duplicate JSON field'); result[key]=value
    return result


def parse(raw):
    return json.loads(raw,object_pairs_hook=fields,
        parse_constant=lambda name:(_ for _ in ()).throw(ValueError('nonfinite JSON '+name)))


def path_for(name):
    need(type(name) is str and str(Path(name))==name and '..' not in Path(name).parts,'exact lexical path')
    p=Path(name);return p if p.is_absolute() else ROOT/p


def pin(path,declared=None):
    path=Path(path);h=hashlib.sha256();count=0
    identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    with path.open('rb') as stream:
        before=os.fstat(stream.fileno());need(stat.S_ISREG(before.st_mode),'regular immutable artifact')
        for block in iter(lambda:stream.read(65536),b''):h.update(block);count+=len(block)
        after=os.fstat(stream.fileno())
    need(identity(before)==identity(after)==identity(path.stat()) and count==after.st_size,'same closed whole bytes')
    return {'path':str(path) if declared is None else declared,'sha256':h.hexdigest(),'bytes':count}


def verify(record):
    need(type(record) is dict and set(record)=={'path','sha256','bytes'}
         and type(record['bytes']) is int and record['bytes']>=0
         and type(record['sha256']) is str and len(record['sha256'])==64
         and all(c in '0123456789abcdef' for c in record['sha256']),'strict raw pin')
    p=path_for(record['path']);same(pin(p,record['path']),record,'whole raw pin changed');return p


def read(record):
    p=verify(record);need(record['bytes']<=MAX_SMALL,'bounded metadata-only owner input')
    with p.open('rb') as stream:raw=stream.read(MAX_SMALL+1)
    need(len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256'],'parse same authenticated bytes')
    value=parse(raw);verify(record);return value


def verify_tree(value, observed):
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:
            verify(value)
            if value['path'] in observed:same(value,observed[value['path']],'same repeated lexical closure')
            observed[value['path']]=value
        else:
            for child in value.values():verify_tree(child,observed)
    elif type(value) is list:
        for child in value:verify_tree(child,observed)


def save(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
        stream.write('\n')
    return pin(path)


def raw_usage(usage):
    return {name:getattr(usage,name) for name in dir(usage) if name.startswith('ru_')}


def peak(usage):
    # Actual units require the fresh ROOT platform review; not cross-platform
    # guessing. Darwin ru_maxrss is raw bytes under that conditional scope.
    need(sys.platform=='darwin' and type(usage.ru_maxrss) in (int,float)
         and math.isfinite(usage.ru_maxrss) and usage.ru_maxrss>=0,'finite Darwin kernel peak')
    return int(usage.ru_maxrss)


def flag(signum,frame):
    CANCELLED[0]=True


def read_worker_frame(path,pid,exit_code,child_seconds,worker_kernel_peak):
    need(math.isfinite(child_seconds) and 0<=child_seconds<=LIMITS['child_seconds'],
         'full cold child170 Popen-to-wait4 including startup/import/exit/reap')
    with Path(path).open('rb') as stream:raw=stream.read(FRAME.size+1)
    need(len(raw)==52==FRAME.size,'only exact closed52 role1 worker frame; no JSON stdout')
    magic,role,code,reserved,emitter,rss,elapsed,start,closed=FRAME.unpack(raw)
    need(magic==b'GCTSCMP1' and role==1 and code==exit_code==0 and reserved==0 and emitter==pid,
         'exact terminal frame identity/exit/role')
    need(all(math.isfinite(x) and x>=0 for x in (elapsed,start,closed)) and closed>=start
         and abs((closed-start)-elapsed)<=0.000001 and elapsed<=child_seconds+0.000001
         and rss<=worker_kernel_peak,'emitter-local subtraction/duration nesting, never shared absolute origins')
    return {'role':role,'exit_code':code,'pid':emitter,'SELF_ru_maxrss_raw':rss,
        'elapsed_seconds':elapsed,'entry_monotone_clock':start,'last_closed_monotone_clock':closed,
        'terminal_frame':pin(path),'clock_scope':'process_local_no_cross_process_absolute_comparison'}

ROOT_COMPLETE_FAMILY_CONTROLS = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-controls-progress-v2-20261014/ROOT-actual-family-controls-disposition-v1.json', 'sha256': '687b59a54a7b10bdfe213b96e66ee18c3ab1d6586c12490b5fceab9227975846', 'bytes': 20667}
ACTUAL_FAMILY_INPUTS = {'candidate_library': {'bytes': 85344, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/worker-output-v1/candidate-library-v1.json', 'sha256': '08e75860545d3e0248e99c36858b0ca25d1bcbb1c7ad01b3cd2d332d51149e07'}, 'independent_audit': {'bytes': 41490, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/worker-output-v1/independent-all-origin-audit-v1.json', 'sha256': '55a9e8c2a4df287da9dbc2c72c42c4b13de520e6eafb02bd61124919b5ee22be'}, 'ROOT_extraction_disposition': {'bytes': 7879, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/ROOT-actual-family-extraction-disposition-v1.json', 'sha256': '757606d7a20048e5a8335559c96cf1749e1ab53f900bdff593fb10beeed8a173'}}
FAMILY_TRAINING = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-implementation-source-20261013/training-inputs-v1.json', 'sha256': 'de34653e96673e080c65a6c17fad3cc24cfb00ab0043fdc11c9741e6708f382c', 'bytes': 8340}
FAMILY_DONORS = {'reader': {'bytes': 64540, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/fresh_equality_context_and_final24_certificate_v3.py', 'sha256': '5d03d088c2d1b7f90e98fb7e28819ab0643b74f6786953c6107d4d2535c2377b'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'dynamic_graph': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}}
FAMILY_UPSTREAM = {'reader': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-first-proof-helper-source-20261013/i2_context_and_final24_certificate_v1.py', 'sha256': 'c8fa4aeba82fcc2af9bd091fd351d72f86a24ae97cb5edd92ff558e81c23501b', 'bytes': 64498}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'dynamic_graph': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}}
FAMILY_ADMISSION_SCHEMA = 'ROOT-finite-Incident-transport-I2-recipient-advice-admission-v2'
FAMILY_REGISTRY_SCHEMA = 'ROOT-I2-finite-Incident-advice-registry-binding-v1'
SCIENTIFIC_PURPOSE = 'scientific-primitive-ordering-only'
ROOT_SIX_LANE_PREREGISTRATION = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-six-lane-ROOT-source-20261014/ROOT-six-lane-preregistration-v1.json', 'sha256': 'cabd16d28e9a51e9899f5e44c244b283f90334b7478fae5df47bec0c6f8902ee', 'bytes': 4623}
SCIENTIFIC_ADMISSION_FIELDS = ('ROOT_advice_library_accepted', 'ROOT_complete_controls_disposition', 'ROOT_extraction_disposition', 'ROOT_library_admitted', 'ROOT_six_lane_preregistration', 'advice_only', 'donor_sources', 'extraction_audit', 'implementation', 'library', 'primitive_source_body_count', 'purpose', 'recipient_qualification', 'registry_preimage_sha256', 'schema', 'schema_universally_validated', 'scientific_episode_activation', 'scope', 'theory_sha256', 'training_spec', 'upstream_sources')


def scientific_variant(leaf):
    registry = leaf['family_registry_binding']
    need(leaf['mode'] in ('base','seed_forward'), 'only declared deterministic modes')
    if registry is None:
        return 'canonical' if leaf['mode'] == 'base' else 'ordinary-incidence-ordering'
    need(leaf['mode'] == 'seed_forward' and type(registry) is dict,
         'family registry only in explicit finite family lane')
    return 'finite-Incident-family-ordering'


def scientific_family_admission(leaf, admission, header):
    """Pure metadata scope gate; no candidate pool, checker or graph construction."""
    registry = leaf['family_registry_binding']
    fields = {'schema','instance_id','recipient_qualification','family_implementation',
        'library_source','training_spec','extraction_audit','model_binding',
        'consumed_source_epoch','primitive_source_body_count','advice_registry_epoch','library_admission'}
    need(type(registry) is dict and set(registry) == fields
         and registry['schema'] == FAMILY_REGISTRY_SCHEMA
         and registry['instance_id'] == leaf['selector']
         and registry['recipient_qualification'] == leaf['qualification']
         and registry['family_implementation'] == leaf['sources']['family_advice']
         and registry['library_source'] == ACTUAL_FAMILY_INPUTS['candidate_library']
         and registry['extraction_audit'] == ACTUAL_FAMILY_INPUTS['independent_audit']
         and registry['training_spec'] == FAMILY_TRAINING
         and type(registry['primitive_source_body_count']) is int
         and registry['primitive_source_body_count'] == 0,
         'exact current finite family registry; no injected bodies or donor target')
    epoch = digest({k:v for k,v in registry.items() if k not in ('library_admission','advice_registry_epoch')})
    need(registry['advice_registry_epoch'] == epoch, 'acyclic exact current registry preimage')
    need(type(admission) is dict and set(admission) == set(SCIENTIFIC_ADMISSION_FIELDS)
         and admission.get('schema') == FAMILY_ADMISSION_SCHEMA
         and admission.get('scientific_episode_activation') is True
         and admission.get('purpose') == SCIENTIFIC_PURPOSE
         and admission.get('scope') == SCIENTIFIC_PURPOSE
         and admission.get('ROOT_library_admitted') is False
         and admission.get('ROOT_six_lane_preregistration') == ROOT_SIX_LANE_PREREGISTRATION
         and admission.get('theory_sha256') == digest(header['context']['theory'])
         and 'controls_scope' not in admission and 'ROOT_controls_authorized' not in admission
         and admission.get('ROOT_complete_controls_disposition') == ROOT_COMPLETE_FAMILY_CONTROLS
         and admission.get('ROOT_extraction_disposition') == ACTUAL_FAMILY_INPUTS['ROOT_extraction_disposition']
         and admission.get('ROOT_advice_library_accepted') is True
         and admission.get('advice_only') is True
         and admission.get('schema_universally_validated') is False
         and type(admission.get('primitive_source_body_count')) is int
         and admission['primitive_source_body_count'] == 0
         and admission.get('registry_preimage_sha256') == epoch
         and admission.get('library') == registry['library_source']
         and admission.get('implementation') == registry['family_implementation']
         and admission.get('recipient_qualification') == registry['recipient_qualification']
         and admission.get('training_spec') == FAMILY_TRAINING
         and admission.get('extraction_audit') == registry['extraction_audit']
         and admission.get('donor_sources') == FAMILY_DONORS
         and admission.get('upstream_sources') == FAMILY_UPSTREAM,
         'separate ROOT scientific-purpose advice admission; controls-only/extraction-only rejected before code loading')


def validate_execution_ledger(leaf, ledger):
    """Exact per-variant executed raw roles; baseline never executes family."""
    need(type(ledger) is list, 'whole executed-source ledger')
    expected = {p['path']:p for role,p in leaf['sources'].items()
                if role != 'master' and (role != 'family_advice' or leaf['family_registry_binding'] is not None)}
    observed = {}
    for item in ledger:
        need(type(item) is dict and set(item) == {'module_name','source_pin'}
             and type(item['module_name']) is str and item['module_name']
             and type(item['source_pin']) is dict, 'exact executed source row')
        p = item['source_pin']
        need(expected.get(p.get('path')) == p, 'no undeclared or deferred family execution')
        observed[p['path']] = p
    same(observed, expected, 'every required per-variant module actually executed; no family execution in BASE/ordinary')


def source_person_review(record, source, scope, observed):
    """Future distinct-person SOURCE review, no author status or actual authority."""
    current = read(record)
    need(current['schema'] == 'ROOT-person-independent-primitive-source-review-v1'
         and current['scope'] == scope and current['source_only'] is True
         and current['source_ready'] is True and current['all_checks_passed'] is True
         and type(current['scientific_calls']) is int and current['scientific_calls'] == 0
         and current['scientific_acceptance'] is False
         and current['author_identity'] == (LEAF_SOURCE_AUTHOR if scope == 'primitive-advice-pair-worker'
             else (SOURCE_AUTHOR if scope == 'final-primitive-advice-pair-certificate-helper'
                   else '/root/hilbert_ordering_diagnosis'))
         and type(current['reviewer_identity']) is str and current['reviewer_identity']
         and current['reviewer_identity'] != current['author_identity'],
         'exact fresh distinct-person Hilbert worker/helper SOURCE review')
    same(current['source'], source, 'whole current reviewed source identity')
    verify_tree(current, observed)
    return current


def preflight(plan_path):
    pp=pin(plan_path);p=read(pp)
    required={'schema','status','selector','mode','phase','owner_source','owner_review','worker_plan',
        'worker_activation','qualified_context','outer_terminal_contract','platform_review','runtime',
        'limits','search_limits','reserve_bytes','closure','owner_output_directory'}
    need(type(p) is dict and set(p)==required and p['schema']==VERSION
         and p['status']=='frozen_once_only_pending_ROOT_owned_invocation'
         and type(p['selector']) is str and p['selector'] in RECIPIENT_IDS
         and p['mode'] in ('base', 'seed_forward') and p['phase']=='primitive-discovery',
         'one exact fresh two-recipient deterministic pair leaf, no proof route field')
    same(p['limits'],LIMITS,'fixed whole/supervisor/leaf/cap');same(p['search_limits'],SEARCH,'same128/20/2000')
    need(p['reserve_bytes']==RESERVE,'same conditional prospective32MiB postlude reserve')
    need(verify(p['owner_source']).resolve()==Path(__file__).resolve(),'exact actual owner bytes')
    review=read(p['owner_review'])
    need(review['schema']=='ROOT-person-independent-primitive-owner-source-review-v1'
         and review['source_only'] is True and review['source_ready'] is True
         and review['all_checks_passed'] is True
         and type(review['scientific_calls']) is int and review['scientific_calls']==0
         and review['scientific_acceptance'] is False and review['author_identity']==SOURCE_AUTHOR
         and type(review['reviewer_identity']) is str and review['reviewer_identity']
         and review['author_identity']!=review['reviewer_identity'],
         'fresh distinct-person owner source review required')
    same(review['owner'],p['owner_source'],'same reviewed owner')
    need(type(p['closure']) is list and p['closure']
         and len({x['path'] for x in p['closure']})==len(p['closure']),'complete distinct lexical raw closure')
    observed={};verify_tree(p,observed);verify_tree(review,observed)
    leaf=read(p['worker_plan']);activation=read(p['worker_activation']);q=read(p['qualified_context'])
    contract=read(WORKER_CONTRACT); abi=contract['prospective_ABIs']
    need(contract['schema']=='I2-finite-family-first-proof-leaf-source-contract-v1'
         and contract['source_only'] is True and contract['scientific_acceptance'] is False
         and contract['scientific_calls']==0 and contract['execution_authorized'] is False,
         'exact new SOURCE contract ABI, no drop-in old arithmetic contract')
    same(contract['sources'], {'worker':WORKER,'certificate':HELPER,'proof_observer':EXPECTED_SOURCES['proof_observer'],
         'streamed_overlay':EXPECTED_SOURCES['streamed_overlay']}, 'full new worker/helper source pair')
    same(contract['recipient_ids'], list(RECIPIENT_IDS), 'exact two literal fresh geometry selectors')
    need(abi['worker_plan_field_count']==21 and abi['qualification_field_count']==11
         and abi['qualification_profile']==DECLARATION_PROFILE
         and abi['no_added_prior_candidate_or_trajectory_field'] is True, 'new21-field family/observer-bound plan/unchanged11-field static context ABI')
    need(set(leaf)==set(abi['worker_plan_exact_fields']) and leaf['schema']==abi['worker_plan_schema']
         and leaf['selector']==p['selector'] and leaf['phase']==p['phase'] and leaf['mode']==p['mode']
         and leaf['ROOT_owned_once_only'] is True,'new reviewed leaf grammar, not old geometry preflight')
    preregistration=read(ROOT_SIX_LANE_PREREGISTRATION)
    need(preregistration['schema']=='ROOT-I2-finite-family-six-lane-endpoint-preregistration-v1'
         and preregistration['controls_prerequisite']==ROOT_COMPLETE_FAMILY_CONTROLS
         and preregistration['search_limits']==SEARCH and preregistration['cold_limits']==LIMITS, 'same exact preregistered six-lane endpoint')
    verify_tree(preregistration,observed)
    controls=read(ROOT_COMPLETE_FAMILY_CONTROLS)
    need(controls['schema']=='ROOT-current-two-I2-family-controls-disposition-v1'
         and controls['ROOT_complete_scoped_controls_accepted'] is True, 'actual complete scoped controls prerequisite')
    verify_tree(controls,observed)
    if leaf['family_registry_binding'] is not None:
        scientific_family_admission(leaf,read(leaf['family_registry_binding']['library_admission']),read(q['catalog']))
    scientific_variant(leaf)
    same(leaf['sources'],EXPECTED_SOURCES,'all full exact Hilbert worker/runtime/helper sources')
    same(leaf['sources']['worker'],WORKER,'exact reviewed standalone pair leaf')
    source_person_review(leaf['source_review'], WORKER, 'primitive-advice-pair-worker', observed)
    source_person_review(leaf['helper_review'], HELPER, 'final-primitive-advice-pair-certificate-helper', observed)
    source_person_review(leaf['observer_review'], EXPECTED_SOURCES['proof_observer'], 'first-checked-proof-observer', observed)
    same(leaf['qualification'],p['qualified_context'],'same full ROOT admitted original context')
    same(leaf['owned_limits'],LIMITS,'same cold limits');same(leaf['search_limits'],SEARCH,'same discovery bounds')
    same(leaf['runtime'],p['runtime'],'same owner/leaf lexical runtime/extension/observer scope')
    rc=leaf['resource_contract']
    same(rc['owner_source'],p['owner_source'],'exact new owner pin in leaf contract')
    same(rc['outer_terminal_contract'],p['outer_terminal_contract'],'same future external terminal contract')
    same(rc['platform_review'],p['platform_review'],'fresh owner/leaf whole topology platform review')
    need(rc['postlude_reserve_bytes']==RESERVE and rc['caller_limit_seconds']==180,'same resource/postlude scope')
    same(activation,{'schema':abi['activation_schema'],'authorized':True,'plan':p['worker_plan'],
        'qualification':leaf['qualification'],'source_review':leaf['source_review'],'helper_review':leaf['helper_review'],'observer_review':leaf['observer_review'],
        'selector':p['selector'],'mode':p['mode'],'phase':'primitive-discovery','owned_limits':LIMITS,'search_limits':SEARCH,
        'expected_inventory_binding_sha256':digest(leaf['expected_inventory_binding']),
        'consumer_binding_sha256':digest(leaf['consumer_binding']),
        'family_registry_binding_sha256':digest(leaf['family_registry_binding']),'no_supplied_proof_route':True,
        'new_training':False,'all_five_qualification':False},'separate exact actual ROOT worker activation')
    need(type(q) is dict and set(q)==set(abi['qualification_exact_fields'])
         and q['schema']==abi['qualification_schema'] and q['instance_id']==p['selector']
         and q['declaration_profile']==DECLARATION_PROFILE
         and q['status']=='accepted_complete_catalog_and_initial_point_model'
         and q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True,
         'exact current ROOT-admitted complete selected Hilbert static context')
    same(q['declaration_inputs'], {'fixture':contract['exact_fixture']}, 'whole exact literal Hilbert fixture')
    same(q['sources'], STATIC_SOURCES, 'full exact producer and independent Hilbert static source roles')
    # Current actual selected artifacts are authenticated through q and the
    # entire raw closure. No arithmetic historical static_reference or new
    # author-generated census/model/acceptance is supplied. Leaf repeats the
    # complete actual ROOT14/static/license/point checks before its first search.
    # The leaf independently validates the full gzip evidence/licenses/epochs
    # before scientific imports. Owner verifies raw closure only, never runs a
    # proof/checker or decodes a catalog/license to establish new authority.
    for value in (leaf,activation,q,contract):verify_tree(value,observed)
    for value in (EXPECTED_SOURCES,STATIC_SOURCES,WORKER_CONTRACT,ROOT_COMPLETE_FAMILY_CONTROLS,leaf['family_registry_binding'],leaf['source_review'],leaf['helper_review']):verify_tree(value,observed)
    runtime=p['runtime']
    need(runtime['platform']==sys.platform=='darwin' and runtime['python_version']==list(sys.version_info[:3])==[3,9,6]
         and runtime['executable']=='/Library/Developer/CommandLineTools/usr/bin/python3'
         and runtime['observer']['path']=='/bin/ps','fixed actual platform/runtime/observer source scope')
    need(verify(runtime['binary']).resolve()==Path(sys.executable).resolve()==Path(runtime['executable']).resolve(),
         'same exact lexical runtime bytes')
    import _posixsubprocess
    for name,module in (('resource_extension',resource),('posixsubprocess_extension',_posixsubprocess)):
        need(verify(runtime[name]).resolve()==Path(module.__file__).resolve(),'exact stdlib native extension')
    need('sitecustomize' not in sys.modules and 'usercustomize' not in sys.modules,'no unreviewed interpreter customization')
    platform=read(p['platform_review']);outer=read(p['outer_terminal_contract'])
    need(platform['schema']=='ROOT-primitive-discovery-known-topology-platform-review-v1'
         and platform['source_only'] is True and platform['known_leaf_scope_reviewed'] is True
         and platform['closed52_postlude_scope_reviewed'] is True
         and platform['reserve_is_prospective_conditional'] is True
         and platform['units_verified'] is True and platform['wait4_leaf_scope_verified'] is True
         and platform['observer_leaf_scope_verified'] is True and platform['source_trusted_owned_filter'] is True
         and platform['owner_postlude_scope_reviewed'] is True
         and platform['postlude_reserve_bytes']==RESERVE,'exact fresh conditional platform scope, not OS hard cap')
    same(platform['worker'],WORKER,'same exact leaf native/no-child scope')
    need(outer['schema']=='ROOT-primitive-discovery-prospective-terminal-contract-v1'
         and outer['once_only'] is True and outer['selector']==p['selector']
         and outer['mode']==p['mode'] and outer['cold_inclusive'] is True and outer['caller_limit_seconds']==180,
         'reviewed actual enclosing tool-clock/terminal prerequisite')
    same(outer['owned_limits'],LIMITS,'same outer full owned budget');same(outer['worker'],WORKER,'same terminal leaf')
    same(outer['owner_source'],p['owner_source'],'same terminal owner')
    same(review['record_adapter'],outer['record_adapter'],'same independently reviewed saved-terminal adapter')
    same(platform['owner'],p['owner_source'],'same fresh whole-owner platform scope')
    same(platform['runtime'],runtime,'same exact platform/runtime/native/observer records')
    verify_tree(platform,observed);verify_tree(outer,observed)
    closure={x['path']:x for x in p['closure']}
    for name,record in observed.items():
        need(name in closure,'owner source/input/receipt/review raw closure incomplete');same(closure[name],record,'exact complete closure alias')
    directory=Path(p['owner_output_directory']);output=Path(leaf['output_directory'])
    for d in (directory,output):
        need(d.is_absolute() and d==d.resolve() and ROOT in d.parents and not d.exists(),
             'exclusive absent owner/leaf namespace, no outcome retry')
    need(directory!=output and directory not in output.parents and output not in directory.parents,
         'separate task-owned owner metadata and leaf artifacts')
    argv=[runtime['executable'],'-B',WORKER['path'],str(verify(p['worker_plan'])),str(verify(p['worker_activation']))]
    need(outer['literal_worker_argv']==argv,'prospective exact literal cold worker command')
    return p,pp,leaf,argv


def observe(records):
    """One trusted leaf /bin/ps; every invocation directly wait4-reaped."""
    need(len(records)<MAX_OBSERVERS,'observer record ceiling, never accepted prefix')
    began=time.perf_counter();child=None;usage=None;status=None;timed_out=False
    with tempfile.TemporaryFile(mode='w+b') as out,tempfile.TemporaryFile(mode='w+b') as err:
        try:
            child=subprocess.Popen(['/bin/ps','-axo','pid=,ppid=,pgid=,rss=,lstart='],
                stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
            while usage is None:
                pid,status,current=os.wait4(child.pid,os.WNOHANG)
                if pid:usage=current;child.returncode=os.waitstatus_to_exitcode(status);break
                if time.perf_counter()-began>=2:timed_out=True;break
                time.sleep(.01)
        finally:
            if child is not None and usage is None:
                try:os.kill(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                _,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
            if child is not None and usage is not None:
                records.append({'index':len(records),'pid':child.pid,'returncode':child.returncode,
                    'terminal_and_reaped':True,'timed_out':timed_out,'elapsed_seconds':time.perf_counter()-began,
                    'wait4_raw':raw_usage(usage),'kernel_peak_bytes':peak(usage)})
        need(not timed_out and child is not None and child.returncode==0,'observer terminal/reaped successful')
        need(out.tell()<=4*1024*1024 and err.tell()<=4*1024*1024,'bounded exact observer text')
        out.seek(0);raw=out.read();text=raw.decode('utf8')
        records[-1]['raw_stdout_sha256']=hashlib.sha256(raw).hexdigest()
        records[-1]['raw_stdout_bytes']=len(raw)
    rows={}
    for line in text.splitlines():
        parts=line.split()
        if not parts:continue
        need(len(parts)==9,'full observer row grammar')
        pid,ppid,pgid,rss=map(int,parts[:4])
        need(pid>0 and ppid>=0 and pgid>=0 and rss>=0 and pid not in rows,'typed unique observer process rows')
        rows[pid]={'ppid':ppid,'pgid':pgid,'rss_bytes':rss*1024,'birth':' '.join(parts[4:])}
    return rows


def collect(rows,leader,owned,leader_live=False):
    identities={pid:birth for pid,birth in owned.items() if pid in rows and rows[pid]['birth']==birth}
    if leader_live and leader in rows:identities[leader]=rows[leader]['birth']
    allow_group=leader_live or any(rows[pid]['pgid']==leader for pid in identities)
    while True:
        new={pid:row['birth'] for pid,row in rows.items()
             if row['ppid'] in identities or (allow_group and row['pgid']==leader)}
        changed=any(pid not in identities for pid in new);identities.update(new)
        if not changed:owned.update(identities);return identities


def kill_owned(rows,leader,owned,sig,leader_live=False):
    active=collect(rows,leader,owned,leader_live)
    for pid,birth in active.items():
        if pid in rows and rows[pid]['birth']==birth:
            try:os.kill(pid,sig)
            except ProcessLookupError:pass


def receipt_gate(path,leaf,plan_pin,activation_pin,qualification_pin,child_pid,code,child_seconds,worker_peak,stdout):
    record=pin(path);r=read(record)
    contract=read(WORKER_CONTRACT)
    need(r['schema']==contract['prospective_ABIs']['receipt_schema']
         and r['status']=='complete_candidate_pending_ROOT_owned_resources'
         and r['stage']=='primitive-discovery' and r['stage_completed'] is True
         and r['selector']==leaf['selector'] and r['selector'] in RECIPIENT_IDS
         and r['mode']==leaf['mode'],'closed exact current Hilbert standalone leaf receipt')
    same(r['plan'],plan_pin,'exact leaf plan');same(r['activation'],activation_pin,'exact separate activation')
    same(r['qualification'],qualification_pin,'same admitted full catalog');same(r['worker'],WORKER,'same source')
    q=read(qualification_pin); header=read(q['catalog']); dimensions=header['dimensions']
    need(q['instance_id']==leaf['selector'] and q['declaration_profile']==DECLARATION_PROFILE
         and q['status']=='accepted_complete_catalog_and_initial_point_model'
         and q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True,
         'receipt same actually admitted Hilbert context')
    need(type(dimensions) is dict and set(dimensions)=={'logical_rows','formula_count',
         'primitive_license_count','non_assumption_witness_count','source_body_count'}
         and all(type(v) is int for v in dimensions.values())
         and dimensions['logical_rows']==24 and dimensions['formula_count']>0
         and dimensions['primitive_license_count']>=3
         and dimensions['non_assumption_witness_count']==dimensions['primitive_license_count']-3
         and dimensions['source_body_count']==0, 'actual complete current census, empty inventory')
    same(r['qualified_dimensions'],dimensions,'full actually admitted selected catalog census')
    same(r['complete_inventory_binding'],leaf['expected_inventory_binding'],'same empty complete inventory')
    same(r['consumer_binding'],leaf['consumer_binding'],'same full paired consumers')
    need(r['direct_children_peak_sum_bytes']==0 and type(r['direct_children_peak_sum_bytes']) is int
         and r['all_direct_children_terminal_and_reaped'] is True and r['RNG_draws']==0
         and r['new_RL_training'] is False and r['native_queries']==0 and r['atomic_macro_moves']==0
         and r['proof_bonus_awarded'] is False and r['training_updates']==0
         and r['full_resource_accepted'] is False and r['independent_full_trajectory_accepted'] is False
         and r['performance_comparison_accepted'] is False and r['all_five_qualification'] is False,
         'leaf cannot issue resource/trajectory/learning claims or hidden child scope')
    need(r['advice_variant']==scientific_variant(leaf)
         and r['family_registry_binding']==leaf['family_registry_binding']
         and r['family_registry_binding_sha256']==digest(leaf['family_registry_binding'])
         and r['ROOT_complete_controls_disposition']==ROOT_COMPLETE_FAMILY_CONTROLS, 'actual declared scientific variant/current registry/control authority')
    actual_registry=r['actual_family_registry_binding']
    need(type(r['family_registry_construction_completed']) is bool
         and r['family_registry_construction_completed'] is (actual_registry is not None), 'actual completed registry flag')
    if leaf['family_registry_binding'] is not None and actual_registry is None:
        need(r['search_status'].startswith('unknown_'), 'unfinished actual registry only in UNKNOWN')
    else:
        same(actual_registry,leaf['family_registry_binding'],'actual completed registry equals planned scientific lane')
    validate_execution_ledger(leaf,r['executed_project_source_ledger'])
    allowed={record['path']:record for record in leaf['sources'].values()}
    need(type(r['executed_project_source_ledger']) is list,'complete saved executable-source ledger')
    for origin in r['executed_project_source_ledger']:
        need(set(origin)=={'module_name','source_pin'} and type(origin['module_name']) is str
             and allowed.get(origin['source_pin']['path'])==origin['source_pin'],
             'only exact disclosed executable roles, including observer')
        verify(origin['source_pin'])
    root=Path(leaf['output_directory']);need(verify(r['result'])==root/'result-v1.json.gz','entire raw result hash, never decode giant tape')
    need(type(r['final_certificate_checked']) is bool and type(r['trace_complete']) is bool,'literal result flags')
    first_proof = r['search_status']=='first_checked_original_Gamma_target_proof'
    need(type(r['first_proof_checked']) is bool and r['first_proof_checked'] is first_proof,
         'separate saved logical endpoint flag')
    same(r['first_proof_source'],EXPECTED_SOURCES['proof_observer'],'same timed observer raw source')
    if first_proof:
        need(r['trace_complete'] is True and r['final_certificate_checked'] is False and r['certificate'] is None
             and r['first_proof_origin_kind'] in ('actual_selected','completed_source_proposal')
             and type(r['first_proof_certificate']) is dict,
             'checked original Gamma patch never masquerades as full24 certificate')
        need(verify(r['first_proof_certificate'])==root/'first-proof-certificate-v1.json'
             and not (root/'certificate-v1.json').exists(),'separate exact saved logical certificate')
    else:
        need(r['first_proof_certificate'] is None and r['first_proof_origin_kind'] is None
             and not (root/'first-proof-certificate-v1.json').exists(),
             'nonlogical terminal has no salvaged logical prefix')
        if r['search_status']=='finite_exact_point_tiling':
            need(r['trace_complete'] is True and r['final_certificate_checked'] is True and type(r['certificate']) is dict,
                 'positive fullboard result requires independently checked finalcertificate')
            need(verify(r['certificate'])==root/'certificate-v1.json','closed complete fullboard certificate file')
        else:
            need(r['search_status'] in ('unknown_search_budget','unknown_trace_budget','unknown_infrastructure_failure','exhausted_finite_marked_subtree')
                 and r['certificate'] is None and r['final_certificate_checked'] is False
                 and not (root/'certificate-v1.json').exists(),'UNKNOWN/exhaustion no certificate/bonus/training')
    frame=read_worker_frame(stdout,child_pid,code,child_seconds,worker_peak)
    return record,r,frame


def run(plan_path):
    p,pp,leaf,argv=preflight(plan_path)
    observers=[];samples=[];owned={};child=None;usage=None;error=None;cleanup_errors=[]
    directory=Path(p['owner_output_directory'])
    # Capability preflight before scientific leaf; no hidden failed launch.
    observe(observers);need(not CANCELLED[0],'cancelled before worker launch')
    need(time.perf_counter()-ENTRY<175-WRITE_SECONDS,'cold metadata consumed supervisor budget')
    directory.mkdir(parents=False,exist_ok=False)
    save(directory/'launch-v1.json',{'plan':pp,'owner':p['owner_source'],'literal_worker_argv':argv,
         'limits':LIMITS,'search_limits':SEARCH,'reserve_bytes':RESERVE,'once_only':True})
    child_start=None;child_end=None
    stdout=directory/'worker-stdout-v1.bin';stderr=directory/'worker-stderr-v1.bin'
    try:
        with stdout.open('xb') as out,stderr.open('xb') as err:
            need(not CANCELLED[0],'cancelled before one cold leaf Popen')
            child_start=time.perf_counter()
            child=subprocess.Popen(argv,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
                start_new_session=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
            while True:
                pid,status,current=os.wait4(child.pid,os.WNOHANG)
                if pid:
                    usage=current;child.returncode=os.waitstatus_to_exitcode(status);child_end=time.perf_counter();break
                need(not CANCELLED[0],'owner interrupted/cancelled')
                need(time.perf_counter()-child_start<LIMITS['child_seconds'],
                     'full cold child170 deadline before receipt; no supervisor175 waiver')
                need(time.perf_counter()-ENTRY<175-WRITE_SECONDS,'supervisor175 deadline before receipt reserve')
                rows=observe(observers)
                if child.pid not in rows:
                    # A successful leaf can finish while the observer runs.
                    # Reap that retained direct child before requiring a live
                    # row; never reacquire its numeric leader after this reap.
                    pid,status,current=os.wait4(child.pid,os.WNOHANG)
                    if pid:
                        usage=current;child.returncode=os.waitstatus_to_exitcode(status);child_end=time.perf_counter();break
                active=collect(rows,child.pid,owned,True)
                need(child.pid in active and rows[child.pid]['ppid']==os.getpid()
                     and rows[child.pid]['pgid']==child.pid,'fresh direct owned leaf/group identity')
                # The reviewed leaf launches no child. Unexpected descendants
                # invalidate topology even if their sampled memory would fit.
                need(set(active)=={child.pid},'unexpected worker descendants, source-trusted leaf scope failed')
                own_peak=peak(resource.getrusage(resource.RUSAGE_SELF));rss=sum(rows[i]['rss_bytes'] for i in active)
                observer_peak=max(x['kernel_peak_bytes'] for x in observers)
                combined=own_peak+rss+observer_peak
                need(len(samples)<MAX_SAMPLES,'complete sample ceiling, no retained-prefix qualification')
                samples.append({'index':len(samples),'owner_elapsed_seconds':time.perf_counter()-ENTRY,
                    'ROOT_peak_bytes':own_peak,'owned_rss_bytes':rss,'observer_peak_bytes':observer_peak,
                    'observer_index':len(observers)-1,'combined_bytes':combined,
                    'owned_rows':{str(i):rows[i] for i in active}})
                need(combined+RESERVE<=LIMITS['peak_bytes'],'sampled full owned scope plus prospective32MiB reserve')
                time.sleep(.1)
    except BaseException as exc:
        error={'type':type(exc).__name__,'message':str(exc)}
    finally:
        if child is not None and usage is None:
            try:kill_owned(observe(observers),child.pid,owned,signal.SIGTERM,True)
            except BaseException as exc:
                cleanup_errors.append({'type':type(exc).__name__,'message':str(exc)})
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            end=time.perf_counter()+2
            while time.perf_counter()<end:
                pid,status,current=os.wait4(child.pid,os.WNOHANG)
                if pid:usage=current;child.returncode=os.waitstatus_to_exitcode(status);child_end=time.perf_counter();break
                time.sleep(.02)
            if usage is None:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                _,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status);child_end=time.perf_counter()
        leftovers={}
        if child is not None:
            try:
                rows=observe(observers);leftovers=collect(rows,child.pid,owned,False)
                if leftovers:
                    kill_owned(rows,child.pid,owned,signal.SIGKILL,False);time.sleep(.05)
                    leftovers=collect(observe(observers),child.pid,owned,False)
            except BaseException as exc:
                cleanup_errors.append({'type':type(exc).__name__,'message':str(exc)})
                leftovers={'unconfirmed':'observer unavailable after direct-child reap'}
        worker_peak=peak(usage) if usage is not None else 0
        own_peak=peak(resource.getrusage(resource.RUSAGE_SELF))
        observer_peak=max([x['kernel_peak_bytes'] for x in observers] or [0])
        conservative=max([own_peak+worker_peak+observer_peak]+[x['combined_bytes'] for x in samples])
        receipt=None;worker_frame=None;worker_record=None;closure_pass=False
        receipt_path=Path(leaf['output_directory'])/'worker-receipt-v1.json'
        try:
            need(error is None and child is not None and usage is not None and child.returncode==0
                 and child_start is not None and child_end is not None,'actual reaped successful direct leaf')
            worker_record,receipt,worker_frame=receipt_gate(receipt_path,leaf,p['worker_plan'],p['worker_activation'],
                 p['qualified_context'],child.pid,child.returncode,child_end-child_start,worker_peak,stdout)
            for record in p['closure']:verify(record)
            verify(pp);closure_pass=True
        except BaseException as exc:
            if error is None:error={'type':type(exc).__name__,'message':str(exc)}
        elapsed=time.perf_counter()-ENTRY
        accepted=(error is None and not CANCELLED[0] and not cleanup_errors and not leftovers
            and receipt is not None and worker_frame is not None and closure_pass
            and len(samples)>=1 and child.pid in owned
            and child_start is not None and child_end is not None
            and 0<=child_end-child_start<=LIMITS['child_seconds']
            and elapsed+WRITE_SECONDS<=175 and conservative+RESERVE<=LIMITS['peak_bytes'])
        ledger=directory/'ownership-ledger-v1.json.gz'
        with ledger.open('xb') as stream:
            stream.write(gzip.compress((canonical({'samples':samples,'observers':observers,
                'retained_births':{str(k):v for k,v in owned.items()},'leftovers':leftovers,
                'owner_pid':os.getpid(),
                'worker_pid':child.pid if child else None,'worker_wait4_raw':raw_usage(usage) if usage else None,
                'worker_kernel_peak_bytes':worker_peak,'observer_peak_bytes':observer_peak,
                'source_trusted_host_filter':True,'independent_whole_host_audit':False})+'\n').encode(),mtime=0))
        result={'schema':TERMINAL,'status':'resource_candidate_pending_actual_ROOT_terminal' if accepted else 'UNKNOWN_owned_phase_gate',
            'resource_gate_accepted':accepted,'plan':pp,'owner':p['owner_source'],'worker_plan':p['worker_plan'],
            'worker_activation':p['worker_activation'],'qualified_context':p['qualified_context'],
            'worker_receipt':worker_record,'worker_closed_SELF':worker_frame,'ownership_ledger':pin(ledger),
            'worker_stdout':pin(stdout) if stdout.exists() else None,'worker_stderr':pin(stderr) if stderr.exists() else None,
            'error':error,'cancelled':CANCELLED[0],'cleanup_errors':cleanup_errors,
            'owner_pid':os.getpid(),'worker_returncode':child.returncode if child else None,'worker_pid':child.pid if child else None,
            'worker_terminal_and_reaped':usage is not None,'owned_leftovers':list(leftovers),
            'child_lifetime_seconds':child_end-child_start if child_start is not None and child_end is not None else None,
            'owner_elapsed_before_receipt_seconds':elapsed,'ROOT_peak_bytes':own_peak,
            'worker_kernel_peak_bytes':worker_peak,'observer_peak_bytes':observer_peak,'conservative_peak_bytes':conservative,
            'prospective_postlude_reserve_bytes':RESERVE,'write_reserve_seconds':WRITE_SECONDS,
            'limits':LIMITS,'complete_post_closure_unchanged':closure_pass,'sample_count':len(samples),
            'observer_count':len(observers),'all_observers_terminal_and_reaped':all(x['terminal_and_reaped'] for x in observers),
            'full_resource_accepted':False,'proof_acceptance_issued':False,'all_five_qualification':False,
            'new_RL_training':False,'OS_hard_cap_claim':False,'whole_host_cap_claim':False,
            'accounting_scope':'Darwin raw bytes; own SELF + separate whole leaf wait4 peak + maximum sequential trusted-PS wait4 peak, also full sampled ownedRSS. No rolled child subtraction/RUSAGE_CHILDREN; source-trusted leaf/filter. Actual enclosing caller terminal and prospective32MiB postlude reserve remain separate conditions.'}
        provisional=directory/'provisional-terminal-v1.json';terminal=directory/'ROOT-terminal-v1.json'
        save(provisional,result)
        post_elapsed=time.perf_counter()-ENTRY
        post_self_usage=resource.getrusage(resource.RUSAGE_SELF)
        post_self_peak=peak(post_self_usage)
        post_peak=max(conservative,post_self_peak+worker_peak+observer_peak)
        post_accepted=accepted and not CANCELLED[0] and post_elapsed<=175 and post_peak+RESERVE<=LIMITS['peak_bytes']
        if post_accepted:os.link(provisional,terminal)
        save(directory/'post-write-observation-v1.json',{'schema':'ROOT-primitive-discovery-post-write-v1',
            'resource_gate_accepted':post_accepted,'owner_elapsed_seconds':post_elapsed,
            'conservative_peak_bytes':post_peak,'postlude_reserve_bytes':RESERVE,'limits':LIMITS,
            'post_write_ROOT_SELF_raw':raw_usage(post_self_usage),'post_write_ROOT_peak_bytes':post_self_peak,
            'terminal':pin(terminal) if post_accepted else None,'provisional':pin(provisional),
            'actual_caller_terminal_required':True})
        print(canonical({'schema':'ROOT-primitive-discovery-owner-final-print-v1',
            'resource_gate_accepted':post_accepted and not CANCELLED[0],'cancelled_at_final_print':CANCELLED[0],
            'owner_elapsed_seconds':post_elapsed,'conservative_peak_bytes':post_peak,
            'terminal':str(terminal) if post_accepted else None}),flush=True)


def main():
    need(len(sys.argv)==2,'one separate ROOT frozen owner plan; no proof/route argument')
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(sig,flag)
    signal.alarm(175)
    run(Path(sys.argv[1]))


if __name__=='__main__':main()
