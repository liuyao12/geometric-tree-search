"""SOURCE ONLY one cold declared primitive-advice-pair leaf; no authored proof route.

No actual job or activation is bundled. Only ROOT may invoke this leaf after
person-independent reviews of this source and the final-certificate helper,
and a separately frozen/reviewed owner/platform/terminal contract. The static
catalog is already admitted; dynamic search and full trajectory attribution
remain distinct. The author has never imported or invoked this file.
"""
import time
ENTRY = time.perf_counter()
import gzip
import hashlib
import importlib.util
import io
import json
import math
import inspect
import types
from collections.abc import Iterable as _StdlibIterable
_NATIVE_GENERIC_ALIAS = type(list[int])
_ITERABLE_CLASS_GETITEM = vars(_StdlibIterable)['__class_getitem__']
import os
from pathlib import Path
import signal
import stat
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PLAN = 'ROOT-I2-finite-family-first-proof-plan-v1'
ACTIVATION = 'ROOT-I2-finite-family-first-proof-activation-v1'
RECEIPT = 'I2-finite-family-first-proof-worker-receipt-v1'
RECIPIENT_IDS = ('fresh-i2-CD-vw-direct', 'fresh-i2-CD-vw-incidence-transport')
DECLARATION_PROFILE = 'hilbert-fresh-guarded-I2-cohort-static-v1'
AUTHOR_IDENTITY = '/root/hilbert_advice_controls'
MODES = ('base','seed_forward')
SEARCH_LIMITS = {'attempts': 128, 'seconds': 20, 'event_ceiling': 2000}
OWNED_LIMITS = {'whole_seconds': 180, 'supervisor_seconds': 175,
                'child_seconds': 170, 'peak_bytes': 536870912}
POSTLUDE_RESERVE = 33554432
MAX_JSON = 64 * 1024 * 1024
OUTPUT_NAMES = ('result-v1.json.gz', 'certificate-v1.json', 'worker-receipt-v1.json', 'first-proof-certificate-v1.json')
CANCELLED = [False]
FAILURE_PHASE = ['entry']
FAILURE_GATE = ['none']
# Exact raw constants are filled by the metadata-only author freezer before
# freezing this source. No scientific source is imported by that freezer.
FROZEN_SOURCES = {'candidate_advice': {'bytes': 27264, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-incidence-priority-source-20261013/incidence_priority_witness_advice_v2.py', 'sha256': '3a86adba8982c406ae4a2ad3349b8ae962e52498dee38ee3ee26719b22468053'}, 'certificate': {'bytes': 64498, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-first-proof-helper-source-20261013/i2_context_and_final24_certificate_v1.py', 'sha256': 'c8fa4aeba82fcc2af9bd091fd351d72f86a24ae97cb5edd92ff558e81c23501b'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'dynamic_graph_adapter': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'dynamic_lifecycle_adapter': {'bytes': 29230, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-dynamic-source-20261012/compact_cluster_lifecycle_v2.py', 'sha256': '677c48c7aebfecf0c83c8daa8bf8e873d0be1e415906afa6687f0b9652e33719'}, 'family_advice': {'bytes': 62803, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/equality_receptor_family_I2_sequence_guard_v3.py', 'sha256': 'b4d20eaf6c7f5db25e7ab7a70303e7d39a733b49c2cec300b363cbc3f7fbfaa5'}, 'features31': {'bytes': 12386, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-rl-small-source-20261012/family_graph_features_v1.py', 'sha256': '644e4cd195f98c1ca3f97c3fcba84dfdbc18765454512435702951cc6169a14b'}, 'final_certificate': {'bytes': 70208, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/I2_family_final24_sequence_guard_binding_v4.py', 'sha256': '10a41171c18a82e6f33d13403aae9e441a69d7fd11f065ff5497aea415f0188f'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'policy_math': {'bytes': 11607, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-learning-20261012/family_policy_math_v2.py', 'sha256': '61b772b45ed4523ba4c14ae4519cd9dae53c21d4dc1b1681689011707831c294'}, 'proof_observer': {'bytes': 29717, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-observer-controls-source-20261013/first_checked_proof_observer_i2_v1.py', 'sha256': 'ad2efd1b7685fe6f7baa8f3b9849baf3568c3cf67e87a85e3d0ac657d8772cdc'}, 'streamed_dfs': {'bytes': 49263, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/compact_I2_family_first_checked_proof_dfs_v12.py', 'sha256': '57e415f9822f73dcbec2f16f45564196de519476ab2b0f3fbb9097fc972d8859'}, 'streamed_overlay': {'bytes': 18348, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/I2_family_consumer_overlay_v2.py', 'sha256': 'df05db866111b8e5c86ddffb9c9a0216678d6e171c7b5f1bdde866573f87ab4b'}, 'streamed_proposal': {'bytes': 25358, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-streamed-consumers-source-20261012/compact_cluster_proposal_v2.py', 'sha256': '1d094e7f51c7607cc121a48e0bc55f4daf2cc7801701eea34a2bb552f1505b38'}, 'transport': {'bytes': 13756, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/curriculum-compact-wrapper-source-20261012/compact_static_transport_v1.py', 'sha256': '65a0b598966ae4dffdda1b770eb2d4d5b64af1bcaf6aead4281a224a4123def3'}}
STATIC_SOURCES = {'producer': {'compact_engine': {'bytes': 20787, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-engine-source-20261012/compact_point_graph_v1.py', 'sha256': 'd638f7152ec7fa8293adbd8915b79de60f95d0756952bdc6bf0e40b15f549ca0'}, 'compiler': {'bytes': 46195, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/hilbert_i2_compiler_v1.py', 'sha256': 'b6a423ab2412af99842894ac8788d167a764987a897f0ca2e974d244d6f21ced'}, 'decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'worker': {'bytes': 31822, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/hilbert_i2_prepare_worker_v1.py', 'sha256': 'b8a75aa41c786ec1003ef8d0f44a3d3b489dd4ce844b7cddfe6eaa0bb85e6336'}}, 'audit': {'catalog_audit': {'bytes': 15171, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-independent-source-20261012/independent_compact_catalog_audit_v1.py', 'sha256': 'db4dc3b904715be3123ed1a9b22eb1ce9144c35aa00c610da94f13263e4334e8'}, 'domains': {'bytes': 7441, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-independent-source-20261012/independent_compact_domains_v1.py', 'sha256': '1b9d6b94c78f363ba20f48234dc1eb48ac9dcfa548e8f0fa1a7350699b059b34'}, 'grammar': {'bytes': 14885, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/hilbert_i2_grammar_v1.py', 'sha256': '3d93bf6f1a970912d4a9b28433f761e91d6d91aeb08e1cc597bae28144139415'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'worker': {'bytes': 47882, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/hilbert_i2_audit_worker_v1.py', 'sha256': 'ac3d460603ae0eea3113d80c5bb63ad1dfc5bdb71ca88727fc69357a4900b2e5'}}}
FIXTURE = {'bytes': 54170, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-static-implementation-source-20261013/i2-fixtures-v1.json', 'sha256': '91fe6df2c148ddc9968c429bd5cf40fbd90f367c337feee14122a9df3bb452b5'}
# Exact helper person-review pin is future ROOT plan input, verified against new bytes.
RESOURCE_PREDICATES = frozenset(('actual_tool_terminal', 'caller_clock_bound',
    'owner_terminal_link_present', 'owner_gate', 'post_write_gate',
    'cancelled_at_final_print_false', 'final_print_gate', 'stage_identity',
    'worker_complete', 'all_worker_direct_children_closed',
    'all_owner_direct_children_closed', 'no_owned_leftovers',
    'complete_post_closure_unchanged', 'post_write_exact_terminal'))


def need(value, message):
    if not value:
        if type(message) is str:
            FAILURE_GATE[0] = hashlib.sha256(message[:512].encode('utf8', errors='replace')).hexdigest()[:16]
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf8')).hexdigest()


def same(actual, expected, message):
    need(canonical(actual) == canonical(expected), message)


def fields(pairs):
    answer = {}
    for name, value in pairs:
        need(name not in answer, 'duplicate JSON field')
        answer[name] = value
    return answer


def parse(raw):
    return json.loads(raw, object_pairs_hook=fields,
        parse_constant=lambda name: (_ for _ in ()).throw(ValueError('nonfinite JSON ' + name)))


def cancel(signum, frame):
    # No raising handler can interrupt registration/serialization bookkeeping.
    CANCELLED[0] = True


def boundary(label):
    need(not CANCELLED[0], 'cancelled primitive discovery: ' + label)
    need(time.perf_counter() - ENTRY < OWNED_LIMITS['child_seconds'],
         'whole cold leaf deadline, not mathematical exhaustion: ' + label)


class Inputs:
    """Pure stdlib whole-byte admission before any project source is loaded."""
    def __init__(self):
        self.pins = {}

    def verify(self, record):
        need(type(record) is dict and set(record) == {'path', 'sha256', 'bytes'}
             and type(record['path']) is str and type(record['sha256']) is str
             and len(record['sha256']) == 64
             and all(c in '0123456789abcdef' for c in record['sha256'])
             and type(record['bytes']) is int and record['bytes'] >= 0,
             'exact raw three-field pin')
        p = Path(record['path'])
        need(str(p) == record['path'] and '..' not in p.parts, 'exact lexical raw path')
        p = p if p.is_absolute() else ROOT / p
        need(not p.is_symlink() or (p.is_absolute() and ROOT not in p.parents),
             'project source/input has no final-component alias; exact external runtime spelling is retained')
        if record['path'] in self.pins:
            same(record, self.pins[record['path']], 'same spelling has inconsistent pins')
        h = hashlib.sha256(); count = 0
        identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
        with p.open('rb') as stream:
            before = os.fstat(stream.fileno())
            need(stat.S_ISREG(before.st_mode), 'regular closed input')
            for block in iter(lambda: stream.read(65536), b''):
                h.update(block); count += len(block)
            after = os.fstat(stream.fileno())
        need(identity(before) == identity(after) == identity(p.stat())
             and count == after.st_size == record['bytes']
             and h.hexdigest() == record['sha256'], 'closed whole raw bytes changed')
        self.pins[record['path']] = dict(record)
        return p

    def equivalent(self, a, b, label):
        pa, pb = self.verify(a), self.verify(b)
        need(pa.resolve() == pb.resolve() and a['sha256'] == b['sha256']
             and a['bytes'] == b['bytes'], label)

    def json(self, record):
        p = self.verify(record)
        with p.open('rb') as stream:
            raw = stream.read(MAX_JSON + 1)
            need(len(raw) <= MAX_JSON and stream.read(1) == b'', 'whole bounded metadata, no prefix')
        need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
             'parse the same authenticated raw bytes')
        if p.name.endswith('.gz'):
            with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:
                raw = stream.read(MAX_JSON + 1)
                need(len(raw) <= MAX_JSON and stream.read(1) == b'', 'whole bounded decoded metadata')
        result = parse(raw); self.verify(record)
        return result

    def tree(self, value):
        # Pin grammars with a role or other semantic fields are not silently
        # projected. Their enclosing source/receipt schema validates them.
        if type(value) is dict:
            if set(value) == {'path', 'sha256', 'bytes'}:
                self.verify(value)
            else:
                for child in value.values():
                    self.tree(child)
        elif type(value) is list:
            for child in value:
                self.tree(child)

    def close(self):
        for record in tuple(self.pins.values()):
            self.verify(record)


def pin(path):
    path = Path(path); h = hashlib.sha256(); count = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            h.update(block); count += len(block)
    return {'path': str(path), 'sha256': h.hexdigest(), 'bytes': count}

ROOT_COMPLETE_FAMILY_CONTROLS = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-controls-progress-v2-20261014/ROOT-actual-family-controls-disposition-v1.json', 'sha256': '687b59a54a7b10bdfe213b96e66ee18c3ab1d6586c12490b5fceab9227975846', 'bytes': 20667}
FROZEN_CONTROL_SOURCES = {'candidate_advice': {'bytes': 27264, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-incidence-priority-source-20261013/incidence_priority_witness_advice_v2.py', 'sha256': '3a86adba8982c406ae4a2ad3349b8ae962e52498dee38ee3ee26719b22468053'}, 'certificate': {'bytes': 64498, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-first-proof-helper-source-20261013/i2_context_and_final24_certificate_v1.py', 'sha256': 'c8fa4aeba82fcc2af9bd091fd351d72f86a24ae97cb5edd92ff558e81c23501b'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'dynamic_graph_adapter': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'dynamic_lifecycle_adapter': {'bytes': 29230, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-dynamic-source-20261012/compact_cluster_lifecycle_v2.py', 'sha256': '677c48c7aebfecf0c83c8daa8bf8e873d0be1e415906afa6687f0b9652e33719'}, 'family_advice': {'bytes': 62803, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/equality_receptor_family_I2_sequence_guard_v3.py', 'sha256': 'b4d20eaf6c7f5db25e7ab7a70303e7d39a733b49c2cec300b363cbc3f7fbfaa5'}, 'features31': {'bytes': 12386, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-rl-small-source-20261012/family_graph_features_v1.py', 'sha256': '644e4cd195f98c1ca3f97c3fcba84dfdbc18765454512435702951cc6169a14b'}, 'final_certificate': {'bytes': 70208, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/I2_family_final24_sequence_guard_binding_v4.py', 'sha256': '10a41171c18a82e6f33d13403aae9e441a69d7fd11f065ff5497aea415f0188f'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'mechanism_controls': {'bytes': 20345, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-controls-source-20261014/actual_Incident_family_controls_v1.py', 'sha256': '70187b4ad5b0a733dedae6b9ac0f9cf20bc398fe83d96fdf17ba522c20cf8583'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'policy_math': {'bytes': 11607, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-learning-20261012/family_policy_math_v2.py', 'sha256': '61b772b45ed4523ba4c14ae4519cd9dae53c21d4dc1b1681689011707831c294'}, 'proof_observer': {'bytes': 29717, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-observer-controls-source-20261013/first_checked_proof_observer_i2_v1.py', 'sha256': 'ad2efd1b7685fe6f7baa8f3b9849baf3568c3cf67e87a85e3d0ac657d8772cdc'}, 'streamed_dfs': {'bytes': 49263, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/compact_I2_family_first_checked_proof_dfs_v12.py', 'sha256': '57e415f9822f73dcbec2f16f45564196de519476ab2b0f3fbb9097fc972d8859'}, 'streamed_overlay': {'bytes': 18348, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-consumer-source-20261014/I2_family_consumer_overlay_v2.py', 'sha256': 'df05db866111b8e5c86ddffb9c9a0216678d6e171c7b5f1bdde866573f87ab4b'}, 'streamed_proposal': {'bytes': 25358, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-streamed-consumers-source-20261012/compact_cluster_proposal_v2.py', 'sha256': '1d094e7f51c7607cc121a48e0bc55f4daf2cc7801701eea34a2bb552f1505b38'}, 'transport': {'bytes': 13756, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/curriculum-compact-wrapper-source-20261012/compact_static_transport_v1.py', 'sha256': '65a0b598966ae4dffdda1b770eb2d4d5b64af1bcaf6aead4281a224a4123def3'}, 'worker': {'bytes': 39476, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/actual_Incident_family_controls_sequence_binding_v3.py', 'sha256': '13d0e7cd30b8dfb905dc2cb7aab5665e649886f7a31c8cb70cb664650957f5c1'}}
ACTUAL_FAMILY_INPUTS = {'candidate_library': {'bytes': 85344, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/worker-output-v1/candidate-library-v1.json', 'sha256': '08e75860545d3e0248e99c36858b0ca25d1bcbb1c7ad01b3cd2d332d51149e07'}, 'independent_audit': {'bytes': 41490, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/worker-output-v1/independent-all-origin-audit-v1.json', 'sha256': '55a9e8c2a4df287da9dbc2c72c42c4b13de520e6eafb02bd61124919b5ee22be'}, 'ROOT_extraction_disposition': {'bytes': 7879, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-extraction-progress-20261014/ROOT-actual-family-extraction-disposition-v1.json', 'sha256': '757606d7a20048e5a8335559c96cf1749e1ab53f900bdff593fb10beeed8a173'}}
FAMILY_TRAINING = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-implementation-source-20261013/training-inputs-v1.json', 'sha256': 'de34653e96673e080c65a6c17fad3cc24cfb00ab0043fdc11c9741e6708f382c', 'bytes': 8340}
FAMILY_DONORS = {'reader': {'bytes': 64540, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/fresh_equality_context_and_final24_certificate_v3.py', 'sha256': '5d03d088c2d1b7f90e98fb7e28819ab0643b74f6786953c6107d4d2535c2377b'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'dynamic_graph': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}}
FAMILY_UPSTREAM = {'reader': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-first-proof-helper-source-20261013/i2_context_and_final24_certificate_v1.py', 'sha256': 'c8fa4aeba82fcc2af9bd091fd351d72f86a24ae97cb5edd92ff558e81c23501b', 'bytes': 64498}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'dynamic_graph': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}}
FAMILY_ADMISSION_SCHEMA = 'ROOT-finite-Incident-transport-I2-recipient-advice-admission-v2'
FAMILY_REGISTRY_SCHEMA = 'ROOT-I2-finite-Incident-advice-registry-binding-v1'
SCIENTIFIC_PURPOSE = 'scientific-primitive-ordering-only'


def scientific_variant(leaf):
    registry = leaf['family_registry_binding']
    need(leaf['mode'] in ('base','seed_forward'), 'only declared deterministic modes')
    if registry is None:
        return 'canonical' if leaf['mode'] == 'base' else 'ordinary-incidence-ordering'
    need(leaf['mode'] == 'seed_forward' and type(registry) is dict,
         'family registry only in explicit finite family lane')
    return 'finite-Incident-family-ordering'


def scientific_family_admission(leaf, admission):
    """Pure metadata scope gate; no candidate pool, checker or graph construction."""
    registry = leaf['family_registry_binding']
    fields = {'schema','instance_id','recipient_qualification','family_implementation',
        'library_source','training_spec','extraction_audit','model_binding',
        'consumed_source_epoch','primitive_source_body_count','advice_registry_epoch','library_admission'}
    need(type(registry) is dict and set(registry) == fields
         and registry['schema'] == FAMILY_REGISTRY_SCHEMA
         and registry['instance_id'] == leaf['selector']
         and registry['recipient_qualification'] == leaf['qualification']
         and registry['family_implementation'] == leaf['sources']['family_advice']
         and registry['library_source'] == ACTUAL_FAMILY_INPUTS['candidate_library']
         and registry['extraction_audit'] == ACTUAL_FAMILY_INPUTS['independent_audit']
         and registry['training_spec'] == FAMILY_TRAINING
         and type(registry['primitive_source_body_count']) is int
         and registry['primitive_source_body_count'] == 0,
         'exact current finite family registry; no injected bodies or donor target')
    epoch = digest({k:v for k,v in registry.items() if k not in ('library_admission','advice_registry_epoch')})
    need(registry['advice_registry_epoch'] == epoch, 'acyclic exact current registry preimage')
    need(type(admission) is dict and admission.get('schema') == FAMILY_ADMISSION_SCHEMA
         and admission.get('scientific_episode_activation') is True
         and admission.get('purpose') == SCIENTIFIC_PURPOSE
         and 'controls_scope' not in admission and 'ROOT_controls_authorized' not in admission
         and admission.get('ROOT_complete_controls_disposition') == ROOT_COMPLETE_FAMILY_CONTROLS
         and admission.get('ROOT_extraction_disposition') == ACTUAL_FAMILY_INPUTS['ROOT_extraction_disposition']
         and admission.get('ROOT_advice_library_accepted') is True
         and admission.get('advice_only') is True
         and admission.get('schema_universally_validated') is False
         and type(admission.get('primitive_source_body_count')) is int
         and admission['primitive_source_body_count'] == 0
         and admission.get('registry_preimage_sha256') == epoch
         and admission.get('library') == registry['library_source']
         and admission.get('implementation') == registry['family_implementation']
         and admission.get('recipient_qualification') == registry['recipient_qualification']
         and admission.get('training_spec') == FAMILY_TRAINING
         and admission.get('extraction_audit') == registry['extraction_audit']
         and admission.get('donor_sources') == FAMILY_DONORS
         and admission.get('upstream_sources') == FAMILY_UPSTREAM,
         'separate ROOT scientific-purpose advice admission; controls-only/extraction-only rejected before code loading')


def validate_execution_ledger(leaf, ledger):
    """Exact per-variant executed raw roles; baseline never executes family."""
    need(type(ledger) is list, 'whole executed-source ledger')
    expected = {p['path']:p for role,p in leaf['sources'].items()
                if role != 'master' and (role != 'family_advice' or leaf['family_registry_binding'] is not None)}
    observed = {}
    for item in ledger:
        need(type(item) is dict and set(item) == {'module_name','source_pin'}
             and type(item['module_name']) is str and item['module_name']
             and type(item['source_pin']) is dict, 'exact executed source row')
        p = item['source_pin']
        need(expected.get(p.get('path')) == p, 'no undeclared or deferred family execution')
        observed[p['path']] = p
    same(observed, expected, 'every required per-variant module actually executed; no family execution in BASE/ordinary')


def admit_complete_family_controls(inputs):
    seal = inputs.json(ROOT_COMPLETE_FAMILY_CONTROLS)
    need(seal['schema'] == 'ROOT-current-two-I2-family-controls-disposition-v1'
         and seal['ROOT_complete_scoped_controls_accepted'] is True
         and tuple(c['instance_id'] for c in seal['cases']) == RECIPIENT_IDS
         and seal['successful_control_cases'] == 2
         and seal['scientific_search_activation'] is False
         and seal['ROOT_library_admitted'] is False,
         'actual complete scoped controls prerequisite, never scientific admission by itself')
    resource = inputs.json(seal['resource_qualification'])
    need(resource['ROOT_final_accepted'] is True
         and set(resource['predicates']) == RESOURCE_PREDICATES
         and all(v is True for v in resource['predicates'].values()), 'whole genuine controls resource closure')
    receipt = inputs.json(seal['actual_receipt']); evidence = inputs.json(seal['actual_evidence'])
    need(receipt['stage_completed'] is True and receipt['controls'] == seal['actual_controls']
         and receipt['evidence'] == seal['actual_evidence']
         and evidence['sources'] == FROZEN_CONTROL_SOURCES
         and evidence['controls'] == seal['actual_controls']
         and evidence['scientific_consumer_activation'] is False,
         'whole current repaired-source control receipt/evidence')
    for value in (seal,resource,receipt,evidence): inputs.tree(value)
    return seal

def function_signature(guard):
    need(type(guard) is types.FunctionType, 'production delegated validator is exact function')
    return (guard, guard.__code__, tuple(id(x) for x in guard.__defaults__ or ()),
            tuple((k, id(v)) for k, v in sorted((guard.__kwdefaults__ or {}).items())),
            tuple((id(c), id(c.cell_contents)) for c in guard.__closure__ or ()))


def effective_methods(endpoint):
    """Effective lookup and all property accessors, recursively through MRO."""
    result = []; seen = set(); namespace = getattr(endpoint, '__dict__', {})
    for owner in type(endpoint).__mro__:
        for name, descriptor in sorted(vars(owner).items()):
            if name in seen:
                continue
            seen.add(name)
            if owner is _StdlibIterable and name == '__class_getitem__':
                # Reject replacement before the initial method cache too,
                # including a Python function or property on this stdlib slot.
                need(type(descriptor) is classmethod
                     and descriptor is _ITERABLE_CLASS_GETITEM
                     and descriptor.__func__ is _NATIVE_GENERIC_ALIAS
                     and types.GenericAlias is _NATIVE_GENERIC_ALIAS,
                     'unchanged trusted Iterable GenericAlias descriptor')
            if isinstance(descriptor, property):
                functions = tuple(f for f in (descriptor.fget, descriptor.fset, descriptor.fdel)
                                  if f is not None)
                result.append((name, owner, descriptor,
                    tuple(function_signature(f) for f in functions)))
                continue
            if isinstance(descriptor, (staticmethod, classmethod)):
                function = descriptor.__func__
            elif type(descriptor) is types.FunctionType:
                function = descriptor
            else:
                continue
            need(name not in namespace, 'no ordinary instance method shadow: '+name)
            effective = getattr(endpoint, name)
            if isinstance(descriptor, staticmethod):
                need(effective is function, 'same static endpoint')
            else:
                receiver = type(endpoint) if isinstance(descriptor, classmethod) else endpoint
                need(type(effective) is types.MethodType and effective.__self__ is receiver
                     and effective.__func__ is function, 'same effective method')
            if type(function) is types.FunctionType:
                executable = function_signature(function)
            else:
                # Python3.9 Iterable supplies classmethod(GenericAlias). This
                # inherited typing helper has no Python code/default/closure.
                # Seal only that exact descriptor/native/effective identity;
                # all project validators and Python accessors remain strict.
                need(owner is _StdlibIterable and name == '__class_getitem__'
                     and type(descriptor) is classmethod
                     and descriptor is _ITERABLE_CLASS_GETITEM
                     and function is _NATIVE_GENERIC_ALIAS
                     and types.GenericAlias is _NATIVE_GENERIC_ALIAS
                     and vars(_StdlibIterable).get(name) is _ITERABLE_CLASS_GETITEM,
                     'only exact trusted Iterable GenericAlias native classmethod')
                executable = ('stdlib-Iterable-GenericAlias-identity', _NATIVE_GENERIC_ALIAS)
            result.append((name, owner, descriptor, executable))
    return tuple(result)


def person_review(inputs, record, source, scope):
    review = inputs.json(record)
    need(review['schema'] == 'ROOT-person-independent-primitive-source-review-v1'
         and review['scope'] == scope and review['source_only'] is True
         and review['source_ready'] is True and review['all_checks_passed'] is True
         and type(review['scientific_calls']) is int and review['scientific_calls'] == 0
         and review['scientific_acceptance'] is False
         and review['author_identity'] == (AUTHOR_IDENTITY if scope == 'primitive-advice-pair-worker'
             else (AUTHOR_IDENTITY if scope == 'final-primitive-advice-pair-certificate-helper'
                   else '/root/hilbert_ordering_diagnosis'))
         and type(review['reviewer_identity']) is str and review['reviewer_identity']
         and review['reviewer_identity'] != review['author_identity'],
         'different-person exact new worker/helper SOURCE review; no author self-admission')
    inputs.equivalent(review['source'], source, 'review exact current source bytes')
    inputs.tree(review)


def static_admission(inputs, qualification, selector):
    q = qualification
    need(type(q) is dict and set(q) == {'schema', 'status', 'declaration_profile', 'instance_id',
         'declaration_inputs', 'catalog', 'producer', 'independent', 'sources',
         'expected_consumer_source_binding', 'all_complete_catalog_licenses_and_initial24domains_accepted'}
         and q['schema'] == 'ROOT-qualified-compact-proof-context-v1'
         and q['status'] == 'accepted_complete_catalog_and_initial_point_model'
         and q['declaration_profile'] == DECLARATION_PROFILE and q['instance_id'] == selector
         and type(selector) is str and selector in RECIPIENT_IDS
         and q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True,
         'only the actual independently admitted fresh geometry catalog')
    same(q['declaration_inputs'], {'fixture': FIXTURE}, 'whole fresh sixteen-case fixture')
    need(set(q['producer']) == {'plan', 'receipt', 'evidence', 'ROOT_decision'}
         and set(q['independent']) == {'plan', 'receipt', 'evidence', 'licenses', 'ROOT_decision'}
         and set(q['sources']) == {'producer', 'audit'}, 'both complete actual admission closures')
    same(q['sources'], STATIC_SOURCES, 'exact complete Hilbert producer and independent source records')
    inputs.tree(q)
    pp = inputs.json(q['producer']['plan']); ap = inputs.json(q['independent']['plan'])
    pr = inputs.json(q['producer']['receipt']); ar = inputs.json(q['independent']['receipt'])
    pe = inputs.json(q['producer']['evidence']); ae = inputs.json(q['independent']['evidence'])
    header = inputs.json(q['catalog']); inputs.tree(header)
    for which, plan in (('producer', pp), ('audit', ap)):
        same(q['sources'][which], plan['sources'], 'exact actual source epoch map ' + which)
        inputs.tree(plan)
        inputs.tree(inputs.json(plan['source_review']))
    for record, stage in ((q['producer'], 'preparation'), (q['independent'], 'replay')):
        decision = inputs.json(record['ROOT_decision'])
        need(decision['schema'] == 'ROOT-fresh-catalog-stage-final-decision-v1'
             and decision['stage'] == stage and decision['ROOT_final_accepted'] is True
             and decision['status'] == 'accepted_complete_owned_stage'
             and set(decision['predicates']) == RESOURCE_PREDICATES
             and all(value is True for value in decision['predicates'].values())
             and decision['mismatches'] == [], 'actual original static ROOT14 accepted, not status-only waiver')
        same(decision['limits'], {'whole_seconds':60,'peak_bytes':536870912,'caller_seconds':90},
             'original accepted static budgets')
        inputs.equivalent(decision['worker'], record['receipt'], 'actual exact completed worker')
        inputs.tree(decision)
        inputs.tree(inputs.json(decision['plan']))
    need(pr['stage_completed'] is True and ar['stage_completed'] is True
         and ar['logical_accepted'] is True and ar['initial_static_point_accepted'] is True,
         'both actually completed static stages')
    need(ae['logical_accepted'] is True and ae['initial_static_point_accepted'] is True
         and all(ae[name] is True for name in ('all_formulas_checked', 'all_licenses_checked',
           'all_DAG_nodes_checked', 'original_canonical_order_and_preimages_checked',
           'all_three_ordered_seed_identities_checked'))
         and ae['point_audit']['all_required_rows_checked'] is True
         and ae['point_audit']['rows'] == 24
         and len(ae['point_audit']['complete_point_factor_streams']) == 24,
         'whole independently licensed original catalog and every initial row')
    expected = header['dimensions']
    need(type(expected) is dict and set(expected) == {'logical_rows','formula_count','primitive_license_count',
         'non_assumption_witness_count','source_body_count'} and all(type(v) is int for v in expected.values())
         and expected['logical_rows'] == 24 and expected['formula_count'] > 0
         and expected['primitive_license_count'] >= 3
         and expected['non_assumption_witness_count'] == expected['primitive_license_count'] - 3
         and expected['source_body_count'] == 0, 'actual independently accepted complete primitive census and empty inventory')
    for value in (header, pr, ar, pe, ae):
        same(value['dimensions'], expected, 'complete untrimmed original catalog census')
    fixture = inputs.json(FIXTURE)
    cases = [case for case in fixture['cases'] if case['id'] == selector]
    need(len(cases) == 1 and len(fixture['cases']) == 16
         and fixture['recipient_case_ids'] == ['next-inc-equality-line-chain', 'next-inc-two-uniqueness', 'next-inc-derived-middle-guard',
             'fresh-inc-point-chain-w', 'fresh-inc-reversed-line-chain', 'fresh-i2-CD-vw-direct', 'fresh-i2-CD-vw-incidence-transport'], 'whole nine-seed/seven-recipient exact sixteen-case declaration')
    case = cases[0]; theory = fixture['theories'][case['theory']]
    gamma = [fixture['literal_formulas'][name] for name in case['hypotheses']]
    target = fixture['literal_formulas'][case['target']]
    same(header['context'], {'theory':theory,'ordered_local_premises':gamma}, 'original theory and three ordered roots')
    same(header['target'], target, 'original conclusion, no target renaming')
    need(case['rows'] == 24 and len(gamma) == 3 and header['context_id'] == digest(header['context'])
         and header['authority']['epoch'] == digest({k:v for k,v in header['authority'].items() if k != 'epoch'})
         and header['authority']['activated'] is False and header['authority']['native_accepted'] is False,
         'exact inactive original sequent/source authority')
    same(pe['catalog_header'], header, 'whole exact admitted raw header')
    same(header['source_bindings'], [dict(q['producer']['plan'], path=str(inputs.verify(q['producer']['plan']).resolve())),
         *pp['inputs'].values(), *pp['sources'].values(), pp['source_review']], 'original complete source-bound producer epoch')
    same(header['authority']['source_bindings'], header['source_bindings'], 'authority retains same producer closure')
    same(pe['model_epoch'], pr['model_epoch'], 'admitted model epoch')
    need(header['bodies'] == [] and header['complete_cluster_inventory'] == [], 'empty complete bootstrap body inventory')
    return header, expected, pr['model_epoch']


def preflight(plan_path, activation_path):
    inputs = Inputs(); ppin = pin(plan_path); apin = pin(activation_path)
    p = inputs.json(ppin); a = inputs.json(apin)
    required = {'schema','status','selector','phase','mode','qualification','expected_inventory_binding',
        'consumer_binding','sources','runtime','resource_contract','source_review','helper_review',
        'closure','output_directory','ROOT_owned_once_only','owned_limits','search_limits','body_source_bindings','observer_review','family_registry_binding'}
    need(type(p) is dict and set(p) == required and p['schema'] == PLAN
         and p['status'] == 'frozen_inputs_pending_separate_ROOT_activation'
         and type(p['selector']) is str and p['selector'] in RECIPIENT_IDS and p['phase'] == 'primitive-discovery'
         and p['mode'] in MODES and p['ROOT_owned_once_only'] is True,
         'strict single fresh primitive advice-pair job; no proof word/route/teacher/hint field')
    need(set(p['sources']) == set(FROZEN_SOURCES) | {'worker'}, 'all exact runtime/leaf/helper source roles')
    same({role:value for role,value in p['sources'].items() if role != 'worker'}, FROZEN_SOURCES,
         'exact complete runtime/helper sources; leaf self pin bound by independent review')
    same(p['owned_limits'], OWNED_LIMITS, 'unchanged cold 180/175/170 and512MiB phase')
    same(p['search_limits'], SEARCH_LIMITS, 'unchanged128attempt/20s/2000event episode')
    need(type(p['closure']) is list and p['closure']
         and len({item['path'] for item in p['closure']}) == len(p['closure']), 'full distinct exact lexical closure')
    for item in p['closure']:
        inputs.verify(item)
    inputs.tree(p)
    # Self pin cannot be hardcoded in its own bytes; it is exact in the plan,
    # review and activation and is rechecked before/after the complete phase.
    need(inputs.verify(p['sources']['worker']).resolve() == Path(__file__).resolve(), 'same reviewed leaf bytes')
    person_review(inputs, p['source_review'], p['sources']['worker'], 'primitive-advice-pair-worker')
    person_review(inputs, p['helper_review'], p['sources']['final_certificate'], 'final-primitive-advice-pair-certificate-helper')
    person_review(inputs, p['observer_review'], p['sources']['proof_observer'], 'first-checked-proof-observer')
    q = inputs.json(p['qualification']); header, dimensions, model_epoch = static_admission(inputs, q, p['selector'])
    same(p['consumer_binding'], q['expected_consumer_source_binding'], 'one exact ROOT-bound full consumer closure')
    need(set(p['body_source_bindings']) == {'records'} and p['body_source_bindings']['records']
         == [p['qualification'], *[p['sources'][role] for role in sorted(p['sources'])]],
         'exact sorted empty-body authority source epoch, no hidden authored lemmas')
    records = p['consumer_binding']['source_records']
    need(p['consumer_binding']['schema'] == 'ROOT-whole-streamed-consumer-source-binding-v1'
         and set(p['consumer_binding']) == {'schema','graph_binding_sha256','source_records',
              'ROOT_source_review_pin','independent_source_review_pin'}
         and type(records) is list, 'exact consumer-source grammar')
    expected_roles = ('streamed_overlay','streamed_dfs','streamed_proposal','features31','policy_math','proof_observer','family_advice')
    same(records, [{'role':role, **p['sources'][role]} for role in expected_roles], 'all exact unchanged consumer sources')
    inputs.tree(p['consumer_binding'])
    admit_complete_family_controls(inputs)
    variant = scientific_variant(p)
    if p['family_registry_binding'] is not None:
        inputs.tree(p['family_registry_binding'])
        scientific_family_admission(p, inputs.json(p['family_registry_binding']['library_admission']))
    runtime = p['runtime']
    need(set(runtime) == {'platform','executable','binary','python_version','resource_extension','posixsubprocess_extension','observer'}
         and runtime['platform'] == sys.platform == 'darwin'
         and runtime['python_version'] == list(sys.version_info[:3]) == [3,9,6]
         and runtime['executable'] == '/Library/Developer/CommandLineTools/usr/bin/python3',
         'exact prospective Darwin/CLT Python3.9.6 runtime')
    need(Path(runtime['executable']).resolve() == Path(sys.executable).resolve()
         == inputs.verify(runtime['binary']).resolve(), 'same actual runtime bytes/lexical alias')
    need(runtime['observer']['path'] == '/bin/ps', 'same bound outer observer, never launched by leaf')
    inputs.tree(runtime)
    import resource
    import _posixsubprocess
    for role, module in (('resource_extension',resource),('posixsubprocess_extension',_posixsubprocess)):
        need(Path(module.__file__).resolve() == inputs.verify(runtime[role]).resolve(), 'actual pinned stdlib native extension')
    need('sitecustomize' not in sys.modules and 'usercustomize' not in sys.modules,
         'no unreviewed interpreter customization')
    rc = p['resource_contract']
    need(set(rc) == {'postlude_reserve_bytes','platform_review','owner_source','outer_terminal_contract','caller_limit_seconds'}
         and rc['postlude_reserve_bytes'] == POSTLUDE_RESERVE and rc['caller_limit_seconds'] == 180,
         'separately reviewed known leaf/postlude/owner contract mandatory')
    platform = inputs.json(rc['platform_review'])
    need(platform['schema'] == 'ROOT-primitive-discovery-known-topology-platform-review-v1'
         and platform['source_only'] is True and platform['known_leaf_scope_reviewed'] is True
         and platform['closed52_postlude_scope_reviewed'] is True
         and platform['reserve_is_prospective_conditional'] is True,
         'fresh proof leaf native/transitive scope, no old static scope substitution')
    inputs.equivalent(platform['worker'], p['sources']['worker'], 'platform review exact new leaf')
    same(platform['postlude_reserve_bytes'], POSTLUDE_RESERVE, 'same reviewed postlude reserve')
    outer_contract = inputs.json(rc['outer_terminal_contract'])
    need(outer_contract['schema'] == 'ROOT-primitive-discovery-prospective-terminal-contract-v1'
         and outer_contract['once_only'] is True and outer_contract['selector'] == p['selector']
         and outer_contract['mode'] == p['mode'] and outer_contract['cold_inclusive'] is True
         and outer_contract['caller_limit_seconds'] == 180,
         'exact reviewed external terminal boundary required, not proof or OS attestation')
    same(outer_contract['owned_limits'],OWNED_LIMITS,'same complete owned envelope')
    inputs.equivalent(outer_contract['worker'],p['sources']['worker'],'outer contract exact leaf')
    inputs.equivalent(outer_contract['owner_source'],rc['owner_source'],'same reviewed owner bytes')
    inputs.tree(outer_contract)
    inputs.tree(platform); inputs.tree(rc)
    expected_activation = {'schema':ACTIVATION,'authorized':True,'plan':ppin,
        'qualification':p['qualification'],'source_review':p['source_review'],'helper_review':p['helper_review'],
        'observer_review':p['observer_review'],
        'selector':p['selector'],'mode':p['mode'],'phase':'primitive-discovery',
        'owned_limits':OWNED_LIMITS,'search_limits':SEARCH_LIMITS,
        'expected_inventory_binding_sha256':digest(p['expected_inventory_binding']),
        'consumer_binding_sha256':digest(p['consumer_binding']),
        'family_registry_binding_sha256':digest(p['family_registry_binding']),
        'no_supplied_proof_route':True,'new_training':False,'all_five_qualification':False}
    same(a, expected_activation, 'exact separately ROOT-issued once-only activation')
    closure_map = {item['path']:item for item in p['closure']}
    for declared, record in inputs.pins.items():
        if declared not in (ppin['path'],apin['path']):
            need(declared in closure_map, 'whole admitted source/input/resource/review closure has no missing raw pin')
            same(closure_map[declared],record,'exact repeated full-closure spelling/hash')
    directory = Path(p['output_directory'])
    need(directory.is_absolute() and directory == directory.resolve() and ROOT in directory.parents
         and directory.parts[len(ROOT.parts)] == '.gcts-active' and not directory.exists(),
         'exclusive absent ROOT-owned output namespace; no stale certificate/UNKNOWN salvage')
    # Reject cached project modules before importing the first bound source.
    for module in tuple(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name and ROOT in Path(name).resolve().parents and Path(name).suffix == '.py':
            need(Path(name).resolve() == Path(__file__).resolve(), 'cold leaf, no hidden preloaded scientific module')
    inputs.close(); boundary('pre-import complete admission')
    return p, ppin, apin, inputs, header, dimensions, model_epoch


def load(record, name, inputs):
    path = inputs.verify(record)
    need(name not in sys.modules, 'fresh explicit source load')
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, 'explicit bound Python source')
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module
    raw = path.read_bytes()
    need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
         'compile exactly the complete currently pinned raw source buffer, never cached pyc')
    exec(compile(raw, str(path), 'exec'), module.__dict__); inputs.verify(record)
    return module


def source_cache_gate(inputs, sources):
    ledger = []
    allowed = {str(inputs.verify(value).resolve()):value for value in sources.values()}
    for module in tuple(sys.modules.values()):
        name = getattr(module,'__file__',None)
        if name and Path(name).suffix == '.py' and ROOT in Path(name).resolve().parents:
            path = str(Path(name).resolve())
            need(path in allowed, 'unfrozen transitive project import')
            inputs.verify(allowed[path])
            ledger.append({'module_name':module.__name__,'source_pin':allowed[path]})
    return sorted(ledger,key=lambda row:(row['source_pin']['path'],row['module_name']))


def write_new(path, value, *, compressed=False):
    path = Path(path)
    with path.open('xb') as raw:
        if compressed:
            with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as stream:
                for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,
                                             allow_nan=False).iterencode(value):
                    stream.write(part.encode('utf8'))
                stream.write(b'\n')
        else:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,
                                         allow_nan=False).iterencode(value):
                raw.write(part.encode('utf8'))
            raw.write(b'\n')
    return pin(path)


def value_state(value):
    """Detect ordinary namespace/default mutation without accepting origin claims."""
    if value is None or type(value) in (str, int, bool, float, list, dict, tuple):
        try: return canonical(value)
        except (TypeError, ValueError): pass
    return None

def executable_state(module, *, class_roots=()):
    state = []; namespaces = []; mros = []; seen_classes = set()
    def keys(owner):
        return tuple(k for k in vars(owner) if not k.startswith('__') and k not in ('_NEXT_CAPSULE','CANCELLED','FAILURE_PHASE','FAILURE_GATE'))
    def add(owner, name, value):
        if isinstance(value, (staticmethod, classmethod)): value = value.__func__
        code = value.__code__ if inspect.isfunction(value) else None
        defaults = (value_state(value.__defaults__), value_state(value.__kwdefaults__)) if code else None
        closure = tuple((cell.cell_contents, value_state(cell.cell_contents))
                        for cell in (value.__closure__ or ())) if code else None
        state.append((owner, name, value, code, defaults, closure, value_state(value)))
        if isinstance(value, property):
            # The descriptor object can stay unchanged while its getter code mutates.
            for accessor in ('fget', 'fset', 'fdel'):
                add(value, accessor, getattr(value, accessor))
    def record_class(value):
        # Generated methods may dispatch through super() or a captured base_type.
        # Preserve every actual MRO class/method, not just that class object's ID.
        for parent in value.__mro__:
            if parent is object or parent in seen_classes: continue
            seen_classes.add(parent); mros.append((parent, parent.__mro__))
            namespaces.append((parent, keys(parent)))
            for field, child in vars(parent).items():
                if field not in ('__dict__', '__weakref__'): add(parent, field, child)
    namespaces.append((module, keys(module)))
    for name, value in vars(module).items():
        if name.startswith('__') or name in ('_NEXT_CAPSULE','CANCELLED','FAILURE_PHASE','FAILURE_GATE'): continue
        add(module, name, value)
        if isinstance(value, type) and value.__module__ == module.__name__:
            record_class(value)
    for value in class_roots:
        need(isinstance(value, type), 'actual generated endpoint class')
        record_class(value)
    return namespaces, state, mros

def unchanged_executable(state):
    namespaces, records, mros = state
    for owner, original_mro in mros:
        need(owner.__mro__ == original_mro and all(a is b for a, b in zip(owner.__mro__, original_mro)),
             'compiled generated endpoint inheritance changed')
    for owner, names in namespaces:
        need(tuple(k for k in vars(owner) if not k.startswith('__') and k not in ('_NEXT_CAPSULE','CANCELLED','FAILURE_PHASE','FAILURE_GATE')) == names,
             'compiled namespace gained or lost bindings')
    for owner, name, original, code, defaults, closure, data in records:
        actual = getattr(owner, name) if isinstance(owner, property) else vars(owner).get(name)
        if isinstance(actual, (staticmethod, classmethod)): actual = actual.__func__
        need(actual is original, 'compiled namespace/function identity changed')
        if code is not None:
            need(actual.__code__ is code and
                 (value_state(actual.__defaults__), value_state(actual.__kwdefaults__)) == defaults,
                 'compiled executable/defaults changed; co_filename is insufficient')
            current = actual.__closure__ or ()
            need(len(current) == len(closure) and all(cell.cell_contents is old and value_state(cell.cell_contents) == text
                 for cell, (old, text) in zip(current, closure)), 'compiled source closure changed')
        if data is not None: need(value_state(actual) == data, 'compiled source constant changed')

def work(plan_path, activation_path):
    FAILURE_PHASE[0] = 'metadata-admission'
    admission_started = time.perf_counter()
    p, ppin, apin, inputs, header, dimensions, model_epoch = preflight(plan_path,activation_path)
    admission_seconds = time.perf_counter() - admission_started
    FAILURE_PHASE[0] = 'bound-source-import'
    import_started = time.perf_counter()
    own_state = executable_state(sys.modules[__name__])
    guard_fn = unchanged_executable; guard_code = guard_fn.__code__
    need_fn = need; need_code = need_fn.__code__
    modules = {}; module_states = []
    variant = scientific_variant(p)
    family_lane = p['family_registry_binding'] is not None
    for role,value in p['sources'].items():
        if role in ('worker','master') or (role == 'family_advice' and not family_lane):
            continue
        modules[role] = load(value, 'fresh_first_proof_' + role, inputs)
        module_states.append(executable_state(modules[role]))
        if (unchanged_executable is not guard_fn or guard_fn.__code__ is not guard_code
                or need is not need_fn or need_fn.__code__ is not need_code):
            raise ValueError('original cold validator/rejection endpoint changed')
        guard_fn(own_state)
        for state in module_states:
            guard_fn(state)
    module_anchors = dict(modules)
    source_cache_gate(inputs,p['sources'])
    # The independently authored metadata helper repeats full qualification
    # authentication, before constructing the dynamic model. No selected proof
    # or certificate is supplied to this function.
    FAILURE_PHASE[0] = 'context-recheck'
    cert = modules['certificate']; final_cert = modules['final_certificate']
    closed = cert.ClosedInputs(); closed_type_anchor = type(closed)
    closed_methods = effective_methods(closed)
    q = closed.json(p['qualification'])
    admitted_header, _, _, _, _, _ = cert.admitted_context(closed,q)
    same(admitted_header,header,'independent helper repeats same complete admission')
    core = modules['point_core']; compact = modules['compact_graph']; decoder = modules['compact_decoder']
    dynamic = modules['dynamic_graph_adapter']; lifecycle = modules['dynamic_lifecycle_adapter']
    dfs = modules['streamed_dfs']; overlay = modules['streamed_overlay']
    runtime_roles = ('point_core','compact_graph','compact_decoder','dynamic_graph_adapter','dynamic_lifecycle_adapter')
    runtime_sources = [{'role':role,**p['sources'][role]} for role in runtime_roles]
    graph_type = dynamic.make_dynamic_graph_type(core,compact,decoder,runtime_sources=runtime_sources)
    boundary('before graph initialization')
    FAILURE_PHASE[0] = 'graph-construction'
    graph_started = time.perf_counter(); graph = graph_type(header_pin=q['catalog'])
    graph_seconds = time.perf_counter() - graph_started
    catalog_anchor = graph.catalog; catalog_type_anchor = type(catalog_anchor)
    graph_methods = effective_methods(graph); catalog_methods = effective_methods(catalog_anchor)
    module_states.append(executable_state(dynamic, class_roots=(graph_type, catalog_type_anchor)))
    same(graph.model_epoch,model_epoch,'dynamic model exact already admitted original epoch')
    same(graph.catalog.header,header,'entire immutable admitted header, no registry subset')
    FAILURE_PHASE[0] = 'authority-and-pool'
    life = lifecycle.make_lifecycle(core,graph_type)
    body_type_anchor, controller_type_anchor = life.BodyAuthority, life.Controller
    module_states.append(executable_state(lifecycle, class_roots=(body_type_anchor,controller_type_anchor)))
    authority = life.BodyAuthority.build(graph,p['body_source_bindings']['records'],[])
    need(authority.bodies == ()
         and len(graph.recipes) == dimensions['primitive_license_count']
         and len(graph.formulas) == dimensions['formula_count'],
         'no supplied proof bodies/lemmas, complete primitive inventory')
    control = life.Controller(graph,authority,[])
    authority_methods = effective_methods(authority); controller_methods = effective_methods(control)
    actual_binding = dfs.complete_inventory_binding(graph,authority,control,dimensions,core)
    same(actual_binding,p['expected_inventory_binding'],'reconstructed exact ROOT-predeclared empty complete inventory')
    need(control.descriptors == () and control.states == []
         and core.json.loads(control.root_rejected_text) == [], 'complete empty registry, never a rejected/truncated pool')
    observer_module = modules['proof_observer']
    # Wire construction/licence scans are timed inside DFS, never pre-search.
    wire = None
    graph_anchor, graph_type_anchor, closed_anchor, wire_anchor = graph, graph_type, closed, wire
    checker_anchor = modules['logical_oracle'].GroundChecker
    header_text = canonical(header); plan_text = canonical(p); q_text = canonical(q)
    def source_guard():
        # Bootstrap rejection does not call the potentially rebound validator/need.
        if (source_guard is not callback_anchor or source_guard.__code__ is not callback_code
                or unchanged_executable is not guard_fn or guard_fn.__code__ is not guard_code
                or need is not need_fn or need_fn.__code__ is not need_code):
            raise ValueError('original cold validator/rejection endpoint changed')
        guard_fn(own_state)
        for state in module_states:
            guard_fn(state)
        need(set(modules) == set(module_anchors)
             and all(modules[role] is original for role,original in module_anchors.items())
             and graph is graph_anchor and type(graph) is graph_type_anchor
             and graph.catalog is catalog_anchor and type(graph.catalog) is catalog_type_anchor
             and closed is closed_anchor and type(closed) is closed_type_anchor is cert.ClosedInputs
             and wire is wire_anchor is None
             and modules['logical_oracle'].GroundChecker is checker_anchor
             and canonical(header) == header_text,
             'exact original graph/reader/wire/checker/header endpoints, never supplied substitutes')
        need(life.BodyAuthority is body_type_anchor and life.Controller is controller_type_anchor
             and type(authority) is body_type_anchor and type(control) is controller_type_anchor
             and effective_methods(closed) == closed_methods
             and effective_methods(graph) == graph_methods
             and effective_methods(graph.catalog) == catalog_methods
             and effective_methods(authority) == authority_methods
             and effective_methods(control) == controller_methods
             and canonical(p) == plan_text and canonical(q) == q_text,
             'unchanged effective generated/class/property/method endpoints and metadata; graph data may evolve')
        ledger = source_cache_gate(inputs,p['sources']); validate_execution_ledger(p,ledger)
        admitted_modules = (sys.modules[__name__], *module_anchors.values())
        for module in tuple(sys.modules.values()):
            name = getattr(module,'__file__',None)
            if name and Path(name).suffix == '.py' and ROOT in Path(name).resolve().parents:
                need(any(module is item for item in admitted_modules), 'no injected/co_filename-only project module')
        inputs.close(); closed.close()
        boundary('guarded fresh observer/scientific boundary')
    # Seal the actual nested callback, not merely top-level work() code.
    callback_anchor = source_guard; callback_code = callback_anchor.__code__
    callback_defaults = callback_anchor.__defaults__; callback_kwdefaults = callback_anchor.__kwdefaults__
    callback_cells = callback_anchor.__closure__
    callback_values = tuple(cell.cell_contents for cell in (callback_cells or ()))
    def invoke_guard():
        if invoke_guard is not invoke_anchor or invoke_guard.__code__ is not invoke_code:
            raise ValueError('original checked callback shim identity/code changed')
        if (source_guard is not callback_anchor or callback_anchor.__code__ is not callback_code
                or callback_anchor.__defaults__ is not callback_defaults
                or callback_anchor.__kwdefaults__ is not callback_kwdefaults
                or callback_anchor.__closure__ is not callback_cells
                or len(callback_anchor.__closure__ or ()) != len(callback_values)
                or any(cell.cell_contents is not value for cell,value in
                       zip(callback_anchor.__closure__ or (),callback_values))):
            raise ValueError('original nested source guard function/code/default/closure changed')
        callback_anchor()
        if (source_guard is not callback_anchor or callback_anchor.__code__ is not callback_code
                or callback_anchor.__defaults__ is not callback_defaults
                or callback_anchor.__kwdefaults__ is not callback_kwdefaults
                or callback_anchor.__closure__ is not callback_cells
                or any(cell.cell_contents is not value for cell,value in zip(callback_anchor.__closure__ or (),callback_values))
                or invoke_guard is not invoke_anchor or invoke_guard.__code__ is not invoke_code):
            raise ValueError('original callback/shim changed during delegation')
    invoke_anchor = invoke_guard; invoke_code = invoke_anchor.__code__
    invoke_defaults = invoke_anchor.__defaults__; invoke_kwdefaults = invoke_anchor.__kwdefaults__
    invoke_cells = invoke_anchor.__closure__
    invoke_values = tuple(cell.cell_contents for cell in (invoke_cells or ()))
    if (invoke_guard is not invoke_anchor or invoke_anchor.__code__ is not invoke_code
            or invoke_anchor.__defaults__ is not invoke_defaults
            or invoke_anchor.__kwdefaults__ is not invoke_kwdefaults
            or invoke_anchor.__closure__ is not invoke_cells
            or len(invoke_anchor.__closure__ or ()) != len(invoke_values)
            or any(cell.cell_contents is not value for cell,value in
                   zip(invoke_anchor.__closure__ or (),invoke_values))):
        raise ValueError('original nested guard invocation shim changed')
    invoke_anchor()
    overlay.check_consumer_binding(p['consumer_binding'],graph,core,modules['features31'],modules['policy_math'],
                                   dfs_function=dfs.search_episode,
                                   proof_observer_class=observer_module.FirstCheckedProofObserver,
                                   family_session_class=modules['family_advice'].FamilySession if family_lane else None)
    construction_seconds = time.perf_counter() - import_started
    source_cache_gate(inputs,p['sources']); inputs.close(); closed.close()
    boundary('before search and exclusive output')
    # Only after full admission, source loading and cold construction succeed
    # may the first exclusive namespace be created. All costs stay in one leaf.
    directory = Path(p['output_directory']); directory.mkdir(parents=False,exist_ok=False)
    costs = {'worker_clock_origin':'emitter-local perf_counter; cross-process origins never compared',
        'complete_static_prerequisite_pins':{'producer':q['producer'],'independent':q['independent']},
        'current_metadata_admission_seconds':admission_seconds,
        'current_import_and_complete_cold_construction_seconds':construction_seconds,
        'current_graph_initialization_seconds':graph_seconds,
        'static_producer_and_audit_costs':'Separate historical accepted phases bound by ROOT decisions; not hidden or included in current20s search timer'}
    # Both modes load the same exact sources and empty authority provenance.
    # Canonical base has no advice; seed_forward uses ordinary or separately admitted family advice.
    # No authored body, proof route, RNG or training. The unchanged graph still
    # owns global dead/forced/earliest decisions and the full primitive domain.
    FAILURE_PHASE[0] = 'finite-base-search'
    result = dfs.search_episode(graph,authority,[],life,overlay,modules['features31'],modules['policy_math'],
        episode_id='fresh-first-proof/' + p['selector'] + '/' + p['mode'],mode=p['mode'],seed=None,
        weights={name:0.0 for name in modules['features31'].FEATURE_NAMES},
        attempts=128,seconds=20,event_ceiling=2000,
        prerequisite_pins={'qualified_context':p['qualification'],'plan':ppin,'activation':apin},
        cold_preparation_costs=costs,qualified_dimensions=dimensions,
        expected_inventory_binding=p['expected_inventory_binding'],consumer_binding=p['consumer_binding'],
        advice_module=(modules['family_advice'] if family_lane else modules['candidate_advice']) if p['mode'] == 'seed_forward' else None,
        advice_source_binding=p['sources']['family_advice' if family_lane else 'candidate_advice'] if p['mode'] == 'seed_forward' else None,
        advice_library_admission=p['family_registry_binding']['library_admission'] if family_lane else None,
        family_registry_binding=p['family_registry_binding'],
        observer_module=observer_module, observer_source_binding=p['sources']['proof_observer'],
        observer_inputs=dict(reader=cert,wire=wire,checker_class=checker_anchor,closed=closed,header=header,
            license_pin=q['independent']['licenses'],source_guard=invoke_guard))
    if (invoke_guard is not invoke_anchor or invoke_anchor.__code__ is not invoke_code
            or invoke_anchor.__defaults__ is not invoke_defaults
            or invoke_anchor.__kwdefaults__ is not invoke_kwdefaults
            or invoke_anchor.__closure__ is not invoke_cells
            or len(invoke_anchor.__closure__ or ()) != len(invoke_values)
            or any(cell.cell_contents is not value for cell,value in
                   zip(invoke_anchor.__closure__ or (),invoke_values))):
        raise ValueError('original nested guard invocation shim changed')
    invoke_anchor()
    boundary('after finite search')
    need(result['mode'] == p['mode'] and result['seed'] is None and result['rng_draws'] == []
         and result['policy_choices'] == [] and result['commits'] == []
         and result['training_updates'] == 0 and result['registered_whole_descriptor_count'] == 0,
         'automatic primitive-only deterministic pair lane, no learned operation or RNG')
    same(result['candidate_advice']['family_registry_binding'], p['family_registry_binding'], 'actual family registry equals predeclared scientific lane')
    same(result['candidate_advice']['family_registry_binding_sha256'],
         digest(p['family_registry_binding']) if family_lane else None, 'actual family registry digest')
    # Save EVERY event, state, order descriptor, error/prefix, point certificate
    # and return field unchanged. An UNKNOWN prefix remains an UNKNOWN artifact.
    FAILURE_PHASE[0] = 'first-proof-return-binding'
    binding_started = time.perf_counter()
    same(result['proof_observer']['source_binding'],p['sources']['proof_observer'],
         'returned full observer record binds the exact timed source')
    logical = observer_module.verify_returned_proof(result)
    logical_binding_seconds = time.perf_counter() - binding_started
    if (invoke_guard is not invoke_anchor or invoke_anchor.__code__ is not invoke_code
            or invoke_anchor.__defaults__ is not invoke_defaults
            or invoke_anchor.__kwdefaults__ is not invoke_kwdefaults
            or invoke_anchor.__closure__ is not invoke_cells
            or len(invoke_anchor.__closure__ or ()) != len(invoke_values)
            or any(cell.cell_contents is not value for cell,value in
                   zip(invoke_anchor.__closure__ or (),invoke_values))):
        raise ValueError('original nested guard invocation shim changed')
    invoke_anchor()
    first_proof = result['status'] == 'first_checked_original_Gamma_target_proof'
    if first_proof:
        need(type(logical) is dict
             and logical['schema'] == 'first-checked-original-Gamma-target-primitive-patch-v1'
             and logical['origin_kind'] in ('actual_selected','completed_source_proposal')
             and logical['original_Gamma_target_sequent_accepted'] is True
             and logical['primary_endpoint_eligible'] is True
             and logical['prospective_current_point_union_accepted'] is True
             and logical['full24_board_accepted'] is False and logical['native_accepted'] is False
             and logical['full_trajectory_accepted'] is False
             and logical['actual_selected_target_accepted'] is (logical['origin_kind'] == 'actual_selected'),
             'timed checked logical endpoint, exact selected/proposed scope and no fullboard/native relabeling')
        same(logical['patch']['exact_original_ordered_gamma'],header['context']['ordered_local_premises'],
             'checked patch retains every original Gamma occurrence')
        same(logical['patch']['conclusion'],header['target'],'same fresh target')
        need(result['point_certificate'] is None and not result['primitive_certificate_accepted'],
             'logical stopping never creates a full24 point certificate')
    else:
        need(logical is None,'nonlogical terminal cannot salvage a checked prefix')
    # Preserve the entire returned tape, including all observer observations.
    FAILURE_PHASE[0] = 'result-serialization'
    result_pin = write_new(directory/OUTPUT_NAMES[0],result,compressed=True)
    logical_certificate_pin = None
    if first_proof:
        logical_certificate_pin = write_new(directory/OUTPUT_NAMES[3],{
            'schema':'fresh-equality-first-proof-saved-certificate-v1',
            'qualification_pin':p['qualification'],'result_pin':result_pin,
            'observer_source':p['sources']['proof_observer'],'observer_review':p['observer_review'],
            'checked_patch':logical,'checked_patch_sha256':digest(logical),
            'original_Gamma_target_sequent_accepted':True,
            'origin_kind':logical['origin_kind'],
            'actual_selected_target_accepted':logical['origin_kind']=='actual_selected',
            'completed_source_proposal_target_accepted':logical['origin_kind']=='completed_source_proposal',
            'full24_board_accepted':False,'native_accepted':False,'full_trajectory_accepted':False,
            'metadata_binding_only_after_timed_check':True,
            'metadata_binding_seconds':logical_binding_seconds})
    certificate_pin = None; certificate_accepted = False; checker_seconds = 0.0
    if result['status'] == 'finite_exact_point_tiling':
        boundary('before independent final certificate')
        FAILURE_PHASE[0] = 'final-certificate'
        check_started = time.perf_counter()
        checked = final_cert.verify_saved_certificate(result_pin=result_pin,
            qualification_pin=p['qualification'],checker_class=modules['logical_oracle'].GroundChecker,
            expected_mode=p['mode'],expected_variant=variant,
            family_registry_binding=p['family_registry_binding'])
        checker_seconds = time.perf_counter()-check_started
        need(checked['status'] == 'accepted_independent_final_primitive_certificate'
             and checked['original_ground_sequent_accepted'] is True
             and checked['whole_t_and_remote_m_accepted'] is True,
             'independent final primitive proof/whole point certificate required')
        if (invoke_guard is not invoke_anchor or invoke_anchor.__code__ is not invoke_code
                or invoke_anchor.__defaults__ is not invoke_defaults
                or invoke_anchor.__kwdefaults__ is not invoke_kwdefaults
                or invoke_anchor.__closure__ is not invoke_cells
                or len(invoke_anchor.__closure__ or ()) != len(invoke_values)
                or any(cell.cell_contents is not value for cell,value in
                       zip(invoke_anchor.__closure__ or (),invoke_values))):
            raise ValueError('original nested guard invocation shim changed')
        invoke_anchor()
        boundary('after independent final certificate')
        certificate_pin = write_new(directory/OUTPUT_NAMES[1],checked)
        certificate_accepted = True
    elif not first_proof:
        need(result['point_certificate'] is None and not result['primitive_certificate_accepted'],
             'UNKNOWN/exhausted result earns no certificate or terminal proof bonus')
    execution_source_ledger = source_cache_gate(inputs,p['sources']); validate_execution_ledger(p,execution_source_ledger)
    inputs.close(); closed.close()
    FAILURE_PHASE[0] = 'final-receipt'
    boundary('before final receipt')
    receipt = {'schema':RECEIPT,'status':'complete_candidate_pending_ROOT_owned_resources',
        'stage':'primitive-discovery','stage_completed':True,'selector':p['selector'],'mode':p['mode'],
        'plan':ppin,'activation':apin,'qualification':p['qualification'],'worker':p['sources']['worker'],
        'advice_variant':variant,'family_registry_binding':p['family_registry_binding'],
        'family_registry_binding_sha256':digest(p['family_registry_binding']),
        'ROOT_complete_controls_disposition':ROOT_COMPLETE_FAMILY_CONTROLS,
        'result':result_pin,'certificate':certificate_pin,'final_certificate_checked':certificate_accepted,
        'first_proof_certificate':logical_certificate_pin,'first_proof_checked':first_proof,
        'first_proof_origin_kind':logical['origin_kind'] if first_proof else None,
        'first_proof_binding_seconds':logical_binding_seconds,
        'first_proof_source':p['sources']['proof_observer'],
        'executed_project_source_ledger':execution_source_ledger,
        'certificate_check_seconds':checker_seconds,'search_status':result['status'],
        'trace_complete':result['trace_complete'],'qualified_dimensions':dimensions,
        'complete_inventory_binding':actual_binding,'consumer_binding':p['consumer_binding'],
        'metadata_admission_seconds':admission_seconds,'cold_import_and_construction_seconds':construction_seconds,
        'direct_children_peak_sum_bytes':0,'all_direct_children_terminal_and_reaped':True,
        'RNG_draws':0,'new_RL_training':False,'native_queries':0,'atomic_macro_moves':0,
        'proof_bonus_awarded':False,'training_updates':0,'full_resource_accepted':False,
        'independent_full_trajectory_accepted':False,'performance_comparison_accepted':False,
        'all_five_qualification':False,'universal_compiler_accepted':False,
        'worker_seconds_before_receipt_serialization':time.perf_counter()-ENTRY,
        'remaining_postlude':'Closed receipt, fixed52 role1 SELF frame then os._exit; ROOT must bind actual terminal and complete cold resource scope with prospective32MiB reserve'}
    write_new(directory/OUTPUT_NAMES[2],receipt)
    boundary('after all artifact close')
    return p


def emit_failure_diagnostic(exc):
    """One best-effort bounded private record; never an acceptance artifact."""
    category = 'other_exception'
    for expected, label in ((ValueError, 'value_error'), (KeyError, 'key_error'),
            (TypeError, 'type_error'), (OSError, 'os_error'),
            (FileNotFoundError, 'file_not_found'), (PermissionError, 'permission_error'),
            (RuntimeError, 'runtime_error'), (MemoryError, 'memory_error'),
            (OverflowError, 'overflow_error'), (AssertionError, 'assertion_error')):
        if type(exc) is expected:
            category = label
            break
    phase = FAILURE_PHASE[0]
    if type(phase) is not str or phase not in ('entry','metadata-admission',
            'bound-source-import','context-recheck','graph-construction',
            'authority-and-pool','finite-base-search','result-serialization',
            'first-proof-return-binding','final-certificate','final-receipt'):
        phase = 'unknown-phase'
    gate = FAILURE_GATE[0]
    if type(gate) is not str or not (gate == 'none' or
            (len(gate) == 16 and all(c in '0123456789abcdef' for c in gate))):
        gate = 'none'
    raw = (canonical({'schema':'compact-primitive-base-worker-failure-diagnostic-v1',
        'status':'UNKNOWN_worker_exception','diagnostic_only':True,
        'phase':phase,'exception_category':category,
        'gate_sha256_prefix16':gate}) + '\n').encode('ascii')
    if len(raw) <= 512:
        os.write(2, raw)


def main():
    need(len(sys.argv) == 3, 'exact ROOT future plan and separate activation, no proof route arguments')
    for signum in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):
        signal.signal(signum,cancel)
    signal.alarm(170)
    code = 1
    try:
        work(Path(sys.argv[1]),Path(sys.argv[2])); code = 0
    except Exception as exc:
        # Do not render exception args, paths, formulas, source or traceback.
        # A failed diagnostic write stays nonzero and cannot bypass the frame.
        try:
            emit_failure_diagnostic(exc)
        except Exception:
            pass
    finally:
        # Fixed transport has no child launch. A failing preflight cannot be
        # saved as a qualifying completed worker. Any final failure is nonzero.
        if FAILURE_PHASE[0] in ('entry','metadata-admission'):
            # Scope rejection must occur before ANY project Source execution.
            # No success frame/prefix: owner still directly wait4-reaps exit1.
            os._exit(1)
        transport_pin = FROZEN_SOURCES['transport']
        inputs = Inputs(); transport = load(transport_pin,'primitive_discovery_final_transport',inputs)
        if CANCELLED[0] or time.perf_counter()-ENTRY >= 170:
            code = 1
        transport.emit_closed_SELF_and_exit(1,ENTRY,code)


if __name__ == '__main__':
    main()
