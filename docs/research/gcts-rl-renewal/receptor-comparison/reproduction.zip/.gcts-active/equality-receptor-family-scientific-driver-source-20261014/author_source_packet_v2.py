"""Stdlib-only additive SOURCE polish; no emitted module or scientific call."""
import ast, copy, difflib, hashlib, json
from pathlib import Path
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
A='/root/hilbert_advice_controls'
def pin(p):
 b=Path(p).read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(p):return json.loads(Path(p).read_bytes())
def save(n,v):
 p=D/n;assert not p.exists();p.write_text(v if isinstance(v,str) else json.dumps(v,indent=2,sort_keys=True)+'\n');return pin(p)
def rep(s,a,b):assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
def top(s,n,v):
 t=ast.parse(s);node=next(k for k in t.body if isinstance(k,ast.Assign) and any(isinstance(t,ast.Name) and t.id==n for t in k.targets));lines=s.splitlines(keepends=True);return ''.join(lines[:node.lineno-1])+n+' = '+repr(v)+'\n'+''.join(lines[node.end_lineno:])
def remove(s,n):
 node=next(k for k in ast.parse(s).body if isinstance(k,ast.Assign) and any(isinstance(t,ast.Name) and t.id==n for t in k.targets));lines=s.splitlines(keepends=True);return ''.join(lines[:node.lineno-1]+lines[node.end_lineno:])
W0=D/'I2_finite_family_first_proof_worker_v1.py';O0=D/'I2_finite_family_first_proof_owner_v1.py';T0=D/'I2_finite_family_first_proof_terminal_v1.py';C0=D/'leaf-source-contract-v1.json'
W=remove(W0.read_text(),'FROZEN_CONTROL_SOURCES')
W=rep(W,"and evidence['sources'] == FROZEN_CONTROL_SOURCES", "and set(evidence['sources']) == set(FROZEN_SOURCES)|{'worker','mechanism_controls'}\n         and {role:evidence['sources'][role] for role in FROZEN_SOURCES} == FROZEN_SOURCES")
W=rep(W,"    same(result['candidate_advice']['family_registry_binding'], p['family_registry_binding'], 'actual family registry equals predeclared scientific lane')\n    same(result['candidate_advice']['family_registry_binding_sha256'],\n         digest(p['family_registry_binding']) if family_lane else None, 'actual family registry digest')", "    actual_registry = result['candidate_advice']['family_registry_binding']\n    if family_lane and actual_registry is None:\n        need(result['status'].startswith('unknown_') and not result['primitive_certificate_accepted']\n             and result['point_certificate'] is None\n             and result['candidate_advice']['family_registry_binding_sha256'] is None,\n             'unfinished registry construction remains honest UNKNOWN, never accepted family use')\n    else:\n        same(actual_registry,p['family_registry_binding'],'completed actual family registry equals predeclared lane')\n        same(result['candidate_advice']['family_registry_binding_sha256'],\n             digest(actual_registry) if actual_registry is not None else None,'completed actual registry digest')\n    same(result['candidate_advice']['source_binding'],\n         p['sources']['family_advice' if family_lane else 'candidate_advice'] if p['mode']=='seed_forward' else None,\n         'actual selected advice source; no family advice in ordinary/canonical lane')\n    same(result['candidate_advice']['library_admission_pin'],\n         p['family_registry_binding']['library_admission'] if family_lane else None, 'actual advice admission argument')")
W=rep(W,"'family_registry_binding_sha256':digest(p['family_registry_binding']),\n        'ROOT_complete_controls_disposition':ROOT_COMPLETE_FAMILY_CONTROLS,", "'family_registry_binding_sha256':digest(p['family_registry_binding']),\n        'actual_family_registry_binding':actual_registry,\n        'family_registry_construction_completed':actual_registry is not None,\n        'ROOT_complete_controls_disposition':ROOT_COMPLETE_FAMILY_CONTROLS,")
compile(W,str(D/'I2_finite_family_first_proof_worker_v2.py'),'exec');wp=save('I2_finite_family_first_proof_worker_v2.py',W)
c=read(C0);c['source_map']['worker']=wp;c['sources']['worker']=wp;c['selected_wrapper_version']='I2-finite-family-worker-v2';c['predecessor_contract']=pin(C0);c['unknown_return_scope']='Planned registry/admission bound in leaf/activation; actual registry may remain None on pre-construction UNKNOWN. Exact actual completed registry required for positive mathematical result; no prefixes salvaged.';c['current_root_control_sources']='Root complete controls seal raw-authenticates current evidence20; worker requires its18 nonworker scientific role pins equal evidence plus only worker/mechanism extra roles. No duplicate mutable injected control map.'
cp=save('leaf-source-contract-v2.json',c);MAP=c['source_map']
O=remove(O0.read_text(),'FROZEN_CONTROL_SOURCES');O=top(O,'WORKER',wp);O=top(O,'WORKER_CONTRACT',cp);O=top(O,'EXPECTED_SOURCES',MAP)
T=remove(T0.read_text(),'FROZEN_CONTROL_SOURCES');T=top(T,'WORKER',wp);T=top(T,'WORKER_CONTRACT',cp);T=top(T,'EXPECTED_SOURCES',MAP)
for which in ('O','T'):
 s=O if which=='O' else T;obj='r' if which=='O' else 'w'
 needle=f"    validate_execution_ledger(leaf,{obj}['executed_project_source_ledger'])"
 insert=f"    actual_registry={obj}['actual_family_registry_binding']\n    need(type({obj}['family_registry_construction_completed']) is bool\n         and {obj}['family_registry_construction_completed'] is (actual_registry is not None), 'actual completed registry flag')\n    if leaf['family_registry_binding'] is not None and actual_registry is None:\n        need({obj}['search_status'].startswith('unknown_'), 'unfinished actual registry only in UNKNOWN')\n    else:\n        same(actual_registry,leaf['family_registry_binding'],'actual completed registry equals planned scientific lane')\n"+needle
 s=rep(s,needle,insert)
 if which=='O':O=s
 else:T=s
compile(O,str(D/'I2_finite_family_first_proof_owner_v2.py'),'exec');op=save('I2_finite_family_first_proof_owner_v2.py',O)
T=top(T,'OWNER',op);compile(T,str(D/'I2_finite_family_first_proof_terminal_v2.py'),'exec');tp=save('I2_finite_family_first_proof_terminal_v2.py',T)
for label,old,new in [('worker',Path(c['parents_preserved']['ROOT_worker']['path']).with_name('i2_first_proof_worker_v1.py'),Path(wp['path'])),('owner',R/'.gcts-active/hilbert-i2-first-proof-owner-source-20261014/i2_first_proof_owner_v1.py',Path(op['path'])),('terminal',R/'.gcts-active/hilbert-i2-first-proof-owner-source-20261014/i2_first_proof_terminal_v1.py',Path(tp['path']))]:
 save(label+'-source-delta-v2.patch',''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),new.read_text().splitlines(keepends=True),fromfile=str(old),tofile=str(new))))
print(json.dumps(dict(worker=wp,contract=cp,owner=op,terminal=tp),indent=2))
