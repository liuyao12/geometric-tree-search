"""Stdlib-only narrow SOURCE repair; no scientific module/function executes."""
import ast,difflib,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent;A='/root/hilbert_advice_controls'
def pin(p):
 b=Path(p).read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def read(p):return json.loads(Path(p).read_bytes())
def save(n,v):
 p=D/n;assert not p.exists();p.write_text(v if isinstance(v,str) else json.dumps(v,sort_keys=True,indent=2)+'\n');return pin(p)
def rep(s,a,b):assert s.count(a)==1,(a[:90],s.count(a));return s.replace(a,b,1)
def top(s,n,v):
 x=next(x for x in ast.parse(s).body if isinstance(x,ast.Assign) and any(isinstance(k,ast.Name) and k.id==n for k in x.targets));ls=s.splitlines(keepends=True);return ''.join(ls[:x.lineno-1])+n+' = '+repr(v)+'\n'+''.join(ls[x.end_lineno:])
W0=D/'I2_finite_family_first_proof_worker_v3.py';O0=D/'I2_finite_family_first_proof_owner_v3.py';T0=D/'I2_finite_family_first_proof_terminal_v3.py';C0=D/'leaf-source-contract-v3.json'
c=read(C0);S=c['source_map'];df=ast.parse(Path(S['streamed_dfs']['path']).read_bytes());dfsver=ast.literal_eval(next(n.value for n in df.body if isinstance(n,ast.Assign) and any(isinstance(k,ast.Name) and k.id=='VERSION' for k in n.targets)))
old='compact24-first-checked-proof-scientific-DFS-v11-source';assert dfsver=='compact24-I2-finite-family-first-checked-proof-scientific-DFS-v12-source'
constants='\nDFS12_RETURN_SCHEMA = '+repr(dfsver)+'\nOBSERVER11_RETURN_SCHEMA = '+repr(old)+'\nRETURN_ADAPTER_SCHEMA = \'explicit-DFS12-to-observer11-return-binding-metadata-adapter-v1\'\n'
adapter='''
def verify_DFS12_return_with_observer11_metadata(result, result_pin, observer_module):
    """Explicit read-only legacy metadata view, never a mathematical replay.

    The complete original result has already been serialized unchanged as v12.
    Only the temporary top-level schema string differs for ad2's pure metadata
    verifier. Every other value remains the same object; hashes and shape are
    checked before/after. This view is not the producer result or a proof input.
    """
    boundary('before explicit DFS12/observer11 metadata adapter')
    need(type(result) is dict and result.get('schema') == DFS12_RETURN_SCHEMA
         and observer_module.VERSION == 'passive-first-checked-original-Gamma-target-observer-v2',
         'exact current DFS12 returned schema and unchanged admitted observer')
    original_sha = digest(result)
    view = dict(result); view['schema'] = OBSERVER11_RETURN_SCHEMA
    need(set(view) == set(result)
         and all(view[k] is result[k] for k in result if k != 'schema'),
         'complete metadata view changes only disclosed schema field')
    view_sha = digest(view)
    logical = observer_module.verify_returned_proof(view)
    need(digest(result) == original_sha and digest(view) == view_sha
         and result['schema'] == DFS12_RETURN_SCHEMA
         and all(view[k] is result[k] for k in result if k != 'schema'),
         'original complete tape and metadata view unchanged during binding')
    record = dict(schema=RETURN_ADAPTER_SCHEMA,metadata_only=True,
        original_result=result_pin,original_result_schema=DFS12_RETURN_SCHEMA,
        verifier_view_schema=OBSERVER11_RETURN_SCHEMA,
        original_complete_result_sha256=original_sha,verifier_view_sha256=view_sha,
        changed_top_level_fields=['schema'],complete_top_level_field_count=len(result),
        original_result_unchanged=True,all_other_field_values_preserved=True,
        metadata_binding_completed=True,mathematical_check_replayed=False,
        producer_schema_relabelled=False,source_tape_saved_before_binding=True)
    boundary('after complete explicit metadata adapter/record preparation')
    return logical,record
'''
validate='''
def validate_return_adapter(record, result_pin):
    """Saved metadata binding only; never replays logic or alters result schema."""
    need(type(record) is dict and record['schema'] == RETURN_ADAPTER_SCHEMA
         and record['metadata_only'] is True and record['original_result'] == result_pin
         and record['original_result_schema'] == DFS12_RETURN_SCHEMA
         and record['verifier_view_schema'] == OBSERVER11_RETURN_SCHEMA
         and record['changed_top_level_fields'] == ['schema']
         and record['original_result_unchanged'] is True
         and record['all_other_field_values_preserved'] is True
         and record['metadata_binding_completed'] is True
         and record['mathematical_check_replayed'] is False
         and record['producer_schema_relabelled'] is False
         and record['source_tape_saved_before_binding'] is True,
         'exact explicit current metadata-only schema adapter; original v12 never relabelled')
'''
W=W0.read_text();W=rep(W,'\n\ndef work(',constants+'\n'+adapter+'\n\ndef work(')
# Persist returned data immediately, before any guarded return-binding can fail.
W=rep(W,"            license_pin=q['independent']['licenses'],source_guard=invoke_guard))\n    if (invoke_guard", "            license_pin=q['independent']['licenses'],source_guard=invoke_guard))\n    # This raw v12 tape is diagnostic until all later bindings/resources pass.\n    # Saving a producer-positive flag here grants no receipt or accepted prefix.\n    FAILURE_PHASE[0] = 'result-serialization'\n    result_pin = write_new(directory/OUTPUT_NAMES[0],result,compressed=True)\n    boundary('after entire original returned tape close, before any return binding')\n    if (invoke_guard")
W=rep(W,"    logical = observer_module.verify_returned_proof(result)", "    logical,return_adapter = verify_DFS12_return_with_observer11_metadata(result,result_pin,observer_module)")
W=rep(W,"    # Preserve the entire returned tape, including all observer observations.\n    FAILURE_PHASE[0] = 'result-serialization'\n    result_pin = write_new(directory/OUTPUT_NAMES[0],result,compressed=True)\n", "    # The entire original v12 tape was already closed before metadata binding.\n    FAILURE_PHASE[0] = 'result-serialization'\n")
W=rep(W,"            'metadata_binding_seconds':logical_binding_seconds})", "            'metadata_binding_seconds':logical_binding_seconds,\n            'proof_return_binding_adapter':return_adapter})")
W=rep(W,"        'first_proof_source':p['sources']['proof_observer'],", "        'first_proof_source':p['sources']['proof_observer'],\n        'proof_return_binding_adapter':return_adapter,")
compile(W,str(D/'I2_finite_family_first_proof_worker_v4.py'),'exec');WP=save('I2_finite_family_first_proof_worker_v4.py',W)
c['source_map']['worker']=WP;c['sources']['worker']=WP;c['selected_wrapper_version']='I2-finite-family-worker-v4';c['predecessor_contract']=pin(C0)
c['return_binding_adapter']={'schema':'explicit-DFS12-to-observer11-return-binding-metadata-adapter-v1','original_result_schema':dfsver,'legacy_verifier_schema':old,'original_observer_unchanged':S['proof_observer'],'operation':'Temporary complete shallow dictionary view, only schema differs; all other values identical, original/view full hashes before/after; original v12 file unchanged.','mathematical_replay':False,'source_tape_save':'Full original tape is serialized immediately after DFS returns, before any later source/variant/observer return binding; absence of final worker receipt makes it an unaccepted diagnostic artifact.','cost_scope':'Whole serialization/hash/view binding is enclosing170/175/180/512MiB cost, not relabelled inner20 search work.'}
CP=save('leaf-source-contract-v4.json',c);MAP=c['source_map']
O=O0.read_text();O=top(O,'WORKER',WP);O=top(O,'WORKER_CONTRACT',CP);O=top(O,'EXPECTED_SOURCES',MAP)
O=rep(O,'\n\ndef source_person_review(',constants+'\n'+validate+'\n\ndef source_person_review(')
O=rep(O,"    root=Path(leaf['output_directory']);need(verify(r['result'])==root/'result-v1.json.gz'", "    validate_return_adapter(r['proof_return_binding_adapter'],r['result'])\n    root=Path(leaf['output_directory']);need(verify(r['result'])==root/'result-v1.json.gz'")
compile(O,str(D/'I2_finite_family_first_proof_owner_v4.py'),'exec');OP=save('I2_finite_family_first_proof_owner_v4.py',O)
T=T0.read_text();T=top(T,'WORKER',WP);T=top(T,'WORKER_CONTRACT',CP);T=top(T,'EXPECTED_SOURCES',MAP);T=top(T,'OWNER',OP)
T=rep(T,'\n\ndef reconcile(',constants+'\n'+validate+'\n\ndef reconcile(')
T=rep(T,"    validate_execution_ledger(leaf,w['executed_project_source_ledger'])", "    validate_return_adapter(w['proof_return_binding_adapter'],w['result'])\n    validate_execution_ledger(leaf,w['executed_project_source_ledger'])")
T=rep(T,"        logical=read(w['first_proof_certificate']);patch=logical['checked_patch']", "        logical=read(w['first_proof_certificate']);patch=logical['checked_patch']\n        same(logical['proof_return_binding_adapter'],w['proof_return_binding_adapter'], 'same disclosed metadata-only return adapter')")
T=rep(T,"        'advice_variant':variant,'family_registry_binding_sha256':digest(leaf['family_registry_binding']),", "        'proof_return_binding_adapter':w['proof_return_binding_adapter'],\n        'advice_variant':variant,'family_registry_binding_sha256':digest(leaf['family_registry_binding']),")
compile(T,str(D/'I2_finite_family_first_proof_terminal_v4.py'),'exec');TP=save('I2_finite_family_first_proof_terminal_v4.py',T)
changes={};patches={}
for role,old,new in [('worker',W0,Path(WP['path'])),('owner',O0,Path(OP['path'])),('terminal',T0,Path(TP['path']))]:
 defs=lambda p:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 a,b=defs(old),defs(new);changes[role]={'previous':pin(old),'current':pin(new),'changed_functions':[k for k in a if a[k]!=b[k]],'unchanged_functions':[k for k in a if a[k]==b[k]],'new_functions':sorted(set(b)-set(a))}
 patches[role]=save(role+'-source-delta-v3-to-v4.patch',''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),new.read_text().splitlines(keepends=True),fromfile=str(old),tofile=str(new))))
assert changes['worker']['changed_functions']==['work'];assert changes['owner']['changed_functions']==['receipt_gate'];assert changes['terminal']['changed_functions']==['reconcile']
for p in MAP.values():assert pin(p['path'])==p
con=save('source-conformance-v4.json',{'schema':'I2-DFS12-observer11-explicit-return-binding-SOURCE-conformance-v4','source_only':True,'author_identity':A,'source_function_calls':0,'project_imports':0,'scientific_calls':0,'tests_executed':0,'syntax_compile_only':True,'changes':changes,'patches':patches,'raw_source_map':MAP,'unchanged_source_roles':18,'all_scientific_engine_sources_unchanged':{k:MAP[k] for k in ('streamed_dfs','streamed_overlay','proof_observer','family_advice','final_certificate','point_core','dynamic_graph_adapter')},'source_review_passed_by_author':False})
h=save('handoff-v4.json',{'schema':'I2-finite-family-scientific-driver-SOURCE-handoff-v4','author_identity':A,'source_only':True,'scientific_calls':0,'source_function_calls':0,'project_imports':0,'tests_executed':0,'worker':WP,'owner':OP,'terminal':TP,'leaf_contract':CP,'source_conformance':con,'predecessor_handoff':pin(D/'handoff-v3.json'),'sources':MAP,'exact_change':'Worker metadata-only adapter explicitly identifies DFS12 original schema and observer11 compatibility view; complete original result saved before all return guards/bindings. Owner/terminal check disclosed provenance plus constant repins. All preflight, mathematical/search/observer/family/point/rollback/scheduler/limits unchanged.','ABI_unchanged':{'source_roles':19,'consumer_roles':7,'leaf_fields':21,'owner_fields':18,'qualification_fields':11,'scientific_grant_fields':21},'current_observer_pin_unchanged':MAP['proof_observer'],'adapter':'No saved producer schema alteration; temporary full shallow view changes only schema; entire original/view data hashed before/after. Mathematical checker not re-executed.','failure_scope':'Preserve prior Direct/canonical v3 failed return binding; no worker receipt, no accepted scientific prefix. Root seals actual failure separately; v4 contains no supplied proof route or old result data.','future_failure_tapes':'Raw returned file may contain provisional producer-positive flags; no final worker receipt/ROOT acceptance means diagnostic-only regardless those flags. Saved before any post-return binding that might fail.','limits':c['limits'],'peer_review_scopes':{'worker':'primitive-advice-pair-worker','owner':'primitive-advice-pair-owner (owner+exact record_adapter)','helper':'final-primitive-advice-pair-certificate-helper source unchanged checker4; existing current typed review may be retained.'},'remaining':['Genuine independent v4 Source delta review','Root fresh common19-source/q/empty epochs/registry/admissions/once-only matched metadata and activations; old five unactivated plans remain untouched','Root actual complete target/kernel/current point/returned metadata/source/resource admission; no author rerun/rescue.'],'plans_or_admissions_or_actual_calls_created':False})
print(json.dumps({'handoff':h,'worker':WP,'owner':OP,'terminal':TP,'contract':CP,'conformance':con},indent=2))
