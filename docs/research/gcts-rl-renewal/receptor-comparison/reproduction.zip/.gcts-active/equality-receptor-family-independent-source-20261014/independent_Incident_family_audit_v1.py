"""SOURCE ONLY: independent complete donor-root audit for Incident families.

This file has never been imported or called by its author. A future cold ROOT
worker must bind all raw sources, runtime, donor inputs, actual guard endpoints
and owned resources. No production family helper, decoder, SelectedWire method,
compiler, graph, search, native checker or RL function is called here.

The independent compact decoder and plain dependency walk below reconstruct the
entire old donor catalog and all command roots. Injected unchanged GroundChecker
calls are prospective host checks. They do not prove a universal meta-schema,
admit inventory, qualify a recipient, replay a search, or establish native truth.
"""
import copy
import gzip
import hashlib
import io
import json
import math
import struct
import time
import types
from pathlib import Path

VERSION = 'independent-complete-Incident-donor-root-audit-v1'
AUTHOR = '/root/arithmetic_induction'
HEIGHT = 24
MARKING = 'injective-formula-ordered-mp-offset-v1'
MAX_BYTES = 64 * 1024 * 1024
RULES = ('axiom', 'instantiate', 'eq_subst', 'mp', 'assumption')
SENTINEL = (1 << 64) - 1
ROW = struct.Struct('<11Q32s32s')
WORD = struct.Struct('<Q')
TRAINING_SPEC_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-implementation-source-20261013/training-inputs-v1.json', 'sha256': 'de34653e96673e080c65a6c17fad3cc24cfb00ab0043fdc11c9741e6708f382c', 'bytes': 8340}
OLD_READER_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/fresh_equality_context_and_final24_certificate_v3.py', 'sha256': '5d03d088c2d1b7f90e98fb7e28819ab0643b74f6786953c6107d4d2535c2377b', 'bytes': 64540}
KERNEL_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc', 'bytes': 24588}


class ExtractionAuditBudgetExceeded(TimeoutError):
    """No completed audit receipt or admitted prefix may escape this limit."""


def require(test, label):
    if not test:
        raise ValueError(label)


def tick(deadline):
    require(type(deadline) in (int, float) and math.isfinite(deadline), 'finite explicit audit deadline')
    if time.perf_counter() >= deadline:
        raise ExtractionAuditBudgetExceeded('complete donor audit unfinished')


def text(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def sha(value):
    return hashlib.sha256(text(value).encode('utf8')).hexdigest()


def exact_int(value, lower=0, upper=None):
    require(type(value) is int and value >= lower and (upper is None or value < upper), 'exact bounded integer')
    return value


def distinct_fields(pairs):
    result = {}
    for name, value in pairs:
        require(name not in result, 'duplicate JSON field')
        result[name] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=distinct_fields,
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError('nonfinite JSON '+token)))


def original_bytes(pin, closed, deadline):
    """Verify and parse the same complete canonical input buffer, not a prefix."""
    tick(deadline)
    require(type(pin) is dict and set(pin) == {'path', 'sha256', 'bytes'}, 'exact raw input record')
    size = exact_int(pin['bytes'], 0, MAX_BYTES+1)
    require(type(pin['path']) is str and type(pin['sha256']) is str
            and len(pin['sha256']) == 64 and all(c in '0123456789abcdef' for c in pin['sha256']), 'typed input pin')
    path = Path(pin['path'])
    require(path.is_absolute() and str(path.resolve()) == pin['path'] and path.is_file(), 'canonical absolute old donor path')
    closed.verify(pin)
    before = path.stat()
    with path.open('rb') as stream:
        raw = stream.read(MAX_BYTES+1)
    after = path.stat()
    require(len(raw) == size and hashlib.sha256(raw).hexdigest() == pin['sha256']
            and (before.st_dev, before.st_ino, before.st_mtime_ns, before.st_size) ==
                (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_size), 'whole stable same-buffer donor pin')
    tick(deadline)
    return raw


def decoded_bytes(pin, closed, deadline):
    raw = original_bytes(pin, closed, deadline)
    if pin['path'].endswith('.gz'):
        with gzip.GzipFile(fileobj=io.BytesIO(raw), mode='rb') as stream:
            raw = stream.read(MAX_BYTES+1)
            require(len(raw) <= MAX_BYTES and stream.read(1) == b'', 'whole bounded decoded donor buffer')
    tick(deadline)
    return raw


def document(pin, closed, deadline):
    value = parse(decoded_bytes(pin, closed, deadline)); tick(deadline)
    return value


def function_anchor(fn):
    require(type(fn) is types.FunctionType, 'exact delegated function endpoint')
    return (fn, fn.__code__, tuple(id(v) for v in fn.__defaults__ or ()),
        tuple((k, id(v)) for k, v in sorted((fn.__kwdefaults__ or {}).items())),
        tuple((id(cell), id(cell.cell_contents)) for cell in fn.__closure__ or ()))


def object_methods(obj):
    """Effective lookup, instance shadowing, class/MRO and property code anchors."""
    out = [type(obj), type(obj).__mro__]; visited = set()
    namespace = getattr(obj, '__dict__', {})
    for cls in type(obj).__mro__:
        for name, descriptor in sorted(vars(cls).items()):
            if name in visited:
                continue
            visited.add(name)
            if isinstance(descriptor, property):
                require(name not in namespace, 'no shadowed endpoint property '+name)
                out.append((name, cls, descriptor, tuple(function_anchor(fn) for fn in
                    (descriptor.fget, descriptor.fset, descriptor.fdel) if fn is not None)))
            elif isinstance(descriptor, (staticmethod, classmethod)) or type(descriptor) is types.FunctionType:
                require(name not in namespace, 'no instance shadowed endpoint '+name)
                fn = descriptor.__func__ if isinstance(descriptor, (staticmethod, classmethod)) else descriptor
                effective = getattr(obj, name)
                if isinstance(descriptor, staticmethod):
                    require(effective is fn, 'same static endpoint '+name)
                else:
                    receiver = type(obj) if isinstance(descriptor, classmethod) else obj
                    require(type(effective) is types.MethodType and effective.__func__ is fn
                            and effective.__self__ is receiver, 'same bound endpoint '+name)
                out.append((name, cls, descriptor, function_anchor(fn)))
    return tuple(out)


class EndpointBoundary:
    """Supplement the caller's whole module/global/code guard; never replace it."""
    __slots__ = ('guard', 'anchor', 'objects', 'snapshots', '_sealed')

    def __setattr__(self, name, value):
        if getattr(self, '_sealed', False):
            raise ValueError('sealed independent endpoint boundary')
        object.__setattr__(self, name, value)

    def __init__(self, guard, objects, deadline):
        self._sealed = False
        self.guard = guard; self.anchor = function_anchor(guard)
        self.objects = tuple(objects); self.snapshots = tuple(object_methods(obj) for obj in self.objects)
        self._sealed = True
        self.check(deadline)

    def check(self, deadline):
        tick(deadline)
        # Direct rejection precedes delegated calls, so a replaced guard cannot
        # make this check pass by replacing its own validator body.
        if function_anchor(self.guard) != self.anchor:
            raise ValueError('delegated source guard identity/code/default/closure changed')
        require(tuple(object_methods(obj) for obj in self.objects) == self.snapshots,
                'effective supplied endpoint changed')
        self.guard()
        if function_anchor(self.guard) != self.anchor:
            raise ValueError('delegated source guard changed during invocation')
        tick(deadline)


def key(value, count=None):
    require(type(value) is list and len(value) == 3 and type(value[2]) is list, 'literal saved placement key')
    index = exact_int(value[0], 0, count); row = exact_int(value[1], 0, HEIGHT)
    refs = tuple(exact_int(ref, 0, row) for ref in value[2])
    return index, row, refs


class PlainCatalog:
    """Independent literal binary/DAG parser, not a production reader facade."""
    def __init__(self, header, license_pin, closed, checker, boundary, deadline, metrics):
        self.header = header
        require(header['schema'] == 'fresh-ground-compact-catalog-v1' and header['height'] == HEIGHT
                and header['marking_version'] == MARKING and header['orientation'] == 'identity', 'exact old donor point language')
        codec = header['codec']; dims = header['dimensions']
        require(codec['byte_order'] == 'little' and codec['recipe_row_bytes'] == ROW.size
                and codec['formula_word_bytes'] == WORD.size and codec['sentinel'] == SENTINEL
                and codec['rules'] == list(RULES), 'declared original reversible codec')
        require(header['context_id'] == sha(header['context'])
                and header['authority']['recipient_theory_sha256'] == sha(header['context']['theory']), 'exact context/theory epoch')
        nodes_raw = decoded_bytes(header['streams']['nodes'], closed, deadline)
        self.nodes = []; self.memo = {}
        for line in nodes_raw.splitlines(keepends=True):
            tick(deadline); rec = parse(line)
            require(type(rec) is list and len(rec) >= 2 and rec[0] == len(self.nodes)
                    and type(rec[0]) is int and line.decode('utf8') == text(rec)+'\n', 'complete canonical contiguous DAG')
            self.nodes.append(rec[1:])
        require(len(self.nodes) == codec['node_count'], 'no omitted or unread DAG node')
        formula_raw = original_bytes(header['streams']['formulas'], closed, deadline)
        self.formula_nodes = [part[0] for part in WORD.iter_unpack(formula_raw)]
        require(len(formula_raw) == dims['formula_count'] * WORD.size
                and len(self.formula_nodes) == dims['formula_count'], 'whole formula word census')
        # Validate every node, including nodes not used by winning roots.
        for node in range(len(self.nodes)):
            tick(deadline); self.expand(node)
        formulas = [self.formula(code) for code in range(len(self.formula_nodes))]
        require(sha(formulas) == header['formula_registry_sha256'], 'whole injective formula registry digest')
        require(len({text(f) for f in formulas}) == len(formulas), 'injective complete formula word registry')
        binary = original_bytes(header['streams']['recipes'], closed, deadline)
        require(len(binary) == dims['primitive_license_count'] * ROW.size, 'full recipe bytes, no tail')
        self.records = []; identities = set()
        for index, row in enumerate(ROW.iter_unpack(binary)):
            tick(deadline); record = self.decode_recipe(index, row, codec['names'])
            require(record['id'] not in identities, 'distinct full recipe identity')
            identities.add(record['id']); self.records.append(record)
            # Each original admitted primitive interface is checked afresh, not
            # merely a selected subset. MP checks use its two literal premises.
            command = copy.deepcopy(record['witness'])
            prior = record['premises']
            if record['rule'] == 'mp':
                command.update(antecedent=0, implication=1)
            metrics['primitive_commands_started'] += 1
            if index % 32 == 0:
                boundary.check(deadline)
            value = checker.command(command, prior, header['context']['ordered_local_premises'])
            require(value == record['witness']['formula'], 'rechecked original primitive interface output')
            tick(deadline); metrics['primitive_commands_completed'] += 1
        require(len(self.records) == dims['primitive_license_count'], 'complete original primitive census')
        license_raw = decoded_bytes(license_pin, closed, deadline)
        count = 0
        fields = {'recipe_index', 'recipe_id', 'rule', 'record_sha256', 'logical_accepted', 'native_accepted', 'status'}
        for line in license_raw.splitlines(keepends=True):
            tick(deadline); rec = parse(line)
            require(count < len(self.records) and type(rec) is dict and set(rec) == fields
                    and type(rec['recipe_index']) is int and rec['recipe_index'] == count
                    and rec['logical_accepted'] is True and rec['native_accepted'] is False
                    and rec['status'] == 'accepted_independent_exact_primitive_license'
                    and line.decode('utf8') == text(rec)+'\n', 'complete exact original license line')
            target = self.records[count]
            require([rec['recipe_id'], rec['rule'], rec['record_sha256']] ==
                    [target['id'], target['rule'], target['record_sha256']], 'every license matches independently decoded record')
            count += 1
        require(count == len(self.records), 'every recipe and no extra license')
        require(len(header['assumption_recipe_indices']) == len(header['context']['ordered_local_premises']) == 3,
                'original occurrence-specific three-hypothesis protocol')
        for occurrence, index in enumerate(header['assumption_recipe_indices']):
            require(self.records[index]['witness'] == {'rule': 'assumption', 'index': occurrence,
                'formula': header['context']['ordered_local_premises'][occurrence]}, 'all original assumption occurrences retained')
        self.epoch = sha({'height': HEIGHT, 'context': header['context'],
            'registry': header['formula_registry_sha256'], 'authority': header['authority']['epoch'],
            'recipes': [r['id'] for r in self.records],
            'fixed_marks': sorted(header['boundary']['fixed_exterior_m']+header['boundary']['fixed_target_m']),
            'roots': [0]*HEIGHT, 'seed_keys': [[index, row, []] for row, index in enumerate(header['assumption_recipe_indices'])],
            'marking_version': MARKING, 'fixture': False, 'source_bindings': header['source_bindings']})
        metrics['catalogues_completed'] += 1
        metrics['complete_recipe_interfaces'] += len(self.records)
        metrics['complete_license_lines'] += count
        metrics['complete_DAG_nodes'] += len(self.nodes)
        metrics['complete_formula_codes'] += len(formulas)
        boundary.check(deadline)

    def expand(self, node):
        exact_int(node, 0, len(self.nodes))
        if node in self.memo:
            return self.memo[node]
        rec = self.nodes[node]; tag = rec[0]
        def child(index):
            exact_int(index, 0, node)
            return self.expand(index)
        if tag == 'bot' and len(rec) == 1:
            value = ['bot']
        elif tag == 'var' and len(rec) == 2 and type(rec[1]) is str and rec[1]:
            value = list(rec)
        elif tag in ('fun', 'pred') and len(rec) == 3 and type(rec[1]) is str and rec[1] and type(rec[2]) is list:
            value = [tag, rec[1], [child(index) for index in rec[2]]]
        elif tag == 'all' and len(rec) == 3 and type(rec[1]) is str and rec[1]:
            value = [tag, rec[1], child(rec[2])]
        elif (tag in ('eq', 'imp', 'and', 'or') and len(rec) == 3) or (tag == 'not' and len(rec) == 2):
            value = [tag]+[child(index) for index in rec[1:]]
        else:
            raise ValueError('unknown or malformed original DAG constructor')
        self.memo[node] = value
        return value

    def formula(self, code):
        exact_int(code, 0, len(self.formula_nodes))
        return self.expand(self.formula_nodes[code])

    def decode_recipe(self, index, row, names):
        tag, node, code, a, b, p0, p1, p2, p3, n, occurrence = row[:11]
        rule = RULES[exact_int(tag, 0, len(RULES))]
        exact_int(code, 0, len(self.formula_nodes))
        require(self.formula_nodes[code] == node, 'recipe output node equals registry word')
        witness = {'rule': rule, 'formula': self.expand(node)}
        if rule == 'mp':
            require(all(v == SENTINEL for v in (p0, p1, p2, p3, n, occurrence)), 'no hidden MP parameter')
            inputs = [exact_int(a, 0, len(self.formula_nodes)), exact_int(b, 0, len(self.formula_nodes))]
        else:
            require(a == b == SENTINEL, 'zero-port primitive has no source reference')
            inputs = []
            if rule == 'axiom':
                witness['name'] = names[exact_int(n, 0, len(names))]
                require(all(v == SENTINEL for v in (p0, p1, p2, p3, occurrence)), 'literal named axiom fields')
            elif rule == 'instantiate':
                witness.update(universal=self.expand(p0), term=self.expand(p1))
                require(all(v == SENTINEL for v in (p2, p3, n, occurrence)), 'literal instantiation fields')
            elif rule == 'eq_subst':
                witness.update(variable=names[exact_int(n, 0, len(names))], template=self.expand(p0), left=self.expand(p1), right=self.expand(p2))
                require(p3 == occurrence == SENTINEL, 'literal equality substitution fields')
            else:
                witness['index'] = exact_int(occurrence, 0, 3)
                require(all(v == SENTINEL for v in (p0, p1, p2, p3, n)), 'literal assumption occurrence fields')
        premises = [self.formula(code) for code in inputs]
        if rule == 'mp':
            require(premises[1] == ['imp', premises[0], witness['formula']], 'ordered MP recipe premise formulas')
        identity = {'recipe': {'primitive_witness': witness, 'ordered_premise_formulas': premises},
            'primitive_authority_epoch': self.header['authority']['epoch'],
            'recipient_theory_sha256': self.header['authority']['recipient_theory_sha256'],
            'marking_version': MARKING, 'formula_registry_sha256': self.header['formula_registry_sha256']}
        if rule == 'assumption':
            identity['local_context_id'] = self.header['context_id']
        identifier = 'primitive-recipe-'+sha(identity)
        require(row[11].hex() == identifier[len('primitive-recipe-'):], 'whole identity preimage SHA')
        record = {'id': identifier, 'primitive_witness': witness, 'ordered_premise_formulas': premises, 'identity_preimage': identity}
        require(row[12].hex() == sha(record), 'whole original record SHA')
        return {'index': index, 'id': identifier, 'witness': witness, 'premises': premises,
                'output': code, 'inputs': inputs, 'record_sha256': row[12].hex(), 'rule': rule}


def row_map(keys, records):
    result = {}
    for raw in keys:
        index, row, refs = key(raw, len(records)); rec = records[index]
        require(row not in result and len(refs) == len(rec['inputs']), 'no duplicate row and complete ordered input arity')
        result[row] = (index, row, refs)
    return result


def dependency_rows(root, selected, records, deadline):
    """Worklist closure; pending source constraints are not available formulas."""
    agenda = [root]; done = set()
    while agenda:
        tick(deadline); row = agenda.pop()
        if row in done:
            continue
        require(row in selected, 'all ancestry physically present in this patch')
        index, actual, refs = selected[row]; rec = records[index]
        require(actual == row and len(refs) == len(rec['inputs']), 'exact dependency node')
        for ref, formula_code in zip(refs, rec['inputs']):
            require(ref < row and ref in selected and records[selected[ref][0]]['output'] == formula_code,
                    'strict prior and formula-equal source receptor')
            agenda.append(ref)
        done.add(row)
    return sorted(done)


def expand_patch(root, selected, catalog, deadline):
    used = dependency_rows(root, selected, catalog.records, deadline)
    rows = sorted(set(used).union(range(3)))
    require(rows[-1] == root, 'target is last primitive dependency root')
    gamma = catalog.header['context']['ordered_local_premises']
    commands = []; keys = []; mapping = {}
    for row in rows:
        tick(deadline); require(row in selected, 'ambient original occurrence retained')
        index, _, refs = selected[row]; rec = catalog.records[index]
        command = copy.deepcopy(rec['witness'])
        if row < 3:
            require(index == catalog.header['assumption_recipe_indices'][row] and not refs
                    and command == {'rule': 'assumption', 'index': row, 'formula': gamma[row]}, 'same original indexed Gamma seed')
        if rec['rule'] == 'mp':
            require(all(ref in mapping for ref in refs), 'command references precede conclusion')
            command.update(antecedent=mapping[refs[0]], implication=mapping[refs[1]])
        mapping[row] = len(commands); commands.append(command); keys.append([index, row, list(refs)])
    consumed = sorted({catalog.records[selected[row][0]]['witness']['index'] for row in used
                       if catalog.records[selected[row][0]]['rule'] == 'assumption'})
    return {'commands': commands, 'primitive_keys': keys, 'exact_original_ordered_gamma': copy.deepcopy(gamma),
            'conclusion': copy.deepcopy(commands[-1]['formula']), 'consumed_original_occurrence_indices': consumed}


def points(keys, catalog, deadline):
    """Independent exact integer unit t and mark agreement/refcount census."""
    totals = [0]*HEIGHT; values = {}; refs_count = {}
    def mark(point, value):
        require(all(type(v) is int for v in (*point, value)), 'integer point values, zero assigned')
        require(point not in values or values[point] == value, 'whole remote mark agreement')
        values[point] = value; refs_count[point] = refs_count.get(point, 0)+1
    fixed = catalog.header['boundary']['fixed_exterior_m']+catalog.header['boundary']['fixed_target_m']
    for x, y, value in fixed:
        tick(deadline); mark((x, y), value)
    selected = row_map(keys, catalog.records)
    for row, (index, _, refs) in selected.items():
        tick(deadline); require(totals[row] == 0, 'unit positive support has capacity one')
        totals[row] = 1; rec = catalog.records[index]; local = {(1, row): rec['output']}
        for port, (source, code) in enumerate(zip(refs, rec['inputs'])):
            require((1, source) not in local or local[1, source] == code, 'shared receptor row code agreement')
            local[1, source] = code; local[2+port, row] = source-row
        for point, value in local.items():
            mark(point, value)
    tick(deadline)
    return {'totals': totals, 't': [[0, row, value] for row, value in enumerate(totals) if value],
        'm': [[x, y, value] for (x, y), value in sorted(values.items())],
        'marks': [[x, y, value, refs_count[x, y]] for (x, y), value in sorted(values.items())]}


def normalize_literal(value, replacements):
    # Only exact term subtrees are substituted. The wrapper never binds roles by
    # a donor recipe ID, formula code, target lookup, result label or proof word.
    if type(value) is list:
        for original, replacement in replacements:
            if value == original:
                return copy.deepcopy(replacement)
        return [normalize_literal(v, replacements) for v in value]
    if type(value) is dict:
        return {k: normalize_literal(v, replacements) for k, v in value.items()}
    return value


def eligible_body(commands, root, theory):
    """Separate bottom-up inspection of an eq_subst -> MP -> MP dependency."""
    output = commands[root]
    if output['rule'] != 'mp':
        return None, 'root_not_MP'
    middle_i = exact_int(output['implication'], 0, root); middle = commands[middle_i]
    if middle['rule'] != 'mp':
        return None, 'root_has_no_second_MP'
    axiom_i = exact_int(middle['implication'], 0, middle_i); axiom = commands[axiom_i]
    if axiom['rule'] != 'eq_subst':
        return None, 'body_has_no_equality_substitution'
    template = axiom['template']
    if not (type(template) is list and len(template) == 3 and template[0] == 'pred'
            and template[1] == 'Incident' and type(template[2]) is list and len(template[2]) == 2):
        return None, 'outside_initial_Incident_body_scope'
    holes = [i for i in range(2) if template[2][i] == ['var', axiom['variable']]]
    if len(holes) != 1:
        return None, 'not_one_whole_argument_hole'
    slot = holes[0]; parameters = {'s': axiom['left'], 't': axiom['right'], 'u': template[2][1-slot]}
    for value in parameters.values():
        if not (type(value) is list and len(value) == 3 and value[0] == 'fun' and type(value[1]) is str
                and value[2] == [] and theory['functions'].get(value[1]) == 0):
            return None, 'outside_closed_nullary_scope'
    if len({text(v) for v in parameters.values()}) != len(parameters):
        return None, 'training_meta_roles_alias_requires_separate_normalizer'
    eq_i = exact_int(middle['antecedent'], 0, middle_i); source_i = exact_int(output['antecedent'], 0, root)
    left_args = [parameters['s'], parameters['u']] if slot == 0 else [parameters['u'], parameters['s']]
    right_args = [parameters['t'], parameters['u']] if slot == 0 else [parameters['u'], parameters['t']]
    equality = ['eq', parameters['s'], parameters['t']]
    left = ['pred', 'Incident', left_args]; right = ['pred', 'Incident', right_args]
    if (commands[eq_i]['formula'] != equality or commands[source_i]['formula'] != left
            or output['formula'] != right or middle['formula'] != ['imp', left, right]
            or axiom['formula'] != ['imp', equality, ['imp', left, right]]):
        return None, 'source_body_formula_or_ordered_port_mismatch'
    replacements = [(parameters[name], ['meta-term', name]) for name in ('s', 't', 'u')]
    members = []
    for index, ports in ((axiom_i, []), (middle_i, ['input:equality', 'member:0']), (root, ['input:formula', 'member:1'])):
        witness = {k: copy.deepcopy(v) for k, v in commands[index].items() if k not in ('antecedent', 'implication')}
        members.append({'witness': normalize_literal(witness, replacements), 'ordered_ports': ports})
    shape = {'predicate': 'Incident', 'slot': slot, 'parameters': ['s', 't', 'u'],
        'input_receptors': [normalize_literal(equality, replacements), normalize_literal(left, replacements)],
        'members': members, 'output': normalize_literal(right, replacements)}
    return {'shape': shape, 'body_command_indices': [axiom_i, middle_i, root],
        'ordered_external_command_indices': [eq_i, source_i], 'original_parameters': copy.deepcopy(parameters)}, 'eligible_Incident_transport'


def open_ground_body(commands, body):
    """Rebuild the found local body with its two exposed, ordered receptors.

    This is a generic extraction-derived ground test, not a target route. The
    two atomic port formulas are provisional local hypotheses. Universal family
    validity and any later recipient instance remain separate qualification.
    """
    gamma = [copy.deepcopy(commands[i]['formula']) for i in body['ordered_external_command_indices']]
    word = [{'rule': 'assumption', 'index': i, 'formula': copy.deepcopy(f)} for i, f in enumerate(gamma)]
    map_body = {}; external = {'input:equality': 0, 'input:formula': 1}
    for member, source_i in enumerate(body['body_command_indices']):
        command = {k: copy.deepcopy(v) for k, v in commands[source_i].items() if k not in ('antecedent', 'implication')}
        ports = body['shape']['members'][member]['ordered_ports']
        resolved = []
        for port in ports:
            if port in external:
                resolved.append(external[port])
            else:
                require(port.startswith('member:'), 'literal earlier member port')
                index = int(port[len('member:'):]); require(index < member and index in map_body, 'strict earlier body port')
                resolved.append(map_body[index])
        if command['rule'] == 'mp':
            require(len(resolved) == 2, 'two ordered exposed local MP sources')
            command.update(antecedent=resolved[0], implication=resolved[1])
        else:
            require(not resolved, 'zero-port local schema')
        map_body[member] = len(word); word.append(command)
    return word, gamma, copy.deepcopy(word[-1]['formula'])


def verify_origin(cert, result, spec, header, deadline):
    """Retained original selected/proposed origin and unique saved event binding."""
    tick(deadline); checked = cert['checked_patch']
    require(cert['schema'] == 'fresh-equality-first-proof-saved-certificate-v1'
            and cert['origin_kind'] == spec['origin'] in ('actual_selected', 'completed_source_proposal')
            and cert['result_pin'] == spec['result'] and cert['qualification_pin'] == spec['qualification']
            and cert['original_Gamma_target_sequent_accepted'] is True
            and cert['native_accepted'] is False and cert['full24_board_accepted'] is False, 'exact checked old donor certificate scope')
    require(sha(checked) == cert['checked_patch_sha256'] and checked['origin_kind'] == cert['origin_kind']
            and sha(checked['source_state']) == checked['source_state_sha256']
            and result['graph_states'].get(checked['source_state_sha256']) == checked['source_state']
            and result['first_checked_proof'] == checked, 'complete retained checked-patch/current-state identity')
    require(checked['primary_endpoint_eligible'] is True and checked['prospective_current_point_union_accepted'] is True
            and checked['patch']['exact_original_ordered_gamma'] == header['context']['ordered_local_premises'], 'primary current-union and original Gamma binding')
    require(result['schema'] == 'compact24-first-checked-proof-scientific-DFS-v11-source'
            and result['status'] == 'first_checked_original_Gamma_target_proof'
            and result['mode'] in ('base', 'seed_forward') and result['seed'] is None
            and result['rng_draws'] == result['policy_choices'] == result['commits'] == []
            and result['training_updates'] == result['all_source_body_count'] == result['registered_whole_descriptor_count'] == 0
            and result['root_restored'] is True and result['trace_complete'] is True
            and result['point_certificate'] is None and result['logical_target_proof_accepted'] is True, 'old stopped logical-proof result, no full-board/learning claim')
    events = [event for event in result['events'] if event['kind'] == 'first_checked_logical_proof'
        and event['proof_sha256'] == sha(checked) and event['origin_kind'] == checked['origin_kind']
        and event['source_link'] == checked['source_link']]
    require(len(events) == 1 and events[0]['state']['overlay']['controller']['graph_state_sha256'] == checked['source_state_sha256'], 'unique whole saved proof observation event')
    selected = cert['origin_kind'] == 'actual_selected'
    require(cert['actual_selected_target_accepted'] is selected
            and cert['completed_source_proposal_target_accepted'] is (not selected)
            and checked['actual_selected_target_accepted'] is selected
            and checked['source_proposal_never_counted_as_selected'] is (not selected)
            and result['actual_selected_target_proof_accepted'] is selected, 'selected/proposed source attribution never conflated')
    require(all(checked[field] is False for field in ('full24_board_accepted', 'native_accepted', 'full_trajectory_accepted',
            'universal_compiler_accepted', 'inventory_admitted', 'new_RL_training')), 'no inherited stronger certificate authority')
    if not selected:
        link = checked['source_link']; observation = result['candidate_advice']['observations'][link['advice_observation_index']]
        require(any(p['root_receptor_row'] == checked['root_row'] and p['primitive_keys'] == checked['patch']['primitive_keys']
            for p in observation['selection']['preferred_cluster_proposals']), 'exact retained completed source proposal')
    tick(deadline)
    return checked


def audit_extraction(*, training_spec, library, reader, checker_class, closed, source_guard, deadline):
    """Prospective full source-bound audit; ROOT's owned wrapper invokes once.

    No favorable family/root count is supplied. Every root derives from every
    fixed original certificate. The full semantic candidate-library projection
    is compared exactly; producer elapsed time is typed but never recomputed as
    an independent cost. No actual library/schema/native authority is returned.
    """
    started = time.perf_counter(); tick(deadline)
    require(type(closed) is reader.ClosedInputs and checker_class.__name__ == 'GroundChecker', 'original injected donor endpoints')
    # Path checks are necessary input binding, not a substitute for caller code,
    # object/global/MRO/raw-compiled-buffer endpoint admission.
    require(str(Path(reader.SelectedWire.recipe.__code__.co_filename).resolve()) == OLD_READER_PIN['path']
            and str(Path(checker_class.proof.__code__.co_filename).resolve()) == KERNEL_PIN['path'], 'explicit old donor reader and unchanged kernel source')
    outer = EndpointBoundary(source_guard, (closed,), deadline)
    closed.verify(OLD_READER_PIN); closed.verify(KERNEL_PIN)
    require(training_spec == document(TRAINING_SPEC_PIN, closed, deadline)
            and training_spec['schema'] == 'exact-three-equality-transport-training-inputs-v1', 'fixed original donor selector only')
    for field in ('design', 'handoff'):
        document(training_spec[field], closed, deadline)
    mathematical = document(training_spec['ROOT_mathematical_disposition'], closed, deadline)
    require(mathematical['schema'] == 'ROOT-fresh-geometry-first-checked-proofs-disposition-v1'
            and mathematical['author_identity'] == '/root' and mathematical['ROOT_final_accepted'] is True
            and mathematical['checked_logical_derivations'] == len(training_spec['certificates']), 'actual old donor math disposition')
    library_before = sha(library); metrics = dict(catalogues_started=0, catalogues_completed=0,
        complete_recipe_interfaces=0, complete_license_lines=0, complete_DAG_nodes=0, complete_formula_codes=0,
        primitive_commands_started=0, primitive_commands_completed=0, certificate_proofs_started=0,
        certificate_proofs_completed=0, open_ground_bodies_started=0, open_ground_bodies_completed=0,
        command_roots_started=0, command_roots_completed=0, point_unions_started=0, point_unions_completed=0,
        exact_catalogue_cache_reuses=0)
    catalogues = {}; expected_origins = []; derivations = []; correlations = {}; evidence = []
    body_checks = []; donor_censuses = []
    for spec in training_spec['certificates']:
        outer.check(deadline)
        cert = document(spec['certificate'], closed, deadline); result = document(spec['result'], closed, deadline)
        qualification = document(spec['qualification'], closed, deadline); header = document(spec['header'], closed, deadline)
        resource = document(spec['resource_disposition'], closed, deadline)
        require(resource['resource_accepted'] is True and resource['result'] == spec['result']
                and resource['logical_certificate'] == spec['certificate']
                and any(trial['logical_certificate'] == spec['certificate'] and trial['ROOT_checked_logical_derivation_accepted'] is True
                        and trial['resource_disposition'] == spec['resource_disposition'] for trial in mathematical['trials']), 'whole actual old math/resource provenance')
        require(qualification['schema'] == 'ROOT-qualified-compact-proof-context-v1'
                and qualification['all_complete_catalog_licenses_and_initial24domains_accepted'] is True
                and qualification['catalog'] == spec['header'] and qualification['independent']['licenses'] == spec['licenses']
                and qualification['instance_id'] == header['instance_id'] == spec['case'], 'whole original header/qualification/license context')
        checked = verify_origin(cert, result, spec, header, deadline)
        checker = checker_class(header['context']['theory'])
        boundary = EndpointBoundary(source_guard, (closed, checker), deadline)
        cache_key = text([spec['header'], spec['licenses']])
        if cache_key not in catalogues:
            metrics['catalogues_started'] += 1
            catalogues[cache_key] = PlainCatalog(header, spec['licenses'], closed, checker, boundary, deadline, metrics)
        else:
            require(catalogues[cache_key].header == header, 'cache only exact byte-identical catalog/license pair')
            metrics['exact_catalogue_cache_reuses'] += 1
        catalog = catalogues[cache_key]; records = catalog.records
        require(catalog.epoch == result['model_epoch'] == checked['source_state']['model_epoch'], 'complete original point model epoch')
        selected = row_map(checked['patch']['primitive_keys'], records)
        actual = row_map(checked['source_state']['order'], records)
        for row, selected_key in selected.items():
            require((actual.get(row) == selected_key) if cert['origin_kind'] == 'actual_selected' else
                    (row not in actual or actual[row] == selected_key), 'selected/proposed exact shared current identities')
        rebuilt = expand_patch(checked['root_row'], selected, catalog, deadline)
        patch = checked['patch']
        require(all(patch[name] == rebuilt[name] for name in rebuilt) and rebuilt['conclusion'] == header['target'],
                'whole primitive word/keys/strict ancestry/original Gamma/conclusion exact')
        metrics['certificate_proofs_started'] += 1; boundary.check(deadline)
        ground_result = checker.proof(rebuilt['commands'], rebuilt['exact_original_ordered_gamma'], rebuilt['conclusion'])
        tick(deadline); boundary.check(deadline)
        require(ground_result['original_ground_sequent_accepted'] is True and ground_result['native_accepted'] is False,
                'fresh complete original-Gamma ground proof')
        metrics['certificate_proofs_completed'] += 1
        require(ground_result == patch['kernel_result'], 'saved whole original-Gamma kernel receipt reconciled')
        metrics['point_unions_started'] += 1
        primitive_points = points(rebuilt['primitive_keys'], catalog, deadline)
        union = dict(actual); union.update(selected)
        union_keys = [[index, row, list(refs)] for index, row, refs in sorted(union.values(), key=lambda item: item[1])]
        whole_points = points(union_keys, catalog, deadline)
        require(primitive_points == patch['literal_points'] and whole_points == checked['prospective_current_point_union'],
                'all source/current/fixed t and m values/refcounts compared')
        metrics['point_unions_completed'] += 1
        correlation = sha([rebuilt['exact_original_ordered_gamma'], rebuilt['conclusion']])
        correlations.setdefault(correlation, []).append(spec['certificate'])
        derivations.append({'certificate': spec['certificate'], 'origin': cert['origin_kind'],
            'original_ordered_Gamma': rebuilt['exact_original_ordered_gamma'],
            'consumed_original_occurrence_indices': rebuilt['consumed_original_occurrence_indices'],
            'correlated_sequent_id': correlation, 'original_commands': rebuilt['commands'],
            'original_keys': rebuilt['primitive_keys'], 'independent_ground_check': ground_result})
        local_eligible = 0
        for root in range(len(rebuilt['commands'])):
            tick(deadline); metrics['command_roots_started'] += 1
            body, reason = eligible_body(rebuilt['commands'], root, header['context']['theory'])
            origin = {'certificate': spec['certificate'], 'command_root': root, 'origin': cert['origin_kind'],
                'eligible': body is not None, 'reason': reason, 'correlated_sequent_id': correlation}
            if body is not None:
                local_eligible += 1
                rows = [rebuilt['primitive_keys'][i][1] for i in body['body_command_indices']]
                closures = [dependency_rows(rebuilt['primitive_keys'][i][1], selected, records, deadline)
                            for i in body['ordered_external_command_indices']]
                consumed = [sorted({records[selected[row][0]]['witness']['index'] for row in dependency
                    if records[selected[row][0]]['rule'] == 'assumption'}) for dependency in closures]
                body.update(origin=origin, source_body_rows=rows,
                    source_body_keys=[rebuilt['primitive_keys'][i] for i in body['body_command_indices']],
                    ordered_receptor_ancestor_rows=closures, ordered_receptor_consumed_occurrences=consumed,
                    ambient_original_ordered_Gamma=rebuilt['exact_original_ordered_gamma'],
                    family_id='Incident-transport-'+sha(body['shape']))
                origin['family_id'] = body['family_id']; evidence.append(body)
                local_word, local_gamma, local_target = open_ground_body(rebuilt['commands'], body)
                metrics['open_ground_bodies_started'] += 1; boundary.check(deadline)
                local_result = checker.proof(local_word, local_gamma, local_target)
                tick(deadline); boundary.check(deadline)
                require(local_result['original_ground_sequent_accepted'] is True and local_result['native_accepted'] is False,
                        'ground local body checked under ordered exposed receptors')
                metrics['open_ground_bodies_completed'] += 1
                body_checks.append({'certificate': spec['certificate'], 'command_root': root,
                    'family_id': body['family_id'], 'ordered_exposed_receptors': local_gamma,
                    'commands': local_word, 'kernel_result': local_result,
                    'schema_universally_validated': False, 'native_accepted': False})
            expected_origins.append(origin); metrics['command_roots_completed'] += 1
        donor_censuses.append({'certificate': spec['certificate'], 'origin': cert['origin_kind'],
            'command_roots': len(rebuilt['commands']), 'eligible_roots': local_eligible,
            'correlated_sequent_id': correlation, 'primitive_recipe_count': len(records),
            'all_original_Gamma_occurrences': list(range(len(rebuilt['exact_original_ordered_gamma']))),
            'consumed_original_occurrence_indices': rebuilt['consumed_original_occurrence_indices']})
        boundary.check(deadline)
    by_id = {}
    for body in evidence:
        identifier = body['family_id']
        if identifier not in by_id:
            by_id[identifier] = {'family_id': identifier, 'shape': body['shape'], 'evidence': []}
        require(by_id[identifier]['shape'] == body['shape'], 'no hash collision or mismatched family shape')
        by_id[identifier]['evidence'].append(body)
    expected = {'schema': 'candidate-finite-Incident-transport-library-v1', 'training_spec_sha256': sha(training_spec),
        'families': [by_id[k] for k in sorted(by_id)], 'complete_origin_census': expected_origins,
        'derivations': derivations, 'correlated_sequents': correlations, 'ROOT_inventory_admitted': False,
        'schema_universally_validated': False, 'primitive_source_body_count': 0, 'source_only_producer': False,
        'calls': {'certificate_ground_checks_started': len(derivations), 'certificate_ground_checks_completed': len(derivations)}}
    require(type(library) is dict and set(library) == set(expected) | {'elapsed_seconds_before_final_guards'},
            'complete candidate library fields, no omission or extra authority')
    require(type(library['elapsed_seconds_before_final_guards']) in (int, float)
            and math.isfinite(library['elapsed_seconds_before_final_guards'])
            and library['elapsed_seconds_before_final_guards'] >= 0, 'producer diagnostic elapsed is typed, not a comparable cost')
    require({k: library[k] for k in expected} == expected, 'every independent family/root/provenance/derivation semantic value exact')
    require(metrics['command_roots_started'] == metrics['command_roots_completed'] == len(expected_origins)
            and metrics['certificate_proofs_started'] == metrics['certificate_proofs_completed'] == len(derivations)
            and metrics['open_ground_bodies_started'] == metrics['open_ground_bodies_completed'] == len(evidence), 'complete root and actual check counts, no partial prefix')
    outer.check(deadline); closed.close(); outer.check(deadline)
    require(sha(library) == library_before, 'candidate input not mutated by auditor')
    receipt = {'schema': VERSION, 'completed': True, 'all_checks_passed': True, 'mismatches': [],
        'author_identity': AUTHOR, 'producer_source_called': False, 'independent_compact_decoder': True,
        'training_spec_sha256': sha(training_spec), 'candidate_library_sha256': library_before,
        'independent_semantic_projection_sha256': sha(expected), 'census': donor_censuses,
        'complete_command_root_census': expected_origins, 'open_ground_body_checks': body_checks,
        'correlated_sequents': correlations, 'metrics': metrics,
        'ROOT_inventory_admitted': False, 'schema_universally_validated': False, 'native_accepted': False,
        'recipient_proof_accepted': False, 'full24_board_accepted': False, 'full_trajectory_accepted': False,
        'new_lemma_discovered': False, 'new_RL_training': False,
        'elapsed_seconds_before_final_receipt_guards': time.perf_counter()-started,
        'cost_scope': 'All loading/catalogue/license/primitive/full-Gamma/open-ground/point/root/provenance comparisons occur inside the shared caller deadline. This partial span ends before final receipt guards/serialization; owned/caller full lifetimes remain authoritative.'}
    text(receipt); outer.check(deadline); tick(deadline)
    return receipt
