"""SOURCE-only certificate-mined Incident transport; no import-time science.

All mathematical calls require a later cold source-bound ROOT caller. The
caller owns full static/q/resource admission, raw compiled module buffers and
all executed module/class/MRO/property/global code. This module does not turn
an input JSON claim, co_filename or hash into that authority. Its own object,
effective-method and delegated-guard anchors supplement that external boundary.
No source result, target code, test proof or placement route is embedded here.
"""
import gzip
import io
import json
import hashlib
import time
import types
from pathlib import Path

VERSION = 'certificate-mined-Incident-receptor-family-I2-recipient-v2'
LIBRARY_SCHEMA = 'candidate-finite-Incident-transport-library-v1'
ADMISSION_SCHEMA = 'ROOT-finite-Incident-transport-I2-recipient-advice-admission-v2'
HEIGHT = 24
MAXIMUM_CERTIFICATES = 3
MAXIMUM_PREFERRED = 64


class FamilyBudgetExceeded(TimeoutError):
    pass


class NoInstance(ValueError):
    """This advice component is unavailable; the base domain stays complete."""


def need(value, message):
    if not value:
        raise ValueError(message)


def clock(deadline):
    need(type(deadline) in (int, float) and type(deadline) is not bool,
         'explicit real caller deadline')
    if time.perf_counter() >= deadline:
        raise FamilyBudgetExceeded('unfinished family work; no usable prefix')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False)


def clone(value):
    return json.loads(canonical(value))


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf8')).hexdigest()


def key_data(value):
    if type(value) is tuple:
        need(len(value) == 3 and type(value[2]) is tuple, 'exact literal key tuple')
        value = [value[0], value[1], list(value[2])]
    need(type(value) is list and len(value) == 3 and type(value[0]) is int
         and value[0] >= 0 and type(value[1]) is int and 0 <= value[1] < HEIGHT
         and type(value[2]) is list and all(type(r) is int and 0 <= r < value[1]
                                         for r in value[2]), 'exact strict-prior key')
    return value[0], value[1], tuple(value[2])


def raw_json(pin, *, deadline, maximum_bytes=67108864):
    """One verified input buffer; no .pyc, partial gzip or prefix admission."""
    clock(deadline)
    need(type(pin) is dict and set(pin) == {'path', 'sha256', 'bytes'}
         and type(pin['path']) is str and type(pin['bytes']) is int
         and 0 <= pin['bytes'] <= maximum_bytes, 'bounded exact input pin')
    path = Path(pin['path'])
    need(path.is_absolute() and str(path.resolve()) == str(path)
         and path.is_file(), 'canonical actual input file')
    with path.open('rb') as stream:
        raw = stream.read(maximum_bytes + 1)
    need(len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256'],
         'whole same-buffer raw pin')
    if path.name.endswith('.gz'):
        with gzip.GzipFile(fileobj=io.BytesIO(raw), mode='rb') as stream:
            raw = stream.read(maximum_bytes + 1)
            need(len(raw) <= maximum_bytes and stream.read(1) == b'', 'entire decoded input')
    value = json.loads(raw)
    clock(deadline)
    return value


def guard_state(guard):
    need(type(guard) is types.FunctionType, 'production delegated validator is exact function')
    return (guard, guard.__code__, tuple(id(x) for x in guard.__defaults__ or ()),
            tuple((k, id(v)) for k, v in sorted((guard.__kwdefaults__ or {}).items())),
            tuple((id(c), id(c.cell_contents)) for c in guard.__closure__ or ()))


def method_state(endpoint):
    """Effective lookup and all property accessors, recursively through MRO."""
    result = []; seen = set(); namespace = getattr(endpoint, '__dict__', {})
    for owner in type(endpoint).__mro__:
        for name, descriptor in sorted(vars(owner).items()):
            if name in seen:
                continue
            seen.add(name)
            if isinstance(descriptor, property):
                functions = tuple(f for f in (descriptor.fget, descriptor.fset, descriptor.fdel)
                                  if f is not None)
                result.append((name, owner, descriptor,
                    tuple(guard_state(f) for f in functions)))
                continue
            if isinstance(descriptor, (staticmethod, classmethod)):
                function = descriptor.__func__
            elif type(descriptor) is types.FunctionType:
                function = descriptor
            else:
                continue
            need(name not in namespace, 'no ordinary instance method shadow: '+name)
            effective = getattr(endpoint, name)
            if isinstance(descriptor, staticmethod):
                need(effective is function, 'same static endpoint')
            else:
                receiver = type(endpoint) if isinstance(descriptor, classmethod) else endpoint
                need(type(effective) is types.MethodType and effective.__self__ is receiver
                     and effective.__func__ is function, 'same effective method')
            result.append((name, owner, descriptor, guard_state(function)))
    return tuple(result)


class Boundary:
    """An anchored outer validator, not a substitute for its cold admission."""
    __slots__ = ('guard', 'anchor', 'endpoints', 'methods', '_sealed')

    def __setattr__(self, name, value):
        if getattr(self, '_sealed', False):
            raise ValueError('sealed delegated validator boundary')
        object.__setattr__(self, name, value)

    def __init__(self, source_guard, endpoints, *, deadline):
        self._sealed = False
        self.guard = source_guard; self.anchor = guard_state(source_guard)
        self.endpoints = tuple(endpoints)
        self.methods = tuple(method_state(e) for e in self.endpoints)
        self._sealed = True
        self.check(deadline)

    def check(self, deadline):
        clock(deadline)
        need(guard_state(self.guard) == self.anchor, 'unchanged delegated guard')
        need(tuple(method_state(e) for e in self.endpoints) == self.methods,
             'unchanged effective objects/class/MRO/property accessors')
        self.guard()
        need(guard_state(self.guard) == self.anchor, 'validator unchanged after call')
        clock(deadline)


def term(value, theory):
    need(type(value) is list and len(value) == 3 and value[0] == 'fun'
         and type(value[1]) is str and value[2] == []
         and theory['functions'].get(value[1]) == 0,
         'initial declared closed nullary term scope only')
    return clone(value)


def replace_terms(value, replacements):
    """Exact AST data rewrite. No meta node may escape the resulting proof."""
    if type(value) is list:
        for original, replacement in replacements:
            if value == original:
                return clone(replacement)
        return [replace_terms(x, replacements) for x in value]
    if type(value) is dict:
        return {k: replace_terms(v, replacements) for k, v in value.items()}
    return value


def ground(value, parameters):
    if type(value) is list:
        if len(value) == 2 and value[0] == 'meta-term':
            need(value[1] in parameters, 'no unbound family meta')
            return clone(parameters[value[1]])
        return [ground(x, parameters) for x in value]
    if type(value) is dict:
        return {k: ground(v, parameters) for k, v in value.items()}
    return value


def literal_points(keys, records, fixed, *, deadline):
    totals = [0] * HEIGHT; marks = {}; counts = {}
    def assign(x, y, value):
        need(all(type(v) is int for v in (x, y, value)), 'exact integer point value')
        if (x, y) in marks and marks[x, y] != value:
            raise NoInstance('remote assigned values disagree, including zero')
        marks[x, y] = value; counts[x, y] = counts.get((x, y), 0) + 1
    for x, y, value in fixed:
        clock(deadline); assign(x, y, value)
    seen = set()
    for value in keys:
        clock(deadline); index, row, refs = key_data(value)
        need((index, row, refs) not in seen, 'distinct full placement counted once')
        seen.add((index, row, refs)); record = records[index]
        if totals[row]:
            raise NoInstance('different placements have same positive support')
        totals[row] = 1
        need(len(refs) == len(record['inputs']), 'whole ordered reference multiplicity')
        local = {(1, row): record['output']}
        for port, (ref, code) in enumerate(zip(refs, record['inputs'])):
            if (1, ref) in local and local[1, ref] != code:
                raise NoInstance('different input formulas cannot share one row')
            local[1, ref] = code; local[2+port, row] = ref-row
        for (x, y), mark in local.items():
            assign(x, y, mark)
    result = dict(totals=totals, t=[[0, r, n] for r, n in enumerate(totals) if n],
                  m=[[*p, v] for p, v in sorted(marks.items())],
                  marks=[[*p, v, counts[p]] for p, v in sorted(marks.items())])
    clock(deadline); return result


def ancestors(row, selected, records, *, deadline):
    found = set(); pending = [row]
    while pending:
        clock(deadline); current = pending.pop()
        if current in found:
            continue
        if current not in selected:
            return None
        index, actual, refs = selected[current]; record = records[index]
        need(actual == current and len(refs) == len(record['inputs']), 'exact ordered source key')
        found.add(current)
        for ref, code in zip(refs, record['inputs']):
            if (ref >= current or ref not in selected
                    or records[selected[ref][0]]['output'] != code):
                return None
            pending.append(ref)
    return sorted(found)


def reconstruct(row, selected, records, header, *, deadline):
    rows = ancestors(row, selected, records, deadline=deadline)
    if rows is None:
        raise NoInstance('incomplete current reader ancestry')
    gamma = header['context']['ordered_local_premises']
    need(len(gamma) == 3, 'current separately indexed three-occurrence ABI')
    all_rows = sorted(set(rows) | {0, 1, 2}); mapping = {}; commands = []; keys = []
    for r in all_rows:
        clock(deadline); index, actual, refs = selected[r]; record = records[index]
        command = clone(record['witness'])
        if r < 3:
            need(index == header['assumption_recipe_indices'][r] and refs == ()
                 and command == {'rule': 'assumption', 'index': r, 'formula': gamma[r]},
                 'same original occurrence, never formula-deduplicated')
        if command['rule'] == 'mp':
            need(all(ref in mapping for ref in refs), 'all ordered proof ancestors expanded')
            command.update(antecedent=mapping[refs[0]], implication=mapping[refs[1]])
        if command['rule'] == 'assumption':
            occurrence = command['index']
            need(type(occurrence) is int and 0 <= occurrence < len(gamma)
                 and command['formula'] == gamma[occurrence], 'original indexed assumption only')
        mapping[r] = len(commands); commands.append(command)
        keys.append([index, actual, list(refs)])
    need(row == all_rows[-1], 'root is last dependency-complete conclusion')
    return dict(commands=commands, primitive_keys=keys,
        exact_original_ordered_gamma=clone(gamma), conclusion=clone(records[selected[row][0]]['witness']['formula']),
        consumed_original_occurrence_indices=sorted({records[selected[r][0]]['witness']['index']
            for r in rows if records[selected[r][0]]['rule'] == 'assumption'}))


def complete_catalogue(reader, closed, header, license_pin, source_guard, *, deadline):
    """All original recipes and independent license lines, not a chosen subset."""
    clock(deadline); wire = reader.SelectedWire(header); records = {}
    boundary = Boundary(source_guard, (closed, wire), deadline=deadline)
    for index in range(wire.count):
        clock(deadline); records[index] = wire.recipe(index)
    reader.licenses(closed, license_pin, wire, records)
    boundary.check(deadline)
    return wire, records


def transport_body(commands, root, theory):
    """One eligible/ineligible result for EVERY closed-certificate command root."""
    final = commands[root]
    if final['rule'] != 'mp':
        return None, 'root_not_MP'
    first_index = final['implication']; first = commands[first_index]
    if first['rule'] != 'mp':
        return None, 'root_has_no_second_MP'
    subst_index = first['implication']; subst = commands[subst_index]
    if subst['rule'] != 'eq_subst':
        return None, 'body_has_no_equality_substitution'
    template = subst['template']
    if not (type(template) is list and len(template) == 3 and template[:2] == ['pred', 'Incident']
            and type(template[2]) is list and len(template[2]) == 2):
        return None, 'outside_initial_Incident_body_scope'
    positions = [i for i, value in enumerate(template[2]) if value == ['var', subst['variable']]]
    if len(positions) != 1:
        return None, 'not_one_whole_argument_hole'
    slot = positions[0]; other = template[2][1-slot]
    try:
        s = term(subst['left'], theory); t = term(subst['right'], theory); u = term(other, theory)
    except ValueError:
        return None, 'outside_closed_nullary_scope'
    # Initial training aliases are retained in evidence. Ambiguous slot-role
    # normalization is rejected, not asserted a universal alias restriction.
    if len({canonical(x) for x in (s, t, u)}) != 3:
        return None, 'training_meta_roles_alias_requires_separate_normalizer'
    eq_input = first['antecedent']; formula_input = final['antecedent']
    phi = lambda x: ['pred', 'Incident', [x, u] if slot == 0 else [u, x]]
    if (commands[eq_input]['formula'] != ['eq', s, t]
            or commands[formula_input]['formula'] != phi(s)
            or final['formula'] != phi(t)
            or subst['formula'] != ['imp', ['eq', s, t], ['imp', phi(s), phi(t)]]
            or first['formula'] != ['imp', phi(s), phi(t)]):
        return None, 'source_body_formula_or_ordered_port_mismatch'
    replacements = [(s, ['meta-term', 's']), (t, ['meta-term', 't']), (u, ['meta-term', 'u'])]
    body_indices = [subst_index, first_index, root]
    need(subst_index < first_index < root and eq_input < first_index and formula_input < root,
         'actual source primitive order strictly prior')
    body = []
    for index in body_indices:
        witness = {k: v for k, v in commands[index].items() if k not in ('antecedent', 'implication')}
        ports = [] if index == subst_index else (['input:equality', 'member:0']
                if index == first_index else ['input:formula', 'member:1'])
        body.append(dict(witness=replace_terms(witness, replacements), ordered_ports=ports))
    shape = dict(predicate='Incident', slot=slot, parameters=['s', 't', 'u'],
        input_receptors=[replace_terms(['eq', s, t], replacements), replace_terms(phi(s), replacements)],
        members=body, output=replace_terms(phi(t), replacements))
    return dict(shape=shape, body_command_indices=body_indices,
        ordered_external_command_indices=[eq_input, formula_input],
        original_parameters=dict(s=s, t=t, u=u)), 'eligible_Incident_transport'


def extract_training(*, training_spec, reader, checker_class, closed, source_guard, deadline):
    """Bound exact design/three certificates; reconstruct, do not trust commands.

    training_spec is the frozen training-inputs-v1.json in this SOURCE package,
    authenticated by the ROOT caller's fixed input closure. It includes no proof
    body or target codes. The output is candidate data, never library admission.
    """
    started = time.perf_counter(); boundary = Boundary(source_guard, (closed,), deadline=deadline)
    need(training_spec == raw_json(TRAINING_SPEC_PIN, deadline=deadline),
         'fixed SOURCE training spec, never arbitrary supplied target evidence')
    need(type(closed) is reader.ClosedInputs
         and str(Path(reader.SelectedWire.recipe.__code__.co_filename).resolve()) == DONOR_SOURCE_PINS['reader']['path'],
         'original donor reader separate from any fresh recipient profile')
    for pin in DONOR_SOURCE_PINS.values():
        closed.verify(pin)
    need(training_spec['schema'] == 'exact-three-equality-transport-training-inputs-v1'
         and len(training_spec['certificates']) == MAXIMUM_CERTIFICATES, 'exact training scope')
    for name in ('design', 'handoff'):
        closed.verify(training_spec[name]); raw_json(training_spec[name], deadline=deadline)
    mathematical = raw_json(training_spec['ROOT_mathematical_disposition'], deadline=deadline)
    closed.verify(training_spec['ROOT_mathematical_disposition'])
    need(mathematical['schema'] == 'ROOT-fresh-geometry-first-checked-proofs-disposition-v1'
         and mathematical['author_identity'] == '/root'
         and mathematical['ROOT_final_accepted'] is True
         and mathematical['checked_logical_derivations'] == MAXIMUM_CERTIFICATES,
         'original actual ROOT mathematical disposition, not source-only readiness')
    origins = []; candidates = []; derivations = []; correlations = {}
    for spec in training_spec['certificates']:
        boundary.check(deadline)
        cert = raw_json(spec['certificate'], deadline=deadline)
        result = raw_json(spec['result'], deadline=deadline)
        q = raw_json(spec['qualification'], deadline=deadline)
        header = raw_json(spec['header'], deadline=deadline)
        resource = raw_json(spec['resource_disposition'], deadline=deadline)
        for pin in (spec['certificate'], spec['result'], spec['qualification'], spec['header'], spec['licenses'], spec['resource_disposition']):
            closed.verify(pin)
        need(resource['resource_accepted'] is True and resource['result'] == spec['result']
             and resource['logical_certificate'] == spec['certificate']
             and any(t['logical_certificate'] == spec['certificate']
                     and t['ROOT_checked_logical_derivation_accepted'] is True
                     and t['resource_disposition'] == spec['resource_disposition']
                     for t in mathematical['trials']), 'entire actual training math/resource linkage')
        need(q['catalog'] == spec['header'] and q['independent']['licenses'] == spec['licenses']
             and q['schema'] == 'ROOT-qualified-compact-proof-context-v1'
             and q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True
             and q['instance_id'] == header['instance_id'] == spec['case']
             and cert['qualification_pin'] == spec['qualification'] and cert['result_pin'] == spec['result'],
             'exact original source/catalogue/result provenance')
        need(cert['schema'] == 'fresh-equality-first-proof-saved-certificate-v1'
             and cert['origin_kind'] in ('actual_selected', 'completed_source_proposal')
             and cert['original_Gamma_target_sequent_accepted'] is True
             and cert['native_accepted'] is False and cert['full24_board_accepted'] is False,
             'actual checked finite proof certificate, never incomplete prefix')
        checked = cert['checked_patch']; patch = checked['patch']
        need(digest(checked) == cert['checked_patch_sha256']
             and checked['origin_kind'] == cert['origin_kind']
             and checked['source_state_sha256'] in result['graph_states']
             and checked['source_state'] == result['graph_states'][checked['source_state_sha256']]
             and digest(checked['source_state']) == checked['source_state_sha256'],
             'complete actual source-state identity')
        if cert['origin_kind'] == 'actual_selected':
            need(cert['actual_selected_target_accepted'] is True
                 and cert['completed_source_proposal_target_accepted'] is False,
                 'selected origin distinct from proposal')
        else:
            need(cert['actual_selected_target_accepted'] is False
                 and cert['completed_source_proposal_target_accepted'] is True,
                 'proposed proof never relabeled selected')
            link = checked['source_link']; observation = result['candidate_advice']['observations'][link['advice_observation_index']]
            proposals = observation['selection']['preferred_cluster_proposals']
            need(any(p['root_receptor_row'] == checked['root_row']
                     and p['primitive_keys'] == patch['primitive_keys'] for p in proposals),
                 'complete retained producer proposal provenance')
        wire, records = complete_catalogue(reader, closed, header, spec['licenses'], source_guard, deadline=deadline)
        need(result['schema'] == 'compact24-first-checked-proof-scientific-DFS-v11-source'
             and result['mode'] in ('base', 'seed_forward') and result['seed'] is None
             and result['rng_draws'] == result['policy_choices'] == result['commits'] == []
             and result['training_updates'] == result['all_source_body_count'] == 0
             and wire.model_epoch() == result['model_epoch'] == checked['source_state']['model_epoch'],
             'original complete model/source result ABI and empty primitive inventory, no mode relabel')
        boundary = Boundary(source_guard, (closed, wire), deadline=deadline)
        selected = {key_data(k)[1]: key_data(k) for k in patch['primitive_keys']}
        need(len(selected) == len(patch['primitive_keys']), 'no duplicate row source identity')
        actual = {key_data(k)[1]: key_data(k) for k in checked['source_state']['order']}
        if cert['origin_kind'] == 'actual_selected':
            need(all(actual.get(r) == key for r, key in selected.items()), 'actual selected patch subset')
        else:
            need(all(r not in actual or actual[r] == key for r, key in selected.items()),
                 'proposal retains exact shared actual identities')
        rebuilt = reconstruct(checked['root_row'], selected, records, header, deadline=deadline)
        need(rebuilt['commands'] == patch['commands']
             and rebuilt['conclusion'] == header['target']
             and rebuilt['exact_original_ordered_gamma'] == patch['exact_original_ordered_gamma']
             and rebuilt['consumed_original_occurrence_indices'] == patch['consumed_original_occurrence_indices'],
             'all certificate commands/Gamma/ancestry independently reconstructed')
        checked_ground = checker_class(header['context']['theory']).proof(rebuilt['commands'],
            rebuilt['exact_original_ordered_gamma'], rebuilt['conclusion'])
        need(checked_ground['original_ground_sequent_accepted'] is True
             and checked_ground['native_accepted'] is False, 'fresh independent original-Gamma ground check')
        fixed = header['boundary']['fixed_exterior_m'] + header['boundary']['fixed_target_m']
        points = literal_points(patch['primitive_keys'], records, fixed, deadline=deadline)
        union = dict(actual); union.update(selected)
        whole = literal_points([[i, r, list(refs)] for i, r, refs in sorted(union.values(), key=lambda k:k[1])],
                               records, fixed, deadline=deadline)
        need(points == patch['literal_points'] and whole == checked['prospective_current_point_union']
             and checked['prospective_current_point_union_accepted'] is True,
             'complete source fixed/current point union')
        correlation = digest([rebuilt['exact_original_ordered_gamma'], rebuilt['conclusion']])
        correlations.setdefault(correlation, []).append(spec['certificate'])
        derivations.append(dict(certificate=spec['certificate'], origin=cert['origin_kind'],
            original_ordered_Gamma=rebuilt['exact_original_ordered_gamma'],
            consumed_original_occurrence_indices=rebuilt['consumed_original_occurrence_indices'],
            correlated_sequent_id=correlation, original_commands=rebuilt['commands'],
            original_keys=rebuilt['primitive_keys'], independent_ground_check=checked_ground))
        for root in range(len(rebuilt['commands'])):
            boundary.check(deadline)
            body, reason = transport_body(rebuilt['commands'], root, header['context']['theory'])
            origin = dict(certificate=spec['certificate'], command_root=root, origin=cert['origin_kind'],
                          eligible=body is not None, reason=reason, correlated_sequent_id=correlation)
            if body is not None:
                source_rows = [rebuilt['primitive_keys'][i][1] for i in body['body_command_indices']]
                closures = [ancestors(rebuilt['primitive_keys'][i][1], selected, records, deadline=deadline)
                            for i in body['ordered_external_command_indices']]
                body.update(origin=origin, source_body_rows=source_rows,
                    source_body_keys=[rebuilt['primitive_keys'][i] for i in body['body_command_indices']],
                    ordered_receptor_ancestor_rows=closures,
                    ordered_receptor_consumed_occurrences=[sorted({records[selected[r][0]]['witness']['index']
                        for r in rows if records[selected[r][0]]['rule']=='assumption'}) for rows in closures],
                    ambient_original_ordered_Gamma=rebuilt['exact_original_ordered_gamma'],
                    family_id='Incident-transport-'+digest(body['shape']))
                candidates.append(body); origin['family_id'] = body['family_id']
            origins.append(origin)
        boundary.check(deadline)
    grouped = {}
    for body in candidates:
        grouped.setdefault(body['family_id'], dict(family_id=body['family_id'], shape=body['shape'], evidence=[]))['evidence'].append(body)
    output = dict(schema=LIBRARY_SCHEMA, training_spec_sha256=digest(training_spec),
        families=[grouped[k] for k in sorted(grouped)], complete_origin_census=origins,
        derivations=derivations, correlated_sequents=correlations,
        ROOT_inventory_admitted=False, schema_universally_validated=False,
        primitive_source_body_count=0, source_only_producer=False,
        calls=dict(certificate_ground_checks_started=len(derivations),
                   certificate_ground_checks_completed=len(derivations)),
        elapsed_seconds_before_final_guards=time.perf_counter()-started)
    canonical(output); boundary.check(deadline)
    return output


def validate_I2_recipient(q, header, closed, *, deadline):
    """Metadata scope only; fresh consumer/graph qualification stays external.

    Keep the two original current I.2 static contexts byte-exact. A later
    SOURCE-reviewed consumer binding may change, never Gamma/catalogue/profile.
    No original donor proof, licence index or formula code is transplanted.
    """
    clock(deadline)
    bindings = raw_json(I2_RECIPIENT_BINDINGS_PIN, deadline=deadline)
    closed.verify(I2_RECIPIENT_BINDINGS_PIN)
    need(bindings['schema'] == 'exact-two-I2-recipient-static-bindings-v1'
         and bindings['recipient_reader'] == UPSTREAM_SOURCE_PINS['reader']
         and len(bindings['recipients']) == 2, 'exact current I.2 static scope')
    selected = next((r for r in bindings['recipients'] if r['instance_id'] == q.get('instance_id')), None)
    need(selected is not None, 'recipient outside the two declared I.2 contexts')
    base = closed.json(selected['original_qualification'])
    need(set(q) == set(base) and q['schema'] == 'ROOT-qualified-compact-proof-context-v1'
         and q['declaration_profile'] == selected['profile'] == 'hilbert-fresh-guarded-I2-cohort-static-v1'
         and q['declaration_inputs'] == selected['declaration_inputs'] == {'fixture': bindings['fixture']}
         and q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True,
         'exact11-field I.2 profile/fixture/static context')
    need({k: v for k, v in q.items() if k != 'expected_consumer_source_binding'}
         == {k: v for k, v in base.items() if k != 'expected_consumer_source_binding'},
         'only separately reviewed consumer binding may change; never static math identity')
    need(q['catalog'] == selected['catalog'] and header == closed.json(selected['catalog']),
         'exact original current catalogue/header/boundary/Gamma/target')
    fixture = closed.json(bindings['fixture'])
    profile = closed.json(bindings['static_profile'])
    static = closed.json(bindings['ROOT_static_disposition'])
    need(len(fixture['cases']) == bindings['fixture_case_count'] == 16
         and profile['profile_id'] == q['declaration_profile']
         and tuple(c['id'] for c in profile['selected_cases'])
             == tuple(r['instance_id'] for r in bindings['recipients'])
         and static['all_four_complete_static_stages_accepted'] is True
         and static['case_ids'] == [r['instance_id'] for r in bindings['recipients']],
         'whole current fixture/profile/actual complete static scope, not SOURCE-only qualification')
    closed.close(); clock(deadline)


class FamilySession:
    """Provisional ground checks; final target/trajectory authority is separate.

    The only library read is a ROOT-bound candidate wire, authenticated by the
    same full raw closure as its single explicit advice-admission record. Cold
    source loading/static q/G/resource qualification remain the caller's job.
    No pre-existing ROOT record is required for each newly sampled grounding.
    """
    __slots__ = ('graph', 'reader', 'checker_class', 'closed', 'header', 'wire',
        'key_type', '_boundary', '_anchors', '_header_text', '_record_texts',
        '_lookup', '_library_text', '_library_pin_text', '_families', '_binding', '_instances',
        'metrics', 'construction', '_sealed')

    def __setattr__(self, name, value):
        if getattr(self, '_sealed', False):
            raise ValueError('sealed family session attributes')
        object.__setattr__(self, name, value)

    def __init__(self, graph, *, reader, checker_class, closed, header,
                 license_pin, library_pin, admission_pin, implementation_pin,
                 source_guard, deadline):
        self._sealed = False; started = time.perf_counter(); clock(deadline)
        boundary = Boundary(source_guard, (closed, graph, graph.catalog), deadline=deadline)
        need(type(closed) is reader.ClosedInputs and graph.height == HEIGHT
             and graph.catalog.header == header and header['dimensions']['source_body_count'] == 0,
             'admitted current exact graph/context and unchanged primitive body inventory')
        need(reader.SelectedWire.__module__ == reader.__name__
             and str(Path(reader.SelectedWire.recipe.__code__.co_filename).resolve()) == UPSTREAM_SOURCE_PINS['reader']['path']
             and str(Path(checker_class.proof.__code__.co_filename).resolve()) == UPSTREAM_SOURCE_PINS['logical_oracle']['path'],
             'fixed reader/kernel endpoints; filenames are necessary but not executable authority')
        for pin in UPSTREAM_SOURCE_PINS.values():
            closed.verify(pin)
        admission = closed.json(admission_pin); library = closed.json(library_pin)
        need(admission['schema'] == ADMISSION_SCHEMA
             and admission['library'] == library_pin
             and admission['implementation'] == implementation_pin
             and admission['ROOT_advice_library_accepted'] is True
             and admission['advice_only'] is True
             and admission['primitive_source_body_count'] == 0
             and admission['theory_sha256'] == digest(header['context']['theory'])
             and admission['schema_universally_validated'] is False,
             'explicit ROOT finite advice library authority, not producer flags')
        need(admission['upstream_sources'] == UPSTREAM_SOURCE_PINS,
             'exact fixed source allowlist; arbitrary injected source records rejected')
        recipient_q = closed.json(admission['recipient_qualification'])
        validate_I2_recipient(recipient_q, header, closed, deadline=deadline)
        boundary.check(deadline)
        closed.verify(implementation_pin)
        need(str(Path(__file__).resolve()) == implementation_pin['path'],
             'implementation raw binding; executed buffers separately cold-authenticated')
        need(library['schema'] == LIBRARY_SCHEMA and library['ROOT_inventory_admitted'] is False
             and library['schema_universally_validated'] is False
             and library['primitive_source_body_count'] == 0,
             'passive complete candidate library, no new axiom/body authority')
        wire, records = complete_catalogue(reader, closed, header, license_pin, source_guard, deadline=deadline)
        families = []
        for family in library['families']:
            clock(deadline); shape = family['shape']
            need(family['family_id'] == 'Incident-transport-'+digest(shape)
                 and shape['predicate'] == 'Incident' and type(shape['slot']) is int
                 and shape['slot'] in (0, 1) and shape['parameters'] == ['s', 't', 'u']
                 and len(shape['members']) == 3 and len(shape['input_receptors']) == 2
                 and family['evidence'], 'finite mined Incident slot body and full evidence retained')
            need(shape['members'][0]['witness']['rule'] == 'eq_subst'
                 and shape['members'][0]['ordered_ports'] == []
                 and shape['members'][1]['witness']['rule'] == 'mp'
                 and shape['members'][1]['ordered_ports'] == ['input:equality', 'member:0']
                 and shape['members'][2]['witness']['rule'] == 'mp'
                 and shape['members'][2]['ordered_ports'] == ['input:formula', 'member:1'],
                 'preserved actual primitive and ordered input-port schema')
            families.append(canonical(family))
        need(len({json.loads(f)['family_id'] for f in families}) == len(families),
             'unique family identity; no favorable subset')
        need(header['context']['theory']['predicates'].get('Incident') == 2,
             'declared binary Incident signature, no logical sort extension')
        self.graph = graph; self.reader = reader; self.checker_class = checker_class
        self.closed = closed; self.header = header; self.wire = wire
        self.key_type = graph._bound_core.Key
        self._boundary = Boundary(source_guard, (closed, graph, graph.catalog, wire), deadline=deadline)
        self._anchors = (graph, type(graph), graph.catalog, type(graph.catalog), reader,
                         checker_class, closed, type(closed), wire, type(wire), self.key_type)
        self._header_text = canonical(header)
        self._record_texts = tuple(canonical(records[i]) for i in range(wire.count))
        self._lookup = tuple(sorted((canonical([record['witness'], record['premises']]), i)
                                    for i, record in records.items()))
        self._library_text = canonical(library); self._library_pin_text = canonical(library_pin)
        self._families = tuple(families)
        self._binding = (graph.model_epoch, graph.catalog_identity_sha, graph.runtime_authority_sha)
        self._instances = ()
        self.metrics = dict(instance_calls_started=0, instance_calls_completed=0,
            ground_checks_started=0, ground_checks_completed=0, ground_checks_accepted=0,
            final_point_calls_started=0, final_point_calls_completed=0,
            embedding_point_calls_started=0, embedding_point_calls_completed=0,
            current_point_calls_started=0, current_point_calls_completed=0,
            exact_legality_calls=0, completed_instance_seconds_before_final_guards=0.0)
        self.construction = dict(version=VERSION, completed=True, all_licenses=wire.count,
            complete_family_count=len(families), library_pin=clone(library_pin),
            admission_pin=clone(admission_pin), primitive_source_body_count=0,
            seconds=time.perf_counter()-started)
        self._sealed = True; self._guard(deadline)

    def _guard(self, deadline):
        clock(deadline)
        need(all(current is original for current, original in zip(
             (self.graph, type(self.graph), self.graph.catalog, type(self.graph.catalog), self.reader,
              self.checker_class, self.closed, type(self.closed), self.wire, type(self.wire), self.key_type),
             self._anchors)), 'same original runtime endpoint objects/types')
        self._boundary.check(deadline); self.graph.assert_runtime_integrity()
        need(canonical(self.header) == canonical(self.wire.header) == canonical(self.graph.catalog.header)
             == self._header_text and (self.graph.model_epoch, self.graph.catalog_identity_sha,
                self.graph.runtime_authority_sha) == self._binding,
             'unchanged full context/catalogue/runtime identity')
        need(all(canonical(receipt) == text for receipt, text in self._instances),
             'provisional instance records cannot be rebound or edited')
        self.closed.close(); clock(deadline)

    def record(self, index):
        need(type(index) is int and 0 <= index < len(self._record_texts), 'complete recipe index')
        return json.loads(self._record_texts[index])

    def families(self):
        return tuple(json.loads(f) for f in self._families)

    def snapshot(self, *, deadline):
        self._guard(deadline); state = self.graph.semantic_state(); selected = {}
        records = {}
        for value in state['order']:
            clock(deadline); index, row, refs = key_data(value)
            need(row not in selected, 'one actual full identity per row')
            records[index] = self.record(index); selected[row] = (index, row, refs)
        for r in range(3):
            need(selected.get(r) == (self.header['assumption_recipe_indices'][r], r, ()),
                 'each original Gamma occurrence seed retained')
        fixed = self.header['boundary']['fixed_exterior_m'] + self.header['boundary']['fixed_target_m']
        self.metrics['current_point_calls_started'] += 1
        points = literal_points(state['order'], records, fixed, deadline=deadline)
        self.metrics['current_point_calls_completed'] += 1
        need(points['totals'] == state['totals'] and points['marks'] == state['marks'],
             'entire actual point totals/assignments/refcounts reconstructed')
        complete = {r: records[selected[r][0]]['output'] for r in sorted(selected)
                    if ancestors(r, selected, records, deadline=deadline) is not None}
        self._guard(deadline)
        need(digest(self.graph.semantic_state()) == digest(state),
             'no state change during current snapshot final guards')
        clock(deadline)
        return state, selected, complete

    def begin_call(self, *, deadline):
        self._guard(deadline)
        object.__setattr__(self, '_instances', ())
        return self.snapshot(deadline=deadline)

    def instantiate(self, *, family_id, equality_key, formula_key, deadline, previous=None):
        started = time.perf_counter(); self.metrics['instance_calls_started'] += 1
        self._guard(deadline); state, actual, complete = self.snapshot(deadline=deadline)
        state_sha = digest(state); selected = dict(actual)
        if previous is not None:
            need(any(previous is item for item, text in self._instances)
                 and previous['source_state_sha256'] == state_sha,
                 'only fresh internally checked prior-family composition')
            for value in previous['primitive_keys']:
                index, row, refs = key_data(value)
                need(row not in selected or selected[row] == (index, row, refs), 'exact shared placement')
                selected[row] = (index, row, refs)
        records = {key[0]: self.record(key[0]) for key in selected.values()}
        eqkey = key_data(equality_key); phikey = key_data(formula_key)
        for key in (eqkey, phikey):
            need(selected.get(key[1]) == key, 'actual or same-call planned receptor identity')
            if ancestors(key[1], selected, records, deadline=deadline) is None:
                raise NoInstance('pending selected reader is not a receptor fact')
        equality = records[eqkey[0]]['witness']['formula']; phi = records[phikey[0]]['witness']['formula']
        family = next((f for f in self.families() if f['family_id'] == family_id), None)
        need(family is not None, 'admitted library family ID only')
        shape = family['shape']; slot = shape['slot']; theory = self.header['context']['theory']
        if not (type(equality) is list and len(equality) == 3 and equality[0] == 'eq'
                and type(phi) is list and len(phi) == 3 and phi[:2] == ['pred', 'Incident']
                and len(phi[2]) == 2 and phi[2][slot] == equality[1]):
            raise NoInstance('ordered equality/formula receptors do not unify')
        try:
            parameters = dict(s=term(equality[1], theory), t=term(equality[2], theory), u=term(phi[2][1-slot], theory))
        except ValueError as exc:
            raise NoInstance('outside declared ground nullary parameter scope') from exc
        need([ground(x, parameters) for x in shape['input_receptors']] == [equality, phi],
             'same exact substitution at every receptor occurrence')
        # All terms are closed, so no free/bound variable can be captured. The
        # mined hole name itself must remain the licensed catalogue name.
        sources = {'input:equality': eqkey[1], 'input:formula': phikey[1]}
        new_keys = []
        for member_index, member in enumerate(shape['members']):
            self._guard(deadline)
            witness = ground(member['witness'], parameters)
            refs = tuple(sources[port] for port in member['ordered_ports'])
            premises = [records[selected[r][0]]['witness']['formula'] for r in refs]
            preimage = canonical([witness, premises])
            index = next((i for signature, i in self._lookup if signature == preimage), None)
            if index is None:
                raise NoInstance('ground body absent from complete current licensed catalogue')
            record = self.record(index); records[index] = record
            reused = next((k for r, k in sorted(selected.items()) if k[0] == index and k[2] == refs
                           and (r in complete or r not in actual)), None)
            if reused is None:
                chosen = None
                for row in range(3, HEIGHT):
                    clock(deadline)
                    if row in selected or any(ref >= row for ref in refs):
                        continue
                    key = self.key_type(index, row, refs); self.metrics['exact_legality_calls'] += 1
                    if not self.graph.legal(key):
                        continue
                    trial = dict(selected); trial[row] = (index, row, refs)
                    try:
                        fixed = self.header['boundary']['fixed_exterior_m'] + self.header['boundary']['fixed_target_m']
                        self.metrics['embedding_point_calls_started'] += 1
                        literal_points([[i, r, list(rs)] for i, r, rs in sorted(trial.values(),key=lambda k:k[1])],
                                       records, fixed, deadline=deadline)
                        self.metrics['embedding_point_calls_completed'] += 1
                    except NoInstance:
                        continue
                    chosen = (index, row, refs); break
                if chosen is None:
                    raise NoInstance('greedy strict-prior current-union placement unavailable')
                selected[chosen[1]] = chosen; new_keys.append(chosen); reused = chosen
            sources['member:'+str(member_index)] = reused[1]
        root = sources['member:2']
        expanded = reconstruct(root, selected, records, self.header, deadline=deadline)
        self.metrics['ground_checks_started'] += 1
        try:
            checked = self.checker_class(theory).proof(expanded['commands'],
                expanded['exact_original_ordered_gamma'], expanded['conclusion'])
        except ValueError as exc:
            raise NoInstance('independent ground checker rejected expansion') from exc
        self.metrics['ground_checks_completed'] += 1
        if checked['original_ground_sequent_accepted'] is not True or checked['native_accepted'] is not False:
            raise NoInstance('expanded original-Gamma proof not independently accepted')
        self.metrics['ground_checks_accepted'] += 1
        fixed = self.header['boundary']['fixed_exterior_m'] + self.header['boundary']['fixed_target_m']
        self.metrics['final_point_calls_started'] += 1
        whole = literal_points([[i, r, list(rs)] for i, r, rs in sorted(selected.values(),key=lambda k:k[1])],
                               records, fixed, deadline=deadline)
        self.metrics['final_point_calls_completed'] += 1
        self.metrics['final_point_calls_started'] += 1
        patch = literal_points(expanded['primitive_keys'], records, fixed, deadline=deadline)
        self.metrics['final_point_calls_completed'] += 1
        self._guard(deadline)
        need(digest(self.graph.semantic_state()) == state_sha, 'state changed during provisional instance check')
        keys = expanded['primitive_keys']
        result = dict(schema='checked-provisional-Incident-transport-instance-v1', family_id=family_id,
            source_state_sha256=state_sha, library_binding=json.loads(self._library_pin_text),
            library_payload_sha256=hashlib.sha256(self._library_text.encode()).hexdigest(),
            parameters=parameters, ordered_receptor_keys=[list(eqkey[:2])+[list(eqkey[2])],
                list(phikey[:2])+[list(phikey[2])]], root_receptor_row=root,
            primitive_keys=keys, new_primitive_keys=[k for k in keys if key_data(k) not in set(actual.values())],
            commands=expanded['commands'], exact_original_ordered_Gamma=expanded['exact_original_ordered_gamma'],
            consumed_original_occurrence_indices=expanded['consumed_original_occurrence_indices'],
            conclusion=expanded['conclusion'], independent_ground_check=checked,
            literal_points=patch, whole_current_point_union=whole, completed=True,
            original_Gamma_target_accepted=False, actual_selected_target_accepted=False,
            full24_board_accepted=False, ROOT_inventory_admitted=False, native_accepted=False,
            macro_executed=False, primitive_source_body_count=0,
            seconds_before_final_guards=time.perf_counter()-started)
        text = canonical(result); self._guard(deadline)
        old_instances = self._instances
        object.__setattr__(self, '_instances', self._instances+((result, text),))
        self.metrics['instance_calls_completed'] += 1
        elapsed = time.perf_counter()-started
        self.metrics['completed_instance_seconds_before_final_guards'] += elapsed
        try:
            self._guard(deadline)
            need(digest(self.graph.semantic_state()) == state_sha,
                 'no state change during final instance guards')
            clock(deadline)
        except BaseException:
            object.__setattr__(self, '_instances', old_instances)
            self.metrics['instance_calls_completed'] -= 1
            self.metrics['completed_instance_seconds_before_final_guards'] -= elapsed
            raise
        return result


class GoalDependencyAdvice:
    """Compatible preferred() shape; one explicit constructor successor needed.

    All current complete equality/Incident receptors are scanned target-blind.
    Advice is deliberately bounded to single transport or two-family chains;
    this bounds proposal cost, never the primitive universe or forced counts.
    """
    __slots__ = ('session', 'graph', 'recipes', '_recipe_methods', '_construction', '_sealed')

    def __setattr__(self, name, value):
        if getattr(self, '_sealed', False):
            raise ValueError('sealed advice endpoints')
        object.__setattr__(self, name, value)

    def __init__(self, graph, recipes, *, deadline, family_session):
        self._sealed = False; clock(deadline)
        need(type(family_session) is FamilySession and family_session.graph is graph,
             'exact checked session and current graph')
        family_session._guard(deadline)
        expected_view = graph.feature_views.__func__.__globals__['RecipeMetadataView']
        need(type(recipes) is expected_view
             and getattr(recipes, 'catalog', None) is graph.catalog
             and len(recipes) == len(family_session._record_texts),
             'actual indexed recipe view and exact checked session, never a supplied list')
        family_session._guard(deadline)
        self.session = family_session; self.graph = graph; self.recipes = recipes
        self._recipe_methods = method_state(recipes)
        self._construction = canonical(dict(family_session.construction,
            control='deterministic mined equality-receptor family composition',
            target_used_for_ranking=False, maximum_composed_families=2,
            no_RL=True, full_primitive_fallback_retained=True))
        self._sealed = True; clock(deadline)

    def construction_record(self):
        return json.loads(self._construction)

    def preferred(self, graph, decision, *, complete_rows, key_type, deadline):
        started = time.perf_counter(); session = self.session
        session._guard(deadline)
        need(method_state(self.recipes) == self._recipe_methods,
             'unchanged actual indexed metadata view methods')
        need(graph is self.graph and decision == graph.decision()
             and decision.kind in ('branch', 'forced') and key_type is session.key_type,
             'unchanged master selected domain and exact Key type')
        binding = graph.membership_binding(decision)
        keys = []; proposals = []; seen_keys = set(); seen_proposals = set(); reasons = {}
        submitted = 0; batch_receipt = None; capped = False
        metrics_before = clone(session.metrics)
        try:
            if decision.kind == 'branch':
                state, selected, complete = session.begin_call(deadline=deadline)
                need(type(complete_rows) is dict
                     and all(type(r) is int and type(code) is int for r, code in complete_rows.items())
                     and complete_rows == complete,
                     'passed facts equal independent dependency-complete current census')
                eqs = [selected[r] for r in sorted(complete)
                       if session.record(selected[r][0])['witness']['formula'][0] == 'eq']
                phis = [selected[r] for r in sorted(complete)
                        if session.record(selected[r][0])['witness']['formula'][:2] == ['pred', 'Incident']]

                def retain(instance):
                    nonlocal capped
                    clock(deadline)
                    chosen = [key_type(i, r, tuple(refs)) for i, r, refs in instance['new_primitive_keys']
                              if r == decision.row]
                    need(len(chosen) <= 1, 'unit chosen-row placement')
                    if not chosen:
                        return
                    token = digest([instance['primitive_keys'], instance['root_receptor_row']])
                    if token not in seen_proposals:
                        # Keep complete chain proposals even when the first
                        # preferred primitive is shared with a shorter proposal.
                        seen_proposals.add(token); proposals.append(instance)
                    if chosen[0] not in seen_keys:
                        seen_keys.add(chosen[0]); keys.append(chosen[0])
                    capped = len(proposals) >= MAXIMUM_PREFERRED

                for family in session.families():
                    for equality_key in eqs:
                        for formula_key in phis:
                            clock(deadline)
                            if capped:
                                break
                            submitted += 1
                            try:
                                first = session.instantiate(family_id=family['family_id'],
                                    equality_key=equality_key, formula_key=formula_key, deadline=deadline)
                            except NoInstance as exc:
                                reasons[str(exc)] = reasons.get(str(exc), 0)+1; continue
                            retain(first)
                            if capped:
                                break
                            root_key = next(k for k in first['primitive_keys'] if k[1] == first['root_receptor_row'])
                            for second_family in session.families():
                                for second_equality in eqs:
                                    clock(deadline)
                                    if capped:
                                        break
                                    submitted += 1
                                    try:
                                        chained = session.instantiate(family_id=second_family['family_id'],
                                            equality_key=second_equality, formula_key=root_key,
                                            previous=first, deadline=deadline)
                                    except NoInstance as exc:
                                        reasons[str(exc)] = reasons.get(str(exc), 0)+1; continue
                                    retain(chained)
                                if capped:
                                    break
                        if capped:
                            break
                    if capped:
                        break
                try:
                    flags, batch_receipt = graph.legal_batch(decision, tuple(keys),
                        expected_binding=binding, deadline=deadline)
                except graph.MembershipBudgetExceeded as exc:
                    raise FamilyBudgetExceeded('unfinished selected-domain batch; no advice prefix') from exc
                need(type(flags) is tuple and len(flags) == len(keys)
                     and all(type(flag) is bool for flag in flags)
                     and batch_receipt['completed'] is True
                     and batch_receipt['partial_results_returned'] is False,
                     'whole exact chosen-domain batch, no partial advice')
                keys = [key for key, flag in zip(keys, flags) if flag]
                legal_chosen = {tuple([key.recipe, key.row, tuple(key.refs)]) for key in keys}
                proposals = [p for p in proposals if any(key_data(k) in legal_chosen
                    for k in p['new_primitive_keys'] if k[1] == decision.row)]
            record = dict(version=VERSION, decision=[decision.kind, decision.row, decision.count, decision.generation],
                preferred_count=len(keys), preferred_cluster_proposals=proposals,
                forced_advice_empty=decision.kind == 'forced', requests_started=submitted,
                failed_instance_reasons=reasons, selected_domain_membership=batch_receipt,
                proposal_pool_capped=capped, proposal_pool_is_not_base_domain=True,
                complete_canonical_fallback_retained=True, target_used_for_ranking=False,
                original_occurrence_and_port_identity_preserved=True,
                learned_marking=False, pruning=False, macro_executed=False, RNG_draws=0,
                independent_target_certificate_issued=False, inventory_admission=False,
                metric_units='actual calls/returned checks; inclusive nested seconds, not descriptor estimates',
                metrics_before=metrics_before, metrics_after=clone(session.metrics),
                seconds_before_final_guards=time.perf_counter()-started)
            canonical(record)
        finally:
            session._guard(deadline)
            need(graph.membership_binding(decision) == binding,
                 'placement/exclusion/rollback/decision/domain changed; no stale advice')
        clock(deadline)
        return tuple(keys), record


AdviceBudgetExceeded = FamilyBudgetExceeded


# Fixed SOURCE inputs. Future profile/reader changes need an explicit reviewed successor.
TRAINING_SPEC_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-implementation-source-20261013/training-inputs-v1.json', 'sha256': 'de34653e96673e080c65a6c17fad3cc24cfb00ab0043fdc11c9741e6708f382c', 'bytes': 8340}
UPSTREAM_SOURCE_PINS = {'reader': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-i2-first-proof-helper-source-20261013/i2_context_and_final24_certificate_v1.py', 'sha256': 'c8fa4aeba82fcc2af9bd091fd351d72f86a24ae97cb5edd92ff558e81c23501b', 'bytes': 64498}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'dynamic_graph': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}}
DONOR_SOURCE_PINS = {'reader': {'bytes': 64540, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/fresh_equality_context_and_final24_certificate_v3.py', 'sha256': '5d03d088c2d1b7f90e98fb7e28819ab0643b74f6786953c6107d4d2535c2377b'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'dynamic_graph': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}}
I2_RECIPIENT_BINDINGS_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/equality-receptor-family-I2-recipient-source-20261014/I2-recipient-bindings-v1.json', 'sha256': '92eeeb7dbac6b6a228e509abb79b4193c83eae9a97303404b1e403ccbf4f21fb', 'bytes': 3983}
