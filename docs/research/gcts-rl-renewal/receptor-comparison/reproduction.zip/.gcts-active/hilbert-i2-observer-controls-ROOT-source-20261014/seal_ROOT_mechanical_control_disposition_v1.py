"""ROOT saved-resource/result metadata disposition; no proof or control replay."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROGRESS=ROOT/'.gcts-active/hilbert-i2-observer-controls-progress-v1-20261014'
PEER=ROOT/'.gcts-active/receptor-i2-independent-implementation-review-20261013'

def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    assert path.resolve()==path
    raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def check(record):
    actual=pin(record['path']);assert actual['sha256']==record['sha256'] and actual['bytes']==record['bytes']
    return actual

def read(path):return json.loads(Path(path).read_bytes())

def main():
    leaf_path=PROGRESS/'controls-worker-plan-v1.json';leaf=read(leaf_path)
    assert pin(leaf_path)['sha256']=='1c457a1cc880c4c197313a00934885f6658c6deb78a29d739c689b9dc2fadec2'
    decision_path=PROGRESS/'replay-ROOT-final-decision-v1.json';decision=read(decision_path)
    assert decision['ROOT_final_accepted'] is True and len(decision['predicates'])==14 and all(v is True for v in decision['predicates'].values())
    for key in ('plan','actual_tool','owner','post_write','worker'):check(decision[key])
    worker_path=PROGRESS/'replay-result-v1/worker-receipt-v1.json';worker=read(worker_path)
    assert check(decision['worker'])==pin(worker_path)
    assert worker['stage_completed'] is True and worker['all_controls_passed'] is True
    assert worker['scope']=='synthetic-observer-semantics-only' and worker['fresh_target_proof_discovered'] is False
    assert worker['mathematical_proofs_accepted']==0 and worker['target_searches']==0 and worker['new_RL_training'] is False
    assert worker['sources']==leaf['sources'] and check(worker['plan'])==pin(leaf_path)
    result_pin=check(worker['result']);result=read(result_pin['path'])
    assert result_pin['sha256']=='ee8a71e9eb19afba92a7d9b1a8f32ef4953eb023f7bb13d1a088fd854bd782b8'
    assert result['completed'] is True and result['all_controls_passed'] is True
    assert result['check_count']==len(result['checks'])==45 and all(c['passed'] is True for c in result['checks'])
    assert result['fresh_target_proof_discovered'] is False and result['static_or_full24_native_trajectory_inventory_RL_accepted'] is False
    evidence_pin=check(worker['evidence']);evidence=read(evidence_pin['path'])
    assert evidence['result']==result_pin and evidence['sources']==leaf['sources'] and evidence['scope']==worker['scope']
    assert evidence['control_call_seconds']<leaf['limits']['control_seconds']
    for record in leaf['closure']:check(record)
    source_review=read(leaf['reviews']['independent']['path']);check(leaf['reviews']['independent'])
    assert source_review['source_review_passed'] is True and source_review['sources']==leaf['sources']
    saved_review_pin=pin(PEER/'I2-observer-controls-actual-saved-findings-v1.json')
    assert saved_review_pin['sha256']=='9a638684826b2cd96cde8ce9a8f89f8397f45e27aec4a4dfa0bd7ec29ccc9f22'
    saved_review=read(saved_review_pin['path'])
    assert saved_review['all_checks_passed'] is True and saved_review['scientific_calls']==0
    mechanism={r:leaf['sources'][r] for r in ('proof_observer','streamed_dfs','certificate')}
    assert worker['mechanism_sources']==mechanism
    value=dict(schema='ROOT-first-checked-proof-observer-conformance-disposition-v1',
        ROOT_final_accepted=True,all_controls_passed=True,scope='synthetic-observer-semantics-only',
        fresh_target_proof_discovered=False,sources=mechanism,result=result_pin,
        author_identity='/root',scientific_calls_in_this_metadata_seal=0,
        actual_once_only_control_attempts=1,restarts=0,checks=result['checks'],check_count=45,
        raw_guard_calls=result['raw_code_guard_calls'],control_call_seconds=evidence['control_call_seconds'],
        caller_elapsed_seconds=decision['caller_elapsed_seconds'],limits=leaf['limits'],
        resource_disposition=pin(decision_path),worker_receipt=pin(worker_path),evidence=evidence_pin,
        independent_saved_metadata_review=saved_review_pin,
        prior_independent_preactivation_plan_review_claimed=False,independent_SOURCE_review=leaf['reviews']['independent'],
        ROOT_SOURCE_review=leaf['reviews']['ROOT'],provenance=pin(__file__),
        actual_runtime_source_functions_exercised=['proof_observer','streamed_dfs','logical_oracle'],
        certificate_source_authenticated_but_not_executed=True,
        production_q_G5_wire_scheduler_and_catalogue_qualified=False,
        synthetic_delay_hooks_are_not_production_clock_qualification=True,
        fresh_target_searches=0,fresh_target_proofs_discovered=0,full24_accepted=False,
        native_accepted=False,full_trajectory_accepted=False,inventory_admitted=False,new_RL_training=False,
        research_program_complete=False,
        assessment='All45 actual mechanical checks and all14 owned/caller resource predicates passed on the once-only run. The observer, DFS and independent logical checker were exercised on explicit unrelated test doubles. This admits only generic mechanical semantics for the exact three current I.2 source pins. All saved metadata was independently reconciled after the actual run; no prior independent plan review is claimed. Production catalogue/graph integration, adviser, fresh target searches and proofs remain separate.')
    destination=HERE/'ROOT-first-checked-proof-observer-conformance-disposition-v1.json'
    with destination.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(dict(disposition=pin(destination),accepted=True,actual_mechanical_checks=45,resource_checks=14,fresh_target_searches=0,scientific_calls_in_seal=0)))

if __name__=='__main__':main()
