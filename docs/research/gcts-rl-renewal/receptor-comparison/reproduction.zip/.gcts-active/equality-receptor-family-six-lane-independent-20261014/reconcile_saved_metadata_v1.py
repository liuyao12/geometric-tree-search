"""Independent SAVED-METADATA ONLY; never imports or invokes project sources.
Whole authenticated buffers, raw pins, finite integer/data projections; no logic replay.
"""
import collections,gzip,hashlib,io,json,math,pathlib,struct
ROOT=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
P=ROOT/'.gcts-active/equality-receptor-family-six-lane-progress-v2-20261014'
OUT=ROOT/'.gcts-active/equality-receptor-family-six-lane-independent-20261014'
cache={}; pins={}; docs={}; checks=[]; references=0

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(x):return hashlib.sha256(canonical(x)).hexdigest()
def path(x):
 p=pathlib.Path(x);return p if p.is_absolute() else ROOT/p

def check(name,v,detail=None):
 if not v:raise AssertionError(name if detail is None else (name,detail))
 checks.append(dict(check=name,passed=True))

def raw(x,expected=None):
 global references
 p=path(x); key=str(p)
 if key not in cache:
  b=p.read_bytes();cache[key]=b;pins[key]=dict(path=key,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
 b=cache[key]
 if expected is not None:
  references+=1
  if len(b)!=expected['bytes'] or hashlib.sha256(b).hexdigest()!=expected['sha256']:raise AssertionError(('raw_pin',expected))
 return b

def pin(x):raw(x);return pins[str(path(x))]
def eqpin(a,b):return str(path(a['path']))==str(path(b['path'])) and a['sha256']==b['sha256'] and a['bytes']==b['bytes']
def whole_gzip(b):
 with gzip.GzipFile(fileobj=io.BytesIO(b),mode='rb') as f:
  decoded=f.read(64*1024*1024+1)
  if len(decoded)>64*1024*1024 or f.read(1):raise AssertionError('whole bounded gzip EOF')
 return decoded

def walk(x):
 if isinstance(x,dict):
  if {'path','sha256','bytes'}<=set(x) and isinstance(x['path'],str) and isinstance(x['sha256'],str) and type(x['bytes']) is int:
   raw(x['path'],x);return
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)

def read(x,expected=None):
 if isinstance(x,dict):expected=x;x=x['path']
 b=raw(x,expected);p=path(x)
 d=json.loads(whole_gzip(b) if p.suffix=='.gz' else b);docs[str(p)]=d;walk(d);return d

def state_ref(s):return s['overlay']['controller']['graph_state_sha256']
def scalar_close(a,b):return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-9)

construction=read(P/'ROOT-construction-v1.json')
root_seal=read(P/'ROOT-actual-six-lane-comparison-disposition-v1.json')
prereg=read(root_seal['preregistration'])
check('six actual root resource outcomes',root_seal['all_six_actual_scientific_invocations_resource_accepted'] is True and root_seal['actual_scientific_invocations']==6)
check('balanced literal order preserved',root_seal['preregistered_order']==construction['exact_preregistered_schedule'])
all_sources=None;cases={};lanes=[];proofs=[];results={}
for selector in ('fresh-i2-CD-vw-direct','fresh-i2-CD-vw-incidence-transport'):
 q=read(construction['qualified_contexts'][selector]);header=read(q['catalog'])
 check(selector+'/qualified complete static source scope',q['instance_id']==selector and q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True and q['status']=='accepted_complete_catalog_and_initial_point_model' and len(q)==11)
 check(selector+'/whole catalogue empty and boundary',header['height']==24 and header['orientation']=='identity' and header['bodies']==header['complete_cluster_inventory']==[] and header['boundary']['required']==[[0,r] for r in range(24)] and header['boundary']['fixed_target_m']==[[1,23,header['target_code']]] and len(header['hypothesis_codes'])==3)
 phases={}
 for ph in ('producer','independent'):
  phases[ph]={k:read(q[ph][k]) for k in ('plan','receipt','evidence','ROOT_decision')}
  check(selector+'/'+ph+'/actual complete ROOT resources',phases[ph]['ROOT_decision']['ROOT_final_accepted'] is True and len(phases[ph]['ROOT_decision']['predicates'])==14 and all(phases[ph]['ROOT_decision']['predicates'].values()))
 recipe_bytes=raw(header['streams']['recipes']['path'],header['streams']['recipes']); fmt=struct.Struct('<11Q32s32s')
 check(selector+'/complete recipe binary rows',len(recipe_bytes)==fmt.size*header['dimensions']['primitive_license_count'])
 fields=[fmt.unpack_from(recipe_bytes,i*fmt.size) for i in range(header['dimensions']['primitive_license_count'])]
 licraw=whole_gzip(raw(q['independent']['licenses']['path'],q['independent']['licenses']));licenses=[json.loads(line) for line in licraw.splitlines()]
 check(selector+'/whole licenses EOF identity',len(licenses)==len(fields) and all(l['recipe_index']==i and l['recipe_id']=='primitive-recipe-'+f[11].hex() and l['record_sha256']==f[12].hex() and l['logical_accepted'] is True for i,(l,f) in enumerate(zip(licenses,fields))))
 cases[selector]=dict(qualification_pin=pin(qpath:=construction['qualified_contexts'][selector]['path']),header_pin=q['catalog'],header=header,fields=fields,licenses=licenses)
 for variant in ('canonical','ordinary-symbolic-advice','extracted-finite-family-advice'):
  l=P/selector/variant;prefix=selector+'/'+variant
  wp=read(l/'worker-plan-v1.json');op=read(l/'owner-plan-v1.json');activation=read(l/'worker-activation-v1.json');outer=read(l/'prospective-terminal-contract-v1.json')
  d=read(l/'ROOT-final-disposition-v1.json');r=read(d['result']);w=read(d['worker_receipt']);a=read(d['actual_terminal']);post=read(d['post_write']);owner=read(d['owner_terminal']);ledger=read(owner['ownership_ledger'])
  results[(selector,variant)]=r
  if all_sources is None:all_sources=wp['sources']
  check(prefix+'/same current19 source roles',len(wp['sources'])==19 and wp['sources']==all_sources)
  check(prefix+'/21 leaf18 owner strict ABI',len(wp)==21 and len(op)==18 and wp['search_limits']==op['search_limits']==d['search_limits']=={'attempts':128,'event_ceiling':2000,'seconds':20} and wp['owned_limits']==op['limits']==d['owned_limits']=={'child_seconds':170,'peak_bytes':536870912,'supervisor_seconds':175,'whole_seconds':180})
  check(prefix+'/plan and result raw links',eqpin(w['plan'],pin(l/'worker-plan-v1.json')) and eqpin(w['activation'],pin(l/'worker-activation-v1.json')) and eqpin(w['result'],d['result']) and eqpin(d['owner_plan'],pin(l/'owner-plan-v1.json')) and eqpin(wp['qualification'],construction['qualified_contexts'][selector]) and eqpin(d['qualified_context'],wp['qualification']))
  check(prefix+'/once only terminal resource and cleanup',d['resource_accepted'] is True and a['terminal'] is True and a['actual_invocations']==1 and a['restarts']==0 and owner['resource_gate_accepted'] is True and post['resource_gate_accepted'] is True and owner['worker_returncode']==0 and owner['worker_terminal_and_reaped'] is True and owner['all_observers_terminal_and_reaped'] is True and owner['owned_leftovers']==[] and owner['cleanup_errors']==[] and owner['cancelled'] is False)
  mode='base' if variant=='canonical' else 'seed_forward'
  check(prefix+'/mode and actual ledger identity',r['mode']==w['mode']==wp['mode']==op['mode']==activation['mode']==d['mode']==mode and w['selector']==wp['selector']==op['selector']==selector)
  executed={str(path(x['source_pin']['path'])) for x in w['executed_project_source_ledger']}
  expected={str(path(v['path'])) for k,v in wp['sources'].items() if k!='master' and (k!='family_advice' or variant=='extracted-finite-family-advice')}
  check(prefix+'/per variant exact executable set',executed==expected and len({x['module_name'] for x in w['executed_project_source_ledger']})==len(w['executed_project_source_ledger']))
  for x in w['executed_project_source_ledger']:check(prefix+'/executed raw source/'+x['module_name'],any(eqpin(x['source_pin'],z) for z in wp['sources'].values()))
  check(prefix+'/seven consumer and empty inventory bindings',len(wp['consumer_binding']['source_records'])==7 and wp['consumer_binding']==q['expected_consumer_source_binding']==r['consumer_source_binding']==w['consumer_binding'] and digest(wp['consumer_binding'])==r['consumer_source_binding_sha256']==activation['consumer_binding_sha256'] and wp['expected_inventory_binding']==r['complete_inventory_binding']==w['complete_inventory_binding'] and digest(wp['expected_inventory_binding'])==r['complete_inventory_binding_sha256']==activation['expected_inventory_binding_sha256'])
  body=wp['body_source_bindings']['records'];check(prefix+'/exact empty body source closure',body==[wp['qualification']]+[wp['sources'][k] for k in sorted(wp['sources'])] and r['all_source_body_count']==r['registered_whole_descriptor_count']==0)
  seeds=[[idx,row,[]] for row,idx in enumerate(header['assumption_recipe_indices'])];g=dict(schema='sealed-compact-dynamic-graph-binding-v2',model_epoch=r['model_epoch'],context_id=header['context_id'],formula_registry_sha256=header['formula_registry_sha256'],authority_epoch=header['authority']['epoch'],catalog_header_pin=q['catalog'],catalog_identity_sha256=digest(dict(header=q['catalog'],streams=header['streams'],codec=header['codec'])),complete_catalog_stream_pins=header['streams'],boundary_sha256=digest(dict(height=24,roots=[0]*24,fixed_marks=sorted(header['boundary']['fixed_exterior_m']+header['boundary']['fixed_target_m']),initial_selected=seeds)),source_bindings_sha256=digest(header['source_bindings']),runtime_source_bindings=[dict(role=k,**wp['sources'][k]) for k in sorted(('point_core','compact_graph','compact_decoder','dynamic_graph_adapter','dynamic_lifecycle_adapter'))],marking_version='injective-formula-ordered-mp-offset-v1',orientation='identity',primitive_identity_relation='exact_original_complete_recipe_preimages_and_index_order',native_accepted=False,engine_authority_activated=False)
  epoch=digest(dict(graph=g,sources=body,bodies=[],version='whole-compact-cluster-lifecycle-v2'));inv=r['complete_inventory_binding']
  check(prefix+'/independent raw G5 and empty epoch recomputation',digest(g)==wp['consumer_binding']['graph_binding_sha256']==inv['runtime_authority_sha256'] and epoch==inv['original_body_authority_epoch']==inv['whole_group_authority_epoch'] and inv['original_source_body_inventory_sha256']==inv['complete_descriptor_registry_sha256']==digest([]))
  reg=wp['family_registry_binding'];actual=r['candidate_advice']['family_registry_binding']
  check(prefix+'/planned versus actual registry hash',digest(reg)==activation['family_registry_binding_sha256']==w['family_registry_binding_sha256']==d['family_registry_binding_sha256'] and actual==w['actual_family_registry_binding'] and r['candidate_advice']['family_registry_binding_sha256']==(digest(actual) if actual is not None else None))
  if reg is not None:
   adm=read(reg['library_admission']);preimage={k:v for k,v in reg.items() if k not in ('library_admission','advice_registry_epoch')}
   check(prefix+'/registry12 acyclic preimage and current source epoch',len(reg)==12 and actual==reg and len(adm)==21 and reg['advice_registry_epoch']==digest(preimage)==adm['registry_preimage_sha256'] and reg['consumed_source_epoch']==digest(dict(consumer_binding=wp['consumer_binding'],complete_inventory_binding=inv,compact_graph_binding=g)) and reg['model_binding']=={k:inv[k] for k in ('model_epoch','catalog_identity_sha256','runtime_authority_sha256')})
   check(prefix+'/scientific advice grant not controls or primitive authority',adm['purpose']==adm['scope']=='scientific-primitive-ordering-only' and adm['scientific_episode_activation'] is True and 'controls_scope' not in adm and 'ROOT_controls_authorized' not in adm and adm['ROOT_library_admitted'] is False and adm['ROOT_advice_library_accepted'] is True and adm['advice_only'] is True and adm['schema_universally_validated'] is False and adm['primitive_source_body_count']==0 and eqpin(adm['recipient_qualification'],wp['qualification']))
   check(prefix+'/family completed construction and current checking census',r['candidate_advice']['construction']['completed'] is True and w['family_registry_construction_completed'] is True and r['candidate_advice']['construction']['complete_family_count']==2 and r['candidate_advice']['family_metrics']['ground_checks_started']==r['candidate_advice']['family_metrics']['ground_checks_completed']==r['candidate_advice']['family_metrics']['ground_checks_accepted'])
  else:check(prefix+'/baseline registry absent and family never executed',actual is None and w['family_registry_construction_completed'] is False and str(path(wp['sources']['family_advice']['path'])) not in executed)
  adapter=w['proof_return_binding_adapter'];view=dict(r,schema=adapter['verifier_view_schema'])
  check(prefix+'/explicit complete metadata binder preimages',adapter==d['proof_return_binding_adapter'] and adapter['original_complete_result_sha256']==digest(r) and adapter['verifier_view_sha256']==digest(view) and adapter['original_result_schema']==r['schema']=='compact24-I2-finite-family-first-checked-proof-scientific-DFS-v12-source' and adapter['verifier_view_schema']=='compact24-first-checked-proof-scientific-DFS-v11-source' and adapter['changed_top_level_fields']==['schema'] and adapter['complete_top_level_field_count']==len(r) and adapter['source_tape_saved_before_binding'] is True and adapter['mathematical_check_replayed'] is False and eqpin(adapter['original_result'],d['result']))
  comp=d['saved_terminal_compatibility'];check(prefix+'/saved terminal compatibility scoped without rerun',comp['scientific_worker_rerun'] is False and comp['mathematical_check_replayed'] is False and comp['original_scientific_inputs_modified'] is False and comp['accepted_prefix_salvaged'] is False and eqpin(comp['original_frozen_terminal'],outer['record_adapter']))
  events=r['events'];states=r['graph_states'];counts=collections.Counter(e['kind'] for e in events)
  check(prefix+'/complete gzip EOF and event indices',len(events)<=2000 and [e['index'] for e in events]==list(range(len(events))) and events[0]['kind']=='solve_begin' and events[0]['limits']=={'attempts':128,'events':2000,'seconds':20} and events[0]['version']==r['schema'])
  check(prefix+'/all saved content addressed whole states and references',all(k==digest(v) for k,v in states.items()) and all(state_ref(e['state']) in states for e in events if 'state' in e) and state_ref(r['terminal_state']) in states and all(v['model_epoch']==r['model_epoch'] and v['catalog_identity_sha256']==inv['catalog_identity_sha256'] and v['runtime_authority_sha256']==digest(g) for v in states.values()))
  check(prefix+'/root restored complete raw state',r['root_restored'] is True and states[state_ref(r['terminal_state'])]['order']==seeds and states[state_ref(r['terminal_state'])]['totals']==[1,1,1]+[0]*21)
  check(prefix+'/no RL native macro or full trajectory authority',r['seed'] is None and r['rng_draws']==r['policy_choices']==r['commits']==[] and r['training_updates']==r['native_queries']==r['atomic_macro_moves']==0 and r['independent_full_replay_accepted'] is False and d['native_accepted'] is False and d['independent_full_trajectory_accepted'] is False and d['performance_comparison_accepted'] is False and d['universal_compiler_accepted'] is False and r['point_certificate'] is None)
  observer=r['proof_observer'];obs=observer['observations'];metrics=observer['metrics']
  check(prefix+'/whole completed observer census counters',metrics['observation_calls']==len(obs) and all(z['completed'] is True and z['all_origins_scanned']==len(z['census']) and z['source_state_sha256'] in states for z in obs) and metrics['selected_origins_scanned']==sum(len(z['census']) for z in obs if z['origin_kind']=='actual_selected') and metrics['proposals_scanned']==sum(len(z['census']) for z in obs if z['origin_kind']=='completed_source_proposal'))
  for z in r['candidate_advice']['observations']:
   if z['completed']:check(prefix+'/completed advice selection retains fallback/'+str(z['index']),z['selection']['complete_canonical_fallback_retained'] is True if 'complete_canonical_fallback_retained' in z['selection'] else z['selection']['full_primitive_fallback_retained'] is True)
  caller=(a['terminal_observed_ms']-a['start_ms'])/1000
  check(prefix+'/genuine observed caller plus separate1 margin',scalar_close(caller+1,d['caller_seconds_with_margin']) and scalar_close(caller+1,a['enclosing_seconds_with_margin']))
  check(prefix+'/observed postwrite and conservative peak scope',d['owner_postwrite_seconds']==post['owner_elapsed_seconds'] and d['conservative_owned_peak_bytes']==post['conservative_peak_bytes'] and d['owner_postwrite_seconds']>=owner['owner_elapsed_before_receipt_seconds'] and d['conservative_owned_peak_bytes']+d['prospective_reserve_bytes']<=536870912 and post['owner_elapsed_seconds']<=180 and caller+1<=180)
  frame=struct.unpack('!8sBBHQQddd',raw(owner['worker_stdout']['path'],owner['worker_stdout']));closed=owner['worker_closed_SELF']
  check(prefix+'/whole52 byte frame exact process local clocks',frame[:4]==(b'GCTSCMP1',1,0,0) and frame[4]==closed['pid'] and frame[5]==closed['SELF_ru_maxrss_raw'] and frame[6]==closed['elapsed_seconds'] and frame[7]==closed['entry_monotone_clock'] and frame[8]==closed['last_closed_monotone_clock'] and scalar_close(frame[8]-frame[7],frame[6]) and frame[6]<=owner['child_lifetime_seconds'] and r['search_seconds_including_certificate_and_return_preparation']<=frame[6])
  winner=r['first_checked_proof'];proofevents=[e for e in events if e['kind']=='first_checked_logical_proof']
  check(prefix+'/proposal selected fullboard scope faithful',w['first_proof_checked']==(winner is not None)==d['checked_logical_target_candidate'] and r['logical_target_proof_accepted']==(winner is not None) and r['actual_selected_target_proof_accepted'] is False and d['actual_selected_logical_target_candidate'] is False and d['automatic_primitive_final_certificate_accepted'] is False and w['certificate'] is None)
  if winner is not None:
   cert=read(d['logical_certificate']);check(prefix+'/accepted proof exact saved certificate and unique event',cert['checked_patch']==winner and cert['checked_patch_sha256']==digest(winner)==proofevents[0]['proof_sha256'] and len(proofevents)==1 and cert['origin_kind']==winner['origin_kind']=='completed_source_proposal' and cert['completed_source_proposal_target_accepted'] is True and cert['proof_return_binding_adapter']==adapter and winner['primary_endpoint_eligible'] is True and winner['prospective_current_point_union_accepted'] is True)
   proofs.append((selector,variant,winner,header,fields,q,cert))
  else:check(prefix+'/unknown no missing positive flag',d['logical_certificate'] is None and proofevents==[] and r['status'].startswith('unknown_') and r['trace_complete'] is False)
  summary=dict(selector=selector,variant=variant,status=r['status'],mode=mode,attempts=r['attempts'],events=len(events),recorded_node_count=r['node_count'],retained_node_enter_count=counts['node_enter'],graph_states=len(states),trace_complete=r['trace_complete'],independent_full_trajectory_accepted=False,root_restored=r['root_restored'],search_seconds=r['search_seconds_including_certificate_and_return_preparation'],cooperative_overshoot_seconds=r['checked_deadline_overshoot_seconds'],observed_owned_postwrite_seconds=d['owner_postwrite_seconds'],observed_caller_seconds=caller,caller_finish_margin_seconds=1,caller_seconds_with_margin=d['caller_seconds_with_margin'],observed_conservative_peak_bytes=d['conservative_owned_peak_bytes'],prospective_reserve_bytes=d['prospective_reserve_bytes'],worker_closed_seconds=frame[6],worker_receipt_seconds_before_serialization=w['worker_seconds_before_receipt_serialization'],cold_import_and_construction_seconds=w['cold_import_and_construction_seconds'],metadata_admission_seconds=w['metadata_admission_seconds'],first_proof_binding_seconds=w['first_proof_binding_seconds'],family_registry_built=w['family_registry_construction_completed'],family_construction=r['candidate_advice']['construction'] if reg is not None else None,family_metrics=r['candidate_advice']['family_metrics'],proof_observer_metrics=metrics,accepted_origin=None if winner is None else winner['origin_kind'],executed_project_source_count=len(executed),result_pin=d['result'],receipt_pin=d['worker_receipt'],disposition_pin=pin(l/'ROOT-final-disposition-v1.json'),event_kind_counts=dict(counts))
  lanes.append(summary)
check('exact one completed proposal and five UNKNOWN',len(proofs)==1 and sum(z['status'].startswith('unknown_') for z in lanes)==5)
# Representation projection only: decode actual compact AST and integer ports.
selector,variant,winner,h,fields,q,cert=proofs[0];patch=winner['patch'];keys=patch['primitive_keys'];commands=patch['commands']
nodes=[json.loads(line)[1:] for line in whole_gzip(raw(h['streams']['nodes']['path'],h['streams']['nodes'])).splitlines()]
words=raw(h['streams']['formulas']['path'],h['streams']['formulas']);codes=struct.unpack('<'+str(len(words)//8)+'Q',words)
expanded={}
def expand(n):
 if n not in expanded:
  rec=nodes[n];tag=rec[0]
  if tag in ('var','bot'):v=rec
  elif tag in ('fun','pred'):v=[tag,rec[1],[expand(x) for x in rec[2]]]
  elif tag=='all':v=[tag,rec[1],expand(rec[2])]
  else:v=[tag]+[expand(x) for x in rec[1:]]
  expanded[n]=v
 return expanded[n]
local_rows={k[1]:i for i,k in enumerate(keys)};prooflines=[]
for i,(key,command) in enumerate(zip(keys,commands)):
 index,row,refs=key;f=fields[index];rule=h['codec']['rules'][f[0]];witness=dict(rule=rule,formula=expand(f[1]));name=f[9]
 if rule=='axiom':witness['name']=h['codec']['names'][name]
 elif rule=='instantiate':witness.update(universal=expand(f[5]),term=expand(f[6]))
 elif rule=='eq_subst':witness.update(variable=h['codec']['names'][name],template=expand(f[5]),left=expand(f[6]),right=expand(f[7]))
 elif rule=='assumption':witness['index']=f[10]
 elif rule=='mp':witness.update(antecedent=local_rows[refs[0]],implication=local_rows[refs[1]])
 check('proof row'+str(i)+'/exact source encoded command',command==witness and f[1]==codes[f[2]] and len(refs)==(2 if rule=='mp' else 0))
 check('proof row'+str(i)+'/strict raw ordered dependency marks',all(ref<row and fields[keys[local_rows[ref]][0]][2]==f[3+p] for p,ref in enumerate(refs)))
 prooflines.append(dict(local_index=i,physical_row=row,recipe_index=index,recipe_id='primitive-recipe-'+f[11].hex(),rule=rule,output_code=f[2],ordered_prior_rows=refs,command_sha256=digest(command)))
check('proof preserved exact indexed original Gamma and target',commands[:3]==[dict(rule='assumption',index=i,formula=formula) for i,formula in enumerate(h['context']['ordered_local_premises'])] and patch['exact_original_ordered_gamma']==h['context']['ordered_local_premises'] and patch['conclusion']==commands[-1]['formula']==h['target'] and len(keys)==len(commands)==19)
# Raw backward edges only, with no logical inference.
anc=set();stack=[keys[-1][1]]
while stack:
 row=stack.pop()
 if row in anc:continue
 anc.add(row);stack.extend(keys[local_rows[row]][2])
consumed=sorted({commands[local_rows[row]]['index'] for row in anc if commands[local_rows[row]]['rule']=='assumption'})
check('proof actual complete raw ancestry consumed indices and I2',anc==set(local_rows) and consumed==patch['consumed_original_occurrence_indices']==[0,1,2] and commands[3]['rule']=='axiom' and commands[3]['name']=='I.2' and any(c['rule']=='mp' and c['antecedent']==3 for c in commands))
assignments=[tuple(v) for v in h['boundary']['fixed_exterior_m']+h['boundary']['fixed_target_m']];totals=[0]*24
for index,row,refs in keys:
 totals[row]+=1;f=fields[index];local=[(1,row,f[2])]
 for port,ref in enumerate(refs):
  item=(1,ref,f[3+port])
  if item not in local:local.append(item)
  local.append((2+port,row,ref-row))
 assignments.extend(local)
grouped=[]
for pt in sorted({x[:2] for x in assignments}):
 vals=[x[2] for x in assignments if x[:2]==pt];check('proof literal marking/'+str(pt),len(set(vals))==1);grouped.append([*pt,vals[0],len(vals)])
project=dict(totals=totals,t=[[0,row,v] for row,v in enumerate(totals) if v],m=[v[:3] for v in grouped],marks=grouped)
check('proof exact raw t m counts and incomplete24 board',project==patch['literal_points']==winner['prospective_current_point_union'] and totals==[1]*19+[0]*5 and all(v<=1 for v in totals) and patch['full24_board_accepted'] is False)
check('proof compatible source seed state and exact zero marking retained',winner['source_state_sha256']==digest(winner['source_state']) and winner['source_state']['order']==keys[:3] and winner['source_state']['totals']==[1]*3+[0]*21 and [1,3,0] in project['m'])
sourceobs=results[(selector,variant)]['candidate_advice']['observations'][winner['source_link']['advice_observation_index']]
sourceproposal=sourceobs['selection']['preferred_cluster_proposals'][winner['origin_index']]
check('proof originates whole completed source proposal not selected',sourceobs['completed'] is True and sourceproposal['actual_root_ancestry_keys']==keys and sourceproposal['root_receptor_row']==winner['root_row'] and winner['actual_selected_target_accepted'] is False and winner['source_proposal_never_counted_as_selected'] is True)
oldseal=read(ROOT/'.gcts-active/hilbert-i2-first-proof-ROOT-source-20261014/ROOT-actual-first-checked-I2-proofs-v1.json');oldtrial=next(t for t in oldseal['trials'] if t['logical_certificate'] is not None);oldcert=read(oldtrial['logical_certificate']);oldpatch=oldcert['checked_patch']['patch']
check('proof is earlier exact known replication only',patch['commands']==oldpatch['commands'] and patch['primitive_keys']==oldpatch['primitive_keys'] and patch['exact_original_ordered_gamma']==oldpatch['exact_original_ordered_gamma'] and patch['conclusion']==oldpatch['conclusion'] and patch['literal_points']==oldpatch['literal_points'])
proofsummary=dict(commands=19,rule_counts=dict(collections.Counter(c['rule'] for c in commands)),consumed_original_occurrence_indices=consumed,essential_physical_rows=sorted(anc),origin='completed_source_proposal',actual_selected=False,full24=False,native=False,independent_trajectory=False,current_point_union_accepted=True,primitive_support_rows=19,unfilled_support_rows=list(range(19,24)),replication_of_previously_saved_exact_commands=True,previous_certificate_pin=oldtrial['logical_certificate'],actual_certificate_pin=pin(certpath:=root_seal['previous_known_certificate']['path']) if False else cert['result_pin'],proof_lines=prooflines,kernel_seconds_saved=patch['kernel_seconds'],literal_point_seconds_saved=patch['literal_point_seconds'],check_seconds_saved=winner['check_seconds'],current_certificate_pin=next(z for z in docs.values() if False) if False else pin(P/selector/variant/'worker-output-v1/first-proof-certificate-v1.json'))
# Q failure is a separate saved incomplete attempt, no provisional JSON decoding.
QP=ROOT/'.gcts-active/arithmetic-Q-controls-progress-20261014';qfailure=read(QP/'ROOT-actual-Q-controls-failure-disposition-v1.json');qd=read(qfailure['resource_qualification']);qo=read(qfailure['owner']);qp=read(qfailure['post_write']);qa=read(qfailure['actual_caller']);qwp=read(QP/'worker-plan-v1.json');qop=read(qd['plan'])
check('Q exact saved raw links relative and absolute spellings',eqpin(qd['owner'],qfailure['owner']) and eqpin(qd['post_write'],qfailure['post_write']) and eqpin(qd['actual_tool'],qfailure['actual_caller']) and eqpin(qo['plan'],qd['plan']))
check('Q whole failure no accepted prefix',qfailure['actual_cold_invocations']==1 and qfailure['ROOT_complete_scoped_controls_accepted'] is False and qd['ROOT_final_accepted'] is False and len(qd['predicates'])==14 and not all(qd['predicates'].values()) and qfailure['control_count'] is None and qfailure['catalogue_accepted'] is False and qfailure['all24_initial_domains_accepted'] is False and qfailure['accepted_prefix'] is False)
check('Q actual reaped memory failure and separate observed scopes',qo['worker_returncode']==qfailure['worker_returncode']==-15 and qo['all_direct_children_terminal_and_reaped'] is True and qo['owned_leftovers']==[] and qo['error']==qfailure['actual_error'] and qp['elapsed_seconds']==qfailure['owned_seconds'] and qp['peak_bytes']==qfailure['conditional_peak_bytes']>qd['limits']['peak_bytes']==536870912 and qd['caller_elapsed_seconds']==qfailure['caller_seconds']==16.38 and qfailure['caller_seconds_with_finish_margin']==17.38)
check('Q no final worker receipt or completed results',qfailure['final_worker_receipt'] is None and qo['worker_receipt'] is None and qp['terminal'] is None and sorted(x.name for x in (QP/'worker-output-v1').iterdir())==['Q-preparation-provisional-v1.json'])
qsummary=dict(status='UNKNOWN_owned_memory_before_complete_controls',actual_invocations=1,owned_postwrite_seconds=qp['elapsed_seconds'],observed_caller_seconds=qd['caller_elapsed_seconds'],caller_finish_margin_seconds=qd['caller_finish_reserve_seconds'],observed_peak_bytes=qp['peak_bytes'],fixed_cap_bytes=536870912,worker_returncode=-15,complete_controls_accepted=False,accepted_control_count=None,qualified_catalogue=False,all24_domains_accepted=False,provisional_preparation_raw_pin=qfailure['provisional_preparation'],final_receipt=None,leftovers=[],target_searches=0,target_proofs=False,native=False,new_RL=False,ROOT_failure_pin=pin(QP/'ROOT-actual-Q-controls-failure-disposition-v1.json'),qualification_predicates=qd['predicates'],provisional_JSON_decoded=False)
# Independently rehash every read raw target after all projections; no mutable saved input.
for key,b in cache.items():
 now=pathlib.Path(key).read_bytes()
 if now!=b:raise AssertionError(('final rehash changed',key))
check('all named raw targets stable at final rehash',True)
publiclanes=[{k:v for k,v in z.items() if k not in ('result_pin','receipt_pin','disposition_pin','family_construction','event_kind_counts')} for z in lanes]
# Construction contains pins with private paths; sanitize public family summary deliberately.
for z in publiclanes:
 orig=next(v for v in lanes if v['selector']==z['selector'] and v['variant']==z['variant'])
 f=orig['family_construction'];z['family_construction']=None if f is None else {k:v for k,v in f.items() if k not in ('admission_pin','library_pin')}
publicproof={k:v for k,v in proofsummary.items() if k not in ('previous_certificate_pin','current_certificate_pin','actual_certificate_pin','proof_lines')}
publicq={k:v for k,v in qsummary.items() if k not in ('ROOT_failure_pin','provisional_preparation_raw_pin')}
public=dict(all_scoped_metadata_checks_passed=True,pin_mismatch_count=0,scientific_calls=0,semantic_replay=False,actual_six_completed_runs=6,UNKNOWN_runs=5,accepted_logical_proposals=1,actual_selected_target_proofs=0,full24_boards=0,native_proofs=0,independent_full_trajectory_accepted=False,new_RL_training=False,performance_advantage_established=False,new_theorems_discovered=0,lanes=publiclanes,accepted_proof=publicproof,Q_failure=publicq,assessment='One automatically checked conventional incidence-ordering proposal replicates the earlier exact 19-command I.2 proof. Both finite-family runs built their registry and completed fresh ground checks, but reached the cooperative search deadline without a checked target. No selected/full-board/native/trajectory/RL or comparative advantage is established. This independent review authenticates saved metadata only; original timed observer/kernel/point checks and ROOT resource dispositions retain their separate authority.')
check('public summary contains no host paths or PIDs','/Users/' not in canonical(public).decode() and 'owner_pid' not in canonical(public).decode())
findings=dict(schema='independent-six-lane-I2-family-saved-metadata-findings-v1',author_identity='/root/hilbert_ordering_diagnosis',source_only_saved_metadata=True,project_imports=0,project_functions=0,kernel_calls=0,search_calls=0,semantic_replays=0,scientific_calls=0,mathematical_acceptance_issued=False,scope='Whole saved buffers and direct raw pins for the six actual v4 lanes, source/executable ledgers, source-bound registries, explicit metadata-only schema adapter, EOF event/state census, exact source-representation and integer point correspondence of the accepted proposal, earlier-proof replication, and separately incomplete Q memory attempt. No all-history recursion or fresh mathematical checking.',checks=checks,check_count=len(checks),pin_reference_count=references,unique_raw_target_count=len(pins),final_rehash_count=len(pins),decoded_named_document_count=len(docs),pin_mismatch_count=0,all_scoped_metadata_checks_passed=True,construction_pin=pin(P/'ROOT-construction-v1.json'),ROOT_comparison_pin=pin(P/'ROOT-actual-six-lane-comparison-disposition-v1.json'),lanes=lanes,accepted_proof=proofsummary,Q_failure=qsummary,raw_targets=[pins[k] for k in sorted(pins)],public_summary=public,limitations=['No kernel, licence semantics, search, logical replay or project Source executed. Raw AST decoding is a representation projection only.','Retained trace prefixes are complete gzip buffers, but UNKNOWN trace_complete=false; recorded node count and retained node_enter differ in companion canonical (83 vs82).','The positive trace_complete=true is producer completeness, not independent full-trajectory acceptance.','Family instance_calls_started include incomplete work; completed-instance clocks before final guards are censored and not total adviser time.','Actual conditional owned peak/caller records do not establish whole-host completeness, hard OS caps or cross-process absolute clock comparison.','The earlier v3 binder failure and v4 saved-terminal missing-digest failure remain preserved. Current saved-only compatibility adapter reruns no science.','Q provisional preparation is raw-pinned only; no completed controls or catalogue qualification exists.'])
(OUT/'saved-six-lane-findings-v1.json').write_text(json.dumps(findings,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
fh=pin(OUT/'saved-six-lane-findings-v1.json')
(OUT/'handoff-v1.json').write_text(json.dumps(dict(schema='independent-six-lane-saved-review-handoff-v1',findings=fh,all_scoped_metadata_checks_passed=True,scientific_calls=0,scope='saved metadata only',accepted_target_proposals=1,actual_selected_target_proofs=0,new_theorems_discovered=0),indent=2)+'\n')
print(json.dumps(dict(findings=fh,handoff=pin(OUT/'handoff-v1.json'),checks=len(checks),raw_targets=len(pins),refs=references,proof=publicproof,Q=publicq),indent=2))
