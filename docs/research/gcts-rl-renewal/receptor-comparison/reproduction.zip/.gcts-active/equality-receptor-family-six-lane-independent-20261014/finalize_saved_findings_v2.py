"""Stdlib-only additive refinement; no project imports/functions or logical inference."""
import collections,gzip,hashlib,json,pathlib,struct
ROOT=pathlib.Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search');O=ROOT/'.gcts-active/equality-receptor-family-six-lane-independent-20261014';P=ROOT/'.gcts-active/equality-receptor-family-six-lane-progress-v2-20261014'
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(v):return hashlib.sha256(canonical(v)).hexdigest()
def fullpin(p,b):return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def readpin(record):
 p=pathlib.Path(record['path']);p=p if p.is_absolute() else ROOT/p;b=p.read_bytes()
 assert len(b)==record['bytes'] and hashlib.sha256(b).hexdigest()==record['sha256'];return b
b=(O/'saved-six-lane-findings-v1.json').read_bytes();f=json.loads(b);oldpin=fullpin(O/'saved-six-lane-findings-v1.json',b)
# Correct one private pin-field name: V1 actual_certificate_pin referred to the result.
f['accepted_proof']['actual_result_pin']=f['accepted_proof'].pop('actual_certificate_pin')
f['accepted_proof']['actual_certificate_pin']=f['accepted_proof']['current_certificate_pin']
f['schema']='independent-six-lane-I2-family-saved-metadata-findings-v2'
f['preserved_prior_findings']=oldpin
f['additive_refinement']='Private actual_certificate_pin label corrected; original result raw pin separately retained. Added exact canonical recipe identity/record SHA correspondence, current ROOT comparison-row equality and public whole EOF totals. No scientific/source/input mutation.'
checks=f['checks']
def ck(n,v):assert v,n;checks.append(dict(check=n,passed=True))
for row in json.loads(readpin(f['ROOT_comparison_pin']))['rows']:
 z=next(z for z in f['lanes'] if z['selector']==row['case'] and z['variant']==row['lane'])
 ck(row['case']+'/'+row['lane']+'/current ROOT scalar table exact',all(row[a]==z[b] for a,b in [('status','status'),('mode','mode'),('attempts','attempts'),('events','events'),('search_seconds','search_seconds'),('owned_seconds','observed_owned_postwrite_seconds'),('caller_seconds','observed_caller_seconds'),('caller_seconds_with_margin','caller_seconds_with_margin'),('peak_bytes','observed_conservative_peak_bytes'),('registry_completed','family_registry_built'),('family_metrics','family_metrics'),('trace_complete','trace_complete'),('root_restored','root_restored')]))
cert=json.loads(readpin(f['accepted_proof']['actual_certificate_pin']));q=json.loads(readpin(cert['qualification_pin']));h=json.loads(readpin(q['catalog']));r=json.loads(gzip.decompress(readpin(cert['result_pin'])));patch=r['first_checked_proof']['patch'];commands=patch['commands'];keys=patch['primitive_keys']
recipes=readpin(h['streams']['recipes']);rowfmt=struct.Struct('<11Q32s32s');outputs={k[1]:commands[i]['formula'] for i,k in enumerate(keys)}
for i,(key,command) in enumerate(zip(keys,commands)):
 index,physical,refs=key;v=rowfmt.unpack_from(recipes,rowfmt.size*index);witness={k:z for k,z in command.items() if k not in ('antecedent','implication')}
 ordered=[outputs[rr] for rr in refs]
 preimage=dict(recipe=dict(primitive_witness=witness,ordered_premise_formulas=ordered),primitive_authority_epoch=h['authority']['epoch'],recipient_theory_sha256=h['authority']['recipient_theory_sha256'],marking_version=h['marking_version'],formula_registry_sha256=h['formula_registry_sha256'])
 if command['rule']=='assumption':preimage['local_context_id']=h['context_id']
 rid='primitive-recipe-'+v[11].hex();record=dict(id=rid,primitive_witness=witness,ordered_premise_formulas=ordered,identity_preimage=preimage)
 ck('proof row'+str(i)+'/complete recipe and record preimage SHA',digest(preimage)==v[11].hex() and digest(record)==v[12].hex())
trainingpin=next(t for t in f['raw_targets'] if t['sha256']=='de34653e96673e080c65a6c17fad3cc24cfb00ab0043fdc11c9741e6708f382c');training=json.loads(readpin(trainingpin))
ck('finite family training contains only declared old3 certificates',len(training['certificates'])==3 and all(x['sha256']!=f['accepted_proof']['previous_certificate_pin']['sha256'] for x in training['certificates']))
# All input targets from V1 rehashed here too, with no historical metadata decoding.
for record in f['raw_targets']:readpin(record)
ck('all397 original saved targets final current rehash stable',len(f['raw_targets'])==397)
f['check_count']=len(checks);f['public_summary']['scoped_metadata_check_count']=len(checks)
f['public_summary']['raw_pin_reference_count']=f['pin_reference_count']
f['public_summary']['unique_raw_target_count']=f['unique_raw_target_count']
f['public_summary']['final_rehash_count']=f['final_rehash_count']
f['public_summary']['whole_saved_event_count']=sum(z['events'] for z in f['lanes'])
f['public_summary']['whole_content_addressed_state_count_per_run_sum']=sum(z['graph_states'] for z in f['lanes'])
f['public_summary']['constructor_and_family_cost_note']='Family construction clocks are nested in the20s search call; started instance calls exceeding completed counts and completed-instance clocks before final guards are censored, not total adviser time. Search cutoff is cooperative; UNKNOWN overshoots are retained.'
f['public_summary']['preserved_failure_note']='The earlier v3 post-search schema-binding failure has unavailable counts/proofs; it remains preserved. The v4 saved-only terminal missing-digest failure was closed using a separately reviewed metadata compatibility adapter without search replay.'
f['public_summary']['Q_failure']['exceeded_fixed_memory_by_bytes']=f['Q_failure']['observed_peak_bytes']-f['Q_failure']['fixed_cap_bytes']
assert '/Users/' not in canonical(f['public_summary']).decode()
fb=(json.dumps(f,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode();dst=O/'saved-six-lane-findings-v2.json';assert not dst.exists();dst.write_bytes(fb);fp=fullpin(dst,fb)
handoff=dict(schema='independent-six-lane-saved-review-handoff-v2',findings=fp,preserved_prior_findings=oldpin,all_scoped_metadata_checks_passed=True,scientific_calls=0,scope='saved metadata only',checks=len(checks),raw_targets=f['unique_raw_target_count'],raw_references=f['pin_reference_count'],accepted_target_proposals=1,actual_selected_target_proofs=0,new_theorems_discovered=0)
hb=(json.dumps(handoff,indent=2)+'\n').encode();hp=O/'handoff-v2.json';assert not hp.exists();hp.write_bytes(hb)
# Compact Q projection of this genuine completed saved review, separate from Source feasibility review.
qo=ROOT/'.gcts-active/arithmetic-Q-cold-controls-independent-20261014/actual-memory-failure-saved-findings-v1.json';assert not qo.exists()
qfind=dict(schema='independent-Q-actual-memory-failure-saved-findings-v1',reviewer_identity='/root/hilbert_ordering_diagnosis',scope='saved raw resource and failure metadata only; provisional preparation JSON raw-pinned, not decoded or mathematically admitted',scientific_calls=0,semantic_replay=False,all_scoped_metadata_checks_passed=True,full_review=fp,failure=f['Q_failure'],public_summary=f['public_summary']['Q_failure'])
qb=(json.dumps(qfind,indent=2)+'\n').encode();qo.write_bytes(qb)
print(json.dumps(dict(findings=fp,handoff=fullpin(hp,hb),Q_saved=fullpin(qo,qb),checks=len(checks),events=f['public_summary']['whole_saved_event_count'],states=f['public_summary']['whole_content_addressed_state_count_per_run_sum']),indent=2))
