"""SOURCE ONLY fixed fresh pilot schedule; no jobs/activations are created."""
import json

VERSION = 'fresh-five-donor-four-heldout-cluster-policy-pilot-v1'
FIXTURE_PIN = dict(path='.gcts-active/cluster-transfer-theorem-source-20261012/fixtures-v2.json',
    sha256='b17ba2cea0dd5d595e39c7c38f3d7cefce2d2c040ba1f3fd4a4aa10418bd99f8', bytes=24474)
TRAINING_IDS = ('train-pa-right-zero', 'train-pa-right-one', 'train-inc-line',
                'train-inc-point', 'train-inc-uniqueness')
HELDOUT_IDS = ('eval-pa-chain', 'eval-pa-nested', 'eval-inc-both-arguments',
               'eval-inc-uniqueness-point')
TRAIN_LIMITS = dict(attempts=64, seconds=10, event_ceiling=1200)
EVAL_LIMITS = dict(attempts=128, seconds=20, event_ceiling=2000)
DONOR_DISCOVERY_LIMITS = dict(attempts=128, seconds=20, event_ceiling=2000)
OWNED_LIMITS = dict(whole_seconds=180, supervisor_seconds=175,
                    child_seconds=170, peak_bytes=536870912)
HYPERPARAMETERS = dict(epsilon=0.1, temperature=1.0, learning_rate=0.05,
                       ema_alpha=0.2, direction_norm_ceiling=1.0)


def jobs():
    """Pure prospective descriptors, not an execution or file-creation action."""
    train = []
    schedule = [(instance, 1201201 + i) for i, instance in enumerate(TRAINING_IDS)]
    schedule += [(instance, 1201211 + i) for i, instance in reversed(tuple(enumerate(TRAINING_IDS)))]
    for index, (instance, seed) in enumerate(schedule):
        train.append(dict(id='fresh-policy-donor-' + str(index + 1), index=index,
            phase='donor', instance_id=instance, mode='donor', seed=seed,
            limits=dict(TRAIN_LIMITS), required_qualified_prefix=index))
    evaluate = []
    lanes = ('base', 'fixed', 'untrained', 'trained')
    for context_index, instance in enumerate(HELDOUT_IDS):
        order = lanes[context_index:] + lanes[:context_index]
        for mode in order:
            evaluate.append(dict(id='fresh-policy-eval-' + instance + '/' + mode,
                index=len(evaluate), phase='evaluation', instance_id=instance, mode=mode,
                seed=1201291 if mode in ('untrained', 'trained') else None,
                limits=dict(EVAL_LIMITS), required_qualified_prefix=10))
    return train, evaluate


def validate_job(job):
    train, evaluate = jobs()
    text = json.dumps(job, sort_keys=True, separators=(',', ':'), allow_nan=False)
    matches = [j for j in train + evaluate if
        json.dumps(j, sort_keys=True, separators=(',', ':'), allow_nan=False) == text]
    if len(matches) != 1:
        raise ValueError('exact prospective frozen pilot job; no seed/lane/context/budget tuning')
    return matches[0]
