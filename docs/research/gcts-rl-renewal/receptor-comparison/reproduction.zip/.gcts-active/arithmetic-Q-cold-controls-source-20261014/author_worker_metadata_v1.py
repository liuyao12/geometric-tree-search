"""Author raw Source/JSON only; never imports or invokes Q code."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/arithmetic-Q-cold-controls-source-20261014'
OLD=ROOT/'.gcts-active/arithmetic-open-generalize-implementation-source-20261014'

def pin(path):
    raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    path=HERE/name
    with path.open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
    return pin(path)

def main():
    sources={role:pin(OLD/file) for role,file in [('kernel','arithmetic_q_kernel_v1.py'),('catalogue','arithmetic_q_catalog_v1.py'),
        ('point_graph','arithmetic_q_point_graph_v1.py'),('payload','q_preparation_gate_v1.py')]}
    sources['controls']=pin(HERE/'arithmetic_Q_controls_v1.py');sources['master']=pin(ROOT/'docs/basic-tiling-algorithm.md')
    spec=save('controls-specification-v1.json',dict(schema='arithmetic-Q-preparation-controls-specification-v1',
        declaration=pin(OLD/'Q-declaration-v1.json'),original_sources={r:p for r,p in sources.items() if r!='controls'},controls_source=sources['controls'],
        full_initial_domain_scope='Every24-row exact parametric 0/1/2-port relation and every original recipe; no target backcone or sampled shortlist.',
        grammar_changed=False,target_changed=False,original_ordered_Gamma=[],
        synthetic_scope='Local synthetic prior formulas test rule side conditions, not licensed proofs. Opaque tiny graph recipes never enter the theorem inventory.',
        scientific_calls=0,controls_run=False,proof_search_authorized=False,native_accepted=False,induction_supported=False,
        independent_mathematical_admission=False,full_PA_accepted=False,
        limitations=['Producer-authored separate domain path requires distinct-author Source review; it is not an independent semantic/native admission.',
            'Exact counts, full graph/cardinality growth, wall/memory and success under20s are unknown until ROOT actual stage.',
            'First-proof tracing, compatible compact unary runtime and native whole-proof checking remain separate work.']))
    inputs=dict(declaration=pin(OLD/'Q-declaration-v1.json'),prototype_contract=pin(OLD/'source-contract-v1.json'),
        prototype_source_review=pin(ROOT/'.gcts-active/arithmetic-open-generalize-independent-20261014/source-findings-v1.json'),
        control_specification=spec)
    parent=ROOT/'.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/actual_Incident_family_controls_sequence_binding_v3.py'
    text=parent.read_text();tree=ast.parse(text)
    names=('need','canonical','pin','verify','parse','read','load','normalize','value_state','executable_state','unchanged_executable','function_signature')
    defs={n.name:ast.get_source_segment(text,n) for n in tree.body if isinstance(n,ast.FunctionDef)}
    prefix='''"""Unexecuted cold Q preparation/controls leaf. ROOT alone activates once.

No theorem search, Graph solve, induction/native/RL or authority issuance.
Raw-buffer Source loading and ordinary endpoint guards are part of20s; all
publication/exit/cleanup remains inside60s/512MiB/caller90 owned scope.
"""
import hashlib
import importlib.util
import inspect
import json
import math
import os
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
SCHEMA='ROOT-Q-open-empty-Gamma-controls-worker-plan-v1'
SCOPE='Q-complete-preparation-and-finite-controls-no-search-no-admission'
COMMAND='ROOT-Q-open-empty-Gamma-preparation-controls'
AUTHOR='/root/arithmetic_induction'
LIMITS=dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)
MAX_METADATA=64*1048576
'''
    prefix+='FROZEN_SOURCES = '+repr(sources)+'\nSOURCE_ROLES=set(FROZEN_SOURCES)|{\'worker\'}\n'
    prefix+='FROZEN_INPUTS = '+repr(inputs)+'\nINPUT_ROLES=set(FROZEN_INPUTS)\n'
    utilities='\n\n'.join(defs[name] for name in names)
    suffix='''

def source_cache_guard(sources,modules,anchors):
    expected={p['path']:p for p in sources.values() if p['path'].endswith('.py')}
    seen=[]
    for name,module in list(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if not isinstance(file,str):continue
        path=str(Path(file).resolve())
        if not path.startswith(str(ROOT)+os.sep):continue
        need(path in expected and not path.endswith(('.pyc','.pyo')),'no undeclared local executable/cache module')
        need(name==__name__ or any(module is value for value in modules.values()),'same exact admitted module object')
        verify(expected[path]);seen.append(expected[path])
    need(all(modules[k] is anchors[k] and sys.modules.get(modules[k].__name__) is modules[k] for k in modules),
         'source-bound module object remains its actual namespace')
    return sorted({p['path']:p for p in seen}.values(),key=lambda p:p['path'])


def preflight(plan_path,owner_path):
    plan_pin,owner_pin=pin(plan_path),pin(owner_path)
    plan,owner=read(plan_pin,2*1048576),read(owner_pin,2*1048576)
    need(set(plan)=={'schema','ROOT_owned_once_only','scope','sources','inputs','runtime','reviews','closure','limits','owner_plan_path','output_directory'}
         and plan['schema']==SCHEMA and plan['ROOT_owned_once_only'] is True and plan['scope']==SCOPE and plan['limits']==LIMITS,
         'strict11-field current Q controls leaf')
    need(set(plan['sources'])==SOURCE_ROLES and {r:p for r,p in plan['sources'].items() if r!='worker'}==FROZEN_SOURCES
         and plan['sources']['worker']==pin(Path(__file__).resolve()) and plan['inputs']==FROZEN_INPUTS,
         'exact current seven raw sources/four fixed inputs')
    need(plan_path.parent==owner_path.parent and plan['owner_plan_path']==str(owner_path),'same flat cold plan namespace')
    output=Path(plan['output_directory'])
    need(output.is_absolute() and output==output.resolve() and output.parent==plan_path.parent and not output.exists(),'exclusive immutable output')
    closure={}
    for record in plan['closure']:
        verify(record);need(record['path'] not in closure,'unique canonical leaf closure');closure[record['path']]=record
    need(list(closure)==sorted(closure),'canonical sorted full raw closure')
    for record in [*plan['sources'].values(),*plan['inputs'].values(),*plan['reviews'].values()]:
        verify(record);need(closure.get(record['path'])==record,'every direct source/input/review is closed')
    need(set(plan['reviews'])=={'ROOT','independent'},'genuine separate actual Source review slots')
    for role in ('ROOT','independent'):
        review=read(plan['reviews'][role])
        need(review.get('source_only') is True and review.get('source_review_passed') is True and review.get('scientific_calls')==0
             and review.get('sources')==plan['sources'],'current exact Source review, never scientific acceptance')
        if role=='independent':need(review.get('author_identity')==AUTHOR and review.get('reviewer_identity')!=AUTHOR,'distinct Q implementation reviewer')
    need(plan['reviews']['ROOT']['path']==str(plan_path.parent/'ROOT-source-review-v1.json'),'generic owner local ROOT Source review')
    runtime=plan['runtime']
    need(set(runtime)=={'binary','resource_extension','python_version','platform'} and runtime['python_version']==[3,9,6]
         and runtime['platform']=='darwin' and list(sys.version_info[:3])==[3,9,6] and sys.platform=='darwin','exact pinned CLT runtime')
    for field in ('binary','resource_extension'):verify(runtime[field]);need(closure.get(runtime[field]['path'])==runtime[field],'runtime closed')
    need(str(Path(sys.executable).resolve())==runtime['binary']['path'] and str(Path(resource.__file__).resolve())==runtime['resource_extension']['path'],
         'actual runtime/resource extension origin')
    argv=[runtime['binary']['path'],'-B',plan['sources']['worker']['path'],COMMAND,str(plan_path),str(owner_path)]
    need(set(owner)=={'schema','stage','runtime_binary','worker','argv','worker_receipt','limits','closure','ROOT_source_review','scope'}
         and owner['schema']=='ROOT-guard-native-owned-plan-v1' and owner['stage']=='preparation' and owner['limits']==LIMITS and owner['scope']==SCOPE
         and owner['argv']==argv and normalize(owner['runtime_binary'])==runtime['binary'] and normalize(owner['ROOT_source_review'])==plan['reviews']['ROOT'],
         'strict10 generic owned preparation plan and literal six argv')
    need((ROOT/owner['worker']).resolve()==Path(plan['sources']['worker']['path'])
         and (ROOT/owner['worker_receipt']).resolve()==output/'Q-controls-result-v1.json','exact worker and final receipt path')
    owner_closure={}
    for record in owner['closure']:
        p=normalize(record);verify(p);need(p['path'] not in owner_closure,'unique canonical owner closure');owner_closure[p['path']]=p
    for record in closure.values():need(owner_closure.get(record['path'])==record,'full worker closure in owned closure')
    need(owner_closure.get(plan_pin['path'])==plan_pin,'owner closes actual worker plan')
    # Read precisely these scientific metadata roots; recursively authenticate
    # their pin values without interpreting arbitrary ancestor JSON as authority.
    def authenticate(value):
        if isinstance(value,dict):
            if set(value)=={'path','sha256','bytes'}:
                p=normalize(value);verify(p);need(closure.get(p['path'])==p,'every named input raw pin in full closure')
            for child in value.values():authenticate(child)
        elif isinstance(value,list):
            for child in value:authenticate(child)
    documents={role:read(record) for role,record in plan['inputs'].items()}
    for document in documents.values():authenticate(document)
    prior=documents['prototype_source_review']
    need(prior['source_only'] is True and prior['source_review_passed'] is True and prior['scientific_calls']==0
         and prior['sources']=={r:FROZEN_SOURCES[r] for r in ('kernel','catalogue','point_graph','payload')},'original Q Source-only prerequisite, not current admission')
    need(documents['declaration']['ordered_Gamma']==[] and documents['control_specification']['grammar_changed'] is False
         and documents['control_specification']['target_changed'] is False,'original empty-Gamma target/grammar preserved')
    return plan,output,plan_pin,owner_pin,closure,owner_closure,documents


def main():
    began=time.perf_counter()
    need(len(sys.argv)==4 and sys.argv[1]==COMMAND,'one literal cold Q controls invocation')
    plan_path,owner_path=(Path(p) for p in sys.argv[2:])
    need(all(p.is_absolute() and p==p.resolve() for p in (plan_path,owner_path)),'canonical actual plans')
    plan,output,plan_pin,owner_pin,closure,owner_closure,documents=preflight(plan_path,owner_path)
    output.mkdir();artifacts=[];final_receipt=None
    def whole_tick():
        need(time.perf_counter()-began<55 and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<500*1048576,
             'whole60/512 includes inherited prospective finishing reserves')
    def save(name,value):
        whole_tick();raw=(canonical(value)+'\\n').encode('utf8');need(len(raw)<=MAX_METADATA,'entire bounded output, no prefix')
        path=output/name
        with path.open('xb') as stream:need(stream.write(raw)==len(raw),'full output write')
        record=pin(path);artifacts.append(record);whole_tick();return record
    own=sys.modules[__name__]
    names=('need','canonical','pin','verify','read','load','normalize','executable_state','unchanged_executable','source_cache_guard','function_signature')
    validators={name:(globals()[name],globals()[name].__code__) for name in names}
    guard_fn,guard_code=unchanged_executable,unchanged_executable.__code__;own_state=executable_state(own)
    modules={};states=[];anchors={};declaration=documents['declaration'];declaration_text=canonical(declaration)
    inner_began=time.perf_counter();deadline=inner_began+LIMITS['control_seconds']
    def inner_tick():
        whole_tick()
        if time.perf_counter()>=deadline:raise TimeoutError('whole20s Q preparation/controls incomplete; no accepted prefix')
    try:
        for role in ('kernel','catalogue','point_graph','payload','controls'):
            if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):raise ValueError('own cold endpoint changed before project load')
            inner_tick();module=load(plan['sources'][role],'_cold_arithmetic_Q_controls_'+role)
            modules[role]=module;states.append(executable_state(module))
            if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):raise ValueError('own cold endpoint changed after project load')
            guard_fn(own_state)
            for state in states:guard_fn(state)
        anchors=dict(modules)
        source_guard=None;source_guard_code=None
        def source_guard():
            if source_guard.__code__ is not source_guard_code or unchanged_executable is not guard_fn or guard_fn.__code__ is not guard_code:
                raise ValueError('original callback/validator code replaced')
            if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):raise ValueError('original cold rejection/validator replaced')
            guard_fn(own_state)
            for state in states:guard_fn(state)
            need(canonical(declaration)==declaration_text,'original declared target/grammar/Gamma unchanged')
            source_cache_guard(plan['sources'],modules,anchors)
            for record in closure.values():verify(record)
            for record in owner_closure.values():verify(record)
            need(pin(plan_path)==plan_pin and pin(owner_path)==owner_pin,'same once-only immutable plans')
            inner_tick()
        source_guard_code=source_guard.__code__;callback_fn=source_guard;callback_anchor=function_signature(callback_fn)
        def invoke_guard():
            if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):raise ValueError('own validator replaced before callback')
            if function_signature(callback_fn)!=callback_anchor:raise ValueError('original callback code/default/closure identity changed')
            callback_fn()
            if function_signature(callback_fn)!=callback_anchor:raise ValueError('callback changed during delegated call')
        invoke_fn=invoke_guard;invoke_anchor=function_signature(invoke_fn)
        def outer_guard():
            if function_signature(invoke_guard)!=invoke_anchor:raise ValueError('original invoking shim changed')
            invoke_fn()
        outer_guard()
        prepared=modules['payload'].prepare_only(declaration=declaration,kernel_module=modules['kernel'],catalogue_module=modules['catalogue'],
            graph_module=modules['point_graph'],source_bindings=plan['sources'],source_guard=invoke_fn,deadline=deadline)
        outer_guard();prepared_pin=save('Q-preparation-provisional-v1.json',prepared);outer_guard()
        controls=modules['controls'].run_controls(declaration=declaration,prepared=prepared,kernel_module=modules['kernel'],
            graph_module=modules['point_graph'],source_bindings=plan['sources'],source_guard=invoke_fn,deadline=deadline)
        outer_guard();need(controls['completed'] is True and controls['target_searches']==0 and controls['independent_mathematical_catalogue_admission'] is False,
            'whole controls complete, no search or admission')
        controls_pin=save('Q-controls-provisional-v1.json',controls);outer_guard()
        # Completion is asserted only after full model/controls/transport bytes
        # and the final20s guard; earlier files are deliberately provisional.
        inner_complete=time.perf_counter()-inner_began
        evidence_pin=save('Q-controls-evidence-v1.json',dict(schema='cold-Q-preparation-controls-evidence-v1',
            sources=plan['sources'],inputs=plan['inputs'],worker_plan=plan_pin,owner_plan=owner_pin,
            prepared=prepared_pin,controls=controls_pin,inner_complete_seconds=inner_complete,
            executed_raw_project_source_ledger=source_cache_guard(plan['sources'],modules,anchors),
            independent_mathematical_catalogue_admission=False,universal_theorem_discovered=False,native_accepted=False,
            source_only_prototype_now_called=True,target_searches=0,RL_training_runs=0,scientific_search_activation=False))
        outer_guard()
        final_receipt=output/'Q-controls-result-v1.json'
        save(final_receipt.name,dict(schema='cold-Q-preparation-controls-receipt-v1',stage='preparation',stage_completed=True,
            status='completed_producer_Q_preparation_controls_pending_ROOT',worker_plan=plan_pin,owner_plan=owner_pin,
            evidence=evidence_pin,prepared=prepared_pin,controls=controls_pin,all_direct_children_terminal_and_reaped=True,
            direct_children_peak_sum_bytes=0,worker_elapsed_before_receipt_seconds=time.perf_counter()-began,
            worker_SELF_peak_before_receipt_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            target_searches=0,native_queries=0,RL_training_runs=0,resource_acceptance_issued=False,
            independent_mathematical_catalogue_admission=False,universal_theorem_discovered=False,scientific_search_activation=False))
        outer_guard();whole_tick();print(canonical(dict(stage_completed=True,target_searches=0,scientific_search_activation=False)),flush=True);whole_tick()
    except BaseException as exc:
        if final_receipt is not None and final_receipt.exists():
            withdrawn=output/'Q-controls-result-withdrawn-v1.json';final_receipt.rename(withdrawn)
            artifacts=[pin(withdrawn) if p['path']==str(final_receipt) else p for p in artifacts]
        failure=dict(schema='cold-Q-preparation-controls-failure-v1',stage='preparation',stage_completed=False,
            status='UNKNOWN_incomplete_Q_preparation_controls',error=dict(type=type(exc).__name__,message=str(exc)[:512]),
            worker_plan=plan_pin,owner_plan=owner_pin,provisional_artifacts=artifacts,accepted_prefix=False,
            target_searches=0,native_queries=0,RL_training_runs=0,scientific_search_activation=False)
        raw=(canonical(failure)+'\\n').encode('utf8')
        if len(raw)<=1048576:
            with (output/'failure-v1.json').open('xb') as stream:stream.write(raw)
        raise


if __name__=='__main__':main()
'''
    path=HERE/'arithmetic_Q_controls_worker_v1.py'
    with path.open('x') as f:f.write(prefix+'\n'+utilities+'\n'+suffix)
    print(json.dumps(dict(worker=pin(path),control_specification=spec,sources=sources,inputs=inputs)))

if __name__=='__main__':main()
