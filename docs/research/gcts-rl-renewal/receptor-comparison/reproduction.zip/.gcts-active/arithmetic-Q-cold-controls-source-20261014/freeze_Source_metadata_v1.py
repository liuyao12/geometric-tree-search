"""Hash/AST/JSON-only freezer. No project imports or scientific invocation."""
import ast
import builtins
import difflib
import hashlib
import json
import symtable
import time
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=Path(__file__).resolve().parent
OLD=ROOT/'.gcts-active/arithmetic-open-generalize-implementation-source-20261014'

def pin(path):
    raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    path=HERE/name
    with path.open('x') as f:json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
    return pin(path)

def main():
    began=time.perf_counter();checks=[]
    def check(value,label):checks.append(dict(name=label,passed=bool(value)))
    worker=HERE/'arithmetic_Q_controls_worker_v3.py';controls=HERE/'arithmetic_Q_controls_v1.py'
    tree=ast.parse(worker.read_bytes());assignments={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign)
        and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    frozen=ast.literal_eval(assignments['FROZEN_SOURCES']);inputs=ast.literal_eval(assignments['FROZEN_INPUTS'])
    sources=dict(frozen,worker=pin(worker));check(len(sources)==7,'six literal roles plus actual current self')
    for path in [worker,controls]+[Path(sources[r]['path']) for r in ('kernel','catalogue','point_graph','payload')]:
        code=path.read_text();parsed=ast.parse(code);compile(parsed,str(path),'exec')
        st=symtable.symtable(code,str(path),'exec');declared={s.get_name() for s in st.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
        declared|=set(dir(builtins))|{'__name__','__file__','__builtins__'};pending=[st];missing=set()
        while pending:
            current=pending.pop();pending.extend(current.get_children())
            for s in current.get_symbols():
                if s.is_global() and s.is_referenced() and s.get_name() not in declared:missing.add(s.get_name())
        check(not missing,'AST/symbol binding only '+path.name+' '+','.join(sorted(missing)))
    old_utils=ROOT/'.gcts-active/equality-receptor-family-Sequence-guard-source-20261014/actual_Incident_family_controls_sequence_binding_v3.py'
    parent_tree=ast.parse(old_utils.read_bytes());parent_defs={n.name:n for n in parent_tree.body if isinstance(n,ast.FunctionDef)}
    defs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
    utility_names=('need','canonical','pin','verify','parse','read','load','normalize','value_state','executable_state','unchanged_executable','function_signature')
    check(all(ast.dump(defs[name],include_attributes=False)==ast.dump(parent_defs[name],include_attributes=False) for name in utility_names),
        'twelve cold raw/executable callback utilities AST exact')
    prior=HERE/'arithmetic_Q_controls_worker_v1.py';patch=HERE/'worker-v1-to-v3.patch'
    with patch.open('x') as f:f.write(''.join(difflib.unified_diff(prior.read_text().splitlines(True),worker.read_text().splitlines(True),fromfile=str(prior),tofile=str(worker))))
    rejected=HERE/'arithmetic_Q_controls_worker_v2.py'
    error=None
    try:ast.parse(rejected.read_bytes())
    except SyntaxError as exc:error=dict(type=type(exc).__name__,message=str(exc),line=exc.lineno)
    check(error is not None,'intermediate V2 indentation authoring failure retained, never invoked')
    all_refs=[]
    def scan(v):
        if isinstance(v,dict):
            if set(v)=={'path','sha256','bytes'}:
                actual=pin(Path(v['path']));all_refs.append(v);check(actual==v,'raw pin '+v['path'])
            for x in v.values():scan(x)
        elif isinstance(v,list):
            for x in v:scan(x)
    scan(sources);scan(inputs)
    for p in inputs.values():scan(json.loads(Path(p['path']).read_bytes()))
    owner=pin(ROOT/'.gcts-active/equality-receptor-family-extraction-progress-20261014/run_owned_bridge_v2.py')
    closer=pin(ROOT/'.gcts-active/equality-receptor-family-extraction-progress-20261014/close_stage_decision_v1.py')
    runtime=json.loads((ROOT/'.gcts-active/hilbert-next-owned-progress-20261013/ROOT-source-review-v1.json').read_bytes())['runtime']
    scan(owner);scan(closer);scan(runtime)
    check(all(c['passed'] for c in checks),'all author static metadata checks complete')
    conformance=save('Source-authoring-checks-v1.json',dict(schema='Q-cold-controls-author-Source-checks-v1',source_only=True,
        author_identity='/root/arithmetic_induction',scientific_calls=0,project_imports=0,source_function_calls=0,tests_executed=0,
        checks=checks,all_checks_passed=all(c['passed'] for c in checks),sources=sources,
        intermediate_unactivated_Source_failure=dict(source=pin(rejected),syntax_error=error,root_cause='Metadata string indentation in first direct-guard authoring helper; final V3 fixes text only.',scientific_calls=0),
        selected_source=pin(worker),old_worker_preserved=pin(prior),worker_delta=pin(patch),
        metadata_freezer_seconds_before_serialization=time.perf_counter()-began,
        authoring_cost='Text/metadata authoring helper invocations are separate preparation; total interactive Source authorship wall is uninstrumented/UNKNOWN, not asserted0. No scientific execution.'))
    contract=save('source-contract-v1.json',dict(schema='Q-open-empty-Gamma-cold-controls-source-contract-v1',
        author_identity='/root/arithmetic_induction',source_only=True,scientific_calls=0,project_imports=0,source_function_calls=0,
        sources=sources,inputs=inputs,entrypoint=dict(worker=sources['worker'],command='ROOT-Q-open-empty-Gamma-preparation-controls',
            argv=['exact canonical CLT runtime','-B',sources['worker']['path'],'ROOT-Q-open-empty-Gamma-preparation-controls','ABS worker-plan path','ABS owner-plan path'],
            payload='prepare_only(declaration=..., kernel_module=..., catalogue_module=..., graph_module=..., source_bindings=..., source_guard=..., deadline=...)',
            controls='run_controls(declaration=..., prepared=..., kernel_module=..., graph_module=..., source_bindings=..., source_guard=..., deadline=...)'),
        ABI=dict(leaf_count=11,owner_count=10,source_roles=7,input_roles=4,project_modules_raw_executed=5,stage='preparation',
            leaf_schema='ROOT-Q-open-empty-Gamma-controls-worker-plan-v1',scope='Q-complete-preparation-and-finite-controls-no-search-no-admission',
            leaf_fields=['schema','ROOT_owned_once_only','scope','sources','inputs','runtime','reviews','closure','limits','owner_plan_path','output_directory'],
            owner_schema='ROOT-guard-native-owned-plan-v1',owner=owner,closer=closer,
            actual_tool_protocol='ROOT invokes exact generic owner once and awaits initial exec_command plus same-handle polls in one functions.exec isolate, recording Date.now terminal before model return. No external tool wait4 claim.'),
        limits=dict(control_seconds=20,whole_seconds=60,peak_bytes=536870912,caller_seconds=90),runtime=runtime,
        output_names=['Q-preparation-provisional-v1.json','Q-controls-provisional-v1.json','Q-controls-evidence-v1.json','Q-controls-result-v1.json'],
        failure_outputs=['failure-v1.json','Q-controls-result-withdrawn-v1.json if a late final gate withdraws receipt'],
        raw_closure='Actual ROOT flat plans must close sources7/inputs4/runtime/reviews and every pin-valued field in the four named input documents. Generic owner closure is normalized ROOT-relative and must include entire canonical leaf closure plus worker plan. No actual plan is authored here.',
        Source_review_ABI=dict(scope='arithmetic-Q-complete-preparation-controls',source_only=True,source_review_passed='genuine distinct-author review only',
            scientific_calls=0,author_identity='/root/arithmetic_induction',reviewer_identity='must differ',sources=sources),
        scientific_scope=dict(target_latex='\\forall n\\;(n+S(0)=S(n))',theory='Exact AZ/AS addition recursion only, schemas empty; not full PA.',
            original_ordered_Gamma=[],grammar='Original declared full restricted Q grammar unchanged: operands<=3 plus open scoped subterms/two instantiation rounds/all operand pairs/all atomic closures/all implication MP.',
            typed_primitive_language='Zero-port original axioms/universal and equality schemas; unary generalize; ordered binary MP.',
            universal_theorem_discovered=False,first_proof_driver_available=False,induction_supported=False,native_accepted=False),
        controls_scope=['Capture-free open substitution/exact fresh spelling/shadowing/fresh-budget UNKNOWN.',
            'Unary generalization checks complete original Gamma, including an unused free-variable hypothesis and duplicate occurrences; local synthetic prior formulas are not licensed proofs.',
            'Every original24 initial point domain and every recipe represented by separate literal reference masks/Cartesian counts; no sampling or target backcone.',
            'Real full-catalog unary footprint has one prior mark/one offset and no second port; strict nonprior/multiple-ref negatives.',
            'One actual canonical master primitive then whole24 parametric recheck and exact state rollback, not a theorem-search episode.',
            'Tiny opaque fixtures separately test late dead over forced, forced over branch, earlier generation over smaller nonsingleton degree, assigned0 versus absent, and temporary nonlogical exclusion rollback.'],
        costs='shared20 starts before all five raw module loads and covers complete catalogue/kernel/graph/payload/provisional transport/control construction/census/results/evidence/receipt/final guards. Whole60 includes stdlib metadata preflight, serialization and all exit/reaping; own500MiB/55s reserves and generic2s/8MiB reserve are internal, not cap increases. Caller90 separate genuine observed clock.',
        unknown_semantics='Any catalogue/formula/visit/depth/fresh/domain/deadline/memory/transport failure is UNKNOWN incomplete, retained provisional artifacts and no usable stage receipt. Owner may reap cleanly while complete stage still fails.',
        source_integrity=['Exact raw Source buffers no .pyc; declared local module allowlist and literal runtime origins.',
            'Own rejection/executable/callback-state validators anchored before project loading; module globals/code/default/closure/MRO/property identities captured.',
            'Direct caller identity/code checks before every invoking-shim call; original callback/default/kwdefault/cell/content anchors.',
            'Actual constructed QChecker/Graph/Executor effective method/property endpoints captured before use and checked through the control guard; graph data may change only through explicit transactions.'],
        feasibility=dict(actual_counts=None,actual_wall_seconds=None,actual_peak_bytes=None,complete_target_universe_EOF_materialized=False,
            census_method='Exact parametric factor relation; full placement list may be enormous and is not silently sampled.',
            memory_risk='Complete catalogue plus production snapshots/independent factor witnesses and serializations coexist. Fits20s/512MiB unestablished; overflow yields UNKNOWN without rescue.',
            no_automatic_resource_expansion=True),
        remaining_gates=['Distinct-author whole Source review of current worker/callable/ABI and effective endpoint guards.',
            'ROOT metadata closure/actual once-only controls and full owned/caller qualification.',
            'Different-author complete grammar/semantic/domain auditor before any actual catalogue or point admission. These are producer-authored controls, not new semantic authority.',
            'Fresh unary-compatible traced first-proof search/current-state union/strict dependency endpoint; complete fallback/rollback trace verification.',
            'Unchanged native whole-proof correspondence and acceptance before native solved labels.'],
        conformance=conformance,Source_status='Implemented/frozen, syntax/metadata only; no actual q, graph, checker, preparation, controls, proof/search/native/RL activation.'))
    files=[]
    for path in sorted(HERE.iterdir()):
        if path.is_file():files.append(pin(path))
    manifest=save('integration-v1.json',dict(schema='Q-cold-controls-Source-integration-v1',files=files,source_only=True,scientific_calls=0))
    handoff=save('handoff-v1.json',dict(schema='Q-cold-controls-Source-handoff-v1',author_identity='/root/arithmetic_induction',
        worker=sources['worker'],controls=sources['controls'],sources=sources,contract=contract,Source_checks=conformance,integration=manifest,
        exact_target=inputs['declaration'],actual_output_status='NOT EXECUTED; counts/resources/admission UNKNOWN',
        next_action='Distinct-author Source review; ROOT alone constructs actual flat11/10 plans and invokes generic owner once after acceptance.',
        scientific_calls=0,project_imports=0,tests_executed=0,source_only=True,limits=dict(control_seconds=20,whole_seconds=60,peak_bytes=536870912,caller_seconds=90)))
    print(json.dumps(dict(handoff=handoff,contract=contract,checks=conformance,all_checks_passed=all(c['passed'] for c in checks),check_count=len(checks))))

if __name__=='__main__':main()
