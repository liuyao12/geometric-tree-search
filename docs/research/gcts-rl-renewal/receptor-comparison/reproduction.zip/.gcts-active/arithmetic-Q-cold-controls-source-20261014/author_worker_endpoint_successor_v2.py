"""Metadata/text-only authoring: direct invoke-shim checks, no Q calls."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent

def main():
    old=HERE/'arithmetic_Q_controls_worker_v1.py';new=HERE/'arithmetic_Q_controls_worker_v2.py'
    raw=old.read_text()
    block="""        def outer_guard():
            if function_signature(invoke_guard)!=invoke_anchor:raise ValueError('original invoking shim changed')
            invoke_fn()
"""
    assert raw.count(block)==1
    raw=raw.replace(block,'',1)
    # No unanchored extra nested delegation helper at the caller endpoints.
    guard="""if any(globals()[name] is not fn or fn.__code__ is not code for name,(fn,code) in validators.items()):
            raise ValueError('original own validator replaced at outer call boundary')
        if function_signature(invoke_guard)!=invoke_anchor:
            raise ValueError('original invoking shim changed at outer call boundary')
        invoke_fn()"""
    lines=[]
    for line in raw.splitlines():
        if 'outer_guard()' not in line:lines.append(line);continue
        # Separate semicolon commands so every guard invocation gets the direct
        # identity/code precheck before calling mutable function_signature.
        pieces=line.strip().split(';')
        for part in pieces:
            if part.strip()=='outer_guard()':lines.extend('        '+s for s in guard.splitlines())
            elif part.strip():lines.append('        '+part.strip())
    final='\n'.join(lines)+'\n'
    with new.open('x') as f:f.write(final)
    data=new.read_bytes()
    print(json.dumps(dict(worker=dict(path=str(new),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)),
        source_only=True,project_functions_called=0,prior_source_preserved=True)))

if __name__=='__main__':main()
