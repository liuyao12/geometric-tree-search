Notebook159 reproduction bundle.
The six scientific invocations and one failed predecessor are immutable records. Arithmetic output is provisional and unaccepted.
PUBLIC contains the reader, translated saved proof and evidence. Scientific Source contains exact absolute-path plans and source review prerequisites; do not overwrite or rerun those namespaces. A repeat experiment needs fresh outputs and qualified inputs.
No kernel, graph, search or RL is invoked by the reader. Proof metadata adaptation and post-terminal hash-helper compatibility are explicitly recorded and independently reviewed.
Runtime binaries are hash references only. The earlier known proof is replicated, not a new theorem.

Display successor: narrow-screen grid sizing and phrase spacing corrected after live verification; original display Source and before/after correction records are retained. Scientific records are unchanged.
