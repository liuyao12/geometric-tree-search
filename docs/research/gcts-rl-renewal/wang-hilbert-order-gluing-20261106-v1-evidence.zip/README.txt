Hilbert geometry from four-point clusters

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/hilbert_order_v1.py
  python3 -I -S -B source/order_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The first command repeats the exhaustive enumeration and receptor joins.
The second repeats the proof search and checks the fixed-palette Wang
certificates, including the bindings from wire names to formulas.
Either accepts --build to regenerate its data. The last command regenerates
the proof reader. MathJax typesets its formulas.
The manifest gives SHA-256 for each included input and result.
