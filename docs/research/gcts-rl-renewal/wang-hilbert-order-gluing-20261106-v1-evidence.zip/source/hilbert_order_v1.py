"""Exact four-point interfaces and finite Hilbert betweenness gluing."""
from collections import Counter, defaultdict
from itertools import combinations, permutations, product
import json
from math import comb
from pathlib import Path
from random import Random


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
POINTS = tuple(range(5))
TRIPLES = tuple(combinations(POINTS, 3))
QUADS = tuple(combinations(POINTS, 4))


def pattern(order):
    positions = {p: i for i, p in enumerate(order)}
    return tuple(sorted(triple, key=positions.get)[1] for triple in combinations(sorted(order), 3))


def orders(points):
    return {pattern(o): o for o in permutations(points) if o[0] < o[-1]}


def interface():
    tables = []
    for q in QUADS:
        ix = tuple(TRIPLES.index(t) for t in combinations(q, 3))
        p = tuple(sorted(orders(q)))
        assert len(ix) == 4 and len(p) == 12
        tables.append((ix, p))
    return tuple(tables)


class Receptors:
    def __init__(self):
        self.tables = interface()
        self.counters = Counter()
        self.learned = {}

    def possible(self, q, known, indexed):
        ix, rows = self.tables[q]
        if not indexed:
            result = []
            for i, row in enumerate(rows):
                self.counters["candidate_tests"] += 1
                if all(known.get(k, m) == m for k, m in zip(ix, row, strict=True)):
                    result.append(i)
            return result
        for k in ix:
            if k not in known:
                continue
            key = q, k, known[k]
            if key not in self.learned:
                column = ix.index(k)
                self.learned[key] = sum(1 << i for i, row in enumerate(rows) if row[column] != known[k])
                self.counters["receptors_formed"] += 1
                self.counters["candidate_tests"] += len(rows)
            else:
                self.counters["receptor_hits"] += 1
        mask = (1 << len(rows))-1
        for k in ix:
            if k in known:
                self.counters["mask_intersections"] += 1
                mask &= ~self.learned[q, k, known[k]]
        return [i for i in range(len(rows)) if mask & (1 << i)]

    def explore(self, indexed):
        full = []
        def descend(q, known, path):
            self.counters["prefixes"] += 1
            if q == len(self.tables):
                full.append((tuple(known[i] for i in range(len(TRIPLES))), path))
                return
            ix, rows = self.tables[q]
            for i in self.possible(q, known, indexed):
                descend(q+1, {**known, **dict(zip(ix, rows[i], strict=True))}, (*path, i))
        descend(0, {}, ())
        return full


def exact_models():
    """Independently evaluate all 3^10 possible abstract middle tables."""
    accepted = []
    by_mask = Counter()
    dropped = None
    # Check each quadruple against all 24 orders, including both directions.
    local = []
    for q in QUADS:
        coords = tuple(TRIPLES.index(t) for t in combinations(q, 3))
        admissible = set()
        for seq in permutations(q):
            value = tuple(next(p for p in seq if p in TRIPLES[k] and
                               any(seq.index(a) < seq.index(p) for a in TRIPLES[k]) and
                               any(seq.index(b) > seq.index(p) for b in TRIPLES[k]))
                          for k in coords)
            admissible.add(value)
        local.append((coords, admissible))
    for vector in product(*TRIPLES):
        mask = sum(1 << i for i, (coords, allowed) in enumerate(local)
                   if tuple(vector[k] for k in coords) in allowed)
        by_mask[mask] += 1
        if mask == 31:
            accepted.append(vector)
        if mask == 7 and dropped is None:
            dropped = vector
    return accepted, by_mask, dropped


def reconstruct(points, middle, anchors):
    """Read a pair comparison from its anchored three- or four-point interface."""
    points = tuple(sorted(points))
    a, b = anchors
    assert a != b and a in points and b in points
    less = {}
    for x, y in combinations(points, 2):
        q = tuple(sorted({a, b, x, y}))
        rows = []
        observed = tuple(middle[t] for t in combinations(q, 3))
        for o in permutations(q):
            if o.index(a) < o.index(b) and observed == pattern(o):
                rows.append(o.index(x) < o.index(y))
        assert rows and len(set(rows)) == 1
        less[x, y] = rows[0]
        less[y, x] = not rows[0]
    for x, y, z in permutations(points, 3):
        assert not (less[x, y] and less[y, z]) or less[x, z]
    ordered = tuple(sorted(points, key=lambda y: sum(less[x, y] for x in points if x != y)))
    assert pattern(ordered) == tuple(middle[t] for t in combinations(points, 3))
    return ordered


def lifted_examples(full):
    for vector, _ in full:
        middle = dict(zip(TRIPLES, vector, strict=True))
        order = reconstruct(POINTS, middle, (0, 1))
        assert reconstruct(POINTS, middle, (1, 0)) == order[::-1]
    rng = Random(321409)
    samples = []
    for n in (6, 8, 12, 18):
        vertices = tuple(range(n))
        order = tuple(rng.sample(vertices, n))
        middle = dict(zip(combinations(vertices, 3), pattern(order), strict=True))
        checked = 0
        for others in combinations(vertices[1:], 3):
            q = (0, *others)
            assert tuple(middle[t] for t in combinations(q, 3)) in orders(q)
            checked += 1
        new = reconstruct(vertices, middle, (0, 1))
        assert new in (order, order[::-1])
        assert checked == comb(n-1, 3)
        samples.append(dict(n=n, reconstructed=new, triples=len(middle), anchored=checked, all_quads=comb(n, 4)))
    return samples


def study():
    plain, marked = Receptors(), Receptors()
    a, b = plain.explore(False), marked.explore(True)
    exhaustive, counts, dropped = exact_models()
    assert a == b
    vectors = [v for v, _ in a]
    assert len(vectors) == len(set(vectors)) == len(exhaustive) == 60
    assert set(vectors) == set(exhaustive) == set(orders(POINTS))
    for omitted in range(len(QUADS)):
        required = 31 ^ (1 << omitted)
        assert sum(count for mask, count in counts.items() if mask & required == required) == 60
    for required in (m for m in counts if m.bit_count() == 3):
        assert sum(count for mask, count in counts.items() if mask & required == required) == 198
    assert dropped is not None and dropped not in orders(POINTS)
    for (q, k, middle), rejected in marked.learned.items():
        ix, rows = marked.tables[q]
        assert all(bool(rejected & (1 << i)) == (row[ix.index(k)] != middle) for i, row in enumerate(rows))
    return dict(total_middle_tables=sum(counts.values()), valid=len(vectors),
                scanned=dict(plain.counters), indexed=dict(marked.counters),
                patterns=vectors, schedules=[p for _, p in a],
                failure_marks=[(k, v) for k, v in sorted(marked.learned.items())],
                subset_counts={str(k): v for k, v in sorted(counts.items())},
                dropped_example=dropped, lifted=lifted_examples(a))


def main():
    import sys
    if not __debug__:
        raise RuntimeError("Order audit requires assertions")
    result = study()
    body = json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n"
    path = DATA / "order-v1.json"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body
    print({k: v for k, v in result.items() if k in
           ("total_middle_tables", "valid", "scanned", "indexed", "subset_counts", "dropped_example")})


if __name__ == "__main__":
    main()
