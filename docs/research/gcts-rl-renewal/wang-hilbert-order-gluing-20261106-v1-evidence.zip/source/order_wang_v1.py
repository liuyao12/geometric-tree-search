"""Discover a five-point order certificate by branching on four-point receptors."""
from argparse import ArgumentParser
from collections import Counter
import gzip
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/p) for p in ("source", "wang/source", "wang/external/source")]
from hilbert_order_v1 import DATA, POINTS, QUADS, TRIPLES, interface, orders
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from schematic_capsules_v1 import encoded, frozen
from study_v1 import Certificate


REQUIRED = tuple(range(4))
TARGET = ROOT / "wang/data"


def sel(q, j):
    return (f"select_{q}_{j}",)


def mid(k, p):
    return (f"middle_{k}_{p}",)


def case(q, lo, hi):
    return sel(q, lo) if hi-lo == 1 else (f"case_{q}_{lo}_{hi}",)


def domain(q):
    return case(q, 0, 12)


class Catalog:
    """Compile the axiom disjunctions, definition implications and negated target."""
    def __init__(self):
        self.tables = interface()
        self.rows = {}
        self.pattern_ids = {p: j for j, p in enumerate(sorted(orders(POINTS)))}
        for k, t in enumerate(TRIPLES):
            for a, b in combinations(t, 2):
                self.add(f"unique:{k}:{a}:{b}", (False, mid(k, a)), (False, mid(k, b)))
        for q in REQUIRED:
            coords, rows = self.tables[q]
            self.add(f"four-orders:{q}", (True, domain(q)))
            self.branches(q, 0, len(rows))
            for j, vector in enumerate(rows):
                for k, p in zip(coords, vector, strict=True):
                    self.add(f"join:{q}:{j}:{k}", (False, sel(q, j)), (True, mid(k, p)))
        for p, j in self.pattern_ids.items():
            self.add(f"exclude-five-order:{j}", *((False, mid(k, m)) for k, m in enumerate(p)))

    def add(self, name, *clause):
        assert name not in self.rows
        self.rows[name] = dict(id=name, variables={}, clause=clause)

    def branches(self, q, lo, hi):
        if hi-lo <= 1:
            return
        pivot = (lo+hi)//2
        self.add(f"split:{q}:{lo}:{hi}", (False, case(q, lo, hi)), (True, case(q, lo, pivot)),
                 (True, case(q, pivot, hi)))
        self.branches(q, lo, pivot)
        self.branches(q, pivot, hi)


def search():
    cat = Catalog()
    preds = {atom[0]: () for row in cat.rows.values() for _, atom in row["clause"]}
    cert = Certificate(cat.rows, {}, preds, ("U",), {})
    stats = Counter()
    instances, conflicts = {}, {}

    def source(name):
        if name not in instances:
            instances[name] = cert.instance(name, {})
        return instances[name]

    def fail(k, old, new):
        (a, qa, ja), (b, qb, jb) = sorted((old, new))
        assert a != b
        key = k, qa, ja, qb, jb
        if key not in conflicts:
            x = cert.resolve(source(f"join:{qa}:{ja}:{k}"), source(f"unique:{k}:{a}:{b}"), mid(k, a))
            conflicts[key] = cert.resolve(source(f"join:{qb}:{jb}:{k}"), x, mid(k, b))
            stats["certified_receptors"] += 1
        else:
            stats["reused_receptors"] += 1
        return conflicts[key]

    def finish(known):
        assert len(known) == len(TRIPLES)
        v = tuple(known[k][0] for k in range(len(TRIPLES)))
        j = cat.pattern_ids.get(v)
        if j is None:
            raise AssertionError("Counterexample to five-point gluing: " + repr(v))
        stats["global_orders"] += 1
        row = source(f"exclude-five-order:{j}")
        for k, (m, q, p) in sorted(known.items()):
            row = cert.resolve(source(f"join:{q}:{p}:{k}"), row, mid(k, m))
        return row

    def search_quad(depth, known):
        if depth == len(REQUIRED):
            return finish(known)
        q = REQUIRED[depth]
        coords, options = cat.tables[q]

        def visit(lo, hi):
            if hi-lo == 1:
                stats["candidate_tests"] += 1
                newly = {k: (p, q, lo) for k, p in zip(coords, options[lo], strict=True)}
                for k, value in newly.items():
                    old = known.get(k)
                    if old is not None and old[0] != value[0]:
                        return fail(k, old, value)
                return search_quad(depth+1, {**newly, **known})
            pivot = (lo+hi)//2
            left, right = visit(lo, pivot), visit(pivot, hi)
            a, b = case(q, lo, pivot), case(q, pivot, hi)
            if (False, a) not in cert.lines[left]["clause"]:
                return left
            if (False, b) not in cert.lines[right]["clause"]:
                return right
            node = source(f"split:{q}:{lo}:{hi}")
            node = cert.resolve(node, left, a)
            return cert.resolve(node, right, b)

        contradiction = visit(0, len(options))
        if (False, domain(q)) in cert.lines[contradiction]["clause"]:
            return cert.resolve(source(f"four-orders:{q}"), contradiction, domain(q))
        return contradiction

    root = search_quad(0, {})
    assert not cert.lines[root]["clause"]
    assert stats["global_orders"] == 60
    needed = set()
    todo = [root]
    while todo:
        i = todo.pop()
        if i not in needed:
            needed.add(i)
            row = cert.lines[i]
            if row["rule"] == "R":
                todo.extend((row["left"], row["right"]))
    order = sorted(needed)
    lookup = {old: new for new, old in enumerate(order)}
    lines = []
    for i in order:
        row = cert.lines[i]
        if row["rule"] == "R":
            row = {**row, "left": lookup[row["left"]], "right": lookup[row["right"]]}
        lines.append(row)
    assert not lines[-1]["clause"]
    return cat.rows, frozen(lines), dict(stats)


def prepare(sources, proof):
    wires, calls = {}, []
    for i, row in enumerate(proof):
        names, prefix, word = fragment(proof, i, sources, {})
        parsed = decoder.read(prefix, word+"!", require_empty=False)
        match(proof, i, sources, names, parsed, prefix)
        key = fingerprint(prefix, records(word))
        wire = wires.setdefault(key, dict(prefix=prefix, word=word, example=i+1, uses=0, rule=row["rule"]))
        assert (wire["prefix"], wire["word"]) == (prefix, word)
        wire["uses"] += 1
        calls.append(key)
    return wires, calls


def main():
    if not __debug__:
        raise RuntimeError("Proof replay requires assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    args = parser.parse_args()
    data = json.loads((DATA / "order-v1.json").read_text())
    assert data["valid"] == 60 and data["dropped_example"] is not None
    sources, proof, search_stats = search()
    wires, calls = prepare(sources, proof)
    bank_file = TARGET / "order-bank-v1.json.gz"
    proof_file = TARGET / "order-proof-v1.json.gz"
    receipt_file = TARGET / "order-receipt-v1.json"
    bank = build_bank(wires) if args.build else json.loads(gzip.decompress(bank_file.read_bytes()))
    result = dict(records=len(calls), search=search_stats, width=max(len(r["clause"]) for r in proof),
                  required=REQUIRED, **verify_bank(wires, bank))
    payload = dict(sources=sources, proof=proof, calls=calls)
    for file, value, compressed in ((bank_file, bank, True), (proof_file, payload, True), (receipt_file, result, False)):
        body = encoded(value)+b"\n"
        if args.build:
            file.write_bytes(gzip.compress(body, compresslevel=6, mtime=0) if compressed else body)
        else:
            raw = file.read_bytes()
            assert (gzip.decompress(raw) if compressed else raw) == body
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
