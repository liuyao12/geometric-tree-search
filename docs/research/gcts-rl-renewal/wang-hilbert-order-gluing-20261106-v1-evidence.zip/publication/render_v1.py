"""Render local order interfaces and a paged Wang certificate."""
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "source", "wang/source")]
from boundary_kernel_v1 import build
from hilbert_order_v1 import POINTS, QUADS, TRIPLES, interface, orders
from proof_views_v1 import frame_window, math, tile_svg

NAME = "wang-hilbert-order-gluing-20261106-v1"
TITLE = "Hilbert geometry from four-point clusters"
POINT = "ABCDE"


def read(path, compressed=False):
    raw = (ROOT / path).read_bytes()
    return json.loads(gzip.decompress(raw) if compressed else raw)


def names(points, op=","):
    return op.join(POINT[p] for p in points)


def atom(value):
    name, = value
    kind, *args = name.split("_")
    a, b, *rest = map(int, args)
    if kind == "select":
        return rf"Q_{{{a+1},{b+1}}}"
    if kind == "case":
        return rf"D_{{{a+1},[{b+1},{rest[0]+1})}}"
    assert kind == "middle"
    x, y = (p for p in TRIPLES[a] if p != b)
    return "B(" + names((x, b, y)) + ")"


def proof_data(proof):
    labels = {
        "four-orders": ("axiom", "At least one local order realizes the four middle choices."),
        "unique": ("axiom", "A triple can have only one middle point."),
        "join": ("definition", "The chosen local pattern fixes the middle point of this triple."),
        "split": ("definition", "Split the allowed pattern list into two cases."),
        "exclude-five-order": ("assumption", "The negated theorem excludes this global order."),
    }
    out = []
    for r in proof:
        row = dict(formula=r"\lor ".join(("" if s else r"\neg ") + atom(t) for s, t in r["clause"]) or r"\bot")
        if r["rule"] == "G":
            row["kind"], row["description"] = labels[r["source"].split(":")[0]]
        else:
            row.update(kind="resolve", description="Resolve on the selected formula.",
                       parents=[r["left"]+1, r["right"]+1], pivot=atom(r["pivot"]))
        out.append(row)
    return json.dumps(out, ensure_ascii=True, separators=(",", ":")).replace("<", r"\u003c")


def model_panel(vector):
    local = []
    for q, (coordinates, allowed) in zip(QUADS, interface(), strict=True):
        val = tuple(vector[k] for k in coordinates)
        passed = val in allowed
        detail = ("Local order " + math(names(orders(q)[val], r"\prec "))
                  if passed else "No order realizes these four middle choices.")
        state = "pass" if passed else "fail"
        local.append(f'<div class="receptor {state}"><strong>{math(names(q))}</strong><span>{detail}</span></div>')
    whole = orders(POINTS).get(tuple(vector))
    heading = ("Global order " + math(names(whole, r"\prec ")) if whole
               else "These middle choices have no common order.")
    facts = "".join("<li>" + math(atom((f"middle_{k}_{m}",))) + "</li>" for k, m in enumerate(vector))
    return f'<p><strong>{heading}</strong></p><div class="patches">{"".join(local)}</div><ul class="facts">{facts}</ul>'


def window(bank, key):
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    e = bank["traces"][key]
    end = e["steps"]
    trace = dict(prefix=e["prefix"], word=e["word"], padding=0, trace=e["fragment"])
    rows, col = frame_window(machine, trace, end-5, e["head"])
    types, cells = {}, []
    for y, row in enumerate(rows):
        for x, t in enumerate(row):
            i = types.setdefault(t, len(types))
            cells.append(f'<use href="#wang-{i}" x="{36*x}" y="{36*y}"/>')
    defs = "".join(tile_svg(t, i) for t, i in types.items())
    return (f'<figure><svg role="img" aria-label="Window of 45 checked Wang squares" viewBox="0 0 324 180">'
            f'<defs>{defs}</defs>{"".join(cells)}</svg><figcaption>Verifier rows {end-4:,} to {end:,} '
            f'and tape columns {col:,} to {col+8:,}. Point to a square for its exact edge labels.</figcaption></figure>')


def main():
    data = read("data/order-v1.json")
    certificate = read("wang/data/order-proof-v1.json.gz", True)
    bank = read("wang/data/order-bank-v1.json.gz", True)
    receipt = read("wang/data/order-receipt-v1.json")
    tests = "".join(f'<tr><th scope="row">{r["n"]}</th><td>{r["all_quads"]:,}</td><td>{r["anchored"]:,}</td>'
                    f'<td>{r["triples"]:,}</td></tr>' for r in data["lifted"])
    fields = dict(
        title=TITLE, total=f'{data["total_middle_tables"]:,}', valid=str(data["valid"]),
        good=model_panel(data["patterns"][31]), bad=model_panel(data["dropped_example"]), tests=tests,
        plain=f'{data["scanned"]["candidate_tests"]:,}', indexed=str(data["indexed"]["candidate_tests"]),
        masks=str(data["indexed"]["mask_intersections"]), records=str(receipt["records"]),
        display_records=f'{receipt["records"]:,}', fragments=str(receipt["unique_fragments"]),
        proof=proof_data(certificate["proof"]), window=window(bank, certificate["calls"][-1]), stem=NAME,
    )
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    body = (ROOT / "publication/order-body-v1.html").read_text()
    for key, value in fields.items():
        body = body.replace("%%"+key.upper()+"%%", value)
    assert "%%" not in body
    (ROOT / "report" / (NAME+".html")).write_text(head+body)


if __name__ == "__main__":
    main()
