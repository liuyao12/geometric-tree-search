const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/wang-hilbert-order-gluing-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#record mjx-container").first().waitFor();
      assert.match(await page.locator("#record strong").innerText(), /Record 4853 of 4853/);
      await page.locator("#record .links button").first().click();
      await page.waitForFunction(() => !document.querySelector("#record strong").textContent.startsWith("Record 4853 "));
      await page.locator("#first").click();
      await page.waitForFunction(() => document.querySelector("#record strong").textContent.startsWith("Record 1 "));
      await page.getByText("Counterexample when only three quadruples are checked").click();
      assert.equal(await page.locator("#experiment .receptor.fail:visible").count(), 2);
      assert.equal(await page.locator("#theorem tbody tr").count(), 4);
      assert.equal(await page.locator("#tiles use").count(), 45);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.deepEqual(errors, []);
      const layout = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        sections: [...document.querySelectorAll("main > section")].filter(node =>
          node.scrollWidth > node.clientWidth + 4).map(node => node.id),
      }));
      assert.deepEqual(layout, { width, sections: [] });
      await page.locator("#experiment").screenshot({ path: "publication/clusters-" + width + ".png" });
      await page.locator("#tiles").screenshot({ path: "publication/wang-" + width + ".png" });
      console.log("Verified", width, "px, order examples, proof navigation and Wang squares.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
