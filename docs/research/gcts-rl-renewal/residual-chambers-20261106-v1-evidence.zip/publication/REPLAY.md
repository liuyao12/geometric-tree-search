# Replay fixed-boundary chamber search

Extract the archive and run this from its root with CPython 3.12.

```sh
python3.12 -I -S -B publication/replay_v1.py
```

The replay regenerates all connected outlines, the three guided comparison arms, the unseeded separator experiment, the independent certificate audit, and the visual report. It compares five generated outputs byte for byte. It retains the timing sample as an input because elapsed times depend on the machine.

To repeat the five timing samples, run the following command in an extracted copy. It overwrites the timing sample in that copy.

```sh
python3.12 -I -S -B source/chamber_timing_v1.py
```

The search operates on allowed Turtle lattice poses and unmarked Penrose unit rhombs. A refutation is scoped to its exact fixed boundary and any prescribed seed tiles. A bounded result carries no feasibility conclusion.
