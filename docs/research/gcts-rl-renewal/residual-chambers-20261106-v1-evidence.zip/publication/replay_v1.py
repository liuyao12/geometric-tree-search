"""Regenerate the checked chamber experiment in a clean directory."""
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from subprocess import run
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
STEM = "residual-chambers-20261106-v1"
OUTPUTS = ("input/chambers-v1.json", "data/chambers-v1.json", "data/chambers-port-v1.json",
           "data/chambers-audit-v1.json", f"report/{STEM}.html")
TIMING = "data/chambers-timing-v1.json"
STAGES = ("source/chamber_cases_v1.py", "source/chamber_experiment_v1.py",
          "source/chamber_port_experiment_v1.py", "source/chamber_check_v1.py", "publication/render_v1.py")


def inputs():
    return tuple(sorted(str(p.relative_to(ROOT)) for folder in ("source", "publication")
                        for p in (ROOT / folder).glob("*.py"))) + (
        "input/exact-point-model-v1.json", "input/chamber-origins-v1.json",
        TIMING, "publication/notebook-v1.html",
    )


def main():
    with TemporaryDirectory() as temp:
        clean = Path(temp)
        for name in (*inputs(), *OUTPUTS):
            (clean / name).parent.mkdir(parents=True, exist_ok=True)
        for name in inputs():
            copyfile(ROOT / name, clean / name)
        for name in STAGES:
            run((sys.executable, "-I", "-S", "-B", name), cwd=clean, check=True)
        digests = {}
        for name in OUTPUTS:
            actual = (clean / name).read_bytes()
            assert actual == (ROOT / name).read_bytes(), name
            digests[name] = sha256(actual).hexdigest()
    result = dict(status="CHECKED_CLEAN_REPLAY", sha256=digests,
                  timing_sha256=sha256((ROOT / TIMING).read_bytes()).hexdigest())
    (ROOT / "publication/replay-v1.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(f"Matched {len(digests)} outputs byte for byte.")


if __name__ == "__main__":
    main()
