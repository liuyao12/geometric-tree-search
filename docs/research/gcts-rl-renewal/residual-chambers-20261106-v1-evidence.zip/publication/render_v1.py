"""Draw actual chamber joins and summarize the checked search arms."""
from html import escape
import json
from math import cos, pi, sin, sqrt
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from chamber_cases_v1 import geometry
from chamber_check_v1 import frozen
from chamber_experiment_v1 import read_cases
from geometry_v1 import add

STEM = "residual-chambers-20261106-v1"
LABELS = {"direct": "Direct", "split": "Fresh split", "reuse": "Reuse",
          "plain": "Unhinted reuse", "automatic": "Boundary scan", "receptor": "Learned two-contact receptor"}


def read(name):
    return frozen(json.loads((ROOT / f"data/chambers{name}-v1.json").read_text()))


def table(headers, rows):
    head = "".join(f'<th scope="col">{h}</th>' for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{value}</td>" for value in row) + "</tr>" for row in rows)
    return f'<div class="table"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def cartesian(p):
    if len(p) == 2:
        return p[0] + p[1] / 2, -sqrt(3) * p[1] / 2
    return (sum(v * cos(2 * pi * i / 5) for i, v in enumerate(p)),
            -sum(v * sin(2 * pi * i / 5) for i, v in enumerate(p)))


def figure(name, case, result, library, caption):
    g = geometry(name)
    event = next(e for e in result["splits"] if e["outcome"] in ("positive", "negative"))
    shapes = []
    for i, (index, anchor) in enumerate(event["parts"]):
        record = library[index]
        style = ("left", "right")[i % 2]
        if record["result"]["status"] == "POSITIVE":
            for tile in record["result"]["patch"]:
                shapes.append((style, g.poly(g.shift(tile, anchor))))
        else:
            shapes.append(("bad", tuple(add(p, anchor) for p in record["ring"])))
    if event["outcome"] == "negative":
        # Show the other residual cycle as an outline even though it needs
        # no cover to establish this refutation.
        attempted = {tuple(add(p, anchor) for p in library[index]["ring"]) for index, anchor in event["parts"]}
        for ring in case["known_parts"]:
            if ring not in attempted:
                shapes.insert(0, ("right", ring))
    shapes.extend(("bridge", g.poly(tile)) for tile in event["path"])
    shapes.extend(("outer", ring) for ring in case["rings"])
    all_points = [[cartesian(p) for p in ring] for _, ring in shapes]
    xs, ys = zip(*(p for poly in all_points for p in poly))
    left, top = min(xs), min(ys)
    width, height = max(xs) - left, max(ys) - top
    padding = max(width, height) * .07
    view = f"{-padding:.5f} {-padding:.5f} {width + 2*padding:.5f} {height + 2*padding:.5f}"
    polygons = []
    for (style, _), coordinates in zip(shapes, all_points, strict=True):
        points = " ".join(f"{x - left:.5f},{y - top:.5f}" for x, y in coordinates)
        polygons.append(f'<polygon class="{style}" points="{points}"/>')
    return (f'<figure><svg viewBox="{view}" role="img" aria-label="{escape(caption, quote=True)}">'
            f'{"".join(polygons)}</svg><figcaption>{escape(caption)}</figcaption></figure>')


def summarize(rows, arm):
    selected = [row["arms"][arm] for row in rows]
    return (sum(a["status"] != "BOUNDED" for a in selected),
            *(sum(a["counts"].get(key, 0) for a in selected)
              for key in ("nodes", "tile_tests", "cross_request_hits")))


def detail(rows):
    entries = []
    for row in rows:
        outcomes = []
        for arm in ("direct", "split", "reuse"):
            result = row["arms"][arm]
            label = result["status"].lower()
            outcomes.append(f'{label} · {result["counts"].get("nodes", 0)}')
        entries.append((row["id"], *outcomes))
    return table(("Request", "Direct", "Fresh split", "Reuse"), entries)


def main():
    experiment, ports, timing, audit = (read(suffix) for suffix in ("", "-port", "-timing", "-audit"))
    rows = {row["id"]: row for cases in read_cases().values() for row in cases}
    comparison, proposals, times, certificates, details = [], [], [], [], []
    for name, system in experiment["systems"].items():
        held = [r for r in system["cases"] if rows[r["id"]]["split"] == "test"]
        for arm in ("direct", "split", "reuse"):
            comparison.append((name.title(), LABELS[arm], *summarize(held, arm)))
        details.append(f'<details><summary>{name.title()} case outcomes and nodes</summary>{detail(held)}</details>')
        auto = ports["systems"][name]["cases"]
        for arm in ("plain", "automatic", "receptor"):
            accepted, nodes, tests, hits = summarize(auto, arm)
            offers = sum(bool(r["arms"][arm]["proposal"]) for r in auto)
            scans = sum(r["arms"][arm]["counts"].get("portal_poses", 0) for r in auto)
            proposals.append((name.title(), LABELS[arm], accepted, nodes, tests, offers, scans, hits))
        for arm in ("direct", "split", "reuse", "plain", "automatic", "receptor"):
            measured = timing["systems"][name][arm]
            measured_rows = held if arm in ("direct", "split", "reuse") else auto
            signature = tuple((r["arms"][arm]["status"], r["arms"][arm]["counts"].get("nodes", 0),
                               r["arms"][arm]["counts"].get("portal_split_checks", 0)) for r in measured_rows)
            assert measured["signature"] == signature
            times.append((name.title(), LABELS[arm], f'{median(measured["donor_ns"])/1e6:.1f}',
                          f'{median(measured["test_ns"])/1e6:.1f}'))
        for arm, record in audit["systems"][name].items():
            certificates.append((name.title(), LABELS.get(arm.removeprefix("port_"), arm),
                                 *(record.get(k, 0) for k in ("checked_options", "checked_library_records",
                                                             "checked_split_events", "checked_port_proposals"))))

    turtle = ports["systems"]["turtle"]
    t_case = next(r for r in turtle["cases"] if r["id"] == "turtle-chambers-07")
    positive = figure("turtle", rows[t_case["id"]], t_case["arms"]["automatic"], turtle["library"]["automatic"],
                      "Turtle. The solver proposed the amber bridge without a hint and joined two cached covers.")
    penrose = experiment["systems"]["penrose"]
    p_case = next(r for r in penrose["cases"] if r["id"] == "penrose-chambers-08")
    negative = figure("penrose", rows[p_case["id"]], p_case["arms"]["reuse"], penrose["library"]["reuse"],
                      "Penrose. With the amber bridge prescribed, the red chamber reuses an exact refutation.")
    fields = dict(FIGURES=f'<div class="grid">{positive}{negative}</div>',
        CONTROL=table(("System", "Arm", "Decided of 10", "Nodes", "Tile checks", "Cross-request hits"), comparison),
        PORTS=table(("System", "Arm", "Decided of 10", "Nodes", "Tile checks", "Proposals", "Poses scanned",
                     "Cross-request hits"), proposals),
        TIMING=table(("System", "Arm", "Donor batch, ms", "Held-out batch, ms"), times),
        DETAILS="".join(details),
        AUDIT=table(("System", "Arm", "Placement options checked", "Library records checked", "Split events checked",
                     "Proposals checked"), certificates))
    page = (ROOT / "publication/notebook-v1.html").read_text()
    for key, value in fields.items():
        page = page.replace(f"%%{key}%%", value)
    assert "%%" not in page
    (ROOT / f"report/{STEM}.html").write_text(page)


if __name__ == "__main__":
    main()
