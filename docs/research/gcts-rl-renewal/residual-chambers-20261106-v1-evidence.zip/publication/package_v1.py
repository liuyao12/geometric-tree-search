"""Package the exact chamber study and its verified replay inputs."""
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
from replay_v1 import OUTPUTS, ROOT, STEM, TIMING, inputs


def read(name):
    return json.loads((ROOT / name).read_text())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def pin(raw):
    return dict(bytes=len(raw), sha256=sha256(raw).hexdigest())


def main():
    replay = read("publication/replay-v1.json")
    assert set(replay["sha256"]) == set(OUTPUTS)
    assert all(pin((ROOT / path).read_bytes())["sha256"] == digest for path, digest in replay["sha256"].items())
    assert pin((ROOT / TIMING).read_bytes())["sha256"] == replay["timing_sha256"]
    browser = read("publication/browser-v1.json")
    assert browser["status"] == "CHECKED_CHAMBER_READER"
    experiment = read("data/chambers-v1.json")
    ports = read("data/chambers-port-v1.json")
    condensed = dict(guided={}, unseeded={})
    for key, value in (("guided", experiment), ("unseeded", ports)):
        for name, system in value["systems"].items():
            condensed[key][name] = [
                dict(id=row["id"], arms={arm: {k: result[k] for k in ("status", "counts", "proposal")}
                                          for arm, result in row["arms"].items()})
                for row in system["cases"]
            ]
    result_name = f"report/{STEM}-results.json"
    save(result_name, dict(schema="RESIDUAL-CHAMBERS-RESULTS-v1", experiment=condensed, replay=replay,
                          browser=browser, audit=read("data/chambers-audit-v1.json"), timing=read(TIMING)))
    paths = (*inputs(), *OUTPUTS, result_name, "publication/REPLAY.md", "publication/check_v1.cjs",
             "publication/browser-v1.json", "publication/replay-v1.json")
    archive = ROOT / f"report/{STEM}-evidence.zip"
    manifest = {}
    with ZipFile(archive, "w") as bundle:
        for name in paths:
            raw = (ROOT / name).read_bytes()
            assert name not in manifest, name
            assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), name
            manifest[name] = pin(raw)
            entry = ZipInfo(name, (2026, 11, 6, 0, 0, 0))
            entry.external_attr = 0o100644 << 16
            bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {name: pin(bundle.read(name)) for name in bundle.namelist()} == manifest
    files = (archive, ROOT / result_name, ROOT / f"report/{STEM}.html")
    save(f"report/{STEM}-manifest.json", dict(schema="RESIDUAL-CHAMBERS-MANIFEST-v1",
        archive_entries=manifest, assets={path.name: pin(path.read_bytes()) for path in files}))
    print(f"Packaged {len(manifest)} evidence files.")


if __name__ == "__main__":
    main()
