"""Time matched batches with donor costs recorded separately."""
from pathlib import Path
import sys
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from chamber_cases_v1 import geometry
from chamber_experiment_v1 import LIMIT, MODES, read_cases, solve, write
from chambers_v1 import Library, Search
from model_v1 import clear_geometry

REPEATS = 5


def batch(name, cases, arm):
    clear_geometry()
    g = geometry(name)
    bank = Library()
    mode = arm if arm in MODES else "reuse"
    started = perf_counter_ns()
    for row in cases:
        if row["split"] == "train":
            solve(g, bank, row, mode)
    training = perf_counter_ns() - started
    start = perf_counter_ns()
    answers = []
    for row in cases:
        if row["split"] != "test":
            continue
        if arm in MODES:
            result = solve(g, bank, row, mode)
        else:
            strategy = {"plain": False, "automatic": "scan", "receptor": "receptor"}[arm]
            search = Search(g, bank, mode=mode, auto_port=strategy, case=row["id"], limit=LIMIT)
            result = search.solve(row["rings"])
        answers.append(result)
    elapsed = perf_counter_ns() - start
    key = tuple((a["status"], a["counts"].get("nodes", 0), a["counts"].get("portal_split_checks", 0))
                for a in answers)
    return training, elapsed, key


def main():
    receipt = {}
    arms = (*MODES, "plain", "automatic", "receptor")
    for name, cases in read_cases().items():
        results = {arm: dict(donor_ns=[], test_ns=[]) for arm in arms}
        for i in range(REPEATS):
            for arm in arms[i:] + arms[:i]:
                before, after, key = batch(name, cases, arm)
                row = results[arm]
                assert key == row.setdefault("signature", key)
                row["donor_ns"].append(before)
                row["test_ns"].append(after)
        receipt[name] = results
    write("data/chambers-timing-v1.json", dict(repeats=REPEATS, systems=receipt))


if __name__ == "__main__":
    main()
