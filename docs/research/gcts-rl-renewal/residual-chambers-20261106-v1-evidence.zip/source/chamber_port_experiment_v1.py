"""Compare automatic separator proposals with the unhinted search."""
from copy import deepcopy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from chamber_cases_v1 import geometry
from chamber_experiment_v1 import LIMIT, read_cases, solve, write
from chambers_v1 import Library, Search


def prepare(g, cases):
    donor = Library()
    for row in cases:
        if row["split"] == "train":
            solve(g, donor, row, "reuse")
    return donor


def main():
    data = {}
    for name, cases in read_cases().items():
        g = geometry(name)
        seed_bank = prepare(g, cases)
        banks = {arm: deepcopy(seed_bank) for arm in ("plain", "automatic", "receptor")}
        strategies = {"plain": False, "automatic": "scan", "receptor": "receptor"}
        result = []
        for row in cases:
            if row["split"] != "test":
                continue
            arms = {arm: Search(g, bank, mode="reuse", auto_port=strategies[arm],
                                case=row["id"], limit=LIMIT).solve(row["rings"]) for arm, bank in banks.items()}
            decisions = {r["status"] for r in arms.values()} - {"BOUNDED"}
            assert len(decisions) <= 1, (row["id"], decisions)
            if row["expected_seeded"] == "POSITIVE":
                assert decisions <= {"POSITIVE"}
            result.append(dict(id=row["id"], arms=arms))
            print(row["id"], [(arm, out["status"], out["counts"].get("nodes"),
                               out["counts"].get("portal_split_checks", 0),
                               bool(out["proposal"])) for arm, out in arms.items()], flush=True)
        data[name] = dict(cases=result, library={a: b.records for a, b in banks.items()},
                          donor_receptors=sum(map(len, seed_bank.receptors.values())))
    write("data/chambers-port-v1.json", dict(status="CHECKED_AUTOMATIC_SEPARATOR_COMPARISON", systems=data))


if __name__ == "__main__":
    main()
