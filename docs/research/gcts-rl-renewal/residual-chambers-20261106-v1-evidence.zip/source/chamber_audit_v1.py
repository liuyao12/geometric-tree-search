"""Check exact covers, exhaustive refutations and translated chamber joins."""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import combinations

from chamber_cases_v1 import edges as outline
from chambers_v1 import normalized, split_rings
from check_v1 import contact, corners
from clipping_v1 import intersection, side, sign, twice
from geometry_v1 import add, area, check_rings, pairs, sub
from triangle_geometry_v1 import _clip, area2, polygon_overlap, triangulate


def physical(point):
    a, b, c, d = point
    return (Fraction(2*a-b, 2), Fraction(b-c-d, 2)), (c-d, b)


@lru_cache(maxsize=500)
def field_triangles(ring):
    points = [physical(p) for p in ring]
    if sign(twice(points)) < 0:
        points.reverse()
    total = twice(points)
    out = []
    while len(points) > 3:
        n = len(points)
        for i in range(n):
            a, b, c = points[i - 1], points[i], points[(i + 1) % n]
            turn = sign(side(a, b, c))
            if not turn:
                del points[i]
                break
            if turn < 0 or any(
                all(sign(side(p, q, v)) >= 0 for p, q in pairs((a, b, c)))
                for j, v in enumerate(points) if j not in ((i - 1) % n, i, (i + 1) % n)
            ):
                continue
            out.append((a, b, c))
            del points[i]
            break
        else:
            raise AssertionError("No exact ear")
    if sign(twice(points)):
        assert sign(twice(points)) > 0
        out.append(tuple(points))
    assert tuple(map(sum, zip(*(twice(t) for t in out)))) == total
    return tuple(out)


@lru_cache(maxsize=2000)
def axial_triangles(ring):
    return triangulate(ring)


class Audit:
    def __init__(self, geometry, library):
        self.g = geometry
        self.library = library
        self.counts = Counter()
        self.checked = set()

    def rings(self, rings):
        check_rings(self.g, rings)
        mass = tuple(map(sum, zip(*(area(r, self.g.cross) for r in rings))))
        return frozenset(e for ring in rings for e in outline(self.g, ring)), self.g.counts(mass)

    @lru_cache(maxsize=20000)
    def contained(self, rings, tile):
        polygon = self.g.poly(tile)
        if any(self.g.wind(rings[0], p, 1) == 0 for p in polygon):
            return False
        if any(self.g.wind(ring, p, 1) == -1 for ring in rings[1:] for p in polygon):
            return False
        if self.g.kind == "turtle":
            triangles = axial_triangles(polygon)
            by_ring = [sum(abs(area2(_clip(a, b))) for a in triangles for b in axial_triangles(ring))
                       for ring in rings]
            exact = by_ring[0] - sum(by_ring[1:])
            return exact == abs(area2(polygon))
        polygon = tuple(physical(p) for p in polygon)
        total = (0, 0)
        for i, ring in enumerate(rings):
            for target in field_triangles(ring):
                local = intersection(polygon, target)
                total = add(total, local) if i == 0 else sub(total, local)
        return total == twice(polygon)

    @lru_cache(maxsize=30000)
    def legal(self, a, b):
        if self.g.kind == "penrose":
            return contact(a, b)
        return not polygon_overlap(self.g.poly(a), self.g.poly(b))["overlap"]

    @lru_cache(maxsize=20000)
    def options(self, edge):
        g = self.g
        a, b = edge
        if g.kind == "penrose":
            return {tile for tile in corners(a) if edge in g.boundary(tile)}
        candidates = set()
        for pose in g.bases:
            for p, q in g.boundary(pose):
                if sub(q, p) == sub(b, a):
                    candidates.add(g.shift(pose, sub(a, p)))
        return candidates

    def cut(self, boundary, tile):
        current = Counter({e: 1 for e in boundary})
        current.subtract(self.g.boundary(tile))
        directed = {e if n > 0 else e[::-1] for e, n in current.items() if n}
        assert all(abs(n) <= 1 for n in current.values())
        assert all(e[::-1] not in directed for e in directed)
        return frozenset(directed)

    def validate_path(self, rings, path):
        assert len(path) == len(set(path))
        for tile in path:
            assert self.contained(rings, tile)
        assert all(self.legal(a, b) for a, b in combinations(path, 2))

    def chamber(self, index):
        assert type(index) is int and 0 <= index < len(self.library)
        if index not in self.checked:
            record = self.library[index]
            form = record["ring"]
            assert normalized(form)[0] == form
            self.result((form,), (), record["result"], allow_split=False)
            self.checked.add(index)
            self.counts["checked_library_records"] += 1
        return self.library[index]

    def state(self, rings, seed):
        boundary, remaining = self.rings(rings)
        if seed:
            assert remaining is not None
            self.validate_path(rings, seed)
        for tile in seed:
            boundary = self.cut(boundary, tile)
            remaining = sub(remaining, self.g.mass(tile))
        return boundary, remaining

    def result(self, rings, seed, result, allow_split=True):
        boundary, remaining = self.state(rings, seed)
        assert result["status"] in ("POSITIVE", "NEGATIVE", "BOUNDED")
        if result["status"] == "POSITIVE":
            patch = result["patch"]
            assert patch[:len(seed)] == seed
            self.validate_path(rings, patch)
            boundary, remaining = self.state(rings, patch)
            assert not boundary and not any(remaining)
            self.counts["positive_witnesses"] += 1
        elif result["status"] == "NEGATIVE":
            self.refute(rings, boundary, seed, remaining, result["proof"], allow_split)
            self.counts["negative_witnesses"] += 1

    def refute(self, rings, boundary, path, remaining, proof, allow_split):
        kind = proof["kind"]
        if kind == "area":
            assert remaining is None
            return
        assert boundary and remaining is not None and all(x >= 0 for x in remaining)
        if kind == "split":
            assert allow_split
            cycles = split_rings(self.g, boundary)
            assert cycles
            record = self.chamber(proof["record"])
            assert record["result"]["status"] == "NEGATIVE"
            moved = tuple(add(p, proof["anchor"]) for p in record["ring"])
            assert outline(self.g, moved) in {outline(self.g, ring) for ring in cycles}
            self.counts["negative_split_uses"] += 1
            return
        assert kind == "branch"
        edge, choices = proof["edge"], proof["choices"]
        assert edge in boundary
        assert len({t for t, _ in choices}) == len(choices)
        assert {t for t, _ in choices} == self.options(edge)
        for tile, block in choices:
            left = sub(remaining, self.g.mass(tile))
            if block == "outside":
                assert not self.contained(rings, tile)
            elif block == "conflict":
                assert any(not self.legal(tile, other) for other in path)
            elif block == "mass":
                assert any(x < 0 for x in left)
            else:
                assert not any(x < 0 for x in left)
                assert self.contained(rings, tile) and all(self.legal(tile, t) for t in path)
                self.refute(rings, self.cut(boundary, tile), (*path, tile), left, block, allow_split)
            self.counts["checked_options"] += 1

    def join(self, rings, event):
        path = event["path"]
        boundary, remaining = self.state(rings, path)
        cycles = split_rings(self.g, boundary)
        assert cycles
        targets = {outline(self.g, ring) for ring in cycles}
        residual = set(targets)
        combined = []
        negative = False
        for index, anchor in event["parts"]:
            assert not negative
            record = self.chamber(index)
            local = outline(self.g, tuple(add(p, anchor) for p in record["ring"]))
            assert local in residual
            residual.remove(local)
            result = record["result"]
            negative = result["status"] == "NEGATIVE"
            if not negative:
                combined.extend(self.g.shift(tile, anchor) for tile in result["patch"])
        if event["outcome"] == "negative":
            assert negative
        elif event["outcome"] == "positive":
            assert not negative and not residual
            self.result(rings, path, dict(status="POSITIVE", patch=(*path, *combined)))
        else:
            assert event["outcome"] == "fallback" and not negative and not residual
            assert any(not self.legal(tile, other) for tile in combined for other in path)
        self.counts["checked_split_events"] += 1
